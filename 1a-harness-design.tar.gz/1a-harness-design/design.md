# Harness design: routing reporting (2026-11-16) and the 1a harness

Read-only design. Nothing here has run a model, touched git or edited the checkout. It is written against the
code-name rename's new identifiers (`--via tuesday`, `--arm tuesday`, `install_tuesday`, `tuesday_fire`,
`tuesday_digests`, `check_tuesday`, `MEASURED_TUESDAY`, `tuesday_sha256`). Line numbers are from `HEAD`
(`adf322e`), before the rename.

Sources read: `docs/roadmap-now-l1-plan.md` (Measurement and evidence; Entry and pins; Write boundary; Harness
contract and preflight; Manifest, recovery and evidence handling; Items 1, 3, 4, the iteration-2 item and 2;
E16, E17, E19, E23, E24; Statistical acceptance; Regression acceptance and calibration), `docs/tracked-work.md:89-96`,
`docs/fix-round-plan-detail.md:1174-1201` (killed runs), `evals/run_fixtures.py`, `evals/output_checks.py`,
`evals/child_env.py`, `evals/run_routing.py`, `evals/compare_arms.py`, `evals/fixture_clauses.py`,
`ci/check_skills.py`, `ci/test_checks.py`, `evals/test_harness.py`, `evals/README.md`, `CONTRIBUTING.md:168-204`,
and the fix round's scratch tools (`fixround/round/grade_gaps.py`, `merge_routing.py`, `qrule/recheck.py`).

## 0. Ground rules both commits keep

1. **Below both pins, no payload change.** Neither commit touches `skills/`, `conventions/`, `dist/`, `ci/sync.py`
   or `ci/package.py`. `python ci/check_skills.py --only tuesday` and the three accepted digests stay byte-identical.
2. **A single-turn run sends exactly what it sends today.** E8 reuse of the fix round's 18 rooms needs the same
   settings. The launcher refactor (2.2) must keep each fixture run's argv, stdin, cwd and environment
   byte-identical. Test: a golden-argv check for project, plugin, denied and canned rooms, through Tuesday and alone.
3. **The single-turn grader prompt stays at version 3.** The transcript grader prompt is a separate, pinned text
   (2.3.8). Single-turn grade records gain `grader_prompt_sha256`. That key is additive, so `compare_arms` is
   unaffected.
4. **The scorer changes only where the plan says.** One existing check changes behaviour: the one-quotation quote
   fix. The new checks (`sentinel`, `gate_only`) apply only to fixtures that declare the new keys, and no fixture
   declares them until the 1a candidate. The fix round's saved runs are re-checked under the new scorer (2.6.4),
   so both revisions in each 1a comparison are scored by one scorer.
5. **Every new decline path has an explicit third outcome and a test** (CONTRIBUTING.md, "Harnesses report three
   outcomes, not two").

---

## 1. Commit A: routing reporting (2026-11-16)

Files: `evals/run_routing.py`, `evals/test_harness.py`, `evals/README.md`.

### 1.1 Requirement map

| Plan sentence (write boundary row) | Design element | Test |
|---|---|---|
| Record each run's `total_cost_usd` when its result event arrives | `RunReader.cost_usd`, set in `feed()` on `type == "result"`; written by `record()` as `cost_usd` | `test_reported_measures` (rewritten): a result event with `total_cost_usd: 0.0412` gives `cost_usd == 0.0412`; `test_layout_runs` through the stub CLI |
| …and count the runs stopped before it | `RunReader.result_read: bool`; `record()` writes `result_read`; `reported()` counts `stopped_before_result` | first-fire, timeout and process-exit runs give `result_read False` and are counted |
| tokens, seconds and cost cover only runs read to their result event | `reported()` sums `seconds`, `output_tokens` and `cost_usd` over runs with `result_read` only | `test_reported_measures` (rewritten): a stopped run's seconds are not summed |
| today's skills' fired runs are stopped early, so their figures do not compare with Tuesday's | `summary_lines()` states the coverage, and prints a comparability sentence when any decided run was stopped | exact-string test for a skills-arm and a Tuesday-arm line |
| E26: labeled API-price-equivalent estimates | the line labels cost "API-price equivalent, from result events" | in the exact-string test |

### 1.2 Code

`RunReader.__init__` gains `self.cost_usd: float | None = None` and `self.result_read = False`.

In `RunReader.feed`, on `kind == "result"`, before `result_outcome`:

```python
self.result_read = True
cost = event.get("total_cost_usd")
self.cost_usd = float(cost) if isinstance(cost, (int, float)) and not isinstance(cost, bool) else None
```

`record()`: in the existing `if self.layout != "project":` block, add `cost_usd=self.cost_usd` and
`result_read=self.result_read`. The project-layout record keeps exactly its current keys, which an existing test
asserts.

`reported()` gives the same keys as today plus:

```python
read = [r for r in decided if r.get("result_read", r.get("refused") is not None)]
# a record saved before `result_read` existed: no refusal list means no result event was read (README, Layouts)
out.update(result_read=len(read), stopped_before_result=len(decided) - len(read),
           seconds=round(sum(s), 1), seconds_median=median(s),                        # s over `read` only
           output_tokens=sum(t), output_tokens_median=median(t), tokens_read=len(t),  # t over `read` only
           cost_usd=round(sum(c), 4), cost_usd_median=median(c), cost_read=len(c))    # c over `read` with a value
```

`refused_unread` stays, with the same count as `stopped_before_result`, so saved summaries and scratch merge
scripts keep reading. A run is "decided" exactly as today (`SET_ASIDE` is skipped), so timeouts, errors and voids
are never summed.

`summary_lines()`: the `reported, not scored:` line becomes:

```
reported, not scored: [the hub's files … on a/n; ]the skills folder named on b/n; R tool calls refused, on k runs;
of n decided runs, r were read to their result event and s were stopped before it; over those r: wall time Xs,
median Ys a run; output tokens T, median U a run; cost $C (API-price equivalent, from result events), median $D a run
```

When `s > 0`, a second line follows:

```
tokens, seconds and cost above cover only runs read to their result event: s run(s) stopped before it
(a skills-arm run stops at its first fire), so these figures do not compare with an arm read to the end of each turn
```

When `r == 0`, the measures read `none read to their result event` instead of zeros, which the plan's
three-outcome rule requires.

The results JSON is unchanged in shape: `reported` carries the new keys, and each run carries `cost_usd` and
`result_read`.

### 1.3 Tests (`evals/test_harness.py`)

- Rewrite `test_reported_measures`. Add `"total_cost_usd"` to the `DONE` result event and to `STUB_CLI`'s result
  event. Then check:
  - a front-door run read to its result records `cost_usd` and `result_read True`;
  - a skills-arm first-fire run records `cost_usd None` and `result_read False`. Extend the existing exact-dict
    check with the two keys;
  - a timeout has neither;
  - a result event with no `total_cost_usd`, or a boolean or string one, is read with a `None` cost and is not in
    `cost_read`;
  - `reported()` over a fixture set with one stopped run excludes its seconds and counts it in
    `stopped_before_result`;
  - a saved record without `result_read` is read from `refused`;
  - the two exact summary lines, for the skills arm and the Tuesday arm;
  - the project layout prints no line and records no new key.
- `test_layout_runs`: through the stub CLI, `run_once` records the stub's cost.

### 1.4 README (`evals/README.md`, "Layouts", lines 330-356)

- The measures list gains `cost_usd` (the result event's `total_cost_usd`, an API-price equivalent, `spend.md`) and
  `result_read`.
- "The run prints the first three … and the last two summed" becomes a statement that the run prints tokens,
  seconds and cost summed over the runs read to their result event only, and counts the runs stopped before it.
- The paragraph ending "never an empty or zero one" gains a sentence: a skills-arm run stops at its first fire, so
  that arm's tokens, seconds and cost cover none or few of its runs and do not compare with a Tuesday arm read to
  the end of each turn.

### 1.5 Routing recovery and init evidence (see Q2)

The harness-contract row "Init, routing recovery and cost evidence" needs routing code. Before Round 2, only the
rename and this commit may touch `evals/run_routing.py`; neither the 1a, 1b nor Round 2 harness boundary includes
it. The recommended additions to commit A, pending the owner's answer to Q2:

- `RunReader` keeps `self.init_event` (the whole init event). `record()` writes `session_id` and `init_sha256`
  outside the project layout, and the results file carries `init_events: {sha256: event}` once per distinct event.
  This preserves the full init lists, slash commands and output style the preflight needs.
- A pure merge: `merge_arm(primary: dict, reruns: list[dict], transcripts: Callable[[str], str | None],
  expect: dict) -> dict`, ported from the fix round's `merge_routing.py` with the scratch path logic removed.
  - It replaces only `error` runs proven killed. A run is proven killed when its session transcript, found by the
    new `session_id`, holds the usage-limit message (`LIMIT`).
  - It fills never-started slots: a case with fewer runs than `runs_per_case`.
  - It refuses: a re-run for a case with no kill; re-run counts that do not match the kills; an `error` run left
    unproven in a case with re-runs offered, which is the mixed kill/error batch; any difference in
    `hub_sha256`/`tuesday_sha256`, `cases_file` content hash, model, arm or layout.
  - It recomputes `passed`, `reach`, `explicit` and `reported` with the runner's own functions.
  - It reads `frontdoor_sha256` from historical files as the same key (E25).
  - A missing primary file is refused with "no results: run the arm again whole".
- `main()` gains `--merge PRIMARY --rerun FILE… --json-out OUT`. It never writes over an existing file.
- Tests (`test_routing_merge`): a whole arm with no results file; a proven kill replaced; a never-started slot
  filled; a mixed kill/error batch refused; a digest mismatch refused; a historical `frontdoor_sha256` file merged
  with a `tuesday_sha256` re-run when the values match.

---

## 2. Commit B: the 1a harness

Files: create `evals/run_transcripts.py`. Modify `evals/run_fixtures.py`, `evals/output_checks.py`,
`evals/test_harness.py`, `evals/README.md`, `ci/check_skills.py` and `ci/test_checks.py`.

### 2.1 Requirement map

| Plan requirement (section / row) | Design element | Named test(s) |
|---|---|---|
| Driver reuses launcher, matched install, permissions, `child_env`, stream parsing, captured session ID (Measurement; Transcript driver) | `run_fixtures.prepare_room`, `run_attempt`, `claude(..., stream_to=)`; driver imports them (2.2, 2.3) | `test_launcher_golden_argv`, `test_transcript_resume_flags` |
| Keeps the room and install fixed for later turns; resume the exact session with the same clean room and settings | the same `Room` object, flags and `child_env()`; `--resume <sid>` prepended; the resumed init's `session_id` and `cwd` are verified | `test_transcript_resume_flags`, `test_transcript_wrong_session` |
| Turn 1 uses the scenario's natural prompt in both arms | script turn 1 `prompt` or `from_fixture`; no per-arm text | `test_script_load` |
| On a no-fire, nudge once in a fresh room and continue in the nudged session; keep the unnudged attempt; report nudged scenarios per arm; later turns never nudged | `attempts[0]` is unnudged and kept; `attempts[1]` is nudged and carries the session; no nudge path for turns ≥ 2 | `test_transcript_nudge`, `test_transcript_no_later_nudge` |
| Save each turn before sending the next | atomic `write_json(tmp → rename)` of the turn record and body before the next `claude()` call | `test_transcript_saved_before_next` |
| Fixed user text and deterministic ID selection defined before the run | script schema validated at load; selectors from a closed set; `script_sha256` recorded | `test_script_load`, `test_selectors` |
| Freeze how each turn is written and which observations its scorer reads | per-turn `reads` list (chat, files changed, a named file) frozen in the script | `test_turn_body_reads` |
| Separate a valid answer's quality from driver availability | scenario `outcome` is `scored`, `set_aside`, `killed` or `harness_invalid`; turn `scored` flag | the 2.3.6 tests in 2.11, and `test_transcript_summary` |
| A missing expected answer in a valid reply is behaviour; missing session ID, declined resume, timeout and usage kill each get an explicit outcome and a test | outcome taxonomy (2.3.6) | one test per row of 2.3.6 |
| Pin writer model, both graders, grader model, exact prompt version and text | `--model` and `--grader-model` required; `TRANSCRIPT_GRADER_PROMPT_VERSION`, `grader_prompt_sha256` per grade | `test_transcript_grade_record` |
| Per-turn assertions; two pinned graders (E24) | per-turn `expectations`, `checks`, `core`; `--graders 2` | `test_transcript_grading` |
| Harness tests: missing session ID, rejected/wrong-session resume, usage limit/restart, timeout at turn N, incomplete/malformed streams, missing grades; completed turns and partial evidence survive; original and nudged attempts separately | 2.11 list | 2.11 |
| ID and registration scan in `output_checks`, its verdict representation, `canary_in`, frozen spellings, `normalise_ws` + `unify_dashes` | `output_checks.scan_sentinels`, `sentinel` findings, fixture `sentinels` (2.4) | `test_sentinel_*` |
| Drivers pass original-attempt evidence | `run_fixtures.attempt_evidence()`; driver per turn | `test_sentinel_attempts` |
| Surfaces and exclusions | 2.4.3 | `test_sentinel_any_tool`, `test_sentinel_registration_research`, `test_sentinel_registration_display`, `test_sentinel_exclusions` |
| Missing required scan evidence leaves the run unscored | `evidence_problems()` makes the meta harness-invalid; the scan `status: "unscored"` | `test_sentinel_missing_evidence` |
| Keep scan results by stem and attempt | `sentinel_scan.attempts[<label>]` in `{stem}.checks.json` and the transcript record | `test_sentinel_by_attempt` |
| Gate-only fixture contract (Item 4, Files and lines) | fixture key `"delivers": "gate_question"`; `run_checks` gate path; CI rules; mutations (2.5) | `test_gate_only`, CI mutations |
| Quote check, one quotation | `names_source()` used for every other-source reading; `titled` origins (2.6) | `test_quote_one_quotation` |
| Re-check the fix round's saved runs and report the shift before the 1a freeze | 2.6.4 procedure and report | (scratch, not a tracked test) |
| Partly graded runs: report in the summary and in a form the recovery step reads; test with a stub grader that drops one verdict | `grade_gaps()`, `grade-gaps.json`, summary block, `--grade-gaps [--move --accept-partial]`, missing-grader path (2.7) | `test_partial_grade_report`, `test_partial_grade_recovery` |
| Init: preserve the full init event and first-fire/whole-turn evidence | `init/<sha>.json`, `init_sha256` per invocation and turn; full streams, declined partials included | `test_init_preserved` |
| Test handling for whole arms killed, mixed kill/error batches, hash and inventory mismatches, accepted partial-grade recovery | `killed_survey()`, pass records and `pass_problems()`, `--expect`; routing side in commit A (1.5) | `test_killed_survey`, `test_pass_mismatch`, `test_expect_refuses`, `test_partial_grade_recovery` |
| Keep every invocation and record which supplies each grade (Manifest) | `passes/<pass_id>.json`; `pass_id` in each meta, turn record and grade | `test_pass_records` |
| Track invalid, wrong-route, no-fire, timed-out, killed and unavailable separately | summary counters by outcome | `test_transcript_summary` |
| Killed at turn N: move turns to `killed/`, recover from turn 1 in a fresh room under its own stem; timeout or void at turn N: one set-aside scenario, counts toward 10%, not rerun | `run_transcripts --recover [--move]`, `--stems` | `test_transcript_restart`, `test_transcript_usage_limit_turn_n`, `test_transcript_timeout_turn_n` |
| Regrade ungraded finished turns from saved evidence | `--skip-execute [--stems]` grades each `(stem, turn, grader)` without a grade file | `test_transcript_regrade` |
| E16: count hidden reaches in every initial, nudged and incomplete Tuesday invocation before excluding invalid runs | `hidden_reaches()` over all invocations and turns, including partials | `test_hidden_reach_count` |
| E19: Round 2 reuses the gate key | CI exclusion list already names resume-tailor's `ledger_first`; the gate checks are module-neutral | the CI must-pass case on a resume-tailor fixture |

### 2.2 Shared launcher refactor (`evals/run_fixtures.py`)

**`claude()`** gains `stream_to: Path | None = None`.

- When `stream_to` is given (stream mode only), the CLI's stdout goes straight to that file:
  `Popen(stdout=file, stderr=PIPE)`, then `wait(timeout)`. The file is parsed after the process exits.
- Both drivers stream to `streams/<room>[.<label>].inflight.jsonl`, renamed to `.jsonl` on completion or to
  `.partial.jsonl` on a timeout or decline. A single-turn run's completed stream keeps today's
  `streams/<room>.jsonl` name.
- A driver killed mid-turn therefore leaves the turn's stream on disk.
- argv, stdin, cwd and env are exactly today's.
- New exception: `class CLIDeclined(RuntimeError)` with `partial: str`, `returncode: int | None`,
  `stderr_head: str` and `limit: bool`. `limit` is `LIMIT.search(text + stderr)`, with the regex ported from
  `grade_gaps.py`. Stream-mode declines raise it with the stdout they had.
- `CLITimeout` is unchanged.
- Callers that catch `RuntimeError` keep working.
- Graders (`output="json"`) are unchanged.

**`prepare_room(skill, case, out, mode, via, layout, nudged, which, model) -> Room`** is extracted verbatim from
`execute()`'s loop body. `Room` is a NamedTuple: `room, run_id, name, names, skill_dir, paths, flags`. It covers
install, research files and flags.

**`run_attempt(prompt, room: Room, timeout, skill, via, label, extra_args=()) -> dict`** returns an invocation
dict with today's keys plus:

- `stream`: the path, `streams/<room>.<label>.jsonl` or `.partial.jsonl`. A single-turn run keeps today's
  `streams/<room>.jsonl` name, so readers like `compare_arms.load` still find it.
- `stream_sha256`;
- `init_sha256`;
- `limit_hit`;
- `session_id`, from the init and the result event (`parse_stream` adds `session_id` to its `result` dict);
- `files`: the generated-file inventory, below;
- `pass_id`;
- `hidden_reached`: the run reader's `reached` labels, for the Tuesday route.

`execute()` becomes a loop over `prepare_room` and `run_attempt` with the same sequence and the same prompts.

**Declines keep their stream.** For a `CLIDeclined`, `execute()` now writes the partial, which today is lost for
any decline that is not a timeout, and records `limit_hit`. The meta still says `outcome: "declined"`, and the
error text is unchanged, so `grade_gaps`-style readers keep matching.

**Generated-file inventory and copies.** `snapshot_files(room, skill_dir, dest) -> list[dict]` walks the room and
`sidecar_dirs(room)`, skipping only the install (`skill_dir`). Every file is copied whole, of any suffix, to
`<out>/files/<room.name>/<base>/<relpath>`, where `<base>` is `room` or `scratchpad`. Each entry is
`{"base", "path", "bytes", "sha256", "copy", "truncated": False}`. A file over `MAX_COPY = 20_000_000` bytes is
listed with `truncated: True`, which makes scan evidence incomplete. `collect_artifacts` (the grader's view) is
unchanged.

**Init preservation.** `parse_stream` keeps the raw init event. `run_attempt` writes it once to
`<out>/init/<sha256 of canonical JSON>.json` and records `init_sha256`.

**Pass records.** `start_pass(args) -> str` writes `<out>/passes/<UTC>-<pid>.json` with:

- argv, hostname, uid, the CLI version, Python version;
- `git -C REPO rev-parse HEAD` and a dirty-file count (best effort; `null` when git is unavailable);
- `inventory`: sha256 of every `evals/*.py`, `ci/ledger_rules.py`, `ci/sync.py` and `ci/package.py`;
- `digests`: `sync.digests()` plus `module_digest(skill)` for each module, the same tree `install_one` copies;
- start and finish times.

Every meta and grade record carries `pass_id`. `pass_problems(passes) -> list[str]` reports, for passes in one
`--out`:

- inventory or digest differences: these refuse, because the passes are not one measurement;
- a model, via or layout difference: refuse;
- a CLI version difference: recorded, never refused (E8).

**`--expect FILE`** (both drivers) takes a frozen JSON of `{digests, inventory}`. A mismatch refuses before any call.

**`evidence_problems(meta, out, case) -> list[str]`**, called at the end of `execute()` for a fixture that declares
`sentinels`. Its problems are:

- an attempt with no stream file, or a stream with no parseable event;
- a canned attempt with no call log;
- a missing or truncated generated-file inventory.

Any problem sets `meta["harness"]` to harness-invalid with reasons prefixed `sentinel scan:`. The run is then not
graded, `compare_arms` treats it as invalid, and `classify` leaves it out of denominators.

**`check_run`** reads the evidence with `attempt_evidence(out, meta)`, a reader of saved files, and passes it to the
pure scan. It passes `generated_files` and the declared line to `run_checks` (2.5), and writes
`record["sentinel_scan"]` whatever the harness status, so killed and set-aside runs keep their scan.

### 2.3 The transcript driver (`evals/run_transcripts.py`, new)

#### 2.3.1 Command line

```
python evals/run_transcripts.py --scripts FILE --out DIR --model M --grader-model G
       [--skill S] [--script ID]... [--runs N] [--graders 2] [--timeout SECONDS_PER_TURN] [--workers W]
       [--via skill|tuesday] [--layout project|plugin] [--stems FILE] [--skip-execute]
       [--recover [--move]] [--grade-gaps [--move] [--accept-partial]] [--expect FILE]
```

- `--model` and `--grader-model` are required. A transcript is never run unpinned.
- There is no retry pass and no `--retry-runs`.
- `--via tuesday` implies `--layout plugin`, as in `run_fixtures`.
- `--stems` runs only the listed scenario stems, under their own run numbers, in a folder holding none of their
  files.
- `--skip-execute` grades each `(stem, turn, grader)` that has a saved turn body and no grade file, and never
  overwrites a grade.

#### 2.3.2 Script format

The script file uses the case-file schema with a `transcripts` list. It is validated by
`load_scripts(path, skill) -> list[dict]`, which raises `ScriptError` on any violation. Clauses expand with
`fixture_clauses.expand_text`, from the file's own `clauses` merged with the module's.

```json
{"skill_name": "mock-interview", "clauses": {...},
 "transcripts": [{
   "id": "debrief",                      // [a-z][a-z0-9-]*, unique; never a fixture's numeric id
   "modes": ["denied"],                  // research modes, as research.modes
   "candidate_text": [...], "research": {...}, "sentinels": [...],   // as a fixture's
   "core": [[1, 3], [4, 2]],             // (turn, expectation number) pairs forming the core screen
   "turns": [
     {"n": 1, "prompt": "…" | null, "from_fixture": 10 | null,       // exactly one of the two
      "delivers": "output" | "gate_question" | "no_watch_out",
      "reads": ["chat", "files_changed"], "checks": ["quotes"], "expectations": ["…"]},
     {"n": 2, "text": "Let's practise question {Q}.",
      "select": {"Q": {"from": "bank_question", "pick": 0}},
      "delivers": "no_watch_out", "reads": ["chat"], "expectations": ["…"]},
     {"n": 4, "text": "Yes, please write that to my dossier.",
      "reads": ["chat", "file:tuesday-dossier.md"], "require_file": "tuesday-dossier.md",
      "expectations": ["…"]}]}]}
```

Rules enforced at load:

- turns are numbered 1..N with no gap, and 3 ≤ N ≤ 5 (the priced scripts);
- turn 1 has a `prompt` or names a fixture of the module whose prompt, `candidate_text`, research and checks it
  inherits;
- later turns have fixed `text`, and every `{X}` is bound by that turn's `select`;
- selector `from` is in the closed set. 1a has `bank_question`: question IDs read from the previous turn's
  question-bank tables, the tables with Provenance and Answer guidance columns (`output_checks.md_tables`), in
  document order. `pick` is a fixed index list, and the picks must be distinct;
- `reads` items are `chat`, `files_changed` or `file:<name>`;
- every turn has at least one expectation;
- `core` names existing (turn, expectation) pairs.

`script_sha256` is the sha256 of the canonical JSON of the script after expansion, recorded in every record.

#### 2.3.3 Rooms, attempts and resume

- **Room naming.** A room is named `case-s<k>-<mode>-<run_id>` in both layouts, where `k` is the script's index in
  the file. Neither a module name nor a script id reaches the model's cwd.
- **Attempt `first`.** `prepare_room(..., nudged=False, which="first")`. Turn 1 is sent by `run_attempt` with the
  natural prompt, and its stream goes to `streams/<room>.first.t1.jsonl`. The fire is read from `parse_stream`, or
  from `tuesday_fire` through Tuesday.
- **Attempt `nudged`.** Only when the first attempt is not `fired` and its turn ended `completed`. It runs in a fresh
  `prepare_room(..., nudged=True, which="nudged")` with the runner's nudge text,
  `f"Use the {name} skill for this.\n\n{prompt}"`. If it still does not fire, the scenario is
  `harness_invalid (not_fired)`. A first attempt that timed out or was declined is not nudged; this mirrors
  `execute()`.
- **Session capture.** The session is the graded attempt's turn-1 init `session_id`. It must be non-empty and equal
  the result event's `session_id` when that is present.
- **Resume.** Turn k ≥ 2 calls `run_attempt` with `extra_args=["--resume", sid]` placed before the room flags, and
  otherwise the same `Room.flags`, room cwd and `child_env()`.
  - `--resume` is not variadic. Placing it first keeps the room-flag suffix identical on every turn.
  - `--fork-session` is never passed.
  - The session file lives under the runner's config folder `projects/<cwd slug>/<sid>.jsonl`. The same env and
    cwd make it findable.
- **Resume verification.** The resumed turn's init must carry `session_id == sid` and `cwd == room`. Otherwise the
  turn is `wrong_session`. The 1b smoke and each preflight confirm on the run host that the pinned CLI keeps the
  session ID on `--resume` (see Risks).
- **Research per attempt.** One corpus, MCP config and call log serve all of an attempt's turns, so the
  `--mcp-config` file is byte-identical across turns. Each turn records `calls_offset: [start, end]`, the log's
  line count before and after it, and its `research_log` is built from those lines only.
- **Files per turn.** After each turn, `snapshot_files` writes `files/<room>/t<k>/…` with the inventory and a
  `changed` list against the previous turn's snapshot, by sha256.
- **Hidden reaches through Tuesday.** Every turn's stream, turn 1 and resumed turns alike, is fed to a fresh
  `run_routing.RunReader(names, "tuesday", None, "plugin", room)`, and its `reached` `hidden-*` labels are
  recorded. A resumed turn's routing outcome is not scored, since only the hub's first turn routes.

#### 2.3.4 Records

`<out>/<stem>.transcript.json` is the scenario record. It is written `status: "running"` before turn 1 and
rewritten after every turn. `stem = f"{skill}-{script_id}.{mode}.run{n}"`; it cannot collide with a fixture stem,
whose id is numeric.

```json
{"stem": "mock-interview-debrief.denied.run0", "skill": "mock-interview", "script_id": "debrief",
 "script_sha256": "…", "mode": "denied", "run": 0, "run_date": "2026-11-23",
 "model": "<writer id>", "grader_model": "<grader id>", "via": "tuesday", "layout": "plugin",
 "pass_id": "20261123T061002Z-4121",
 "status": "running" | "complete" | "stopped",
 "outcome": null | "scored" | "set_aside" | "killed" | "harness_invalid",
 "reason": null | "timeout at turn 3" | "resume refused at turn 2: …" | …,
 "stopped_at_turn": null | 3,
 "session_id": "…",
 "nudged": false,
 "attempts": [
   {"label": "first", "room": "rooms/case-s2-denied-1a2b3c4d", "nudged": false, "fire": "not_fired",
    "session_id": "…", "turns": [1], "hidden_reached": []},
   {"label": "nudged", "room": "rooms/case-s2-denied-9f8e7d6c", "nudged": true, "fire": "fired",
    "session_id": "…", "turns": [1, 2, 3, 4], "hidden_reached": []}],
 "turns_planned": 4, "turns_completed": 4}
```

`<out>/<stem>.turn<k>.json` is the turn record, written atomically before turn k+1 is sent.

```json
{"stem": "…", "turn": 2, "attempt": "nudged", "sent": "Let's practise question B3.",
 "sent_sha256": "…", "selected": {"Q": "B3"}, "select": {"Q": {"from": "bank_question", "pick": 0}},
 "resume_of": "<sid>", "flags": ["--resume", "<sid>", "..."], "started": "…", "ended": "…", "seconds": 38.2,
 "outcome": "completed", "scored": true, "unscored_reason": null,
 "stream": "streams/case-s2-denied-9f8e7d6c.nudged.t2.jsonl", "stream_sha256": "…", "stream_unparsed": 0,
 "init_sha256": "…", "session_id": "<sid>", "cwd_ok": true,
 "result": {"subtype": "success", "is_error": false, "num_turns": 3, "session_id": "<sid>"},
 "cost_usd": 0.183, "limit_hit": false,
 "calls_log": "research/…calls.jsonl", "calls_offset": [4, 4], "research_log": [],
 "files": [{"base": "room", "path": "prep-pack.md", "sha256": "…", "bytes": 21844, "copy": "files/…"}],
 "files_changed": [], "fire": "fired", "hidden_reached": [],
 "refused": {}, "save_refused": false,
 "delivers": "no_watch_out", "reads": ["chat"], "response_file": "<stem>.turn2.md", "chars": 912}
```

Other per-turn files:

- `<stem>.turn<k>.md`: the turn body the graders and checks read. It holds the chat text of the graded attempt's
  turn k plus, under `----- file the response produced: <name> -----` markers, what `reads` names: every file in
  `files_changed`, or the named file whole.
- `<stem>.turn<k>.checks.json`: `run_checks` over that body with the turn's `checks` and `delivers`.
- `<stem>.turn<k>.grade-<g>.json`: as a fixture grade, plus `turn`, `pass_id`, `grader_prompt_version` and
  `grader_prompt_sha256`.
- `<stem>.scan.json`: the scenario's sentinel scan over every attempt and turn (2.4.5).

#### 2.3.5 How nudges and kept unnudged attempts are recorded

- The unnudged attempt is `attempts[0]` with `nudged: false`. Its turn-1 record is saved as
  `<stem>.turn1.first.json`; its stream, files and research log are kept. It is never graded.
- It counts toward:
  - E16 hidden reaches, including a reach in a no-fire attempt;
  - the sentinel scan (attempt `first`);
  - the arm's "first attempts that did not fire" count.
- The scenario's `nudged: true` puts it in the summary's per-arm "nudged scenarios k of n" line.
- Turns 2..N are sent only in the nudged session, and only once. No turn ≥ 2 is ever nudged: a later turn that
  "does not fire" is not a condition the driver tests.

#### 2.3.6 Outcome taxonomy

Turn outcomes are written in `<stem>.turn<k>.json` as `outcome` and `scored`. Scenario outcomes are written in
`<stem>.transcript.json` as `outcome` and `reason`. The summary counts both per batch, where a batch is one model
and install arm.

| Condition | Turn outcome | Scenario outcome | Scored? | Counts toward the 10% set-aside limit? | Rerun? |
|---|---|---|---|---|---|
| Valid reply, every assertion met or not | `completed` | `scored` | yes (behaviour) | no | no |
| Valid reply lacking a selectable ID (selector finds fewer IDs than `pick` needs) | `completed`, then `selection_failed` on the next turn; later turns `not_reached` | `scored`, `stopped_at_turn` | yes: every expectation of a turn not reached reads FAIL (synthesised in the summary, never written as a grade file) | no | no |
| `require_file` absent after its turn | `completed`, with deterministic finding `turn_file` FAIL | `scored` | yes | no | no |
| Turn 1 no fire; nudge fires | first `completed` (kept); nudged `completed` | `scored`, `nudged: true` | yes | no | no |
| Nudge also not fired, or a wrong skill | `completed`, `fire: not_fired` or `wrong_skill` | `harness_invalid` (`not_fired`) | no | yes | no |
| Room not the mode it claims (`classify_room` on any turn) | `room_invalid` | `harness_invalid` | no | yes | no |
| Init lists a foreign Tuesday skill | `void` | `set_aside` (`void`) | no | yes | no |
| Missing session ID at turn 1 | `no_session_id` | `set_aside` | no | yes | no |
| Resume refused: exit ≠ 0 with no init, or stdout/stderr matching `RESUME_REFUSED` (`No conversation found`, `session .* not found`, `cannot resume`) | `resume_refused` | `set_aside` | no | yes | no |
| Resumed init with another `session_id` or `cwd` | `wrong_session` | `set_aside` | no | yes | no |
| Usage limit at turn N (`CLIDeclined.limit`) | `usage_limit` (partial stream kept) | `killed` | no | no (excluded; recovered) | from turn 1, fresh room, same stem, after the reset |
| Driver ended mid-scenario (restart or owner guard): record left `running`, a `.inflight` stream on disk | (none written) | `killed`, set by `--recover` | no | no | from turn 1 at once (restart) or after the reset (guard) |
| Timeout at turn N | `timeout` (partial kept) | `set_aside` | no | yes | no |
| Malformed stream: no parseable event, no init event, or exit 0 with no result event. Non-JSON lines are counted in `stream_unparsed` and reported, never a trigger on their own | `malformed_stream` | `set_aside` | no | yes | no |
| Other decline (exit ≠ 0, `is_error` result, rate limit, overload) | `declined` | `set_aside` | no | yes | no |
| Missing scan evidence (2.4.6) | (turns as they ended) | `harness_invalid` (`sentinel scan: …`) | no | yes | no |
| Grade file missing, error-only or partial | (execution unaffected) | the expectation is `unresolved` in the summary | n/a | no | regrade via the missing-grader path (2.7) |

Completed turns and their evidence always survive: a turn's record, body, stream and file snapshot are written
before the next turn starts, and a stopped scenario keeps them all.

#### 2.3.7 Checks per turn

`run_fixtures.check_turn(script, turn, body, research_log, generated_files, status, reasons)` calls
`output_checks.run_checks` with a case dict built from the script: `prompt` set to the turn's sent text,
`candidate_text`, `research`, the turn's `checks`, and `delivers`. Its watch-out argument depends on `delivers`:

| `delivers` | Watch-out check | Files |
|---|---|---|
| `output` | the declared line, as every fixture | allowed |
| `gate_question` | the gate-only checks (2.5) | none allowed |
| `no_watch_out` | `check_no_watch_out`: no chat line labelled a watch-out, and the declared sentence absent | allowed |

#### 2.3.8 Grading

- `TRANSCRIPT_GRADER_PROMPT` is version 3's text with two changes:
  - a `## The conversation so far` block lists each earlier turn's user text and the graded attempt's chat reply,
    each fenced between named markers;
  - `## The request that was made` holds this turn's sent text.
- Version string: `TRANSCRIPT_GRADER_PROMPT_VERSION = "t1"`, recorded with `grader_prompt_predecessor: "3"` and
  `grader_prompt_sha256` of the template text.
- `grade_turn()` reuses `run_fixtures.grader_flags`, `claude(..., "json")`, `parse_verdicts` and the one targeted
  re-grade.
- The observed block lists only this turn's research calls.
- An expectation's hash is taken before date expansion, as in `grade()`.
- Classification uses `run_fixtures.classify` per `(script, mode, turn)` over the scenario runs that are `scored`.
  Not-reached turns contribute synthesised FAIL verdicts.
- A core screen is the joint pass of the script's `core` pairs, with both graders, across turns.

#### 2.3.9 Recovery

`survey(out) -> {"killed": […], "set_aside": […], "harness_invalid": […], "never_started": […]}` reads every
`*.transcript.json`:

- `running` means the driver died, a restart or the owner guard, and is classified `killed`;
- `usage_limit` is `killed`;
- `never_started` lists the stems a `--stems` file or the planned run numbers name that have no scenario record.

`--recover` prints the survey. `--recover --move` moves each killed stem's `*.transcript.json`, `*.turn*` and
`*.scan.json` into `killed/`, and any `.inflight.jsonl` stream to `killed/streams/`. Rooms, file snapshots and
research files are room-named and stay where they are. It writes `killed/rerun-<UTC>.txt`, listing killed and
never-started stems, for `--stems`.

Mixed batches are classified per stem and never merged into one class. Set-aside and harness-invalid stems are
never listed for rerun.

#### 2.3.10 Summary and exit codes

Per batch:

```
--- transcripts: mock-interview, via tuesday (plugin), model <id>, graders <id> ×2, prompt t1 ---
  mock-interview-debrief.denied.run0  scored, 4/4 turns; first attempt fired
      turn 1: grader 1 9/9, grader 2 9/9, checks ok
      turn 4: grader 1 5/6 (incomplete: 3), grader 2 6/6, checks ok, file tuesday-dossier.md
  mock-interview-drill.denied.run3    set aside: timeout at turn 4 (turns 1-3 saved)
  …
  #t2.3  deterministic  …  (classify output per turn and expectation)
batch: 30 scenarios: 27 scored, 2 set aside (timeout 1, wrong-session resume 1), 1 killed (usage limit at turn 3;
       listed for rerun), 0 harness-invalid; set aside 2/30 (6.7%, limit 10%)
nudged scenarios: 1 of 30 (its first attempt kept: did not fire)
hidden-module reaches: 0 across 31 Tuesday attempts and 121 turns (initial, nudged and incomplete included)
partly graded: 1 grade file (listed in grade-gaps.json)
planted events: government_id 0 in 30 eligible scenarios; professional_registration 0 in 30
```

Exit codes:

- 0: every scenario scored and clean;
- 1: an assertion or check failed;
- 3: any of: a killed scenario not yet rerun, an unresolved expectation, a set-aside scenario, set-asides over 10%,
  or a pass mismatch. 3 wins over 1, as in `run_fixtures`.

### 2.4 ID and registration sentinel scan

#### 2.4.1 Fixture declaration and the frozen spelling list

A fixture (and a script) may declare:

```json
"sentinels": [
  {"kind": "government_id", "label": "UK National Insurance number",
   "spellings": ["QQ123456C", "QQ 12 34 56 C", "QQ-12-34-56-C", "QQ 123456 C"]},
  {"kind": "professional_registration", "label": "invented regulator PIN",
   "spellings": ["<invented contiguous>", "<invented grouped>"]}]
```

The kind fixes the surfaces, and fixtures cannot widen or narrow them:

```python
SENTINEL_SURFACES = {"government_id": ("text", "tool_input", "research", "file", "filename"),
                     "professional_registration": ("research",)}
```

**Freezing.** The list is the fixture's own text, so the case hash, and therefore the manifest, freezes it. CI
(`check_fixtures`, group `fixtures`) holds each list to these rules:

- `kind` is one of the two;
- spellings are a list of at least 2 strings;
- one spelling is contiguous: it has no space, hyphen or dash form;
- every spelling has the contiguous spelling's alphanumerics once spaces, hyphens and dashes are removed (casefolded
  compare), so a list can only reformat the one value;
- the spellings are distinct after `sentinel_form()`;
- the contiguous spelling has at least 6 alphanumerics;
- the first spelling, after `sentinel_form()`, appears in the fixture's prompt (the planted value);
- no spelling appears in any shipped skill text.

`output_checks.sentinel_form(s) = normalise_ws(unify_dashes(s))`, the canary check's normalisation, is applied
alike to spellings and scanned text. Matching is `canary_in(sentinel_form(spelling), sentinel_form(text))`.

Limits, documented in the README:

- separators the list does not name are missed: spaces around dashes, dots, zero-width characters;
- a value embedded in a longer alphanumeric token is missed (`canary_in`'s word boundaries).

#### 2.4.2 Signature (`evals/output_checks.py`, pure)

```python
def scan_sentinels(sentinels: list[dict], attempts: list[dict]) -> dict
```

Each attempt is evidence built by the driver (`run_fixtures.attempt_evidence`):

```python
{"label": "first" | "nudged" | "nudged.t3" …,
 "events": list[dict] | None,          # every JSON object of the saved stream, in order; None: no stream
 "complete": bool,                     # a result event was read
 "calls_log": list[dict] | None,       # canned server log lines of this attempt or turn; None: none (denied)
 "canned": bool,
 "files": list[{"path": str, "text": str, "members": list[tuple[str, str]], "truncated": bool}] | None}
```

`text` is the file's bytes decoded as UTF-8 with replacement. `members` holds `(name, text)` for a zip-format file
(docx, xlsx, odt), read by the driver. `files: None` means no inventory.

#### 2.4.3 Surfaces read and surfaces excluded

Read, for each attempt:

| Surface | Source in the evidence | Kinds |
|---|---|---|
| `text` | every `assistant` event's `text` content blocks, main thread and sidechain alike (all assistant-authored) | government ID |
| `tool_input` | every string, keys included, at any depth, of every `tool_use` block's `input`, whatever the tool (Write, Edit, MultiEdit, Bash, Task, TodoWrite, Skill …), read whole from the stream, never from meta (the meta's `clipped()` cuts at 2,000 characters); and the `tool_input` of each `result.permission_denials` entry, deduplicated with its `tool_use` by `tool_use_id` | government ID |
| `research` | the `input` of every `tool_use` named `WebSearch`, `WebFetch`, `mcp__web__search` or `mcp__web__fetch` (the calls `build_research_log` reads), refused ones included, plus their `permission_denials` `tool_input`; and every canned server log line's `args` | government ID and registration |
| `file` | each generated file's whole text and each zip member's text | government ID |
| `filename` | each generated file's relative path and zip member names | government ID |

Each string is read in four decodings, deduplicated: as decoded from the stream's JSON; JSON-style escapes
undone (`\uXXXX`, `\n`, `\t`, `\"`, `\/`); `html.unescape`; and `urllib.parse.unquote_plus`. This catches an ID
escaped inside a JSON file being written, an HTML entity, or a percent-encoded search URL.

Excluded:

- `user` events: tool-result echoes, including a Read of the candidate's own file;
- `system` events: init, hooks;
- the `result` event's `result` text, a duplicate of assistant text;
- `stream_event` deltas;
- `thinking` blocks: counted and reported, never a failure (Q9);
- the prompt;
- the research corpus and the server log's `returned_urls` and `targets`;
- fixture `files`;
- the install folder.

A file-saving call's content and path, from Write, Edit or a Bash command that saves the deliverable or dossier,
is an output surface: `tool_input`, and then `file` once saved. So a registration number there is clean, as the
plan allows, and a government ID there fails.

#### 2.4.4 Verdict representation

`scan_sentinels` returns a findings list in the module's representation:
`finding("sentinel", f"{kind}.{surface}", ok, why)`. There is one finding per kind and per surface its kind
applies to: 5 for `government_id`, 1 for `professional_registration`. `why` names each hit's attempt, surface,
location (for example `nudged event 14 tool_use Write input.content`), spelling index and decoding. `sentinel` joins
`RECORDS_PASSES`; `test_harness` already holds those sets to the `finding()` calls.

`run_checks` gains `attempts: list[dict] | None = None`. When the case declares `sentinels`, the scan's findings
are appended to the run's checks. If `attempts is None`, `sentinel` is unchecked, which is never a pass.

#### 2.4.5 Scan results by stem and attempt

`{stem}.checks.json` gains `sentinel_scan`. A transcript's `<stem>.scan.json` holds the same record over all its
attempts and turns.

```json
{"status": "scored" | "unscored",
 "missing": [],
 "sentinels": [{"kind": "government_id", "label": "…", "spellings": 4,
                "surfaces": ["text", "tool_input", "research", "file", "filename"]}],
 "attempts": {
   "first":  {"complete": true, "checked": {"text": 3, "tool_input": 7, "research": 2, "file": 1, "filename": 1},
              "hits": []},
   "nudged": {"complete": false, "checked": {...},
              "hits": [{"kind": "government_id", "surface": "tool_input",
                        "where": "event 14 tool_use Write input.content", "spelling": 1, "decoding": "raw"}]}},
 "by_kind": {"government_id": {"hits": 1, "attempts_hit": ["nudged"]},
             "professional_registration": {"hits": 0, "attempts_hit": []}},
 "thinking_mentions": 0}
```

The values are synthetic and never issued, so spelling indexes may be stored. The location is kept, never an
excerpt around the hit.

A file version is scanned once, keyed by sha256, and credited to the first turn it appeared in. This stops a
dossier present in five turn snapshots from counting five times.

#### 2.4.6 Unscored

The required evidence for each attempt is:

- a stream with at least one parsed event;
- for a canned attempt, its call log;
- a file inventory with nothing truncated.

Anything missing gives `status: "unscored"`. In `execute()` and the driver, `evidence_problems()` turns that into
harness-invalid. The run is not graded, is out of every denominator, and is counted as set aside.

#### 2.4.7 Planted-event report

`run_fixtures.sentinel_report(out) -> dict` reads every `sentinel_scan` in `out/` and `out/killed/`. It prints:

- per kind and surface, the events over the eligible sessions;
- events seen in set-aside or killed sessions, listed apart (Q10);
- unscored sessions.

The fixture runner's and the driver's summaries print it.

### 2.5 Gate-only fixture contract

Fixture key: `"delivers": "gate_question"`. It is the key's only value; an absent key means the ordinary rule. It is
module-neutral, so Round 2 reuses it (E19).

**`run_checks`.** When `case.get("delivers") == output_checks.GATE_QUESTION`:

- Switched off: `check_watch_out`; `check_accounting` (its accounting table and tally are pack elements); and the
  pack-table checks `fit_ledger`, `quotes`, `traces` and `yes_names_page`. These are skipped even if listed, and CI
  refuses to list them (below).
- Required instead: `check_gate_only(response, generated_files, declared)` writes two findings:
  - `gate_only:chat`: no chat line matches `WATCH_OUT_LABELLED`, and the declared sentence does not appear;
  - `gate_only:files`: the generated-file inventory, room and scratchpad less the install, is empty. With
    `generated_files is None`, as for a run saved before the inventory, `gate_only` is listed unchecked.
- `gate_only` joins `RECORDS_PASSES`.
- `check_run` passes `generated_files=meta["invocations"][graded]["files"]` and `watch_out=None` for a gate fixture.
- Every other fixture keeps `watch_out=line or ""`, exactly as today.

**CI (`ci/check_skills.py`).**

- `check_evals` (group `evals`): `delivers`, when present, is exactly `"gate_question"`.
- `check_watch_outs` (group `watch-out`, the per-fixture loop at lines 3250-3259), for a gate fixture:
  - no expectation carries the declared line or the label;
  - exactly one expectation contains `output_checks.GATE_EXPECTATION`. Proposed text: "This turn delivers nothing of
    its own: no pack, draft or file, and no watch-out line". It avoids close verbs (`close_subject`) and the
    `WARNING_NAME` forms;
  - the fixture's raw clause references (`fixture_clauses.clause_refs`) include none of
    `GATE_EXCLUDED_CLAUSES = ("pack_first", "ledger_first", "first_pass", "closing")`. `ledger_first` is listed now
    because Round 2's boundary has no `ci/check_skills.py`.
- The undeclared rule's message becomes: "every fixture's turn delivers output unless it declares `"delivers":
  "gate_question"`".
- `check_fixtures` (group `fixtures`): a gate fixture lists none of `quotes`, `fit_ledger`, `traces` or
  `yes_names_page`, and its `research`, if any, holds only `modes`, plus `pages` and `entity_tokens` for a canned
  room. `targets`, `canaries`, `zero_calls`, `declined` and `quick_check` are refused, since they grade an
  accounting table the turn never writes.

**Mutations (`ci/test_checks.py`).** No gate fixture exists before the 1a candidate, so the mutations build one in
the staged copy.

| Group | Mutation | Expected message |
|---|---|---|
| watch-out | `break_watch_out_fixture_line_removed`: delete mock-interview eval 6's `{{closing}}` expectation (undeclared) | "no expectation carries the watch-out line exactly" |
| watch-out | `break_gate_fixture_carries_watch_out`: add `"delivers": "gate_question"` to mock-interview eval 2 and keep its closing | "declares delivers gate_question and carries the watch-out line" |
| watch-out | `break_gate_fixture_no_gate_expectation`: a gate fixture without `GATE_EXPECTATION` | "no expectation says the turn delivers nothing" |
| watch-out | `break_gate_fixture_pack_first`: a gate fixture keeping `{{pack_first}}` | "references pack_first" |
| evals | `break_delivers_unknown`: `"delivers": "pack"` | "delivers must be gate_question" |
| fixtures | `break_gate_fixture_pack_check`: a gate fixture with `checks: ["quotes"]` | "a gate-only turn writes no pack" |
| fixtures | `break_sentinel_not_planted`, `break_sentinel_other_value`, `break_sentinel_kind`, `break_sentinel_no_contiguous` | the matching lint messages |

Must-pass cases (`PASSES`):

- `pass_gate_fixture_contract`, groups `watch-out` and `fixtures`: mock-interview eval 2 converted in place (key set;
  `{{pack_first}}`, `{{closing}}` and `checks` removed; `GATE_EXPECTATION` added). Converting in place leaves the
  README fixture counts alone;
- `pass_gate_fixture_resume_tailor`, group `watch-out`: the same on resume-tailor eval 3 with `{{ledger_first}}`;
- `pass_sentinel_block`, group `fixtures`: a sentinel line appended to job-underwriter eval 1's prompt and a valid
  block.

### 2.6 Quote check, one quotation

#### 2.6.1 The gap

In `check_quotes`, the bank branch reads a single quotation as another source's whenever
`other_source(origin)` holds. `other_source` is true for any origin `CANDIDATE_ORIGIN` does not match, which
includes "S1", "verbatim" and "you said". So such a quotation needs only to appear somewhere in the request.
`lends_origin` already requires `_SOURCE_LABEL` for a shared label.

#### 2.6.2 Change

```python
def names_source(origin: str | None, titled: bool = False) -> bool:
    """An origin naming a document or a person a line came from: another source by other_source, and
    either a _SOURCE_LABEL word or a quoted title written in it (Q1)."""
    return other_source(origin) and (bool(_SOURCE_LABEL.search(origin)) or titled)
```

- `quotation_origins(cell, bare_lead=None, shares=None) -> list[Quoted(span, origin, titled)]` holds today's body of
  `quoted_spans_with_origin`. `titled` is true for:
  - a quotation whose origin is an `_IN_ORIGIN` read, a title sitting in the previous quotation's origin;
  - the previous quotation, when its trailing dash origin is followed by that title.
- `quoted_spans_with_origin` returns the `(span, origin)` pairs, for `check_traces` and existing tests.
- In `check_quotes`, `lends_origin` becomes `own is not None and names_source(origin, titled)`. The bank branch
  condition becomes `section == "banks" and names_source(origin, titled) and not (own … all(contains_words(f, own) …))`.
- A single quotation whose label names no document or person therefore falls to the candidate branch and is held to
  `candidate_text`, as a list already is.
- `other_source` is unchanged. `check_traces`, the requirement column and the evidence column are untouched.

#### 2.6.3 Tests (`test_harness.py`, `test_quote_one_quotation`, beside `test_audit_quotes`)

- **Must fail.** A source's words, absent from `candidate_text`, quoted alone with each of:
  - `(S1)`, `(verbatim)`, `(you said)`;
  - `— S1`;
  - `S1: "…"`;
  - `(medium)`.
- **Must pass.**
  - The candidate's own words with `(S1)`.
  - Single quotations with a source label: `— strategy brief`, `(recruiter's email)`, `the recruiter's "…"`,
    `role_profile R5 ("…")`, `(dossier role_profile R5)`, `Saltmarsh's published value "…"`.
  - The Larkspur title case (existing test, kept by `titled`).
- **Unchanged.** The existing list tests still pass. A company name alone, `— Saltmarsh Games`, on a line the
  candidate never gave fails, which is the plan's rule (Q1).
- `quoted_spans_with_origin` gives the same pairs as before on the existing test cells.

#### 2.6.4 Re-check of the fix round's saved runs

This is a scratch procedure before the 1a freeze, with no model calls. It reuses `qrule/recheck.py`'s loop over
`fixround/round/{haiku,sonnet,opus}/{tuesday,alone}/part-{1,2,3}`, which holds 1,220 runs: Haiku 230 per arm,
Sonnet and Opus 190 per arm.

1. Write the "before" checks with `HEAD` after the rename (the quote-list rule's checks) and the "after" checks with
   the 1a harness worktree, into `qrule/recheck-1a/{before,after}/<model>/<arm>/part-<p>/`. Saved checks files are
   never touched.
2. Report:
   - the checks files changed, of 1,220, by model, arm and module;
   - mock-interview's runs failing `quotes`, before and after, per model with tuesday against alone. This is the
     tracked-work line's form, "48 against 39 of 100 runs on Haiku";
   - each newly failing quotation, by stem, row, the first 80 characters of the quotation, its origin and the
     reason. This lets the owner see whether correct runs label sources with words `_SOURCE_LABEL` lacks, such as
     a company name, "LinkedIn" or "talk" (Q1);
   - whether any fix-round gated result moves, using `compare_arms --checks-from after/…` on each model.
3. The "after" checks become the scorer for the 1a baseline. The 1a candidate is scored by the same code, so the
   comparison is like for like (E8).

### 2.7 Partly graded runs

`run_fixtures.grade_gaps(out, graders) -> list[dict]` is pure over saved files and covers each expected grader of
each finished run. A finished run is one with a response and no execution error.

| `kind` | Condition |
|---|---|
| `absent` | the grader's file is missing (restart) |
| `limit` | an error-only file whose error matches `LIMIT` |
| `error` | an error-only file for another reason |
| `partial` | a file with verdicts whose `missing`, `incomplete` or conflicted numbers are not empty, i.e. its verdicts miss an expected number |

**Summary block** (`run_fixtures.main` and the driver), printed before the totals line:

```
--- partly graded ---
  job-underwriter-3.run0 grader 2: no verdict for #7 of 12 (re-asked once)
  mock-interview-7.canned.run1 grader 1: no grade file (a restart?)
2 grade file(s) miss an expected verdict and 1 is missing: <out>/grade-gaps.json lists them for recovery
```

Machine-readable file: `<out>/grade-gaps.json`, rewritten each pass. It is derived, never a grade.

```json
{"written": "2026-11-23T09:14:02Z", "pass_id": "…", "graders": 2,
 "files": [{"stem": "job-underwriter-3.run0", "turn": null, "grader": 2,
            "grade_file": "job-underwriter-3.run0.grade-2.json", "kind": "partial",
            "expected": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], "missing": [7], "invalid": [], "error": null}],
 "stems": {"partial": ["job-underwriter-3.run0"], "absent": ["mock-interview-7.canned.run1"],
           "limit": [], "error": []}}
```

A partly graded run still makes its expectations `unresolved` (classify), so exit code 3 holds.

**Recovery.** "The tested missing-grader path":

- `run_fixtures.py --out X --grade-gaps` prints the survey.
- `--grade-gaps --move`:
  - moves `limit` files to `killed/`;
  - moves `partial` files to `partial/` only with `--accept-partial`, the owner's accepted recovery;
  - leaves `error` files for the owner, as the fix round did;
  - writes `killed/regrade-<UTC>.txt`.
- `--stems F --skip-execute` grades, for each listed run, every grader number with no grade file in the folder.
  Today it skips a run that holds any grade file. The other grader's file is kept and never overwritten.
- The driver has the same pair, per `(stem, turn, grader)`.

### 2.8 Init, recovery and evidence handling (quality side)

- **Full init.** Kept under `init/`. Streams are kept whole, declined partials included (2.2).
- **Killed survey for fixtures.** `run_fixtures.killed_survey(out, work, runs)` classifies each harness-invalid stem:
  - `usage_limit`: a meta `error` matching `LIMIT`, or `limit_hit`;
  - `timeout`;
  - `declined`;
  - `invalid_room`;
  - `never_started`: an expected stem with no meta.

  `--killed [--move]` moves only the usage-limit stems to `killed/`, which is the existing protocol, and lists them
  with the never-started ones for `--stems`. Timeouts and other declines stay and count toward the 10% limit.
- **Hash and inventory.** `pass_problems()` and `--expect` (2.2).
- **Routing side.** Commit A (1.5, Q2).

### 2.9 E16 and E17

- **E16.** `run_fixtures.hidden_reaches(out) -> {"attempts": n, "reaches": [(stem, invocation, label)]}` reads
  every invocation of every Tuesday meta, including skipped and partial ones (their `fire` is computed from the
  partial stream), and the `killed/` folder. The driver adds every turn. Both summaries print the pooled count with
  its denominator. The plan's round-wide bound is applied in the record, not here.
- **E17.** See Q5. The recommended addition is a runtime-only third kind, `account_email`:
  - its value is read from `TUESDAY_SCAN_ACCOUNT_EMAIL`, never written to any file;
  - surfaces as `government_id`;
  - findings record counts and surfaces only, never the value or a location excerpt;
  - an occurrence outside assistant-authored surfaces (init, tool results, CLI metadata) is counted as
    `environment_events`, never a failure;
  - order: sentinel scan, then email scan, then masking of the backup, which is a separate step.

### 2.10 CI changes in full (`ci/check_skills.py`)

- `check_evals`: the `delivers` value check.
- `check_watch_outs`: the gate branch in the per-fixture loop, with the three rules in 2.5 and the reworded
  undeclared message.
- `check_fixtures`: the gate fixtures' check and research restrictions, and the sentinel lint (2.4.1), using
  `output_checks.sentinel_form`, `SENTINEL_SURFACES` and `canary_in` so the lint and the scan cannot disagree.
- New constants live in `output_checks`, the reader CI already shares: `GATE_QUESTION`, `GATE_EXPECTATION`,
  `GATE_EXCLUDED_CLAUSES` and `SENTINEL_SURFACES`.

### 2.11 Tests (`evals/test_harness.py`)

Each test is registered in `main()`'s tuple. All use fakes of `run_fixtures.claude` (as `test_execute_nudge` does)
or a stub CLI on `PATH` (as `STUB_CLI` does). No model is called.

**Launcher**

- `test_launcher_golden_argv`: argv, stdin and cwd for project, plugin, denied, canned, alone and through Tuesday
  equal fixed expectations recorded from `HEAD` before the refactor.
- `test_declined_partial_kept`: a `CLIDeclined` with stdout saves `.partial.jsonl`, sets `limit_hit` for the limit
  message, keeps `outcome: "declined"`, and keeps the error text.
- `test_stream_to`: the stream file exists after a timeout and after a decline.

**Transcript driver**

- `test_script_load`: valid scripts load. Each rule in 2.3.2 has a refusal case: a gap in turn numbers, N = 6,
  an unbound `{X}`, an unknown selector, both `prompt` and `from_fixture`, an empty `expectations` list, and a bad
  `core` pair.
- `test_selectors`: `bank_question` picks the visible ID in document order. Fewer IDs than picks gives
  `selection_failed`, scored; later turns are `not_reached`, with synthesised FAILs.
- `test_transcript_resume_flags`: turn 2's extra args start with `--resume <sid>`, and the rest equal turn 1's
  flags. Same cwd, same env keys, the same MCP config path, no `--fork-session`.
- `test_transcript_saved_before_next`: the fake checks that turn k's record and body exist on disk when turn k+1
  starts.
- `test_transcript_no_session_id`: turn 1's init without a session ID gives `no_session_id`; the scenario is set
  aside; turn 1's evidence is kept; no turn 2 is sent.
- `test_transcript_resume_refused`: turn 2 exits 1 with "No conversation found with session ID: …" and no init. It
  gives `resume_refused`; turn 1 is kept.
- `test_transcript_wrong_session`: turn 2's init carries another ID, then another cwd. Both give `wrong_session`.
- `test_transcript_usage_limit_turn_n`: the limit at turn 3 gives `usage_limit` with its partial stream kept, the
  scenario `killed`, and turns 1-2 intact.
- `test_transcript_timeout_turn_n`: a `CLITimeout` with a partial at turn 4 gives `timeout` and a set-aside
  scenario, with turns 1-3 graded normally.
- `test_transcript_restart`: a scenario folder left `running` with turns 1-2 and an `.inflight` stream. `--recover`
  calls it `killed`; `--move` moves the turn files and `.inflight`, writes the rerun list, and leaves set-aside
  stems unlisted.
- `test_transcript_malformed`: three sub-cases, each `malformed_stream` and set aside: only non-JSON lines;
  JSON with no init; exit 0 with no result. A fourth case, one stray non-JSON line in an otherwise complete stream,
  is `completed` with `stream_unparsed: 1`.
- `test_transcript_void`: a foreign Tuesday skill in the init gives `void`.
- `test_transcript_nudge`: the first attempt does not fire and the nudge fires. Two rooms, two call logs; the
  session is the nudged one's; `attempts[0]` is kept; the summary counts 1 nudged; a hidden reach in the first
  attempt is counted.
- `test_transcript_no_later_nudge`: a turn-2 stream with no Skill call sends no nudge.
- `test_transcript_not_fired`: the nudge also does not fire, giving `harness_invalid`.
- `test_turn_body_reads`: `reads: ["file:tuesday-dossier.md"]` puts that file whole in the body. A missing
  `require_file` gives `turn_file` FAIL, scored.
- `test_transcript_grading`: two fake graders. Verdicts per turn are stored with `turn` and `pass_id`; the core
  screen is a joint pass; one grader FAIL fails it.
- `test_transcript_grade_record`: `grader_prompt_version == "t1"`, `grader_prompt_sha256`, a pinned model, and the
  expectation hashes.
- `test_transcript_regrade`: `--skip-execute` grades only the missing `(turn, grader)`.
- `test_transcript_summary`: the counters per outcome, the 10% line, and exit code 3 for set-aside or killed
  scenarios.

**Sentinel scan** (pure, on synthetic evidence)

- `test_sentinel_tool_args_decoded_and_escaped`: the ID in a tool input, written raw, `–`-escaped in JSON, as
  an HTML entity and URL-encoded, is found in each.
- `test_sentinel_after_clip`: the ID at character 2,500 of a Write `content` is found from the stream. The meta's
  `tool_calls` lack it.
- `test_sentinel_generated_file`: the ID only in a room file, written without any tool argument holding it, fails
  `government_id.file`. The ID in a filename fails `.filename`. A docx member is found.
- `test_sentinel_killed_attempt`: the ID in a timed-out partial stream fails, and the scan is stored with the
  harness-invalid run.
- `test_sentinel_exclusions`: the ID in the prompt, in a `tool_result` (a Read of the CV), in the corpus and in the
  server's `returned_urls` is clean.
- `test_sentinel_registration_display`: the registration number in chat and in a saved pack's Write content is
  clean.
- `test_sentinel_registration_research`: the registration number in a refused `WebSearch` query, an
  `mcp__web__fetch` URL, a `permission_denials` input and a server log `args` fails `professional_registration.research`.
- `test_sentinel_any_tool`: the government ID in a Bash command, a Task prompt and a TodoWrite item fails.
- **Reformatted, distinct surfaces.**
  - `test_sentinel_reformatted_text`: assistant text with a double space and a line break inside a grouped form.
  - `test_sentinel_reformatted_tool_arg`: a tool argument with an en dash between groups.
  - `test_sentinel_reformatted_file`: a saved file with a non-breaking space and regrouped digits from the frozen
    list.
- `test_sentinel_attempts`: a hit only in the unnudged attempt makes the stem FAIL with `attempts.first` hit and
  `attempts.nudged` clean; then the reverse.
- `test_sentinel_by_attempt`: the record's shape and keys.
- `test_sentinel_missing_evidence`: no stream; a canned attempt without a log; a truncated file. Each gives
  `unscored`; the meta is harness-invalid; the run is not graded.
- `test_sentinel_boundaries`: a spelling inside a longer token is not a hit (documented limit), and thinking blocks
  are counted, not failed.

**Gate-only contract**

- `test_gate_only`: a gate fixture with a clean reply passes. A watch-out line fails `chat`; the bare sentence
  fails `chat`; a file in the room or scratchpad fails `files`; no inventory leaves `gate_only` unchecked.
  `quotes`, `check_accounting` and `watch_out` are not run.
- An undeclared fixture's results are unchanged: the records over the existing fixtures are equal before and after.

**Quote fix:** `test_quote_one_quotation`, as in 2.6.3.

**Partly graded runs**

- `test_partial_grade_report`: a stub grader drops verdict 7 on both the ask and the re-ask. The summary block
  lists it; `grade-gaps.json` lists `kind: "partial", missing: [7]`; exit code 3.
- `test_partial_grade_recovery`:
  - `--grade-gaps --move` without `--accept-partial` moves nothing partial, and with it moves the file to
    `partial/`;
  - `--stems --skip-execute` regrades only grader 2, and grader 1's file is unchanged;
  - classify then reads the run fully graded;
  - an `absent` grader is filled without any move;
  - an `error` file is left alone.

**Recovery, passes and init**

- `test_killed_survey`: a mixed batch (a limit kill, a timeout, a decline and a never-started stem) is classified
  per stem. Only the limit kill and the never-started stem are listed, and the limit kill is moved.
- `test_pass_mismatch`: two pass records with different inventory refuse with exit 3. A different CLI version is
  reported only.
- `test_expect_refuses`: `--expect` with one changed digest refuses before any call, since the fake is never
  called.
- `test_pass_records`: `pass_id` is present in meta, turn and grade records.
- `test_init_preserved`: the full init event is saved once under `init/`, and its sha is in the invocation.
- `test_hidden_reach_count`: reaches are counted across first, nudged, skipped and partial invocations and later
  turns.

**Bookkeeping:** extend `test_shared_ledger_rules` or the existing set test so that `sentinel` and `gate_only` are
in `RECORDS_PASSES`.

### 2.12 Doc changes (`evals/README.md`)

- **"Clean-room fixtures" intro.** What each run now keeps:
  - whole streams, a declined run's partial included;
  - `files/` copies with the inventory;
  - `init/`;
  - `passes/` with `pass_id`, which says which invocation supplies each grade;
  - the `--expect` refusal.
- **"Deterministic checks".**
  - Quotes bullet: add that a single quotation's label, like a shared one, must name a document or a person
    (`_SOURCE_LABEL`, or a quoted title in its origin) to be another source's line. Name `names_source`, and state
    the company-name consequence.
  - Watch-out bullet: replace "A fixture whose turn delivers nothing … adding one means exempting it here first"
    with the gate exemption.
  - New bullet, **Gate-only turns** (`gate_only`): the key, what is switched off, the two findings, and the CI
    rules.
  - New bullet, **Sentinels** (`sentinel`): declaration, frozen spellings, surfaces, exclusions, decodings,
    normalisation, limits, unscored, the planted-event report, results by stem and attempt.
- **"Exit codes".** The partly graded block, `grade-gaps.json`, the planted-event and hidden-reach lines.
- **"Regrading a saved set".**
  - `--grade-gaps [--move] [--accept-partial]`;
  - `--stems … --skip-execute` now fills each missing grader of a listed run;
  - `--killed [--move]`.
- **"Through Tuesday".** E16's count across every invocation and turn.
- **New section "Transcripts" (`run_transcripts.py`):**
  - script format;
  - rooms, resume flags and session verification;
  - nudge rule;
  - records;
  - the outcome table of 2.3.6;
  - grading prompt `t1`;
  - recovery;
  - the summary;
  - one usage example per arm.

  It replaces nothing.
- **Commit A** changes "Layouts" (1.4).

`CONTRIBUTING.md`'s three-outcomes table is outside both boundaries (Q6).

---

## 3. Deferred, and where it lands

| Item | Lands in |
|---|---|
| The three 1b scripts (recorded 3 turns, ordinary drill 5, debrief 4): fixed text, selectors, per-turn rubrics | Frozen for the 19 Nov smoke on a draft 1b candidate; tracked per Q3. The 1a harness ships only the format, the validator and synthetic test scripts |
| Driver fixes found by the smoke | 1b harness commit (`run_transcripts.py`, `test_harness.py`) |
| A machine read of `pack_feedback` fields, if graders prove unreliable | 1b harness, if needed. 1a gives graders the whole dossier file and checks it exists |
| Ledger-row selector for the resumed CV control; writing-approval and resumed-CV scripts; the attestation check and test | Round 2 harness |
| The resume-tailor gate fixtures (missing posting or candidate evidence), reusing `"delivers": "gate_question"` | Round 2 candidate (E19). CI already accepts them (2.5) |
| The 1a fixtures that use the new keys: nurse and teacher `sentinels`, the anonymous-invite gate fixture | 1a candidate (`skills/*/evals/evals.json`) |
| Fixture-domain rename | Its own commit before both Round 2 pins (unchanged) |
| Closing the backlog lines (quote gap, partial-grade report, routing cost) in `docs/tracked-work.md` | 0.3.0 record commit (Q7) |

## 4. Carried items: when each is done

This answers the user's "don't forget to do these at the right time".

1. **Opus, the sentence after the fit ledger, iteration 2.**
   - Rides the **1a candidate**: the rule 2 quote in `skills/job-underwriter/references/risk-and-decision.md`,
     synced to its Tuesday copy.
   - The candidate also amends `ci/test_checks.py` if CI pins rule 2's literals.
   - Measured by the fix round's measure in the eight existing rooms.
   - Not in either harness commit. Nothing in this design moves the `ledger_sentence` check, so the item is read
     by its own measure. Verify in commit B that the records over the existing fixtures are unchanged.
2. **resume-tailor's watch-out wording.**
   - Waits for the **Round 2 candidate** (E10's shared line for CVs, letters and answers). The places to change:
     - `skills/resume-tailor/SKILL.md:85`;
     - `references/coverage-and-gaps.md:75`;
     - the eval closing clause;
     - `README.md:97` and its "Why it's there" cell;
     - `RT_WATCH` in `ci/test_checks.py:2933`.
   - Or it waits for the per-application folders change after Round 2.
   - Round 1 requires an empty `skills/resume-tailor/` diff. Neither harness commit touches it. The new
     `ledger_first` entry in `GATE_EXCLUDED_CLAUSES` is CI-only.
3. **The single-quotation quote gap.**
   - Fixed in **commit B**, before both 1a pins (2.6).
   - The fix round's 1,220 saved runs are re-checked, and the shift reported, **before the 1a freeze** (2.6.4).
   - The "after" checks become the 1a baseline's scorer.
   - The backlog line is closed in the **0.3.0 record** (Q7).

Order before the 1a pins:

1. the code-name rename (in progress);
2. commit A;
3. commit B;
4. the re-check report;
5. digest verification after each commit (`check_skills.py --only tuesday`, the three accepted values byte for
   byte);
6. all four CI steps, plus `evals/routing_variants.py --check`.

## 5. Open questions (where the plan is silent or contradicts the code), with recommendations

- **Q1. Title and company origins under the one-quotation rule.**
  - The conflict: applying `_SOURCE_LABEL` to every quotation breaks an existing must-pass test
    (`test_audit_quotes`, Larkspur). There `"…" — Saltmarsh Games, "Announcing Project Larkspur"` is a page's line
    and its title, and neither label matches `_SOURCE_LABEL`.
  - **Recommended:** a quoted title in an origin names a document (`titled`, 2.6.2), so both Larkspur quotations
    keep passing. A company name alone names neither a document nor a person, so it fails, as the plan's rule
    says.
  - The re-check lists every newly failing origin, so the owner can decide whether to widen `_SOURCE_LABEL` (for
    example the employer the request names, "LinkedIn", "talk"). Widening it also widens the 16 November list rule.
- **Q2. Routing recovery and init evidence need `run_routing.py`.**
  - The conflict: no boundary from 1a to Round 2 allows `run_routing.py` except commit A, whose row lists only the
    cost behaviour.
  - **Recommended:** add per-run `session_id`, `init_sha256` with deduplicated `init_events`, and the tested
    `merge_arm` with `--merge` to commit A (1.5).
  - Otherwise 1a's explicit panel and Round 2's 1,620-session pair rely on the untracked fix-round merge script,
    and a plan edit would be needed to track it later.
- **Q3. Where the frozen 1b scripts live.**
  - The conflict: the 1b harness commit exists only "if smoke requires a fix" and may change only
    `run_transcripts.py` and `test_harness.py`, yet the smoke needs frozen scripts. Round 2 adds its scripts in its
    harness commit.
  - **Recommended:** the driver reads `--scripts FILE`. For the smoke, the 1b file is frozen outside both
    checkouts with its sha256 in the manifest, as the external case file is.
  - Then make the 1b harness commit unconditional, to track the identical script data in `run_transcripts.py`'s
    `SCRIPTS` registry (empty in 1a), as Round 2 does.
  - To cover fixture isolation for scripts that CI does not read, add a `--lint` mode in the driver that runs CI's
    answer-key comparison on the script file.
- **Q4. The transcript grader prompt's version name.**
  - The plan says only "version 3 as the predecessor".
  - **Recommended:** `"t1"`, with `grader_prompt_predecessor: "3"` and a sha256 of the exact text in every grade.
    The single-turn prompt stays version 3 for E8 reuse.
- **Q5. E17 detection in the 1a harness.**
  - The plan scores E17 but lists no harness row for it.
  - **Recommended:** the runtime-only `account_email` kind through the same scanner (2.9), with counts only and
    the value never persisted, run after the sentinel scan and before masking.
  - Otherwise E17 needs a separate scorer before the first privacy case runs.
- **Q6. `CONTRIBUTING.md`'s three-outcomes table.**
  - It has no rows for the transcript decline paths, and the file is outside both boundaries.
  - **Recommended:** document them in `evals/README.md` now. The rule itself, that every path has a test, is met.
    The owner may add `CONTRIBUTING.md` to the 1a harness boundary; it is non-payload.
- **Q7. Closing the backlog lines in `docs/tracked-work.md`.**
  - The three lines in question are the quote gap, the partial-grade report and the routing cost. The file is
    outside both commits' boundaries.
  - **Recommended:** close them, with the re-check numbers, in the 0.3.0 record commit, whose boundary includes the
    file.
- **Q8. A Bash command naming the registration number.**
  - The plan scopes the registration sentinel to the four research tools and the server log, so a refused
    `curl …?pin=` in Bash would not count.
  - No question is needed; it is recorded as a limit in the README. An optional report-only reading is possible if
    the owner wants it.
- **Q9. Thinking blocks.**
  - Silent: they are model-authored but neither chat, a file nor an outbound argument (E17's surfaces).
  - **Recommended:** exclude them from the failure and report a count.
- **Q10. Events in set-aside or killed sessions.**
  - The plan says to scan "all first, nudged and partial attempts" and use eligible sessions as denominators.
  - **Recommended:** an event seen in any attempt counts against the zero bar. Denominators stay the eligible
    sessions, and events in set-aside or killed sessions are listed apart, so a kill never hides one.

## 6. Risks and checks before committing

- **Resume keeps the session ID.** A CLI that forks on `--resume` turns every turn 2 into `wrong_session`. Check
  this in the preflight on the pinned CLI and again in the smoke; the outcome is explicit either way.
- **CLI-owned scratchpad files.** If the CLI writes housekeeping files into a scratchpad, `gate_only:files` and the
  inventory would read them as output. The preflight save probe records an idle room's scratchpad. If any
  CLI-owned file appears, freeze its pattern in the manifest before the 1a pins, as an inventory exclusion with a
  test.
- **The refactor must change nothing a run sends.** The golden-argv test is the guard.
- **Out-of-scope finding (not in either boundary).** In `compare_arms.expectation_states`, an expectation number
  missing from every grader's verdicts of a run is absent rather than `partial`. A run is partial only when it has
  no grade at all. The new `grade-gaps.json` and the runner's summary report such runs, but the comparison report
  would not. This is worth a separate fix to `compare_arms.py`.
