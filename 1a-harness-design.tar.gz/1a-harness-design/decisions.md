# Decisions on the harness design's open questions (16 November 2026)

Made by the main session from the plan and its intent, to be recorded in the PR for the owner's review (the owner may veto any).

1. **Commit A scope (Q2).** Accept. Commit A ("routing reporting") also carries routing recovery and init evidence:
   - per-run `session_id` and `init_sha256`, with `init_events` deduplicated;
   - the pure `merge_arm` port of the fix round's merge rule, with its `--merge` CLI and `test_routing_merge`;
   - each read stream copied to `<json-out dir>/streams/`.

   Reason: the harness contract row "Init, routing recovery and cost evidence" requires these before the pins, and `run_routing.py` sits only in commit A's boundary. Update that row of the plan's write boundary to say so.
2. **Gate fixtures and CI.** Accept. Commit B exempts expectations of fixtures that declare `delivers: gate_question` from check_skills' `closing_order` and `question_budget` restatement checks, or reads them against a one-question gate that ends with the question. Add must-pass cases and a mutation proving a non-gate fixture still fails.
3. **The one-quotation quote fix (Q1).** Do not use `_SOURCE_LABEL` (an allowlist) for single quotations; it would fail company-name labels such as "— Saltmarsh Games". Use a denylist for single quotations:
   - A single quotation is another source's line only when `other_source(origin)` holds and the origin does not name only a row ID, a confidence or a comment.
   - Denied shapes:
     - one or more row IDs (`[A-Z]{1,3}\d+[a-z]?` joined by commas, slashes or "and"), optionally followed by a confidence (high / medium / low);
     - "verbatim", "both verbatim", "nearest quote…";
     - "you said", "you told me", "what you told me", "your notes";
     - a dash comment such as "— shows ownership".

     Keep the denylist a named, tested regex, `_NO_SOURCE_LABEL`.
   - Lists keep the stricter allowlist already merged.
   - Narrow the `titled` exception the same way.
   - Tests:
     - must-fail: (S1), (verbatim), (V1, high), "— S1, \"…\"" and "— verbatim, \"…\"" single quotations of request lines offered as the candidate's;
     - must-pass: the Saltmarsh Games and Larkspur cases, and every existing must-pass case.
   - Re-check the fix round's saved runs and report the origins whose reading changed.
4. **Grade gaps in the manifest.** Yes. Before compare_arms is read, the 1a manifest requires a grade-gap report (no gap, or each gap listed with how it is handled) for both revisions, including the saved fix-round baseline sets. Commit B's tracked gap report produces it.
5. **Haiku's five-of-ten baseline subset.** Freeze it now, outcome-blind, by run ID: runs 0–4 of each Haiku cell. Record it in the plan's manifest notes before any per-stem re-check result is read for 1a.
6. **E17 account email.** Yes. Add a runtime-only `account_email` kind:
   - The value comes from an environment variable at run time and is never written to the repository, the results or the logs.
   - It is scanned on the same surfaces as `government_id`.
   - It is reported as counts only.
7. **`protected_value` kind.** Yes. It has government_id's surfaces and is reported separately (for job-underwriter case (a) and any invite assessed for leakage).
8. **CONTRIBUTING.md (Q6).** Yes. It joins commit B's boundary for the transcript rows in the three-outcomes table. Record that in the plan's write boundary.
9. **1b scripts (Q3).** Deferred to the 1b work; not needed for commit B. Commit B's driver loads a script from a path given on the command line and validates it.
10. **Planted events in set-aside or killed sessions (Q10).** Recommend: count them against the zero bar and report them. A leak in a session that was later set aside still happened. This is a bar question, so it goes into the 1a manifest for the owner's approval under E21. Commit B records such events by stem and attempt whatever the session's outcome.

Every high- and medium-severity gap in the critique is to be fixed in the implementation as the critique's "fix" says, unless it conflicts with a decision above. Low-severity gaps are fixed too, where small.
