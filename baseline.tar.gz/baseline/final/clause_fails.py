import json, sys, glob
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model, skill, token, arm = sys.argv[1:5]
ev=json.load(open(f'/home/user/tuesday/skills/{skill}/evals/evals.json'))
idx={e['id']:[i+1 for i,x in enumerate(e['expectations']) if token in x] for e in ev['evals']}
for g in sorted(glob.glob(f'{S}/{model}/{arm}/{skill}-*.grade-*.json')):
    d=json.load(open(g))
    for v in d['verdicts']:
        if v['n'] in idx[d['id']] and v['verdict']=='FAIL':
            print(g.split('/')[-1].replace('.json',''), '|', v['why'][:260])
