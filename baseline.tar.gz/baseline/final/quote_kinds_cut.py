"""mock-interview quotes failures by kind, read from each check's message, and what is left if kinds are accepted.

A = the candidate's exact words, cut differently from the fit snapshot ("not in the fit snapshot's evidence column");
B = not the candidate's words / source form ("not in what the candidate gave"); C = fixture 5's sentence the
fixture's candidate_text omits ("which I've read"); E = no table. Sonnet uses the re-check (fixed check, 2d7dbfc).
"""
import json
from collections import Counter
from pathlib import Path
S = Path(__file__).resolve().parent.parent
for step in ("sonnet-recheck", "haiku", "opus"):
    for arm in ("alone", "tuesday"):
        runs = Counter(); left_c = left_ac = 0
        for p in sorted((S / step / arm).glob("mock-interview-*.checks.json")):
            ks = set()
            for c in json.loads(p.read_text()).get("checks", []):
                if c["check"] == "quotes" and c["verdict"] == "FAIL":
                    w = c["why"].lower()
                    ks.add("C" if "which i've read" in w else "A" if "not in the fit snapshot" in w
                           else "B" if "not in what the candidate gave" in w else "E")
            for k in ks:
                runs[k] += 1
            runs["any"] += bool(ks); left_c += bool(ks - {"C"}); left_ac += bool(ks - {"A", "C"})
        print(f"{step:15} {arm:8} failing runs {runs['any']:2}  by kind {dict(sorted((k, v) for k, v in runs.items() if k != 'any'))}"
              f"  left if C accepted {left_c}, if A and C accepted {left_ac}")
