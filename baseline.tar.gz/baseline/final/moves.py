"""Expectations whose grader pass count moves by 4+ of 10 verdicts through Tuesday (the reported rule is 6+), per model.

Usage: python3 -I moves.py <repo>. Prints the clause each expectation carries, so a move can be tied to an open issue.
"""
import json, re, sys
from collections import defaultdict
from math import comb
from pathlib import Path
S = Path(__file__).resolve().parent.parent
REPO = Path(sys.argv[1])
MODS = ("job-underwriter", "mock-interview", "resume-tailor")
texts = {}
for mod in MODS:
    spec = json.loads((REPO / "skills" / mod / "evals" / "evals.json").read_text())
    for e in spec["evals"]:
        for i, x in enumerate(e["expectations"], 1):
            texts[(mod, e["id"], i)] = x if isinstance(x, str) else json.dumps(x)
for step in ("sonnet", "haiku", "opus"):
    mv = defaultdict(lambda: {"alone": [0, 0], "tuesday": [0, 0]})
    for arm in ("alone", "tuesday"):
        for meta in sorted((S / step / arm).glob("*.meta.json")):
            stem = meta.name[:-10]; m = json.loads(meta.read_text())
            if (m.get("harness") or {}).get("status") != "ok":
                continue
            mod = next(x for x in MODS if stem.startswith(x))
            for g in (S / step / arm).glob(f"{stem}.grade-*.json"):
                d = json.loads(g.read_text())
                if d.get("harness_invalid") or d.get("error"):
                    continue
                for v in d.get("verdicts", []):
                    k = (mod, m["id"], m.get("mode"), v["n"])
                    mv[k][arm][0] += v["verdict"] == "PASS"; mv[k][arm][1] += 1
    print("=====", step)
    for k, v in sorted(mv.items(), key=lambda kv: str(kv[0])):
        a, t = v["alone"], v["tuesday"]
        if not a[1] or not t[1]:
            continue
        d = (t[0] / t[1] - a[0] / a[1]) * 10
        if abs(d) >= 4 - 1e-9:
            txt = texts.get((k[0], k[1], k[3]), "")
            cl = ",".join(re.findall(r"\{\{([a-z_]+)\}\}", txt)) or txt[:70]
            print(f"  {'UP  ' if d > 0 else 'DOWN'} {k[0]} fixture {k[1]} {k[2] or ''} #{k[3]}: alone {a[0]}/{a[1]} tuesday {t[0]}/{t[1]}  [{cl}]")
