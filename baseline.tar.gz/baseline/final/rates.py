"""Rate view with parent denominators for fail-only checks, Fisher exact p, and overlaps between paired checks.

Usage: python3 -I rates.py. Reads m18/{sonnet,haiku,opus}/{alone,tuesday}/*.checks.json (runs with harness ok only).
"""
import json
from collections import defaultdict
from math import comb
from pathlib import Path
S = Path(__file__).resolve().parent.parent
MODS = ("job-underwriter", "mock-interview", "resume-tailor")
PARENT = {"gates_form": "gates_line", "severity_form": "severity", "evidence_form": "quotes",
          "ledger_markup": "ledger_sentence"}


def fisher(a, n1, b, n2):
    """Two-sided exact p for a/n1 vs b/n2."""
    K = a + b; N = n1 + n2
    def p(x): return comb(n1, x) * comb(n2, K - x) / comb(N, K)
    obs = p(a); lo = max(0, K - n2); hi = min(K, n1)
    return min(1.0, sum(p(x) for x in range(lo, hi + 1) if p(x) <= obs * (1 + 1e-9)))


def load(step, arm):
    runs = []
    for meta in sorted((S / step / arm).glob("*.meta.json")):
        stem = meta.name[:-10]; m = json.loads(meta.read_text())
        if (m.get("harness") or {}).get("status") != "ok":
            continue
        mod = next(x for x in MODS if stem.startswith(x))
        cj = S / step / arm / f"{stem}.checks.json"
        checks = json.loads(cj.read_text()).get("checks", []) if cj.exists() else []
        by = defaultdict(list)
        for c in checks:
            by[c["check"]].append(c["verdict"])
        runs.append((stem, mod, {k: any(v == "FAIL" for v in vs) for k, vs in by.items()}))
    return runs


for step in ("sonnet", "haiku", "opus"):
    data = {arm: load(step, arm) for arm in ("alone", "tuesday")}
    print(f"===== {step}")
    for mod in MODS:
        st = {}
        for arm, rs in data.items():
            d = defaultdict(lambda: [0, 0])
            for stem, m, ch in rs:
                if m != mod:
                    continue
                for k, f in ch.items():
                    d[k][1] += 1; d[k][0] += f
                for k, par in PARENT.items():
                    if par in ch and k not in ch:
                        d[k][1] += 1  # applied through its parent, passed
            st[arm] = d
        for k in sorted(set(st["alone"]) | set(st["tuesday"])):
            fa, na = st["alone"][k]; ft, nt = st["tuesday"][k]
            if ft - fa >= 3 or (na and nt and ft / nt - fa / na >= 0.10 and ft >= 3):
                ra = fa / na if na else float("nan"); rt = ft / nt if nt else float("nan")
                print(f"  {mod:16} {k:22} tuesday {ft}/{nt} ({100*rt:.0f}%)  alone {fa}/{na} ({100*ra:.0f}%)  "
                      f"diff {100*(rt-ra):+.0f} pts  Fisher p={fisher(ft, nt, fa, na):.3f}")
    # overlaps
    for arm, rs in data.items():
        for a, b in (("gates_form", "gates_line"), ("accept", "zero_calls")):
            both = sum(1 for _, m, ch in rs if ch.get(a) and ch.get(b))
            ea = sum(1 for _, m, ch in rs if ch.get(a)); eb = sum(1 for _, m, ch in rs if ch.get(b))
            either = sum(1 for _, m, ch in rs if ch.get(a) or ch.get(b))
            if ea or eb:
                print(f"  overlap {arm:8} {a}&{b}: {a} {ea}, {b} {eb}, both {both}, either {either}")
