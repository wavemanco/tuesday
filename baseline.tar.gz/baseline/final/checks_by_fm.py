"""Per model, module, check: failing runs by fixture-mode, both arms, plus sample 'why' strings."""
import json, sys
from collections import defaultdict
from pathlib import Path
S = Path(__file__).resolve().parent.parent
MODS = ("job-underwriter", "mock-interview", "resume-tailor")
step, mod, chks = sys.argv[1], sys.argv[2], sys.argv[3].split(",")
for arm in ("alone", "tuesday"):
    byfm = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    whys = defaultdict(list)
    for meta in sorted((S / step / arm).glob(f"{mod}-*.meta.json")):
        stem = meta.name[:-10]
        cj = S / step / arm / f"{stem}.checks.json"
        if not cj.exists():
            continue
        d = json.loads(cj.read_text())
        fm = stem[len(mod) + 1:].rsplit(".run", 1)[0]
        by = defaultdict(list)
        for c in d.get("checks", []):
            by[c["check"]].append(c)
        for ch in chks:
            if ch in by:
                byfm[ch][fm][1] += 1
                fails = [c for c in by[ch] if c["verdict"] == "FAIL"]
                if fails:
                    byfm[ch][fm][0] += 1
                    whys[ch].append((stem, fails[0].get("target"), fails[0]["why"][:230]))
    for ch in chks:
        tot = [sum(v[0] for v in byfm[ch].values()), sum(v[1] for v in byfm[ch].values())]
        print(f"[{step} {arm}] {ch}: {tot[0]}/{tot[1]}  " + "  ".join(f"{fm}:{v[0]}/{v[1]}" for fm, v in sorted(byfm[ch].items()) if v[0] or True))
        if "-v" in sys.argv:
            for w in whys[ch][:int(sys.argv[-1]) if sys.argv[-1].isdigit() else 6]:
                print("     ", w)
