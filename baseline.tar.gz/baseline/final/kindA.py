import json, sys, glob, re, collections
sys.path.insert(0,'/home/user/tuesday/evals')
import output_checks as oc
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model=sys.argv[1]
def snapshot_spans(md):
    spans=[]
    for source, body in oc.split_response(md):
        for t in oc.md_tables(body):
            names=oc.header_names(t)
            v=next((i for i,h in enumerate(names) if 'verbatim' in h), None)
            if v is None: continue
            for cells in t['rows']:
                if v < len(cells):
                    spans += [oc.normalise_quote(s).strip(oc.EDGE) for s in oc.quoted_spans(cells[v])]
    return spans
for arm in ('alone','tuesday'):
    runs=collections.defaultdict(set)
    for f in sorted(glob.glob(f'{S}/{model}/{arm}/mock-interview-*.checks.json')):
        c=json.load(open(f))
        A=[x for x in c['checks'] if x['check']=='quotes' and x['verdict']=='FAIL' and "fit snapshot's evidence column" in x['why']]
        if not A: continue
        md=open(f.replace('.checks.json','.md')).read()
        sp=[s for s in snapshot_spans(md) if s]
        for x in A:
            m=re.search(r': "(.*?)" — "', x['why'])
            q=oc.normalise_quote(m.group(1)).strip(oc.EDGE) if m else ''
            contained=[s for s in sp if len(s)>8 and s in q]
            kind='joined/extended (contains %d snapshot quote(s))'%len(contained) if contained else 'not in snapshot at all'
            runs[c['stem']].add(kind if not contained else ('joined' if len(contained)>=2 else 'extended'))
    print(model, arm, {k: sorted(v) for k,v in runs.items()})
