import json, sys, glob, os, collections
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model=sys.argv[1]; fix=sys.argv[2] if len(sys.argv)>2 else None
checks_of_interest=set(sys.argv[3].split(',')) if len(sys.argv)>3 else {'zero_calls','accept','skip_has_no_call','yes_has_call','unavailable_has_refusal','off_target_shown'}
for arm in ('alone','tuesday'):
    print('=====',model,arm)
    for f in sorted(glob.glob(f'{S}/{model}/{arm}/mock-interview-*.meta.json')):
        m=json.load(open(f)); stem=m['stem']
        if fix and m['id']!=int(fix): continue
        c=json.load(open(f.replace('.meta.json','.checks.json')))
        fails=[x for x in c.get('checks',[]) if x['verdict']=='FAIL' and x['check'] in checks_of_interest]
        log=m.get('research_log') or []
        calls=[f"{e.get('kind')}:{e.get('tool')}:{str(e.get('query_or_url'))[:70]!r}:{e.get('outcome')}" for e in log]
        if fails or log:
            print('--',stem, 'calls:',len(log))
            for cl in calls: print('     call', cl)
            for x in fails: print('     FAIL',x['check'],x['target'],x['why'][:220])
