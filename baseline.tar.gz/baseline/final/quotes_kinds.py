import json, sys, glob, collections
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
base=sys.argv[1]  # e.g. opus or sonnet-recheck
def kind(why):
    if "fit snapshot's evidence column" in why: return 'bank_quote_not_in_snapshot'
    if "not in what the candidate gave" in why: return 'not_candidate_text'
    if 'no fit snapshot' in why: return 'no_snapshot_table'
    return 'other:'+why[:60]
for arm in ('alone','tuesday'):
    runkinds=collections.Counter(); fixt=collections.defaultdict(list)
    files=sorted(glob.glob(f'{S}/{base}/{arm}/mock-interview-*.checks.json'))
    for f in files:
        c=json.load(open(f))
        fails=[x for x in c.get('checks',[]) if x['check']=='quotes' and x['verdict']=='FAIL']
        if not fails: continue
        ks=sorted({kind(x['why']) for x in fails})
        for k in ks: runkinds[k]+=1
        fixt[c['stem'].rsplit('.run',1)[0]].append('+'.join(k[:12] for k in ks))
    n=sum(1 for f in files if any(x['check']=='quotes' and x['verdict']=='FAIL' for x in json.load(open(f)).get('checks',[])))
    print(base, arm, 'files', len(files), 'runs failing', n, 'runs by kind', dict(runkinds))
    for k,v in sorted(fixt.items()): print('    ', k, v)
