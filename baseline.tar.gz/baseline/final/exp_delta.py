import json, sys, glob, collections
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model, skill = sys.argv[1], sys.argv[2]
thr=int(sys.argv[3]) if len(sys.argv)>3 else 2
evals=json.load(open(f'/home/user/tuesday/skills/{skill}/evals/evals.json'))
exp={e['id']:e['expectations'] for e in evals['evals']}
cnt={a:collections.defaultdict(lambda:[0,0]) for a in ('alone','tuesday')}
for a in cnt:
    for g in glob.glob(f'{S}/{model}/{a}/{skill}-*.grade-*.json'):
        d=json.load(open(g))
        if d.get('harness_invalid') or d.get('error'): continue
        for v in d['verdicts']:
            k=(d['id'], d.get('mode'), v['n'])
            cnt[a][k][0]+= v['verdict']=='PASS'; cnt[a][k][1]+=1
tot={a:[sum(x[0] for x in cnt[a].values()), sum(x[1] for x in cnt[a].values())] for a in cnt}
print(model, skill, 'totals', tot)
rows=[]
for k in sorted(set(cnt['alone'])|set(cnt['tuesday']), key=str):
    pa,na=cnt['alone'][k]; pt,nt=cnt['tuesday'][k]
    rows.append((pt-pa, k, pa,na,pt,nt))
# by fixture
byfix=collections.defaultdict(lambda:[0,0,0,0])
for d,k,pa,na,pt,nt in rows:
    f=(k[0],k[1]); byfix[f][0]+=pa; byfix[f][1]+=na; byfix[f][2]+=pt; byfix[f][3]+=nt
print('by fixture-mode (alone pass/n, tuesday pass/n, delta):')
for f,v in sorted(byfix.items(), key=str): print('  ',f, f'{v[0]}/{v[1]}', f'{v[2]}/{v[3]}', v[2]-v[0])
print(f'expectations moving by {thr}+ verdicts:')
for d,k,pa,na,pt,nt in sorted(rows):
    if abs(d)>=thr:
        t=exp[k[0]][k[2]-1]
        print(f'  {d:+d}  fixture {k[0]} mode {k[1]} exp {k[2]}: alone {pa}/{na} tuesday {pt}/{nt} :: {t[:160]}')
