import json, sys, glob, collections
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model, skill, token = sys.argv[1], sys.argv[2], sys.argv[3]
ev=json.load(open(f'/home/user/tuesday/skills/{skill}/evals/evals.json'))
idx={e['id']:[i+1 for i,x in enumerate(e['expectations']) if token in x] for e in ev['evals']}
for a in ('alone','tuesday'):
    p=n=0
    for g in glob.glob(f'{S}/{model}/{a}/{skill}-*.grade-*.json'):
        d=json.load(open(g))
        for v in d['verdicts']:
            if v['n'] in idx[d['id']]: n+=1; p+= v['verdict']=='PASS'
    print(model, skill, token, a, f'{p}/{n}')
