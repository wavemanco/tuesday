import json, glob, collections
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
for model in ('sonnet','haiku','opus'):
  for skill in ('job-underwriter','mock-interview'):
    for arm in ('alone','tuesday'):
        applied=collections.Counter(); failed=collections.Counter(); qs=[]
        for f in sorted(glob.glob(f'{S}/{model}/{arm}/{skill}-*.checks.json')):
            c=json.load(open(f))
            z=[x for x in c.get('checks',[]) if x['check']=='zero_calls']
            if not z: continue
            key=c['stem'].rsplit('.run',1)[0]
            applied[key]+=1
            if z[0]['verdict']=='FAIL':
                failed[key]+=1
                m=json.load(open(f.replace('.checks.json','.meta.json')))
                qs.append((c['stem'].split('-',2)[-1] if False else c['stem'], [str(e.get('query_or_url'))[:60] for e in (m.get('research_log') or [])]))
        print(model, skill, arm, 'zero_calls applied', dict(applied), 'failed', dict(failed))
        if model=='opus' and skill=='job-underwriter':
            for q in qs: print('     ', q)
