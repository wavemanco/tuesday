"""Run and grader cost per model, arm and module, from each run's stream (rooms named in .meta.json) and grade files."""
import json
from collections import defaultdict
from pathlib import Path
S = Path(__file__).resolve().parent.parent
MODS = ("job-underwriter", "mock-interview", "resume-tailor")
for step in ("sonnet", "haiku", "opus"):
    cost = defaultdict(float)
    for arm in ("alone", "tuesday"):
        for meta in (S / step / arm).glob("*.meta.json"):
            m = json.loads(meta.read_text()); stem = meta.name[:-10]
            mod = next(x for x in MODS if stem.startswith(x))
            for inv in m.get("invocations", []):
                st = S / step / arm / "streams" / (Path(inv["room"]).name + ".jsonl")
                if st.exists():
                    last = [l for l in st.read_text(errors="ignore").splitlines() if '"type":"result"' in l]
                    if last:
                        cost[(arm, mod)] += json.loads(last[-1]).get("total_cost_usd") or 0
            for g in (S / step / arm).glob(f"{stem}.grade-*.json"):
                d = json.loads(g.read_text())
                cost[(arm, mod)] += sum((u.get("costUSD") or 0) for u in (d.get("model_usage") or {}).values())
    tot = sum(cost.values())
    per_mod = {mod: cost[("alone", mod)] + cost[("tuesday", mod)] for mod in MODS}
    print(step, f"total ${tot:.2f}", {k: f"${v:.1f} ({100*v/tot:.0f}%)" for k, v in per_mod.items()})
