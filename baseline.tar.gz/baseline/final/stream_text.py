import json, sys
path=sys.argv[1]; width=int(sys.argv[2]) if len(sys.argv)>2 else 800
for line in open(path):
    try: e=json.loads(line)
    except: continue
    if e.get('type')=='assistant':
        for b in e['message'].get('content',[]):
            t=b.get('type')
            if t=='text': print('TEXT:', b['text'][:width].replace('\n',' / '))
            elif t=='thinking': print('THINK:', (b.get('thinking') or '')[:width].replace('\n',' / '), '[sig]' if b.get('signature') else '')
            elif t=='tool_use':
                i=b.get('input',{})
                s=i.get('query') or i.get('file_path') or i.get('command') or i.get('skill') or ''
                print('TOOL:', b['name'], str(s)[:200].replace('\n',' '))
