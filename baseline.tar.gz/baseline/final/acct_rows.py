import json, sys, glob, re
sys.path.insert(0,'/home/user/tuesday/evals')
import output_checks as oc
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model, fix, target = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
for arm in ('alone','tuesday'):
    print('=====',model,arm)
    for f in sorted(glob.glob(f'{S}/{model}/{arm}/mock-interview-{fix}.*md')):
        txt=open(f).read()
        t=oc.parse_accounting(txt)
        row=t['rows'].get(target)
        tl=oc.parse_tally(txt)
        print('--',f.split('/')[-1], '| row:', (row or {}).get('raw','<none>')[:400].replace('\n',' '))
        print('      tally:', [l[:200] for l in tl.get('lines',[])][:2])
