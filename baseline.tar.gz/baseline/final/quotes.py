import json, sys, glob, collections, re
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model=sys.argv[1]; verbose=len(sys.argv)>2
for arm in ('alone','tuesday'):
    per=collections.Counter(); runs=0; reasons=collections.Counter(); targets=collections.Counter()
    for f in sorted(glob.glob(f'{S}/{model}/{arm}/mock-interview-*.checks.json')):
        c=json.load(open(f))
        fails=[x for x in c.get('checks',[]) if x['check']=='quotes' and x['verdict']=='FAIL']
        if fails:
            runs+=1
            fx=c['stem'].split('.')[0]+('.'+c['mode'] if c.get('mode') and 'canned' in c['stem'] or 'denied.' in c['stem'] else '')
            per[c['stem'].rsplit('.run',1)[0]]+=1
            for x in fails:
                targets[x['target']]+=1
                if verbose: print(arm, c['stem'], x['target'], x['why'][:400])
    print(model, arm, 'runs failing quotes:', runs, dict(per), 'by section:', dict(targets))
