# Tuesday quality check (m18) and routing rounds 1–3: verified summary of misses, gaps and failures

I treated this as read-only. I only ran the scripts already in `…/m18/final/` and inline Python, and I wrote no files.

**Source keys.** `SP` = /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad
- [sS] SP/m18/sonnet-score.txt · [hS] SP/m18/haiku-score.txt · [oS] SP/m18/opus-score.txt · [SUM] SP/m18/summary-all.txt · [BAR] SP/m18/bar.md, bar-haiku.md, bar-opus.md
- [DIAG] SP/m18/diag-result.json · [RECHK] SP/m18/sonnet-recheck/ · [RUNS] SP/m18/{sonnet,haiku,opus}/{alone,tuesday}/ (.meta, .checks, .md) · [GR] the *.grade-1/2.json files in [RUNS] · [METER] SP/m18/meter/
- [F:x] SP/m18/final/x (an existing script) · [m15J]/[m16J] SP/m15, SP/m16 /<model>/e{0,1}.json · [m16S] SP/m16/score-literal.txt · [m16V] SP/m16/verify-result.json · [m17S] SP/m17/score-final.txt · [m17V] SP/m17/verify-result.json · [m17J] SP/m17/<model>/*.json · [VERD] SP/frontdoor/verdict.md
- [README] /home/user/tuesday/README.md · [EVR] /home/user/tuesday/evals/README.md · [RF] /home/user/tuesday/evals/run_fixtures.py · [EJ-mi] /home/user/tuesday/skills/mock-interview/evals/evals.json · [EJ-ju] /home/user/tuesday/skills/job-underwriter/evals/evals.json
- "inline" means computed in this pass from the files named next to it.

---

## 1. Number check: corrections

Almost every number in the compilation reproduces from its source. These do not:

1. **D3, "the gain has shrunk round by round": wrong.** Tuesday's own Haiku single-module rate fell 93% → 83% → 75%/73%. The gain over modules alone did not shrink: it was +40, +21, then +28/+26 points, because the baseline was 53%, 62% and 47% [README L128–130][m16S][m17S].
2. **B, "only Sonnet quotes (p=0.027) … under 0.05".** p=0.027 is for the old check (20 vs 9). With the fixed check it is 17 vs 8 [RECHK], p≈0.063 (inline Fisher). So only Haiku gates_form (p≈0.044) is under 0.05 on its own [F:rates.py]. Pooled quotes across models, 65 vs 47 of 150, is p≈0.042.
3. **E7 Bash counts.** 43/17 (Opus), 22/8 (Sonnet) and 4/5 (Haiku) are right. They count runs with a refused Bash command on the skill's own folder (inline over [RUNS] meta). They include `cd`, `mkdir` and `ls`, not only reads. The cited `denials_all.py` gives all Bash refusals instead: Opus 52 vs 29, Sonnet 29 vs 20, Haiku 9 vs 14 [F:denials_all.py].
4. **E8, Sonnet grading "$24–28 per step".** The figures are right ($27.37, $23.92, $27.66), but they come from the grade files' `model_usage` [GR]. `cost_by_module.py` does not split grader cost out.
5. **B, no_overclaim "p≈0.09 on verdicts".** That is correct for verdicts, but each run has two graders, so its verdicts are not independent. Counted by runs it is 13 vs 17 of 50, p≈0.51 [F:clause_rates.py, inline]. Any p-value computed on verdicts is overstated the same way.
6. **B and H7, the closing block on resume-tailor.** Most failing verdicts come from a grader misreading, not the response (see §2). The "73 vs 88 of 150 runs, p≈0.1" figure has that artefact mixed in.
7. **E3, the spanning rule "misses about 4 times in 10".** This holds when every run's outcome varies (0.38–0.43 for true rates 0.5–0.9, inline binomial). For Opus's actual case mix, where cases 9 and 21 always fire, the miss chance is 20–30% per layout and 15–20% in both layouts [m17V].
8. **C7 and H6 flip the order.** "35 vs 29", "20 vs 19" and "31 vs 33" are alone first, while the rest of the report is Tuesday first. Tuesday vs alone, Haiku: evidence_form 29 vs 35, tally 19 vs 20, quotes 33 vs 31 [hS].
9. **D2 is missing context.** Haiku with the modules alone scored 1/5 on case 3 in round 1 and 1/5 in round 2, then 3/5 in round 3 [m15J][m16J][m17J]. Part of the gap is the baseline rising, as with Opus case 10. Tuesday scored 3/5, then 2/5 (one of those a hidden-module reach), then 0/10.
10. **Plan, step 0.4, "re-score under steps 1–3".** Step 3 (the save policy) changes how runs behave, so it cannot be applied by re-scoring saved runs.
11. **Plan total, "about 30 points".** The parts sum to 31–34: quality 22, routing 3–5, add-ons under 2, review 4–5 [METER]. Also, 42% is the reading taken right after the Opus step. The diagnosis and this compilation ran afterwards without a meter reading.
12. **E1.** The count-rule fix is already a backlog item [README L141]. Cite it as existing, not as new.

**The Opus diagnosis: all claims check, with two small corrections.**
- "Every one is a single call for target 3": Sonnet's one Tuesday run sent a search plus a fetch [F:mi_research.py sonnet 8].
- Fixture 8 is indeed −18 of mock-interview's −19 graded verdicts. Only about −11 of those come from the search itself: accounting −8 and sources list −3. The other −7 are no_overclaim (−2 net) and closing (−5) [F:exp_delta.py opus mock-interview 1].

## 2. Opus diagnosis, folded in

- **A5 rewritten.** On Opus mock-interview, zero_calls 6 vs 2 and 6 of the 9 accept failures are one behaviour, counted twice. On fixture 8 the user pasted everything, and the run sent one news search for target 3 anyway.
  - The labels are honest (`yes` or `unavailable`); the defect is the call.
  - It happens in both arms on every model. Fixture-8 runs that searched, alone vs Tuesday: Opus 2 vs 6, Sonnet 0 vs 1, Haiku 1 vs 0 of 10. Pooled that is 3/30 vs 7/30 (p≈0.30), and Opus alone is p≈0.17 [F:zc_all.py][oS][sS][hS].
  - Only one cell is new: denied mode, where Opus through Tuesday searched in 3 of 5 runs and every other model and arm in 0 of 5. Those 3 runs are exactly the reported drop, 10/10 → 4/10 [oS][GR].
  - The other 3 accept failures are fixture 5: interview process written `skipped` where `unavailable` is required, 3 runs vs 2 alone. The same mislabel appears on Sonnet alone and Haiku alone [F:mi_research.py].
  - The instructions are byte-identical between the arms, apart from a generated Contents list, the Paths note and one renamed file (inline diff of room copies). The shared text pulls two ways: "one recent-strategy sweep, sources under ~6 months" against §4's "skipped if the inputs already fix every output". The model's thinking is redacted, so why a run searched cannot be observed.
- **New harness flaw: the grader prompt.** It puts "What the harness observed" right after `{response}` [RF L177–183]. Graders read that block as text after the watch-out line and fail the closing expectation.
  - Closing FAIL verdicts that cite it, alone vs Tuesday: Opus 16/18 vs 20/29, Sonnet 21/25 vs 23/31, Haiku 33/40 vs 23/34 [F:closing.py].
  - Graders also use the block to call the bundled C25–C27 citations unsourced (resume-tailor fixture 4, expectation 4) [F:exp_grades.py].
- **The resume-tailor drop is explained.** Opus fell 532 → 514 verdicts (−3.1 points), mostly on the closing expectation: 32/50 → 21/50, net −11 [F:exp_delta.py][F:clause_rates.py].
- **The sibling module goes the other way.** job-underwriter zero_calls on Opus is alone 4 vs Tuesday 2; Sonnet is 9 vs 9; Haiku is 9 alone vs 10 Tuesday [oS][sS][hS]. So research discipline is not looser through Tuesday in general.

## 3. What both reports miss

1. **job-underwriter's research skip fails in both arms, and the ledger says it is closed.** On fixture 5, zero_calls fails in 9/10 Sonnet runs in each arm, 9/10 (alone) and 10/10 (Tuesday) on Haiku, and 4/10 and 2/10 on Opus [F:zc_all.py].
   - The ledger says "Research paths — closed… the skip held in 3, 3, 4 and 5 runs of five" on these four rooms [README L123].
   - On Sonnet and Haiku, m18 has the skip holding in only 0–1 of 5 on job-underwriter's two rooms. This is not caused by Tuesday and is not recorded anywhere.
   - Harm: low (a needless company search). Fix: docs now, text later.
2. **The arms differ in more than Tuesday.** "Alone" runs the module as a project skill inside the room's `.claude/skills/`, with no plugin folder and no Read rule, in a room named after the module (`rooms/mock-interview-8-denied-…`). Tuesday runs as a plugin outside the room, with a Read allow rule, in a room named `case-N` [RUNS meta flags and rooms].
   - The refused saves (C5), the Bash refusals (E7) and the nudge asymmetry (C6: all 115 alone runs fired unprompted on every model) may come from this layout difference, not from Tuesday's text. This is inference.
   - Fix: harness.
3. **Fixture 8 is dated in the past.** Its prompt says "copied this morning (12 October 2026)" and "three rounds on 21 October", but the runs were on 8 November. All 20 Opus fixture-8 runs noted that the interviews had passed [EJ-mi id 8][RUNS opus .md]. That makes the June brief look about 5 months old, next to the checklist's "under ~6 months".
   - Fix: harness (relative dates or a pinned clock). Free.
4. **resume-tailor's real closing failures rise through Tuesday on all three models.** Counting only FAIL verdicts that do not cite the harness block, alone vs Tuesday: Opus 2 vs 9, Sonnet 4 vs 8, Haiku 7 vs 11. Pooled that is 13 vs 28 of 150 (p≈0.02, overstated because it counts verdicts) [F:closing2.py].
   - The failures are thin upgrade menus, and a line placed between the questions and the watch-out. Harm: low.
5. **Drops hidden by flat module rates** (4 or more of 10 verdicts) [F:moves.py]:
   - Haiku mock-interview fell on 5 expectations and rose on 3. The falls: bridge guidance on fixtures 1 and 2 (8→4 each), no_overclaim on fixture 4 (6→2), fixture 3 #5 (5→1), fixture 4 #4 (8→4).
   - Sonnet mock-interview: loop_source on fixture 3 (10→6) and prep triage on fixture 5 (5→1).
   - Opus job-underwriter: map_vocab on fixture 2 (10→6).
6. **Haiku's truthfulness is low in both arms.** Grader pass rates, alone/Tuesday: no_overclaim 32%/31%, proposed_language 48%/32%, ledger_counts 18%/28% [F:clause_rates.py]. The README's Haiku entry gives only module-level rates.
7. **More checks the rate view cannot flag.** These record only failures, so summary.py reads them as 100% vs 100%: unavailable_has_refusal, ledger_markup, format, tally_remark and evidence_map (inline over [RUNS] checks).
   - unavailable_has_refusal: Haiku job-underwriter 2 vs 0, mock-interview 2 vs 3 [hS]. These are rows saying a search was refused when none was sent.
8. **Untested.** No fixture uses live web research: every research room is canned or denied [EJ-mi][EJ-ju]. There is also no second-turn (iterate) fixture.
9. **Minor.** Haiku mock-interview packs delivered only in chat: 3 alone vs 0 Tuesday [F:denials_all.py].

---

## 4. Final summary for the owner

Wording: "Tuesday" means a module run through Tuesday, and "alone" means the module installed by itself. Counts are Tuesday vs alone unless marked. "p" is how often luck alone would give a gap this big.

### A. Quality bar misses, as the bar scored them
Bars 1 and 3 were met on every module and model. Bar 2 (no check failing in 3 or more extra runs) missed 15 times [sS][hS][oS].
- **A1 · Sonnet mock-interview quotes: 20 vs 9 runs, and 17 vs 8 with the fixed check (p≈0.06)** [sS][RECHK]. Harm: almost none, since every quote is real words, re-cut or loosely sourced. One run per arm let a company line read as the candidate's. One Tuesday pack was never delivered after its save was refused: it graded 4/32, against 28/32 alone [DIAG]. Fix: check and fixture (free); a text change is optional (G5).
- **A2 · Haiku job-underwriter, six checks.** Mostly because Tuesday runs wrote the fit ledger more often (28 vs 20 of 40) [F:checks_by_fm.py]. One real gap: gates_form 15/27 vs 5/20 (p≈0.044) [F:rates.py]. Harm: low. The one exception is yes_names_page (6/14 vs 3/12): a `yes` row that names no page, so the user cannot check it. Fix: bar (rates).
- **A3 · Haiku mock-interview watch-out line: 6 vs 1 of 50 (p≈0.11)** [hS][F:rates.py]. One run gave no warning at all; the other five were form. Fix: one line of text (G4), or accept it.
- **A4 · Opus job-underwriter.**
  - gates_form 15 vs 12 and gates_line 13 vs 10 are one defect counted twice: 13 of the 15 Tuesday gates_form runs also fail gates_line [F:rates.py].
  - snapshot_band 3 vs 0 and tally 4 vs 1 [oS].
  - Harm: none to low. Fix: bar.
- **A5 · Opus mock-interview.** zero_calls 6 vs 2 and accept 9 vs 4 [oS] are one behaviour: a single news search on fixture 8, honestly labelled, seen in both arms on every model (pooled 7/30 vs 3/30, p≈0.30). The 3 denied-mode Tuesday runs that searched are exactly the reported drop, 10/10 → 4/10 [GR]. Fixture 5 has "skipped" for "unavailable" in 3 vs 2 runs. Quotes are 15 vs 8 (p≈0.15). Harm: low. Fix: text (G6) plus fixture dates (E14).
- resume-tailor had no misses, but only its watch-out line is checked (202 passes, no other check) [RUNS checks].

### B. Rate view and graded rates
- **Graded pass rates, alone → Tuesday** [sS][hS][oS]:
  - job-underwriter: Sonnet 91.1→92.4, Haiku 63.7→74.2, Opus 91.4→92.0.
  - mock-interview: Sonnet 92.4→89.4, Haiku 77.6→78.1, Opus 90.4→88.6.
  - resume-tailor: Sonnet 88.8→88.0, Haiku 83.7→84.6, Opus 90.2→87.1.
- **The rate view flags only four checks** [SUM]: Sonnet quotes 40% vs 18%; Haiku yes_names_page 43% vs 25%; Opus accept 30% vs 13%; Opus zero_calls 60% vs 20%. It cannot see Haiku gates_form (56% vs 25%) or other checks that record only failures [F:rates.py].
- **Truthfulness, not gated.**
  - Opus no_overclaim: 83%→72% of verdicts; by runs 13→17 of 50 (p≈0.5).
  - Haiku proposed_language: 48%→32%; by runs 14→21 of 25 (p≈0.06) [F:clause_rates.py].
  - Harm: yes, if real. Fix: bar (gate a truthfulness family).
- **The closing block on resume-tailor is mostly a grader artefact** (E12) [F:closing.py].

### C. Patterns across models
- **C1 · Quotes fail more often through Tuesday on all three models.** Pooled 65 vs 47 of 150 (p≈0.04). The growth is re-cut quotes, 43 vs 30 (p≈0.11) [F:quote_kinds_cut.py]. Harm: none.
- **C2 · gates_form is higher through Tuesday on all three:** Sonnet 9 vs 7, Haiku 15 vs 5, Opus 15 vs 12. Only Haiku's gap is beyond chance [sS][hS][oS].
- **C3 · Graded scores.** job-underwriter rises on all three models. The other two modules fall 0.8–3.1 points on Sonnet and Opus [SUM].
- **C4 · Expectations that moved.**
  - The closing expectation falls on Sonnet and Opus; on Opus resume-tailor fixture 5 it went 5/10 → 0/10.
  - Truthfulness falls on Haiku (proposed_language) and on Opus: job-underwriter fixture 1 proposed_language 9→4, and resume-tailor fixture 4's keyword premise 7→3, where graders mostly call bundled citations unsourced.
  - Haiku mock-interview hides 5 falls behind a flat module rate [F:moves.py].
- **C5 · Saves.** mock-interview's save was refused in 50/50 and 49/50 Tuesday runs on Sonnet and Opus, against 1/50 and 10/50 alone. Packs delivered only in chat: 17 vs 1 and 9 vs 0 [F:denials_all.py]. This may be the install layout (E13), not Tuesday.
- **C6 · Haiku nudges.** 8 of 115 Haiku Tuesday runs routed only after a re-prompt naming Tuesday, and this is not disclosed. No alone run needed one [RUNS meta].
- **C7 · Failures that are the same in both arms.**
  - The ledger-sentence rule fails on every model (see H1).
  - Haiku mock-interview quotes fail in about 2 runs of 3 [hS].
  - job-underwriter's research skip fails in 9 of 10 Sonnet and Haiku runs (H9).
- **C8 · Real resume-tailor closing failures are up on all three models:** 28 vs 13 of 150 verdicts [F:closing2.py]. Harm: low. Fix: watch it in the next round.

### D. Routing open items
- **D1 · Opus case 10:** Tuesday 0 of 20 runs; modules alone 0/5, 0/5, then 2/5. That caused the round-3 spanning miss, 12→10 of 15 (p≈0.095 for the case pooled over both layouts; p=0.68 on the spanning totals) [m17V].
  - Harm: low to moderate. The user gets sensible advice but no evidence check.
  - Fixes: leave it open, or a pre-registered harness run of 50–80 runs per arm (power 0.67–0.96) [m17V], or description text.
- **D2 · Haiku case 3:** Tuesday 0/10 against alone 3/5 (p≈0.02 uncorrected, one of about 63 case comparisons). Alone's own history was 1/5 and 1/5 [m15J][m16J][m17J]. Harm: moderate, because these runs reached no skill. Fix: more runs (harness).
- **D3 · Haiku without a command:** the right module on 75% (plugin) and 73% (personal) of single-module requests, against 100% on Sonnet and Opus [m17S]. Tuesday's rate fell 93→83→75/73% over the rounds, with gains of +40, +21 and +28/+26 points [README]. Harm: about 1 Haiku request in 4 gets a generic answer. Fix: docs.
- **D4 · Refused tool calls:** 44–58 of 105 runs per Tuesday arm had at least one. They changed no routing label [m17S][m17V].
- **D5 · Unread runs:** modules-alone routing runs stop at the first fire, so 37, 70 and 72 of them per model are unreadable. Opus's 2 case-10 fires cannot be inspected [m17V].

### E. Bar and harness flaws
- **E1 · Count rule.** It would flag some check about 88% of the time with no real change [DIAG]. It double-counts (A4, A5) and penalises the arm that writes more of the required output. It is already in the backlog [README L141]. Fix: bar, free.
- **E2 · Rate view.** It is blind to checks that record only failures. Fix: free.
- **E3 · Spanning rule.** No margin; 20–40% chance of a miss by luck [m17V]. Fix: bar, free.
- **E4 · Hidden-module gate.** Low power; round 3's zero reaches cap the rate at about 2.8% per arm and 0.5% over all 630 runs (inline). Fix: docs.
- **E5 · Pooled expectations dilute the few that protect users.** Opus no_overclaim fell 11 points inside a module change of 1.7 [F:clause_rates.py][oS]. Fix: free re-score.
- **E6 · Quotes check stricter than needed.** Fixture 5's candidate_text leaves out the candidate's own sentence, which causes 4 of 15 Opus Tuesday failures and 3 of 8 alone. Accepting that sentence and re-cut quotes would leave Opus 1 vs 1 [F:quote_kinds_cut.py]. Fix: harness, free.
- **E7 · Headless refusals of saves and Bash** [inline over RUNS]. Fix: harness.
- **E8 · Graders pinned to Sonnet.** They agree on 93.9–95.6% of verdicts and cannot see quote form [GR][DIAG]. An Opus spot-check would be about 2–3 points per model (estimate).
- **E9 · No check on resume-tailor's "Traces to" quotes.** Fix: free.
- **E10 · Not disclosed or stale.** The nudges, [EVR] line 504, and the backlog's "Opus running" [README L140].
- **E11 · Minor.** 959 verdicts instead of 960; 63.7 vs 63.8 from rounding; CLI 2.1.318 vs 2.1.319 [oS][hS][SUM][RUNS meta].
- **E12 (new) · Grader prompt.** It puts the harness block after the response, and graders misread it [RF L177–183][F:closing.py]. Fix: harness, plus a regrade.
- **E13 (new) · The arms differ in more than Tuesday:** install layout, read rule and room name [RUNS meta]. Fix: harness.
- **E14 (new) · Fixture 8 is dated in the past** [EJ-mi id 8]. Fix: harness, free.
- **E15 (new) · Two limits on reading causes.** p-values on verdicts are overstated, and thinking is redacted, so why a run did something cannot be seen. Fix: bar and docs.

### F. Untested surfaces
F1 claude.ai web and desktop [VERD rows 18, 19, 32] · F2 the plugin on claude.ai, and whether hidden modules stay hidden there [VERD row 21] · F3 marketplace install, private-repo authentication and the real-path Read rule [RUNS meta] · F4 permission prompts in a normal session [RUNS meta init] · F5 quality through the personal install [BAR] · F6 cloud sessions and synced duplicates [README] · F7 live drills, second turns and live web research [EJ-mi][EJ-ju].

### G. Text backlog (each needs re-measuring)
- **G1** The old name "front door" in three places Claude reads [README L136].
- **G2** No Tuesday row in the §6 routing table.
- **G3** Tuesday's description holds 1,020 of 1,024 characters (inline).
- **G4** Haiku's watch-out line (A3).
- **G5** Provenance quoting (A1, C1).
- **G6 (new)** One line in research-checklist.md: a brief the user supplied that is under ~6 months old answers target 3, and reads `skipped` (A5).

### H. Pre-existing open issues
- **H1 · More than one sentence after the ledger.** Fails on every model, alone/Tuesday: Haiku 75%/74%, Opus 83%/80%, Sonnet 50%/30% of runs [F:checks_by_fm.py]. Harm: low. Fix: text.
- **H2 · Count statements against the evidence table.** Grader pass rates: Sonnet 84→94%, Haiku 18→28%, Opus 71→64% [F:clause_rates.py]. Harm: yes. Out of scope under the standing rule.
- **H3 · Invented history.** no_overclaim: Sonnet 89/88%, Haiku 32/31%, Opus 83/72% [F:clause_rates.py]. Harm: yes. Fix: update the docs.
- **H4 · resume-tailor altered quotes.** 33%, last measured on 2d0efb8 [README L131]. Fix: add the check (free), then a text change if it is still frequent.
- **H5 · Haiku's research tally line:** off-form in 19 of 30 Tuesday runs and 20 of 30 alone [hS]. Harm: low.
- **H6 · Haiku reworded quotes in mock-interview:** quotes fail in 33 vs 31 runs [hS]. Harm: moderate.
- **H7 · Closing block.** Mostly the grader artefact (E12). Real failures are low and form-only (C8).
- **H8 · Opus case 10** (D1).
- **H9 (new) · job-underwriter's research skip.** It fails in 9–10 of 10 runs on Sonnet and Haiku in both arms, while the ledger calls it closed [F:zc_all.py][README L123]. Harm: low. Fix: docs now, text later.

---

### One ordered fix plan
**Step 0: no measured runs, except the regrade.**
1. **Bar.** Rate over the runs where each check applied; one defect per run per check family; a false-alarm rate fixed in advance; a spanning margin; a small truthfulness family gated by runs; p-values on runs; report nudges and the hidden-module upper bound (E1–E5, E15). Free.
2. **Harness.**
   - Fence the harness block in the grader prompt (E12).
   - Use the same install layout and neutral room names in both arms (E13), and the same save policy; log Bash reads (E7).
   - Fix fixture 8's dates (E14) and fixture 5's candidate_text (E6).
   - Report re-cut quotes as their own kind; add resume-tailor's "Traces to" check (E9).
   - Free. The changes take effect from the next round.
3. **Re-score and regrade the saved m18 runs.**
   - Re-score under the new checks and bar: free.
   - Regrade all of m18 under the fixed grader prompt: about $79 of Sonnet grading, so about 3–4 points [GR][METER].
   - The resume-tailor regrade alone is about $9, under 1 point.
   - The regraded m18 becomes the control for step 2.
4. **Docs.** Record the Opus step, the nudges, the ledger sentence on all models, Haiku's truthfulness rates, H9, refreshed count and invented-history rates, [EVR] line 504, and the untested surfaces (F).
5. **Owner decisions.**
   - Is a re-cut quote a defect?
   - Is one recency search a defect?
   - Trim the description now?
   - Include resume-tailor's shape change, based on step 3's number?
   - Keep counts and invented history out of the round, as the standing rule says?

**Step 1: one text commit.** G1, G2, G5, G6 and H1; optionally G4; H4 if step 3 shows it is still frequent; G3 only if you want room now.

**Step 2: one measured round, with its bar fixed beforehand.**
- **What runs:** quality on 3 models in both arms; routing on the plugin layout only; plus Opus case 10 and Haiku case 3, at 25 or more runs per arm, interleaved.
- **Cost:**
  - Quality: about 22 points (m18's actual 9 + 2 + 11) [METER].
  - Routing: about 3–5 points. This is an estimate from round 2's 3.8M output tokens; routing rounds have no meter reading [m16V].
  - Add-ons: under 2 points.
  - Review and diagnosis: about 4–5 points.
  - Total: about 31–34 points. Doubling mock-interview runs for 80–90% power [DIAG] adds about 14 points, since mock-interview is 63–64% of each step's cost [F:cost_by_module.py]. That makes about 45–48 in all.
- **When:** the meter read 42% after Opus, with unmetered work since, and it resets on Thursday 2026-11-12 at 06:00 UTC [METER]. Start after the reset in the order Haiku, Sonnet, Opus, and stop if the meter passes about 80%. Round 3 hit the weekly limit partway through [README L130].