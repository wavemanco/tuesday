"""Per model, arm, module: runs with a refused Write/Edit, refused Read, other refusals; and chat-only delivery."""
import json
from collections import Counter, defaultdict
from pathlib import Path
S = Path(__file__).resolve().parent.parent
MODS = ("job-underwriter", "mock-interview", "resume-tailor")
for step in ("sonnet", "haiku", "opus"):
    for arm in ("alone", "tuesday"):
        out = defaultdict(Counter)
        for meta in sorted((S / step / arm).glob("*.meta.json")):
            stem = meta.name[:-10]; m = json.loads(meta.read_text())
            mod = next(x for x in MODS if stem.startswith(x))
            den = []
            for inv in m.get("invocations", []):
                den += (inv.get("result") or {}).get("permission_denials") or []
            names = Counter(d["tool_name"] for d in den)
            o = out[mod]; o["runs"] += 1
            if names.get("Write", 0) + names.get("Edit", 0): o["write_refused"] += 1
            if names.get("Read", 0): o["read_refused"] += 1
            if names.get("Bash", 0): o["bash_refused"] += 1
            others = set(names) - {"Write", "Edit", "Read", "Bash"}
            if others: o["other_refused:" + ",".join(sorted(others))] += 1
            if not m.get("artifacts"): o["no_file"] += 1
        for mod in MODS:
            print(step, arm, mod, dict(out[mod]))
