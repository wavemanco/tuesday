"""Graded pass rate, per model and arm, of the expectations that carry one clause (the open issues' own expectations).

Usage: python3 -I clause_rates.py <repo>. Expectation n of fixture id is matched to the clause by its raw text in
<repo>/skills/<module>/evals/evals.json. Counts grader verdicts and runs failing on either grader.
"""
import json, sys
from collections import defaultdict
from pathlib import Path
S = Path(__file__).resolve().parent.parent
REPO = Path(sys.argv[1])
WANT = dict(a.split("=") for a in sys.argv[2:]) if len(sys.argv) > 2 else {"job-underwriter": "ledger_counts", "mock-interview": "no_overclaim", "resume-tailor": "row_quote"}
for mod, clause in WANT.items():
    spec = json.loads((REPO / "skills" / mod / "evals" / "evals.json").read_text())
    targets = {(e["id"], i) for e in spec["evals"] for i, x in enumerate(e["expectations"], 1)
               if "{{" + clause + "}}" in (x if isinstance(x, str) else json.dumps(x))}
    for step in ("sonnet", "haiku", "opus"):
        line = []
        for arm in ("alone", "tuesday"):
            v = [0, 0]; runs = [0, 0]; per = defaultdict(lambda: [0, 0])
            for meta in sorted((S / step / arm).glob(f"{mod}-*.meta.json")):
                stem = meta.name[:-10]; m = json.loads(meta.read_text())
                if (m.get("harness") or {}).get("status") != "ok":
                    continue
                fid = m.get("id"); failed_any = False; seen = False
                for g in (S / step / arm).glob(f"{stem}.grade-*.json"):
                    d = json.loads(g.read_text())
                    if d.get("harness_invalid") or d.get("error"):
                        continue
                    for x in d.get("verdicts", []):
                        if (fid, x["n"]) in targets:
                            seen = True; ok = x["verdict"] == "PASS"
                            v[0] += ok; v[1] += 1; per[fid][0] += ok; per[fid][1] += 1
                            failed_any |= not ok
                if seen:
                    runs[1] += 1; runs[0] += failed_any
            line.append(f"{arm}: verdicts pass {v[0]}/{v[1]} ({100*v[0]/max(v[1],1):.0f}%), runs failing on a grader "
                        f"{runs[0]}/{runs[1]}; per fixture " + " ".join(f"{k}:{a}/{b}" for k, (a, b) in sorted(per.items())))
        print(f"{mod} {{{{{clause}}}}} [{step}]\n   " + "\n   ".join(line))
