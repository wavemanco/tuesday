import json, sys, glob, collections, re
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model, skill = sys.argv[1], sys.argv[2]
ev=json.load(open(f'/home/user/tuesday/skills/{skill}/evals/evals.json'))
idx={e['id']:[i+1 for i,x in enumerate(e['expectations']) if '{{closing}}' in x] for e in ev['evals']}
for a in ('alone','tuesday'):
    c=collections.Counter()
    for g in sorted(glob.glob(f'{S}/{model}/{a}/{skill}-*.grade-*.json')):
        d=json.load(open(g))
        for v in d['verdicts']:
            if v['n'] in idx[d['id']]:
                c['n']+=1
                if v['verdict']=='FAIL':
                    c['fail']+=1
                    if re.search(r'harness', v['why'], re.I): c['fail_cites_harness_block']+=1
    print(model, skill, a, dict(c))
