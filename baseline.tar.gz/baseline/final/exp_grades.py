import json, sys, glob
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model, skill, fix, n = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
pat = sys.argv[5] if len(sys.argv)>5 else ''
for arm in ('alone','tuesday'):
    print('=====',model,arm)
    for f in sorted(glob.glob(f'{S}/{model}/{arm}/{skill}-{fix}.{pat}*grade-[12].json')):
        d=json.load(open(f))
        for v in d['verdicts']:
            if v['n']==n:
                print(f.split('/')[-1], v['verdict'], v['why'][:300])
