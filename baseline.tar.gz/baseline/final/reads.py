import json, sys, glob, os, re
S='/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18'
model, skill, fix = sys.argv[1], sys.argv[2], sys.argv[3]
for arm in ('alone','tuesday'):
    print('=====',model,arm)
    for f in sorted(glob.glob(f'{S}/{model}/{arm}/{skill}-{fix}.*meta.json')):
        m=json.load(open(f)); inv=m['invocations'][m.get('graded_invocation',0)]
        seq=[]
        for t in inv.get('tool_calls') or []:
            n=t['name']; i=t.get('input',{})
            if n=='Read':
                p=i.get('file_path','')
                seq.append('R:'+os.path.basename(p)+(f"[{i.get('offset')}+{i.get('limit')}]" if i.get('offset') or i.get('limit') else ''))
            elif n=='Bash':
                c=i.get('command','')
                files=re.findall(r'[\w./-]+\.md',c)
                seq.append('B:'+(','.join(os.path.basename(x) for x in files) if files else c[:50].replace('\n',' ')))
            elif n in ('WebSearch','mcp__web__search','WebFetch','mcp__web__fetch'):
                seq.append(f"{n}:{(i.get('query') or i.get('url'))!r}")
            elif n=='Skill':
                seq.append('Skill('+str(i.get('args',''))[:0]+')')
            else:
                seq.append(n)
        print('--',m['stem'],'|',' '.join(seq))
