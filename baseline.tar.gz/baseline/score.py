"""Score the quality check through Tuesday against m18/bar.md, for one model step.

Usage: score.py [step folder, default m18/sonnet]. Reads <step>/alone and <step>/tuesday.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

S = Path(__file__).resolve().parent
STEP = Path(sys.argv[1]) if len(sys.argv) > 1 else S / "sonnet"
MODULES = ("job-underwriter", "mock-interview", "resume-tailor")
ARMS = ("alone", "tuesday")


def module_of(stem: str) -> str:
    return next(m for m in MODULES if stem.startswith(m))


def load(arm: str) -> dict:
    """Per run (stem): harness status, checks, both graders' verdicts, and its cost."""
    folder = STEP / arm
    runs = {}
    for meta in sorted(folder.glob("*.meta.json")):
        stem = meta.name[: -len(".meta.json")]
        m = json.loads(meta.read_text())
        runs[stem] = {"module": module_of(stem), "mode": m.get("mode"), "id": m.get("id"),
                      "ok": (m.get("harness") or {}).get("status") == "ok",
                      "why": (m.get("harness") or {}).get("reasons"), "checks": [], "verdicts": [],
                      "out_tokens": 0, "cost": 0.0}
    for stem, r in runs.items():
        c = folder / f"{stem}.checks.json"
        if c.exists():
            r["checks"] = json.loads(c.read_text()).get("checks", [])
        for g in sorted(folder.glob(f"{stem}.grade-*.json")):
            d = json.loads(g.read_text())
            if d.get("harness_invalid") or d.get("error"):
                continue
            r["verdicts"] += [(v["n"], v["verdict"] == "PASS") for v in d.get("verdicts", [])]
            for u in (d.get("model_usage") or {}).values():
                r["out_tokens"] += u.get("outputTokens") or 0
                r["cost"] += u.get("costUSD") or 0.0
    for stream in (folder / "streams").glob("*.jsonl") if (folder / "streams").exists() else []:
        last = None
        for line in stream.read_text(errors="ignore").splitlines():
            if '"type":"result"' in line or '"type": "result"' in line:
                last = line
        if last:
            e = json.loads(last)
            # Stream files are named for the room, not the run; spread cost by matching run order.
            runs.setdefault("_streams", {"out_tokens": 0, "cost": 0.0})
            runs["_streams"]["out_tokens"] += (e.get("usage") or {}).get("output_tokens") or 0
            runs["_streams"]["cost"] += e.get("total_cost_usd") or 0.0
    return runs


arms = {a: load(a) for a in ARMS}
print(f"step: {STEP}")
ok_all = True
cost = {}
for a in ARMS:
    runs = {k: v for k, v in arms[a].items() if not k.startswith("_")}
    bad = [k for k, v in runs.items() if not v["ok"]]
    share = len(bad) / len(runs) if runs else 1.0
    s = arms[a].get("_streams", {"out_tokens": 0, "cost": 0.0})
    g_tok = sum(v["out_tokens"] for v in runs.values()); g_cost = sum(v["cost"] for v in runs.values())
    cost[a] = (s["out_tokens"], g_tok, s["cost"] + g_cost)
    flag = share <= 0.10
    ok_all &= flag
    print(f"BAR 3 {a:8} runs {len(runs)}, set aside {len(bad)} ({100*share:.0f}%) -> {'ok' if flag else 'UNSCORED'}"
          + (f"  {[(k, runs[k]['why']) for k in bad[:4]]}" if bad else ""))

print()
for mod in MODULES:
    rate = {}
    for a in ARMS:
        vs = [p for v in arms[a].values() if isinstance(v, dict) and v.get("module") == mod and v["ok"] for _, p in v["verdicts"]]
        rate[a] = (sum(vs), len(vs))
    ra = rate["alone"][0] / rate["alone"][1] if rate["alone"][1] else float("nan")
    rt = rate["tuesday"][0] / rate["tuesday"][1] if rate["tuesday"][1] else float("nan")
    nodata = not (rate["alone"][1] and rate["tuesday"][1])
    ok = (not nodata) and rt >= ra - 0.05
    ok_all &= ok
    print(f"BAR 1 {mod:16} graded pass ALONE {rate['alone'][0]}/{rate['alone'][1]} ({100*ra:.1f}%)  "
          f"TUESDAY {rate['tuesday'][0]}/{rate['tuesday'][1]} ({100*rt:.1f}%) -> {'ok' if ok else ('NO DATA' if nodata else 'MISS (more than 5 points below)')}")
    fails = {a: defaultdict(int) for a in ARMS}
    for a in ARMS:
        for v in arms[a].values():
            if isinstance(v, dict) and v.get("module") == mod and v["ok"]:
                for c in {c["check"] for c in v["checks"] if c.get("verdict") == "FAIL"}:
                    fails[a][c] += 1
    worse = {c: (fails["tuesday"][c], fails["alone"][c]) for c in set(fails["tuesday"]) | set(fails["alone"])
             if fails["tuesday"][c] - fails["alone"][c] >= 3}
    ok2 = not worse
    ok_all &= ok2
    print(f"BAR 2 {mod:16} checks failing in 3+ more runs through Tuesday: {worse or 'none'} -> {'ok' if ok2 else 'MISS'}"
          f"   (all check failures, tuesday/alone: { {c: (fails['tuesday'][c], fails['alone'][c]) for c in sorted(set(fails['tuesday']) | set(fails['alone']))} })")

print("\nREPORTED: expectations whose pass count drops by 3+ runs in 5 (6+ of 10 grader verdicts)")
counts = {a: defaultdict(lambda: [0, 0]) for a in ARMS}
for a in ARMS:
    for v in arms[a].values():
        if isinstance(v, dict) and v.get("ok"):
            for n, p in v["verdicts"]:
                key = (v["module"], v["id"], v["mode"], n)
                counts[a][key][0] += p
                counts[a][key][1] += 1
drops = []
for key in sorted(set(counts["alone"]) | set(counts["tuesday"]), key=str):
    pa, na = counts["alone"][key]; pt, nt = counts["tuesday"][key]
    if na and nt and (pa / na - pt / nt) * 10 >= 6 - 1e-9:
        drops.append((key, f"alone {pa}/{na}", f"tuesday {pt}/{nt}"))
for d in drops:
    print("  ", d)
print("  none" if not drops else f"  {len(drops)} expectation(s)")
rises = [(k, counts["alone"][k], counts["tuesday"][k]) for k in set(counts["alone"]) & set(counts["tuesday"])
         if counts["alone"][k][1] and counts["tuesday"][k][1]
         and (counts["tuesday"][k][0] / counts["tuesday"][k][1] - counts["alone"][k][0] / counts["alone"][k][1]) * 10 >= 6 - 1e-9]
print(f"  (for symmetry: {len(rises)} expectation(s) rise by 3+ runs in 5 through Tuesday)")

print("\nREPORTED cost (from streams and grade files):")
for a in ARMS:
    st, gt, c = cost[a]
    print(f"  {a:8} run output tokens {st:,}, grader output tokens {gt:,}, cost ${c:,.2f}")
print("\nVERDICT:", "every bar item met: Sonnet passes" if ok_all else "an item missed or unscored: report to the owner")
