import json, re
from pathlib import Path
from collections import Counter, defaultdict
S = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18/sonnet")
rows = {(r["arm"], r["stem"]): r for r in json.load(open(S.parent/"diag/quotes_rows.json"))}
per = {}
for arm in ("alone", "tuesday"):
    for meta in sorted((S/arm).glob("mock-interview-*.meta.json")):
        stem = meta.name[:-10]; m = json.loads(meta.read_text())
        room = Path(m["invocations"][0]["room"]).name
        reads = []; skills = []; partial = []
        for line in (S/arm/"streams"/f"{room}.jsonl").read_text(errors="ignore").splitlines():
            try: e = json.loads(line)
            except: continue
            if e.get("type") != "assistant": continue
            for c in e.get("message", {}).get("content", []):
                if c.get("type") == "tool_use":
                    if c["name"] == "Read":
                        p = c["input"].get("file_path", "")
                        reads.append(Path(p).name)
                        if c["input"].get("limit") or c["input"].get("offset"): partial.append(Path(p).name)
                    elif c["name"] == "Skill":
                        skills.append(c["input"].get("skill"))
                    elif c["name"] == "Bash" and re.search(r"\bcat\b|head|sed -n", c["input"].get("command","")) and "references" in c["input"].get("command",""):
                        reads.append("BASH:" + c["input"]["command"][:60])
        per[(arm, stem)] = dict(reads=reads, skills=skills, partial=partial, fail=rows[(arm, stem)]["fail"])
json.dump({f"{a}|{s}": v for (a, s), v in per.items()}, open(S.parent/"diag/reads.json", "w"), indent=1)
for arm in ("alone", "tuesday"):
    c = Counter(); cf = Counter(); n = 0; nf = 0
    for (a, s), v in per.items():
        if a != arm: continue
        n += 1; nf += v["fail"]
        for r in set(v["reads"]):
            c[r] += 1; cf[r] += v["fail"]
    print(f"== {arm}: runs {n}, quotes-fail {nf}")
    for r, k in c.most_common(40):
        print(f"   {r:40} read in {k:2}/{n} runs; quotes-fail among them {cf[r]}/{k}")
    print("   partial reads:", Counter(p for (a, s), v in per.items() if a == arm for p in v["partial"]))
    print("   skills:", Counter(tuple(v["skills"]) for (a, s), v in per.items() if a == arm))
