import json
from pathlib import Path
from collections import Counter
S = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18/sonnet")
rows = {(r["arm"], r["stem"]): r for r in json.load(open(S.parent/"diag/quotes_rows.json"))}
for arm in ("alone", "tuesday"):
    tools = Counter(); runs_w = []; xt = Counter()
    for meta in sorted((S/arm).glob("mock-interview-*.meta.json")):
        stem = meta.name[:-10]; m = json.loads(meta.read_text())
        den = m["invocations"][0]["result"].get("permission_denials") or []
        names = Counter(d["tool_name"] for d in den)
        tools.update(names)
        wd = names.get("Write", 0) + names.get("Edit", 0)
        bashw = [d for d in den if d["tool_name"] == "Bash"]
        if wd: runs_w.append(stem.replace("mock-interview-", ""))
        art = bool(m.get("artifacts"))
        xt[("write-denied" if wd else "no-write-denial", "file" if art else "chat-only", "FAIL" if rows[(arm, stem)]["fail"] else "pass")] += 1
    print(arm, "denials by tool:", dict(tools)); print("   runs with Write/Edit denied:", len(runs_w), runs_w)
    for k in sorted(xt): print("   ", k, xt[k])
