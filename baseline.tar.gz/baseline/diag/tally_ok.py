import sys, json, glob, re, os, collections
A, S = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(A, 'evals'))
import output_checks as oc
ev = {e['id']: e for e in json.load(open(os.path.join(A, 'skills/mock-interview/evals/evals.json')))['evals']}
for arm in ['alone', 'tuesday']:
    T = collections.Counter(); runs = collections.defaultdict(set)
    for f in sorted(glob.glob(f'{S}/sonnet/{arm}/mock-interview-*.md')):
        stem = os.path.basename(f)[:-3]
        d = json.load(open(f'{S}/sonnet/{arm}/{stem}.checks.json'))
        e = ev[d['id']]; resp = open(f).read()
        own = oc.normalise_quote("\n".join(e['candidate_text']))
        evid = []; prov = []
        for source, body in oc.split_response(resp):
            for t in oc.md_tables(body):
                names = oc.header_names(t)
                vb = next((i for i, h in enumerate(names) if 'verbatim' in h), None)
                if vb is not None:
                    for c in t['rows']:
                        if vb < len(c): evid += [oc.normalise_quote(s).strip(oc.EDGE) for s in oc.quoted_spans(c[vb])]
                if any('provenance' in h for h in names) and any('answer guidance' in h for h in names):
                    pc = next(i for i, h in enumerate(names) if 'provenance' in h)
                    for c in t['rows']:
                        if pc < len(c): prov.append(c[pc])
        snap = "\n".join(evid)
        T['runs'] += 1
        if prov: T['runs_with_banks'] += 1
        T['prov_cells'] += len(prov)
        for cell in prov:
            named = oc.fields_named(cell)
            for span, origin in oc.quoted_spans_with_origin(cell):
                w = oc.normalise_quote(span).strip(oc.EDGE)
                if not w or w == 'none given': continue
                T['spans'] += 1
                frags = [x.strip(oc.EDGE) for x in re.split(r"\.\.\.|…", oc.normalise_quote(span)) if x.strip(oc.EDGE)]
                if all(oc.contains_words(x, own) for x in frags):
                    T['cand_spans'] += 1
                    if not all(oc.contains_words(x, snap) for x in frags):
                        T['cand_not_in_snapshot'] += 1; runs['A'].add(stem)
                else:
                    T['noncand_spans'] += 1; runs['noncand_any'].add(stem)
                    if named and any(w in (oc.dossier_items(e['prompt']) or {}).get(fl, set()) for fl in named):
                        T['noncand_dossier_item_ok'] += 1
                    elif oc.other_source(origin):
                        T["noncand_origin_recognised"] += 1; print("   OK", arm, stem, repr(cell.strip()[:160]))
                    else:
                        T['noncand_origin_unrecognised'] += 1; runs['B'].add(stem)
    print(arm, dict(T))
    print('   runs with any non-candidate quote in Provenance:', len(runs['noncand_any']), '| runs with unrecognised-origin non-candidate quote:', len(runs['B']), '| runs with candidate quote not in snapshot:', len(runs['A']))
