import sys, json, glob, re, os
A = sys.argv[1]; S = sys.argv[2]
sys.path.insert(0, os.path.join(A, 'evals'))
import output_checks as oc
ev = {e['id']: e for e in json.load(open(os.path.join(A, 'skills/mock-interview/evals/evals.json')))['evals']}
for arm in ['alone', 'tuesday']:
    for f in sorted(glob.glob(f'{S}/sonnet/{arm}/mock-interview-*.checks.json')):
        d = json.load(open(f))
        fails = [c for c in d['checks'] if c['check'] == 'quotes' and c['verdict'] != 'PASS']
        if not fails: continue
        stem = d['stem']
        resp = open(f.replace('.checks.json', '.md')).read()
        e = ev[d['id']]
        own = oc.normalise_quote("\n".join(e['candidate_text']))
        print(f"\n######## {arm} {stem}")
        failrows = set()
        for c in fails:
            m = re.match(r'(.*?) row (\S+):', c['why'])
            if m: failrows.add((m.group(1), m.group(2)))
            else: print('  FORMAT:', c['why'])
        for source, body in oc.split_response(resp):
            for t in oc.md_tables(body):
                names = oc.header_names(t)
                vb = next((i for i, h in enumerate(names) if 'verbatim' in h), None)
                if vb is not None:
                    print(f"  [snapshot in {source}] header={names}")
                    for cells in t['rows']:
                        if vb < len(cells):
                            print(f"    {cells[0].strip()[:8]:8} EVID: {cells[vb].strip()[:300]}")
                if any('provenance' in h for h in names) and any('answer guidance' in h for h in names):
                    pc = next(i for i, h in enumerate(names) if 'provenance' in h)
                    qc = next((i for i, h in enumerate(names) if 'question' in h), 1)
                    for cells in t['rows']:
                        rid = cells[0].replace('`','').replace('*','').strip()[:20]
                        if (source, rid) in failrows:
                            print(f"  >> {source} row {rid}")
                            print(f"     Q: {cells[qc].strip()[:200] if qc < len(cells) else ''}")
                            print(f"     PROV: {cells[pc].strip()}")
                            for span, origin in oc.quoted_spans_with_origin(cells[pc]):
                                w = oc.normalise_quote(span).strip(oc.EDGE)
                                print(f"       span={span!r} origin={origin!r} in_own={oc.contains_words(w, own)} in_prompt={w in oc.normalise_quote(e['prompt'])} fields_named={oc.fields_named(cells[pc])}")
