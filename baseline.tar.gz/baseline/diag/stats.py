import json
from math import comb
from collections import defaultdict, Counter
rows = json.load(open("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18/diag/quotes_rows.json"))
print("runs per arm:", Counter(r["arm"] for r in rows), "harness:", Counter((r["arm"], r["ok"]) for r in rows))
f = Counter(r["arm"] for r in rows if r["fail"]); print("fails:", f)
def fisher(a, b, c, d):
    # table [[a,b],[c,d]], rows arms; two-sided by summing p <= p_obs
    n1 = a + b; n2 = c + d; k = a + c; N = n1 + n2
    def p(x): return comb(n1, x) * comb(n2, k - x) / comb(N, k)
    po = p(a)
    lo, hi = max(0, k - n2), min(k, n1)
    tot = sum(p(x) for x in range(lo, hi + 1) if p(x) <= po * (1 + 1e-7))
    one = sum(p(x) for x in range(a, hi + 1))
    return tot, one
t2, t1 = fisher(20, 30, 9, 41)
print(f"Fisher two-sided p={t2:.5f}, one-sided (T>A) p={t1:.5f}")
# odds ratio
print("OR", (20*41)/(30*9))
by = defaultdict(lambda: {"alone": [], "tuesday": []})
for r in rows:
    by[r["fm"]][r["arm"]].append((r["stem"].split(".run")[1], r["fail"]))
more = fewer = eq = 0
print(f"{'fixture-mode':14} alone tuesday  diff   alone-fail-runs | tuesday-fail-runs")
for fm in sorted(by, key=lambda s: (int(s.split('.')[0]), s)):
    a = sum(x for _, x in by[fm]["alone"]); t = sum(x for _, x in by[fm]["tuesday"])
    more += t > a; fewer += t < a; eq += t == a
    print(f"{fm:14} {a}/5   {t}/5     {t-a:+d}   {[k for k,x in sorted(by[fm]['alone']) if x]} | {[k for k,x in sorted(by[fm]['tuesday']) if x]}")
print("fixture-modes TUESDAY more/fewer/equal:", more, fewer, eq)
# sign test on non-ties
n = more + fewer
p_sign = sum(comb(n, i) for i in range(0, n+1) if comb(n,i) <= comb(n, more)) / 2**n
print(f"two-sided sign test {more} vs {fewer}: p={p_sign:.4f}")
# Stratified (CMH-like) exact: permutation of arm labels within each fixture-mode, conditional on fails per fm
# Exact distribution of T-fail total under H0 within strata: product of hypergeometric(10,5,k_fm)
import itertools
dists = []
for fm in by:
    k = sum(x for _, x in by[fm]["alone"]) + sum(x for _, x in by[fm]["tuesday"])
    d = {x: comb(5, x) * comb(5, k - x) / comb(10, k) for x in range(max(0, k-5), min(k, 5)+1)}
    dists.append(d)
tot = {0: 1.0}
for d in dists:
    new = defaultdict(float)
    for s, ps in tot.items():
        for x, px in d.items():
            new[s + x] += ps * px
    tot = new
obs = 20
mean = sum(s*p for s,p in tot.items())
p_hi = sum(p for s, p in tot.items() if s >= obs)
p_two = sum(p for s, p in tot.items() if abs(s - mean) >= abs(obs - mean) - 1e-9)
p_two_pp = sum(p for s,p in tot.items() if p <= tot[obs]*(1+1e-7))
print(f"stratified exact (within fixture-mode permutation): E[T fails]={mean:.2f}, P(T>=20)={p_hi:.5f}, two-sided(|dev|)={p_two:.5f}, two-sided(prob<=obs)={p_two_pp:.5f}")
