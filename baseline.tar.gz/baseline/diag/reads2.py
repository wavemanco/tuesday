"""Per mock-interview run, every access of a skill file in order, with coverage, from the raw streams.

Coverage of a file: full = every line reached the model (a Read whose range is the whole file, a
`cat` whose output was returned whole, or a persisted `cat` output later Read whole); part = some
lines (Read with offset/limit, sed/head, a persisted-output 2KB preview only, grep); none.
"""
import json, os, re, sys, glob, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import reads
M18 = "/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18"
KNOWN = ["SKILL.md", "mock-interview.md", "output-template.md", "question-rubric.md", "personas.md",
         "reframing-audit.md", "evidence-conventions.md", "output-discipline.md", "interaction-grammar.md",
         "research-checklist.md", "dossier-handoff.md", "dossier-schema.md", "citations.md", "rationale.md",
         "mock-interview-rationale.md", "job-underwriter.md", "resume-tailor.md"]
# lines in output-template.md / question-rubric.md that state the rule check_quotes enforces
RULE = {"output-template.md": [(94, 104), (208, 216)], "question-rubric.md": [(43, 45), (62, 62)]}
TOTAL = {}

def owner(path):
    m = re.search(r"/skills/([^/]+)/", path or "")
    return re.sub(r"-[0-9a-f]{8}$", "", m.group(1)) if m else "?"

def basenames_in(s):
    return [b for b in re.findall(r"([\w-]+\.md)\b", s) if b in KNOWN]

def bash_ops(cmd):
    """[(op, [files], whole)] for each pipeline segment that touches a known file."""
    ops = []
    for seg in re.split(r"&&|;|\|\|", cmd):
        seg = seg.strip()
        pipe = seg.split("|")
        head = pipe[0].strip()
        piped_trunc = any(re.match(r"\s*(head|tail|sed|grep)", p) for p in pipe[1:])
        files = basenames_in(head)
        if not files: continue
        verb = head.split()[0] if head.split() else ""
        if verb == "cat":
            ops.append(("cat", files, not piped_trunc))
        elif verb in ("sed", "head", "tail", "grep", "awk"):
            ops.append((verb, files, False))
        elif verb in ("wc", "ls", "echo", "for", "R=", "cd"):
            if verb == "for" or "cat " in seg:
                ops.append(("loop-cat", files, not piped_trunc))
            else:
                ops.append(("ls/wc", files, None))
        else:
            ops.append((verb, files, None))
    return ops

def run_accesses(stream):
    seq, cov, pending = [], collections.defaultdict(set), {}   # pending: persisted path -> files
    def mark_full(f):
        cov[f].add("ALL")
    for u in reads.events(stream):
        b, inp, r, tur = u["use"], u["use"]["input"], u["res"], u["tur"]
        name = b["name"]; err = bool(r and r.get("is_error")); text = reads.result_text(r)
        sub = "{sub}" if u["parent"] else ""
        if name == "Skill":
            seq.append(f"Skill({re.sub(r'-[0-9a-f]{8}', '', inp.get('skill',''))}){sub}")
        elif name == "Read":
            fp = inp.get("file_path", "")
            f = (tur or {}).get("file") if isinstance(tur, dict) else None
            if "/tool-results/" in fp:
                files = pending.get(os.path.basename(fp))
                if files is None: continue
                whole = bool(f and f.get("startLine") == 1 and f.get("numLines") == f.get("totalLines"))
                for x in files:
                    if whole: mark_full(x)
                    else: cov[x].add("PART")
                seq.append(f"Read(persisted cat output of {'+'.join(files)}{'' if whole else ' PARTIAL'}){sub}")
                continue
            base = os.path.basename(fp)
            if "/skills/" not in fp and base not in KNOWN: continue
            o = owner(fp)
            if err:
                seq.append(f"Read {o}:{base} ERROR{sub}"); continue
            if f:
                s, n, t = f.get("startLine"), f.get("numLines"), f.get("totalLines")
                TOTAL[base] = t
                if s == 1 and n == t:
                    mark_full(base); tag = ""
                else:
                    cov[base].update(range(s, s + n)); tag = f"[{s}-{s+n-1}/{t}]"
            else:
                tag = "[?]"
            seq.append(f"Read {o}:{base}{tag}{sub}")
        elif name == "Bash":
            cmd = inp.get("command", "")
            if not (basenames_in(cmd) or "/skills/" in cmd): continue
            ops = bash_ops(cmd)
            if err:
                seq.append(f"Bash DENIED({text[:45]!r}): " + ",".join(f"{op}:{'+'.join(fs)}" for op, fs, _ in ops)); continue
            persisted = "persisted-output" in text[:300] or "Output too large" in text[:300]
            m = re.search(r"saved to: (\S+)", text)
            desc = []
            for op, fs, whole in ops:
                if op in ("cat", "loop-cat"):
                    if persisted:
                        for x in fs: cov[x].add("PREVIEW")
                        pending[os.path.basename(m.group(1)) if m else "?"] = fs
                    else:
                        for x in fs:
                            (mark_full(x) if whole else cov[x].add("PART"))
                    desc.append(f"cat {'+'.join(fs)}{' (output persisted: 2KB preview only)' if persisted else ''}")
                elif op in ("sed", "head", "tail", "grep", "awk"):
                    for x in fs: cov[x].add("PART")
                    desc.append(f"{op} {'+'.join(fs)}")
                else:
                    desc.append(f"{op}")
            seq.append("Bash " + "; ".join(desc) + sub)
        elif name in ("Grep", "Glob"):
            s = json.dumps(inp)
            if "/skills/" not in s and not basenames_in(s): continue
            for x in basenames_in(s): cov[x].add("PART")
            seq.append(f"{name} {s[:120]}{sub}")
        elif name in ("Task", "Agent"):
            seq.append(f"{name}(subagent) {json.dumps(inp)[:100]}")
    return seq, cov

def level(f, cov):
    c = cov.get(f)
    if not c: return "none"
    if "ALL" in c: return "full"
    lines = {x for x in c if isinstance(x, int)}
    t = TOTAL.get(f)
    if t and set(range(1, t + 1)) <= lines: return "full"
    if c == {"PREVIEW"}: return "preview"
    return "part"

def rule_level(f, cov):
    c = cov.get(f)
    if not c: return "none"
    if "ALL" in c: return "yes"
    lines = {x for x in c if isinstance(x, int)}
    hits = [all(l in lines for l in range(a, b + 1)) for a, b in RULE[f]]
    return "yes" if all(hits) else ("some" if any(hits) else "no")

if __name__ == "__main__":
    rows = []
    for arm in ("alone", "tuesday"):
        for r in reads.runs(arm):
            seq, cov = [], collections.defaultdict(set)
            for inv in r["invs"]:
                s, c = run_accesses(inv["stream"])
                seq += s
                for k, v in c.items(): cov[k] |= v
            rows.append(dict(arm=arm, stem=r["stem"], rooms=[i["room"] for i in r["invs"]], quotes=r["quotes"],
                             qfail=[c["target"] + ": " + c["why"] for c in r["qfail"]], qinfo=r["qinfo"],
                             seq=seq, cov={f: level(f, cov) for f in KNOWN},
                             rule={f: rule_level(f, cov) for f in RULE}))
    json.dump(rows, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "reads2.json"), "w"), indent=1)
    for row in rows:
        print(f"{row['arm']:7} {row['stem']:28} quotes={row['quotes']:4} room={row['rooms'][0]}"
              f"  OT={row['cov']['output-template.md']} QR={row['cov']['question-rubric.md']}"
              f" playbook={row['cov']['mock-interview.md']} ruleOT={row['rule']['output-template.md']} ruleQR={row['rule']['question-rubric.md']}")
        print("    " + " -> ".join(row["seq"]))
