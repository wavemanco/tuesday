import json
from pathlib import Path
from collections import Counter
P = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad")
sets = {"m12-new": P/"m12/claude-sonnet-5-5/new", "m12-ctl": P/"m12/claude-sonnet-5-5/ctl", "m14-sonnet": P/"m14/sonnet",
        "m18-alone": P/"m18/sonnet/alone", "m18-tuesday": P/"m18/sonnet/tuesday"}
for name, d in sets.items():
    fails = []; n = 0; meta = Counter(); targets = Counter()
    for c in sorted(d.glob("mock-interview-*.checks.json")):
        stem = c.name[:-12]
        ch = json.loads(c.read_text())
        q = [x for x in ch["checks"] if x["check"] == "quotes"]
        m = json.loads((d/f"{stem}.meta.json").read_text())
        n += 1
        meta[f"harness={m.get('harness',{}).get('status')}"] += 1
        for i in m.get("invocations", []):
            meta[f"ver={i.get('init',{}).get('claude_code_version')}"] += 1
            meta[f"model={i.get('init',{}).get('model')}"] += 1
            meta[f"via={i.get('via')}"] += 1
            meta[f"competing={len(i.get('init',{}).get('competing_skills') or [])}"] += 1
        meta[f"artifacts={len(m.get('artifacts') or [])}"] += 1
        meta[f"unchecked_quotes={'quotes' in ch.get('unchecked', [])}"] += 1
        f = [x for x in q if x["verdict"] == "FAIL"]
        if f:
            fails.append(stem.replace("mock-interview-", ""))
            for x in f: targets[x["target"]] += 1
    if name.startswith("m18"):
        print(f"{name}: {len(fails)}/{n} runs fail quotes")
    else:
        print(f"{name}: {len(fails)}/{n} runs fail quotes: {fails}  targets {dict(targets)}")
        print("    ", dict(meta))
        for s in fails:
            ch = json.loads((d/f"mock-interview-{s}.checks.json").read_text())
            for x in ch["checks"]:
                if x["check"] == "quotes" and x["verdict"] == "FAIL": print("      ", s, x["why"][:200])
