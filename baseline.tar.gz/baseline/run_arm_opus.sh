#!/bin/bash
# m18 Opus step (bar-opus.md): one arm, all fixtures and modes of all three modules, 5 runs each.
ARM="$1"; VIA="$2"
D=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/m18
cd "$D/arm-haiku" || exit 1
python3 evals/run_fixtures.py --skill job-underwriter --skill mock-interview --skill resume-tailor \
  --runs 5 --retry-runs 0 --model claude-opus-5-5 --grader-model claude-sonnet-5-5 --workers 3 \
  --via "$VIA" --out "$D/opus/$ARM" > "$D/opus/$ARM.log" 2>&1
echo "$(date -u +%H:%M) $ARM exit $?" >> "$D/opus/status"
