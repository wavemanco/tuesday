Web search was denied, so I'm assessing from your paste alone. Here is the full first pass.

## Decision snapshot

**Yes, apply. R1, R2, R3, R4 and R5 are `direct` fits, so you read as a fit for the role. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R7a (Partner with PMs on roadmap decisions) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 is the must-have to firm up. R9 has a credible bridge with its limit named.

**Opportunity ledger.** The role reads as concretely defined, with named stakeholders and decisions (RR4). The employer is unverified because research did not run (RR1), and compensation is not in the posting as pasted (RR2). The scope folds several specialisms into one title (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) compensation clears your floor, see RR2 (you haven't given me a floor); (3) your ownership of shared metric definitions is confirmed, see R6; (4) the healthcare bridge is framed as adjacent privacy work, never as HIPAA experience, see R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header as you pasted it; not independently checked |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor post with light people-leadership (two juniors) | `[inferred]` from the mentoring line against the absence of any reporting-line or headcount language |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not established: the role-family sweep did not run, so I have no band to set the title and scope against | `[grounded]` search calls refused, see Evidence status |
| Unknowns | Compensation; reporting line; who owns the metrics layer today; the experimentation platform and warehouse; data-engineering support; how clinicians are involved | `[grounded]` JD silence on each |
| Contradictions | None within the pasted JD; the careers page was not checked | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit subscription company, which clears the stated minimum. Self-reported with nothing inspectable yet, so medium. | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. "Expert" is the JD's word, so carry your claim as daily use. | `[grounded]` your background | Offer: a sanitized query or model that shows depth would raise this to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, you designed and ran the program, and one pricing test sits behind an 11% retention lift. A base of about 2M subscribers is the scale you worked at. The JD does not say whether "at scale" means traffic or test cadence. | `[grounded]` your background; `[inferred]` ambiguity of "at scale" from the JD's silence | Offer: a sanitized write-up of the pricing test would raise this to high |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. You did not say they were self-serve, so I carry "governed" and not "self-serve". | `[grounded]` your background | Offer: a dashboard screenshot or LookML excerpt, sanitized |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. | `[grounded]` your background | Offer: a sanitized memo would raise this to high |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Building Looker with governed dashboards suggests you set shared metric definitions, but you did not say you defined or maintained them. | `[inferred]` from "governed" in your background | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present monthly to the VP Product and your pricing test produced an outcome. You did not say what roadmap decisions your analysis changed. | `[grounded]` your background | Offer: a sanitized note of the roadmap decision the pricing test drove |
| R7b | Partner with clinicians | important | unclear | none | discovery | Your background mentions no partnership with domain experts. Nothing contradicts it either. | `[grounded]` background silence | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background is silent on mentoring. | `[grounded]` background silence | See G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. You have no healthcare data work. Consumer-privacy and health-data compliance are separate regimes. | `[grounded]` your background; `[generic]` that the two regimes are distinct | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | discovery | A Looker build with governed dashboards, but nothing on who defined the metrics or kept them current | A must-have at `adjacent`; confirming it would likely settle the condition tied to R6 | Writing the canonical definition of retention or active subscriber; a LookML model or metrics spec others built on; resolving a metric dispute between teams | A metric dictionary, a LookML excerpt, or a definitions page (sanitized) | `[grounded]` background silence on definitions; `[inferred]` that this affects the conditions |
| G2 | Mentoring (R8, important) | discovery | Nothing in the background | The JD names it as part of the role | Onboarding a new analyst; reviewing others' SQL or test designs; coaching an intern | A short description of the arrangement; no document needed | `[grounded]` background silence |
| G3 | Clinician partnership (R7b, important) | discovery | Nothing in the background | The JD pairs clinicians with PMs as the stakeholders for roadmap decisions | Working with any domain expert whose judgement shaped what you measured or tested | A test brief or analysis note showing their input (sanitized) | `[grounded]` background silence; `[generic]` that domain-expert partnership recurs in roles of this kind |
| G4 | Healthcare and HIPAA (R9, preferred) | transferability | Adjacent: consumer PII handling and a consent-state model. Limit: nothing on protected health information, de-identification rules or vendor agreements for health data. Strengthener: be able to describe the consent-state model concretely and say plainly where health data differs | A preferred row, so a minor risk, not a blocker | Data-access controls, retention rules or consent logic you designed | The consent-model design doc (sanitized) | `[grounded]` background; `[generic]` that these regimes differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The posting may be stale or aggregated, or simply unchecked here. The details are unconfirmed, not contradicted. | `[generic]` pattern for employers of this kind, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not in the posting as pasted | unknown | — | No figure appears in the text you gave me | It may have been omitted from the paste, or withheld. I have no market band to compare against. | `[grounded]` JD silence as pasted | What salary range is budgeted for this post? | unresolved |
| RR3 | Several specialisms folded into one title | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker, partner with product managers and clinicians … and mentor two junior analysts" | Delivering all of it may depend on data-engineering support the posting does not mention. | `[inferred]` from the JD's list against its silence on support | Which of these is the priority in the first six months, and what data-engineering support does the analytics team have? | unresolved |
| RR4 | Named stakeholders and decisions | positive_signal | — | "turn analysis into roadmap decisions" | Analysis appears to be tied to decisions, with defined partners | `[grounded]` JD | What roadmap decision did analytics most recently change? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program (30+ A/B tests a year, the pricing test behind the 11% retention lift) and the Looker build (40+ governed dashboards) | See R3, R4 | `[grounded]` R3, R4 rows | pending your approval |
| P2 | Describe the consent-state model as privacy work on consumer data, and say you have not worked with healthcare data | See R9, G4 | `[grounded]` R9 row | pending your approval |
| P3 | Hold any "defined" or "owned" wording about metrics until G1 is answered | See R6 | `[grounded]` R6 row | pending your approval |
| P4 | Confirm the posting is live on the company's own careers page before applying | See RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Ask RR2, RR3 and RR4's questions verbatim in the first screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row above is proposed and nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches sent: "Harborlight Health care navigation app Series C" and "Harborlight Health careers Senior Product Analyst". Both were refused for lack of permission and returned nothing. A result would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | Search sent: "senior product analyst digital health salary range 2026". It was refused and returned nothing. A result would have moved the market calibration row and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Dossier offer and upgrade menu

I can save all of this as `tuesday-dossier.md` to carry into later steps; just say so.

- Search permission (the three refused calls) → RR1 and RR2 resolve or sharpen, role reality gets a market calibration row, and the decision may move from `conditional_go` to `go`.
- A sanitized pricing-test write-up → R3 to `high`, and R7a gets its roadmap example.
- A sanitized metrics memo → R5 to `high`.
- A LookML excerpt or metric dictionary → R4 to `high`, and R6 resolves.
- Your pay floor, location and schedule limits → the hard-gates line checks against them instead of reading "unknown".
- The hiring manager's name → role reality's scope read, and which story the plan leads with for that reader.

G1 — On the Looker build, did you write and maintain the shared metric definitions themselves (how "retention" or "active subscriber" is calculated), and who else relied on them?

G2 — Have you mentored or formally guided other analysts, such as new hires, interns or people whose work you reviewed? What did that involve?

G3 — Have you worked closely with any domain experts whose judgement shaped what you measured or tested? How did their input change an analysis or experiment?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.