Dev, I've built your resume changes as a ledger, so you can approve each line separately. Nothing is applied yet, and I'll only produce the tailored resume from the rows you approve.

I ran this with resume-tailor. Your material is a prose summary, so I treated it as your own account, and every quote below comes from your message. I dropped the leading "I" in resume voice and changed no other wording except where a row shows it.

## What the edits can and can't do

The edits move your dimensional modelling, dbt and data-quality work to the top, and they claim nothing new. The must-haves of 3+ years of data engineering, production Python and Airflow-style orchestration are not covered by your current material. I won't write around them, and the coverage map and named absences below show exactly where they stand. Whether the role is worth applying to with those gaps is job-underwriter's question, not this ledger's.

## The edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." *(moved to the second bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Line 1: "Fixed our nightly dbt job when it breaks." Line 2: "Added tests to our nightly dbt job." *(third and fourth bullets)* | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis — pandas, some scripting to pull vendor APIs on a cron." *(fifth bullet)* | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to the last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail"; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |

Notes on specific rows:
- **E2** keeps "with our then-DE". Dropping that phrase would make you the sole designer.
- **E3** keeps "when it breaks". It is a fixing role, not ownership of the job.
- **E4** keeps "some" and "for analysis". They are the honest size of that work.
- **E6** is three sentences, each one of yours, kept separate. Your title stays Senior Data Analyst.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your 5 years are as an analyst. Nearest work is E1–E3, which sit beside data engineering but aren't it. See the named absences. | `[grounded]` your resume |
| R2 | Production Python | must-have | `not_evidenced` | The cron API scripts (E4) are adjacent. Your resume doesn't say they run unattended or that others depend on them. See C1. | `[grounded]` your resume |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | The nightly dbt job (E3) is adjacent, but you've fixed it rather than described scheduling or dependency management. See C2. | `[grounded]` your resume |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E2, E6, with the co-design with the DE kept in | `[grounded]` your resume |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1, E6 | `[grounded]` your resume |
| R6 | Data quality | important | `surfaced_by_edit` | E3, line 2: tests added to the nightly job | `[grounded]` your resume |
| R7 | SLAs | important | `not_evidenced` | Nothing in your material mentions SLAs. See the named absences. | `[grounded]` your resume |
| R8 | Spark | important | `not_evidenced` | Never used. See the named absences. | `[grounded]` your resume |
| R9 | Streaming and Kafka | preferred | `not_evidenced` | Never used. See the named absences. | `[grounded]` your resume |

## Gap handling

### Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python is "for analysis", plus "some scripting to pull vendor APIs on a cron". It doesn't say whether that scripting is production code that others rely on. | A must-have a reader can't confirm from one pass is likely to be read as missing. | A vendor-API script that downstream models or dashboards depend on; retries, alerting or failure handling you added; code in a shared repo someone else reviewed | A repo link or script, the cron entry, an incident or alert you fixed | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Airflow or equivalent orchestration | must-have | You've "fixed our nightly dbt job when it breaks", but the resume doesn't say what schedules or triggers it. | Orchestration is the JD's first-named tool area, and a scheduler you used would be the closest equivalent. | Running the nightly dbt job on dbt Cloud, a CI scheduler or an orchestrator someone else owned; defining job order or dependencies; debugging a failed upstream run | The job config, a screenshot or export of the schedule, a runbook | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | 3+ years data engineering | must-have | Nothing in your account states ingestion or load work beyond the cron API pulls. | This is the requirement most likely to decide the application. Any pipeline you built or owned end to end would be the evidence. | Loading the vendor-API data into Redshift yourself; building or changing a load, backfill or ingestion job; being on call for a data feed | The pipeline code, a design doc, a ticket or PR history | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

### Named absences

| # | Requirement | The gap, plainly | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | 3+ years data engineering | Your 5 years are analytics. Without a recall answer you have no data engineering role to claim, and I won't relabel the work as one. | Either evidence from C3 of pipeline work you owned, or a scoped target such as analytics engineer or a hybrid analytics/data role. Time spent in a data engineering role can't be closed by wording. | `[grounded]` your resume; `[generic]` roles that state a years-of-experience must-have are often screened against it literally |
| A2 | SLAs | Tests exist (E3); an SLA is a committed freshness or uptime target, and nothing you've said mentions one. | Define a freshness target for the orders mart and monitor it, or ask which dbt jobs have an agreed delivery time. Only a real one can then be claimed. | `[grounded]` your resume |
| A3 | Spark | Never used. | A small Spark project on real data (for example reprocessing a vendor API extract) would give you something to show. It's an important requirement and may be worth closing only if the rest of the application holds. | `[grounded]` your resume |
| A4 | Streaming and Kafka | Never touched. | A small project that produces and consumes a Kafka topic. This is a "plus" in the JD, so it's the lowest-cost gap to leave open. | `[grounded]` your resume |

## Not written, and why

- **"3+ years of data engineering experience", or a Data Engineer title.** The JD invites it; your title and years are analyst.
- **"Built and owned batch pipelines".** Fixing the nightly dbt job and cron-pulling vendor APIs aren't ownership of a pipeline.
- **"Orchestrated pipelines" or "Airflow-equivalent experience".** You've never described scheduling or dependency work, and the JD's word "orchestration" isn't yours.
- **"Production Python pipelines".** Your sentence says Python "for analysis" plus "some scripting".
- **"Owned data quality and SLAs".** You added tests; you named no SLA.
- **"Led" or "architected" the orders mart.** You designed the star schema "with our then-DE", so a sole-designer reading would change which side of the table you sat on.
- **"Familiar with Spark, Kafka or streaming".** You've never used them.

## Parse-safety check

Your resume came as prose, not a file, so I couldn't check layout. That covers multi-column layout, tables and text boxes, images and icons, content in headers or footers, non-standard headings and file type. Send the file (a `.docx` or text-layer PDF is the safe pair) and I'll check what survives extraction.

## Upgrade menu

- **Your resume as a file:** unlocks the parse-safety checks above.
- **A repo link or script for the vendor-API pulls:** could move R2 toward evidence and give the cron work something inspectable.
- **The nightly dbt job config or schedule:** shows what actually triggers it, which decides whether R3 can be touched at all.
- **The dbt project or orders mart lineage graph:** the inspectable proof for R4–R6.
- **An earlier resume version:** may hold detail the current one dropped.
- **Offer, not built:** I could draft a short "gaps and plan" note for your interviews, showing which gaps are closable and how. It would need your approval and is separate from this ledger.

## Questions

C1 — Do the vendor-API scripts run unattended, and does anything downstream depend on them? If so, what breaks or alerts when they fail?

C2 — What schedules or triggers the nightly dbt job (dbt Cloud, cron, an orchestrator), and did you configure that, or only fix it when it broke?

C3 — Have you built or changed any load or ingestion job, such as getting the vendor-API data into Redshift, that you owned end to end?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.