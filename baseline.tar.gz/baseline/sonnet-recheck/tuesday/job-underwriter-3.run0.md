**Is this worth pursuing? No: R1 and R2, both hard gates, fail. Status: `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin five days a week), R2 ($70–85k base against your $150k floor)
- `must_have` — direct: R3, R4, R5
- `important` — adjacent: R9 (Team of one, executing across functions); unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops)

R1 and R2 fail whatever R3, R4 and R5 show, so your match on paper doesn't rescue the role.

**Opportunity ledger.** The role conflicts with your terms (RR1, RR2) and carries the pattern behind your "something feels off": bundled functions under one title (RR4), a team of one with no stated authority or budget (RR5), always-on expectations (RR6) and undefined success metrics (RR7). RR9 is a positive signal, but it is the company's own claim and is unverified.

- **Hard gates:** failed: R1 (On-site in Austin five days a week), R2 ($70–85k base against your $150k floor).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the base would have to reach at least $150k (R2) and the role would have to be remote from Portland (R1). The posting says "no exceptions" on location and states the pay band.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD; the company's own claim, not independently checked |
| Mandate | Own all revenue growth: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Location and schedule | On-site Austin, 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; equity size and terms not stated | `[grounded]` JD |
| Success outcomes | None stated; "success metrics will evolve as we learn". No first-90-day or first-year outcomes | `[grounded]` JD |
| Scope read | Seven functions with no team reads as several roles bundled under a Head-level title | `[inferred]` from the JD's function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so there is no band to set the pay against | — |
| Unknowns | Equity terms, budget, hiring plan, revenue, whether the customer model is B2B or B2C (your background is B2C subscription) | — |
| Contradictions | A "Head of" title with a team of one, reporting to the CEO and also to the board. The careers page wasn't checked | `[inferred]` from the JD's own wording |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" (your constraint: remote only, based in Portland) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit, which is yours and specific. The fit fails because the JD rules out remote work | `[grounded]` JD quote and your stated constraint | Only you revising the constraint, or the employer changing terms, resolves it |
| R2 | $70–85k base (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The fit fails because the top of the posted band is $65k under it | `[grounded]` JD figure and your stated constraint | Only changed terms resolve it |
| R3 | 8+ years of growth leadership | must_have | direct | medium | discovery | You state 9 years in growth, as growth lead and then Head of Growth. A background typed into chat is self-report. Your years in leadership roles aren't separated from total years, and a literal screen could read that against you | `[grounded]` your stated background; `[generic]` that years-based requirements are often read literally | State your years in lead roles if you proceed |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid at both companies and controlled the budget behind $8M to $40M ARR growth. Nothing inspectable yet, so expect a probe | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state ownership of lifecycle and depth in Braze, SQL and GA4. Confirmed in prose only | `[grounded]` your stated background | none |
| R6 | SEO and content | important | unclear | low | discovery | Your stated background names paid, lifecycle and experimentation, and is silent on SEO and content | `[grounded]` background silent | See G1 |
| R7 | Brand, PR, partnerships | important | unclear | low | discovery | Your stated background is silent on all three | `[grounded]` background silent | See G1 |
| R8 | Sales ops | important | unclear | low | discovery | Your stated background is silent; the posting doesn't define what sales ops means here | `[grounded]` background and JD silent | See G1 |
| R9 | Operating as a team of one across the whole mandate | important | adjacent | low | transferability | You led teams of 3–7, which is leadership. Executing seven functions alone is a different job and nothing confirms you've done it | `[grounded]` your stated team sizes; `[generic]` that a solo hire at this scope must execute, not just direct | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand/PR/partnerships, sales ops (R6, R7, R8, important) | discovery | Your background doesn't mention these functions | It wouldn't move the decision while R1 and R2 fail. It matters only if the terms change | An organic or content program you ran; a co-marketing or affiliate deal you signed; lead routing or CRM-to-sales handoff you owned | A traffic dashboard, a partner agreement, a campaign brief | `[grounded]` background silent; `[inferred]` that the decision is fixed by R1 and R2 |
| G2 | Executing the whole mandate alone (R9, important) | transferability | Team leadership, 3–7 people | Same: it matters only if the terms change | A stretch where you personally ran several channels before hiring | A channel plan or a pre-hire performance summary | `[grounded]` your stated team sizes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R2) | red_flag | high | "$70–85k base" | The posted band doesn't reach your $150k floor | `[grounded]` JD figure against your constraint | Is there any flexibility on base above $85k? | unresolved |
| RR2 | On-site mandate against your remote-only constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer has ruled out the arrangement you need | `[grounded]` JD quote against your constraint | Has this role ever been filled remotely, and what makes in-office five days essential? | unresolved |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | A leadership mandate over seven functions may be priced below what it normally commands. The sweep didn't run, so this is unconfirmed | `[generic]` pattern for roles of this kind, not a claim about this employer | What is the basis for the base range at this scope, and how much of the pay is equity? | unresolved |
| RR4 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles are folded into one title | `[inferred]` from the JD's function list against "team of one" | Which of these functions matter in the first six months, and which would you expect to hire for? | unresolved |
| RR5 | Responsibility without authority or resources | risk_signal | medium | "team of one to start … players who don't need a bench" | You could be accountable for all revenue growth with no stated budget, headcount or decision rights | `[inferred]` from the JD's scope language against its silence on resources | What budget and headcount are committed, and when? | unresolved |
| RR6 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Long hours may be the norm. The wording hedges ("when it matters"), so I've kept this at `medium` | `[inferred]` from the JD's wording | In the last quarter, how often did the team work evenings or weekends, and what triggered it? | unresolved |
| RR7 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held to targets that haven't been defined | `[inferred]` from the JD's wording | What would you want to see from this role by day 90 and by month 12? | unresolved |
| RR8 | Employer not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | I couldn't check that the company exists as described or that the posting is live | `[grounded]` no research ran; nothing is established either way | Can you point me to this role on your own careers site, and who would I report to? | unresolved |
| RR9 | Profitable since day one, Series A | positive_signal | — | "profitable since day one" | If true, it points to a funded and financially sound employer | `[grounded]` JD states it; unverified | What are current revenue and runway? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on the role as posted | See R1, R2 | `[grounded]` R1, R2 rows | recommendation, pending your approval |
| A2 | Optional: one short message asking whether base and location have any flex. Treat a "no" as final | See RR1, RR2 | `[inferred]` from "no exceptions" and the gap to your floor, so low odds | pending your approval |
| Q1 | If you proceed anyway, ask RR3–RR7 verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was sent, but permission wasn't granted, so nothing was found. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Same: permission wasn't granted. It would have set the market calibration row and confirmed or cleared RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'm offering a `tuesday-dossier.md` of this assessment, in case you want to keep it or reuse it for the next posting.

## Upgrade menu

- Search permission, or a link to the role on Novaline's own careers page → RR8 closes and role reality's organization row is grounded.
- The same search permission also runs the role-family sweep → role reality's market calibration row is filled, and RR3 is confirmed or cleared.
- Your resume → R3 to R5 are checked against a document, not just your summary.
- Any content, partnership or CRM-handoff artifact → G1's rows can be closed, if the terms ever change.
- The recruiter's or CEO's name → the scope read, and which of your stories to lead with, if you proceed.

No questions this turn: nothing I could ask would move a decision that R1 and R2 fix.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.