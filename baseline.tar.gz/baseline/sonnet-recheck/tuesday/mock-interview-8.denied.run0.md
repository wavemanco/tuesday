Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-denied-f5d3ad69/e194e398-caa8-467e-a6f9-067d169e94c1/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. My first write, into the project folder, was refused, so I saved it to the scratchpad folder instead.

I built it as one mini-pack per round, since you gave me all three. It has 28 questions: 9 for the recruiter, 9 for the Head of Member Services and 10 for the panel. It has the four values mapped for the panel round, a requirement-coverage table, and 8 reverse questions, spread across the three rounds. I ran no web searches, because your pasted JD, values, recruiter email and strategy points already covered everything a search could have changed.

- **Highest-ROI prep:** question 2B1, the contact-centre gap. Your material says you've never worked in a contact centre and shows nothing adjacent, so the pack coaches you to say that plainly and give a learning plan. It doesn't bridge from the branch.
- **Second stated limit:** you've never presented above regional level. 1B2 and 2B3 rehearse that the same way.
- **Answer slots:** where your material is silent (digital teams, Excel, what the spreadsheet measured, whether the complaints were regulated, whether you coached supervisors), the pack leaves a slot for you to fill honestly. It doesn't write the answer for you.
- **Date:** I took your 12 October as today, but my clock says 5 November. If 21 October has already passed, tell me and I'll rework the prep triage.

Say the word and I'll play the Head of Member Services as a Skeptic on 2B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview pack for Dara

Three rounds on 21 October (loop mode, one mini-pack per round):

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Recruiter screen |
| 2 | Head of Member Services | 45 minutes, mostly behavioural | Would be your manager |
| 3 | Panel of two branch managers | 60 minutes, including a 20-minute complaint escalation case | Panel, and the values round: scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. Persona weights rest on the recruiter's own description of the loop, not on an archetype.

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores: VAL (behavioural, values alignment), EXP (work-experience deep-dive), JD (role and JD-driven), CO (company and strategy knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Where guidance rests on something you said, the sentence is quoted in the Provenance column. Where nothing you said carries a story, you get selection criteria that end in an honest branch.
- An answer slot is an instruction for the interview, not a question for now. Each slot has two branches: if you did the thing, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with what your quotes carry.
- Question IDs read round, persona letter, number (1A1, 2B1, 3C2).

## Prep triage (21 October is nine days after your note of 12 October)

1. Days 1 to 2: rehearse 2B1 and its short form 1B1 until the contact-centre answer is boring. This is the highest-ROI prep in the pack.
2. Days 2 to 3: rehearse the two stated limits aloud, F2 and F8 (1B2, 2B3), in the plain words the fit snapshot gives, then the plan you would follow.
3. Days 3 to 5: fill the answer slots on F1, F3, F4, F5, F7 and F9 for yourself, then walk 1A3, 2A3, 2A4 and 2B2 aloud.
4. Days 5 to 7: the panel. Run 3B1 twice as a timed 20-minute case, then pick your stories for the four values (cheat sheet).
5. Day 8 and the day before: 2C1, 2C2 and 3B3 (strategy), and your reverse questions per round.

Everything else is insurance.

## The fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any stage beyond the log was yours, say which, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet your regional manager uses; your material does not show what it measured. Answer slot: the JD names volumes and resolution times, so a probe on what the spreadsheet counted is likely. If it counted either, say what and how, in your own words; if it counted neither, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on supervisors likely. If any of your training or coaching was with supervisors, say who and how, in your own words; if none was, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, which is not a stated absence. Answer slot: the JD names digital teams and self-service journeys. If you have worked with a digital team or on a self-service journey, say what and which part was yours, in your own words; if you have not, say so plainly, say what you would want to learn first, and return to the log you handled in F1 |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length. Lead with the quote in its own terms: six years in retail banking, the last three as a branch supervisor. Expect a probe on what the years held; your material says nothing about the first three of the six, so describe only what you actually did in them |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal; your material does not show whether external rules applied to it. Answer slot: the JD says regulated. If the log was subject to external rules, say which and what that meant for how you handled complaints, in your own words; if it was not, or you do not know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would build that confidence, said as a plan and never as a past. The JD does not define senior leaders; that is a question for the recruiter, not a reason to soften the line |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not which tool. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built |

## Grounding brief (from your summary of the June 2026 strategy brief; the brief itself was not supplied)

| Item | As you gave it | Provenance | Where it appears |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | 1A4, 2C1 |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] | 2C2 |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | none, and why: no JD line touches it; use it only if someone raises it |
| Competitive frame | "the main competitive pressure is app-only banks" | [grounded] | 3B3, 3B1 |

---

# Round 1: the recruiter (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly biography and motivation questions that are still scored | High. A recruiter screen starts from Conversational plus a light Skeptic, and the email gives this round only a length, with no stated focus | A 90-second arc built from your own sentences; treat casual questions about JD topics as scored; never answer "I think you've covered everything" to the reverse slot |
| Skeptic | Quiet checks on the JD's gaps | Mid. Two of your stated limits, F2 and F8, sit on the JD's own lines, so they are easy for a screen to reach | Rehearse the plain acknowledgment and the plan until it is boring |
| Values / Behavioral | One or two casual behavioural questions | Low. The email places values scoring with the panel; a casual question can still arrive, so two are rehearsed | Selection scaffolds with the honest branch |

## Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So, walk me through the journey: how did you get here, and why this role now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped arc of three beats the quotes state: the six years in retail banking with the last three as a branch supervisor; that you handled the branch's formal complaints log; that you built the monthly complaints spreadsheet your regional manager uses. Tell them in your own words and stop. Why this role now: the pack holds nothing from you on this, so say your own reason, in your own words | F6 gives the arc its spine and F1 and F3 its two complaints beats. EXP because it tests whether the biography is told economically and stays inside what you did |
| 1A2 | "What do you know about Ashgrove, and what drew you to the role?" | CO | [grounded] | Use what you hold in writing: the value "Members First, Always — we decide from the member's side of the counter" and the brief's "move 40% of member service to digital channels by 2028". Pick one value that matters to you and say why in your own words; the pack has no reason from you. Do not claim knowledge beyond the pages you have | Rapport interviewers weight homework depth. CO because it scores knowledge of the employer; the facts come from your pasted values and the brief points you gave |
| 1A3 | "The JD asks for experience handling regulated complaints. Tell me about the formal complaints you handled." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1 and F7: tell it as "I handled the branch's formal complaints log" and nothing beyond. Answer slot, F7: if the log was subject to external rules, say which and what that meant for how you handled complaints, in your own words; if it was not, or you do not know, say so plainly. Answer slot, F1: if any stage beyond the log was yours, say which; if none was, or it was not yours, say so and stay with the log | F7 and F1 are the two JD lines this one answer must cover. JD because it scores a stated requirement; the premise is the JD's, so each slot lets it be false |
| 1A4 | "The role works with digital teams on self-service journeys. How do you think a member should be able to raise a complaint without visiting or calling?" | JD | [grounded] | A live opinion, so the guidance makes no claim about your past. Clarify first (what journeys exist today?), then speak from the member's side of the counter, in plain words. Tie it to "move 40% of member service to digital channels by 2028". Answer slot, F5: if you have worked with a digital team or a self-service journey, say what and which part was yours; if not, say so plainly and say what you would want to learn first | F5 is the JD line your material is silent on. JD with CO delivery: it scores the digital requirement and the 40% target in one question |
| 1B1 | "This role covers the contact centre as well as the branches. How would you handle the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" | The short form of 2B1, kept to about 40 seconds: "I've never worked in a contact centre." Then one sentence of plan in your own words. Do not bridge from the branch; your material carries nothing adjacent to calls | F2 is the stated absence, and a screen checks the JD's headline scope first. JD because it scores a stated requirement and its gap |
| 1B2 | "The role asks for confidence presenting to senior leaders. What is your experience there?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom and about what, in your own words; if not, say so plainly. Then a plan for building the confidence, in your own words. Hold the line through one follow-up without adding to it | F8 is the second stated limit and a likely knockout probe. JD because it scores the presenting requirement, delivered as a Skeptic check |
| 1B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose between the two limits you stated and name one plainly, with a plan; do not offer a third gap you have not said. Calibrated candor beats guessing which one the recruiter expects | F2 and F8 are the candidates; naming one early reads as self-aware. JD because it scores honest self-assessment against the listed role |
| 1C1 | "Tell me about a time you put a member ahead of an internal measure." | VAL | [generic] | Selection scaffold: pick a time with a named member or situation, the internal measure that pulled the other way, what you actually did, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from the value "Members First, Always". VAL because it scores behaviour against a published value; generic because no sentence of yours carries a story here |
| 1C2 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [generic] | Selection scaffold: pick a time you found a problem yourself, name what you did to keep hold of it, how you knew it was solved, and who confirmed it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from the value "Own the Fix — whoever finds the problem keeps hold of it until it is solved". VAL; generic because none of your quotes states a problem kept hold of |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Once interviewers are assigned for rounds two and three, could you share who they are, and is there anything I should read ahead of the 20-minute case?" | The email says assignments are open, so this asks for what only the recruiter holds; it shows you are preparing |
| R1.2 | "Is the complaints role part of the digital shift from day one, or does it come later?" | Ties the role to "move 40% of member service to digital channels by 2028" and shows you read the brief |

---

# Round 2: Head of Member Services (45 minutes, would be your manager)

## Persona table, round 2

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario and past-behaviour probes | High. The recruiter calls this round mostly behavioural, which lifts it above the hiring-manager prior | Stories from your own sentences where one carries it; a scaffold with the honest branch where none does; "we" for context, "I" for contribution |
| Skeptic | Persistent probing of F2, F4 and F8 | Mid. A hiring manager derisks gaps, and three of your rows sit at transferability or capability | Hold the plain acknowledgment, concede only what is true, never bluff a competency your manager owns |
| Case / Strategist | A strategy question or a live problem | Low. The hiring-manager prior favours it, but "mostly behavioural" lowers it; two rehearsed because the strategy brief makes them likely to be asked | Clarify, structure, think aloud, challenge one premise respectfully |

## Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the message was unwelcome, name who heard it and what you actually said, and what happened next; choose one where the truth landed and the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for a manager who will own the reporting line. VAL; generic because none of your quotes states such a moment |
| 2A2 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: "I trained new tellers on our escalation script" is the beat; tell it in your own words. Answer slot: if you chose what the training covered or how it was run, say how, in your own words; if the script and format were set for you, or there was no formal session, say so plainly and describe what you did | F4 is the evidence for the coaching requirement and the likeliest place for a manager to dig. EXP because it tests exactly what was yours |
| 2A3 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: one beat, that you handled the branch's formal complaints log. Answer slot: if any stage beyond the log was yours, say which and how, in your own words; if there was no such stage, or it was not yours, say so plainly and describe how you handled the log. Hold through two follow-ups by returning to the log, never by adding to it | F1 is where "end to end" presses hardest. EXP because it scores attribution |
| 2A4 | "Walk me through the monthly complaints spreadsheet you built. What did it show, and how did your regional manager use it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F9: one beat, that you built the monthly complaints spreadsheet your regional manager uses. Answer slot, F3: if it counted volumes or resolution times, say how, in your own words, and name the assumption behind a figure you would defend least; if it counted neither, say so plainly. Answer slot, F9: if it was built in Excel, say what you did in it; if it was another tool, say so | F3 and F9 both hang on this one quote, so it will be probed. EXP because it tests what you built and how you can describe it |
| 2B1 | "You've never worked in a contact centre. How will you manage that side, and earn credibility with people who have?" | JD | [grounded] "Never worked in a contact centre" | The highest-ROI prep in this pack: it is asked in some form by someone, and it is aimed at where your material is thinnest. The limit, named before it is asked for: nothing you gave me shows contact-centre work or anything adjacent to calls, so do not bridge from the branch. Opening: "I've never worked in a contact centre." Follow-up 1, what carries over: say what you did, "I handled the branch's formal complaints log", and say plainly that it is a different setting. Follow-up 2, why hire you: hold, concede it is a real gap, and do not fold or bluff. Follow-up 3, your first month: say, in your own words, who you would learn from and what you would ask first; the pack supplies the shape, not the content | F2 is the stated absence in the JD's headline scope, and your manager owns the function. JD because it scores a stated requirement; Skeptic delivery |
| 2B2 | "Supervisors would be your peers on day one. How would you coach them on escalations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Open with what your material carries: you spent the last three years as a branch supervisor, and "I trained new tellers on our escalation script." Answer slot, F4: if any of your training was with supervisors, say who and how; if none was, say so plainly and stay with the tellers. Then your approach in your own words; the pack supplies no method | F4 and F6 meet here. JD because it scores the coaching requirement, from the peer-turned-coach angle |
| 2B3 | "Where would you need the most support from me in your first 90 days?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name what you stated, plainly: the contact centre and presenting above regional level, in the words of the quotes. Ask for specific help in your own words, such as who to learn from. Do not add a gap you have not stated | F2 and F8 are the honest answers; asking for support signals self-awareness to the person who would give it. JD because it scores the listed role's gaps |
| 2C1 | "Ashgrove wants 40% of member service on digital channels by 2028. What happens to complaints in that world?" | CO | [grounded] | Clarify first: does moving service to digital include complaints, and which journeys? Then structure: the member's route in, the handoff to a person, what gets measured (the JD names volumes and resolution times), the risks. Think aloud, challenge one premise respectfully, and use "self-service journeys" from the JD. No claim about your past | Grounded in "move 40% of member service to digital channels by 2028", and F5's requirement is the JD's. CO with CASE delivery |
| 2C2 | "Eight branches are becoming five hubs over 2027. What would you watch first in the complaints process?" | CO | [grounded] | Clarify what has been decided and when; then structure: members whose branch changes, staff, escalation paths, measures. Link it to "Neighbours, Not Numbers — every branch is part of its town" in your own words. Offer a view and label it as yours | Grounded in "consolidate eight branches into five hubs over 2027"; the pack holds no other facts about it. CO with CASE delivery |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you want complaints reporting to look like six months in?" | Asks your future manager for the outcome, which also tells you how F3 will be judged |
| R2.2 | "How do complaints in the contact centre and in branches meet today, and where do they split?" | Diligence that also addresses F2 openly, from curiosity rather than defence |
| R2.3 | "How would this role sit alongside the digital teams' self-service work, and who sets priorities?" | Ties to the 40% target and F5, and finds out who you will depend on |

---

# Round 3: panel of two branch managers (60 minutes, with a 20-minute case; the values round)

## Persona table, round 3

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four values | High. The recruiter says the panel scores against the four values | A story or scaffold per value; harmony stories where the hard truth landed |
| Case / Strategist | The 20-minute complaint escalation case | High. It takes a third of the round | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Peer Evaluator | "What would you need from us", seam and credit questions | Mid. The role coaches branch supervisors, and branch managers sit beside them; `[inferred]` from the JD's coaching line and the panel's roles, not from anything about these two people. The consolidation of eight branches into five hubs may colour how they hear "Neighbours, Not Numbers"; also `[inferred]`, from your message | Reciprocity framing; propose principles for the seam; spine and tact together |

## Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold for "Members First, Always": pick a decision with a named member or situation, what the other option was, and what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from the value as published. VAL; generic because none of your quotes carries this story |
| 3A2 | "When did something you explained need explaining a second time, and what did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4 for "Plain Words": the beat the quote states is that you trained new tellers on the escalation script. Answer slot: if a teller needed it explained twice and you changed the wording, say what you changed, in your own words; if that did not happen, or you changed nothing, say so plainly and describe how you trained | Theme from "if a member needs it explained twice, we wrote it wrong". VAL; the explained-twice beat is a slot because the quote does not state it |
| 3A3 | "Tell me about a time you thought about a branch or a member as part of their town, not just as numbers." | VAL | [generic] | Selection scaffold for "Neighbours, Not Numbers": pick a time with a named place or member, what the numbers said, what you knew locally, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not claim local knowledge you have not stated | Theme from "every branch is part of its town", and the hub consolidation may sharpen it. VAL; generic because none of your quotes states a local-knowledge story |
| 3A4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [generic] | Selection scaffold for "Own the Fix": pick a problem you found yourself, what you did to keep hold of it, how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Theme from "Own the Fix". VAL; the same question as 1C2, rehearsed in full here because the panel scores it |
| 3B1 | "A member has raised the same fee complaint three times through their branch and says they are moving to an app-only bank. The supervisor has escalated it to you. You have twenty minutes: where do you start?" | CASE | [generic] | Clarify first: what the member has been told, what has been tried, what rules or deadlines apply to a formal complaint, whether the fee was wrong. Objective: fix it for the member and keep the record straight. Segment: this complaint versus a pattern. Approach, metrics (the JD names volumes and resolution times), risks. Think aloud, use plain words, challenge one premise respectfully. The case needs no claim about your past | The recruiter says the panel's case is a complaint escalation; the scenario here is invented for rehearsal. CASE; generic because it is a pattern, not a fact about this employer |
| 3B2 | "One branch's escalations doubled last month. Diagnose it." | CASE | [generic] | Clarify what counts as an escalation and what changed; segment by type, channel, staff and date; form a hypothesis early and say how you would test it; name the figure you would check first and the assumption behind it. No claim about your past | Tests the reporting requirement (F3) as a live problem. CASE; generic |
| 3B3 | "App-only banks are Ashgrove's main competitive pressure. Where does the complaints process help or hurt Ashgrove against them?" | CO | [grounded] | Grounded in "the main competitive pressure is app-only banks". Clarify what the pressure looks like to a member, then name the moments in a complaint where a member is won or lost, and give your view in plain words, labelled as yours. The pack supplies no view and no claim about app-only banks | Differentiator question most candidates cannot touch. CO with CASE delivery |
| 3C1 | "You'd coach our supervisors on escalations. What would you need from us, and what would we get from you?" | JD | [grounded] "trained new tellers on our escalation script" | Reciprocity framing: what you would bring a branch manager's team, starting from "I trained new tellers on our escalation script", then what you would need. Answer slot, F4: if any of that training was with supervisors, say so; if none was, say so plainly and stay with the tellers. Offer principles for how the two of you would work, not a claim to know their seam | F4 is the coaching evidence and the panel is the audience for it. JD with Peer delivery |
| 3C2 | "Where is the seam between branch handling and the central complaints process, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam rather than pretending to know it: who decides what, how a disagreement is escalated, how the member is kept informed. For the disagreement, a selection scaffold: pick a time you disagreed with a peer and the relationship held; if no such time comes to mind, say so plainly and say how you would handle it | The role's scope spans branches, so the seam is the likeliest Peer probe. JD; generic because it makes no claim about your past |
| 3C3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, say who did what in your own words, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Peer stem aimed at partnership fit. VAL; generic |

## Values and principles cheat sheet (the panel is the values round)

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row carries a story. Scaffold, 3A1: a decision with a named member, the option you did not take, and why. If none comes to mind, say so plainly |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "trained new tellers on our escalation script". The explained-twice beat is a slot, 3A2: if a teller needed it explained twice and you changed the wording, say what; if not, say so |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries a story. Scaffold, 3A3: a named place or member, what the numbers said, what you knew locally. If none comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Nearest in your material, F1: "I handled the branch's formal complaints log". It says handled, not kept hold until solved, so it is the honest branch and not the story. Scaffold, 3A4: a problem you found and kept hold of. If none comes to mind, say so plainly |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for the peer-style panel, aimed at their work, not at yours |
| R3.2 | "As eight branches become five hubs, what would you most want complaint handling to protect for your town?" | Ties "Neighbours, Not Numbers" to the consolidation in your own words and invites their view |
| R3.3 | "Which of the four values is hardest to keep hold of in a real complaint?" | Shows you are using the values as working tools, and gives you their reading of them |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches" | 1A3, 2A3, 3B1 |
| "across branches and the contact centre" | 1B1, 2B1, 1B3 |
| "report monthly on complaint volumes and resolution times" | 2A4, 3B2 |
| "coach branch supervisors on escalations" | 2A2, 2B2, 3C1 |
| "work with digital teams on self-service journeys" | 1A4, 2C1, 3B3 |
| "4+ years in financial-services customer operations" | 1A1 |
| "experience handling regulated complaints" | 1A3 |
| "confident presenting to senior leaders" | 1B2, 2B3 |
| "comfortable with Excel reporting" | 2A4 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process. The slots in 1A3 and 2A3 stay inside the log |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The material says the spreadsheet, not what it measured. The slot in 2A4 asks only what it counted |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope. The material says new tellers, not supervisors. The slots in 2B2 and 3C1 stay with the tellers |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The material says formal, not regulated. The slot in 1A3 asks only whether external rules applied |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." The only slot is regional-level presenting, in 1B2 |

## Sources

Provided documents, all from your message: the JD; the four values as you copied them from ashgrovecu.org/about/values on 12 October 2026 (the page itself was not fetched); the recruiter's email on the three rounds; your summary of the June 2026 strategy brief (the brief itself was not supplied); your background. No searches or fetches were sent. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Your pasted values text already fixes the cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member experience | skipped | The recruiter's email already fixes the loop: three rounds, who runs each, lengths, the case, and the values scoring |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the brief's four points already fixes the CO questions; a search would not have changed them |
| 4. Interviewer name and Ashgrove | n/a | No names are assigned, so there is no query to form; the upgrade menu says what a name would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned: an interviewer read, persona weights adjusted to each person's public footprint, and a reverse question tied to their path
- The strategy brief's full text: the grounding brief widens beyond four points and the CO questions rest on more than your summary
- Your own answers to the answer slots in F1, F3, F4, F5, F7 and F9: those rows upgrade from slots to quoted evidence, and the guidance in 1A3, 2A2, 2A3, 2A4, 2B2 and 3C1 becomes story-mapped
- A line from the recruiter on what the 20-minute case covers, and whether any material comes ahead of it: 3B1 and 3B2 move from generic to grounded
- A line from the recruiter on what "senior leaders" means for this role: F8 and 1B2 can be aimed at the actual audience
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): role-family loop reports and recent organisation context, offered once
- A `tuesday-dossier.md` from an earlier underwriting pass, if you have one: verified evidence and named objections would sharpen the banks; never a prerequisite
