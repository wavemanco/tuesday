Web search was declined, so I'm building the pack from your message alone. I'll mark everything about Atlas Freight as generic, then save the file.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-2-denied-63297582/6714a82a-5ff5-4e61-a890-335f155d4641/scratchpad/Atlas-Freight_operations-manager_interview_pack.md`. It holds 24 questions across seven interviewer styles, a fit table against each JD line, six reverse questions and a list of claims it won't coach.

- **Saved location:** Writing to the project folder was declined, so I saved it in the session scratchpad instead.
- **No Atlas Freight research:** Web search was declined (3 searches refused). The only company facts in the pack are the ones in your JD, and everything company-specific is marked generic. Before the interview, read their site and careers page yourself.
- **Round type assumed:** I built it for a generic loop with near-flat weights, since you don't know the round or the interviewer.
- **Highest-ROI prep:** Question A2 is about the jump from 3 supervisors to 12, and from your current site to 4. Rehearse it through three follow-ups, then its pressure version, D3.
- **Number to be ready on:** Be ready to explain the 40% mis-pick figure at its own scope: how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours (C1, C2, D1).
- **Power BI:** Say it plainly: "I haven't used Power BI." Then give a plan for learning it, not a past.

I'll play the Skeptic on A2 whenever you like, as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Do you know whether this is a recruiter screen, a hiring-manager round or a panel, even just from the invite? That reweights every bank, and if the recruiter mentioned focus areas or something to prepare, tell me that too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer and round type: not known. Built as a generic loop (screen, hiring manager, panel) with near-flat persona weights, because your note named neither the round nor the interviewer.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: every sentence about your past is one of your own, quoted, and where the material stops, the guidance gives you an answer slot instead. An answer slot is an instruction for the interview with two honest branches; either branch meets it.

Bank letters skip F so that question IDs never clash with fit rows F1 to F7.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates values, not generic virtue |
| EXP | Whether the claims on your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage (interview next week)

1. A2, then D3: the span objection, three supervisors against twelve. This is the highest-ROI prep in the pack.
2. C1, C2 and D1: the 40% mis-pick figure, said at its own scope, with how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours.
3. A1, B3 and C4: Power BI said plainly, Excel said at its own scope.
4. G2: company homework. No research ran, so this one is on you before the interview.
5. B1 and B2: say each case aloud twice.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift role and a site's surge plan, with nothing inspected behind it, and the words stay there: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4 sites make a probe on scope likely. Stay inside your site: say what the surge plan covered and which part of it was yours to set, in your own words; if you cannot say, say so plainly and say how you would start with four sites as a plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material names mis-pick rate, not on-time performance or cost-per-shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's line makes a probe on what you watch day to day likely. If you track either measure, say how you look at it; if you do not, or someone else owns it, say so plainly and return to mis-pick rate |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The number stays on the supervisors your sentence names: "I'm currently a senior shift manager over 3 supervisors." The JD's 12 is a larger span than that sentence carries. Answer slot: say what your current span of 3 supervisors has taught you about how you lead, in your own words; if nothing comes to mind, say so plainly and say how you would start with twelve as a plan, never as a past |
| F4 | "build reporting in Excel/Power BI" — JD, Excel side | "solid Excel" — your message | medium | [grounded] | discovery | "Solid Excel" does not say what the Excel is used for. Answer slot: the JD's reporting line makes a probe on what you use Excel for likely. Say what you use it for and who sees the result, in your own words; if none of it is reporting, say so plainly and return to "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD, Power BI side | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI use, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | Your material says 7 years in the field, not how many of them included supervisors under you. Words at scope: "I have 7 years in warehouse and distribution ops." Answer slot: say what your roles across those years were and which of them had supervisors under you; if you cannot put a number on it, say so plainly and stay with "currently a senior shift manager over 3 supervisors" |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but the certification has nothing inspected behind it here, so expect a probe. Lead with it in its own terms: "I'm green belt certified." Answer slot: if asked where you have applied it, say where and how in your own words; if the certification is the extent of it, say so plainly |

## Persona table

No loop source establishes Atlas Freight's process, so the fallback archetype is Generic (screen, hiring manager, panel) with flat weights. Your persona weights rest on that pattern, not on this company's documented process. Depth ordering below comes from where the JD and your material press hardest, not from any research.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent probing of gaps: span, terminals, Power BI, leadership years | Highest depth. F1, F3, F5 and F6 are where your material is thinnest against the JD; the round is unknown, so every round type can reach them | Rehearse the single most predictable objection until it is boring; bridges only from sentences you stated; calibrated candor over bluffing |
| Case/Strategist (bank B, 4) | Live problems from the role: diagnose on-time performance, cost, reporting, a surge | High depth. F2 and F4 are the JD lines no sentence of yours reaches; a live problem is the cheapest way to test them | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C, 4) | Reads your lines one by one; asks how the 40% was counted | High depth. F2's one metric is a magnet target | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know; name the weakest assumption before they do |
| Pressure (bank D, 3) | Interrupts, time-boxes, tests whether you hold a position | Mid depth. Appears more in a panel or a later round; the round is unknown | Pause; restate; anchor in what you stated; hold through two follow-ups before conceding anything real |
| Values/Behavioral (bank E, 3) | Scenario probes, STAR-shaped stories | Mid depth. No published values were read and no values-style round is detected, so the questions theme from the JD and standard stems | Selection scaffolds ending in the honest branch; "we" for context, "I" for contribution |
| Conversational (bank G, 3) | Friendly opener, then casual questions that are still scored | Mid depth. A recruiter screen would weight it up; the round is unknown | A short arc built only from your quoted sentences; treat casual questions on JD topics as scored |
| Peer (bank H, 2) | Seam-splitting between sites, credit, disagreement | Low depth. Four sites make peer managers plausible interviewers, but nothing says one is in the loop | Reciprocity framing; propose seam principles rather than pretending to know the seam |

## Question banks

### Bank A: Skeptic

Highest-ROI prep in the pack: A2. The objection is the step from your current span to the JD's, and it will be asked in some form. Rehearse it through three follow-ups.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "solid Excel" | Name one real gap plainly. The one your own message states is the tool: "I haven't used Power BI." Then a plan, said as a plan: how you would learn it in the first weeks. Stay with "solid Excel" at its scope for what you do bring. Do not name a second weakness you have not thought through | F5 is the only row where you stated an absence, so it is the safest honest answer; F4 is the other half of the same JD line. JD because it scores the stated requirement, Skeptic because of the delivery |
| A2 | "What from your current span carries over to 4 sites and 12 supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | The hold is only what the quotes carry: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Concession, at scope: "Twelve is a larger span than the three I have today." Answer slot: say what your current span has taught you about how you lead, in your own words; if nothing comes to mind, say so plainly and say how you would start as a plan. Follow-up 1 (what changes at twelve): answer from the three, then say what you would ask first. Follow-up 2 (how would you know it was working): name one thing you would look at first, in your own words, or say you would ask. Follow-up 3 (what if a site resists): stay with how you worked with your supervisors today, or say that you would find out. Hold by returning to the quotes, never by adding to them | F1 and F3 are where the JD's scale presses hardest on your material, so this objection arrives in some form. JD because it scores the stated requirements; deepest follow-up chain because it is the most predictable question |
| A3 | "Your background is warehouse and distribution. How does terminal operations differ, and where would you need to learn?" | JD | [grounded] "7 years in warehouse and distribution ops" | Open with the quote at its scope: "I have 7 years in warehouse and distribution ops." Answer slot: say which part of those years is closest to what the JD calls terminal operations, in your own words; if none is, say so plainly and say what you would ask about first. Do not describe terminal practices you have not worked in | F1 is the requirement the question presses. JD because it tests the stated role; Skeptic because it targets the background mismatch |
| A4 | "Why leave a senior shift manager role for this one, and why Atlas Freight?" | JD | [generic] | Selection criteria: one reason that is true and points at something the JD lists, in the JD's own words, for example "Own daily terminal operations across 4 sites"; one reason for this company that you can only get from your own research before the interview, since none was run here. If no company-specific reason comes to mind, say so plainly, then say what attracted you in the JD | Motivation consistency is what a skeptical interviewer scores. JD because the reason should point at the posting |
| A5 | "The posting asks for 5+ years of operations leadership. How would you describe your leadership years?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the quotes at their scope: "I have 7 years in warehouse and distribution ops" and "I'm currently a senior shift manager over 3 supervisors." Answer slot: say what your roles were across those years and which had supervisors under you; if you cannot put a number on it, say so plainly and stay with the current role | F6 is a requirement the posting marks required. JD because it scores that line |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four terminals has dropped for three weeks. Diagnose it. What do you need to know first?" | CASE | [generic] | Structure aloud: clarify (how on-time is defined and measured, since the definition changes the answer), objective, how you would split the problem, approach, the few measures you would watch, risks. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | F2 names on-time performance and no sentence of yours reaches it; a live problem tests it. CASE because it scores structure; generic because it is a pattern, not a fact about this employer |
| B2 | "Cost-per-shipment is above target across the sites. Where do you look first, and how do you avoid trading it against on-time performance?" | CASE | [generic] | Structure aloud: clarify what is in the cost figure, what the target assumes, then segmentation, approach, measures, risks, and name the trade-off with on-time performance explicitly before the interviewer does. No claim about your past | F2's other half. CASE because it is a live problem; the JD line is the raising source |
| B3 | "You take over four sites that each report differently. How do you build one daily view for the team?" | CASE | [grounded] "solid Excel, never used Power BI" | Structure aloud: who reads it and what decision it serves, definitions agreed before tools, a small set of measures, cadence. On tools, say what the quote says: "solid Excel", and "I haven't used Power BI." Then say what you would start with, as a plan. Answer slot: if the interviewer asks what you have built, say it in your own words; if you have not built one, say so plainly and return to the plan | F4 and F5. CASE because it asks how you would build, not what you built |
| B4 | "A surge hits all four sites in the same week. How do you decide where the extra capacity goes?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure aloud: clarify the capacity you have and what each site is committed to, the objective, how you would rank claims on capacity, the measures, the risks. You can refer once to your own plan at its scope: "I ran the site's peak-season surge plan two years running." Then stay with the question. Answer slot: if the interviewer asks what the plan contained, say what was in it and which part was yours, in your own words; if parts were not yours, say so plainly | F1. CASE because it is a live problem; the quote earns one reference and no more |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the quote at scope: "I cut mis-pick rate 40% by redesigning the pick path." Four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. For each, if you know, say it; if you do not know, or it was not yours, say so plainly and return to the sentence. Never supply a method or baseline you cannot repeat under a second question | F2's one metric, so a defend-the-number question. EXP because it tests attribution and counting |
| C2 | "Tell me about the redesign itself. What changed in the pick path?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The quote says you redesigned the pick path, not what changed. Answer slot: describe in your own words what changed and what was yours; if parts were someone else's, or you cannot recall the detail, say so plainly and stay with the sentence. If asked whether it used Lean or Six Sigma tools, say so in your own words, or say it did not | F2 and F7 meet here. EXP because it tests what was actually done |
| C3 | "What do you measure at your site, and how often do you look at it?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The one measure your quote names is mis-pick rate. Answer slot: the JD's on-time and cost-per-shipment lines make a probe on whether you also look at either likely. If you do, say how you look at it; if you do not, or someone else owns it, say so plainly and return to mis-pick rate | F2. JD because it scores the stated measures |
| C4 | "What do you use Excel for in your current role?" | JD | [grounded] "solid Excel" | Say the quote at scope: "solid Excel." Answer slot: say what you use it for and who sees the result, in your own words; if none of it is reporting, say so plainly. If asked about Power BI: "I haven't used Power BI." | F4 and F5. JD because the posting names the tools |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to it. Answer slot: if part of the result was the team's or someone else's, say which part plainly; if none was, say so and stay with the sentence. Concede only what you know is true, specifically | F2. EXP because it scores attribution under pressure |
| D2 | "Sixty seconds: why you for this role?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Choose two of the three quotes and say each at its scope: "I have 7 years in warehouse and distribution ops", "I ran the site's peak-season surge plan two years running", "I'm green belt certified." Stop at sixty seconds. If cut off, restate the strongest of the two. Add nothing the quotes do not carry | F1, F6 and F7 are the strongest supported rows. JD because it scores fit to the posting |
| D3 | "You'd go from 3 supervisors to 12. Convince me you won't be out of your depth." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The same objection as A2 in pressure packaging. Hold: "I'm currently a senior shift manager over 3 supervisors." Concede at scope: "Twelve is a larger span than the three I have today." Answer slot: say what your current span has taught you, in your own words; if nothing comes to mind, say so plainly and say how you would start. Do not claim the span is comparable | F3. JD because it scores the stated requirement; objections from other banks return in this packaging |

### Bank E: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment where you said the hard thing, and the truth landing with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem; no values page was read, so it is generic. VAL because it scores behavior |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real customer-facing consequence, the metric you set aside and why, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values stem, generic for the same reason as E1 |
| E3 | "Tell me about a time a supervisor on your team missed a standard." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | You may name your span at its scope: "I'm currently a senior shift manager over 3 supervisors." The story itself is a selection scaffold: pick a time where the standard was clear, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3. JD because the posting's supervisor line is the raising source |

### Bank G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc with four beats, each a quoted sentence at its own scope, in that order. The last beat is your own reason for this role, in your own words; if you do not have one yet, build it from the JD line you most want to own before the interview | F1, F2, F3 and F6. EXP because it is your own history |
| G2 | "What do you know about Atlas Freight?" | CO | [grounded] "(regional logistics, 800 employees)" — JD | No research ran, so nothing about the company beyond the posting is in this pack. Say what the posting says, "regional logistics, 800 employees", and nothing more. Before the interview, read the company's own site and careers page and bring one thing you found, in your own words. If you found nothing, say so plainly and ask the interviewer | The only company facts this pack has are the posting's. CO because it scores homework |
| G3 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say the quote at scope: "I'm green belt certified." Answer slot: if you use Lean or Six Sigma tools in your current work, say which and where, in your own words; if you do not currently, say so plainly and return to the certification | F7. JD because the posting lists it |

### Bank H: Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where's the seam between my site and yours, and what happens when we disagree?" | JD | [generic] | Reciprocity first: what you would bring to their site, not only what you need. Propose seam principles rather than claiming to know the seam. For a disagreement story, selection criteria: spine and tact together, the relationship intact. If no such time comes to mind, say so plainly, then say how you would handle it | The posting spans four sites, so peers are plausible. JD because it scores the multi-site requirement |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: a time work spanned teams, how credit was shared in practice, and the relationship afterward. Use "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly, then say how you would handle it | A standard peer stem. VAL because it scores behavior |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, A3, B1, B4, H1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C3 |
| "lead a team of 12 supervisors" | A2, D3, E3 |
| "build reporting in Excel/Power BI" | A1, B3, C4 |
| "5+ years operations leadership required" | A5, G1 |
| "Lean/Six Sigma a plus" | C2, G3 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Which of the four sites would you want me to spend my first thirty days at, and why?" | Shows you are already planning for the span the JD describes, and it asks for their reasoning rather than yours | [grounded] "across 4 sites" — JD |
| 2 | "How is on-time performance defined today, and where is it measured?" | Shows you would clarify a definition before driving a number | [grounded] "on-time performance" — JD |
| 3 | "What does the team of 12 supervisors look like today, and where do they most need support?" | Turns the span objection into a conversation about the team itself | [grounded] "12 supervisors" — JD |
| 4 | "Is reporting built in Excel, Power BI, or both today, and what would you want me to own first?" | Settles whether the JD's slash means either tool, and lets you ask without bluffing | [grounded] "Excel/Power BI" — JD |
| 5 | "What would make the first six months a success in this role?" | Asks for the scoring sheet directly | [generic] |
| 6 | "What is the biggest operational problem across the sites that you would want solved first?" | Moves the conversation to the real job and gives you something to plan against | [generic] |

## Prohibited claims

Built locally from the fit snapshot, before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: your material says a shift role and a site's surge plan, not terminals or four sites. A2's and A3's slots stay inside those quotes |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote with the 3 attached to supervisors. D3's concession states only that twelve is a larger span than three |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope: mis-pick rate. C3's slot stays there |
| Built reports or dashboards in Excel | Inflated form of F4 | "solid Excel" at its own scope. C4's slot asks only what you use it for |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Has 5 or more years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops" at its own scope. The pack's observation is that your material does not say how many of them included supervisors under you |

## Sources

Provided documents: the job description text pasted in your message; your background as described in your message (no CV file was provided). No dossier was present.

Searches sent, all refused because web search permission was not granted:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals news strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have moved the values cheat sheet and the VAL bank's themes; no values-style round is detected without it, so bank E is generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have moved the loop structure and persona weights; the Generic archetype stands in |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have moved the CO and CASE banks, which are generic or built from the posting alone |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → rows 1 to 3 above become researched: published values by name, the documented loop and persona weights, and strategy-grounded CO and CASE questions. A deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- The round type and who is interviewing → every bank reweights; an interviewer name adds an interviewer read and a tailored reverse question
- The recruiter's note on focus areas or anything to prepare in advance → coverage assumed from round-type priors becomes real, plus a build section for any announced deliverable
- Your own words on F1, F2, F4 and F6 (what the surge plan covered, what you track, what you use Excel for, which years had supervisors under you) → those rows move from answer slots to story-mapped answers
- The before-and-after report or site scorecard behind the 40%, and the green belt certificate → the mis-pick quote and F7 move from medium toward high
- A `tuesday-dossier.md` from an earlier session → verified evidence and any prohibited claims arrive pre-checked
