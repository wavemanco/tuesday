The pack is fully drafted, but my save to the working folder was blocked. I'll try once to save it in the session scratchpad. If that's blocked too, I'll give you the pack in this chat.
Dara, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-denied-fc3807ce/44822503-fa63-4100-ae82-62e2d2fa9c3f/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

My first save to the working folder was blocked, so the pack is in the session scratchpad instead.

**What's in it**
- Because all three rounds are scheduled, I built it as one shared fit snapshot plus a section for each round. Each round has its own persona weights, question bank and reverse questions.
- Each JD requirement is checked against your own sentences. Where your material is silent, the pack gives you an honest two-branch answer to rehearse. It never writes a claim you didn't make.
- Round 3 carries a cheat sheet for the four values, with your stories mapped where your material supports one.
- The strategy brief feeds two questions: G1 on the 40% digital shift and K1 on the hub consolidation. Branch managers may raise the consolidation against "Neighbours, Not Numbers".
- I ran no searches. Your pasted values, the recruiter's email, the JD and the brief already fixed everything a search could have changed.

**Highest-ROI prep**
- **E1, the contact-centre objection.** The role owns the process across branches and the contact centre, and you've never worked in one. Rehearse naming that limit in your first sentence, then a plan, then returning to what you did handle. Presenting above regional level (B3, F2) is second.
- **Slots to fill.** The pack leaves several answer slots open because your material doesn't say. Fill them in your own words before 21 October: what the spreadsheet counted and whether it was Excel, any rules your complaints log had to meet, and any digital-team work.

I couldn't reconcile one date. You gave today as 12 October, but my clock shows 5 November. I assumed 21 October is still ahead, so tell me if it has passed.

Say the word and I'll run a live drill as the Skeptic on E1. I can also record the gaps this prep exposed in a `tuesday-dossier.md` for later sessions, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Three scheduled rounds on 21 October (loop mode): round 1 with the recruiter (30 min); round 2 with the Head of Member Services, who would be your manager (45 min, mostly behavioural); round 3 with a panel of two branch managers (60 min, including a 20-minute case on a complaint escalation, and scored against the four values). Interviewers beyond their roles are not yet assigned, so there is no interviewer read.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether a line of your background survives scrutiny |
| JD | The role's stated responsibilities and requirements, gaps included |
| CO | Knowledge of Ashgrove's strategy and where it points |
| CASE | A live problem, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you. It names what an interviewer is likely to probe, then gives two honest branches: say how it went, in your own words, or say plainly that the step did not exist or was not yours, and return to what you did say.

The highest-ROI prep in this pack is E1, the contact-centre objection: every round touches it, and a rehearsed, non-defensive answer changes the interview. The second is the presenting-to-senior-leaders limit (B3, F2).

## The fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: if any decision in handling the log was yours to make, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly and describe how you handled the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past; the plan's content is yours to write. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted volumes or resolution times, say how each was counted, in your own words; if it counted something else, or there was no such step, say so plainly and describe what the spreadsheet did |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet, not which tool. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, or the build was shared, say so plainly and stay with the spreadsheet you built |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quote says new tellers and the escalation script; the JD says branch supervisors. The words stay at: "I trained new tellers on our escalation script." The step from tellers to supervisors is not in your material, and any answer about it is method, said as how you would do it |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team or on a self-service journey, say what and what part was yours; if you have not, say so plainly and answer the question as a structured view (G1) |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the years, but a line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor. Expect "customer operations" to be tested against the contact-centre limit in F2 |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The quote says formal complaints log; it does not show whether rules or deadlines governed it. Answer slot: if there were rules or deadlines the log had to meet, say what they were and how you worked to them, in your own words; if you do not know of any, or someone else tracked them, say so plainly and stay with the log |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Your material does not say whether you presented at regional level, so that is not claimed; whether Ashgrove's senior leaders sit above that line is also not in your material. Then a plan, in your own words |

No row is a gate: the years requirement is length of experience, which is graded like any other row.

## Grounding brief (shared)

Built from the strategy lines you passed on from the June 2026 brief the recruiter sent. No deeper research ran.

| Brief line | Provenance | Where it may surface in your rounds (this pack's inference) |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] | F6's requirement; G1; reverse question R2-4 |
| "consolidate eight branches into five hubs over 2027" | [grounded] | K1 and H3, since round 3 is two branch managers; whether their own branches are affected is not in your material |
| "launch a small-business lending product in Q1 2027" | [grounded] | No bank question: your material gives it no complaints angle. Use it as vocabulary and in R2-4 |
| "the main competitive pressure is app-only banks" | [grounded] | G1's framing of why digital matters. Use it as context, never as expertise you hold |

---

## Round 1: recruiter screen (30 minutes)

### Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; casual questions on hot JD topics | Top, 5 questions. Recruiter-screen prior is Conversational plus a light Skeptic; the recruiter's email names this as a 30-minute conversation | A 90-second arc for the biography question; treat casual JD questions as scored; answer each question once, plainly, since the values prize plain words |
| Skeptic | Knockout checks on the JD's requirement list | Mid, 3 questions. Same prior; your two stated limits are the obvious checks | Name the limit once, in your own words, then your plan; no bluffing |
| Values/Behavioral | Motivation and values-flavoured prompts | Low, 2 questions. The recruiter says the panel is the values round, so this round only previews it | One story per value, carried forward to round 3 |

Weights rest on the recruiter's email as the loop source.

### Question bank

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: six years in retail banking, the last three as a branch supervisor." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Story-mapped on F7: six years in retail banking and the last three as a branch supervisor are the beats; tell them in your own words in about 90 seconds. Answer slot: the first three of the six years are not in your material; if asked, say what you did then, in your own words, and if there is nothing to add, say so. Close on why this role, in your own words | F7 is the evidence for the years requirement and the natural opener; EXP because the interviewer is checking the line says what it says |
| A2 | "The role runs across the branches and the contact centre. What's your experience on the contact centre side?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The friendly version of E1. Say the limit first, in one sentence: "I haven't worked in a contact centre." Then your plan in your own words: what you would learn first and from whom. Nothing beyond the quote about contact-centre work | F2 is the largest gap against the JD; JD because it scores a stated requirement, asked in a casual register |
| A3 | "What drew you to a member-owned credit union?" | JD | [generic] | Selection scaffold: pick the real reason and keep it to three sentences, since a different reason in a later round would read as inconsistent. If no particular reason comes to mind, say so plainly and say what you are looking for in a role, in your own words | The JD's title line names the member-owned model; a recruiter screen tests motivation consistency; JD because it tests fit with the stated employer |
| A4 | "How are you with Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F4: you built the monthly complaints spreadsheet and your regional manager uses it; tell it in those words. Answer slot: the JD names Excel, so expect a follow-up on what is in it. If it was built in Excel, say what you did in it; if it was another tool, or the build was shared, say so plainly and stay with the spreadsheet you built | F4 is the only evidence for the Excel requirement; JD because it scores the stated requirement, asked casually |
| A5 | "Tell me about the formal complaints you handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8: "I handled the branch's formal complaints log." Answer slot: the JD's wording on complaint experience makes a probe likely. If there were rules or deadlines the log had to meet, say what they were and how you worked to them; if you do not know of any, or someone else tracked them, say so plainly and stay with the log | F8 is the evidence for the JD's complaints-experience line and is a discovery row; JD because it scores a stated requirement |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name one limit before they press, in one sentence, using only what the quote carries: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Choose the one that is truer for you, then your plan in your own words. One limit, said plainly, not a list | F2 and F9 hold both stated limits; the persona stem is a standard knockout check; JD because it scores the requirement list |
| B2 | "You handled the branch's formal complaints log. How does that prepare you for a role that covers the whole process?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold F1 at its own scope: "I handled the branch's formal complaints log." Answer slot: if any decision in handling the log was yours to make, say which and how you decided; if there was no such decision, or it was not yours, say so plainly and describe how you handled it. Then what you would need to learn about the rest of the process, as a plan | F1 is the evidence for the headline responsibility and a transferability row; JD because it scores the stated requirement |
| B3 | "You'd be presenting to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment from your own statement: "I haven't presented to anyone above regional level." Do not claim regional-level presenting; your material does not say you did. Answer slot: if you have presented at regional level, say what and to whom, in your own words; if not, say so plainly. Then your plan | F9 is a stated capability gap; JD because it scores a stated requirement |

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of an internal target." | VAL | [generic] | Selection scaffold, for the value Members First, Always: pick a time you decided something from the member's side when another consideration pulled the other way; it needs the decision, the pull the other way, and what happened for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem tied to the published value; a preview of H1; VAL because it scores behaviour against a named value |
| C2 | "When have you stayed with a problem until it was solved, even if it wasn't yours to fix?" | VAL | [generic] | Selection scaffold, for the value Own the Fix: a named problem, the point where you could have handed it on, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The quote-mapped version is D3 | Tied to the published value's wording; VAL because it scores behaviour against a named value |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "For the 20-minute case in round 3, is the material shared beforehand or given on the day, and do I present my approach or talk it through?" | The recruiter can answer it in one email; it removes the biggest unknown and shows you are preparing the case itself |
| R1-2 | "Who will be on the round 3 panel, and who is the Head of Member Services I'd be meeting?" | Names unlock the interviewer read and persona reweighting; asking is routine for a recruiter |
| R1-3 | "How does Ashgrove weigh contact-centre experience for this role, since the process runs across branches and the contact centre?" | Puts your known gap on the table early, on your terms, and tells you how much weight to give E1 |
| R1-4 | "How are complaints split between the branches and the contact centre today, and who holds them in between?" | A real-process question that signals you think about the handoff, which is the seam the role sits on |
| R1-5 | "What is the timeline for decisions after 21 October?" | Logistics; closes the conversation on a practical note rather than a generic one |

---

## Round 2: Head of Member Services, your would-be manager (45 minutes)

### Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" prompts | Top, 4 questions. The recruiter calls this round mostly behavioural | A story per prompt, "we" for context and "I" for contribution; where no story exists, the honest branch |
| Skeptic | Probing the gaps a future manager is buying | Mid, 3 questions. The hiring-manager prior is Case plus Skeptic: they are weighing capability and gaps | Rehearse the contact-centre objection until it is boring (E1); limit named first |
| Data-Driven Prober | Reads the reporting line by line | Low, 2 questions. The JD makes monthly reporting a responsibility and Excel a requirement | Know what you can and cannot say about what the spreadsheet counted, and say plainly when you do not know |
| Case/Strategist | Live problems on the role's roadmap | Low, 2 questions. Hiring-manager prior; the strategy brief supplies the roadmap | Clarify, structure, answer; challenge one premise respectfully |

Weights rest on the recruiter's email as the loop source, adjusted by its "mostly behavioural" description.

### Question bank

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a moment where the hard truth actually landed, from the levels you have actually worked with; it needs the truth, who heard it, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; a hiring manager scoring behaviour in a mostly behavioural round; VAL |
| D2 | "Tell me about a time you trained someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5: "I trained new tellers on our escalation script." Answer slot: expect a follow-up on how you taught it. Say how, in your own words; if there was no set way you taught it, or the script was someone else's, say so plainly and stay with the fact that you trained new tellers on it | F5 is the only evidence for the coaching responsibility, and the JD says supervisors while the quote says tellers; JD because it scores the stated responsibility |
| D3 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1: "I handled the branch's formal complaints log." Answer slot: the value Own the Fix invites a specific complaint. If there was one you kept hold of until it was solved, say what it was and which part of the fix was yours; if the log was a record and the fixes sat with others, or no such case comes to mind, say so plainly and stay with the log | F1 is the nearest evidence for the value; VAL because the published value is the raising source |
| D4 | "How would you explain a complaint outcome to an upset member, in plain words?" | VAL | [generic] | A method, with no claim about your past: the outcome in one plain sentence first, then the reason, then what happens next and by when. Say it once and check it landed; the value Plain Words says a member who needs it twice means the wording was wrong. Ask what is true before you say it | The value Plain Words, asked as a method; VAL because it scores the value; no past is presupposed |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You haven't worked in a contact centre, and this role covers branches and the contact centre. How would that work?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The deepest rehearsal in the pack. Name the limit in your first sentence, before it is pressed: "I haven't worked in a contact centre." Then your plan in your own words: what you would learn first, from whom, over what period. Follow-up 1, what you would do in the first month: the plan, in order, as a plan. Follow-up 2, what if the contact-centre team doesn't take you seriously: do not claim parity; concede in these words: "I haven't worked in a contact centre, so on that side I'd rely on the people who do it every day to teach me." Then return to what is yours: "I handled the branch's formal complaints log." Follow-up 3, what you need from the manager: ask for one introduction to someone on the contact-centre side. Never offer a contact-centre equivalent | F2 is the biggest gap against the JD's headline responsibility and the one a future manager must be comfortable with; F1 is the branch-side evidence to return to. JD because it scores the stated requirement |
| E2 | "Why this role, and why now?" | JD | [generic] | Selection scaffold: your real reason, matching what you told the recruiter in A3, in three sentences. If you cannot say it without borrowing the company's values language, say what you are looking for in your own words | The persona stem for motivation consistency; JD because it tests fit with the role |
| E3 | "You've been a branch supervisor for the last three years. How do you move from doing the job to coaching others in it?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold F5 at its own scope: "I trained new tellers on our escalation script." The step from tellers to supervisors is not in your material; if pressed, say so plainly and answer the rest as how you would do it, not as something you have done | F5 is the coaching evidence and a transferability row; F7 gives the supervisor tenure; JD because it scores the stated responsibility |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through what's in the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3: you built it, it is monthly, and your regional manager uses it; tell it in those words. Answer slot: the JD names volumes and resolution times. If it counted either, say how each was counted and the assumption you would defend least; if it counted something else, or you do not know how a figure was counted, say so plainly and describe what it did | F3 is the only reporting evidence and a discovery row; EXP because the Prober tests what you actually built |
| F2 | "You have ten minutes with the senior team on this quarter's complaints. What do you show them?" | CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | A structure, with no claim about your past: what changed this quarter, the likely cause, what you are doing, and what you need from them. One page, plain words. If asked about your experience: "I haven't presented to anyone above regional level." Then your plan | F9 is the stated limit this question presses; CASE because it is a live problem from the role's reporting line |

**Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The strategy moves 40% of member service to digital channels by 2028. Which complaints would you keep with a person, and why?" | CO | [grounded] the strategy line "move 40% of member service to digital channels by 2028" | Clarify first (what counts as member service here, which complaint types exist, what the digital teams are building). Then segment by what the complaint needs: judgement or explanation to a person; status or tracking to self-service. Metrics: repeat contacts, time to resolution. Risks: a member who must repeat themselves. Answer slot: if you have worked with a digital team, say what and what part was yours; if you have not, say so plainly and answer as a structured view | The brief line is the raising source and F6 is the JD requirement it meets; CO because it needs the company's own strategy at its altitude |
| G2 | "Average complaint resolution time rose 20% last month. Diagnose it." | CASE | [generic] | Clarify: how resolved is defined by Ashgrove's policy, which complaint types, which channel, volumes against backlog. Then hypotheses by segment, the data you would pull, and what you would tell the Head. Do not recite a definition of resolved from memory | Persona stem; the JD makes resolution times a reporting item; CASE |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would a good first monthly report need to show you?" | Ties directly to the JD's reporting responsibility and tells you what the manager will score |
| R2-2 | "Where does the handoff between the branches and the contact centre break down today?" | The role sits on that seam; the answer tells you what you would inherit |
| R2-3 | "Since I haven't worked in a contact centre, who would you want me spending time with in the first month?" | Turns your known gap into a working plan with your future manager |
| R2-4 | "With 40% of service moving digital and the small-business lending launch next year, where does the complaints role sit with the digital team?" | Shows you read the brief, and it is a real scoping question for the role |
| R2-5 | "What do you wish a new lead had known in their first month?" | Invites a candid answer rather than a prepared one |

---

## Round 3: panel of two branch managers, including the 20-minute case (60 minutes)

### Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts mapped to the four values, scored | Top, 4 questions. The recruiter says the panel is the values round and scores against the four values | One story per value, quoted from your material or a scaffold with its honest branch (cheat sheet below) |
| Case/Strategist | The 20-minute complaint-escalation case | Mid, 3 questions. The recruiter names the case; the format is not yet known | Clarify, then structure, then answer; challenge one premise respectfully |
| Peer Evaluator | Where your role meets theirs: you coach their supervisors | Mid, 3 questions. A panel blends the top personas of each member's relationship, and the JD has you coaching branch supervisors | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Skeptic | Contact centre, presenting, and the hub consolidation | Low, 2 questions. The gaps matter less to branch managers than the values, but are still on the page | Limit named first; hold what the quotes carry |

Names are not assigned, so personas are blended rather than assigned per member.

### Question bank

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold, for Members First, Always: the decision, the pull the other way, and what happened for the member. Tell the C1 story again, tightened, if you used one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Uses the published value's own wording; VAL because the panel scores against the value |
| H2 | "Tell me about a time something you explained or wrote had to be explained again. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5: "I trained new tellers on our escalation script." Answer slot: if the script's wording, or the way you taught it, ever changed because someone needed it explained twice, say what changed and whose change it was; if not, or it was not yours, say so plainly and stay with training the tellers on the script | The value Plain Words is the raising source; F5 is the nearest evidence; VAL |
| H3 | "Tell me about a time you thought about a branch's town when making a decision." | VAL | [generic] | Selection scaffold, for Neighbours, Not Numbers: the decision, what the local community had to do with it, and the outcome. If no such time comes to mind, say so plainly, then say what you would ask the local branch manager first | The published value's wording; asked of two branch managers; VAL |
| H4 | "Tell me about a time you found a problem that wasn't yours to fix." | VAL | [generic] | Selection scaffold, for Own the Fix: the problem, the moment you could have walked away, and what you did. If you told the D3 story, keep it consistent. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's wording; D3 is the quote-mapped version; VAL |

**Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "A member has complained three times, at the counter, by phone to the contact centre, and in writing, and each time was told someone would come back to them. Nothing has happened. They are at the counter now and the branch supervisor has called you. Walk us through what you do." | CASE | [generic] | A pattern for the case, not the case itself, which is not yet known. Clarify first: what is recorded and where, what the member wants, which clock applies under Ashgrove's policy and any regulator rules; ask, do not recite one. Objective: the member leaves knowing who holds it and when they will hear. Approach: one named owner today (Own the Fix), plain words to the member (Plain Words), then why it fell between channels. Metrics and risks last. The case needs no claim about your past; any example you reach for must be one you actually handled | The recruiter names a 20-minute escalation case; this pattern hits the JD's coaching, cross-channel and complaints lines; CASE |
| I2 | "The supervisor says the contact centre should have picked it up. What do you say to them?" | CASE | [generic] | Separate the member's problem from the blame: first close the member's case, then the handoff. Say it in a sentence a supervisor can act on. Do not take a side before you know what happened | A likely follow-up to I1 from branch managers; CASE |
| I3 | "How would you coach a branch supervisor who keeps escalating complaints late?" | CASE | [generic] | A method: find what is late (spotting, process, fear of escalating), walk their last case together, agree a trigger, follow up. The question asks for method, not memory. If you reach for the tellers you trained, keep it at: "I trained new tellers on our escalation script" | The JD's coaching line; F5 holds the nearest evidence; CASE |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Where is the seam between your role and ours? What happens when you coach one of our supervisors differently from how we would?" | CASE | [generic] | Propose seam principles and ask where the line sits today; do not pretend to know it. For example: agree with the branch manager before changing what a supervisor does, and be clear who owns the process standard and who owns the person. Offer what you bring their branch | The panel manages the people the JD has you coaching; the persona stem; CASE |
| J2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "We" for context, "I" for contribution. "I built the monthly complaints spreadsheet our regional manager uses" stands as said. Answer slot: if others contributed to it, say who and what; if you built it alone, say so plainly | The persona stem, applied to F3; EXP because it tests attribution |
| J3 | "A branch manager disagrees with how you've handled one of their members' complaints. What do you do?" | CASE | [generic] | Show spine and tact together: hear their reason, restate it, say what you would still do for the member and why. No claim about your past | Disagreement style with equals, the Peer persona's real score; CASE |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "The strategy folds eight branches into five hubs over 2027. A member from a branch that's closing makes a complaint about it. How do you handle that?" | CO | [grounded] the strategy line "consolidate eight branches into five hubs over 2027" | Separate the decision from the service: you do not defend or dispute the strategy in the room; you keep hold of the complaint and answer in plain words. Say what you would need to know first, such as what Ashgrove has told members and where complaints about it go. Neighbours, Not Numbers applies: the branch belongs to its town. Your material has only the brief's one line, so say that if asked | The brief line meets the published value; asked of branch managers; CO |
| K2 | "You haven't worked in a contact centre and you haven't presented above regional level. Why should we back you for this?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "6 years in retail banking, the last 3 as a branch supervisor." | Hold, then concede. Concede both limits in your own words, specifically: "I haven't worked in a contact centre and I haven't presented to anyone above regional level." Hold the core through two follow-ups by returning to what the quote carries: "6 years in retail banking, the last 3 as a branch supervisor." Do not add to it to restore harmony | F2 and F9 together are the pressure point; F7 is the position held; JD because it scores the stated requirements |

### Values cheat sheet (round 3)

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold: pick a time you decided something from the member's side when another consideration pulled the other way; it needs the decision, the pull the other way, and what happened for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained twice, the wording is at fault | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat the sentence states is training new tellers on the script. Answer slot: if its wording, or how you taught it, ever changed because someone needed it explained twice, say what changed and whose change it was; if not, or it was not yours, say so plainly and stay with the training |
| Neighbours, Not Numbers | Every branch belongs to its town; people are not statistics | Selection scaffold: pick a decision where the local community mattered; it needs the decision, the community's part in it, and the outcome. If none comes to mind, say so plainly and say what you would ask the local branch manager first |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat the sentence states is handling the log. Answer slot: if there was a complaint you kept hold of until it was solved, say what it was and which part of the fix was yours; if the log was a record and the fixes sat with others, say so plainly and stay with the log |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "How do complaints reach you today, and where do your supervisors tend to get stuck?" | These are the people the role coaches; their answer is the best preview of the work |
| R3-2 | "What would you want from this role in the first month that would help your supervisors?" | Reciprocity: leads with what you bring their branch, not what you need |
| R3-3 | "How are members hearing about the move to hubs, and what do you hope the complaints lead can do there?" | Engages the strategy without taking a side, in front of the people who live it |
| R3-4 | "Which of the four values is hardest to hold to when a complaint is live, and what does it look like when it works?" | Invites their own example in a round they are scoring against the values |
| R3-5 | "What did the best handover between a branch and the contact centre look like, and what made it work?" | Own the Fix in practice, and it gives you a story to learn from |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A2, B2, D3, E1, I1 |
| Report monthly on complaint volumes and resolution times | F1, F2, G2 |
| Coach branch supervisors on escalations | D2, E3, I3, J1 |
| Work with digital teams on self-service journeys | G1, R2-4 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A5, D3 |
| Confident presenting to senior leaders | B3, F2, K2 |
| Comfortable with Excel reporting | A4, F1 |

Every published value has at least one question: Members First, Always (C1, H1); Plain Words (D4, H2); Neighbours, Not Numbers (H3, K1); Own the Fix (C2, D3, H4). No headline figure appears in your material, so no defend-the-number question was written.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation, not words for you: your material says the branch's formal complaints log, not the process end to end. Slots stay inside the log |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." The material says new tellers and the script, not supervisors or coaching |
| Reported complaint volumes and resolution times to leaders | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The material says built, not what it counted or who it was reported to |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope: "I handled the branch's formal complaints log." The material says formal log, not what governed it |
| Has contact-centre experience | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description; the four published values, as you pasted them (copied 12 October 2026 from ashgrovecu.org/about/values, not fetched); the recruiter's email on the process; the four strategy lines from the 2026 brief; your background, as you described it in your message. No searches or fetches were sent, and no dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted is in hand and fixes the cheat sheet and every VAL question |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email gives the rounds, durations, who runs each and the values round; it fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The four brief lines you passed on fix the CO questions; a news sweep could add recent context, offered in the upgrade menu |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer has been named, so there was no query to form |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read from their public professional footprint, persona weights per panel member, and a reverse question tied to their path
- The recruiter's answer on the 20-minute case format (materials, preparation, whether you present) → I1 to I3 rebuilt around the real format
- Your answers to the slots in F1, F3, F4, F5, F6 and F8, stated in your own words → each entered into the fit snapshot verbatim, with the rows and bank cells that draw on them upgraded from answer slots to story maps
- Any figures from your complaints work, such as monthly volumes or resolution times, and what the spreadsheet counted → defend-the-number questions in round 2 and a firmer F3
- Whether the spreadsheet was in Excel → F4 from a discovery row to a grounded one
- Your CV → sentences for the 6-year line (F7) and a check that no row missed a stronger quote
- Hours available before 21 October → a prep triage schedule sized to your time
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a fuller grounding brief on Ashgrove's strategy and recent organisation context, and stronger CO and CASE questions
- A tuesday-dossier.md from the job-underwriter → verified evidence, per-area strategy limits and the objection to rehearse most, so this pack stops inferring them
