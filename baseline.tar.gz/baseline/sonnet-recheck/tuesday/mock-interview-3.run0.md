I'll read the playbook's reference files before building the pack.
I couldn't save the pack as a file because the write was denied, so the full pack is below. The four web searches were also denied. That means nothing here comes from Stripe's own materials. I had no JD, CV or interviewer details either, so this is a rehearsal worksheet and not a personalised script.

# Stripe — Product Operations Manager — Final-round interview pack

Interviewer(s): not given. Relationship to you: not given. I assumed a final round with a hiring-manager-type lead plus cross-functional and peer sessions, because "final round" doesn't say how many sessions you face or who runs them.

## How to use this pack

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script. Nothing here says what you did, because I haven't seen what you did. Every answer you rehearse should come from your own experience, in your own words.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

This is the worksheet variant. The requirements are role-family patterns in plain prose, not quotes from a Stripe posting. Send your own sentences and the rows regenerate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional launches or programs across product, engineering, go-to-market and support (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is one named launch or program, who was involved, and your exact part in it. Selection scaffold: pick one where you can state the stake, your role and the outcome without rounding up; if no such program comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F2 | Design and run an operating cadence: planning, reviews, launch checklists (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, and whether teams kept using it. Selection scaffold: pick a process where you can say what it replaced and whether it stuck; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start |
| F3 | Metrics, reporting and diagnosing why a product or launch is under plan (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain end to end: how it was counted, what it is sensitive to, which part was yours. Selection scaffold: pick one number you could defend to a skeptic; if you do not know how a figure was counted, say so plainly, then give the nearest thing your material does carry, or how you would find out |
| F4 | Influence senior stakeholders and teams you do not manage (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a moment you changed a decision without authority, and what you conceded. Selection scaffold: pick a time with a named stake and an intact relationship afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F5 | Bring customer and field feedback into product decisions (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a case where user or field signal moved a priority. Selection scaffold: pick one where the signal and the decision are both nameable; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build the loop |
| F6 | Get up to speed fast on an unfamiliar product area or domain (role family, no posting) | none given | none | [generic] | discovery | Strong evidence is a ramp you can describe step by step, and what you got wrong early. Selection scaffold: pick a ramp where you can say what you did in the first month; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would ramp here |

## Persona table

The loop isn't established, so the fallback is the Generic archetype (screen, hiring manager, panel) with flat weights. Relationship priors are blended from the three session types I assumed. Counter-strategies are rehearsal methods, not claims about you.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems on launches, adoption, process | High: hiring-manager prior | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Probes gaps and why-this-role, why-now | High: hiring-manager prior; home of the highest-ROI item | Rehearse the most predictable objection until it's boring; calibrated candor |
| Values / Behavioral (C) | Scenario probes, STAR-shaped stories | Medium: cross-functional prior; no values round is established, so no cheat sheet | One story per theme, only from what happened; "we" for context, "I" for contribution |
| Data-Driven Prober (D) | Walks a number back to its assumptions | Medium: peer prior | Know how each figure was counted; name the weakest assumption first |
| Peer Evaluator (E) | Seams between teams, credit, disagreement | Medium: peer prior | Reciprocity framing; propose seam principles, not a made-up seam |
| Pressure (G) | Interrupts, time-boxes, tests composure | Low: only a skip-level prior, and none is established | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (H) | Friendly openers that are still scored | Low weight, but a likely opener | A 90-second arc; treat casual questions as scored |

## Question banks

Every row is `[generic]`. No candidate sentence and no researched company fact stands behind any of them. They become `[grounded]` as you add your CV, the JD and research. Questions about your past ask you to choose an instance, and none presumes an event.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team is about to ship a significant change that touches sales, support and engineering in several regions. Sketch the plan for the launch. What do you need to know first?" | CASE | [generic] | Clarify first: what is changing, for whom, what a good launch looks like. Then segment the affected groups, sequence the work, name the metrics and the top two risks. Think aloud and challenge one premise, such as whether one plan fits every region. It claims nothing about your past | F1's requirement as a live problem. CASE because it scores structure over the "right" answer |
| A2 | "Adoption of a feature shipped three weeks ago is 20% below plan. Diagnose it." | CASE | [generic] | Define the metric and its source, check instrumentation before believing the drop, segment by user type and region, look at the funnel, add qualitative signal, rank hypotheses, say what you'd do in week one, and what would change your mind | F3 as a live problem; diagnosis is the daily work of the function |
| A3 | "Three product teams each run their own planning cadence and launch checklist. You're asked to make this less chaotic without slowing anyone down. Where do you start?" | CASE | [generic] | Ask what chaotic costs and who feels it. Listen to each team before proposing a standard, propose a minimal shared core, pilot with one team, decide how you'd tell whether it was adopted. Challenge the premise that standardising is the right fix | F2 as a live problem. Scores whether you diagnose before prescribing |
| A4 | "What would you want to understand about our users and our business in your first thirty days, and where would you look?" | CO | [generic] | Structure by source: public materials, the product itself, internal documents, one-to-ones with product, engineering, go-to-market and support. Keep it a plan. Replace the generic sources with named ones once you've done your own research | F6's requirement. Generic by necessity, since research didn't run |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI rehearsal in this pack.** Choose a real weak area from F1 to F6, not a disguised strength. Say it plainly, say what you'd do in the first thirty days to close it, and who you'd ask. Expect three follow-up levels: how do you know that's weakest, what if the team needs it from day one, why not someone stronger there. Hold through the first two by returning to your plan, then concede specifically what is true. Selection scaffold: if no honest weakness comes to mind, say so plainly, then name the requirement where you have least direct experience and the nearest thing your material carries, or how you'd handle it | Some form of this is close to certain, and every snapshot row is open. It sharpens a lot once your CV arrives |
| B2 | "What does product operations add that a strong PM couldn't do alone?" | JD | [generic] | Argue from principles: what the function takes off PMs, makes consistent, makes visible. Don't claim ownership of product decisions the role doesn't hold. Hold your position, and concede where a strong PM really could do it | F2 and F4 meet here. Scores whether you understand the role's boundary |
| B3 | "Why product operations, why this company, why now?" | CO | [generic] | Three short parts, each from your own real reasons. The company part must come from research you do, not from this pack. Selection scaffold: if "why now" has no strong story, say so plainly and give the true reason | The standard motivation probe. "Why here" is homework |
| B4 | "What would make you leave this role within a year?" | JD | [generic] | Name an honest condition, such as lack of scope or access to decisions, without ultimatum framing. Keep it consistent with B3 | Consistency check against B3 |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said it anyway, a result you can state, and an intact relationship afterwards. "We" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | F4's requirement. Standard Values-persona prompt |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an instance where the customer cost and the metric cost are both nameable. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | F5's requirement. Standard Values-persona prompt |
| C3 | "Your data says a launch the whole team is proud of isn't working. How and when do you say so, and to whom?" | VAL | [generic] | A live judgement, so no past is claimed. Cover what you check before speaking, who hears it first, how you frame it as a question about the plan and not the people, and what you propose next | F3 and F4 together. Scores candor under social cost |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Choose one number from your work that you'd put on a slide. Walk me through how it was counted, and which assumption behind it you'd defend least." | EXP | [generic] | Selection scaffold: pick a figure you can explain fully. Cover how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours, in your own words. If you don't know how a figure was counted, say so plainly, then give the nearest thing your material does carry, or how you'd find out | F3's requirement. Becomes a sharper defend-the-number row once your CV supplies figures |
| D2 | "A weekly product dashboard shows two different numbers for the same metric from two sources. What do you do?" | CASE | [generic] | Establish definitions and time windows first, trace each source, find the first point of divergence, agree one source of truth with the owners, and say how you'd stop it recurring | F3 as a live problem |
| D3 | "How would you decide which metrics a product team reviews weekly and which quarterly?" | JD | [generic] | Tie each metric to a decision it informs and how fast it can move. Name criteria, not a list of metrics. Say what you'd cut | F3 and F2 |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a pretended seam: who decides, who's consulted, who's informed, how disagreements escalate. Offer what you bring their team, not only what you need | F4 and F1. Standard Peer-persona prompt |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle first. If you use an example, it must be one where you can say exactly which part was yours. If no example comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | F4. Standard Peer-persona prompt |
| E3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity: two or three specific, small asks, and one thing you could take off their plate early | F6 and F4. The reciprocity question for peer rounds |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Hold-then-concede. Pause, restate, give one position you can back with a specific from your own material, hold it through two follow-ups, then concede what's genuinely true about the internal candidate. This pack can't supply the position, since it holds nothing about you. If nothing specific comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Standard Pressure-persona prompt; tests composure more than content |
| G2 | "Pick a result you're proud of. How much of it was actually you?" | EXP | [generic] | Pause, then split it cleanly into what you did, what you influenced and what others did. Hold the split through two follow-ups. If your honest share is smaller than you hoped, say so, because the question exists to catch inflation. If you can't split it, say so plainly and describe your part | The attribution probe |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the two or three moves that mattered, and why this role is next. Each beat is only what happened, and each move gets its real reason. If you can't name the reason for a move, say so and don't invent one | Casual, still scored |
| H2 | "What have you been reading or trying out lately that changed how you think about running product teams?" | CO | [generic] | Pick one real thing, and say what changed in your thinking and what you did differently. If nothing comes to mind, say so plainly and name the closest thing you follow | Casual questions about hot topics are scored; probes curiosity |

## Requirement coverage

There was no JD, so these are the role-family rows above, not a posting's own list.

| Requirement | Covered by |
|---|---|
| F1 | A1, E1 |
| F2 | A3, B2, D3 |
| F3 | A2, C3, D1, D2, D3 |
| F4 | B2, C1, C3, E1, E2, E3, G1 |
| F5 | C2 |
| F6 | A4, E3 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What does a great first ninety days look like for this role, and what would make it a miss?" | Shows you plan to be measured and surfaces the real success bar |
| 2 | "Which product decision recently got stuck, and what would have unstuck it?" | Gets the interviewer describing the problem this function exists to solve |
| 3 | "How do product teams currently learn about each other's launches, and what isn't working about it?" | Probes F2 and F1 from the other side and invites a candid answer |
| 4 | "Where does this role end and the product managers' work begin?" | Tests the seam directly and shows you care about boundaries, not turf |
| 5 | "What did you hope to find in the person for this role that previous candidates didn't show?" | Surfaces the real remaining concern while you can still address it |
| 6 | "What has surprised you most about how this team works since you joined?" | A personal question signals curiosity about people |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past experience, scope, metrics, title or outcomes | No candidate material was supplied, so there is no sentence to quote and none to inflate or contradict | Selection scaffolds and answer slots only. Once you send a CV, entries are built against its sentences |
| Any fact about Stripe: its values, products, interview loop or strategy | Research didn't run, and these facts are not taken from memory | Use only what you read yourself; the upgrade menu says what research would add |

## Sources

Provided documents: none. Dossier: none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query | Result |
|---|---|
| Stripe operating principles values | refused |
| Stripe interview process Product Operations Manager | refused |
| Stripe strategy 2026 news priorities | refused |
| Stripe Product Operations Manager job description | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. Would have supplied official value names and themed the VAL bank |
| 2. Stripe interview process, product operations | unavailable | Search refused. Would have established the loop and moved persona weights |
| 3. Stripe strategy and recent news | unavailable | Search refused. Would have grounded A4, B3 and H2 as real CO and CASE questions |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have turned the F rows into quoted `[inferred]` requirements |

## Upgrade menu

- The job description text → the F rows become quoted `[grounded]` requirements, and every JD question gets a real hook
- Your CV, or a few of your own sentences about the work → the fit snapshot fills, D1 and G2 become defend-the-number rows, and the prohibited list is built against your actual wording
- The round structure and who you meet → persona weights stop being flat, and the banks re-sort
- Interviewer names → an interviewer read, personalised weights, and a reverse question tied to their path
- The recruiter's prep email or any stated focus areas → coverage of any declared case, deliverable or topic
- Permission to run web searches → Stripe's published values, documented loop and current strategy, which ground the CO and CASE rows and show whether a values cheat sheet applies
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief, interviewer footprint, loop reports and recent org context
- A tuesday-dossier.md from an earlier session → verified evidence and agreed limits, which would replace the scaffolds with story maps

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also record the gaps this prep exposed in a tuesday-dossier.md for later sessions, once I have write access.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and in what format: future manager, peer, cross-functional or skip-level, and has the recruiter named any focus areas or a case or presentation to prepare? The answer reweights every bank.
2. Can you paste the job description and your CV, or tell me to proceed without them? Either one turns the rows above from `[generic]` into `[grounded]`.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.