## Decision snapshot

**Yes, apply, as long as the working pattern checks out. Status: `conditional_go`.** The condition is R1. Your JD says "Fully remote (UK)", but the Brindlemoor careers page says "Leeds office four days a week".

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important`: adjacent: R8 (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain)

R6b is unclear because your "maintained" doesn't yet show monitoring. R8 and R10 are adjacent with their limits named. R1 is the open gate.

**Opportunity ledger.** The role is live under a Director of Pricing with a pricing-analytics background (RR4). Against that, the JD and the careers page conflict on working pattern (RR1), no salary is stated (RR2), and no first-year outcomes are stated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed and acceptable to you (R1, RR1); (2) you can evidence monitoring of a rating model (R6b, G1); (3) the pet-insurance gap is framed honestly as adjacent (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the careers page lists this role as accepting applications | `[grounded]` JD header; careers page fetched |
| Mandate | "Own pricing analytics for our pet-insurance product"; build and monitor rating models, design and read price tests, make recommendations to underwriting and product | `[grounded]` JD; careers page repeats the first line |
| Reports to | The Director of Pricing (Odile Varga) | `[grounded]` careers page; JD |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". Which is current is unknown | `[grounded]` both quoted |
| People management | The JD text you gave lists no management duty, and the careers page excerpt mentions none | `[grounded]` JD and careers page |
| Scope read | A single-product pricing-analytics post. The first-year outcomes are not stated | `[inferred]` from the JD's mandate lines against its silence on outcomes |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). This is a market band, never Brindlemoor's offer, and your pay floor wasn't given | `[generic]` Pricewell 2026 survey, search snippet only, page not fetched |
| Hiring manager | Director of Pricing; spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, search snippet |
| Unknowns | Salary; first-year outcomes; whether the role is remote or Leeds-based; team size | — |
| Contradictions | JD against careers page on working pattern (RR1) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have stated no working-pattern constraint, so there is no confirmed statement to grade. Fit is `unclear` because the JD and the careers page disagree | `[grounded]` JD and careers page quoted | Closing question on R1; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years' pricing analytics at a UK motor insurer, the last two as senior analyst. Self-reported, nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", confirmed in your words but no artifact | `[grounded]` your background | Upgrade menu: a code sample or a sanitized notebook |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Medium until an inspectable artifact exists | `[grounded]` your background | Upgrade menu: sanitized model documentation |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial leads" | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4, read against the "build" half of "build and monitor rating models" | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". That may include monitoring but doesn't establish it, so it is low rather than none | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | Closing question G1 |
| R7 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year, run with the underwriting team | `[grounded]` your background | Upgrade menu: a sanitized test readout |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | The underwriting side is covered by your quarterly review. Nothing you gave touches product | `[grounded]` your background; JD wording | Closing question G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (your concern; the JD asks only for "insurance experience a plus") | preferred | adjacent | medium | transferability | Motor pricing carries over in method (GLM, price tests). Limit: you have not worked on pet insurance, so no pet-specific pricing work is shown | `[inferred]` method carry-over; `[grounded]` the limit, in your words | Bridge case in the plan, A3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" the GLM model, with no detail on monitoring | A must-have at `unclear`. The JD names monitoring explicitly, and resolving it removes the main open fit question | Tracking actual against expected loss ratios; watching for drift in the young-driver book; deciding when to refit; a monthly or quarterly model-health report | A monitoring pack, a dashboard screenshot, or a model-review paper | `[grounded]` JD names monitoring; `[grounded]` CV-equivalent silence on it |
| G2 | Recommendations to product (R8, important) | discovery | Underwriting recommendations are evidenced; product ones are not | `important` tier, so it can sharpen the application and won't decide it | A price-test result that changed a product feature or a rating factor; a proposal taken to a product or commercial owner | A test readout or a review-deck extract | `[grounded]` your background silent on product |
| G3 | Pet-insurance domain (R10, preferred) | transferability | Strong adjacent method, no pet work | `preferred`, so it is a stated limit and not a blocker. It is framed in A3 | Any pet, small-animal or other low-frequency, high-severity line you've touched; breed, age or vet-cost analysis in a side project | A short note or analysis on pet claims data | `[inferred]` bridge from method; `[grounded]` limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the arrangement may have changed. If you need remote, this fails the gate | `[inferred]` from the two quoted sources conflicting | Is this role fully remote, or four days a week in Leeds, and which is current? | unresolved |
| RR2 | Salary not stated | unknown | — | JD gives no figure; careers page excerpt gives none | It may sit inside the market band or outside it. Not knowable from what's published | `[inferred]` from silence; `[generic]` band for comparison | What is the salary range for this post? | unresolved |
| RR3 | First-year outcomes not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | A broad ownership mandate with no stated success measures | `[inferred]` from the JD's scope line against its silence on outcomes | What would success look like in the first year? | unresolved |
| RR4 | Reports to a Director of Pricing with a pricing-analytics background | positive_signal | — | Careers page: "reports to the Director of Pricing" | Your work would be read by someone who has led pricing analytics | `[grounded]` careers page; public profile snippet | How are rating models monitored today, and what would you want from this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Odile Varga before investing in the application | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead the application with the GLM rating model, the 14 price tests and the quarterly review, in your own words as you gave them. Add no new claims | See R4, R6a, R7, R5 | `[grounded]` your background | pending your approval |
| A3 | State plainly that your pricing work is motor and you haven't worked on pet insurance, then make the case that GLM and price-test method carry over. Don't present it as pet expertise | See R10, G3 | `[inferred]` carry-over; `[grounded]` your wording | pending your approval |
| A4 | Look up Odile Varga's 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", if it is published, and prepare a monitoring example only if G1 confirms one | See R6b | `[grounded]` talk title from profile snippet | pending your approval |
| A5 | Ask RR2 and RR3's questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at intake, so it sits at `medium` at best until you share an inspectable artifact.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirms the posting is live and surfaced the working-pattern contradiction (R1, RR1). The page text is one line, so it says nothing on company size or stage |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. It set the market calibration row and RR2's comparison |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. It fed the hiring-manager row, RR4 and A4 |

I can offer one more step, labeled as an extra: a short, truthful draft of your lead paragraph, built only from your own sentences. I'd produce it only on your approval.

I can save all of this as `tuesday-dossier.md` if you'd like to keep it or reuse it later.

**Upgrade menu**
- A sanitized rating-model monitoring pack, model documentation or a drift report → R4 and R6b can rise toward `high`.
- A sanitized price-test readout or the quarterly review deck → R7 and R5 can rise toward `high`, and G2 may resolve.
- A code sample or notebook → R3 can rise toward `high`.
- Whether remote working is a requirement for you → R1 resolves, and the decision moves to `go` or `no_go`.
- Your pay floor → RR2 can be set against the market band.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) → only if you say the word.

**Questions**

R1 — Is remote working a requirement for you, or would four days a week in Leeds work? Either answer settles the gate.

G1 — After your young-driver GLM went live, who watched how it performed, and what did you personally do: actual-versus-expected tracking, drift checks, refit decisions?

G2 — Did any price-test result you ran go beyond underwriting, for example to a product owner or a commercial lead? If so, what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.