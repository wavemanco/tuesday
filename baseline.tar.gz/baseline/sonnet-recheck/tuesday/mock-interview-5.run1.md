Shell loops are blocked here, so I'll read the files directly.
I couldn't save the pack as a file because write permission was denied, and web searches were refused earlier. So the full pack is below, built from your message and the recruiter's email alone. I haven't seen the market report, a job posting or a CV.

# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** 60-minute panel with Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your spoken POV on operator partnerships over the next 18 months, ending on what it means for the operators. The rest is Q&A, where Ross will push on commercials.

I built it as a panel, treating Deepa as the hiring manager and Ross as the commercial voice. That reading comes from the recruiter's email only.

## How to use this pack

Personas describe how a question is asked. Types describe what is scored: VAL (values in past behavior), EXP (whether your background claims survive scrutiny), JD (can you do the listed job, gaps included), CO (company and strategy knowledge), CASE (a live problem from the role). Guidance is scaffolding, not a script. Say only what you actually did, in your own words.

## Prep triage (four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Build the POV: pick the spine thesis, write the beats, choose one report item to agree with and one to diverge from | Graded deliverable, A3 |
| 2 | 45 min | Say the POV aloud twice, timed to 12 to 13 minutes, ending on the operator sentence | Graded deliverable |
| 3 | 45 min | Rehearse the rail-gap objection and both follow-ups until it is boring | B1, D1, B3 |
| 4 | 30 min | Defend the numbers and the no-quota answer, aloud, to a second question | C1, C2, D2 |
| 5 | 30 min | Your 90-second arc and the reverse questions | E1, reverse questions |
| 6 | 30 min | One full run-through of 15 minutes of POV plus six questions, ideally with another person | Whole pack |

The highest-ROI prep is B1, the "you haven't sold into rail" question. C2, the no-direct-quota answer, is a close second because of Ross. Everything else is insurance.

## Fit snapshot

No job posting was supplied. Requirements come from the recruiter's words (quoted) or are role-family prose (unquoted, `[generic]`). Every evidence cell is your own wording.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Please land on what it means for the operators themselves", and operator partnerships generally. Recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, from the consulting side. It doesn't say train operating companies, or from inside an operator. Words: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: the recruiter's operator framing makes a probe on how far that carries to train operators likely. Say which part of that work is closest, in your own words. If none of it is, say so plainly and stay with bus and light rail |
| F2 | Build and grow a partner channel (role-family, no posting) | "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No wording gap, but nothing is inspected behind it, so expect a probe. Lead in the quote's terms: you ran the ISV channel for the last four years and it went from 6 partners to 40. The £4M is influenced revenue, not tied to the partners or to a year. Your material doesn't show how partners were counted or what "influenced" covers (C1 and C2) |
| F3 | Revenue accountability, a direct number (role-family). Recruiter: "Ross will push on commercials" | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you'd want to be measured here, said as a plan. Nothing added to make the gap feel smaller |
| F4 | Selling into rail operators (role-family) | "Never sold into rail specifically" — your message | none | [grounded] | capability | Your own statement. Words: "I've never sold into rail specifically." Then how you'd learn it, as a plan. Never softened by the operator knowledge in F1 |
| F5 | Enough scheduling-software fluency to talk credibly with operators (role-family; the company description is yours: "they sell scheduling software to train operating companies") | "bus and light rail network planning" — your message | low | [inferred] | discovery | Network planning touches this without showing it reaches scheduling software, and you've stated no absence. No source names the requirement, so there is no answer slot. Selection scaffold: pick the part of your planning work closest to how services get scheduled. If none comes to mind, say so plainly, then say what you'd learn first |

## Graded deliverable: the 15-minute POV

The market report is equally available to both interviewers, and probably to other candidates. Differentiate from it rather than reciting it.

**Facts to build on** (fit-snapshot row, your exact words):
- F2: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F1: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- Limits to concede, F3 and F4: "never carried a direct quota, only influenced revenue" and "Never sold into rail specifically"

**Three theses.** These are shapes derived from the brief and your background `[inferred]`, not from Kelverton's data. All are pending your approval.

| Thesis | What it means for operators | Mandatory concession |
|---|---|---|
| T1: Build partnerships around outcomes each operator would itself measure, agreed operator by operator | An operator can point to one change it would notice | You're outside-in and haven't seen Kelverton's partner data, so this is a hypothesis to test in the first 90 days |
| T2: Scale through repetition: a common path for how an operator starts and grows with Kelverton | A predictable way in and a predictable next step | Your quote shows a partner count grew, not that the path was repeatable. If the number of operators is small, depth beats repetition, and you'd need the account list to know |
| T3: Earn the right first: the opening months are listening and fixing before any growth commitment | Operators are heard before they're sold to | Least distinctive, and can sound like avoiding commitment unless it has dates and a decision point |

**Recommended shape:** T1 as the spine, T3 as the sequencing for months 1 to 6, and T2 only if the report gives you a reason.

**Differentiating from the report.** Bring one consensus item from the report to prove grounding, then one divergence you actually hold, with reasons. Slot: name the report item and the divergence in your own words. If you agree throughout, say so and spend the time on sequencing.

**Anti-pick (optional).** The role's real job includes saying no. One option is that you wouldn't set a partner-count target in year one. It echoes your 6 to 40, so expect Ross to push. The reply is to pair any count with an operator-outcome measure. Take it only if you believe it.

**The requested close.** End on: "By month 18, an operator should be able to say: ______." Fill the blank from T1, with something an operator would notice rather than something Kelverton would count.

**Run-sheet (about 14 minutes):**
- 1 min: stance, outside-in, with your assumptions named
- 3 min: what you take from the report, the consensus item then your divergence
- 5 min: spine thesis and what changes for operators
- 2 min: sequencing with the concession said aloud
- 1 min: anti-pick
- 2 min: operator close

## Reading the interviewers

This comes from the recruiter's email only. No public footprint was researched.

| Interviewer | What the email says | Implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" | She scores the POV as the person who'd manage you, so judgment about operators matters more than polish | [inferred] |
| Ross | "Commercial Director"; "Ross will push on commercials" | Expect F2's numbers and F3's no-quota fact to be probed from his side. Answer in the quotes' terms and say what you don't know | [inferred] |
| Both | "Please land on what it means for the operators themselves" | It's the one thing they asked for by name, so make it the last thing you say | [grounded] |

## Persona table

The loop is established by the recruiter's email: one 60-minute session, a spoken POV, then Q&A. No values-style round is documented, so there is no values cheat sheet. The Peer Evaluator has no bank, because neither panelist is a peer on the team.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live questions on your POV | High: the opening is a graded case and Deepa is the hiring manager | Clarify, structure, answer; think aloud; challenge one premise respectfully |
| Skeptic (B) | Probing the rail gap and the move from payments | High: F3 and F4 are what a manager derisks | Rehearse the likeliest objection until boring; bridge only from what you stated, with the limit said plainly |
| Data-Driven Prober (C) | Ross on influenced revenue and 6 to 40 | Medium: the recruiter named commercials | Know what you can and can't say about how each number was counted, and say so when you don't know |
| Pressure (D) | Time-boxed challenges | Medium: a Commercial Director pushing on stated gaps | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (E) | The opener, why Kelverton | Low: common but lightly weighted here | A 90-second arc; treat casual questions as scored |
| Values/Behavioral (F) | Partner-facing integrity scenarios | Low: no values round documented | Selection scaffold ending in the honest branch |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months, and what do you need to know first?" | CASE | [grounded] the recruiter's "present a short POV on where you'd take our operator partnerships over the next 18 months" | This is the deliverable; build it from the section above. Open with the one thing you need to know and say what you're assuming around it. No claim about your past | Announced by the recruiter, so certain in some form; CASE |
| A2 | "If you could start with only one operator, how would you choose?" | CASE | [generic] | Name your criteria before the operator, say what you'd ask them first, and say what would change your mind | A manager testing prioritization; CASE |
| A3 | "You've read the market report our strategy team circulated. Where do you disagree with it?" | CO | [grounded] "which I've read" | Consensus item first, then one divergence with reasons. Answer slot: name both in your own words. If you agree throughout, say so and say where you'd sequence differently. Don't recite the report | It's their report, so reciting scores as homework and departing with reasons scores as judgment |
| A4 | "An operator tells you the partnership isn't delivering anything they can see. What do you do in the first week?" | CASE | [generic] | Clarify what they'd count as delivery, agree one visible thing and a date, and say what you wouldn't promise | The operator-side close makes this a likely live test |
| A5 | "What would you not do in your first six months?" | CASE | [generic] | Use the anti-pick if you hold it, defend it, and say what evidence would change your mind | The role includes saying no; also JD content |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. Why should we believe you can build operator partnerships here?" | JD | [grounded] "Never sold into rail specifically" and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **Highest-ROI rehearsal.** Open with the acknowledgment: "I've never sold into rail specifically." Then the quote at its scope: "I spent five years in transport consulting, on bus and light rail network planning." Answer slot: if pressed on how far that carries to train operators, say which part is closest, in your own words. If none is, say so plainly and stay with bus and light rail. Follow-up 1, "bus and light rail aren't train operators": concede that your planning work was bus and light rail, then return to your plan for learning the rest. Follow-up 2, "what could you do in month three that a rail hire couldn't": name one thing you'd bring and say how you'd test it with operators rather than assert it works. Hold by returning to the quote, never by adding to it | F4 and F1 are where the role presses hardest; JD |
| B2 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Your reasons are yours; the pack can't supply them. Your material carries "5 years in transport consulting" and "9 years in partnerships" and not why you moved. Scaffold: give the true reason in one sentence and tie it to something you said you did. If no clean reason comes to mind, say so and give the nearest honest one | Motivation consistency is what the Skeptic scores |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" and "never carried a direct quota, only influenced revenue" | Choose from the gaps you've stated and name one plainly before they do, then your 90-day plan, said as a plan. Don't disguise a strength as a weakness | Persona stem; F3 and F4 make it predictable |
| B4 | "Your last four years were on an ISV channel, and operators aren't ISVs. What transfers, and what doesn't?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Beats are the quote's: the last four years, the ISV channel. Frame what transfers as hypotheses about operators, not things done with operators. Answer slot: if some part transfers, say what it was, in your own words, and what you'd check first. If none does, say so | The second obvious seam after rail itself |
| B5 | "How do you earn credibility with operators who've spent their careers in rail?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Start from what you have and its limit, then the plan: listen first, name what you don't know, bring evidence rather than assertion | F1's seam, in operator-facing packaging |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say roughly £4M of influenced revenue. Walk me through how that number was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say it in the quote's terms. Answer slots, each in your own words: how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours. Where you don't know how it was counted, say so. Never turn "influenced" into "sourced" or "closed", and keep the £4M off the 40 partners and off any year | F2 holds the headline figure; EXP |
| C2 | "What's the difference between influenced revenue and revenue you were accountable for?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Open with: "I've never carried a direct quota, only influenced revenue." Hold it there. If pressed on what "influenced" covered, say how it was defined where you worked, in your own words, or that you don't know how it was set. Then, as a plan, how you'd want to be measured here | F3 plus Ross's commercial push |
| C3 | "Suppose we gave you a partner-sourced revenue number for year one. How would you set the target, and who would own it?" | CASE | [generic] | Define terms first, since sourced, influenced and owned differ, and say which you'd be accountable for. Then work back from pipeline, name what lags, and say who shares the number. No claim about your past | A commercial case in Ross's register |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who's sold into rail?" | JD | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" and "Never sold into rail specifically" | Hold only what the quotes carry: the ISV channel went from 6 partners to 40, and you did five years of bus and light rail network planning. Concede in the first breath that you haven't sold into rail. Hold through two follow-ups by returning to the quotes | B1's seam, delivered at speed |
| D2 | "That growth from six partners to forty. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate. Hold the quote at its scope: you took it from 6 to 40. Answer slot: say which parts were yours and which were others', in your own words. If you don't know the split, say so. Never upgrade "took it" to "built" or "owned" | Attribution probes exist to catch inflation |
| D3 | "You're proposing a roadmap for an industry you haven't worked in. Isn't that presumptuous?" | JD | [grounded] "Never sold into rail specifically" | Hold: a POV was requested, and you framed it as outside-in with stated assumptions. Concede the limit in the quote's words and ask which assumptions they'd change first | The POV format invites this |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships, last 4 at a payments company running the ISV channel" and "took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc of only what the quotes state: five years in transport consulting on bus and light rail network planning, nine in partnerships, the last four running the ISV channel as it went from 6 partners to 40. Observation: the five partnership years before the payments company aren't in your material. Say what they were in your own words, or leave them out | Casual but scored |
| E2 | "What drew you to Kelverton?" | CO | [generic] | Your reasons are yours. Scaffold: one reason about the customers, one about the role, and one thing you took from the report you read. If nothing specific comes to mind, say so and give the nearest honest reason | The likeliest place F5's product side surfaces |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to a partner." | VAL | [generic] | Choose a time with a named stake, a moment you didn't soften it, and a relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Persona stem; generic because no values page is in hand |
| F2 | "When did you put a partner's interest ahead of an internal metric?" | VAL | [generic] | Same scaffold: a named decision, what it cost, what the partner did afterward. If none comes to mind, say how you'd weigh the two | Fits the operator-first close of your POV |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| POV on operator partnerships over 18 months | A1, A2, A3, A5, deliverable section |
| Land on what it means for operators | A1, A4, deliverable section |
| Commercials (Ross) | C1, C2, C3, D2 |
| F1: operator-world credibility | B1, B5, D1, E1 |
| F2: partner channel | B4, C1, D2, E1 |
| F3: revenue accountability | B3, C2, C3 |
| F4: rail selling | B1, B3, D1, D3 |
| F5: scheduling-software fluency | E2 only. No posting names it, so a fuller question waits on the posting |

## Reverse questions

No interviewer profile exists, so none is tied to a personal path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which operators and what kind of relationship do you mean?" | Shows you structure before pitching. Best asked early as a clarifier |
| R2 | "What would tell you in month six that this hire is working?" | Turns the 18-month frame into a measure |
| R3 | "How is the partnerships number set, and how much is attributed to partnerships rather than sales?" | For Ross. Makes your no-direct-quota fact a shared discussion instead of a probe |
| R4 | "What did the market report get least right, in your view?" | Treats the report as a conversation |
| R5 | "What's hardest about the operator relationship today, from your side?" | Gets the real problem your POV should address |
| R6 | "Where would you most want this hire to take work off your plate?" | For Deepa. Makes the working relationship concrete |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F4 | "I've never sold into rail specifically." No slot |
| Has carried a quota or owned revenue | Negative you stated, F3 | "I've never carried a direct quota, only influenced revenue." No slot |
| Has worked with or for train operating companies, or knows operators from inside | Inflated form of F1 | F1's quote at its scope. The pack's observation: your material says bus and light rail network planning, from the consulting side |
| Built or owned the ISV channel | Inflated form of F2 | F2's quote: ran the channel, took it from 6 partners to 40. The pack's observation: your material doesn't show how partners were counted or which parts were yours |
| £4M of revenue won, sourced or closed | Inflated form of F2 | "Roughly £4M of influenced revenue", attached to that noun, not to the partners or a year |

## Sources

Provided: your message, including the recruiter's email as you quoted it. Named but not in hand: the market report, the job posting, a CV. No dossier was consumed.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

Every search was refused: Kelverton Rail company values; Kelverton Rail interview process partnerships manager; Kelverton Rail strategy train operating companies scheduling software news; Deepa VP Partnerships Kelverton Rail; Ross Commercial Director Kelverton Rail; Senior Partnerships Manager Kelverton Rail job description.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | VAL questions; no values-style round is documented, so no cheat sheet either way |
| 2. Interview process, partnerships | unavailable | Loop confirmation; the recruiter's email already fixes this session |
| 3. Strategy and recent news | unavailable | A grounding brief and sharper CO questions; CO items are generic or rest on the report you read |
| 4. Deepa and Ross | unavailable | The interviewer read and a path-tied reverse question |
| 5. Representative posting | unavailable | Quoted requirements for the JD-tagged rows; they are labeled role-family instead |

## Upgrade menu

- The job posting text → F2 to F5 gain quoted requirements, JD-tagged questions become `[grounded]`, and F5 can gain a question
- The market report's headline findings, pasted → A3 and the POV differentiation name a real consensus item and divergence, and a grounding brief becomes possible
- What your five partnership years before the payments company were → E1 and B4 gain a quoted beat
- How "influenced revenue" was defined and counted, in your words → C1 and C2 gain quoted answers, and F2 and F3 can be re-graded
- Search access → values, strategy, loop and interviewer rows move from unavailable to researched
- Surnames for Deepa and Ross → the interviewer read can use public professional footprint
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and sharper prohibited claims

Say the word and I'll play the Skeptic on B1, the question the pack names as highest-ROI.
I can also record the gaps this prep exposed in a `tuesday-dossier.md` for later sessions.
Once write access is granted, I can save this as a file, or as a Word document if you prefer.

1. Can you paste the job posting, if you have it?
2. Can you paste the market report's headline findings? A3 and the POV's differentiation are currently running without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.