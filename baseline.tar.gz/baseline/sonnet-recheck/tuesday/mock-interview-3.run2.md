I'm building your Stripe prep pack. So far I've read the playbook and its rules. Next I'll read the remaining conventions, then run the Stripe research.
Web search wasn't permitted, so I'm building the pack from what you've told me and labeling everything that would have come from research. Saving it now.
I couldn't save the pack as a file because write permission was denied. Web search was also denied, so I've put the pack below, built without research and without your CV or the job description. I've labeled everything accordingly, and the first thing to do is **B1**. I assumed a final round with an unknown interviewer, and the pack is the starting version.

## Interview pack: Product Operations Manager, Stripe

**Reading the labels.** `[generic]` marks a role-family pattern with no claim about you or Stripe. Guidance is scaffolding, so say it in your own words and only about what you actually did.

**Question types:**
- **VAL** scores values.
- **EXP** scores whether your claims hold up.
- **JD** scores whether you can do the job.
- **CO** scores company homework.
- **CASE** scores a live problem.

### Fit snapshot (worksheet)

I had no CV and no JD, so every evidence cell is `none given`. The requirements are role-family patterns, not quotes from a Stripe posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Coordinate cross-functional launches and changes (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one launch you can narrate end to end. Pick one with a contested decision. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R2 | Define and track operating metrics (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain: how it was counted, what it is sensitive to, which part was yours. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R3 | Run planning and operating cadences (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a recurring process you ran or changed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R4 | Influence partners without formal authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a disagreement you resolved without a reporting line. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R5 | Communicate decisions in writing and meetings (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a document others acted on. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| R6 | Improve processes and tooling as the org scales (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a before and after you can describe without inflating it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Persona weights

Nothing established Stripe's final-round loop, so I used the generic archetype and flat-ish weights. The weights below blend the hiring-manager, cross-functional and peer priors.

| Persona | Bank | Weight | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A | 4 | Clarify, structure, metrics, risks; think aloud |
| Skeptic | B | 4 | Rehearse the predictable objection until it's boring |
| Values / Behavioral | C | 3 | Pick stories where the hard truth landed |
| Peer Evaluator | D | 3 | Reciprocity; propose seam principles |
| Data-Driven Prober | E | 3 | Know how your numbers were counted |
| Conversational | F | 3 | 90-second arc; casual is still scored |
| Pressure | G | 2 | Pause, hold through two follow-ups, concede specifically |

### Question banks

All 22 questions are `[generic]`, and none presupposes anything about your past. **B1 is the highest-ROI rehearsal.** I inferred it from the role family, not from your material.

**A. Case / Strategist**
- **A1 (CASE):** "A product change is two weeks from launch and three teams disagree on whether it's ready. What do you do first?" Ask who decides and on what criteria, what the launch is for, and what each team fears. Then give options, risks and how you'd communicate the decision.
- **A2 (CASE):** "Adoption of a recently shipped feature is well below plan. Diagnose it." Clarify how adoption is counted, split by segment and funnel stage, form two or three hypotheses, and name the data that would separate them.
- **A3 (CASE):** "Design the operating rhythm for a growing product org. What do you keep, and what do you cut?" Start from the problem the rhythm solves. Give principles before artifacts, and say what you'd stop doing.
- **A4 (CO):** "Where could product operations add the most value at Stripe, and where could it get in the way?" Answer only from Stripe material you've personally read or used. Check Stripe's own pages before the interview, and don't assert facts you haven't verified.

**B. Skeptic**
- **B1 (JD):** "Which part of this role would you be weakest at on day one?" Name one real area from your own honest read, then a first-30-days plan, said as a plan and not as a past. If none comes to mind, say so plainly, then name the area where you've had the least practice. Hold through two follow-ups.
- **B2 (JD):** "Why product operations, and why now?" Give a three-beat arc in your own words, using only your real history.
- **B3 (CO):** "Why Stripe rather than another company?" Use only what you've actually read, used or heard. If you can't say yet, say what you're looking for and why it points here.
- **B4 (JD):** "Product ops can look like coordination without authority. What makes it more than project management?" Give your own definition. If an instance of yours fits, narrate it. If none does, say so plainly and answer as a principle.

**C. Values / Behavioral**
- **C1 (VAL):** "Tell me about a time you delivered an unpopular truth to leadership." Pick a time with a named stake, a moment you didn't fold, and an intact relationship afterward. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it.
- **C2 (VAL):** "When did you put a customer ahead of an internal metric?" Pick a decision with a visible tradeoff and say what you gave up. Use the same honest fallback as C1.
- **C3 (VAL):** "A principle you believe in conflicts with a deadline. How do you decide?" Walk through what's irreversible, who's affected and what can be staged. This question makes no claim about your past.

**D. Peer Evaluator**
- **D1 (JD):** "Where's the seam between product ops and product management, and what happens when we disagree?" Propose seam principles instead of claiming to know the seam. Say how you'd disagree: facts first, then a decision owner.
- **D2 (VAL):** "How do you handle credit when work spans teams?" Say what you do in principle: "we" for context, "I" for your contribution. If you have an instance, narrate it. If not, say so plainly.
- **D3 (JD):** "What would you need from me in your first month, and what could you do for my team?" Lead with what you bring, then give two specific asks.

**E. Data-Driven Prober**
- **E1 (CASE):** "How would you measure whether a process change actually worked?" Cover the outcome, a baseline, a comparison, and what would count as failure.
- **E2 (CASE):** "Which dashboard metric would you trust least, and why?" Name how metrics mislead: definition changes, selection effects, lag.
- **E3 (EXP):** "Pick a number from your own work. How was it counted, and which assumption would you defend least?" Choose a figure you can defend. Be ready to say how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours. If you don't know how it was counted, say so plainly.

**F. Conversational**
- **F1 (EXP):** "Walk me through the journey." Give a 90-second arc in your own words, ending on why this role.
- **F2 (JD):** "What do you do to keep up with how products get built and run?" Name one or two real habits only.
- **F3 (JD):** "Anything you expected me to ask that I haven't?" Use it for the one point you most want heard, and don't say you've covered everything.

**G. Pressure**
- **G1 (JD):** "Sixty seconds: why you over an internal candidate?" Pause and restate. Give two reasons from your real strengths and one honest limit.
- **G2 (EXP):** "Pick a result you're proud of. How much of it was actually you?" Hold what you did and concede what others did specifically. Never widen the claim.

**Requirement coverage**

| Requirement | Questions |
|---|---|
| R1 | A1, C3, D1 |
| R2 | A2, E1, E2, E3 |
| R3 | A3, A4 |
| R4 | B4, C1, D1, D2, D3 |
| R5 | C1, F1, F3 |
| R6 | A2, A3, E1 |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does success look like at six and twelve months, and how would you know?" | Gets a measurable bar and shows you think in outcomes |
| 2 | "Which product decisions are slow or contested today, and what part does product ops play?" | Surfaces the real job behind the title |
| 3 | "Where's the seam between product ops and product management here?" | Shows you think about turf honestly |
| 4 | "What operating problem do you most hope this hire solves?" | Tells you what the team believes is broken |
| 5 | "What do new people most often get wrong in their first ninety days?" | Shows you plan for your own ramp |
| 6 | "What would help your team most from a new person in the first month?" | Reciprocity, useful if the interviewer is a peer |

### Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentences about your past were supplied, so there's no stretched wording to list | Say only what you actually did, in your own words |

### Sources

Provided documents: none. Your message gave the company, the role and the round.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

All four searches were refused and returned nothing, so nothing from them is used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have tied the VAL bank to Stripe's published principles and allowed a values cheat sheet |
| 2. Stripe interview process | unavailable | Would have set persona weights from the documented loop |
| 3. Stripe strategy and news | unavailable | Would have grounded A4 and B3 in current priorities |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative JD | unavailable | Would have replaced the generic requirements with quoted ones |

### Upgrade menu

- **Job description text:** R1 to R6 become quoted `[grounded]` requirements.
- **Your CV:** the worksheet rows become story-mapped evidence, with defend-the-number questions.
- **Who you're meeting, and whether the final is one conversation or several back-to-back sessions:** this reweights the personas, and I can build per-session mini-packs from a schedule.
- **Interviewer names:** an interviewer read and a reverse question tied to their path.
- **Recruiter guidance:** coverage of any pre-declared take-home or presentation.
- **Web search permission:** the research targets above run, and a deeper pass can be offered after that.
- **A `tuesday-dossier.md` from a prior role assessment:** verified evidence and a named top objection in place of the inferred one.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you grant write permission, I'll save this as a file or convert it to Word.

1. Who are you meeting in the final round, is it one conversation or several back-to-back sessions, and did the recruiter mention any focus areas or a take-home or presentation? The answer reweights every bank.
2. Can you paste the job description and your CV? I'll proceed without them if you'd rather skip.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.