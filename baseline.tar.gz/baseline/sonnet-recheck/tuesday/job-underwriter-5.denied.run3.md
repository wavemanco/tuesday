I'm reading the rest of the underwriter's reference files (output rules, research tiers, worked report) so I can build the assessment in its required shape.
I'll check the employer against its own site and the live posting, since that's the one fact your pasted text can't settle. First I'm loading the search and fetch tools.
**Yes, it's worth applying, on conditions. Status: `conditional_go`.** The must-have rows R3, R4, R5, R6, R7 and R8 are all `direct`. What keeps this from a clean go is R1 and R2, two hard gates your message doesn't settle because you gave me no pay floor or location needs.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148k–$166k plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts)

R9 has a credible bridge with its limit named, and R10 and R11 are open on whether you did the work, not on capability.

**Opportunity ledger.** Sound on the evidence so far. The pay is disclosed and its range straddles the Datawright median (RR4). Scope and reporting line are unstated (RR2, RR3), equity terms are withheld (RR5), and the employer facts rest on pages I couldn't fetch (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148k–$166k plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the terms meet your pay floor and location needs, which closes R1 and R2; (2) you frame BigQuery honestly as a gap with a Snowflake bridge (R9); (3) the employer and live posting check out (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about page text you pasted; I could not fetch it (see Evidence status) |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements | 5+ years data engineering, strong SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; equity terms not stated; Remote (US) or Denver | `[grounded]` JD |
| Seniority read | 5+ years sits inside the 5–8 years the report calls typical for "Senior" | `[grounded]` JD against the Datawright report you supplied |
| Market calibration | Datawright 2026 (US, n=2,310, Series B–D): base median $151,000, interquartile range $139,000–$163,500. The posting's low end is $3,000 under the median, its high end $2,500 over the range's top, and its midpoint is $157,000. Pellucid is Series C, inside the cohort. This is the market band, never this employer's offer | `[generic]` report figures, provided by you and not searched; `[grounded]` the posting's figures |
| Scope read | The report's typical Senior owns one domain's pipelines with no reports. This posting names three layers (ingestion, warehouse, contracts) and no team or reports, so it may be wider than one domain | `[inferred]` from the JD's three layers against the report's typical scope |
| Unknowns | Hiring manager (the posting names none), team size, equity terms, whether the role owns all three layers | `[grounded]` JD silence |
| Contradictions | None between the JD and the about page text as you pasted them | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver | hard_gate | unclear | none | hard_gate | You gave no location or authorization constraints, so nothing grades your side of this term. Confidence is `none` because no claim exists yet, not because the term looks bad | `[grounded]` no constraint stated | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The term is stated, but your floor is not, so whether it is met is unsettled. Equity terms are also unstated | `[grounded]` JD; no floor given | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is specific but intake prose with nothing inspected yet, which is the `medium` ceiling. I haven't seen a CV | `[grounded]` your stated background | CV or role dates would firm up the dates |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. "Strong" is a level, and nothing inspectable shows it yet | `[grounded]` your stated background | A sanitized query or code sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models on Snowflake. That is specific, with no artifact yet | `[grounded]` your stated background | A dbt docs or lineage export would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the requirement as written is met. The JD's own warehouse is BigQuery, carried as R9 | `[grounded]` your stated background; JD wording | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | You used Airflow for orchestration. The scale and your role in it are not stated | `[grounded]` your stated background | An anonymized DAG list would raise it |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is a direct match. Coverage and outcomes are not stated | `[grounded]` your stated background | A suite or data-docs export would raise it |
| R9 | BigQuery, the warehouse this role runs on | important | adjacent | medium | transferability | Credible bridge: dbt modelling on Snowflake carries over. Limit: you have never used BigQuery, so none of its platform-specific operation or cost behaviour is exercised. State the limit wherever the bridge is used | `[grounded]` your stated background and "never used BigQuery"; `[inferred]` the bridge | G5 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | Six years of Airflow work plausibly involved ingestion, but your message names no sources. A lead, not a claim | `[inferred]` from Airflow use; nothing stated on sources | Q2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby work. Whether you defined expectations that downstream analysts relied on is not stated | `[inferred]` from the suite; nothing stated on contracts | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | The posting allows Remote (US) or Denver; your constraints are not given | A failed gate would make this `no_go` whatever the fit | — | — | `[grounded]` JD; no constraint stated |
| G2 | Pay (R2, hard_gate) | hard_gate | The range is stated; your floor is not | The gate decides whether the rest matters | — | — | `[grounded]` JD; no floor given |
| G3 | Ingestion from app and CRM (R10, important) | discovery | Airflow work is stated, but not which systems fed it | It is a named responsibility in the mandate; a concrete answer moves the row to `direct` | Loading product events or a CRM export into the warehouse; owning a connector or an API pull; handling schema changes at the source | A DAG list, a source inventory, or an architecture sketch | `[grounded]` your message is silent on sources |
| G4 | Data contracts (R11, important) | discovery | A Great Expectations suite exists; nothing says it served as an agreement with consumers | "Contracts" is the JD's own term for what analysts depend on | Agreeing column definitions or freshness expectations with analysts; failing a pipeline on a breached expectation; versioning a model's interface | A suite export, a model YAML with tests, or a short spec | `[grounded]` suite stated; `[inferred]` that it may count |
| G5 | BigQuery (R9, important) | transferability | Snowflake dbt experience, no BigQuery | The role runs on BigQuery, so the interviewer will probe the switch | Snowflake work that maps across: modelling, incremental builds, query tuning. The limit: none of it was done on BigQuery | A small dbt project run against BigQuery, if you choose to build one | `[inferred]` bridge from your stated Snowflake work; `[generic]` that a warehouse switch is a common interview probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not independently verified | unknown | — | "Accepting applications" (as you saw it at 09:12) | The pages you copied may be accurate and current; I could not fetch them, so the facts are the company's own as you relayed them | `[grounded]` my fetch and search were refused | Is this role open, and who is the recruiting contact for it? | unresolved |
| RR2 | Scope may span ingestion, warehouse and contracts | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role may be wider than the one-domain ownership the report calls typical | `[inferred]` from the JD's three layers against the report's typical scope | Does this role own all three layers, and who else works on the data platform? | unresolved |
| RR3 | No hiring manager or reporting line named | unknown | — | "The posting names no hiring manager" | Reporting line and team size are unknown | `[grounded]` posting silence | Who would I report to, and how large is the data team? | unresolved |
| RR4 | Pay disclosed, near the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The range is stated openly and sits around the report's median | `[grounded]` JD against the Datawright figures you supplied | How was the range set, and where in it does a candidate with my background land? | noted |
| RR5 | Equity terms withheld | unknown | — | "plus equity" | The amount, type and vesting may materially change the offer's value | `[grounded]` JD states equity with no terms | What is the equity grant, its type and its vesting schedule? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the dbt project (about 180 models on Snowflake) and the Great Expectations suite you set up | see R5, R8 | `[grounded]` your stated background | pending your approval |
| E2 | Put "Snowflake" beside "dbt" in the same line, and write no BigQuery claim. If asked: you have not used BigQuery and have built the same modelling work on Snowflake | see R6, R9 | `[grounded]` your stated background | pending your approval |
| W1 | Optional: a small dbt project run against BigQuery, so the gap has a specific answer | see R9 | `[inferred]` from the R9 limit | pending your approval |
| Q1 | Ask the verification questions of RR2, RR3 and RR5 verbatim in the first screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check the posted terms against your pay floor and location before investing in the loop | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |

## Evidence status

Verified: none yet. Every candidate claim above comes from the background you typed in, and I assumed the stage is evaluating. Nothing is recalled from memory.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried to fetch pellucidlearning.com/careers/senior-data-engineer and to search for the company. Both were refused, so nothing came back. It would have checked that the posting is live and that Pellucid matches the about page (RR1, role reality's organization and contradictions rows) |
| 2. Role-family sweep | skipped | Your Datawright report is in hand with the median, range, seniority and scope, which fix the market calibration line and RR4 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- Your pay floor and location needs: R1 and R2 close, and the decision likely simplifies to `go` or `no_go`.
- Permission for me to fetch the careers page and search the company: RR1 closes. If you also want a deeper pass (funding, leadership changes, employee reports, recent news), that is up to 5 more searches and 2 more fetches.
- Your CV, plus a sanitized dbt docs or lineage export, a Great Expectations suite or data-docs export, or an anonymized DAG list: R3 to R8 move toward `high`, and the CV edits can be proposed.
- Answers to G3 and G4: R10 and R11 move toward `direct`.
- The hiring manager's name: it would sharpen RR3 and which story the plan leads with.

**Questions**

1. G1, G2: Do the posted terms, $148,000–$166,000 plus equity and Remote (US) or Denver, meet your pay floor and location needs?
2. G3, G4: Have you owned ingestion from product or CRM sources, or set expectations that analysts relied on? What was yours, and what happened?
3. Could you paste your CV, or a sanitized dbt, Great Expectations or Airflow artifact from your current job?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.