I've tailored your CV to the Quartzline posting as a five-row edit ledger. Nothing is applied until you approve rows.

I used the dossier excerpt you pasted, and its role matches this posting. R1 and R2 keep the dossier's `adjacent`, `medium` calls, and its E1 is re-audited as E1 below. I only have your summary, not the CV file. So each "Current line" and quote below is your sentence as you gave it, not necessarily your CV's exact wording.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own line, not folded into another bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your summary; inherited from dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your summary | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the third bullet, directly under E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your summary | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved to the top of the Skills section)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your summary | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor"; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your summary | pending your approval |

Audit notes, one per row:
- **E1:** "the whole team" stays. It does not become "company-wide" or "adopted across the org".
- **E2:** "30+" counts the integrations, not the clients. "Our REST APIs" stays vendor-side, so the line does not say you built or shipped the APIs.
- **E3:** The row does not say the sessions set or shaped the roadmap. Your sentence says you collected feedback "for product".
- **E4:** "Comfortable in" stays. It does not become "wrote" or "authored" OpenAPI specs.
- **E5:** The two sentences stay separate. The title string is quoted as you gave it, so it makes no claim about one employer or several.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ yrs PM | must-have | `not_evidenced` | No row can carry it, since you never held a PM title. The adjacent work is in E2 and E3, and the dossier's call (adjacent, transferability, medium) is inherited. A titled-years requirement is a risk, not a gate. See the named absence below. | `[grounded]` you have never held the title; `[generic]` titled-years requirements are often read literally at screening |
| R2 | Shipped API or platform products | important | `not_evidenced` | E2 shows end-to-end integration of an API you did not build. Nothing says you shipped one. See C2. | `[grounded]` what E2 and your summary say |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, E2, E1 | `[grounded]` |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 show client-facing work. The JD's own phrase is not used for your history. | `[grounded]` |
| R5 | Roadmap ownership and prioritisation authority | must-have | `not_evidenced` | E3 shows feedback input only. The dossier flagged this as not evidenced. See C1. | `[grounded]` the dossier's reasoning and your summary |
| R6 | Specs and delivery with two engineering squads | important | `not_evidenced` | Nothing in your summary covers it. See C2. | `[grounded]` |
| R7 | Adoption metrics | important | `not_evidenced` | Nothing in your summary covers it. See C3. | `[grounded]` |
| R8 | Discovery with integration partners | important | `surfaced_by_edit` | E3 partially covers it. Your sessions were with clients of your employer, not integration partners, and the line keeps that side. | `[grounded]` |

## Gap handling

**Recall prompts** (the questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership and prioritisation authority (R5) | must-have | Quarterly sessions that collect client feedback "for product". It does not show who decided what was built. | The dossier names this as the open gap in R1, and the role owns the platform roadmap. | A client request from your sessions that reached product and shipped; a ranking of client asks you handed to product; a case where you argued a feature up or down | A session summary, a feedback-to-ticket trail, a release note | `[grounded]` what your summary does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Specs, delivery with engineers, and shipped API work (R6, R2) | important | "Comfortable in … OpenAPI specs" and a playbook. It does not show writing specs or driving engineers to a delivery. | Writing specs and driving two squads is the daily work of the role. | An API change you specced for engineering; a client-driven fix you pushed through with a dev team; an OpenAPI spec you wrote or edited | A spec, a ticket thread, a changelog entry | `[grounded]` what your summary says; `[generic]` what this costs on applications of this kind |
| C3 | Adoption metrics (R7) | important | Counts of integrations led, but no tracking of use or adoption. | The role must define adoption metrics for a partner platform. | Time-to-first-call or go-live time across your 30+ integrations; client usage you reported; a tracker you kept | A spreadsheet, a dashboard, a quarterly report | `[grounded]` what your summary says; `[generic]` what this costs on applications of this kind |

**Named absence (R1, 3+ years PM):** you have seven years of adjacent work and no PM title. No wording closes that, and I will not write a line that implies it. Closing it would take evidence from C1 to C3 that you did PM-scope work, such as owning a prioritisation call or a spec-to-delivery loop. If none exists, the honest path is to apply on transferability and say so plainly.

## Not written, and why

- "Built an internal request-triage tool". The dossier's rejected inference: it was a memory lead and you could not confirm you owned it.
- "Has been the customer of a partner API platform". The dossier's rejected inference: you worked vendor-side, so the line would flip which side of the transaction you were on.
- "3+ years of product management". You have never held the title, and this is the posting's must-have.
- "Owned the roadmap" or "prioritised the roadmap". You collected client input. Deciding what gets built is a different job.
- "Shipped API products". You led integrations of your employer's APIs, which is a different activity.
- "Wrote OpenAPI specs". Your sentence says "comfortable in", which does not say you authored any.
- "Drove delivery with engineering squads" and "defined adoption metrics". Nothing in your material supports either.
- "Stakeholder management" and "partnered with integration partners". These are the posting's words, not yours. "Partner" would also change which side of the table you sat on.

## Parse-safety check

Your CV arrived as prose, so the layout checks could not run. That covers multi-column layout, tables and text boxes, images and skill bars, content in headers or footers, non-standard headings, and file type. If you send the file, I'll run them. A `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

- **Your CV file:** it would let every trace quote your exact wording instead of your summary.
- **The full `tuesday-dossier.md`:** only the excerpt is in hand, so the evidence map, constraints and gap queue are not inherited.
- **Inspectable artifacts:** a playbook excerpt, an OpenAPI spec you wrote or edited, a roadmap-input session summary, or an integration tracker. Any of these could lift R2, R5 and R7 from unevidenced to `medium` or higher.

## Questions

C1 — Did any client request from your quarterly sessions end up on product's roadmap, and what was your part in deciding that: raising it, ranking it, or only passing it on?
C2 — Have you written or edited an API spec, or pushed a fix or change through to delivery with a dev team? If so, what was it and what was your part?
C3 — Did you track anything across your 30+ integrations, such as time to go-live, usage or call volume? If so, what, and where did it get reported?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.