I'm saving the prep pack, but the write to the project folder was refused. I'll try the session scratchpad folder instead.
Dara, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-canned-fc33a887/c1627eac-4d39-40d3-a7eb-b11de73b2856/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It's in the scratchpad because the write to the project folder was refused. I built it as a three-round loop, with a mini-pack and question bank for each round, plus the values sheet for the panel. It rests only on your own sentences, your pasted values text and your summary of the June brief, so I ran no searches.

The date doesn't match: your notes put the rounds on 21 October, but my clock reads 5 November. I've used your dates, so tell me if the rounds have moved or already happened.

The pack names R2B1 as the highest-ROI prep. It's the Head of Member Services pressing on the contact-centre gap, which is the first line of the role's remit. It opens with your own words, "I've never worked in a contact centre," and then runs three follow-ups.

Say the word and I'll play the Head of Member Services (Skeptic) on R2B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste your CV, or just the lines on complaints, reporting and training? The pack works without it, but four rows are marked inferred and would be re-checked against it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Interviewers:** names not yet assigned; roles only. **Mode:** loop, three rounds on 21 October (as the recruiter's email gives them).

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Nothing beyond the slot |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Built on one assumption: your background is the paragraph in your message, since no CV document was supplied, so every claim about your past below rests on a sentence from that paragraph.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for me: say what is true in your own words, and where the slot's second branch applies, say that plainly.

| Type | What is being scored |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values |
| EXP | Whether what you say you did survives scrutiny; what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If any step before or after the log was yours to run, say which, in your own words; if the log was the whole of it, or the rest was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated, so the words are the plain acknowledgment: "I've never worked in a contact centre." Then a plan for learning it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The quote says formal complaints; it does not say whether any rule from outside the branch governed them, and the words stay at "I handled the branch's formal complaints log." Answer slot: the JD's regulated line makes a probe likely. If the complaints you logged fell under outside rules, say which and what that meant for how you handled them, in your own words; if you do not know, or none did, say so plainly and stay with the log you handled |
| F4 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The count is 6 against the JD's 4+, in the quote's own terms: "Six years in retail banking, the last three as a branch supervisor." The JD says customer operations and the quote says retail banking; say retail banking and let them map it. Confirmed by you, nothing inspected behind it, so expect a probe |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The quote says a monthly spreadsheet and nothing of what it held. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's volumes and resolution-times line makes a probe on what yours tracked likely. Say what it showed each month, in your own words; if it showed less than that, or did not track them, say so plainly and stay with the spreadsheet you built |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | The material says new tellers and a script, and that you held the supervisor's seat for three years; it does not say you coached supervisors. The words stay at "I trained new tellers on our escalation script." Answer slot: the JD's escalation line makes a probe on how you taught the script likely. Describe how you taught it, in your own words; if there is no more to it than the sentence says, say so plainly and stay with the new tellers you trained |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital or self-service work. Answer slot: the JD's digital line makes a probe likely. If you have worked with a digital team on anything members used themselves, say what it was and what your part was, in your own words; if not, say so plainly, and say what you would ask a digital team first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated, so the words are the plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The quote says spreadsheet and does not name the tool. Answer slot: the JD names Excel, so expect a probe on it. If the spreadsheet was in Excel, say what you did in it, in your own words; if it was another tool, or someone else did parts of it, say so plainly and stay with the spreadsheet you built |

## Requirement coverage

| JD requirement | Fit row | Questions that cover it |
|---|---|---|
| Own the complaints process end to end across branches | F1 | R1A4, R1C1, R2A1, R2C1, R3B1, R3B2, R3C1 |
| ...and the contact centre | F2 | R1B1, R2B1, R3C2 |
| Experience handling regulated complaints | F3 | R1C1, R3B1 |
| 4+ years in financial-services customer operations | F4 | R1A1, R1A4 |
| Report monthly on complaint volumes and resolution times | F5 | R1C2, R2C1 |
| Coach branch supervisors on escalations | F6 | R2A3, R3B3 |
| Work with digital teams on self-service journeys | F7 | R2B2, R2C2 |
| Confident presenting to senior leaders | F8 | R1B2, R2B3 |
| Comfortable with Excel reporting | F9 | R1C2 |

No headline figure beyond tenure appears in your material, so there is no defend-the-number question beyond F4's count.

## Grounding brief

From the 2026 strategy brief Ashgrove published in June 2026, as you summarised it; the brief itself was not pasted.

| Fact | Source | Provenance | Where it is used |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | June 2026 strategy brief, your summary | [grounded] | R1A2, R2C2, R2 reverse questions |
| Consolidate eight branches into five hubs over 2027 | June 2026 strategy brief, your summary | [grounded] | R2C2, R3C3, R3 reverse questions |
| Launch a small-business lending product in Q1 2027 | June 2026 strategy brief, your summary | [grounded] | Background only; no question rests on it |
| Main competitive pressure is app-only banks | June 2026 strategy brief, your summary | [grounded] | R1A2, R2C2 |
| Member-owned, about 900 staff | The JD | [grounded] | Background only |

---

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; casual questions still scored | Highest. The recruiter-screen prior is Conversational plus a light Skeptic; no interviewer profile exists to adjust it, and the email describes this round only as 30 minutes | A 90-second arc built only from sentences you wrote; treat casual questions about the JD's topics as scored |
| Skeptic | Quiet knockout checks on the gaps | Medium. The prior is "light Skeptic", and F2 and F8 are stated gaps on the JD's headline lines, which a screen tests first | Rehearse the stated limits until they are boring; concede plainly, then the plan |
| Data-Driven Prober | Reads the background line by line | Low, two questions. Not a recruiter prior; kept because the JD's regulated-complaints and reporting lines are checkable | Know what you can and cannot say about what the log and the spreadsheet held; say plainly when you do not know |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1A1 | "So — walk me through the journey: how did you get from where you started to wanting this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F4, F1 and F5: a 90-second arc in the quotes' own terms, at their own scope: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log; building the monthly complaints spreadsheet your regional manager uses. Answer slot: why this role and why now is yours to say; this pack holds no sentence of yours on it, so say only what is true for you | The standard opener of a recruiter screen; F4 is the spine of the arc. EXP because it tests whether the story matches the material; conversational delivery, scored anyway |
| R1A2 | "What do you make of where Ashgrove is heading?" | CO | [grounded] | Bring one fact from the published strategy to show you read it; the move of 40% of member service to digital channels by 2028 is the one that meets the JD's self-service line (F7). Then your own view, in your own words, of what that means for how members complain; the fact is shared by every prepared candidate, so the view is what is scored, and this pack holds no sentence of yours on it. Do not recite the other items | Casual-register strategy questions are the cheapest differentiator at a screen; CO because it tests altitude. Fact from the brief row in the grounding table |
| R1A3 | "What are you looking for on pay, and when could you start?" | JD | [generic] | Logistics, asked casually, still scored. Have both answers decided before the call; this pack holds neither, and a number you have not thought through is the one that comes out wrong. Say what is true, and if the band is not stated, ask for it before giving a figure | Recruiters close a screen with logistics; JD because it is a knockout check rather than a competency. Generic because nothing supplied states pay or a start date |
| R1A4 | "Tell me about the last three years as a branch supervisor." | EXP | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Story-mapped on F1 and F6, each at its quote's scope: you handled the branch's formal complaints log; you trained new tellers on the escalation script. Anything else about the day-to-day is yours to say in your own words; this pack holds no other sentence of yours on it | F4's count is tested here as role content; EXP because it checks what the title meant in practice |
| R1B1 | "The role covers the contact centre as well as branches, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Open with the limit in your own words: "I've never worked in a contact centre." Then a plan, said as a plan: who you would sit with first and what you would listen for before changing anything. Do not claim contact-centre knowledge you do not hold, and stop after the plan. The recruiter is checking candour; a clean concession is the strong answer | F2 is a gap you stated, on the JD's opening line, so a screen will test it. JD because it scores the stated requirement. The deepest version is R2B1 |
| R1B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose one of your two stated limits and name it plainly: "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Then the plan for it. Do not invent a third weakness to look balanced, and do not say you have none | F2 and F8 are the two limits you stated. JD because it scores fit against the posting |
| R1B3 | "Why this move, and why now?" | JD | [generic] | Your reason is yours; this pack holds no sentence of yours on it, so it cannot supply one. Settle one version of about 45 seconds that you will also give in rounds 2 and 3; the recruiter hears all three | Motivation consistency is the Skeptic's core check at a screen; JD because it scores fit with this role. Generic because no supplied text states a reason |
| R1C1 | "Tell me about the formal complaints on your log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F3: the log, which was the branch's, and your handling of it, in those words. Answer slot: the JD says regulated, so expect a follow-up on what governed those complaints. If outside rules applied, say which and what they meant for how you handled each one, in your own words; if you do not know, or none applied, say so plainly and stay with the log you handled | F3 is the row with the most probing room. EXP because it tests what you actually handled |
| R1C2 | "You built the monthly complaints spreadsheet. What did it track, and what was it built in?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F9: the spreadsheet, monthly, used by your regional manager, in those words. Answer slot: the JD asks for monthly reporting on volumes and resolution times and for Excel, so expect both probes. Say what it showed each month and what it was built in, in your own words; if it showed less, or was built in something else, say so plainly and stay with the spreadsheet you built. If you quote any number from it, say how it was counted, or say you do not know | Reporting and Excel are two JD lines resting on one sentence, so this is where a screen probes. EXP because it tests ownership of what was built |

## Reverse questions (round 1)

| # | Question | Why it lands |
|---|---|---|
| R1V1 | "Can you tell me who is on the panel when it is set, and whether there is anything I should prepare or bring for the 20-minute case?" | A practical ask that a recruiter can answer in one email; it also tells you what the case papers look like |
| R1V2 | "Which regulator's rules govern the complaints this role handles?" | The JD says regulated and names no rules; asking shows you take the framework seriously, and the answer fills a gap in this pack |
| R1V3 | "Where does this role sit relative to the contact centre and the branches, and who reports into it?" | Makes the end-to-end line concrete and shows you are thinking about ownership boundaries |
| R1V4 | "What would the hiring team most like to see resolved in the first six months?" | Shows outcome orientation; the answer tells you what rounds 2 and 3 will weigh |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes, STAR-shaped stories, "tell me about a time" | Highest. The hiring-manager prior is Case/Strategist plus Skeptic; the recruiter's "mostly behavioural" lifts Behavioral to the top | Where a sentence of yours carries a story, map it at its scope; where none does, pick by the scaffold's criteria and use the honest branch. "We" for context, "I" for contribution |
| Skeptic | Persistent probing of the gaps and of motivation | High. A future manager derisks gaps; F2, F7 and F8 are the three they can see | Rehearse the single most predictable objection until it is boring; concede the limit first, then a ramp plan |
| Case / Strategist | A live problem from the role | Medium, two questions. The prior puts it high; "mostly behavioural" pulls it down | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2A1 | "Tell me about a time a complaint couldn't be settled where it started and had to be taken further." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, not a mapped story: pick a time a complaint you held moved beyond where it began; it needs the member's situation, the point you decided to take it further, what you kept hold of afterwards, and how it ended. The one sentence of yours that touches this is "I handled the branch's formal complaints log"; it carries that you handled the log, so any particular complaint and its ending is yours to supply. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation line and the value Own the Fix both press here; F1 is the evidence. VAL because the interviewer wants a behaviour, and the theme is the JD's, not an assumed event |
| R2A2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior a hard truth; it needs the stake, what you said, how they responded, and that the working relationship held. This pack holds no sentence of yours that carries one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem; the role reports to senior leaders (F8). Generic because it is a pattern, not a fact about Ashgrove |
| R2A3 | "Tell me about a time you taught or coached someone who didn't want to change how they did something." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold with the nearest sentence: "I trained new tellers on our escalation script" carries that you trained them, not that anyone resisted, so any resistance and what you did is yours to supply. Pick a time with a named person, what they resisted, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's coaching line (F6) is the live concern for a manager hiring someone who will coach supervisors. VAL because it scores behaviour |
| R2A4 | "When did you put a customer ahead of an internal metric?" | VAL | [grounded] | Selection scaffold: pick a time a member's situation pulled one way and a target or process pulled the other; it needs both pulls, what you decided, and what the member got. This pack holds no sentence of yours that carries one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First is Ashgrove's first value, so a manager will try the theme before the panel does. Stem is a standard one; the value text is the raising source |
| R2B1 | "The role owns complaints across branches and the contact centre, and you haven't worked in a contact centre. Why should we believe you can lead there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | **The highest-ROI rehearsal in this pack.** Open with the limit before it is pressed: "I've never worked in a contact centre." Follow-up 1, "what makes you think branch complaints work carries over": stay with the sentences you have, "I handled the branch's formal complaints log" and "I trained new tellers on our escalation script", and say where the carry-over stops; what a contact centre does that a branch does not is something to ask about, not to claim. Follow-up 2, "what do you do in the first 90 days": a plan, in your own words, that starts with listening before changing anything. Follow-up 3, "what will the contact-centre team think of a branch person leading them": concede that they may doubt it, and say how you would earn it. Hold the limit through all three by returning to it, never by adding to your experience | F2 is a stated gap on the JD's first line, and the person you are rehearsing for would own the result. JD because it scores the stated requirement; deepest because it is the one objection almost certain to be asked in some form |
| R2B2 | "Tell me about any time you've worked with a digital team on something members used themselves." | JD | [grounded] | Answer slot: the JD's digital line raises this and your material holds nothing on it. If you have worked with a digital team on anything members used themselves, say what it was and what your part was, in your own words; if not, say so plainly, then say what you would ask a digital team first | F7 has no evidence, and the strategy puts digital at the centre (grounding brief). JD because it scores the stated requirement; the open prompt supplies no event |
| R2B3 | "You'll report monthly to senior leaders, and you haven't presented above regional level. What will you do differently the first time?" | JD | [grounded] "I've never presented to anyone above regional level" | Open with the limit: "I've never presented to anyone above regional level." Then your preparation, in your own words, as a plan and not a past: how you would find out what the leaders need to decide from the report before writing it. Stop after the plan; do not claim comfort you have not yet earned | F8 is a stated gap; a manager will want to know how much support it will need. JD because it scores the stated requirement |
| R2C1 | "Complaint volumes are rising in one region and resolution times are slipping. How would you diagnose it?" | CASE | [generic] | Clarify first: what counts as a complaint, which region and channels, what period, and whether the rise is real or a change in how complaints are recorded. Then segment: branch against contact centre, complaint type, age of case. Then hypotheses and what each would show, what you would report and to whom, and the risks. Think aloud and challenge one premise respectfully. The question asks nothing about your past | The JD's monthly volumes and resolution-times line (F5) as a live problem. Generic because it is a pattern for the problem |
| R2C2 | "The strategy moves 40% of member service to digital channels by 2028 and brings eight branches down to five hubs over 2027. What does that do to complaints, and what would you want to know first?" | CO | [grounded] | Clarify before structuring: which services move, what counts as a digital complaint, how the hubs divide the work. Then a view of where complaints could arise in the change, held as hypotheses to test; who keeps hold of a complaint that starts in an app and ends in a branch, which is the value Own the Fix in practice; and what you would report. Challenge one premise, for example whether digital changes how many complaints there are or only where they are raised. App-only banks are the brief's named pressure, so you may say how a member would compare the two | The differentiator question most candidates cannot touch; CO because it tests altitude. Facts from the grounding table |

## Reverse questions (round 2)

| # | Question | Why it lands |
|---|---|---|
| R2V1 | "What does success in this role look like at six months, and at twelve?" | Shows ownership of outcomes; gives you the manager's real measure |
| R2V2 | "Where does the complaints process work least well today?" | Shows you are already thinking about the fix; the answer tells you where the first 90 days go |
| R2V3 | "As 40% of member service moves to digital, who in the digital teams would I work with first, and what would you want settled between us?" | Connects F7 to the strategy and shows you will build the relationship rather than wait for it |
| R2V4 | "How do you prefer to hear about a complaint that is going badly: early and rough, or later and complete?" | A working-style question with your future manager; shows you want the relationship to work |

---

# Round 3: the panel of two branch managers (60 minutes, with the 20-minute case, scored against the four values)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to each published value | Highest. The recruiter's email calls this the values round, and the panel scores against the four values; a loop source documents it | One story per value, mapped to a sentence of yours where one carries it and picked by the scaffold where none does; "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute complaint-escalation case | High. The email names the case as part of this round; its content is not yet known | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting, "what would you need from us" | Medium. Panel rule: blend the top two of each member's relationship, and the names are unknown. Branch managers sit beside the role you would coach into, so the closest priors are cross-functional and peer. This is an inference from the roles, not a profile | Reciprocity: what you bring their branches as well as what you need; propose seam principles rather than pretending to know the seam |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3A1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for Members First: pick a time you made a call from the member's side when something internal pulled the other way; it needs the member's situation, what pulled against it, what you decided, and what the member got. This pack holds no sentence of yours that carries one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always is the first value and is scored by name. The value text is the raising source |
| R3A2 | "Tell me about a time something you wrote or said had to be explained to a member twice." | VAL | [grounded] | Selection scaffold for Plain Words: pick a time something had to be explained twice, and what you changed so it would not be; it needs the original wording, the change, and who it helped. This pack holds no sentence of yours that carries one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words says that if a member needs it explained twice, Ashgrove wrote it wrong; the role's escalation script and member letters live here |
| R3A3 | "Tell me about something you did for a member or a town that went beyond what the process asked." | VAL | [grounded] | Selection scaffold for Neighbours, Not Numbers: pick a time you did something that took account of where a member lived or which branch they used, beyond what the process asked; it needs the member or the town, what you did, and why the process did not ask for it. This pack holds no sentence of yours that carries one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Every branch is part of its town; two branch managers will weigh this one personally |
| R3A4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold for Own the Fix, with the nearest sentence: "I handled the branch's formal complaints log" carries that you handled the log, not any particular problem or its ending, so a problem and how it ended is yours to supply. Pick one with the moment you found it, any point where handing it on would have been easier, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 is the evidence. Own the Fix asks the finder to keep hold, while the JD asks for coaching on escalations; an answer that treats escalation as a hand-off may read against the value (the pack's own reading) |
| R3B1 | "Here is a complaint a branch has escalated. What do you want to know before you do anything?" | CASE | [generic] | Clarify before acting: what the member said in their own words; what the branch has already told them; who has the case now, and who keeps hold of it; what clock or rule applies; whether it has touched more than one channel; what the member is asking for. Ask rather than assume the details. The question asks nothing about your past | The 20-minute case opens here; F1 and F3 as a live problem. Generic because the case content is not yet known |
| R3B2 | "You have the facts. Walk us through what you would do and what you would say to the member." | CASE | [generic] | Structure it: the objective for the member and for Ashgrove, the steps in order, who does each, what the member is told and when, and who keeps hold until it closes. Say it in plain words, since the member should not need it explained twice. Challenge one premise respectfully, and think aloud. The question asks nothing about your past | The second half of the case; scores structure and plain communication, which map to two of the values |
| R3B3 | "The supervisor who raised it says head office never listens. How would you coach them through the next one?" | CASE | [generic] | Listen first, and separate this complaint from the pattern they are describing. Agree what they can resolve themselves and what to escalate, and agree that they keep hold of the member's case either way. Plan a follow-up. If you mention your own experience, the sentence you have is "I trained new tellers on our escalation script"; say it at that scope and no wider. The coaching itself is a hypothetical, so describe how you would do it | F6 as a live problem; the panel includes branch managers, who will recognise the supervisor's frustration. Generic because it is a pattern for the problem |
| R3C1 | "Our branches and the complaints function will sit side by side. Where is the seam, and what happens when we disagree about a complaint?" | JD | [generic] | Propose principles for the seam, not a map you do not have: the finder keeps hold of the member's case, decisions are made from the member's side, and disagreements are settled by what the member needs. Say what you would want from the branches and what you would offer them. The question asks nothing about your past | A standard peer stem on a role that works across branches (F1) |
| R3C2 | "How do you handle credit and blame when a complaint spans a branch and the contact centre?" | JD | [generic] | A principle, not a past: the branch or team that found the problem and kept hold of it is credited; blame goes to the process rather than a person. Say how you would make that visible in your monthly reporting. The question asks nothing about your past | Credit-sharing is a standard peer probe, and the role spans both channels (F2) |
| R3C3 | "Eight branches become five hubs through 2027. What would you want from us in that period, and what could you offer us?" | CO | [grounded] | Reciprocity first: what you could offer, in your own words as a proposal, for example a single route for escalations so a member does not fall between a branch and a hub. Then what you would want. Assume nothing about which branches are affected, and keep the tone neutral; branch managers may not be able to speak about it | The brief's branch consolidation touches the people in the room. CO because it tests strategy fluency; peer because it asks for reciprocity |

## Values / principles cheat sheet

No sentence of yours carries a story for any of the four values; the four scaffolds below say what to pick.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: pick a time you made a call from the member's side when something internal pulled the other way; it needs the member's situation, what pulled against it, what you decided, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | Something a member has to have explained twice was written wrongly | Selection scaffold: pick a time something had to be explained twice and what you changed; it needs the original wording, the change, and who it helped. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Every branch belongs to its own town | Selection scaffold: pick a time you did something that took account of where a member lived or which branch they used, beyond what the process asked; it needs the member or town, what you did, and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Selection scaffold: pick a problem you found and stayed with rather than handed on; it needs the moment you found it, any point where handing it on was easier, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Reverse questions (round 3)

| # | Question | Why it lands |
|---|---|---|
| R3V1 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel; it shows you are thinking about what you bring |
| R3V2 | "From where you sit, what makes an escalation work, and what makes one fail?" | Draws on their experience of the exact process you would own, and they score the answer as listening |
| R3V3 | "As eight branches become five hubs, how are you thinking about members who relied on the branch they know, if that is something you can speak to?" | Ties Neighbours, Not Numbers to the strategy; the clause lets them decline without awkwardness |
| R3V4 | "Which of the four values is hardest to hold to on a busy day?" | The panel scores against them, so asking invites a candid answer; it signals you take them seriously |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one branch's formal complaints log, not a process across branches |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says new tellers and a script, not supervisors |

## Sources

**Provided documents:** the job description (pasted); the values text (pasted; ashgrovecu.org/about/values named as where it was copied, not fetched); the recruiter's email on the process (pasted); your summary of the June 2026 strategy brief (the brief itself was not pasted); your background paragraph (pasted). No dossier was present.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The pasted values text fixes the cheat sheet and the VAL questions, four values by name |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email fixes the number of sessions, who runs each, and what each holds |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the June 2026 brief fixes the CO bank; later news is not in hand, and the deeper pass in the upgrade menu would look for it |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the lines on complaints, reporting and training → F3, F5, F6 and F9 are checked against it, and the rows currently marked inferred can become grounded
- Your answers to the answer slots on F1, F3, F5, F6, F7 and F9 (said outside a drill) → each becomes quoted material that upgrades its row and the questions that draw on it
- One story per value, in your own words → the four scaffolds in the cheat sheet become mapped stories
- The panel's names, once assigned → persona weights read from public professional footprint, and a reverse question tied to an interviewer's path
- From the recruiter: the case format and whether papers come in advance, and which regulator's rules govern the complaints → the round 3 case and F3 firm up
- The full June 2026 strategy brief → the grounding brief expands from four facts to its own vocabulary and headline numbers
- How many days you have before each round → a prioritised prep schedule
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): recent organisation context, loop reports for this role family, and any public material on the interviewers once named → a fuller grounding brief
- A tuesday-dossier.md from an earlier job assessment, if you have one → verified evidence and absolute prohibited claims carried in
