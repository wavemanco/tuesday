I've read the playbook and the dossier. Now I'm running the default research pass on Quartzline: values, interview process and strategy. After that I'll write the pack.
The write to the project folder wasn't permitted. The session's scratchpad is the sanctioned place for files, so I'll save the pack there instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-4-denied-71487605/1f2f0c74-c63f-4318-9e8f-ebab523bc3a2/scratchpad/Quartzline_product-manager-platform-apis_interview_pack.md`. The project folder write was refused, so it went to the scratchpad.

I built it for the hiring-manager round you described, from the dossier alone. Search permission was denied, so none of it uses Quartzline research. The "why Quartzline" answer (D3) and the case questions are generic and labeled that way. The pack has 18 questions across five interviewer styles, with a requirement-coverage table and six reverse questions.

- **Drill first:** A1 is the underwriter's objection (no PM title, no roadmap). It gets the deepest rehearsal: concede in one sentence, bridge with the limit named, ramp plan, then three follow-ups. A2 ("weakest on day one") is next.
- **Must-have gap:** R2 ("shipped API or platform products") is a must-have the dossier doesn't list as a weak area. Your evidence is client integrations of the vendor's APIs, not shipping a product. I treated it as an adjacent bridge, with a slot for whether any part of the API itself was yours. That grading is my call, not the underwriter's.
- **Years:** The dossier's decision line says seven years, but no verified entry states it. The pack doesn't script that number, so add your own figure only if you want it in your 90-second arc.
- **Dossier age:** It's dated 2026-08-14, so tell me if the posting or your evidence has changed.
- **Slots:** Several answers end in "if you did X, say how; if not, say so plainly." Those are for you to answer truthfully. Your answers upgrade the pack.

If you want, I can run a live Skeptic drill on A1.
I can also save a `tuesday-dossier.md` update recording what this prep exposed.
I can convert the pack to Word as well.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer: not named. Built from your underwriting dossier (conditional_go) with no company research (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether claims on your record survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Highest-ROI rehearsal: A1. The underwriter named that objection from the evidence you confirmed, so it is the one this pack rehearses deepest. If you only have time for one thing, drill A1 until it is boring, then A2.

## Fit snapshot

Requirements are quoted from the dossier's role_profile (the JD equivalent). Evidence cells hold the verified entries word for word; their confidence notes are in the Confidence and bridge columns, not in the quotes. Dossier source below means `handoff_to_mock_interview.verified_candidate_evidence`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy for this area is bridge, positioned as adjacent and never as PM experience; low is the dossier's grade for R1. Words stay at the quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." Limit, as the pack's observation: the material shows adjacent integration and input work, not time in a PM role. The sessions entry is confirmed with limited inspectable proof, so expect a probe on it. Plain acknowledgment, sourced by the dossier field `prohibited_claims`, item "Having held a product manager title or role": "I haven't held the product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities; "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The underwriter's strategy is acknowledge_gap, so no bridge is coached here and no quote is stretched toward it. Words, sourced by the `acknowledge_gap` area named at left and by `prohibited_claims` item "Having owned a product roadmap": "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first about which decisions sit with the PM and which with the two squad leads |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | transferability | Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The pack's observation: the quote is about integrations of the vendor's APIs, not about shipping an API or platform product, and the dossier's weak-area list does not carry R2, so this classification is the pack's own call. Answer slot: the JD line makes a probe on whether any part of the API or platform itself was yours likely. If any was, say which part and what you did, in your own words; if none was, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [inferred] | discovery | The quotes name REST APIs, architecture and a playbook; they do not show whether API docs or schemas were read, written or reviewed. Answer slot: the JD names docs and schemas, so expect that probe. If you worked with them, say how, in your own words; if not, say so plainly and stay with the architecture and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Medium because one of the two entries is confirmed with limited inspectable proof. The quotes carry client-facing work and a channel into product; they do not mention engineering or sales. Answer slot: the JD names engineering, sales and customers. If you worked with engineering or sales on any of this, say how, in your own words; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The underwriter's strategy is clarify: the evidence may exist but was not established, and no verified entry speaks to it, so nothing about your past is scripted. Answer slot: the JD's wording is the likely probe. If you worked that way, say how in your own words; if you never worked that way, say so plainly and say what you would want to confirm about how they define it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes say clients, the JD says integration partners, and the words keep clients. Answer slot: if you ran any conversation with clients aimed at what they needed beyond a single integration, say how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the sessions and the scoping you led |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | discovery | The quote shows requirements and go-live on client integrations; it does not show specs or work with engineering squads. Answer slot: if you wrote specs or drove delivery with engineers, say what and how, in your own words; if not, say so plainly and stay with requirements and go-live |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Silence, not a stated absence. Answer slot: if you ever defined or tracked a measure of whether integrations were used, say what was counted; if not, say so plainly and say what you would ask first. How Quartzline measures adoption today is one of the dossier's unknowns |

## Persona table

Weights are the hiring-manager relationship prior, adjusted by the dossier. No interviewer profile exists, so no interviewer-signal adjustment was made. Only this one session is established (your words); later rounds are not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5 questions) | Quiet, persistent probing of the title and roadmap gap | High: skeptic is a hiring-manager prior, and the dossier names a specific objection (F1, F2) | Rehearse the one objection until it is boring; bridge only from the quotes in F1; say the limit before it is asked for |
| B. Case/Strategist (5) | Live problems from the actual role | High: the other hiring-manager prior, and the JD's spec, delivery and adoption lines (F8, F9) are case-shaped | Clarify, then objective, segments, approach, metrics, risks; challenge one premise respectfully. Frame answers as how you would work it, never as how you did |
| C. Data-Driven Prober (3) | Walks your record line by line | Medium: no interviewer signal says data-driven, but a 30+ figure and a medium-confidence entry invite it (F1, F5) | Know what you can and cannot say about how the figure was counted; name your weakest assumption first |
| D. Conversational (3) | Friendly opener, casual JD questions | Medium: openers and the reverse-question slot are scored even when they feel unscored | A 90-second arc from your quotes; a prepared reverse-question set |
| E. Pressure (2) | Time-boxes you, plays devil's advocate on the title gap | Low: no signal for it, but the objection can be delivered this way | Hold the position through two follow-ups, then concede specifically |

Not built: Peer Evaluator (the relationship is manager, not peer; if you will also meet the squad leads, a peer bank is worth adding) and Values/Behavioral (no values-style round is established; see Sources).

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; both negatives are sourced by the dossier fields `prohibited_claims` ("Having held a product manager title or role", "Having owned a product roadmap") and `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The deepest rehearsal in the pack. (1) Concede first, one sentence, no apology: "I haven't held the product manager title, and I haven't owned a product roadmap." (2) Bridge with the limit named before they ask, as adjacent work and never as PM years: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." The sessions support only the adjacent-work half of the answer; the roadmap half stays at the concession. (3) Volunteer the sessions' limit, because it is confirmed with limited inspectable proof. Answer slot: if you have anything to hand over from those sessions, name it; if you do not, say so plainly and describe the sessions. (4) Close on the ramp, as a plan: you would first learn which decisions sit with the PM and which with the two squad leads, and how adoption is measured today. Follow-ups to drill, hold then concede. "What did you actually decide in those sessions?" Answer slot: if a decision was yours, say which, in your own words; if none was, say so plainly and return to the sessions you ran. "That's still not PM experience." Agree it is adjacent, do not argue the label, and return to what the quotes show. "Why leave the integration side?" Give your own reason in your own words; nothing in your material supplies one, so none is scripted here | The underwriter named this objection (likely_interviewer_objections). F1 and F2 are where it presses; JD because it scores R1 |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it before they do, plainly: the roadmap and prioritization piece. No bridge here; the underwriter found no credible evidence and a bridge improvised live is how people get caught. Then the plan, as a plan: ask the squad leads how decisions are made today and which are the PM's, and learn the adoption baseline. Say it in your own words and stop | F2 is the acknowledge_gap area; this is the persona stem for the same objection in a different register |
| A3 | "Tell me about your experience with agile delivery." | JD | [grounded] `uncertain_or_weak_areas` clarify area "Agile delivery inside a product org (R5)" | Nothing in your verified evidence speaks to this, so nothing about your past is scripted. Answer slot: the JD's wording is the likely probe. If you worked that way, say how, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline defines it | F6 is a clarify area; preferred, so low stakes, but a free answer to rehearse. JD content, open-prompt delivery |
| A4 | "Tell me about an API or platform product you've shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say precisely what the object was: "I led 30+ end-to-end client integrations of the vendor's REST APIs", then the stages the quote names, in your own words. Answer slot: the JD asks about shipped API or platform products, so expect a probe on whether any part of the API or platform itself was yours. If any was, say which part and what you did; if none was, say so plainly and stay with the integrations. Do not call the integrations a shipped product | F3 is a must-have the dossier did not list as a weak area; the pack grades it transferability. JD, must-have coverage |
| A5 | "Walk me through one of your quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell what the quote states: the sessions were quarterly, you ran them, and the input was client evidence going to product. This entry is confirmed with limited inspectable proof, so say what you can and cannot show before they ask. Answer slot: the JD's roadmap and discovery lines make a probe on what happened to the evidence after it reached product likely. If you know, say what and how you know; if you did not see, or it was not tracked, say so plainly and return to the sessions you ran | F7 and F1 rest on this entry, and a medium entry is where a prober goes. EXP, because it tests what was actually the candidate's |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squads each want the same engineering capacity next cycle: one for a reliability fix, one for a new endpoint a large partner is asking for. How do you decide?" | CASE | [generic] | Clarify first, and treat the open question as part of your answer: who holds the decision between the PM and the squad leads? Then the objective, the partners affected, the cost of delay on each side, the evidence you would want, and the risks. Challenge one premise respectfully, for example whether it really is either-or. Frame everything as how you would work it | F8 and F2 meet here; the dossier lists decision authority as unevidenced. CASE delivery of a JD line |
| B2 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Ask how adoption is defined and measured today before diagnosing anything; that is a dossier unknown and also your reverse question. Then segment partners, locate where they drop off, form two or three hypotheses, say which data would separate them, and name the first thing you would do | F9; adoption metrics are a named responsibility with no baseline stated |
| B3 | "Partners, sales and engineering each want something different on the roadmap. How would you decide what goes on it?" | CASE | [generic] | State criteria out loud, say who you would consult, and say what you would need to learn about decision rights first. Say "I would", not "I did": your material does not show you setting priorities for a squad | F2 and F5; the prohibited list bars implying prioritization authority, so the answer is a method, not a history |
| B4 | "A partner asks you to rename a field in a widely used response schema. How do you think about it, and what goes in the spec?" | CASE | [generic] | Think aloud: who depends on the field, how a change would be rolled out and communicated, what the doc and schema changes are, and what the success check is. It is a pattern for the problem, so the guidance makes no claim about your past | F4 and F8; tests technical fluency and spec-writing in one problem |
| B5 | "What would your first 90 days look like?" | CASE | [generic] | Learn before you commit: decision rights with the two squad leads, the adoption baseline, and what partners are asking for. Tie it to your A1 ramp so the two answers agree | Seeds the ramp plan that A1 and A2 promise; F7 |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep the number on the noun it came from: 30+ integrations, not clients and not go-lives. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; and which of scoping, requirements, architecture, UAT and go-live were yours. If a stage was shared or someone else's, say so plainly. If you do not know how something was counted, say that | F3 and F8 lean on this figure, so it is the number a prober tests. EXP, defend-the-number |
| C2 | "Tell me about the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states: you wrote it and your team uses it. The dossier records the playbook as inspectable, so offer to walk through it. Answer slot: the JD's adoption line makes a probe on how its use was known likely. If use was tracked, say how; if it was not, say so plainly | F4; the playbook is the best inspectable artifact in the material. EXP delivery, R3 content |
| C3 | "Tell me about a time you worked across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-map on what the quotes carry: clients through scoping to go-live, and client evidence going to product. Answer slot: the JD names engineering and sales, so expect a probe on them. If you worked with either, say how; if you did not, say so plainly and stay with clients and product | F5 |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order, each at its own scope: the integrations, the playbook, the roadmap-input sessions. The dossier's decision line mentions years of integration work, but no verified entry states them, so give your own figure only if you want it in the arc. Then your reason for this role, in your own words; your material carries none | F1, F3, F4; the biography question is scored even when it sounds casual |
| D2 | "What are you actually playing with in API docs and schemas these days?" | JD | [generic] | Selection scaffold: pick something real you have looked at recently that bears on docs or schemas. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, the integration playbook, or how you would go about it | F4; a casual question on a JD topic is still scored |
| D3 | "Why Quartzline, and why now?" | CO | [generic] | The pack could not research Quartzline, so no company fact is scripted. Anchor on the JD's own lines (a partner-facing API platform, discovery with integration partners, adoption metrics) in your own words. If no company-specific reason comes to mind, say so plainly and give the part of the role that draws you | Company knowledge is the cost of the refused research; see Sources |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; concession words sourced by `prohibited_claims` items "Having held a product manager title or role" and "Having owned a product roadmap" | A1 compressed. Concede first ("I haven't held the product manager title, and I haven't owned a product roadmap"), then the adjacent case in one sentence from the two quotes. Hold through two follow-ups by returning to the quotes, never by adding to them. Concede specifically if pushed: the title and the roadmap, nothing more | A1 under time pressure; F1 |
| E2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold at the quote's own verb: "I led them." Answer slot: say which of the stages the quote names were yours and which were shared, in your own words; if you are not sure how a stage was split, say so plainly. Do not fold on the core claim to restore harmony, and do not extend it | Attribution probe on the pack's strongest entry; F3 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, E1 |
| R2 Shipped API or platform products | A4 |
| R3 Technical fluency: API docs, schemas | B4, C2, D2 |
| R4 Stakeholder management across engineering, sales, customers | B1, B3, C3 |
| R5 Agile delivery experience | A3 |
| Own the roadmap | A1, A2, B3 |
| Run discovery with integration partners | A5, B5 |
| Write specs and drive delivery with two engineering squads | B1, B4 |
| Define and track adoption metrics | B2, C2 |

## Reverse questions

Two arrive from the dossier and double as diligence on its open risks.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier risk that decision authority is asserted in the JD but not evidenced. It reads as diligence and answers what you need before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier risk that adoption metrics are named with no baseline stated. Shows you think in measures |
| 3 | "What would you want to see from someone coming from the integration side in their first 90 days to feel this was the right hire?" | Hands the hiring manager the chance to name their bar on the title gap, and you hear what they will actually test |
| 4 | "How do partner requests reach the squads today, and where do they get stuck?" | Shows discovery thinking and surfaces the process you would inherit |
| 5 | "What separates the people who have done well in this seat from those who have struggled?" | Invites their definition of success rather than your guess at it |
| 6 | "What does the rest of the process look like, and who would I meet next?" | Settles whether a peer bank for the squad leads is worth adding |

## Prohibited claims

Not coached anywhere in this pack, in any cell, slot or drill. The first three are the dossier's `prohibited_claims`; the last two are built here as stretched forms of your own quotes.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The F1 quotes at their own scope, plus the plain acknowledgment the field supports: "I haven't held the product manager title." |
| Having owned a product roadmap | Dossier `prohibited_claims`; `acknowledge_gap` area | The plain acknowledgment: "I haven't owned a product roadmap." No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The pack's observation is that nothing in the material shows it. The plain acknowledgment the field and the acknowledge_gap area support: "I haven't set prioritization for an engineering squad." No slot |
| Shaped the product roadmap | Inflated form of F1 and F7 | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The pack's observation: the quote says what went to product, not what product did with it. A5's slot stays on what happened to the evidence |
| Shipped an API or platform product | Inflated form of F3 | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The pack's observation: the quote is about integrations. A4's slot asks only whether any part of the API itself was yours |

## Sources

Provided: `tuesday-dossier.md` (version 1.1, generated 2026-08-14, which is older than today's 2026-11-05; if the posting or your evidence has changed since, tell me). Consumed: `role_profile` (the JD tier), `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the objection, risks, employer questions, prohibited claims) and `decision` (context only). Not present: `evidence_map`, `evidence_state`, `risk_register`. The pack's grading of the fit rows follows the handoff's own confidence and gap-type vocabulary where it graded an area, and is the pack's call where it did not (F3 to F5 and F7 to F9).

Queries sent:

- `Quartzline company values principles` — refused (search permission was not granted)
- `Quartzline interview process product manager` — refused
- `Quartzline partner API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed the values cheat sheet. Dropped: no values were in hand, and no loop source documents a values round |
| 2. `Quartzline interview process product manager` | unavailable | Would have fixed the loop and persona weights beyond this session. Weights rest on the hiring-manager relationship prior; later rounds are not established |
| 3. `Quartzline partner API platform strategy news` | unavailable | Would have grounded a CO or CASE question and D3 in current strategy. They are labeled generic |
| 4. interviewer name | n/a | No name was given, so no query could be formed; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or a pasted company values page and strategy brief → a values cheat sheet if a values round exists, grounded CO and CASE questions, and D3 and the persona weights rebuilt on Quartzline's real loop
- A deeper research pass (offered once: up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission too) → a strategy brief and the competitor frame for the differentiator questions
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep note → any focus areas or pre-declared deliverable, so coverage stops resting on the round-type prior
- Your answers to the slots in F3, F4, F5, F7, F8 and F9 → those rows become grounded story maps instead of slots, and A4, C2, C3 and A5 sharpen with them
- Anything inspectable from the roadmap-input sessions (an agenda, notes or a deck) → raises that entry from medium and removes the probe risk behind A5
- If you will also meet the squad leads → a Peer Evaluator bank, and the seam between the PM and the squads, can be added
