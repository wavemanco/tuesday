**Your resume as written can't be made to meet the "3+ years data engineering" must-have, and no wording will change that.** What it can do is lead with the evidence you do have: the dbt models, the star schema, the nightly job fixes and the tests. Everything below is proposed, and nothing is applied. You approve rows, and I build the new resume only from those.

I've treated your message as your resume, so the quotes below are your own sentences. Whether this role is worth applying to, given that must-have, is job-underwriter's question rather than this one.

## Edit ledger (`resume_edits_pending_approval`)

Target bullet order if all rows are approved: E1, E2, E3, E4, E5, then E6. The summary (E7) goes at the top.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE" | `compress` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to our nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote some Python scripting to pull vendor APIs on a cron" (the pandas half stays in your skills line, unchanged) | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to the last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |
| E7 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart; designed its star schema with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |

What the audit held back:
- **E2, E7:** I kept "with our then-DE". The star schema is a joint design, and "with" is the qualifier an interviewer will probe.
- **E5:** I kept "some" and "scripting". Moving the line up doesn't make it production Python, and it isn't claimed to be.
- **E7:** I kept "5 years" exactly as you wrote it. It could mean five years as a Senior Data Analyst or five years as an analyst overall, so I took no reading of it. Tell me which it is before you send this out.
- **Titles:** I did not retitle you, because "Senior Data Analyst" is the equivalent title you hold.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | Named absence A1. Adjacent work is in E1 to E5. | `[grounded]` nothing you wrote describes a data engineering role or stretch |
| R2 | Production Python | important | not_evidenced | Recall prompt C2. E5 is scheduled scripting, but nothing says it is relied on. | `[grounded]` |
| R3 | Airflow or equivalent orchestration | important | not_evidenced | Recall prompt C1. You said "Never used Airflow". Whether your cron and dbt scheduling counts as "equivalent" depends on the answer. | `[grounded]` |
| R4 | Dimensional modelling | important | surfaced_by_edit | E2, E7 | `[grounded]` |
| R5 | Model the warehouse | important | surfaced_by_edit | E1, E2, E7 | `[grounded]` |
| R6 | Own data quality | important | surfaced_by_edit | E4. This covers tests only, not ownership. | `[grounded]` |
| R7 | Own SLAs | important | not_evidenced | Recall prompt C3 | `[grounded]` |
| R8 | Build batch and streaming pipelines in Spark and Kafka | important | not_evidenced | Named absence A2 | `[grounded]` |
| R9 | Streaming experience | preferred | not_evidenced | Named absence A2 | `[grounded]` |
| R10 | Partner with analytics on requirements | important | surfaced_by_edit | E2. You worked across the analytics and data engineering line on the orders mart. | `[grounded]` |

## Recovery per gap

Recall prompts, each with a matching question in the closing block:

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | important | A nightly dbt job you fix when it breaks, and Python pulls "on a cron". Nothing says what schedules the dbt job or who owns it since "our then-DE". | The posting says "Airflow or equivalent", so a scheduler you ran day to day could count, but only if you say what it was. | dbt Cloud or another scheduler running the nightly job; retries, dependencies or alerts you set up on it; taking over the job when the DE left | The job config or DAG, a run history, a runbook | `[grounded]` what the resume does and does not say; `[generic]` what a screener usually does with "or equivalent" |
| C2 | Production Python | important | Python "for analysis" plus cron-run API pulls. Nothing says anyone depends on the output or that failures are handled. | "Production" is the word that separates the analyst line from the engineer line in this posting. | The API scripts feeding a table others use; failure handling or alerting; code in a shared repo | The repo, the cron entry, a failure alert | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Own SLAs | important | Tests were added to the nightly job. No freshness target or deadline is mentioned. | The posting lists SLAs next to data quality as things the hire owns. | A dashboard that must be fresh by a set time; a stakeholder notified when the job fails; a freshness check | A freshness test, a status message, a stakeholder thread | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

Named absences:

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | 3+ years data engineering | You have 5 years as an analyst, with data engineering-flavoured work inside it. No wording turns that into 3 years as a data engineer. | Either C1 to C3 show you owned pipelines in practice, or you aim at analytics engineering roles that don't ask for the title. Otherwise carry it as the main risk of this application. | `[inferred]` from the posting marking it must-have; a titled-years requirement is likely read literally |
| A2 | Spark, Kafka, streaming | You have never used Spark or Kafka, and the streaming requirement is only a plus. | A small project: a Kafka producer feeding a Spark or dbt job, kept in a repo you can show. For this posting, though, the plus matters less than A1. | `[grounded]` your own statement; `[generic]` project path |

## Not written, and why

- "Data engineer" or "data engineering experience": your title is analyst, and the posting makes this a must-have.
- "Built and owned pipelines": you fixed a nightly job and added tests. Building and owning is a different claim.
- "Airflow", "Spark", "Kafka" anywhere, including a skills line: you said you have never used them.
- "Data quality framework", "SLA ownership", "orchestration experience": tests were added to a job. The framework, the SLAs and the orchestration are not in your account.
- "Production Python": see C2. I'll write it only if you confirm it.
- "Partnered with analytics": you are the analytics side, and the word "partner" would flip which side you sat on.

## Parse-safety check

Your resume came as pasted text, not a file. These checks could not run: multi-column layout, tables and text boxes, images and skill bars, content in headers or footers, non-standard section headings, and file type. Send the file and I'll run them. Use a `.docx` or a text-layer PDF.

## Upgrade menu

- **Resume as a file:** this unlocks the parse-safety check.
- **The nightly dbt job config or run history, or a cron and repo screenshot:** this could move R2, R3 and R7 from not_evidenced to evidenced.
- **Prior resume versions:** earlier drafts often hold pipeline or ownership detail that was dropped.
- **A one-line target statement (offered, not owed):** "Moving from analytics into data engineering" traces to your own words and puts the pivot in front of the reader. It would be a new row for your approval, and I'll add it only if you ask.

## Questions

C1 — What runs your nightly dbt job (dbt Cloud, cron, Redshift scheduler, something else), and since the then-DE left, who has owned it?
C2 — Where do the vendor-API scripts live and run, does anything downstream depend on their output, and what happens when one fails?
C3 — Does the orders mart have a deadline or freshness expectation (a dashboard due by a set time, someone told when it's late)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.