I found the strategy page, and its snippet matches the four points you gave me. I'm fetching the full page to check for anything more before I write the pack.
The write to the working directory was declined, so I'm saving the pack to the session scratchpad instead.
Dara, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-canned-9a3c886f/58ebc8e0-978d-4ea5-b297-8c2be5ffe33f/scratchpad/ashgrove_credit_union_member_experience_lead_interview_pack.md`. The write to the project folder was declined, so it's in the session scratchpad.

The pack covers all three rounds, with 30 questions in total (8, 10 and 12) and reverse questions for each round. It also has a shared fit snapshot, a list of claims it won't coach, and a values cheat sheet for the panel.

- **Dates:** I took the interviews to be on 21 October, as your message says. My clock reads 5 November, so if the interviews have already happened, the pack is better used as a debrief.
- **What I checked online:** I found ashgrovecu.org/news/strategy-2026 and read it. It holds the same four lines you gave me and nothing more, so the strategy questions rest on those four points. You already had the values page in hand, and I made no other searches.
- **Biggest risk:** You've never worked in a contact centre, and the job owns complaints across branches and the contact centre. Expect that question in every round. E1 is the full rehearsal, with B1 and K1 as the short forms.
- **Second gap:** You've never presented above regional level (E3). I wrote that answer as an honest sentence followed by a plan for how you'd prepare.
- **Where your evidence stops:** Your background gives four things to quote: the complaints log, training tellers on the escalation script, the monthly spreadsheet, and six years in banking. For anything beyond those, the pack gives you "answer slots" with an honest second branch. Examples are what the spreadsheet counted, whether the log was tied to any rules, and whether you've worked with a digital team. Fill these in with what's true, or take the second branch.
- **Branch managers and the hub plan:** The branch managers on the panel may work at branches caught up in the eight-into-five plan. That's my inference, not a fact. I Wrote I3 and R3.4 so they work whether or not it's true.

Say the word and I'll run a live drill as the Skeptic on E1, or as the panel on the I1 escalation case. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union — Member Experience Lead — interview pack for Dara

Loop mode: three rounds on 21 October. Round 1: the recruiter (30 minutes). Round 2: the Head of Member Services, who would be your manager (45 minutes, mostly behavioural). Round 3: a panel of two branch managers (60 minutes, with a 20-minute complaint-escalation case; the panel also scores the four values). Individual interviewers beyond their roles have not been assigned, so there is no interviewer read.

Highest-ROI prep: E1, with B1 and K1 as its other two forms. F2 is a gap you stated, and it sits on the JD's headline duty.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every answer slot is an instruction for the interview: answer it with what is true, in your own words, and take the second branch when the first is not true for you.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behaviour shows the published values |
| EXP | Work-experience deep-dive | Whether the claims on your background survive scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

IDs run by persona across the pack: A to C are Round 1, D to G are Round 2, H to K are Round 3. Your background figures here are durations (six years, the last three), not metrics, so there is no defend-the-number question; the pack supplies no figure for you.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you pasted. Evidence is your own words from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat beyond the log likely. If any step beyond the log was yours, say which and what you did, in your own words; if there was none, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim that branch work covers it, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The sentence says a monthly complaints spreadsheet, not what it counted. Answer slot: if it counted volumes or resolution times, say which and how, in your own words; if it counted something else, or neither, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on what the training involved likely. Say what it covered and how you ran it, in your own words; if it was the script delivered as written, or the format was someone else's, say so plainly and stay with the fact that you trained them |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show any work with a digital team. Answer slot: if you have worked with a digital or online team in any way, say what the work was and what part was yours; if you have not, say so plainly and say what you would ask them first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as you wrote it: six years in retail banking, the last three as a branch supervisor. Let the interviewer place it; do not relabel it in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | The sentence says a formal log; it does not show what rules or deadlines governed it. Answer slot: if you know what the entries had to meet, say it in your own words; if none applied that you know of, or tracking it was not yours, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first senior audience, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms and says spreadsheet, not Excel. Say it as you wrote it: you built the monthly complaints spreadsheet your regional manager uses. Name the tool only if it was Excel |

## Prohibited claims (shared)

Built before the banks, so every guidance cell is written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the branch's log, not the process end to end. E2's slot stays inside the log |
| Has worked in a contact centre, or knows how one runs first-hand | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." The slot in E3 asks only who the most senior person was and what you showed them |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." The limit is the pack's observation: your material says new tellers, not supervisors |
| Reported complaint volumes and resolution times to leadership | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." G2's slot asks only what the spreadsheet counted |
| Handled the complaints the JD describes as regulated | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." G1's slot asks only what the log had to meet |
| Six years in financial-services customer operations | Inflated form of F6 (the JD's vocabulary on your history) | F6's quote as you wrote it: "6 years in retail banking, the last 3 as a branch supervisor" |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 own the process end to end | E2, J2, I1 |
| F2 across branches and the contact centre | B1, E1, K1 |
| F3 monthly reporting on volumes and resolution times | G2 |
| F4 coach branch supervisors on escalations | D1, I2, J1 |
| F5 work with digital teams on self-service journeys | B2, D3, F1 |
| F6 four-plus years in financial-services customer operations | A4, A1 |
| F7 experience handling regulated complaints | G1 |
| F8 present to senior leaders | E3, B2, D2 |
| F9 Excel reporting | G2, A2 |

## Sources

Provided: the JD you pasted; the four values you copied on 12 October 2026 from ashgrovecu.org/about/values (pasted text, so not fetched); the recruiter's email; your strategy-brief summary; your background message.

Searches and fetches sent:

- Search "Ashgrove Credit Union 2026 strategy brief digital branches hubs" returned one result: https://ashgrovecu.org/news/strategy-2026
- Fetch of https://ashgrovecu.org/news/strategy-2026 returned a four-line summary identical to the four points you gave: 40% of member service to digital channels by 2028; eight branches consolidated into five hubs over 2027; a small-business lending product in Q1 2027; app-only banks as the main competitive pressure.

Research tier: L1 — searches 1 of 6, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the loop: three sessions, who runs each, the 20-minute case, and the panel scoring the four values |
| 3. `Ashgrove Credit Union strategy` | yes | Confirmed your four points against the published page; it moved nothing, because the page holds the same four lines |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

The loop is established by the recruiter's email, so no archetype fallback applies. A values-style round is detected: the email says the panel is the values round.

---

# Round 1 — Recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk through your background and motivation | Highest. The email says "30 minutes with me", and the relationship prior for a recruiter screen is Conversational plus a light Skeptic | A pre-scripted 90-second arc built from your quoted sentences (A1); treat casual questions about the posting as scored |
| Skeptic | Quiet check on the gaps | Medium. F2 and F8 are gaps you stated, and a screen is where they are first probed | Say the stated gap in one sentence, then the plan (B1, B2) |
| Values/Behavioral | Why Ashgrove, and a first look at the values | Lower. The email puts the values scoring in Round 3, but the published values are likely to colour motivation questions | One value, chosen honestly, by its exact name (C1, C2) |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. What led you to a credit union complaints role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Ninety seconds in three beats your sentences state: six years in retail banking, the last three as a branch supervisor; the formal complaints log; the monthly complaints spreadsheet. The fourth beat, why this role and why Ashgrove, is your own reason. Answer slot: say in your own words what draws you here; if it is mostly the work and not the employer, say so plainly and stay with the work | The biography question opens most screens, and F6, F1 and F3 supply the arc. EXP because it tests whether the background holds up |
| A2 | "In thirty seconds: what does a Member Experience Lead actually do here, as you read the job?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Give the JD's four duties in its words: own the complaints process end to end across branches and the contact centre; report monthly on complaint volumes and resolution times; coach branch supervisors on escalations; work with digital teams on self-service journeys. Then one sentence on which duty your work sits nearest, using a quote at its own scope: the log, the escalation script training, or the spreadsheet. On the digital duty your material is silent. Answer slot: if you have worked with a digital team, say how; if you have not, say so plainly and say what you would ask them first | Tests whether the posting was read; covers F1, F3, F4, F5 and F9 in one answer |
| A3 | "Why a credit union rather than a bank?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | The question rests on your six years in retail banking. Use only published facts: member-owned (the JD), the four values by exact name, and the strategy brief's own words (40% of member service to digital channels by 2028; app-only banks as the main competitive pressure). Pick one and say what it means for members. Answer slot: say which published fact or value you actually respond to and why; if you cannot point to one yet, say so plainly and say what you want to find out across these three rounds | Motivation consistency is the recruiter's likeliest read. CO because it tests homework depth, with motivation as the second call |
| A4 | "The post asks for four-plus years in financial-services customer operations. Talk me through your most recent role against that." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Say it at the quotes' scope: six years in retail banking, the last three as a branch supervisor; the formal complaints log; training new tellers on the escalation script. Let the interviewer decide whether that is customer operations; do not relabel it in the JD's words. Team size, branch size and volumes: name them only if you know them, because the pack supplies none | F6 is the requirement most likely screened literally. JD because it scores a stated requirement |
| B1 | "You haven't worked in a contact centre, and this role covers branches and the contact centre. How would you get up to speed?" | JD | [grounded] "Never worked in a contact centre" | Acknowledge it plainly first: "I've never worked in a contact centre." Then a plan, said as future: what you would ask to see and hear in the first weeks (how complaints arrive and are logged there, who hands off to whom, how its escalations reach branches) and who you would learn from. The plan names nothing about Ashgrove's contact centre, because your material does not. Do not bridge with branch work you have not said reaches the contact centre | F2 is a stated gap on the JD's headline duty. This is the shortest rehearsal of the pack's highest-ROI objection; the full form is E1 |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose honestly from what you have stated: the contact centre (F2) or presenting above regional level (F8). Say it in one sentence in your words, then the plan. If you choose the digital duty instead, your material is silent on it. Answer slot: say what you have done with digital teams, if anything; if nothing, say so plainly and say what you would ask first | The Skeptic's standard stem. Naming a real weakness first costs less than having it found. F2, F5 and F8 are the candidates |
| C1 | "Which of our four values spoke to you when you read them, and why?" | VAL | [grounded] "trained new tellers on our escalation script" | Name one by its exact name. If it is Plain Words, story-mapped on F4: you trained new tellers on the escalation script. Answer slot: the value says if a member needs it explained twice, we wrote it wrong, so expect a probe on the script's wording. If the wording was something you shaped, say how; if it was fixed and not yours, say so plainly and stay with the training. If you pick another value, use its row in the cheat sheet | The values are the Round 3 scoring sheet, so the recruiter may test familiarity early. VAL because it asks for a published value, not generic virtue |
| C2 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Theme: Own the Fix. Story-mapped on F1: the formal complaints log, handled by you. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on one case. If you kept hold of a complaint from the log until it was resolved, say which kind, what you did and what part was yours; if the log was for recording and others resolved the cases, say so plainly and stay with the log you handled | Own the Fix is the value closest to the JD's complaints ownership. VAL because it scores a published value |

## Reverse questions for the recruiter

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What are the salary range and working pattern for this role, and where is it based?" | The JD gives neither, and settling terms in the screen avoids a late mismatch |
| R1.2 | "When you know who is on the Round 3 panel, could you tell me their roles and branches?" | The interviewers are unassigned, and names let you research their public professional footprint |
| R1.3 | "For the 20-minute case, is there anything to prepare, and is it a written scenario or a conversation?" | The email gives the length and the topic but not the format |
| R1.4 | "How does the panel score against the four values — particular examples, or an overall read?" | Shows you treat the values as a scoring sheet and gets the format from the person who knows it |
| R1.5 | "Does the contact centre sit in the same team as the branches under Member Services, or elsewhere?" | Shows you read the JD's scope, and the answer shapes how you approach E1 |

---

# Round 2 — Head of Member Services (45 minutes, your future manager)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario and "tell me about a time" questions | Highest. The email says "mostly behavioural", which lifts it above the Case/Strategist prior for a hiring manager | Story-map only where a quote carries the story; use a selection scaffold with its honest branch where none does (D1 to D3) |
| Skeptic | Probes on the contact centre, the end-to-end scope and senior presenting | High. The hiring-manager prior is Case/Strategist plus Skeptic, and F2 and F8 are stated gaps | The deepest rehearsal in the pack is E1: acknowledge, bridge from stated work only, name the limit, give the plan |
| Case/Strategist | Strategy-based live problems | Lower. The hiring-manager prior is high, but the email's "mostly behavioural" trims it to two questions | Clarify, objective, segmentation, approach, metrics, risks; use the brief's own words (F1, F2) |
| Data-Driven Prober | Line-by-line reading of the log and the spreadsheet | Lower. Two of your stated sentences are the only CV-style claims to read | Say only what you can stand behind under a second question (G1, G2) |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you helped a colleague through a difficult escalation." | JD | [grounded] "trained new tellers on our escalation script" | Theme from the JD's coaching duty. Story-mapped on F4: you trained new tellers on the escalation script, which is the beat the quote states. Answer slot: the JD's coaching line points at supervisors, so expect a probe on whether you have coached at that level. If you have, say who and what you did; if the people you trained were tellers, say so plainly and stay with the training. "We" for context, "I" for what you did | F4 is adjacent work, and this is where it gets tested. JD because it scores the coaching duty |
| D2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, because none of your sentences carries this story: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you held your point, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard Values/Behavioral stem, and a safe place to rehearse the F8 gap in a behavioural frame. VAL because it scores a behaviour, not a requirement |
| D3 | "Tell me about a time you worked with a specialist team, such as digital, on a problem." | JD | [generic] | Theme from the JD's digital duty. Selection scaffold: pick a time you worked with a team outside your own on something that was not yours alone to fix; it needs a named team, what each side owned, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material is silent on digital teams (F5) | F5 is the requirement with no evidence at all. JD because it scores the digital duty |
| E1 | "You haven't worked in a contact centre, and this role owns complaints across branches and the contact centre. Where does that leave you?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | The pack's highest-ROI rehearsal. The answer: "I've never worked in a contact centre." Then your quotes at their own scope: the formal complaints log and training new tellers on the escalation script, both branch-side, and say branch because that is what the quotes show. Then the limit, named before it is asked for: you cannot yet speak to how a contact centre handles a complaint. Then the plan, as future. Follow-ups to rehearse: what would you do in your first 30 days; what if the contact centre team disagrees with how you would handle an escalation; why not hire someone who has run one. Hold through the first two, then concede specifically on the third: contact-centre operations are what you would have to learn, and the log and the script training are what you can describe. Never claim branch work transfers unless you can say how, in your own words | F2 is a stated gap on the headline duty, so this question arrives in some form in every round. JD because it scores the stated duty |
| E2 | "'End to end across branches and the contact centre.' Which part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log" | The hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if any step beyond the log was yours, say which and how you decided, in your own words; if there was none, or it was not yours, say so plainly and describe the log you handled. The honest branch is a limit, not a confession. Hold through two follow-ups by returning to the log, never by adding to it | F1 is where the JD's scope presses hardest on a branch-level background. JD because it scores the duty as written |
| E3 | "This role presents to senior leaders. What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I've never presented to anyone above regional level." Answer slot: say who the most senior person was that you have presented to and what you showed them, in your own words; if you have presented only informally, or not at all, say so plainly. Then the plan, as future: what you would do before a first senior audience, such as agreeing the one decision you need from them and bringing only figures you can explain. Do not present regional-level exposure as senior-leader experience | F8 is a stated gap on a listed requirement. JD because it scores that requirement |
| F1 | "Ashgrove wants 40% of member service on digital channels by 2028. What do you think happens to complaints as that shifts, and what would you want to know first?" | CO | [grounded] | Clarify first, as questions and not facts: where complaints start today, how one raised on a digital channel reaches the formal process, who owns the digital journey. Then objective, segmentation by channel and complaint type, approach, metrics, risks. State your hypothesis early and mark it as one. Use the brief's own words: 40% of member service to digital channels by 2028, with app-only banks as the main competitive pressure. Challenge one premise respectfully, such as whether the 40% counts contacts or members. No claim about your past is needed, and your material is silent on digital (F5) | The strategy brief's headline target, and the CO question most candidates will not prepare |
| F2 | "Eight branches are becoming five hubs over 2027. A member from a branch that's merging says nobody told them plainly. Walk me through your first hour." | CASE | [grounded] | A live problem. Start with the member: listen, restate, and say what happens next in plain words before touching process. Clarify what they were told and by whom, and whether others are affected. Objective: this member first, then the pattern. One named person holds the complaint until it is solved. Propose that merge-related complaints are visible in the monthly report. Do not assert what Ashgrove has told members; you do not know | Joins the brief's hub plan to Plain Words and Own the Fix. CASE because it is a live problem from the role |
| G1 | "Tell me about the formal complaints log you handled." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped: the log was formal, it was the branch's, and you handled it; tell those beats in your words. Answer slot: the JD asks for experience handling regulated complaints, so expect a probe on what rules or deadlines the log had to meet. If you know, say them in your own words; if none applied that you know of, or tracking them was not yours, say so plainly and stay with the log you handled. Describe it as the quote does and add nothing | F7 is the requirement with the widest gap between the quote and the wording. JD because it scores the stated requirement |
| G2 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped: you built it, it is monthly, and your regional manager uses it. Answer slot: the JD asks for monthly reporting on complaint volumes and resolution times with Excel, so expect probes on what the spreadsheet counted and what tool it was in. Say what it counted and how, in your own words; if it did not count volumes or resolution times, or it was not Excel, say so plainly and stay with the spreadsheet you built. The quote gives no figures, so the pack supplies none | F3 and F9 both rest on this one sentence. JD because it scores the reporting requirement; the EXP check on attribution is K2 |

## Reverse questions for the Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "The role owns complaints across branches and the contact centre. What is working there today and what isn't?" | Uses the JD's own scope and shows you want the real state, not the brochure |
| R2.2 | "As 40% of service moves to digital by 2028, which complaints do you expect to grow or shrink, and who holds the fix today?" | Ties the brief's target to Own the Fix |
| R2.3 | "With eight branches becoming five hubs over 2027, how do you see escalations changing for supervisors?" | Shows you thought about the people you would coach |
| R2.4 | "Who reads the monthly complaints report today, and what do they decide from it?" | Turns the reporting duty into a question about use, not format |
| R2.5 | "Will the small-business lending product in Q1 2027 bring a new kind of complaint I should plan for?" | Uses a brief fact few candidates will, and shows forward planning |

---

# Round 3 — Panel of two branch managers (60 minutes, including the 20-minute case; values scored)

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored stories against the four values | Highest. The email says "The panel is also the values round — they score against the four values" | One story or scaffold per value, with "we" for context and "I" for what you did (H1 to H4, cheat sheet below) |
| Case/Strategist | The complaint-escalation case, live | High. The email says "a 20-minute case on a complaint escalation" | Clarify before structuring, think aloud, challenge one premise (I1 to I3) |
| Peer Evaluator | Seam, reciprocity and credit questions from the people whose supervisors you would coach | Medium. Branch managers are the likely day-to-day counterpart for the coaching duty, which is the pack's reading of the email and the JD | Offer seam principles, not a seam you do not know; reciprocity framing (J1 to J3) |
| Pressure | Interruptions and time-boxed challenges inside the case | Lower. The case invites follow-ups; a panel can also press on the gaps | Pause, restate, hold through two follow-ups, concede specifically (K1, K2) |

The panel may include managers whose branches are in the eight-into-five plan. That is this pack's inference from the brief and the email, labelled as such: do not assume it, and do not avoid the subject either (I3, R3.4).

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Theme: Members First. No sentence of yours states a decision made from the member's side, so this is a selection scaffold: pick a time you weighed what a member needed against what a process or a figure asked. It needs a named decision, what the member needed, and what it cost you or the branch. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log told at its own scope, or how you would handle it | Members First is the first of the four scored values. VAL because it scores a published value |
| H2 | "Tell me about a time something had to be explained twice, and what you did about it." | VAL | [grounded] "trained new tellers on our escalation script" | Theme: Plain Words. Story-mapped on F4: you trained new tellers on the escalation script. Answer slot: the value says if a member needs it explained twice, we wrote it wrong, so expect a probe on wording. If you changed any wording so it landed first time, say what and why; if the wording was fixed and not yours, say so plainly and stay with the training | The only value your quoted material touches directly. VAL because it scores a published value |
| H3 | "Tell me about a time you thought about the town a branch serves, not just its figures." | VAL | [grounded] | Theme: Neighbours, Not Numbers. No sentence of yours carries this story, so it is a selection scaffold: pick a time you took account of the people or place a branch serves in a decision. It needs a named place or group, the decision, and what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. The brief's hub plan makes this value live; do not presume which branches are affected | The value the hub plan puts under most pressure. VAL because it scores a published value |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Theme: Own the Fix. Story-mapped on F1: the formal complaints log, handled by you. Answer slot: if you kept hold of a complaint from the log until it was resolved, say which kind, what you did and what part was yours; if the log was for recording and others resolved the cases, say so plainly and stay with the log you handled | The value that matches the JD's central duty. VAL because it scores a published value |
| I1 | "A member's formal complaint has come back to the branch for the third time, and the supervisor has escalated it to you. Where do you start?" | CASE | [grounded] | The email says the case is a complaint escalation and lasts 20 minutes; the real scenario is unknown, so this one rehearses structure. Clarify first: what the member is asking for, what they have been told and by whom, what rules or deadlines apply, who has touched it. Then objective, the member's outcome first and a fix that holds; approach, with the member told in plain words, one named person holding it, and the supervisor coached on what to do next time; metrics, such as time to resolve and repeat contact; risks. Think aloud, challenge one premise, and say what you would check where you lack knowledge. No claim about your past is needed | The pre-announced case. CASE because it is a live problem from the role |
| I2 | "A branch supervisor tells you the escalation script doesn't work for the kind of complaint in front of them. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | A live problem. Ask what happened and what they tried, then what the script was meant to do. Handle the member's complaint first, then coach, and feed the gap back to whoever owns the script. The only thing from your past is the quote at its own scope: you trained new tellers on the escalation script. Answer slot: if you have coached anyone through a script that did not fit, say how; if you have not, say so plainly and answer as a plan | Tests the coaching duty live, with the branch-manager panel as the audience for it. CASE because it is a live problem |
| I3 | "Eight branches become five hubs over 2027. How should complaints be handled differently for members of a branch that's merging?" | CO | [grounded] | Use the brief's words and do not presume which branches or what happens to staff; ask what has been decided and what has not. Offer principles, not specifics: tell members plainly, one named person holds each complaint, merge-related complaints are visible in the monthly report. Link Members First and Neighbours, Not Numbers: a member of a merging branch loses a local counter. You do not know whether the panel's own branches are affected, so ask and do not assume | The brief's most sensitive fact, put to the people who may live with it. CO because it tests thinking at the company's altitude |
| J1 | "What would you need from a branch manager to make coaching your supervisors work, and what would you bring?" | JD | [grounded] "trained new tellers on our escalation script" | Reciprocity. What you bring is the quote at its own scope: you trained new tellers on the escalation script. What you need is a principle, not a claim about their branch: time with supervisors, and their view of what escalations are hardest. Do not pretend to know their branch | F4 with the people who would be on the receiving end. JD because it scores the coaching duty |
| J2 | "Where's the seam between your role and a branch manager's, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not the seam: the person who finds a complaint keeps hold of it until it is solved; the lead owns the process and the monthly report; the branch manager owns the branch's relationship with its members. On disagreement: raise it privately, use the member's outcome as the shared test, and escalate only after. Say these are proposals to test with them | F1 as seen from the branch side. JD because it scores the cross-branch ownership duty |
| J3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold, because none of your sentences carries this story: pick a time work spanned two teams and credit could have gone to one. It needs a named piece of work, who did what, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The Peer Evaluator's standard probe. VAL because it scores a behaviour |
| K1 | "Sixty seconds: why you, rather than someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Pause and restate the question. Hold only what the quotes carry: the formal complaints log, the escalation script training, the monthly spreadsheet, each at its own scope. Hold through two follow-ups, then concede explicitly: "I've never worked in a contact centre." Do not claim you would learn faster or that branch knowledge is better, because nothing you have said shows either | The Pressure form of the pack's highest-ROI objection. JD because it scores F2 |
| K2 | "That spreadsheet — how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold on your own verb: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else supplied part of it, say what they did; if you built all of it, say so plainly and do not enlarge what it did. Hold through two follow-ups by returning to the sentence | The attribution probe exists to catch inflated claims. EXP because it tests what was actually yours |

## Values / principles cheat sheet (Round 3)

Official names from the page you copied on 12 October 2026. Working meanings are paraphrased.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, no story in your quotes: pick a time you weighed what a member needed against what a process or a figure asked, with a named decision and its cost. If none comes to mind, say so plainly, then give the nearest thing your material carries (F1: "I handled the branch's formal complaints log") or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | F4: "trained new tellers on our escalation script". Answer slot as in H2: say what you changed in the wording if anything; if the wording was fixed and not yours, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold, no story in your quotes: pick a time you took account of the people or place a branch serves, with a named place or group, a decision and what you gave up. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". Answer slot as in H4: say which complaint you kept hold of and what you did; if others resolved the cases, say so plainly |

## Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What do your supervisors find hardest about escalations today?" | Asks for their view of the coaching duty before offering yours |
| R3.2 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for peers |
| R3.3 | "Which of the four values do you see tested most in your branch week to week?" | Invites a real example and shows you treat the values as practice |
| R3.4 | "What are members in your town asking about the hubs plan?" | Neighbours, Not Numbers in practice; ask it gently, because the panel may be affected |
| R3.5 | "What would you want me to have learned about your branch by the end of my first month?" | Turns a first-month plan into something the panel owns |

---

## Upgrade menu

- The names or roles of the Round 3 panel and the Head of Member Services → an interviewer read from their public professional footprint, persona weights per panel member, and a reverse question tied to each one's path
- Your answers to the answer slots in F1, F3, F4, F5, F7 and F9 → those rows and the banks that draw on them regenerate from your words, and several slots become mapped stories
- Your CV, or any further sentences about your branch work → more of the scaffold rows (D2, D3, H1, H3, J3) become mapped stories
- The recruiter's answers to R1.3 and R1.4 on the case format and the values scoring → a case rehearsal built to its real format
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → role-family loop reports and recent organisation context; the strategy page held only a four-line summary, so the CO and CASE rows rest on those four points
- A `tuesday-dossier.md` from an earlier fit assessment, if you have one → verified evidence and prohibited claims set elsewhere would sharpen the objection rehearsal
