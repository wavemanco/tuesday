I'm building your prep pack as a saved file. Web search was refused in this session, so everything about Kelverton comes from your message and the recruiter's email.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-5-denied-2f794a66/138ac58b-a9c9-4bba-b42a-727d20c4fbf7/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for the panel round with Deepa and Ross, using only your message and the recruiter's quoted email.

- **No web research ran.** All six searches were refused. The pack has no Kelverton values, strategy or interviewer background, and the Sources section lists each refused query.
- **I haven't seen the market report.** The POV section tells you how to use it: one item you agree with, then one departure, then an anti-pick. The report-specific parts are left for you to fill.
- **The first save location was also denied.** The file is in the scratchpad folder instead.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the JD text? It would turn the three role-family rows (F4 to F6) into quoted ones and might add requirements I can't see.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Panel round: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Sixty minutes: a 15-minute POV from you, then Q&A, per the recruiter's email as you quoted it. Session mode.

Built from your message and the recruiter's quoted email only. No JD, CV or market report text was supplied, and web research was refused, so the Sources section shows what is missing and the upgrade menu says what each input would unlock.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. Anything in quotation marks inside guidance is your own sentence or the recruiter's. Where the pack cannot know something about your past, the cell holds an answer slot: an instruction for the interview, with two honest branches, not a question for you now.

Type key:

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior demonstrates the company's published values (no VAL questions here: no values-style round was detected) |
| EXP | Whether the claims in your background survive scrutiny, and what was actually you |
| JD | Stated responsibilities and requirements, including the gaps |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role, structure and reasoning |

Provenance labels: `[grounded]` traces to a document you supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about Kelverton. Bank IDs skip the letter F so they never clash with the fit rows F1 to F6.

## Prep triage (about four hours, in this order)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 90 min | Re-read the market report once with two jobs only: pick one item you agree with and one you would depart from. Then build and speak the POV twice, timed to 15 minutes | Graded deliverable section; A1 |
| 2 | 45 min | Rehearse the rail-gap objection aloud until it is boring, including both follow-ups | B1 |
| 3 | 45 min | Write, in your own words, your answers to the four figure slots on the numbers, and say plainly anything you do not know about how they were counted | F3; C1, C2, C3, D2 |
| 4 | 30 min | Speak the commercial case structure once, start to finish | C4 |
| 5 | 30 min | Choose your reverse questions and rehearse the first 90 seconds of your story | Reverse questions; G1 |

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's words where she gave them, quoted. Rows F4 to F6 are role-family requirements written without a posting, so they are plain prose labeled `[generic]` and raise no answer slot.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "9 years in partnerships" — your message, "last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says you ran the ISV channel at a payments company, not that you set a direction for operator partnerships, and nothing is inspected behind it. The words stay there: "Nine years in partnerships, the last four at a payments company running the ISV channel." Answer slot: the recruiter's "where you'd take" line makes a probe on how the channel's direction was decided likely. If you set or shaped it, say how, in your own words; if you did not, or it was set for you, or there was no such step, say so plainly and stay with running the channel |
| F2 | "what it means for the operators themselves" — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning and does not show whether any of it touched train operators; nothing is inspected behind it. The words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter's line makes a probe on your phrase "the operator world from the other side" likely. Say which side you meant and what the work was, in your own words; if it did not involve train operators, say so plainly and stay with bus and light rail network planning |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "took it from 6 partners to 40" — your message, "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material gives a count of partners and a figure of influenced revenue, not commercial terms, and the words keep "influenced": "I took the ISV channel from six partners to forty; the figure I can speak to is roughly £4M of influenced revenue." Answer slot: the figure raises four probes. How it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; answer each in your own words, and if you do not know how it was counted, say so plainly |
| F4 | Carrying a direct revenue target (role-family expectation, no posting supplied) `[generic]` | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The words: "I haven't carried a direct quota; what I can speak to is influenced revenue." Then how you would take on a number here, said as a plan and never as a past. Whether this role carries a quota is not established, because no posting was supplied. Nothing added to make the gap feel smaller |
| F5 | Growing a partner network (role-family expectation, no posting supplied) `[generic]` | "took it from 6 partners to 40" — your message | medium | [inferred] | none | No gap, but a figure with nothing inspected behind it, so expect a probe. Inferred because the requirement is this pack's role-family reading set against your sentence. Lead with the count in the quote's own terms, six to forty, because a number beats an adjective; the limit is that it counts partners in an ISV channel |
| F6 | Selling or partnering into rail operators (role-family expectation, no posting supplied) `[generic]` | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The words: "I haven't sold into rail specifically." Then what you would learn first, said as a plan and never as a past |

Proposed language in this table is pending your approval. No row is a hard gate: the material states no eligibility, location, travel or schedule term, and the JD, if you can paste it, may add some.

## Graded deliverable: the 15-minute POV

Proposed language in this section is pending your approval. This is built without the market report's content, because it was not supplied; every instruction that depends on it says so.

What the recruiter asked, quoted: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

| Fact to build on | Row | Exact words |
|---|---|---|
| Channel you ran | F1 | "last 4 at a payments company running the ISV channel" |
| Operator-side background, at its scope | F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| Your figure, if pushed | F3 | "roughly £4M of influenced revenue" |

Three defensible theses. Choose one as the spine; each carries a concession you make before they do.

| # | Thesis | Outline | Mandatory concession | Provenance |
|---|---|---|---|---|
| T1 | Organise the 18 months around changes operators can see, one partnership at a time | Name the change for the operator first, then the partner and commercial shape that delivers it; sequence months 0 to 6, 6 to 12 and 12 to 18 by what the operator sees | This makes a volume target harder to commit to, and Ross will ask what it does to revenue timing. Say so first and name the first thing you would measure | [inferred] derived from the recruiter's close request, "what it means for the operators themselves"; a framing choice, not a fact about Kelverton |
| T2 | Depth before breadth: fewer operator partnerships taken to a visible result before widening | Pick the few where a result would be visible to the operator soonest, and say what earns the next | Your headline is a count, and this thesis argues against leading with one, so expect "so your track record doesn't apply?". Proposed words: "My count is of partners in an ISV channel; I'm not claiming that number carries over, and I'd rather agree what we measure here." | [inferred] derived from "took it from 6 partners to 40" and "last 4 at a payments company running the ISV channel" |
| T3 | Treat each partnership as a jointly agreed proof, with commercial terms set before it starts | Agree the success test and the commercial shape with the operator at the outset, and say what converts the proof into a contract | A proof with no conversion path stalls, so name what turns it into a contract. Your material has no quote about pricing or terms, so say you would build them with Ross's team and do not claim you have set them | [inferred] derived from "never carried a direct quota, only influenced revenue" and the recruiter's "Ross will push on commercials" |

Differentiation. A report circulated to candidates is equally available to the panel, who may have written it, so reciting its shortlist scores as homework. Bring one item you agree with, to show you have read it; I have not seen the report, so the pack cannot name it. Then give one thesis-driven departure, with reasons, in the report's own vocabulary. Then the anti-pick: do not lead with a partner-count target for the 18 months, and name one kind of operator partnership you would decline to start, chosen from the report.

Requested close, proposed frame: "For an operator, month eighteen means ____, and the way we would know is ____." Fill both blanks from the report's operator-facing language and from what you would test. If you cannot name the change with confidence, say that naming it is the first thing you would test.

Fifteen-minute shape, rehearsed aloud twice, with a minute of slack:

| Minutes | Segment |
|---|---|
| 0:00 to 1:00 | Frame: what you will cover, that it is a hypothesis, and what you do not know yet |
| 1:00 to 4:00 | The one item you agree with from the report, and why it matters to operators |
| 4:00 to 9:00 | Your thesis, phased across the 18 months |
| 9:00 to 11:00 | Your concession and the anti-pick |
| 11:00 to 14:00 | What it means for the operators themselves, using the close frame |
| 14:00 to 15:00 | Invite push-back, naming that you expect it on the commercial side |

## Persona table

The recruiter's email establishes this one session: who runs it (Deepa and Ross) and what it holds (a 15-minute POV, then Q&A). It says nothing of other sessions.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The POV is itself a live problem on their roadmap; expect follow-ups probing your premises | High: Deepa is "your future manager", which gives the hiring-manager prior of Case plus Skeptic, and the recruiter announced the POV | Clarify, then structure aloud, then challenge one premise respectfully (A1 to A3) |
| Skeptic | Quiet, persistent probing of rail and quota | High: the hiring-manager prior's second persona, and F4 and F6 are gaps you stated | Rehearse the single predictable objection until boring; bridge only from your own quoted adjacent work (B1 to B4) |
| Data-Driven Prober | Ross working through numbers and commercial terms | High: the recruiter wrote "Ross will push on commercials", and F3 is a figure | Know how each figure was counted, name the weakest assumption you know of, say plainly what you do not know (C1 to C4) |
| Pressure | Time-boxed challenge, motives questioned | Medium: "push" is the recruiter's word for Ross, and a two-person panel can interrupt | Pause, restate, hold the position through two follow-ups, then concede specifically (D1 to D3) |
| Peer Evaluator | Where partnerships and the commercial side meet | Low: Ross's seat is commercial, but nothing in the email frames the round as a peer one | Propose seam principles rather than pretending to know the seam (E1, E2) |
| Conversational | A friendly opener, scored anyway | Low: the email puts the POV first, but a short opener is still likely | A prepared arc and a reverse-question slot you use (G1, G2) |
| Values/Behavioral | None in this pack | Not detected: the email names no values round, and web research on published values was refused | Section 10 is dropped; see the upgrade menu |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] | This is the 15-minute deliverable; build it from the graded-deliverable section. The question presupposes nothing about your past, so the guidance makes no claim about it | The recruiter announced this as the first 15 minutes. CASE delivery on a JD-style requirement; F1 is the evidence nearest to it |
| A2 | "Take your first 90 days. What do you need to know first, and who do you need to talk to?" | CASE | [generic] | Clarify first, then objective, segmentation, approach, metrics, risks, thinking aloud. Name what you would ask before proposing anything, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A standard case probe for a manager hiring into a gap area (F6). Tagged CASE because it is a live problem; generic because it is a pattern, not a fact about Kelverton |
| A3 | "Pick one operator partnership you'd start in month one. What does the operator get at month six that it doesn't have today?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Name the operator-side change first, then who at the operator sees it, then how you would test that. You may anchor in your background only at its scope: "my background is five years in transport consulting, in bus and light rail network planning". What you do not know about how a train operator works, say plainly and say who you would ask | The recruiter's close asks for what it means for operators, and F2 is the only operator-side evidence. CASE because it is a live problem on the role |
| A4 | "The strategy team circulated a market report. Which part would you depart from, and what follows from that?" | CO | [grounded] | Bring one item you agree with, then one departure with reasons, using only what the report says; this pack has not seen it, so it names nothing from it. Do not recite the shortlist. The guidance makes no claim about your past | A company-strategy probe built on a document the recruiter's email attached; labeled CO. The honest cost of the refused research is that this is the only CO question |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail specifically. Why should an operator take your call?" | JD | [grounded] "Never sold into rail specifically", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack. Open with the plain words: "I haven't sold into rail specifically." Then the adjacent work at its scope: "I spent five years in transport consulting, in bus and light rail network planning." Then a ramp plan said as a plan: what you would do in the first weeks. The pack's observation, not words for you: your quote says bus and light rail and does not show whether any of it touched train operators. Follow-up one, "bus and light rail aren't heavy rail": stay with the scope you stated and do not widen it. Follow-up two, "so you'll learn on our time": answer slot, name the thing you would least trust yourself on, in your own words; if you do not know, say so plainly and say how you would find out. Concede specifically, never fold on what you stated | F6 is a gap you stated and F2 is the only adjacent evidence, so this objection arrives in some form. JD because it scores the role's rail requirement, delivered by a Skeptic |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue", "Never sold into rail specifically" | Choose one honestly, in your own words, and say it plainly: "I haven't carried a direct quota" or "I haven't sold into rail specifically", whichever you would pick. Then the plan for it. Ross's title is Commercial Director, so the quota answer is the one he is best placed to test; calibrated candor over bluffing it | F4 and F6 are both stated gaps. JD because the Skeptic's stem scores the requirement list |
| B3 | "You haven't carried a direct quota. How would you cope with a number with your name on it?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Plain words first: "I haven't carried a direct quota; what I can speak to is influenced revenue." Then forward-looking only: what you would want agreed about how a number is set, said as a plan. Nothing about readiness you cannot back from the quote | F4 is the gap this question presses. JD because it scores a likely role-family expectation |
| B4 | "Why leave payments, why rail, why now?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "last 4 at a payments company running the ISV channel" | Selection scaffold: say your actual reason in one sentence, and make it consistent with the two stretches of your history you quoted: transport consulting and the payments channel. If no reason comes to mind that you would stand behind, say so plainly, then give the nearest honest thing, or how you would think about it | Motivation consistency is what a Skeptic scores, and F1 and F2 are the two stretches it must reconcile. EXP because it tests whether the story holds together |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure in the quote's own terms: "roughly £4M of influenced revenue". Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; say each in your own words, and name the weakest assumption before he does. If you do not know how it was counted, say so plainly and return to the sentence you stated | F3 is the headline figure and the likeliest target for a commercial probe. EXP because it tests attribution honesty |
| C2 | "You took the channel from six partners to forty. What was your part in that?" | EXP | [grounded] "took it from 6 partners to 40", "last 4 at a payments company running the ISV channel" | Say it at its scope: "I took the ISV channel from six partners to forty." Answer slot: what the count includes, which part was yours, and the assumption you would defend least, each in your own words; if you do not know what the count includes, say so plainly and return to the sentence | F3 and F5 carry the count, and a count invites a probe on attribution. EXP because it tests what was actually yours |
| C3 | "Influenced revenue. What did influence mean in your numbers?" | EXP | [grounded] "roughly £4M of influenced revenue", "never carried a direct quota, only influenced revenue" | Plain words: "I've never carried a direct quota; what I can speak to is influenced revenue." Answer slot: how the figure was counted, in your own words; if you do not know, say so plainly. Do not describe a method you cannot repeat under a second question | The distinction between influenced and direct is where Ross's commercial push is most likely to land, per F3 and F4. EXP because it tests the figure |
| C4 | "An operator will only run a pilot if we carry the risk. How do you think about what we charge and what we give?" | CASE | [generic] | Clarify first: who carries which risk, what a successful pilot looks like, what Kelverton's floor is. Then objective, options such as a paid pilot, a staged commitment or a fee tied to a result, then risks. Concede early that you would build the numbers with Ross's team. Your material has no quote about pricing or terms, so the guidance makes no claim about your past | The recruiter's "Ross will push on commercials" makes a commercial case likely, and F4 is the gap it presses. CASE because it is a live problem; generic because it is a pattern |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "last 4 at a payments company running the ISV channel", "took it from 6 partners to 40", "Never sold into rail specifically" | Pause and restate the question. Hold only what you stated: "I took the ISV channel from six partners to forty." Concede plainly and specifically: "I haven't sold into rail specifically." Hold through two follow-ups by returning to those sentences, never by adding to them | F6 is the stated gap and F5 the stated strength; a time-boxed version tests whether you fold. JD because it scores the role's rail requirement |
| D2 | "The roughly £4M of influenced revenue you mention. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue", "took it from 6 partners to 40" | Pause, restate, anchor in the sentences you stated. Answer slot: which part was yours, in your own words; if you cannot separate it, say so plainly and return to the sentence. Hold through two follow-ups, concede the specific part you cannot attribute, never the whole claim | F3 is the figure that attribution questions aim at. EXP because it tests attribution honesty under pressure |
| D3 | "You haven't worked here. Why should we hear a view on our operators from you?" | JD | [generic] | Pause. Hold that a POV is a hypothesis offered to be tested, and concede specifically what you cannot see from outside, for example internal data. Do not fold on offering a view at all. The guidance makes no claim about your past | The recruiter asked for a POV from an outsider, so this challenge is likely in some form; F2 and F6 are where it bites. JD because it scores the announced deliverable |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does partnerships stop and the commercial team start, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a claimed seam: agree how credit is counted before the first deal, give each account one owner, and escalate by a rule rather than by seniority. Reciprocity first: what partnerships would bring the commercial team. Your material has no quote about a past disagreement, so the guidance claims none | Ross sits on the commercial side and F4 sits on the seam. JD because it scores the role's cross-team requirement |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick one real instance with a named stake and a credit decision; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Your headline figure is influenced revenue, so expect this to arrive in that form | F3's influenced figure makes credit a live topic. EXP because it tests a past instance |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through the journey that brought you here." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)", "9 years in partnerships", "last 4 at a payments company running the ISV channel" | A 90-second arc with three beats, each at its own scope, in the order you lived them: five years in transport consulting, in bus and light rail network planning; nine years in partnerships; the last four at a payments company, running the ISV channel. Answer slot: why you moved at each step, in your own words; if there was no single reason, say so plainly | F1 and F2 are the two stretches of the story. EXP because it is a CV-line deep-dive in a friendly register |
| G2 | "What are you actually looking at in operator partnerships these days?" | CO | [generic] | Selection scaffold: name one specific thing you have actually read or studied that bears on operators, and what you took from it; if nothing comes to mind, say so plainly, then name what you would read first. Casual questions on hot topics are scored | The recruiter's own topic is operator partnerships, so a casual version is likely. CO because it tests homework depth |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A4, D3 |
| "what it means for the operators themselves" | A1, A3 |
| "Ross will push on commercials" | C1, C2, C3, C4, D2 |
| Carrying a direct revenue target (role-family) | B2, B3, C3 |
| Growing a partner network (role-family) | C2, D2, G1 |
| Selling or partnering into rail operators (role-family) | B1, B2, D1 |
| "no slides needed, just talk us through it" | none as a bank question: it is the deliverable, built in its own section |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would need to be true about operator partnerships at month 18 for you to say this hire worked?" | It puts the yardstick for your POV on the table and shows you plan backwards from a result |
| 2 | "How do you tell a partnership that is working from one that is just busy?" | It gets at how credit is counted, which is the thread Ross is likely to pull |
| 3 | "How is credit split today between partnerships and the commercial team?" | It names the seam before they raise it and shows you thought about it |
| 4 | "What do operators say they want that we haven't been able to give them?" | It goes to the operator's voice, which the recruiter's close asked you to land on |
| 5 | "What do people from outside rail typically miss in their first months here?" | It turns your rail gap into curiosity rather than a defence |
| 6 | "What would help the commercial team most from partnerships in the first quarter?" | A reciprocity question for the commercial seat: what you bring, not just what you need |

No question is tied to an interviewer's own career path, because no interviewer profile could be read.

## Prohibited claims

Built before the banks. None of these is coached anywhere in the pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't sold into rail specifically." No slot |
| Has carried a quota or owned a revenue number | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; what I can speak to is influenced revenue." No slot |
| Sourced or closed the £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The pack's observation: your material says influenced, not sourced or closed. C1's slots stay inside how the figure was counted |
| Built the ISV channel | Inflated form of F5 | F5's quote at its own scope: "took it from 6 partners to 40". The pack's observation: your material says took it, not built it |
| Advised or worked with train operators | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The pack's observation: your material does not show train operators. B1's slot stays inside that scope |

## Sources

Provided documents: your message, containing your background and the recruiter's email as you quoted it. The market report is named in your message but its text was not supplied; nothing in this pack comes from it. No tuesday-dossier.md was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

Every call below was refused; none returned a result, and nothing from any of them is used.

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail strategy train operating companies scheduling software news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology job description operators | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have decided whether a values cheat sheet and VAL questions exist; the pack has neither |
| 2. `{company} interview process {role family}` | unavailable | Would have confirmed loop structure beyond the recruiter's email; persona weights rest on that email alone |
| 3. `{company} strategy` / recent news | unavailable | Would have fed the CO bank; A4 and G2 stand in, and the rest of the CO bank is absent |
| 4. `{interviewer name} {company}` | unavailable | Would have fed an interviewer read and a reverse question tied to an interviewer's path; both are absent |
| 5. representative `{role title}` JD | unavailable | Would have given quoted role requirements for the fit snapshot; F4 to F6 are role-family prose instead |

## Upgrade menu

- The JD text → F4 to F6 become quoted requirements instead of role-family prose, JD-tagged questions get sharper, and any hard-gate rows (location, travel, schedule) would appear
- The market report's text, pasted → A4 and the POV's consensus item and departure become specific, and the differentiation section names the shortlist to depart from
- Search permission granted, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the values, loop, strategy and interviewer rows become researched, and a values cheat sheet or interviewer read is added if the sources support them
- Your CV → evidence cells quote it as well as your message, and rows F1 to F6 can gain inspectable detail
- Interviewer names with surnames, or their public profiles → an interviewer read, persona weights adjusted to their published signals, and a reverse question tied to their path
- Your own answers, outside a drill, to the slots in F1, F2 and F3 → quoted into the snapshot, and the rows and bank cells that draw on them regenerate
- A tuesday-dossier.md from a job-underwriter pass → verified evidence, per-area interview strategy and a prohibited-claims list from that pass; this pack stands without one
