Sam, I can only optimise what your resume can honestly back, and against this JD that's less than keyword placement can fix. Nothing below is applied until you approve it.

I'm working from your pasted summary, not the PDF, so I couldn't check how the file extracts. The JD doesn't tier its requirements, so I ranked them by how central each looks to "own platform reliability and developer experience". Correct me if that's wrong.

**On the keyword theory.** I can't tell why you were rejected, and the one dataset I have doesn't support a pure keyword story. Its 25 US recruiters were interviewed by a résumé-builder vendor, so treat it as a hint, not a measurement.
- Auto-rejection on content is rare in that sample: "AI/content auto-rejection configured: 8% of recruiters." (cite C25)
- When filters do reject, they're mostly form questions, not keywords: "When automated filters are used, they’re almost always knockout questions" (cite C26). Check your application forms for these (location, work authorisation, required licences).
- Keywords may affect ordering: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27)

Two things on your side are more likely to hurt than missing keywords. The coverage map shows most of this JD's stack as `not_evidenced`, and the layout you describe may lose content in extraction. I'm naming `job-underwriter` once, for the separate question of whether this role is worth applying to. I haven't done that analysis.

### Edit ledger (resume_edits_pending_approval)

Only three rows trace to your own words, so the ledger is short on purpose. I quote your message, since I haven't seen the PDF's exact text.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(Kubernetes not in the skills list, as far as I can tell)* | "Kubernetes (two-month proof-of-concept, not in production)", placed after Docker | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your summary | pending your approval |
| E2 | Summary | *(no current line, assumed)* | "DevOps Engineer, 4 years. AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |
| E3 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged wording, moved to the first Experience bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |

- **E1** makes "Kubernetes" findable and keeps the PoC qualifier. Dropping the qualifier would turn a two-month PoC into production experience.
- **E2** puts your strongest verifiable evidence first, in plain single-column text. Ansible and CloudWatch stay in Skills.
- **E3** changes position only.

### Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes | must-have | surfaced_by_edit | E1. Evidence is a PoC only, so expect an interviewer to ask about production | `[grounded]` PoC sentence; `[inferred]` priority from JD order and centrality |
| M2 | AWS EKS | must-have | not_evidenced | Adjacent: EC2, S3, RDS, IAM. EKS is not stated anywhere (C1) | `[grounded]` AWS list |
| M3 | Terraform | must-have | not_evidenced | Adjacent: Ansible for config management. Different tool and category (C2) | `[grounded]` Ansible sentence |
| M4 | CI/CD (GitLab) | must-have | not_evidenced | Adjacent: Jenkins deploy pipeline (E2, E3). GitLab is not stated | `[grounded]` Jenkins sentence |
| M5 | Python | must-have | already_evidenced | "Bash and Python scripting"; E2 moves it earlier | `[grounded]` |
| M6 | SRE practices, platform reliability | must-have | not_evidenced | Nothing in your summary on SLOs, on-call or incident work (C3) | `[grounded]` absence; `[inferred]` priority from the JD's closing sentence |
| M7 | GitOps, ArgoCD | important | not_evidenced | Named absence below | `[grounded]` |
| M8 | Helm | important | not_evidenced | Named absence below | `[grounded]` |
| M9 | Prometheus, Grafana, observability | important | not_evidenced | Adjacent: CloudWatch for monitoring. Different tool, and "observability" is the JD's word | `[grounded]` CloudWatch sentence |
| M10 | Istio, service mesh | important | not_evidenced | Named absence below | `[grounded]` |
| M11 | Vault | important | not_evidenced | IAM is access control, not secrets management. Named absence below | `[grounded]` |
| M12 | Developer experience | important | not_evidenced | The Jenkins pipeline may have been developer-facing, but your summary doesn't say who used it (C3) | `[grounded]` |
| M13 | Go | preferred | not_evidenced | Named absence below | `[grounded]` |

### Recovery per gap

Recall prompts for the three gaps where your history may hold something. The questions are asked once, in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS (M2) with Kubernetes (M1) | must-have | A two-month Kubernetes PoC. It doesn't say where it ran or what it covered | EKS is named in the JD; a PoC on EKS would be a much stronger match than a generic one | PoC on EKS rather than minikube or kind; Helm charts or ingress in the PoC; any monitoring stack in the PoC cluster | PoC README, manifests repo, architecture diagram | `[grounded]` what the summary says and omits; `[generic]` what this costs on platform-role applications |
| C2 | Terraform (M3) | must-have | Ansible only | Terraform is a must-have in this stack and Ansible doesn't stand in for it | A Terraform module you edited in a team repo; CloudFormation you wrote or reviewed; Ansible used to provision rather than configure | A repo, a PR link, a module path | `[grounded]` Ansible sentence; `[generic]` cost of a missing IaC tool |
| C3 | Reliability and developer experience (M6, M12) | must-have | A pipeline built and about 30 jobs maintained, with no users, uptime or incidents stated | The JD ends on owning both; the resume is silent on who depended on your work | Number of developers or teams using the pipeline; on-call rotation; outage or postmortem work | Runbook, postmortem, pipeline usage numbers | `[grounded]` absence; `[generic]` what the closing duty signals |

Named absences, with what closing each would take:

| # | Requirement | The gap, plainly | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | GitLab CI/CD (M4) | You have used Jenkins, not GitLab CI. Same job, different tool. | Port one Jenkins pipeline to GitLab CI in a personal project and link it | `[generic]` |
| A2 | GitOps, ArgoCD, Helm (M7, M8) | Nothing in your summary. | Install ArgoCD and a Helm chart on the PoC cluster, or a local one, and keep the repo | `[generic]` |
| A3 | Prometheus, Grafana (M9) | CloudWatch only. | Run the Prometheus and Grafana stack on that same cluster | `[generic]` |
| A4 | Istio, Vault, Go (M10, M11, M13) | No evidence. These are the thinnest rows. | Probably not worth closing for this application. Each is a separate project, and the JD lists them as part of one stack | `[generic]` |

### Prohibited claims (not written, and why)

- "Platform Engineer" as your title. You are a DevOps Engineer; a retitle to the JD's title is an upgrade, not an equivalent.
- "CI/CD pipelines" or any GitLab claim. You built a Jenkins deploy pipeline. "CI/CD" is the JD's word, and it also claims the CI half, which you haven't said.
- "Kubernetes in production" or "managed Kubernetes". It was a two-month PoC.
- "EKS", "Terraform", "infrastructure as code", "Helm", "ArgoCD", "GitOps", "Istio", "Vault", "Prometheus", "Grafana" or "Go". Listing a tool isn't owning it, and an interviewer will test each one.
- "Observability" for CloudWatch monitoring. Monitoring and observability are different work.
- "SRE practices", "platform reliability ownership" or "developer experience". Nothing in your summary supports them yet, and C3 is how that could change.
- "Secrets management" for IAM. That is a different kind of work.

### Parse-safety check

I can't open the PDF, so these come from your description of it. They are practitioner knowledge of how text extraction fails, not measured rates. I report risks only; layout is your call.

| Check | What breaks | What it costs | Applies to you |
|---|---|---|---|
| Multi-column layout | Parsers read linearly and serialise columns interleaved | Text mixes together; dates detach from roles | Yes, two columns |
| Images, icons, skill-level bars | Rendered as garbage characters, or the line is skipped | The information in them is absent | Yes, icons per skill. If the icons carry the skill names, those names may be lost |
| Content in headers | Treated as page furniture and discarded | Contact details can be lost, leaving you unreachable | Possibly. Contact details are in the header |
| Tables and text boxes | Cell contents re-ordered or dropped | Whole sections can vanish | Could not check |
| Non-standard section headings | Section detection looks for conventional labels | A section may not be recognised as Experience | Could not check |
| File type | Varies by parser | A `.docx` or a text-layer PDF is the safe pair | Could not check whether your PDF has a text layer |

A quick test is to copy all the text out of the PDF into a plain-text editor. If the order is scrambled or the contact details are missing, extraction is damaging your resume.

### Upgrade menu

- **The PDF or a plain-text export:** lets me run the parse-safety checks I marked "could not check".
- **PoC write-up, repo or README:** this is the inspectable proof for M1 and C1, and could turn a `not_evidenced` row into a real one.
- **Jenkinsfile, pipeline docs or usage numbers:** support C3, and for M4 and M12 they show the pipeline's scale and users.
- **Any Terraform or CloudFormation repo or PR:** closes C2 if it exists.
- **Runbooks or postmortems:** the only way to move M6 off `not_evidenced`.
- **Prior resume versions:** they often hold evidence a current version dropped.

### Questions

C1 — Where did your Kubernetes proof-of-concept run (EKS, another managed service, or local), and what did it cover beyond deploying pods?

C2 — Have you written or edited any Terraform or CloudFormation, even a module in a team repo, and what did Ansible actually manage for you?

C3 — Roughly how many developers or teams relied on the Jenkins pipeline you built, and did you carry on-call or handle outages for it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.