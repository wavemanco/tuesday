Web search was denied in this session, so I'm building the pack from what you gave me alone. I'll note the refused searches in its Sources section. I'm writing the full pack now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-1-denied-580bfe44/f77954d2-1803-49ea-9189-215c980a1c90/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I wasn't allowed to write to the project folder, so it's in the scratchpad. I built it for one 60-minute peer conversation with Dan, with no recruiter guidance.

**What the research covered.** The web searches for Northwind's values, its interview process, and Dan's public footprint were all refused. Everything rests on what you gave me. As a result:
- There is no values cheat sheet and no VAL-type questions.
- The persona weights follow your description of a single peer conversation.
- The interviewer read uses only your summary of Dan's profile.
- The Northwind facts in the case bank (the three priorities, Compass, the bundling threat) come from your research note and are unverified.

**What the pack holds.**
- A fit snapshot with Priya's own words quoted against each JD requirement, plus a requirement-coverage table.
- An interviewer read and a persona table with the weighting reasoning shown.
- 20 questions with provenance, answer guidance and rationale. They are split across Prober (5), Peer (4), Case (4), Skeptic (3), Pressure (2) and Conversational (2).
- 6 reverse questions, including one tied to Dan's pricing path and one reciprocity question.
- A prohibited-claims table, sources with the research accounting, and an upgrade menu.

**Highest-ROI prep.** Question D1, the no-sales-ops and no-quota-setting objection, gets the deepest rehearsal. Dan's seat points straight at that gap. Question A1, on how the ~$400M ARR credit was counted, is next.

Because the JD arrived as highlights, the requirements quoted in the snapshot are your wording, not the JD's. Several answer guidance cells are slots for Priya to fill in her own words rather than scripted answers. That keeps the pack from inventing details she hasn't given.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: you and he would report to the same VP.
**Format:** one 60-minute conversation with Dan.
**Built on:** your description of the role, the JD highlights as you worded them, Dan's profile summary, and your research note. No web research ran (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: it is built only from sentences you gave me, and an answer slot is an instruction for the interview, not a question for me. Question banks are lettered A to E and G; F is skipped so that question IDs never collide with the fit-snapshot rows F1 to F7.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values. No rows here: no published values were read and no values round is documented for this loop |
| EXP | Whether the claims on your CV survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge, at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to a document you gave me, `[inferred]` is derived and the derivation is named, `[generic]` is a rehearsal pattern with no claim about you or Northwind.

**Highest-ROI prep in this pack: D1**, the Skeptic question on sales-ops and quota-setting. It is the likeliest objection from a Director of Sales Strategy sitting next to this role, and it is the deepest-rehearsed item below.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material shows a proposal that was credited with an uplift, inside strategy roles. It does not show a go-to-market for a new product line, and the words stay at the quote: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's two-new-product-lines line makes a probe on whether you have taken something new to market likely. If you have, say which and what part was yours, in your own words; if not, or not in the sense this role means, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material does not show work on a customer lifecycle. Answer slot: the JD names land, adopt, expand and renew, so expect a probe on which stage you would examine first. If you have worked on any of these stages, say which and what you did, in your own words; if you have not, say so plainly and say how you would size the whitespace, as a plan |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The quote names the tools, not an analysis you ran from start to finish. Words: "I'm skilled in SQL and Tableau." Answer slot: expect Dan to ask for one analysis. If you ran one yourself end to end, name it and what it showed, in your own words; if others built the queries or dashboards, or none comes to mind, say so plainly and stay with the tools line |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a model that was used in negotiations, not a partner motion. The words stay at the quote: "I built a partner-level revenue model that was used in carrier negotiations." Any wider step is an answer slot inside that scope (A3) |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as it stands: "I set annual volume targets with cross-org consensus." A CV line with nothing inspected behind it, so expect a probe on how the consensus came about (A4) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: "I use AI tools daily." It says use. The pack's observation is that your material does not show building or shipping AI features, and your research note names Compass as an AI copilot launch, so expect the probe to land on that boundary (G2) |
| F7 | fluency in sales ops and quota setting, the terrain of a Director of Sales Strategy peer; derived from Dan's title, not from the JD | "No classic sales-ops or quota-setting experience" — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Your annual volume targets (F5) and quotas stay separate, as your own message keeps them separate |

None of the JD highlights is a gate (authorization, location, schedule, travel, pay, credential). The full JD may carry one; the upgrade menu asks for it.

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| F1 own GTM strategy for two new product lines | C1, C3, E2 | C1 is the live version; E2 is the JD-tagged version |
| F2 whitespace across land/adopt/expand/renew | C1, C4 | No quote carries it, so both are reasoning questions |
| F3 independent analysis in SQL and Tableau | A2 | |
| F4 partner-motion design (required) | A3 | |
| F5 cross-functional influence | A4, B1, B4 | |
| F6 AI experience (plus) | G2 | |
| F7 sales-ops and quota-setting (not in the JD) | D1, E2, B4 | Covered because Dan's seat makes it likely |
| Headline metric: the ARR figure | A1, E1 | Defend-the-number, twice: once as a Prober, once under Pressure |

## Reading the interviewer

Public professional footprint only, and only what you told me from Dan's profile. Nothing else was looked up.

| Signal | Source | Provenance | What it means for you |
|---|---|---|---|
| Describes himself as "relentlessly data-driven" | Dan's profile, via your message | [grounded] | Expect every number to be taken to its assumptions. A1 to A5 are built for this, and the weakest-assumption move matters more with him than with most |
| Career spine is pricing and monetization roles | Dan's profile, via your message | [grounded] | Pricing, packaging and unit-economics angles are his native language, so C-bank cases will probably arrive in them. Say the structure aloud before the numbers |
| One early-stage-startup chapter | Dan's profile, via your message | [grounded] | Expect scrappiness probes against a nine-year large-company background (D3). Do not claim startup traits |
| Same VP as you | Your message | [grounded] | He is pricing what you cost and contribute to his work. Reciprocity framing wins (B4, R3) |

Mirror opportunity: Dan's monetization spine shares revenue vocabulary with F4's quote ("built a partner-level revenue model used in carrier negotiations"). Use the quote's own terms when you connect them. Do not call that work pricing unless it was. No shared career jump is visible in the material, so none is offered.

## Persona table

Weights: peer-relationship priors (Peer Evaluator and Data-Driven Prober dominant), adjusted by Dan's signals above. The loop is the single peer conversation you described, so no company archetype was needed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Data-Driven Prober (bank A, 5 questions) | Reads each claim to its inputs and assumptions; follow-ups go two levels deeper | High. Peer prior, raised by Dan's "relentlessly data-driven" self-description | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name the weakest assumption before he does |
| Peer Evaluator (bank B, 4 questions) | Seam-splitting, "what would you need from me", credit and disagreement | High. Peer prior; same reporting line | Reciprocity framing; propose seam principles instead of pretending to know the seam; disagreement stories with spine and tact |
| Case / Strategist (bank C, 4 questions) | Live problems on the actual role: whitespace, bundling, trade-offs | Medium to high. Not guaranteed in a peer round, tilted up by Dan's pricing and monetization spine | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank D, 3 questions) | Quiet probing of gaps: background mismatch, why leave, why here | Medium. Startup chapter on his side, a large-company tenure on yours, and F7 | Rehearse D1 until it is boring; bridges only from what you stated, with the limit said plainly |
| Pressure (bank E, 2 questions) | Time-boxing, "how much was actually you" | Low to medium. Not a peer-round prior, but a two-levels-deep Prober can feel like pressure | Pause, restate, anchor in the quote, hold through two follow-ups, concede specifically |
| Conversational (bank G, 2 questions) | Friendly opener, casual question on a hot JD topic | Low to medium. Likely as the first five minutes; still scored | A 90-second arc built from your own sentence; treat the casual AI question as scored |
| Values / Behavioral | Scenario probes mapped to published values | Low. No published values were read and no values round is documented for this loop. Its stems appear inside the Peer bank (B2, B3) | Selection scaffolds, with the honest branch when no story comes to mind |

## Question banks

Provenance carries every sentence of yours that the guidance rests on.

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open at the quote's own scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." The word is credited, so keep it. Then the four slots a figure raises, each in your own words. Answer slot: how it was counted; what it is sensitive to; the assumption behind it you would defend least, named before Dan names one; which part was yours. If you do not know how it was counted, say so plainly and say what you would ask to find out. If a part was not yours, say so and return to the proposal | F1 holds the only headline metric, and a self-described data-driven peer will go straight to its counting. EXP because it tests what the claim rests on |
| A2 | "Walk me through an analysis you ran yourself in SQL or Tableau, end to end." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold. Pick one analysis where you wrote the query or built the view yourself, and can state the question it answered, the data it ran on, and what it changed or did not change. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries: "I'm skilled in SQL and Tableau." Offer to walk him through it end to end only if one exists | F3 is the JD's explicit analysis requirement, and Dan can check it live. JD because it scores a stated requirement; the Prober delivery is why it sits in this bank |
| A3 | "Walk me through the partner-level revenue model you built. What was it used for?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says: a partner-level revenue model, built by you, used in carrier negotiations. Answer slot: the JD's partner-motion line makes a probe on whether you designed how the company works with partners likely. If any part of that was yours, say which and what you decided, in your own words; if none was, or the model was the whole of it, say so plainly and stay with the model | F4 is the required-experience row, and the likeliest place a required line gets tested. JD content, EXP delivery |
| A4 | "How did you get cross-org consensus on the annual volume targets you set?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The quote states the targets, annual, and the consensus, across orgs. Say those in your own words. Answer slot: the JD's cross-functional-influence line makes a probe on how the consensus came about likely. Say how, in your own words; if it came without much effort of yours, or someone else brokered it, say so plainly and return to the quote. If you can stand behind a number, name it; if not, leave it out | F5 is a clean quote with nothing inspected behind it, so a Prober asks how. EXP because it tests what was yours; the JD influence line is why it is likely |
| A5 | "Your numbers come from a consumer-tech setting. Which of them would you expect to carry over to an enterprise data-infrastructure motion, and which not?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A reasoning answer, not a claim. Words for the setting: "I spent nine years at a large consumer-tech company, in product strategy and ops." For each number, say what it depended on, in your own words, and where that dependency may not travel. Answer slot: the assumption behind your headline figure you would defend least. If you cannot say, say so plainly and say what you would check first | Dan's native test of transferability, from F1's evidence. EXP because it asks which claims survive a change of setting |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam. Propose principles: who decides what, what data each side needs from the other, and where an unresolved disagreement goes (your shared VP). Then ask Dan how he would draw it. The question needs no claim about your past, so the guidance makes none | The peer prior's signature question. JD because cross-functional influence is a stated requirement (F5); Peer delivery |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold. Pick a time credit was shared across teams: what each team contributed, how the credit was shared, and the relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I set annual volume targets with cross-org consensus." Or say how you would handle it. Say "we" for context and "I" for what was yours | Credit-sharing is a standard peer probe. EXP rather than VAL because no published values were read, so nothing here is scored against values |
| B3 | "Tell me about a time you disagreed with an equal and had to resolve it." | EXP | [generic] | Selection scaffold. It needs a named disagreement, your position, a moment you did not fold without cause, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. Do not supply an ending the material does not give | Spine and tact with equals is what a peer scores. A persona-stem question whose theme comes from the Peer Evaluator's own scoring |
| B4 | "What would you need from me in your first 90 days, and what would I get from you?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience" | Reciprocity first. What you bring, in the quotes' own terms: "I'm skilled in SQL and Tableau", "I built a partner-level revenue model that was used in carrier negotiations". Then what you need, including the stated gap: "I haven't had classic sales-ops or quota-setting experience." Ask Dan to walk you through how his team works with the numbers, as a plan, not a past | Peer hire cost is Dan's real question, and F7 means the "need from me" half is not hypothetical. JD because it tests the cross-functional requirement |

### C. Case / Strategist

Facts about Northwind in this bank come from your research note (enterprise expansion, the Compass AI copilot launch, reaching profitability, and bundling by a much larger platform vendor). The pack has not verified them. These questions ask about no past of yours.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line has to land, adopt, expand and renew. Where would you look for whitespace first, and what would you pull in SQL?" | CASE | [grounded] your research note | Clarify first: which line, which customers, what is already sold. Then objective, segmentation (existing accounts against new logos), approach, metrics, risks. Think aloud and challenge one premise. Use pricing and packaging language, since that is Dan's own | F1 and F2 meet here with no quote behind F2, so a reasoning answer is the honest one |
| C2 | "A much larger platform vendor starts bundling a competing capability. How does that change pricing and packaging for an enterprise expansion motion?" | CASE | [grounded] your research note | Same structure. Name the buyer segments the bundle hurts most, what you would measure to see it (attach, discounting, renewal), and your recommendation. Hold it through one challenge and concede specifically what data you would need to change it | The note names bundling as the main threat, and Dan's spine makes this his home turf. CASE because it is a live problem from the role |
| C3 | "Of the three priorities, enterprise expansion, Compass, and profitability, where would you put the first analyst and the first dollar, and what would you not do?" | CO | [grounded] your research note | Pick one with reasoning, state the trade-off you are accepting, and name the data that would change your mind. Include an anti-pick: where the role's job is to say no, say it. Do not recite the three priorities back as the answer; bring one as grounding and one reasoned departure | CO because it tests strategy altitude. A list recited from a source any prepared candidate has reads as homework; a reasoned choice reads as judgment |
| C4 | "Compass-attributed expansion revenue looks strong after one quarter. What would make you distrust it?" | CASE | [grounded] your research note | Definitions first: what counts as expansion, against what baseline. Then what would inflate it (a repriced renewal, bundled discounting, cohort mix), what you would cut it by, and what you would ask for. Expect Dan to turn this around on your own figure (A1) | Tests the counting discipline Dan prizes in a setting native to this role. CASE with a Prober edge |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting experience in your background. How would that show up in this role?" (the highest-ROI rehearsal) | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | The limit is named before it is asked for: "I haven't had classic sales-ops or quota-setting experience." Level 1, "Aren't your volume targets quota-setting?": keep them apart in your own words, as your message does: "I set annual volume targets with cross-org consensus; I haven't had classic quota-setting experience." Level 2, "So what do you do in week one?": a plan, not a past: what you would ask Dan to walk you through first, and what you would pull in SQL. Level 3, "What if the VP expects you to own quota design?": hold the same line and say plainly what you would need. Concede exactly the gap, nothing wider, and never fold the quote | F7 is the biggest gap and the one Dan's seat points straight at. JD because it scores fit against the role; Skeptic delivery |
| D2 | "You have been at one large company for nine years. Why leave, why here, why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The material holds no reasons, so none are supplied here: write your three answers first, in your own words, and check that they agree with each other. If a reason is not yet clear to you, say so plainly and say what you are weighing. Anchor the facts to the quote: "I spent nine years at a large consumer-tech company, in product strategy and ops." | Motivation consistency is the Skeptic's core score, and a long single tenure invites it |
| D3 | "How do you work when the data is thinner and the support smaller than at a large company?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Selection scaffold. Pick a time you had less data or support than you wanted and still made a call: what was missing, the call, and what you did when it was checked. If no such time comes to mind, say so plainly, then say how you would handle it. Do not claim startup traits | An Emerging Products seat and Dan's startup chapter make a scrappiness probe likely. JD because emerging products is the role's stated nature |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How much of that ~$400M was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, anchor: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Hold through two follow-ups by returning to the quote, never by adding to it. Concede specifically. Answer slot: the parts of the counting you do not know, said plainly; the parts you do know, in your own words. Never fold on "proposed", and never upgrade it | F1's figure is where attribution probes land hardest. EXP because it tests what was yours; Pressure delivery |
| E2 | "Sixty seconds: what would a stronger candidate for this role have that you do not?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Name the gap first, in the plain acknowledgment F7 allows: "I haven't had classic sales-ops or quota-setting experience." Then what you bring, in the quotes' terms only: the revenue model that was used in carrier negotiations, and SQL and Tableau. Let Dan draw the inference; do not tell him what your work proves | Candor under a time-box is what Pressure scores. JD because it tests fit including the gap (F1, F7) |

### G. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the sentence states: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: the move toward this role, in your own words, which this pack cannot supply. If the reason is still forming, say so plainly | The biography question is the most predictable opener, and casual questions are scored. EXP because it checks the CV's story |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Words: "I use AI tools daily." Answer slot: name the tools and what you use them for, in your own words; if the use is narrower than a follow-up implies, say so plainly and stay with the tools line. Expect Compass to come up, so know where your own use stops | The JD's plus, asked casually (F6), against a product line named after an AI copilot. JD because it scores a stated requirement; Conversational delivery |

## Reverse questions

At least one is tied to Dan's own path, and one is a peer reciprocity question.

| # | Question for Dan | Why it lands |
|---|---|---|
| R1 | "Your career has centered on pricing and monetization. How has that lens shaped how you want the two new product lines packaged against the bundling threat?" | Tied to his path. Signals you read him, not just the company, and turns the interview into a peer conversation in his native language |
| R2 | "Where does your team's remit end and this role's begin on the two new lines: who decides pricing and packaging, and who owns the numbers behind quota and capacity?" | Surfaces the seam directly and shows you treat F7 as a boundary to respect, not hide |
| R3 | "What could a new person in this role do in their first month that would genuinely help your team?" | The reciprocity question for a peer; he is pricing what you cost his team |
| R4 | "Of enterprise expansion, Compass, and profitability, which does your team's plan lean on most this year, and where do the two new lines fit?" | Uses the three priorities from your note and surfaces the trade-offs that drive real decisions |
| R5 | "When you and the VP see a launch priority differently, how does that usually get settled?" | Shows you are thinking about a shared reporting line, and tells you something you need to know before you accept |
| R6 | "Which numbers does this org trust, and which does it still argue about?" | Plays to a self-described data-driven peer, and answers whether the measurement culture is one you can work in |

## Prohibited claims

What this pack will not coach, with the basis for each and the honest form. Built before the banks and binding on them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or launched go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a proposal that was credited, not a go-to-market. C1 and E1 stay inside the proposal |
| That the store-surface change drove or delivered the ~$400M | Inflated form of F1 | "proposed ... credited with" at its own scope. A1 and E1 slots ask only how it was counted and which part was yours |
| Designed a partner motion or program | Inflated form of F4 | F4's quote at its own scope: a model that was used in negotiations. A3's slot stays inside the model |
| Set quotas, or has sales-ops or quota-setting experience, or that annual volume targets are quotas | Negative stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Built every analysis or dashboard yourself | Inflated form of F3 | F3's quote at its own scope: "skilled in SQL/Tableau". A2 asks for one example and accepts either branch |
| Building or shipping AI features | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". G2's slot stays inside the tools line |

## Sources

**Provided documents:** your message (role and company, JD highlights worded by you, the candidate summary, Dan's profile summary, and your research note on Northwind's priorities). The JD arrived as highlights, so the requirements quoted in the fit snapshot are your wording of them, not the JD's own text. No `tuesday-dossier.md` was present.

**Searches sent, all refused (no permission to search was granted):**

| Query | Outcome |
|---|---|
| Northwind Data company values principles | refused |
| Northwind Data interview process strategy GTM role | refused |
| Dan Kovac Northwind Data Director of Sales Strategy | refused |

No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have fed a values cheat sheet and a values-round check. Neither was built; no VAL questions were written |
| 2. `Northwind Data interview process, strategy GTM role` | unavailable | Would have fed loop structure. Persona weights rest instead on the single peer conversation you described |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already holds the priorities and the bundling threat, which fix the CO and CASE banks |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have fed the interviewer read with public talks or writing. It rests only on the profile summary you gave |
| 5. representative role JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text: F1 to F6 would quote the real JD rather than your highlights, and could surface a requirement the highlights omit (a gate such as location or travel, or a mid-list tool).
- Your answers to the answer slots in F1 to F3 and A1 to A5, written in your own words and sent outside any drill: those rows would move from slots to story maps, and could lift their gap types.
- The written artifact behind the ARR credit (the readout or attribution memo that records how the figure was counted) and the partner revenue model's documentation: F1 and F4 would move from `medium` towards `high`, and A1, A3 and E1 could be mapped to what the documents say.
- The recruiter's guidance (focus areas, whether Dan's session includes a case or a deliverable, process details; usually one email): it would reweight the banks and add a build section for any announced deliverable.
- Research permission or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): it would add Northwind's published values and any documented loop, Dan's public talks or writing for sharper reverse questions, and a strategy brief to replace the unverified note.
- Prep time available: a prioritized schedule sized to your hours.
- A `tuesday-dossier.md` from an earlier role evaluation: verified evidence, a named objection and absolute prohibited claims would sharpen the guidance. Never required.
