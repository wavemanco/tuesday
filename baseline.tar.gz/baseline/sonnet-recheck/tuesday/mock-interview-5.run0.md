Web search was refused, so I'm building the pack from your message and the recruiter's email alone and labelling what that costs.
The write to the working directory was refused. The scratchpad folder is the sanctioned place for files, so I'll save the pack there instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-5-denied-f1f8dce7/4efcb9fb-b2dd-4268-998f-e5fba8a263e4/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. The write to the working directory was refused, so I saved it in the scratchpad folder. It's built for the panel round the recruiter described: Deepa as hiring manager, Ross pushing on commercials, and a 15-minute POV up front.

What the pack could not use:
- **Market report:** I never saw it, so nothing in the pack comes from it. The POV section tells you to bring one item from it to show you've read it, then one divergence and one thing you'd say no to. Your panel has this report too, so reciting it won't count for much.
- **Job description:** I didn't have one. The requirements come from the recruiter's own words and from role-family assumptions, and I've marked which is which.
- **Web research:** all five searches were refused, so the pack has no Kelverton-specific facts. The company and strategy questions are labelled `[generic]` rather than invented.

The question to rehearse most is B2: "You've never carried a direct quota. Why should we believe you can be commercially accountable here?" Ross is the one pushing on commercials, and that gap is one you named yourself. The pack's advice is to say the limit first, then stand on "roughly £4M of influenced revenue" at exactly that scope. Decide before Tuesday what you'd accept being measured on in year one, because I can't supply that position for you.

The four hours are split into six steps in the pack. The biggest block, 90 minutes, goes on building the POV and saying it aloud against a timer. The commercial objection gets 50 minutes next.

Say the word and I'll play the Skeptic on B2, then move to Ross's questions on your £4M and your 6-to-40 growth.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the Senior Partnerships Manager job description to paste in, or shall I leave the pack as built?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60 minutes, panel. **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). **Shape, from the recruiter's email:** a 15-minute spoken POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves; the rest is Q&A, and Ross will push on commercials.

Built on three limits: no job description was supplied, the market report was not available to this session, and web research was refused. Every row that would have rested on one of those says so.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it scores. Rehearse both: the same question arrives friendly from one panelist and hard from the other.
- Type key: **VAL** whether past behaviour shows published values; **EXP** whether your CV claims survive scrutiny; **JD** can you do the listed job, gaps included; **CO** company and strategy knowledge; **CASE** a live problem set in the role.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer it from your own experience, or say plainly the practice was not yours or never existed. Nothing in this pack supplies a detail you did not give.
- With research refused, CO and CASE questions are labelled `[generic]`: honest rehearsal patterns, not claims about Kelverton.

## Prep triage (four hours)

| Order | Time | Do this | Tied to |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV: pick one thesis, one consensus item from the report, one divergence, the anti-pick and the operator close. Say it aloud twice against a timer | Graded deliverable, A1 to A3 |
| 2 | 50 min | Rehearse the commercial objection until it is boring: write the limit sentence and decide your own position on being measured in year one | B2, D2, F3 |
| 3 | 30 min | Defend your two figures: how each was counted, what it is sensitive to, the assumption you would defend least, which part was yours | C1 to C3, F1, F2 |
| 4 | 25 min | Decide what you can truthfully say about operator-side exposure from your consulting years | B5, F5 |
| 5 | 15 min | Pick three reverse questions; make one of them about the commercial number | Reverse questions |
| 6 | 30 min | One live run with someone interrupting: POV, then B2 and C1 | Drill |

Everything else in the pack is insurance.

## Fit snapshot

Requirements come from the recruiter's own words as you quoted them, or are role-family expectations written as plain prose because no posting was seen; those raise no answer slot. No row is a hard gate on the material supplied; a posting could add some (location, travel, right to work).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material shows ISV partners and says nothing about operators as partners, with nothing inspected behind the count. Words stay at the quote: "I took the ISV channel from 6 partners to 40." Answer slot: the 18-month line makes a probe on your share of that growth likely. Say which part was yours, in your own words; if part of it was not yours, say so plainly and stay with the number |
| F2 | "Ross will push on commercials" — recruiter's email as you quoted it | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The material says influenced revenue, not revenue you closed or carried, and nothing inspected sits behind it. Words: "roughly £4M of influenced revenue." Answer slot: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F3 | A direct revenue target for partner-sourced revenue — role-family expectation, no posting seen | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would want to be measured, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | Selling into rail operators — role-family expectation, no posting seen | "Never sold into rail specifically" — your message | none | [grounded] | capability | Stated by you. Words: "I've never sold into rail specifically." Then how you would get credible fast, said as a plan, with F5 as the only bridge |
| F5 | "Please land on what it means for the operators themselves" — recruiter's email as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning and "the other side"; it does not say train operating companies, or whether operators were your clients. Words: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the operators line makes a probe on your operator-side knowledge likely. If your consulting put you in front of operator staff, say who and what you learned, in your own words; if it did not, or none of it concerned train operators, say so plainly and stay with the network planning |
| F6 | Running a partner programme — role-family expectation from the title, no posting seen | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | none | No gap in wording, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: nine years in partnerships, the last four running the ISV channel |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. No slides, 15 minutes, and it must land on what the plan means for the operators.

**Grounded facts to build on (about you).** F6: "9 years in partnerships, last 4 at a payments company running the ISV channel". F1: "took it from 6 partners to 40". F5: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". Cite them at that scope. Present anything about how operators behave as a hypothesis you would test, never as something you know.

**The report is shared with your panel.** Their strategy team circulated it, so the consensus answer is the one every prepared candidate assembles, and reciting it scores as homework. Bring one item from it to prove you read it, then one thesis-driven divergence with your reasons, then the anti-pick. I have not seen the report, so I cannot say which items are consensus; you can, in ten minutes of reading with that one question.

**Three defensible theses (all `[generic]` frames; pick one, do not blend).**

| Thesis | The claim | Mandatory concession | Anti-pick it sets up |
|---|---|---|---|
| T1 Depth before breadth | Fewer operator partnerships, each run toward a shared measure, rather than coverage of every operator | Slower coverage, and concentration risk if one operator relationship weakens. Note your strongest figure is a count (F1), so say plainly why count is not your headline here | A partner-count target as the headline metric |
| T2 The operator outcome as the unit | Define each partnership around one outcome the operator already cares about, agreed with them first | Outcomes are hard to attribute and need operator data and commercial buy-in, which is Ross's lane; commit to agreeing measures, not to inventing numbers | Partnerships with no named operator outcome |
| T3 Partners around the product | Grow third-party partners so operators get more from the scheduling product without Kelverton building it | Operators may not want more vendors or integration work, and it depends on product readiness you do not know. Frame the ISV link (F6) as a hypothesis, never as proof it transfers | Bespoke integrations for a single operator |

**Run order (aim for 12 to 13 minutes, then stop).** 2 min what you are answering and the thesis; 3 min the thesis and why; 3 min the consensus item and your divergence; 3 min the 18 months in three stages, each with what you would stop doing; 2 min what it means for the operators; leave the remainder for the concession and what you would need to learn first.

**The requested close, what it means for the operators.** For each stage say what an operator would see differently, what it would cost them in time or change, and what they would decide differently. Name the operator role you mean (the person, not "operators"). Use F5 only at its scope.

**Commercial line, for Ross.** Say how you would want success measured as ranges to agree, not targets you invent. You have said you have not carried a direct quota (F3); name that limit yourself in Q&A, at the first commercial question.

## Persona table

The loop is established by the recruiter's own description (one 60-minute panel, a 15-minute talk, then Q&A), so these weights rest on that, not on an archetype.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on operator partnerships; scores structure and the company's vocabulary | High: the POV is a quarter of the hour, and Deepa is a hiring manager, whose relationship prior is Case plus Skeptic | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic | Probes the two stated gaps (F3, F4) and the ISV-to-operator jump | High: same prior for Deepa, and both gaps are ones you have named | Rehearse the commercial objection (B2) until it is boring; plain acknowledgment, then adjacent evidence at its own scope, then a plan |
| Data-Driven Prober | Takes each figure two levels deep | Medium-high: Ross is described as pushing on commercials, and you have two figures | Know, in your own words, how each was counted; name the assumption you would defend least; say plainly when you do not know |
| Pressure | Time-boxes, interrupts, "how much was you" | Medium: a commercial director's push, per the recruiter | Pause, restate, hold the position through two follow-ups, concede specifics |
| Conversational | A friendly opener: the journey, what you are reading | Low-medium: panels often open warm, and it is still scored | A 90-second arc built only from your own sentences |
| Peer Evaluator | Seam between partnerships and commercial | Low-medium: Ross sits on that seam | Offer seam principles, not a pretended map; reciprocity |
| Values / Behavioral | Scenario probes | Low: no values-style round is named by the recruiter and Kelverton's published values are unknown to this pack | Two scaffolds as insurance, each ending in its honest branch |

## Question banks

Bank IDs skip F so they never collide with fit rows F1 to F6.

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [generic] | Deliver the build above in 12 to 13 minutes: thesis, consensus item, divergence, three stages, operator close, concession. Then stop and invite questions. This guidance makes no claim about your past | The recruiter's 15-minute request, asked live; F1 is the requirement. CASE for delivery, with JD content |
| A2 | "Which operator problem does your plan fix first, and how would you know it had worked?" | CASE | [generic] | Clarify first (which operators, what measure they already use), then objective, then the single first problem, then a metric you would agree with the operator and a risk. Say hypotheses as hypotheses. No claim about your past | F5's requirement, asked as a decision; the operator-first close is where this panel was told to look |
| A3 | "You can start only one partnership in the first six months. Which, and what do you drop?" | CASE | [generic] | Name the one, the reason, and the anti-pick from your thesis; give the concession in your own words before they ask. A named no is the judgment signal here | The anti-pick rehearsed under time pressure; F1 |
| A4 | "In month nine, two operators ask for something the product doesn't do. What do you do?" | CASE | [generic] | Clarify (how many operators, is it a product decision or an integration, who decides), then options, then your call and who you need in the room, including Commercial. It presupposes nothing about your past | A live problem on the seam between partnerships, product and commercial; F2's commercial lens |
| A5 | "What would you need to learn in your first 30 days before committing to the plan you've just described?" | JD | [generic] | List three real unknowns from your own reading of the report and this interview, ordered by what would change the plan; end with the one you would ask Deepa first. Do not pretend to know Kelverton's current partner list | The honest-limits answer to F4 as a plan, not a past; JD because it scores readiness for the role |

### B. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Pick the one you would actually rank weakest, say it first and plainly: "I've never carried a direct quota, only influenced revenue." or "I've never sold into rail specifically." Then how you would close it, as a plan from day one, never as a past. Do not volunteer both unless asked | F3 and F4 are the stated gaps, so this question arrives in some form. JD for the scoring, with EXP delivery |
| B2 | "You've never carried a direct quota. Why should we believe you can be commercially accountable here?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | **Highest-ROI prep in this pack.** Move 1, plain and first: "I've never carried a direct quota, only influenced revenue." Move 2, what you can stand behind, at its scope: "roughly £4M of influenced revenue." Answer slot: expect how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; answer each in your own words, and if you do not know how it was counted, say so plainly. Move 3, hold through two follow-ups by returning to Move 2 rather than adding to it, and concede specifically that influenced and carried are different. Move 4, a plan: decide before Tuesday what you would accept being measured on in year one and say it in your own words; this pack will not supply your position. Say Move 1 yourself at the first commercial question | F3 is where Ross's commercial push lands hardest, so this objection will arrive in some form; the deepest rehearsal goes here. EXP because it tests what was yours, with JD content |
| B3 | "How is a train operator partnership different from the ISV channel you ran?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Say what you expect to differ and label it as hypothesis ("my hypothesis is"); say what you would check in the first 30 days. Do not state how operators buy or behave as fact. Describe the channel only as the quote does: you ran the ISV channel | F6 and F1 are the jump the panel will test; the premise is your own channel, at its scope |
| B4 | "Why leave a payments company for rail software now?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A scaffold in your own words, in three beats: why partnerships in this sector, why Kelverton (name something from the report you actually noticed), why now. If your return toward transport is part of the reason, say so; the material shows five years of transport consulting. If part of the real reason is practical, say that plainly | None of the five types is "motivation", so EXP: it tests whether your story survives cross-examination; F5 is the only relevant sentence |
| B5 | "You haven't sold into rail. How do you get credible with operators quickly?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Acknowledge first: "I've never sold into rail specifically." Then the bridge at its scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if your consulting put you in front of operator staff, say who and what you learned; if it did not, or none of it concerned train operators, say so plainly and stay with the network planning. Then a plan: who you would shadow, what you would ask | F4 and F5 together; the credibility probe is the natural follow-up to B1 |

### C. Data-Driven Prober (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure at its scope. Answer slot: how it was counted, in your own words; if you do not know how it was counted, say so plainly, which beats a method you cannot repeat under a second question. This pack does not supply a method | F2; defend-the-number for the headline metric |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name, before they do, the assumption you would defend least, and what would change if it were wrong. Answer slot: if you can name one, say it; if you cannot, say plainly you do not know how it was counted and what you would check to find out | F2; the weakest-assumption move converts a gotcha into credibility |
| C3 | "Partner count went from 6 to 40. How much of that was actually you?" | EXP | [grounded] "took it from 6 partners to 40" | Say it at its scope: "I took the ISV channel from 6 partners to 40." Answer slot: which part was yours, in your own words; if some of it was not yours, say so plainly and stay with the number | F1; attribution is what a prober scores on a growth figure |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause and restate. Concede rail first: "I've never sold into rail specifically." Then hold on what the quotes carry: nine years in partnerships, the last four running the ISV channel; five years in transport consulting. Describe it and let them draw the conclusion; do not say what it proves. Hold through two follow-ups | F4 under time pressure; F5 and F6 are the only evidence the hold may use |
| D2 | "Doesn't influenced revenue just mean revenue someone else closed?" | EXP | [grounded] "roughly £4M of influenced revenue" | Pause. Answer slot: say how influenced revenue was defined in your role, in your own words; if you do not know exactly, say so plainly. Hold your account through two follow-ups, concede the specific limit (it is not a quota), and do not argue the definition | F2 and F3; this is the Pressure form of the commercial objection |
| D3 | "Sixty seconds: what's the first partnership you'd start, and what does it cost us to start it?" | CASE | [generic] | Name it, give the reason, then the cost honestly in time and attention, ranges not invented numbers, then what you would stop to make room. Hold through two follow-ups; concede what you do not yet know. No claim about your past | A time-boxed form of A3; F2's commercial lens |

### E. Conversational (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc using only those two sentences as beats: the five years in transport consulting, then nine years in partnerships, the last four running the ISV channel. End on why this role, in your own words | F5 and F6; the biography question is scored even when it feels casual |
| E2 | "What are you actually looking at in operator partnerships these days?" | CO | [generic] | Name one thing you have actually read or done; if it is the report, say what you noticed. If nothing comes to mind, say so plainly and say what you would look at first. Do not claim to track anything you have not | The recruiter's own phrase makes this the casual form of the hot topic; `[generic]` because no research ran |

### G. Peer Evaluator (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between partnerships and commercial, and what happens when we disagree?" | CASE | [generic] | Offer seam principles rather than a map: who owns the operator relationship, who owns terms, how a disagreement is decided and by whom. Add reciprocity: what you would bring Commercial. No claim about your past | Ross sits on the seam; F2's commercial lens |
| G2 | "How do you handle credit when a deal spans partnerships and sales?" | EXP | [generic] | Selection scaffold: pick a time credit for revenue was shared or disputed between you and another team; it needs named parties, what you decided and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 involves influenced revenue, so this probe is plausible, but no sentence of yours carries a case, so it is a scaffold |

### H. Values / Behavioral (weight: low; insurance only)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a moment with a named stake, a point where you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no sentence of yours carries a story, so no mapping is offered |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: a named customer, the metric you did not serve, the decision and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; values are unknown to this pack, so it is generic |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, A5, D3 |
| "Please land on what it means for the operators themselves" | A2, B5, E2, and the POV close |
| "Ross will push on commercials" | B2, C1, C2, C3, D2, G1 |
| Running a partner programme (role-family) | B3, C3, E1 |
| A direct revenue target (role-family) | B1, B2, D2 |
| Selling into rail operators (role-family) | B1, B5, D1 |
| Values-style questions | none, and why: no values-style round is named by the recruiter; H1 and H2 are insurance |

## Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| 1 | "When we say operator partnerships, which parties do you mean, and what does a good one look like from the operator's side?" | It resolves the one ambiguity your material leaves open (partners or customers) and keeps you operator-first |
| 2 | "How is success measured in the first year, and how much of it is a number I'd carry versus one I'd influence?" | It puts the commercial gap on the table yourself, with Ross, instead of waiting for it |
| 3 | "What would you want to be different about operator partnerships by month six?" (to Deepa) | Turns her expectations, as the future manager, into the plan's success measure |
| 4 | "Where do you want the seam between partnerships and commercial to sit?" (to Ross) | Shows you plan for the boundary he lives on, not only for your own lane |
| 5 | "Where do operators say Kelverton is strongest, and where do they say it is weakest?" | Keeps the conversation on the operators, the thing the recruiter asked you to land on |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a direct quota or revenue target | Negative you stated, F3 | The plain acknowledgment F3 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative you stated, F4 | "I've never sold into rail specifically." No slot |
| Generated, closed or owned £4M | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says influenced revenue, not revenue you closed. C1's slot stays inside how it was counted |
| Built the ISV channel from nothing | Inflated form of F1 | F1's quote at its own scope: the material says you took it from 6 partners to 40 and ran it |
| Has worked with train operating companies | Inflated form of F5 | F5's quote at its own scope: bus and light rail network planning, and "the other side". The limit is the pack's observation; the slot in B5 stays inside the consulting work |

## Sources

**Provided documents:** your message, including the recruiter's email as you quoted it. The market report: named by you, not available to this session, not read; nothing in this pack comes from it. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Query sent | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail strategy train operating companies scheduling software news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Senior Partnerships Manager Kelverton Rail job | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet if a values-style round had been named, and the theme of the VAL questions; H1 and H2 stay generic |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Would have added Kelverton-specific round formats; persona weights stand, since the recruiter's own description establishes this session |
| 3. `Kelverton Rail strategy` | unavailable | Would have grounded the CO and CASE banks and a grounding brief; A-bank and E2 stay `[generic]` |
| 4. `Deepa Kelverton Rail` | unavailable | Would have supplied an interviewer read and a reverse question tied to her path; none is written. No query was sent for Ross |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have turned the role-family rows (F3, F4, F6) into quoted requirements and surfaced any gate rows |

## Upgrade menu

- The job description text → the role-family rows become quoted requirements, any gate rows (location, travel, right to work) appear, and the coverage table fills in against the posting's own list
- The market report's key sections pasted in → a grounding brief, and a concrete consensus-versus-divergence plan for the POV, with the CO bank grounded in what Kelverton itself says
- Search permission (refused this session) → a deeper research pass, up to 6 more searches and 2 more fetches, several more minutes: strategy brief, Deepa's public professional footprint and recent organisation context
- Deepa's and Ross's public professional profiles pasted in → an interviewer read and a reverse question tied to each path
- An inspectable artifact behind the two figures, such as an attribution export or a partner-programme dashboard, anonymised as needed → F1 and F2 move from medium to high
- Your answers to the F1, F2 and F5 slots, in your own words → those rows regenerate on your sentences, and B2, B5 and C1 to C3 sharpen
- The recruiter's one-line answer on what "operator partnerships" covers → the A-bank questions tighten around the right partner type
- A `tuesday-dossier.md` from job-underwriter → verified evidence, the objection to rehearse derived from evidence rather than inferred, and absolute prohibited claims
