Web search wasn't permitted, so this is based on the job description and your background alone.

## Decision snapshot

**Yes, worth applying to, on conditions. R1 (a hard gate) is unconfirmed and the employer is unverified (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R7a, R8 · unclear: R7b (Recommendations for product)
- `important`: adjacent: R10 (Pet-insurance pricing domain)
- `preferred`: direct: R9

R10 has a credible bridge with its limit named, and R7b waits on an answer.

**Opportunity ledger.** The JD names concrete activities (RR4), but the employer is unverified (RR1), pay is not stated (RR2), and the reporting scope is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you are UK-based with the right to work, with no sponsorship needed (R1); (2) the employer and the live posting verify (RR1); (3) the pet-insurance gap is framed honestly as adjacent, never as pet experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; existence not verified |
| Role | Senior Pricing Analyst: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as given in your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Scope read | The JD lists no direct reports, team or budget, so it reads as an individual-contributor senior post | `[inferred]` from the JD's silence on reports against its "Own pricing analytics" |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not run, so no salary band is offered | `[grounded]` no research ran; compensation is not in the JD |
| Unknowns | Salary; whether anyone reports in; who signs off rate changes; employing entity | `[grounded]` JD silent on each |
| Contradictions | None inside the JD; no careers page to check it against | `[grounded]` JD read; research did not run |

## Evidence map

Your background is typed prose, which counts as self-report. That caps confidence at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You have not stated where you live or your right to work. Working at a UK insurer suggests but does not settle it. Confidence is low because there is no statement of the constraint to grade. | `[inferred]` from the UK employer; JD quoted | Ask G1 in the closing questions |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer. It is specific but uninspected. | `[grounded]` your stated background | Raise with a CV or dated role history |
| R3 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. The line of business is motor, not pet. | `[grounded]` your stated background | A sanitized model-documentation page would raise this to high |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. That is self-reported with no artifact. | `[grounded]` your stated background | A code sample or repo would raise this to high |
| R5 | GLM experience | must_have | direct | medium | none | See R3: the same model is the evidence. | `[grounded]` your stated background | As R3 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. The count attaches to tests, not to people or outcomes. | `[grounded]` your stated background | A sanitized test readout would raise this to high |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You ran tests with the underwriting team and present the quarterly pricing review to the head of underwriting. | `[grounded]` your stated background | Ask for the review deck format |
| R7b | Turn results into recommendations for product | must_have | unclear | low | discovery | Nothing you have said touches a product team. A lead may exist, but it is unconfirmed. | `[grounded]` silence in your background | Ask G2 in the closing questions |
| R8 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your stated background | A sanitized review deck would raise this to high |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer meets it. | `[grounded]` your stated background | None |
| R10 | Pet-insurance pricing domain (implied by owning pricing for the pet product) | important | adjacent | low | transferability | Your motor GLM work carries over to rating-factor design and monitoring. The limit is that you have not worked with pet-specific rating factors or claims patterns. | `[inferred]` adjacency from your motor work; `[generic]` that pet and motor books differ in their rating factors | See G3; no claim of pet experience |

R10's requirement is an inference from the JD's "Own pricing analytics for our pet-insurance product". The JD does not list pet experience as required.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based and eligible to work (R1, hard_gate) | hard_gate | Nothing states your location or eligibility | A failed gate would make this `no_go` whatever the fit elsewhere | A plain statement of residence and right to work | None needed | `[grounded]` no statement in your message |
| G2 | Recommendations for product (R7b, must_have) | discovery | Your underwriting work is clear; no product-facing work appears | A must-have; resolving it could remove the condition on how you pitch the role | A price-test result that fed a product or proposition change; a presentation to a product or commercial lead; a rate or feature recommendation another team acted on | A readout, deck or email thread, sanitized | `[grounded]` background silent; `[inferred]` that resolving it firms up the decision |
| G3 | Pet-insurance domain (R10, important) | transferability | Adjacent: motor GLM, tests and monitoring. Limit: no pet-specific rating factors or claims patterns | The most likely objection in a screen | A strengthener: a short note comparing the rating factors you used in the young-driver model with what a pet book might use | A one-page sanitized factor comparison | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Research was refused, so this is unchecked. | `[generic]` pattern for companies of this size, not a claim about this one | Which legal entity employs this role, and who underwrites the pet policies? | unresolved |
| RR2 | Salary not stated | unknown | — | No figure in the JD | The pay may sit anywhere relative to your current salary | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Reporting scope unstated for a senior "Own" role | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be an individual-contributor post, or may expect people leadership later | `[inferred]` from the JD's silence on direct reports | Does this role have direct reports now, and is any planned? | unresolved |
| RR4 | Responsibilities are concrete | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is defined by named activities | `[grounded]` JD | Which of these three activities takes most of the week? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and the live posting through Brindlemoor's own careers page or the recruiter's email domain before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your own sentences: "built and maintained the GLM rating model for the young-driver book", "ran 14 price tests last year with the underwriting team", "present the quarterly pricing review to the head of underwriting" | see R3, R6, R8 | `[grounded]` your stated background | pending your approval |
| A3 | Name the pet-insurance gap yourself and bridge through your motor rating work. Claim no pet exposure | see R10, G3 | `[inferred]` from the R10 row | pending your approval |
| A4 | Ask RR2 and RR3 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | If asked about management, say you have not managed anyone. The JD lists no reports (RR3) | see RR3 | `[grounded]` JD silent on reports; your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have tested whether Brindlemoor exists as described and the posting is live (RR1, role reality) |
| 2. Role-family sweep | unavailable | The search was refused. It would have supplied the market calibration line and a salary band to set against RR2 |
| 3. Hiring manager's public footprint | unavailable | The search for Odile Varga was refused. It would have fed the scope read and which story to lead with in the plan |

I didn't retry the refused searches.

Would you like me to put this into a `tuesday-dossier.md`? It's optional, and it would carry this analysis forward to other steps.

## Upgrade menu

- Your CV, or a dated role history, would firm up R2 and show whether the evidence is buried.
- A sanitized model-documentation page, test readout or review deck would raise R3, R5, R6 and R8 toward `high`.
- Permission to run web search would let me check RR1, set a salary band against RR2, and read Odile Varga's public professional footprint.
- The budgeted salary range closes RR2.
- Any non-negotiables (pay floor, contract type, days in an office) would let me check the role's terms against them.

G1 — Are you UK-based with the right to work in the UK without sponsorship?
G2 — Has a price-test result of yours ever fed a product or proposition decision, and what did you own versus the team?
Q3 — Do you have any non-negotiables, such as a pay floor or contract type, that I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.