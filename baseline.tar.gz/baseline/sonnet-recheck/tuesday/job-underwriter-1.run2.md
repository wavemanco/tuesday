Both web searches were refused, so this assessment rests on your text alone and the research rows below say so.

## Decision snapshot

**Yes, apply. R1, R2, R3, R4 and R5 land `direct`, with R6 still to firm up. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (Metrics layer)
- `important`: adjacent: R7a (Partnering with product managers) · unclear: R7b (Partnering with clinicians), R8 (Mentoring two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data / HIPAA)

R6 is the one `must_have` to firm up, and R9 is adjacent with its limit named.

**Opportunity ledger.** The role is clearly bounded (RR3), but the employer is unverified (RR1), pay and location are absent from the posting as pasted (RR2), and the metrics layer's current state is unknown (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your metrics-definition work matches what R6 asks (G1); (2) the posting and employer verify (RR1); (3) pay and location fit your constraints once you state them (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C; not independently checked | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve dashboards | `[grounded]` JD |
| Stakeholders | Product managers and clinicians; two junior analysts to mentor | `[grounded]` JD |
| Scope read | A senior individual-contributor role with a mentoring component, not a people-manager role | `[inferred]` from "mentor" where the JD could have said "manage" |
| Market calibration | Not done: the role-family search was refused, so no pay band is offered | `[grounded]` search refused |
| Unknowns | Pay, location or remote policy, whether the metrics layer exists today or must be built, how clinicians take part in roadmap decisions | `[grounded]` absent from the pasted JD |
| Contradictions | None inside the JD; the careers page was not checked | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics stated, which meets the bar; self-reported, no document inspected | `[grounded]` your background statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is stated. "Expert" is the JD's word, not yet evidenced; expect a live SQL exercise | `[grounded]` your statement; `[generic]` that roles like this often test SQL live | A sanitized query or data-model sample would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Expect a probe on your exact role in that test and on sample-size trade-offs in a smaller user base | `[grounded]` your statement; `[generic]` on the smaller-base probe | A sanitized experiment readout or test-plan template would raise it to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. Limited inspectable proof | `[grounded]` your statement | A sanitized dashboard inventory or screenshots would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your statement | A sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests definition work, but nothing says you owned canonical metric definitions or a modeling layer. Low rather than none, because a concrete thread exists | `[grounded]` your statement; `[inferred]` that governance implies some definition work | See G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | low | discovery | You present to the VP Product and ran an experiment program, which implies product-manager partnership; you did not state it directly | `[inferred]` from the experiment program and VP presentations | Confirm in G1's answer or the resume pass |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your background touches clinical stakeholders. Any bridge would be other domain-expert partners, with the limit named | `[grounded]` no evidence given | G2; not asked this turn |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Mentoring is not mentioned either way | `[grounded]` your background is silent | See G3 |
| R9 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | GDPR/CCPA handling of consumer PII and the warehouse consent-state model carry over. Limit: no protected health information or HIPAA-specific practice | `[inferred]` adjacency from your GDPR/CCPA work; `[generic]` that HIPAA practice differs from consumer-privacy work | Never claim healthcare experience; G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | You built governed dashboards, but not whether you owned the metric definitions behind them | The one `must_have` row below `direct`; resolving it likely makes the case a plain `go` | Writing canonical definitions for retention or churn; LookML or semantic-layer models; a metric dictionary; resolving "two teams, two numbers" disputes | A metric dictionary, LookML excerpt, or definitions doc, sanitized | `[grounded]` your statement does not say who owned definitions; `[inferred]` that this moves the status |
| G2 | Clinician partnership (R7b, important) | discovery | No clinical or other domain-expert stakeholders mentioned | A named JD responsibility that a hiring panel is likely to ask about | Analysis done with ops, nutrition, or customer-care experts who judged what the data meant | A project brief or readout | `[grounded]` background silent; `[generic]` that panels ask about named stakeholders |
| G3 | Mentoring (R8, important) | discovery | Mentoring is not mentioned | The JD names two junior analysts | Onboarding a new analyst, reviewing others' SQL or experiment designs, or a formal mentee | A named mentee or review process | `[grounded]` background silent |
| G4 | Healthcare data (R9, preferred) | transferability | Real consent-state and PII work, no HIPAA exposure | Preferred only; an honest bridge beats an overclaim | Consent-state model, access controls, de-identification or minimization decisions | The consent-model design doc, sanitized | `[inferred]` bridge from your GDPR/CCPA work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The posting may be real and ordinary, but the search that would show it was refused | `[generic]` pattern for any unverified employer, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location not stated | unknown | — | No pay or location appears in the pasted JD | The posting may state them and the paste dropped them, or the employer may withhold them | `[inferred]` from the pasted text | What is the salary range, and what is the location or remote policy? | unresolved |
| RR3 | Clear ownership and named partners | positive_signal | — | "Own product analytics for our care-navigation app" | Scope looks genuinely bounded, with named responsibilities | `[grounded]` JD | Which roadmap decisions has analytics changed in the last two quarters? | noted |
| RR4 | Metrics layer state unknown | unknown | — | "define and maintain the metrics layer" | The layer may exist and need upkeep, or it may need building from nothing, which is a different job | `[inferred]` from "define and maintain" being ambiguous | Is the metrics layer in place today, and in what tooling? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the company's careers page, or ask the recruiter, before investing in a tailored application | See RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead your resume with the experimentation program and the Looker build, using your own figures (30+ A/B tests a year; the pricing test behind an 11% retention lift; 40+ governed dashboards) | See R3, R4 | `[grounded]` your statements | pending your approval |
| E2 | Describe the healthcare gap plainly: you have not worked in healthcare, and you handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Do not call that HIPAA experience | See R9 | `[grounded]` your statements | pending your approval |
| Q1 | Ask RR2 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app Series C" was refused (permission not granted). It would have fed role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | The search "Senior Product Analyst digital health salary range Looker A/B testing" was refused. It would have fed market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can write this up as a `tuesday-dossier.md` if you want a copy to keep.

**Upgrade menu**
- Grant search permission, and I'll run targets 1 and 2. That would settle RR1 and add a pay band against RR2. A deeper pass (up to 5 more searches and 2 more fetches) is available after that.
- A sanitized metric dictionary or LookML excerpt would settle R6.
- A sanitized experiment readout, dashboard inventory, or exec memo would raise R3, R4, and R5 to `high`.
- Your pay floor and location or remote needs would let me check hard gates, which are currently unknown.
- The hiring manager's name would shape which story the plan leads with.

**Questions**
- G1: Did you personally own the definitions behind your dashboards, such as how retention or churn is calculated, and where do they live (LookML, a doc, a metric dictionary)?
- Constraints: What is your pay floor, and what location or remote setup do you need?
- G3: Have you mentored or onboarded other analysts, and in what form?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.