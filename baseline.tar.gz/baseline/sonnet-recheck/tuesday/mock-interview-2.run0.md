No dossier present. Reading the playbook's required files.
I couldn't save the pack as a file because write permission was denied, so the whole pack is below. The company searches were also refused. Nothing here about Atlas comes from outside your JD, and the company-knowledge parts are marked generic.

I built it for a hiring-manager round, since you didn't say who you're meeting.

# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees), as in the JD you pasted.
**Interviewer:** not known.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding, not a script. Quoted lines from your message are safe to say. An "answer slot" has to be filled from your own experience, or left out.

| Tag | What it tests |
|---|---|
| VAL | Whether past behavior shows good judgment on the people and values side |
| EXP | Whether a claim about your work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company |
| CASE | Structure and reasoning on a live problem |

- **Provenance labels:** `[grounded]` rests on your message or the JD. `[inferred]` is this pack's derivation, and the derivation is named. `[generic]` is a role-family pattern with no claim about Atlas or about you.
- **Question IDs:** they skip the letter F so they can't be confused with fit-snapshot rows F1 to F7.

## 1. Prep triage (about a week, assumed from "next week")

1. **B1, three times aloud.** The step from 3 supervisors to 12 is the question this pack expects most.
2. **C1 and E1.** The 40% is your only number. Know how it was counted and which part was yours, or be ready to say plainly that you don't know how it was counted.
3. **B5, A3 and F5.** Your Power BI answer is one plain acknowledgment plus a plan. Practice it in one breath.
4. **A1 and A2.** Do each case aloud once, clarifying before you structure.
5. **A5.** Research couldn't run (section 8), so read Atlas's own site and recent news and bring two specifics.
6. **D1.** A 90-second arc built from your own sentences.

Everything else is insurance.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution work, a shift role and one site's surge plan. It does not show terminals or more than one site. The words stay at the quotes: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on what you've covered beyond your own site likely. If any of your work reached other sites or a terminal, say which and what you did, in your own words. If none did, say so plainly and stay with the site you work in |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate measures accuracy. Your material doesn't show an on-time or cost-per-shipment measure. The words stay at: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: expect a probe on which service and cost measures your site counts. If it counts either measure the JD names, say which, how it's counted and which part you influenced. If it doesn't, or the measure was someone else's, say so plainly and stay with the pick-path result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Twelve is four times three. The words stay at: "I'm a senior shift manager over 3 supervisors." Answer slot: if you've led more than three supervisors at any point, say how many and when. If not, say so plainly and describe the three. Anything beyond that is a plan, said as a plan |
| F4 | "build reporting in Excel/Power BI" — JD (Excel side) | "solid Excel" — your message | low | [inferred] | discovery | Derived from the gap between a skill claim and the JD's "build reporting": the quote says Excel skill, not what was built. Answer slot: if anything you made in Excel is read by others, say what it shows and who reads it. If your Excel use isn't that, say so plainly and say what you'd build first |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI side) | "never used Power BI" — your message | none | [grounded] | capability | A gap you stated. The words: "I've never used Power BI." Then how you'd learn it, said as a plan and never as a past. The JD's "Excel/Power BI" doesn't say whether both are required, which the recruiter can settle |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Derived from the quotes: the seven years are operations, and the material doesn't say how many were leadership, which is what the requirement counts. Expect the arithmetic to be asked. Answer slot: say how many of the seven years you've led supervisors, as the number stands. If fewer than five, say so plainly and say what the other years covered |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I'm green belt certified." Your message lists it apart from the pick-path redesign, so the pack doesn't join them. If they are joined, that's yours to say (see D2) |

No row is a hard gate. The 5+ years line is a years requirement, graded as F6 and not as a gate.

## 3. Requirement coverage

| JD requirement or headline claim | Questions that cover it |
|---|---|
| Own daily terminal operations across 4 sites | A4, B1, B2, H1 |
| Drive on-time performance and cost-per-shipment down | A1, A2, C3 |
| Lead a team of 12 supervisors | B1, D3, G2 |
| Build reporting in Excel/Power BI | A3, B5, C2 |
| 5+ years operations leadership | B3 |
| Lean/Six Sigma a plus | D2 |
| The 40% mis-pick figure | C1, E1 |
| Company knowledge | A5, plus the reverse questions in section 6 |

## 4. Persona table

Weights start from the hiring-manager assumption. No loop source was read, so the fallback is the Generic archetype (screen, then hiring manager, then panel, flat weights). These weights rest on a pattern, not on Atlas's actual process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a method, not a claim) |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems on on-time, cost and reporting | High: hiring-manager prior, and the JD is a list of operating metrics. Five questions | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic (bank B) | Quiet probing of scale, terminals, years and Power BI | High: hiring-manager prior, and F1, F3, F5 and F6 are the largest gaps. Five questions | Rehearse the most predictable objection (B1) until it's boring. Bridge only from what you stated |
| Data-Driven Prober (bank C) | Line-by-line probing of the 40%, and of what you measure and report | Mid: your only figure, and the JD names Excel and Power BI. Three questions | Know how each number was counted and say so plainly when you don't. Name your weakest assumption first |
| Conversational (bank D) | Friendly opener, casual probe on the JD's plus-skill | Mid: a recruiter screen or opener is possible in any round. Three questions | A 90-second arc. Treat casual questions as scored |
| Pressure (bank E) | Time-boxed challenges to attribution and motive | Low to mid: possible with a skip-level, nothing says so. Two questions | Pause, restate, hold through two follow-ups, concede only what's real |
| Values / Behavioral (bank G) | Scenario prompts on leading people | Low: no values-style round is detected and no published values were read. Two questions | Where none of your sentences carries a story, use the selection scaffold and its honest branch |
| Peer Evaluator (bank H) | Seams between sites, credit, disagreement | Low: a site-lead peer may sit in the loop, nothing says so. Two questions | Reciprocity framing. Propose seam principles rather than pretending to know Atlas's seams |

## 5. Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your four terminals has slipped over the past two months while the other three are steady. What do you want to know first, and how do you diagnose it?" | CASE | [generic] | No claim about your past. Clarify first: how on-time is defined and who sets it, which shipments and shifts, since when. Then objective, segmentation (shift, inbound versus outbound, customer), approach, metrics, risks. Challenge one premise, such as whether the other three are steady because of the operation or the measure | F2 is the requirement this tests. CASE because it scores structure on a live problem |
| A2 | "Cost per shipment is up and leadership wants it down this year without hurting service. Where do you look first and how do you decide what to change?" | CASE | [generic] | No claim about your past. Clarify what's inside cost per shipment and how it's calculated, and segment the cost. Test any change against on-time, pilot at one site, and name the risk that a cost cut quietly costs service. Challenge one premise: is a single cost measure the right target | F2's second measure. CASE because reasoning is scored, not the number |
| A3 | "Four sites report performance in four different ways. How would you build one weekly view for the leadership team?" | CASE | [grounded] "solid Excel, never used Power BI" | Structure first: who reads it, what decision it supports, a small set of measures defined once. Excel is the tool your message calls solid, so start there. Plain acknowledgment from F5: "I've never used Power BI." Then a plan said as a plan: how you'd learn it, and what you'd confirm about the tools already in use | F4 and F5. CASE because it's a build problem, and you surface the Power BI limit before they find it |
| A4 | "A major customer says its volume will double for six weeks across all four sites. What does your plan look like and where does it break first?" | CASE | [generic] | No claim about your past. Clarify the forecast and its confidence, the constraints per site and what can flex. Plan labor, space and handoffs between sites, and name the first likely failure and the signal you'd watch. Challenge one premise, such as whether all four sites feel the surge equally | The JD's four sites and daily ownership (F1). CASE because the load is hypothetical |
| A5 | "What do you know about Atlas Freight, and why us?" | CO | [generic] | This pack couldn't research Atlas, so it supplies no facts about the company. Selection criteria: bring two specifics you found yourself on Atlas's own site or in recent news, say where you found each, and tie each to a line in the JD. If you find nothing specific, say so plainly and answer from the JD's words: regional logistics, four sites, twelve supervisors | Near certain in some form. CO because it scores homework depth. `[generic]` because no research ran |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're a senior shift manager over three supervisors today. This role leads twelve across four sites. What changes?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI prep in this pack.** Say the quote first and the limit before they ask: "I'm a senior shift manager over 3 supervisors, and twelve across four sites is a bigger step." Hold that through two follow-ups. Concede the size of the step, never the core of your answer. Follow-up one, "what makes you think you can lead four times as many": answer slot: if you've led more than three people at any point, say how many and when. If not, say so plainly and go to your plan. Follow-up two, "terminals aren't warehouses": go to B2. Follow-up three, "six months in, one site is failing, how do you know": a plan, said as a plan. Plan slots, in your own words: the first thing you'd learn about each supervisor, the first measure you'd read at each site, what you'd leave unchanged for thirty days | F3 is the biggest visible gap and F1 sits beside it, so this objection will arrive in some form. JD because it scores the stated requirement |
| B2 | "Your background is warehouse and distribution. How would you handle the terminal side of this role?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's daily terminal ownership makes a probe on terminal work likely. If any of your seven years touched terminal work, say which part and what you did, in your own words. If none did, say so plainly and say how you'd learn a terminal in your first weeks | F1. JD because it scores the stated responsibility and its gap |
| B3 | "The role asks for five or more years of operations leadership. How does your experience stack up?" | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" | Say the quotes as they are. Answer slot: say how many of the seven years you've led supervisors, as the number stands. If it's fewer than five, say so plainly and say what the other years covered. Don't round up, because the next follow-up is usually "since when" | F6. JD because it scores a stated qualification literally |
| B4 | "You're a senior shift manager today. Why leave that for a role this much bigger?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | The reasons are yours, and this pack doesn't supply them. Selection criteria: one thing in the JD that pulls you, quoted from it, and one thing from your own work that connects, in your own words. Say toward the role rather than away from your current one. If no reason comes to mind yet, say so plainly and work it out before the interview | The standard motivation probe. EXP because it tests whether your story survives questioning |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Name it before they do, and choose it yourself. Your material shows two candidates, Power BI and the step to twelve supervisors, and which you name is your call. If it's Power BI: "I've never used Power BI," then your plan, said as a plan. Don't volunteer a weakness you don't believe in | F5. JD because it scores honest self-assessment against the stated list |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40% by redesigning the pick path. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the quote: "I cut mis-pick rate 40% by redesigning the pick path." Four answer slots, each in your own words: how the figure was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours. If you don't know how it was counted, say so plainly. Never explain a method you can't repeat under a second question | F2. EXP because this is the defend-the-number question for your only figure |
| C2 | "How do you report on your site's performance today?" | JD | [grounded] "solid Excel, never used Power BI" | Answer slot: the JD's reporting line makes this probe likely. If you make or maintain anything others read, say what it shows and who reads it. If there's none, or someone else builds it, say so plainly and return to "solid Excel" as what you can say | F4. JD because it scores the stated reporting requirement |
| C3 | "What numbers do you look at to know your site had a good day?" | JD | [generic] | Selection criteria: name the two or three you actually use, with each one's definition and who sees it. The JD names on-time performance and cost per shipment. If your site counts neither, say so plainly and say how you'd define them | F2. JD because it tests whether the JD's measures are ones you already work with |

### Bank D: Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc whose beats are the clauses of those quotes: seven years in warehouse and distribution ops, now a senior shift manager over 3 supervisors, the pick-path result, the surge plan two years running, the green belt. Close with why this role. That part is yours to say, and no quote carries it | F1, F2, F3 and F7 as one story. EXP because the opener is a scored summary |
| D2 | "I see you're green belt certified. Tell me about that." | JD | [grounded] "green belt certified" | The quote at its own scope: "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a probe on use likely. If the certification has been used in your work, say how and what part was yours. If it hasn't, or the work was separate, say so plainly and stay with the certification. Your message lists the pick-path redesign separately, so don't join the two unless you did | F7. JD because the plus-skill is asked casually and still scored |
| D3 | "What would your first ninety days here look like?" | CASE | [generic] | No claim about your past. A plan skeleton: learn each site's measures first, meet the supervisors, pick one thing to improve and one to leave alone, say what you'd report back and when. Promise no results | F1 and F3. CASE because it scores structure, and it prepares the answer B1 needs |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold the quote through two follow-ups: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you designed the path, say what you decided. If others did parts, say who did what. If part wasn't yours, say so plainly and return to the part that was. Concede specifically, never on the core claim | F2. EXP because attribution probes exist to catch inflation, and the honest rehearsal is candor |
| E2 | "Sixty seconds: why you over a candidate who has already run several sites?" | JD | [grounded] "7 years in warehouse and distribution ops" and "ran the site's peak-season surge plan two years running" | One claim from each quote, in its own terms. Answer slot: if pressed on running several sites, say what you have, in your own words, or say plainly that you haven't and return to the two quotes. Don't argue the other candidate down | F1 and F3. JD because it scores fit against the stated role under time pressure |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | None of your sentences carries this story, so it's a selection scaffold. Pick a time with a named stake, a moment you didn't soften it, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | A standard values prompt. No values round is detected, so this is insurance |
| G2 | "Tell me about a time you had to hold a supervisor accountable." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | The theme comes from the JD's twelve supervisors. Your quote gives the setting only: "I'm a senior shift manager over 3 supervisors." The story is yours to choose: a named situation, what you said, what happened next, where the relationship ended up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | F3. VAL because it scores how you lead people, and it sits beside B1 |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "If two of the four sites need the same resource in the same week, how do you and the other site lead settle it?" | CASE | [generic] | No claim about your past. Propose principles rather than pretending to know Atlas's seams: shared priorities, an agreed tiebreaker, a standing weekly check. Offer what you'd give the other lead, not only what you need. Say how you'd disagree with a peer and keep the relationship | F1's four sites. CASE because the problem is hypothetical |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a case where credit was shared, say plainly what was yours and what was others', and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you'd handle it | Persona stem. VAL because it scores collegial candor |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and which of the four sites is furthest from where you want it?" | Shows you think in definitions first, and surfaces which site matters most |
| R2 | "What does reporting look like today, what lives in Excel, what in Power BI, and who owns each?" | The JD names both tools. This turns your Power BI gap into a plan about where you'd start |
| R3 | "Is this a new role or a backfill, and what does the supervisor team look like today?" | Tells you the starting point behind the twelve supervisors |
| R4 | "What would make you say in six months that this hire worked?" | Makes the interviewer state the measure of success |
| R5 | "Do the sites hand work to one another, and if so where does it break most often?" | Shows you look for seams, and gets the real operating problem in their words |
| R6 | "How much of this role is time at the sites versus time in reporting and meetings?" | Surfaces the real shape of the week, which the JD doesn't state |

## 7. Prohibited claims

Built before the banks, from the fit snapshot. None of these is coached, softened or implied anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The pack's observation, not words for you: your material shows a shift role and one site's surge plan, not terminals or several sites. B2 and H1 stay inside that |
| Improved on-time performance, lowered cost per shipment, or saved money through the pick-path change | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate. C3's slot asks only what your site counts |
| Led or managed twelve supervisors, or supervisors at scale | Inflated form of F3 | F3's quote: "I'm a senior shift manager over 3 supervisors" |
| Built dashboards or BI reporting | Inflated form of F4 | "solid Excel" at its own scope. The pack's observation is that the quote doesn't say what was built. C2's slot asks only what you make that others read |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Led Lean or Six Sigma projects, or presented the pick-path redesign as a belt project | Inflated form of F7 | "green belt certified" at its own scope. Your message lists the redesign separately |
| Five or more years of operations leadership | Inflated form of F6 | F6's quotes: seven years in operations, with the leadership years an open number that B3 asks you to state |

## 8. Sources

**Provided documents:** the JD text and your background paragraph, both in your message. No `tuesday-dossier.md` was present.

**Searches sent, all refused (search permission wasn't granted):**

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics terminals news strategy` — refused

No page fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search refused. Would have moved: a values cheat sheet if a values round is documented, and VAL questions themed on Atlas's own principles |
| 2. `Atlas Freight interview process` | unavailable | Search refused. Would have moved: the loop structure and persona weights. The Generic archetype stands in, as section 4 says |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search refused. Would have moved: a CO question grounded in current strategy. A5 is `[generic]` instead |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. There is no interviewer read |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 9. Upgrade menu

- **Interviewer and round:** who it is and what round it is → persona weights recomputed, and a reverse question tied to their own path.
- **Search access, or pasted Atlas pages:** access or the text of Atlas's values page, careers page or recent news → a values cheat sheet if a values round is documented, and A5 and the CO bank grounded. A deeper pass would then be available at up to 6 more searches and 2 more fetches, taking several more minutes.
- **Recruiter details:** the process, any take-home or presentation, and whether the role travels between the four sites → coverage of any declared deliverable, and sharper A4 and H1.
- **Your CV:** the snapshot's six quotes from your message become CV lines, and F1, F3 and F6 get dates and scope.
- **Your answers to the slots in F1, F2, F3, F4 and F6, said outside a drill:** those rows upgrade, and B1, B3 and C2 become story-mapped.
- **The green belt certificate or issuing body:** F7 moves from medium toward high.
- **A `tuesday-dossier.md` from the job-underwriter, if you've run it on this role:** verified evidence, its objection and its prohibited claims folded in. It's never a prerequisite.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you grant file-write permission, I'll save this pack as a markdown file, and as a Word document if you'd like one.

Who is the first person you're meeting — a recruiter, your would-be manager, a peer or a panel — and did the recruiter mention a format or a take-home? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.