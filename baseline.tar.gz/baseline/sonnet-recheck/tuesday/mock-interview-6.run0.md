Web search was refused in this session, so I'm building the pack from your message alone. Everything about Larkfield itself will be labeled generic.
The write to the working directory was denied. The scratchpad folder is one of the places you can open files from, so I'll save the pack there.
I couldn't save the pack as a file. Both the write to the working directory and the one to the scratchpad were declined, and I didn't try other routes. The full pack is below instead. Web search was also refused, so nothing here is a researched fact about Larkfield.

# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Built on these assumptions:
- Your role summary stands in for the JD.
- There is no CV, so every fact about you comes from your message.
- The two staff engineers are treated as technical peers.
- No interviewer names were given.

## How to use this pack

Personas describe how a question is asked. Types describe what is scored. Guidance is scaffolding, not a script. Where a cell has an answer slot, give whichever branch is true.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Work-experience deep-dive: what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

IDs: T is Tuesday, P is the panel, V is the VP. The letter is the persona. The deepest rehearsal is **T-B1**. The hardware-roadmap gap it targets returns in P-E1, V-K1 and V-L2.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your role summary | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team of six, not two squads, and shows no device-management work. Words stay at that scope: "I've spent three of my nine years as a team lead of six." Answer slot: expect a probe on stepping from one team to two. If any part of your current work spans more than one team, say what and what was yours; if none does, say so plainly and stay with the team of six |
| F2 | "own delivery" — your role summary | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | One delivery call under pressure, with a figure; it does not show a roadmap owned end to end. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: expect the defend-the-number probes: how the 60% was counted, what it is sensitive to, the assumption you would defend least, which part was yours. If you do not know how it was counted, say so plainly |
| F3 | "hiring" — your role summary | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | Already in role-relevant terms, but nothing inspected sits behind it, so expect a probe. Lead with it as written, keep "about", and don't widen it beyond backend roles |
| F4 | "growth for 11 engineers" — your role summary | none given | none | [grounded] | discovery | Your material neither shows nor denies this. Answer slot: if you have helped an engineer grow, say who and what was yours; if not, or it was not yours, say so plainly and say how you would start |
| F5 | "partner with hardware and product on roadmap" (hardware side) — your role summary | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you've said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past |
| F6 | "partner with hardware and product on roadmap" (product side) — your role summary | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | transferability | The sentence doesn't say who applied the pressure or that you partnered with product. Answer slot: if the pressure came from product, say so and what you did; if it came from elsewhere, or you had no product counterpart, say so plainly |

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probing what the role needs and your background doesn't show | High. Hiring-manager prior is Skeptic plus Case. It gets the extra question because F1 and F5 are the biggest gaps | Rehearse the predictable objection until it's boring; candor over bluffing |
| Case/Strategist | Live problems from the real role | High. Same prior | Clarify, objective, approach, metrics, risks; challenge one premise |
| Data-Driven Prober | Line-by-line probing | Medium. One headline figure and one count | Know how each number was counted |
| Conversational | Chatty opener | Low | A 90-second arc |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | **Highest-ROI prep.** Level one: name it before they do: "I've never owned a hardware-adjacent roadmap." State the limit first: your material shows no hardware-adjacent roadmap work, so no story is available and none should be reached for. Then a plan, said as a plan: who you'd learn from first and what you'd ask, in your own words. Follow-up "What makes you think you can learn it fast?": answer slot: if you've worked beside hardware teams, say how and what was yours; if not, say so plainly and return to the plan. Follow-up "What if you're wrong about how fast?": concede the specific uncertainty and name the checkpoint where you and the Director would both see whether the ramp works. Don't fold on willingness; concede only the speed | F5 is the stated gap and the one the role text names; this question arrives in some form |
| T-B2 | "The role covers two squads and 11 engineers; you've been a team lead of 6. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Say the step plainly: "I've spent three of my nine years as a team lead of six." Then what you expect to change, as a plan. Answer slot: if any current work spans more than one team, say what and what was yours; if none, say so plainly. If it turns to managing managers: "I've never managed managers." | F1 is the scope gap |
| T-B3 | "Why this role, and why now?" | VAL | [generic] | Scaffold: one specific thing in the role as described that you want, and one conclusion from your current work that points here. If no reason comes cleanly, say so plainly, then give the nearest honest thing | Standard motivation probe; no claim made |
| T-B4 | "When have you helped an engineer grow? Pick one case." | JD | [generic] | Scaffold: a named person, something that was yours, a result you can describe without inflating. If no case comes to mind, say so plainly, then say how you'd approach growing the 11 | F4 has no evidence either way |

**Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "Sketch your first 90 days: two squads, 11 engineers, a roadmap you share with hardware and product. What do you need to know first?" | CASE | [generic] | Clarify first (customers, commitments, hardware counterpart), then objective, approach, metrics, risks. Name one premise to challenge | The role's shape as a live problem |
| T-A2 | "A device-management outage: hardware thinks it's firmware, your squad thinks it's the service. Walk me through the first hour." | CASE | [generic] | Stabilize, establish who owns diagnosis, communicate, decide what's reversible, record. Say what you'd ask the hardware lead first | Tests the squad/hardware seam (F5) as a decision |
| T-A3 | "Product wants a customer feature this quarter, and a squad is carrying reliability debt. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Structure the decision and what you'd agree before the quarter starts. If you draw on a past case, tell it as "I pushed a reliability quarter through against roadmap pressure". Answer slot: if the pressure came from product and something was traded, say what; if nothing was, or it came from elsewhere, say so plainly and answer fresh | F2 and F6 meet here |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-C1 | "The on-call burden dropped 60%. How was that number counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: how it was counted, what it's sensitive to, the assumption you'd defend least, which part was yours. If you don't know how it was counted, say so. Keep the sentence's order: it dropped after the quarter, which is not the same as the quarter being the whole cause | F2's headline figure |
| T-C2 | "How much of that reliability quarter was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold on "I pushed a reliability quarter through against roadmap pressure." Answer slot: which parts were yours and which the team's; if most was the team's, say so plainly. Hold through two follow-ups by returning to that sentence, never adding to it | Attribution probe on F2 |
| T-C3 | "You run the hiring loop for backend roles. How would you approach hiring for these squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it as written. Answer slot: expect a probe on who made final calls. If offers or decisions were yours, say so; if the loop fed someone else's decision, say so plainly | F3, your strongest match; the probe is on its edge |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." and "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | A 90-second arc of only these beats: nine years in engineering, three as team lead of six, you run the backend hiring loop, you pushed a reliability quarter through. Add your reason for this role in your own words | The opener is scored |

**Reverse questions (Tuesday)**

| Question | Why it lands |
|---|---|
| "What does success look like for these two squads at six months, and who decides?" | Shows you're pricing the job |
| "Where do the squads' roadmap and the hardware roadmap collide today, and how is it handled?" | Goes to the seam this role sits on |
| "I haven't owned a hardware-adjacent roadmap. What would you want me to learn first?" | Turns the named gap into a working conversation |
| "How are the 11 engineers split across the two squads, and what's each squad's hiring picture?" | Ties hiring and growth to specifics |
| "Which decisions would you want to stay yours, and which would you hand to me?" | Tests the boss relationship early |

## Round 2: Thursday, panel (two staff engineers and a product manager), 60 min

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit | High. Peer prior for the staff engineers; the PM's partnership role adds to it | Reciprocity; propose seam principles |
| Data-Driven Prober | Line-by-line claim probing | High. Technical-peer prior; F2's figure and F3's count are targets | Know how each number was counted |
| Values/Behavioral | Scenario probes | Medium. Cross-functional prior for the PM | Stories only where your material carries one |
| Conversational | Friendly but scored | Medium | Treat casual questions as scored |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-E1 | "Our teams sit side by side. Where's the seam between a squad's services and hardware, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know this seam: who owns the interface, how changes are announced, how disagreements escalate. For the disagreement half, a scaffold: a named disagreement, your position, what you conceded. If none comes to mind, say so plainly | F5; peers price what the hire costs them |
| P-E2 | "What would you need from me, and what would I get from you?" | JD | [generic] | Lead with what you bring, then a clear ask. No claim about your past | Peers weigh whether you add or reduce their load |
| P-E3 | "Tell me about a time you pushed back on a roadmap and kept the relationship with product intact." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-map only what the sentence states: a reliability quarter, roadmap pressure, you pushed it through, on-call dropped after. Answer slot: if the relationship with whoever applied the pressure held, say how; if it strained or the pressure came from elsewhere, say so plainly | F6 |
| P-E4 | "How do you handle credit when work spans teams?" | VAL | [generic] | "We" for context, "I" for what you did. Choose a shared-credit case; if none, say so and say how you'd handle it | Standard Peer probe |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-F1 | "The on-call burden dropped 60% after the reliability quarter. What do you know about why?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: if you know what changed, name it and which part was yours; if you don't know what drove it, or it wasn't the quarter's work, say so plainly. Name the assumption you'd defend least before they ask | F2; staff engineers go two levels deep |
| P-F2 | "How do you judge an engineer's technical depth when you interview?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: say what you actually look for and how you decide; if there's no consistent method, say so and say what you'd put in place. Stay with backend roles | F3 |
| P-F3 | "What do you know about device-management services today, and where does it run out?" | JD | [generic] | State what you know, name where it stops, say what you'd read or ask first. No domain claim is supplied | F1's domain gap |

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The sentence doesn't say leadership was involved; use it only if that's true. Answer slot: if so, say what you told them and how it landed; if not, say so plainly and use another case or say you have none | F6 |
| P-G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Scaffold: a named decision, a metric given up, the result. If none comes to mind, say so plainly | Standard Values stem |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-H1 | "What are you actually playing with in IoT or device fleets these days?" | CO | [generic] | Say only what's true. If nothing, say so and say what you'd explore first | F1 shows no domain evidence |
| P-H2 | "How do you like to work with product day to day?" | JD | [generic] | Describe how you want to work. Your material carries one product-adjacent sentence (P-E3); use no more than it says | F6 is thin; the PM's seat |

**Reverse questions (Thursday)**

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity for the peer seat |
| "What part of device management would you most like leadership to understand better?" | Invites them to teach you |
| "What was the most recent roadmap disagreement between product and engineering, and how did it resolve?" | Shows interest in how the partnership really works |
| "How are on-call and reliability work weighed against roadmap features here?" | Connects to your one story without claiming more |
| "What do you want from a manager that you haven't had?" | Makes the panel describe the job |

## Round 3: Monday, VP Engineering, 30 min

The recruiter's description names a values-style round. Larkfield's published values weren't retrieved, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Principles and leadership philosophy | High. The recruiter named the round | Map a story only where your material carries one |
| Case/Strategist | Altitude and strategy | Medium. Skip-level prior | Structure aloud |
| Pressure | Time-boxed composure test | Medium. Skip-level prior; 30 minutes forces compression | Pause, restate, hold through two follow-ups |
| Conversational | Rapport opener | Low | One honest reason |

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-J1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Three beats: what you believe (yours; the pack doesn't supply it), one example, where it costs you. The one example your material carries is "I pushed a reliability quarter through against roadmap pressure"; describe what you did and let them draw the inference. If no belief comes cleanly, say so plainly | F2 is your only story |
| V-J2 | "Which value would you refuse to trade for a deadline? If it has come up, tell me when." | VAL | [generic] | Name the value; a case only if one exists. If none, say so plainly and say how you'd hold it | The conditional lets an honest no be an answer |
| V-J3 | "How do you think about growing a strong engineer versus supporting a struggling one?" | VAL | [generic] | Your stance in your own words; it asks about no past. Offer no case unless one is true (F4) | F4 at leadership altitude |

**Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-K1 | "Where do you think the hardest trade-offs sit between squad delivery and the hardware roadmap?" | CASE | [generic] | Clarify what you'd need to know, then structure the trade-offs; if you lack the domain, say so and say how you'd find out | F5 at executive altitude |
| V-K2 | "What do you know about Larkfield, and where would you push us?" | CO | [generic] | Research was refused, so the pack holds no company facts. Bring three things you read yourself in Larkfield's public material, and one question. If you've read little, say so and say what you'd read first | A CO question the pack can't ground |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-L1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." and "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold on two things your message states: you run the backend hiring loop, and you pushed a reliability quarter through. Concede in the same breath what the third quote says. Make no claim about the internal candidate. Return to the two quotes through two follow-ups | F2 and F3 held; F5 conceded |
| V-L2 | "You've never managed managers. Why should I trust you with this scope?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." and "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Acknowledge first: "I've never managed managers." Then what you carry: "I've spent three of my nine years as a team lead of six." State the limit before it's pressed: the material shows no manager-of-managers work. Then the step as a plan. Concede only speed | The negative is yours; this tests whether you hold without defensiveness |

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V-M1 | "What draws you to engineering management?" | VAL | [generic] | One reason in your own words; the pack doesn't supply it. If none comes cleanly, say so plainly | Short-round opener |

**Reverse questions (Monday)**

| Question | Why it lands |
|---|---|
| "What do you look for in someone leading two squads here?" | Asks the VP to define the job |
| "What did the last person you promoted into leadership do that you want more of?" | Shows you think about growing leaders |
| "How do you want engineering to balance reliability against roadmap commitments?" | Connects to your one story |
| "What has changed in how engineering is led here over the last year?" | Asks for their account rather than assuming one |
| "What would make you say in a year that this hire was a mistake?" | Candor that invites the real criteria |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | T-B2, T-A1, T-A2, P-F3 |
| "own delivery" | T-A3, T-C1, T-C2, P-F1, V-J1 |
| "hiring" | T-C3, P-F2, T-D1 |
| "growth for 11 engineers" | T-B4, V-J3 |
| "partner with hardware and product on roadmap", hardware | T-B1, P-E1, V-K1, V-L2 |
| "partner with hardware and product on roadmap", product | P-E3, P-H2, T-A3 |
| "industrial IoT, ~600 people" (context) | P-H1, V-K2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, F5 | "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | "I've never owned a hardware-adjacent roadmap." Then a plan, not a past |
| Led two squads or 11 engineers | Inflated form of F1 | F1's quote at its own scope; your material says a team of six |
| Single-handedly cut on-call by 60% | Inflated form of F2 | F2's quote at its own scope; the sentence gives a sequence, not a mechanism |
| Decided who was hired | Inflated form of F3 | F3's quote: you run the loop, about 40 interviews |

## Sources

Provided: your message. No tuesday-dossier.md was present.

Searches sent, all refused:
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Would have moved a Monday values cheat sheet and VAL questions; refused |
| 2. Larkfield interview process | unavailable | Would have checked loop structure and persona weights beyond your schedule; refused |
| 3. Larkfield strategy and news | unavailable | Would have grounded V-K2 and the CO questions; refused |
| 4. Interviewer name and Larkfield | n/a | No name was given |
| 5. Representative Engineering Manager JD | skipped | Your role summary fixes the fit snapshot and JD-tagged questions |

## Upgrade menu

- Permission for web search → Larkfield's published values for a Monday cheat sheet, the documented loop, and a strategy brief that turns V-K2, P-H1 and the CO questions from `[generic]` to grounded. A deeper pass adds up to 6 further searches and 2 further fetches and takes several more minutes.
- Your CV → F1 to F4 and F6 draw on more than one message.
- The full JD text → fit rows quote the posting instead of a summary.
- The staff engineers' relationship to the squads → Thursday's weights and P-E1 retune.
- Interviewer names → an interviewer read, persona adjustments, and reverse questions tied to their paths.
- The recruiter's prep notes, including any announced deliverable → coverage of stated focus areas.
- Written answers to the slots in F1, F2, F4 and F6 → those rows and their bank cells upgrade on your own words.
- A tuesday-dossier.md from an earlier engagement, if you have one → verified evidence and prohibited claims arrive pre-graded.

Say the word and I'll play the Director on T-B1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, if file writes get approved.
If you'd like the pack as a Word document, say so and I'll convert it, once I can write files.

Are the two staff engineers on the squads you'd lead, or elsewhere? The answer reweights Thursday's whole bank.
Can you paste your CV and the full JD? I'll proceed without them if you'd rather not.
Can you allow web search, so I can research Larkfield's values and strategy?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.