Web research was denied, so I'm building the pack from your JD and background alone and labeling everything that would have needed research. Writing the file now.
I couldn't save the pack as a file because the write was declined, so the full pack is below. Web search was also refused, so it has no Atlas research and anything that needed it is generic. Your round type and interviewer are unknown, so I built it for a general conversation with flat persona weights.

# Interview pack: Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight (regional logistics, 800 employees)
- Interviewer and relationship: not known
- Round type: not known

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Every sentence it gives you as your own is one you already wrote. Where a detail is missing, it is marked as an answer slot for you to fill truthfully.

| Type | What it scores |
|---|---|
| VAL | Past behavior against published company values |
| EXP | Whether claims on your background survive scrutiny, and what was actually yours |
| JD | The stated responsibilities and qualifications, including the gaps |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem set in the role |

Provenance labels: `[grounded]` traces to your JD or your message. `[inferred]` is derived, with the derivation named. `[generic]` is a role-family pattern with no claim about Atlas or about you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations, not terminals and not a multi-site remit, and the words stay there: "I have seven years in warehouse and distribution operations, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's sites line makes a probe on the span of your remit likely. Say plainly how many sites your remit has covered, in your own words; if it has been one, say so and stay with that site |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | discovery | Your material says you ran the surge plan, not what it was measured on. Answer slot: if on-time or service measures were tracked during the plan, say which and how they were counted; if none were, or tracking was not yours, say so plainly and describe the plan you ran |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is an accuracy measure, not a cost measure, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if that work was ever expressed in cost terms, say how, in your own words; if no cost figure was tracked, say so plainly and say what you would track first, as a plan |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's team size makes a probe on scale likely. Say plainly the size of team you have led and describe how you lead it, in your own words |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel, never used Power BI" — your message | low | [inferred] | discovery | "Solid" is a self-assessment and doesn't show reporting built. Answer slot: if you have built reports or trackers in Excel, say which and who used them; if you mainly use it for your own analysis, or built none, say so plainly and describe what you do with it |
| F6 | "build reporting in Excel/Power BI" — JD | "solid Excel, never used Power BI" — your message | none | [grounded] | capability | The Power BI half is a gap you stated. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material gives seven years of operations and a current leadership role, and doesn't show how many of the seven were spent leading. Answer slot: say plainly how many of those years were in a role leading others and what the role was, in your own words; if it is fewer than the JD's number, say so |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but no certificate has been inspected, so expect a probe. Lead with it in your own terms: "I'm green belt certified." Say what the certification covered and don't stretch it. Your material doesn't link it to the pick-path work, so don't present one as the other |

## Persona table

No loop source was read, because the searches were refused and you don't know the round. The loop archetype is the generic fallback (screen, hiring manager, panel). That is a pattern, not Atlas's documented process, and weights are flat. No values-style round is detected, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the scale and tooling gaps | Even weight. Depth tilts here (four questions) because this bank carries the thinnest rows: F1, F4, F6, F7 | Rehearse the most predictable objection until it's boring; bridge only from what you stated and say the limit plainly |
| B. Data-Driven Prober | Reads your background line by line and asks how each number was counted | Even weight. You have one headline figure and the JD names two measures | Know what you can and can't say about how the 40% was counted; name the assumption you'd defend least before they do |
| C. Case / Strategist | Live operations problems on on-time and cost | Even weight. Round type unknown; the JD is measure-driven | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| D. Pressure | Interrupts, time-boxes, questions attribution | Even weight. The scale gap invites it | Pause, restate, anchor on what you stated, hold through two follow-ups before conceding anything real |
| E. Peer Evaluator | Seams between sites and teams, credit, disagreement | Even weight. Four sites implies side-by-side managers | Reciprocity: what you bring them; propose seam principles without pretending to know the seam |
| F. Values / Behavioral | Scenario probes, story-shaped answers | Even weight. No published values were read, so these use the JD and standard stems | Choose stories where the hard truth landed; where your material shows none, say so |
| G. Conversational | Friendly, unstructured, still scored | Even weight. Openers like this are common to first conversations | Pre-script the 90-second arc; treat casual questions about JD topics as scored |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI"; "currently a senior shift manager over 3 supervisors" | Name your weakest part before they do, from the rows where your material is thinnest. If it's Power BI: "I have never used Power BI." Then give a plan, not a past: what you'd learn first and how. If it's team size, anchor on "I'm currently a senior shift manager over 3 supervisors" and use F4's slot | F4 and F6 are the largest named gaps; JD because it scores stated requirements |
| A2 | "This role owns daily terminal operations across 4 sites. How does your background get you there?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | **Highest-ROI rehearsal in the pack.** The hold is only what the quotes carry: "I have seven years in warehouse and distribution operations, I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Follow-up one will likely probe how terminals differ from what you've run. Answer slot: if you have worked in terminal operations, say where; if not, say so plainly and say what you'd learn first, as a plan. Follow-up two will probe scale: use F1's and F4's slots. Hold through both by returning to the quotes, never by adding to them | F1 is where the mandate presses hardest on the material; JD because it scores the headline responsibility |
| A3 | "Why this role, and why now?" | JD | [generic] | Selection scaffold: name a pull toward regional logistics operations and a reason for the timing, both in your own words. The pack has no Atlas research, so make no claim about the company you can't source yourself. If no specific reason comes to mind, say so and give the honest one | Motivation consistency is the Skeptic's standing probe |
| A4 | "Reporting here is built in Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Say it first and plainly: "I'm solid in Excel, and I have never used Power BI." Don't stretch Excel to cover Power BI. Then a plan: what you'd do before day one and in the first month. Don't say you've started unless you have | F6 is a stated gap and a near-certain question |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F3: the cut, the 40%, and the pick-path redesign, which are the beats the quote states; tell them in your own words. Answer slot: how the figure was counted, what it's sensitive to, and the assumption behind it you'd defend least. Name that assumption before they do. If you don't know how it was counted, say so plainly | F3 holds the only headline figure; probers target those |
| B2 | "This role is measured on cost-per-shipment. What have you tracked on cost?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start from the quote at its own scope. Answer slot: if that work was ever expressed in cost terms, say how, in your own words; if no cost figure was tracked, or it wasn't yours, say so plainly and say what you'd track first, as a plan | F3 is adjacent to the cost requirement and doesn't reach it; the premise is the JD's |
| B3 | "On-time performance is a core measure here. What did you track during your peak-season surge plan?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Start from "I ran the site's peak-season surge plan two years running." Answer slot: if on-time or service measures were tracked, say which and how they were counted; if none were, or tracking wasn't yours, say so plainly and describe the plan you ran | F2 is the evidence nearest the on-time requirement |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one of the four sites drops sharply over two weeks. What do you need to know first?" | CASE | [generic] | Clarify (what changed, which lanes, which shifts), objective, segmentation, approach, metrics, risks. Think aloud; challenge one premise respectfully. No claim about your past | Live problem from the JD's on-time line |
| C2 | "Cost-per-shipment is rising across the network while volume is flat. Where do you look first?" | CASE | [generic] | Same structure. Segment before you diagnose and say which data you'd pull. No claim about your past | Live problem from the JD's cost line |
| C3 | "Peak volume arrives and two of the four sites are short of supervisors. Walk me through your first 48 hours." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: what you'd establish, who you'd ask, what you'd protect. You may reach for your surge plan; describe only what you did, in your own words, and if the plan didn't involve moving staff, don't borrow it here | Multi-site problem on the JD's sites and supervisors lines |
| C4 | "What do you know about us, and what do you think our biggest operational challenge is?" | CO | [generic] | The pack couldn't research Atlas, so it supplies no facts about the company. Do your own homework from their careers page, news and customer-facing material. Answer with hypotheses labeled as hypotheses and end with a question back to them | A free miss if unprepared; generic because research was refused |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold on the quote as stated. Answer slot: say which parts were yours and which were shared, in your own words; if the redesign wasn't yours alone, say so plainly. Hold through two follow-ups, concede specifically what you don't know, and don't fold on what you stated | F3 is the figure an attribution probe targets |
| D2 | "Sixty seconds: why you over a candidate who already runs terminals?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Don't argue the comparison. State the facts in the quotes' own terms: "I ran the site's peak-season surge plan two years running. I cut mis-pick rate 40% by redesigning the pick path. I'm green belt certified." Stop and let the interviewer draw the inference; one you assert yourself is the one that gets tested | F1 is the gap this probes |
| D3 | "You're asking us to bet a four-site operation on someone who's currently over 3 supervisors. Convince me." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause and restate. Anchor: "I'm currently a senior shift manager over 3 supervisors." The difference from the JD's team size is the open question, and conceding that is honest. Answer slot: how you lead the team you have, in your own words. Hold through two follow-ups by returning to the quote | F4 is the plainest scale gap |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our sites run side by side. Where is the seam between us, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you can't know, and ask which handoffs cause friction today. Disagreement: pick a story with a named stake, a position held with tact, and an intact relationship; if none comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | The JD's four sites make site-to-site seams the peer's natural probe |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time work crossed teams, with who did what named exactly. "We" for context, "I" for your own contribution. If none comes to mind, say so plainly and say how you'd handle it | Credit-sharing is the Peer Evaluator's standing probe |
| E3 | "What would you need from the other site managers in your first month?" | JD | [generic] | Reciprocity: say what you'd ask for and what you'd bring in return. Don't name things you've brought before that your material doesn't state | Tests partnership fit |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a story with a named stake, a moment you didn't soften it, and a stated outcome where the hard truth actually landed. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you'd handle it | Standard values stem; generic because no Atlas values were read |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a story with a named customer need, the internal metric it cost, and the decision as yours. If none comes to mind, say so plainly and say how you'd weigh it | Standard values stem on service orientation |
| F3 | "Tell me about a time you needed your supervisors to deliver under pressure." | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Story-mapped on the surge plan, with the beats its quote states: you ran it, two years running. Answer slot: if supervisors carried part of the plan, say what you asked of them and what happened; if the plan didn't depend on them, say so plainly and stay with the plan | The JD's supervisors line raises this |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc from what you stated: seven years in warehouse and distribution operations, now a senior shift manager over 3 supervisors. Add dates and roles from memory; the pack has none. Answer slot: the JD's 5+ years line makes a probe on how many of your years were spent leading likely; say plainly how many, in your own words. End with why this role, in your own words | The biography question is always asked; F7 is the row it settles |
| G2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Start: "I'm green belt certified." Answer slot: if you're applying it now, say where and how; if not currently, say so plainly and say what you'd apply first, as a plan. Don't describe the pick-path work as a certified project unless it was | F8 is the plus the JD names |
| G3 | "What do you do with Excel day to day?" | JD | [grounded] "solid Excel, never used Power BI" | Start: "I'm solid in Excel." Answer slot: say which reports or trackers you build and who uses them, in your own words; if you mainly use it for your own analysis, say so plainly and describe that | F5 is a self-assessment a casual question will test |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A2, C1, C3, D2 |
| "drive on-time performance" | B3, C1 |
| "cost-per-shipment down" | B2, C2 |
| "lead a team of 12 supervisors" | A1, D3, F3 |
| "build reporting in Excel/Power BI" | A4, G3 |
| "5+ years operations leadership required" | G1 |
| "Lean/Six Sigma a plus" | G2, D2 |
| Company context (regional logistics, 800 employees) | C4, A3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and where is each site against it today?" | Shows you think in the JD's measure and gets you the real baseline |
| R2 | "What does the reporting stack look like today, and who owns the Power BI models?" | Surfaces the tooling honestly and frames your ramp as a plan |
| R3 | "Where do the supervisors most need support in the first 90 days?" | Signals you lead from the team's needs |
| R4 | "What is the biggest driver of cost-per-shipment right now?" | A concrete operational question the JD invites |
| R5 | "What would make the first six months a clear success, and what would a miss look like?" | Makes the scoring criteria explicit |
| R6 | "What does the rest of the process look like from here?" | Practical, and tells you which personas later rounds weight |
| R7 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question, for a peer interviewer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran operations across multiple terminals or sites | Inflated form of F1 | F1's quotes at their own scope. The material says warehouse and distribution operations, not terminals or a multi-site remit. A2's slot stays inside the span of your remit |
| Led a team of the JD's size | Inflated form of F4 | F4's quote at its own scope: 3 supervisors. D3's slot asks only how you lead the team you have |
| Cut cost per shipment or improved on-time performance through the pick-path redesign or the surge plan | Inflated form of F2 and F3 | F2's and F3's quotes at their own scope. B2 and B3 slots ask only what was tracked |
| Has Power BI experience, or familiarity by way of Excel | Negative you stated, F6 | The plain acknowledgment F6 gives: "I have never used Power BI." Then a plan, not a past |
| The pick-path redesign was a certified Lean or Six Sigma project | Inflated form joining F3 and F8 | Each quote separately, at its own scope; the material doesn't link them |
| 5+ years of operations leadership | Inflated form of F7 | F7's quotes at their own scope. G1's slot asks how many years were spent leading |

## Sources

Provided documents: the job description you pasted, and your background as described in your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight` values | unavailable | Every call was refused. Would have fed a values cheat sheet and VAL questions on named values |
| 2. `Atlas Freight` interview process, operations manager | unavailable | Every call was refused. Would have fed loop structure and persona weights |
| 3. `Atlas Freight` strategy / recent news | unavailable | Every call was refused. Would have grounded the CO and CASE questions |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: `Atlas Freight regional logistics company values`; `Atlas Freight interview process operations manager`; `Atlas Freight regional logistics strategy news`.

## Upgrade menu

- Permission to search the web → a values cheat sheet, Atlas's documented loop, and CO and CASE questions grounded in its current strategy in place of the generic ones
- The interviewer's name and role, from the invitation or your recruiter → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The round format and any focus areas the recruiter mentions → persona weights in place of the flat fallback, and coverage of any announced deliverable
- Your CV → evidence cells quoted from it, with dates and roles for G1 and F7
- Your green belt certificate → F8 moves from `medium` to `high`
- Your answers to the slots in F1 to F7 and in the banks, in your own words → those rows become story-mapped answers
- A tuesday-dossier.md from an earlier assessment of this role → verified evidence and a sourced prohibited-claims list in place of the locally built one

Say the word and I'll play the Skeptic on A2, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you grant file access I'll save the pack as markdown, and I can make a Word version if you'd like one.

Does the invitation or your recruiter say who you're meeting or what format to expect? Either answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.