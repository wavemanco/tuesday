Research is back (4 of 6 searches used). I'm now fetching the official values page and the interviewing page, so the pack uses their exact wording.
I have everything the pack needs, so I'm writing it to the working directory now.
The write to the working directory wasn't permitted. I'm saving the pack to the session scratchpad instead, which doesn't need a permission prompt.
Femi, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-canned-098966a5/b7fed146-9aba-4d03-a302-4a41b3f1df01/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. The write to the project folder wasn't permitted, so it went to the session scratchpad.

I built it for the Outage Hour that Saltmarsh's interviewing page describes. That is a 60-minute hiring-manager interview: a live-incident tabletop on a simulated outage, then a values conversation. I assumed Tobias is your hiring manager. The Project Larkspur announcement and Tobias's GDC talk were read as search summaries only, because I ran out of page fetches. Check both yourself before Friday.

Say the word and I'll play the Skeptic on C1, the season-pass question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did your recruiter say anything about what Friday will cover? The answer reweights the persona table and the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager.
**Session:** one 60-minute interview on Friday. Built for the Outage Hour that Saltmarsh's interviewing page describes: a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home (Sources, target 2).

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims in your background survive scrutiny, and what was actually yours |
| JD | The stated responsibilities and requirements, including where your material is thin |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role, answered by structuring it aloud |

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe, then gives two honest branches. The second branch always allows that the thing never happened, or was not yours.

**Highest-ROI prep: question C1.** It will be asked in some form, and a calm, rehearsed answer changes the interview. If you only rehearse one thing, rehearse that.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles lines make a probe on events and on a second title likely. If any drop was a timed event, say which and how it was run, in your own words; if they were content releases only, or there was one title, say so plainly and stay with the weekly calendar you ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | The calendar quote does not show which of the four teams you worked with, and the second quote is a limit about leading, a different verb from the JD's coordinate. Answer slot: the JD names four teams, so expect a probe on which you worked with on an update. Say which and what you did with each, in your own words; if you never worked with one of them, or that went through someone else, say so plainly and stay with the calendar you ran. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, not that you owned a post-event review or chose the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe on who produced the numbers and who chose what was reported likely. If either was yours, say which and how you decided, in your own words; if the numbers came from someone else, or no review step existed, say so plainly and stay with the monthly presentations. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | Lead with it in the quote's own terms: you wrote the checklist and the QA team still uses it. The quote says wrote, not that you ran it release by release, so keep the words at that scope and expect a probe on it. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The quotes show four years as an associate producer and two years on the calendar, and they do not say the game was run as a live service, so your material does not establish the 3+ years line. Answer slot: if the main title was run as a live service, say what that meant day to day, in your own words; if it was not, say so plainly and stay with the years and the calendar you ran. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in the quote's own terms: a weekly calendar, your main title, two years. Lead with those words, because a named cadence beats an adjective. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message; "never worked on a game with in-app purchases" — your message | medium | [grounded] | none | The first quote reaches the requirement: you presented the monthly retention numbers to the studio head. The second quote bounds the setting those numbers come from, so keep the claim at presenting scope and expect a probe on how the numbers were counted. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist the QA team still uses is a written artifact, and the quote shows no other writing. Answer slot: the JD names clear written communication, so expect a probe on your writing. If any other writing of yours was used by others, say what it was, in your own words; if not, say so plainly and stay with the checklist. |

## 3. Reading the interviewer

Public professional footprint only. Both facts below come from search summaries, not full pages (Sources, target 4).

| Fact | Provenance | What it means for Friday |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] Sources, target 4 | Expect the checklist story (F4) to be read closely. Lead with it in the quote's own terms and do not stretch it. |
| Gave a GDC 2026 talk, "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes describe what actually shipped | [grounded] Sources, target 4 | The same idea as the published value Ship the Patch Not the Promise. Keep every answer precise about what was built and what was only planned. |

Mirror opportunity: the shared ground is the QA-facing artifact. Your side of it is one sentence, "Wrote the release checklist our QA team still uses" (F4). It is shared vocabulary, not a shared career path, so do not present it as one.

## 4. Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The live-incident tabletop on a simulated outage | Highest. The interviewing page names the tabletop as half the hour (target 2), and the hiring-manager prior also favours this persona | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Values/Behavioral | The values conversation after the tabletop | Highest. The interviewing page documents it, and Saltmarsh publishes three values by name (targets 1 and 2) | Map a story to each value where one of your quoted sentences carries one. Where none does, pick an instance honestly, or say plainly that none comes to mind |
| Skeptic | Probing the limits you stated and the move to a season pass | Medium. Hiring-manager prior, plus the announced season-pass move (target 3) against the limits in F2 and F7 | Rehearse C1 until it is boring. Name the limit first, say what your material carries at its own scope, then give a plan |
| Data-Driven Prober | Retention numbers and the checklist | Medium. The interviewer read points to precision about what shipped, and F3, F4 and F7 are all specific claims | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Pressure/Stress | Time-boxed or interrupted moments inside the tabletop | Medium, and inferred: the careers page does not say the tabletop is pressured, but incident drills often are | Pause, restate, anchor in what you stated, hold a position through two follow-ups before conceding anything real |
| Conversational | The opening and any casual written exercise | Low to medium. The recruiter call is a separate step (target 2), but an opener is likely | Prepare a 90-second arc from your own quoted sentences and treat casual questions as scored |
| Peer Evaluator | Not included | No peer session is documented in the loop. If your schedule adds a team session, send it and I will add a bank | Not applicable |

## 5. Question banks

### A. Case/Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The event store is down forty minutes into a weekend event and players are filling chat. Walk me through your first ten minutes." | CASE | [generic] | Think aloud in order. What you need to know first: what is down, for whom, since when, who is already on it. The objective: protect players, which the published value Players Before Plans puts first. Then who you tell and when, what you decide and what you leave to engineering, and what you will watch. Say what the first update would contain and when the next one comes. Challenge one premise respectfully, such as whether the event keeps running while you diagnose. The question asks about no past, so the guidance makes none. | The likeliest opener, because the tabletop is half the hour (Sources, target 2). CASE because it scores structure under time, and [generic] because the scenario is a pattern, not their incident. |
| A2 | "The outage took six hours of a forty-eight-hour event, and another event is queued behind it. Players want to be made whole. What do you decide, and what do you need to know first?" | CASE | [grounded] | Clarify first: what players lost, what the queued event needs from the same teams, who owns the call on compensation. State the principle in the published words before you answer: when the calendar and the players disagree, the players win. Then lay out options such as extending the event, compensating players, or delaying the queued event. Give the cost of each to design, engineering and community, recommend one as a proposal, and say what you would not decide alone. No claim about your past. | A direct test of the first published value on a calendar tradeoff. CASE because the answer is a decision under constraints. |
| A3 | "QA has two items still open on the checklist, the fix is ready, and the event is bleeding. Ship or wait?" | JD | [grounded] | Ask what the two items are and what each one protects. Name the options, including a narrower release. Say who decides and what you tell QA and players. Hold the published line that you announce what is built, not what is hoped. Pick a side, and name the condition that would flip it. The checklist is a tool for the decision, not the decision. No claim about your past. | JD content, since the JD asks you to manage the release checklist with QA, with CASE delivery. It also tests two published values at once. |
| A4 | "Two titles each have an event starting the same Friday, and community can support only one launch. How do you sequence them?" | JD | [grounded] | Clarify what each event needs from design, art, engineering and community, which launch is hardest to move, and what players of each title were told. Objective: the least harm to players. Then the options, who you consult, who decides, and how you make the tradeoff visible to the four teams. Close with the metrics and risks you would watch. No claim about your past. | JD content, since the JD asks you to coordinate four teams across two titles, with CASE delivery. |
| A5 | "Two of our titles move to a season-pass model with one shared events calendar from January. What would you want the first season's calendar to protect, and what do you need to know before you build it?" | CO | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Use their vocabulary: season pass, shared calendar, single live-ops group. Read the full announcement before Friday, because this pack saw only its summary. Clarify before you structure: what the pass promises players and when, how a shared calendar changes the event load per title, who owns the pass design. Protect the principle that what is announced is what is built. Then say where your experience stops, in your own words: "I haven't worked on a game with in-app purchases." What your material does carry is the calendar: "I ran the weekly content-drop calendar for our main title for the last two years." Offer no opinion on pass pricing or rewards as if you had run one. | The differentiator question, built on the one current-strategy item research found. F7 holds the limit and F1 the nearest evidence. CO because it tests homework at the company's altitude. |

### B. Values/Behavioral (the values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players pulled in different directions. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | A selection scaffold, because the quote carries the calendar but no such moment. Pick a time a scheduled drop met a player problem; it needs the stake, the decision, who was in the room and what players got. Say "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it. Do not supply an ending. | The first published value is about exactly this tradeoff, and the values conversation is documented. F1 is the nearest evidence. VAL because it scores behavior against a published value. |
| B2 | "Tell me about a time you held back an announcement because the work was not finished." | VAL | [grounded] | A selection scaffold. Pick a time something was ready to be said before it was ready to ship; it needs what was about to be said, who wanted it said, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use the value's own test: you announce what is built, not what is hoped. | Ship the Patch Not the Promise is the likeliest value to be probed, given the interviewer read. VAL, with the theme taken from the published value. |
| B3 | "Tell me about a time you changed a checklist or a process so the next release went more smoothly." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4. The beats the quote states are that you wrote the checklist and that QA still uses it; tell those in your own words. Answer slot: the third published value says every release leaves the checklist better than it found it, so expect a probe on whether it changed after you wrote it. If you revised it after a release, say what and why; if it stayed as written, or QA owns changes now, say so plainly and stay with having written it. Do not describe a problem the checklist solved unless you tell it yourself. | The strongest quote in the material meets the third value. VAL because it scores a behavior against a published value. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | A selection scaffold. Pick a time a number you presented was not the one the room wanted; it needs the figure, the reaction and what happened next. The quote carries the monthly presentations only: "I presented the monthly retention numbers to the studio head." If no such time comes to mind, say so plainly, then give that nearest thing, or how you would handle a bad month. | A standard values-round question, with F7 as the nearest evidence. VAL because the hard truth has to land. |
| B5 | "What does Players Before Plans mean for how you would build a calendar?" | VAL | [grounded] | Start from the published definition in its own words: when the calendar and the players disagree, the players win. Then say what that implies as a design choice you would propose: what you keep flexible, who can move a date, how players hear about a change. It is a plan, not a past, so claim nothing about a calendar you ran. | A values conversation can quiz the value by name. VAL because it tests whether you can turn a value into a working rule. |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two of our titles move to a season pass in January, and I don't see in-app purchases in your background. How would you handle the money side of running that calendar?" | CO | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The highest-ROI prep in this pack. Name the limit first, in words your own sentence carries: "I haven't worked on a game with in-app purchases." Then say what your material does carry, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head." Then give a plan, said as a plan: what you would ask whoever owns the pass design in week one, such as what players are promised and when, and which numbers the post-event review must report. Follow-up one asks what you would do on day one: answer with the first step of that plan. Follow-up two says you would be learning on their time: concede that specifically, yes on the pass mechanics, and say what you bring at quoted scope. Follow-up three asks what you would leave alone until you understood it: answer as a plan, in your own words. Never imply you have worked on purchases or revenue numbers, and never assert what the pass should contain. | The likeliest objection to this candidate. F7 holds the limit you stated, and the announced season-pass move aims it at the job. CO because it tests company-strategy fluency, delivered in the Skeptic's register. |
| C2 | "You ran the weekly content-drop calendar for your main title. What changes when it is timed events across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what it was in the quote's words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles lines are the probe. If any drop was a timed event, say which and how it was run, in your own words; if they were content releases only, or there was one title, say so plainly and stay with the weekly calendar. Then say what changes as a plan, not a past: overlap between titles, shared teams, event end times. Hold through two follow-ups by returning to what you ran, never by widening it. | F1 is the gap between what you ran and what the JD names. JD because it scores the stated responsibility, including where the material is thin. |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team"; "never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | Pick one in your own words, and pick the truest. Your material shows two limits you stated: "I haven't led a team" and "I haven't worked on a game with in-app purchases." The JD lines you gave say coordinate, not manage, so the first may not be the weakest. F3 is also thin: the quote says "I presented the monthly retention numbers to the studio head", and the JD says own. Whichever you choose, say it plainly, give the first step you would take in week one as a plan, and do not fold on what you did do. | A persona stem every hiring manager has available, and the honest answer is the one that survives follow-ups. F2, F3 and F7 are the rows it draws on. JD because it scores the stated requirements. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you did in the quote's words: "I presented the monthly retention numbers to the studio head." Then the defend-the-number slots, each in your own words: how the numbers were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how they were counted, say so plainly; if you presented numbers someone else produced, say that and stay with the presenting. | F7 is the likeliest place a prober digs. EXP because it tests attribution and what the number rests on. |
| D2 | "Walk me through the release checklist you wrote. What is on it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say it at the quote's scope: "I wrote the release checklist our QA team still uses." Describe what is on it from memory, in your own words; this pack does not supply its items. Answer slot: the JD's QA line and the third published value make a probe on who maintains it likely. If you maintained or revised it, say how; if QA owns it now, or it never changed, say so plainly and stay with having written it. | F4 is the strongest quote in the material, which makes it the one most likely to be tested; the interviewer read (section 3) says why. EXP because it checks you know your own artifact. |
| D3 | "A two-week event ran in one title. Retention dipped in that title and held in the other. Walk me through the post-event review." | JD | [grounded] | Clarify first: which retention measure the team uses and over what window, the baseline, what else changed in those two weeks, and which players moved. Then what you would report, to whom, and what you would recommend next. A review ends in a decision, not a description. Say what you would want to know before claiming the event caused the dip. Use the terms you actually used; where unsure of a term, ask what the team means. No claim about your past. | JD content, since the JD asks you to own the post-event review and the KPIs it reports, with CASE delivery. It checks comfort with retention numbers without presupposing your history. |

### E. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "never worked on a game with in-app purchases" | Pause, restate the question, and anchor in what you stated: "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses." Make no comparison to anyone, since you do not know the internal candidate. Hold through two follow-ups by returning to those three. If pressed on what is missing, concede it specifically: "I haven't worked on a game with in-app purchases." | A time-boxed motive test. F5 holds the years and F4 and F6 the strongest quotes. JD because it scores fit to the role as stated. |
| E2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold only what the quote carries: "I wrote the release checklist our QA team still uses." Answer slot: if others added items or reviewed it, say who and what; if it was yours alone, or the contributions were not tracked, say so plainly. Hold through two follow-ups by returning to what you wrote, never by adding. Concede the exact limit of your part without folding on the core claim. | Attribution probes exist to catch inflation, and F4 is the claim most worth defending precisely. EXP because it tests what was actually yours. |
| E3 | "Your update said one hour. It has been three. An executive asks why you promised it. What do you say?" | CASE | [grounded] | Concede specifically and do not fold: what was said, what was known when you said it, what you know now. Then commit to something you can keep: a time for the next update, and only what is built. Separate the apology from the explanation, do not blame another team, and do not invent a reason. It is a hypothetical, so the guidance makes no claim about your past. | Pressure delivered through the second published value, which is the likeliest place a tabletop turns on you. CASE because it asks about no past. |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get from a puzzle studio to wanting this?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc whose beats are your own quoted sentences: "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head." Then why this role. Answer slot: say what draws you, in your own words; this pack cannot supply your motive. If you cite something Saltmarsh publishes, cite only what is true for you. Treat this as scored. | A friendly opener is still scored, and the arc needs to be ready before Friday. F1, F3, F4 and F5 are the rows it uses. EXP because it checks the story is consistent. |
| F2 | "Quick one: an outage note goes to players in ten minutes. What are the first two lines?" | JD | [grounded] | Draft it aloud. One plain sentence on what happened, what players can do now, and when the next update comes, a time you can keep. Promise only what is built, in line with the second published value. Skip apology filler and anything hoped. No claim about your past. | JD content, since the JD asks for clear written communication, in a casual register that is still scored. It also tests the second published value. |

## 6. Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4, A5, C2 |
| "coordinate design, art, engineering and community teams on each update" | A4, A2 |
| "own the post-event review and the KPIs it reports" | D3 |
| "manage the release checklist with QA" | A3, B3, D2 |
| "3+ years producing live-service games or apps" | E1, C3 |
| "experience running a content calendar" | C2 |
| "comfortable with player-retention metrics" | D3, D1 |
| "clear written communication" | F2 |

## 7. Values cheat sheet

Values are named exactly as Saltmarsh publishes them (Sources, target 1).

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players conflict, the calendar yields | Selection scaffold, B1: pick a time a scheduled drop met a player problem, with the stake, the decision and what players got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announcements describe what already exists, not what is intended | Selection scaffold, B2: pick a time something was ready to be said before it was ready to ship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Each release should leave the code and the checklist in better shape | F4: "Wrote the release checklist our QA team still uses", told at that scope, with B3's answer slot on whether it changed after you wrote it |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You moved from QA lead into running live operations. What did QA instincts change about how you run an event day?" | Tied to his public path, and it invites a story instead of a pitch. It also sets up the checklist ground you share. |
| 2 | "Project Larkspur retires per-title event teams for a single live-ops group. Where does this role sit in that, and which two titles would the calendar cover?" | It shows you read the announcement, and it resolves how the JD's two titles fit a shared calendar. |
| 3 | "What does a good post-event review look like to you, and who reads it?" | It tells you whether own-the-review means defining the KPIs or reporting them, which is the thin spot in F3. |
| 4 | "How will the season pass change which events the calendar has to carry from January, and who decides?" | It turns the biggest unknown into a conversation, and it shows you are thinking about the calendar, not only the pass. |
| 5 | "Looking at what we covered today, what would you have wanted me to go deeper on?" | It asks for calibration while he is still in the room, and a rapport-style close is weighted heavily as a preparation signal. |

## 9. Prohibited claims

This pack will not coach these. The honest form for each is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Planned and ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for your main title. C2's slot stays inside the calendar |
| Owned post-event reviews or chose the KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says presented the monthly retention numbers. D1's slot asks only how those numbers were counted |
| Managed or ran the release checklist release by release | Inflated form of F4 | F4's quote at its own scope: wrote it, and QA still uses it. D2 and E2 stay inside the writing |
| Three or more years of live-service production | Inflated form of F5 | The quotes at their own scope: four years as an associate producer, two on the calendar. The limit is the pack's observation: live-service is not stated |
| Led a team or managed people | Negative the candidate stated, F2 | The plain acknowledgment: "I haven't led a team." No slot, and any plan is said as a plan |
| Worked on a game with in-app purchases | Negative the candidate stated, F7 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot, and any plan is said as a plan |

## 10. Sources

Provided documents: the job description you pasted, and your message describing your background. No `tuesday-dossier.md` was present, so nothing was consumed from one.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | What came back |
|---|---|
| Search: "Saltmarsh Games values" | https://saltmarshgames.com/values |
| Search: "Saltmarsh Games interview process live operations producer" | https://saltmarshgames.com/careers/interviewing |
| Search: "Saltmarsh Games strategy news" | https://saltmarshgames.com/news/project-larkspur |
| Search: "Tobias Wrenfield Saltmarsh Games" | https://talks.gdconf.example/2026/patch-notes-are-a-promise |
| Fetch: https://saltmarshgames.com/values | Read in full: three values by name, each with a one-line definition |
| Fetch: https://saltmarshgames.com/careers/interviewing | Read in full: recruiter call, then the Outage Hour, a 60-minute hiring-manager interview with a live-incident tabletop and a values conversation; no take-home |

Pages not fetched: the Project Larkspur announcement (August 2026) and the talk page were read as search summaries only, because the fetch budget went on the values and interviewing pages.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet (section 7), the VAL bank and B5 |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop structure: the Outage Hour sets the persona weights, bank A and a detected values-style round |
| 3. Saltmarsh Games strategy or recent news | yes | A5, C1 and reverse questions 2 and 4, from the Project Larkspur summary |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read (section 3) and reverse question 1, from the talk summary |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- Hours available before Friday → a prep triage schedule: the few questions to rehearse first, in order, with everything else marked as insurance
- Anything your recruiter said about what the Outage Hour covers → coverage assumed from the published format becomes confirmed, and any announced exercise gets its own build section
- Confirmation of Tobias's role in your reporting line → persona weights stay as built if he is the hiring manager, and reweight if he is a skip-level or a peer
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the full Project Larkspur post and Tobias's talk read in full, so A5, C1 and the interviewer read rest on full pages instead of summaries
- Your CV text → evidence cells sourced from your CV instead of your message, and any figures on it raise defend-the-number questions
- A redacted calendar page or the checklist itself → F4 and F6 can move from medium toward high
- Your answers to the slots in F1, F2, F3, F5 and F8 → those discovery and transferability rows become grounded, and the bridge language gets your own words
- A dossier from an earlier role evaluation would add a verified-evidence list and a prohibited-claims list; this pack is complete without one
