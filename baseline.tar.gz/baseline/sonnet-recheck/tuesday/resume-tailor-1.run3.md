I've run the resume-tailor pass: your CV text against the Tessellate JD, as an approve-first edit ledger. I built it from the text you pasted, which I'm treating as self-report. I haven't seen the CV's layout or any lines beyond what you pasted, so the ledger proposes no cuts. Every row is pending your approval and nothing has been applied.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no summary line in what you pasted)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." (kept as two sentences) | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV text | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to the first bullet under your current role)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV text | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV text | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Two lines: "On-call rotation every fourth week for two years." and "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV text | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged — moved to the fourth bullet; not retitled as "mentoring")* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV text | pending your approval |
| E6 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | Same tools, with the languages first and the rest in this order: Go, Rust, Python, gRPC, Kafka, Postgres, Datadog, Terraform | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV text | pending your approval |

The split in E4 gives incident command its own line. Your sentence doesn't say what period the six incidents cover, so the new line doesn't either.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years backend | must-have | `surfaced_by_edit` | E1. Your "7 years" isn't stated as backend-specific, so E1 keeps it exactly as you wrote it. | `[grounded]` what the CV says |
| M2 | Production Go | must-have | `surfaced_by_edit` | E1 and E2. "Go … daily for 4 years" is on the page. That the three services are written in Go is not (see C1). | `[grounded]` what the CV says |
| M3 | Distributed systems at scale | must-have | `not_evidenced` | Nothing on the page describes the services as distributed, and Kafka is listed, not described. See C2. | `[grounded]` what the CV says |
| M4 | Strong incident response | must-have | `surfaced_by_edit` | E4 | `[grounded]` what the CV says |
| M5 | Experience mentoring | must-have | `surfaced_by_edit` | E5. Your sentence is about onboarding new hires, and the hires' seniority isn't stated. | `[grounded]` what the CV says |
| M6 | Design and ship high-volume services | important | `surfaced_by_edit` | E2 carries "own" and the request volume. "Designed" and "shipped" aren't in your sentence, so they aren't claimed. | `[grounded]` what the CV says |
| M7 | Drive down p99 latency | important | `already_evidenced` | E3 moves it earlier. | `[grounded]` what the CV says |
| M8 | Own on-call | important | `already_evidenced` | E4 gives it its own line. | `[grounded]` what the CV says |
| M9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing on the page touches this. See C3. | `[grounded]` what the CV says |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go (M2) | must-have | Go daily for 4 years, and three owned services. It doesn't say what language the services are in. | The JD's first technical requirement is production Go, and the page currently leaves the link between your Go and your services to the reader. | The three ledger services being written in Go; the cache-layer rework being Go code; Go services you deployed and ran on-call for | A repo link, design doc or service README showing the language | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Distributed systems at scale (M3) | must-have | A 40k requests/minute service in a ledger pipeline, with Kafka in the tools list. Nothing says how the services interact. | A must-have with no supporting sentence is the gap a reader is most likely to notice. | Services in your pipeline communicating over Kafka or gRPC; retry, ordering or idempotency decisions; a failure that crossed service boundaries | An architecture diagram, a postmortem, or a design doc for the pipeline | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Partner with product on roadmap sequencing (M9) | important | No product-facing work is mentioned. | The role lists roadmap sequencing as a duty, and your page gives nothing to weigh it against. | Deciding with a PM which ledger-pipeline work came first; trading reliability work against feature work; scoping the cache rework with a product owner | A planning doc, roadmap thread or ticket history showing a sequencing decision | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Not written, and why

- **"Senior Backend Engineer" as your title.** You hold "Senior Software Engineer", and "backend" is the posting's word.
- **"Go services" for the three you own.** Your sentence names the services but not their language.
- **"Distributed systems" or "at scale".** Neither phrase is in your sentences, and a tool listed is not a tool owned.
- **"Mentored mid-level engineers".** You onboarded new hires, and their level is unstated.
- **"Designed and shipped".** You wrote "own".
- **"Partnered with product on the roadmap".** Nothing you wrote supports it.
- **"Led incident response across the org".** You wrote "run six incidents as incident commander", so the scope stays that.

## Parse-safety check

Your CV arrived as pasted text, so I could not run any of these: multi-column layout, tables and text boxes, images or skill bars, content in headers or footers, section headings, file type. Send the file and I'll report what I can observe.

## Upgrade menu

- **The CV as a file.** This unlocks the parse-safety checks, a hidden-text check, and a search for buried lines or cut candidates.
- **A design doc, postmortem or p99 dashboard** for the cache rework or one of the incidents. This could raise those rows from user-stated to inspectable.
- **Prior CV versions.** These sometimes hold evidence the current one dropped, which could close C2 or C3.

## Questions

C1 — Are the three ledger services written in Go, and are they the Go you use daily?
C2 — How do the services in your pipeline communicate (Kafka, gRPC, something else), and have you handled a failure that crossed service boundaries?
C3 — Have you worked with product or a PM on what to build or fix first, and what was the decision?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.