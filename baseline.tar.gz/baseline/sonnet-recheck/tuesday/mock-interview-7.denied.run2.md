Let me read the files directly instead.
I couldn't save the pack as a file because the write permission was declined, so the full pack is below. The web searches were also declined, so nothing here comes from research on Saltmarsh Games or Tobias. Everything about them that a search would have supplied is missing, not guessed.

I built this for a hiring-manager round, since your note didn't say how Tobias relates to the role.

---

# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. One 60-minute session. **Relationship assumed:** hiring manager.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: rehearse it in your own words and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Whether your claims survive scrutiny and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, because no research ran) |
| CASE | A live problem from the role, scored on structure and reasoning |

Answer slots are instructions for the interview, not questions for you now. Each has two branches: say what you did, or say plainly that there was no such step or it was not yours.

## Prep triage

1. Say B1 and B3 aloud until they are boring. They are the likeliest objections.
2. Settle your honest answers to the answer slots in F1, F2, F3 and F5.
3. Run A1, A4 and A5 once each as a structured, think-aloud answer.
4. Pick three reverse questions and know why you are asking each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says weekly content drops for one title, not live events for two. The words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title line makes a probe on how drops differ from events likely. If any of what you ran were events, say which and how; if it was drops only, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: expect a probe on which of those four disciplines you worked with on a drop. If you worked with any, say which and what your part was; if you did not, or it was not yours, say so plainly and return to the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the numbers, not owning a review or its KPIs. The words: "I presented the monthly retention numbers to the studio head." Answer slot: if you also chose what those numbers covered, or ran a review after drops, say how; if there was no such step or it was not yours, say so plainly and stay with presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | The JD says manage and the quote says wrote, so the words stay at wrote: "I wrote the release checklist our QA team still uses." Answer slot: if you also ran releases against it with QA, say how; if not, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material doesn't say whether that title was a live service. Answer slot: if it ran as a live service, say what made it one; if not, say so plainly and describe the weekly content drops instead |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but expect a probe since nothing is inspected behind it. Lead with it in the quote's own terms |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote says presenting, not comfort. Describe what you presented and to whom, and let the interviewer draw the conclusion |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | A written artifact others still use is the evidence. Reword only the quote and add no practice, figure or event |
| F9 | Not a JD line: team-leadership and in-app-purchase experience, the two limits you raised yourself — your message | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then how you would learn, as a plan and never as a past |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Calendar clashes, a retention dip, a post-event review, a late QA blocker | High. The hiring-manager prior, plus a JD scope that suits live problems | Clarify, objective, approach, metrics, risks; think aloud |
| Skeptic (B) | Probing of F9, F1, F2, F5 | High. The hiring-manager prior, and F9 is a limit you named | Rehearse B1 until boring: say the limit, then a ramp plan |
| Data-Driven Prober (C) | Retention numbers, KPIs | Medium. The JD names both (F3, F7) | Say plainly what you don't know about how numbers were counted |
| Conversational (D) | "Walk me through the journey" | Medium. Casual questions are still scored | A pre-scripted 90-second arc from your own sentences |
| Pressure (E) | Time-boxed "why you" | Low to medium. Prior only; no interviewer signal | Hold what the quotes carry through two follow-ups, concede specifically |
| Peer Evaluator (F) | Seams with design, art, engineering | Low. A hiring manager reads from the top | Offer seam principles, say what you bring |
| Values/Behavioral (G) | Scenario probes | Low. No values-style round is detected | Pick stories where the hard truth landed, or say none comes to mind |

No interviewer signals were available, so none adjusted the weights. The highest-ROI prep is B1, with B3 close behind.

## Question banks

### A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two live events are due in the same week for two titles, and both need art and engineering time. How do you decide what ships and what moves?" | JD | [generic] | Ask first what is fixed, what depends on what, and capacity. Then objective, two or three options, who you'd talk to, how you'd communicate the trade-off, what could go wrong. Makes no claim about your past | F1 as a decision; JD content, CASE delivery |
| A2 | "The cohort that played the last event retained worse than the cohort from the event before. Diagnose it." | CASE | [generic] | Clarify the measure, window and what changed. Segment, rank hypotheses by cost to check, say what you'd report and to whom. Challenge one premise | F7 as a live problem |
| A3 | "You've just closed a live event. Design the post-event review: what goes in it, who sees it, and which KPIs it reports." | JD | [generic] | Purpose, the few KPIs and why, the comparison each needs, who reads it and what decision it feeds. Name one KPI you'd leave out | F3 as a design task |
| A4 | "A release is due Thursday and QA finds a blocker on Wednesday evening. What do you do, and who do you talk to?" | JD | [generic] | Severity, who is affected, options (fix, cut, delay, ship with a known issue), who decides, how the call is recorded. A method, not a story | F4 as a pressure case |
| A5 | "You've run one title's calendar. You're now handed two. What do you need to know in the first weeks, and what do you change last?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the quote at its scope. Then give the new ground as a future-tense plan: what you'd learn about each calendar, which commitments are fixed, who you'd meet first, what you'd leave alone until understood | The one-to-two step (F1, F6) |

### B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Highest-ROI rehearsal. Say the limit first: "I haven't worked on a game with in-app purchases." Then a ramp plan, as a plan: what you'd try to understand, whom you'd ask, how you'd check. Don't cover the gap with the retention numbers or the calendar; your material doesn't show that. Hold through two follow-ups by repeating the limit and the plan | F9 is a limit you stated, so this will arrive in some form |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Choose honestly from your own list: the limits in the first quote, or the one-to-two-title step in the second. Say the limit, then your plan | F9 and F1 are the weakest rows shown |
| B3 | "You've never led a team. How would you get design, art, engineering and community to move on your calendar?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say "I haven't led a team." Answer slot: expect a probe on whether you worked with those disciplines on a drop. If you did, say which and your part; if not, or it wasn't yours, say so plainly and return to the calendar you ran. Then, as a plan, how you'd agree priorities and dates | F2 has no evidence and F9 is stated |
| B4 | "The role asks for three years producing live-service games. How do your four years line up?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Four years as an associate producer at a puzzle-game studio, at that scope. Answer slot: if the title ran as a live service, say what made it one; if not, say so plainly and describe the weekly content drops. Don't call it live-service unless it was | F5 |
| B5 | "Why this move, and why Saltmarsh?" | JD | [generic] | Your material doesn't say why, so the pack writes none. Give two or three of your own reasons, specific to the JD. No company research ran, so avoid claims about Saltmarsh beyond the JD | Motivation consistency |

### C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. What did they show, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Tell it at its scope. Answer slot: expect probes on how the numbers were counted, what they are sensitive to, the assumption you'd defend least, and which part was yours. Answer in your own words; where you don't know how a figure was counted, say so. If you presented numbers someone else produced, say that | F3 and F7 rest on this line |
| C2 | "Which retention metrics would you put in an event's KPI report, and which would you leave out?" | JD | [generic] | Pick a few, define each in one line, say what each can mislead you about, and name one you'd leave out | F3, F7 |
| C3 | "How would you tell whether an event worked, as opposed to whether it was just popular?" | CASE | [generic] | What you'd compare against, over what window, for which players, and what result would change your mind | Separates reporting from reading numbers |

### D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Four beats at their own scope, one per quote. Close with why this role in your own words; the material doesn't say. About ninety seconds | Most sessions open here |
| D2 | "What are you actually playing in live-service games these days?" | JD | [generic] | Name something you really play and one thing you notice about how it runs events. If none, say so and say how you follow updates | Casual, still scored (F5) |
| D3 | "Tell me about the release checklist you wrote for QA." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Tell it at its scope. Answer slot: expect probes on what prompted it, how it's used in a release, and what changed from before. If you know, say so; if there was no earlier version, or you can't describe QA's use, say so and stay with having written it | F4, F8 |

### E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "Never led a team, and never worked on a game with in-app purchases" | Pause, restate. Hold only the three held lines: the calendar, the checklist, the retention numbers. When pressed, concede the limits specifically and return to the three lines rather than adding to them | F1, F3, F4, F9 |
| E2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Anchor in the quote. Answer slot: if some parts were yours to decide, say which and how you decided; if shared or not yours, say so plainly and describe what you did. Hold through two follow-ups by returning to what you did | F6 under attribution probing |

### F: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Design, art and engineering all work alongside you. Where is the seam between producer and each of them, and what happens when we disagree?" | JD | [generic] | Offer principles, not a fake seam: who decides what, how a disagreement is raised and recorded. Say what you bring them. If you have a disagreement that ended well, say your part plainly; if none comes to mind, say so and say how you'd handle it | F2 |
| F2 | "In three sentences, write up the result of an event for the design, art and engineering leads." | JD | [grounded] "Wrote the release checklist our QA team still uses" | What happened, the number that matters, the decision it points to. For evidence you write for others, use the quote at its scope and nothing more | F8 tested live |

### G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time the message landed and the relationship held. Your material shows presenting numbers to the studio head but not that anything was unpopular, so the pack supplies no story. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Standard probe; low weight |
| G2 | "Tell me about a time you put a player ahead of an internal metric." | VAL | [generic] | Pick a decision with a named trade-off. Your material doesn't show one. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Standard probe; low weight |

### Requirement coverage

| Requirement | JD-tagged IDs | Other IDs |
|---|---|---|
| Live-events calendar for two mobile titles | A1, A5 | E1 |
| Coordinate design, art, engineering, community | B3, F1 | none |
| Own post-event review and KPIs | A3, C2 | A2, C1, C3 |
| Manage release checklist with QA | A4 | D3 |
| 3+ years live-service | B4 | D1, D2 |
| Content calendar experience | A5 | E2 |
| Comfortable with retention metrics | C2 | A2, C1 |
| Clear written communication | F2 | none |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first ninety days look like across the two titles?" | Turns the one-to-two step (F1) into a shared plan |
| R2 | "How do post-event reviews feed the next calendar, and what has changed because of one?" | Treats the review as an input and claims nothing of your own |
| R3 | "How is the support around each title set up, and which disciplines does the live-ops producer work with day to day?" | Covers the coordination row (F2) from the answer side |
| R4 | "If I came in without in-app-purchase experience, what would you want me to understand first, and who would I learn it from?" | Turns B1 into a conversation about your ramp |
| R5 | "What does the release checklist look like today, and where does it hurt?" | Connects to the checklist you wrote (F4) without claiming it applies here |
| R6 | "How do you tell whether a live event was worth running?" | Asks a Head of Live Operations for their own bar |

None is tied to Tobias's career path, because no profile was available.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events for two titles | Inflated form of F1 | F1's quote at its scope; the material says weekly content drops for one title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its scope; the material says presenting the numbers |
| Managed releases with QA | Inflated form of F4 | F4's quote: you wrote the checklist QA still uses |
| Produced live-service games for three years or more | Inflated form of F5 | F5's quote at its scope |
| Has led a team | Negative you stated, F9 | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |

## Sources

**Provided:** the JD you pasted and your background as written in your message. No CV text was supplied.

**Searches sent, all refused:** "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games mobile studio strategy news"; "Tobias Wrenfield Saltmarsh Games".

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved the values cheat sheet and bank G; both are absent or generic |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved loop structure and persona weights, which now rest on your description and my hiring-manager assumption |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO bank; there is no CO question |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and JD-tagged questions |

## Upgrade menu

- Permission for web search, or pasted material → Saltmarsh's values, loop, strategy and Tobias's public footprint; adds the values cheat sheet, CO questions, an interviewer read and a tailored reverse question
- A deeper research pass (offered once; up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief that feeds the CO questions
- Your CV text → evidence cells quote its exact wording and some medium rows may move
- Your answers to the slots in F1, F2, F3 and F5 → those rows and the banks drawing on them become mapped stories
- Whether Tobias is your future manager, a skip-level or a peer → reweighted personas and banks
- The recruiter's prep email → focus areas or a pre-announced deliverable, which would add a build section
- A tuesday-dossier.md from an earlier fit analysis → verified evidence and prohibited claims carried in

---

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a file or a Word document, say so and I'll try saving it again.

Is Tobias your future manager, a skip-level or a peer, and has the recruiter given you any focus areas or announced a deliverable? The answer reweights every bank.
Can you paste your CV so I can quote its exact wording instead of your summary?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.