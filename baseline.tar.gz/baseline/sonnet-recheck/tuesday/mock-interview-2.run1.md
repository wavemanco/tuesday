Searches were refused, so I'm building the pack from your JD and background only, then saving it.
I couldn't save the file or run the searches, because neither permission was granted. The full pack is below instead, built only from the JD and background you gave me. Nothing in it comes from the web. I built it for a hiring-manager round, since you didn't say who you're meeting.

# Interview prep pack: Operations Manager, Atlas Freight

Interviewer and round type are unknown. Persona weights are flat-leaning because nothing establishes how Atlas Freight interviews.

## How to use this pack

Personas are how a question is asked. Types are what it scores: VAL (behavior against values, here only as generic stems), EXP (do your claims survive scrutiny), JD (the posting's requirements), CO (company knowledge, none here), CASE (a live problem). Guidance is scaffolding, not a script. Every sentence about your past rests on a sentence you wrote, quoted beside it. Where the pack can't know something, there's an **answer slot**: say what's true in your own words, and if the thing didn't exist or wasn't yours, say so plainly.

## Prep triage (interview next week)

1. **A2, A3, A4**: the scale step (3 supervisors to 12, one site to 4, warehouse to terminal) and the 5+ years reading.
2. **C1, C2, E2**: the 40% mis-pick figure.
3. **E3, B4**: the Power BI answer, as a plain acknowledgment plus a plan.
4. **B1, B2**: the on-time and cost-per-shipment cases.
5. **D1** and the reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your quote carries one site's surge plan, not terminal operations and not several sites. Words: "I ran the site's peak-season surge plan two years running." Answer slot: expect a probe on multi-site scope. If any of your responsibility reached beyond that site, say where and what you decided; if it did not, or the decisions weren't yours, say so plainly and stay with the site's plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is the measure your quote carries; on-time and cost per shipment aren't in it. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked either measure, say what was counted and what moved; if not, or it wasn't yours to track, say so plainly and stay with the mis-pick work |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your quote says 3; the JD says 12. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you've led more people at any point, say who, how many and when; if not, say so plainly and stay with the 3. How you'd approach 12 is a plan, said as a plan |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Solid Excel is a tool skill; it doesn't say reports were built. Answer slot: if you built a recurring report, say who used it and what it fed; if not, or it was a one-off, say so plainly and say what you'd build first |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording can't close, and you've said so. Words: "I've never used Power BI." Then how you'd learn it, as a plan and never as a past |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | The quote counts years in operations, not years leading. Answer slot: expect the 5+ to be read literally. Say which of the seven were supervisory or management, with dates if you have them; if fewer than five, or you're unsure how they count, say so plainly and give the figure you can stand behind |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but nothing inspected, so expect a probe. Words: "I'm green belt certified." Your material doesn't say whether the pick-path work used it, so state that link only if true |

## Persona table

Relationship prior (hiring manager): Case/Strategist plus Skeptic first. Interviewer signals: none. Loop: generic archetype (screen, hiring manager, panel), stated plainly. Correct any of this if you know better.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Probing the scale step and the Power BI gap | High: hiring-manager prior, and F1, F3, F5, F6 are visible gaps | Rehearse A2 until it's boring; candor over bluffing |
| Case/Strategist (B) | Live problems on on-time, cost, reporting, peak load | High: hiring-manager prior, and two JD headline measures invite cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober (C) | Line-by-line on the 40% | Medium: the one number in your background | Say how it was counted, or say plainly you don't know |
| Conversational (D) | Biography, Lean question | Medium: common first contact | 90-second arc from your own quotes; casual is still scored |
| Pressure (E) | Time-boxed why-you, how-much-was-you | Medium: tests composure on the gaps | Hold through two follow-ups, concede specifically |
| Peer Evaluator (F) | Seam with neighboring teams | Low to medium: depends on who's in the loop | Offer seam principles, don't pretend to know the seam |
| Values/Behavioral (G) | Unpopular-truth, customer-vs-metric stems | Low: no values-style round established | Pick a true instance or use the honest branch |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" "currently a senior shift manager over 3 supervisors" | Name one real gap before they do. Your material gives two you can state truthfully: "I've never used Power BI" and "I'm currently a senior shift manager over 3 supervisors." Then a plan in the future tense | F5 and F3 are the gaps visible without asking |
| A2 | "You're over 3 supervisors today, and this role leads 12 across 4 sites. What changes at that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **Highest-ROI rehearsal in the pack.** Hold only the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you've led more people or more than one location, say who, where, when; if not, or it wasn't yours, say so plainly and stay with the 3. Then your approach as a plan. Hold through two follow-ups by returning to the quote; concede specifically that 3 to 12 is a real step | F3 and F1 are where the role presses hardest; this objection arrives in some form |
| A3 | "The posting asks for 5+ years of operations leadership. How do your 7 years in warehouse and distribution line up against that?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Start in the quote's terms: "I have 7 years in warehouse and distribution ops." Answer slot: say which years were supervisory or management, in your own words; if fewer than five, or unsure how they count, say so plainly and give the figure you can stand behind. Don't round up | F6: discovery gap and literal-reading risk |
| A4 | "Your background is warehouse and distribution. What's different about running terminals, and where do you expect to be least prepared?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: if you've worked in any terminal-type setting, say where and what you did; if not, say so plainly and stay with warehouse and distribution. Then ask what a typical day looks like at one of the four sites, since the pack doesn't know | F1 carries the warehouse-to-terminal step |
| A5 | "Why leave your current role, why a regional carrier, why now?" | JD | [generic] | Selection scaffold: pick the reason that's true, say what this role offers without criticizing your employer, and why now. If no such reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Skeptic stem on motivation; no motivation material supplied |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites slips over a month. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify what on-time means here and how it's measured; then objective, segmentation (lane, shift, customer, cause), approach, metrics, risks. Think aloud; challenge one premise | F2's requirement as a live problem |
| B2 | "Cost per shipment is up and on-time is flat. Where do you look, and what would you not cut?" | CASE | [generic] | Define numerator and denominator first; split by cost line and site; say what you'd protect and why | F2's second measure |
| B3 | "A peak week hits: volume jumps and two supervisors call out the same morning across your four sites. Walk me through the first hour." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure the hour: what you check, who you call, what you reallocate, what customers hear. If a beat of your surge plan fits, name it only as the quote carries it. Answer slot: if asked what the plan covered, say what was in it and which parts were yours; if parts were set by others, or there was less to it than the question assumes, say so plainly | F1's quote is your one peak-load fact |
| B4 | "Design the daily and weekly dashboard you'd want on your desk for four sites. What's on it and what's left off?" | CASE | [grounded] "solid Excel" "never used Power BI" | Ask who reads it and what decision it feeds; start with on-time and cost per shipment. Say what you'd build in Excel. If asked about Power BI: "I've never used Power BI," then your plan. Answer slot: if you've built a recurring report, say who used it and what it fed; if not, say so plainly and describe the design | F4 and F5 |
| B5 | "One of your supervisors hits every target but their team keeps turning over. What do you do?" | CASE | [generic] | Clarify (how long, which roles, exit reasons); separate the person's results from the team's experience; then what you'd observe, say and decide, and by when | F3's requirement as a live people problem |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | In your own words: how it was counted, what it's sensitive to, which part was yours. The pack supplies no baseline, period or method. If you don't know how it was counted, say so plainly | F2 holds the figure |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name it before they do, in your own words. If you can't name one, say you haven't tested it and what you'd check first | Weakest-assumption move for F2 |
| C3 | "This role is judged on on-time performance and cost per shipment. What is your experience with those measures?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked either, say what was counted and who used it; if not, or it wasn't yours, say so plainly and return to the mis-pick work as the quote states it | F2 is a transferability gap |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | 90 seconds, your own order, only these facts as stated, closing on why this role (A5). Add no dates or sequence the quotes don't give | Biography material is F1, F2, F3, F6, F7 |
| D2 | "Tell me about where Lean or Six Sigma has shown up in your work." | JD | [grounded] "green belt certified" "cut mis-pick rate 40% by redesigning the pick path" | Lead with "I'm green belt certified." Answer slot: expect a probe on whether the pick-path redesign used it. If it did, say which methods and how; if not, or the certification stood apart, say so plainly and stay with the certification | F7; its link to F2 isn't in the material |
| D3 | "How would the people who work for you describe your management style?" | JD | [generic] | Selection scaffold: pick a specific habit you can show in action, not an adjective. If no such habit comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F3 asked casually |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run multi-site terminals?" | JD | [grounded] "7 years in warehouse and distribution ops" "green belt certified" | Pause, restate, hold only the quotes: "I have 7 years in warehouse and distribution ops, and I'm green belt certified." Concede specifically: "I've never used Power BI," and that 3 to 12 supervisors is a real step. Don't fold on the core claim | F1, F3, F5 are the concessions |
| E2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote's scope. Answer slot: say which parts of the redesign were yours; if it was shared, or others set parts of it, say so plainly. Concede uncertainty on anything you can't reconstruct | F2's attribution probe |
| E3 | "The posting names Power BI and you've never used it. Why should I take that risk?" | JD | [grounded] "never used Power BI" "solid Excel" | Open with "I've never used Power BI." Hold what's carried, "solid Excel," then a plan in the future tense. Claim no familiarity | F5 and F4 |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side — where's the seam between us, and what happens when we disagree?" | EXP | [generic] | Offer seam principles (who decides what, how issues escalate, what each side needs), not a pretended map. Ask how handoffs work today | Peer stem; relevant if dispatch, service or finance is in the loop |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared that you can describe truthfully. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem |

### G. Values/Behavioral

No values-style round is established, so these rehearse persona stems, not company values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a point where the hard truth landed, an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a specific decision, the metric you gave up, what you told the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, A4, B3 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C3 |
| "lead a team of 12 supervisors" | A2, B5, D3 |
| "build reporting in Excel/Power BI" | A1, B4, E3 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which site would you want moved first?" | Shows you think in the JD's measure at site level |
| R2 | "How is cost per shipment calculated here, and who owns the inputs?" | A prober's habit; surfaces the data setup you'd inherit |
| R3 | "What does the reporting stack look like today, and what lives in Excel versus Power BI?" | Turns the Power BI gap into a ramp conversation |
| R4 | "Of the 12 supervisors, who is newest in role, and where is the biggest development need?" | Addresses the scale step and shows you start with people |
| R5 | "What would success look like at 90 days, and what would tell you it was going badly?" | Gives you the scoring sheet |
| R6 | "What do people outside this role most underestimate about running four sites?" | Invites them to teach, which suits a step up in scale |

## Prohibited claims

Built locally from the fit snapshot. No cell in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led twelve supervisors | Inflated form of F3 | F3's quote at its own scope: the material says 3, not 12 |
| Owned terminal operations across four sites | Inflated form of F1 | F1's quote: one site's surge plan, not terminals or four sites |
| Improved on-time performance or cost per shipment | Inflated form of F2 | F2's quote: mis-pick rate. A3 and C3 slots stay inside the mis-pick work |
| Five or more years of operations leadership | Inflated form of F6 | F6's quote: 7 years in operations, not 7 years leading |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment: "I've never used Power BI." No slot |

## Sources

Provided: the JD text and background in your message. No CV, dossier, interviewer profile or recruiter guidance.

Searches sent, all refused (permission not granted):
- `Atlas Freight regional logistics company values`: refused
- `Atlas Freight interview process operations manager`: refused
- `Atlas Freight regional logistics strategy news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Refused. Would have fed a values cheat sheet and VAL themes; none built |
| 2. `Atlas Freight interview process` | unavailable | Refused. Would have set loop and persona weights; the generic archetype stands in |
| 3. `Atlas Freight strategy` / news | unavailable | Refused. Would have fed a CO bank; the pack has none |
| 4. `{interviewer name} Atlas Freight` | n/a | No name given, so no query to form |
| 5. representative Operations Manager JD | skipped | Your JD fixes the fit snapshot and JD-tagged questions |

## Upgrade menu

- Round type and who you're meeting (manager, peer, skip-level, recruiter) → reweights every bank
- The interviewer's name → an interviewer read and a reverse question tied to their path
- The recruiter's prep note (focus areas, any take-home or presentation) → coverage of any announced deliverable
- Your answers to the slots on F1, F2, F3, F4, F6 → those rows regenerate with your own words quoted, and bank cells become story maps
- Your CV with dates → F3 and F6 firm up and gap types can improve
- The sheet or report behind the 40% → C1, C2, C3, E2 can rest on inspectable proof
- The green belt certificate → F7 moves from medium to high confidence
- Search and write permission → a default company pass (values, loop, strategy: up to 6 searches, 2 fetches) and a saved file. A deeper pass adds up to 6 more searches, 2 more fetches and several more minutes
- A `tuesday-dossier.md` from earlier work, if you have one → verified evidence and prohibited claims arrive pre-graded

Say the word and I'll play the Skeptic on A2, the question the pack names as your highest-ROI prep.
I can also record the gaps this prep exposed in a `tuesday-dossier.md` for later sessions, if you grant write access.

Who are you meeting (future manager, peer, someone from HR), and has the recruiter mentioned any focus areas or a deliverable?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.