Search and page fetch were both declined, so everything below rests on what you pasted. The accounting is under Evidence status.

## Decision snapshot

**Yes, Ines, this is worth applying to, on conditions. R3, R4, R5, R6 and R7, the `must_have` rows, are all `direct`, and R1 and R2 (hard gates) aren't settled yet. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts)

R8 carries a bridge with its limit named, and R9 and R10 wait on discovery.

**Opportunity ledger.** The pay reads as supportive (RR4). The employer is unverified because search was declined (RR1). Team, manager, first-year outcomes and equity are unspecified (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 are met, which is your call; (2) the live posting and employer verify, see RR1; (3) the BigQuery gap is stated plainly as adjacent, never as BigQuery experience, see R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about page text you pasted; not independently checked |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| Seniority | JD asks for 5+ years; the report says "Senior" typically means 5–8 years | `[grounded]` JD and the Datawright report you supplied |
| Scope read | One reporting platform end to end, from ingestion through modelling to contracts. That is broader than the report's typical "one domain's pipelines", and whether it is a one-person remit is not stated | `[inferred]` from the JD's three-part mandate against the report's typical scope |
| Market calibration | Base median $151,000, interquartile range $139,000–$163,500, for Senior Data Engineer at Series B–D companies, with no direct reports typical. It is a pattern, not this employer's offer | `[grounded]` the report you supplied (US, n=2,310); `[generic]` as a role-family pattern |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager (the posting names none), team size, which orchestrator they run, equity terms, which CRM | `[grounded]` JD silence |
| Contradictions | None between the JD text and about-page text as you pasted them; neither was checked against the live pages | `[grounded]` your two pastes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and US work authorization weren't given, so the term can't be checked. Confidence is `none` because there is no statement of your constraint to grade | `[grounded]` JD; your side unstated | Question at close, tagged G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The range is stated, the equity is not quantified | `[grounded]` JD; your floor unstated | Question at close, tagged G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is a prose self-report with no inspectable artifact, so `medium`, and a probe on dates and scope is likely. Length of experience is not a gate | `[grounded]` your background summary | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Confirmed and plausible, but no artifact inspected | `[grounded]` your summary | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. "About 180" counts models and is self-reported. A dbt docs site or lineage view would raise it to `high` | `[grounded]` your summary | Offer: sanitized dbt docs or lineage screenshot |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. How much of it you authored versus maintained isn't stated, so no artifact and `medium` | `[grounded]` your summary | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is what you said and no more. The suite's size and who ran it afterward are unstated. A sanitized suite config would raise it to `high` | `[grounded]` your summary | Offer: sanitized expectation suite or checkpoint report |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Tiered `important`, not `must_have`, because the requirements line asks for "a cloud warehouse" and BigQuery appears only in the mandate. You've never used BigQuery. The bridge is dbt on Snowflake, and the limit is zero BigQuery use. Warehouses differ in cost model and tuning levers, so that part of the work is untested | `[grounded]` your statement; `[generic]` that warehouse-specific tuning differs | Work sample W1 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Your summary doesn't say what your pipelines ingested from. Six years of pipelines is indirect context only | `[grounded]` your summary's silence | Question at close, tagged G4 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | A Great Expectations suite is testing. Whether it worked as an agreement with analysts isn't stated, and the two aren't the same thing | `[grounded]` your summary's silence | Question at close, tagged G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and US authorization (R1) | hard_gate | The posting allows US remote or Denver. Your location and authorization are unstated | A gate that fails ends the decision, however strong the fit | Not experience: a term you confirm | None needed | `[grounded]` JD; your side unstated |
| G2 | Pay floor against the range (R2) | hard_gate | A stated range and unquantified equity. Your floor is unstated | The posted range is the one pay term in hand | Not experience: a term you confirm | None needed | `[grounded]` JD; your floor unstated |
| G3 | BigQuery (R8) | transferability | dbt and Snowflake carry over, with no BigQuery use | The only `important` row with a named limit | A small dbt project run on BigQuery's free tier | A public repo with a README and tests | `[inferred]` bridge from R8's stated limit |
| G4 | Ingestion from app and CRM sources (R9) | discovery | Nothing says where your pipelines' data came from | It is the first half of the mandate | Pulling a SaaS CRM through a connector or API; replicating an application database; consuming product event data | Source definitions in your dbt project, an ingestion DAG list | `[grounded]` summary silence; `[generic]` that ingestion work usually leaves source definitions behind |
| G5 | Data contracts (R10) | discovery | Testing is established. Agreements with downstream analysts are not | The mandate names it explicitly | Agreeing freshness or schema guarantees with analysts; a process for breaking changes; tests added after an upstream change hit a dashboard | A sanitized source-freshness config or change note | `[grounded]` summary silence; `[inferred]` that your GE suite may be a starting point |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | Nothing was independently confirmed because search was declined. The details are specific and came from the company's own pages as you pasted them, so I took the lower severity | `[generic]` pattern: an unchecked employer says nothing against it, not a claim about this one | Is this role open on your careers site today, and who would I interview with? | unresolved |
| RR2 | No team, manager or first-year outcomes stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the only data engineer or part of a team. The posting names no manager and no definition of success | `[grounded]` JD silence; `[inferred]` that the remit could be a team of one | How many data engineers and analysts are there, who would I report to, and what should be true after twelve months? | unresolved |
| RR3 | Equity unspecified | unknown | — | "$148,000–$166,000 plus equity" | The equity's size and terms can't be valued from the posting | `[grounded]` JD gives no equity figures | What is the equity grant range, vesting schedule and strike price basis? | unresolved |
| RR4 | Posted range sits around the report's median | positive_signal | — | "$148,000–$166,000 plus equity" | The low end is $3,000 under the $151,000 median and the high end $2,500 over the $163,500 upper quartile. The role doesn't look underpaid for a Series B–D senior post, and the band is not this employer's offer | `[grounded]` JD range and the report you supplied; `[generic]` the band as a role-family pattern | Is the range fixed for the level, and where would my experience place me in it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the dbt project on Snowflake (about 180 models), Airflow orchestration, and the Great Expectations suite you set up, in your own verbs and numbers | see R5, R6, R7 | `[grounded]` your summary | resume_edits_pending_approval |
| E2 | In the application and screens, say plainly: dbt on Snowflake, no BigQuery use yet | see R8 | `[grounded]` your statement | pending your approval |
| E3 | Don't relabel the Great Expectations suite as "data contracts", or your pipelines as "CRM ingestion", unless your answers to G4 and G5 confirm it | see R9, R10 | `[grounded]` your summary; the JD's vocabulary isn't your history | pending your approval |
| W1 | A small public BigQuery project: load a public dataset, model a slice with dbt, add tests, link it | see R8, G3 | `[inferred]` strengthener from R8's limit | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetch of pellucidlearning.com/careers/senior-data-engineer and search "Pellucid Learning online tutoring K-12 Denver Series C $52M" were both refused. It would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes market calibration and RR4 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

I can write this up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your location, US authorization and pay floor → R1 and R2 settle, and the hard-gates line closes.
- A sanitized dbt docs or lineage view → R5 to `high`.
- A sanitized Great Expectations suite or checkpoint report → R7 to `high`.
- Your answers on sources and analyst guarantees → R9 and R10 resolve, and E3's caution relaxes or holds.
- Search and fetch permission → RR1 verifies against the live posting, with 4 searches and 1 fetch left. A deeper pass on Pellucid (funding, leadership changes, recent news) would add up to 5 more searches and 2 more fetches.
- The hiring manager's name, once you have it → role reality's scope read and which story to lead with.

**Questions**

- G1 — Where are you based, and are you authorized to work in the US without sponsorship? Would you take the remote or the Denver option?
- G2 — What is your pay floor, and how much weight do you put on the equity?
- G4, G5 — Which source systems did your pipelines ingest from, and what did analysts rely on you to guarantee about that data? What was yours and what was the team's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.