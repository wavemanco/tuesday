I couldn't run the web searches because permission was denied, so I'm building the pack from what you gave me. I'll write the three-round pack to a file now.
I couldn't save the pack as a file because write permission wasn't granted, so it's below in full. I built it for loop mode and rested every row on the sentences in your message. The web searches were refused, so there's no company research. That means no published values, no documented loop and no strategy questions.

# Interview pack: Engineering Manager, Larkfield Systems (three rounds, loop mode)

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Hiring manager, a Director of Engineering | 45 min | Would-be boss |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min | Peers and a cross-functional partner |
| 3 | The following Monday | VP Engineering, "values and leadership philosophy" per the recruiter | 30 min | Skip-level |

**How to use:** Personas are how a question is asked. Types are what's scored: VAL (behavioral or values), EXP (experience deep-dive), JD (role-driven), CO (company knowledge), CASE (live problem). Guidance is scaffolding, not a script. Answer slots are instructions for the interview: fill them from what actually happened, or take the honest branch. IDs run by round: A to D, E to H, I to L.

**Prep triage:**
- Before Tuesday: A2 first (the highest-ROI prep in the pack), then A1, C1 and B1.
- Before Thursday: E1, F1, F2, G2 and H1.
- Before Monday: I4, J1, I1 and I2.
- Everything else is insurance.

## Fit snapshot (shared)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description you pasted | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads. Words stay at that scope: "For three years I led a team of six." Answer slot: the two-squads line makes a probe on splitting attention likely. If you've led work spanning more than one team, say how; if not, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role description you pasted | "currently at a payments company" — your message | low | [inferred] | discovery | Your material doesn't show whether any of your services touch devices or fleets. Answer slot: if you've worked on services whose clients you don't control, say what and which part was yours; if not, say so and say what you'd learn first |
| F3 | "own delivery" — role description you pasted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is about pushing a reliability quarter through, with the drop coming "after". It isn't delivery ownership in general. Answer slot: if you owned delivery dates or commitments, say which; if that wasn't yours, say so and stay with the reliability quarter |
| F4 | "hiring" — role description you pasted | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote already reaches hiring. Keep the number attached to interviews, not hires. Nothing inspected sits behind it, so expect a probe |
| F5 | "growth for 11 engineers" — role description you pasted | none given | none | [grounded] | discovery | Your material doesn't show growth work. Answer slot: if you've helped an engineer grow, say what you did and what changed; if not, say so and say how you'd start |
| F6 | "partner with hardware and product on roadmap" — role description you pasted, hardware side | "never owned a hardware-adjacent roadmap" — your message | low | [grounded] | discovery | You stated the limit: "I haven't owned a hardware-adjacent roadmap." Owning isn't partnering, and your material is silent on partnering. Answer slot: if you've worked alongside hardware or firmware teams in any form, say how and which part was yours; if not, say so plainly |
| F7 | "partner with hardware and product on roadmap" — role description you pasted, product side | "pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote shows roadmap pressure and that you pushed, not who pressed or how you worked with them. Answer slot: if you worked it out with a product partner, say how; if it was decided elsewhere, say so |
| F8 | [generic] a possible expectation of leading through squad leads; the role description doesn't say whether the squads have leads | "I've never managed managers" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never managed managers." Then your plan to learn it, said as a plan, never as a past |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers or led through leads | Negative you stated, F8 | "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." Slots stay on partnering only |
| Has led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: the material says one team of six |
| The reliability quarter alone cut on-call burden 60% | Inflated form of F3 | The quote's order: the drop came after |
| Owned or set the roadmap | Inflated form of F3 and F7 | The quote says pressure on a roadmap, not who set it |
| Hired about 40 engineers, or owned hiring end to end | Inflated form of F4 | You run the loop, about 40 interviews |

## Round 1: Hiring manager (Tuesday)

This round is built on the assumption that the Director evaluates capability and gaps. Nothing documents how Larkfield runs its rounds beyond your description.

| Persona | Weight | Reasoning |
|---|---|---|
| Skeptic | high, 4 | Hiring managers derisk gaps, and F6 and F8 are stated gaps |
| Case / Strategist | high, 3 | Hiring managers buying capability tend to bring live problems from the role |
| Data-Driven Prober | mid, 2 | The 60% and the interview count invite denominators |
| Conversational | low, 1 | The opener is casual and still scored |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led a team of six. What changes when you're accountable for two squads and eleven engineers?" | JD | [grounded] "3 as a team lead of 6" | Say the scope you have: three years leading a team of six. Answer slot: if you've led work spanning more than one team, say how, in your own words; if not, say so plainly, then give your approach to the first weeks as a plan, never a past | F1 is the headline requirement and its limit is scope |
| A2 | "This role partners with hardware on the roadmap. What experience do you bring there?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | **Highest-ROI rehearsal in the pack.** Hold only the quote: "I haven't owned a hardware-adjacent roadmap." Answer slot: if you've worked alongside hardware or firmware teams in any form, say how and which part was yours; if not, say so plainly. Then give your ramp plan in your own words. Hold through two follow-ups by returning to the stated limit, never by adding to it | F6 is the largest stated gap against the role's hardware partnership |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers" and "never owned a hardware-adjacent roadmap" | Your material states two limits. Pick the one you'd actually rank first, say it in the quote's own terms, and say what you'd do about it as a plan. Don't volunteer a third limit your material doesn't state, and don't minimize these two | F8 and F6 are the two stated limits |
| A4 | "Why leave payments for industrial IoT, and why now?" | JD | [generic] | Selection scaffold, since no sentence of yours carries a motive. Pick a reason you can state in your own words that ties to something the role description says. If the honest reason is partly a pull toward people leadership, say so. If no reason comes to mind yet, settle one before Tuesday | F2 is the domain move behind the probe |
| B1 | "You inherit two squads, a slipping release and a hardware date that won't move. What do you need to know first?" | CASE | [generic] | Clarify what's slipping, against which commitment, affecting whom. Then objective, options, measures, risks. Challenge one premise politely, such as how fixed the date is. No claim about your past | A live problem from the role's hardware partnership |
| B2 | "Product wants a feature and hardware needs a compatibility change. Both squads are full. How do you decide?" | CASE | [generic] | Say your criteria aloud before choosing: what each ask protects, what each costs if delayed, who must be in the decision. Name what you'd want to know that the question doesn't say, and say what you'd tell whoever lost | The role names both partnerships (F6, F7) |
| B3 | "A squad lead says the team needs a reliability quarter and product says no. What do you do?" | CASE | [generic] | Treat it as a live problem: ask what the on-call load is and what the work would change, state how you'd take it to product, and what you'd give up. Your own reliability quarter isn't part of this question | A case adjacent to F3; no past claim |
| C1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four slots, in your own words: how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours. "I don't know how it was counted" is an honest branch. Say it in the quote's order: the drop came after | F3 holds the headline metric |
| C2 | "Tell me about the roadmap pressure you pushed against." | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" | Beats the quote states: you pushed a reliability quarter through, and there was roadmap pressure. Answer slot: a probe on who was pressing and what was traded is likely. If you negotiated trade-offs, say what; if there were none, or others made that call, say so and stay with what you pushed | F7 is your nearest roadmap-partnership evidence |
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc from the quote only: nine years, three as a team lead of six, now at a payments company. Add your reason from A4 and stop | F1 gives the clauses the quote states |

**Round 1 reverse questions:**
1. "How are the two squads split today, and do they have leads?" This settles F8's open point.
2. "Where do hardware dates and software roadmaps collide most often?" It shows you're thinking about the F6 seam.
3. "What would make the first six months a success for this seat?" It points the conversation at the outcome the Director owns.
4. "What would you want someone without a hardware-roadmap background to be told first?" It names your limit and invites the ramp conversation.
5. "How do the eleven engineers split between the squads, and what's open on hiring?" It ties to the role's hiring and growth line.

## Round 2: Panel (the Thursday after)

Names are unknown, so personas are blended rather than assigned per member. The staff engineers count as peers and technical probers, and the product manager as cross-functional.

| Persona | Weight | Reasoning |
|---|---|---|
| Peer Evaluator | high, 4 | Staff engineers price what the hire costs and adds to their work |
| Values / Behavioral | mid, 3 | Cross-functional rounds tend to be behavioral |
| Data-Driven Prober | mid, 2 | Staff engineers verify specifics collegially |
| Skeptic | low, 1 | The panel may test the domain gap |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What would you need from staff engineers on these squads, and what would we get from you?" | JD | [generic] | Reciprocity first: what you bring to their work, then what you need. Propose principles for the seam (who decides what) without claiming to know where it sits today. No past claim | Squad delivery involves staff engineers directly |
| E2 | "A staff engineer wants to re-architect a service and product wants the feature this quarter. How do you referee?" | CASE | [generic] | Clarify what each buys and what each is worth, state criteria, then decide. Say what would change your mind | A live squad-level problem scoring disagreement style |
| E3 | "Tell me about a time you disagreed with a technical lead and how it ended." | VAL | [generic] | Selection scaffold, since no sentence of yours carries this. Pick a time with a named stake, a position held, and a relationship intact. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Persona stem for peer evaluators |
| E4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time credit was shared across teams and say what you did. If none, say so, then say how you'd handle it. The pack supplies no example | Persona stem for peer evaluators |
| F1 | "Walk me through the hiring loop you run for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F4: you run it, it's for backend roles, about 40 interviews last year. Answer slot: a probe on what the loop consists of and which parts were yours is likely. If any part was yours to set, say which and how you decided; if not, say so and describe how you ran it | F4 is your strongest-fit row, so expect probes at its edges |
| F2 | "Walk me through how you got to about 40." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Four slots: how it was counted, what it's sensitive to, the assumption you'd defend least, which part was yours. Keep it attached to interviews, not hires. "I don't know exactly" is honest | F4 holds a figure |
| G1 | "Tell me about a time you and a product partner disagreed on priorities." | VAL | [inferred] "pushed a reliability quarter through against roadmap pressure" | Selection scaffold: a named stake, a position held, a relationship intact. Your quote shows pressure and that you pushed, not a product partner or how it ended. If none comes to mind, say so, then give the nearest thing at its own scope | The role names product partnership (F7); the quote is adjacent |
| G2 | "When did you put a team's health ahead of a delivery date?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F3: pushed a reliability quarter through against roadmap pressure; on-call burden dropped 60% after. Answer slot: a probe on what the pressure cost and who absorbed it is likely. If anything slipped, say what; if nothing did, or it wasn't yours to know, say so | F3 is your strongest story |
| G3 | "Tell me about a time you helped an engineer grow." | VAL | [generic] | Selection scaffold, since nothing carries growth work. Pick a specific person and change, in your own words. If none, say so plainly and say how you'd start with eleven engineers | F5 is a silence the role's growth line raises |
| H1 | "Which parts of device-management work would you need us to teach you first?" | JD | [grounded] "currently at a payments company" and "never owned a hardware-adjacent roadmap" | Name what you'd ask them instead of claiming domain knowledge. Your stated limit: "I haven't owned a hardware-adjacent roadmap." Answer slot: if any of your services deal with clients you don't control, say what; if not, say so and say how you'd learn the device side first | F2 and F6 are the domain gap |

**Round 2 reverse questions:**
1. "What could a new manager do in the first month that would genuinely help your team?" This is the reciprocity question for peers.
2. "What's the on-call experience like for the squads today?" It opens a reliability conversation without claiming one.
3. "Where do hardware constraints most change how you design the services?" It probes the F6 seam.
4. "How does the roadmap get negotiated between product and the squads?" It tests F7 from the inside.
5. "What would you want a new manager to stop doing, or not start?" It invites candid peer feedback.

## Round 3: VP Engineering (the following Monday)

The recruiter's words, "values and leadership philosophy", are the source for a values-style round. Larkfield's published values weren't retrieved, so the VAL questions theme from the recruiter's description rather than named values. For that reason there's no values cheat sheet.

| Persona | Weight | Reasoning |
|---|---|---|
| Values / Behavioral | high, 4 | The recruiter's description names the round |
| Pressure | mid, 2 | Skip-levels test composure, and the 60% invites attribution probes |
| Conversational | low, 2 | A short round still opens warmly and is scored |
| Case / Strategist | low, 2 | A VP may test altitude |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What's your leadership philosophy?" | VAL | [inferred] "I run our hiring loop for backend roles — about 40 interviews last year" and "pushed a reliability quarter through against roadmap pressure" | The pack doesn't write your philosophy. Name two or three principles you actually act on, each tied to a decision you can describe. Your quotes show a hiring loop you run and a reliability quarter you pushed, at their own scope. Drop any principle with no decision behind it | Raised by the recruiter's words; the quotes are adjacent to a philosophy, not a statement of one |
| I2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [inferred] "pushed a reliability quarter through against roadmap pressure" | Selection scaffold: a named stake, a moment you didn't fold, a relationship intact. Your quote shows pushing against pressure, not who the audience was or that the truth landed. If none comes to mind, say so, then give the nearest thing at its own scope | Persona stem; F3 is adjacent, not equivalent |
| I3 | "You run hiring loops. What do you look for beyond skill?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on F4. Answer slot: a probe on your hiring bar is likely. If you hold a bar you apply, say what it is in your own words; if you work to one someone else set, say so | F4; scores hiring values |
| I4 | "You haven't managed managers. How do you intend to grow into that?" | VAL | [grounded] "I've never managed managers" | The most likely VP probe. Plain acknowledgment: "I've never managed managers." Then your plan, in your own words. Answer slot: if you've grown anyone toward leading others, say what and which part was yours; if not, say so plainly | F8; leadership growth is the round's stated subject |
| J1 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold only the quote: "I pushed a reliability quarter through against roadmap pressure." Hold through two follow-ups by returning to it. Concede specifically what the sentence doesn't claim: the drop came after, and it's a team figure. Answer slot: which parts were yours and which others', in your own words | F3 under the Pressure stem |
| J2 | "Sixty seconds: why you for this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I run our hiring loop for backend roles — about 40 interviews last year" | Say the facts the quotes state and let the interviewer draw the inference. State your limit before they do: "I've never managed managers." Don't claim the work proves the fit | F1 and F4 hold the evidence |
| K1 | "Tell me how you got here." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc from the quote only, plus your reason for this role. Stop at the reason | F1 |
| K2 | "What would your team say it's like to work for you?" | VAL | [generic] | Selection scaffold: say only what you can back with a specific example. If none comes to mind, say so plainly. The pack supplies none | Raised by the leadership description; nothing in your material states this |
| L1 | "You have ninety days across two squads. What do you want to learn before changing anything?" | CASE | [generic] | State what you'd ask, of whom, in what order; the objective; how you'd decide when to act; the risk of acting too early. No past claim | A live problem in the role |
| L2 | "How do you balance reliability work against roadmap commitments when hardware dates are fixed?" | CASE | [generic] | State your decision criteria aloud before answering. This asks for a framework, so the guidance borrows no story from your past | The role's tension between delivery and hardware dates |

**Round 3 reverse questions:**
1. "How do you develop engineering managers here?" This addresses your stated gap and shows you plan to grow.
2. "What do you see as the hardest tension between hardware and software at Larkfield?" It signals altitude and respect for the domain.
3. "What would you want a new manager to have changed by the end of year one?" It moves from philosophy to outcome.
4. "Which principles have shaped how you built this organization?" It mirrors the round's stated subject.
5. "What do people get wrong about this job in the first ninety days?" It shows you're preparing for the ramp.

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | A1, A4, B1, H1, J2, L1 |
| "own delivery" | B1, B2, B3, C2, G2, L2 |
| "hiring" | F1, F2, I3 |
| "growth for 11 engineers" | G3, I4 |
| "partner with hardware and product on roadmap" | A2, B2, E2, G1, L2 |

## Sources

Provided documents: your message. No dossier was present.

Searches sent, all refused, so none returned anything:
- "Larkfield Systems industrial IoT values"
- "Larkfield Systems interview process engineering manager"
- "Larkfield Systems industrial IoT device management strategy news"

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The values cheat sheet, dropped: no published values are in hand |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The documented loop; persona weights rest on your round descriptions |
| 3. `Larkfield Systems strategy` / recent news | unavailable | CO questions: none in this pack, and a strategy-grounded one would have been added |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so no query could be formed |
| 5. representative `Engineering Manager` JD | skipped | The role description you pasted fixes the fit snapshot and JD-tagged questions |

## Upgrade menu

- Your CV → F1 to F8 regrade on your own wording, and some answer slots may become story-mapped beats.
- The full posting → requirements beyond the summary become quoted rows.
- Web search permitted → published values (a round-3 cheat sheet), the documented loop, and a CO question grounded in current strategy.
- Interviewer names → an interviewer read, tailored persona weights and a reverse question tied to each person's path.
- The recruiter's prep email, if any → focus areas or deliverables for each round.
- Your answers to the slots in F2, F5, F6 and F7 → those rows regrade from discovery to a quoted row.
- A tuesday-dossier.md, if you have one → verified evidence and a named strongest objection.

Say the word and I'll run a live drill, starting with the Skeptic on A2, the pack's highest-ROI question.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
Once file writes are allowed, I can save this pack and convert it to Word if you'd like.

Can you paste your CV and the full posting? I've proceeded without them, and they'd regrade most rows.
Do you want me to retry the company research if you allow web search?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.