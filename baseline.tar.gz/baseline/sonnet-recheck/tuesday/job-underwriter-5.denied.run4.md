**Decision snapshot**

**Yes, worth applying, on conditions. All five `must_have` rows (R3, R4, R5, R7, R8) are `direct`, and the two hard gates, R1 and R2, are still unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R7, R8
- `important`: adjacent: R6 (a dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R6 has a credible bridge with its limit named. R9 and R10 wait on what you tell me.

**Opportunity ledger.** The posted pay sits inside the pay report's range (RR2). The open items are equity terms (RR3), team size and ownership (RR4), on-call (RR5), and outside corroboration of the company's own description (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You can work from within the US, remotely or in Denver (R1).
  2. Your pay floor is at or below the band (R2, RR2).
  3. BigQuery is presented as adjacent to your Snowflake and dbt work, never as BigQuery experience (R6).
  4. The company's stage and size hold up when asked of the employer (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted. These are the company's own claims, not checked elsewhere (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Location and pay | Remote (US) or Denver office; $148,000–$166,000 plus equity | `[grounded]` JD |
| Posting status | Showed "Accepting applications" when you copied it at 09:12 today | `[grounded]` your observation; not independently checked |
| Scope read | Three named areas (ingestion, warehouse modelling, contracts) in one role, with no team size or reporting line stated. This may be broader than a single domain's pipelines (RR4) | `[inferred]` from the JD's three areas and its silence on team, set against the pay report's typical scope below |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500. "Senior" typically means 5–8 years, with ownership of one domain's pipelines and no direct reports. The posted band runs from just under the median to above the upper quartile. Your 6 years falls inside the 5–8 range. This is a pattern, not Pellucid's offer | `[generic]` Datawright 2026 report (n=2,310) as sent by your recruiter; `[grounded]` JD figures and your 6 years |
| Unknowns | Hiring manager (not named), equity terms, team size, on-call, how much BigQuery experience is expected on day one | `[grounded]` the posting is silent on each |
| Contradictions | None between the pasted posting and the pasted about page | `[grounded]` both texts as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or whether you can work in the US, so the gate isn't settled either way. Confidence is `none` because no statement from you exists to grade | `[grounded]` JD; your background silent on location | Answer G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given, so whether the band meets it is unknown. See RR2 for the market read | `[grounded]` JD; your floor not given | Answer G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Confirmed and specific, but typed background has no inspectable artifact yet, so `medium`; expect a probe | `[grounded]` your background as typed | Offer: a dated work history or LinkedIn would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state SQL and Python daily. "Strong" is the employer's judgment and an interviewer will test it | `[grounded]` your background as typed | Offer: a code sample or repo would raise it |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. Limit: "about 180 models" is self-reported | `[grounded]` your background as typed | Offer: dbt docs or a lineage-graph screenshot would raise it |
| R6 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Adjacent: dbt on a cloud warehouse at 180-model scale. Limit: you have never used BigQuery, so nothing about running it is exercised. dbt skills tend to carry across warehouses, while warehouse-specific cost and performance habits do not | `[grounded]` your "never used BigQuery"; `[generic]` that dbt skills carry across warehouses | Bridge plus an optional small BigQuery work sample (G4, W1) |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow orchestration at your company. Confirmed and specific, with no artifact inspected | `[grounded]` your background as typed | Offer: a sanitized DAG screenshot would raise it |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. Confirmed and specific, with no artifact inspected | `[grounded]` your background as typed | Offer: a sanitized suite config or docs page would raise it |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background doesn't say which sources your pipelines ingested. Airflow work is indirect context, not evidence of app or CRM sources | `[grounded]` your background silent on sources | Answer G5 when asked |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is indirect context. Nothing you've said covers agreed expectations with downstream consumers | `[grounded]` your background silent on consumer agreements | Answer G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and US eligibility (R1, hard_gate) | hard_gate | Posting offers Remote (US) or Denver; your location and authorization aren't stated | A failed gate makes this `no_go` however strong the fit | Not applicable: this is a term, not experience | None needed; your statement settles it | `[grounded]` JD and your silence |
| G2 | Pay floor against the band (R2, hard_gate) | hard_gate | Band is posted; your floor isn't | A floor above $166,000 would fail this gate | Not applicable: this is a term, not experience | None needed; your statement settles it | `[grounded]` JD and your silence |
| G3 | Data contracts (R10, important) | discovery | Your GE suite is the nearest evidence; consumer agreements aren't mentioned | This is one of the three named pieces of the mandate, so a direct answer could move R10 to `direct` or `adjacent` | Agreeing column definitions or freshness with analysts; GE checks analysts asked for; a process for announcing schema changes | A GE config, a schema doc, a dbt docs page, or a reviewed pull request for a breaking change | `[grounded]` CV silence; `[inferred]` that it affects fit on the mandate |
| G4 | BigQuery (R6, important) | transferability | Snowflake and dbt confirmed; BigQuery never used | The posting names BigQuery as the warehouse | A small dbt project on BigQuery against a public dataset | A repo link and short README | `[grounded]` your statement; `[generic]` that a small sample narrows this kind of limit |
| G5 | App and CRM ingestion (R9, important) | discovery | Sources your pipelines ingested aren't stated | Second named piece of the mandate | Pulling from a product database or event stream; syncing from a CRM or SaaS API | A DAG screenshot or pipeline diagram | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Company description not independently corroborated | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The stage and size are the company's own claims and no outside source was reached in this pass. Most companies of this kind are as they describe themselves | `[generic]` pattern, not a claim about this company | Which investors led the Series C, and how large is the data team today? | unresolved |
| RR2 | Posted pay sits inside the market range | positive_signal | — | "$148,000–$166,000 plus equity" | Nothing suggests a seniority-pay mismatch. The band spans from just under the report median to above its upper quartile | `[grounded]` JD figures; `[generic]` report figures as supplied by your recruiter | Where in the band would an offer for my experience typically land? | noted |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Grant size, vesting and strike aren't stated, so its value can't be judged | `[grounded]` JD silent on terms | What are the grant size, vesting terms and strike price? | unresolved |
| RR4 | Scope breadth and team unknown | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | One engineer may own the whole reporting stack, broader than the single-domain scope the report calls typical. Or a team may sit around the role | `[inferred]` from three named areas and no team size, against the `[generic]` report scope | Who else is on the data team, and which of ingestion, modelling and contracts would I own at the start? | unresolved |
| RR5 | On-call expectation unstated | unknown | — | "Build and run the pipelines" | "Run" may mean carrying on-call for pipelines. The posting doesn't say | `[inferred]` from the word "run" and the posting's silence | Is this role on call for pipeline failures, and how often? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dbt project you built on Snowflake (about 180 models), your Airflow orchestration, and the Great Expectations suite you set up | see R5, R7, R8 | `[grounded]` your background as typed | pending your approval |
| P2 | State the gap plainly if asked: "My warehouse experience is Snowflake; I haven't used BigQuery." | see R6 | `[grounded]` your "never used BigQuery" | pending your approval |
| W1 | Optional small dbt-on-BigQuery project as a work sample | see R6, G4 | `[grounded]` R6 row | pending your approval |
| Q1 | Ask the verification questions in RR1 and RR3 to RR5 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Settle R1 and R2 before investing in an application | see G1, G2 | `[grounded]` R1, R2 rows | pending your approval |

No resume was shared, so no resume edits are proposed.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search ("Pellucid Learning online tutoring Denver Series C $52M") was refused because search permission wasn't granted, so nothing came back. It would have tested stage, size and live posting against outside sources. I used your pasted text as given and carried the gap as RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and RR2, so a search could change neither |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I can write this up as a `tuesday-dossier.md` to carry into later steps if you'd like. Say so and I'll emit it.

**Upgrade menu**

- Search permission → target 1 runs; RR1 clears or tightens. After that, a deeper pass on funding and leadership changes can follow (up to 5 more searches and 2 more fetches) if you want it.
- Your location, authorization and pay floor → R1 and R2 close, and the decision either firms up or flips.
- Your resume → proposed edits for R3 to R8, since I can only work from typed background now.
- Artifacts (dbt docs or lineage screenshot, sanitized DAG, GE suite config) → R5, R7 and R8 can rise from `medium` toward `high`.
- A BigQuery project link → R6's limit narrows.
- The hiring manager's name → the scope read and which story the plan leads with.
- Employer answers on team, on-call and equity → RR3 to RR5 close.

**Questions**

G1 — Can you work from within the US, remotely or from Denver, without needing visa sponsorship?

G2 — What is the lowest base salary you would accept for this role?

G3 — Did you agree schemas, freshness or quality expectations with the analysts or teams who consumed your data? Who set them, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.