Checking Quillfield's own careers page to confirm the posting is live there, then I'll write up the assessment.
## Decision snapshot

**Yes, worth applying to, with two named stretches: R5 (forecast ownership) and R7 (billing data). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days)
- `must_have`: direct: R2a, R3 · adjacent: R4 (SQL and spreadsheet modelling), R5 (owning a forecast) · unclear: R2b (at a B2B software company), R6 (finance on billing or revenue data)
- `important`: direct: R8 · absent: R7 (Own billing data)

R5, R6 and R7 are where the two gaps you named land. R5 has adjacent work behind it, with its limit stated in the map.

**Opportunity ledger.** The employer matches its description (role reality) and the stated pay sits inside the market range I found (RR4). Three things are open: the posting is not yet confirmed on Quillfield's own site (RR1), the team and resourcing behind a "Lead" title are unstated (RR2), and no success measures are given (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days works for you (R1); (2) your forecast work is presented as adjacent, and the interview confirms Quillfield will take a first-time forecast owner (R5, RR2); (3) the interview confirms there is a ramp for billing data (R7, RR2); (4) the posting verifies as live with Quillfield (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` Quillfield's About page (search result) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; option terms unstated | `[grounded]` posting |
| First-year outcomes | None stated | `[grounded]` posting silence |
| Scope read | Finance-facing. The CFO and billing data are both named, and your two gaps sit in those parts | `[inferred]` from the posting naming the CFO and billing data |
| Market calibration | Ledgerline 2026 puts UK B2B software revenue operations leads at a median base of £64,200, interquartile range £57,800 to £70,400 (n=438). The posted range sits inside that range, near the median. It is a market band, not Quillfield's offer, and it is not Bristol-specific | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting for the range |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. You were told she is the hiring manager | `[grounded]` search-result snippet of her profile (page not opened); `[grounded]` recruiter, per you |
| Unknowns | Team size and reports; billing system; option terms; success measures | — |
| Contradictions | Posting and About page agree on the product. I tried Quillfield's careers page and it returned no page, which doesn't show the role is absent | `[grounded]` posting, About page, failed fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The posting states the terms. Your location and any limits on commuting were not given, so the gate is not established | `[grounded]` posting; `[grounded]` your silence on location | G4 |
| R2a | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. This is your own account, with no document inspected | `[grounded]` your background | A CV would confirm titles and dates |
| R2b | …at a B2B software company | must_have | unclear | low | discovery | You said B2B payments company. The posting says software company, and whether your employer's product counts is not stated | `[grounded]` your background; `[grounded]` posting | Tell me if your employer sells software; no question asked |
| R3 | HubSpot or Salesforce administration (and owning CRM data) | must_have | direct | medium | none | Salesforce admin certified, by your statement. The credential was not inspected. Ownership of the instance is not stated | `[grounded]` your background | A credential ID would raise this to `high` |
| R4 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily give frequency, not depth. "Strong" and "modelling" are the posting's words, not yours | `[grounded]` your background; `[grounded]` posting wording | A sanitized query or model would settle it |
| R5 | Experience owning a forecast; running the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | The adjacent work is the monthly pipeline review with your sales director. The limit is that finance owned the forecast, and no CFO-level session is stated | `[grounded]` your background | G1 |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue", so revenue data could count. Your renewal dashboards touch revenue figures, but their source and finance's involvement are not stated | `[grounded]` posting wording; `[grounded]` your background | G2 |
| R7 | Own billing data (a stated responsibility) | important | absent | none | capability | You confirmed you have never worked on billing data. I tiered this `important` because it is the second thing the posting says you will own, not a listed requirement | `[grounded]` your statement; `[inferred]` tier from the posting's order of duties | G3 |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt pipeline and renewal dashboards. Whether finance used them is not stated | `[grounded]` your background | Covered by G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5, must_have) | transferability | A monthly pipeline review with the sales director. Finance built the forecast | The posting makes the forecast a named duty with the CFO, so this is the likeliest probe | Producing the pipeline or commit numbers finance took into its forecast; reconciling the sales view against finance's; explaining a forecast miss | A sanitized pipeline-to-forecast sheet or review deck | `[grounded]` your account; `[generic]` that forecast ownership is the likeliest probe |
| G2 | Revenue data with finance (R6, must_have) | discovery | Renewal dashboards exist. Their data source and finance's use of them are unknown | The posting accepts "billing or revenue", so this may close R6 without billing experience | Renewal figures sourced from finance or a billing export; finance reviewing or signing off a dashboard; reconciling CRM renewals to invoiced revenue | A dashboard spec or data dictionary | `[grounded]` your account |
| G3 | Billing data (R7, important) | capability | No billing-data work, confirmed by you | It is a stated duty. The closure path is a ramp, not a rewording | Nothing on file; a self-study of the billing system is a path, once its name is known | Ask Quillfield which billing system and what ramp exists | `[grounded]` your statement |
| G4 | Location (R1, hard_gate) | hard_gate | Posting terms known; your side unknown | An unmet gate ends the process whatever the fit | n/a | n/a | `[grounded]` posting; `[grounded]` your silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Revenue Operations Lead, Quillfield" (Tallyboard Jobs) | The role may be live only on the job board, or the page I guessed was the wrong address | `[inferred]` from the failed careers-page fetch | Is this role open now, and who does the post report to? | unresolved |
| RR2 | "Lead" title with no team or support stated | unknown | — | "You will own our CRM and billing data… and run the quarterly revenue forecast with the CFO" | The role may be a one-person function carrying CRM, billing data, reporting and forecast together | `[inferred]` from the bundle of duties against silence on reports | Does the role have direct reports or analyst support, and what ramp is there on billing data? | unresolved |
| RR3 | No success measures | unknown | — | (posting is silent on first-year outcomes) | Accountability for the forecast may come without a stated definition of success | `[inferred]` from the posting's silence | What would a successful first year look like, and how is the forecast judged? | unresolved |
| RR4 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range sits near the market median for the title | `[grounded]` posting; `[generic]` Ledgerline band | What are the option terms: grant size, vesting, strike? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the pipeline and renewal dashboard rebuild and the Salesforce admin certification | R3, R8 | `[grounded]` your background | resume_edits_pending_approval |
| P1 | Describe your forecast involvement as it was: the monthly pipeline review with your sales director, with finance owning the forecast. Say what you would need to learn | R5; avoids claiming ownership | `[grounded]` your account | pending your approval |
| P2 | Say plainly that you have not worked on billing data, and ask what system and what ramp there is | R7, RR2 | `[grounded]` your statement | pending your approval |
| A1 | Ask the recruiter to confirm the role is open and where it reports (RR1), then use RR2–RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Tried quillfield.co.uk/careers, which returned no page. Role reality: the employer matches its description. RR1 opened |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Fed the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Only the snippet was read. It fed the role reality hiring manager row and changed nothing in the plan |

I can write up the whole assessment as a `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**
- Your CV: confirms titles and dates (R2a) and what your employer's product is (R2b).
- A credential ID for the Salesforce certification: R3 to `high`.
- A sanitized pipeline-to-forecast sheet or review deck: strengthens or limits R5.
- A dashboard spec showing where the renewal figures come from: could close R6 and R8.
- A sanitized SQL query or model: settles R4.
- Your pay floor and any other must-haves: makes pay and R1 checkable as gates.
- A deeper research pass on Quillfield (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**
- G4 — Is Bristol with two days a week in the office workable for you?
- G1 — Has any forecast number you produced fed into finance's forecast or been reconciled against it? What was yours, and what did finance own?
- G2 — Where did your renewal dashboard figures come from (CRM fields, a billing export, finance), and did finance use or review them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.