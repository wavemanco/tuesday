Building the tailoring ledger now. I worked from your CV text and the JD you pasted, and nothing is applied yet.

**Requirements I read from the JD (all five listed ones treated as must-have):** 5+ years backend, production Go, distributed systems at scale, strong incident response, and experience mentoring. The responsibilities add p99 latency work, on-call ownership and partnering with product on roadmap sequencing.

## Edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (current role) | "Go and Rust daily for 4 years, Python before that." | *(unchanged, moved above the services line)* | reorder | "Go and Rust daily for 4 years, Python before that." | [grounded] | pending your approval |
| E2 | Experience (current role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | compress | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | [grounded] | pending your approval |
| E3 | Experience (current role) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved directly below E2)* | reorder | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | [grounded] | pending your approval |
| E4 | Experience (current role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Line 1: "On-call rotation every fourth week for two years." Line 2: "Ran six incidents as incident commander." | split | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | [grounded] | pending your approval |
| E5 | Experience (current role) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | compress | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | [grounded] | pending your approval |

Notes on the choices:
- **E4:** splitting gives the JD's separate asks (on-call, incident response) a line each. The original sentence implied the six incidents fell inside the two on-call years, and your text doesn't say that, so the split drops the implication.
- **E5:** I kept "onboarding" and "pairing" and did not write "mentoring". I used "pairing with them", not "each", because "each" claims more than your sentence does.
- **E1:** I only have your text, not the layout, so "above the services line" assumes Go and Rust sit in or near the role entry. Tell me if that's wrong.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years backend | must-have | already_evidenced | "Senior Software Engineer, 7 years." plus the service ownership. The CV states 7 years but not 7 backend years, so expect a probe. No row needed. | [grounded] |
| M2 | Production Go, services at high request volume | must-have | surfaced_by_edit | E1 and E2. The CV doesn't say which of your three services run on Go (see M2 question). | [grounded] |
| M3 | Distributed systems at scale | must-have | not_evidenced | Adjacent only: ~40k requests/minute (E2), and Kafka and gRPC are listed as tools. Nothing states how your services interact. See C1. | [grounded] |
| M4 | Drive down p99 latency | must-have | surfaced_by_edit | E3. It's already strong as written; the edit only moves it up. | [grounded] |
| M5 | Strong incident response | must-have | surfaced_by_edit | E4, line 2 | [grounded] |
| M6 | Own on-call | must-have | surfaced_by_edit | E4, line 1. The CV doesn't say the rotation covers your three services. | [grounded] |
| M7 | Experience mentoring (the JD says mid-level engineers) | must-have | surfaced_by_edit | E5. Your CV describes onboarding and first-month pairing, and doesn't give the hires' level. | [grounded] |
| M8 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV. See C2. | [grounded] |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A 40k requests/minute service, three owned services in a pipeline, and Kafka and gRPC in the tools list. It doesn't say how the services communicate or what you designed. | The posting makes this a core requirement, and a tools list alone doesn't show it. | Service-to-service flow over Kafka or gRPC that you designed or changed; handling a slow or failed downstream service; retries or ordering in the ledger path; a consistency decision in ledger writes | An architecture or design doc, a throughput dashboard, an incident postmortem | [grounded] what the resume does and does not say; [generic] what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | No product-facing work appears. | The role pairs ownership with roadmap input, and the CV is silent on the second half. | Deciding with a PM which of two ledger-pipeline projects went first; trading reliability work against feature work in planning; giving input on a deadline | A planning doc, roadmap tickets, a design review where you weighed in | [grounded] what the resume does and does not say; [generic] what this costs on applications of this kind |

If C2 turns out to be nothing, I'll list it as a named absence. The JD names it as one responsibility among several, so it wouldn't sink the application.

## Not written, and why

- **"Senior Backend Engineer" as your title.** Your CV says Senior Software Engineer, and a title is a fact only you can change.
- **"Designed and shipped high-volume Go services."** You wrote "own". The CV doesn't say you designed them or which ones are in Go. That wording would be borrowed from the JD.
- **"Distributed systems at scale" or "built distributed systems."** Kafka and gRPC are tools you listed, and a tool listed is not a tool owned. "At scale" is the JD's judgement, not something your numbers state.
- **"Mentored mid-level engineers."** You described onboarding and pairing, and the hires' level isn't stated. That's a different kind of work.
- **"Partnered with product on roadmap sequencing."** Nothing on the CV supports it.
- **"Owned on-call for my services."** The CV says a rotation every fourth week. It doesn't say the rotation covers your three services.
- **"7 years of backend experience."** The CV states 7 years but not that they're backend.
- **Build-cache or developer-tools experience.** Your cache work is the balance-read path, a different system.
- **Incident outcomes such as MTTR gains or org-wide process changes.** None are in your text.

## Parse-safety check

You pasted text, so I could not run any layout checks: multi-column layout, tables or text boxes, images or skill bars, content in headers or footers, and file type. The section headings and contact details are also not visible to me. Send the file and I'll run them.

## Upgrade menu

- **Your CV as a .docx or text-layer PDF:** this lets me run the layout and heading checks above.
- **A design doc, architecture diagram or throughput dashboard for the ledger pipeline:** this is the inspectable proof for C1 and could support a stronger distributed-systems claim.
- **The p99 before/after dashboard or the PR for the cache rework:** this backs E3, which is currently your own word.
- **An incident postmortem you commanded:** this supports E4 with something a reviewer can read.
- **A planning doc or roadmap discussion you took part in:** this could close C2.
- **Earlier CV versions:** they may still hold lines the current one dropped.
- **Proposed addition, not written:** a short summary line built only from E1–E5. Say if you want it, and it will go through the same trace-and-approve step.

## Questions

M2 — Which of your three services run on Go, and is the 40k requests/minute service one of them?
C1 — How do your three services interact (Kafka, gRPC or something else), and which parts of that did you design or change?
C2 — Have you helped decide what product work got sequenced first, and can you give one example?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.