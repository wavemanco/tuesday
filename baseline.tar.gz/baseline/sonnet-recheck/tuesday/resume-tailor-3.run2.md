I'm still reading the playbook's audit and output rules, so the ledger will follow them. Then I'll build it.
I tailored Nadia's CV against the dossier and the posting. Nothing is applied yet. Every row below waits on your approval.

I only have your summary of the CV, not the CV itself. Each "Traces to" quote is your sentence from your message, so check it against the CV's wording. I carried over the dossier's `conditional_go` without changing it. The dossier's `role_profile` matches this posting, so I used it as is.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | Playbook authorship sits inside another line (the dossier's E1) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV, re-audited against it | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the third bullet, after the playbook)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved up to a visible skills line near the top)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |

- **E1** is the dossier's pending edit. I re-checked it against your sentence instead of copying it, and it holds as written.
- **E2** keeps "client" and does not become "partner". Your role was vendor-side, and the JD's word is a different relationship.
- **E3** keeps "collecting client feedback for product". Moving it up must not turn it into roadmap ownership, so I changed no words.
- **E4** only moves position. I did not turn "comfortable" into a stronger claim.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | not_evidenced | Dossier calls it adjacent (transferability, medium confidence). Integration leadership is adjacent, but you have never held a PM title and roadmap ownership isn't shown. See C1. | `[grounded]` your CV and the dossier |
| R2 | Shipped API or platform products | must-have | not_evidenced | Dossier calls it adjacent (medium confidence). You led integrations of APIs but are not shown shipping one. See C2. | `[grounded]` your CV and the dossier |
| R3 | Technical fluency | important | surfaced_by_edit | E4 and E2 | `[grounded]` your CV |
| R4 | Stakeholder management | important | surfaced_by_edit | E2 and E3 show client-facing delivery and structured client input. | `[grounded]` your CV |
| R5 | Discovery with integration partners | important | surfaced_by_edit | E3 is the nearest evidence, but your sessions were with clients, not integration partners. | `[grounded]` your CV |
| R6 | Write specs and drive delivery with two engineering squads | important | not_evidenced | No spec-writing or squad delivery shown. See C3. | `[grounded]` your CV |
| R7 | Define adoption metrics | important | not_evidenced | No metrics work shown. See C3. | `[grounded]` your CV |

## Recovery per gap

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership and prioritisation authority (R1) | must-have | You collected client feedback for product, which feeds a roadmap but doesn't set one. | The dossier flagged this as the unproven part of the PM-years requirement. | A request you escalated that shipped; a trade-off you argued between clients; a standing seat in product planning | A planning doc, a ticket thread, a release note | `[grounded]` what your CV says; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform product (R2) | must-have | You led integrations of APIs your employer shipped, with no stated role in shipping them. | A screener reading "shipped" will look for your part in a release. | A feature you specced or beta-tested with clients; an API change you drove; internal tooling other teams adopted | Release notes, a changelog, an OpenAPI spec you wrote | `[grounded]` what your CV says; `[generic]` what this costs on applications of this kind |
| C3 | Specs, squad delivery and adoption metrics (R6, R7) | important | Only OpenAPI familiarity and the playbook, with no delivery or metrics lines. | Two squads and adoption metrics are named duties. | A spec or requirements doc you wrote; an adoption or time-to-integrate figure you tracked for integrations | A spec, a dashboard, a metrics summary | `[grounded]` what your CV says; `[generic]` what this costs on applications of this kind |

## Not written, and why

- **"3+ years product management" or any PM title.** You never held the title, and the JD makes it a must-have. I left your title as "solutions engineer / implementation lead".
- **"Owned the roadmap" or "prioritised".** You gathered input for product. The dossier says prioritisation authority is not evidenced.
- **"Shipped API products" or "launched APIs".** You integrated clients onto APIs. That is a different side of the work.
- **"Partner discovery" or "partner-facing".** These are the JD's words, and your sessions were with clients.
- **"Defined adoption metrics" and "drove delivery with engineering squads".** Nothing in your CV supports either.
- **Internal request-triage tool.** This is a dossier rejected inference: it was a memory lead, and you couldn't confirm you owned it.
- **"Customer of a partner API platform".** This is a dossier rejected inference: you worked vendor-side, so it is the wrong side of the table.

## Parse-safety

I have no CV file, only prose, so I couldn't check layout, columns, headers or fonts. The edits above only reorder and surface existing text and add no hidden or unusual formatting.

## Upgrade menu (offered, not started)

- Your actual CV file, so I can quote it verbatim and check parsing.
- Earlier CV versions, which may hold lines the current one dropped.
- A sample spec, OpenAPI file or the playbook, which could turn C2 and C3 into real rows.

## Questions

C1 — Did you ever take a client request into product planning and see it prioritised, shipped or declined? What was your part?
C2 — Did you contribute to any API feature or change that shipped, such as a spec, a beta with clients or a change request? Which one?
C3 — Did you write a spec or requirements doc for engineers, or track any integration adoption or time-to-go-live figures?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.