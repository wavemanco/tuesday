Priya, here is the ledger. All I had was the CV text you pasted, so I treated it as your own account, not as verified. Every row below is pending your approval, and nothing is applied yet. Each proposal quotes your own sentence. I added no claims and used none of the JD's wording for your history.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV text | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV text | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV text | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV text | pending your approval |
| E5 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in our ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline" | `[grounded]` your CV text | pending your approval |

- **E2:** I left "Go" out of the services line. You said you use Go daily, but not that these three services are written in Go. If they are, tell me and I'll add it as a new row.
- **E3:** I did not write "owned on-call". Your sentence says you are on a rotation, and ownership of on-call for specific services would be a bigger claim.
- **E4:** I kept "usually" and did not write "mentored". Your sentence describes onboarding and pairing with new hires, and it doesn't say what level they were.
- **E5:** It is three separate sentences, not one clause. "Backend" appears nowhere in your text, so I didn't write it.
- **Not run:** I only had pasted text, so I couldn't check layout, headers and footers, or file type. Those need the actual file.
- **Not proposed:** I haven't seen your older roles or the full CV. Cut and reorder rows for those need the full document.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E5 states "7 years". Your text never says all 7 were backend, so "backend" is not claimed. | `[grounded]` your CV text |
| R2 | Production Go | must-have | `surfaced_by_edit` | E5 leads with "Go and Rust daily for 4 years". Whether the three services run Go is unconfirmed (question Q1). | `[grounded]` your CV text |
| R3 | Go services at high request volume | important | `surfaced_by_edit` | E2 carries the "about 40k requests/minute at peak" figure. | `[grounded]` your CV text |
| R4 | Distributed systems at scale | must-have | `not_evidenced` | Kafka and gRPC appear only in a tools list, and a listed tool is not a tool owned. See C1. | `[grounded]` your CV text |
| R5 | Drive down p99 latency | must-have | `surfaced_by_edit` | E1 moves it to the top. | `[grounded]` your CV text |
| R6 | Own services | must-have | `surfaced_by_edit` | E2 (and E5). | `[grounded]` your CV text |
| R7 | Strong incident response, on-call | must-have | `already_evidenced` | Already in your CV as written. E3 only tightens the wording. | `[grounded]` your CV text |
| R8 | Experience mentoring | must-have | `surfaced_by_edit` | E4 covers new-hire onboarding. The JD says mid-level engineers, and your text doesn't say what level your new hires were. | `[grounded]` your CV text |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your text. See C2. | `[grounded]` your CV text |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A 40k requests/minute service, and Kafka and gRPC in a tools list. Nothing says how the services coordinate, fail over, or handle consistency. | It is listed as a requirement, and a tools list alone doesn't show you built or ran a distributed system. | A Kafka consumer or producer you designed; a ledger-write path that had to stay consistent across services; a failure mode you diagnosed across service boundaries | An architecture doc, a design review, a postmortem | `[grounded]` what your text does and doesn't say; `[generic]` what a tools-list-only mention costs |
| C2 | Partner with product on roadmap sequencing | important | Nothing about working with product. | The JD names it as a duty of the role. | Pushing back on or reordering a planned feature for a technical reason; negotiating scope with a product manager; a migration you got prioritized | A roadmap doc, a planning thread, a ticket you reprioritized | `[grounded]` what your text says; `[generic]` that senior roles of this kind usually include it |

## Not written, and why

- **"Distributed systems at scale":** that is the JD's phrase, and your text doesn't support it yet (C1).
- **"Mentored mid-level engineers":** you described onboarding new hires, and nothing says their level.
- **"Owned on-call for my services":** you described a rotation.
- **"Go services" or "production Go services" for the ledger pipeline:** your text doesn't say which language the services use.
- **"7 years backend":** your text says 7 years as a software engineer.
- **"Designed and shipped" and "partnered with product":** these are the JD's verbs, and they don't appear in your history.

## Upgrade menu

- **Paste the full CV as a file or text.** This adds rows for your older roles and runs the parse-safety check.
- **Share the cache-layer rework or a postmortem.** This would show whether the p99 bullet can carry more of the distributed-systems requirement.

## Questions

Q1 (R2) — Which of your three ledger-pipeline services are written in Go, and are they all in production?
C1 — Did you design or own any part of how your services coordinate, such as a Kafka flow or a gRPC boundary, and what did it do?
C2 — Have you ever argued for, reordered, or scoped roadmap work with a product partner? What was it and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.