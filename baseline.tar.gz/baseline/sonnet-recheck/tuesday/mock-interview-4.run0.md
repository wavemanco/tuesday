Web search was refused, so I'm building the pack from your dossier alone. I'll write it to a file now.
I couldn't save the pack to a file or search the web, because both were declined. The full pack is below instead. Nothing here about Quartzline comes from outside your dossier.

One thing to know first: the dossier lists no weak-area entry for R2 ("Shipped API or platform products"), which is a must-have. I graded it myself as a discovery gap (F3, A3).

# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. The interviewer's name isn't given. I built this from your dossier (version 1.1).

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it scores: VAL (values), EXP (experience deep-dive), JD (role requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Every sentence about your past rests on a sentence quoted in the same row. Answer slots are instructions for the interview, not questions for you to answer now.
- Start with A1. The dossier named it as your most likely objection, so it gets the deepest rehearsal.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. Evidence is the dossier's `verified_candidate_evidence`, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy is bridge, positioned as adjacent and never as PM experience. Words: "I haven't held the product manager title." The source is the dossier's prohibited_claims item "Having held a product manager title or role". Then the adjacent case at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and I wrote the integration playbook my team uses." The limit, as the pack's observation: this is integration leadership, adjacent to the PM job and not the job itself |
| F2 | "3+ years product management experience" (roadmap and prioritization authority sub-claim) — dossier role_profile R1 | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)". Words: "I haven't owned a product roadmap." The source is the prohibited_claims item "Having owned a product roadmap". Then a ramp plan, said as a plan and never as a past. No bridge and no slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The dossier has no weak-area entry for this must-have, so this grading is the pack's own. The quote shows integrations of someone's REST APIs and doesn't show whether you built or released an API or platform product. Answer slot: if you had a hand in building or releasing one, say what and which part was yours, in your own words; if your work sat on the integration side only, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes show architecture work on REST integrations and a playbook. Neither names API docs or schemas. Answer slot: if you read or wrote API documentation or schemas as part of that work, say which and for what; if you did not, say so plainly and stay with the architecture stage and the playbook as quoted |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes reach customers and product, not engineering or sales counterparts. The roadmap-input quote is confirmed with limited inspectable proof, so expect a probe and volunteer the limit first. Answer slot: if you worked with engineering or sales counterparts, say with whom and on what; if not, say so plainly and stay with clients and product as quoted |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy is clarify. No verified entry speaks to this, so nothing about your past is scripted. Answer slot: "Agile delivery experience" is the likely probe. If you worked in an agile process, say how and in what role, in your own words; if you never worked that way, say so plainly. You may also say what you'd want to confirm about how this team defines it |

*Proposed language, pending your approval.*

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the title and roadmap gap, motivation, day-one weaknesses | **High.** Hiring-manager rounds lean Skeptic and Case, and your dossier names a specific objection (A1) | Rehearse A1 until it's boring. Bridge only from the quotes, name the limit, give a ramp plan |
| Case/Strategist | Live problems on the partner API platform and the two squads | **High.** Same relationship prior. The dossier's unknowns (decision authority, how adoption is measured) are what a case would surface | Clarify, then structure. Ask what decision rights you'd have before deciding anything |
| Data-Driven Prober | Asks how 30+ was counted and what's in the playbook | **Medium.** 30+ is the headline number and the playbook is your one inspectable artifact | Know how it was counted, say plainly where you don't, and name your weakest assumption first |
| Conversational | "Walk me through the journey", and a soft version of the objection | **Medium.** Almost every conversation opens this way, and it's scored | A 90-second arc built only from your quotes |
| Peer Evaluator | The seam with the two squad leads | **Low.** The interviewer is the hiring manager, but decision authority against the squad leads is an open unknown | Offer seam principles instead of pretending to know the seam |
| Pressure | Time-boxed "why you over a PM with the actual job" | **Low.** A1 can arrive in this packaging | Hold the core claim through two follow-ups, concede specifically |
| Values/Behavioral | Scenarios mapped to published values | **No bank.** No source documents a values round and Quartzline's values couldn't be retrieved | Not applicable this round |

The loop basis is your own description of this one session. Nothing establishes other rounds, so I applied no archetype tilt.

## Question banks

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] prohibited_claims: "Having held a product manager title or role"; acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | **The highest-ROI rehearsal in this pack, and the underwriter named it.** Three beats. One, concede first: "I haven't held the product manager title, and I haven't owned a product roadmap." Two, the adjacent case at the quotes' scope: you led 30+ end-to-end client integrations of the vendor's REST APIs from scoping through go-live, and wrote the playbook your team uses. Name the limit before it's asked: this is integration leadership, adjacent to the job and not the job. Three, a ramp plan in your own words, as a plan: what you'd learn first and from whom, such as the current roadmap and which decisions sit with the squad leads. Follow-up 2, "what would you own on day one": say you'd want to establish which decisions are yours and which are the squad leads', and claim no authority you haven't had. Follow-up 3, "a titled PM would ramp faster": concede on roadmap mechanics, then return to the two quotes without adding to them. Never say you've effectively done PM work, and never describe a prioritization call you didn't make | The dossier's named objection, aimed at F1 and F2. JD because it scores R1. Both the bridge and acknowledge_gap strategies bind here |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name the area your dossier records as having no evidence, in plain words: "I haven't owned a product roadmap." Then the ramp plan, as a plan. Don't reach for a bridge and don't name a strength to soften it | F2 is the one capability gap on file, so a direct weakness question lands there |
| A3 | "The role asks for shipped API or platform products. Where does your background meet that?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start with the quote at its own scope: the integrations you led, scoping through go-live. Answer slot: "Shipped API or platform products" is a must-have, so expect a probe on whether you built or released the API or platform itself. If you had a hand in that, say what and which part was yours; if your work sat on the integration side only, or the building wasn't yours, say so plainly and return to the integrations. Don't call the integrations shipped products | F3 is the must-have row the dossier doesn't grade, so it's the likeliest surprise |
| A4 | "Tell me about the quarterly roadmap-input sessions you ran. What happened with what you brought?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The beats the quote states: you ran the sessions, they were quarterly, they fed client evidence to product. This item has limited inspectable proof, so volunteer that: say what record exists, such as an agenda or notes, if one does. Answer slot: if you know what product did with any of that evidence, say what you know and how you know it; if you don't, or nothing came of it, say so plainly and stay with what you brought. Don't describe it as shaping the roadmap | F5 is the only product-side entry and is medium confidence, so a prober will test it. It is not coached as roadmap ownership, which the dossier prohibits |
| A5 | "What has your experience of agile delivery looked like?" | JD | [grounded] | Nothing about your past is scripted. Answer slot: "Agile delivery experience" is a preferred requirement and the likely probe. If you worked in an agile process, say how and in what role; if you never worked that way, say so plainly. You may then say what you'd want to confirm about how the squads here define it | F6 is a discovery gap and the strategy is clarify, so the guidance is a slot |

*Proposed language, pending your approval.*

### B. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A strategic partner says onboarding to your API is slow enough that they're evaluating alternatives. You have two squads and a quarter. What do you do first?" | CASE | [generic] | Clarify before structuring: which partner segment, what slow means to them, what's measured today. Then objective, options, a first move, how you'd know it worked, and the risk. No claim about your past | Hiring managers set live problems from their own roadmap. Generic because it's a role-family pattern |
| B2 | "How would you define and track adoption for a partner API platform?" | CASE | [generic] | Ask first how adoption is measured today and what the baseline is, since your dossier lists both as unknown. Then candidate definitions and what each would and wouldn't tell you. State the weakest assumption in your own proposal before they do | Adoption metrics are a listed responsibility with no stated baseline |
| B3 | "Two squad leads disagree about next quarter, and both have partner demand behind them. How do you decide?" | CASE | [generic] | Ask what decision rights the PM has before answering. Then the evidence you'd gather from both sides, the criteria you'd propose, and who has the final call. Forward-looking only: your material doesn't say you've set a squad's priorities | The role's authority question, made live. It tests the F2 gap through a scenario |
| B4 | "A partner's integration passes in sandbox and fails in production. Walk me through how you'd triage it with them and with engineering." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure it as reproduce, isolate, communicate, decide. You may point to the stages your quote states, UAT and go-live, as where you'd look first. Don't describe a specific incident unless one genuinely comes to mind that was yours | Plays to the integration side without asserting any past event (F4, F5) |
| B5 | "Sketch how you'd set the roadmap for this platform. What do you need to know first?" | CASE | [generic] | The answer is mostly the questions: partner segments, how adoption is measured today, which decisions are yours versus the squad leads', what each squad is already committed to. Say plainly you'd learn the current roadmap before changing anything | Exposes the roadmap gap (F2) honestly and turns it into diligence |

*Proposed language, pending your approval.*

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say 30+ integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words: how it was counted, what it's sensitive to, the assumption you'd defend least, and which parts were yours. If you don't know how something was counted, say so plainly | The headline number behind F1, F3, F4 and F5 |
| C2 | "Walk me through the integration playbook. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states: you wrote it and your team uses it. Describe what it covers in your own words. The dossier notes it was provided, so it's your one inspectable artifact; offer to walk through it. If a part was written by someone else, say so. Don't describe it as API documentation | The highest-confidence item behind F1 and F4 |
| C3 | "The role asks for fluency with API docs and schemas. Where have you worked with them?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start with the architecture stage your quote names. Answer slot: if you read or wrote API documentation or schemas, say which and for what; if your work sat above that level, say so plainly and return to the architecture work and the playbook as quoted | F4 is a discovery gap on an important requirement |

*Proposed language, pending your approval.*

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each a clause its quote states: the integrations, the playbook, the sessions. Your material gives no reason for the move into product, so that beat is yours to say in your own words. Name the PM gap in one sentence yourself, before they do | Every conversation opens here and it's scored (F1, F5) |
| D2 | "What draws you to partner-facing platform work in particular?" | JD | [generic] | Your material carries no stated reason, so pick one you can back with something you actually did. It needs a named piece of work, a concrete moment and an honest limit. If none comes to mind, say so plainly and give the nearest thing your material does carry | Motivation consistency is what this persona scores |
| D3 | "Is there anything about your background that worries you, or me?" | JD | [grounded] prohibited_claims: "Having held a product manager title or role"; acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | This is A1 in a softer register. Name the concern yourself using A1's structure: concede, adjacent case at the quotes' scope, name the limit, ramp plan. Don't let the casual tone loosen the claims | Rapport-style interviewers often ask for the objection directly (R1) |

*Proposed language, pending your approval.*

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our two squad leads each have their own view of the roadmap. How would you work with them from day one?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Propose seam principles: ask which decisions are theirs and which are yours, and agree where partner evidence enters planning. Say what you bring them, at the quote's scope: you've run sessions that fed client evidence to product. Don't claim to have set a squad's priorities | Decision authority against the squad leads is an open unknown (F2, F5) |
| E2 | "When a partner escalation competes with what a squad has committed to, how do you handle it with the lead?" | JD | [generic] | Principles, not an incident: get the facts, size the cost of the commitment, bring options to the lead, agree who decides. No past escalation unless one genuinely comes to mind that was yours | Tests disagreement style with equals |

*Proposed language, pending your approval.*

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] prohibited_claims: "Having held a product manager title or role"; acknowledge_gap area: "Owning a roadmap and prioritization authority (R1 sub-claim)"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Hold, then concede. Hold only what the quotes carry: you led 30+ integrations, scoping through go-live, and wrote the playbook. Hold through two follow-ups by returning to those quotes, never adding to them. Concede specifically: "I haven't held the product manager title, and I haven't owned a product roadmap." Pause and restate the question first | A1 in stress packaging, so the same limits bind (R1) |
| F2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Anchor in the quote: you ran the sessions. Answer slot: if some of the evidence or agenda came from colleagues, say which part and whose; if it was all yours, say so plainly. Volunteer the limit on inspectable proof. Hold through two follow-ups without enlarging what the sessions achieved | Attribution pressure on the one medium-confidence item (F5) |

*Proposed language, pending your approval.*

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, D3, F1 |
| R1 sub-claim: roadmap and prioritization authority | A1, A2, B3, B5, E1, F1 |
| R2: Shipped API or platform products | A3 |
| R3: Technical fluency: API docs, schemas | B4, C2, C3 |
| R4: Stakeholder management across engineering, sales, customers | A4, B3, E1, E2, F2 |
| R5: Agile delivery experience | A5 |
| Responsibility: define and track adoption metrics | B2, B5 |

There are no CO questions. Quartzline's strategy couldn't be researched, and a company-knowledge question written without research would be generic.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Your dossier lists decision authority as asserted but not evidenced. It reads as diligence, and you need the answer before accepting |
| 2 | "How is partner API adoption measured today, and what's the current baseline?" | The dossier names adoption as a responsibility with no stated baseline. The answer tells you what success is judged against |
| 3 | "How does partner feedback reach the two squads today, and where does it get stuck?" | Invites the manager to describe the seam you'd work in, with no claim about your past |
| 4 | "You're hiring someone who hasn't held the PM title. What would you want to see in the first months to be confident in that decision?" | Turns the objection into criteria in the interviewer's own words and shows you heard it |
| 5 | "What would a good first quarter look like for the person in this seat?" | A standard question that gets you the success definition. Rapport-style interviewers weight this slot as a preparation signal |

## Prohibited claims

Built before the banks. These bind every guidance cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims: "Having held a product manager title or role" | The plain acknowledgment: "I haven't held the product manager title." Then the quotes at their own scope. No slot |
| Having owned a product roadmap | Dossier prohibited_claims: "Having owned a product roadmap" | The plain acknowledgment: "I haven't owned a product roadmap." The roadmap-input quote stays at its own scope and is never offered as ownership |
| Having set prioritization for an engineering squad | Dossier prohibited_claims: "Having set prioritization for an engineering squad" | Forward-looking answers only (B3, E1). No past prioritization call is described |
| Shipped or released API or platform products | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material shows integrations of the vendor's REST APIs, not shipping an API |
| Shaped or influenced the roadmap through the sessions | Inflated form of F5 | F5's quote at its own scope: you ran the sessions, and they fed client evidence to product |
| Wrote API documentation or schemas | Inflated form of F4 | F4's playbook quote at its own scope: an internal integration playbook |

## Sources

**Provided documents:** `tuesday-dossier.md`, dossier_version 1.1. Sections consumed: `role_profile` and `handoff_to_mock_interview`. The `decision` section was read as context only. Your message supplied the round type, relationship and length.

**Searches sent, all refused:** "Quartzline company values"; "Quartzline interview process product manager"; "Quartzline partner API platform strategy news".

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet and VAL questions. Neither exists in this pack |
| 2. `Quartzline interview process product manager` | unavailable | Would have named the loop's rounds. Persona weights rest on the relationship prior and your description of the session |
| 3. `Quartzline strategy` / recent news | unavailable | Would have supported CO questions. The pack has none |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements the fit snapshot and JD questions use |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Web search enabled, or Quartzline's values and strategy pages pasted → CO questions, the loop structure, a values cheat sheet if a values round is documented, and the generic case rows (B1 to B3, B5) grounded in what Quartzline publishes
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief behind the case questions; offered once
- Recruiter guidance (focus areas, any announced deliverable) → coverage tuned to what they say will be tested, and a build section for any take-home or presentation
- Your answers to the slots on F3, F4, F5 and F6 → those rows move from discovery toward grounded, and A3, A5, C3 and E1 become story-mapped
- The agenda or notes from one quarterly roadmap-input session → the artifact that would lift that item from medium toward high confidence
- The raw CV behind the confirmed claims → further story beats, each quoted
- Hours available before Thursday → a prioritized prep schedule sized to them

I can play the Skeptic on A1 now, since the pack names it as your highest-ROI prep.
I can also record what this prep exposed in your dossier, starting with R2 having no weak-area entry. That would go in a `pack_feedback` section.
If you want the pack as a Word document or saved as a file, say so and I'll try again.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.