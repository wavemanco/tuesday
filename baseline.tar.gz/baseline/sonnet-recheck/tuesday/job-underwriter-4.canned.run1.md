Four searches are done, and one result contradicts the JD. The careers page lists the role as Leeds office four days a week, not fully remote. I'm fetching that page now to confirm.
**Not yet. The posting contradicts itself on remote versus Leeds (R1), and that answer decides whether this role is worth applying to. Status: `hold_pending_answers`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: direct: R7a · unclear: R7b (Recommendations to product)
- `preferred`: direct: R8 · absent: R9 (Pet-insurance domain knowledge)

R1 decides the next step, and R7b and R9 are where the case needs work.

**Opportunity ledger.** The JD and the company's own careers page disagree on working pattern (RR1) and the salary is withheld (RR2). Two entries run the other way: the hiring manager has a public record on rating-model monitoring (RR3), and the careers page shows the posting is live (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the hold waits on two answers. (1) Which working pattern is real, remote or Leeds four days a week (R1, RR1). (2) Whether you can work that pattern (R1). If it resolves in your favour, the status likely moves to `conditional_go` or `go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, pet-insurance product; the careers page lists the role as "Accepting applications" | `[grounded]` JD and careers page. Company stage and size are not established |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reports to | Director of Pricing (Odile Varga) | `[grounded]` JD and careers page |
| Working pattern | JD says fully remote (UK). Careers page says Leeds office, four days a week | `[grounded]` both sources, in conflict |
| Scope read | An individual-contributor ownership role. No direct reports are mentioned | `[inferred]` from the JD's silence on management |
| Market calibration | £52,100–£64,900 interquartile range for senior pricing analysts at UK insurers and insurtechs, median £58,400. The posting withholds salary, so this is the expected band and not Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 survey (search result text; page not fetched, not pet-specific); `[grounded]` JD for the withheld salary |
| Unknowns | Salary, team size, who the product counterpart is, first-year outcomes | `[grounded]` JD silence |
| Contradictions | Remote versus Leeds four days a week (R1, RR1) | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Confidence grades your own statement of a constraint, and you gave none. Fit is unclear because the JD and the careers page disagree on the working pattern | `[grounded]` JD and careers page; no candidate constraint stated | Closing question on G1; employer question in RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer. Specific, but nothing inspectable yet | `[grounded]` your background statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Specific, with no inspectable artifact | `[grounded]` your background statement | none |
| R4 | GLM experience (the JD pairs it with "build and monitor rating models") | must_have | direct | medium | none | You state building and maintaining the GLM rating model for the young-driver book. "Maintained" is your word. Monitoring is not stated, so it is not carried | `[grounded]` your background statement | Upgrade menu: a monitoring account |
| R5 | Design and read price tests | must_have | direct | medium | discovery | You state running 14 price tests last year with the underwriting team. Whether you designed them or ran and read them is not stated. Per the audit's downward rule, it is carried as run | `[grounded]` your background statement | Closing question on G2 |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You state presenting the quarterly pricing review to the head of underwriting | `[grounded]` your background statement | none |
| R7a | Turn results into recommendations for underwriting | important | direct | medium | none | The 14 tests were run with underwriting and the quarterly review goes to its head. Whether the tests produced recommendations is implied but not stated | `[grounded]` your background statement | none |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product audience | `[grounded]` background silence | Closing question on G3 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background statement | none |
| R9 | Pet-insurance domain knowledge (not required by the JD; the JD names only "insurance experience a plus") | preferred | absent | none | capability | You confirm no pet-insurance work. Motor GLM work carries over as method, not as domain knowledge. Pet-specific rating factors are untested in your history | `[inferred]` from the product named in the JD against your stated history; `[generic]` that the method carries over | Name the limit honestly (plan A3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | JD says fully remote. Careers page says Leeds four days a week. Your location and constraints are not given | A term you either meet or don't; it decides whether this is worth applying to | Not applicable, since this is a term and not experience | The employer's written confirmation of the working pattern | `[grounded]` the two sources; `[inferred]` that it decides the status |
| G2 | Price-test ownership (R5, must_have) | discovery | 14 tests run with underwriting. Design versus run-and-read is not stated | The role says "design and read" price tests, so the split decides whether R5 stays at the same strength | Choosing test and control groups, setting sample size or duration, defining the success measure, reading results, the call that followed | A test plan, a results readout or a decision note (sanitized) | `[grounded]` background wording; `[generic]` that roles like this probe design |
| G3 | Product-side recommendations (R7b, important) | discovery | Underwriting is the only audience mentioned | The JD names product alongside underwriting as a recipient | A price change that went to a product or commercial owner, a pricing paper for a product launch, a proposition review | A recommendation paper or deck (sanitized) | `[grounded]` background silence |
| G4 | Pet-insurance domain (R9, preferred) | capability | No pet work | A preferred row; the objection to expect and answer | Closure path: read pet-insurance rating factors before the loop, and frame motor GLM as the transferable method with its limit stated | A short note on how your young-driver model's factor structure would map to pet risk | `[inferred]` closure path; `[generic]` that this is the likely objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale or the arrangement may have changed; it may also be hybrid-by-practice | `[grounded]` the two quotes conflict; `[generic]` that stale copies are a common cause | Is this role fully remote, or is it Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | JD gives no figure | May sit inside or outside the expected band, or the company may not publish salaries | `[inferred]` from the missing figure against the `[generic]` band | What is the salary range for this post? | unresolved |
| RR3 | Hiring manager has a public record on monitoring rating models | positive_signal | — | Search result: talk "Small Books, Loud Errors" at the 2025 Insurance Pricing Forum; previously head of pricing analytics at Calloway Re for six years | The role's "build and monitor rating models" is likely central to how she judges candidates | `[grounded]` search result text (page not fetched); `[inferred]` the link to this role | How do you currently monitor rating models on a book this size? | noted |
| RR4 | Little footprint beyond the careers page | risk_signal | low | Company-name search returned no results; the careers page confirms the posting | The company may simply be small; the posting itself is live | `[grounded]` the empty search and the live page; `[generic]` that small insurtechs often have thin footprints | What stage is the company at, and how large is the pricing team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern in writing before investing in the application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with two of your own sentences: "built and maintained the GLM rating model for our young-driver book" and "ran 14 price tests last year with the underwriting team". Do not say "monitored" or "designed" until G2 and the R4 monitoring detail are confirmed | see R4, R5; per the reframing audit, "monitor" and "design" are the JD's words, not yours | `[grounded]` your background statement | pending your approval |
| A3 | Frame the pet gap plainly: "I haven't worked on pet insurance; my GLM work is on a motor book" | see R9 | `[grounded]` your statement | pending your approval |
| A4 | Ask the RR1, RR2 and RR4 questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Role reality's contradictions row and R1; the posting is live; the company's stage and size stay not established (RR4) |
| 2. Role-family sweep | yes | Searched "Senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Market calibration, from the result's text only |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). RR3 and A2's positioning |

I can build this into `tuesday-dossier.md` if you want to keep it or reuse it later.

## Upgrade menu

- The employer's written working pattern → R1 and RR1 close, and the decision simplifies.
- Your location and whether you could do Leeds four days a week → R1 resolves on your side.
- A test plan or readout (sanitized) → R5 firms up and the design-versus-run question closes.
- An account of how you monitored the young-driver GLM in production (actual-versus-expected checks, drift) → R4's monitoring detail firms up, and it gives you the lead story for Odile's published interest.
- A deeper research pass on Brindlemoor (funding, leadership changes, news; up to 5 more searches and 2 more fetches) → RR4 gets a real answer. Say the word and it runs.

## Questions

G1 — Where are you based, and could you work from a Leeds office four days a week if that turns out to be the real arrangement?
G2 — On the 14 price tests, which parts did you personally own: designing them, running them, or reading the results? What did the underwriting team change as a result?
G3 — Have you made a pricing recommendation that went to a product or commercial owner, not only to underwriting? What was it and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.