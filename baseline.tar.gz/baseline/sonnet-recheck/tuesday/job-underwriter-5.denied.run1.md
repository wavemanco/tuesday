Checking whether Pellucid's careers posting is live and matches what you pasted. Then I'll write the assessment.
Yes, this is worth applying to. The status is `conditional_go`, and two checks come first.

Both research calls (one fetch of the careers page, one search) were refused for lack of permission. That means the employer check is unverified, which is why the status stops at `conditional_go`. Everything below rests on your pasted JD, company page, pay report and background.

## Decision snapshot

**Yes, worth applying to. Your six years, dbt, Airflow and Great Expectations line up with the must-haves (R3, R4, R5, R6, R7), and the pay is in the market band. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery) · unclear: R9 (Ingestion from our app and CRM), R10 (Data contracts our analysts depend on)

R8 (`medium`) has a credible bridge with its limit named, and R9 and R10 wait on your answers.

**Opportunity ledger.** The stated terms are sound: pay and scope sit inside the band your report gives (RR4, RR5). Three things are unknown: the hiring manager (RR2), the equity terms (RR3) and the first-year outcomes (RR6). RR1 is the standing unverified-employer entry, open because the check was refused.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor fit the posting's terms — R1, R2; (2) the posting is confirmed live on Pellucid's own careers page — RR1; (3) the BigQuery bridge is framed as adjacent, never as BigQuery experience — R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company page text you pasted, not independently verified (RR1) |
| Mandate | Build and run the pipelines behind the reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| Scope read | Ordinary senior scope: one function's pipelines, no direct reports named | `[inferred]` from the JD's mandate list and its silence on reports; `[generic]` that this matches the typical scope in your Datawright report |
| Market calibration | The report gives a base median of $151,000 and an interquartile range of $139,000–$163,500 for Senior Data Engineers at Series B–D companies (n=2,310). The posted low end is $3,000 under the median and the top end is $2,500 over the 75th percentile. "Senior" typically means 5–8 years, and the JD asks 5+ | `[generic]` the report your recruiter sent, no search run; `[grounded]` JD figures |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager, equity terms, success measures, independent confirmation the posting is live | `[grounded]` JD and your message |
| Contradictions | None between the JD and the company page text you pasted; the live pages were not read | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not stated where you are or whether you can work in the US, so nothing grades your constraint. The posting's terms are not settled for you either | `[grounded]` JD; no constraint given | Gate question G3 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given. The posted range itself sits in the market band (RR4) | `[grounded]` JD; no constraint given | Gate question G3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company clears 5+. It is a length requirement, not a gate, and is self-reported with nothing inspectable. Six years sits inside the 5–8 range the report calls typical for Senior | `[grounded]` your background; `[generic]` report's seniority range | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is the JD's word and you have not described depth, so expect a probe | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse; the BigQuery specifics are R8 | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. How much of it you owned is unstated, so the claim stays at that wording | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite | `[grounded]` your background | none |
| R8 | Warehouse in BigQuery | important | adjacent | medium | transferability | Bridge: your dbt modelling on Snowflake is the same kind of warehouse work. Limit: you have never used BigQuery, so its cost model and platform-specific dbt setup are untested by you. Strengthener: a small dbt-on-BigQuery project, offered in the plan | `[grounded]` your stated BigQuery gap; `[generic]` that warehouses differ in cost model and dbt configuration | Plan row A3 |
| R9 | Ingestion from the app and the CRM | important | unclear | none | discovery | Your background says nothing about ingestion sources, so there is nothing to grade either way | `[grounded]` background silence | Question G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Indirect context only: a Great Expectations suite tests data, but you have not described agreements with analyst consumers. Do not assume it counts | `[grounded]` background; `[generic]` that a test suite and a contract with consumers are different things | Question G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Nothing in your background on where your payroll pipelines pulled from | The mandate's first named duty, and the only row where the evidence could still move from unknown to direct | Loading product-database or event data into the warehouse; pulling a CRM or HR-system export; writing or configuring the loaders yourself | A DAG screenshot, an ingestion README, a source inventory | `[grounded]` background silence; `[inferred]` that ingestion is the first duty from the JD's ordering |
| G2 | Data contracts (R10, important) | discovery | A test suite is claimed; agreements with analysts are not | The JD says analysts depend on these contracts, so this is a named deliverable | Agreeing schemas or freshness expectations with analysts; dbt tests with a named owner and alert path; a process for announcing schema changes | A sanitized schema file, a runbook, a change-notice example | `[grounded]` JD wording; `[inferred]` that contract work may exist in your tests |
| G3 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The posting's terms are known; yours are not | Unmet gates cap the decision, and none can be checked without your terms | Not applicable; this is a yes-or-no on terms | None needed | `[grounded]` JD terms, no constraint stated |
| G4 | BigQuery (R8, important) | transferability | Snowflake dbt work, no BigQuery use | The likeliest objection to your application | Any BigQuery use, even in coursework or side work, if it exists | A small public dbt project on BigQuery | `[grounded]` your stated gap; `[generic]` that a named platform is a common screen |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees." | I could not read the live pages, so the posting and company facts rest on your copies. I put severity at low because both are the employer's own text and agree with each other | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager not named | unknown | — | "The posting names no hiring manager" (your note) | Reporting line and who the analysts' contracts serve are unknown | `[inferred]` from the posting's silence | Who would this role report to, and which analyst teams depend on its contracts? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "$148,000–$166,000 plus equity" | Equity is promised, but type, size and vesting are not given | `[grounded]` JD states equity and nothing more | What is the equity grant for this level: type, size, vesting? | unresolved |
| RR4 | Pay stated and in the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The range overlaps the report's interquartile range; the low end is just under its median | `[grounded]` JD figures; `[generic]` the report, which covers Series B–D companies, not this employer | Where in the range would my experience be placed? | noted |
| RR5 | Scope and seniority match the title | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting"; "5+ years" | One function's pipelines with no reports named, as the report describes the usual remit | `[grounded]` JD; `[generic]` the report's typical scope | Which pipelines would I own in the first quarter? | noted |
| RR6 | First-year outcomes not stated | unknown | — | "Build and run the pipelines" (no success measures follow) | A demanding mandate with no stated definition of success | `[inferred]` from the JD's silence | What should be delivered by month twelve? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up | R5, R7 are `direct` | `[grounded]` your background | pending your approval |
| A2 | Name the BigQuery gap yourself and present your Snowflake dbt work as adjacent, not as BigQuery experience | R8, with the limit stated | `[grounded]` your stated gap | pending your approval |
| A3 | Optional: a small public dbt project on BigQuery as a work sample. It would show tooling basics only, not production scale | Narrows R8's limit | `[inferred]` from R8's stated limit | pending your approval |
| A4 | Before applying, open the posting on Pellucid's own careers page and confirm it still reads "Accepting applications" | RR1 | `[grounded]` RR1 | pending your approval |
| A5 | In a recruiter or manager conversation, ask RR2, RR3 and RR6's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One fetch of pellucidlearning.com/careers/senior-data-engineer and one search ("Pellucid Learning online tutoring K-12 Series C Denver") were both refused, so nothing came back. They would have moved role reality's contradictions row and RR1, which is why the status is capped |
| 2. Role-family sweep | skipped | Your Datawright report is in hand and fixes the market calibration line and the RR4 and RR5 comparisons |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

I can write all of this up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Permission for me to read Pellucid's careers and about pages: RR1 can clear, and the status can move toward `go`. A deeper pass later would add up to 5 more searches and 2 more fetches.
- Your location, US work authorization and pay floor: R1 and R2 resolve, and the hard-gates line becomes a real check.
- Answers on ingestion and data contracts: R9 and R10 can move to `direct`.
- A sanitized dbt docs page, DAG screenshot or Great Expectations config: R3 to R7 can rise from `medium` toward `high`, because a repository or docs site is the inspectable proof in this field.
- The hiring manager's name, once you have it: the scope read and A1's lead story get checked against that reader.

## Questions

G3 — Does the posting's location and pay fit you: are you US-based with work authorization (remote, or willing to be in Denver), and is $148,000–$166,000 at or above your floor?

G1 — Where did your payroll pipelines pull data from, and did you build the ingestion yourself? Name the sources, what you owned and what the team owned.

G2 — Did you agree schemas, freshness or test expectations with the analysts who used your models? If so, what did you own and how were changes announced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.