I tailored your CV to the Tessellate role, and nothing is applied yet. I worked from your CV as you typed it. I haven't seen the file, so every quote below comes from your message. Each row is pending your approval, and you can approve them one by one.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line shown)* | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years"; "Currently at a payments company"; "Go and Rust daily for 4 years, Python before that" | `[grounded]` your CV sentences, kept as three separate claims | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak" | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak" | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer" | *(unchanged, moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer" | `[grounded]` your CV | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander" | Two lines: "On-call rotation every fourth week for two years" and "Ran six incidents as incident commander", placed third | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander" | `[grounded]` your CV; the split stops "six incidents" from implying they all fell inside the two years | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month" | *(unchanged, moved to the fourth bullet)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month" | `[grounded]` your CV | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "gRPC, Kafka, Postgres, Datadog, Terraform" | `reorder` | "Kafka, Postgres, Terraform, gRPC, Datadog" | `[grounded]` your CV; the tools are the same, only the order changes | pending your approval |

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | `already_evidenced` | "Senior Software Engineer, 7 years" already says it; E1 keeps it in the first line. Your sentence says "software", and the ledger services are what make it backend. | `[grounded]` your CV |
| 2 | Production Go | must-have | `surfaced_by_edit` | E1 (Go daily for 4 years) and E2 (services you own, 40k requests/minute) | `[grounded]` your CV |
| 3 | Distributed systems at scale | must-have | `not_evidenced` | E2 covers volume only. Kafka and gRPC are in your tools list, but nothing says what they do in your services. See C1. | `[grounded]` your CV |
| 4 | Drive down p99 latency | important | `surfaced_by_edit` | E3 | `[grounded]` your CV |
| 5 | Incident response and on-call | must-have | `surfaced_by_edit` | E4 | `[grounded]` your CV |
| 6 | Mentoring mid-level engineers | must-have | `surfaced_by_edit` | E5 supports onboarding and pairing with new hires. Their level isn't stated, so the "mid-level" half is open (question on row 6). | `[grounded]` your CV |
| 7 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material touches it. See C2. | `[grounded]` your CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | 40k requests/minute at peak and three services in a pipeline. Kafka and gRPC appear only as tool names. | The posting lists it as a requirement, and your resume doesn't yet show what is distributed or how. | A service consuming or producing ledger events over Kafka; one of your services calling another over gRPC; handling retries or duplicate messages on a payment path | An architecture diagram, a design doc, a runbook, or a Datadog dashboard for the pipeline | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Technical ownership and latency work only | The posting names it as a responsibility, and your resume has no product-facing line. | Agreeing with a product manager to schedule the cache rework ahead of feature work; pushing back on a deadline; giving planning input for a quarter | A planning doc, a ticket thread, or an RFC with your name on it | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Not written, and why

- "Designed and shipped Go services": your word is "own", and the posting's verb is different. Owning a service and designing it are different claims.
- "Distributed systems experience" or "built on Kafka and gRPC": a listed tool is not an owned one, and 40k requests/minute shows volume, not distribution.
- "Mentored mid-level engineers": you onboard and pair with new hires, and their level isn't stated. "Mentored" is the posting's word, not yours.
- "Owned on-call for my services": you said you're on a rotation every fourth week. Whether it covers only your three services isn't stated.
- "Built-cache" or "build-cache" experience: your cache layer is on a balance-read path in payments. The shared word "cache" doesn't make it the same work as Tessellate's product.
- "Partnered with product on the roadmap": there is no source sentence for it.

## Parse-safety check

You gave me pasted text, so I couldn't run any of the layout checks. That covers columns, tables and text boxes, images or skill bars, contact details in headers or footers, section headings and file type. If you send the file, I can run them. A `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

- **The CV as a `.docx` or PDF:** I could run the parse-safety check and quote your exact wording instead of your typed version.
- **A pipeline diagram, design doc or Datadog dashboard:** this could turn C1 from `not_evidenced` into a real row.
- **A planning doc, ticket thread or RFC:** this could do the same for C2.
- **An earlier CV version:** it may hold roadmap or design work the current one dropped.

## Questions

C1 — In your ledger pipeline, which of your three services use Kafka or gRPC, and for what (for example consuming ledger events, or calling another service)?

C2 — Have you ever decided with a product manager what ships first, such as sequencing the cache rework against feature work? Even once counts.

Row 6 — When you pair with new hires, what level are they: mostly junior, mid-level, or it varies?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.