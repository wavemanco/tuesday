Search permission was denied, so I'm continuing without web research and using only your inputs. I'm writing the pack file now.
The write to the working directory was declined. I'll save the pack in the session scratchpad instead, which is set aside for working files.
Priya's prep pack for the Dan Kovac conversation is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-1-denied-ea349222/c34950e7-a4b9-4641-bb93-f42fdc5397fb/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 23 questions across seven personas, each with a question type, answer guidance and a rationale for inclusion and categorization. It also has a fit snapshot, a read of Dan, reverse questions, a list of claims not to coach, and a JD-requirement coverage table.

- **Web search and file write:** Web search was denied, so nothing about Northwind or Dan comes from outside what you gave me. Northwind's priorities, Compass and the bundling threat come from your research note, and Dan's profile from your description. The write to the working directory was also denied, so I saved the pack in the session scratchpad.
- **Persona weights:** The top two personas are the Peer Evaluator and the Data-Driven Prober, because of the peer round and Dan's "relentlessly data-driven" self-description. The Case questions lean toward pricing and packaging because of his monetization background.
- **Highest-ROI prep:** Question D1: "You haven't done classic sales-ops or quota-setting. How would you handle that here?" The pack has Priya state the gap plainly, point only to the volume-targets work she did describe, and give a ramp plan that doesn't claim a past.
- **No values cheat sheet:** Your account is a single conversation with a peer, so no values round is detected and I left it out. The two values-style questions use generic persona prompts instead.
- **Answer slots:** Where Priya's material is silent, the guidance asks her to answer in her own words and allows "that wasn't mine" or "I don't know how it was counted." That applies to the $400M figure, who ran the SQL analysis, and how the partner motion was designed.

I can run a live drill, playing a skeptical Dan on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two questions that would reshape the pack:
1. Did the recruiter name any focus areas or a pre-announced deliverable (a POV, a case, a presentation) for the Dan conversation? A deliverable would get its own build section, and focus areas would reweight the personas.
2. Can you paste the full JD? I worked from your highlights only, and any requirement they leave out has no question yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data — Senior GTM Strategy Lead, Emerging Products — Interview Pack

**Candidate:** Priya  |  **Interviewer:** Dan Kovac, Director of Sales Strategy (peer; both report to the same VP)  |  **Format:** one 60-minute conversation

Built on these assumptions: a peer round as you described it, requirements taken from your JD highlights (not the full JD), and your research note as the only source on Northwind's priorities. Web search was not available for this run, so nothing about Northwind or Dan comes from outside your inputs.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Answer guidance is scaffolding to rehearse from, not a script. Wherever guidance says "answer slot", it is an instruction for the interview: answer from your own experience in your own words, and either branch is a good answer.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the behavior asked about. No Northwind values were available, so VAL here follows persona stems |
| EXP | Work-experience deep-dive | Whether the CV claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company & strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy & ops, not go-to-market ownership, and the words stay there: "I spent two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops." Answer slot: the JD's line on owning GTM strategy makes a probe on go-to-market work likely. If any of your product-strategy work took a product to market, say which and what part was yours, in your own words. If none did, or it was not yours, say so plainly and stay with the product strategy & ops role |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Your material does not show which lifecycle stage the change touched. Answer slot (the figure): say how the number was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Answer slot (the JD line): if the change came out of finding whitespace, say how, in your own words. If it did not, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The words are the quote's: "I'm skilled in SQL and Tableau." The quote names tools and does not show independent analyses. Answer slot: the JD's "independent analysis" line makes a request for an example likely. If you ran an analysis end to end yourself, choose one and say what you pulled and what it fed, in your own words. If others did the query work, or there is no such example, say so plainly and say what you did do |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Your material says a revenue model, not the design of a motion. Answer slot: the JD asks for partner-motion design, so expect a probe. If any part of how the partner motion was designed was yours, say which and how you decided. If none was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | A CV-style line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I set annual volume targets with cross-org consensus." The quote says the consensus existed. It does not say how it was reached, and the words say no more |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | medium | [grounded] | discovery | The words are the quote's: "I use AI tools daily." Answer slot: the JD flags AI as a plus, and Compass is an AI launch, so a casual question on it is likely. Say which tools and what you use them for, in your own words. If the use is personal productivity only, say so plainly. Do not stretch it to building or launching AI products |
| F7 | Sales-ops and quota-setting fluency (role-family expectation; no JD line; unquoted) | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap you stated, so the words are yours: "I don't have classic sales-ops or quota-setting experience." After it, say how you would learn it, as a plan and never as a past. Your material says volume targets (F5), and the words do not call them quotas |

## Reading the interviewer

| Signal | Source | Implication | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Your note on his profile | Every number you give is likely to be probed to its inputs and assumptions, so B1 to B3 carry the most weight | [grounded] |
| Career spine is pricing and monetization roles | Your note on his profile | Cases tilt toward pricing, packaging and unit economics, so C2 and C3 are rehearsed in his vocabulary | [grounded] |
| One early-stage-startup chapter | Your note on his profile | Plausible probe on moving at a small team's pace after nine years at a large company. This is a reading of the profile, not a published fact about him | [inferred] |
| Peer reporting to the same VP | Your message | He is pricing what your hire costs and contributes to his own work, so reciprocity and seam principles matter more than selling yourself | [grounded] |
| Mirror opportunities | — | None offered. No quoted row carries a startup chapter or a pricing role on your side, and the pack does not invent a shared path | [grounded] |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting, "what do you need from me", credit and disagreement | Top. Peer round prior, and the same VP makes overlap real. 5 questions | Reciprocity first, seam principles rather than a claimed seam, and attribution in "we" for context and "I" for contribution. Rehearse A1 to A5 |
| B. Data-Driven Prober | Reads the numbers line by line and pushes to assumptions | Top. Peer prior plus his "relentlessly data-driven" self-description. 5 questions | Know what you can and cannot say about how each figure was counted, name your weakest assumption before he does, and offer to walk through one analysis end to end. Rehearse B1 to B5 |
| C. Case / Strategist | Live problems on Compass, bundling, and the three priorities | Mid. His pricing and monetization spine tilts cases toward packaging and unit economics. 3 questions | Clarify, then objective, segmentation, approach, metrics, risks, thinking aloud. Challenge one premise respectfully. Rehearse C1 to C3 |
| D. Skeptic | The sales-ops gap, the partner-motion gap, consumer to B2B | Mid-high. The JD highlights and your own stated gap give him ready material. 4 questions | Rehearse the most predictable objection until it is boring: D1, the highest-ROI prep in this pack. Calibrated candor over bluffing a competency he may own |
| E. Pressure / Stress | Time-boxed challenges, "how much was you" | Low. Nothing in the profile signals a stress style, but a peer can push on attribution. 2 questions | Pause, restate, hold through two follow-ups, then concede specifically. Rehearse E1 and E2 |
| F. Conversational / Rapport | The opening journey question and a casual AI question | Low as a persona and still scored. 2 questions | A 90-second arc built from your own sentences, and a prepared answer on AI |
| G. Values / Behavioral | Unpopular-truth and customer-over-metric prompts | Low. No values-style round was detected: your account is a single conversation with a peer. 2 questions | A story chosen with a named stake and an intact relationship, or the honest branch if none comes to mind |

## Question banks

Highest-ROI rehearsal in this pack: **D1** (the stated sales-ops and quota-setting gap). The sections below run in persona-weight order. Questions are shown as the interviewer would ask them.

### A. Peer Evaluator (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know the seam: who owns which decisions, shared definitions for the numbers you both use, and escalation to the VP you both report to. Say what you bring his team, not only what you need. This guidance makes no claim about your past | Peer-round stem, and it scores the JD's cross-functional line (F5). Tagged JD because it tests the stated cross-functional requirement, with Peer Evaluator delivery |
| A2 | "Tell me about a time you disagreed with someone in another org and how it resolved." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the beats are annual volume targets, across orgs, consensus, told in your own words. Answer slot: the JD's cross-functional line makes a probe on disagreement likely. If a disagreement arose along the way, say what it was and what you did. If there was none, or it was not yours, say so plainly and stay with the targets and the consensus | F5 is the only quoted cross-org evidence and the likeliest place a peer digs. EXP because it tests what was actually yours; open prompt from the Peer persona stem |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Principle first: "we" for context, "I" for contribution. Then keep your own contribution at the quote's scope: you proposed a change and it was credited with the uplift. Answer slot: if others built or shipped it, say what part each had, in your own words. If you do not know how credit was split, say so plainly | F2 is the largest credited claim and a peer will test its attribution. VAL because it scores behavior on credit, not a published Northwind value (none was available) |
| A4 | "What could you take off my plate in your first 90 days, and what would you need from my team?" | JD | [generic] | Reciprocity framing. Offer to take the analysis on the two new lines that no one has had time for, and name what you would need: access to account and pipeline data, shared metric definitions, and introductions. No claim about his workload | Peer prior: he is pricing what the hire costs him. Tagged JD because it tests the job's cross-functional scope, with reciprocity as the delivery |
| A5 | "Where do you think my team's approach to sales strategy is weakest for a new product?" | JD | [generic] | Do not critique what you cannot see. Ask what the team already tracks for new products and where he sees the gap himself, then offer a hypothesis labeled as one. Make no claim about your past | A standard peer trap: it tests disagreement style and turf awareness. JD because the answer must stay inside the role's remit |

### B. Data-Driven Prober (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot, four parts: how the number was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Say each in your own words. If you do not know how it was counted, say so plainly. Hold the quote's verbs: you proposed it and it was credited with the uplift | F2 is the headline metric and his self-description makes it the first probe. EXP because it tests whether the number survives scrutiny |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the assumption yourself before he does. The pack does not name it for you. If you know one, state it and what changes if it is wrong. If you do not know the assumptions, say so plainly and say what you would check first | Persona stem for the Prober. The weakest-assumption move turns a gotcha into a credibility gain. F2 again, one level deeper |
| B3 | "Walk me through the partner-level revenue model that was used in carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built it, it was partner-level and revenue-based, and it was used in carrier negotiations. Answer slot: the JD's independent-analysis line makes a probe on who did the analysis likely. If you ran parts of it yourself, say which parts, in your own words. If others did, or you do not know, say so plainly and stay with what you built | F4 is the strongest evidence for the partner requirement and a data-driven reader will want its inner workings. EXP because it tests what was actually built |
| B4 | "Say you had access to our account data. What SQL would you write first to find expansion whitespace?" | JD | [grounded] "skilled in SQL/Tableau" | Think aloud: define whitespace first, then the table grain, the joins, the metric, and the cut by land, adopt, expand and renew. Offer to walk through an analysis you ran yourself, if there is one. Keep the claim to the quote: you are skilled in SQL and Tableau | The JD names SQL and Tableau and his profile makes this the likeliest hands-on probe. JD because it scores the stated requirement, with CASE-style delivery |
| B5 | "What would you put on a one-page scorecard for each of land, adopt, expand and renew on a new product, and what would you refuse to measure?" | JD | [generic] | Pick one lead metric per stage, say what decision it feeds, and name one metric you would refuse and why. Make no claim about your past; this is a structure to rehearse aloud | Scores the JD's whitespace line across the lifecycle for a reader who thinks in metrics. JD because it tests the stated responsibility; the delivery is case-like |

### C. Case / Strategist (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. What do you need to know first to sketch its go-to-market?" | CASE | [grounded] | Clarify before structuring: who the first buyers are, what Compass replaces or sits beside, how it is sold (standalone, add-on or inside existing tiers), and what success means in 12 months. Compass is from your research note; nothing is claimed about your past | Your note names the Compass launch as a priority and the JD gives you two new product lines. CASE because it is a live problem with no past premise |
| C2 | "A much larger platform vendor bundles a capability in against us. How do you think about packaging and pricing the new lines?" | CASE | [grounded] | Clarify what is being bundled and who the buyer is, then walk the options: price against the bundle, differentiate on a dimension the bundle cannot match, or package so the bundle is a complement. Name the metric that would tell you which is working. The bundling threat is from your research note | His pricing and monetization spine makes this his native ground, and the threat is in your research note. CASE because it is a live strategy problem |
| C3 | "Enterprise expansion, Compass, profitability. Where do those pull against each other for the two new lines?" | CO | [grounded] | Name the tension plainly: expansion spends and profitability saves. Say how you would sequence, what you would ask first, and what evidence would change your mind. The three priorities are from your research note. Do not claim inside knowledge of Northwind's plans | Tests whether you can think at the company's altitude using its stated priorities. CO because it scores strategy fluency, not a case structure |

### D. Skeptic (weight: mid-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting. How would you handle that here?" | JD | [grounded] "No classic sales-ops or quota-setting experience" "set annual volume targets with cross-org consensus" | The highest-ROI prep. Say the plain acknowledgment first: "I don't have classic sales-ops or quota-setting experience." Then the nearest evidence at its own scope: "I set annual volume targets with cross-org consensus." Then a plan, said as a plan: ask the sales-ops team how targets and quotas are set today, and work alongside them before proposing changes. Follow-up one, "isn't that different from setting quotas?": hold, and concede specifically that your material says volume targets and not quotas. Follow-up two, "what would you get wrong first?": answer from the plan, not from a past. Never say or imply you have set quotas | F7 is your stated gap and the likeliest objection from a Director of Sales Strategy (inferred from his title). JD because it tests the role's expectation; Skeptic delivery |
| D2 | "You've spent nine years in consumer tech. Why B2B data infrastructure, and why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | State the career in the quote's words. Answer slot: why this move, in your own words. The pack does not supply your reasons. If your reason is partly about the company or the problem, say that. Do not claim B2B or sales experience your material does not show | Motivation consistency is the Skeptic's core test and F1 sets up the mismatch. JD because it scores fit for this specific role |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" "built a partner-level revenue model used in carrier negotiations" | Pick one honestly. The material points at sales-ops (F7) and partner-motion design (F4). Name it, say what you have that sits beside it at its own scope, and give a ramp plan. Calibrated candor beats bluffing a competency he may own | Persona stem for the Skeptic. JD because it scores the full requirement list, F1 included |
| D4 | "Partner-motion design is a stated requirement here. What have you designed, and what would you want to learn from us?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what you built, at the quote's scope: a partner-level revenue model used in carrier negotiations. Answer slot: if any part of the partner motion's design was yours, say which and how you decided. If none was, or it was not yours, say so plainly and name what you would want to learn | The one hard requirement your highlights flag as required. F4 is the only adjacent evidence, so a direct question is likely |

### E. Pressure / Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run sales ops for a new product?" | JD | [grounded] "No classic sales-ops or quota-setting experience" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | Pause and restate. Concede first, specifically: "I don't have classic sales-ops or quota-setting experience." Then hold on what the quotes carry: you built a partner-level revenue model used in carrier negotiations, and you set annual volume targets with cross-org consensus. Hold through two follow-ups by returning to those, not by adding to them | Time-boxed challenge on F7 with F4 and F5 as the held ground. JD because it tests fit for the stated role |
| E2 | "That ~$400M result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the quote's scope: you proposed the change and it was credited with the uplift. Answer slot: say which part was yours in your own words. If you do not know how the credit was assigned, or part of it was not yours, say so plainly. Do not fold on the core claim to restore harmony, and do not add to it | Persona stem for Pressure. EXP because it tests attribution under composure pressure; F2 again |

### F. Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quote states: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: the last beat, why this role, in your own words. The pack does not supply it | The opener is scored for economy and fit. F1 is the spine of your story. EXP because it checks the CV's shape |
| F2 | "What are you actually using AI for these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what for, in your own words, starting from "I use AI tools daily." If the use is personal productivity, say so plainly. Connect to Compass only as a question you would ask, not as a claim | The JD flags AI as a plus and a casual question on it is still scored (F6). JD because it tests that plus-skill |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior what they did not want to hear. It needs a named stake, what you actually said, and a relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem. No quoted sentence carries this story, so it is a scaffold, not a mapping. VAL because it scores past behavior |
| G2 | "When did you put a customer or a partner ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where a customer or partner outcome cost an internal number. It needs the metric named, the choice you made and the result. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide | Persona stem; ties to the partner emphasis in the JD highlights. A scaffold, since no quote carries a story here |

## Requirement coverage

| JD requirement (JD highlights) | Questions |
|---|---|
| "own GTM strategy for two new product lines" | D3, D2, C1, C2, C3, F1 |
| "identify whitespace across land/adopt/expand/renew" | B4, B5, C3 |
| "run independent analysis in SQL and Tableau" | B4, B3, B5 |
| "partner-motion design experience required" | D4, B3, D3, C2 |
| "strong cross-functional influence" | A1, A2, A3, A4, A5 |
| "AI experience a plus" | F2, C1 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your career has been mostly pricing and monetization, with a stint at an early-stage company. What did that chapter change about how you approach sales strategy?" | Tied to his own path, from the profile you described. It turns the interrogation into a peer conversation and shows you read about him | [grounded] |
| R2 | "How are you thinking about packaging and pricing the two new lines against a larger vendor's bundle?" | His pricing spine meets the threat in your research note, and he will have a real view | [grounded] |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for a peer: it shows you think about his load, not just your onboarding | [generic] |
| R4 | "How do you and our VP split decisions on the new lines: what's decided jointly, what's yours, what's mine?" | Surfaces the seam directly and signals you want it explicit rather than assumed | [generic] |
| R5 | "Which of the three priorities pulls hardest on GTM for these lines right now, and what does good look like in a year?" | Uses the priorities from your research note and invites him to rank them | [grounded] |
| R6 | "Where is visibility across land, adopt, expand and renew weakest today?" | A data-driven reader weights this heavily as a preparation signal | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has set sales quotas or has sales-ops experience | Negative you stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Volume targets (F5) are said at their own scope and never called quotas |
| Owned or designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model, not the design of a motion. D4's slot stays inside the model |
| Owned GTM for a product launch, or ran land/adopt/expand/renew | Inflated form of F1 and F2 | F1 and F2's quotes at their own scope. The material says product strategy & ops and a proposal, not go-to-market ownership |
| Drove or was solely responsible for the ~$400M ARR uplift | Inflated form of F2 | The quote's verbs: you proposed the change, and it was credited with the uplift. The slots ask only how it was counted and which part was yours |
| Built or led AI products | Inflated form of F6 | F6's quote: you use AI tools daily. The limit is the pack's observation: the material says use, not building |

## Sources

Provided documents: your message (JD highlights, candidate summary, interviewer profile description, research note).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Query sent | Outcome |
|---|---|
| Northwind Data company values principles | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Both calls to the search tool were refused. It would have named published values to theme G1 and G2. The values cheat sheet stays off regardless, since no values-style round is detected |
| 2. Northwind Data interview process, GTM strategy | skipped | Your words fix the loop: one 60-minute conversation with a peer. That fixes the persona weights and the values-round call |
| 3. Northwind Data strategy and recent news | unavailable | Search was not granted. It would have added recent moves to the CO and CASE bank (C1 to C3), which rest on your research note alone |
| 4. Dan Kovac, Northwind Data | unavailable | The search was refused. It would have added talks or writing to the interviewer read and to R1 |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six requirement rows now quote highlights; the full text would add any requirement the highlights omit and could add questions for it
- The recruiter's prep guidance (focus areas, any pre-declared deliverable) → a graded-deliverable build section if one exists, and persona weights tuned to what is flagged
- Your answers to the answer slots in F1 to F4 and F6 → each of those rows can move from a slot to a story-mapped answer, and B1 to B3 and D4 get sharper
- The analysis memo or readout behind the ~$400M figure → F2 can move from medium to high confidence, and B1 and B2 can be rehearsed against how it was actually counted
- Search access granted → Northwind's published values, loop reports and strategy news (L1), and Dan's public footprint, which would add to the interviewer read and R1
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, needs search access → a strategy brief to sharpen C1 to C3, and recent org context
- A tuesday-dossier.md from an earlier fit analysis → verified evidence and a prohibited-claims list from that analysis would replace the locally built list. Not required
