I'm tailoring your CV against the Quartzline posting, using your Tuesday dossier. I've built the edit ledger below. Nothing is applied until you approve rows.

I built this from your description of the CV, not the document itself. Where a "Current line" cell shows your sentence, I haven't seen its placement or surrounding wording. The dossier is for this same role, so I used it as is: R1 and R2 stay `adjacent` at `medium` confidence, and its pending edit E1 is carried in below after a fresh audit. Your CV has no PM title and the ledger doesn't invent one. Everything below is the nearest honest version of what you've done.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | Same sentence as its own line (dossier E1) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV; dossier E1 | pending your approval |
| E2 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor"; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to directly after the integrations bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | Same sentence as its own line near the top | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |

- **E2 keeps two sentences.** It states your actual title up front, so a reader never has to infer it. Joining the two into one clause would be a different claim.
- **E3 keeps "client" and "for product".** You collected input. Product owned the roadmap.
- **E4 keeps "Comfortable in".** A tool you're comfortable in is not a tool you own or a skill you've certified.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | No row can carry it. The dossier calls it adjacent: integration leadership is adjacent, and roadmap ownership and prioritisation authority are not evidenced. See C1. | `[grounded]` your "Never held a PM title."; dossier R1 |
| R2 | Shipped API or platform products | important | `not_evidenced` | E2 shows integrations of an existing API, not shipping the product. The dossier has this as adjacent. See C2. | `[grounded]` your CV; dossier R2 |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, E2 | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2, E3 | `[grounded]` your CV |
| R5 | Run discovery with integration partners | important | `not_evidenced` | E3 is the nearest evidence, shown in your own words. Those were client feedback sessions, not partner discovery. | `[grounded]` JD; your CV |
| R6 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | E4 shows OpenAPI spec literacy, which is not product specs or delivery ownership. See C3. | `[grounded]` JD; your CV |
| R7 | Define adoption metrics | important | `not_evidenced` | No row. | `[grounded]` JD; your CV |

## Gaps: what would close them

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM, roadmap ownership | must-have | Roadmap input (E3) but no decision authority, and no PM title | It's the posting's only stated must-have | A feature you decided to prioritise or deprioritise for clients; a roadmap trade-off you made or were consulted on | A roadmap doc, a decision memo, a client-facing release note | `[grounded]` your CV; dossier R1 |
| C2 | Shipped API products | important | 30+ client integrations of existing REST APIs | The JD asks for shipped API or platform products | An API feature or endpoint you helped define, test or launch; integration tooling you built for clients | A launch note, a changelog, a spec you authored | `[grounded]` your CV; dossier R2 |
| C3 | Specs and delivery with engineering squads | important | OpenAPI spec comfort only | The JD names this as core work | Requirements you handed to engineers for a client-driven fix or feature, and following it through to release | A ticket, a written requirement, a release thread | `[grounded]` your CV; JD |

- **Discovery with integration partners (R5).** You've done client-side feedback, not partner discovery. The path is to run a few structured partner or client discovery conversations, or a small written discovery study. For this role that may be worth doing before applying. I'd treat it as a gap to name in a cover note, not to paper over.
- **Adoption metrics (R7).** Nothing in your material touches this. It closes only if you've tracked usage or adoption of an API or feature, even informally, and have something to show for it.

## Parse-safety check

You gave me pasted text, not a file. I couldn't run the layout checks (columns, tables, text boxes, headers and footers, images, file type), so please check those in the actual document. The headings I'm proposing, Summary, Experience and Skills, are conventional.

## Not written, and why

- "Built an internal request-triage tool". This was a memory lead and you couldn't confirm ownership. It stays out per the dossier's rejected inferences.
- "Has been the customer of a partner API platform". You worked vendor-side, so this flips which side of the table you stood on. It stays out per the dossier's rejected inferences.
- "Product Manager" or "3+ years of product management". You never held the title, and it's the JD's must-have.
- "Owned the roadmap" or "prioritised the roadmap". You ran input sessions, and ownership is a different job.
- "Shipped API products". You led integrations of existing APIs, which is a different kind of work.
- "Ran discovery with integration partners". That's the JD's wording, and your sessions were with clients.
- "Wrote product specs" or "drove delivery with engineering squads". Your evidence is OpenAPI spec comfort only.
- "Defined adoption metrics". Nothing in your material supports it.

## Upgrade menu

- **The CV as a file.** This lets me run the real parse-safety check and quote your lines character for character.
- **Answers to C1–C3.** Each confirmed answer can become a grounded row.
- **Portfolio or work samples** (specs, release notes, playbook excerpts). These would make rows `[grounded]` in inspectable evidence and not just self-report.

## Questions

C1 — Have you ever made, or been asked to weigh in on, a call about what got built or dropped for clients, and what was your actual authority in it?
C2 — Did you ever help define or launch an API feature, endpoint or integration tool, as opposed to integrating existing ones?
C3 — Have you written requirements for engineers and followed them through to release?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.