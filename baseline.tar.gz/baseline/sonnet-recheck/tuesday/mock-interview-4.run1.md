Loading done. Running the default research pass on Quartzline now: values, interview process and strategy searches.
Web search wasn't permitted, so the pack is built from the dossier and your own words only. I'm writing it now and will label the research targets as unavailable.
The write to the working directory was refused. I'll save the pack to the session scratchpad instead, which is the designated place for files like this.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-4-denied-0e53284c/8da8cde1-a8d2-4158-9286-308e2e7feeaf/scratchpad/Quartzline_product-manager-platform-apis_interview_pack.md`. It has 22 questions, nine fit-snapshot rows, six reverse questions and a list of claims it won't coach.

Two permissions were refused, which shaped the pack:
- **Web search:** I sent three searches (values, interview process, strategy) and all were refused. The pack rests only on your dossier and your message. There is no company-values sheet and no company-strategy question, and the values bank is generic.
- **Saving to your working directory:** that write was refused too, so I saved the file in the session scratchpad instead.

I built it for a hiring-manager round, weighted toward live case questions and Skeptic probing. Recalibrate if you know the manager's style.

- **Highest-ROI rehearsal (B1):** the dossier's objection, "never held the PM title or owned a roadmap, why not a PM with three years of the actual job?" The pack gives you concede first, bridge with the limit stated, then a plan. It also scripts holding through two follow-ups.
- **Answer slots:** where your material is silent, the guidance is an instruction to answer in your own words, with an honest "that wasn't mine" branch. This covers the specs, adoption-metrics and agile rows.
- **R2 (shipped API or platform products):** this is a must-have, but the dossier doesn't list it among your weak areas. Your evidence is integrations of the vendor's APIs, so expect a probe on "shipped" (B3).
- **Roadmap-input sessions:** the dossier rates these medium confidence, so B5 and D2 coach you to volunteer the limit before the interviewer extracts it.

I can play the Skeptic on B1, the question the pack names as the highest-ROI prep, whenever you say.
I can save a `tuesday-dossier.md` recording the gaps this prep exposed, including the R2 observation, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes. Interviewer: not named. Built on the dossier you supplied and nothing researched (web search was not permitted, so company values, loop and strategy are absent, not guessed).

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment |
| EXP | Work-experience deep-dive: do the claims survive scrutiny |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: research did not run) |
| CASE | Live problem from the role, delivered on the spot |

The highest-ROI rehearsal is B1. The underwriter named that objection; its wording is theirs.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | The dossier's strategy for this area is bridge: adjacent work, positioned as adjacent and never as product-management experience. The limit stays attached, as `prohibited_claims: "Having held a product manager title or role"`. Words: "I haven't held a product manager title. I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live." No duration appears in any verified entry, so the pack supplies none; if asked how long, answer in your own words |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities; the dossier's R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this as an `uncertain_or_weak_areas` item with strategy acknowledge_gap and `prohibited_claims: "Having owned a product roadmap"`. No bridge is built here, because the underwriter found nothing to bridge from. Words: "I haven't owned a roadmap." Then a plan, said as a plan and never as a past: you would start by learning which decisions are yours and which belong to the squad leads |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Derived by this pack: your material says integrations of the vendor's APIs, not shipping an API or platform product. The dossier lists R2 as a high-priority requirement but not among its weak areas, so expect a probe here and treat this row as a lead for pack_feedback. Words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD's R2 line makes a probe on how far you took those integrations likely. Say which stages of the go-live path were yours, in your own words; if none were, or they were not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes touch REST APIs and architecture without showing API docs or schemas. Answer slot: R3 names API docs and schemas, so a probe on them is likely. If you read, wrote or worked from them in those integrations, say how, in your own words; if you did not, or someone else did, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes reach clients and product; they do not show engineering or sales. Answer slot: R4 lists three groups, so expect a probe on the two the quotes do not name. Say which of engineering and sales you worked with and how, in your own words; if you did not work with one of them, say so plainly and stay with the clients and product you did. The second quote is confirmed with limited inspectable proof, so expect a probe on it |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Dossier strategy for this area is clarify, and no verified entry speaks to it. Answer slot: the JD's wording is the probe. If you have delivered in sprint-based or similar cycles alongside engineers, say how and what part was yours, in your own words; if you never worked that way, say so plainly. Then say what you would want to confirm about how Quartzline defines it |
| F7 | "Run discovery with integration partners" — JD (dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | Confirmed, limited inspectable proof, so expect a probe, and volunteer the limit before it is extracted. The quote shows sessions and evidence fed to product; it does not show how the evidence was gathered. Answer slot: the JD's discovery line makes that probe likely. If you gathered it yourself, say how; if it came from elsewhere, or there was no set method, say so plainly and return to the sessions you ran |
| F8 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quote names requirements and architecture stages without showing whose pen wrote them. Answer slot: the JD's specs-and-delivery line makes a probe on those stages likely. Say which parts you wrote or drove, in your own words; if you did not write or drive them, say so plainly and stay with the stages you led |
| F9 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | none given | low | [grounded] | discovery | Nothing in the material shows metrics work. Answer slot: if you tracked how clients' integrations were adopted or used, say what was counted; if you never tracked it, say so plainly and say what you would measure first |

Proposed language above is pending your approval. Every first-person sentence rests on a quote in the evidence column or on the dossier field named in its own row.

## Persona table

Weights start from the relationship prior for a hiring-manager round (Case/Strategist and Skeptic dominant), adjusted by the dossier's named objection. No interviewer profile and no loop source beyond your own words exist, so there are no further adjustments. Your words establish one 45-minute session. Recalibrate if you know the manager's style.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case/Strategist | Live problems on the actual roadmap: plan, diagnose, decide | High: a hiring manager is buying capability, and the role's own responsibilities (roadmap, discovery, specs, adoption) make natural cases | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | A, 5 questions |
| Skeptic | Quiet, persistent probing of the title and roadmap gap | High: the prior says a hiring manager derisks gaps, and the underwriter named this objection from evidence you confirmed | Rehearse the single objection until it is boring; concede the limit before it is extracted | B, 5 questions |
| Data-Driven Prober | Reads your claims line by line, asks how the 30+ was counted | Medium: the headline figure and the playbook are inspectable targets | Know what you can and cannot say about how the figure was counted; say plainly when you do not know | C, 3 questions |
| Pressure | Time-boxes, questions authority, devil's advocate | Medium: the squad-authority gap invites a stress test of how you would hold a position | Pause, restate, hold through two follow-ups, concede specifically | D, 3 questions |
| Peer Evaluator | Where the PM seam with a squad lead sits | Low to medium: this is not a peer round, but the two squad leads are the peers you would work beside | Offer seam principles rather than pretending to know the seam; reciprocity | E, 2 questions |
| Conversational | Friendly opener, casual probes on JD topics | Low: a 45-minute hiring-manager round usually opens this way, and casual questions are still scored | A 90-second arc for the biography question | F, 2 questions |
| Values/Behavioral | Scenario probes | Low: no values-style round is detected and no published values were read | A selection scaffold with an honest branch | G, 2 questions |

## Question banks

| JD line | Questions |
|---|---|
| R1: 3+ years product management experience | B1, B2, B4, D1, F1 |
| Own the roadmap (R1 sub-claim) | A1, A3, B1, B2, D1, D2 |
| R2: Shipped API or platform products | B3 |
| R3: Technical fluency: API docs, schemas | A5 |
| R4: Stakeholder management across engineering, sales, customers | A3, D3, E1, E2 |
| R5: Agile delivery experience | F2 |
| Run discovery with integration partners | A4, B5 |
| Write specs and drive delivery with two engineering squads | A3, A5, C2 |
| Define and track adoption metrics | A2 |
| Company and strategy (CO) | none: research did not run, and a pack built from memory would be inventing |

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you'd spend your first sixty days on the partner API roadmap — what do you need to know first?" | CASE | [inferred] derived from the dossier's role_profile unknowns | Clarify before structuring: which decisions are yours versus the squad leads', how adoption is measured today and from what baseline, what partners are asking for. Then objective, partner segments, approach, metrics, risks. Think aloud. Challenge one premise politely: what "owning the roadmap" means in practice. The guidance makes no claim about your past | F2's area asked as a live problem; the unknowns are the underwriter's, so the clarifying questions double as the reverse questions. CASE because it is delivered live |
| A2 | "An endpoint partners were meant to adopt shows few active integrations ninety days after launch. Diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify what "active" and "launch" mean and which partners. Segment them, then walk a funnel from first look to production. The stages in your own sentence (scoping, requirements, architecture, UAT, go-live) are usable as structure vocabulary, with no claim about where any partner stalled, because nothing in your material says. Name the metric you would trust and the assumption you would defend least | F9's area as a live problem: adoption metrics are named in the JD and no baseline is stated. CASE because it asks for structure, not a past |
| A3 | "Two squads, one quarter. One wants to ship a new authentication flow, the other a partner sandbox, and both want your backing. How do you decide?" | CASE | [generic] | Ask first who decides and by what rule; the role leaves decision authority unevidenced. Propose criteria instead of pretending to know the seam: partner evidence, effort, reversibility, dependencies. Say how you would gather partner evidence, what you would escalate and to whom, then commit to a recommendation and say what would change it. Claim no past decisions of this kind | F2 and F8 as a live problem. The underwriter flagged authority versus the squad leads as the unresolved risk, and this question hits it |
| A4 | "The role runs discovery with integration partners. How would you do that, and what would be different from running a client integration?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F7: tell the quarterly sessions at the quote's scope, evidence fed to product, in your own words. Name the limit before it is extracted: confirmed, little inspectable proof, so expect a probe, and say what you fed in and stop there. What would be different is a plan, said as a plan. Answer slot: the JD's discovery line makes a probe on how the evidence was gathered likely. If you gathered it yourself, say how; if it came from elsewhere, or there was no set method, say so plainly and return to the sessions you ran | F7 is the evidence for the discovery line and the second quote carries a medium band. JD because it scores the stated responsibility |
| A5 | "Walk me through what goes into a spec for a breaking change to an endpoint partners already use, including the API docs and schema changes." | CASE | [generic] | Structure it: the problem and the partners affected, the change and its migration path, how docs and schemas change, sequencing with the squad, how you would tell partners and when, and how you would know it worked. Say aloud which parts you would hand to engineering. The question needs no claim about your past, so the guidance makes none | R3's wording (API docs, schemas) and the specs line (F4, F8) as a live problem. CASE because it asks for structure rather than a past |

Proposed language above is pending your approval.

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"`; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The highest-ROI prep in this pack, and the underwriter named the objection. Concede first, plainly: "I haven't held a product manager title and I haven't owned a roadmap." Then the bridge, with its limit: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through architecture, UAT and go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." Name the limit on the last one before it is asked for: confirmed, little inspectable proof. Close with a plan, said as a plan: learn which decisions are yours and how adoption is measured. Follow-up one, "but a PM has made the trade-offs": hold by returning to the integrations and concede exactly: "I haven't set prioritization for an engineering squad." Follow-up two, "so why not hire that PM": do not argue you are better; say what you bring in the terms of the three quotes and leave the call to them | F1 and F2 are where the title and the roadmap gap sit; this question is the dossier's own and will arrive in some form. JD because it scores the headline requirement |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"` | The dossier's strategy for this area is acknowledge_gap, so no bridge. Plain acknowledgment: "I haven't owned a roadmap and I haven't set prioritization for an engineering squad." Then the ramp plan, said as a plan: you would first learn which decisions are yours and how adoption is measured today. Calibrated candor beats bluffing a competency the interviewer owns | F2 is the weakest row, and this stem is how a Skeptic reaches it. JD because it scores the listed responsibilities |
| B3 | "The role needs someone who has shipped API or platform products. Tell me about something you shipped." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the sentence says: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Use the word "shipped" only if you can stand behind it. Answer slot: the JD's R2 line makes a probe on how far you took those integrations likely. Say which stages of the go-live path were yours, in your own words; if none were, or they were not yours, say so plainly and stay with the integrations you led | F3 is the must-have the dossier did not list among its weak areas; JD because it scores a stated requirement |
| B4 | "Why move from integration work into product, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Selection scaffold, not a story: your reason has to be yours. Name one concrete part of this JD that draws you, then the nearest thing your material carries, which is the quarterly sessions at the quote's scope, with no claim that it was product work. If no clear reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Say what you know about Quartzline only if you actually know it; the pack could not research it | F1's motivation probe. JD because it tests consistency of motive against the stated role |
| B5 | "Walk me through how the quarterly roadmap-input sessions worked." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Tell the beats the sentence states: the sessions, quarterly, client evidence, product. Volunteer the limit first: confirmed, with little inspectable proof, so expect a probe. Answer slot: the JD's discovery line makes a probe on how the evidence was gathered likely. If you gathered it yourself, say how, in your own words; if it came from elsewhere, or there was no set method, say so plainly and return to the sessions you ran | F7 is the medium-confidence row the dossier warns is probed. EXP because it tests what you did |

Proposed language above is pending your approval.

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the 30+ integrations — what made one count?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say "30+" as the sentence says it, without rounding up. Answer slot: the figure raises four probes. How it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of it was yours. Answer each in your own words; if you do not know how it was counted, say so plainly | Every headline figure gets a defend-the-number question; F1's figure is the one. EXP because it tests attribution |
| C2 | "How much of the end-to-end work on those integrations was you, and how much your team?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Hold at the verb the sentence uses, "led", and at the stages it names. Answer slot: the figure raises which part was yours. Say which of those stages you did yourself and which you directed, in your own words; if a stage was not yours, say so plainly. Do not upgrade "led" to anything larger | F1 and F3 share this sentence, and attribution is where a Prober goes second |
| C3 | "Walk me through the integration playbook — what's in it and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the sentence states: you wrote it, it is internal, your team uses it. The dossier marks this high confidence because the playbook was provided, so describe its sections from the document itself; the pack supplies none. If you did not write part of it, say so plainly | F4's second quote, and the most inspectable evidence you have. EXP because it can be checked |

Proposed language above is pending your approval.

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: you've never owned a roadmap. Why would two engineering squads listen to you?" | JD | [grounded] `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"`; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate the question. Hold only what the sentence carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Do not argue authority you have not had. Concede specifically: "I haven't owned a roadmap and I haven't set prioritization for an engineering squad." Then plan, said as a plan: what you would do to earn it | F2's gap under time pressure. JD because it scores the listed responsibility |
| D2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having owned a product roadmap"` | Hold at the sentence's own verb: you ran the sessions and fed client evidence to product. Concede only what the dossier sources: "I haven't owned a roadmap." Anything beyond the sentence is yours to say in your own words, or to say plainly it was not yours. Hold through two follow-ups by returning to the sentence | F7's medium band is the exact seam a Pressure interviewer finds |
| D3 | "A squad lead tells you flatly that your priority isn't going in this quarter. What do you do?" | CASE | [generic] | Pause, restate. Find the constraint behind the no, separate the decision from the evidence, bring partner evidence, and name what you would escalate and to whom. Hold your position one round, then concede one thing explicitly and specifically. If decision rights are unclear, say you would confirm them first. Claim no past instance | F2 and F8: authority versus the squad leads is the dossier's unresolved risk |

Proposed language above is pending your approval.

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between a PM and a squad lead, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: the PM brings partner evidence and the problem, the squad owns how it is built, and disagreements are settled by evidence, then escalated. Add reciprocity: what you bring the squad lead's team. Ask where the seam sits here; that is the first reverse question | F2 and F8; the seam is the unevidenced item in the JD |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion when work spanned teams, with named people, your part and what you did about credit. Use "we" for context and "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5's engineering and sales probe in collegial form. VAL because it tests behaviour, not a JD line |

Proposed language above is pending your approval.

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each the sentence as written: the integrations you led, the playbook you wrote, the sessions you ran. Close with one sentence on why product, in your own words; the pack does not supply it. Add no duration the sentences do not state | F1 is the bridge; this is where it is first heard |
| F2 | "The posting lists agile delivery experience. How have you worked that way?" | JD | [grounded] | The dossier's strategy here is clarify, and no verified entry speaks to it. Answer slot: the JD's wording is the probe. If you have delivered in sprint-based or similar cycles alongside engineers, say how and what part was yours; if you never worked that way, say so plainly. Then say what you would want to confirm about how Quartzline defines it | F6 is a discovery gap, and a casual question about a preferred skill is still scored |

Proposed language above is pending your approval.

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said the hard thing, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plausible somewhere in the loop; no quoted sentence of yours carries a story for it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision with a named trade-off, what you chose and what it cost. Where no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plausible for a partner-facing role; the material carries no story for it |

Proposed language above is pending your approval.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | Which roadmap decisions does this PM make alone, and which belong to the squad leads? | The JD asserts authority it does not evidence; the answer settles the risk the underwriter flagged, and it reads as diligence |
| 2 | How is partner API adoption measured today, and what is the current baseline? | Adoption metrics are a named responsibility with no stated baseline; you need it before accepting |
| 3 | What would you want me to have learned, and shipped or decided, by day ninety? | Converts the ramp plan into the manager's own yardstick |
| 4 | How do the two squads take input from partners and from sales today, and where does it get stuck? | Shows you think about the seam, and surfaces the stakeholder load in R4 |
| 5 | What is the main reason someone in this seat would struggle here? | Invites the honest risk from the person who owns it |
| 6 | Given my background is integration leadership rather than product, what would you want me to prove first? | Names the title gap yourself, on your terms, once the interview is going well |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims: "Having held a product manager title or role"` | F1's quote at its own scope, plus the acknowledgment the dossier supports: "I haven't held a product manager title." No bridge reframes the work as PM work |
| Having owned a product roadmap | `prohibited_claims: "Having owned a product roadmap"`; the dossier's acknowledge_gap area on roadmap ownership | F7's quote at its own scope, plus the acknowledgment the dossier supports: "I haven't owned a roadmap." No slot, because the underwriter found no evidence to bridge from |
| Having set prioritization for an engineering squad | `prohibited_claims: "Having set prioritization for an engineering squad"` | The acknowledgment the dossier supports: "I haven't set prioritization for an engineering squad." Hold the integrations; never suggest prioritising authority |
| Shipped an API or platform product | Inflated form of F3: the requirement's wording widens the quote | F3's quote at its own scope. The limit is this pack's observation: the material says integrations of the vendor's APIs, not a shipped product. B3's slot stays inside the integrations |
| Drove roadmap decisions through the roadmap-input sessions | Inflated form of F7: the quote says sessions feeding evidence to product | F7's quote at its own scope. The limit is this pack's observation: the material says evidence fed to product, not decisions made. B5's slot stays inside the sessions |

## Sources

Provided: `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14), consumed standalone. It supplied `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the objection, risks, employer questions, prohibited claims) and `role_profile` (requirements stand as the JD's lines). `decision` was read as context only. The dossier carries no `evidence_map`, `evidence_state` or `risk_register`; the reverse questions use `opportunity_risks_to_validate` and `questions_for_employer`. Round, relationship and length come from your message.

Searches sent, all refused (permission to use web search was not granted):
- "Quartzline company values": refused
- "Quartzline interview process product manager": refused
- "Quartzline partner API platform strategy news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved the values cheat sheet (section 10), now dropped. No values-style round is detected, so G is generic |
| 2. `Quartzline interview process product manager` | unavailable | Would have moved persona weights and loop structure. Weights rest on the relationship prior and your own words |
| 3. `Quartzline strategy` / recent news | unavailable | Would have moved a company-strategy question (CO) and the case content. No CO question is in this pack |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → values by name, loop structure and strategy; the generic G bank, the strategy case and a CO question become grounded
- Deeper research pass, offered once → up to 6 further searches and 2 further fetches, several more minutes: a strategy brief and recent org context for sharper case content
- The interviewer's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → stated focus areas and any announced deliverable, replacing the assumed coverage
- An artifact for the roadmap-input sessions, such as an agenda, notes or a message showing what product did with them → F7 and A4, B5 and D2 would move from medium toward high
- Your own-words answers to the slots in F3, F4, F5, F6, F7, F8 and F9 → the answer slots in those rows and their questions become story-mapped guidance
- Prep time available → a prioritised schedule of which questions to rehearse first
- The raw CV behind the confirmed claims → any further stories the dossier did not carry
