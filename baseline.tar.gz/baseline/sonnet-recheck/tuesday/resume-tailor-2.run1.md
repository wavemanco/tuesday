I read the resume-tailor playbook and its rules, so here is the first pass: a ledger of proposed edits, none applied.

The ledger can reorder and tighten what you wrote, but it can't turn "Senior Data Analyst" into 3+ years of data engineering, and the coverage map marks that must-have `not_evidenced`. Whether the role is still worth applying for is job-underwriter's question, not this ledger's.

## The edit ledger

I haven't seen the full resume, so "Current line" quotes your sentences from the message.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `compress` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E5 | Skills | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E6 | Skills | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, placed above the Python line)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |

- **E1** stays as two separate sentences, so neither one gets bigger by being joined to the other.
- **E3** keeps "with our then-DE", and it says "designed", not "owned".
- **E4** keeps "tests". I did not change it to "data quality checks", which is the JD's wording, not yours.
- **E5** keeps "some scripting". Dropping it would be the compression that quietly makes a claim larger.
- Your title stays "Senior Data Analyst". A retitle would have to be an equivalent, not an upgrade.

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | No row can carry it. Nearby work is in E2–E4. See C3. | `[grounded]` JD marks it must-have and your title is analyst; `[generic]` an analyst title with adjacent work is often read literally against a titled-years requirement |
| 2 | Production Python | important | not_evidenced | E5 keeps Python as analysis plus some cron scripting. See C1. | `[grounded]` your Python line says "for analysis" |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | You've never used Airflow, and nothing yet shows an equivalent. See C2. | `[grounded]` "Never used Airflow or Spark." |
| 4 | Dimensional modelling and warehouse modelling | important | surfaced_by_edit | E3 (star schema, with the DE), supported by E1 and E2 | `[grounded]` your message |
| 5 | Data quality (tests on the pipeline) | important | surfaced_by_edit | E4. Tests only; I claim no ownership of data quality. | `[grounded]` "added tests to it" |
| 6 | SLAs | important | not_evidenced | Named absence below | `[grounded]` nothing in your message mentions SLAs |
| 7 | Batch pipelines in Spark | important | not_evidenced | Named absence below. E4 and E5 are adjacent only. | `[grounded]` "Never used Airflow or Spark." |
| 8 | Streaming (Kafka) | preferred | not_evidenced | Named absence below | `[grounded]` "Never touched Kafka." |
| 9 | Partner with analytics on requirements | important | not_evidenced | You stood on the analytics side, so I did not write this as "partnered with analytics". | `[grounded]` your title and the star-schema sentence |

## Recovery per gap

I wrote one recall-prompt row for each gap where your history may hold something I can't see from here. The questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | Python "for analysis", plus "some scripting to pull vendor APIs on a cron". That doesn't say whether anyone depended on those scripts. | The JD lists it by name, and "for analysis" reads as notebooks. | A vendor-API script that feeds a table other people query; one with retries or failure alerts; one that runs on a shared server instead of your laptop | The script in a repo, its cron entry, an alert or failure log | `[grounded]` what the line says; `[generic]` what this costs on data-engineering applications |
| C2 | Airflow or equivalent orchestration | important | A nightly dbt job you fixed and added tests to, and cron scripts. Nothing says what schedules the dbt job. | The JD says "or equivalent", so how the job is scheduled decides whether anything adjacent exists. | A dbt Cloud or CI scheduler you configured; job dependencies between the API pulls and the dbt run; someone else's Airflow DAG you debugged | A scheduler config, a job-run history, a DAG screenshot | `[grounded]` the nightly job is in your message; `[generic]` schedulers count as equivalents only if you configured them |
| C3 | 3+ years data engineering | must-have | Five years as an analyst, with dbt models, a star schema, and nightly-job fixes inside that role | It's the only must-have, and a title-based reading will see "analyst". | A stretch where pipeline or modelling work was most of your week; any period when your scope changed | A dbt project repo with lineage docs, or a prior resume version showing a scope change | `[grounded]` your title and years; `[generic]` how such requirements get screened |

### Named absences

| Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|
| Spark | You have never used it. | A small Spark job on a public dataset, which you could describe only as a personal project. It is weeks of work, and the JD doesn't list it in Requirements. | `[grounded]` your message and the JD |
| Streaming (Kafka) | You have never touched it. | A local Kafka demo would close it only as a personal project. It's a preferred item, so I'd leave it open for this application. | `[grounded]` your message and the JD |
| SLAs | Nothing in your history mentions an SLA. | Define freshness targets for the nightly job, measure them for a few months, and then it's real. Until then, it stays off. | `[grounded]` nothing in your message |
| Airflow itself | You have never used it. | A local Airflow project that schedules your own API pulls and dbt run. That makes it a project, not job experience. | `[grounded]` "Never used Airflow or Spark." |
| Partnering with analytics | You have stood on the analytics side. | Your star-schema work with the then-DE is the nearest thing, and E3 already carries it. Don't flip it into the engineer's side. | `[grounded]` your title and the star-schema sentence |

## Not written, and why

- "Data Engineer" or "Analytics Engineer" as a title. Your title is analyst, and the new title would be an upgrade, not an equivalent.
- "Built and owned batch pipelines." You fixed one nightly job and ran some cron scripts, and "owned" is a different claim.
- "Production Python" or "ingestion pipelines". Your line says "for analysis", and the JD's word would move the claim.
- "Data quality ownership" or "SLAs". You added tests, and the JD's word asks for more than that.
- "Orchestrated pipelines." The nightly dbt job and the cron scripts don't establish orchestration. That depends on C2.
- "Partnered with analytics on requirements." You were on the analytics side.
- Airflow, Spark or Kafka anywhere, including a Skills list. A tool listed isn't a tool used.
- Hidden keyword text to get past screening. I wouldn't write that for anyone, and it's not needed here.

## Parse-safety check

You pasted prose, not a file, so I couldn't run any of the six checks: columns, tables, images, headers and footers, section headings, file type. Send the file and I'll run them. Until then, keep conventional headings like Experience and Skills, and keep contact details out of the header.

## Upgrade menu

- **Full resume as a file:** lets me run the parse check, cut irrelevant retail-analysis bullets, and trace every row against your actual wording.
- **dbt project repo or lineage docs:** an inspectable artifact that supports E2–E4 and C3.
- **Nightly job's scheduler config and a cron script:** could move C1 and C2 from `not_evidenced`.
- **Prior resume versions or job descriptions:** may show scope changes the current version dropped.

## Questions

C1 — Where do your vendor-API cron scripts run, who or what depends on their output, and what happens when one fails?
C2 — What triggers your nightly dbt job (dbt Cloud, cron, CI, or something else), and did you set it up or just maintain it?
C3 — Roughly how much of your week, and for how long, has been dbt/pipeline/modelling work rather than analysis, and did your scope change at any point?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.