Web search was denied, so I'm building the pack from your JD and background alone. I'll mark everything company-specific as generic.
The write to the working directory was refused, so I'll save the pack to the session scratchpad, which is set aside for this.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-2-denied-8f7d9817/84251aff-525e-4e53-982d-5610495390b9/scratchpad/atlas-freight_operations-manager_interview_pack.md`. It has 22 questions, built for an unspecified round with flat persona weights, since you don't know who's interviewing you.

- **Where it's thin:** Web search and the write to the working folder were both denied, so I used the scratchpad. Nothing about Atlas Freight itself is researched. The company question is marked generic and the pack has no values sheet. Pasting their careers or about page would fix that.
- **Highest-ROI prep:** The scale step from 3 supervisors to 12 across 4 sites (A1). Your material says "3 supervisors", so rehearse saying that plainly without inflating it.
- **Other likely probes:** Warehouse versus terminal work, how many of your 7 years were leadership against the 5+ required, and Power BI. The pack gives the honest wording for each: "I've never used Power BI", then a learning plan.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, and did the recruiter say anything about format or focus?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees)
Interviewer: not known. Relationship and round type: not known. This pack is built for an unspecified round with flat persona weights, which makes it noticeably weaker than one built for a known round. Telling me the round type reweights every bank.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the claims about your work survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI prep in this pack is A1, the step up from 3 supervisors to 12 across 4 sites. It will be asked in some form. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material carries warehouse and distribution work and a surge plan. It does not show terminal work or more than one site, and nothing is inspected behind it. The words stay at the quotes: "I have seven years in warehouse and distribution operations, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal and four-site line makes a probe on how your work compares likely. If any of your work spanned more than one site or handled terminal freight, say what and how, in your own words; if not, say so plainly and stay with the site and the surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost per shipment, with nothing inspected behind the figure. The words stay there: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures, so expect a probe on which you have tracked. If you tracked either, say how it was counted and which part was yours; if neither was yours to track, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows the same kind of leadership at a quarter of the JD's number, and nothing in it shows work at that size. The words stay at the quote: "I'm a senior shift manager over 3 supervisors." Answer slot: if any role of yours has covered more people, shifts or sites, say which and what you were responsible for, in your own words; if none has, say so plainly and describe how you lead the three |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Solid Excel is not building reporting, and the bridge does not stretch it. Answer slot: the JD names building reporting. If any of your Excel work produced reports that others used, say what it showed and who used it, in your own words; if it was your own tracking, or no reports were built, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and no claim that Excel covers it |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | Your material gives seven years in operations and a current leadership role, and does not say when leading began, so the pack does not count the seven toward the five. Answer slot: if you can say the year you first led people and what you led then, say so, in your own words, and count only those years; if the leadership years are fewer than five, say so plainly and stay with what the role did cover |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap in wording: "I'm green belt certified." Lead with it in the quote's own terms. The quote does not say which belt scheme it is or whether it touches Lean, and no certificate has been inspected, so expect a probe. Name no body, project or Lean program the quote does not |

## Persona table

No loop source establishes this company's rounds, so the pack falls back to the Generic archetype (screen, hiring manager, panel) with flat priors, and the weights below rest on that pattern, not on this company's documented process. The tilt comes from where your fit snapshot is thinnest, so you can recalibrate it if you know the round.

| Persona | How it shows up | Weight and reasoning | Counter-strategy (a method, not a claim) |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the scale, terminal, Power BI and leadership-years gaps | Top, 5 questions. F1, F3, F5 and F6 are the thinnest rows | Rehearse the scale objection (A1) until it is boring; bridges only from what you stated; say the limit plainly |
| B. Case / Strategist | Live problems from the JD's own lines: on-time, cost, surge, allocation | High, 4 questions. The JD is operational, and cases need no claim about your past | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Reads your figures line by line | Mid, 3 questions. The 40% figure (F2) and the reporting rows (F4, F5) invite it | Know how the figure was counted, or say plainly you do not; name the weakest assumption before they do |
| D. Pressure | Time-boxes, interrupts, questions attribution | Mid, 3 questions. A figure you own (F2) and a step up in scale (F3) are classic targets | Pause, restate, hold the quoted position through two follow-ups, concede only what is true and specific |
| E. Conversational | Friendly, unstructured, still scored | Mid, 3 questions. Likely if a recruiter screen comes first | A 90-second arc built from your own sentences; treat the casual JD-plus question as scored |
| F. Peer Evaluator | Seam-splitting, credit, collaboration | Low, 2 questions. Unknown whether a peer is in the loop | Offer seam principles instead of pretending to know the seam; reciprocity |
| G. Values / Behavioral | Scenario probes | Low, 2 questions. No values-style round is detected: no loop source names one, the fallback archetype reads no, and no values page was read | Selection criteria, then the honest branch where no story comes to mind |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role has 12 supervisors across 4 sites. Your team is 3 supervisors. What changes at that size?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Open in the quote's own terms: "I'm a senior shift manager over 3 supervisors." Do not grow it. Answer slot: the JD's 12 and 4 make a probe on span likely. If any role of yours has covered more people, shifts or sites, say which and what you were responsible for, in your own words; if none has, say so plainly, then give how you would learn each site and each supervisor, as a plan and not as something already done. Hold through two follow-ups by returning to the three you lead, never by adding scale | F3 is the widest gap against a headline requirement, so this objection arrives in some form. JD because it scores the stated team size |
| A2 | "The posting asks for 5+ years of operations leadership. How many of your seven years were spent leading?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the years in their own terms: "7 years in warehouse and distribution ops." Do not call all seven leadership years; your material does not date when you started leading. Answer slot: if you can say the year you first led people and what you led then, say so, in your own words, and count only those years; if the leadership years are fewer than five, say so plainly and stay with what the role did cover; if you cannot separate the years, say that plainly | F6 is a discovery gap on a requirement the JD marks required. JD because it scores the stated qualification |
| A3 | "Your background is warehouse and distribution. This job is terminal operations. Where do those overlap and where don't they?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running" | State your background in the quote's words. This pack does not say what a terminal involves, so do not guess at their practices: ask them (reverse question R1). Answer slot: the JD's terminal line makes this probe likely. If any of your work handled the same kind of freight flow, say what, in your own words; if none did, say so plainly and stay with the warehouse and distribution work and the surge plan you ran | F1 pairs a requirement the JD states with adjacent work only. JD because it scores the listed responsibility |
| A4 | "The role builds reporting in Excel and Power BI. Where do you stand on Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Say the acknowledgment first and flat: "I've never used Power BI." Then a plan, said as a plan: what you would learn first and whose data you would use, in your own words. Answer slot: if you have started anything on it since, say what; if not, say nothing of the kind. Do not say Excel makes it similar | F5 is a gap you stated yourself, so the honest answer is ready before the probe. JD because it scores the stated tool |
| A5 | "Why this move, and why now?" | EXP | [generic] | Selection scaffold: give a reason in your own words, tie it to a named piece of the JD, and keep it consistent with what you do now. Do not invent dissatisfaction. If no reason beyond the title comes to mind, say so plainly, then give the nearest honest reason | Motivation consistency is scored in a Skeptic's register. EXP because the career story must survive cross-examination; no company claim is made |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has slipped for three weeks. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and measured, whether the other sites moved, what changed three weeks ago. Then objective, segmentation of where the misses sit, approach, metrics, risks. Challenge one premise, such as whether the measure itself changed. The case needs no claim about your past, so the guidance makes none | The JD's on-time line, asked as a live problem. Generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment is rising while volume is flat. Where do you look first, and what would you refuse to cut?" | CASE | [generic] | Clarify what is in the cost and what counts as a shipment, then split the cost, rank by size and by controllability, and name the trade-off: what you would not cut and why. No claim about your past | The JD's cost-per-shipment line, asked as a decision. Generic pattern |
| B3 | "Volume is forecast to jump across all four sites for six weeks. Sketch the plan and tell me what you need to know first." | CASE | [generic] | Ask about forecast confidence, per-site capacity and labor availability; set the objective; plan in stages with trigger points; name metrics and risks. Challenge the premise that all four sites are hit equally. No claim about your past | The JD's four-site ownership as a live problem. Generic pattern |
| B4 | "Two of your four sites ask you for the same extra headcount in the same week. How do you decide?" | CASE | [generic] | Clarify what each site's need is and what it is tied to, set the criteria out loud, name the data you would want, decide, and say how you would handle the site that loses. No claim about your past | The JD's four-site, twelve-supervisor span as a decision. Generic pattern |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the figure in the quote's terms: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words, naming the weakest assumption before they do. If you do not know how it was counted, say that plainly. Do not name a baseline or method you cannot repeat under a second question | F2 holds your only headline figure, and figures are what a Prober tests. EXP because it scores attribution and counting |
| C2 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The story has only the beats the quote states: the plan, the site's peak season, two years running. Tell them in your own words. This pack does not supply what the plan contained or what happened; give detail only where you can stand behind it, and say plainly where your memory ends | F1 is where your surge work is evidence. EXP because it tests what was actually yours |
| C3 | "Tell me about reporting you've built in Excel." | JD | [grounded] "solid Excel, never used Power BI" | Start from the quote: "solid Excel." Answer slot: the JD names building reporting. If you built reports that others used, say what they showed and who used them, in your own words; if your Excel work was your own tracking, or no reports were built, say so plainly and stay with "solid Excel". Name no function or technique you have not used | F4 is a discovery gap on the JD's reporting line. JD because it scores the stated tool |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who already runs several terminals?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate, then hold on what the quotes carry: "I cut the mis-pick rate 40% by redesigning the pick path", "I ran the site's peak-season surge plan two years running", "I'm green belt certified." Hold through two follow-ups by returning to those. Answer slot: expect the follow-up to press on scale; say what your role covers today in the quote's words, add anything more only if it is true and yours, and if there is nothing more, say so plainly and name what you would learn first | F1 and F3 are where a comparison with a stronger candidate lands. JD because it scores fit against the stated role |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts were yours; if others designed, measured or carried out parts of it, say who and what, using "we" for context and "I" for your contribution; if it was yours throughout, say so. Hold through two follow-ups by returning to the redesign, and concede only a specific uncertainty you actually have | F2 is the figure a Pressure interviewer attacks. EXP because it scores attribution honesty |
| D3 | "A veteran supervisor tells you in front of the team that your change won't work. Respond." | CASE | [generic] | Pause and restate what you heard, ask for the specific failure they see, decide in the moment whether to hold or adapt and say why, and take the rest to a private conversation. No claim about your past | Composure under a challenge to authority, relevant to the JD's supervisor team. Generic pattern |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built from those five sentences, each at its own scope. Your material does not date them, so order the beats yourself as they actually happened. Add why this role as one sentence in your own words; this pack supplies no motive | F1 to F3 and F7 are the sentences a biography answer can be made from. EXP because it is the first test of whether the CV story holds together |
| E2 | "What are you actually working on in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Start from the quote: "I'm green belt certified." Answer slot: the JD marks Lean and Six Sigma as a plus. If you use any of it now, say what, in your own words; if you have not used it since certifying, or it has not touched your work, say so plainly and stay with "green belt certified" | F7 is the row a casual question about a plus-skill probes. JD because it scores the stated plus |
| E3 | "What do you know about Atlas Freight, and what draws you to it?" | CO | [generic] | Selection scaffold: research was not available when this pack was built, so use only what you read yourself in the company's own materials this week. Pick two facts you can name the source of and one question that follows from them. If you found little, say what you did find and ask what you could not | Homework depth is scored in a friendly register. Generic because no company research ran; this pack makes no claim about the company |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles and do not pretend to know the seam: who decides what, who gets told what, and how a disagreement is escalated. For the disagreement, selection scaffold: pick a time you disagreed with an equal, with a named stake, a position held, and the relationship intact; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A multi-site role sits on seams between sites and functions. JD because it scores the span the posting describes |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams and the credit question was real, name how you handled it, and say what the other side would say. If no such time comes to mind, say so plainly, then say how you would handle it | Credit-sharing is a standard peer probe. No quote carries this story, so it is a scaffold |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: choose a time with a named stake, what you said, how it landed, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard Values probe. No quote carries a story for it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: choose a specific decision, name the metric and the customer's side of it, and say what it cost. If no such time comes to mind, say so plainly, then say how you would weigh it | Customer-versus-metric is the natural tension in an on-time and cost role. No quote carries a story for it |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, B3, B4, D1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, G2 |
| "lead a team of 12 supervisors" | A1, B4, D3, F1 |
| "build reporting in Excel/Power BI" | A4, C3 |
| "5+ years operations leadership required" | A2 |
| "Lean/Six Sigma a plus" | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How would you describe the difference between what a terminal does day to day and what I've worked in?" | It gets the real answer to the gap in A3 from the person who knows it, and shows you asked instead of guessing |
| R2 | "How do the four sites differ in volume, staffing and how they report?" | It shows you are thinking at the span the job has |
| R3 | "How are on-time performance and cost per shipment measured today, and what would a good first year look like on each?" | It ties the two headline measures to a definition and a target |
| R4 | "What reporting do the sites use today, and where does it live?" | It gets an honest read on how much Power BI the role needs on day one |
| R5 | "What would make you say in a year that this hire was clearly the right one?" | It makes the interviewer state the scoring sheet |
| R6 | "If you work alongside this role: what could a new person do in the first month that would genuinely help your team?" | Reciprocity question for a peer, if one is in the loop |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations, or ran more than one site | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution ops and one surge plan, not terminals or more than one site |
| Owned on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope. The material says mis-pick rate; C1's slot asks only how that figure was counted |
| Led a team of 12, or led at that scale | Inflated form of F3 | F3's quote at its own scope. The material says 3 supervisors; A1's slot stays inside the role you hold |
| Built reporting or dashboards in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel". C3's slot asks only what the Excel work was used for |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has 5+ years of operations leadership | Inflated form of F6 | F6's quotes at their own scope. The material gives seven years in ops and a current leadership role, without dating when leading began |
| Ran a Lean or Six Sigma program | Inflated form of F7 | F7's quote at its own scope: "green belt certified". No body, project or program is added |
| Presented the pick-path redesign as a Lean or Six Sigma project | Inflated form of F2 and F7, which no quote links | F2 and F7 stay as separate quotes at their own scope. No slot |

## Sources

Provided documents: the job description as pasted in your message; the background summary in your message. No CV, no dossier, no assessment, no interviewer profile.

Searches sent, all refused (permission was not granted, so each returned nothing):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news 2026" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have moved the values cheat sheet and the Values bank themes; neither is in the pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have moved the persona weights and round structure; the Generic archetype stands in |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have moved a strategy-grounded CO or CASE question; E3 is generic instead |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (future manager, peer, panel, recruiter) → persona weights recomputed and banks added or dropped, and the reverse questions retuned
- Any recruiter email or process details (format, focus areas, a take-home or presentation) → coverage of any pre-declared deliverable, and a loop source for the persona weights
- The interviewer's name → an interviewer read from their public professional footprint, and a reverse question tied to their own path
- Atlas Freight's values, careers or about pages, pasted in (or search permitted) → E3 and the CO bank become grounded, and a values cheat sheet if a values round is named
- Your CV → the verbatim evidence cells in F1 to F7 come from its lines instead of your summary, and some rows may move band
- Your green belt certificate → F7 moves from medium to high
- Your answers to the slots in F1, F2, F3, F4 and F6 (sites and terminal work, on-time or cost tracking, people led before, reports built, the year you first led) → those rows regenerate on your own words, along with A1, A2, A3, C3 and D1
- What your surge plan contained and what happened → F1 and C2 become story-mapped
- A tuesday-dossier.md from an earlier role evaluation → a verified evidence base and an objection list in place of the pack's own inference
