**Not a waste of time, but a stretch. R1a (3+ years in a product-management role) is absent as a title. R1b, R2 and R9 hold adjacent work that makes an application worth trying. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM work, title aside), R2 (Shipped API or platform products), R9 (Own the roadmap) · absent: R1a (3+ years held as a PM role)
- `important` — direct: R6 · adjacent: R4 (Stakeholder management), R7 (Specs and delivery with two squads), R10 (Launches with sales and support) · unclear: R5 (Agile delivery), R8 (Adoption metrics)

R1a cannot be closed by wording; R1b, R2 and R9 carry the adjacent work toward it.

**Opportunity ledger.** The role is concretely scoped (RR4), and its main exposure is the literal must-have (RR2). Pay, level and location are unstated (RR3), and the employer is unverified (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Someone at Quartzline confirms that equivalent product-facing work can meet the 3+ years (RR2, R1a, R1b).
  2. The internal triage tool is confirmed with specifics (G2, R2, R8).
  3. The employer and live posting are verified (RR1).
  4. Your adjacent work is never described as a PM role or roadmap ownership (R1b, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not checked externally |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Must-have | 3+ years of product management experience | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Stage | Evaluating, assumed | `[inferred]` from no stage stated |
| Scope read | A technical platform PM whose customers are developers integrating the APIs, the people you worked beside on 30+ integrations | `[inferred]` from "partner-facing" and "reading API docs and discussing schemas" |
| Market calibration | Not established: the role-family sweep did not run, so there is no pay band and no norm for how strictly titled years are enforced | `[grounded]` research refused; see Evidence status |
| Unknowns | Pay, level, location or remote policy, reporting line, the hiring manager | `[grounded]` JD silence |
| Contradictions | None visible, but only the JD was available to compare | `[grounded]` one source only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience, held as a PM role | must_have | absent | none | capability | You confirm you have never held a PM title and the JD marks the requirement must-have. This row grades the title only; the work near it is R1b. Screens tend to read "must-have" literally | `[grounded]` your statement and the JD; `[generic]` on screening | No wording closes it. Ask RR2's question; G1 tests for PM-type duties |
| R1b | Product-management work for 3+ years, title aside | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product, wrote requirements documents, and coordinated engineers and PMs. The limit: that fed product decisions made by others, and nothing stated shows you owning prioritisation | `[grounded]` resume for the work; `[inferred]` that it counts toward the requirement | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your vendor's REST APIs, which is the integrator side of an API product. The resume does not say you built or shipped one. The triage tool is an unconfirmed lead and is not counted here | `[grounded]` resume; memory lead excluded | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | The resume states REST integrations, integration architecture, Postman, SQL and OpenAPI reading. Nothing has been inspected, so `medium`; expect a probe on schemas in an interview | `[grounded]` resume; `[generic]` on the probe | A sanitized architecture diagram or your playbook would raise it to `high` |
| R4 | Stakeholder management across engineering, sales, customers | important | adjacent | medium | discovery | Engineering and customers are evidenced: your engineers, client engineers, PMs and clients. Sales and support are not mentioned, so the claim stays at what you wrote | `[grounded]` resume | G3 |
| R5 | Agile delivery | important | unclear | low | discovery | The resume describes scoping, UAT and go-live and does not mention sprints or similar ceremonies | `[grounded]` resume silence | G3 |
| R6 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops across 30+ client integrations and quarterly client-feedback sessions are discovery work, but the resume frames them as implementation. Your counterparts are clients, not "partners", so keep your word | `[grounded]` resume | E1 |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated your engineers on custom builds. Those were for client-specific work, and no standing squad is stated | `[grounded]` resume | W1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The resume states no metrics. The triage tool could bear on this, but it is an unconfirmed lead | `[grounded]` resume silence; memory lead excluded | G2 |
| R9 | Own the roadmap | must_have | adjacent | medium | transferability | Running roadmap-input sessions is input to a roadmap others owned. No prioritisation call or trade-off is stated, and ownership is what the JD asks for | `[grounded]` resume; tier `[inferred]` from this being the first duty listed | G1 |
| R10 | Coordinate launches with sales and support | important | adjacent | low | discovery | Client go-lives are launch-like, but the sales and support side is unstated | `[grounded]` resume; `[inferred]` that go-lives bear on it | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product decisions you owned (R1b, R9, R1a) | transferability | Feedback-gathering and requirements writing, but no stated prioritisation authority | These are the rows that decide whether "3+ years" can be read as met by work rather than title | Choosing which custom-build requests went ahead; setting the order of work on a project; standing in for a PM; deciding what went into the playbook | A roadmap-input summary you wrote, a prioritisation list, a manager's note on your remit | `[grounded]` resume silence; `[generic]` that this is the usual line a must-have is tested on |
| G2 | A product you built that others adopted (R2, R8) | discovery | An earlier-context mention of an internal request-triage tool that support agents adopted. It is unconfirmed and is not evidence | It is your most direct route to "shipped" and "adoption" | Building it, specifying it, deciding what it did, getting agents to use it, watching usage | A screenshot, README or spec, a usage count, the request that started it | `[grounded]` memory lead only; `[inferred]` that confirmation would move R2 and R8 |
| G3 | Agile cadence and sales/support launches (R5, R4, R10) | discovery | Delivery described as scoping, UAT and go-live; no sprints, sales or support named | Lower decision impact than G1 and G2, so no question this turn | Sprint reviews with engineers, launch checklists, hand-offs to support at go-live | A launch checklist, a release note, a go-live runbook | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Unverified because the research call was refused, not because nothing was found; small Series B firms often have thin footprints | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who the hiring manager is? | unresolved |
| RR2 | Titled-years must-have | risk_signal | medium | "3+ years product management experience (must-have)" | A screen or recruiter may read "must-have" as a PM-title filter | `[generic]` pattern; `[grounded]` the JD marks it must-have | Must the 3+ years be in a product-management role, or does equivalent product-facing work count? | unresolved |
| RR3 | Pay, level and location unstated | unknown | — | (the posting states no salary, level or location) | Any of the three could conflict with your needs, and none has been checked | `[grounded]` JD silence | What are the salary band, level and location policy for this role? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "Own the roadmap for our partner-facing API platform … drive delivery with two engineering squads" | Scope is concrete (one platform, two squads, named duties). Who wins when a sales request conflicts with the roadmap is not stated | `[grounded]` JD; `[inferred]` on the authority gap | When a sales request and the roadmap conflict, who decides? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the 30+ client integrations (scoping workshops, requirements documents, integration architecture, UAT, go-live) to the top of the resume, keeping "client", not "partner" | R6 | `[grounded]` resume | `resume_edits_pending_approval` |
| E2 | Keep the roadmap line in your own verbs: "ran quarterly roadmap-input sessions collecting client feedback for product". Do not write roadmap ownership or prioritisation | R9, R1b | `[grounded]` resume | `resume_edits_pending_approval` |
| W1 | Write a one-page product brief from a real integration pain point you saw: the problem, who it hit, what you would specify | R7, R9 | `[inferred]` from R7's limit | pending your approval |
| A1 | Ask RR2's question to a recruiter before investing in a tailored application | RR2, R1a | `[grounded]` register | pending your approval |
| A2 | Look for an internal referral, because a person can read your work where a title filter cannot | R1a | `[generic]` how hiring often works, not a fact about Quartzline | pending your approval |
| A3 | Widen the target set to roles such as technical product manager, partner or integrations PM, or product owner for developer platforms | R1a | `[generic]` role-family pattern, not a claim about any employer | pending your approval |

Every row in this plan is proposed and nothing is final until you approve it. E1 and E2 are the resume edits; the others are actions and advice.

## Evidence status

Verified: none yet. Unverified lead: a prior-context mention of an internal request-triage tool that support agents adopted. It is unconfirmed and prompts a question only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company careers Product Manager Platform APIs"; the call was refused, so nothing returned. It would have moved the employer check, the live-posting check and RR1 |
| 2. Role-family sweep | unavailable | Searched "product manager API platform salary requirements transition from solutions engineer to product management"; the call was refused. It would have moved the market calibration, RR3 and how strictly RR2 is likely enforced |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you want a file to keep or carry forward; there's no pressure either way.

## Upgrade menu

- Permission for the search tool → targets 1 and 2 run, so RR1 closes, RR3 gets a band, and RR2 gets a norm.
- An answer to G2, plus a screenshot, README or usage count → R2 and R8 move.
- A recruiter's answer to RR2 → R1a and R1b settle, and the decision likely simplifies to `go` or `no_go`.
- Your non-negotiables (pay floor, location) → the hard-gates line resolves.
- A sanitized architecture diagram or your playbook → R3 to `high`.
- A roadmap-input summary you wrote → R9 and R1b firm up.
- The hiring manager's name → the scope read and which of your stories to lead with.

**G2** — Did you build the request-triage tool that support agents adopted? What was yours and what was the team's, who used it, and how did you know they were using it?

**G1** — Was there a stretch where you decided what got built, or in what order, such as choosing between client requests for custom builds or standing in for a PM? Who signed off on those calls?

**Constraints** — What are your non-negotiables for a move: pay floor, location or remote, and any title or seniority you would refuse?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.