## Decision snapshot

**Yes, apply. The map holds no pet-insurance or line-management requirement, so neither gap is a reason to hold back. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote)
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important`: direct: R8a · unclear: R8b (Recommendations for product)
- `preferred`: direct: R9

R6b and R8b both need one concrete example from you. R1 needs a one-line confirmation.

**Opportunity ledger.** The role is concrete about what it does, with named audiences (RR4). The employer could not be established from public sources (RR1), the salary is unstated (RR2), and the team and resources behind "own pricing analytics" are unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor verifies as a live employer with a live posting (RR1); (2) R1 is confirmed; (3) the motor-to-pet move and your lack of line management are stated plainly, never papered over (A3, A4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. No company site or careers page turned up in search | `[grounded]` JD header; `[grounded]` search returned no result for the company |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | One owner across modelling, testing and communication. Team size and reports are not stated | `[inferred]` from the verb "own" against the JD's silence on staff |
| Market calibration | UK senior pricing analyst at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). This is the band to expect, not Brindlemoor's offer, because the JD gives no figure | `[generic]` Pricewell 2026 survey, from a search snippet; `[grounded]` JD for the absent figure |
| Hiring manager | Odile Varga, Director of Pricing. A profile snippet says she spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). Before Brindlemoor she was head of pricing analytics at Calloway Re for six years | `[grounded]` search-result snippet; the page was not fetched |
| Unknowns | Salary; direct reports; data and tooling; first-year outcomes | — |
| Contradictions | None found among the material provided. The JD could not be checked against a careers page | `[grounded]` target 1 found nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the UK; fully remote role | hard_gate | unclear | medium | hard_gate | You work at a UK insurer, which suggests a UK base, but you haven't said so | `[inferred]` from UK employer | G3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years in pricing analytics, the last 2 as senior analyst. Self-reported | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily. Self-reported, with no artifact | `[grounded]` your message | a sanitized query or notebook would raise to `high`; not needed to apply |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Pet rating factors differ from motor ones, but the JD asks for GLM experience, not pet factors | `[grounded]` your message; `[generic]` that rating factors differ by line | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM build as R4 | `[grounded]` your message | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is stated, but what monitoring you ran is not | `[grounded]` your message silent on monitoring practice | G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your message | none |
| R8a | Turn results into recommendations for underwriting | important | direct | medium | none | Quarterly review plus tests run with underwriting | `[grounded]` your message | none |
| R8b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in what you've told me names a product audience | `[grounded]` your message silent | G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. Pet-specific experience is not asked for | `[grounded]` your message and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Recommendations for product (R8b, important) | discovery | Tests and the quarterly review serve underwriting. No product-side audience is evidenced | The JD names product as a recommendation audience. A concrete example moves R8b to `direct` | A test result that changed an add-on, excess or cover-tier decision; a pricing recommendation to a product or proposition lead; a review item product acted on | A sanitized test readout or review slide | `[grounded]` your message silent; `[inferred]` that motor add-ons and excesses count as product levers |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" is stated. Nothing says what you monitored or what triggered action | A must-have, and the hiring manager's public talk was about monitoring models | Actual-vs-expected tracking by segment; drift checks; a rule for when to refit; a post-implementation review of a rate change | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your message silent; `[inferred]` that monitoring depth will be probed, from the talk snippet |
| G3 | UK base (R1, hard_gate) | hard_gate | UK employer, but your location isn't stated | The role is UK-remote; a mismatch would fail the gate | Not applicable | Not applicable | `[inferred]` from UK employer |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Medium, not high, because one profile names the company and the salary is the only other flag | `[generic]` pattern for small companies, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | JD contains no figure | The offer may sit inside or below the survey band, or the company may not publish pay | `[inferred]` from the missing figure against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Ownership asserted; team and resources unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The post may be a sole-owner role with thin data and tooling, or it may carry direct reports. That matters because you haven't line-managed | `[inferred]` from "own" against the JD's silence | Does this role have direct reports now or planned, and what data, tooling and analyst support does it start with? | unresolved |
| RR4 | Responsibilities concrete and tied to named audiences | positive_signal | — | "turn the results into recommendations for underwriting and product" | The mandate is a defined workflow, not a vague analytics brief | `[grounded]` JD states it | What would a good first six months look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify Brindlemoor and the live posting before investing effort: find the role on their own careers page, or ask the recruiter | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2 and RR3 questions at first contact, and RR4 in the interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| E1 | CV ordering only: lead with the GLM build-and-maintain line and the 14 price tests run with underwriting. No new facts | see R4, R7 | `[grounded]` your message | pending your approval |
| A3 | State the move plainly: "motor pricing, GLM build, test design; pet-specific rating factors are new to me." Don't call the motor work pet-adjacent | see R4, R9 | `[inferred]` bridge, with its limit named | pending your approval |
| A4 | If asked about management, say you haven't line-managed. Name what you did lead (tests run with underwriting, the quarterly review) only as you've described it | see RR3 | `[grounded]` your message | pending your approval |
| A5 | If G2 produces a monitoring example, lead with it for Odile Varga | see R6b | `[grounded]` talk snippet; `[inferred]` it shapes what she probes | pending G2 and your approval |

Every row above, and any wording in it, is proposed. Nothing becomes CV or outreach text until you approve it.

## Evidence status

Verified: none yet. Everything about you is from your message, so it is a lead and not proof.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech"; no results. Employer not established, which is why RR1 stands |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). That gave the market calibration band `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). That gave the scope read and A5. Public professional facts only |

Want me to turn this into a `tuesday-dossier.md` you can carry into interview prep? Say so and I'll emit it.

## Upgrade menu

- A link to the live posting or Brindlemoor's careers page → RR1 closes and the decision likely simplifies to `go`.
- An answer to G1 → R8b moves toward `direct`.
- An answer to G2, or a sanitized monitoring pack → R6b resolves and A5 firms up.
- Confirmation of your UK base → R1 closes.
- The budgeted salary → RR2 closes, and the figure is set against the band.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — Have you ever taken a test result or pricing finding to a product or proposition owner, not just underwriting? What did you recommend, and what changed?

G2 — How did you monitor the young-driver GLM once it was live? What did you track, and what made you act or refit?

G3 — Are you UK-based, and is there any term (salary floor, hours, office days) that would make you walk away from a role like this?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.