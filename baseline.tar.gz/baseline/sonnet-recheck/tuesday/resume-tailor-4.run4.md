Your resume can't be made to cover this JD with keywords alone, and I won't write keywords you haven't earned. The ledger below makes your real evidence easier to find and shows where the resume is silent. It doesn't close those gaps.

**On "it's the keyword matching":**
- **What one source reports.** In one vendor's interviews with 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters." (cite C25). The same source says "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no form questions on work authorization, licence or location, not resume keywords.
- **What keywords may do.** The source says "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). That is ranking, not rejection.
- **Limits of that source.** It is a small vendor sample that calls its findings themes rather than representative statistics. Nobody can tell you why a specific application was turned down.
- **What the coverage map shows.** Of 14 JD rows below, 2 are `already_evidenced`, 1 is `surfaced_by_edit` and 11 are `not_evidenced`. A person reading your resume would also see that gap, so I'd weigh it alongside any ATS problem.
- **Your layout is a separate risk.** A two-column Canva file with icons can drop real content before anyone reads it (see the parse check).
- **Whether to keep applying.** Whether roles with this gap profile are worth your time is job-underwriter's question, not this one's.

**Assumption.** I only have the summary you typed, not the PDF. I'm treating your sentences as the resume's lines, so confirm they match the file.

## The edit ledger

All rows are `resume_edits_pending_approval`.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(Kubernetes not in the skills you described)* | "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your summary | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — moved to first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your summary | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged — moved to second bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your summary | pending your approval |
| E4 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your summary | pending your approval |

- **The qualifier stays.** E1, E3 and E4 all keep "never went to production". Dropping it would turn a proof-of-concept into production experience, and an interviewer would test that in one question.
- **E4 is three separate sentences.** I didn't join them into one claim.

## Coverage map

The JD gives no tiers, so Priority is my reading of its list.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E1, E3, E4 carry the proof-of-concept with its limit; production use is not shown | `[grounded]` your summary; `[inferred]` priority |
| R2 | AWS EKS | must-have | `not_evidenced` | You list EC2, S3, RDS and IAM; EKS is not named. See C1 | `[grounded]` your summary; `[inferred]` priority |
| R3 | Terraform | must-have | `not_evidenced` | Ansible config management is not Terraform. See C2 | `[grounded]` your summary; `[inferred]` priority |
| R4 | CI/CD | must-have | `already_evidenced` | "Built our deploy pipeline in Jenkins…"; E2 and E4 only move it earlier | `[grounded]` your summary; `[inferred]` priority |
| R5 | CI/CD on GitLab | important | `not_evidenced` | Jenkins only. See C2 | `[grounded]` your summary; `[inferred]` priority |
| R6 | Python | important | `already_evidenced` | "Bash and Python scripting" | `[grounded]` your summary; `[inferred]` priority |
| R7 | Go | important | `not_evidenced` | Named absence A2 | `[grounded]` your summary; `[inferred]` priority |
| R8 | GitOps and ArgoCD | must-have | `not_evidenced` | See C1 | `[grounded]` your summary; `[inferred]` priority |
| R9 | Helm | important | `not_evidenced` | See C1 | `[grounded]` your summary; `[inferred]` priority |
| R10 | Istio and service mesh | important | `not_evidenced` | Named absence A1 | `[grounded]` your summary; `[inferred]` priority |
| R11 | Prometheus, Grafana, observability | must-have | `not_evidenced` | CloudWatch for monitoring is adjacent and stays "monitoring". See C2 | `[grounded]` your summary; `[inferred]` priority |
| R12 | Vault | important | `not_evidenced` | See C2 | `[grounded]` your summary; `[inferred]` priority |
| R13 | SRE practices and platform reliability | must-have | `not_evidenced` | See C3 | `[grounded]` your summary; `[inferred]` priority |
| R14 | Developer experience | important | `not_evidenced` | See C3 | `[grounded]` your summary; `[inferred]` priority |

## Gap handling

**Recall prompts** (pending your approval; questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | EKS, GitOps/ArgoCD, Helm | must-have | A two-month Kubernetes proof-of-concept, with no cluster type or tooling stated | The JD names EKS, ArgoCD and Helm; the proof-of-concept is your only route to any of them | The cluster ran on EKS; manifests packaged as Helm charts; a Git-driven deploy flow; a demo to your team | PoC notes, architecture doc, repo, README | `[grounded]` what the resume says; `[generic]` what the gap costs on applications of this kind |
| C2 | Terraform, GitLab CI, Prometheus/Grafana, Vault | must-have | Ansible, Jenkins and CloudWatch only | These are four named tools, and none is evidenced | Terraform for any AWS resources; a GitLab project or migration; Prometheus/Grafana in a side project or the PoC; secrets handled with Vault | Public repo, module, dashboard export | `[grounded]` what the resume says; `[generic]` what the gap costs on applications of this kind |
| C3 | SRE practices, reliability, developer experience | must-have | Pipeline ownership and about 30 Jenkins jobs; no reliability or developer-facing outcome | The JD's closing line says you "will own platform reliability and developer experience" | On-call rotation; an incident you resolved; alerts you set up; developers who depend on the pipeline | Postmortem, alert config, internal docs | `[grounded]` what the resume says; `[generic]` what the gap costs on applications of this kind |

**Named absences:**
- **A1, Istio and service mesh.** Your resume has no service-mesh work. To close it, you'd build and publish a small cluster project that uses a mesh, which is real learning time. With this many unevidenced rows, it is probably not the first gap to close for this role.
- **A2, Go.** Nothing in your resume shows Go. To close it, you'd write and publish a small tool in Go. If you'd rather not, skip it and rely on Python, which is evidenced.

## Not written, and why

- **"Kubernetes experience" with no qualifier.** The proof-of-concept never went to production, and the JD asks for platform ownership.
- **"EKS", "Helm" or "ArgoCD".** Nothing you wrote names them; they stay out until C1 is answered.
- **"Infrastructure as code" or "Terraform" for Ansible.** Config management and provisioning are different work.
- **"Observability" for CloudWatch.** The JD's word is not yours; you wrote "monitoring".
- **"GitLab CI".** You wrote Jenkins.
- **"Owned platform reliability" or "improved developer experience".** Nothing you wrote says either. The pipeline you built may serve developers, but that is a question (C3), not a line.
- **"SRE practices".** You haven't described any.

## Parse-safety check

I could only run checks on what you described, not on the file.

| Check | Finding | Provenance |
|---|---|---|
| Two-column layout | Parsers read linearly, so columns can interleave and detach dates from roles | `[grounded]` the layout you described; `[generic]` how parsers read |
| Icons for skills | If an icon stands in for a skill name, that skill is absent to a parser; text beside the icon survives | `[grounded]` the layout you described; `[generic]` how parsers read |
| Contact details in header | If that is the file's header region, parsers may discard it and leave you unreachable; if it is only the top of the page body, no risk | `[generic]` what happens with header regions; I can't tell which yours is |
| Section headings, hidden text, text layer | Not run: no file | n/a |

I haven't proposed layout changes, and what you do with the layout is your call. A cheap test is to paste the PDF's text into a plain-text editor and see whether the order and contact details survive.

## Upgrade menu

- **The PDF itself, or its text.** I could run the real parse checks, inspect for hidden text you didn't author, and quote your lines exactly.
- **Answers to C1–C3.** Each answer can turn `not_evidenced` rows into rows you can defend.
- **Artifacts from the proof-of-concept.** A repo, notes or an architecture doc would raise the Kubernetes evidence from your word alone to something inspectable.
- **An earlier resume version.** It may still hold evidence your current one dropped.

## Questions

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

- **C1:** Did the Kubernetes proof-of-concept run on EKS, and did it use Helm or a Git-driven deploy such as ArgoCD?
- **C2:** Have you used Terraform, GitLab CI, Prometheus/Grafana or Vault anywhere (work, side project, the proof-of-concept), and what did you do with it?
- **C3:** Have you been on call or handled an incident, and who depends on your Jenkins pipeline (how many developers or teams)?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.