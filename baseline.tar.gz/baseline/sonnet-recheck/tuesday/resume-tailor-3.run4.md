Here is the tailoring ledger for Quartzline. Nothing is applied yet.

I used these parts of the Tuesday dossier:
- R1 and R2 as graded (both `adjacent`, `medium`)
- the pending edit E1
- both rejected inferences
- the `conditional_go` decision, which I read but did not act on

Your message gave the rest of your CV only as a summary, and the dossier excerpt didn't include the rest of its `evidence_map`. So every quote below is your own sentence as you wrote it to me, and I graded the other requirements myself. If your actual CV words differ, paste it and I'll re-check each row.

## Edit ledger — pending your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(no standalone line, per dossier E1)* | "Wrote the internal integration playbook the whole team uses." | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV and dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved first under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved directly after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved up to sit just below the role's bullets)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

- **E1** is the dossier's pending edit. I re-audited it against your sentence, and the scope stays "the whole team", not the company.
- **E5** keeps the two sentences separate on purpose, so the summary states your real title up front rather than hiding it. Reject it if you'd rather not have a summary.
- None of the rows retitles you. "Solutions engineer / implementation lead" stays as it is.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | not_evidenced | No PM title held. Adjacent work is in E2 and E3. The dossier grades it `adjacent` with a `transferability` gap at `medium`, and I inherit that. Roadmap ownership and prioritisation authority aren't evidenced. See C1. | `[grounded]` |
| 2 | Shipped API or platform products | important | not_evidenced | Your sentences show integrating and implementing APIs, not shipping them. The dossier grades it `adjacent` at `medium`. See C2. | `[grounded]` |
| 3 | Technical fluency | important | surfaced_by_edit | E2 and E4 | `[grounded]` |
| 4 | Stakeholder management | important | surfaced_by_edit | E2 and E3 | `[grounded]` |
| 5 | Run discovery with integration partners | important | surfaced_by_edit | E3. Your sentence says "client feedback", which is vendor-side, so I did not call them partners. | `[grounded]` |
| 6 | Write specs and drive delivery with two engineering squads | important | not_evidenced | Nothing in your sentences. "OpenAPI specs" under tools doesn't say you wrote them. See C2. | `[grounded]` |
| 7 | Define adoption metrics | important | not_evidenced | Nothing in your sentences. See C3. | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM, specifically roadmap ownership and prioritisation | must-have | Quarterly sessions that collected client feedback "for product". It doesn't say who decided what went on the roadmap. | The posting asks for you to "own the roadmap", and this is the one must-have. | Ranking which client requests you escalated; arguing a client ask into or out of a release; a session summary that led to a roadmap change | A session write-up, a ranked backlog, a ticket you prioritised | `[grounded]` what the CV says and omits; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API products; specs and delivery with engineering | important | 30+ integrations of APIs you didn't say you built, plus OpenAPI comfort | The posting has you writing specs and driving two squads | An API change request you wrote that shipped; an OpenAPI file you authored or edited that engineering released; an integration pain point you specced that became a fix | A change request, a spec file, a release note | `[grounded]` what the CV says and omits; `[generic]` what this costs on applications of this kind |
| C3 | Define adoption metrics | important | The 30+ integrations are counted, but nothing about how they were tracked | The role ends with defining adoption metrics | Time-to-go-live across your integrations; a SQL query on endpoint usage; a client-activation tracker | A query, a dashboard screenshot, a tracker sheet | `[grounded]` what the CV says and omits; `[generic]` what this costs on applications of this kind |

**Named absence:** you have never held a PM title, and the posting makes 3+ years of PM its must-have. Closing it fully isn't possible with wording. The only honest path is C1: if you did decide or rank what went to product, that evidence moves the row. If you didn't, the gap stays and the application rests on the adjacent work in E1 to E3.

## Not written, and why

- "Built an internal request-triage tool": carried from the dossier's rejected inferences. It was a memory lead, and you couldn't confirm you owned it.
- "Customer of a partner API platform": carried from the dossier's rejected inferences. You worked vendor-side.
- "3+ years of product management", any PM title, or "Product Manager" as a retitle: you have never held the role.
- "Owned the roadmap" or "prioritised the roadmap": your sessions collected input. Owning the roadmap is a different job.
- "Shipped API products": you integrated APIs, and nothing says you released one.
- "Partners" in place of "clients": it's the posting's word, and it would change which side of the table you stood on.
- "Wrote and managed API specs": your sentence says "comfortable in", not authored.
- "Drove delivery with engineering squads" and any adoption-metrics claim: no sentence supports either.
- Widening E1 to "defined the company's integration approach": your sentence says "the whole team uses".

## Parse-safety check

Your CV came as a description, not a file, so I could not run the layout checks:
- multi-column
- tables and text boxes
- images and icons
- headers and footers
- section headings
- file type

## Upgrade menu

- **Your CV as a file (docx or text-layer PDF):** lets me quote your exact words and run the layout checks above.
- **A roadmap-session summary or ranked backlog:** could move row 1 toward `surfaced_by_edit`.
- **An API change request or an OpenAPI file you authored:** could do the same for rows 2 and 6.
- **A go-live tracker or usage query:** could do the same for row 7.

## Questions

C1 — In your quarterly roadmap-input sessions, did you decide or rank what product took forward, or did you pass the feedback on and product decided?
C2 — Did any API change or spec you wrote get built by engineering, and if so, what was it?
C3 — Did you track anything about how the 30+ integrations went (time to go live, usage), and if so, how?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.