I checked the live posting and the company page. The assessment is below.

## Decision snapshot

**Yes, this is worth applying to, on the conditions below. Status: `conditional_go`.** R3, R4, R5, R6, R8 and R9 are all the `must_have` rows, and all are `direct`. R1 and R2 are gates your own terms haven't been checked against yet.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R7 carries a bridge with its limit named, and R10 and R11 turn on what your pipelines actually did.

**Opportunity ledger.** The role is sound on what it states. Pay is disclosed and sits inside the market band you sent (RR1), and the employer's own pages match the posting (RR5). Equity terms (RR2), team shape (RR3) and success measures (RR4) are open.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 hold against your own location and pay terms; (2) the BigQuery gap is framed as adjacent and never as BigQuery experience (R7); (3) team shape and ownership verify in interviews (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the company's About page (pellucidlearning.com/about), which is the company's own statement, not independently corroborated |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years, SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | The JD names no direct reports and no team, which matches the typical remit in your report, ownership of one domain's pipelines with no direct reports | `[inferred]` from the JD's silence on reports against the Datawright 2026 report's stated typical scope |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500. The posted $148,000–$166,000 starts $3,000 under the median and ends $2,500 over the top of the interquartile range. Pellucid's stage matches the report's Series B–D group. Your 6 years sit inside the typical 5–8 for "Senior" | `[grounded]` the Datawright report you supplied and the JD; `[generic]` that the band is a pattern, not this employer's offer |
| Unknowns | Equity type and size; team size and reporting line; first-year outcomes; whether the role is new or a backfill | — |
| Contradictions | None. The live careers page carries the same posting and shows "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You gave no location or work-authorization terms, so there is no statement to grade. "Remote (US)" implies a US base, which isn't established | `[grounded]` JD; your background says nothing on location | Closing question R1/R2 |
| R2 | Pay: $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You gave no pay floor. The posted band is within the market band you sent, so pay is not the likely failure, but it is unconfirmed against your terms | `[grounded]` JD and your pay report | Closing question R1/R2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company, self-reported with no dates or artifact, so `medium`. A length requirement, not a gate | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated. Nothing inspectable has been offered, so `medium`, and expect a probe on depth | `[grounded]` your stated background | A SQL or Python sample would raise it, if you have one you can share |
| R5 | dbt | must_have | direct | medium | none | You built the project, about 180 models, on Snowflake. Confirmed and specific, with no artifact inspected | `[grounded]` your stated background | A sanitized project structure or model-lineage screenshot would raise it |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The JD's requirements list names the category, not a product | `[grounded]` JD requirements line and your stated background | none |
| R7 | BigQuery (named in the responsibilities, not the requirements list) | important | adjacent | medium | transferability | Snowflake plus dbt is adjacent work. Limit: you have not used BigQuery, so its specifics are untested. The JD names it only as the stack, not as a requirement | `[grounded]` JD and your statement of no BigQuery use; `[generic]` that BigQuery's pricing and table-design choices differ from other warehouses | Gap queue G3 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named exactly. Confirmed, with no artifact | `[grounded]` your stated background | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Specific and confirmed, no artifact | `[grounded]` your stated background | A sanitized suite layout would raise it |
| R10 | Ingestion from an app and a CRM | important | unclear | low | discovery | Six years of pipelines likely include ingestion, but your sources are unstated | `[inferred]` from your years of pipeline work; the JD names the two sources | Gap queue G1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your test suite is related, but nothing you've said describes agreements with downstream consumers | `[inferred]` from the Great Expectations work; the JD names contracts | Gap queue G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R10, important) | discovery | Your pipelines are described by tooling, not by source system | The JD names this as the first job, so what you ingested decides how direct this row is | Pulling from a product database or event stream; syncing a CRM such as Salesforce or HubSpot; payroll-system extracts feeding the warehouse | A sanitized pipeline diagram, a DAG listing, or a source-system inventory | `[grounded]` silence on sources in your background; `[generic]` that ingestion design is a common interview probe for this title |
| G2 | Data contracts (R11, important) | discovery | Nothing yet separates tests you wrote from agreements with consumers | The JD frames contracts as what analysts depend on, so this is where your testing work either carries over or doesn't | Schema or freshness expectations agreed with analysts; blocking a deploy on a failed expectation; a documented column-level interface for a downstream team | A sanitized contract doc, a dbt tests and exposures file, or a changelog policy | `[grounded]` the absence of any consumer-facing detail; `[inferred]` that your test suite may have played that role |
| G3 | BigQuery (R7, important) | transferability | Snowflake and dbt carry over, but no BigQuery use | Named in the stack, so you'd be learning the warehouse on the job | Adjacent evidence: the Snowflake and dbt work. Limit: no BigQuery use, so cost and table-design behavior are unproven. Strengthener: a small dbt model on BigQuery's free tier | A small public repo, if you choose to build one | `[grounded]` your statement of no BigQuery use; `[generic]` that warehouse-specific cost and layout choices differ by product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posting is transparent and priced for senior scope; the low end sits $3,000 under the report's median | `[grounded]` JD against the Datawright report you supplied | Is the top of the range reachable for a candidate with 6 years, and what sets where in the range someone lands? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | The equity may vary widely in value; the posting gives no type or size | `[inferred]` from the posting's silence on terms | What is the equity (type, grant size, vesting schedule), and what is the strike or latest valuation basis? | unresolved |
| RR3 | Team shape and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the sole data engineer carrying both build and on-call | `[inferred]` from the JD's silence on team and manager | How many data engineers are on the team, who does this role report to, and who owns the data contracts today? | unresolved |
| RR4 | First-year outcomes not stated | unknown | — | the posting lists duties and requirements, with no stated outcomes | Success may be undefined for a role carrying a broad pipeline mandate | `[inferred]` from the absence of outcomes in the JD | What would a successful first year look like, and how is it measured? | unresolved |
| RR5 | Employer matches the posting on its own site | positive_signal | — | "Series C ($52M, February 2026)" and "264 employees" | The employer exists as described and the posting is live. The figures are self-reported | `[grounded]` the About page and careers page, both the company's own | Is this a new role or a backfill, and what prompted the opening? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the dbt project (Snowflake, about 180 models) and the Great Expectations suite in your top lines, in your own existing wording | See R5, R9 | `[grounded]` your stated background | pending your approval |
| E2 | Say "Snowflake" plainly and don't claim BigQuery; present the warehouse move as adjacent | See R7, G3 | `[grounded]` your statement of no BigQuery use | pending your approval |
| A1 | Confirm your location and pay terms against the posting before applying | See R1, R2 | `[grounded]` the unconfirmed gate rows | pending your approval |
| Q1 | Ask RR2, RR3, RR4 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you decide to apply, resume-tailor can turn E1 and E2 into an approve-first edit ledger.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), and searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Role reality's contradictions row (the posting matches and shows "Accepting applications") and RR5. The size and funding figures are the company's own statements and nothing independent corroborated them |
| 2. Role-family sweep | skipped | Your Datawright pay report is in hand with its figures, so it already fixes the market calibration and RR1. A sweep would add no new figure |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so no query could be formed |

## Upgrade menu

- A sanitized pipeline diagram or DAG listing: R4, R5, R8 and R10 can rise toward `high`.
- Your answers to G1 and G2: R10 and R11 resolve to `direct`, `adjacent` or a named gap.
- A small public dbt repo on BigQuery: R7's limit narrows.
- Your location, work-authorization and pay-floor terms: R1 and R2 close, and the decision likely simplifies to `go` or `no_go`.
- The hiring manager's name, if you learn it: the scope read, and which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding, leadership churn, employee and candidate reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also save this as `tuesday-dossier.md` if you want a file to carry forward.

Questions, answerable in text, by pasted voice transcript, attachment, link, or "skip":

1. R1/R2: Do the role's terms (US remote or Denver, $148,000–$166,000) fit your own non-negotiables on location, work authorization and pay floor?
2. G1: Which source systems did your payroll pipelines ingest from, and did any come from the product itself or a CRM?
3. G2: Did you ever agree schema or freshness expectations with the analysts who used your models, and what happened when one failed?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.