Search permission was declined, so this runs at documents-only strength. The two search calls I tried count against the budget and are logged below.

## Decision snapshot

**No, it isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.** Your sense that something is off is borne out by those two rows.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin, 5 days a week), R2 (Base $70–85k)
- `must_have` — direct: R4, R5 · adjacent: R3 (8+ years growth leadership)
- `important` — unclear: R6 (SEO/content), R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops)

R4 and R5 are your strongest matches on paper, and R1 and R2 decide the outcome regardless.

**Opportunity ledger.** The role is poorly scoped on its own terms: seven functions with no team (RR2), always-on expectations (RR3), success metrics that are undefined (RR4), and an employer I could not check (RR5). The posting's one positive is a claimed profitable start (RR6).

- **Hard gates:** failed: R1 (On-site Austin office 5 days a week, no exceptions), R2 (Base $70–85k against your $150k floor).
- **Severe red flags:** RR1 (`severity: high`).
- **What would change this:** the employer would have to make the role remote and raise base to at least $150k. The posting says "no exceptions" on location and gives no sign the pay band will move.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; not independently checked |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | Austin office 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus unspecified "meaningful equity upside" | `[grounded]` JD |
| Success metrics | "Will evolve as we learn" | `[grounded]` JD |
| Scope read | Several full roles folded into one title, with the pay stated at one level | `[inferred]` from the seven listed functions against the stated team size and base |
| Market calibration | Not established: the role-family search was refused. The $70–85k figure is the posting's own, and I'm not putting a market band on it | — |
| Unknowns | Paid budget, tooling, hiring plan, equity terms, who the CEO is | — |
| Contradictions | None found between JD statements, but the employer was not cross-checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit: remote-only, living in Portland, not relocating. Fit fails because the JD rules out any remote arrangement | `[grounded]` JD quote and your stated constraint | Surface only; no wording fixes this |
| R2 | Base $70–85k (against your $150k floor) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the posted band is $65k below it | `[grounded]` JD figure and your stated floor | Surface only |
| R3 | 8+ years growth leadership | must_have | adjacent | medium | discovery | You gave 9 years in growth and growth lead then Head roles, but not how many years were in lead or Head titles. Ambiguity resolves downward, so it is `adjacent` until that is confirmed | `[grounded]` your stated background (self-report, no inspectable artifact) | Confirm years in lead/Head titles |
| R4 | Paid acquisition | must_have | direct | medium | none | You stated you owned paid at two B2C subscription companies, with a controlled budget while scaling one from $8M to $40M ARR. No artifact inspected, so `medium`: expect a probe on attribution | `[grounded]` your stated background | None |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You stated you owned lifecycle and are deep in Braze. Same limit: self-report only | `[grounded]` your stated background | None |
| R6 | SEO/content | important | unclear | none | discovery | Nothing you gave touches SEO or content | `[grounded]` silence in your background | Ask only if you proceed |
| R7 | Brand and PR | important | unclear | none | discovery | Same silence | `[grounded]` silence in your background | Ask only if you proceed |
| R8 | Partnerships | important | unclear | none | discovery | Same silence | `[grounded]` silence in your background | Ask only if you proceed |
| R9 | Sales ops | important | unclear | none | discovery | Same silence | `[grounded]` silence in your background | Ask only if you proceed |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Years in leadership roles (R3, must_have) | discovery | 9 years in growth, with lead and Head titles, but no split | Decides whether R3 is `direct` or stays `adjacent` | Dates for the lead and Head titles | Titles and dates on the CV or LinkedIn | `[grounded]` your stated background gives total years only |
| G2 | SEO/content (R6, important) | discovery | No mention | Would be a real stretch only if unowned | Owning organic landing pages, a content calendar, or an SEO agency | Traffic dashboards or a content brief | `[grounded]` silence in your background |
| G3 | Brand and PR (R7, important) | discovery | No mention | Same | Press launches, brand campaigns, agency management | A campaign recap or press list | `[grounded]` silence in your background |
| G4 | Partnerships (R8, important) | discovery | No mention | Same | Affiliate, co-marketing or channel deals | A deal summary | `[grounded]` silence in your background |
| G5 | Sales ops (R9, important) | discovery | No mention | Same | CRM routing, lead handoff to sales | A pipeline or routing doc | `[grounded]` silence in your background |

None of these gaps can move the decision while R1 and R2 stand.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Conflict with your two hard constraints (see R1, R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" and "$70–85k base" | The posting states terms that rule out remote work and sit well below your floor | `[grounded]` JD against your stated constraints | Is any remote or hybrid arrangement possible, and is the base negotiable above the posted band? | confirmed |
| RR2 | Several roles bundled into one title, with no team | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | You may be accountable for seven functions with no help and no stated budget or authority | `[inferred]` from the function list against the stated team and base | What budget and decision rights come with this role, and when is the first hire planned? | unresolved |
| RR3 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be a routine expectation and not an exception | `[inferred]` from the framing as a cultural trait | How often did the last person in this function work evenings and weekends? | unresolved |
| RR4 | No defined success metrics for a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability with no stated definition of success | `[inferred]` from the JD's wording | What would success look like at 90 days and at 12 months? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small for a footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Profitable since day one; CEO reporting line with board access | positive_signal | — | "profitable since day one"; "Report to the CEO with a dotted line to the board" | If true, the company is financially stable and the role has senior access | `[grounded]` JD states both; unverified | Can you share the headcount and what a typical month looks like for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1, R2, RR1 | `[grounded]` map and register | pending your approval |
| A2 | If you proceed anyway, ask RR1's questions before investing any more effort | They test whether either gate could move | `[grounded]` register | pending your approval |

I've proposed no resume edits, since there's no application to tailor them for.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Novaline e-commerce enablement startup Austin Head of Growth careers" was refused, so the employer is unconfirmed. Would have moved: role reality's organization and contradictions rows, and RR5 |
| 2. Role-family sweep | unavailable | The search "Head of Growth Series A startup salary range 2026 base compensation" was refused. Would have moved: role reality's market calibration and RR2's pay mismatch |
| 3. Hiring manager's public footprint | n/a | No name was given. The posting names only "the CEO" |

## Dossier offer

If you want a record of this assessment, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Search permission would let me check the company exists as described, and would put a market band on the $70–85k figure.
- The CEO's or recruiter's name would let me look at their public professional footprint.
- Your lead and Head title dates would settle R3.
- Anything you own on SEO, brand, PR, partnerships or sales ops would move R6 to R9.

## Questions

I have no question this turn, because nothing I could ask would move the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.