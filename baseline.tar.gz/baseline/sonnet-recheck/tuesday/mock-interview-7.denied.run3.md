The searches were refused, so I'm building the pack from your message and the JD only. I'm writing the file now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-denied-9eba5bdd/524776ff-fdab-4c61-9261-c0adc0960561/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions across seven interviewer styles, a fit snapshot of the JD against your own sentences, and reverse questions for Tobias.

- **Assumption:** You didn't say whether Tobias is your future manager, so I built it for a hiring-manager round. That puts case-style problems and skeptical probing first.
- **No research ran:** All four web searches (Saltmarsh values, interview process, strategy, and Tobias) were refused. Nothing in the pack comes from the web. It rests on the JD and your message only, so there are no company facts, no read on Tobias, and no reverse question tied to his career. The pack's Sources section lists the refused searches.
- **Where I saved it:** The first write to your project folder was also refused, so I saved the file to the scratchpad folder instead.
- **Likeliest objection:** B1 is the one to rehearse most. You ran a content-drop calendar for one main title, and this role runs live events across two. The follow-ups after that are in-app purchases and leading a team, and the pack gives you the exact honest wording for both.
- **Before Friday:** Play both Saltmarsh titles. D2 asks which you've played, and I couldn't supply anything about them.

Say the word and I'll play the Skeptic on B1 live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Is Tobias the person this role would report to, a skip-level, or a peer, and did the recruiter mention any focus areas or something to prepare? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: probe.txt -----
ok


----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The relationship is assumed to be hiring manager, because your note did not say. If that is wrong, the persona weights below change.
**Format:** 60 minutes, Friday.
**Built from:** the JD you pasted and your own background message. No research ran, because the search calls were refused (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, in your own words, and if the thing never happened or was not yours, say so plainly.

Question IDs run by persona. The letter F is skipped because F1 to F9 are fit-snapshot rows.

| Type | What is being scored |
|---|---|
| VAL | Whether past behavior shows good judgment on values-type themes. No published Saltmarsh values were in hand, so these use the standard themes. |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did homework on the company and its games |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The years are in the quote. Whether the title was live-service is not shown, and the words stay at the quote: "I had 4 years as an associate producer at a puzzle-game studio." Answer slot: the JD's live-service line makes a probe likely. If your main title was a live-service game, say what made it one, in your own words; if it was not, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for your main title, for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material names a weekly content-drop calendar for a main title and no second title, and does not say whether the drops were events. The words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on how the calendar was built likely. If the drops included time-limited events, say which and how they were planned; if they were drops only, say so plainly and stay with the calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The quote touches the calendar and does not say which teams were involved. Answer slot: the JD names four teams. If you worked with any of them on the drops, say which and what you did, in your own words; if none, or it was not your part, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly retention numbers is adjacent to an event review and does not show one. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on who produced the numbers and whether any review followed individual drops. If you ran a review after drops, say how, in your own words; if there was none, or it was not yours, say so plainly and stay with presenting |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead in the quote's own terms: "I wrote the release checklist our QA team still uses." It says wrote, not ran each release, so expect a probe on how it is used; D3 holds that slot |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement. No figure was given, so how the numbers were counted is C1's slot |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written checklist touches writing and does not show it was clear. Answer slot: if other written work you could point to exists, name it in your own words; if the checklist is your main example, say so plainly |
| F9 | Experience on a game with in-app purchases, and leading a team. Neither is a JD line; both are limits you stated | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases" and "I haven't led a team." Then how you would learn, said as a plan and never as a past. Nothing added to make the gap smaller |

## Persona table

The starting weights are the hiring-manager prior: Case/Strategist plus Skeptic. Nothing about Tobias adjusted them, because no interviewer research ran. The loop is one 60-minute session, taken from your message.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan this, diagnose that | High. The hiring-manager prior puts it first, and the JD is built around planning and running a calendar. Bank A, 5 questions | Clarify, objective, segments, approach, metrics, risks. Think aloud. Challenge one premise politely |
| Skeptic | Quiet probing of the jump from one title's drops to live events on two titles, and of the gaps in F9 | High. The prior puts it second, and F3, F4 and F9 are where your material is thinnest. Bank B, 4 questions | Rehearse B1 until it is boring. Bridges use only your quoted sentences. State the limit before it is asked for |
| Data-Driven Prober | Goes line by line through the retention numbers | Medium. The JD names retention metrics and KPIs. Bank C, 3 questions | Say how the numbers were counted if you know, say plainly if you do not, and name your weakest assumption before they do |
| Conversational | Opening "walk me through" question and casual probes about the games | Medium. This is a generic opening pattern, and it is still scored. Bank D, 3 questions | A 90-second arc built from your quoted sentences. Play both titles first |
| Pressure | Time-boxed "why you" and "how much was you" | Low. The prior puts it behind the first two for a hiring manager. Bank E, 2 questions | Pause, restate, hold the core claim through two follow-ups, concede only what is true and specific |
| Values/Behavioral | Standard themes such as unwelcome news and putting players first | Low. No loop source and no published Saltmarsh values were in hand. Bank G, 2 questions | Pick a story only if your own material carries one; otherwise say so plainly |
| Peer Evaluator | Seam between producer and design, art, engineering and community | Low. The JD names four teams, but a hiring-manager round leans away from this. Bank H, 2 questions | Offer principles for the seam rather than pretending to know it |

## Question banks

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have two mobile titles and one quarter to plan. What do you need to know before you put a single event on the calendar?" | CASE | [generic] | Clarify before structuring: each title's goals for the quarter, what bounds the calendar (which teams' lead times), and what past events did. Then objective, segments, approach, metrics, risks. Think aloud and challenge one premise politely, such as whether one calendar should serve both titles. The question needs no claim about your past, so the guidance makes none | Tests the JD's calendar line for two titles, which F3 shows is the thinnest part of your match. CASE because it is a live planning problem |
| A2 | "Retention drops after an update. Walk me through your diagnosis." | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Clarify first: which players, which retention measure, over what period, and what else shipped or ran alongside the update. Then segment, list hypotheses, say what you would pull and whom you would ask, and name your first move. Optional anchor, used only as written: "I presented the monthly retention numbers to the studio head." Add nothing to it | Tests the retention-metrics line (F7). CASE delivery with JD content |
| A3 | "Both titles want the same weekend, and engineering can support only one. How do you decide?" | CASE | [generic] | Ask what is at stake in each, what is fixed, and whether scope can shrink to fit both. Offer decision criteria rather than a verdict, name who decides and who is informed, and say what you would bring to that person. Make no claim about having done this | Tests the four-team coordination line (F4) as a decision. Hypothetical, so nothing about your past is presumed |
| A4 | "Thursday's event is on track, and on Tuesday QA flags an open blocker. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure it: severity and player impact, options (ship as is, cut scope, delay, hotfix), who decides and who is told, and what the community hears. Anchor, used only as written: "I wrote the release checklist our QA team still uses." Your material does not show whether that checklist covered a blocker, so do not describe it as doing so | Tests the release-checklist line (F6) under pressure. CASE because the scenario is hypothetical |
| A5 | "A community manager says players are angry about an event reward two days before it ends. What do you do?" | CASE | [generic] | Listen before acting: what exactly the complaint is, how widespread it is, and whether it is a bug or an expectation. Then options, who decides, what players are told, and what goes into the post-event note. Make no claim about having handled this | Tests the community-team coordination line (F4) as a live problem |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran the weekly content-drop calendar for your main title. This role plans live events across two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team, and never worked on a game with in-app purchases" | The highest-ROI prep in this pack. Open with the quote at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then answer what changes as a plan, not a past: principles for shared teams and clashing dates, in your own words. Answer slot: the JD's two-title line makes a probe on how the calendar was built likely. If it included time-limited events, say which and how they were planned; if it was drops only, say so plainly and stay with the calendar you ran. Follow-up two, with the limit named before it is asked for: expect whether you have worked on a game with in-app purchases. Concede it whole: "I've never worked on a game with in-app purchases." Then a ramp plan in your own words, said as a plan. Follow-up three: expect a question on leading. "I haven't led a team." Say it once, plainly. Hold through all three by returning to the calendar, never by adding to it | F3 and F9 are where this objection is born, so it will arrive in some form. JD because it scores the role's stated scope |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Selection scaffold: choose the part of the JD where you are truly thinnest and name it before they do. The pack's observation is that your material shows no example for F4 and says nothing on events beyond drops (F3). If you name in-app purchases, say "I've never worked on a game with in-app purchases", then your ramp plan. If another area is truly your thinnest, say so in your own words and say what you would do first; the pack supplies no wording for it. If nothing comes to mind, say so plainly, and say how you would find out | The stock Skeptic stem, rehearsed because a vague answer reads as bluffing |
| B3 | "You have spent four years at a puzzle-game studio, the last two running its calendar. Why leave, and why here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: use only reasons you actually hold, and tie each to a JD line only if you want it (two titles, the post-event review, the KPIs). The pack supplies no motive. If one reason is stronger than the rest, lead with it and say it once. If you cannot say what pulls you to the role, say that plainly and say what you hope to learn | Motivation consistency. F1 and F2 supply the facts and the question probes why you would leave them |
| B4 | "This role coordinates design, art, engineering and community on each update, and you haven't led a team. How do you get four teams moving to one date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Acknowledge once: "I haven't led a team." Then separate coordinating from leading, as a plan: how you would agree dates with each team, what you would show them, and when you would escalate. Answer slot: if you worked with any of those four teams on the drops, say which and what you did, in your own words; if none, or it was not your part, say so plainly and stay with the calendar you ran | F4 is thin and F9 holds the stated gap, so the two arrive together. JD because it scores a stated line |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The defend-the-number slots, all in your own words: how the figures were counted, what they are most sensitive to, the assumption behind them you would defend least, and which part was yours. If you know these, say them; if you did not count them or do not know how they were counted, say so plainly and return to "I presented the monthly retention numbers to the studio head." Naming your weakest assumption first turns a gotcha into credibility | F7 is the only metric evidence in the material. EXP because it tests what was actually yours |
| C2 | "Tell me about a time a retention number moved and you acted on it." | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time with a named number, what you did, and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I presented the monthly retention numbers to the studio head", or say how you would handle it | An open prompt on the JD's retention line (F7). The guidance does not supply the story |
| C3 | "An event just ended. How do you decide whether it worked?" | JD | [generic] | Structure it: what the event was for, which measures follow from that, what you compare against, which segments you cut, and what decision the review feeds. Think aloud and say which measure you would trust least. Make no claim about having run a review | Tests the post-event review and KPI line (F5) as a method, since your material shows presenting and not owning |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc made of those four sentences, in that order, told in your own words and adding nothing. Then one closing sentence on why this role, from your own reasons | The biography question is scored even when it sounds casual. F1, F2, F6 and F7 are the whole arc |
| D2 | "Which of our two titles have you played, and what did you notice about its events?" | CO | [generic] | Before Friday, find both titles and play them. Take one observation per title, in your own words. If you have not played either, say so plainly and say what you would look at first. The pack supplies no facts about the titles | Homework check. Generic because no research ran, so the pack knows nothing about the titles |
| D3 | "Tell me about working with your QA team on the release checklist." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Tell it at the quote's scope: "I wrote the release checklist our QA team still uses." Answer slot: the JD's "manage the release checklist with QA" makes a probe on how it is used each release likely. If you ran it with QA, say how, in your own words; if others ran it, or it was a one-time document, say so plainly and stay with having written it | F6, and the likely probe on "wrote" versus "ran". EXP because it tests what was actually yours |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events on a monetized mobile game?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate. Hold only what the quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Concede specifically what is true: "I've never worked on a game with in-app purchases." Hold through two follow-ups by returning to the calendar, never by adding to it | Hold-then-concede on the stated gap (F9). JD because it scores fit against the role |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: say which decisions about what went on the calendar and when were yours. If those were set by others and you ran the process, or the work was shared, say so plainly and stay with "I ran the weekly content-drop calendar for our main title for the last two years." Precise attribution is the point | The attribution probe on F2, which is the line the whole application rests on |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: a named stake, a moment you did not soften it, and an intact relationship afterward. Answer slot: if any month's retention numbers were unwelcome and you said so, say what happened and how it landed; if none were, or nothing like that happened, say so plainly and stay with "I presented the monthly retention numbers to the studio head", or say how you would handle it | A standard values stem. F7 is the only place your material meets leadership |
| G2 | "When did you put the player's experience ahead of a schedule or a metric?" | VAL | [generic] | Selection scaffold: a specific decision, what you gave up, and who was affected. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would handle it. The pack supplies no story | A standard values stem. Generic because no published Saltmarsh values were in hand |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Design and engineering both feed your calendar. Where is the seam between you and them, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than pretending to know the seam: what the producer owns (dates, the plan, communication), what each team owns, and how disagreements are surfaced early. Show spine and tact together. Make no claim about a past seam | Tests the coordination line (F4) from the peer side |
| H2 | "How do you handle credit when a drop ships because six teams made it?" | VAL | [generic] | Selection scaffold: a specific moment when credit was shared or misplaced and what you did. If no such time comes to mind, say so plainly, then say how you would handle it. Use "we" for context and "I" for your own contribution | Standard credit-sharing probe. The pack supplies no story |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A3, B1 |
| "coordinate design, art, engineering and community teams on each update" | A3, A5, B4, H1 |
| "own the post-event review and the KPIs it reports" | C3 |
| "manage the release checklist with QA" | A4, D3 |
| "3+ years producing live-service games or apps" | B3, D1 |
| "experience running a content calendar" | B1, E2 |
| "comfortable with player-retention metrics" | A2, C1, C2 |
| "clear written communication" | none, and why: it is not scored by a live question here, and no written deliverable was announced |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first 90 days look like for the producer on each title?" | Shows you are thinking about ramping across two titles, which is your biggest scope question |
| 2 | "How are live events reviewed after they end, and which KPIs does the producer own versus other teams?" | Goes straight at the post-event review line (F5), where your material shows presenting and not owning |
| 3 | "When QA and an event date disagree, where does that decision get made?" | Shows you understand the release-checklist line (F6) as a decision, not a document |
| 4 | "How do the two titles differ in how their calendars run?" | Shows you want to plan for two titles, not one |
| 5 | "Where does monetization sit in event planning here, and what would you want a new producer to learn first?" | Turns your stated gap (F9) into a ramp question, so it reads as diligence rather than a confession |
| 6 | "What has the person who did well in this role done differently from the one who struggled?" | Gets a concrete bar to prepare against. It is not tied to Tobias's own path, because no interviewer research ran |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material names one main title and a content-drop calendar. B1's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The material says presenting, not owning. C1's slot asks only how the numbers were counted and which part was yours |
| Ran the release process with QA each release | Inflated form of F6 | F6's quote at its own scope: wrote the checklist. D3's slot stays inside how it is used |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I've never worked on a game with in-app purchases." No slot |
| Has led a team | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |

## Sources

Provided: the JD text you pasted, and your background message. No `tuesday-dossier.md` was present.

Searches sent, all refused:

- `Saltmarsh Games mobile studio values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy news 2026` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet and themed the VAL questions. Without it there is no cheat sheet and Bank G uses standard stems |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have set persona weights from documented rounds. They rest on the hiring-manager prior and your note that it is one 60-minute session |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current priorities. D2 is generic and the cases are role-family problems |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have added an interviewer read, persona adjustments and a reverse question tied to his path. All three are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Search access.** If you allow search, I can run the four research targets above. That would add Saltmarsh's published values, documented interview rounds, current strategy, and Tobias's public professional footprint, which would give a tailored reverse question and adjusted persona weights. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow; I am offering it once.
- **Confirmation of Tobias's role in the hiring chain** (your future manager, a skip-level, or a peer). This reweights every bank.
- **The recruiter's notes**, such as focus areas or a task to prepare. This adds coverage and a build section if a deliverable was announced.
- **Your CV text.** Rows built on message lines would be re-quoted from it, and rows F1 to F8 may gain better evidence.
- **Your answers to the answer slots in F1, F3, F4, F5, F6 and F8.** These would turn discovery and transferability rows into story-mapped guidance.
- **Hours available before Friday.** This adds a prioritized prep schedule.
- **A `tuesday-dossier.md` from an earlier job-underwriter pass.** It would add an evidence-checked map and a named top objection. It is not required.
