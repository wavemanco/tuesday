Web searches were denied, so I'm building the pack from your notes alone and writing the file now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-1-denied-0c6deff4/bf0223ff-acc8-4c6c-a883-e13ddfedb49f/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. I built it for a single 60-minute peer conversation with Dan, using only the notes you gave me.

- **Web search was denied.** I couldn't check Northwind's values, its interview process or Dan's public footprint. I wrote no values section and no interviewer detail beyond your profile summary. The Sources section lists the three refused searches.
- **The pack has 22 questions across seven personas.** Peer Evaluator and Data-Driven Prober carry the most weight (5 each). Case, Skeptic, Conversational, Pressure and Values follow, with 3, 3, 2, 2 and 2.
- **D1 is the highest-ROI prep:** the missing sales-ops and quota-setting background, asked by someone who runs sales strategy. The second priority is B1, where Dan walks Priya through the ~$400M ARR figure.
- **A few answers are left as slots.** Where your notes don't say what Priya actually did (how the $400M was counted, what fed the revenue model, any work done with no playbook), the guidance has her answer in her own words. I didn't fill those in.

I can run a live drill as Dan, starting with D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two things would change the pack:
1. Did the recruiter say anything about what Dan will cover, or announce a take-home or presentation?
2. Can you paste the full JD text and Priya's CV lines? Several rows currently rest on your summary instead of her own wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer. He and Priya would report to the same VP.
**Format:** one 60-minute conversation (session mode).
**Built on:** the coach's notes only. Web research was refused (see Sources), so every company fact below comes from the coach's research note and nothing else.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows good judgment and values in action |
| EXP | Whether the CV's claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Northwind's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Answer it from your own experience, in either branch. Saying plainly that a step was not yours, or never existed, is a complete and good answer.

## Fit snapshot

Source key: the coach's notes are the only source of evidence. The JD arrived as highlights, so requirement quotes are those highlights, not the full posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | transferability | The material shows product strategy and ops, not GTM ownership, and the words stay there: "I spent nine years at a large consumer-tech company in product strategy and ops." Answer slot: the JD's own-the-strategy line makes a probe on go-to-market work likely. If any of it was yours, say which part and what you decided, in your own words; if there was no such work, or it was not yours, say so plainly and stay with the product strategy and ops role |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Adjacent work with a headline figure and nothing inspected behind it. The words are the quote's: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." The material says proposed and credited, with no stage of the customer lifecycle named. Answer slot: if the change touched any lifecycle stage, say which, in your own words; if it did not, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools. A self-description with nothing inspected behind it, so expect a request to show a piece of analysis. Lead with the tools in the quote's own terms |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | A revenue model used in negotiations, which is adjacent to designing a partner motion and does not reach it. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how a partner arrangement was structured was yours to shape, say which, in your own words; if the model was the whole of your part, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: targets, set, across organizations, by consensus. Expect a probe on where the consensus was hard, which is answer-slot material for A3 |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | The quote shows use and does not show what for. Answer slot: say which tools and for what, in your own words; if use is narrower than a Compass-style product role would want, say so plainly and say what you would learn first |
| F7 | Sales-ops and quota-setting fluency. Not in the JD highlights: read from the interviewer's title, so unquoted prose and not a stated requirement | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap the coach stated, so the candidate can say it. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

No row is a gate: the JD highlights name no authorization, location, travel, pay or credential term, so no gate question is asked.

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 own GTM strategy for two new product lines | C1, C3, D2 |
| F2 whitespace across land/adopt/expand/renew | B4, B3 |
| F3 independent analysis in SQL and Tableau | B3, B1 |
| F4 partner-motion design | A5, B2 |
| F5 cross-functional influence | A1, A3 |
| F6 AI experience | E2, C1 |
| F7 sales-ops and quota-setting (interviewer's function) | D1, D2, F1 |

## Reading the interviewer

| What the notes say | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | "relentlessly data-driven" — the coach's notes on Dan's profile | Expect every number you give to be followed two levels down. Know what you can and cannot say about how each figure was counted, and say plainly where you do not know | [grounded] |
| "career spine is pricing and monetization roles" | the coach's notes | Case questions will likely arrive in pricing, packaging and unit-economics terms. Your material shows revenue modeling, not pricing work, so structure the answer and do not claim pricing experience | [grounded] |
| "one early-stage-startup chapter" | the coach's notes | Expect a probe on pace and scrappiness, aimed at someone from a very large company. D3 rehearses it | [grounded] |
| Peer, same VP | the coach's notes | He is pricing what you cost and add to his own work. Bring reciprocity: what you give his team, not only what you need | [grounded] |

Mirror opportunity: shared vocabulary in revenue modeling. Dan's pricing and monetization path pairs with the quote "built a partner-level revenue model used in carrier negotiations" (F4), at that scope only. No shared career jump is offered, because the material does not carry Dan's side of one.

## Persona table

Weights start from the peer-round prior (Peer Evaluator and Data-Driven Prober), then move on Dan's signals. The loop is one 60-minute conversation with Dan, per the coach's words, so no values round is detected and Values/Behavioral stays low.

| Persona | Weight | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator (A) | Top, 5 questions | Seam-splitting between his team and the new product lines; what you need from him; credit across teams | High. Peer prior, and the role sits next to his function | Reciprocity first. Propose seam principles and ask what his team owns before drawing a line. Disagreement stories with spine and tact |
| Data-Driven Prober (B) | Top, 5 questions | Walk-throughs of the $400M figure and the revenue model; a live SQL-flavored analysis question | High. Peer prior, raised by his "relentlessly data-driven" self-description | Know how each figure was counted or say you do not; name the weakest assumption you know of before he does |
| Case/Strategist (C) | Mid, 3 questions | Compass packaging and pricing, bundling response, sequencing two lines under a profitability priority | Medium. His pricing spine tilts cases toward packaging and unit economics; the three company priorities in the coach's research note give him material | Clarify, objective, segmentation, approach, metrics, risks. Think aloud; challenge one premise respectfully |
| Skeptic (D) | Mid, 3 questions | The missing sales-ops and quota-setting background; day-one weakness; big-company pace | Medium to high on the first. A sales-strategy peer is the person most likely to test F7 | Rehearse the one predictable objection until it is boring. Bridges only from quoted material; the limit said plainly |
| Conversational (E) | Low, 2 questions | Opening "walk me through the journey"; a casual question on AI | Medium. Peer conversations open this way, and the JD flags AI as a plus | A 90-second arc; treat the casual AI question as scored |
| Pressure (F) | Low, 2 questions | Time-boxed "why you" and "how much was you" | Low to medium. Peer rounds rarely interrupt, but the $400M figure invites an attribution push | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (G) | Low, 2 questions | Judgment and disagreement stories | Low. No values round is detected; included as insurance so no style is met cold | Selection scaffold with the honest branch; "we" for context, "I" for contribution |

## Question banks

Highest-ROI prep in this pack: **D1**. A Director of Sales Strategy is the most natural person to test the missing sales-ops and quota-setting background, and a rehearsed, non-defensive answer changes the conversation. B1 is second: the $400M figure will be taken apart by this interviewer.

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles, not a seam you cannot know: who owns the number, who owns the customer conversation, and where a disagreement goes (the shared VP). Ask what his team owns before drawing any line. Say how you disagree in the open with an equal, as a method. The question needs no claim about your past, so the guidance makes none | F5's requirement is the cross-functional line, and a peer asks it as seam-splitting. JD because it scores a stated requirement; the persona stem is the source |
| A2 | "What would you need from my team in your first 90 days?" | JD | [generic] | Name what you would ask for in terms of access and definitions, such as how his team defines pipeline stages and where the data lives, and pair every ask with what you would give back. Offer it as a plan, not a history | Peers price what a hire costs them. Reciprocity framing is the counter. JD because it tests the cross-functional requirement; the rationale is a pattern, so generic |
| A3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: annual volume targets, set across organizations, by consensus; tell it in your own words at that scope. Answer slot: if credit or ownership of the number was contested, say how it was handled and what part was yours; if it never came up, or was not yours to settle, say so plainly and stay with the targets and the consensus | Persona stem for the Peer Evaluator. VAL because it scores behavior with equals; F5 is the evidence |
| A4 | "Tell me about a time you disagreed with a peer team and didn't get the outcome you wanted." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a position you kept, and a working relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement-with-equals is the Peer Evaluator's scoring target. No quoted sentence carries it, so this is the scaffold case |
| A5 | "Two new product lines will ask sales to change what it does. How would you decide what to ask of sales and what to ask of partners instead?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | A live problem: clarify what each line sells and to whom, then the economics each channel needs, then the cost of changing seller behavior, then how you would test it. Where the partner side is concerned, say what you built at its scope: a partner-level revenue model used in negotiations. Answer slot: if you shaped how a partner arrangement was structured, say how; if you did not, say so plainly and stay with the model | The JD asks for partner-motion design (F4); the seam with a sales-strategy peer is exactly this tradeoff. JD with CASE delivery |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say it at the quote's scope: you proposed the change; it was credited with the uplift. Four slots, each in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least; which part was yours. Name the weakest assumption before he does. If you do not know how it was counted, say so plainly. Never describe a method you cannot repeat under a second question | F2's headline number is the first target for a self-described data-driven interviewer. EXP because it tests whether the number survives scrutiny |
| B2 | "Which assumption in your partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say the model at the quote's scope. Answer slot: what the model took as inputs and what moved its output most, in your own words; if you do not know, or the inputs were not yours, say so plainly and stay with the fact that you built it. On how it was used, say "used in carrier negotiations" and no more | The Prober checks the second quantitative claim after the first. F4 is the evidence, and the weakest-assumption move converts a gotcha into credibility |
| B3 | "Say I give you a table of enterprise accounts. What would you pull in SQL, and how would you show it in Tableau, to find where expansion is leaking?" | JD | [grounded] "skilled in SQL/Tableau" | A live problem. Say your skill at the quote's scope, then structure: define the stages first, state the grain of the table, name the cuts you would try, and say what each would change. Ask what data exists before assuming. Answer slot: if there is an analysis you did yourself in these tools, offer to walk it end to end; if there is none you can stand behind, say so plainly and show the method | F3 requires independent SQL and Tableau analysis; a data-driven interviewer tests it live. JD with CASE delivery |
| B4 | "How would you split land, adopt, expand and renew into things we can measure, and which stage would you distrust first?" | JD | [grounded] | A live problem from the JD's lifecycle line. Define each stage by the event that marks it, ask how Northwind defines them, then say which metric you would distrust first and why. A view about the problem, not a claim about your past | The JD's whitespace requirement (F2) is stated in these four stages, so the vocabulary is the interviewer's. Grounded in the supplied JD line |
| B5 | "Tell me about a time the numbers said one thing and your judgment said another." | EXP | [generic] | Selection scaffold: a decision where the data and your instinct split, what you checked, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | His self-description makes this a likely open prompt. No quoted sentence carries it, so it is the scaffold case |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is an AI copilot. Sketch how you'd package and price it for the enterprise base. What do you need to know first?" | CO | [grounded] | Clarify before structuring: who buys, what it replaces, what it costs to serve. Then options (standalone, add-on, bundled into a tier), the pricing metric each implies, the risk to the existing line, and how you would test. Challenge one premise. Your material shows revenue modeling and not pricing work, so structure the answer and claim nothing about past pricing | The coach's research note names Compass and enterprise expansion as stated priorities, and his pricing spine makes this his native ground. CO with CASE delivery |
| C2 | "A much larger platform vendor bundles a competing capability into its suite. How does your go-to-market for the new lines respond?" | CO | [grounded] | Clarify which capability and which segment. Then options: concentrate on segments where the bundle is weakest, make partners part of the answer, and lead with what a bundle cannot match. Say which you would test first and why. Do not guess which vendor | The research note names bundling by a much larger platform vendor as the main competitive threat. CO because it tests altitude; CASE delivery |
| C3 | "Profitability is a stated priority and you can't fund both lines at once. How do you sequence them?" | JD | [grounded] | Say you would first need to know the two lines, then state the criteria: size of the opening, readiness of the motion, cost to reach it, and learning value. Give a conditional recommendation and say what would change it | The research note names profitability as a priority, and the JD asks for ownership of strategy for two lines (F1). JD with CASE delivery |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sales strategy is what I run, and quota-setting isn't in your background. How do you expect to work with me?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | The deepest rehearsal. Open with the concession, plain: "I haven't had classic sales-ops or quota-setting experience." Then the adjacent work at its own scope: "I set annual volume targets with cross-org consensus." Do not call those targets quotas. Answer slot: if he asks how the targets differ from quotas, say the difference you know; if you do not know, say so plainly. Hold through two follow-ups by returning to the concession and the quote, never by adding to them. Close with a plan, not a past: the first things you would ask his team to teach you | F7 is the largest gap against this interviewer's own function. JD because it scores fit to the role; Skeptic delivery. Included as the highest-ROI prep |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Pick the weakness that is true and say it once, plainly. The pack's observation is that F1 and F7 carry the thinnest evidence, so those are the likeliest honest answers. If you name sales-ops or quota-setting, use the sourced sentence: "I haven't had classic sales-ops or quota-setting experience." Pair it with the first thing you would do to close it, stated as a plan | A stem the Skeptic uses at the end of a long conversation. Calibrated candor beats bluffing a competency the interviewer owns |
| D3 | "You've spent nine years inside a very large company. How do you work when the playbook doesn't exist yet?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Say the nine years at that scope. Answer slot: if you started any work without a playbook, name it and what you did; if you did not, or it was not yours, say so plainly and say how you would start. Do not call the proposal in F2 a zero-to-one effort | His startup chapter makes pace and scrappiness a likely probe. EXP because it tests what you actually did; F1 is the evidence |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the two quoted blocks: two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Answer slot: the last beat, why Northwind and why now, is yours; say the real reason in your own words. If no reason beyond the role comes to mind, say so plainly and say what in the role draws you | Peers open with the biography and score economy. The journey question is also where "why leave, why here" arrives in friendly form |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at the quote's scope: you use AI tools daily. Answer slot: which tools and for what, in your own words; if the use is narrower than building or launching anything, say so plainly and say how it would shape how you think about Compass. Treat this casual question as scored | The JD flags AI as a plus (F6), and rapport-style questions on the plus-skills are scored |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause, restate the question, then hold on three quoted facts at their own scope: skilled in SQL and Tableau, built a partner-level revenue model, set annual volume targets with cross-org consensus. Hold through two follow-ups by returning to those. Concede specifically by saying what you would need to learn first about Northwind, as a plan | Persona stem. F3, F4 and F5 are the evidence. JD because it scores fit to the role; Pressure delivery |
| F2 | "That ~$400M result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and it was credited with the uplift." Answer slot: after the proposal, which parts were yours, and who did the crediting, in your own words; if you do not know, or the rest was not yours, say so plainly and stay with the proposal. Concede the unknown specifically. Never fold on the core claim to restore comfort | F2 is the headline figure, and attribution is what a pressure push tests. EXP because it scores what was yours |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a message that was unwelcome, and a result where the truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. No values round is detected, so this is insurance, and no quoted sentence carries it |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: the metric, the customer need, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; low weight. Included so the style is not met cold |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization. How does that shape the way your team thinks about what the new product lines should cost to sell?" | Ties to his own career, signals you researched him, and puts him in his native language |
| R2 | "You've also spent time at an early-stage company. What from that period do you still reach for here?" | Converts a likely pace probe into a peer conversation about his own path |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it also answers A2 in advance |
| R4 | "Where do you see the remits of your team and this role overlapping most, and where do you want a clear line?" | Shows seam-awareness and hands him the first draft of the boundary |
| R5 | "How is success for the two new lines measured in year one, and who decides?" | Shows you think in outcomes and tells you who the real stakeholders are |
| R6 | "Where is bundling by the larger platform vendor showing up in deals today?" | Uses the main competitive threat in the coach's research note, and invites him to share what he sees |

## Prohibited claims

Built from the fit snapshot before the banks were written. Each entry is something this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience, or that the volume targets were quotas | Negative the coach stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." F5's quote at its own scope. No slot on the quota claim |
| Led, owned or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited. The limit is the pack's observation: the material says proposed and credited, not led or delivered. B1 and F2 slots stay inside the proposal |
| Designed or ran a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope: built a revenue model used in negotiations. The limit is the pack's observation: the material says the model, not the motion. A5's slot stays inside the model |
| Negotiated the carrier deals | Inflated form of F4 | The quote says the model was used in the negotiations; it does not say who negotiated. B2's slot stays inside the model |
| Owned or launched GTM strategy for products | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The limit is the pack's observation: the material does not show GTM ownership |
| Built, shipped or led AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily. E2's slot asks only what for |

## Sources

**Provided documents:** the coach's message, which supplied the JD highlights, the candidate summary, the interviewer profile summary and the research note on Northwind's priorities and competitive threat. No dossier was present.

**Searches sent, in order:**

| Query | Outcome |
|---|---|
| Northwind Data company values | refused |
| Northwind Data interview process strategy GTM | refused |
| Dan Kovac Director of Sales Strategy Northwind Data | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have set the official value names for a values cheat sheet. No values section is present; no values-style round is detected either way |
| 2. Northwind Data interview process, GTM strategy roles | unavailable | Would have documented the loop. The coach's words already establish this session as one 60-minute peer conversation, so persona weights rest on that |
| 3. Northwind Data strategy and recent news | skipped | The coach's research note already supplies the priorities and competitive threat the CO bank uses |
| 4. Dan Kovac, Northwind Data | unavailable | Would have added his talks and writing to the interviewer read, which now rests only on the coach's profile summary |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights the coach supplied fix the snapshot's requirement rows, though not in full text |

## Upgrade menu

- The full JD text → the JD highlights in F1 to F6 become exact quotes, and any mid-list requirement missing from the highlights gets a row and a question
- Priya's CV lines, verbatim → the evidence column now rests on the coach's summary, and quoted CV lines would let B1, B2 and D3 be story-mapped with beats
- Priya's answers to the answer slots in B1, B2, D3, E1 and E2, stated outside the pack → F1, F2, F4 and F6 regrade and their guidance can be tightened
- The recruiter's guidance on focus areas, or any announced deliverable → coverage stops resting on peer-round priors, and a deliverable would get its own build section
- Permission for web search → Northwind's official values, the documented loop and Dan's public talks and writing, which would add a values cheat sheet if a values round is documented and sharpen the interviewer read
- A tuesday-dossier.md with verified evidence and prohibited claims → the evidence rows would rest on user-confirmed claims, and the prohibited list would carry sourced entries in place of the locally built ones
