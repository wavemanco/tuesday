Web search wasn't permitted, so the pack below uses only your message. I'm writing it now and will note in it that the company research didn't run.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-denied-416f2a3c/d55b5e07-2758-4700-aa86-71f327a21c98/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions, each with answer guidance, plus a fit table, reverse questions and an upgrade menu.

- **Research didn't run.** My web searches (Saltmarsh's values and interview process, their strategy, and Tobias) weren't permitted, so none of that is in the pack. The Sources section lists all four attempts.
- **Write permission.** I also couldn't write to the project folder, so the file went to the scratchpad directory instead.
- **Interviewer assumption.** I built it as a hiring-manager round, since your note gave Tobias's title but not his relationship to the role. That puts case problems and skeptical probing first.
- **Your highest-ROI prep is B1.** It's the "three-plus years live-service" question, which the JD itself presses on. Your material shows four years as an associate producer and two on the weekly calendar. The guidance holds that wording exactly and has a prepared concession.
- **B2 and B3 come next.** They cover your two stated gaps, in-app purchases and never having led a team.
- **What I didn't write for you.** Several fit-table rows have answer slots for things your material is silent on, such as which teams you worked with and where the retention numbers came from. Fill those in yourself. I haven't scripted anything you didn't tell me.

I can play the Skeptic on B1 live. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

1. Is Tobias your future manager, a skip-level, or a peer? The answer reweights every bank.
2. Did the recruiter say anything about focus areas or something to prepare? If you paste your CV too, I'll fold it in, but I can go on without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Your note gave his title and a 60-minute slot, not his relationship to the role. This pack is built as a hiring-manager round on that assumption. Persona weights below rest on the hiring-manager prior, not on anything known about him.
**Loop:** one 60-minute session with Tobias, per your note. Nothing is known or asserted about any other round.
**Research:** company research did not run (see Sources). Nothing here about Saltmarsh's values, interview process, strategy or Tobias's background comes from outside your message.

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. No values were read for this pack, so no question is tagged VAL |
| EXP | Whether your claims survive scrutiny: what you actually did |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. None here: strategy research did not run, so none would be grounded |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` traces to your message or the JD you pasted; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## Prep triage

You interview Friday. In this order; the rest is insurance.

1. Say B1 aloud until it is boring. It is the pack's highest-ROI prep (reasoning under B1).
2. Say B2 and B3 aloud, then write your own answers to the slots in F1, F2, F3 and F5 and send them back; they turn thin rows into story maps.
3. Run A3 and A4 aloud as cases: clarify, structure, then answer.
4. Time D1 to 90 seconds.
5. Pick three reverse questions you would actually ask.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly calendar for the main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's calendar line makes a probe on how that calendar was built likely. If any part of the drops' timing was yours to set, say which and how you decided, in your own words; if it was set for you, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you dealt with on a drop. Answer slot: the JD names design, art, engineering and community, so a probe on which of them you worked with is likely. If you worked with any, say which and what you needed from them, in your own words; if you did not, or a drop did not involve them, say so plainly and say what you would agree with each team first |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | discovery | Your material says you presented the numbers, with nothing inspected behind it: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's review-and-KPIs line makes a probe on where those numbers came from likely. If you chose or pulled them, say how, in your own words; if someone else produced them, or no review was built around them, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I wrote the release checklist our QA team still uses." The JD's verb is manage and your material says wrote; the pack does not turn one into the other, and D3 holds the slot |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material says four years as an associate producer and, within them, two years on the weekly calendar; it is silent on what the earlier years held, and the words stay at that scope: "I have four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the JD's years line makes a probe on the earlier years likely. If any of them involved updates or releases you worked on, say which and what part was yours, in your own words; if they did not, say so plainly and stay with the two years of the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: a weekly calendar, a main title, two years, because a named cadence beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it. Lead with: "I presented the monthly retention numbers to the studio head." The limit is the pack's observation: your material says presented, not that you defined or analysed them, and C1's slot stays inside that |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Your material carries a written artifact still in use: "I wrote the release checklist our QA team still uses." Put it on the table at that scope and let the interviewer draw the inference; the pack does not call it proof of anything |
| F9 | in-app-purchase economy knowledge, a role-family requirement written from no source | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan a calendar, handle a late bug, diagnose a metric | High. Hiring-manager prior puts Case first, and the JD's calendar, release and review lines each suit a live problem | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps | High. Hiring-manager prior puts Skeptic second, and your own material states two negatives (F9 and no team led) and is silent on the earlier years (F5) | Rehearse B1 until boring; bridge only from what you stated, say the limit plainly, then give a concrete ramp plan |
| Data-Driven Prober | Reads the lines closely and asks how a number was counted | Medium. The JD names retention metrics and KPIs, but nothing is known about Tobias's style | Say plainly what you do and do not know about how each number was counted; name the assumption you would defend least before he does |
| Conversational | Friendly opener, "walk me through the journey" | Medium. Any 60-minute conversation opens somewhere, and casual questions are still scored | A 90-second arc built from your own sentences (D1) |
| Pressure | Time-boxed "why you", interrupts | Low to medium. Not a hiring-manager prior, but your material gives a time-boxed "why you" something to press on | Pause, restate, hold the claim your sentences carry through two follow-ups, concede specifically |
| Values/Behavioral | Scenario prompts: unwelcome news, holding a release | Low. No values-style round is documented for this loop, but a hiring manager can ask behavioral prompts, so two are included | Pick a real instance, or say plainly none comes to mind |
| Peer Evaluator | Seam-splitting between adjacent teams | Not weighted. No bank. It becomes plausible if Tobias turns out to be a peer, and the pack reweights then | Not applicable unless the relationship changes |

## Question banks

### Bank A: Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the next eight weeks for a mobile title's live calendar. What do you need to know first?" | CASE | [generic] | Clarify before structuring: the goal the next updates must serve, what is already locked, each team's capacity, what the last cycle taught. Then the structure: objective, what goes when, dependencies, metrics, risks. Think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | F1's requirement, asked as a live problem. CASE because it scores structure, not recall; generic because it is a pattern, not a fact about this employer |
| A2 | "You take on a second title with its own calendar and the same engineering team. How do you sequence the two?" | CASE | [generic] | Name what is shared and what collides, how conflicts surface early, who decides when two things compete for the same people, and what you would ask before moving anything. It asks about no past, so the guidance claims none | The JD's two-title line (F1) is where scale presses hardest; CASE because it is a decision problem |
| A3 | "An update is due Thursday and QA finds a blocking bug on Tuesday. Walk me through the next 48 hours." | CASE | [generic] | Clarify severity and who decides; lay out the options (fix, cut scope, delay, ship with the issue known); say what each team and the community are told and when; end with what you would change afterwards. No claim about your past | F4's requirement as a live problem. CASE because the structure matters more than the answer |
| A4 | "Retention for players who joined during last month's event is down against the cohort before. Diagnose it." | CASE | [generic] | Clarify first: which retention measure and window, against what, how many players, what else changed in that window. Then hypotheses, the data each needs, and your weakest assumption named before he asks. If you do not know how a figure would be counted, say so | F3 and F7 as a live problem; CASE with JD content |
| A5 | "How would you structure a post-event review so it changes the next event?" | JD | [generic] | Structure: the goal and KPIs agreed before the event, what happened against them, what was learned, what changes, who owns each action, and how it is written so people who were not in the room can use it. A plan, not a past: it claims no review you ran | F3 and F8: the JD's review line and its written-communication line meet here. JD because it scores the stated responsibility |

### Bank B: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for three-plus years producing live-service games. How do your four years line up against that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry: "I have four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Concession, worded in advance: "That is the span I can speak to." Follow-up 1, asking whether that adds up to three: say what the quotes carry and stop. Follow-up 2, asking about the earlier years. Answer slot: if any of them involved updates or releases you worked on, say which and what was yours, in your own words; if not, say so plainly and return to the two years of the weekly calendar. Follow-up 3, asking what you would be missing: give a ramp plan as a plan, never as a past | F5 is the row the JD itself presses on, so this objection arrives in some form, and nothing in the material closes it, which is why the limit is named before it is asked for. JD because it scores the stated requirement |
| B2 | "You haven't worked on a game with in-app purchases. How would that show up in this role?" | JD | [grounded] "never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | Say the acknowledgment and stop: "I haven't worked on a game with in-app purchases." Then a plan, stated as a plan: what you would learn first, who you would ask, what you would want a second pair of eyes on in your first events. The nearest thing your material carries is "I presented the monthly retention numbers to the studio head"; say it at its own scope and stop there. Hold through two follow-ups by returning to the acknowledgment, never by adding to it | F9 is the gap you named yourself, so it is the one you control best; the second most predictable objection after B1. JD because the question scores a gap in the role |
| B3 | "This role coordinates design, art, engineering and community on every update. You haven't led a team. How do you get four teams to hold a date?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say it plainly: "I haven't led a team." Answer slot: the JD's coordination line makes a probe on which of those teams you worked with likely. If you worked with any on the weekly drops, say which and what you needed from them, in your own words; if you did not, or the drops did not involve them, say so plainly and return to the calendar you ran. Then a plan, as a plan: what you would agree with each team before a date is set, and who decides if it slips | F2 and the stated negative. JD because the JD's verb is coordinate |
| B4 | "You presented the monthly retention numbers to your studio head. Where did those numbers come from, and which part of them was yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with the words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or pulled the numbers, say how, in your own words; if someone else produced them, or the question of whose part it was does not split that way, say so plainly and stay with presenting them. Hold through the follow-up by returning to presenting, never by adding to it | F3 and F7 are where the JD's KPI line presses against the material. EXP because it tests attribution |
| B5 | "You ran the weekly content-drop calendar. Which parts were decisions you made, and which were handed to you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start with the words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you set priorities or timing, say which and how you decided, in your own words; if those were set by others, or there was no such split, say so plainly and describe how the calendar ran week to week | F1 and F6. EXP because it tests what was actually yours |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention measures did you report each month, and how was each one counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with the words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's retention line makes a probe on the measures likely. If you know how they were counted, say so in your own words, including the assumption you would defend least; if you do not, or someone else owned the counting, say so plainly and stay with presenting them. "I don't know how that was counted" is an honest answer | F7. EXP because it tests whether the numbers survive scrutiny |
| C2 | "A KPI is up the week of an event. How do you decide the event caused it?" | CASE | [generic] | Structure: compare against what, what else changed that week, how much of the movement is noise, what would change your mind, and your weakest assumption named first. No claim about your past | F3 and F7 as a live problem, asked the way a prober asks |
| C3 | "Tell me about a time you looked back at a content drop and changed what came next." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The sentence carries the weekly calendar and the two years, and those are the only beats it states. Answer slot: the JD's review line makes a probe on what you looked at after a drop likely. If you reviewed drops, say what you looked at and what changed, in your own words; if there was no review, or it was not yours, say so plainly and describe how you ran the calendar week to week | F3 and F6. An open prompt: the theme comes from the JD, and the story is yours or the honest branch |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built from those four sentences in that order. The connecting sentences and your reason for this role are yours; none are written here. End on what you want from the next role, in your words | F5, F6, F4 and F7 are the whole of your material, and an opener is where all of it should be heard once. EXP because it is your own history |
| D2 | "What are you playing right now, and what does its calendar do that you would borrow?" | JD | [generic] | Name a game you actually play, one thing its calendar does, and one thing you would test. Never name a game you do not play. No claim about your past | F6's requirement, asked casually; casual questions on hot JD topics are still scored |
| D3 | "Tell me about the release checklist you wrote. What was it for?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Start with the words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's release-checklist line makes a probe on running it with QA likely. If you ran releases through it alongside QA, say how, in your own words; if QA ran it after you handed it over, or there was no such step, say so plainly and stay with having written it | F4 and F8. EXP because it tests what you did, and it is the artifact you can put on the table |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone with live-service and in-app-purchase experience?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause, restate the question. Hold: the calendar, the checklist and the retention presentation, each in the words above. Concede specifically: "I haven't worked on a game with in-app purchases." Through two follow-ups, return to the calendar, never add to it | F5 and F9 are what a time-boxed "why you" presses on. JD because it scores the gaps against the role |
| E2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if QA or others contributed, say what and credit them, in your own words; if you wrote it alone, say so; if the question's premise does not fit, say so plainly. Never claim a part you cannot repeat under a second question | F4. EXP because it is the attribution probe, and a pressure delivery tests whether you hold or fold |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you gave someone senior news they did not want about a date or a result." | EXP | [generic] "Presented the monthly retention numbers to the studio head" | Your material shows presenting numbers, not a hard truth landing, so no story is written. Pick a time with a named stake, a moment you said it plainly, and a relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, at its own scope, or how you would handle it | F7. EXP because no published values were read, so VAL does not apply; the theme comes from the persona stem |
| G2 | "Tell me about a time you held back a release or a drop because it was not ready." | EXP | [generic] "Wrote the release checklist our QA team still uses" | Your material shows a checklist, not a held release, so no story is written. Pick a time with a named cost of holding and who decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, at its own scope, or how you would handle it | F4. EXP because the JD's release-checklist line raises the theme |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B5, C3, D1 |
| Coordinate design, art, engineering and community on each update | B3, A2, A3 |
| Own the post-event review and the KPIs it reports | A4, A5, B4, C2, C3 |
| Manage the release checklist with QA | A3, D3, E2, G2 |
| 3+ years producing live-service games or apps | B1, D1, E1 |
| Experience running a content calendar | B5, C3, D1, D2 |
| Comfortable with player-retention metrics | A4, B4, C1, C2 |
| Clear written communication | A5, D3 — no separate question: the pack cannot know whether a writing exercise is part of the loop |
| In-app-purchase knowledge (not a JD line; your own stated gap, F9) | B2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first cycle look like for someone new to these calendars, and what would tell you at day sixty that it is going well?" | It asks for the success measure itself, which turns the years-of-experience objection into an agreed target |
| R2 | "Of the two titles, which calendar would you most like improved, and what is in the way?" | It shows you think in calendar terms and shows you the real job |
| R3 | "How are events judged after they run: which KPIs does the review report, and who has owned it so far?" | The JD makes the producer own the review and its KPIs, so it asks how settled that ownership is |
| R4 | "How do design, art, engineering and community agree on dates today, and where do dates slip most?" | It goes to the coordination line (F2) from the producer's side |
| R5 | "How closely does the calendar touch monetization, and who would I learn that from in my first month?" | It turns the gap you named (F9) into a ramp plan and tells you how much it matters |
| R6 | "What separates a good live-operations producer from a great one on your team?" | It invites his own standard, which you cannot research for yourself at this tier |

## Prohibited claims

What this pack will not coach, and why. Built before the question banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Has in-app-purchase experience | Negative you stated, F9: "never worked on a game with in-app purchases" — your message | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led or managed a team | Negative you stated: "Never led a team" — your message | "I haven't led a team." No slot. B3's slot asks only which teams you worked with |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for the main title. Slots stay inside that calendar |
| Has three or more years of live-service production | Inflated form of F5 | F5's quotes at their own scope. The limit is the pack's observation: the material says four years as an associate producer and two on the weekly calendar. B1's slot stays inside the earlier years |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says presenting the numbers. C1 and B4's slots stay inside that |
| Defined or analysed retention metrics | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says presenting the numbers |

## Sources

**Provided documents:** the job description pasted in your message; your background paragraph in the same message. No `tuesday-dossier.md` was present, so none was consumed.

**Searches sent, all refused (no result came back from any):**
1. "Saltmarsh Games mobile game studio values" — refused
2. "Saltmarsh Games interview process Live Operations Producer" — refused
3. "Saltmarsh Games strategy news mobile titles" — refused
4. "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

No pages were fetched. Nothing in this pack about Saltmarsh's values, loop, strategy or Tobias's background comes from outside your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have moved a values cheat sheet, if a values-style round had been documented; no such round is detected, so none is written |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | Every call was refused. It would have moved persona weights and the round structure, now resting on the hiring-manager prior and your own note of one 60-minute session |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have moved a grounded CO or CASE question; the CASE questions here are generic and there is no CO question |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have moved the interviewer read and persona weights, and tied a reverse question to his own path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Web search allowed for this session → values, documented loop, current strategy and Tobias's public footprint, replacing the generic CASE questions and role-generic reverse questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a grounding brief
- Your relationship to Tobias (future manager, skip-level, or peer) → persona weights and banks reweighted
- The recruiter's notes on focus areas or anything to prepare → coverage and any graded deliverable
- Your CV text → more quoted evidence, possibly moving F2, F3 and F5 off thin rows
- Your answers to the slots in F1, F2, F3 and F5 → those rows become story maps in B1, B3, B4 and C3
- The release checklist itself, a content calendar export, or a retention deck you presented → F3, F4, F6, F7 and F8 can move from medium to high
- A `tuesday-dossier.md` from a job-underwriter pass would add verified evidence and the objection worth deepest rehearsal
