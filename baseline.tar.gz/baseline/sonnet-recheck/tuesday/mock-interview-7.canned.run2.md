Searches came back with attributable results for the values, the loop, the strategy and Tobias. I'm now fetching the official values page and the interviewing page to get the exact wording.
The write to the working directory was declined, so I'm saving the pack to the session scratchpad instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-canned-68f382fe/3ae37285-6a97-4f3d-ac5f-abd801cb002f/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. The write to your working directory was declined, so it went to the session scratchpad.

I built it for the format Saltmarsh's interviewing page describes. That is one 60-minute session with the hiring manager: a live-incident tabletop on a simulated outage, then a values conversation. The pack has 23 questions across seven interviewer styles, with answer guidance written from your own sentences. It also has an interviewer read on Tobias, six reverse questions, the three published values mapped to stories, and a list of claims not to make.

Research was light: 4 of 6 searches and both page fetches. I read the values and interviewing pages in full. The Project Larkspur announcement (shared events calendar and a single live-ops group from January 2027) comes from a search result only, so question A4 and reverse question R3 rest on that summary. Tobias's public footprint is a GDC 2026 talk, "Patch Notes Are a Promise", and a past role as a QA lead.

Your biggest prep item is C1, the in-app-purchase question. The pack rehearses a plain "I've never worked on a game with in-app purchases", then a plan with no bridge. Your material has nothing adjacent to it. Your never having led a team is handled the same way.

Say the word and I'll run a live drill as the Skeptic on C1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you want the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or further up? And has the recruiter said anything about what the tabletop covers? Either answer reweights the banks. Do you also want a deeper research pass, with up to 6 more searches and 2 more fetches taking several more minutes? It would fetch the Larkspur page itself and read more of Tobias's talks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship to the role not confirmed; built as the hiring-manager session that Saltmarsh's interviewing page describes: a 60-minute live-incident tabletop on a simulated outage, then a values conversation. Candidate: Femi. Interview: Friday.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Quoted sentences are yours, taken from your message; anything not quoted is a slot for you to fill truthfully or to leave empty.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The listed responsibilities and requirements, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem |

## Prep triage

Interview is Friday, so the order below is what to do first. Everything else is insurance.

| Order | Do | Where |
|---|---|---|
| 1 | Say the C1 answer aloud until it is boring: plain acknowledgment, then plan | C1 |
| 2 | Run the tabletop structure twice out loud: clarify, objective, who, what players are told | A1, A2 |
| 3 | Settle your Leave the Build Greener story, and decide your honest branch for the other two values | B1, B2, B3 |
| 4 | Read the F1 to F4 answer slots and decide, before Friday, which branch is true for you | Fit snapshot |

## Fit snapshot

Gaps F8 and F9 are limits you stated; they are not JD lines.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives the years and the title, not whether the title ran as a live service, so the words stay at: "I've spent four years as an associate producer at a puzzle-game studio." Keep the word associate. Answer slot: the JD's live-service wording makes a probe likely. If the title was updated on a schedule over time, say how, in your own words; if it was not run as a live service, or you did not work on it that way, say so plainly and stay with the weekly drops in F2 |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows a weekly content-drop calendar for one title, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." The JD says events and two titles; your material says drops and one. Answer slot: if any drops were time-limited events, say how they were planned, in your own words; if none were, or events were not part of it, say so plainly and stay with the weekly drops |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show who you worked with on each drop, and it says you have never led a team (F8), so coordination is not leadership here. Answer slot: if you worked with any of those four teams on a drop, say which and what you needed from each, in your own words; if none were part of it, or you did not work with them, say so plainly and say how you would set up your first update with them |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material shows presenting monthly retention numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." Presenting numbers is not owning a review. Answer slot: the JD's KPI line makes a probe on how those numbers connected to specific events likely. If they did, say how, in your own words; if they did not, or that was not yours, say so plainly and stay with the monthly presentation |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: "I wrote the release checklist our QA team still uses." Your material says wrote and still uses; nothing in it says managed, and nothing is added about how it was run with QA. Nothing inspected stands behind the line, so expect a probe |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on its face, but nothing inspected stands behind it, so expect a probe. Lead with it in the quote's terms: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's wording makes a probe on which measures likely. Say which, in your own words; if someone else prepared the numbers, say so plainly and stay with presenting them |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Written work exists in your material; it shows a checklist was written, not how clear it was. Answer slot: if you have a written piece others used and can show it, be ready to talk through it; if you have nothing you can show, say so plainly and say how you would write your first post-event note |
| F8 | people leadership (not a JD line; the JD asks you to coordinate teams) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A limit you stated, so the pack gives it back in your words: "I've never led a team." Then how you would learn it, said as a plan and never as a past. No bridge and nothing added to make it feel smaller |
| F9 | familiarity with in-app purchases in live events (not a JD line) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A limit you stated, so the pack gives it back in your words: "I've never worked on a game with in-app purchases." Then what you would want to learn first, said as a plan and never as a past. No bridge |

## Reading the interviewer

Public professional footprint only.

| Public fact | Source | What it means for Friday | Provenance |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | talks.gdconf.example/2026/patch-notes-are-a-promise | Release checklists and QA vocabulary are his native ground, so F5 will be heard closely | [grounded] |
| GDC 2026 talk "Patch Notes Are a Promise"; argument: a live team is judged by how often its patch notes describe what actually shipped | same page | Expect questions about what players are told versus what is built; his talk title echoes the value Ship the Patch Not the Promise | [inferred] |
| Mirror opportunity: his QA background beside your F5 quote, "Wrote the release checklist our QA team still uses." | same page; F5 | Shared professional vocabulary, not a shared career jump; mention the checklist in its own terms and do not build on it further | [inferred] |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case / Strategist | The simulated outage during a live event | High: saltmarshgames.com/careers/interviewing says the hour opens with a live-incident tabletop; the hiring-manager prior also points here | Clarify, objective, who, what players are told, risks; think aloud; challenge one premise | A (5) |
| Values / Behavioral | The second half of the hour | High: the same page says a values conversation follows; the three values are published at saltmarshgames.com/values | Map a story to a value only where your sentences carry one; otherwise pick honestly | B (4) |
| Skeptic | Quiet probing of the gaps | High: hiring-manager prior; F8 and F9 are limits you stated | Rehearse C1 until boring; no bridge where there is no adjacent evidence | C (4) |
| Pressure | Time-boxed, interrupting | Medium: the tabletop is time-pressured; the page does not say the interviewer interrupts | Pause, restate, hold through two follow-ups, concede only what is true | D (3) |
| Data-Driven Prober | Line-by-line on numbers and announcements | Medium: F4 and F6 rest on retention numbers; his talk is about notes matching what shipped | Say how things were counted, or say you do not know | E (3) |
| Conversational | Opening chat | Low: likely only as the opener | A 90-second arc from your own sentences | G (2) |
| Peer Evaluator | Seam-splitting between teams | Low: he is a head of department; the JD names four teams to coordinate | Offer seam principles, not a pretended seam | H (2) |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and players report rewards are not being granted. You have an hour. Where do you start, and what do players read first?" | CASE | [generic] | Clarify first: what is broken, who is affected, since when, what is known versus suspected. State the objective, then who you need (the JD names engineering and community), then draft the player message aloud using only what is confirmed. Challenge one premise politely. The question needs no claim about your past, so the guidance makes none | The tabletop is the first half of the hour per the interviewing page; CASE with JD content, since it touches the written-communication line (F7) |
| A2 | "The fix needs a hotfix build. QA's checklist takes longer than the event has left. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | You may speak as the checklist's author, in the quote's words: you wrote it and QA still uses it. Then structure the call: what QA says can and cannot be cut, what the options cost, who decides. Answer slot: the JD's checklist line makes a probe on what you would change under time pressure likely. If you have ever decided that, say how you decided; if it was never yours to decide or never came up, say so plainly and say what you would ask QA first | F5 is the evidence and the most natural seam to Tobias's QA background; CASE with JD content |
| A3 | "The event is over and retention for players who joined during it is below plan. Diagnose it." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify: below what plan, which cohort, which measure, compared with what baseline. Segment, hypothesize, say what you would check first. Story-map only what the quote carries: you presented the monthly numbers to the studio head. Answer slot: the JD's retention line makes a probe on which measures you worked with likely. Say which, in your own words; if someone else prepared them, say so plainly and say what you would ask first | F4 and F6 meet here; JD because it scores the KPI and retention lines, with CASE delivery |
| A4 | "From January there is one shared events calendar and one live-ops group. How would you sequence the first quarter?" | CO | [grounded] Project Larkspur announcement, saltmarshgames.com/news/project-larkspur, via search result | Clarify first: which titles, what the season-pass cadence allows, what each team needs from the calendar. Use only what Saltmarsh announced and say what you would want to learn. You may state the calendar fact in the quote's words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles wording makes a probe on whether you have planned more than one title likely. If you have, say how, in your own words; if not, say so plainly and stay with the one title | The differentiator question most candidates will not touch; resting on one search-result summary, so keep claims to what it states. F2 is the evidence |
| A5 | "A community poll says a planned event should slip, and the calendar says ship. Which wins, and how do you tell the teams?" | CASE | [grounded] Players Before Plans, saltmarshgames.com/values | Their published value says that when the calendar and players disagree, the players win; show the reasoning rather than the slogan: what the poll does and does not tell you, what slipping costs the teams, how you tell each team. The question needs no claim about your past, so the guidance makes none | A live problem built from a published value; CASE because it is decided live |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] Players Before Plans, saltmarshgames.com/values | Selection scaffold: pick a time a planned release met a reason to change it from the player side; it needs a named stake, what you did and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value; no quoted sentence carries this story, so it is a scaffold |
| B2 | "Tell me about a time you had to decide what to tell players about something not yet built." | VAL | [grounded] Ship the Patch Not the Promise, saltmarshgames.com/values | Selection scaffold: what you said, what was true at the time, what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second published value, and the theme of Tobias's talk; no quoted sentence carries it |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F5: the beats are the ones the quote states: you wrote the checklist and QA still uses it; tell them in your own words. Answer slot: the value's checklist wording makes a probe on whether it changed after releases likely. If you revised it, say what changed and why; if you did not, say so plainly and stay with writing it | The third published value; F5 is the only quoted sentence that reaches it |
| B4 | "Tell me about a time you delivered an unwelcome truth to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: it needs a named stake, the moment, and the relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you presented the monthly retention numbers to the studio head | Standard values-round stem; nothing quoted says the numbers were unwelcome, so the pack supplies no ending |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases in your background. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI prep in this pack. Say it plainly first: "I've never worked on a game with in-app purchases." Name the limit before it is asked for, with no bridge: nothing in your material is adjacent to it. Then the plan, as a plan: what you would want to learn first and from whom. Follow-ups to expect: what would you learn first; what if the first event is revenue-sensitive; can you start without it. Concession wording: "That's a real gap for me today, and I'd rather say so than stretch what I've done." Do not claim anything beyond your own sentence | F9 is the stated limit; JD because it tests the role's fit, gap included. The Larkspur season-pass shift makes a probe more likely, which is this pack's inference |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose before they do. Look at where your quotes are thinnest in the snapshot (F2, F3, F4) and where you stated a limit (F8, F9). Selection scaffold: name one requirement, say why in your own words, and say the first thing you would do about it. If no single weakness comes to mind, say so plainly | Persona stem; the answer is picked from the snapshot, not supplied |
| C3 | "You've run a weekly content-drop calendar for one title. This role runs live events for two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell the quote's beats in your own words: weekly, main title, the last two years. Answer slot: the JD's events and two-titles wording makes a probe likely. If any of it involved time-limited events or more than one title, say how, in your own words; if not, say so plainly and stay with the one title. Then what you would ask first about the second title, as a plan | F2 is the evidence; the likeliest bridge question after C1 |
| C4 | "You wrote the release checklist QA still uses. What was yours and what was QA's?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say it in the quote's words: you wrote it and QA still uses it. Answer slot: if QA changed it or you kept it up with them, say who did what; if you only wrote it, say so plainly and stay there | F5; a quiet attribution probe from a former QA lead, scored against the checklist line |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run live events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | Pause, restate, then anchor in those three sentences, in their words. Hold through two follow-ups by returning to them, not by adding to them. Concede only what you stated: "I've never worked on a game with in-app purchases." Do not say what your history proves; describe it and let them infer | Persona stem; F2, F5 and F6 are the held position and F9 is the concession |
| D2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote's words: "I ran it." Answer slot: if others shaped parts of it, say which parts and whose; if it was yours throughout, say so and stay with what the quote says. Where the word ran is ambiguous, take the smaller reading | Persona stem on attribution; F2 is the evidence |
| D3 | "An executive messages you to extend the event, and engineering says no. You have two minutes." | CASE | [generic] | Pause, restate the conflict, ask what each side knows, make a call, state the one thing you would concede and the one you would not. No claim about your past is made | Tests composure on a live decision; CASE delivered under pressure |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the retention numbers you presented each month: which measures, and how were they counted?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start with the quote: you presented them monthly to the studio head. Answer slot: say which measures and how each was counted, in your own words; if you did not prepare how they were counted, say so plainly. Name the assumption you would defend least if you know one; if you do not know, say that | F4 and F6; the JD's retention line scored as a defend-the-number probe |
| E2 | "Tell me about a time you checked what you had announced against what actually shipped." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: what was announced, what shipped, what you did about any difference. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you wrote the release checklist QA still uses, and no more than that | Raised by the theme of Tobias's talk and the second value; VAL content, EXP delivery |
| E3 | "Which of your numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the assumption you would defend least in your own words, before they do; if you do not know how a figure was counted, say so plainly | The weakest-assumption move for a metric answer; F6 |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are those four sentences, in your own words, in that order. Answer slot: why this role and why Saltmarsh are yours to say, resting only on what you have read, such as the three values and the Outage Hour format | The opener is scored; F1, F2, F5, F6 supply the beats |
| G2 | "What live event in a mobile game have you admired lately, and why?" | JD | [generic] | Pick one you have actually played; say what it did for players and what you would borrow. No claim about your past is made | Casual questions about the hot JD topic, the live-events calendar, are still scored |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where is the seam between a producer and design on an event, and what happens when you disagree?" | JD | [generic] | Offer seam principles rather than pretending to know their seam: who owns the calendar, who owns the content, how a disagreement gets decided. Selection scaffold for the disagreement story: a named stake and an intact relationship; if no such time comes to mind, say so plainly | The JD names four teams to coordinate (F3) |
| H2 | "What would you need from engineering and from community in your first month, and what would you give them?" | JD | [generic] | Reciprocity framing: what you need and what you bring each team. Keep the offer to what you can do from the role, not to what your history proves | F3 again, from the collegial side |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | C3, G1 |
| "Plan and run the live-events calendar for two of our mobile titles" | C3, A4, G2 |
| "coordinate design, art, engineering and community teams on each update" | H1, H2, A1 |
| "own the post-event review and the KPIs it reports" | A3, E1 |
| "manage the release checklist with QA" | C4, A2, B3 |
| "comfortable with player-retention metrics" | E1, E3, A3 |
| "clear written communication" | none JD-tagged: A1 and E2 touch it; the tabletop scores it through the message you draft, and F7 holds the gap |

## Values cheat sheet

A values conversation is documented on saltmarshgames.com/careers/interviewing.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (B1): a named stake, what you did, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (B2): what you said and what was true then. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than found | F5: "Wrote the release checklist our QA team still uses." The beats are that you wrote it and QA still uses it; whether you revised it after releases is a slot for you (B3) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've been a QA lead and now run live operations. What carried over?" | Tied to your interviewer's public path; it opens the QA and checklist ground where your F5 line sits |
| R2 | "Your GDC talk said a live team is judged by whether its patch notes match what shipped. How does the team check that?" | From his own published argument; shows you read it |
| R3 | "With the shared calendar from January, how does this role sit in the single live-ops group?" | Tied to a published announcement; it also answers something you need to know about the job |
| R4 | "What does the post-event review look like today: who reads it, and what changes because of it?" | The JD makes you the owner of it; it is diligence that does not claim you have done one |
| R5 | "Where is this producer's authority clear, and where do they have to persuade?" | Fits a role that coordinates teams, and tells you what the job needs given F8 |
| R6 | "What does a good first 90 days look like?" | A standard question that shows you plan; ask it last |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F2 | F2's quote at its own scope; the limit is the pack's observation: your material says weekly drops for one title |
| Owned post-event reviews and their KPIs | Inflated form of F4 | F4's quote at its own scope; your material says presenting retention numbers |
| Managed the release process with QA | Inflated form of F5 | F5's quote at its own scope; your material says wrote it and still uses it |
| Led a team | Negative you stated, F8 | The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD and your background, as you wrote them. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | The three published values by name; B bank, A5, cheat sheet |
| 2. Saltmarsh interview process | yes | Loop of one 60-minute hiring-manager session, tabletop then values; persona weights and bank order follow it |
| 3. Saltmarsh strategy and recent news | yes | Project Larkspur, August 2026, from the search result only; A4 and R3 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | His role, QA background and talk; the interviewer read, E2, R1, R2 |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and results:

- "Saltmarsh Games values": saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer": saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile": saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games": talks.gdconf.example/2026/patch-notes-are-a-promise
- Fetched saltmarshgames.com/values and saltmarshgames.com/careers/interviewing

## Upgrade menu

- Whether Tobias is your direct manager or further up → persona weights and the reverse bank retuned
- The recruiter's note on what the tabletop covers → coverage tuned to it, and a build section if any deliverable was announced
- Your answers to the slots in F1 to F4, F6 and F7 → those rows regenerate and the banks that draw on them upgrade from slots to story-mapped answers
- A redacted copy of the release checklist, a content calendar page, or a retention deck → F2, F4, F5, F6 and F7 can rise from medium or low toward high
- A strategy brief you supply → a grounding section; A4 and R3 currently rest on one search-result summary of the Larkspur announcement
- A tuesday-dossier.md from earlier work on this role → confirmed evidence and a named top objection in place of this pack's inferences
