I read your message as a request to tailor your resume to this role. I haven't changed anything, and every edit below is a proposal waiting for your approval.

**On the keyword theory.** The one study I have on how recruiters screen is small, but it doesn't back it. It is an interview study of 25 US recruiters, run by a résumé-builder vendor, and the vendor says its findings are themes, not representative statistics. In it, "AI/content auto-rejection configured: 8% of recruiters" (cite C25), and "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are the yes/no eligibility checks in the application form, such as work authorization, licence and location. Where match scores exist, "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). So keywords may affect your ranking, but I can't say that is why you've been rejected.

A bigger issue is that most of this JD's tools don't appear anywhere in what you gave me. Reordering and truthful keyword placement can make your real experience findable. They can't supply Terraform, ArgoCD or Istio, and I won't write them in. Whether this role is worth applying to at your current evidence is job-underwriter's question, not this one's.

**Assumptions.** The JD gives no tiers, so I treated the duty it states in prose, owning platform reliability, as the anchor. I rated Kubernetes, Terraform, AWS EKS, CI/CD and SRE practices as must-have. The rest of the tool list I rated important or preferred. I'm also working from the lines you pasted here, not from the PDF.

## Edit ledger — resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | *(unchanged — moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | *(unchanged — moved to the second bullet, qualifier kept)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` your resume | pending your approval |
| E3 | Skills | *(Kubernetes is not in your skills list)* | "Kubernetes (two-month proof-of-concept, not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` your resume | pending your approval |

I left the skills list's other items unchanged because every reorder I could make there would only be cosmetic.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | Kubernetes | must-have | `surfaced_by_edit` | E2 and E3. Proof-of-concept only, never production, and the labels say so. | `[grounded]` your PoC sentence |
| C2 | Terraform | must-have | `not_evidenced` | Ansible is config management, not infrastructure provisioning. See recall row C2. | `[grounded]` nothing in your resume names it |
| C3 | AWS EKS | must-have | `not_evidenced` | You list EC2, S3, RDS and IAM. EKS is not listed. See recall row C3. | `[grounded]` your AWS list |
| C4 | CI/CD | must-have | `surfaced_by_edit` | E1. Your Jenkins pipeline stays in your words; I don't relabel it. | `[grounded]` your Jenkins sentence |
| C5 | GitLab as the CI/CD tool | must-have | `not_evidenced` | Your pipeline experience is Jenkins. See the named absences below. | `[grounded]` your resume |
| C6 | SRE practices, platform reliability | must-have | `not_evidenced` | The resume describes pipeline and job maintenance, not reliability work. See recall row C6. | `[grounded]` your resume |
| C7 | ArgoCD, GitOps | important | `not_evidenced` | See the named absences below. | `[grounded]` your resume |
| C8 | Prometheus, Grafana, observability | important | `not_evidenced` | You have CloudWatch for monitoring. That is a different tool, and I won't relabel it. | `[grounded]` your CloudWatch line |
| C9 | Helm | important | `not_evidenced` | Possibly used in your PoC, which is unknown. See the PoC question. | `[grounded]` your resume |
| C10 | Istio, service mesh | important | `not_evidenced` | See the named absences below. | `[grounded]` your resume |
| C11 | Python | important | `already_evidenced` | "Bash and Python scripting" is already in your skills line. | `[grounded]` your skills line |
| C12 | Vault | preferred | `not_evidenced` | See the named absences below. | `[grounded]` your resume |
| C13 | Go | preferred | `not_evidenced` | See the named absences below. | `[grounded]` your resume |

## Recovery per gap

**Recall prompts.** These three could be real experience that your resume doesn't show.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C2 | Terraform | must-have | Ansible for config management, and no infrastructure-as-code tool for provisioning. | Terraform is listed second in the JD, and a resume without it leaves the gap visible. | Terraform used for a side project; a module someone else wrote that you modified; provisioning your PoC cluster with it | A repo, a PR, a module, a plan output | `[grounded]` what the resume does and does not say; `[generic]` what this costs on platform-engineering applications |
| C3 | AWS EKS | must-have | Four AWS services listed, with no managed Kubernetes. | The JD names EKS specifically, and your PoC is the one place it could have come up. | PoC run on EKS rather than local or self-managed; cluster creation; IAM roles for service accounts | PoC write-up, architecture notes, cluster config | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C6 | SRE practices, platform reliability | must-have | Pipeline building and Jenkins job maintenance, with no on-call, incident, SLO or alerting language. | The JD says you "will own platform reliability", so this is the duty itself. | On-call rotations; incident reviews or postmortems; alert tuning; uptime targets you tracked | A postmortem, an alert runbook, a CloudWatch dashboard | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences.** Each of these is a plain gap in your current evidence, with a closing path.

- **C5, GitLab CI.** You have no GitLab experience on the page. To close it, run a real project's pipeline on GitLab, for example porting a small Jenkins job. It is a weekend of work, and the repo would be something you can show.
- **C7, ArgoCD and GitOps.** To close it, stand up ArgoCD against a small cluster repo and keep that repo as evidence. It is only worth doing if you decide the role is worth pursuing.
- **C10, Istio and service mesh.** To close it, install Istio on a local cluster and write up a traffic-routing example. This is a real stretch from a PoC-level Kubernetes base. For a role that lists it among many tools, it may not be worth closing before you apply.
- **C12, Vault.** To close it, do a small integration where an app reads a secret from Vault. It is preferred rather than required, so it can wait.
- **C13, Go.** To close it, write one small tool in Go and publish it. It is preferred, and your Python is the relevant strength.

## Parse-safety check

I checked the layout you described, but I haven't seen the file itself.

| Check | What I can see | What it costs | Provenance |
|---|---|---|---|
| Multi-column layout | You describe two columns. | Parsers may serialize both columns line by line, so text interleaves and dates detach from roles. | `[generic]` how extraction fails on columns |
| Icons for each skill | You describe icons next to skills. | Icons may render as garbage characters or be skipped. If a skill's level is shown only by the icon, that information is absent. | `[generic]` how extraction fails on images |
| Contact details in the header | You describe contact details in the header. | Parsers may treat headers as page furniture and discard them, which can leave you unreachable. | `[generic]` how extraction fails on headers |
| Section headings, file type, hidden text | Not checkable from your description. | I can't say. | `[generic]` |

I report these risks and stop there. I haven't redesigned anything.

## Not written, and why

- "Terraform", "ArgoCD", "Istio", "Prometheus", "Grafana", "Vault", "Helm", "Go", "GitLab" or "AWS EKS" in any skills line or bullet. None appears in anything you gave me.
- "Kubernetes experience" or "managed Kubernetes clusters" without the proof-of-concept qualifier. Your sentence says it never went to production, and an interviewer will ask.
- "Observability" for your CloudWatch work. The JD's word names a broader kind of work than "monitoring", and the swap would change what you did.
- "CI/CD (GitLab)". Your pipeline is Jenkins.
- "Platform Engineer" as your title, or any "owned platform reliability" line. You are a DevOps Engineer, and the evidence doesn't show reliability ownership.
- "SRE practices". No sentence of yours supports it.

## Upgrade menu

- **Your resume as pasted text or the original file.** I could quote it verbatim, so the traces above would be exact, and I could run the parse-safety check on the real file instead of your description.
- **A write-up or repo of your Kubernetes proof-of-concept.** This is the inspectable proof for container platforms. It would raise C1 from a stated claim to one a reader can check, and it would settle C3 and C9.
- **Any Terraform code, a runbook, a postmortem or a monitoring dashboard.** Each one would turn a recall row into a grounded edit.
- **Earlier resume versions.** They often hold evidence that the current version dropped.

## Questions

C3 — Was your Kubernetes proof-of-concept run on EKS, and did you use Helm?
C2 — Have you written or modified Terraform anywhere, at work or outside it?
C6 — Have you been on call, written up an incident, or tuned alerts for anything you ran?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.