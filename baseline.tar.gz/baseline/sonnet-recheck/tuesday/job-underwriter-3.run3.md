Web search was declined, so I'm finishing this from the posting and your details alone.

## Decision snapshot

**Not worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay $70–85k), R2 (On-site in Austin five days a week)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content)
- `important`: adjacent: R9 (Team of one, thrive on ambiguity) · unclear: R7 (Brand, PR, partnerships), R8 (Sales ops)

R3, R4 and R5 are a strong paper match, but they do not offset the failures at R1 and R2.

**Opportunity ledger.** Your instinct is borne out. Beyond the two terms that rule it out for you (RR1, RR2), the posting packs seven functions into a team of one (RR3), with open-ended hours (RR4) and success measures it says will "evolve" (RR5). The pay sits oddly against its own seniority bar (RR6). The employer is unverified (RR8).

- **Hard gates:** failed: R1 (Base pay $70–85k), R2 (On-site in Austin five days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1's base would have to reach your $150k floor, and R2 would have to allow remote work from Portland. The posting says "no exceptions" on location, so neither is open as written.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" (the employer's own claim, not checked) | `[grounded]` JD header |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget, headcount plan or tools stated | `[grounded]` JD; silence on budget `[inferred]` from absence in the JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | Austin office five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside" (no percentage, vesting or valuation given) | `[grounded]` JD |
| Success measures | "Will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD |
| Scope read | Several full functions in one seat, with no support stated | `[inferred]` from seven named channels against "a team of one" |
| Market calibration | Not established. The role-family search did not run, so there is no band for this title and scope, and I won't supply one from memory | — |
| Unknowns | Equity size and terms; any budget; whether the office and posting are live as described; who owns sales versus marketing today | — |
| Contradictions | None inside the JD. It was not checked against Novaline's own site | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of $70–85k (your floor is $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor, which is your own and specific. Fit fails because the top of the posted range is below it | `[grounded]` JD quote and your statement | Surface only; the range or your floor would have to change |
| R2 | On-site in Austin five days a week (you are remote-only, in Portland) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. Fit fails because the JD says "no exceptions" | `[grounded]` JD quote and your statement | Surface only; the employer's terms or your relocation stance would have to change |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, including Head of Growth. It is self-reported with no artifact inspected, so it stays at `medium` | `[grounded]` your intake prose | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at two B2C subscription companies, with a controlled budget while scaling from $8M to $40M ARR over three years. Self-reported, nothing inspected | `[grounded]` your intake prose | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Self-reported, nothing inspected | `[grounded]` your intake prose | none |
| R6 | SEO/content | must_have | unclear | low | discovery | Your summary doesn't mention SEO or content. A growth-lead title is indirect context only | `[grounded]` your summary's silence | Would need a specific SEO or content example. It can't change the status (see G1) |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing in your summary touches these | `[grounded]` your summary's silence | Would need examples if you want these rows closed (see G2) |
| R8 | Sales ops | important | unclear | none | discovery | Nothing stated. The role sells to e-commerce businesses, whereas your companies were B2C subscription | `[grounded]` your summary's silence; `[inferred]` B2B read from "e-commerce enablement" | See G2 |
| R9 | Team of one; thrive on ambiguity | important | adjacent | low | transferability | You have run teams of 3–7 and are hands-on in SQL, GA4 and Braze. Limit: nothing stated about running seven functions with no support | `[grounded]` your summary; limit `[inferred]` from its silence | See G3 |

## Gap recovery queue

No questions this turn: the gate failures settle the decision, and none of these gaps could move it.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Nothing stated about SEO or content | It affects fit only; the status stays `no_go` either way | Owning an organic-traffic target, a content calendar or landing-page programs that fed paid or lifecycle | A traffic or rankings dashboard export, a content brief | `[grounded]` your summary's silence |
| G2 | Brand, PR, partnerships, sales ops (R7, R8, important) | discovery | Nothing stated | Same; fit only | Affiliate or referral partners, press launches, handoff to a sales team | Partner agreement, press coverage list, CRM-to-sales workflow | `[grounded]` your summary's silence |
| G3 | Solo, no-bench operation (R9, important) | transferability | Team leadership shown, solo scope not | Same; fit only | Any period running multiple channels with little support | A role description from a lean period | `[grounded]` your summary; limit `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | Equity is the posting's offset for base pay, but it is unquantified, so it cannot be weighed against your $150k floor | `[grounded]` JD figure against your stated floor | Is $70–85k the full approved base range for this post, and what equity percentage and terms come with it? | unresolved |
| RR2 | Location conflict (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Conflicts directly with your remote-only constraint | `[grounded]` JD quote against your stated constraint | Is the five-day on-site requirement fixed for this role? | unresolved |
| RR3 | Bundled specializations, no support | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one" | Several full roles folded into one seat | `[inferred]` from the channel count against the stated team size | What budget, tools and first hires are committed to this seat? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be a standing expectation | `[inferred]` from the JD's framing of overtime as culture | How often did the last person in a growth role work evenings or weekends? | unresolved |
| RR5 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable for outcomes with no agreed measure | `[inferred]` from the JD's wording | What are the three outcomes this role is judged on at six and twelve months? | unresolved |
| RR6 | Seniority and pay tension | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The ask and the pay may not match; no market band was established, so this stays at medium | `[inferred]` from two statements within the JD | How was the $70–85k range set for this seniority? | unresolved |
| RR7 | Employer unverified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The posting's description of Novaline is not checked against its own site or careers page | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR8 | Reports to CEO with a board line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Senior access, if real | `[inferred]` from the reporting statement | Which board members would I work with, and how often? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the posted terms | see R1, R2 | `[grounded]` the two gate rows | pending your approval |
| A2 | If Novaline changes pay and location terms in writing, re-run this assessment on the new terms | New terms are new inputs | `[grounded]` R1, R2 | pending your approval |
| A3 | If you proceed against the no_go, ask RR1, RR2 and RR3 verbatim before investing in any interview | The register becomes the essential questions | `[grounded]` register | pending your approval |

No CV edits are proposed.

## Evidence status

Verified: the constraint statements behind R1 and R2, which are your own and specific. Unverified: the experience claims behind R3, R4, R5 and R9, which are self-reported prose with no artifact inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused (permission not granted). It would have moved role reality's organization and contradictions rows and RR7 |
| 2. Role-family sweep | unavailable | One search was refused. It would have moved the market calibration row and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Closing

I can also write this up as `tuesday-dossier.md` if you'd like a file to keep.

Upgrade menu:
- A link to the live posting on Novaline's own careers page, or the recruiter's email domain, would close RR7.
- The equity percentage and terms would let RR1's offset be weighed.
- An SEO, brand or partnership example would firm up R6–R8, though it could not change the status.
- A hiring manager's name would let me check their public footprint.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.