**Is it worth it? Yes, apply, on conditions. Status: `conditional_go`.** You meet every must-have (R3, R4, R5, R6, R7, R8) at `direct` fit, and the pay is stated and sits in the market band (RR3). Two gates, R1 and R2, can't be settled because you haven't given me your location or pay floor.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts analysts depend on)

R9 is the one row with a bridge to name, and R10 and R11 wait on your answers.

**Opportunity ledger.** Sound and transparent. Pay is stated and straddles the market median (RR3), and the employer is funded and live (RR4). The reporting line and the team's ownership boundary are unstated (RR1, RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 and R2 are met by your actual location and pay floor.
  2. BigQuery (R9) is framed as adjacent to your Snowflake work, never as BigQuery experience.
  3. The team and ownership questions in RR1 and RR2 get concrete answers in the loop.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026). | `[grounded]` company about page; the company's own account, with no independent source returned |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Location and pay | Remote (US) or Denver; $148,000–$166,000 plus equity | `[grounded]` JD |
| Posting status | Live, shown as "Accepting applications", and the text matches what you pasted | `[grounded]` careers page fetched |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500. "Senior" typically means 5–8 years, and the usual scope is one domain's pipelines with no direct reports. | `[generic]` Datawright 2026 pay report you supplied (n=2,310), not searched by me; the posted range is `[grounded]` JD |
| Seniority read | The 5+ year requirement against your 6 years sits at the low end of the report's typical range for the title | `[inferred]` from the JD and your stated background against the report |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Hiring manager, team size, whether the role has direct reports, equity terms, how BigQuery is used, interview process | `[grounded]` JD silent |
| Contradictions | None between your pasted text and the live page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what you will accept, so the term can't be checked. | `[grounded]` JD terms; your constraints not given | G1's question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor from you, so the range can't be checked against it. | `[grounded]` JD terms; your floor not given | G1's question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is specific but is self-report with nothing inspectable yet. | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Specific, no artifact yet. | `[grounded]` your stated background | none |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models, on Snowflake. Confirmed and specific, with no inspectable proof yet, so expect a probe. | `[grounded]` your stated background | offer: a sanitized dbt docs lineage screenshot would raise it to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The BigQuery-specific part of the role is carried by R9. | `[grounded]` your stated background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in your background, and it is the JD's own example. | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. That is setup; nothing yet says how widely it was used or maintained. | `[grounded]` your stated background | offer: Great Expectations data docs, sanitized, would raise it to high |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Credible adjacency: the same dbt-modelled warehouse work on a different engine. The limit is that you have never used BigQuery, so its engine specifics are untested for you. Engines usually differ in cost and performance tuning. | `[grounded]` your statement that you haven't used BigQuery; `[generic]` that engines differ in tuning | see G2 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Nothing in your background says which sources your pipelines ingested. | `[grounded]` background silent | G3's question |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Your test suite may bear on this, but nothing confirms agreed contracts with downstream users. | `[grounded]` background silent | G4's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms not settled (R1, R2, hard_gate) | hard_gate | The JD allows Remote (US) or Denver and offers $148,000–$166,000. Your location and floor are not stated. | A failed gate caps the decision however strong the fit is. | Not applicable: this is a fact about you, not a skill. | None needed | `[grounded]` JD terms and your silence |
| G2 | BigQuery (R9, important) | transferability | Snowflake and dbt experience, no BigQuery. | The posting names BigQuery in its first line. Your bridge is real and its limit is stated. | A small public dbt project on BigQuery's free tier; any BigQuery queries you have run alongside Snowflake | A repo or short write-up | `[inferred]` bridge from your dbt-on-Snowflake work |
| G3 | Ingestion from app and CRM (R10, important) | discovery | The JD names two source types. Your pipelines' sources are not stated. | Ingestion is the first listed duty, so this may decide how strong the application is. | Loading data from a product database or event stream; syncing a CRM or third-party API into the warehouse; customer or vendor integrations at the payroll company | A pipeline diagram or DAG screenshot, sanitized | `[grounded]` background silent; `[inferred]` that payroll integrations may count |
| G4 | Data contracts (R11, important) | discovery | The JD frames contracts as what analysts depend on. Nothing here shows agreed schemas or SLAs. | A named piece of the mandate, and a strong answer could lift R11 to `direct`. | Agreed schemas or freshness expectations with upstream engineers or downstream analysts; tests that blocked a bad load; alerts on schema change | A contract doc, a runbook or a test-suite excerpt | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and reporting line unnamed | unknown | — | (posting names no hiring manager) | The posting may simply be a standard careers-page listing, or the team may be new. | `[inferred]` from the posting's silence | Who would I report to, and who else is on the data team? | unresolved |
| RR2 | Team size and ownership boundary unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The scope covers ingestion, warehouse and contracts, which may be one domain or the whole stack. The pay report's usual senior scope is one domain with no direct reports. | `[inferred]` from the JD's scope against the report; `[generic]` for the report's norm | What does this role own end to end, and how many data engineers are on the team? | unresolved |
| RR3 | Pay stated and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range's midpoint is $157,000, above the report's $151,000 median. Its top sits above the report's $163,500 upper quartile. | `[grounded]` JD and your pay report; `[generic]` that the report's sample matches this employer's peers | Where in the range would an offer for my experience land, and what are the equity terms? | noted |
| RR4 | Funded, established stage | positive_signal | — | "Series C ($52M, February 2026)" | The company has had a recent raise and a multi-year operating history. The figures come from the company's own site. | `[grounded]` company page, self-reported | Is the data team growing, and what is it prioritising this year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with dbt on Snowflake (about 180 models), the Great Expectations suite you set up, and Airflow. State BigQuery plainly: "Snowflake in production; BigQuery is new to me." | R5, R7 and R8 are your `direct` rows, and it keeps R9 honest | `[grounded]` your background | pending your approval |
| W1 | A small BigQuery and dbt sandbox project before the loop | narrows R9's limit | `[inferred]` from R9's gap | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim in the loop | the register doubles as interview prep | `[grounded]` register | pending your approval |

Everything above is proposed. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Series C $52M", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It moved role reality's organization, posting-status and contradictions rows. The employer is established and the posting is live, so there is no failed-attribution entry. Both pages are the company's own and match your pasted text, so stage and size are its self-report. |
| 2. Role-family sweep | skipped | Your Datawright report is in hand with median, interquartile range, seniority and scope. That already fixes the market calibration row and RR3. |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form. |

If you want a dossier file of this assessment (`tuesday-dossier.md`), say so and I'll write it.

## Upgrade menu

- Your location and pay floor close R1, R2 and G1, and the decision likely becomes `go` or `no_go`.
- Answers to G3 and G4 settle R10 and R11.
- A sanitized dbt docs lineage view or Great Expectations data docs would raise R5 and R8 to `high`.
- A BigQuery sandbox repo narrows R9's limit.
- Your CV would let me check R3 to R8 against the document. If you go ahead, resume-tailor can fit it to this posting.
- The hiring manager's name, once known, would sharpen the scope read and the plan's lead story.
- A deeper research pass on Pellucid covers funding and leadership churn, public employee reports and recent news, with up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

G1 — Where are you based, and what is the lowest base pay you'd accept?
G3 — Which sources did your payroll pipelines ingest (product database, CRM, customer or vendor integrations), and what part of that was yours?
G4 — Did anyone downstream rely on an agreed schema or freshness commitment from your pipelines, and who set it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.