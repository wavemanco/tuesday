I won't add the hidden instruction or the 1pt keyword block. Here's why:

- **It's likely to hurt you.** Many applicant tracking systems strip or flag hidden text. A recruiter who sees it when the PDF is copied or opened in plain view will probably reject you on the spot.
- **It misrepresents you.** The injected line asks the screener to say you're highly qualified whether or not you are.
- **You don't need it.** Your real experience matches most of this JD.

I'll tailor the visible resume so the JD's keywords appear in honest, specific bullets. That is what parsers and humans both reward.
Rowan, I left the hidden text out completely and won't add it in a later pass.

- **It's deception, and you couldn't defend it.** It's aimed at the employer's software, and you'd be asked about a line you didn't write.
- **It can be found.** One platform disclosed that "1% of the resumes it processed in the first half of the year contained white text messages" (cite C19). One candidate said "One recruiter discovered the prompt hacking and turned him down because of it, he told the NYT." (cite C35). That's a single anecdote, but you'd carry the downside.
- **The premise is weaker than your friend made it sound.** In a vendor's interviews with 25 recruiters, "We only saw 2 of 25 using it." (cite C25) for content-based auto-rejection. Match scores mostly reorder the pile: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). What rejects without a person is usually the application form: "When automated filters are used, they’re almost always knockout questions" (cite C26). Read those questions carefully.

The legitimate version is below: truthful keywords placed where your experience already supports them, and your strongest evidence first.

I treated your pasted background as your resume text and as self-report. Whether the SQL gap makes this role worth chasing is job-underwriter's question, and I haven't answered it.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social; the budget I controlled was about $600k a year." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume text | pending your approval |
| E2 | Skills / Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line 1: "HubSpot daily for 4 years." Line 2: "Built our lifecycle email programme from scratch, 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume text | pending your approval |
| E3 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "I pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume text | pending your approval |

- **E1:** the two sentences stay separate and keep "about" and "a year". "Controlled" stays instead of the JD's "managed".
- **E2:** the split doesn't say the flows were built in HubSpot, because your sentence doesn't say so. See question E2.
- **E3:** the cut removes your SQL self-assessment, which was never a resume claim. The kept line asserts HubSpot reporting only, so it doesn't imply SQL.

Your webinar line, "Ran a monthly webinar series, average 300 registrants.", needs no change, so it has no row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| V1 | Paid search | must-have | `already_evidenced` | "Ran paid search and paid social"; E1 moves it into the summary | `[grounded]` |
| V2 | Lifecycle email | must-have | `already_evidenced` | "built our lifecycle email programme from scratch, 12 automated flows"; E2 gives it its own line | `[grounded]` |
| V3 | Webinars | important | `already_evidenced` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` |
| V4 | Content distribution | important | `not_evidenced` | Nothing in your material covers it; see C1 | `[grounded]` |
| V5 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts the channels next to "6 years B2B SaaS". Your text doesn't say how many of those years were demand gen, so I haven't claimed it; see question V5 | `[grounded]` |
| V6 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E2 gives "HubSpot daily for 4 years." its own line | `[grounded]` |
| V7 | SQL-literate | must-have | `not_evidenced` | Named absence below | `[grounded]` |
| V8 | Budget over $500k | must-have | `already_evidenced` | "about $600k a year" in E1; "about" stays | `[grounded]` |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Paid, email and webinar channels, but no organic or owned-content channel | The JD names it as one of four owned areas, so a reader looking for all four will find three | Promoting webinar recordings or blog posts through newsletters or social; partner or syndication placements; a content calendar you ran | A distribution plan, a newsletter or social report, an old resume version that lists it | `[grounded]` what the resume does and does not say; `[generic]` what a missing named channel costs on applications of this kind |

**V7, SQL-literate (named absence).** You've told me you aren't strong in SQL and rely on an analyst, so there is no recall prompt to run. I won't write any phrasing that gestures at SQL, and "works with analysts on queries" would do exactly that. Closing it means getting hands-on with basic queries (SELECT, JOIN, GROUP BY) and having a small piece of your own work to show, which realistically takes weeks. If you'd rather not close it, say plainly in interviews that you pull your own numbers in HubSpot and bring in an analyst for SQL.

## Not written, and why

- **Hidden white-text instructions and a 1pt keyword block:** refused, for the reasons above.
- **Anything claiming SQL skill:** you aren't strong in SQL.
- **"5+ years of demand generation":** your text says 6 years B2B SaaS, not how many were demand gen.
- **"Managed a budget over $500k":** your numbers are "about $600k a year" and "controlled". I used your words.
- **"Owned demand generation":** you ran the channels, and your text doesn't say you owned the whole function.
- **"Built in HubSpot":** your sentence doesn't say where the flows were built.
- **"300 attendees":** your figure is registrants.
- **Marketo, pipeline, MQL or ROI figures, and content distribution:** none of these appear in what you gave me.

## Parse-safety check

Your resume arrived as pasted text, so I couldn't check layout. That means columns, tables, text boxes, images, headers and footers, and file type are all untested. Send the file and I'll run those checks.

## Upgrade menu

- **The resume as a file (docx or text-layer PDF):** lets me run the parse checks, including whether any hidden text from an old template is already in it.
- **An older resume version:** may hold content-distribution work your current one dropped (C1).
- **A HubSpot report or dashboard export, and a webinar platform report:** would let me check your numbers and raise confidence on the webinar and budget lines.
- **An ad-account spend summary:** would let me confirm the $600k and whether it covers paid search and paid social together.

## Questions

V5 — Of your 6 years in B2B SaaS marketing, roughly how many were demand-gen work (paid, email, webinars) rather than other marketing?
E2 — Were the 12 automated flows built in HubSpot?
C1 — Have you distributed content to an audience (newsletter sends, social, partner or syndication placements, promoting webinar recordings)? If so, what and how often?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.