## Decision snapshot

**Yes, worth applying, on conditions. R1 and R2 (hard gates) are unconfirmed, and R6, R7 and R8 are real stretches. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3a, R4 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast), R7 (Working with finance on billing or revenue data) · unclear: R3b (At a B2B software company)
- `important` — direct: R9 · absent: R8 (Own the company's billing data)

R6 (`medium`) and R7 (`low`) are the must-have rows you flagged yourself; R8 is the `important` row you flagged too.

**Opportunity ledger.** The employer is attributable (RR1) and the pay is stated inside the market band (RR2). The posting's presence on Quillfield's own site is unconfirmed (RR3), and team, authority (RR4) and option terms (RR5) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay range both work for you — R1, R2; (2) the forecast stretch is stated plainly as adjacent, never as owning a forecast — R6; (3) the billing and finance-data gap is stated plainly and you ask how much of the role it is — R7, R8, RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` search result, linkedin.example/in/tamsin-achebe (snippet only) |
| Scope read | CRM, billing data, reporting and forecast are bundled in one title, with no team size or decision rights stated | `[inferred]` from the posting's list against its silence on team and authority |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400 (n=438, 2026 survey). The posted range sits inside that interquartile range; the band is what to expect, never this employer's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for the range |
| Unknowns | Team and reporting line; who signs off the forecast; option grant terms; whether the role is on Quillfield's own careers page | — |
| Contradictions | None between the posting, your description and the About page | `[grounded]` posting and About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You have stated no location or office-day limit, so there is nothing to grade and the fit is unsettled | `[grounded]` posting; no constraint given | Closing question Q1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor given. The range sits inside the market band (RR2), but whether it clears your floor is unknown | `[grounded]` posting; no constraint given | Closing question Q1 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. Prose self-report, nothing inspectable yet | `[grounded]` your account | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You said "B2B payments company". Whether that counts as software is not stated, so I take the lower band | `[grounded]` your account against posting wording | Say what the company's product is |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, by your statement. No credential seen, so expect a probe | `[grounded]` your account | Credential link would raise to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily is stated use. "Strong" and "modelling" are not evidenced: no model is described | `[grounded]` your account | Name one model or analysis you built |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and have never owned the company forecast; finance did. The posting says the forecast is run "with the CFO", but the requirement says owning | `[grounded]` your account and posting | G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | adjacent | low | transferability | You rebuilt renewal dashboards and have not worked on billing data. Working with finance on revenue figures is not stated | `[grounded]` your account; `[inferred]` that renewal dashboards involve revenue figures | G2 |
| R8 | Own the company's billing data | important | absent | none | capability | You have never worked on billing data | `[grounded]` your account | G3 |
| R9 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt pipeline and renewal dashboards. Who consumed them beyond sales is not stated | `[grounded]` your account | Sanitized screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | The monthly pipeline review is the adjacent work. The limit is that you have never owned a forecast number | A `must_have` row at `adjacent`; the bridge and its limit decide how you frame it | Supplying pipeline coverage or renewal projections that finance used; making a commit call; reviewing forecast against actuals | Pipeline review deck, a weighted-pipeline view, a forecast-versus-actual sheet (sanitized) | `[grounded]` your account; `[inferred]` that these artifacts would narrow the limit |
| G2 | Working with finance on revenue data (R7, must_have) | transferability | Renewal dashboards are adjacent, but no finance collaboration is stated | A `must_have` row at `low` confidence | Reconciling renewals or bookings with finance's figures; agreeing a definition of ARR or churn with finance | A metrics-definition doc or a reconciliation sheet (sanitized) | `[grounded]` your account; `[inferred]` that these examples would count |
| G3 | Owning billing data (R8, important) | capability | No billing-data experience, by your own account | The posting lists billing data under what you will own | None. A closure path is a small self-built exercise matching CRM closed-won deals to invoices in a sample dataset, or carrying it as an honest risk | A sample reconciliation | `[grounded]` your account; `[inferred]` the closure path |
| G4 | Software-company setting (R3b, must_have) | discovery | "B2B payments company" does not say whether the product is software | Cheap to settle and it is in the requirement's wording | Payments platform, API or SaaS product sold on subscription | Your CV's company line | `[grounded]` your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer attributable | positive_signal | — | "Quillfield… invoicing software" | The company exists as described | `[grounded]` About page: Bristol, 96 employees, Series A | Who else sits in the revenue operations team today? | noted |
| RR2 | Pay stated and inside market band | positive_signal | — | "£61,500–£67,000 plus share options" | The range is within the survey's interquartile range, near its median | `[grounded]` posting; `[generic]` survey band | Is the range fixed, or does it depend on level? | noted |
| RR3 | Posting not seen on Quillfield's own site | unknown | — | Tallyboard listing 2291 | The listing may be live, stale or syndicated; my search did not surface the careers page | `[inferred]` from the search returning only the About page | Is this role open on your own careers page, and since when? | unresolved |
| RR4 | Team and authority unstated | unknown | — | "own our CRM and billing data… run the quarterly revenue forecast with the CFO" | The role may be accountable for finance-facing numbers with no stated team or sign-off rights | `[inferred]` from the posting's scope list against its silence | Does this role have direct reports, and who signs off the forecast? | unresolved |
| RR5 | Option terms unstated | unknown | — | "plus share options" | The grant size and vesting may be material to total pay | `[inferred]` from the posting naming options without terms | What is the option grant, vesting schedule and strike price for this level? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Bristol hybrid and the pay range against your own limits before investing effort | see R1, R2 | `[grounded]` posting | pending your approval |
| E1 | Lead with: "Five years in sales operations at a B2B payments company, the last two running revenue operations for the UK team. Rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director. Salesforce admin certified; SQL weekly, Excel daily." | see R3a, R4, R9; each clause traces to your own sentences | `[grounded]` your account | pending your approval |
| E2 | State the limits in the same words you used to me: "Finance owned our company forecast, so I haven't owned one. I haven't worked on billing data." | see R6, R8; it keeps interview answers consistent with the application | `[grounded]` your account | pending your approval |
| W1 | Optionally, a one-page sanitized sample from your own non-confidential data, such as a pipeline-to-renewal view | narrows the limit in R6 and R7 | `[inferred]` strengthener from the bridge-case method | pending your approval |
| Q1 | Ask RR3, RR4 and RR5 verbatim in the first conversation | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background was given in prose, so it counts as self-report, not proof. No CV was provided.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers"; read "About Quillfield" (quillfield.co.uk/about). It established the employer for role reality and RR1. The careers page itself did not surface, hence RR3 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK scope forecasting billing data"; read "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It set the market calibration and RR2. It said nothing on scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; read "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. It filled role reality's hiring-manager row |

I can save this as `tuesday-dossier.md` to carry forward, if you want it.

## Upgrade menu

- Your Salesforce credential link → R4 to `high`.
- A sanitized dashboard screenshot → R9 to `high`.
- A pipeline review deck or a model workbook → R5 and R6 firm up, and G1 narrows.
- Your CV → presentation gaps checked against the map, and E1 tested against your actual wording.
- Your location and pay floor → R1 and R2 settle, and the status can move to `go` or `no_go`.
- A deeper research pass on Quillfield (leadership changes, hiring patterns, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

Q1 (R1, R2) — Is either of these a problem for you: being in the Bristol office two days a week, or a base of £61,500–£67,000?

G1 (R6) — Have you ever produced or signed off a revenue number that finance used in the forecast, such as a pipeline-coverage view, a renewal projection or a commit call? What exactly was yours?

G2 (R7) — Have you worked with finance on revenue figures like renewals, invoiced versus booked, or ARR, and what was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.