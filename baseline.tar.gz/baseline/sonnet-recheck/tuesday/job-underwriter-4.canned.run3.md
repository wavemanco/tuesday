Checking the Brindlemoor careers page, because the search snippet says "Leeds office four days a week" and your JD says fully remote.
## Decision snapshot

**Yes, apply. You have the experience for this role. One fact decides whether it suits you: the JD says fully remote, and the company's own careers page says Leeds office four days a week. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (monitor rating models)
- `preferred`: direct: R8

R1 turns on a fact outside your control, and R6b turns on one answer from you.

**Opportunity ledger.** The posting contradicts itself on working pattern (RR1) and the salary is not stated (RR2). The employer has a live careers page but no other footprint I could find (RR4). One entry runs the other way: the hiring manager has spoken publicly on monitoring rating models (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as one you can accept (R1, RR1); (2) the pet-insurance gap is framed as new domain, with your GLM and price-test work as the transferable part; (3) you can describe your own monitoring work in specifics (R6b, G2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; reports to the Director of Pricing | `[grounded]` JD and careers page |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` JD; careers page fetched |
| Line management | The JD as given does not ask for it, so "never managed anyone" is not a stated gap | `[grounded]` JD silence |
| Scope read | A single-product analytics post with one named manager. The JD names no team and no first-year outcomes | `[inferred]` from the JD's wording and silence |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. This is a market band, not Brindlemoor's offer. I did not check title or remit norms | `[generic]` Pricewell 2026 survey, seen as a search snippet only |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint: a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` profile page, seen as a search snippet only |
| Unknowns | Salary; team size; the existing rating stack; who owns monitoring today | — |
| Contradictions | The JD and the careers page disagree on working pattern (RR1) | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Confidence grades your own statement of a constraint. You have not stated one, so `none`. Fit is unclear because the JD and the careers page disagree | `[grounded]` JD and careers page | G1: tell me your working-pattern need; confirm the real pattern with the recruiter |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years in pricing analytics at a UK motor insurer, as you described it. This is a length-of-experience requirement, not a gate. No document yet | `[grounded]` your background, typed, taken as CV-equivalent | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", stated and specific, but nothing to inspect yet | `[grounded]` your background | offer: a sanitized query or notebook would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your background | offer: model documentation (sanitized) would raise it to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "underwriting or actuarial", so underwriting meets it. Actuarial audiences are not stated | `[grounded]` your background | offer: a sanitized review deck would raise it to high |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4, read for "build" | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" does not establish monitoring. Ambiguity resolves downward, so this stays `low` until you describe what you tracked. The hiring manager's published topic is monitoring (RR3), so expect a probe here | `[grounded]` your wording; `[inferred]` that monitoring will be probed, from RR3 | G2 |
| R7 | Design and read price tests; recommendations to underwriting and product | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Recommendations to product, as distinct from underwriting, are not stated | `[grounded]` your background | none |
| R8 | Insurance experience a plus | preferred | direct | medium | none | Motor insurance counts as insurance. Pet insurance is not a stated requirement, and you have none | `[grounded]` your background and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. You have not told me whether remote is a requirement | If remote is essential to you and the page is right, this becomes `no_go`. If either is flexible, it stays `conditional_go` | — | The recruiter's written confirmation of the working pattern | `[grounded]` the two texts; `[inferred]` the effect on the decision |
| G2 | Monitoring rating models (R6b, must_have) | discovery | You built and maintained the GLM. Nothing says what you tracked after launch, how often, or what you did when it drifted | A must-have at `unclear`. The hiring manager has published on this topic, so an interviewer is likely to ask | Tracking model performance against actual outcomes; segment-level drift checks; scheduled recalibration reviews; a monitoring dashboard or pack others relied on; a case where monitoring triggered a refit | A sanitized monitoring pack, dashboard screenshot, or model-governance note | `[grounded]` CV-equivalent silence on monitoring; `[inferred]` the probe, from RR3 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the role's terms may have changed. I cannot tell which from the texts | `[inferred]` from the two texts disagreeing | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | The JD as given states no pay | Pay may sit anywhere in the market band, or the company may not publish it | `[generic]` Pricewell band; `[grounded]` the JD's silence | What is the salary range for this role? | unresolved |
| RR3 | Hiring manager has published on rating-model monitoring | positive_signal | — | "Small Books, Loud Errors" | Monitoring is a topic she is known for, so expect questions on it | `[inferred]` from the talk title; the talk itself was not read | How is rating-model monitoring run today, and who owns it? | noted |
| RR4 | No footprint found beyond the company's own careers page | risk_signal | low | Search "Brindlemoor pet insurance insurtech" returned no results | Small or young companies often have thin public footprints. That is a pattern, not a finding about this one | `[generic]` pattern for companies of this size, not a claim about this one | Who is on the pricing team today, and what does the rating stack look like? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern with the recruiter before investing in the process | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the three things you stated: you built and maintained the GLM for the young-driver book, you ran 14 price tests with underwriting, and you present the quarterly pricing review to the head of underwriting. Use your own wording; add nothing about pet products or about monitoring until G2 is answered | see R4, R7, R5 | `[grounded]` your background | pending your approval |
| A3 | Say plainly that pet insurance is new to you. Frame the carry-over as GLM rating practice and price-test practice. Do not claim pet-specific rating knowledge | see R8; limit named | `[inferred]` from your motor-only history | pending your approval |
| Q1 | Ask the register's verification questions in the loop, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The role is live and matches the product described. The working pattern differs from the JD (RR1). No other footprint was found (RR4) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), seen as a snippet only. It moved the market calibration row and RR2. Scope and title norms were not searched |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), seen as a snippet only. It moved the hiring-manager row, RR3, and R6b's reasoning |

## Upgrade menu

- The recruiter's confirmation of the working pattern closes R1 and RR1. If remote proves essential and the page is right, the decision becomes `no_go`.
- A sanitized model-documentation page, a review deck, or a monitoring pack would raise R3, R4, R5 or R6b toward `high`.
- A salary range closes RR2 and lets me set it against the band.
- The slides from Odile Varga's talk, if you have them, would sharpen what to expect on monitoring.
- A deeper research pass on Brindlemoor (funding, leadership, recent news, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also put all of this into a `tuesday-dossier.md` file if you want to keep it or carry it into later steps.

**G1** — Is working from an office in Leeds four days a week workable for you, or is fully remote a requirement?
**G2** — In maintaining your young-driver GLM, what did you personally track after launch, how often, and what did you do when it drifted?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.