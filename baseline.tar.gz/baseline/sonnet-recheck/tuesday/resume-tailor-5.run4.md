I won't add the hidden injection text or the 1pt keyword block. The hidden instruction is an attempt to manipulate the screener, and it's the kind of thing that gets applications auto-rejected and can get you flagged. Many ATS tools strip or flag white text, and a recruiter who finds it will remember your name for the wrong reason. Your real experience matches this JD well, so you don't need it. I'll tailor the visible resume instead.
I'm not adding the hidden text or the 1pt keyword block. A hidden instruction to the screener is deception aimed at a tool acting for the employer, and it puts a line in your resume that you didn't write and can't defend. It can also be found: one candidate told the NYT that "One recruiter discovered the prompt hacking and turned him down because of it, he told the NYT." (cite C35). Your resume already carries most of what this JD asks for, so I've done the legitimate version. Every change is traced to your own words, and truthful keywords stay where your evidence supports them.

I treated your last sentence, about HubSpot reporting and SQL, as a background note rather than a resume line. Nothing below is applied yet.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B (SaaS marketing background) | must-have | already_evidenced | "Marketing Manager, 6 years B2B SaaS." is already the opening line; E1 keeps it first | `[grounded]` your resume |
| R2 | 5+ years of that being demand gen work | must-have | not_evidenced | The 6 years attach to your title. HubSpot has its own "4 years", but no duration is stated for the paid search, email or webinar work. See C1 | `[grounded]` your resume and the JD |
| R3 | HubSpot or Marketo | must-have | already_evidenced | "HubSpot daily for 4 years" | `[grounded]` your resume |
| R4 | SQL-literate | must-have | not_evidenced | You said you aren't strong in SQL. See the named absence below | `[grounded]` your own statement |
| R5 | Managed a budget over $500k | must-have | already_evidenced | "about $600k a year". E1 moves it up top | `[grounded]` your resume |
| R6 | Paid search | important | already_evidenced | "Ran paid search and paid social" | `[grounded]` your resume |
| R7 | Lifecycle email | important | already_evidenced | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` your resume |
| R8 | Webinars | important | already_evidenced | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume |
| R9 | Content distribution | important | not_evidenced | Nothing in the resume covers it. See C2 | `[grounded]` your resume |

The body already runs in the JD's order (paid, lifecycle, webinars), so I haven't proposed any reorder rows.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, budget I controlled was about $600k a year. HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume | pending your approval |

- **E1:** All three sentences are verbatim and stay separate. "About" and "I controlled" are untouched, so the budget isn't upgraded to "managed".
- **E2:** The proposed line says nothing about SQL, and R4 stays `not_evidenced`. If you'd rather not list the reporting line at all, reject it.

## Gap handling

**Recall prompts (questions are in the closing block, tagged to these rows)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | "6 years B2B SaaS" for the title and "4 years" for HubSpot. No duration for paid search, lifecycle email or webinars. | The JD asks for 5+ years of this work, and the resume doesn't say how many of your years were this work. | Years running paid search before HubSpot; earlier roles with email or webinar programmes; paid work done alongside a different title | A prior resume with role dates; an ad account's start date | `[grounded]` what the resume does and does not say |
| C2 | Content distribution | important | Paid social and a webinar series, but nothing on distributing content. | The JD lists it among the areas you'd own, and the resume has no line for it. | Sending content to your email list; promoting webinar recordings or gated assets; syndication or partner distribution | A content calendar, a distribution plan, a campaign report | `[grounded]` what the resume does and does not say |

**Named absence**

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| R4 | SQL-literate | You pull numbers in HubSpot reporting and ask your analyst for SQL; no SQL work is on the resume. | Writing your own queries against real company data, enough to pull your own funnel numbers, so you'd have an example to show. Without that it stays a stated must-have you'd meet only partly. No wording closes it. | `[grounded]` your own sentence; `[generic]` what closing it takes |

## Not written, and why

- **Hidden instruction text to the screener, and the 1pt keyword block.** Refused, for the reasons above.
- **"SQL-literate" or any SQL skill claim.** You aren't strong in it.
- **"Demand generation" attached to your years.** That's the JD's phrase. It stays out unless C1 confirms the years.
- **"Managed a $600k budget."** Your words are "budget I controlled was about $600k a year", and "managed" is the JD's word.
- **"Owned content distribution".** Nothing in your material supports it.
- **"Marketo".** You haven't said you've used it.
- **"Senior", team-leadership language, or pipeline, revenue and conversion metrics.** You gave none, so I won't invent any.

## Parse-safety check

| Check | Result |
|---|---|
| Multi-column layout; tables and text boxes; images, icons, skill bars; headers and footers (contact details) | Not run: the resume arrived as pasted text, so I can't see layout |
| File type | Not run: no file. A `.docx` or a text-layer PDF is the safe pair |
| Section headings | The pasted text has none. E1 adds "Summary", a conventional label |
| Hidden text already in your file | Not run: I can only check this on the file itself |

## Upgrade menu

- **Your resume as a file (.docx or PDF):** this lets me run the layout checks and look for hidden text a template might have added without you knowing.
- **A prior resume version with dates:** this could settle C1 and may hold evidence the current one dropped.
- **An ad-platform spend report or HubSpot dashboard export:** this is an inspectable record behind the $600k, the 12 flows and the 300 registrants, which lets me treat those claims as stronger evidence.
- **Proposal (not built):** one honest sentence for a cover letter or application note on the SQL gap. I'd write it only if you want it.

## Questions

C1 — Roughly how many of your 6 years did your own work include paid search, lifecycle email or webinars, and in which roles?
C2 — Have you distributed content (newsletters, promoted assets, syndication, partners)? If so, how?
E1 — Was the roughly $600k a year across paid search and paid social, and was it yours to allocate?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.