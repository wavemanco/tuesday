Still reading the tailoring rules (parse-safety and scope guidance) before I build your ledger.
Nadia, here's the tailoring ledger for the Quartzline posting. I used the dossier excerpt, and nothing is applied yet.

Your dossier excerpt gave me the R1 and R2 judgments, the pending edit E1 and the two rejected inferences. I used those and did not re-derive them. The `conditional_go` decision isn't mine to act on. I had only your CV as text in your message, not the file, so every quote below comes from those sentences. I can't see their order or layout on your actual CV.

## Edit ledger

Every row below is pending your approval. Quotes are copied exactly from your text.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own standalone line (the dossier's pending edit, inherited and re-audited) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV text and dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | Wording unchanged; moved to the first line under the role | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV text | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | Wording unchanged; moved to second position, straight after E2 | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV text | pending your approval |
| E4 | Experience or Skills | "Comfortable in Postman, SQL, OpenAPI specs." | Wording unchanged; given its own line directly under the role, if it currently sits only in a tools list. If it is already prominent, drop this row. | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV text | pending your approval |

I did not retitle "solutions engineer / implementation lead". Any PM-flavoured title would be an upgrade, not an equivalent. I also left the posting's words ("partners", "discovery", "shipped") out of every line. Your sentences say "client", "roadmap-input sessions" and "Led".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | The dossier marks this adjacent (transferability, medium): integration leadership is adjacent, while roadmap ownership and prioritisation authority aren't evidenced. E2, E3 and E1 show the adjacent work and nothing in them claims PM. | `[grounded]` dossier evidence_map R1 and your CV text |
| R2 | Shipped API or platform products | important | `not_evidenced` | The dossier marks this adjacent (medium). E2 shows you led integrations of your vendor's REST APIs, which is not the same as shipping those APIs. | `[grounded]` dossier evidence_map R2 and your CV text |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4 (Postman, SQL, OpenAPI specs), backed by E2 (REST APIs end to end). | `[grounded]` your CV text |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E3 covers clients and product. Working with engineering squads isn't evidenced. | `[grounded]` your CV text |
| R5 | Discovery with integration partners | important | `surfaced_by_edit` | E3 is the closest match. It is client feedback sessions, not partner discovery. | `[grounded]` your CV text |
| R6 | Specs and delivery with two engineering squads | important | `not_evidenced` | "OpenAPI specs" is listed under what you're comfortable in. Nothing says you wrote specs or drove delivery. | `[grounded]` your CV text |
| R7 | Define adoption metrics | important | `not_evidenced` | Nothing in your text mentions metrics. | `[grounded]` your CV text |

## Gap handling

Recall prompts (the questions are in the closing block, tagged to these rows):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM, covering roadmap ownership and prioritisation | must-have | You collected client feedback "for product" and hold no PM title. Nothing shows you deciding what got built or in what order. | The posting's first duty is owning the roadmap. The dossier already names this as the unevidenced part. | Ranking client requests before they went to product; deciding which asks made it into a release; writing a requirements doc that engineering built from | A prioritised list, a requirements doc, a release note naming the change | `[grounded]` what your CV does and doesn't say; `[generic]` roadmap ownership is typically the core of a platform PM role |
| C2 | Shipped API or platform products | important | You led integrations of the vendor's APIs. Nothing shows you releasing an API or feature. | The posting asks for shipped API products, and the dossier rates this adjacent. | Specifying or launching an endpoint, a partner-facing integration template or an SDK; a client-driven API change you took through release | A spec, a changelog entry, a launch note | `[grounded]` what your CV does and doesn't say; `[generic]` screeners read "shipped" literally |
| C3 | Define adoption metrics | important | Nothing in your text mentions metrics. | Adoption metrics are a named duty. | Tracking how many client integrations went live; time to first successful API call; usage of an endpoint after launch | A dashboard, a report or a tracking sheet | `[grounded]` what your CV does and doesn't say; `[generic]` defining metrics is a stated duty of this kind of role |

Named absences:
- **R6, delivery with two squads.** You have no evidence of driving delivery with engineering squads. Closing it takes either a project where you specified work and engineers built it, or accepting that the posting will read this as unproven. Given the dossier's conditional_go, the second is a realistic outcome. I'd rather say that than write around it.

## Prohibited claims

Not written, and why:

- **"3+ years of product management" or any PM title.** You've never held one and it's the must-have. The gap is named above.
- **"Owned the roadmap".** You ran input sessions. The dossier says ownership and prioritisation authority aren't evidenced.
- **"Shipped API products".** You led integrations of the APIs, which is a different job. The dossier rates it adjacent.
- **"Built an internal request-triage tool".** Carried over unaltered from the dossier's rejected inferences: memory lead, you could not confirm ownership.
- **"Has been the customer of a partner API platform".** Carried over unaltered from the dossier's rejected inferences: you worked vendor-side.
- **"Wrote product specs" or "drove delivery with engineering".** "OpenAPI specs" appears only under what you're comfortable in. Turning that into writing specs would change the kind of work.
- **"Partner discovery" or "partner-facing"**. You wrote "client". Moving to "partner" would change which side of the table you describe.

## Parse-safety check

I can't run this properly because your CV arrived as pasted text. I could not check multi-column layout, tables or text boxes, images or skill bars, contact details in headers or footers, section headings or file type. Send the file (a `.docx` or text-layer PDF is the safe pair) and I'll run all six.

## Upgrade menu

- **Your actual CV file.** This would let me run the parse checks, quote your exact wording and see the real order, so that E2 and E3 can be confirmed as moves rather than assumed.
- **Answers to C1–C3.** Each confirmed answer turns a `not_evidenced` row into a real one. Answering C1 matters most, since R1 is the must-have.
- **The integration playbook or a roadmap-session output.** An inspectable artifact would upgrade E1 and E3 from self-report.

C1 — Did you ever decide, or recommend to product, which client requests got built and in what order? If so, what happened?
C2 — Did you take any API change or feature through to release, even partly? If so, what was your part?
C3 — Did you track anything about how clients adopted the APIs, such as integrations live or usage? If so, what was it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.