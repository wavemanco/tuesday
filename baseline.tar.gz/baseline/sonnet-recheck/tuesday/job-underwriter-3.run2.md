I'm answering from the posting and what you told me. Both web searches were denied, so nothing here is verified against Novaline's own site.

## Decision snapshot

**Is it worth pursuing? No. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in our Austin office 5 days a week), R2 ($70–85k base)
- `must_have`: direct: R3, R4, R5, R6 · unclear: R7 (SEO/content)
- `important`: unclear: R8 (brand, PR, partnerships), R9 (sales ops)

The status rests on R1 and R2.

**Opportunity ledger.** Several of the posting's own terms read as risk signals: six or more functions bundled into a team of one (RR1), pay stated below the mandate's reach (RR2), expected evenings and weekends (RR3), and success metrics left undefined (RR4). The posting does state its pay range up front (RR6), and I could not check the employer (RR5).

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days a week), R2 ($70–85k base).
- **Severe red flags:** none found.
- **What would change this:** R1 would need to be a remote role in Portland, and R2 would need a base of at least $150k. The top of the posted range is $85k, which is $65k below your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup at Series A, "profitable since day one" | `[grounded]` JD; the profitability claim is the posting's own and unchecked |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start. Reports to the CEO, dotted line to the board | `[grounded]` JD |
| Location and schedule | On-site Austin five days a week, "no exceptions". Evenings and weekends "when it matters" | `[grounded]` JD |
| Success metrics | None stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions, usually run by separate specialists, assigned to one person with no bench | `[inferred]` from the function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so the only figure is the posting's $70–85k base | `[grounded]` JD for the figure; sweep unavailable |
| Unknowns | Equity size and terms, budget, who owns sales, what "evolving metrics" means in practice | `[grounded]` JD silence |
| Contradictions | None checkable without the careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin five days a week (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the constraint, which is specific and your own. Fit fails because the JD says "no exceptions" and you will not relocate | `[grounded]` JD quote and your stated constraint | Only the employer changing terms, or you changing the constraint, resolves it |
| R2 | $70–85k base (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor. Fit fails because the top of the posted range is below it | `[grounded]` JD figure and your stated floor | Same as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years, Growth Lead then Head of Growth. This is self-reported background with no inspectable artifact yet | `[grounded]` your stated background | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid at both companies. Self-reported, scope of spend not given | `[grounded]` your stated background | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. Self-reported | `[grounded]` your stated background | none |
| R6 | Own revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled, and you built teams of 3–7. The ARR figure is unverified, and the "end to end" breadth beyond paid and lifecycle is not shown | `[grounded]` your stated background | none |
| R7 | SEO/content | must_have | unclear | none | discovery | You did not mention SEO or content, so I can't tell whether you did that work | `[grounded]` your summary is silent | See G1 |
| R8 | Brand, PR, partnerships | important | unclear | none | discovery | Your summary is silent on all three | `[grounded]` your summary is silent | See G2 |
| R9 | Sales ops | important | unclear | none | discovery | Your summary is silent. Subscription growth roles can sit near sales-ops work, but that is a pattern and not evidence about you | `[grounded]` your summary is silent; `[generic]` for the pattern | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | Nothing in your summary on organic or content work | A `must_have` row, but it cannot move a status capped by R1 and R2 | Briefing a content team, owning organic landing pages, a content-led acquisition test | A channel report or an organic-traffic dashboard | `[grounded]` silence; `[inferred]` that it cannot change the status |
| G2 | Brand, PR, partnerships (R8, important) | discovery | Nothing in your summary | An `important` row. It is relevant only if the gates ever open | Co-marketing deals, affiliate or referral partners, press placements | A partner agreement or a press hit | `[grounded]` silence |
| G3 | Sales ops (R9, important) | discovery | Nothing in your summary | Same as G2 | Lead routing, CRM hygiene shared with sales, pipeline reporting | A pipeline dashboard | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled specializations with no bench | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops"; "a team of one" | Several full roles may be folded into one title, with no budget or help committed | `[inferred]` from the function list against "team of one" | Which of these functions have budget and contractors behind them, and when is the first hire? | unresolved |
| RR2 | Pay below the mandate's reach (see R2) | risk_signal | medium | "$70–85k base plus meaningful equity upside" | The base may not match a Head-level, 8+ year, all-revenue mandate. A market sweep is needed to confirm, which is why this is not rated higher | `[inferred]` from the JD's scope against its stated base; sweep unavailable | What is the equity grant, vesting and strike, and is the base negotiable? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime may be a standing expectation and not an exception | `[inferred]` from the phrasing "just who we are" | How many evenings or weekends did the last person in this function work in a typical month? | unresolved |
| RR4 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for all revenue with no agreed definition of success | `[inferred]` from the JD | What does success look like at 6 and 12 months, in numbers? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | low | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Search was unavailable, so I did not check whether the company exists as described or the posting is live. Severity is held low because I have no negative finding | `[generic]` pattern for a check that did not run, not a claim about Novaline | Can you point me to this role on Novaline's own careers page, and who would I interview with? | unresolved |
| RR6 | Pay range stated openly | positive_signal | — | "$70–85k base" | The posting does not hide compensation, so the mismatch can be seen before investing effort | `[grounded]` JD | Is the equity grant documented in the offer? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not invest application effort on current terms | see R1, R2 | `[grounded]` the two failed gates | recommended |
| A2 | Optional: one short question to the recruiter or CEO asking whether remote work and a base of $150k or more are possible. If either answer is no, stop | R1 and R2 are the only things that decide this | `[grounded]` R1, R2 | pending your approval |
| Q1 | If you proceed anyway, put RR1 to RR4 to them verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was denied. It would have moved the employer-exists check (RR5) and the contradictions row |
| 2. Role-family sweep | unavailable | The search was denied. It would have moved the market calibration row and could have raised RR2's severity |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll offer to write this up as `tuesday-dossier.md` if you want a saved record.

**Upgrade menu**

- Permission to run the searches → RR5 closes or escalates, and R2 gets a market band to sit beside the $70–85k figure.
- The recruiter's answer on remote work and base → R1 and R2 either stay failed or the status changes.
- Short answers on SEO/content, brand and PR, partnerships, and sales ops → G1 to G3 close, and R7 to R9 get real fit calls.
- A deeper research pass on Novaline (funding, leadership churn, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

Q1 — Is there any version of this where you'd still talk to Novaline, such as the CEO volunteering remote work and a base of $150k or more? If yes, I'd ask the gap questions for R7 to R9. If no, we can stop here.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.