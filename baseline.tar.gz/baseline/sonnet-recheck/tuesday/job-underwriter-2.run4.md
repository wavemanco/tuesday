**Decision snapshot**

No, you are not wasting your time. R3 and R4a are `direct`, and R1b, R2, R6, R7 and R9 are `adjacent`. But R1a, the 3+ years of product management experience, is `absent`, so this is a stretch application, not a strong match. Status: `conditional_go`.

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM-type work without the title), R2 (Shipped API or platform products) · absent: R1a (3+ years product management experience)
- `important` — direct: R4a · adjacent: R6 (Discovery with integration partners), R7 (Specs and delivery with two squads), R9 (Launches with sales and support) · unclear: R4b (Stakeholders in sales), R5 (Agile delivery), R8 (Adoption metrics)

The decision turns on R1a and R2.

**Opportunity ledger.** The scope is concrete (RR4), but the years requirement may be screened literally (RR2), the employer is unverified (RR1), and pay, location and reporting line are unstated (RR3, RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) someone with authority confirms that product work done in an implementation role is considered (RR2, R1a); (3) your answers on shipped work and metrics hold up (R2, R8); (4) your resume never implies a PM title you haven't held (R1a).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not cross-checked externally |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive two squads; define and track adoption metrics; coordinate launches | `[grounded]` JD |
| Scope read | One product area with two squads, a single-platform PM post rather than a portfolio role | `[inferred]` from the two-squad and single-platform wording |
| Success measures and first-year outcomes | Not stated beyond "adoption metrics" | `[grounded]` JD silence |
| Pay, location, reporting line | Not stated | `[grounded]` JD silence |
| Market calibration | Not available: the role-family search was refused, so there is no band to set against this title | `[grounded]` search refused |
| Contradictions | None inside the JD; no cross-check against the careers page was possible | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | none | capability | You confirmed you've never held a PM title, and the JD marks the years a must-have with no "or equivalent". Wording can't fix titled years. Postings like this are often screened on the literal line | `[grounded]` JD and your statement; `[generic]` on screening | Closure path in G2; RR2's question to the employer |
| R1b | PM-type work without the title | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions and coordinating with product managers on custom builds are product-adjacent. Limit: gathering input and coordinating is not owning prioritization or the roadmap | `[grounded]` CV | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | discovery | Leading 30+ end-to-end integrations of your vendor's REST APIs is implementing an API product, not shipping one. The playbook is an internal document. I read this as the role's core because the job is to own the API platform | `[grounded]` CV; `[inferred]` tiering from the mandate | G3 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and 30+ integrations meet this directly. It is self-reported and nothing has been inspected, hence `medium` | `[grounded]` CV | A sanitized playbook excerpt or architecture diagram would raise it to `high` |
| R4a | Stakeholders: engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran scoping workshops | `[grounded]` CV | none |
| R4b | Stakeholders: sales | important | unclear | low | discovery | The CV never mentions sales | `[grounded]` CV silence | G6 |
| R5 | Agile delivery | important | unclear | low | discovery | UAT and go-live show delivery discipline, but nothing places you in sprints or a backlog | `[grounded]` CV silence | G5 |
| R6 | Discovery with integration partners | important | adjacent | medium | transferability | Your clients are integrators, so you know their side. Limit: no evidence you synthesized feedback into priorities | `[grounded]` CV; `[inferred]` that clients resemble integration partners | Bridge in plan A1 |
| R7 | Specs and drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and integration architecture are spec-like. Limit: they were written for client projects, not a product backlog you owned | `[grounded]` CV | Bridge in plan A1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. A prior-context note mentions a request-triage tool that support agents adopted, which is a lead only | `[grounded]` CV silence; memory lead unconfirmed | G4 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind. Limit: they are not product launches with enablement for sales and support | `[grounded]` CV | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM-type work (R1b, must_have) | transferability | Roadmap-input sessions, with no sign of who prioritized what | It is the bridge for the years requirement | Feedback that changed a roadmap item; a client request you escalated that shipped; a prioritization call you made | A session summary, a feedback log, a product ticket | `[grounded]` CV; `[inferred]` bridge |
| G2 | Titled PM years (R1a, must_have) | capability | No PM title, no direct evidence | This is the row most likely to end a screen | None to recover: the closure paths are a scoped-down target or an internal move into product, such as a technical PM, product owner, or product-ops role at your current vendor | none | `[grounded]` your statement |
| G3 | Shipped product (R2, must_have) | discovery | Integrations delivered; nothing shipped as product | It decides whether the bridge is "implemented the API" or "shaped the API" | A connector, template or reference integration reused across clients; an API change you specified that shipped; docs customers used | Release notes, a changelog entry, a reuse count | `[grounded]` CV silence |
| G4 | Adoption metrics (R8, important) | discovery | A possible triage tool, unconfirmed | Metrics are a named duty, and a tool others adopted is the closest evidence | The triage tool: who used it, how adoption was tracked, what you owned | A usage screenshot, an adoption number, a note from support | `[grounded]` CV silence; memory lead unconfirmed |
| G5 | Agile delivery (R5, important) | discovery | UAT and go-live, no sprints | A cheap gap to close if the experience exists | Writing stories or tickets for engineers; joining planning or grooming; accepting work | A ticket board export or a sprint doc | `[grounded]` CV silence |
| G6 | Sales and launches (R4b, R9, important) | discovery | No sales contact shown; go-lives only | The JD names sales and support by function | A deal you supported; enablement material for a go-live | A handoff doc or a launch checklist | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "B2B logistics-tech, ~150 people, Series B" | The posting could be stale, or the company small; searches were refused, so no attribution was attempted | `[generic]` pattern, not a claim about this company | Can you point me to this role on your careers page, and who I'd interview with? | unresolved |
| RR2 | Titled-years must-have may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | A non-titled background may be filtered before a human reads it | `[generic]` hiring pattern | Would you consider product work done in a solutions or implementation role toward the 3+ years? | unresolved |
| RR3 | Pay and location withheld | unknown | — | the JD lists neither | The posting may simply omit them | `[grounded]` JD silence | What is the salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "run discovery… write specs… define and track adoption metrics… coordinate launches" | The duties are defined and testable | `[grounded]` JD | Which of these do you most want done in the first 90 days? | noted |
| RR5 | Reporting line and decision rights unstated | unknown | — | "Own the roadmap" | The role may own the roadmap without final say on priorities | `[inferred]` from the JD's silence on decision rights | Who does this role report to, and who decides roadmap priority when sales and engineering disagree? | unresolved |

## Application plan

`resume_edits_pending_approval`

| # | Current | Proposed | Source | Status |
|---|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | Same wording, moved up to sit directly under the integrations bullet | your CV line | pending your approval |
| E2 | "Wrote the internal integration playbook the whole team uses" | Same wording, moved up to third position | your CV line | pending your approval |

Neither edit adds a claim or changes a verb, scope or number. A full line-by-line tailoring pass is a separate job for resume-tailor.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the integrations and the roadmap-input sessions, in your own words, and name the title as it is. Offer the limits yourself: you implemented and fed the roadmap, you didn't own it | See R1b, R6, R7 and G1. It keeps the bridge honest | `[grounded]` R-rows | pending your approval |
| A2 | Look for a referral or a recruiter conversation before applying through the form | Titled-years lines are often screened before anyone reads further (RR2) | `[generic]` hiring pattern | pending your approval |
| A3 | Ask RR2, RR3 and RR5 verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Confirm the posting and employer before investing in tailoring (RR1) | It is the cheapest check there is | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a prior-context mention of a request-triage tool that support agents adopted. It is unconfirmed and used only to prompt question G4.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The company search was refused. It would have confirmed the employer and the live posting, feeding RR1 and role reality |
| 2. Role-family sweep | unavailable | The salary and scope search was refused. It would have given the market calibration line and a pay check for RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can offer a one-file dossier (`tuesday-dossier.md`) of this assessment to carry into later steps, if you want it.

**Upgrade menu**

- Search access, or a link to the live posting or the Quartzline careers page → RR1 can close and the market calibration can run.
- A sanitized integration playbook excerpt or architecture diagram → R3 to `high`.
- Answers to G3, G4 and G5 → R2, R8 and R5 can move, and the decision could simplify to `go` or `no_go`.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper research pass on Quartzline (funding, leadership, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G3 — Has anything you specified or built ever shipped as part of the product itself for more than one client, such as a connector, a template, an API change or documentation? What was your part in it?

G4 — The request-triage tool I may have noted before: is that real, what did you own, who used it, and how did you know they adopted it?

G5 — Have you worked inside engineers' sprints, for example writing tickets or stories, joining planning, or accepting finished work? What was your role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.