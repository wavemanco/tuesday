Reading is done; now running the Stripe research (values, interview process, strategy, a representative JD) before I build the pack.
I couldn't run the research (all four searches were refused) or save the pack as a file (the write wasn't granted), so the full pack is below. I built it for a final round with an unknown interviewer and flat persona weights, using no JD, no CV and no research. Everything is a rehearsal pattern, not a fact about Stripe or about you.

# Interview prep pack: Product Operations Manager, Stripe

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: where it asks you to pick an example, it has to be one you actually lived, told in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims about past work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem |

## Fit snapshot

This is the worksheet variant. With no job description, the requirements are role-family patterns in plain prose, not quotes, and they raise no answer slots. With no background supplied, every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or programs across several teams (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a launch or program you coordinated across teams, with your actual part stated. Pick one with a named stake, a point where teams disagreed, and a result you can state. If no such example comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would approach it |
| F2 | Defining, tracking and reporting product or operational metrics (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you helped define or track, with how it was counted. Pick one number you can explain end to end, including the assumption you would defend least. If you cannot explain how a figure was counted, say so plainly, then give the nearest thing your experience does carry, or how you would find out |
| F3 | Structuring ambiguous problems and making recommendations (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a problem that arrived unstructured, how you framed it, and what was decided. Pick one where the recommendation was yours. If no such example comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F4 | Influencing stakeholders without direct authority (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement with someone you could not overrule, and how it ended. Pick one where the relationship was intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it |
| F5 | Designing or improving processes and operating rhythms (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, and how you knew it worked. Separate what you designed from what you inherited. If you only ran a process someone else designed, say so plainly, then give the nearest thing your experience does carry, or how you would improve one |
| F6 | Location and right to work for the role (a term, role-family pattern, no JD supplied) | none given | none | [generic] | hard_gate | Your material does not establish it. A term like this is met or not, and wording cannot solve it |

## Persona table

The round type and relationship are unknown, and no source established Stripe's loop, so the weights are flat at three questions per persona. That is noticeably weaker than a pack built on a known relationship.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Case / Strategist | Live problems set in the role | Flat. Relationship unknown | Clarify, state the objective, segment, approach, metrics, risks. Think aloud and challenge one premise politely |
| B Skeptic | Quiet probing of motivation and gaps | Flat. Applies in any round that tests fit | Rehearse the most predictable objection until it is boring. Bridge only from what you actually did |
| C Values / Behavioral | Scenario probes, STAR-shaped stories | Flat. Not established whether this loop has a values round | Choose stories where you can say what you did. Use "we" for context, "I" for contribution |
| D Data-Driven Prober | Digs into your numbers and assumptions | Flat. Common for an operations role | Know how each figure was counted. Name your weakest assumption before they do |
| E Pressure | Interrupts, time-boxes, plays devil's advocate | Flat. Tests composure, not content | Pause, restate, hold a position through two follow-ups before conceding anything real |
| F Conversational | Friendly, unstructured, still scored | Flat. The danger is treating it as unscored | Prepare a 90-second arc. Never answer the reverse-question slot with "I think you've covered everything" |
| G Peer Evaluator | Seam-splitting, collaboration scenarios | Flat. Likely if a peer is in the loop | Frame what you bring their team. Propose seam principles instead of claiming to know the seam |

## Question banks

No candidate sentences exist yet, so no row claims anything about your past. Past-experience questions are open prompts: you choose the instance. There are no company-specific (CO) questions because no research ran.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams disagree on whether it is ready. How do you run the next two weeks? What do you need to know first?" | CASE | [generic] | Clarify what "ready" means, who decides, what is reversible. Then objective, the disagreements by team, a plan with checkpoints, risks. No claim about your past | Live problem from F1's requirement |
| A2 | "An adoption metric for a recently launched feature dropped 20% week over week. Diagnose it." | CASE | [generic] | Check the metric's definition and window, rule out measurement change before real change, segment, form hypotheses, say what you would check first and why | Live problem from F2's requirement |
| A3 | "You are asked to set up an operating rhythm for a product organization that has none. Where do you start, and what do you leave alone?" | CASE | [generic] | Start with the decisions currently getting stuck, then the smallest rhythm that fixes that, then what you would not touch yet and why | Live problem from F5's requirement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why this role, why here, why now?" | JD | [generic] | **The highest-ROI prep in this pack.** Three short parts, each true: why the role, why this company, why now. Practise until it sounds boring. If one part has no real answer, say so plainly, then give the nearest true thing. Hold it through two follow-ups by returning to what you actually believe | A motivation probe arrives in some form in a final round. The pack can't name a sharper objection without your material (F1 to F5) |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one honestly, say what you would do about it in the first month, and don't pick a fake weakness. If none comes to mind, say so plainly, then name where you would ask for help | Tests honest self-assessment. See F1 to F5 |
| B3 | "What would you want to learn in your first thirty days before changing anything?" | JD | [generic] | Three things in your own words: what the work is, who it depends on, how success is judged. No claim about your past | Tests whether you would act before understanding. Relates to F3 |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you didn't fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Standard stem for this style. Relates to F4 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time the metric and the customer pulled apart, where you can say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Standard stem for this style. Relates to F2 |
| C3 | "Two teams you support ask for conflicting things in the same week. What do you do?" | CASE | [generic] | Clarify what each needs and by when, find what actually conflicts, decide who decides, communicate the trade-off to both. No claim about your past | Live problem from F4's requirement. CASE by delivery, VAL by theme |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a number from your work you're proud of. Walk me through how it was counted." | EXP | [generic] | Choose one you can explain end to end: how it was counted, what it is sensitive to, the assumption you'd defend least, and which part was yours. If you don't know how it was counted, say so plainly and say what you would ask | Standard stem for this style. Relates to F2 |
| D2 | "How would you decide whether a new product metric is trustworthy enough to show leadership?" | CASE | [generic] | Definition, source, a sanity check against something independent, known blind spots, who would challenge it. No claim about your past | Live problem from F2's requirement |
| D3 | "How would you tell whether a process you introduced was working or just being followed?" | CASE | [generic] | An outcome measure separate from compliance, a way to hear from the people using it, a point at which you would change or stop it | Live problem from F5's requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, answer in three sentences you can back up. Hold through two follow-ups, then concede only what is specifically true. Never fold on what you actually did just to restore harmony | Standard stem for this style. Relates to F1 to F5 |
| E2 | "I'm not convinced an operations role adds value rather than coordination overhead. Change my mind." | JD | [generic] | Don't get defensive. Concede what is fair, then say in your own words what the role changes and how it would be seen. Hold the core point through two follow-ups | Devil's-advocate challenge to the role itself. Relates to F5 |
| E3 | "Thirty seconds: what's the biggest risk in this role, and what would you do about it?" | JD | [generic] | One risk, one action, said plainly. If you don't yet know the role well enough, say what you'd find out first | Time-boxed judgment. Relates to F3 |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words: where you started, the two or three turns, why this role is next. Write it out and time it. If a turn has no clean reason, say so rather than inventing one | Standard stem for this style. Casual but scored |
| F2 | "What are you reading or trying out these days that relates to how product teams run?" | JD | [generic] | Name something you are actually doing and what you took from it. If nothing comes to mind, say so plainly and say what you'd like to explore | Casual field questions are scored. Relates to F5 |
| F3 | "What would you like me to know that we haven't covered?" | JD | [generic] | One thing you want remembered, not a recap. If nothing comes to mind, say so and move to your reverse questions | Rapport interviewers use this slot to test preparation |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles, not a claim to know this seam: who owns the decision, how disagreement escalates, how it's recorded | Standard stem for this style. Relates to F4 |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time work spanned teams where you can say who did what. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Standard stem for this style. Relates to F1 and F4 |
| G3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity: give as much as you ask. Name what you'd ask for and one thing you could offer, both true to what you can actually do | Tests partnership fit. Relates to F1 |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Coordinating across teams | A1, E1, G1, G2, G3 |
| F2 Metrics | A2, C2, D1, D2 |
| F3 Structuring ambiguity | A1, A2, B3, E3 |
| F4 Influence without authority | C1, C3, G1, G2 |
| F5 Process and operating rhythm | A3, D3, E2 |
| F6 Location and right to work | none, because a gate is a term and no question can rehearse it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like in this role, and how will you know?" | Shows you think in outcomes and want a standard to hold yourself to |
| R2 | "Where does the work of this role most often get stuck between teams?" | Shows you think about seams and want the real ones, not the org chart |
| R3 | "What's a recent decision this role's work actually changed?" | Moves the conversation from the job description to evidence of impact |
| R4 | "What would make you regret this hire a year from now?" | Invites candor and gives you something concrete to address |
| R5 | "What has changed about how the team operates in the last year that I should know?" | Signals you want current context, not the archival version |
| R6 | "What haven't I asked that I should have?" | Gives the interviewer room to raise what they were holding back |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None yet | No candidate sentence exists to inflate, and no stated negative or dossier entry is available | Anything you add enters the fit snapshot as a quote, and its inflated forms are listed here on regeneration |

## Sources

Provided documents: none.

Searches sent, all refused (permission not granted):
- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe strategy 2026 news annual letter": refused
- "Stripe Product Operations Manager job posting": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have supplied published value names for a values cheat sheet and VAL themes; none is in this pack |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Would have established the loop; persona weights fell back to flat |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded CO questions; there are none |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have supplied inferred requirements; F1 to F5 are generic patterns instead |

## Upgrade menu

- The job description text → F1 to F5 become quoted requirements and the JD-tagged questions become `[grounded]`
- Your CV or a short account of your background → verbatim evidence in the fit snapshot, story maps in place of scaffolds, and a filled prohibited list
- The round type and who you're meeting → persona weights stop being flat and the banks reorder
- The interviewer's name → an interviewer read and a reverse question tied to their path
- The recruiter's prep email (focus areas, any deliverable) → coverage of anything pre-declared
- Permission to search, or Stripe's values and interview-process pages pasted → a values cheat sheet, a documented loop, and company-strategy questions
- Your location and right to work, if the role is tied to a place → F6 stops being an open gate
- A tuesday-dossier.md from an earlier fit review → verified evidence and a named highest-ROI objection instead of an inferred one

Say the word and I'll play the Skeptic on B1, the question this pack names as its highest-ROI prep.
I can also write a tuesday-dossier.md recording the gaps this prep exposed, and save this pack as a file if you grant write access.

1. Who runs this final round, and what's their relationship to the role (hiring manager, peer, skip-level, cross-functional)? Did the recruiter name focus areas or a deliverable? Either answer reweights every bank.
2. Can you paste the job description and your CV or a short background, or tell me to proceed without them? Each turns scaffolds into your own story maps.
3. Are you able to work from the location the role is based in, and do you have the right to work there? That settles F6.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.