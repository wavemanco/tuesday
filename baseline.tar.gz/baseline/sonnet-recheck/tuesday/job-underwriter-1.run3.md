I've read the underwriting playbook and I'm now loading the search tool so I can check that Harborlight Health exists and is hiring, before I write the assessment.
**Yes, apply. You fit on the core requirements, and the healthcare gap is real but secondary.** Research was blocked, so the employer is still unchecked. That keeps this at conditional, not a clean go.

## Decision snapshot

**Yes, apply: R1, R2, R3, R4 and R5, the must-haves, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (Metrics layer), R7 (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data, HIPAA)

R8 is the row a hiring manager is likeliest to probe, and R9 is the domain gap.

**Opportunity ledger.** The employer could not be checked, because the search was refused (RR1). Compensation and level are not in the posting (RR2), and how much clinician partnership the role involves is unstated (RR3). One entry runs the other way: the responsibilities are concrete and tied to roadmap decisions (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the compensation question gets answered before you invest in a loop (RR2); (3) the healthcare gap is framed as adjacent, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header, not checked against any outside source |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards | `[grounded]` JD |
| Stakeholders | Product managers and clinicians, turning analysis into roadmap decisions | `[grounded]` JD |
| People scope | Mentor two junior analysts; no stated direct-report authority | `[grounded]` JD, for mentoring; `[inferred]` for the authority read, from the JD's silence |
| Success outcomes | No first-90-days or first-year outcomes stated | `[grounded]` JD silence |
| Compensation | Not stated | `[grounded]` JD silence |
| Market calibration | Not done: the role-family sweep was refused, and I won't quote a pay band from memory | `[grounded]` search refused |
| Unknowns | Pay and level; whether the metrics layer already exists or is to be built; how embedded the clinicians are; the experimentation platform and traffic volume | — |
| Contradictions | None found within the JD and your background; no external page was compared | `[inferred]` from the two inputs only |

## Evidence map

Your background was typed into the conversation, so it counts as self-report: leads, not proof. That caps everything at `medium` until you give me something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit company is stated and specific. No document backs it | `[grounded]` your intake message | A CV or LinkedIn page would raise this to `high` |
| R2 | Expert SQL | must_have | direct | medium | discovery | "SQL daily on Snowflake" shows use, not level. "Expert" is a judgment a screen may test directly | `[grounded]` your intake message; `[generic]` that SQL screens for analyst roles usually test live | Offer a sanitized complex query or a description of your hardest model |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, and you designed the program and the pricing test behind an 11% retention lift. The lift figure and your ownership are unverified | `[grounded]` your intake message | A sanitized test readout or experiment-program doc would raise this to `high` |
| R4 | Looker or similar BI | must_have | direct | medium | none | You built the Looker instance from scratch, 40+ governed dashboards. This is the same tool the JD names | `[grounded]` your intake message | A screenshot or description of the LookML structure would raise this to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product | `[grounded]` your intake message | A sanitized memo would raise this to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | Governed dashboards and an exec metrics memo suggest you handled metric definitions, but you did not say you owned a semantic layer or metric definitions | `[inferred]` from "governed dashboards" and the memo | Ask G1 |
| R7 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | medium | transferability | Monthly VP Product presentations cover the PM half. Nothing in your background is a clinician-partner analogue. The limit: you have not translated analysis for clinical judgment or safety concerns | `[grounded]` your intake message for the VP Product work; `[inferred]` for the limit | Name any domain-expert partnership you have had, such as a nutritionist or ops lead |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in your background mentions mentoring or managing analysts | `[grounded]` your intake silence | Ask G2 |
| R9 | Healthcare data experience (HIPAA) a plus | preferred | adjacent | medium | transferability | GDPR/CCPA PII handling and a consent-state model are real, relevant privacy work. The limit: PHI rules, de-identification standards and business associate agreements are not exercised by consumer-privacy work | `[grounded]` your intake message; `[generic]` that HIPAA differs from GDPR/CCPA in these ways | Ask G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | Governed dashboards and a metrics memo, but no statement that you defined and maintained the metric definitions behind them | The JD lists this first among responsibilities, so a clear yes would make this row `direct` | A metric dictionary or definitions doc; LookML measures you owned; resolving "two teams, two churn numbers"; a certified-metrics process | A metric glossary, a LookML excerpt or a governance doc | `[grounded]` your silence on definitions; `[inferred]` that this is the first responsibility the JD lists |
| G2 | Mentoring (R8, important) | discovery | Nothing in your background either way | The JD names two junior analysts, and an empty row reads as "no" | Onboarding a new analyst; reviewing others' SQL or dashboards; running an analytics office hour; coaching an intern | A short description is enough; no artifact needed | `[grounded]` your silence |
| G3 | Healthcare and regulated data (R9, preferred) | transferability | A consent-state model and consumer-PII handling | The bridge is credible, and it needs the limit stated up front | Access controls or audit logging you designed; data minimization or retention rules; security or legal reviews you passed; any health-adjacent data such as dietary or allergy information | The consent-model design doc, or a description of the review process | `[inferred]` bridge from the consent-state model; `[generic]` that HIPAA-adjacent roles probe this boundary |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The posting, or the company's details, could not be checked because the search was refused. That is not a failed attribution, which is why I rated this `low`, not `medium` | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and tell me who I would be interviewing with? | unresolved |
| RR2 | Compensation and level not stated | unknown | — | "Senior Product Analyst" | A senior title with mentoring duties may or may not be priced like one; the posting gives nothing to compare | `[inferred]` from the JD's silence | What is the budgeted range and level for this role? | unresolved |
| RR3 | Clinician partnership scope unclear | unknown | — | "partner with product managers and clinicians" | Clinicians may be embedded partners or occasional reviewers, and that changes the daily work | `[inferred]` from the JD's one-line mention | How often do analysts work directly with clinicians, and on what kind of decisions? | unresolved |
| RR4 | Responsibilities tied to decisions | positive_signal | — | "turn analysis into roadmap decisions" | The role looks aimed at influencing decisions, not just producing reports | `[grounded]` JD language | Which roadmap decision did analytics change last quarter? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your application with the experimentation program: 30+ tests a year and the pricing test behind the 11% retention lift, stating your own role in it | R3 is a `must_have` row and your strongest evidence | `[grounded]` your intake message | pending your approval |
| E2 | Describe the Looker build as governed, and name who relied on it | R4, and it gives G1 a place to land if the answer is yes | `[grounded]` your intake message | pending your approval |
| E3 | Prepare a sanitized monthly metrics memo as a writing sample | R5 | `[grounded]` your intake message | pending your approval |
| E4 | Frame the healthcare gap as adjacent: consent-state and PII work, with PHI and HIPAA named as what you would learn | R9 | `[grounded]` your intake message | pending your approval |
| A1 | Confirm the posting is live on the company's own careers page before applying | RR1 | `[grounded]` register | pending your approval |
| Q1 | Ask the verification questions from RR2 and RR3 in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have confirmed the employer and the live posting, feeding RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | The search was refused. It would have given a market band for this seniority, feeding RR2 and the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can offer you a dossier file, `tuesday-dossier.md`, if you want to carry this analysis into interview prep.

**Upgrade menu**

- Permission to search, which would run targets 1 and 2 and could clear RR1 and put a market band beside RR2. A deeper pass on company history and recent news would be up to 5 more searches and 2 more fetches, if you want it.
- A sanitized experiment readout, metrics memo, or LookML excerpt, to raise R3, R4 and R5 to `high`.
- A sample of your hardest SQL, to settle the "expert" claim in R2.
- The hiring manager's name, for the scope read and which story to lead with.

**Questions**

G1 — Did you personally define and maintain metric definitions that other teams relied on, such as a metric glossary, shared LookML measures, or a "one official churn number" decision? What did you own, and who used it?

G2 — Have you onboarded, coached or reviewed the work of other analysts, formally or informally? Describe what you did and for how long.

G3 — In building the consent-state model, did you design access controls, retention rules, audit logging, or pass a security or legal review? Did any data you handled touch health information, such as dietary or allergy data?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.