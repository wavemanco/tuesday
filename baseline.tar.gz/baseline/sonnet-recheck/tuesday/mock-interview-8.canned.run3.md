I've built the full prep pack, but the write to the working folder was refused. I'm retrying in the session scratchpad.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-canned-9336ece8/25951ae1-4372-4b31-a854-4d547cb7d5d4/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. The write to the working folder was refused, so it's in the session scratchpad instead.

I built it as a three-round loop from the recruiter's email, with a separate set of questions for each round:
- **Round 1 (recruiter):** 8 questions.
- **Round 2 (Head of Member Services):** 10 questions.
- **Round 3 (the two branch managers):** 12 questions, plus a values cheat sheet and a method for the 20-minute escalation case.

It uses only what you gave me. I ran no searches and did not fetch the values page or the strategy brief, so the strategy questions rest on your four-point summary.

- **Highest-ROI prep is D1.** It's the "you've handled your branch's complaints log, you haven't worked in a contact centre, and this role owns both" question. Your own sentences name that gap, and the pack rehearses it by holding what you actually did and conceding plainly.
- **Most values stories are scaffolds, not mapped answers.** Only Own the Fix has one of your sentences behind it (the complaints log). For the other three values, you'll need to bring a real example.
- **The pack never coaches** "owned the process end to end", "coached supervisors", or "handled regulated complaints". Your material says "formal" complaints and "new tellers", so those answers are slots for you to fill truthfully.
- **The date doesn't match.** Your note puts today at 12 October, with the rounds on 21 October, but this session's clock reads 5 November. I built it on your dates, so tell me if the rounds have already happened or moved.
- **Round 3 assumes the branch managers manage the supervisors you'd coach.** I read that from the JD; if they sit above the role instead, the Peer bank (J) should give way to the Skeptic bank.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**For:** Dara. **Loop:** three rounds on 21 October 2026, per the recruiter's email. **Built on:** the intake of 12 October 2026.

| Round | Who | Length | What it holds |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | A panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned beyond these roles, so there is no interviewer read.

## How to use this pack

- Personas describe how a question is asked; types describe what it is scoring. Every question carries both a persona (its bank) and a type.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- Type key: **VAL** behavioural or values alignment; **EXP** work-experience deep-dive; **JD** role and JD-driven; **CO** company and strategy knowledge; **CASE** hypothetical or live problem.
- Provenance key: `[grounded]` traces to something you or the recruiter gave me; `[inferred]` is derived from an adjacent source; `[generic]` is a role-family pattern with no claim about Ashgrove or about you.
- An answer slot is an instruction for the interview, not a question for this conversation. Where an answer of yours would sharpen the pack, the upgrade menu says which rows it would upgrade.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you pasted. Evidence is quoted from your message; the only background I have is the short summary in it, not a CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: expect a probe on how far your part reached beyond the log. If any step beyond the log was yours, say which and what you did, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn the contact centre, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses and does not show what it counted; the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. Say what it counted and how, in your own words; if it counted neither, or someone else defined the counts, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: expect a probe on what that training covered and how you ran it. Say, in your own words, what you covered and how you ran it; if there was no more to it than the script, or the content was not yours to set, say so plainly and stay with the new tellers you trained |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the strategy brief you were sent puts 40% of member service on digital channels by 2028, so expect this probe. If you have worked with a digital or product team on anything members use themselves, say what and what your part was, in your own words; if you have not, or it was not yours, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in length, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with it in your own terms, "6 years in retail banking, the last 3 as a branch supervisor", and leave the JD's phrase "customer operations" to the interviewer; do not relabel your work in it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says formal complaints, not regulated complaints, and does not show what made them formal; the words stay there: "I handled the branch's formal complaints log." Answer slot: expect a probe on what made those complaints formal. Say what made them formal at your branch, in your own words; if you do not know, or that was set by someone else, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added about what you presented at regional level, because your material does not say |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says spreadsheet, not Excel; the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD says Excel, so expect a probe on the tool. Say what it was built in, in your own words; if it was another tool, say which and say so plainly |

No row is a hard gate: the JD you pasted states no authorisation, licence, location, schedule or pay term, and its years requirement is graded as experience (F6).

## Grounding brief

The four strategy points you gave me from the June 2026 brief the recruiter sent. I have not read the brief itself, only your summary of it.

| Point | Source | Where it shows up in this pack |
|---|---|---|
| 40% of member service to move to digital channels by 2028 | Strategy brief, as you summarised it | E1, H2 |
| Eight branches to consolidate into five hubs over 2027 | Strategy brief, as you summarised it | E2, H2, G3 |
| A small-business lending product to launch in Q1 2027 | Strategy brief, as you summarised it | Not used in a question; no complaints question rests on it |
| The main competitive pressure is app-only banks | Strategy brief, as you summarised it | E1 |

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly and unstructured; "walk me through the journey"; casual asks on the digital side | High. A recruiter screen sets this as the starting weight, and the recruiter's own email makes this the shortest session | Pre-script the 90-second arc (A1); treat casual questions on hot JD topics (A4, A5) as scored; never answer "I think you've covered everything" in the reverse-question slot |
| Skeptic, light | Gentle probes on motivation, the years requirement and the weakest area | Medium-low. Knockout and motivation checks are the starting weight; your own sentence names two limits (F2, F8), which gives a screener something to ask | Rehearse the day-one-weakest answer (B2) until it is boring |

Depth: Conversational 5 questions, Skeptic 3.

## Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with four beats, each a clause your sentences state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Say "I" for what you did. Close with your own reason for wanting this role, which the pack does not supply | F6, F1, F4 and F3 are the evidence the arc rests on; EXP because it is a walk through the background; casual in register but scored |
| A2 | "What do you know about Ashgrove, and what drew you to it?" | CO | [grounded] | Say what you have actually read, and no more: the four values by name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) and the four strategy points in the grounding brief. Then pick the one or two that genuinely draw you and say why in your own words; the pack supplies no reason. Say what you would like to learn more about | Homework and motivation are the recruiter-screen starting weight; CO because it tests company knowledge. The values and strategy points are from your message |
| A3 | "Before we go on, what are your notice period and pay expectations?" | JD | [generic] | Decide your notice period and your pay expectation before the call; the pack knows neither and supplies neither. The JD you pasted states no pay, so asking the recruiter for the band first is reasonable. Give a figure or range you can defend, not "flexible" | Logistics and knockout checks are the recruiter-screen starting weight; JD because it scores role terms; generic because it is a pattern, not a fact about Ashgrove |
| A4 | "Tell me about a time you worked with a digital team on something members use themselves." | JD | [generic] | Pick a time you worked with a digital or product team on something members used on their own. It needs a named change, your part in it, and what members did differently afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach working with a digital team | F5 has no evidence, and the strategy points put 40% of member service on digital by 2028, so this probe arrives early. JD because it scores a stated responsibility; casual in register |
| A5 | "How comfortable are you in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built, in those terms: the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD says Excel, so expect a probe on the tool. Say what it was built in, in your own words; if it was another tool, say which and say so plainly. Do not rate yourself on a scale the spreadsheet cannot back | F9 is the evidence and the gap is whether the tool was Excel; JD because it scores the stated requirement |

## Bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why are you looking to move on from your branch role?" | EXP | [generic] | Give your own reason in one or two sentences, framed toward what this role offers rather than against your current one. The pack knows no reason and supplies none; decide yours before the call | The persona's stem on motivation consistency; EXP because it tests the story of the career move; generic because the reason is yours |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick one and say it first, before they do. Your own sentence names two limits, and the words are yours: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Then how you would close it, said as a plan and never as a past. Name no third weakness that your material does not show | F2 and F8 are the stated limits; JD because it scores honest self-assessment against the stated requirements |
| B3 | "The role asks for 4+ years in financial-services customer operations. How does your background map?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer in your own terms: "6 years in retail banking, the last 3 as a branch supervisor." Let the interviewer decide whether that is the JD's phrase; do not relabel your work in it | F6 is the row this question tests and the cheapest to rehearse; JD because it scores a stated requirement |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Who will I be meeting in the second and third rounds, and is there anything I should prepare for them?" | It surfaces the names and roles still to be assigned, which the upgrade menu says would sharpen the pack |
| R1.2 | "Is there anything in my background you would want me ready to expand on in the later rounds?" | It invites a hint about the gaps, from the person who knows what the later rounds look for |
| R1.3 | "Is there anything I should prepare or bring for the 20-minute case in the panel?" | It finds out whether any material comes with the case |
| R1.4 | "What is the highest priority for this role in its first six months?" | It shows you are thinking about the job, not only the process |
| R1.5 | "What happens after the third round, and when do you expect to decide?" | It closes the logistics so the next steps are not a surprise |

---

# Round 2: the Head of Member Services (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes and "tell me about a time"; STAR-shaped stories | High. The recruiter's email says this round is mostly behavioural | Map a story to a question only where one of your sentences carries it; otherwise use the scaffold and its honest branch; "we" for context, "I" for contribution |
| Skeptic | Quiet, persistent probing of the gaps and the move into this role | Medium-high. The hiring-manager starting weight is capability and gaps, and F1, F2 and F8 are where a manager would press | Rehearse D1 until it is boring; concede the stated limits in plain words |
| Case/Strategist | A live problem set on the role's own roadmap | Medium. The hiring-manager starting weight, tempered by the recruiter's "mostly behavioural"; the strategy points in hand supply three problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

Depth: Values/Behavioral 4, Skeptic 3, Case/Strategist 3. The highest-ROI prep in the whole pack is **D1**.

## Bank C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pick a time you told someone senior something they did not want to hear. It needs a named stake, the plain words you used, and a relationship intact afterwards. Name the audience accurately: your sentence says you have never presented above regional level, so do not stretch an audience upward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's stem; F8 is the limit on how high the audience can honestly be. VAL, with EXP delivery |
| C2 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4, with the beat the sentence states: you trained new tellers on the escalation script. Tell that in your own words. Answer slot: expect the probe to ask for a real escalation you worked through with someone. If one was yours, say what happened and what part was yours; if none was, or the training was all of it, say so plainly and stay with the tellers you trained | F4 is the evidence for the coaching requirement; JD because it scores a stated responsibility, behavioural in delivery |
| C3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3, with the beats the sentence states: you built it, it was monthly, it was about complaints, your regional manager uses it. Say what it counted and how, what the counts are sensitive to, the assumption you would defend least, and which part was yours, in your own words; if you do not know how something was counted, say so plainly. Answer slot: the JD names complaint volumes and resolution times, so expect a probe on whether it counted either; if it did, say how each was counted; if it did not, or the counts were set by someone else, say so plainly and stay with the spreadsheet you built | F3 and F9 are the evidence; EXP because it tests what was actually yours, and a prober's question can arrive in a behavioural round |
| C4 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time you chose the member's outcome over a branch target or a process measure. It needs a named choice, what it cost, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide. The same story can serve G1 in round 3 | The persona's stem; Members First, Always is the first published value, so one rehearsed story pays twice |

## Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've handled your branch's complaints log and you haven't worked in a contact centre. This role owns the process across both. Why you?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** Pause and restate the question. Hold only what the sentence carries: "I handled the branch's formal complaints log." Concede early, in plain words: "I've never worked in a contact centre." Then a plan in the future tense: what you would learn first about the contact centre, from whom, and what you would ask. Follow-up 1, "that's one branch": concede the scope, since the log was the branch's, and return to what you handled. Follow-up 2, "so why trust you across the whole process": do not claim it; say what you would do in your first weeks, as a plan. Follow-up 3, "what would you need from us": name what you would need. Hold through two follow-ups before conceding anything real, and never add to the log to win the exchange | F1 and F2 are the widest gap between your material and the role, and you stated the contact-centre limit yourself, so this question arrives in some form. JD because it scores the headline responsibility; Skeptic because it presses the gap |
| D2 | "This role presents to senior leaders. Tell me where you stand on that." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Answer slot: your material does not say what you have presented at regional level; if you have presented there, say to whom and about what, in your own words; if you have not presented, say so plainly | F8 is a stated limit; JD because it scores the stated requirement |
| D3 | "The role asks for experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7, with the beat the sentence states: you handled the branch's formal complaints log. Tell that in your own words. Answer slot: expect the probe to press on what made those complaints formal. Say what made them formal at your branch, in your own words; if you do not know, or that was set by someone else, say so plainly and stay with the log you handled | F7 is the evidence and the likeliest place to be probed; JD because it scores a stated requirement |

## Bank E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove aims to move 40% of member service to digital channels by 2028, with app-only banks the main pressure. Where do complaints sit in that, and what should stay human?" | CASE | [grounded] | Clarify first: what counts as member service, and how complaints reach Ashgrove today (you do not know, so ask). Objective: what a good complaint outcome is from the member's side. Segment complaints by how complex they are and what the member needs. Approach: what can be self-served, what needs a person, and how a member moves between the two without repeating themselves (Plain Words). Metrics: complaint volumes and resolution times, the two the JD names. Risks: members passed around, and app-only banks setting the standard. Challenge one premise respectfully, for example whether 40% should apply evenly to complaints. The question needs no claim about your past, so the guidance makes none | The first strategy point and the competitive frame, joined to the role's own subject; CASE because it is a live problem; F5 is why the digital angle matters here |
| E2 | "Eight branches become five hubs over 2027. Walk me through what should happen to a member's open complaint when their branch is one of those that merges." | CASE | [grounded] | Clarify: when the change happens relative to an open complaint, and who holds it today. Objective: the member never has to start again. Segment by how far along the complaint is. Approach: one named owner for each open complaint across the move (Own the Fix), and a notice to the member in plain words (Plain Words). Metrics: resolution time and repeat contact. Risks: complaints lost between sites, and members feeling processed rather than known. The question needs no claim about your past, so the guidance makes none | The second strategy point set against the values text; CASE because it is a live problem; ties to F1 because the process spans branches |
| E3 | "The role reports monthly on complaint volumes and resolution times. How would you build that report for senior leaders?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Structure it: who reads it and what they decide from it; what volumes show and what resolution times show; what to add and what to leave out; and the questions you would put first, such as how a complaint is defined and when its clock starts and stops. For your own material, keep to its scope: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if it counted volumes or resolution times, say how each was counted, in your own words; if it counted neither, or someone else defined the counts, say so plainly and stay with the spreadsheet you built | F3 and F9 against the role's reporting line; CASE because it asks you to build, with JD content |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would a good first 90 days look like in this role?" | It turns the conversation to what success looks like and invites the manager to say what matters first |
| R2.2 | "How does the complaints process run today across branches and the contact centre, and where does it break?" | It asks about the thing the role owns, and shows you expect to learn the contact centre rather than pretend to know it |
| R2.3 | "How are complaint volumes and resolution times reported to leaders now, and what would you want changed?" | It shows reporting is a working concern for you, and tells you what the monthly report has to beat |
| R2.4 | "Who are the digital counterparts for the self-service work, and how do complaints feed into it?" | It tests whether the 40% digital target reaches complaints, and shows you read the strategy |
| R2.5 | "What would make you say, at six months, that this hire isn't working?" | It invites the objection into the open, where you can answer it |

---

# Round 3: the panel of two branch managers (60 minutes)

The panel is also the values round: the recruiter's email says it scores against the four values. It includes a 20-minute case on a complaint escalation.

**Assumption to correct:** I treated the two branch managers as stakeholders whose supervisors you would coach, because the JD says "coach branch supervisors on escalations". If they instead sit above the role, the Peer bank should give way to the Skeptic bank.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" scored against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Highest. The recruiter's email says the panel scores against the four values | One story per value where a sentence of yours carries it; otherwise the scaffold and its honest branch |
| Case/Strategist | The 20-minute escalation case, with follow-up on hubs and coaching | High. The recruiter's email names a 20-minute case on a complaint escalation | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | The seam between your coaching and a branch manager's own job; credit across teams | Medium. This rests on the assumption above | Reciprocity first: what the role gives the branch managers; propose seam principles rather than pretending to know the seam |
| Pressure | Time-boxed challenges on the stated limits | Low-medium. Two panelists and 60 minutes, with no sign in the email of a stress style; F2 and F8 give material if it appears | Pause, restate, hold the position through two follow-ups, concede specifically |

Depth: Values/Behavioral 5, Case/Strategist 3, Peer Evaluator 2, Pressure 2.

## The 20-minute escalation case

The recruiter's email says only that it is a 20-minute case on a complaint escalation. The case itself is not known, so nothing below assumes its facts.

| Item | Content | Provenance |
|---|---|---|
| What is announced | A 20-minute case on a complaint escalation, inside the 60-minute panel | [grounded] |
| Structure to use | Clarify; objective; segmentation; approach; metrics; risks. One way to spend the time: clarify early, structure aloud, then test your approach against the panel's questions | [generic] |
| Clarifying questions worth having ready | What has already been promised to the member; what limits or rules apply to this complaint and its timing; who holds it now; what the supervisor has already tried | [generic] |
| Values to keep visible | Say early who holds the complaint (Own the Fix) and how the member will hear the outcome (Plain Words) | [grounded] |
| What the material lets you say about yourself | Keep any claim about your past inside F1 and F4: you handled the branch's formal complaints log, and you trained new tellers on the escalation script | [grounded] |
| The close | None was named in the recruiter's email | [grounded] |

## Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Pick a time you chose the member's outcome when it was inconvenient for the branch or for you. It needs a named decision, the stake, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide. The story from C4 can serve here | Members First, Always, in the value's own words; the panel scores against it |
| G2 | "Tell me about a time a member needed something explained twice." | VAL | [generic] | Pick a time a member did not understand what they were told the first time. It needs the thing that was unclear, what you changed in how it was said, and whether it worked the second time. The value puts the fault on the writer, so a story that blames the member's understanding works against it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would say it plainly | Plain Words, whose published text says "if a member needs it explained twice, we wrote it wrong" |
| G3 | "Tell me about a time the town mattered more than the number." | VAL | [generic] | Pick a time you weighed a figure against what a branch meant to the people around it. It needs a named decision, what the figure said, and what the town needed. Expect it to be set beside the hub plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | Neighbours, Not Numbers, and the hub consolidation is in the strategy points; the panel is the round that scores it |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1, with the beat the sentence states: you handled the branch's formal complaints log. Tell that in your own words. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on a complaint you followed from when it was found to when it was solved. If you followed one that way, say which and what you did; if the log was where your part ended, or none ran that way, say so plainly and stay with the log you handled | Own the Fix; F1 is the only row whose evidence touches the value |
| G5 | "Which of our four values would be hardest for you to live up to?" | VAL | [generic] | Pick one honestly, say why in a sentence, and say how you would work at it. Do not claim all four are easy. The pack does not pick for you | The panel scores against all four, and candour about one is a way to show you read them |

## Bank H: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A branch supervisor escalates a complaint the branch could not resolve. Walk us through your first hour and your first week." | CASE | [generic] | Practice version of the announced case, not their case. Clarify first: what was promised, what limits or rules apply and when they bite, what the supervisor has tried. Objective: the member's outcome, in words they understand. Segment by urgency and by what the member needs. Approach: name who holds the complaint, tell the member what happens next in plain words, and coach the supervisor on what to do differently next time. Metrics: resolution time and whether the member had to chase. Risks: passing the complaint around, and branch and contact centre telling different stories. The question needs no claim about your past, so the guidance makes none | The announced case, set as a practice problem; CASE because it is a live problem; F1 and F4 are the rows it presses on |
| H2 | "Branches are becoming hubs over 2027. What should the complaints process do so members in the affected towns still feel it's theirs?" | CASE | [grounded] | Clarify what changes for members and when. Objective: a member in an affected town still has someone who holds their complaint. Approach: a named owner per complaint across the move (Own the Fix), plain-worded notices (Plain Words), and a local face for escalations where it matters (Neighbours, Not Numbers). Metrics: resolution time, repeat contact, and what members say. Risks: the digital shift making the process feel distant. The question needs no claim about your past, so the guidance makes none | The hub and digital strategy points set against the values; CO with CASE delivery |
| H3 | "Role-play: I'm a supervisor and I've just told a member their complaint can't be escalated until Monday. Coach me." | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Ask first what happened and what they were trying to do. Name what was sound. Offer one thing to change. Agree what the member hears today and who holds the complaint. Close by asking how it felt. Keep anything you say about your own past inside your material, which carries training new tellers on the escalation script | F4 is the evidence, and the role-play tests coaching rather than the script; CASE because it is live |

## Bank J: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Our supervisors are stretched at peak times. Where does your coaching end and our job as branch managers start, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than claiming to know the seam: ask before you tell; keep the branch manager informed about coaching themes; every complaint has one named owner. Reciprocity: what the role gives them is the monthly complaint numbers for their branch. On disagreement: say your view, hear theirs, agree what the member hears today. If you have a story of disagreeing with an equal, pick one with a named stake and a relationship intact afterwards; if none comes to mind, say so plainly and describe how you would handle it | The seam is the peer persona's centre; JD because it scores the coaching responsibility |
| J2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick an occasion when work crossed teams. Use "we" for the team's context and "I" for what you did, and say who else did what. If no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle credit | The persona's stem; EXP because it probes attribution |

## Bank K: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Sixty seconds: why you rather than someone who has run a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause and restate. Three lines: what you hold, "I handled the branch's formal complaints log"; the concession, "I've never worked in a contact centre"; and your plan, in the future tense. Hold through two follow-ups by returning to the log, never by adding to it. Concede specifically and never fold on what the sentence carries | F1 and F2 under time pressure; the pressure persona tests composure, not content |
| K2 | "This role presents to senior leaders. You've never presented above regional level. Convince us." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause and restate. Concede in the exact words: "I've never presented to anyone above regional level." Then your own plan for getting ready, said as a plan. Hold through two follow-ups; do not claim senior experience you have not described, and concede specifically | F8 is a stated limit; the pressure persona tests whether you hold without defending |

## Values cheat sheet

A values-style round is detected: the recruiter's email says the panel scores against the four values. Names are from the page you pasted.

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Look at a decision from the member's position first | Scaffold, ending in its honest branch: see G1 and C4. No sentence of yours carries a story for this value |
| Plain Words | If a member has to hear it twice, the explanation was at fault | Scaffold, ending in its honest branch: see G2. No sentence of yours carries a story for this value |
| Neighbours, Not Numbers | Each branch matters to its own town, not only to the figures | Scaffold, ending in its honest branch: see G3 and H2. No sentence of yours carries a story for this value |
| Own the Fix | The person who finds a problem keeps it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence states the log; the rest is the answer slot in G4 |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does a good escalation from one of your supervisors look like today, and what does a bad one cost your branch?" | It puts the conversation in the branch managers' world and gives the case a real definition |
| R3.2 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question: it asks what you can give them, not only what you need |
| R3.3 | "How is the move to hubs being talked about in your branches, and how should complaints be handled during it?" | It shows you read the strategy and puts Neighbours, Not Numbers into practice |
| R3.4 | "Which of the four values do you see lived most visibly in your branch?" | It invites their stories, and shows you take the values seriously |
| R3.5 | "How would you prefer to hear about problems your supervisors raise?" | It starts the seam conversation and shows you will ask before you tell |

---

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches" (F1) | D1, E2, G4, H1 |
| "and the contact centre" (F2) | B2, D1, K1 |
| "report monthly on complaint volumes and resolution times" (F3) | C3, E3 |
| "coach branch supervisors on escalations" (F4) | C2, H1, H3, J1 |
| "work with digital teams on self-service journeys" (F5) | A4, E1, H2 |
| "4+ years in financial-services customer operations" (F6) | A1, B3 |
| "experience handling regulated complaints" (F7) | D3 |
| "confident presenting to senior leaders" (F8) | B2, C1, D2, K2 |
| "comfortable with Excel reporting" (F9) | A5, C3, E3 |

The CV has no headline figure to defend (its numbers are years of experience), so there is no defend-the-number question. Every published value has a question: Members First, Always (G1, C4); Plain Words (G2); Neighbours, Not Numbers (G3, H2); Own the Fix (G4).

## Prohibited claims

Built from the fit snapshot before the banks were written. Each is a claim this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's formal complaints log, not the process end to end. The slots stay inside the log |
| Worked in, or ran, a contact centre | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot beyond what D2 gives for regional level |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says new tellers and the escalation script. The slots ask only what that training covered |
| Produced complaints reporting for senior leaders or the whole organisation | Inflated form of F3 | F3's quote at its own scope: the spreadsheet your regional manager uses. The slots ask only what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says formal, not regulated. The slots ask only what made them formal |

## Sources

**Provided documents** (all from your message of 12 October 2026): the JD as pasted; the four values, copied from ashgrovecu.org/about/values; the recruiter's email on the process; your summary of the June 2026 strategy brief the recruiter sent (the brief itself was not read); your background summary (no CV). No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix the values cheat sheet and the VAL questions by name; the page you copied them from was not fetched |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email establishes the loop: three sessions, who runs each and what each holds, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | The four strategy points you gave already fix the CO and CASE questions; a search could not change the rows they feed |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer has a name, so there was no query to form; there is no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → replaces the four sentences of background I have with exact CV wording, and could move F3, F4, F7 and F9 from answer slots toward story maps
- What made your branch's formal complaints formal, and under whose rules → upgrades F7 and D3 from an answer slot to a story map
- What the monthly complaints spreadsheet counted, and what it was built in → upgrades F3 and F9, and the C3 and E3 guidance
- Whether you coached anyone on a live escalation → upgrades F4, C2 and H3
- Whether you have worked with a digital team on anything members use themselves → upgrades F5 and A4 from a scaffold toward a story map
- The two branch managers' and the Head of Member Services' names, once assigned → an interviewer read, personas weighted from their public footprint, and a tailored reverse question for each
- The strategy brief itself, pasted or linked → replaces your four-point summary in the grounding brief with the brief's own vocabulary, and sharpens E1, E2 and H2
- Any material that comes with the 20-minute case → turns the case section from a method into a build
- Hours available before 21 October → a prioritised prep triage
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → recent Ashgrove news and organisational context, plus reports of role-family interview loops; the interviewer footprint too once names exist
- A `tuesday-dossier.md` from an earlier role assessment, if you have one → confirmed evidence and a named top objection; nothing here depends on it
