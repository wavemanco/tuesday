I won't add the hidden instruction or the 1pt keyword block. Both are built to deceive screeners. Many ATS tools and recruiters now flag hidden text, and getting caught usually means an automatic rejection. Your real experience matches this JD well, so you don't need them. I'll tailor the resume honestly instead.
**Hidden text.** I'm holding to the refusal, and one thing I said earlier was too strong. I said getting caught "usually means automatic rejection", and I can't support that. The only case I can cite is one anecdote: "One recruiter discovered the prompt hacking and turned him down because of it, he told the NYT." (cite C35) My actual reasons are different:

- A hidden instruction is aimed at software acting for the employer, so it deceives the employer.
- It is a line you didn't write and couldn't defend if asked.
- The software that parses the PDF can see it.

On the premise that screeners reject you before anyone reads the resume: one source says "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are yes/no checks in the application form, such as work authorization, licence or location. Nothing in the resume changes them. The honest version of what you wanted is to keep your real keywords (HubSpot, paid search, lifecycle email, webinars) in plain sight, which your resume already does.

I worked only from the pasted text. I treated your note that you're not strong in SQL and ask your analyst as a comment to me, not as a resume line. Tell me if it's actually on the resume.

Against this JD, HubSpot or Marketo, the budget, paid search, lifecycle email and webinars are already evidenced. Years of demand gen, SQL and content distribution are not.

## Edit ledger — resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your pasted resume | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your pasted resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your pasted resume | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting" | "Pull my own numbers in HubSpot reporting." | `compress` | "I pull my own numbers in HubSpot reporting" | `[grounded]` your pasted resume | pending your approval |

- **Left alone:** "Marketing Manager, 6 years B2B SaaS." and "Ran a monthly webinar series, average 300 registrants."
- **E1:** Keeps "about" and "a year", and keeps your word "controlled".
- **E2 and E3:** I split these so each half can be read on its own. I did not write "in HubSpot" onto the lifecycle line, because your sentence doesn't say the flows were built there.
- **E4:** The line says HubSpot reporting and nothing about SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `not_evidenced` | The resume says 6 years of B2B SaaS marketing, but not how many were spent on these channels. Recall prompt C1. | `[grounded]` "6 years B2B SaaS" |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years"; E2 gives it its own line. | `[grounded]` |
| R3 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year"; E1 only tidies the wording. | `[grounded]` |
| R4 | SQL-literate | must-have | `not_evidenced` | Named absence below. | `[grounded]` your own statement |
| R5 | Paid search | important | `already_evidenced` | E1 | `[grounded]` |
| R6 | Lifecycle email | important | `already_evidenced` | E3 gives it its own line. | `[grounded]` |
| R7 | Webinars | important | `already_evidenced` | The webinar line, unchanged. | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | Nothing in the resume covers it. Recall prompt C2. | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years of B2B SaaS marketing. It doesn't say how many were on paid, lifecycle email or webinars. | A years requirement is likely checked against the dates on the page. | Paid search or paid social before your current role; email or HubSpot work before the 4 years; running webinars before the monthly series | A dated role history with employers and years | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Content distribution | important | No content distribution appears anywhere. | It is one of the four channels the JD lists. | Promoting webinar recordings or follow-ups; sending blog, ebook or newsletter content by email or social; partner or syndication placements | A content calendar, a newsletter send report or a distribution tracker | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absence, R4 (SQL-literate).** You rely on your analyst for SQL, and the JD lists it as a requirement. Closing it would take a few weeks of writing, yourself, the queries you currently hand to your analyst, until you can show one you wrote. HubSpot reporting is adjacent work, but it is not SQL, and I won't word it as if it were. Whether this gap is worth applying despite is job-underwriter's question.

## Not written, and why

- **Hidden instruction to the screener and the 1pt keyword block** — refused, for the reasons above.
- **"SQL-literate", "data-driven", or any SQL claim** — you told me you aren't strong in it.
- **"Demand generation" as your function or title** — that is the JD's word. Your history is the channels you ran.
- **"Managed a budget over $500k"** — your words are "controlled" and "about $600k a year".
- **"Content distribution" or "Marketo"** — nothing in your material supports either.
- **"Owned" the function, team leadership, pipeline or revenue results** — you stated none of these. I haven't invented numbers.

## Parse-safety check

You pasted text, so I could not run any of these checks: multi-column layout, tables and text boxes, images or icons, content in headers or footers, section headings, and file type. I also could not look for hidden text inherited from a template or a previous tool.

## Upgrade menu

- **Your resume as a file (.docx or PDF):** This lets me run all six parse checks and look for hidden text you didn't author.
- **A HubSpot workflow list showing the 12 flows:** This would support the lifecycle line with something inspectable.
- **A webinar platform registration report:** This would support the 300-registrant average.
- **An ad-platform spend report or budget sheet:** This would show what the $600k covered.
- **Optional extra, not part of what you asked for:** A two-line summary built only from your existing sentences. It would give the 6 years and the channels a place at the top, since the resume has no summary. I'll draft it only if you say yes, and it would be a new row for you to approve.

## Questions

- **C1:** Of your 6 years, how many were spent running paid, lifecycle email or webinars?
- **C2:** Did you distribute content beyond webinars and paid, such as a newsletter, blog, ebooks or syndication? Give an example if so.
- **E1:** Was the $600k a year the paid search and paid social budget only, or all programme spend you controlled?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.