Running the company check and a salary sweep for the role, then I'll write the assessment.
**Short answer: yes, apply. You're a fit on the core of the role, and the main thing to check first is that the posting and employer are real.** Both of my web searches were refused, so nothing about Harborlight Health is checked outside the JD you pasted.

## Decision snapshot

**Yes, apply. R1, R2, R3, R4 and R6 (all `must_have`) land `direct`, and R5 (`must_have`) is the one open question. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · unclear: R5 (Define and maintain the metrics layer)
- `important` — adjacent: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 (`low`) is the row that could move the status, and R9 (`medium`) is a bridge with its limit named.

**Opportunity ledger.** The role is concretely described, with named stakeholders and a named tool (RR5). It is unverified as an employer (RR1), withholds pay (RR2), and may bundle several specialisms under one title (RR3). The mentoring duty comes with no stated title or authority (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify on Harborlight's own careers page (RR1); (2) the "metrics layer" turns out to be work you've actually done, or a scope you're happy to grow into (R5); (3) pay and level are acceptable once disclosed (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header, not externally confirmed |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | A senior individual-contributor role with light mentoring. The JD names no team size, reporting line or budget | `[inferred]` from the responsibility list against the JD's silence on authority |
| Market calibration | Not done: the role-family search was refused, so I offer no salary band | — |
| Unknowns | Pay, location and remote policy, level and title ladder, who the clinicians are, how the metrics layer is built | `[grounded]` absent from the pasted JD |
| Contradictions | None visible inside the JD. I could not compare it with the careers page | `[grounded]` JD only |

## Evidence map

Your background was typed in, so it counts as self-report. That caps every row at `medium` until you share something I can inspect.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber consumer company. Confirmed in prose, not documented | `[grounded]` your background | CV or LinkedIn dates would raise it to high |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a self-grade that an interviewer will test | `[grounded]` your background; `[generic]` that SQL depth gets probed live in analyst loops | A query sample or a sanitized model would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, 30+ tests a year, including the pricing test behind an 11% retention lift. Your sentence doesn't say who made the call to ship the winning variant, so I haven't assumed it | `[grounded]` your background | A sanitized test write-up would raise it |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the instance from scratch, with 40+ governed dashboards | `[grounded]` your background | A dashboard screenshot or catalog would raise it |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" suggests metric definitions, but you haven't said you owned a semantic layer such as LookML, a metric dictionary or dbt models. Low because the claim itself is missing | `[grounded]` your background is silent on a metrics layer | Question G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly exec metrics memo and present monthly to the VP Product | `[grounded]` your background | A redacted memo would raise it |
| R7a | Partner with product managers on roadmap decisions | important | adjacent | medium | discovery | The VP Product presentation and the pricing test are close. Day-to-day PM partnership isn't stated | `[grounded]` your background; `[inferred]` that monthly VP presentations are adjacent to PM partnership | Fold into G2's answer |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your background touches clinical or other domain-expert stakeholders | `[grounded]` background silent | Question G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` background silent | Question G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. That is real privacy-governance work, but no HIPAA, PHI or clinical data | `[grounded]` your background | Bridge case in G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards, but no stated ownership of definitions or a semantic layer | A must-have, and the JD lists it first among the responsibilities | Writing LookML measures others reuse; a metric dictionary or "single definition" project; retiring conflicting versions of retention or churn | A metric-definitions doc, a LookML excerpt, a data-dictionary screenshot | `[grounded]` background silence; `[inferred]` that resolving it firms up the status |
| G2 | Clinician and domain-expert partnership (R7b, important; R7a) | discovery | PM-side partnership is partly shown. Domain experts aren't mentioned | The JD names clinicians as a stakeholder group | Working with food-safety, nutrition or culinary teams on test design; any analysis a non-product specialist had to sign off on | A write-up or brief naming the specialist stakeholder | `[grounded]` background silence |
| G3 | Mentoring (R8, important) | discovery | No mention | It is a stated duty, and it also signals seniority | Onboarding an analyst; reviewing others' SQL or test designs; running office hours | A mentoring or onboarding note, a review checklist | `[grounded]` background silence |
| G4 | Healthcare data (R9, preferred) | transferability | Bridge: GDPR/CCPA PII handling and the consent-state model. Limit: no HIPAA, PHI, minimum-necessary or clinical-data work. Strengthener: a short note on how your consent model restricted who could see what | A "plus", so it is unlikely to decide the outcome | Access controls, de-identification, audit or consent-withdrawal flows you built | A sanitized data-model diagram | `[grounded]` your stated work; `[generic]` that the limit is where a healthcare interviewer will probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The search was refused, so the employer is unchecked rather than disproven. Postings can be stale or aggregated | `[generic]` pattern for unverified postings, not a claim about this company | Can you point me to this role on Harborlight's own careers site, and who would I interview with? | unresolved |
| RR2 | Compensation and level not stated | unknown | — | (the pasted JD has no pay or level) | The posting may be withholding pay, or the paste may have dropped it | `[grounded]` absent from the pasted text | What is the salary band and the level for this post? | unresolved |
| RR3 | Many specialisms in one role | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards… mentor two junior analysts" | The role may fold analytics engineering, experimentation, BI and people-leadership into one title | `[inferred]` from the length of the responsibility list | Which of these is the priority in the first six months, and what support does the role have for the metrics layer? | unresolved |
| RR4 | Mentoring with no stated authority | unknown | — | "mentor two junior analysts" | The seniors may carry the juniors' output without formal management | `[inferred]` from the JD's silence on reporting lines | Do the two juniors report to this role, and who sets their goals? | unresolved |
| RR5 | Concrete scope and named stakeholders | positive_signal | — | "partner with product managers and clinicians" | The mandate is specific and tied to decisions, not just reporting | `[grounded]` JD | Which roadmap decisions has analytics changed in the last year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Harborlight's own careers page before writing anything | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the experimentation program (30+ tests a year) and the pricing test with its 11% retention lift, with the number attached to retention exactly as you stated it | see R3 | `[grounded]` your background | pending your approval |
| A3 | Don't call your Looker work a "metrics layer" until G1 is answered | see R5 | `[grounded]` your background | pending your approval |
| A4 | Describe the consent-state model as adjacent privacy-governance work, never as HIPAA experience | see R9 | `[grounded]` your background | pending your approval |
| A5 | Ask RR2, RR3 and RR4 verbatim in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage is assumed to be "evaluating", since you gave none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app company careers" was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary range 2026" was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save all of this as a `tuesday-dossier.md` for later turns or other modules. Say the word and I'll emit it.

## Upgrade menu

- **Search permission:** allowing web search lets me check the employer and calibrate pay, which would clear or confirm RR1 and RR2.
- **Your CV or LinkedIn:** this would raise R1 and would let me check wording against what you've actually written.
- **A redacted metrics memo, a test write-up or a Looker catalog:** these would raise R6, R3 and R4 to `high`.
- **A metric-definitions doc or LookML excerpt:** this would resolve R5.
- **The hiring manager's name:** this would feed the role-reality scope read and which story you lead with.
- **Your constraints (pay floor, location, remote):** I can only check these against the role once you give them.

## Questions

G1 — Did you own the definitions behind your dashboards, such as LookML measures, a metric dictionary or a single agreed definition of retention or churn? What was yours, and what did the team own?
G3 — Have you onboarded, reviewed or coached other analysts? What did you do, for whom, and for how long?
Constraints — What are your non-negotiables on pay floor, location or remote, and hours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.