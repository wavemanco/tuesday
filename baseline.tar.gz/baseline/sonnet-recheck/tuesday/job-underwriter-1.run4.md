**Decision snapshot**

**Yes, apply. You are a fit on the main requirements, and the status is `conditional_go`.** R1, R2, R3, R4 and R5 are all `direct`. R9a (healthcare data experience) is `absent`, but the posting lists it as a plus, so it is `preferred` only.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (Define and maintain the metrics layer), R7a (Partner with product managers) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9b (HIPAA-style handling of sensitive data) · absent: R9a (Healthcare data experience)

R6 and R8 are the rows your answers below can move.

**Opportunity ledger.** The role is unchecked on three points. The employer could not be verified (RR1), pay is not stated (RR2), and no success measures are given (RR3). One entry points the other way: the responsibilities and tools are named concretely (RR4).

- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) pay and level are checked against your floor once you share it (RR2, C1); (3) your answers on R6 and R8 confirm the evidence, or they are carried as minor risks; (4) healthcare is framed as adjacent privacy work (R9b), never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up with about 400 people, Series C, care-navigation app | `[grounded]` JD header. Not cross-checked against any outside source (see Evidence status) |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A broad but ordinary senior remit that combines analytics engineering (metrics layer), experimentation, BI and people mentoring in one post | `[inferred]` from the JD's five responsibilities listed together |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not done. The role-family sweep did not run, so there is no pay or scope band | `[grounded]` research unavailable; upgrade menu |
| Unknowns | Pay; reporting line and who the hiring manager is; how clinicians are embedded in the product team; what success looks like in year one; user volume per test | — |
| Contradictions | None between your background and the JD. The posting was not compared with a careers page | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit subscription company, stated in your message. Confirmed and specific, but no inspectable artifact yet | `[grounded]` your stated background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a self-rating with no artifact behind it. Roles that ask for expert SQL commonly test it live | `[grounded]` your stated background; `[generic]` on live testing | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Limit: your tests ran on about 2M subscribers, and a care-navigation app may have far less traffic per test, so power and test duration differ | `[grounded]` your stated background; `[generic]` on smaller user bases in apps like this | A sanitized experiment readout or test-design doc would raise this to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your stated background | A sanitized screenshot or a LookML excerpt would raise this to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your stated background | A sanitized memo excerpt would raise this to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | "Governed dashboards" suggests metric definitions were controlled, but your background does not say you defined a metrics layer: shared measures, a metric dictionary or owner, or change control. Low, because the claim is my inference | `[inferred]` from "40+ governed dashboards" | G1 |
| R7a | Partner with product managers on roadmap decisions | important | adjacent | low | discovery | You present to the VP Product monthly and ran experiments. Working with PMs on roadmap choices is not stated | `[inferred]` from the experimentation program and the VP Product briefings | Ask at the next turn |
| R7b | Partner with clinicians | important | unclear | low | discovery | Nothing in your background mentions clinical or other domain-expert partners | `[grounded]` background silent | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Your background is silent on mentoring or managing people | `[grounded]` background silent | G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You have never worked in healthcare | `[grounded]` your statement | Carry as a minor risk, given preferred priority |
| R9b | HIPAA-style handling of sensitive data | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. Limit: that is consumer PII, not health data. You have not worked with minimum-necessary access, de-identification, or business-associate agreements | `[grounded]` your stated background | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards, but no stated ownership of metric definitions | It is the first-named responsibility in the JD, so a clear yes moves R6 to `direct` | LookML measures or explores others reused; a metrics dictionary or glossary; a definition-change process; retiring conflicting versions of one KPI | A metric glossary, a LookML excerpt, or a definition-change doc | `[grounded]` background silent on definitions; `[inferred]` that it would move R6 |
| G2 | Mentoring (R8, important) | discovery | No mention of mentoring or managing | The JD names two junior analysts to mentor | Onboarding analysts; reviewing others' SQL or dashboards; a buddy or intern role; coaching a PM on reading tests | A review checklist or an onboarding doc | `[grounded]` background silent |
| G3 | Clinician partnership (R7b, important) | discovery | Nothing about clinical or domain-expert partners | A care-navigation app is built with clinicians | Working with nutritionists, dietitians or food-safety staff on analysis or test design | A joint test brief or readout | `[grounded]` background silent |
| G4 | Health-data privacy (R9b, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling | It is the strongest honest bridge to the HIPAA plus. Limit: it is consumer PII, not health data | The consent model's access rules, deletion handling, who could see what | A data-handling or consent-model doc | `[inferred]` bridge from your stated privacy work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | Not checked because search was not permitted. The posting may be fine, but nothing outside the JD confirms the company or that the role is live | `[generic]` pattern for unchecked postings, not a claim about this company | Can you point me to this role on your careers site, and tell me who I would interview with? | unresolved |
| RR2 | Pay not stated | unknown | — | no figure appears | The posting may withhold pay, or it may be set outside your range | `[inferred]` from the JD's silence | What is the budgeted pay range for this post? | unresolved |
| RR3 | No stated success measures for a broad mandate | unknown | — | "Own product analytics for our care-navigation app" | The post may be judged on outcomes it never defines | `[inferred]` from the JD listing duties and no year-one outcomes | What would success in the first year look like, and who sets those measures? | unresolved |
| RR4 | Concrete, tool-named responsibilities and a stated team of two juniors | positive_signal | — | "define and maintain the metrics layer ... build self-serve dashboards in Looker ... mentor two junior analysts" | The scope is concrete enough to prepare for | `[grounded]` JD | Who owns the metrics layer today, and who set it up? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the pricing test behind the 11% retention lift and the Looker build with 40+ governed dashboards. Use your own wording, not the JD's | see R3, R4 | `[grounded]` your stated background | pending your approval |
| A2 | Describe healthcare experience as adjacent privacy work: GDPR/CCPA consumer PII and the consent-state model. Do not describe it as HIPAA or health-data experience | see R9a, R9b | `[grounded]` your stated background | pending your approval |
| A3 | Confirm the employer and the live posting before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A4 | In a screen, ask the questions from RR2, RR3 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent "Harborlight Health care navigation app careers Senior Product Analyst" and it was refused, so nothing was read. It would have settled RR1, which now stays unresolved and caps the status at `conditional_go` |
| 2. Role-family sweep | unavailable | I sent "senior product analyst digital health salary range 2026" and it was refused. It would have given a pay and scope band for the market calibration line and for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as a `tuesday-dossier.md` you can bring into later steps, if you want it.

## Upgrade menu

- Permission to search the web: I would run targets 1 and 2 (up to 5 searches and 2 fetches in all). That could clear RR1 and add a pay band against RR2.
- A link to the live posting on Harborlight's careers page, or the recruiter's email domain: RR1 can close without any search.
- A sanitized experiment readout, LookML excerpt or metrics memo: R3, R4 and R5 can move to `high`.
- A metric glossary or definition-change doc (G1): R6 may move to `direct`.
- The hiring manager's name: the plan can lead with the story that fits that reader.

## Questions

**G1** — Did you personally define or own how key metrics were calculated (shared measures in Looker, a glossary, or a change process), or did definitions sit with someone else? What did you own, and what changed because of it?

**G2** — Have you ever mentored, onboarded or reviewed the work of other analysts, formally or informally? Who, for how long, and what did you do?

**C1** — Do you have a pay floor, location or remote requirement, or any other must-have that this role has to meet?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.