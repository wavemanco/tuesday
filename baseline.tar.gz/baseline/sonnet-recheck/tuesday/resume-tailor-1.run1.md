I've read the tailoring playbook. Below is the edit ledger for the Tessellate role. Nothing is applied until you approve rows.

I built it from the CV text you pasted, not from your actual document. The "current line" and "traces to" quotes are your own sentences from your message, and the resume file may word them differently.

## Resume edits, pending your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years, at a payments company. Own three services in the ledger pipeline; one handles about 40k requests/minute at peak. Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged, moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Bullet 1: "On-call rotation every fourth week for two years". Bullet 2: "Ran six incidents as incident commander". | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year — pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E6 | Skills | "Go and Rust daily for 4 years, Python before that." | *(unchanged, placed above the tools line)* | `reorder` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV | pending your approval |

- **E4:** splitting the line stops it from saying all six incidents happened during the two on-call years. Your sentence doesn't say that.
- **E5:** the compression keeps "usually", because dropping it would make the number sound fixed.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts "7 years" next to the services you own. Your sentence says 7 years as a software engineer, so the ledger never writes "7 years backend". | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E6 leads with "Go and Rust daily for 4 years". Your CV doesn't say the three services are written in Go, so "production" is not written. See C1. | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | Your CV has a volume figure (E2) and Kafka and gRPC as listed tools. Nothing says how the services are distributed. See gap C1. | `[grounded]` |
| R4 | Drive down p99 latency | must-have | `surfaced_by_edit` | E1 and E3 | `[grounded]` |
| R5 | Strong incident response | must-have | `surfaced_by_edit` | E4 | `[grounded]` |
| R6 | Own on-call for your services | important | `surfaced_by_edit` | E4 gives the rotation. Your CV doesn't say the on-call covers your own services, so "own on-call" is not written. | `[grounded]` |
| R7 | Experience mentoring mid-level engineers | must-have | `surfaced_by_edit` | E5 gives the onboarding and pairing. Your CV doesn't give the hires' level. See the E5 question. | `[grounded]` |
| R8 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your CV touches it. See gap C2. | `[grounded]` |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A service at about 40k requests/minute at peak, and Kafka and gRPC in a tools list. It doesn't say which services use them or how the work is spread across them. | The posting lists this as a requirement, and a reader has only a tools list to go on. | Kafka producers or consumers in the ledger pipeline; gRPC calls between your three services; partitioning, retries or idempotency on the high-volume path | A design doc, an architecture diagram, or a Datadog dashboard for the 40k/min service | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | No product-facing work appears anywhere in your CV. | The posting lists it as a duty, and your CV gives a reader nothing on it. | Weighing a product request against reliability work; sequencing a quarter's work with a product manager; pushing back on a deadline with a technical reason | A planning doc or roadmap you contributed to | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |

## Parse-safety check

Your CV arrived as pasted text, so I couldn't run any of the checks: multi-column layout, tables and text boxes, images and icons, content in headers or footers, non-standard headings, and file type. Send the file and I'll run them.

## Not written, and why

- **"Distributed systems at scale":** this is the posting's phrase. Your CV has a request volume and two tools, and neither says the work is distributed.
- **"Production Go" or "Go services":** "daily" use of Go isn't tied to the three services. Tying them together would make a claim your CV doesn't make.
- **"Senior Backend Engineer" as your title:** it's the posting's title, and yours is Senior Software Engineer.
- **"Mentored mid-level engineers":** you onboard new hires and pair with them. Their level isn't stated, and "mentored" is a different verb.
- **"Owned on-call for my services":** you have a rotation. Ownership of the services it covers isn't stated.
- **"Designed and shipped" services:** your verb is "own". Design and shipping aren't stated.
- **Kafka, gRPC or Terraform attached to a specific service:** a tool in a list isn't a tool you owned on that service.
- **Build-cache or developer-tools experience:** your cache work is on a balance-read path, which is a different kind of cache.
- **Partnering with product:** nothing in your CV supports it, so no row touches it.

## Upgrade menu

- **Your actual CV file:** I'd quote your real wording, and the parse-safety check could run.
- **A Datadog dashboard or postmortem for the p99 work and the incidents:** these are the inspectable evidence for the 380ms to 95ms drop and the six incidents. They'd move those claims from "confirmed, limited proof" to well-supported.
- **A design doc for the 40k/min service:** it could turn R3 into a real row.
- **Prior CV versions:** an earlier version may hold product-facing or mentoring work that the current one dropped.

## Questions

- **C1:** Which language is the roughly 40k requests/minute service written in, and does it use Kafka or gRPC?
- **C2:** Have you ever helped decide what your team builds next, such as weighing a product request against reliability work? If so, what is one case?
- **E5:** What level were the new hires you onboarded?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.