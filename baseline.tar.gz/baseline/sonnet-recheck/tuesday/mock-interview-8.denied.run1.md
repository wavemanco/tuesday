Your prep pack is built and saved. I tried the project folder first and that write was declined, so the file is in the session scratchpad instead.

**File:** `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-denied-fff1b74f/c53755d5-6e8e-45d2-a324-00bc1c50c853/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`

**Dates:** your note puts the rounds on 21 October and the values copy on 12 October, but my clock says 5 November. I assumed all three rounds are still ahead. If any have happened, tell me which and I'll rebuild around the rest.

**What it holds:**
- **Format:** three mini-packs, one per round (30-minute recruiter screen, manager round, panel with the 20-minute case). Each has persona weights, 8 to 12 questions and its own reverse questions.
- **Fit table:** your background is graded against each JD requirement using your own words.
- **Values sheet:** a cheat sheet for the four values, plus a list of claims the pack won't coach.

**What to know first:**
1. **The contact-centre objection is your highest-ROI prep (D1).** You said you've never worked in one, and the JD makes it half of the first responsibility. The pack has you say that plainly, then give a plan to learn it, and not stretch your branch complaints log to cover it.
2. **You need four real stories for the values round.** Nothing you told me carries a full story for any of the four values, so those answers are prompts to pick your own stories, not scripts.
3. **The panel's hub question is a likely tension.** The panel is two branch managers, and the strategy consolidates eight branches into five hubs, while "Neighbours, Not Numbers" says every branch is part of its town. H4 and G3 prepare you to raise it neutrally. That the managers are personally affected is my inference, not something I know.
4. **Several answers are open slots.** For digital work, regulated complaints, what your spreadsheet counted, and whether it was Excel, I wrote slots for you to fill from what you did, not made-up details. Any of these may have a good answer, but I can't supply it.

**Research:** I ran no searches, because your pasted values, the recruiter's email, your summary of the strategy brief and the JD already settled every output. I have only your four points from the brief, not the brief itself.

**Upgrade menu** (also at the end of the file):
- Interviewer names once assigned.
- Your CV as written.
- Your answers to the open slots.
- Four real stories for the four values.
- The full strategy brief.
- The recruiter's answer on the case format.
- A deeper research pass of up to 6 more searches and 2 more fetches, which I'll only run if you say so.

Say the word and I'll play the Skeptic on D1, the contact-centre question, as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 21 October (recruiter 30 min; Head of Member Services, your future manager, 45 min, mostly behavioural; panel of two branch managers 60 min, including a 20-minute complaint-escalation case, and the values round). Interviewer names are not assigned yet, so only their roles are used.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether what you say about your experience survives follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the credit union's altitude (strategy, competition) |
| CASE | Structure and reasoning on a live problem |

An answer slot is an instruction for the interview, not a question for me. Where one says "if you did this, say how", the honest second branch (it was not mine, or it never happened) is always a full answer.

The highest-ROI prep in this pack is **D1** (the contact-centre objection), rehearsed in light form at B1 and under pressure at J1. The second is choosing four real stories for the four values (round 3, G1 to G4), because no sentence in your material carries a full story for any of them.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD, the branches half | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, and the words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on where your part started and stopped likely. If you followed any complaint past the log, say how far and what you did, in your own words; if the log was where your part ended, or it was not yours to follow, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD, the contact-centre half | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly complaints spreadsheet you built that your regional manager uses; it does not show what it counted. Answer slot: the JD names volumes and resolution times. If the spreadsheet counted either, say how each was counted, in your own words; if it counted something else, or you do not know how part of it was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Tellers are not supervisors, and training on a script is not the JD's coaching; the words stay at "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether you have guided anyone more senior than tellers likely. If you have, say who and how, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital work. Answer slot: the JD names self-service journeys. If you have worked with a digital or online-banking team, say on what and what your part was, in your own words; if not, say so plainly and say how you would work with one |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | The years clear the number on their face; the open point is whether branch work reads as the JD's "customer operations". Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor. Do not define "customer operations" on their behalf |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal, not regulated, and the words stay at "formal complaints log". Answer slot: the JD says regulated. If the log was kept to a regulator's rules or your employer's rules, say which and what they required, in your own words; if it was an internal log only, or you do not know what governed it, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare your first one, said as a plan and never as a past. The quote does not say what you presented at regional level, so nothing is written about it here |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: say which tool it was and what it did, in your own words; if it was not Excel, or part of it was not yours, say so plainly and stay with the spreadsheet you built |

Requirement coverage (stated JD requirement to question IDs; every requirement has at least one JD-typed question):

| Requirement | Questions |
|---|---|
| Complaints process end to end, branches | A3, D2, H1 |
| Complaints process end to end, contact centre | B1, D1, J1 |
| Monthly reporting on volumes and resolution times | F1, F2, E2, H3 |
| Coach branch supervisors on escalations | C2, D3, I1 |
| Work with digital teams on self-service journeys | E3, C3 |
| 4+ years financial-services customer operations | B4, A1 |
| Regulated complaints | A3, H2 |
| Presenting to senior leaders | B2, F2, J2 |
| Excel reporting | A4, F1 |

## Grounding brief

From your summary of the June 2026 strategy brief the recruiter sent (I have your four points, not the brief itself) and the JD's own description of the employer.

| Item | Provenance | Where it surfaces in this loop |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | [inferred] from the JD's self-service line: E1, E3 |
| Consolidate eight branches into five hubs over 2027 | [grounded] | [inferred] from the panel being branch managers (recruiter's email): H4, G3, round 3 reverse questions |
| Launch a small-business lending product in Q1 2027 | [grounded] | [inferred] as background only; no question depends on it |
| Main competitive pressure is app-only banks | [grounded] | [inferred] from the 40% digital target and the Plain Words value: E1, E3 |
| Member-owned, about 900 staff | [grounded] | JD opening line; A2 |

---

## Round 1: Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; biography, motivation, tool comfort | high: recruiter-screen prior is Conversational plus a light Skeptic, and a recruiter's questions are scored even when casual | A pre-scripted 90-second arc for the biography; treat casual questions on JD topics as scored |
| Skeptic | Quiet knockout checks on the visible gaps | medium: the recruiter has read your background against the JD and will check the two stated gaps lightly | Rehearse the plain acknowledgment until it is boring; no cushioning |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey: how did you get from retail banking to where you are now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F6: six years in retail banking, the last three as a branch supervisor are the beats the quote states; tell them in your own words and keep to them. Answer slot: your reason for moving toward a lead role is not in your material, so none is written here; say it in your own words, or if there was no single reason, say so plainly | Recruiter screens open on the biography; F6 is the evidence for the experience requirement. EXP because it checks the story hangs together; Conversational in delivery |
| A2 | "What drew you to Ashgrove, and to a member-owned credit union?" | CO | [grounded] | Pick one of the four published values, named exactly as Ashgrove words it, and say in your own words why it matters to you. Pick only one that is true for you: the panel scores all four in round three and will notice if every answer claims all of them. Your material has no credit-union sentence to quote, so make no claim about credit-union experience | Motivation consistency is the recruiter's main scored item; CO because it tests homework on the employer. The values and the "member-owned" line are the raising sources |
| A3 | "Tell me about your experience handling complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1 and F7: the branch's formal complaints log, which you handled, is the beat the quote states; tell it in those terms. Answer slot: the JD says regulated and the quote says formal. If the log was kept to a regulator's rules or your employer's rules, say which, in your own words; if it was an internal log only, or you do not know what governed it, say so plainly and stay with the log you handled | F1 and F7 are the first rows a recruiter checks against the screen. JD because it scores the headline requirement; Conversational delivery |
| A4 | "How comfortable are you with Excel for reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F9: you built the monthly complaints spreadsheet and your regional manager uses it, which are the beats the quote states. Answer slot: the JD says Excel and the quote says spreadsheet. Say which tool it was and what it did, in your own words; if it was not Excel, or part of it was not yours, say so plainly and stay with the spreadsheet you built | F9 is a stated requirement a recruiter can tick or not in one answer; JD because it scores the Excel line |
| B1 | "I don't see a contact centre in your background. How would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre" | The light version of D1 (the full rehearsal is there). Say it plainly first: "I haven't worked in a contact centre." Then the plan, not a past: before changing anything, listen to how complaints reach the contact centre and ask the people who handle them what works and what does not. Stop there; do not stretch the branch log into contact-centre experience | F2 is the stated gap and the recruiter already knows it. JD because the contact centre is half of the first responsibility; Skeptic in delivery |
| B2 | "This role presents to senior leaders. Have you presented at that level before?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment, sourced to your own words: "I haven't presented to anyone above regional level." Then how you would prepare your first one: decide what you would lead with, and who you would ask to review it before you present. Answer slot: if you have presented at regional level or below, say to whom and on what, in your own words; if not, say so plainly | F8 is the second stated gap. JD because the requirement is explicit; Skeptic in delivery |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre", "I've never presented to anyone above regional level" | Choose one of the two limits you have already stated, name it plainly in your own words, and say what you would do first about it. Do not read both as a list and do not offer a third; a disguised strength scores worse than a plain limit | Persona stem for the Skeptic. F2 and F8 are the stated limits; a rehearsed single answer is steadier than a shopping list |
| B4 | "We're asking for four years in financial-services customer operations. Does your branch work count as that, in your view?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F6: say the quote's terms and do not define "customer operations" for them. Answer slot: if there are parts of that time you would call customer operations, say which, in your own words; if you would not call it that, say so plainly and stay with the years | F6 clears the number on its face; the open point is whether branch work reads as the JD's phrase, so the recruiter checks it here. JD because it scores a stated requirement |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Will I meet the same two branch managers for the whole panel, and can I know their names beforehand?" | Names are not yet assigned; asking now gets you the interviewer read later |
| "For the 20-minute case on a complaint escalation, is it unseen, or is there anything I should prepare or bring?" | Settles whether there is a deliverable to build, which changes the pack |
| "How does the panel score the four values: is there a framework or an example of a strong answer?" | Recruiters can often answer in one email; signals you are taking the values round seriously |

---

## Round 2: Head of Member Services (your future manager), 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" prompts mapped to the published values | high: the recruiter's email calls the round mostly behavioural, which lifts it over the hiring-manager prior | A real story per prompt; "we" for context, "I" for your part; hard truths that actually landed |
| Skeptic | Persistent probing of the contact centre, the end-to-end scope and the coaching gap | medium: a hiring manager is derisking gaps, and F1, F2, F4 are the visible ones | Plain acknowledgment, then plan; hold the plan through follow-ups |
| Case/Strategist | Live problems from the role: strategy, a metric, a digital journey | medium: hiring-manager prior; the strategy brief gives them material | Clarify, objective, segment, approach, metrics, risks, aloud |
| Data-Driven Prober | How the monthly numbers were counted | low: you have one reporting artefact in your material | Say what the spreadsheet counted and what you do not know |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, since no sentence in your material carries this story: pick a time with a named stake where you said the hard thing to someone senior and the relationship was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for Values/Behavioral in a mostly behavioural round; VAL because Plain Words and Own the Fix both turn on saying hard things |
| C2 | "Tell me about a time you guided someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: training new tellers on the escalation script is the beat the quote states; tell it in those terms. Answer slot: the JD says coaching supervisors. If you guided anyone more senior than tellers through an escalation, say who and how, in your own words; if not, say so plainly and stay with the tellers | F4 is the JD's coaching line; the JD is the raising source. JD because it scores that requirement through a behavioural prompt |
| C3 | "Tell me about a time you worked with another team to fix something for members." | VAL | [generic] | Selection scaffold: pick a time with a named other team, a named member problem, your part and theirs said separately, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work with a digital team | F5 has nothing in your material to quote, so this is a scaffold. VAL because it scores Members First through cross-team work; the JD's digital line raises the theme |
| C4 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Selection scaffold: pick a time with a named member, a metric that pointed the other way, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Persona stem; the theme is Members First, "we decide from the member's side of the counter" |
| D1 | "You've never worked in a contact centre, and this role owns complaints across it. Why should I be comfortable with that?" | JD | [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Move one, concede first and plainly: "I haven't worked in a contact centre." Move two, the plan, said as a plan and never as a past: listen to how complaints reach the contact centre before changing anything, and ask the people who handle them what the branches get wrong and right. Move three, hold: expect three follow-ups, namely what you would do in your first thirty days, how you earn the trust of colleagues who know you have not done their job, and whether you would want someone else to lead that part. Answer each from the plan; the hold is that you can learn it, never that you already know it. Do not stretch the branch log into contact-centre work | F2 is the stated gap in the role's widest requirement (F1). The Skeptic is a manager's natural persona, and this objection will be asked in some form |
| D2 | "In the complaints you handled, where did your part start and where did it stop?" | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: the branch's formal complaints log, which you handled, is the beat the quote states. Answer slot: if you followed any complaint past the log, say how far and what you did, in your own words; if the log was where your part ended, or you do not know what happened after, say so plainly and stay with the log | F1 and the end-to-end requirement; EXP because it tests the honest edge of your ownership, which Own the Fix also probes |
| D3 | "You trained new tellers on an escalation script. This role coaches supervisors. How would you adjust?" | JD | [grounded] "trained new tellers on our escalation script", "6 years in retail banking, the last 3 as a branch supervisor" | Say what the quotes say: "I trained new tellers on our escalation script", and you spent the last three years as a branch supervisor, so you know the supervisor's side of the counter. Then the plan: ask supervisors what they get stuck on before teaching anything. The answer slot is the one at C2 | F4 is the adjacent-evidence row; the question asks for the bridge and its limit. JD because it scores the coaching line |
| E1 | "We plan to consolidate eight branches into five hubs over 2027 and move 40% of member service to digital channels by 2028. If you owned complaints through that, what would you want to know first?" | CO | [grounded] your summary of the June 2026 strategy brief | No claim about your past. Clarify first: where complaints come in today, by channel and type. Objective: a member should not have to explain themselves twice, in Ashgrove's own Plain Words terms. Segment by channel and by branches affected by the hubs; metrics are the JD's volumes and resolution times; risk is members whose branch changes. Challenge one premise respectfully, such as whether the 40% is existing contacts moving or new ones | The strongest differentiator question most candidates cannot touch. CO because it needs the brief; CASE in delivery |
| E2 | "Monthly complaint volumes are flat, but average resolution times are up by a fifth. Diagnose it." | CASE | [generic] | No claim about your past. Clarify what changed: complaint mix, channel, stage, and when the clock starts and stops. Hypotheses by stage and channel, then the data you would pull first and what each would tell you | Live problem on the JD's own two measures (F3). The figures are hypothetical |
| E3 | "A member can't find how to complain in the app, so they ring their branch. What would you change in the journey, and who would you involve?" | JD | [generic] | No claim about your past. Structure: what the member is trying to do, where they get stuck, which teams you would involve (digital, contact centre, branches), how you would know it improved. Separately, expect a probe on digital experience: the answer slot is the one in F5 | F5 has no evidence in your material, and the 40% target makes this probable. JD because it scores the digital line; CASE in delivery |
| F1 | "Tell me about the monthly complaints spreadsheet you built. What did it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built it and your regional manager uses it, which are the beats the quote states. Answer slot: the JD names volumes and resolution times. If the spreadsheet counted either, say how it was counted, what it was sensitive to, and which assumption behind it you would defend least; if it counted something else, or you do not know how part of it was counted, say so plainly and stay with what you built | F3 and F9; a prober's first question is how the number was counted. EXP because it tests attribution |
| F2 | "Walk me through how you'd report to our senior leaders each month." | JD | [grounded] "I've never presented to anyone above regional level" | No past is claimed in the structure: lead with what changed since last month, then the one thing you want them to decide, then the supporting numbers. If asked about your own experience at that level, the plain acknowledgment is "I haven't presented to anyone above regional level", followed by how you would prepare | F8 and F3 together; JD because it scores the reporting and presenting lines |

### Reverse questions

| Question | Why it lands |
|---|---|
| "When a complaint moves from a branch to the contact centre, who holds it today, and what happens if it stalls?" | Own the Fix made concrete; shows you read the value as a design question |
| "Who reads the monthly complaints report today, and what decisions has it driven?" | Shows you think of reporting as decisions rather than a document |
| "What would you want me to have learned about the contact centre by day ninety?" | Turns your biggest gap into a shared plan with your future manager |
| "How does the digital team's work on the 40% target connect to complaints?" | Shows you read the brief and think across the self-service line |

---

## Round 3: Panel of two branch managers, 60 minutes (includes the 20-minute case; values round)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored against the four published values | high: the recruiter's email says the panel scores against the four values | One real story per value; the story must show the value, not recite it |
| Case/Strategist | The 20-minute escalation case, plus a strategy question | high: 20 of the 60 minutes is the case | Clarify aloud before structuring; think aloud |
| Peer Evaluator | The seam between branch managers and your coaching of their supervisors | medium: [inferred] from the panel being branch managers and the JD's coaching line | Reciprocity: what you offer them, and principles for the seam rather than pretending to know it |
| Pressure | Time-boxed challenge on the same gaps | low: a values panel is less adversarial than a manager round | Hold, then concede specifically |
| Conversational | Warm-up opener | low: not banked; reuse the A1 and A2 arc, shortened to a minute | Same arc as round 1 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell us about a complaint where you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold, since no quoted sentence carries this story: pick a complaint with a named member, a decision where the easy answer favoured the institution, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Members First, Always; the value text is the raising source |
| G2 | "Tell us about a time something had to be explained to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a moment with a named member or colleague, what was unclear, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is "I trained new tellers on our escalation script", or how you would handle it | Plain Words; the value says that if a member needs it explained twice, Ashgrove wrote it wrong |
| G3 | "Tell us about a decision you made with your branch's town in mind." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a decision with a named stake for the town or its members and say what you weighed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the last three years as a branch supervisor, or how you would approach it. Expect a follow-up linking this to the move from eight branches to five hubs; see H4 | Neighbours, Not Numbers; the panel are branch managers |
| G4 | "Tell us about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a problem you found yourself, say what keeping hold of it meant concretely, and how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the branch's formal complaints log you handled, or how you would do it. Note the tension: escalating hands a problem on, and this value says the finder keeps hold | Own the Fix; the JD's escalation coaching sits right beside it |
| H1 | "A member complained at a branch and was promised a callback. They have now rung the contact centre twice with no answer. The branch says it's the contact centre's problem and the contact centre says it's the branch's. What do you do?" | CASE | [generic] | No claim about your past. Clarify first: what was promised, by whom, when, and what the record shows. Objective: the member hears from one named person today. Then who holds the complaint, the root cause, the metric (time to first reply, resolution time), and the risk of the two teams blaming each other. Tie it to Own the Fix: the one who finds it keeps hold. Think aloud throughout | The 20-minute case, as the recruiter describes it (a complaint escalation). The scenario is a pattern, not a fact about Ashgrove |
| H2 | "Suppose it's a formal complaint with a response deadline. What would you need to know about the deadline, and who would you tell?" | JD | [grounded] "I handled the branch's formal complaints log" | No claim is made about Ashgrove's actual rules. Answer slot: the JD says regulated complaints. If the log you handled ran to a deadline or rules, say which and how you tracked it, in your own words; if it did not, or you do not know, say so plainly and stay with the log you handled | F7; JD because it scores the regulated-complaints line; CASE in delivery |
| H3 | "How would you know your fix is working? What would you track each month?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name the JD's two measures, volumes and resolution times, as what you would track and why each matters to the member. Your own spreadsheet is the quote at its own scope; the answer slot is the one at F1 in round 2 (what it counted) | F3; extends the case into reporting |
| H4 | "How should complaints handling change as eight branches become five hubs?" | CO | [grounded] your summary of the June 2026 strategy brief | No claim about your past. Do not criticise the plan, and do not defend it either: you are in a room of branch managers. Say what you would want to know (which towns, which complaint types, who holds a complaint when a branch changes), and name the principle: a member should not have to start again because the building changed. Reconcile with Neighbours, Not Numbers by treating each town as part of the picture, not a line in the numbers | [inferred] the panel's own branches may be affected; the question tests altitude and tact together |
| I1 | "You'd coach our supervisors on escalations. Where's the seam between your job and ours, and what happens when we disagree?" | JD | [inferred] panel are branch managers (recruiter's email) and the JD's coaching line; "6 years in retail banking, the last 3 as a branch supervisor" | Offer principles for the seam, not facts about it: agree in advance who decides what; when you disagree on one complaint, the member's outcome comes first and you settle the principle afterward. Reciprocity: what you bring them is the supervisor's side of the counter, as the quote says, three years as a branch supervisor. Do not claim to know their structure | Persona stem for the Peer Evaluator; F4 is the bridge and the quote supplies only the supervisor side |
| I2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time with named teams, say plainly what each did and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would share credit | Persona stem; Peer Evaluators probe credit-sharing |
| J1 | "Sixty seconds: why you, rather than someone who already works in our contact centre?" | JD | [grounded] "Never worked in a contact centre", "I handled the branch's formal complaints log", "6 years in retail banking, the last 3 as a branch supervisor" | Hold then concede. Hold: say what you bring in the quotes' own terms, six years in retail banking, the last three as a branch supervisor, and the branch's formal complaints log you handled. Concede, specifically: "I haven't worked in a contact centre." Do not claim to be better and do not disparage anyone. Return to the same terms through two follow-ups | Pressure persona stem; F2 and the D1 plan, compressed |
| J2 | "How do we know you'll hold your own in front of our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold then concede. Concede first: "I haven't presented to anyone above regional level." Then the plan, said as a plan: decide what you lead with, ask someone to review it first, and bring the one decision you need. Answer slot: if you have presented at regional level or below, say to whom and on what, in your own words; if not, say so plainly | F8; Pressure delivery of the same gap B2 raised lightly |

### Values and principles cheat sheet

No sentence in your material carries a full story for any of the four values. Each row below is a selection scaffold, not a mapped story: you need four real stories, picked from your own experience.

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold at G1. Nearest thing in your material: F1, "I handled the branch's formal complaints log". If no real story comes to mind, say so plainly, then give the nearest thing or how you would decide |
| Plain Words | If a member needs it explained twice, Ashgrove wrote it wrong | Scaffold at G2. Nearest thing: F4, "trained new tellers on our escalation script". If no real story comes to mind, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold at G3. Nearest thing: F6, "6 years in retail banking, the last 3 as a branch supervisor". Pair it with the hubs question at H4 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold at G4. Nearest thing: F1, "I handled the branch's formal complaints log". Reconcile with escalation at G4's note |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity with branch managers; converts the panel into peers |
| "Where does the handover between your branch and the contact centre work best, and where is it hardest?" | Shows you will ask before changing anything, the D1 plan in practice |
| "How do you expect the move to five hubs to affect escalations in your branch?" | Shows you read the brief and care about their side; asked neutrally |
| "Which of the four values is hardest to live by on a busy day, and what does that look like?" | Invites a real story and shows you treat the values as practice, not slogans |

---

## Prohibited claims

Built from the fit snapshot before the banks. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process across branches. D2's slot stays inside the log |
| Worked in or with a contact centre | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders, or at Ashgrove's level | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." The slot at B2 asks only what you presented at regional level or below |
| Coached or managed supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says new tellers, not supervisors |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material shows a monthly spreadsheet, not what it counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says formal, not regulated |
| Excel reporting skill | Inflated form of F9 | F9's quote at its own scope. The limit is the pack's observation: your material says spreadsheet, not Excel |

## Sources

Provided documents: the JD (your message); the four values, as you copied them on 12 October 2026 from ashgrovecu.org/about/values (your note; I did not fetch the page); the recruiter's email on the three rounds; your summary of the June 2026 strategy brief; your background (your message). No tuesday-dossier.md was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The four pasted values fix the values cheat sheet and every VAL question; a fetch could change nothing |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the rounds, their lengths, the panel, the case and the values scoring, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | Your summary of the June 2026 brief fixes the CO questions and the grounding brief; the brief's full text would add depth, not change a row |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No names exist yet, so there was no query to form; the interviewer read is absent and the upgrade menu says what names unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-typed questions |

## Upgrade menu

- Interviewers' names, when assigned → an interviewer read for each round, persona weights tuned to their public footprint, and a reverse question tied to each person's path
- Your CV as written → the fit snapshot would quote it directly and could regrade F1, F3, F4, F7 and F9 if it says more than your message did
- Your answers to the answer slots at F1, F3, F4, F5, F7 and F9 → each moves from an open slot to a grounded story the banks can map
- Four real stories for the four values, chosen by you → G1 to G4 become mapped stories instead of scaffolds
- The full June 2026 strategy brief → a fuller grounding brief and sharper CO questions at E1 and H4
- The recruiter's answer on the 20-minute case (unseen or prepared) → a build section if there is a deliverable
- A tuesday-dossier.md from an earlier job-underwriter run → verified evidence and a named top objection, though this pack stands without one
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisational context, offered once and not run unless you say so
