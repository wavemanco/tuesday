Writing the file was also refused, so I haven't saved anything to disk. Here is the full pack inline instead.

# Interview prep pack: Product Operations Manager, Stripe

**Round:** Final round. The number of sessions and who runs each are unknown, so personas are blended.
**Built from:** your message only. There was no CV, JD or recruiter guidance, and all four searches were refused. Everything below is a rehearsal structure, and nothing in it says anything about your past.

## How to use this pack

- **Personas are how a question is asked, and types are what it is scoring.**
- **Guidance is scaffolding, not a script.** Where a question asks about your past, the guidance tells you how to choose a story from your own experience. It never supplies one.
- **Type key:**
  - VAL: behavioral and values alignment.
  - EXP: work-experience deep-dive.
  - JD: role-driven.
  - CO: company and strategy knowledge.
  - CASE: a live problem.
- **Highest-ROI prep: B1.** With no CV or JD, the pack can't name your most predictable objection from evidence. B1 is the nearest question every Skeptic asks, so it gets the deepest rehearsal for now.

## Fit snapshot

No background was provided, so this is the worksheet variant. The requirements are role-family patterns in plain prose, because no JD was supplied and the posting search was refused.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate cross-functional product launches (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a named launch, the teams that depended on each other, and which part was yours. Selection scaffold: pick a launch with a named stake and a part you can say was yours; if no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Design and run the processes product teams work through (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, who used it, and what you saw change. Selection scaffold: pick one where you can say what existed before, what you did, and what happened next; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Track product health with data and surface what it shows (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a metric you used to decide something, how it was counted, and the assumption you trust least. Selection scaffold: pick one decision a metric informed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Align senior stakeholders across functions (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement between functions, your position in it, and how it ended. Selection scaffold: pick one with a named stake and an intact relationship afterward; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritise under ambiguity and limited capacity (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a choice between competing asks, your criteria, and what you declined. Selection scaffold: pick one where you can state the criteria; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Maintain the documentation and tooling product work runs on (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a named tool or document set and what it was used for. Selection scaffold: pick one you can describe end to end; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No source establishes this company's loop, so the pack uses the generic archetype (screen, hiring manager, panel) with roughly flat weights. The ordering below is a judgment from relationship priors, not a documented Stripe loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role | Moderate to high: a hiring manager in a final round buys capability on their own problems | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic | Probes gaps and "why this, why now" | Moderate to high: a final round prices gaps, and with no CV the pack can't say which | Rehearse the likeliest objection until it is boring; bridges only from things you actually did; a concrete ramp plan |
| Values / Behavioral | Scenario probes, often from outside the function | Moderate: product ops works across functions. No loop source shows a values round, so none is assumed | Pick stories where the hard truth landed; "we" for context, "I" for contribution |
| Data-Driven Prober | How a number was counted | Moderate: operations roles report metrics | Know how each number was counted and say plainly when you don't |
| Peer Evaluator | Seams with adjacent teams | Moderate: plausible if a session is with a product peer | Reciprocity; propose seam principles |
| Conversational | Friendly openers | Moderate: openers are likely, and casual questions are still scored | A 90-second arc |
| Pressure | Interrupts, time-boxes | Lower: nothing you told me indicates it | Pause, restate, hold through two follow-ups |

## Question banks

Every row is [generic]. There is no CV, JD or research, so no row rests on a candidate sentence or a company fact.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A cross-functional launch is two weeks out and three teams each say they are not ready. What do you need to know first, and what do you do in the first two days?" | CASE | [generic] | Say your structure aloud. Clarify what ready means for each team and whether the date can move. Then objective, who is blocked on what, the actions that unblock most, how you tell leadership, and what you watch. Challenge one premise | Tests F1 and F4 live |
| A2 | "Adoption of a newly shipped feature is 20 percent below plan a month after launch. Diagnose it." | CASE | [generic] | Clarify what plan means and how adoption is counted. Segment who was meant to adopt and where they drop off. Give two or three hypotheses with the data that would test each, then what you do first. Name the assumption in the plan you'd trust least | Tests F3; the standard diagnose-it case |
| A3 | "Product teams tell you the planning review is a waste of time. How do you decide whether to fix it, shrink it, or end it?" | CASE | [generic] | Clarify what the review is for and whose problem it is. Lay out the three options, what each costs, and what evidence favors each. Say how you'd test the choice. Hold your recommendation and concede what you can't yet know | Tests F2: process as a means |
| A4 | "You have one quarter and no extra headcount to improve how product teams ship. How do you choose what to work on?" | CASE | [generic] | State criteria first: impact, reach, effort, reversibility. Say who you'd ask. Pair one early visible win with one structural piece, and say what you'd decline | Tests F5; scored on criteria, not the pick |
| A5 | "What do you want to learn in your first 30 days, and from whom?" | CO | [generic] | Name groups (product, engineering, dependent teams) and what you'd ask each, plus what you'd read first and what would change your plan. Don't offer company facts you haven't checked yourself | Generic because no research ran |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The deepest rehearsal. Pick one real area, say it before being pressed, say how you'd close it in the first weeks, and who you'd ask. A weakness you can't defend through a second follow-up is worse than a modest true one. If no such area comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Asked of every candidate; stands in for the sharper objection a CV would reveal |
| B2 | "Why this role, why this company, and why now?" | JD | [generic] | Three beats in your own words: what draws you to this work, what about this company, why the timing. Say only what you've verified about the company; this pack has nothing. If the honest answer is mixed, say so | Motivation consistency; the company beat is where unresearched answers sound generic |
| B3 | "Product operations sits between product, engineering and go-to-market. What keeps this role from being just a coordinator?" | JD | [generic] | Take a position on where the role adds judgment, concede that part is coordination, hold through a second challenge, then concede one specific thing | Tests F2 and F4 |
| B4 | "A team that outranks you is asked to follow a process you own, and they refuse. What do you do?" | CASE | [generic] | Clarify why before responding: wrong process, poor explanation, or inconvenience. Sequence: ask, adjust if they're right, escalate only with evidence, protect the relationship. Say what you wouldn't do | Tests F4 and F2; a hypothetical, so no past is presupposed |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you didn't soften it, and an intact relationship after. Say what you said and what followed, in your own words. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; F4 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where the two really pulled apart, and say whether the customer was internal or external. Name the metric you gave up. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; tests naming the tradeoff |
| C3 | "A team asks you to report a launch as green when you believe it is amber. What do you do?" | VAL | [generic] | Say what you'd check first, what you'd tell the team, how you'd report if they still disagree, and what you wouldn't do | Hypothetical integrity probe on F1 and F4 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a metric you have relied on to make a decision. How was it counted, and which assumption behind it would you defend least?" | EXP | [generic] | Pick a metric you can explain end to end. Say how it was counted, what it's sensitive to, and the assumption you trust least, before the interviewer finds it. Say plainly if you don't know part of it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; F3 |
| D2 | "What would you measure to know whether a product operations function is working?" | CASE | [generic] | Separate outcome from activity measures, say what each misses and how each could be gamed, name your weakest assumption, and pick the one or two you'd start with | F3 from the design side |
| D3 | "Two sources disagree on launch adoption. How do you decide which to trust?" | CASE | [generic] | Clarify how each is collected. Check definitions, windows and population. Say what you'd reconcile first, what you'd tell stakeholders meanwhile, and concede what may stay unresolved | Tests F3 and F5 on method |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between product operations and product, and what happens when we disagree?" | JD | [generic] | Propose seam principles (who owns the decision, who owns the mechanism, how disagreements surface) rather than claiming to know the seam. Say what you do when the call is theirs. Say what you bring their team | Persona stem; F2 and F4 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick one piece of cross-team work where credit was a live question; "we" for context, "I" for your part, in your own words. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem |
| E3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Answer both halves: your needs (access, context, a standing conversation) and one small concrete way to lighten their load. Don't promise specifics you can't yet know | Reciprocity; the second half is where candidates stall |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, the thread connecting your moves, why this role is next. Say the thread early. The content is yours to supply | The likeliest opener |
| F2 | "What are you actually playing with these days in how teams plan and ship product?" | CO | [generic] | Pick something you've really used or read and say what you took from it, including what you doubt. If nothing comes to mind, say so and name what you'd look at first | Casual form of a scored question; generic because no JD supplied a plus-skill |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then three sentences built only from your own material once you share it. Hold through two follow-ups, then concede one specific true limit. Don't run anyone down | Persona stem; hold-then-concede |
| G2 | "You've given me a lot of process. Why would a product team ever want you in the room?" | CASE | [generic] | Hold a position on your value in terms of the team's problem. Concede process can be a cost and say when you'd remove it. Hold through two follow-ups, then concede one real thing | Pressure on F2 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Launch coordination | A1, A2, C3 |
| F2 Process design | A3, A4, B3, B4, E1 |
| F3 Metrics and data | A2, D1, D2, D3 |
| F4 Senior stakeholder alignment | A1, B3, B4, C1, C3, E1 |
| F5 Prioritisation | A4, A5, B1, D3 |
| F6 Documentation and tooling | none, and why: with no JD naming a tool, a question would be invented |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like in this role, and how would you tell?" | Shows you think in outcomes |
| R2 | "Where does product operations get pulled in too late, and where too early?" | Surfaces the real friction |
| R3 | "How do product teams here decide whether a process is worth keeping?" | Shows process is a means, answering B3 early |
| R4 | "Which teams does this role depend on but not manage, and how does that work?" | Shows you understand influence without authority |
| R5 | "What is one thing about how this function works today that you would change?" | Invites candor |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer session |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entry | No CV, dossier or stated negative, so there is no sentence to inflate | Every clause about your past is a scaffold or answer slot until you share material |

## Sources

Provided documents: your message only. Searches sent, all refused with no results:

- "Stripe operating principles values": refused
- "Stripe interview process product operations manager": refused
- "Stripe strategy news 2026": refused
- "Stripe Product Operations Manager job posting responsibilities qualifications": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Search refused. Would have supplied official value names for a cheat sheet if a values round were detected |
| 2. Interview process | unavailable | Search refused. Would have set persona weights from documented rounds; the generic archetype is used |
| 3. Strategy and news | unavailable | Search refused. Would have grounded a CO question; A5 and F2 are generic |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative posting | unavailable | Search refused. Would have replaced the plain-prose requirements with quoted, inferred ones |

## Upgrade menu

- Your CV: snapshot rows become quoted evidence, guidance becomes story-mapped, the prohibited list gets real entries, and B1's stand-in objection is replaced by one named from evidence
- The JD text: the six requirements become quoted and grounded, each gets a JD-tagged question, and F6 is resolved
- Which sessions you have and who runs each: persona weights are recomputed, and if your final is several sessions, a mini-pack per session is possible
- An interviewer's name: an interviewer read from their public footprint and a reverse question tied to their path
- The recruiter's prep email: stated focus areas or any pre-declared deliverable
- Search access: published values, documented loop, current strategy and a representative posting, turning the generic CO questions and persona weights into sourced ones
- A tuesday-dossier.md from earlier work on this role: verified evidence and prohibited claims, never required

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
The pack isn't saved because the file write was refused. If you'd like it saved as markdown or converted to Word, grant write access and say so.

Who are your final-round sessions with, and in what order (manager, peer, cross-functional, skip-level)? The answer reweights every bank.
Can you paste the JD and your CV? I'll proceed without them, but they turn the scaffolds into story-mapped answers.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.