Loading is done; next I'm running the L1 research searches on Saltmarsh Games and Tobias Wrenfield, then I'll build the pack.
The write to the project folder was declined, so I'm saving the pack to the session scratchpad instead.
Femi, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-canned-1fd525bf/833e423a-483d-400f-9790-505a0dcdf136/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions, and I wrote it for a hiring-manager round with Tobias. I couldn't write to the project folder, so the file is in the session scratchpad.

Saltmarsh's careers page says every interview is one 60-minute session with the hiring manager, called the "Outage Hour". It's a live-incident tabletop on a simulated outage, then a values conversation, and there's no take-home. The pack is weighted that way. It covers the tabletop scenarios, one question for each of Saltmarsh's three values, and the retention and KPI probes.

- **Where you're most exposed:** Your stated gap, never having worked on a game with in-app purchases, is the likeliest objection. A search summary says Saltmarsh is moving both titles to a season pass from January 2027. Question C2 is the highest-priority prep: say "I haven't worked on a game with in-app purchases" plainly, then give a plan, and don't present your retention work as monetization experience.
- **Where to lean on Tobias's background:** His GDC 2026 talk, "Patch Notes Are a Promise", argues a live team is judged by whether its patch notes match what shipped, and he was previously a QA lead. Your sentence "Wrote the release checklist our QA team still uses" is your closest match, and the pack rehearses defending exactly what was yours.
- **Where the answers are yours to supply:** For the values questions and several fit rows, your material doesn't carry a story or fact. Those cells are marked answer slots, and I haven't invented anything to fill them. The pack won't coach you to claim team leadership, in-app purchase experience, or owning the post-event review.
- **How much of the research is solid:** I read the values page and the careers page in full. The Project Larkspur announcement and Tobias's talk I saw only as search-result summaries, so the pack labels those details as summary-level.

By today's date Friday is tomorrow, so the pack opens with a short prep order.

Say the word and I'll run a live drill as Tobias on C2 or on the tabletop. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be the hiring manager: Saltmarsh's careers page describes its loop as a recruiter call, then one 60-minute interview with the hiring manager, and your note describes a 60-minute interview with him.
**Round:** the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script. Where a cell says "answer slot", the fact is yours to supply or to say plainly you can't.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your CV-level claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its direction |
| CASE | A live problem, scored on structure and reasoning |

Question IDs use letters by persona and skip F, so they never collide with the fit-snapshot rows F1 to F8.

## Prep triage

Your note gives the day, not the hours. By today's date (Thursday 5 November) Friday is tomorrow, so this assumes one working session. In order:

1. **C2**, the highest-ROI prep in the pack. Say the plain acknowledgment aloud until it is boring, then rehearse the two follow-ups.
2. **A1 and A2**, aloud, as the tabletop is half the hour. Practise the clarify, then objective, then who you pull in, then what players are told, structure.
3. **B1 to B3**: for each of Saltmarsh's three values, decide which of your own stories you will use, or decide that none comes to mind and rehearse the honest branch.
4. **E2 and D1**: defend your own sentences, including the parts that were not yours.
5. **Reverse questions**: pick three, including the first.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's line makes a probe on events and on a second title likely. If any of the drops were timed events, say which and what you planned, in your own words; if the calendar held no events, or covered only the one title, say so plainly and stay with the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The calendar sentence does not say which teams the drops involved, and the second sentence speaks to leading and to in-app purchases, neither of which this JD line asks. Answer slot: the JD names four disciplines, so expect a probe on which you worked with. If the drops involved any of them, say which and what you asked of each, in your own words; if the calendar did not involve them, or someone else coordinated them, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a review, and the words stay at the presenting: "I presented the monthly retention numbers to the studio head." Answer slot: the JD says own the review and its KPIs, so expect a probe on whether you chose what went in. If you chose or built any part of what was presented, say which and how, in your own words; if the numbers were assembled by someone else, or there was no review of an event, say so plainly and stay with presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The sentence already reaches the requirement in other terms. Lead with it as written: you wrote the release checklist, and your QA team still uses it. Nothing inspected stands behind it yet, so expect a probe, and E2 rehearses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives the years, the genre and the title associate producer, and does not say the game was live-service across all four. Answer slot: the JD's 3+ years makes a probe on which years ran on a live cadence likely. Say which, in your own words; if only the last two did, say so plainly. Say your title as it is: associate producer |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. Lead with the quote's own terms: weekly, your main title, two years. Nothing inspected stands behind it, so a sanitized view of the calendar would raise the band |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in what the quote reaches: monthly retention numbers, presented to the studio head. Expect a probe on how they were counted, which D1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A checklist your QA team still uses is writing others act on, and that is all the sentence says. Your material shows nothing about player-facing writing, so the pack makes no claim there; expect a request for a sample, and B5 rehearses the nearest live version |

## Reading the interviewer

Public professional footprint only, taken from search-result summaries; the talk itself was not fetched.

| Fact | Provenance | What it implies |
|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | [grounded] search result for his GDC 2026 talk page | He has sat on the QA side of a release, so release-checklist answers will be heard by someone who has used one. F4 is your closest match to his path |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | [grounded] same search result, one-line summary | Expect claims about shipped work to be tested against what was actually shipped. This is the same idea as the value "Ship the Patch Not the Promise", so B3, B5 and E2 are his native ground |

**Mirror opportunity.** His public path runs through QA, and your F4 sentence is "Wrote the release checklist our QA team still uses." — your message. Use it as the shared ground; do not build on anything beyond what that sentence says.

Read the talk summary or watch the talk before Friday if you can; this pack has only its one-line summary.

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop on a simulated outage during a live event | Highest. Saltmarsh's own page makes the tabletop half the hour, and the hiring-manager prior favors this persona | Clarify, objective, who you pull in, what players are told, how you review it afterwards. Bank A |
| Values / Behavioral | The second half of the hour, mapped to the three published values | High. The careers page documents a values conversation, and the interviewer's talk theme matches one value | One story per value where a quoted sentence of yours carries one; otherwise a selection scaffold and the honest branch. Bank B |
| Skeptic | Probes the gaps you stated: team leadership, in-app purchases, two titles | Medium-high. The hiring-manager prior includes it, and you have stated two gaps outright. The season-pass announcement (Project Larkspur, August 2026, from a search summary) makes the in-app purchase gap likelier to surface | Rehearse the plain acknowledgment and the plan. C2 is the highest-ROI prep in this pack. Bank C |
| Data-Driven Prober | Retention and KPI questions | Medium. The JD names retention metrics and KPI ownership, and nothing public says he reads CVs line by line, so this is the JD's pull only | Say how a number was counted, or say you do not know. Bank D |
| Pressure | Time-boxing inside the tabletop | Lower. This is my inference from the tabletop format, not something Saltmarsh publishes | Pause, restate, hold two follow-ups, then concede specifically. Bank E |
| Conversational | The opener, and any casual question near the end | Lower, but still scored | A 90-second arc built from your own sentences. Bank G |

Peer Evaluator is not included: the round is with the hiring manager.

## Question banks

### Bank A: Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A weekend event is live and rewards are failing to arrive for part of the player base. Engineering says a fix is a few hours out. Walk me through your first fifteen minutes." | CASE | [generic] | Structure aloud: clarify first (who is affected, what players see, what engineering can and cannot yet say), then your objective, then who you pull in from design, art, engineering and community, then what players are told and when, then how it feeds the post-event review. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The careers page documents a live-incident tabletop, so a scenario of this shape is the likeliest thing in the hour. The scenario is my example of the format, not Saltmarsh's actual script. CASE because it is scored on structure |
| A2 | "Thursday's event is scheduled to go live. It is Wednesday night and QA has not signed off the build. What do you do?" | CASE | [generic] | Structure it: what you ask QA and engineering first, what the options are (hold, ship with a known issue, ship reduced), who decides, and what players are told. Let the value "Players Before Plans" shape the choice and the wording, without quoting it at him. No claim about your past | The JD's release-checklist line and the first two published values meet here, so a scenario about calendar pressure against readiness is likely. F4 is the related evidence row; the answer needs none of it |
| A3 | "From January our two titles share one events calendar, and the per-title event teams are folded into one live-ops group. What would you expect to collide, and how would you sequence the first two months?" | CO | [inferred] derived from a search-result summary of Saltmarsh's August 2026 Project Larkspur announcement; the page itself was not fetched | Clarify what you do not know about the plan first. Then name the kinds of collision a shared calendar produces (overlapping events, shared teams, one build cadence) and propose how you would sequence and what you would watch. Frame it as hypotheses, and say that you are working from a public announcement | At least one strategy-grounded question is required when research ran, and this is the one live company change found. It is labeled inferred because only a summary was read |
| A4 | "An event underperformed. How would you structure the post-event review?" | JD | [grounded] the JD's "own the post-event review and the KPIs it reports" | Structure: what the event was meant to do, what you would measure and from where, what you compare it against, what you would conclude and what you would not, and what changes before the next event. Make no claim about reviews you have run | F3 is the evidence row for the requirement, and a review structure is what the requirement most directly asks for. JD because it scores the stated responsibility |
| A5 | "You ran the weekly content-drop calendar for your main title. This role covers two titles. How would you plan the second?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the quote at its scope: you ran the weekly calendar for your main title. Answer slot: the JD's line on two titles makes a probe on running more than one calendar likely. If you have planned more than one at once, say how, in your own words; if not, say so plainly and stay with the one calendar you ran. Then say how you would approach two as a plan, not as a past | F1 is the row where the JD stretches furthest past your sentence, so this question arrives in some form. JD because it scores a stated requirement |

### Bank B: Values / Behavioral (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Leave the Build Greener. Story-map on the one sentence: you wrote the checklist, and your QA team still uses it. Tell those beats in your own words. Answer slot: the value says every release leaves the checklist better, so expect a probe on whether it changed after releases. If it did, say what changed and what prompted it; if it was not revised, or the changes were not yours, say so plainly and stay with writing it. If another story serves better, use it from your own experience | F4 is the only row that touches this value. VAL because it scores a published value, with EXP as the follow-up |
| B2 | "Tell me about a time the plan and the players disagreed." | VAL | [grounded] Saltmarsh's published value "Players Before Plans" | Selection scaffold, no quote of yours carries this: pick a time a schedule or plan was set against what players or users needed, with a named stake, what you did, and what happened to the plan. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is published, so a question on it is likely. The pack does not supply a story: none of your sentences carries one |
| B3 | "Tell me about a time you told people less than they had hoped to hear, because that was what was actually ready." | VAL | [grounded] Saltmarsh's published value "Ship the Patch Not the Promise" | Selection scaffold: choose a moment where you announced or reported only what existed, with who was disappointed, how you said it, and what the relationship was after. The interviewer's public talk argues patch notes should match what shipped, so a story that shows the same discipline lands well. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | This value and his public talk theme point at the same test. Your material is silent on whether any of your monthly retention reporting carried bad news, so the pack supplies nothing |
| B4 | "Tell me about a time something went wrong in a release or an update, and what you did next." | VAL | [grounded] the JD's "manage the release checklist with QA" | Selection scaffold: pick a release or update that went wrong in a way you can describe precisely, with what you saw, what you did, who you told and what changed afterwards. Do not enlarge your role in it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The tabletop tests this live, and the values half may test it from the past. Your material says nothing of an incident, so the pack does not supply one |
| B5 | "An event has to be extended by a day because of a bug. Give me the first two sentences of the player-facing notice." | JD | [grounded] the JD's "clear written communication"; "Wrote the release checklist our QA team still uses." | Say what happened, what players get, and when the next update is, using only what is true and built, with no promise beyond it. This is the value "Ship the Patch Not the Promise" in sentence form. Your writing evidence is the checklist you wrote, which is internal; answer slot: if you have written anything players saw, name it and what you wrote; if you have not, say so plainly and show the discipline in the two sentences | F8 is the evidence row, and it carries no player-facing writing. The written-communication requirement is otherwise easy to leave uncovered, and the interviewer's talk theme is patch notes |

### Bank C: Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] the JD's responsibilities and requirements | Choose one honestly before he does, and tie it to a plan for the first weeks. The gaps your material shows are listed in F1, F2, F3 and F5, and the two you stated are in C2 and C3. Whichever you pick, say what you would do to close it as a plan, not as a past | A standard skeptic opener, and the one that tests whether you know your own gaps. JD because it scores the whole list |
| C2 | "You've never worked on a game with in-app purchases, and our titles are moving to a season pass. Why should I think you would cope?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep.** Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Do not soften it. Then say only what your material carries: you ran a weekly content-drop calendar for your main title and presented monthly retention numbers, each at its own scope, and do not call either monetization experience. Follow-up 1, what would you want to know first about how the season pass is read here: answer as a plan. Follow-up 2, retention is not revenue, so what don't you know: concede specifically that you do not yet know how those numbers are read. Hold the plan through both, and concede only what is true | Your own sentence states this gap, and the season-pass change (from a search summary) makes it likelier to be probed. It is the most predictable objection, aimed at exactly where your material is thin, so it gets the deepest rehearsal. EXP because it tests what you actually did. If you learn the role touches no monetization, A5 and C3 take its place |
| C3 | "You've never led a team. This role coordinates four disciplines. Where does your authority come from?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases."; "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the plain acknowledgment: "I haven't led a team." Then the point that the JD asks you to coordinate, not to manage. Answer slot: if your drops involved design, art, engineering or community, say who and what you asked of each; if the calendar did not involve them, or someone else handled them, say so plainly and stay with the calendar. Then how you would get agreement without authority, as a plan | F2 is where the JD's word coordinate meets your stated negative. EXP because it tests what you actually did |

### Bank D: Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about the retention numbers you presented each month: which ones, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say which numbers and how they were counted, in your own words, and say plainly if you do not know how a figure was counted. Name the assumption behind them you would defend least before he does. Say what the numbers were sensitive to and which part of the work was yours. The pack supplies none of these | F7 is a metric claim, which probers go straight to. EXP because it tests attribution and counting |
| D2 | "Retention fell in the week after an event ended. What do you look at first?" | CASE | [generic] | Clarify first (which cohorts, which retention measure, what changed besides the event), then segment, then name hypotheses and what would confirm each. Say what you would not conclude from one week. Makes no claim about your past | The JD names player-retention metrics, so a diagnosis question is likely. CASE because it is scored on reasoning |
| D3 | "Which KPIs would you put in the post-event review, and which would you leave out?" | JD | [grounded] the JD's "the KPIs it reports" | Choose a few tied to what the event was for, say what each does and does not tell you, and name one you would leave out and why. Make no claim about KPIs you have owned | F3 is the evidence row for the requirement. JD because it scores a stated responsibility |

### Bank E: Pressure (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already worked on in-app purchases?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold only what the quotes carry: you ran a weekly content-drop calendar for your main title for two years, and you wrote the release checklist your QA team still uses. Hold that through two follow-ups. Concede the gap explicitly and specifically: "I haven't worked on a game with in-app purchases", and say what you would learn first, as a plan. Do not claim you would be better at it | A time-boxed comparison is the pressure form of C2. EXP because it tests whether the claims hold without inflating |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it." Answer slot: if QA or others contributed, say what and who; if you wrote it yourself, say so plainly. Return to the sentence through two follow-ups. Concede specifically whatever part was not yours | F4 is a claim of authorship, and the interviewer's public talk is about claims matching what shipped. EXP because it tests attribution |

### Bank G: Conversational (weight: lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc in four beats, one per sentence: the four years and the title as it is, the calendar, the checklist, the monthly retention numbers. Add why this role in your own words. Answer slot: which of the four years ran on a live cadence, if asked | The opener is scored, and F5 and F6 are the rows it carries. EXP because it is the CV in spoken form |
| G2 | "Why Saltmarsh, why live operations, why now?" | VAL | [grounded] Saltmarsh's published values page | Selection scaffold: pick one published value that matches how you work, one fact about this role, and one reason from your own path, all yours to supply. If no value comes to mind honestly, say so plainly rather than claiming one | A motivation question is near-certain in a conversational register. The pack cannot supply your reasons |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | A3, A5, C1, E1 |
| Coordinate design, art, engineering and community on each update | A1, C3 |
| Own the post-event review and the KPIs it reports | A4, D3 |
| Manage the release checklist with QA | A2, B1, B4, E2 |
| 3+ years producing live-service games or apps | G1, C1 |
| Experience running a content calendar | A5, G1 |
| Comfortable with player-retention metrics | D1, D2, D3 |
| Clear written communication | B5 |

## Values cheat sheet

The careers page documents a values conversation, and the values page was fetched.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and players disagree, players win | No quoted sentence of yours carries a story. Selection scaffold at B2, ending in the honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence of yours carries a story. Selection scaffold at B3, ending in the honest branch |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." — your message. B1 holds the answer slot on whether it improved over time |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How does your team measure that here?" | Ties to his own public path and talk, and invites him to talk about work he cares about. Use only if you have read or watched it |
| R2 | "With Project Larkspur folding the per-title event teams into one live-ops group, where does this role sit, and who would I coordinate with day to day?" | Shows you read the public announcement and asks about the role as it will actually exist. The JD's framing is two titles, and this asks without correcting him |
| R3 | "What would you want a new producer to know by day thirty about how the season pass is read here?" | Turns the in-app purchase gap into a forward-looking question without volunteering a deficiency |
| R4 | "What does a good post-event review look like today, and which KPI in it do you trust most?" | Maps to the post-event review responsibility and shows you think about KPIs critically |
| R5 | "Where does the release checklist tend to break down in practice?" | Speaks to a former QA lead from his own ground, and signals you take the checklist seriously |

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." — your message | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Same negative you stated, same sentence | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot, then a plan |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the weekly content-drop calendar for your main title. A5's slot stays inside that |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presenting monthly retention numbers |
| Managed the release checklist with QA release to release | Inflated form of F4 | F4's quote at its own scope: you wrote it, and your QA team still uses it |
| Has monetization or revenue-metrics experience | Inflated form of F7, and contradicted by your stated negative above | F7's quote at its own scope: retention numbers, presented to the studio head |

## Sources

**Provided documents:** the job description, and your background as given in your message.

**Searches sent:**

| Query | Returned |
|---|---|
| Saltmarsh Games values | saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | saltmarshgames.com/careers/interviewing |
| Saltmarsh Games mobile strategy news | saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Saltmarsh Games | talks.gdconf.example/2026/patch-notes-are-a-promise |

**Pages fetched:** saltmarshgames.com/values, and saltmarshgames.com/careers/interviewing. The Project Larkspur announcement and the talk page were read only as search-result summaries, not fetched, so claims drawn from them are summary-level.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: the three values by official name; B1 to B3 |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop structure: the Outage Hour, 60 minutes, hiring manager, tabletop then values, no take-home. Drove persona weights and dropped the graded-deliverable section |
| 3. Saltmarsh Games strategy / recent news | yes | A3 and R2: Project Larkspur, from a summary only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read, R1, and the weight of B3, B5 and E2 |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Deeper research pass** → a strategy brief and a grounding section, the interviewer's other talks and writing, loop reports for this role family, and recent org context. Up to 6 more searches and 2 more fetches, several more minutes. Offered once.
- **Recruiter's answers on the Outage Hour** (how it is scored, whether the scenario is shared in advance) → replaces my assumed tabletop shape in A1 and A2 with the real one.
- **Confirmation that Tobias is the hiring manager and your future manager** → locks the persona weights; if he is not, Bank A and C reweight.
- **A sanitized view of your release checklist and your content calendar** → F4 and F6 move from medium to high.
- **Anything you have written that players saw** → B5 and F8 move from a rehearsal of the discipline to an evidenced answer.
- **Your answers to the answer slots in F1, F2, F3 and F5** → each row regenerates with your words, and A5, C3 and G1 follow.
- **The full text of the GDC talk and a fetch of the Project Larkspur page** → R1 and A3 move from summary-level to full detail.
- **A tuesday-dossier.md from an earlier session** → verified evidence and a named top objection in place of the ones inferred here.
