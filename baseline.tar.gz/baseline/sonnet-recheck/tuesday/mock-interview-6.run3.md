Web search wasn't permitted, so I'm building the pack from what you told me, with no company-specific facts. It's a loop pack: one shared fit snapshot, then a mini-pack for each of your three rounds.
The write to the working directory was refused. The system prompt names the session scratchpad as the place for files like this, so I'll save the pack there.
I couldn't save the pack to a file: the write was refused, and so was creating a folder in the scratchpad. I haven't tried any other way to save it. The full pack is below instead.

# Interview pack: Engineering Manager, Larkfield Systems (three-round loop)

I built this from your message only, because web search wasn't permitted. Nothing here is a claim about Larkfield beyond the role text you pasted and what the recruiter told you.

| Round | When | Who | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores: VAL (values), EXP (work-experience deep-dive), JD (role and requirements), CO (company and strategy), CASE (live problem). Guidance is scaffolding, not a script.
- An answer slot names a probe the interviewer is likely to make and gives you two honest branches. If you did the thing, say how, in your own words. If you didn't, or it wasn't yours, say so plainly and return to what your own sentences carry. The pack never fills a slot for you.
- Provenance labels: `[grounded]` means traceable to your message. `[inferred]` means derived, with the derivation named. `[generic]` means a role-family pattern with no claim about you or Larkfield.
- Persona weights rest on your own description of the three rounds. They don't rest on any documented Larkfield process.

## Prep triage

I don't know your hours per day, so this is ordered by deadline.

1. Before Tuesday: B2 (the highest-ROI prep in the pack), then B1, A3, C1, A1.
2. Before Thursday: E1 and E2 (the 60% figure will be probed), D1, E3, F1.
3. Before Monday: G1, H1, G3, I2.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material shows one team of six and nothing about two squads or device-management services. The words stay at that scope: "For three years I was a team lead of six." Answer slot: expect a probe on scope. If you've led more than one team, or worked on anything like device-management services, say which; if not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message (delivery) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The sentence shows a push against roadmap pressure and a drop that followed. It doesn't show who answered for delivery. Answer slot: expect a probe on how delivery was tracked and answered for. If that was yours, say how; if someone else did it, or there was no such step, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote reaches hiring in the role's terms, so lead with it as written. The sentence doesn't say the 40 interviews were yours, so read the figure downward, and expect a probe on that and on the roles being backend. Nothing inspected stands behind the line |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message (growth) | none given | none | [grounded] | discovery | Your material is silent on developing engineers. Answer slot: if you've helped an engineer take on more, say who and what changed; if not, say so plainly and say what you'd do first, as a plan |
| F5 | "partner with hardware and product on roadmap" — your message (hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated you haven't owned a hardware-adjacent roadmap, so those words are yours. The requirement is partnering, which your sentence doesn't speak to. Answer slot: if you've worked alongside hardware or firmware teams, say how; if not, say so plainly and say what you'd ask the hardware lead first, as a plan |
| F6 | "partner with hardware and product on roadmap" — your message (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a push against roadmap pressure and nothing about who applied it. Keep it at that scope. Answer slot: expect a probe on who was on the other side and what was traded. If you can say, do; if the pressure didn't come from product, or nothing was traded, say so plainly |

## Prohibited claims

I built this list from the snapshot, since there's no dossier.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, F5 | "I haven't managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." |
| Managed a team of six and answered for its delivery, hiring and growth | Inflated form of F1 | F1's quote at its own scope. The material says team lead of six, not what that covered |
| Cut on-call burden by 60% through the reliability quarter | Inflated form of F2 and F6 | The sentence at its scope: the drop came after the push. It doesn't say the quarter caused it or how the figure was counted |
| Hired about 40 engineers, or did all 40 interviews yourself | Inflated form of F3 | "I run our hiring loop for backend roles", with the figure told as about 40 interviews and no more |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | A2, B3, C2, D4, F1 |
| Own delivery | A3, A4, E2, F1 |
| Own hiring | E3, G4 |
| Own growth for 11 engineers | G2, H1 |
| Partner with hardware on roadmap | A1, B1, B2, D1, F2 |
| Partner with product on roadmap | A3, D1, D2, F2 |

There's no CO question in this pack because no company research ran. The CASE questions are `[generic]`.

## Sources

Provided: your message (role text, the three rounds, your background). No dossier, CV or full JD was provided.

Searches sent, all refused because permission wasn't granted:

- `Larkfield Systems industrial IoT values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems strategy news device management` — refused

Fetches: none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Refused. Would have fed the Monday values cheat sheet, which is dropped because no published values are in hand |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Refused. Would have checked your described loop against a documented one |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Refused. Would have fed a CO bank grounded in current strategy, which is absent |
| 4. `{interviewer name} Larkfield Systems` | n/a | Only titles were given, no names, so there was no query to form |
| 5. representative `Engineering Manager` JD | skipped | The role text you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Round 1 — Tuesday, Director of Engineering (hiring manager)

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on the squads' roadmap | High. The hiring-manager prior is Case/Strategist plus Skeptic, and this person is your would-be boss | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Skeptic | Probing the two gaps you named | High. A hiring manager de-risking a hire will find the same two gaps | Rehearse B2 until it's boring; concede the limit specifically |
| Conversational | Opener and motivation | Low. It's brief but still scored | Pre-script a 90-second arc |

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over two squads and learn that hardware's release dates keep moving under your roadmap. What do you need to know first?" | CASE | [generic] | Clarify first: what's committed to customers, what moves when a date moves, who at hardware owns the date. Then objective, segments of work by exposure to hardware dates, approach, metrics, risks. Challenge one premise respectfully, such as whether the dates are the real problem. No claim about your past | F5's partnering line; CASE because a hiring manager can pose it on the real roadmap |
| A2 | "Sketch your first ninety days leading these two squads. What do you need to know first?" | CASE | [generic] | Structure by what you must learn before changing anything: work in flight, the people, the hardware and product relationships. Say what you won't touch until you've learned it. A plan, not a claim about your past | F1's two-squads line |
| A3 | "One squad wants a quarter for reliability and product wants features. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: what each side protects, what evidence each needs, a decision rule, what you tell the side that loses. Then, once, offer your sentence at its scope. Answer slot: expect a probe on what the roadmap gave up. If something was traded, say what and who agreed; if nothing was, or the call wasn't yours alone, say so plainly and stay with the quarter you pushed through | F2 and F6; an EXP follow-up is likely |
| A4 | "Pages on a device-management service doubled after a release. Diagnose it." | CASE | [generic] | Clarify service, devices, release, start time. Segment hypotheses by release, device population, upstream change. Mitigate before root-causing, then metrics and risks. Think aloud. No claim about your past | F2's delivery line |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name one weakness from your own statement: "I haven't owned a hardware-adjacent roadmap." Then say how you'd close it in the first weeks, as a plan. Answer slot: expect a follow-up on whether you've worked with hardware teams. If you have, say how; if not, say so plainly and return to the plan | F5 is the named gap |
| B2 | "You haven't owned a hardware-adjacent roadmap. How would you partner with hardware on ours?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | **Highest-ROI rehearsal in the pack.** Hold only what the quote carries: "I haven't owned a hardware-adjacent roadmap." Answer slot: if you've worked alongside hardware or firmware teams, say how and what you learned; if not, say so plainly. Close with what you'd ask the hardware lead in week one. Rehearse three follow-ups: what you'd ask first, what you'd do if hardware and the squads disagree on a date, what you'd concede. Hold each by returning to the plan, never by adding to your past | F5 is where the partnership mandate presses hardest and your own sentence names the limit, so this will arrive in some form |
| B3 | "Eleven engineers across two squads is more than the team of six you've led. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say it at its scope: "I was a team lead of six." Then structure what changes as a plan: what you'd stop doing yourself, how you'd keep signal across two squads. Answer slot: if you've led more than six or more than one team, say so; if not, say so plainly | F1 |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year" | A 90-second arc from these beats only. Answer slot: the turn toward managing is yours to explain, in your own words; if it wasn't a single decision, say that | F1 and F3; casual delivery, still scored |
| C2 | "Why leave a payments company for industrial IoT?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: your reasons are yours; the pack supplies none. Keep them to why this role and company, using only what the role text says. If it's more about the role than the industry, say so plainly | F1 and F5; motivation consistency |

### Reverse questions for Tuesday

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would make you say in twelve months that this hire was a clear success?" | It puts your would-be boss's bar on the table |
| R1.2 | "Where do hardware and the squads' roadmaps collide most today, and how is that handled now?" | It shows you're thinking about the gap you named |
| R1.3 | "Of the eleven engineers, where is the team strongest and where is the biggest hiring or growth need?" | It ties to the hiring and growth line |
| R1.4 | "How is the device-management work divided between the two squads, and where is the seam?" | It tests the scope question from the other side |
| R1.5 | "What would support from you look like in my first ninety days?" | It turns the round into a working conversation |

---

## Round 2 — Thursday, panel (two staff engineers, one product manager)

I assigned personas by role, since no names are known.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seams, disagreement, credit | High. All three are peers or near-peers of the role, and the PM is cross-functional | Reciprocity: what you bring them. Propose seam principles, not a seam you don't know |
| Data-Driven Prober | Probing the 60% and the 40 interviews | Mid. Staff engineers are a depth audience and your two figures are probe targets | Know what you can and can't say about how each figure was counted; name your weakest assumption first |
| Case/Strategist | Paging and hardware-limit problems | Low. Panels spend less time on cases | Clarify, structure, think aloud |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our squads sit next to hardware and product. Where's the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Propose seam principles: who decides what, how disagreement is made visible, what each side gets back. Reciprocity first. Your sentence is a data point at its scope. Answer slot: who was on the other side and how it ended are yours to say; if there was no real disagreement, say so plainly | F5 and F6 |
| D2 | "How would you handle a roadmap request from product when the squads are already stretched?" | JD | [generic] | Structure: what you'd ask product first, how you'd show the cost, what you'd offer in exchange, how the decision is recorded. Frame it as a shared problem. No claim about your past | F6's product line |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold, since none of your sentences carries this. Pick a time work crossed a team boundary and credit was shared visibly: a named piece of work, a moment you gave credit away, an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; your material doesn't carry it |
| D4 | "A staff engineer on your squad disagrees with your call on a design. What do you do?" | CASE | [generic] | Listen for the actual objection, separate who decides from who's right, decide and record why, set a time to revisit. Spine and tact together. No claim about your past | F1's leadership line |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The 60% drop in on-call burden — walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Slots, each in your own words: how it was counted, what it's sensitive to, the assumption you'd defend least, which part was yours. The pack names none. If you don't know how it was counted, say so plainly. Name your weakest assumption before they ask | F2 and F6; a headline metric is a probe target |
| E2 | "What was your part in getting the reliability quarter through?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say it at its scope: "I pushed a reliability quarter through." The pack's observation: your sentence says the drop came after, not that the quarter caused it. Answer slot: if other things contributed, say which; if the team did the work, say so plainly and stay with your push | F2 and F6; attribution honesty |
| E3 | "You said you run the hiring loop for backend roles. What does running it involve?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say it as written and tell the figure as about 40 interviews. Answer slot: what running it involved is yours to say; if parts weren't yours, or the 40 weren't all yours, say so plainly | F3; the figure and the verb will both be probed |

### F. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A device-management service is paging at 3am every few nights, and you have one quarter. Plan it." | CASE | [generic] | Clarify what the pages are, who's hurt, what the quarter competes with. Then objective, options ranked by cost and risk, how you'd protect the quarter, how you'd know it worked. If you reach for your own quarter, use the sentence at its scope | F2 |
| F2 | "A large customer needs a feature that hardware can't support until next year. What do you tell product and the customer?" | CASE | [generic] | Clarify what's truly constrained versus only unscheduled. Offer options, an honest date range, the trade for each, and what you won't promise. No claim about your past | F5 and F6 |

### Reverse questions for Thursday

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What's one thing a new manager could do in their first month that would genuinely help your squad?" | The reciprocity question: it asks what you can give them |
| R2.2 | "Where do the squads feel the pull between roadmap and reliability today?" | It invites their account of the tension your own sentence touches |
| R2.3 | "How does roadmap input from hardware reach product, and where does it get stuck?" | It asks the PM about the seam you were asked to propose |
| R2.4 | "How are technical decisions made when staff engineers and the manager disagree?" | It shows you expect to share decisions |
| R2.5 | "What do you wish product and engineering did differently in how they plan together?" | It gives each panelist a chance to describe a good partner |

---

## Round 3 — Monday, VP Engineering (values and leadership philosophy)

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Unpopular truths, growing people, how you lead | High. The recruiter called this a values and leadership philosophy round | Map a story where one of your sentences carries one; a scaffold with an honest branch where none does. "We" for context, "I" for your part |
| Skeptic | The gap between your scope and the role's | Low. Thirty minutes leaves little room | Concede the limit plainly, then give a plan |
| Pressure | Time-boxed "why you" | Low. The skip-level prior includes it, but the time and the recruiter's framing weigh toward Values | Pause, restate, hold through two follow-ups, concede specifically |

There's no values cheat sheet. The recruiter's description does point to a values-style round, but Larkfield's published values aren't in hand because search was refused.

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map on the beats the sentence states: roadmap pressure, you pushed a reliability quarter through, the on-call burden dropped 60% after. Who the pressure came from, whether it was leadership, and how the truth landed are answer slots, in your own words. If another story fits better, pick it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 and F6; scores whether the hard truth landed |
| G2 | "Tell me about a time you helped an engineer grow." | VAL | [generic] | Selection scaffold: a named engineer, a specific change in what they took on, a part you can say was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's growth line raises it; your material is silent |
| G3 | "What's your philosophy on how to lead engineers?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The recruiter named leadership philosophy as this round's subject. Answer slot: the philosophy itself is yours, in your own words; the pack supplies none. Back each principle with something you did, at its scope, and let the VP draw the inference rather than asserting what your work proves | F2, F3 and F6 |
| G4 | "You run your team's hiring loop. What do you look for in an engineer?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Answer slot: what you look for is yours to say; the pack supplies no criteria. If you don't set the criteria yourself, say so plainly and say what you do | F3 |

### H. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've never managed managers. How do you think about growing leaders under you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The plain acknowledgment is yours: "I haven't managed managers." The pack's observation: the role text you gave names two squads and eleven engineers and doesn't mention managers. Answer slot: if anything in your experience bears on growing someone into leading others, say what; if nothing does, say so plainly and answer as a plan | F4 and your stated limit |
| H2 | "Why do you want to manage rather than stay a tech lead?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: your reasons are yours; the pack supplies none. Say what you want to do more of and what you'd miss, and keep it true | F1; motivation consistency |

### I. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause and restate. Hold only what the quotes carry. Don't argue you're better. Concede specifically when pressed: "I haven't managed managers" and "I haven't owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to the quotes, never by adding to them | F3, F5 and F6; composure is scored |
| I2 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: "I pushed a reliability quarter through." Answer slot: what else contributed and who did the work are yours to say; if the team did most of it, say so plainly and stay with your push. Concede uncertainty specifically, such as how the figure was counted, but don't fold on the core claim | F2 and F6; attribution honesty |

### Reverse questions for Monday

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does leadership at Larkfield look like when it's working well, in your words?" | It asks directly for the philosophy the round is about |
| R3.2 | "How do you develop engineering managers, and what would you expect from me in that?" | It treats your stated gap as a shared question |
| R3.3 | "Where does engineering leadership trade roadmap against reliability, and who makes the call?" | It connects to your reliability story without retelling it |
| R3.4 | "What would you want me to have learned about the hardware side of the business in my first six months?" | It addresses the second gap as a plan |
| R3.5 | "What would make you hesitate about a candidate for this role, and is there anything in my background I can address now?" | It lets the VP name a concern while you can still answer |

## Upgrade menu

- **Permission to search the web:** Larkfield's published values by name (the Monday values cheat sheet), the documented interview loop (checks the persona weights), and current strategy (a CO bank grounded in what the company is doing).
- **The full JD text:** role rows become quotes from the posting, and mid-list requirements this pack couldn't see get questions.
- **Your CV:** the snapshot rests on four of your sentences. A CV adds evidence for F1, F2, F4 and F5 and lets stories map to quotes instead of scaffolds.
- **Your answers to the slots in F2, F4 and F5** (delivery, growing an engineer, working alongside hardware): those rows move from discovery toward grounded bridges.
- **Interviewer names:** an interviewer read, personas assigned per panelist, and a reverse question tied to each person's path.
- **The recruiter's stated focus areas per round, and any announced deliverable:** coverage assumed from round-type priors becomes coverage I can check.
- **A `tuesday-dossier.md` from an earlier fit assessment of this role, if you have one:** verified evidence and a sourced prohibited-claims list. This pack doesn't need one.

I can run a live drill, starting with B2 as the Skeptic, since it's the pack's highest-ROI question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. To get the pack as a file or a Word document, grant write access and I'll save it.

Can you paste the full JD and your CV, or tell me to skip? And do you have interviewer names, or anything the recruiter said about focus areas for each round? Either would restructure parts of the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.