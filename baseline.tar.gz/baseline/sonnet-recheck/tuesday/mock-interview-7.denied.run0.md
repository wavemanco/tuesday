Searches were denied, so I'm building the pack from your message alone and saving it now.
I couldn't save the pack as a file because the write was denied, so it's below in full. Web searches were also denied, so none of it uses research on Saltmarsh or Tobias. It rests on your message and the JD you pasted.

# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. You didn't say how you relate to him, so I built this as a hiring-manager round. It's a 60-minute conversation.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Say it in your own words, and only about what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows values, not generic virtue |
| EXP | Whether the claims on your CV survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, because research didn't run) |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep: B1, with B2 beside it.** Your own message states the limits those two questions press on.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are stated. Your material doesn't show whether the title ran as a live service, so the words stay at the quote. Answer slot: expect a probe on "live-service". If your title ran as an ongoing service, say what that involved, in your own words; if it did not, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but nothing is inspected behind it, so expect a probe. Lead with the quote's own terms: you ran it, weekly, for two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material carries a content-drop calendar for "our main title", not an events calendar and not two titles. Answer slot: if you ran or coordinated calendars for more than one title, say how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | low | [grounded] | discovery | You've stated you haven't led a team. Your material doesn't say whether you worked across these four disciplines, and leading and coordinating are different things. Words you can give back: "I've never led a team." Answer slot: if you coordinated with any of the four on a drop, say which and what you did; if that wasn't part of your work, say so plainly and stay with the calendar |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or defined KPIs. You also stated the other limit: "I've never worked on a game with in-app purchases." Answer slot: if you looked back over those numbers after a drop, say what you did; if no such review happened, or it wasn't yours, say so plainly and stay with the numbers you presented |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only that: "I wrote the release checklist our QA team still uses." |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, with nothing inspected behind it. Lead with the quote's own terms: monthly, retention, presented to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | A checklist a team still uses is written work, but your material doesn't show how it read to them. Answer slot: if QA or others said anything about its clarity, say what; if nobody did, say so plainly and describe what the checklist does |

## Persona table

No source describes this interview beyond your own words. Weights rest on the hiring-manager prior plus what the snapshot exposes. If Tobias is a peer or a skip-level, tell me and I'll recompute them.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems: two titles colliding, a late asset, a missed metric | Highest, 5 questions. It is the hiring-manager prior, and F3, F5 and F6 are where a live problem tests more than your calendar | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise |
| Skeptic | Quiet probing of gaps: no team led, no in-app-purchase game, one calendar against two | Highest, 5 questions. Same prior, and F4 and F5 carry limits you stated yourself | Rehearse the likeliest objection until it's boring. Say the limit plainly, then give a plan in the future tense |
| Data-Driven Prober | Reads each CV line, goes two levels deeper | Medium, 3 questions. F7, F2 and F6 are short claims, and short claims invite "walk me through it" | Know what you can and can't say about how numbers were counted, and say so when you don't know |
| Pressure | Time-boxed, devil's advocate, "how much was actually you" | Medium, 3 questions. A head of function may test composure on the gap in F4 | Pause, restate, hold your actual sentence through two follow-ups, concede specifically |
| Conversational | Friendly opener, "walk me through the journey" | Medium, 3 questions. Casual answers are still scored | A 90-second arc from your own sentences only |
| Values / Behavioral | Scenario probes on past behaviour | Low, 2 questions. No values round is documented here | Where none of your sentences carries a story, use the scaffold and its honest branch |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles both want the same engineering release window next month. How do you decide whose event goes in?" | CASE | [generic] | Think aloud: what you need to know about each event, the objective, the options, what you'd ask each team, and how the loser is told and the decision recorded. Challenge one premise, such as whether the window is really fixed. No claim about your past | F3's two-title calendar. CASE because it tests structure; generic because it's a pattern, not a fact about Saltmarsh |
| A2 | "An event's player retention came in well below plan. Diagnose it. What do you need to know first?" | CASE | [generic] | Clarify what the metric is and what plan it was measured against, split the players into groups, list hypotheses (content, timing, a technical issue, communication), name the data each needs, say what you'd do first. Say the framework aloud. No claim about your past | F7 and F5 are where retention and the review meet. CASE because it's a live diagnosis |
| A3 | "You're designing the post-event review for a two-week event. What goes on page one?" | CASE | [generic] | Say what the review is for and who reads it, which few KPIs and who agrees their definitions beforehand, how results compare to plan, and which decisions come out of it. Where you don't know which KPIs the studio tracks, say you'd ask | F5 is the requirement. CASE because it asks you to build the artifact the JD says the role owns |
| A4 | "An update's art lands three days late and community has already announced the date. Walk me through the next 24 hours." | CASE | [generic] | Clarify what's late and what it affects, lay out options (cut, slip, partial release), say who you'd speak to first, what you'd tell players and when, and how the checklist is kept rather than skipped. A plan in the future tense | F4 and F6. CASE because it presses on all four disciplines at once |
| A5 | "Say aloud the opening three sentences of the brief you'd send design, art, engineering and community before an update." | CASE | [generic] | Lead with what ships and when, what each discipline owns, and what you need back and by when. Short sentences. If you have a real written brief or checklist you can share, offer it | F8 and F4. CASE because it makes the writing audible |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd coordinate design, art, engineering and community on every update, and you haven't led a team. How would you get those teams to move?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **The highest-ROI rehearsal.** Name the limit first: "I've never led a team." Then give a plan in the future tense, never as a past: what you'd agree with each discipline up front, how dates stay visible, how you'd handle a disagreement. Answer slot: the JD names the four disciplines, so expect a probe on whether you worked with any of them on a drop. If you did, say which and what you did; if that wasn't part of your work, say so plainly and stay with the calendar you ran. Follow-ups to rehearse: who you'd go to when one discipline says no, and how you'd know the plan was working. Hold the plan, concede the limit, never add a past | F4 is the likeliest place to be probed, and the limit is yours. JD because it scores the stated coordination requirement |
| B2 | "Which of the KPIs a post-event review reports would be new to you?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." and "Never led a team, and never worked on a game with in-app purchases." | State the limit plainly: "I've never worked on a game with in-app purchases." Then what your material carries, at its own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you can name a KPI you haven't worked with, say which and how you'd learn it, as a plan; if you can't name one before you know the list, say so plainly and ask which ones the team reports. Don't guess at Saltmarsh's list | F5 holds both the adjacent work and the stated limit. JD because the review and its KPIs are in the posting |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Selection scaffold: pick one real limit from the snapshot, say it plainly, and give a first-month step as a plan. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | The standard Skeptic opener. F1, F3, F4 and F5 are where an honest answer sits |
| B4 | "This role runs calendars for two titles at once. How would you keep them from colliding?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start from the quote at its own scope, then a plan in the future tense: one shared view of both calendars, each event's dependencies, a rule for conflicts, who you'd bring in. Answer slot: if you've ever kept more than one calendar from colliding, say how; if not, say so plainly and stay with the one you ran | F3 is the two-title gap. JD because the two titles are in the posting |
| B5 | "Why live operations, why here, why now?" | JD | [generic] | Selection scaffold: three short parts, each a reason you can stand behind. Prepare the "here" part from Saltmarsh's own pages before Friday, since I couldn't. If one part isn't clear yet, say so plainly and give the parts that are | The standard motivation probe in a Skeptic's register |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented each month." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: the numbers, monthly, to the studio head. Answer slots, each in your own words: how they were counted, what they were sensitive to, the assumption behind them you'd defend least, and which part was yours. If you don't know how they were counted, say so plainly; if someone else produced them and you presented them, say so | F7 is a short claim a prober goes two levels into. EXP because it tests what was yours |
| C2 | "Walk me through a typical week of the content-drop calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F2: weekly, content drops, the main title, two years. Answer slot: the JD says plan and run, so expect a probe on planning. If planning was yours, say how you decided what went in which week; if you ran what others planned, or there was no formal planning step, say so plainly and describe how you ran it | F2 and F3. EXP because it tests whether the claim survives a walk-through |
| C3 | "Tell me about the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6: you wrote it and QA still uses it. Answer slot: expect a probe on its contents. If you decided what went on it, say how; if the contents were set elsewhere, or came from a template, say so plainly and describe what the checklist does | F6. EXP because a prober reads each CV line |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has led a live-ops team?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate. Hold only the first quote: "I ran the weekly content-drop calendar for our main title for the last two years." Concede one limit specifically: "I've never led a team." Hold through two follow-ups by returning to the calendar, never by adding to it. Don't claim you'd outperform anyone | F4 is the limit. Pressure because it tests composure on a stated gap |
| D2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate. Hold the sentence as you said it. Answer slot: if parts of the calendar were yours to set, say which; if others set parts, or you ran what you were given, say so plainly and return to what you ran. Hold through two follow-ups, then concede the specific part that wasn't yours | F2 and F3. EXP because attribution is what's scored |
| D3 | "If you had half the time on your release checklist, what would you cut?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Pause. The position you hold is the sentence: "I wrote the release checklist our QA team still uses." Answer slot: if you've made that trade-off, say what and why; if you haven't, say so plainly and say what you'd ask QA before cutting anything, as a plan. Hold through two follow-ups | F6. Pressure because the question forces a trade-off |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are those four sentences, in your order and your words, with nothing added between them. Close with why this role, in one sentence of your own. Answer slot: if the move into live operations has a reason you can state plainly, say it; if it doesn't yet, say so and give what draws you to this role | F1 to F7 are the whole arc. EXP because the biography question is scored for economy |
| E2 | "What are you actually playing and following in live-service mobile these days?" | JD | [generic] | Selection scaffold: pick a title you really play and one specific thing about how its events work that you noticed. Say only what you actually did. If nothing comes to mind, say so plainly, then say what you'd study before day one | A casual question on the core topic of the job, and still scored |
| E3 | "Tell me about a time you worked with QA on a release." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6: you wrote the checklist and QA still uses it, which is all the quote states. Answer slot: if a particular release comes to mind, say what happened and what part was yours; if none does, say so plainly, then give the checklist as you wrote it, or how you'd work with QA | F6 is the QA tie. The JD's QA line raises this question |

### F. Values / Behavioral

No values round is documented for this interview and I read no published values, so these two are the persona's own stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment the message landed, and a relationship intact afterwards. Your one nearby sentence, "Presented the monthly retention numbers to the studio head.", doesn't say whether any numbers were unwelcome. If a time comes to mind, tell it; if none does, say so plainly, then give that sentence at its own scope, or how you'd handle it | F7 is the nearest evidence |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake and a decision you made, and say what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | No fit row carries this ground |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | B3, E1 |
| "experience running a content calendar" | C2, D2 |
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B4, C2 |
| "coordinate design, art, engineering and community teams on each update" | A4, A5, B1 |
| "own the post-event review and the KPIs it reports" | A3, B2, C1 |
| "manage the release checklist with QA" | C3, D3, E3 |
| "comfortable with player-retention metrics" | A2, C1 |
| "clear written communication" | A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do the two titles' calendars get negotiated today, and who decides when they collide?" | It shows you're already thinking about collisions, and asks about process |
| R2 | "What does a good post-event review look like to you, and what has one changed recently?" | It speaks to the head of the function in the function's own artifact |
| R3 | "Which of the four disciplines is hardest to keep in step on an update, and why?" | It asks what coordination really costs, from someone who has seen it |
| R4 | "How is a new producer expected to split time across the two titles in the first 90 days?" | It signals you're planning the first quarter |
| R5 | "What would tell you in six months that this hire was the right call?" | It asks for the scoring sheet directly |
| R6 | "How does the release checklist work with QA today, and what would you want changed?" | It opens the checklist conversation on their ground without asserting anything about it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F4 | The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F5 | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |
| Planned and ran live events for two titles | Inflated form of F3 | F3's quote at its own scope. The material says one title's content-drop calendar |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The material says presented the numbers |
| Managed the release checklist with QA | Inflated form of F6 | F6's quote at its own scope. The material says wrote it, and the team still uses it |

## Sources

Provided documents: your message, containing the JD and your background. There was no CV file, recruiter guidance, interviewer profile or dossier.

Searches sent (all refused, nothing returned):

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy mobile games news` — refused
- `Tobias Wrenfield Saltmarsh Games` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved a values cheat sheet and the VAL themes |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved loop structure and persona weights, which rest on the relationship prior instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO bank, which is absent for that reason |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved an interviewer read and an interviewer-tied reverse question |
| 5. representative `Live Operations Producer` JD | skipped | Your pasted JD fixes the snapshot and the JD-tagged questions |

## Upgrade menu

- Saltmarsh's published values, interview process or strategy page, pasted in → a CO question, a values check, and persona weights read from a documented loop
- Tobias's public profile, talks or posts, pasted in → an interviewer read, persona adjustments and a reverse question tied to his own path
- Whether Tobias is your future manager, a peer or a skip-level → every persona weight recomputed
- The recruiter's prep note (focus areas, any announced exercise) → coverage of what they said will be asked, plus a build section for any deliverable
- Your written answers to the slots in B1, B2, C2 and C3 → F3, F4, F5 and F6 move from slots to quoted evidence and the guidance rebuilds on them
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), once searching is permitted → a strategy brief and the CO bank
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence, per-gap strategies and a ready objection list, none of which this pack needs to run

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep. I can also record the gaps this prep exposed in a `tuesday-dossier.md` for later sessions. If you grant write access, I'll save this pack as a file.

Is Tobias the person you'd report to, a peer on the team, or a skip-level? The answer reweights every bank. If the recruiter told you what he'll focus on, include that too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.