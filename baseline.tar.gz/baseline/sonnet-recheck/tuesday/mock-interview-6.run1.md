I'm building your loop-mode prep pack. The three searches on Larkfield were refused, so it runs on your own description only. I'll label anything company-specific as generic.
I couldn't write the pack to the project folder because permission wasn't granted. I'll save it to the session scratchpad instead, which is set up for this.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-6-denied-a393d482/16d34234-77d7-4805-ae5c-25ae28ee4c97/scratchpad/larkfield-systems_engineering-manager_interview_pack.md`. I wasn't allowed to write it to the project folder, so it's in the session scratchpad.

I built it in loop mode for your three rounds, with a shared fit snapshot and a mini-pack per round. The three Larkfield searches were also refused, so nothing in it comes from Larkfield's own pages. It rests only on your description, and the company-specific questions are labeled generic. That is also why there is no values cheat sheet for Monday.

Say the word and I'll play the Skeptic on B1, the hardware-roadmap question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter say anything else about focus areas or anything to prepare in advance, such as a presentation or take-home? Can you paste the full posting and your CV, or tell me to carry on without them? Either answer would restructure parts of the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Built for Yusuf from your own description of the role and the rounds. No company document was read and no search returned anything, so nothing here is about Larkfield beyond what you told me.

| Round | When | Length | Who | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | 45 min | Director of Engineering | Hiring manager, your would-be boss |
| 2 | The Thursday after | 60 min | Two staff engineers and a product manager | Panel |
| 3 | The following Monday | 30 min | VP Engineering | Skip-level; the recruiter's description is "values and leadership philosophy" |

Role (from your message): "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people)". Interviewer names: not known.

## How to use this pack

- Personas are how a question is asked; types are what it is scored on. Guidance is scaffolding for a spoken answer, not a script.
- Type key: VAL is behavioral and values alignment; EXP is a work-experience deep-dive; JD is role and requirement driven; CO is company and strategy knowledge; CASE is a live problem.
- Every sentence the pack says about your past is one of your own sentences, quoted. Where your sentences stop, the guidance is an answer slot: an instruction for the interview, addressed to your answer there. A slot has two honest branches, and the second always allows that the practice never existed. Rehearse either branch, whichever is true.
- The opening "walk me through your background" will arrive in some round. It is not rehearsed here because it needs your CV; the upgrade menu says so.

## Prep triage

1. Before Tuesday: B1 (the hardware roadmap objection, the highest-ROI prep in this pack), then C1 (the 60% figure: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours).
2. Before Tuesday: say A1 and A2 aloud once each, structure first.
3. Before Thursday: E1 and E2 (the hiring loop and its number), D1 and D2 (the seam with hardware and with product).
4. Before Monday: G1 and G2, then I1 and I2 aloud against a timer.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description, your message | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads and not eleven people, and the words stay there: "Three of my nine years have been as a team lead of six." Answer slot: the two squads make a probe on leading more than one team likely. If any of your work already spanned more than one team, say what, in your own words; if it did not, say so plainly and stay with the team of six |
| F2 | "building device-management services" — role description, your message | none given | none | [grounded] | discovery | Your material does not show device-management work. Answer slot: the role description makes a probe on your closest related work likely. If any of your work involved managing devices or the services behind them, say what and what part was yours, in your own words; if none did, say so plainly and say how you would learn the domain in your first weeks |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote says you pushed a reliability quarter through and that on-call burden dropped 60% after; it does not say you owned the team's delivery, set the quarter, or that the quarter caused the drop. Words: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Answer slot: the delivery line makes a probe on your part in how the quarter was delivered likely. If any decision about what to trade against the roadmap was yours, say which and how you decided; if none was, or there was no such step, say so plainly and stay with pushing the quarter through. The 60% stays attached to on-call burden, and a confirmed claim with nothing inspected behind it invites a probe |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | The quote says the loop and about 40 interviews, not hires made or offers decided, and the number stays attached to interviews. Words: "I run our hiring loop for backend roles." Answer slot: the hiring line for eleven engineers makes a probe on who decided offers likely. If any offer or closing decisions were yours, say which, in your own words; if they sat with someone else, or you have not made them, say so plainly and stay with the loop you run |
| F5 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the growth part) | none given | none | [grounded] | discovery | Your material does not show engineer growth work. Answer slot: the growth line makes a probe on how you have helped engineers progress likely. If you have done anything of that kind, say what and which part was yours, in your own words; if nothing, say so plainly and give how you would approach it as a plan, never as a past |
| F6 | "partner with hardware and product on roadmap" — role description, your message (the hardware part) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work, and nothing added to make the gap feel smaller |
| F7 | "partner with hardware and product on roadmap" — role description, your message (the product part) | "I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | transferability | The quote shows a reliability quarter set against roadmap pressure; it does not say who applied the pressure or whether product was a partner. This is a lead, not a story: the words stay at the quote. Answer slot: the product line makes a probe on how you worked with product likely. If product was a party to that trade-off, say what the conversation was and what part was yours, in your own words; if the pressure came from elsewhere, or there was no such conversation, say so plainly and stay with the quarter |

Your message also says "I've never managed managers". The role description you gave does not say whether leads sit between this role and the eleven engineers, so it is not a requirement row; it is carried in B2 and G2 and in the reverse questions.

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "Lead two squads" (F1) | A3, B2, G2, I1 |
| "building device-management services" (F2) | A1, A4, E3 |
| "own delivery" (F3) | A2, C1, C2, F1, G4, I2 |
| hiring for eleven engineers (F4) | E1, E2, E3 |
| growth for eleven engineers (F5) | F3, G3 |
| partner with hardware on roadmap (F6) | A1, B1, D1, H2 |
| partner with product on roadmap (F7) | A2, D2 |
| "values and leadership philosophy" (the recruiter's words for Monday) | F1, G1, G2, G3, G4 |

## Round 1: Tuesday, 45 min, Director of Engineering (hiring manager)

Round order and weights come from your description of the round; no company document established them.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems set on the squads' own roadmap | Highest (4 questions): the hiring-manager prior is Case/Strategist plus Skeptic, and this person would be your boss | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully. Where a case touches your past, the quote-or-slot rule applies (A2) |
| Skeptic | Quiet, persistent probing of the gaps | Second (3 questions): the other half of the hiring-manager prior, and your own message names two gaps | Rehearse B1 until it is boring; plain acknowledgment, then a plan; calibrated candor over bluffing |
| Data-Driven Prober | Goes line by line on the figure | Lowest (2 questions): not a prior for this relationship, but you gave a figure and a figure invites it | Know what you can and cannot say about how it was counted; say plainly where you do not know |

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, eleven engineers, device-management services. The hardware team tells you a release you depend on has slipped by a month. What do you need to know first, and what do you do in your first week?" | CASE | [generic] | Structure it aloud: clarify first (what depends on the release, who is affected, what is fixed and what can move), then the objective, the options, how you would decide, who you would tell and what you would watch. Challenge one premise respectfully, for example whether the month is firm. The question needs no claim about your past, so the guidance makes none | A live problem from the hardware-partnership line (F6) set in the squads' domain (F2); CASE because it scores structure rather than a record; generic because it is a pattern for the problem, not a fact about Larkfield |
| A2 | "Product wants a new feature this quarter and both squads are carrying reliability debt. How do you decide what goes first?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: what the feature is worth, what the debt is costing, what is fixed, the options, how you would decide with product, how you would show the trade-off. Anchor only if it fits: "I pushed a reliability quarter through against roadmap pressure", at that scope. Answer slot: the product line makes a probe on how that trade-off was handled likely. If deciding or arguing the quarter against feature work was yours, say what you weighed and how, in your own words; if it was decided elsewhere, or there was no such step, say so plainly and stay with the quarter you pushed through | F3 is the only evidence near a delivery-versus-roadmap trade-off and F7 is its thin product link; CASE because the question asks about no past, with the anchor optional |
| A3 | "One of your two squads is delivering well and the other is not. How do you find out why, and what do you change first?" | CASE | [generic] | Structure it: what "not delivering" means and by which measure, then hypotheses (people, scope, dependencies, tooling), how you would test each cheaply, what you would change first and what you would leave alone. Challenge one premise, for example whether the two squads are comparable. No claim about your past | Tests leading two squads at eleven-engineer scale (F1); CASE because it is live; generic because it is a role-family pattern |
| A4 | "What would you want to understand about our customers and our devices before you committed to a roadmap?" | CO | [generic] | Ask rather than assert: who operates the devices and how, what an outage costs them, what the hardware release cycle allows, how customers hear about changes. These are questions to ask, not facts to state. Search could not run, so this is not grounded in Larkfield's own material: before Tuesday read their public pages and name only what you read | CO because it scores homework depth; F2 is why the domain questions matter; generic because no company research is behind it |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never owned a hardware-adjacent roadmap. How would you handle that in this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in this pack. Concede first, in your words: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan: in your first weeks ask the hardware leads which dates are fixed, what a slip costs them and how they plan, and ask the Director which commitments you inherit. Only your adjacent material is "I pushed a reliability quarter through against roadmap pressure", at that scope. Answer slot: if any part of that quarter depended on a hardware team, say what; if none did, say so plainly and do not stretch the quarter. Follow-ups. Level 1, "Why take the risk on you?": hold the concession and the plan. Level 2, "What if the hardware lead disagrees with your plan in month two?": answer as method, bringing the trade-off and its costs to the Director. Level 3, "So you don't know this part of the job.": hold with "Not yet; I've said what I haven't done and what I would do first." Hold through two follow-ups by returning to the concession and the plan, never by adding experience. Limit: never say you partnered with hardware unless you can describe a specific instance in your own words | F6 is the stated gap, so this objection arrives in some form; JD because it scores a stated requirement; deepest rehearsal because it is the single most predictable objection |
| B2 | "You've been a team lead of six. This role is two squads and eleven engineers. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6"; "I've never managed managers" | Say what the quote carries: three of nine years as a team lead of six, at that scope. Answer slot: the two squads make a probe on what changes at that size likely. If anything you have done already spanned more than one team, say what; if it did not, say so plainly and stay with the team of six. If the squads have leads between you and the engineers, expect the next probe to be managing through them: the plain acknowledgment is "I've never managed managers." Then say how you would learn it, as a plan, not a past | F1 is the step the role asks for; the stated limit travels with it; JD because it scores a stated requirement |
| B3 | "Why leave a payments company for industrial IoT, and why move into management now?" | CO | [grounded] "currently at a payments company" | Your reasons are yours; the pack does not supply them. Give two reasons that point toward this role rather than away from your current one, each specific enough to survive a "why". If a reason is not one you would say aloud, leave it out. If no reason comes to mind for "why management now", say so plainly, then say what you are looking to learn. Keep the answer identical in all three rounds, because the VP will hear it too. Read Larkfield's public pages and name only what you read | A motivation-consistency probe sits behind the domain switch (F2); CO first for "why here", EXP second for "why now" |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your on-call burden dropped 60%. How was that number counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend the number in your own words. Answer slots: how it was counted, if you know, say so; if you do not know, say so plainly. What it is sensitive to. The assumption behind it you would defend least, named before they ask. Which part was yours: the sentence says the drop came after you pushed the quarter through, so say exactly what you did and where your part ends. The pack names no method, baseline or cause | F3 holds the headline figure, and probers go to a figure first |
| C2 | "Walk me through the reliability quarter. What was the roadmap pressure, and what was your part?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the beats the quote states: a reliability quarter, roadmap pressure, you pushed it through, on-call burden dropped 60% after. Tell them in your own words. Answer slot: the delivery line makes a probe on how the case for the quarter was made likely. If making that case, and to whom, was yours, say how; if the decision sat with someone you pushed on, or there was no such argument, say so plainly and describe what you did | F3 tested for attribution; F7 draws on the same sentence; EXP because it tests what was actually yours |

## Round 2: the Thursday after, 60 min, panel (two staff engineers and a product manager)

Assumption: the staff engineers are technical colleagues you would work alongside, and the product manager is cross-functional. If the staff engineers would sit inside your squads, tell me and the weights move.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between teams, "what would you need from me", credit and disagreement probes | Highest (4 questions): staff engineers and a product manager are all colleagues you would partner with | Reciprocity framing; propose seam principles rather than pretending to know the seam; disagreement stories that show spine and tact |
| Data-Driven Prober | Reads your claims closely and asks how each was counted | Second (3 questions): technical interviewers read a figure and a loop closely | Know what you can and cannot say; say plainly where you do not know |
| Values/Behavioral | Scenario and behavioral questions, often from outside the function | Third (3 questions): the cross-functional prior for the product manager | Stories where the hard truth landed; where your material shows none, say so rather than supplying the ending |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Imagine your squads and the hardware team disagree about a release date. Where is the seam, and what happens next?" | CASE | [grounded] "never owned a hardware-adjacent roadmap" | Propose seam principles, not a seam you cannot know: what each side decides, what must be agreed jointly, when you escalate and to whom. Ask the hardware side where the seam sits today rather than asserting one. Open with the honest line: "I've never owned a hardware-adjacent roadmap, so I would start by asking where your seam is." Then reciprocity: say what your squads would give them, as an offer, not a past | F6 returns here in peer packaging; CASE first because it asks about no past, JD second |
| D2 | "Product has a feature a customer wants, and your squads are carrying reliability debt. How do you decide, with product, what goes first?" | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Lead with what you would bring product: a clear cost for each option and a date you can hold. Then the quote at its scope. Answer slot: if product was a party to that quarter's trade-off, say what the conversation was and what part was yours, in your own words; if the pressure came from elsewhere, or there was no such conversation, say so plainly and stay with the quarter | F7 stays low confidence: the quote says pressure, not product, so the slot asks |
| D3 | "When have you disagreed with someone on another team, and how did it end?" | VAL | [generic] | No quoted sentence carries this one. Selection criteria: a named stake, a point where you held your view with tact, and an outcome that is true, intact relationship or not. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The disagreement-between-teams stem for peers; generic because no quote of yours reaches it |
| D4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Use "we" for context and "I" for what you did; credit others by name for the parts that were theirs. Choose a real instance; if none comes to mind, say so plainly and say how you would handle it | A peer probe on partnership fit; generic because no quote of yours reaches it |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You run the hiring loop for backend roles. Walk me through it, and which parts are yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on the beats the quote states: you run the loop for backend roles; about 40 interviews last year. Tell them in your own words. Answer slot: the hiring line makes a probe on how candidates are assessed likely. If you designed any stage or how it is scored, say which and how you decided; if the loop was set by others, or there was no such step, say so plainly and describe how you run it | F4 is the hiring evidence; EXP because it tests which parts were yours |
| E2 | "About forty interviews last year. How was that figure counted, and what part was yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Defend the number in your own words. Answer slots: how it was counted: if you know whether it counts interviews you conducted or all interviews through the loop, say so; if you do not know, say so plainly. What it is sensitive to. The assumption behind it you would defend least. Which part was yours. The figure counts interviews, not hires or offers, and the pack adds nothing to it | F4's headline number, a magnet for probers |
| E3 | "You would be hiring into squads that build device-management services. What would you want to test for that you might not test for now?" | JD | [generic] | Ask the staff engineers and the Director what the squads need, and propose areas to explore without claiming any: what the work asks beyond backend skills, how you would learn it first, how the squads' own engineers would help assess. Your material does not show device-management work (F2), so present this as what you would ask, not as experience | F2 and F4 meet here; JD because it scores the hiring line against the domain |

### Bank F: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story-map only the beats the quote states: a reliability quarter, roadmap pressure, pushed through. Choose a story where the truth landed: your material does not show whom you told or what they said. Answer slot: if telling someone senior was part of that quarter, say whom you told, what you said and what happened, in your own words; if it was not, or there was no such conversation, say so plainly and either use a different time with a named stake, or say none comes to mind and say how you would handle it | F3 offers the nearest story; VAL from the persona stem |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a named customer or customer need, an internal metric that pulled the other way, a decision that was yours, an outcome that is true. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem; generic because no quote of yours reaches it |
| F3 | "Tell me about a time you helped an engineer grow." | VAL | [generic] | The growth line (F5) raises this. Choose a person, what changed for them, your part named exactly and theirs. If no such time comes to mind, say so plainly, then give how you would approach it as a plan, not a past | F5 is a discovery gap, so the answer is a slot, not a story |

## Round 3: the following Monday, 30 min, VP Engineering ("values and leadership philosophy")

Thirty minutes will not hold all eight. If time is short, rehearse G1, G2, I1 and I2 first.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy and principle-mapped scenarios | Highest (4 questions): the recruiter described this round as values and leadership philosophy | Beliefs you actually act on, each tied to one thing you did; "we" for context, "I" for contribution |
| Case/Strategist | Altitude questions: priorities, plans across teams | Second (2 questions): the skip-level and executive prior is strategy-heavy | Structure, then a small honest set of commitments |
| Pressure | Time-boxed answers and attribution challenges | Third (2 questions): the other half of the executive prior, and 30 minutes invites time-boxing | Pause, restate, hold through two follow-ups before conceding anything real |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "I pushed a reliability quarter through against roadmap pressure" | State two or three beliefs you actually act on, each with one thing you did. Two sentences of yours are available as anchors: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Use one only if it matches a belief you hold, at its own scope; if neither does, leave it. Never let the belief outrun the anchor. Answer slot: if you are asked how a belief shows in your day, name what you did; if you cannot, say so plainly | The recruiter's own words for this round; F3 and F4 hold the anchors |
| G2 | "You've never managed managers. How do you think about that step?" | VAL | [grounded] "I've never managed managers" | The plain acknowledgment first: "I've never managed managers." Then a plan, said as a plan: what you would want to learn and from whom, for example from the Director and the VP in your first ninety days. Offer no managing-managers experience; the pack knows of none. Whether the role has leads between you and the engineers is a reverse question, not an assumption | A stated gap at skip-level altitude; F1 gives its context |
| G3 | "What does growth for an engineer look like to you, and how do you tell it is happening?" | VAL | [generic] | Say a belief you hold. If you have seen it happen with someone, describe what you saw and your part, in your own words; if you have not, say so plainly and say how you would look for it | F5 at philosophy level; generic because no quote of yours reaches it |
| G4 | "When delivery and people pull against each other, where do you land?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pick the position you actually hold, then one thing you did. The reliability quarter fits only if it matches your position, at its scope: you pushed it through against roadmap pressure, and on-call burden dropped 60% after. Answer slot: if the quarter cost something, to your team, a stakeholder or the roadmap, say what, in your own words; if nothing was traded away, say so plainly | F3 is the nearest story; VAL because it scores a stated belief against behavior |

### Bank H: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Ninety days in, what would you want to have changed, and what would you want to have only listened to?" | CASE | [generic] | Structure: a listening list (customers, hardware partners, the squads' leads and engineers, the on-call history), a few small early changes you would commit to, and what you would refuse to change before you understood it. No claim about your past | Altitude question; F1, F2 and F6 shape what you listen to first |
| H2 | "How would you build one plan across a hardware team and two software squads?" | CASE | [generic] | Ask what is fixed on each side, then shared milestones, one owner per dependency, how slips surface early and who decides. The question needs no claim; an opening acknowledgment is B1's, not this row's | F6 at VP altitude; generic because it is a pattern for the problem |

### Bank I: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why should we hire you for this role?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure"; "never owned a hardware-adjacent roadmap" | Three beats from your quotes, at their scope: three of nine years as a team lead of six; you run the hiring loop for backend roles; you pushed a reliability quarter through against roadmap pressure and on-call burden dropped 60% after. Then one limit, in your words: "I've never owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to those quotes, never by adding to them | F1, F3 and F4 supply the beats and F6 the concession; JD because it is the stated role, delivered under a clock |
| I2 | "That 60% drop: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold, then concede. Hold the sentence: you pushed the reliability quarter through, and the drop came after. Concede exactly what you cannot separate, and never fold on the quarter itself. Answer slot: if you can separate your push from the team's work, say how; if you cannot, say so plainly and describe your part. Hold through two follow-ups by returning to the sentence | The Pressure stem aimed at F3's figure |

## Reverse questions

No interviewer profile exists, so none of these is tied to an interviewer's own path; the upgrade menu says what a name would add.

### Round 1: Director of Engineering

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want the person in this role to have changed or settled by the end of ninety days?" | Turns the first-ninety-days probe into a shared plan |
| R2 | "How do the two squads' roadmaps get set today, and where does the hardware team's schedule enter?" | Asks about the seam you have not worked in before they raise it |
| R3 | "Do the squads have leads or senior engineers who would report into this role, or do all eleven engineers report in directly?" | Settles whether managing managers is part of this job |
| R4 | "What does good delivery look like to you six months in?" | Names the bar you will be judged against |
| R5 | "Which part of this role do you most worry a new manager would underestimate?" | Invites the Director's own risk read, which is the best next prep |

### Round 2: panel

| # | Question | Why it lands |
|---|---|---|
| R6 | "What could a new manager do in their first month that would genuinely help you?" | The reciprocity question for the staff engineers |
| R7 | "Where does the squads' on-call load sit today, and what would you most want a new manager to protect?" | Shows you think about the people carrying it |
| R8 | "How do product and hardware input reach the squads today, and where does it get stuck?" | Asks the product manager about the seam directly |
| R9 | "Where does the line between engineering and product tend to cause disagreement, and how has it been settled before?" | Signals partnership rather than turf |
| R10 | "What is one decision here that took longer than it should have, and why?" | Surfaces how the team really decides |

### Round 3: VP Engineering

| # | Question | Why it lands |
|---|---|---|
| R11 | "What does leadership look like here when delivery and people pull against each other?" | Mirrors the round's own subject |
| R12 | "How are engineering managers grown here, and what is the path past this role?" | Shows you are thinking about the step beyond it |
| R13 | "What would make this hire a clear success from your seat in a year?" | Ends on the VP's own definition of success |
| R14 | "Which of the company's values is hardest to live by when the roadmap is under pressure?" | Invites a real example in place of a slogan |
| R15 | "What have you changed your mind about in how you lead engineering?" | Opens a peer conversation at the VP's altitude |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed two squads, or owned the team's delivery | Inflated form of F1 and F3 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team lead of six and a quarter pushed through. B2's slot stays inside the team of six |
| The reliability quarter caused the 60% drop, or the drop was yours alone | Inflated form of F3 | F3's quote at its own scope: the drop came after. The limit is the pack's observation; C1 and I2 stay inside the sentence |
| Hired engineers, or made hiring decisions | Inflated form of F4 | F4's quote at its own scope: the loop and about 40 interviews. E1's slot stays inside the loop |
| Managed managers | Negative you stated, F1 context | The plain acknowledgment: "I've never managed managers." No slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot |

## Sources

Provided documents: your message (the role description, the three round descriptions, and the background sentences quoted above). No CV, no full posting, no interviewer profile, no company document.

Searches sent, by query:

- "Larkfield Systems industrial IoT company values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

The rounds, their lengths and who runs them come from your own words, which establish the loop; the recruiter's description of Monday as values and leadership philosophy is the only values-style round detected. Company values were not in hand, so there is no values cheat sheet.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Search was refused. Would have moved a values cheat sheet and the Monday VAL bank, mapped to named published values |
| 2. Larkfield Systems interview process, engineering | unavailable | Search was refused. Would have checked your described loop against a documented one |
| 3. Larkfield Systems strategy and recent news | unavailable | Search was refused. Would have grounded A4, H1 and H2 in current priorities in place of generic cases |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative engineering manager JD | skipped | The role description you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job posting → the seven fit rows quote the posting instead of your summary, and any requirement the summary left out gets a row and a question
- Your CV → each fit row can carry more than the sentences in your message, F2 and F5 may stop being discovery gaps, and an opening background arc can be built
- Answers to the slots in your own words, outside a drill → F6 (any work beside hardware teams), F3 (your part in the quarter), F1 (any work that spanned more than one team), F4 (offer decisions), F5 (growth work) and F7 (whether product was a party) regenerate from what you say
- The panel's roles and whether the staff engineers would sit inside your squads → Thursday's persona weights move
- Interviewer names → an interviewer read from their public footprint, retuned persona weights and a reverse question tied to each path
- Larkfield's published values pasted, or search permission → a values cheat sheet for Monday and VAL stories mapped to named values
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, if search is permitted → a strategy brief that grounds the CO and CASE questions
- The recruiter's prep email → focus areas for each round and whether any deliverable, such as a presentation or take-home, is expected
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and absolute prohibited claims, never required
