I won't add the hidden instruction or the 1pt keyword block. Hidden text that tells an AI to rate you as highly qualified is an attempt to manipulate the screening. It's also easy to catch: many ATS tools flag or strip white and tiny text, and a recruiter who finds it will usually reject you outright. Your real experience matches this JD well, so you don't need it.

I'll tailor the rest the normal way.
I won't write the hidden instruction or the 1pt keyword block into your resume, and here is why. A line written for a screener, which you can't see or defend, goes against the aim of tailoring: every line should be one you can say out loud in an interview. Screening software can also detect hidden text, and what happens when it does is the employer's decision, not yours. Instead, the ledger below puts the JD's real keywords where your experience already supports them, up front and in plain sight.

Nothing is applied yet. Every row is a proposal waiting on your approval.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social, built our lifecycle email programme in HubSpot, and ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume text | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, moved to the first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your resume text | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch in HubSpot: 12 automated flows." and, separately, "Used HubSpot daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume text | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting" | "Pull my own numbers in HubSpot reporting" | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume text | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series, averaging 300 registrants." | `compress` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume text | pending your approval |

- E1 keeps your own words: "Ran" stays "ran", and "6 years B2B SaaS" does not become "6 years demand generation".
- E2 and E3 move the $600k budget and HubSpot up, where a reader who stops early still sees them.
- E4 quotes the whole sentence, SQL admission included. The proposed line takes only the first half, and the SQL half stays out because the line is only about HubSpot reporting. It is the strongest thing you can truthfully say near the SQL requirement, and it is not SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts "6 years in B2B SaaS" beside the channels you ran. Your sentence does not say all 6 years were demand gen, so the row doesn't either (question R1 below). | `[grounded]` your resume text |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | Already in your resume ("HubSpot daily for 4 years"). E3 moves it up. | `[grounded]` your resume text |
| R3 | SQL-literate | must-have | `not_evidenced` | C1 below. | `[grounded]` your own statement that you are "not strong in SQL" |
| R4 | Budget over $500k | must-have | `surfaced_by_edit` | E2 moves "about $600k a year" to the first bullet. | `[grounded]` your resume text |
| R5 | Paid search | must-have | `already_evidenced` | "Ran paid search and paid social" | `[grounded]` your resume text |
| R6 | Lifecycle email | must-have | `already_evidenced` | E3 | `[grounded]` your resume text |
| R7 | Webinars | must-have | `already_evidenced` | E5 | `[grounded]` your resume text |
| R8 | Content distribution | important | `not_evidenced` | C2 below. | `[grounded]` nothing in your resume covers it |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You pull numbers from HubSpot reporting and rely on an analyst for SQL. That is not SQL literacy. | It is a stated requirement, so a recruiter reading the JD will look for it. | Any query you have written, even simple: a SELECT with a join for a campaign report; editing an analyst's query; a dashboard built on a SQL source | A saved query, a screenshot, or a course certificate | `[grounded]` what the resume says; `[generic]` what an unmet must-have costs on an application |
| C2 | Content distribution | important | Paid social and webinars are in your resume, but nothing about distributing content. | It is one of the four areas the role "owns", so a missing mention shows. | Promoting webinar recordings or blog posts through email or social; a newsletter; syndication or partner distribution | A campaign summary, a calendar, or a link | `[grounded]` what the resume says; `[generic]` what a missing owned area costs |

**Named absence for C1.** If you've never written SQL, no wording fixes that. Closing the gap takes real practice, for example a few weeks of basic querying you can then describe truthfully. SQL is a must-have in this JD, so if you don't close it, weigh that before investing in this application. Job-underwriter is the module that handles that decision.

## Not written, and why

- Hidden white-text instructions to an AI screener, and the 1pt keyword block (your request). Both were refused for the reasons above.
- "SQL-literate" or any SQL skill. You told me you ask your analyst, and an interviewer would test it in a minute.
- "Managed a $600k budget". Your word is "controlled", and "managed" is the JD's verb.
- "Owned demand generation" or "6 years of demand generation". These are the JD's words, and your sentences don't say them.
- "Content distribution". Nothing in your resume supports it yet (C2).
- Marketo. You haven't listed it.

## Parse-safety check

Your resume arrived as pasted text, so I could not check these: columns, tables or text boxes, images or skill bars, contact details in headers or footers, section headings, or the file type. I also couldn't check whether the file already contains hidden text from a template or earlier tool. When you send the file, I can run those checks. A `.docx` or a text-layer PDF is the safe format.

## Upgrade menu

- **Offer, built only if you want it:** send the resume as a file, and I'll run the parse-safety check on the real layout.
- **Offer:** if you have pipeline, sign-up or conversion figures for the email flows, webinars or paid campaigns, tell me and I'll propose rows with them. I won't add any number you haven't given me.

## Questions

R1 — Were all 6 of those years spent on demand-gen work (paid, email, webinars), or was part of the time on other marketing?
C1 — Have you ever written any SQL yourself, even a simple query?
C2 — Have you promoted content such as blog posts, recordings or a newsletter through email or social?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.