I couldn't save the pack as a file because the write was declined, so the full pack is below. The web searches were also declined, so nothing in it comes from research on Stripe. I had no CV, job description or interviewer information either, which makes it a rehearsal frame and not a personalized pack.

# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round (sessions, interviewers and format not stated). **Interviewer:** unknown.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you did your homework on the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem |

Guidance is scaffolding, not a script. Each guidance cell tells you what to pick from your own history and gives an honest fallback if nothing fits. Nothing here says what you did, because I have no material about that.

## Fit snapshot (worksheet)

The requirements are typical for the role family, written as plain prose and labeled generic. None is quoted from a Stripe posting. Swap in the real JD lines when you have them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a recurring cross-functional launch or planning process | none given | none | [generic] | discovery | Strong evidence is a named process you ran, who it involved, and how often. Selection scaffold: pick the process with the clearest stakes and an outcome you can describe in your own words. If no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F2 | Define and track metrics for product or launch health | none given | none | [generic] | discovery | Strong evidence is a metric you defined or tracked, with how it was counted. Selection scaffold: pick one metric you can explain end to end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would measure first |
| F3 | Communicate clearly to senior, many-stakeholder audiences | none given | none | [generic] | discovery | Strong evidence is a written update or review you produced and who read it. Selection scaffold: pick a communication where the audience had to decide something. If none comes to mind, say so plainly, then give the nearest thing your material does carry |
| F4 | Improve a process or drive adoption of a tool | none given | none | [generic] | discovery | Strong evidence is a change you drove and what happened to uptake. Selection scaffold: pick a change people could have ignored. If none comes to mind, say so plainly, then describe how you would approach adoption |
| F5 | Work across product, engineering and go-to-market without direct authority | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team and how it resolved. Selection scaffold: pick one where you did not control the outcome. If none comes to mind, say so plainly, then give the nearest thing your material does carry |
| F6 | Turn customer or field feedback into input for product decisions | none given | none | [generic] | discovery | Strong evidence is a feedback channel you used and a decision it informed. Selection scaffold: pick a case where feedback and an internal metric pointed different ways. If none comes to mind, say so plainly, then give the nearest thing your material does carry |

## Persona table

The weights are blended. You said "final round" but not who you are meeting or how many sessions there are, and I found no loop source for Stripe. The fallback is the Generic archetype (screen, hiring manager, panel) with flat weights. Adjust them if you know the interviewers.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case / Strategist | Live problems set in the role | High: finals usually test structure | Clarify, objective, segmentation, approach, metrics, risks; think aloud | A (4) |
| Skeptic | Probing gaps and "why this role, why now" | High: finals derisk motivation and gaps | Rehearse the most predictable objection until it is boring | B (4) |
| Peer Evaluator | Seam-splitting between teams | Medium: operations roles sit between teams | Reciprocity framing; propose seam principles | D (3) |
| Data-Driven Prober | Asks how numbers were counted | Medium: metrics are central to the role family | Know how each number you quote was counted, or say you do not | E (3) |
| Values / Behavioral | Scenario probes on past behavior | Medium: no values round established for this loop | Pick your own stories; "we" for context, "I" for contribution | C (2) |
| Pressure | Interruptions, time-boxing | Medium: tests composure | Pause, restate, hold through two follow-ups | F (2) |
| Conversational | Friendly openers that are still scored | Medium: nearly every loop has one | A pre-scripted 90-second arc | G (2) |

## Question banks

Every question is `[generic]`: none is built on your material or on Stripe research. **B1 is the highest-ROI rehearsal**, because "where would you be weakest on day one?" will be asked in some form in a final round.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A cross-functional launch is two weeks out and three teams disagree about what ready means. Walk me through your first two days." | CASE | [generic] | Clarify first: who decides, what is fixed. Then objective, options for what ready could mean, one shared definition, risks, and how you would check it held. Think aloud and challenge one premise respectfully | Tests F1 and F5 as a live decision |
| A2 | "Adoption of a new internal planning process is low after a quarter. Diagnose it." | CASE | [generic] | Ask what low is measured against and who was meant to adopt. Segment by team and step. List hypotheses (awareness, effort, incentive, fit), say what data separates them, and end with what you would try first | Tests F4 and F2 |
| A3 | "How would you decide which launches get a full operational plan and which get a light touch?" | CASE | [generic] | Name criteria (risk, reach, reversibility, dependencies), how you would weigh them, and what you would want to know first. Close with how you would review the rule after a quarter | Tests F1 and F2 on prioritization |
| A4 | "A key launch-health metric dropped 20% week over week. Diagnose it." | CASE | [generic] | Check the measurement first (definition, pipeline, instrumentation), then segment, then look for product or behavior changes. Say which hypothesis you test first and why | Tests F2; persona stem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick the row of F1 to F6 your own material supports least. Name it, say why, and give a 30-day ramp plan. Hold through two follow-ups, conceding specifically what you do not yet know. If none comes to mind, say so plainly, then name where your material is thinnest and how you would learn it | Arrives in some form in a final round; JD because it scores the listed job |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Give your own reasons in two or three sentences, then one piece of work you chose to do. If no example comes to mind, say so plainly and say what draws you to the work | Motivation consistency is the Skeptic's core test |
| B3 | "What would you need to learn fastest to be effective here?" | JD | [generic] | Name one or two things, link each to an F row, and say how you would learn them in the first month | Pairs with B1; a concrete plan is the signal |
| B4 | "Why this company rather than another place you could do product operations?" | CO | [generic] | Read the company's official pages yourself and use only what you read. Do not recite facts from memory; this pack holds none. If your reason is thin, say what you have seen and what you still want to find out | CO scores homework depth; no research ran |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften it, and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F3; persona stem |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a case where the two pointed different ways and say what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | Tests F6; persona stem |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles instead of claiming to know the seam: who owns the decision, who owns follow-through, how disagreements escalate. Say what you bring to their team | Tests F5; persona stem |
| D2 | "What would you need from me to succeed?" | JD | [generic] | Two concrete asks (access, context, a decision rhythm) and one thing you offer back | Tests F5 and reciprocity |
| D3 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle in a sentence, then an example only if one from your history fits. If none comes to mind, say so plainly and stay with the principle | Tests F5; persona stem |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick one number you have reported to leadership. Walk me through how it was counted." | EXP | [generic] | Pick a number you can explain end to end: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly, then say what you do know | Tests F2; persona stem |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they do, in your own words. If none comes to mind, say so plainly and say how you would find it | Follow-up to E1 |
| E3 | "How did you check that the data behind a metric you relied on was right?" | EXP | [generic] | Pick a metric where you looked at the source. If you took it on trust, say so plainly and say what you would check now | Tests F2 on validation |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, give two points that are true for you and tied to F rows, hold through two follow-ups, and concede specifically what you do not know about the team | Persona stem; tests composure |
| F2 | "That result: how much of it was actually you?" | EXP | [generic] | Say what you did in the first person and what the team did as "we". If part was not yours, say so plainly | Persona stem; follows any story you tell |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, two choices that shaped your path, why this role is next. Use only facts from your own CV | Tests F3; persona stem |
| G2 | "What are you actually playing with these days in the tools or methods the job description highlights?" | JD | [generic] | Name something you have actually used and what you learned. If nothing comes to mind, say so plainly and name the one thing you would try first | Casual questions on hot JD topics are still scored |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Recurring cross-functional process | A1, A3, B1 |
| F2 Metrics | A2, A3, A4, E1, E2, E3 |
| F3 Senior communication | C1, G1 |
| F4 Process improvement and adoption | A2 |
| F5 Working without authority | A1, D1, D2, D3 |
| F6 Customer feedback into product input | C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like in this role at 90 days, and who decides?" | Shows you think in outcomes and ownership |
| R2 | "Which part of the launch or planning process is most broken today?" | Invites candor and shows you can find the work |
| R3 | "How does this function work with product and engineering when priorities conflict?" | Probes the seam, which is the heart of the role |
| R4 | "What decision from the last six months would you make differently now?" | Opens a real conversation |
| R5 | "What do the strongest people in this role do that others don't?" | Tells you the bar and signals you want to meet it |
| R6 | "What could a new person do in their first month that would help your team?" | The reciprocity question; use it if the interviewer is a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None yet | No candidate material was supplied, so there is nothing to inflate or contradict | Every guidance cell is a scaffold ending in an honest branch; this fills in when you send a CV |

## Sources

Provided documents: none. Searches sent, all refused:

- `Stripe operating principles values`: refused
- `Stripe interview process product operations manager final round`: refused
- `Stripe strategy 2026 news annual letter`: refused
- `Stripe Product Operations Manager job posting responsibilities requirements`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have given official value names for a values cheat sheet (section dropped) |
| 2. `Stripe interview process product operations` | unavailable | Would have established the loop and moved persona weights off the Generic archetype |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded a CO question in current strategy; B4 is generic instead |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have replaced the generic F1 to F6 with quoted lines |

## Upgrade menu

- Your CV → the `none given` cells become your quoted sentences, guidance becomes story-mapped, and the prohibited list fills in
- The job description text → F1 to F6 become real quoted requirements and JD questions become `[grounded]`
- Who you are meeting and how many sessions → persona weights are recomputed, and I can split the pack into per-session mini-packs
- The recruiter's prep email → any announced deliverable gets its own build section
- An interviewer's name → an interviewer read and a reverse question tied to their path
- Search permission → Stripe's published values, loop and strategy replace the generic banks and add a values cheat sheet

Say the word and I'll run a live drill as the Skeptic on B1, the question this pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, if you allow file writes.

1. Who are you meeting, your future manager or a peer, and do you know how many sessions the final has? The answer reweights every bank.
2. Can you paste the job description and your CV? Without them, every cell above stays generic, but I'll proceed without them if you'd rather.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.