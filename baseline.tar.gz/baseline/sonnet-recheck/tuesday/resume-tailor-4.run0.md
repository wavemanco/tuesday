I read this as a request to tailor your resume to the Ridgemount JD, so I ran the tailoring module. I only have your description of the resume, not the PDF. I quoted your own sentences from your message as the baseline, and I haven't changed a word of the resume yet.

## A correction before the edits

You think keyword matching is auto-rejecting you. The one source I can cite is a small vendor sample, not a representative study, and it points somewhere else:

- Content-based auto-rejection did exist but was uncommon: "AI/content auto-rejection configured: 8% of recruiters." and "We only saw 2 of 25 using it." (cite C25)
- Filters that do reject are mostly form questions: "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are the work-authorization, licence and location checks on the application form, not your resume.
- Match scores affect ordering more than rejection: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27)

So I can't tell you keywords are why you're rejected, and nobody can from 25 interviews. What I can do is make sure your real evidence is findable and survives parsing. I won't add a keyword you can't defend in an interview.

I also assumed every line you pasted is on your resume, and I treated the JD's flat tool list as `important` because it doesn't tier requirements.

## The edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." as its own bullet in Experience, directly under the pipeline bullet | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E2 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Kubernetes (proof-of-concept only), Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E3 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — moved to the first bullet under your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |

E1 and E2 keep "proof-of-concept" and "never went to production" because dropping the qualifier would turn a two-month trial into Kubernetes experience.

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | important | `surfaced_by_edit` | E1, E2. Proof-of-concept only, and the line says so. | `[grounded]` the PoC sentence; `[generic]` a PoC is weaker evidence than production use |
| R2 | AWS | important | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" as written. | `[grounded]` your description |
| R3 | Python | important | `already_evidenced` | "Bash and Python scripting" as written. The word is scripting, so I haven't written "development". | `[grounded]` your description |
| R4 | CI/CD (GitLab) | important | `not_evidenced` | The Jenkins pipeline in E3 is adjacent. No GitLab claim, and no "CI/CD" label on the Jenkins work, because you said "deploy pipeline". | `[grounded]` your description |
| R5 | Terraform | important | `not_evidenced` | Ansible config management is not Terraform. See C1 below. | `[grounded]` your description |
| R6 | Helm | important | `not_evidenced` | See C2 below. | `[grounded]` your description |
| R7 | Prometheus, Grafana, observability | important | `not_evidenced` | CloudWatch monitoring stays under its own name. See C3 below. | `[grounded]` your description |
| R8 | SRE practices | important | `not_evidenced` | See C3 below. | `[grounded]` your description |
| R9 | AWS EKS | important | `not_evidenced` | Named absence below. | `[grounded]` your description |
| R10 | ArgoCD, GitOps | important | `not_evidenced` | Named absence below. | `[grounded]` your description |
| R11 | Istio, service mesh | important | `not_evidenced` | Named absence below. | `[grounded]` your description |
| R12 | Vault | important | `not_evidenced` | Named absence below. | `[grounded]` your description |
| R13 | Go | important | `not_evidenced` | Named absence below. | `[grounded]` your description |
| R14 | "own platform reliability and developer experience" | must-have | `not_evidenced` | Maintaining about 30 Jenkins jobs is adjacent, but nothing you've described says you owned reliability or developer experience. | `[grounded]` your description |

Only AWS and Python are already on your resume as written. The rest is thin or missing. A tailoring pass can't change that.

## Recovery per gap

**Recall prompts (pending your approval).** These are for gaps where you may have something I can't see:

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | important | Ansible for config management and AWS services, with no provisioning tool named | The JD lists it by name, and Ansible alone doesn't establish it | A module you wrote; a Terraform plan or apply you ran for a team; AWS resources you imported into Terraform | A repo, a module, a pull request | `[grounded]` what the resume says; `[generic]` what a missing named tool costs on applications of this kind |
| C2 | Kubernetes depth, Helm, EKS | important | A two-month proof-of-concept that never reached production | Helm and EKS are named in the JD, and the PoC may have touched them | Helm charts you wrote or used; the cluster being EKS; a write-up or demo that came out of the PoC | A design doc, a chart, a demo recording | `[grounded]` what the resume says; `[generic]` what an unreleased PoC costs on applications of this kind |
| C3 | Observability and SRE practices | important | CloudWatch for monitoring | The JD pairs Prometheus and Grafana with SRE practices and reliability ownership | Alerts you tuned; an on-call rota; incident write-ups; dashboards beyond CloudWatch | A runbook, an alert-rule list, a postmortem | `[grounded]` what the resume says; `[generic]` what a thin monitoring story costs on applications of this kind |

**Named absences.** For these there is nothing in your material to pull on:

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | ArgoCD, GitOps | Nothing in your material touches either. | A small public repo that deploys a sample app to a cluster via Argo CD. | `[grounded]` your description |
| A2 | Istio, service mesh | Nothing in your material touches either. | Run Istio on a practice cluster and write up one real traffic-management exercise. | `[grounded]` your description |
| A3 | Vault | Nothing in your material touches it. | A practice setup that reads a secret from Vault into a workload. | `[grounded]` your description |
| A4 | Go | You describe Python and Bash scripting only. | One small, finished Go tool you can show. | `[grounded]` your description |
| A5 | GitLab CI | You describe Jenkins only. | Rebuild one Jenkins pipeline as a GitLab CI pipeline on a personal project. | `[grounded]` your description |
| A6 | AWS EKS | You list EC2, S3, RDS and IAM only. | Only if the PoC ran on EKS (C2). Otherwise a small EKS cluster you stand up and tear down. | `[grounded]` your description |

Several of these could share one practice cluster. For this particular posting, though, the list is long enough that some of it may not be worth closing before you apply.

## Not written, and why

- **A skills list naming Terraform, ArgoCD, Istio, Vault, Helm, Go and EKS.** You can't defend any of them, and adding them to match the JD is the thing I won't do.
- **"Production Kubernetes experience" or "managed clusters".** You ran a two-month proof-of-concept that never went to production.
- **"CI/CD" attached to the Jenkins work.** The word is the posting's, and you said "deploy pipeline". Whether tests or builds were part of it is unconfirmed.
- **"Observability" or "Prometheus/Grafana" for CloudWatch.** You wrote CloudWatch for monitoring. Those are different tools and a bigger claim.
- **"Infrastructure as code" or "GitOps" for Ansible.** Ansible config management is a different kind of work from provisioning with Terraform or running GitOps. C1 asks whether you have more.
- **"Python development" for "Python scripting".** That would be a bigger claim than the one you made.
- **"Owned platform reliability and developer experience".** You maintain about 30 Jenkins jobs. Ownership of reliability or developer experience isn't something you've said.

## Parse-safety check

I can't inspect the PDF, only your description of it. I couldn't check whether it has a real text layer, how Canva exported the icons, or what the section headings are.

| Check | What breaks | What it costs | Provenance |
|---|---|---|---|
| Multi-column layout (yours is two-column) | Parsers read linearly and can interleave the columns | Text can interleave, and dates can detach from the roles they belong to | `[grounded]` you said two-column; `[generic]` how parsers read columns |
| Icons for each skill | Icons can render as garbage or be skipped | If a skill is shown only by an icon or a level mark, that information is absent | `[grounded]` you said icons for each skill; `[generic]` how parsers treat images |
| Contact details in the header | Headers can be discarded as page furniture | Your email or phone may be lost, so a recruiter can't reach you | `[grounded]` you said header; `[generic]` how parsers treat headers |
| File type (Canva PDF) | Varies by parser; an image-only export has no text at all | Nothing parseable if there's no text layer | `[generic]` text-layer PDF or `.docx` is the safe pair |

A quick test you can run yourself: copy all the text out of the PDF into a plain-text editor. If your contact details, dates or skills are missing or scrambled, a parser will see the same thing. I'm reporting this, not redesigning your layout.

Whether Ridgemount is worth applying to at all, given how many requirements the map shows as `not_evidenced`, is a separate question that job-underwriter handles.

## Upgrade menu

- **The actual PDF or a `.docx` export.** That lets me run the parse-safety check on the real file instead of your description.
- **A write-up, design doc, chart or demo from the Kubernetes PoC.** It could turn R1 and R6 into stronger, inspectable evidence.
- **Your Jenkinsfiles or a pipeline diagram.** They would let me check what the deploy pipeline covers, including whether it builds and tests.
- **A repo, Terraform module, runbook, alert-rule list or postmortem.** Any of these could move R5, R7 or R8 off `not_evidenced`.
- **An earlier version of your resume.** It may hold evidence the current one dropped.

## Questions

C1 — Have you written or applied Terraform (or similar provisioning code) at work, even something small, and for what?

C2 — What did the Kubernetes PoC run on (EKS or something else), did it use Helm, and what did it produce?

C3 — Have you tuned alerts, been on call, written incident reviews, or set up Prometheus or Grafana anywhere?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.