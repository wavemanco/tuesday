Web search wasn't permitted, so I'm building the pack from your dossier alone. I'll mark company-specific content as generic. Writing it now.
The write to the working directory was declined. I'll save the pack in the session scratchpad instead, which is the sanctioned location for files you read.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-4-denied-ba674e6e/6c5f2038-6348-42da-beb1-4b6824b3b376/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It has 21 questions, and I built it for a hiring-manager conversation using only your dossier.

- **No company research:** The web searches I tried (Quartzline's values, interview process and strategy) were refused, so the pack contains no Quartzline facts. The case questions and reverse questions are labeled generic. The Sources section lists each refused search.
- **Save location:** Saving to the project folder was also declined, so I used the session scratchpad.
- **A1 is the question to rehearse first.** It's the objection your dossier named: "You have never held the PM title or owned a roadmap — why you instead of a PM with three years of the actual job?" The pack coaches you to concede the title and roadmap plainly, then give your integration work in its own words. You volunteer the limit on the roadmap-input sessions yourself, since that evidence has limited proof behind it. You finish with a ramp plan.
- **R2 (shipped API or platform products) is a must-have the dossier leaves unresolved.** It lists R2 as high-priority but gives it no weak-area entry. The pack grades it as unclear and gives you A4 to rehearse, with space to say what you shipped or that you didn't.
- **Answer slots:** Where your evidence is silent (Agile, specs, adoption metrics, docs and schemas), the pack leaves a slot for you to answer in your own words. It doesn't write an answer for you.

I can play the Skeptic on A1 as a live drill, pushing back twice and then giving feedback.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry it into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

- **Role and company:** Product Manager, Platform APIs at Quartzline
- **Round:** one 45-minute conversation with the hiring manager (your message). Interviewer name: not given
- **Built from:** your `tuesday-dossier.md` (job-underwriter, `conditional_go`, dossier_version 1.1)
- **Research:** none ran (see Sources), so everything about Quartzline itself is labeled `[generic]`

Wording in quotation marks that is offered for you to say is proposed wording, pending your approval. Rehearse only what you actually did, in your own words.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, including attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no company research ran) |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI prep in this pack is **A1**. The underwriter named that objection from evidence you confirmed, so it will be asked in some form. Question IDs skip the letter F so they never collide with fit-snapshot rows (F1 to F9).

## Fit snapshot

Proposed wording in the last column is pending your approval. The evidence column holds only the dossier's verified entries, quoted. No gate rows: the dossier lists `hard_gates` as empty, and R1's years requirement is graded as an ordinary requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD, dossier role_profile R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | Derived from the dossier's strategy `bridge`: positioned as adjacent, never as product management experience (the underwriter's condition). Words at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "I ran quarterly roadmap-input sessions feeding client evidence to product". The limit, as the pack's observation: your material shows integration work and input sessions, not a product management role. Sourced acknowledgment, from `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title". The second quote is confirmed with limited inspectable proof, so volunteer that limit before a probe finds it |
| F2 | "Own the roadmap for the partner-facing API platform" — JD, dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this area as `acknowledge_gap`: `uncertain_or_weak_areas` "Owning a roadmap and prioritization authority (R1 sub-claim)", confidence none, no bridge. Words come only from that field and from `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap" and "I haven't set prioritization for an engineering squad". Then a plan, never a past: what you would learn first about decision rights and the adoption baseline. Nothing added to make the gap feel smaller |
| F3 | "Shipped API or platform products" — JD, dossier role_profile R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote shows integrating the vendor's APIs, which touches the requirement without showing whether it reaches shipping an API or platform product. The dossier names R2 high-priority but lists no weak-area entry for it, so this grading is the pack's own. Answer slot: the must-have makes a probe on what you shipped likely. If you shipped any API or platform product, say what and which part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD, dossier role_profile R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes show REST API integration work with an architecture stage, and a playbook you wrote; neither names API docs or schemas. Words at their scope: "I wrote the internal integration playbook my team uses". Answer slot: the JD names docs and schemas, so expect a probe on each. If the integrations or the playbook involved either, say how, in your own words; if they did not, say so plainly and stay with the integrations |
| F5 | "Stakeholder management across engineering, sales, customers" — JD, dossier role_profile R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The first quote is client-facing work and the second carries client evidence to product; neither names engineering or sales. Answer slot: if the integrations or the sessions put you in front of engineering or sales, say who and what you did with them, in your own words; if they did not, say so plainly and stay with the clients and product |
| F6 | "Agile delivery experience" — JD, dossier role_profile R5 (preferred) | none given | low | [grounded] | discovery | Dossier strategy `clarify`: no verified entry speaks to this requirement, so nothing about your past goes into an answer. Answer slot: the JD's wording is "Agile delivery experience", and the probe will be what that means in your work. If you worked in sprints, a backlog or a release cadence with engineers, say what and your part, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines it |
| F7 | "Run discovery with integration partners" — JD, dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The scoping and requirements stages are adjacent to discovery, and the sessions carried client evidence onward; neither quote says discovery. Words are the quotes at their own scope. Any wider step is an answer slot: if any of that work was open-ended learning about partners' problems, say what and how, in your own words; if it was not, say so plainly and stay with the stages and sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — JD, dossier role_profile responsibilities | none given | none | [grounded] | discovery | No verified entry speaks to specs or squad delivery. The playbook in F4 is an integration playbook, and the pack does not treat it as a spec. Answer slot: if you wrote specs or drove delivery with an engineering team, say what and your part, in your own words; if you did not, or it was not yours, say so plainly and stay with the integrations you led |
| F9 | "Define and track adoption metrics" — JD, dossier role_profile responsibilities | none given | none | [grounded] | discovery | No verified entry speaks to metrics. Answer slot: if you defined or tracked adoption or usage measures, say which and how they were counted, in your own words; if you did not, say so plainly and say what you would ask first about how adoption is measured today (an open risk in the dossier) |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Skeptic | Quiet probing of the missing title and roadmap, then why product, why here | High. A hiring-manager round starts from Case/Strategist plus Skeptic, and the underwriter named a Skeptic-style objection from your confirmed evidence (F1, F2) | Rehearse A1 until it is boring; bridge only from the quoted entries with the limit named; concede the sourced gaps plainly |
| B. Case/Strategist | Live problems from the real role: roadmap, adoption, a squad conflict | High. Hiring-manager prior; the JD's roadmap, adoption and squad lines are easy to turn into cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Line-by-line reading of the quoted entries, starting with the 30+ | Mid. Your evidence has one headline figure and one confirmed-but-thin entry, which a prober finds | Know how the figure was counted and say plainly when you do not; volunteer the thin entry's limit first |
| D. Pressure | Time-boxed challenge on why you, and on authority over squad leads | Low. Not in the hiring-manager prior; raised only by the unevidenced squad authority (F2) | Pause, restate, anchor in the quoted sentence, hold through two follow-ups, concede only what the sources support |
| E. Peer Evaluator | The seam with the two squad leads, credit across teams | Low. The interviewer is a manager, not a peer, but the squad relationship is a JD unknown | Offer seam principles, not a pretended seam; state what you would bring them |
| G. Conversational | The opener and a casual question about API topics | Low. Short and friendly, still scored | A prepared 90-second arc from the quotes; treat the casual question as scored |
| H. Values/Behavioral | A story prompt on unpopular truths or customer-first calls | Low. No values-style round is detected: your message names one conversation and no loop source documents a values round | Selection scaffolds with an honest branch; no values are named because none were researched |

The loop is established by your own words (one 45-minute hiring-manager conversation), so no archetype fallback applies. There are no interviewer signals to adjust the weights.

## Question banks

Proposed wording in these tables is pending your approval.

### A. Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having set prioritization for an engineering squad"`; `uncertain_or_weak_areas` acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | The highest-ROI rehearsal, named by the underwriter in `likely_interviewer_objections`. Four beats. One, concede first and specifically: "I haven't held a product manager title, and I haven't owned a roadmap." Two, the adjacent work in the quote's own terms: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Three, volunteer the limit on the second quote before it is extracted: you ran quarterly roadmap-input sessions feeding client evidence to product, which is input and not a roadmap decision, and the proof beyond your own account is limited, so say what you can show and what you cannot. Four, a ramp plan said as a plan: the first things you would learn are which decisions the squad leads hold and how adoption is measured today. Do not argue equivalence with a PM who has done the job; the underwriter's condition is that this is adjacent, never PM experience. Hold through two follow-ups by returning to the integrations. If pressed, concede the title, the roadmap and prioritization specifically, and never concede the integrations | The underwriter derived this from evidence you confirmed rather than from a document read cold. F1 and F2 are where it presses. JD because it scores R1; the Skeptic delivers it as a hire-or-pass framing |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims: "Having owned a product roadmap"` | Name it plainly rather than ranking around it: "I haven't owned a product roadmap." The underwriter found no bridge for this area, so none is offered; do not reach for the roadmap-input sessions as a substitute. Then the plan: what you would do in the first weeks to learn the decision rights and the adoption baseline, and who you would ask. Candor beats bluffing a competency the interviewer personally owns. Stop after the plan and do not volunteer a second weakness | F2 is the gap with no bridge, and this is the stem that surfaces it. JD because it scores the role's roadmap line |
| A3 | "The JD lists Agile delivery experience. How would you describe yours?" | JD | [grounded] JD line "Agile delivery experience" (dossier role_profile R5) | No verified entry speaks to this, so nothing about your past goes into the answer. Answer slot: the JD's wording is "Agile delivery experience", and the interviewer's probe will be what that means in your work. If you worked in sprints, a backlog or a release cadence with engineers, say what and your part, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines it | F6 is a `clarify` area: the evidence may exist but was not established. Asked neutrally because the material is silent; JD because R5 is a stated requirement |
| A4 | "The role asks for shipped API or platform products. Where does your experience sit against that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start with what the quote states, in your own words: you led client integrations of the vendor's REST APIs, from scoping to go-live. Do not call that shipping an API product; section 13 lists that wording as not coached. Answer slot: the must-have makes a probe on what you shipped likely. If you shipped any API or platform product, say what and which part was yours; if you did not, or it was not yours, say so plainly and stay with the integrations you led | F3 is a must-have with no weak-area entry in the dossier, so this is likely the second-biggest question after A1. JD because it scores R2 directly |
| A5 | "Why a product role, and why Quartzline?" | JD | [generic] | Selection scaffold. Pick the one thing in the JD you want to do and cannot do now, using its own lines: "Run discovery with integration partners", "Own the roadmap for the partner-facing API platform" or "Define and track adoption metrics". It should be specific, forward-looking and about the work. The pack holds no Quartzline facts because no research ran, so the why-Quartzline half has to come from your own reading of their materials. If no single reason comes to mind, say so plainly, then say what you would want to learn in this conversation | The Skeptic's why-here, why-now probe; it tests motivation consistency. JD because the answer should tie to the stated responsibilities. `[generic]` because no Quartzline research ran |

### B. Case/Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would decide the first three things on the partner API roadmap — what do you need to know first?" | CASE | [generic] | Clarify, objective, segmentation, approach, metrics, risks, thinking aloud. Clarify first with the two things the dossier left open: which roadmap decisions belong to the PM and which to the squad leads, and how adoption is measured today and from what baseline. State your premises aloud and challenge one respectfully. Name no baseline or target number, since none was given. The question needs no claim about your past, so the guidance makes none | JD roadmap responsibility delivered as a CASE, which the hiring-manager prior favors. `[generic]` because no Quartzline roadmap research ran |
| B2 | "Partner adoption of the API has stalled between signup and production. Diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify what stalled and since when, then segment partners, form hypotheses, name the data you would pull and the first test. The quote's stage names (scoping, requirements, architecture, UAT, go-live) give you a diagnostic spine: ask at which stage partners drop out. That uses the names as vocabulary and claims nothing about what you found in any integration. Close with the metric you would track and one risk | Covers discovery with partners and adoption (F7, F9). CASE because it is a live diagnosis |
| B3 | "A large partner asks for a breaking change to an endpoint, and one squad lead says no. What do you do?" | CASE | [generic] | Ask first who decides this and on what basis, since the dossier shows squad authority is unevidenced. Then the partner's evidence and the cost of not changing, the options (a versioned change, a phased path, a decline with an alternative), who decides, how you escalate, and what you record. Say your principle for the seam rather than pretending to know it | Tests the squad-authority unknown behind F2 and F8. CASE because it is a decision under conflict |
| B4 | "How would you define and track adoption for a partner API platform?" | CASE | [generic] | Ask how it is measured today before proposing anything, then layer it: reach, activation, depth and health, with one headline measure and why. A baseline comes before a target. The question needs no claim about your past, so the guidance makes none | The JD names adoption metrics as a responsibility, with no baseline stated (dossier risk). F9 holds the slot for any past |
| B5 | "A partner says their integration broke after a field in a response schema was renamed. Walk me through what you check and who you talk to." | CASE | [generic] | Reproduce first, then compare the schema versions against the docs and changelog, scope which other partners are affected, and choose the path (revert, alias, deprecate). Say how you would communicate to partners and the squad, and what you would put in place to prevent a repeat, such as a versioning and deprecation policy. No claim about your past | JD requirement R3 (technical fluency) as a live problem; see F4. CASE because it tests structure on a technical scenario |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations — how was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep the figure on its noun: 30+ client integrations, not clients or APIs. Four slots, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly. The pack supplies no method, baseline or attribution | The one headline figure in your evidence (F1, F3). EXP because it checks attribution and counting |
| C2 | "Walk me through one of those integrations, from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one you can narrate in full. The beats are the stages the quote states: scoping, requirements, architecture, UAT, go-live. For each, say what you did in your own words, and where someone else did it, say so. Add no incident or decision you cannot name. Expect a probe two levels deep on any stage | Tests attribution on the strongest evidence (F1, F4, F7). EXP because it checks what was actually yours |
| C3 | "Walk me through the quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the quote: the sessions ran quarterly and fed client evidence to product; tell that in your own words. This entry is confirmed with limited inspectable proof, so volunteer the limit first: what you can show and what rests on your own account. Answer slot: the JD's roadmap line makes a probe on whether any input changed a roadmap likely. If one did, say what it was and what part was yours; if none did, or the decision sat with product, say so plainly and return to the sessions you ran | F1 and F5 rest partly on this entry, and it is the medium-confidence seam. EXP because it tests what you actually did |

### D. Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say you led 30+ integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate the question, and anchor in the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Keep "led" at that scope. Answer slot: say which integrations and which stages were yours; if a stage belonged to someone else or the team, say so plainly and name it. Hold through two follow-ups by returning to the sentence rather than adding to it. Concede any stage that was not yours, specifically, and do not concede the claim as a whole just to restore harmony | The standard attribution stem aimed at F1. EXP because it scores precise ownership |
| D2 | "A squad lead will not take prioritization direction from someone who has never set priorities for a squad. What happens in your fourth week?" | JD | [grounded] `prohibited_claims: "Having set prioritization for an engineering squad"` | Do not defend a past you do not have. Concede the sourced part plainly: "I haven't set prioritization for an engineering squad." Then the plan: by week four you would be working from the decision rights agreed in the first weeks, bringing partner evidence in a form the squad lead can use, asking what they need from you, and taking unresolved calls to the hiring manager. The plan asserts no past | F2 and the unevidenced squad authority. JD because it scores the role's squad-delivery line, with CASE delivery |

### E. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our two squad leads will be your closest partners. Where is the seam between you and them, and what happens when you disagree?" | JD | [generic] | Do not pretend to know the seam: the dossier shows decision authority is asserted in the JD and not evidenced. Offer seam principles instead (who owns the problem and who owns the solution, how disagreements surface, when they escalate) and ask where the line sits today. Reciprocity: say what you would bring the squads, partner evidence in a form they can use. For a disagreement story, no quoted sentence carries one, so pick a time you disagreed with an engineer or lead and the work still moved; it needs a named stake, how you raised it and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The squad relationship is the live unknown (F8). JD because it scores the stakeholder and delivery lines |
| E2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the internal integration playbook her team uses" | Use "we" for context and "I" for contribution: "I wrote the internal integration playbook my team uses." That sentence is the only credit example your quotes carry; do not extend it to who contributed to or reviewed it. If another example fits better, choose one where you can say plainly which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries | A collegial credit probe; see F4 for the evidence. VAL because it scores behavior with others, not a company value |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from the three quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." Close it on this role in your own words, using the scaffold in A5; the pack states no motive for you. Do not open with a title or a count of years, since no quote carries either | The opener is scored. F1 supplies the beats. EXP because it checks your account of your own work |
| G2 | "What are you actually playing with in API products these days?" | JD | [generic] | A casual question on a hot JD topic (the JD names API docs and schemas), still scored. Pick one thing you have actually used or read recently about API docs, schemas or platform adoption, and say what it was and why it interested you. If nothing real comes to mind, say so plainly, then say what you would want to explore first. Name no tool you have not used | R3 asked casually (F4). JD because it scores a stated requirement |

### H. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Choose a time with a named stake, a moment the truth actually landed, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No values round is detected, so this is low weight; it is here so the style is not met first live. `[generic]` because it is a persona stem and no Quartzline values were researched |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Choose a time where the customer outcome and the internal measure pulled apart, you chose the customer, and you can say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | As H1; a persona stem relevant to a partner-facing role |

### Requirement coverage

| JD line (source) | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, D2 |
| R2 "Shipped API or platform products" | A4 |
| R3 "Technical fluency: API docs, schemas" | B5, C2, G2 |
| R4 "Stakeholder management across engineering, sales, customers" | B3, C3, E1 |
| R5 "Agile delivery experience" | A3 |
| Own the roadmap for the partner-facing API platform | A1, A2, B1, B3 |
| Run discovery with integration partners | B2, C2, C3 |
| Write specs and drive delivery with two engineering squads | A3, B3, E1 |
| Define and track adoption metrics | B2, B4 |

## Reverse questions

Proposed wording, pending your approval. The first two come from the dossier's `questions_for_employer` and `opportunity_risks_to_validate`.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority without evidencing it (the dossier's first open risk). It reads as diligence, and the answer is something you need before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The adoption responsibility has no stated baseline (the dossier's second open risk). It shows you think in measures, and it tells you what you would be accountable for |
| 3 | "What do partners most often get stuck on when they integrate today, and how does that reach the team?" | Moves the conversation to the integration problem, which is where your quoted work sits, without claiming anything about it. The answer shows how evidence flows to product (`[generic]`) |
| 4 | "When partner requests conflict with a squad's plan, how does that get resolved today?" | Probes the seam behind B3 and E1 and tells you whether the PM role carries authority or only influence (`[generic]`) |
| 5 | "What would you most want a new PM here to have figured out by the end of the third month?" | Invites the hiring manager to describe the ramp, which lets your ramp plan from A1 meet theirs (`[generic]`) |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Built before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: `prohibited_claims` | F1's quotes at their own scope, plus the sourced acknowledgment "I haven't held a product manager title" |
| Having owned a product roadmap | Sourced: `prohibited_claims`, and the `acknowledge_gap` area | F2's acknowledgment "I haven't owned a product roadmap". No bridge is coached; the roadmap-input sessions stay input |
| Having set prioritization for an engineering squad | Sourced: `prohibited_claims` | F2's acknowledgment "I haven't set prioritization for an engineering squad", then a plan |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the quote shows integrating the vendor's APIs. A4's slot stays inside the integrations |
| Ran product discovery with partners | Inflated form of F7 | F7's quotes at their own scope: the scoping and requirements stages, and the sessions. B2 and C3 stay inside them |
| Shaped or decided roadmap outcomes | Inflated form of F1's second quote | The quote at its own scope: sessions feeding client evidence to product. C3's slot asks only whether any input changed a roadmap |
| Designed API schemas or wrote API documentation | Inflated form of F4's quotes | "I wrote the internal integration playbook my team uses" at its own scope. F4's slot asks only whether docs or schemas were involved |

## Sources

- **Provided:** your pasted `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14. Consumed: `role_profile` (supplied the JD lines and the requirement priorities), `handoff_to_mock_interview` (verified evidence, weak areas with their allowed strategies, the named objection, risks, employer questions, prohibited claims) and `decision` (context only). Not present in it: `evidence_map`, `evidence_state`, `risk_register`. Anything that changed in the posting or your evidence since 2026-08-14 is not reflected.
- **Searches:** `Quartzline company values` — refused. `Quartzline interview process product manager` — refused. `Quartzline partner API platform strategy news` — refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The call was refused. It would have named published values; no values cheat sheet is built because no values-style round is detected either way |
| 2. `Quartzline interview process product manager` | unavailable | The call was refused. It would have documented the loop; persona weights rest on your stated round and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | The call was refused. It would have grounded CO and CASE questions in current strategy; B1 to B5 are `[generic]` and the bank holds no CO question |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the JD lines the fit snapshot and JD-tagged questions use |

## Upgrade menu

- Permission to search the web, or a pasted Quartzline about, careers or values page → CO and CASE questions grounded in their actual strategy (B1 to B5 move from `[generic]` toward `[grounded]`), a values cheat sheet if a values round is documented, and a documented loop. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available on your say-so
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email, if there is one (focus areas, any pre-declared deliverable) → coverage of any graded deliverable and a check on the conversation format
- Your answers to the answer slots in F3, F4, F5, F6, F7, F8 and F9, given outside a drill → those rows enter the fit snapshot as quoted evidence and their questions (A3, A4, C3) are regenerated
- Notes or a deck from one roadmap-input session → raises the medium-confidence entry behind C3 and F1 toward high
- Your raw CV → more quotable lines for F3, F4, F5 and F7, and more figures to rehearse the way C1 does
- Your prep time before Thursday → a prioritized schedule sized to it
