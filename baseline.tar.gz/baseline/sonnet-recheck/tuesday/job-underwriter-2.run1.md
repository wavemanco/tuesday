I've read the underwriting playbook. Next I'm running two research searches: whether Quartzline exists as described, and what the API product manager role normally looks like.
**No, you're not wasting your time on the pivot. But this role is a stretch application, not a fit.** The "3+ years product management experience" must-have is absent as titled experience (R1), and your resume has no PM title. Your technical fluency and stakeholder work are strong (R3, R4a). The posting also isn't verified, because my searches were refused.

## Decision snapshot

**Worth applying to, deliberately and not as a mass-apply. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R2 (Shipped API or platform products) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery) · absent: R1 (3+ years PM experience)
- `important` — adjacent: R6 (Discovery with integration partners), R7 (Specs and delivery with two squads), R9 (Own the roadmap) · unclear: R8 (Define and track adoption metrics), R10 (Coordinate launches with sales and support)

R1 is absent against a must-have the posting states outright. R2, R6, R7 and R9 hold the adjacent work an application would argue from.

**Opportunity ledger.** The posting gives concrete scope (RR5). The employer and posting are unverified (RR1). Level, pay and location are unstated (RR3), and adoption targets are not given (RR4). The titled-years must-have is a screening risk (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, per RR1; (2) the team doesn't apply the 3+ years literally, tested early with the recruiter, per R1 and RR2; (3) R2's bridge is stated as adjacent, never as shipped platform experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not verified against any outside source (RR1) |
| Mandate | Own the roadmap of a partner-facing API platform, run discovery with integration partners, write specs, drive delivery with two engineering squads, define and track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Level | Title is "Product Manager"; seniority is not stated, and the 3+ years requirement points to a mid-level post | `[inferred]` from the years requirement against the absent level label |
| Scope read | Every responsibility listed is within the usual span of a platform PM post; nothing is bundled from an unrelated function | `[inferred]` from the JD's responsibility list |
| Market calibration | Not calibrated: the role-family sweep did not run, so no band for title, scope or pay is offered | `[grounded]` the JD states no compensation (RR3) |
| First-year outcomes | Not stated; adoption metrics are named as something the role defines | `[grounded]` JD silence |
| Unknowns | Level, pay, location or remote policy, adoption targets, which partners are on the platform, reporting line | `[grounded]` JD silence on each |
| Contradictions | None found within the JD | `[grounded]` JD read; no second source |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience (must-have) | must_have | absent | none | transferability | Your resume states no PM title or PM role in seven years, so no wording can claim it. This is a years requirement, not a gate, so it is graded on fit like any other. The adjacent work is carried in R6, R7 and R9, not here. | `[grounded]` resume states no PM title; `[generic]` that titled-years requirements are often screened literally | No wording closes this. Lead with R6, R7 and R9 adjacency (E1, E2) and test flexibility early (RR2) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook the team uses: deep implementation-side experience of a shipped API product. Limit: nothing says you built or launched an API or platform, and the playbook is an internal document, not a product. | `[grounded]` resume | G1 asked; a sanitized playbook excerpt would make the artifact inspectable |
| R3 | Strong technical fluency: API docs and schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus integration architecture across 30+ client integrations. It is a specific claim with no inspectable artifact yet, so expect a probe. | `[grounded]` resume | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, the client's engineers and product managers on custom builds, and ran scoping workshops, UAT and go-live with clients. | `[grounded]` resume | none |
| R4b | Stakeholder management with sales | must_have | unclear | none | discovery | The resume is silent on working with sales. | `[grounded]` resume silence | G5, not asked this turn |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The resume shows project delivery (scoping, UAT, go-live) but names no sprint, backlog or cadence. Indirect context only. | `[grounded]` resume silence on cadence | G3 asked |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions collecting client feedback for product are real listening to partners. Limit: scoping serves one client's implementation, and the sessions fed product's roadmap with no sign you synthesized findings into a product bet. | `[grounded]` resume | G2 asked |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture and coordinated engineers on custom builds. Limit: these were per-client builds, not a standing backlog for two squads, and who set priorities is not stated. | `[grounded]` resume | G2 asked |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The resume shows SQL but no metric you defined or tracked. An unconfirmed lead from earlier conversation about an internal tool support agents adopted could bear on this; it is a question, not evidence. | `[grounded]` resume silence; `[inferred]` that the prior-context lead may bear on it | G1 asked |
| R9 | Own the roadmap for the partner-facing API platform | important | adjacent | medium | transferability | You ran quarterly sessions collecting client feedback as input to product's roadmap. Limit: input to the roadmap is not ownership of it, and nothing shows you prioritized or committed. | `[grounded]` resume | G2 asked |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | Go-lives were client implementations. The resume is silent on coordinating with sales or support on launches. | `[grounded]` resume silence | G5, not asked this turn |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Something you built and others adopted (R2, must_have; R8, important) | discovery | Integration and playbook work, nothing built as a product. Earlier conversation context hinted at an internal request-triage tool that support agents adopted; unconfirmed. | It is the one route to narrow R2's limit (integrated, did not ship) and to give R8 any evidence. | An internal tool, template or process other teams used; something whose scope you decided, rolled out and saw usage numbers for | Usage numbers, a rollout note, a screenshot, a short problem-and-result write-up | `[grounded]` resume silence; `[inferred]` that resolving it could lift R2 and R8 |
| G2 | Deciding what got built (R7, R9, important) | discovery | Requirements documents and coordination, but not who set priorities. | The line between writing specs for engineers and deciding what they build is what these rows turn on. | Choosing what went into a custom build; trading scope against a deadline; pushing back on a client request | A sanitized spec, a scope-change note, a roadmap-input summary you sent to product | `[grounded]` resume; `[generic]` that PM interviews probe this line |
| G3 | Agile delivery (R5, must_have) | discovery | Delivery is evidenced, cadence is not. | A must-have row that can move from `unclear` on one answer. | Sprint planning with a client's engineers; backlog grooming on a custom build; running a fixed-phase plan alongside a sprint team | A sprint board export, a delivery plan | `[grounded]` resume silence |
| G4 | Titled PM years (R1, must_have) | transferability | The bridge is R6, R7 and R9. The limit is that none of the work held the PM role. | No question closes it. The honest route is adjacent evidence plus an early check on how literally the requirement is read (RR2). | n/a | A work sample such as a one-page adoption-metrics plan for a partner API (W1) | `[grounded]` resume; `[inferred]` that a sample narrows the limit |
| G5 | Sales and launch coordination (R4b, must_have; R10, important) | discovery | Silent. Lower expected impact than G1 to G3, so not asked this turn. | Would settle two rows if the work exists. | Joining pre-sales calls; handing a go-live to support; writing enablement for support | A handoff checklist, an enablement deck | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Not checked against any outside source; the posting may be stale or the company small. Treat that as unchecked, not as a flag. | `[grounded]` the research calls were refused, so nothing was attributed | Can you confirm this role is open and tell me who the hiring manager is? | unresolved |
| RR2 | Titled-years must-have may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | A recruiter or applicant-tracking screen may filter on PM titles before anyone reads the integration work | `[generic]` pattern for years requirements, not a claim about this employer | Would the team consider someone whose product-side work came from a solutions role, and what would they want to see? | unresolved |
| RR3 | Level, pay and location unstated | unknown | — | "Product Manager, Platform APIs — Quartzline" | The posting may be at a level or pay you cannot judge yet; withholding is itself worth a question | `[grounded]` the JD states none of the three | What level and salary band is budgeted, and is the post remote or office-based? | unresolved |
| RR4 | Adoption targets not given | unknown | — | "define and track adoption metrics" | The role may define its own success measures with no baseline or target | `[inferred]` from the JD naming the metrics but no targets | What adoption targets would this role be accountable for in year one? | unresolved |
| RR5 | Concrete scope on the page | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Named product, named delivery squads and named discovery customers, which suggests a defined remit | `[grounded]` JD | Which partners are on the platform today, and how do they use the APIs? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the experience section with your two lines nearest to product work, kept as written: "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses". | See R6, R9 | `[grounded]` resume | `resume_edits_pending_approval` |
| E2 | Summary line: "Solutions engineer and implementation lead with seven years leading 30+ client integrations of REST APIs end to end, who ran quarterly roadmap-input sessions collecting client feedback for product." Do not use "owned the roadmap", "shipped" or any PM title. | See R1, R2, R9 | `[grounded]` every clause traces to your resume | `resume_edits_pending_approval` |
| W1 | A one-page sample of how you would define adoption metrics for a partner API, using your SQL fluency | See R8, G4 | `[inferred]` from the R8 gap | pending your approval |
| A1 | Verify the posting and ask the RR2 and RR3 questions of the recruiter before investing in a full application | See RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Seek a referral or write directly to the hiring manager, as a way around a literal titled-years screen | A pattern for small companies, not a fact about this employer | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask the RR1 to RR5 verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: an internal request-triage tool that support agents adopted, recalled from earlier conversation and unconfirmed; it prompts G1 only. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused, so there is no confirmation that Quartzline exists as described or that the posting is live. It would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | The search was refused. It would have moved the market calibration line and the pay and level checks in RR2 and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. A name would feed the scope read and which story the plan leads with |

Offer beyond the spec: a short scan of the kinds of roles that count untitled product work, built on your approval. R1's titled-years gap is the main obstacle here and would recur beyond Quartzline. It needs research access to run.

I can write this up as a `tuesday-dossier.md` if you want to carry it into later steps.

**Upgrade menu**
- Research access for the two L1 targets that did not run, which would settle RR1 and the market calibration line. A deeper pass on Quartzline (leadership and funding changes, recent news; up to 5 more searches and 2 more fetches) is available on your word.
- Your non-negotiables (pay floor, location or remote, authorization, schedule). Today the hard-gates line is flagged as unchecked against them.
- A sanitized spec or requirements document from a custom build, or a summary you sent to product from a roadmap-input session. Either would make R6, R7 and R9 inspectable and could move them from `medium`.
- Usage numbers or a write-up of the triage tool, if it is yours. That could lift R2 and R8.
- The hiring manager's name, and a link to the live posting.

**Questions**

G1 — Earlier conversation context suggested you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you personally decide and build, roughly how many people used it, and how did you know it was being adopted?

G2 — On your custom builds, who decided what the engineers built and in what order? Did you set scope or priorities yourself, or take them from a PM or the client? One concrete example is plenty.

G3 — What delivery cadence did your custom builds run on (sprints, kanban or fixed phases), and which part of it did you personally run?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.