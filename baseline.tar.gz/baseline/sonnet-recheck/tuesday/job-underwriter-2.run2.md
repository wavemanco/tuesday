## Decision snapshot

**No, applying is not a waste of time. R1 (a) (3+ years PM experience, as a titled role) is the real obstacle, and it is not a gate. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1b (PM-type work without the title), R2 (Shipped API or platform products) · unclear: R4b (Sales and support launch coordination), R5 (Agile delivery with squads) · absent: R1a (3+ years PM experience as a titled role)
- `important`: direct: R6 · adjacent: R8 (Specs and delivery with engineering squads) · unclear: R7 (Adoption metrics)

R1a is the weakest row, and R1b and R2 are what the bridge rests on.

**Opportunity ledger.** The scope is concrete (RR5). The employer is not yet established (RR1), the titled-years screen is a risk (RR2), pay is unknown (RR3), and success measures are unstated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline verifies as real and the posting is live (RR1). (2) The hiring side confirms that PM-scope work without the title can count toward R1a (RR2, R1b). (3) Your bridge is presented as adjacent, never as titled PM experience (R1b, R2).
- **What would change this:** a flat "titled PM years only" answer on R1a would likely move this posting toward `no_go`. The pivot itself stays open through the other routes in the application plan (A2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not verified against any outside source |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Seniority signal | The JD asks for 3+ years of PM experience and names no people reports | `[grounded]` JD |
| Scope read | An individual-contributor PM with a defined audience (integration partners) and defined team (two squads) | `[inferred]` from the JD's named squads and audience against its silence on reports |
| Market calibration | Not done: the search was refused, so no salary or title band is stated | `[grounded]` the Research tier line below |
| Unknowns | Compensation, success measures, who sets priority between the two squads, whether title-less PM work counts toward the 3+ years | `[grounded]` JD is silent on each |
| Contradictions | None visible inside the JD; the company's own site is unchecked | `[grounded]` JD read; no search result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as a titled role | must_have | absent | none | capability | You state you have never held a PM title. A length-of-experience requirement is not a gate, so it is graded like any row. Wording cannot create titled years. | `[grounded]` your statement and the JD | Put RR2's question to the hiring side; pursue A2 in parallel |
| R1b | PM-type work over several years (roadmap input, requirements, coordinating PMs and engineers) | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions for product and coordinated PMs on custom builds. Limit: that is feeding a roadmap, not owning or prioritizing one. No artifact has been inspected. | `[grounded]` CV prose; limit is `[inferred]` from the CV's silence on prioritization | Bridge case in G4; offer a work sample (W1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the team's integration playbook. Limit: that is delivery against an API, and the CV does not say you shipped or specced the API itself. | `[grounded]` CV prose; limit is `[inferred]` from the CV's silence on API design | G1 and G4 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI-spec reading, plus integration architecture work. Confirmed prose, no inspectable artifact yet. Expect a probe. | `[grounded]` CV prose | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs across 30+ engagements. No artifact inspected. | `[grounded]` CV prose | none |
| R4b | Stakeholder work with sales and support; launches coordinated with them | must_have | unclear | low | discovery | The CV shows go-lives for clients but names neither sales nor support. | `[grounded]` CV silence | G3 |
| R5 | Agile delivery | must_have | unclear | low | discovery | The CV names UAT and go-live but not sprints, backlogs or squad ceremonies. | `[grounded]` CV silence | G2 |
| R6 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and roadmap-input sessions with clients are the same motion. The CV does not frame them as discovery. | `[grounded]` CV prose | E1 pending approval |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | The CV has no metrics line. A prior-context memory lead suggests an internal triage tool that support agents adopted. It is unconfirmed and cannot count as evidence. | `[grounded]` CV silence; `[grounded]` the lead is a `memory_lead` | G1 |
| R8 | Write specs; drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and integration architecture. Limit: client-facing specs for a custom build differ from specs for a shared platform, and you did not say you directed engineers. | `[grounded]` CV prose; limit is `[inferred]` | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Adoption metrics and shipped product (R7, important; R2) | discovery | The CV has no metrics line. A possible internal tool is an unconfirmed lead. | Evidence of a built-and-adopted tool is the closest thing to a shipped product and an adoption metric in your history. | A tool, template or process others took up; usage numbers, even rough ones; a request queue you redesigned | A short write-up, screenshot or usage figure | `[grounded]` CV silence; `[inferred]` that it could raise R7 and R2 |
| G2 | Agile delivery (R5, must_have) | discovery | The CV shows delivery stages but no iteration cadence. | It is a listed requirement, and a single sentence could close it. | Sprint planning with the engineers; backlog grooming for a custom build; release trains | A ticket-board screenshot or sprint notes, sanitized | `[grounded]` CV silence |
| G3 | Sales and support launch coordination (R4b, must_have) | discovery | Clients, engineers and PMs appear; sales and support do not. | The JD names launches with sales and support. | Handoffs to support after go-live; enablement material for sales; joint launch checklists | A handoff doc or enablement deck, sanitized | `[grounded]` CV silence |
| G4 | The bridge from integration delivery to product ownership (R1b, R2, R8) | transferability | Strong adjacent work. Limit: delivery and input, not ownership of prioritization or of a shared product. | This is the case you would make to the hiring side. | The playbook as a product you maintained; client feedback you turned into a prioritized ask | One-page sanitized excerpt of the playbook or a roadmap-input summary | `[inferred]` bridge from the CV; limit named in R1b, R2 and R8 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Medium, not high, because nothing else is off. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Titled-years requirement may be applied literally | risk_signal | medium | "3+ years product management experience (must-have)" | The screen may filter on PM job titles. A hiring manager may weigh PM-scope work without the title. | `[generic]` pattern for how hiring teams read years requirements | Would work that carries PM-scope responsibilities without the title count toward the 3+ years, and what would that look like? | unresolved |
| RR3 | Compensation not stated in the posting as provided | unknown | — | "Product Manager, Platform APIs — Quartzline" (no figure given) | The original listing may state a range that was left out of what you pasted. | `[inferred]` from the pasted text's silence | What salary range is budgeted for this role? | unresolved |
| RR4 | No definition of success on a roadmap-owning mandate | unknown | — | "Own the roadmap for our partner-facing API platform" | Success may be defined verbally, or adoption metrics may not yet exist. | `[inferred]` from the JD's mandate against its silence on outcomes | What would success look like at twelve months, and which adoption metrics exist today? | unresolved |
| RR5 | Concrete audience and team | positive_signal | — | "two engineering squads"; "integration partners" | Scope is defined enough to assess. | `[grounded]` JD states both | Who sets priorities between the two squads? | noted |

## Application plan

Every row below, and the positioning advice inside it, is proposed (`resume_edits_pending_approval`). Nothing is final until you approve.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move your integration-playbook and roadmap-input-session lines to the top of the resume, wording unchanged. Keep your current title as it is. | See R1b, R6 | `[grounded]` CV | pending your approval |
| E2 | Group Postman, SQL and OpenAPI-spec reading beside the integration work instead of in a tools list, wording unchanged. | See R3 | `[grounded]` CV | pending your approval |
| W1 | A one-page sanitized excerpt of the playbook, or of one roadmap-input summary, as a work sample. | See R1b, R2, G4 | `[inferred]` from G4 | pending your approval |
| A1 | Before investing in the loop, put RR2's question to the recruiter. | See R1a, RR2 | `[grounded]` RR2 | pending your approval |
| A2 | In parallel, target roles that name no minimum of titled PM years, and look at internal moves into product at your current employer. | Solutions engineers commonly enter product through roles and moves that do not screen on titled years. This is a pattern, not a fact about Quartzline. | `[generic]` role-family pattern | pending your approval |
| Q1 | Ask RR1 to RR5's verification questions verbatim during the process. | The register doubles as interview preparation. | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention of an internal request-triage tool adopted by support agents. It is unconfirmed and only prompts G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Quartzline logistics technology API platform Series B" and the call was refused. It would have moved RR1 and role reality's organization and contradictions rows. |
| 2. Role-family sweep | unavailable | I searched "Product Manager platform APIs salary B2B SaaS Series B requirements transition from solutions engineer" and the call was refused. It would have moved market calibration, RR3 and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

---

If you want, I can save this as a `tuesday-dossier.md` so later modules can reuse it.

**Upgrade menu**
- Permission to search the web, or a link to the live posting or Quartzline's careers page: this settles RR1 and adds a salary and title band to role reality and RR3. A deeper pass later would be up to 5 more searches and 2 more fetches.
- The posted salary range: this closes RR3.
- The hiring manager's name: this adds their public professional footprint to the scope read and to which story the plan leads with.
- A sanitized playbook excerpt or a write-up of the triage tool: this could raise R1b, R2 or R7 above `medium` or `low`.

**Questions**
- G1: Did you build an internal request-triage tool that support agents adopted? What did you own, how many people used it, and is there anything to show for it?
- G2: When you worked with engineers on custom builds, did you run to sprints or a backlog, and who ordered the work?
- O1: What are your non-negotiables for a move, such as pay floor, location, and remote or onsite? That would let me check them against the role.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.