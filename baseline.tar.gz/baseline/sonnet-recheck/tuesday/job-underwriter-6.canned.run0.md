**Yes, it's worth applying, but as a stretch with conditions. Status: `conditional_go`.** The two parts of the job you haven't done are the forecast and the billing data, and the role is built around both. R6 (forecast) has a credible bridge. R8b (billing data) has no direct evidence.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two days in the office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3a, R4, R8a · adjacent: R5 (SQL and spreadsheet modelling), R6 (Experience owning a forecast), R7 (Working with finance on billing or revenue data) · unclear: R3b (At a B2B software company) · absent: R8b (Owning billing data)
- `important`: direct: R9

R6 is the row where your monthly pipeline review gives you a real bridge. R8b is the one `absent` row.

**Opportunity ledger.** The employer matches the posting and the pay is stated (RR3). Three things are open: who owns the forecast model today (RR1), whether the role is live on Quillfield's own site (RR2), and the terms of the share options (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days in the office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol two days a week and the pay range both work for you, which settles R1 and R2; (2) the forecast bridge is framed honestly as adjacent, never as owning a forecast (R6, RR1); (3) the billing-data gap is named up front with a ramp plan (R8b, RR1); (4) the role is confirmed open, with Tamsin Achebe as hiring manager (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` "About Quillfield" page (search result) |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Location and pay | Bristol, hybrid, two days a week in the office; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, who a public profile lists as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. You were told by the recruiter that she is the hiring manager; the profile is consistent with that. The posting names no manager. | `[grounded]` your recruiter's statement and the profile snippet |
| Scope read | The role is finance-facing at its centre: billing data and the CFO forecast are two of its three headline duties, and those are your two stated gaps | `[inferred]` from the posting's duty list against your background |
| Market calibration | UK revenue operations leads in B2B software have a median base of £64,200 and an interquartile range of £57,800–£70,400, so the posted range straddles the median. This is a market pattern, not Quillfield's offer. | `[generic]` Ledgerline 2026 pay guide (n=438); `[grounded]` posting for the posted range |
| Unknowns | Reporting line and team size; who owns the forecast model today; share option size and vesting; your location and pay floor | `[grounded]` posting silence; your message silent on constraints |
| Contradictions | None found. One address on the company's own site, quillfield.co.uk/careers, returned no page, so the posting is not confirmed there (RR2). | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You gave no location or schedule constraint, so there is nothing to grade your side of this. Fit stays unclear until you answer. | `[grounded]` posting term; no candidate constraint given | Closing question Q1 |
| R2 | Salary £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | You gave no pay floor. The posted range is stated, but whether it works for you is unknown. Posted range sits inside the market interquartile range. | `[grounded]` posting; `[generic]` market band | Closing question Q1 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations. Confirmed in your message, specific, no artifact inspected yet. | `[grounded]` your stated background | none |
| R3b | That experience at a B2B software company | must_have | unclear | low | discovery | You describe a B2B payments company. Whether it counts as software is not established. | `[grounded]` your wording "B2B payments company" | Ask whether the company sells software; one line, no question slot needed unless it matters to you |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified. The posting accepts either tool. A certificate would raise this to high. | `[grounded]` your stated certification | offer: the certification record would raise to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | You use SQL weekly and Excel daily. That shows usage, not depth or modelling, so fit is adjacent until an example shows what you build. | `[grounded]` your stated frequency | Share one model or query you built, sanitised |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You have never owned the company forecast; finance did. You run the monthly pipeline review with your sales director, which is near-forecast work. Limit: ownership of the number and the CFO relationship were not exercised. | `[grounded]` your statement of both facts | Closing question Q2; bridge case in G3 |
| R7 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | You have never worked on billing data. The "or revenue data" wording may be met by your renewal dashboards, but whether finance used them is unstated. | `[grounded]` your statement; `[inferred]` that renewal reporting is revenue data | Closing question Q3 |
| R8a | Owning the CRM | must_have | direct | medium | none | You rebuilt your pipeline dashboards in Salesforce and are certified as admin. Whether you owned the CRM end to end is stated only as admin and dashboard work. Carried at the narrower claim. | `[grounded]` your stated work | none |
| R8b | Owning billing data | must_have | absent | none | capability | You have not worked on billing data. | `[grounded]` your statement | Name a closure path in G5; carry as a material risk |
| R9 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is not stated, so this is direct for the building and unconfirmed for the finance audience. | `[grounded]` your stated work | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and schedule (R1, hard_gate) | hard_gate | The posting asks for two office days in Bristol; your constraints are not stated | A failed gate caps the decision however strong the fit | Not a workaround hunt: a plain yes or no on the posted terms | None needed | `[grounded]` posting term |
| G2 | Pay (R2, hard_gate) | hard_gate | The posted range is known; your floor is not | Same cap as G1 | Same as G1 | None needed | `[grounded]` posting term |
| G3 | Owning a forecast (R6, must_have) | transferability | You run a monthly pipeline review with your sales director; finance owned the company forecast | A must-have and a headline duty; the bridge and its limit are what you will be asked about | Owning the commit number in the review; building the roll-up from pipeline stage and renewal dates; reconciling pipeline to finance's number | A sanitised review deck or forecast roll-up | `[grounded]` your statements; `[generic]` that a forecast duty is probed hard in roles that run it with a CFO |
| G4 | Finance on revenue data (R7, must_have) | discovery | Renewal dashboards exist; finance's use of them is unstated | Could move R7 from adjacent toward direct | Finance using your renewal figures in their forecast; resolving a mismatch between CRM and finance numbers; agreeing a revenue definition with finance | A renewal dashboard screenshot, a definitions doc | `[grounded]` your statement |
| G5 | Billing data (R8b, must_have) | capability | No direct or adjacent billing-data work | A headline duty, and the one row with no evidence | Closure path: ask what billing systems Quillfield uses and what ramp support exists; any invoicing or payments data you touched at your current company, if it exists | None unless something surfaces | `[grounded]` your statement; `[inferred]` that a ramp plan is the realistic path |
| G6 | B2B software employer (R3b, must_have) | discovery | Your employer is described as a payments company | A literal reader may screen on "software company" | Whether your employer's product is software | Company description page | `[grounded]` your wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast and billing duties without a stated owner today | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast and billing data may currently sit with finance, so the role would take them over from scratch | `[inferred]` from the duty list against its silence on who holds them now | Who owns the forecast model and billing data today, and what would this role own in its first two quarters? | unresolved |
| RR2 | Posting not found on the company's own careers address | unknown | — | "Revenue Operations Lead, Quillfield" | The role may be listed elsewhere on the site or only through the recruiter and the job board | `[grounded]` one fetch of quillfield.co.uk/careers returned no page; `[generic]` that small companies often post through boards | Is this role open now, and is Tamsin Achebe the hiring manager? | unresolved |
| RR3 | Pay is stated and sits inside the market range | positive_signal | — | "£61,500–£67,000 plus share options" | The employer is transparent on pay | `[grounded]` posting; `[generic]` market band | What is the review cycle for this band? | noted |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | The options may be small or slow to vest | `[inferred]` from the posting's silence on size and vesting | What is the option grant size and vesting schedule for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol two days a week and the pay range work for you before investing in the loop | see R1, R2 | `[grounded]` posting terms | pending your approval |
| A2 | Ask the recruiter to confirm the role is open and that Tamsin Achebe is the hiring manager | see RR2 | `[grounded]` your recruiter's statement | pending your approval |
| P1 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review you run with your sales director, as direct evidence for the pipeline and renewal reporting duty | see R9, R8a; every clause traces to your own sentences | `[grounded]` your statements | pending your approval |
| P2 | If asked about forecasting or billing, say it as you told me: finance owned the company forecast, and you have not worked on billing data; then ask how the ramp works | see R6, R8b; keeps the claim at what you said | `[grounded]` your statements | pending your approval |
| P3 | Ask RR1, RR2 and RR4's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved the role reality organization row; the missing careers page moved RR2. |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR3; it gave pay only, so the scope read stays an inference. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the role reality hiring manager row and the lead-with choice in P1. |

I can write all of this up as a `tuesday-dossier.md` if you want a saved copy.

**Upgrade menu**

- Your location and pay floor settle R1 and R2, and the status likely moves to `go` or `no_go`.
- Your CV, or a sanitised pipeline review deck, would show presentation gaps and could raise R5, R6 and R9.
- The Salesforce certification record would raise R4 to `high`.
- The recruiter's answers on who owns the forecast and billing today (RR1) and on the option terms (RR4) would close those entries.
- A deeper research pass on Quillfield (funding and leadership changes, recent news, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

- Q1 (G1, G2): Do two days a week in Bristol and a £61,500–£67,000 range work for you as they stand? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Q2 (G3): In your monthly pipeline review, what did you own: the pipeline numbers, a commit or forecast call, or the reporting only? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Q3 (G4): What did you do with finance on revenue figures, for example renewal numbers they used, or reconciling CRM against their numbers? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.