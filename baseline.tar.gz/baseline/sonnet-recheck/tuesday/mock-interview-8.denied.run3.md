Using Read instead.
The write to the working directory was declined, so I'll save the pack to the session scratchpad instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-denied-65d1d4ef/6ba11d10-ebe7-4a63-8c42-818a783401bd/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. I tried the working directory first, but that write was declined.

I built it as three separate mini-packs, one per round on 21 October. Each has its own persona weights, 8–10 questions and reverse questions. The values cheat sheet sits with the panel round. There are 28 questions in total, and a table maps every JD requirement to the questions that cover it.

- **Biggest objection:** The pack names R2-B1 as the highest-ROI prep. It's the question your future manager is most likely to ask: "I don't see contact centre in your background." You told me you've never worked in one, and the JD makes it a headline line. The pack gives you a full follow-up ladder, and the plain "I've never worked in a contact centre" is the answer you open with.
- **Second gap:** You've never presented above regional level, which the pack covers in R1-B2 and R2-B2.
- **Answer slots:** Where your material is silent, the pack leaves a slot for you to fill in your own words rather than writing a story for you. Those are F1, F3, F4, F5, F6 and F8: end-to-end ownership, what your spreadsheet held, Excel, coaching supervisors, digital work, and regulated complaints. Both branches of each slot are fine answers.
- **Values stories:** None of your four background sentences carries a story for any of Ashgrove's four values. R3-C1 to R3-C4 are scaffolds for finding real examples, not mapped stories.
- **Case scenario:** R3-D1 is a practice scenario, because the real 20-minute case is unknown. Ask the recruiter whether it's shared in advance.

I ran no searches. Your pasted values, the recruiter's email, the JD and your brief summary already covered everything a search would have fed. The prep schedule counts nine days from 12 October, as you said.

Say the word and I'll run a live drill as the Skeptic on R2-B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Interviewers:** not yet assigned; only their roles are known
**Mode:** loop (three scheduled rounds, all on 21 October)

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| R1 | The recruiter | 30 min | A conversation about the process and fit |
| R2 | Head of Member Services (your future manager) | 45 min | Mostly behavioural |
| R3 | Panel of two branch managers | 60 min | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Built from: the JD, the values text you copied on 12 October, the recruiter's email, your four-point summary of the June 2026 strategy brief, and your background message. There is no CV in the inputs, so every "your CV" slot below is "your message".

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Guidance is scaffolding, not a script. Say only what you actually did, in your own words.
- Question IDs read round, then persona letter, then number: R2-B1 is round 2, Skeptic bank, question 1. Fit rows are F1 to F9.
- Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Data-Driven Prober, F Peer Evaluator, G Pressure.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition |
| CASE | Structure and reasoning on a live problem from the role |

A question with two natures carries its primary type in the Type column; the rationale says the other.

An answer slot is an instruction for the interview, not a question for this chat. Where a slot appears, decide your honest answer before the day. Either branch is a good answer.

## Prep triage (9 days: counted from 12 October to 21 October)

1. **R2-B1**, the contact-centre objection. It is the highest-ROI prep in the pack: the fit snapshot's stated gap (F2) sits on the JD's headline line. Rehearse the whole ladder aloud until it is boring.
2. **Answer slots on F1, F3, F4, F5, F6 and F8.** Write one honest sentence per branch, in your own words. These are the places a probe lands.
3. **R3-D1**, the 20-minute case structure. Run it aloud twice, with a timer.
4. **R3-C1 to R3-C4**, one real story per value. The scaffolds find them; the pack cannot supply them.
5. **R1-A1**, your 90-second arc, because all three rounds start from it.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If any step beyond the log was yours, say which and what you did, in your own words; if the log was the part you handled, say so plainly and stay with it |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence shows a monthly spreadsheet your regional manager uses; it does not show what it counts. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours held. If it held either, say which and how each was counted; if it held something else, or neither, say so plainly and say what it did hold |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not which tool. Answer slot: if you built it in Excel, say so and say what it did, in your own words; if it was built in another tool, or you used Excel for other things, say so plainly and say where your limits are |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your quote carries training tellers on a script, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on whether you have coached people at your own level or above on escalations. If you did, say with whom and what you did; if the tellers are the coaching you have done, say so plainly and stay with them |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here, and silence is not an absence. Answer slot: the JD names digital teams and self-service journeys, so expect a probe on any work with online or app channels. If you have worked with such a team, say on what and what part was yours; if you have not, say so plainly and say how you would approach a first conversation with them |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so lead with it as you wrote it: "I've spent six years in retail banking, the last three as a branch supervisor." Let the interviewer make the match; do not rename your work in the JD's vocabulary |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The quote says formal complaints; it does not show what rules governed them. Answer slot: the JD says regulated, so expect a probe on what rules applied to the complaints in your log. If a regulatory process governed them, say which and what it required of you; if you do not know, or none did, say so plainly and stay with the log you handled |
| F9 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. The quote does not say whether you have presented at regional level; R1-B2 holds that as a slot |

No row is a hard gate: the JD's requirements are experience and skills, and a length-of-experience line (F7) is graded like any other row.

## Grounding brief

Your four-point summary of Ashgrove's June 2026 strategy brief. The brief itself was not pasted; the pack uses only these four points.

| Brief point, as you gave it | Used in | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | R1-A3, R2-D1 | [grounded] |
| "consolidate eight branches into five hubs over 2027" | R1-A3, R2-B3, R3-D2, R3-C3 | [grounded] |
| "launch a small-business lending product in Q1 2027" | R1-A3 | [grounded] |
| "the main competitive pressure is app-only banks" | R1-A3, R1-A2 | [grounded] |

---

# Round 1: the recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, unstructured; the biography question; feels unscored | High. The relationship prior for a recruiter screen is Conversational plus a light Skeptic, and the email gives the recruiter this round | A 90-second arc built from the quotes; treat casual questions about complaints and reporting as scored |
| B. Skeptic (light) | Short checks on the two stated gaps, in a friendly register | Medium. Same prior; F2 and F9 are the gaps this persona would find first | Plain acknowledgment, then a plan, said once and briefly; the same words you will use in R2 |

Weights rest on the recruiter's own description of the rounds, not on an archetype.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So — walk me through the journey. Where have you been, and what's brought you to Ashgrove?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A 90-second arc in the beats the quotes state, in your own words and this order: six years in retail banking, the last three as a branch supervisor; the formal complaints log you handled; the new tellers you trained on your escalation script. Answer slot: why Ashgrove is yours alone to say. Say what drew you here, and name one of Ashgrove's published values only if it is true for you | F7 is the experience line a recruiter checks first, so JD; the delivery is Conversational, so it is scored though it feels casual |
| R1-A2 | "What draws you to a member-owned credit union rather than another bank?" | CO | [grounded] | Your own reason, in your own words: one thing that is true for you, and one thing specific to Ashgrove drawn from the values text or the brief points above. Do not borrow a reason you do not hold | The JD's opening line says member-owned; this tests motivation consistency across the loop, so it will be asked again in other forms |
| R1-A3 | "What have you read about where Ashgrove is heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028; consolidate eight branches into five hubs over 2027" | Name two of the brief's moves in its own terms, and for each say one thing you would want to understand from a complaints point of view. Ask rather than assert. The brief as you described it says nothing about complaints, so do not suggest it does | The recruiter sent the brief, so familiarity is expected; this is the cheapest CO question to prepare |
| R1-A4 | "Tell me about your complaints experience. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 and F8 at the quote's scope: you handled the branch's formal complaints log, and you trained new tellers on your escalation script. Answer slot: the JD's regulated line makes a probe on the rules behind that log likely. If a regulatory process governed those complaints, say which and what it required of you; if you do not know, or none did, say so plainly and stay with the log you handled | F8 is the requirement a screen is most likely to test, and F1 is the nearest to the role; JD because it scores the stated complaints requirement |
| R1-A5 | "Tell me about the monthly reporting you've done on complaints." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote states: you built a monthly complaints spreadsheet; your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect a probe on what it held and what it was built in. If it held either measure, say which and how each was counted; if it held something else, say so plainly and say what; if it was built in another tool, say that | F3 and F4 together; JD because it scores the reporting and Excel lines, asked in a friendly register |
| R1-B1 | "The role covers the contact centre as well as the branches. How do you see that fitting your background?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Lead with the plain acknowledgment: "I've never worked in a contact centre." Then a plan, said as a plan: what you would want to learn first and from whom, before proposing anything. Close on what your material carries: "I handled the branch's formal complaints log." Claim no skill that sits next to a contact centre | F2, the stated gap, in its light screening form; the same words feed R2-B1, so say them identically |
| R1-B2 | "This role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, as a plan. Answer slot: if you have presented at regional level, say what you presented and to whom, in your own words; if you have not, say so plainly and say what you would do first | F9, the second stated gap; JD because the JD names it |
| R1-B3 | "Why leave a supervisor role you know for this one, and why now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Your own reason, in your own words, pointing toward the role rather than away from your current one. Answer slot: the pack does not know why now, so decide the answer and keep it consistent with R1-A1 and R1-A2. If part of the reason is practical, say it plainly | Motivation consistency is what a Skeptic scores; JD because it tests fit for this role. F7 is the background it starts from |

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| R1-X1 | "What would the Head of Member Services most want changed in the complaints process by the end of the first year?" | It asks for the success measure from the person who would manage you, and shows you think in outcomes |
| R1-X2 | "Is the case in round three a scenario I can prepare for, or live on the day?" | The recruiter is the one person who can say; it settles whether a graded deliverable section is needed |
| R1-X3 | "Once the panel is assigned, could you tell me their roles or names?" | Interviewer names let the persona weights be set per person instead of per role |

---

# Round 2: the Head of Member Services (45 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C. Values/Behavioral | Open prompts: "Tell me about a time…"; stories scored against what a manager needs | High. The recruiter's own description says mostly behavioural, which lifts this persona above the hiring-manager prior | A story for each theme where a quote carries one; a selection scaffold where none does; "we" for context, "I" for contribution |
| B. Skeptic | Quiet, persistent probes at the gaps, above all the contact centre | High. The hiring-manager prior includes the Skeptic, and this person would manage you, so they are pricing the gaps | Rehearse R2-B1 until boring; calibrated candour over bluffing a competency they may own |
| E. Data-Driven Prober | Line-by-line questions on the one concrete artifact you have: the spreadsheet | Medium. My judgment: it is the only piece of your work the material names that they could ask you to walk through (F3, F4) | Know what it held and what it did not, and say plainly when you do not know |
| D. Case/Strategist | One strategy question at the company's altitude | Low. The prior puts the Case persona high for a hiring manager, but the recruiter's description moves weight to behavioural | Clarify, then structure, then answer; use the brief's own vocabulary |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "I don't see contact centre in your background, and this role owns complaints across the branches and the contact centre. How would you handle that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI prep in the pack.** Layer 1: "I've never worked in a contact centre." Then the plan, as a plan: learn how complaints reach and leave that channel from the people who take them, before proposing anything. Then return to what your material carries: "I handled the branch's formal complaints log." Follow-up one (what in the meantime): stay with the plan and ask what support exists. Follow-up two (that is a big gap): concede it specifically, as new ground for you, and do not fold on the rest of what you said. Follow-up three: answer slot. If any of your branch complaints work involved handing complaints to the contact centre or receiving them from it, say what you did, in your own words; if none did, say so plainly and stay with the branch work | F2 is a gap you stated, it sits on the JD's headline line, and the person who would manage you will ask it in some form. JD because it scores that line; Skeptic in delivery. Deepest means the most follow-up layers and the limit named before it is asked for |
| R2-B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name one yourself before they do. Your material states two: the contact centre and presenting above regional level. Pick the one you would put first, say your plan for it, and say what you would not claim in the meantime. Answer slot: if a third part of the JD would be weaker for you, say so in your own words | F2 and F9; the question the Skeptic stem is built around. A candidate who names it first converts a probe into a plan |
| R2-B3 | "You've spent six years in branches. How do you feel about a plan that consolidates eight of them into five hubs?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "consolidate eight branches into five hubs over 2027" | Neither perform enthusiasm nor resistance. Say what you would need to understand: what a member sees at each stage, and what is decided versus still open. If Ashgrove's value "Neighbours, Not Numbers" fits what you actually think, name it; if not, leave it | Tests whether a branch background becomes resistance to the brief. F7 is the background it starts from; CO because it is the brief's second move |
| R2-C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F5 at the quote's scope: you trained new tellers on your escalation script; tell that in your own words. Answer slot: the JD says supervisors, and the question says through an escalation. If you coached anyone, at any level, through a live one, say who and what you did; if the training of tellers is the coaching you have done, say so plainly and stay with it | F5 transferability; JD because it scores the coaching line, and behavioural in delivery |
| R2-C2 | "Tell me about a time you put a member ahead of an internal metric." | VAL | [generic] | Selection scaffold. Pick a time with a named stake: a member's interest on one side, a target or measure on the other. It needs the moment you chose, what happened, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, and it points at the "Members First, Always" value. No sentence in F1 to F9 carries this story, so it is a scaffold, not a mapped answer |
| R2-C3 | "Tell me about a time you delivered an unpopular truth to someone senior to you." | VAL | [generic] | Selection scaffold. Choose a case where the hard truth actually landed and the working relationship survived; name the stake and what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F9 tested sideways: it probes how you deal with seniority without asking for a presentation. No quote carries a story here, so no beats are supplied |
| R2-C4 | "Tell me about a time you worked with a team outside your branch to fix something for members." | JD | [grounded] | Selection scaffold. Pick a case with a named team, a named problem, and your own part in it. Answer slot: the JD names digital teams, so expect a probe on any digital or online work. If you worked with such a team, say on what and what part was yours; if you did not, say so plainly, then give the nearest cross-team case your material carries, or how you would begin with a digital team | F6 has no evidence in your material, so this is where a story would have to come from you; JD because it scores the digital-teams line |
| R2-E1 | "Walk me through the monthly complaints spreadsheet you built. What's in it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The beats the quote states: you built it; it is monthly; your regional manager uses it. Answer slot: the JD names volumes and resolution times. If it held either, say which, how each was counted, and the assumption you would defend least; if it held something else, say so plainly and say what | F3 is the one concrete artifact in your material, so a Prober goes here; EXP because it tests what was actually yours |
| R2-E2 | "How comfortable are you in Excel, and where does it stop?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you built and where your limits are, plainly; naming a limit reads as calibration. Answer slot: if the spreadsheet was built in Excel, say what it did in your own words; if it was built in another tool, or you cannot say, say that and stay with what you can describe | F4; JD because it scores the Excel line |
| R2-D1 | "The brief aims to move 40% of member service to digital channels by 2028. How should complaints work in that world?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" | A live problem; it asks for nothing about your past. Clarify first: what counts as a complaint on a digital channel, where it is logged, who owns it. Objective: a member never explains the same thing twice, in the spirit of "Plain Words". Segment by channel; approach; measures (volumes and resolution times are the JD's); risks, including a member moving between channels. Challenge one premise respectfully | The differentiator question most candidates cannot touch without the brief; F6's requirement in strategic form |

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| R2-X1 | "Complaints cross the branches and the contact centre today. Where does ownership change hands, and where do members get stuck?" | Uses "Own the Fix" vocabulary and asks about the end-to-end line in the JD, which tells you what F1 will really mean |
| R2-X2 | "The brief targets 40% of service on digital by 2028. What is the digital team already planning for complaints?" | Ties to the JD's digital-teams line and the first brief point; the answer tells you how big F6 is |
| R2-X3 | "What should I learn about the contact centre in my first month, and from whom?" | Turns the stated gap into a working relationship with your future manager |

---

# Round 3: the panel of two branch managers (60 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C. Values/Behavioral | One question per published value, scored against the value | High. The recruiter's email says this panel is the values round and scores against the four values | A story for each value; a selection scaffold where no quote carries one; pick stories where the hard truth landed |
| D. Case/Strategist | The 20-minute complaint-escalation case, plus a strategy question | High. The email states the 20-minute case | Clarify, then objective, segmentation, approach, measures, risks; think aloud; challenge one premise |
| F. Peer Evaluator | Seam questions: what you would need from them, who owns what | Medium. My assumption: branch managers are the stakeholders whose supervisors you would coach, so a seam read applies; the recruiter did not say | Reciprocity; propose seam principles rather than pretending to know the seam |
| B. Skeptic | The coaching-credibility probe in a panel setting | Low. Panels blend each member's top personas, and R2-B1 covers the main objection | The same plain acknowledgment and plan you used in R1 and R2 |
| G. Pressure | One time-boxed challenge on why you | Low. Included so the style is not met cold | Pause, restate, hold on what you stated, concede specifically |

Panel names are unassigned, so personas are set for the panel as a whole.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for "Members First, Always". Pick a decision where the member's side and the institution's side pulled apart; say what you weighed, what you chose, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first of four value questions. No quote in F1 to F9 carries a decision story, so none is mapped |
| R3-C2 | "Tell me about a time something you said or wrote needed explaining twice. What did you change?" | VAL | [grounded] | Selection scaffold for "Plain Words". Pick a case with a specific explanation, the moment you saw it had not landed, and the change you made. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value text says an explanation needed twice means "we wrote it wrong"; this asks for your version. No quote carries it |
| R3-C3 | "Tell me about a time what the numbers said and what a neighbour needed pulled apart." | VAL | [grounded] "consolidate eight branches into five hubs over 2027" | Selection scaffold for "Neighbours, Not Numbers". Pick a case with a figure on one side and a person or town on the other; say what you did with the tension. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The brief's consolidation is the live version of this tension in front of both panellists; do not argue the plan, describe your own case | The brief's consolidation is the context a branch-manager panel will hear this value in. No quote carries a story |
| R3-C4 | "Tell me about a time you found a problem that wasn't yours to fix, and what you did." | VAL | [grounded] | Selection scaffold for "Own the Fix". Pick a problem you found, who it belonged to, and how you kept hold of it until it was solved or handed over by name. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The fourth value; also the shape of a complaints lead's job. No quote carries it |
| R3-D1 | "A member comes into a branch to complain about a charge on their account. They tell the supervisor they have phoned the contact centre twice and nobody has called them back. The supervisor isn't sure whether to escalate. Talk us through what you do." | CASE | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A live problem; it needs no claim about your past. Clarify aloud first: what the complaints policy requires and by when, whether the earlier calls were logged, what the member wants. Objective: the member leaves knowing who has the complaint and what happens next. Then ownership and handover, what is recorded, how you measure it, and the risk of the member bouncing between channels. Answer slot: if the escalation script you trained tellers on covered a case like this, say what it asked of a teller; if you cannot say, or it did not, say so plainly and say you would check Ashgrove's | This is the stated 20-minute case, but its scenario is unknown, so this is a practice shape and labelled generic; ask the recruiter (R1-X2). F5 and F1 are the rows it draws on. The value text is the scoring lens: "Own the Fix" and "Plain Words" |
| R3-D2 | "Eight branches become five hubs over 2027. What happens to complaints from members whose branch changes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" | A live problem; it needs no claim about your past. Clarify what is decided and what is still open. Then members affected, how complaints get a clear owner during the change, what to measure, and the risk of "Neighbours, Not Numbers" being read as a slogan. Challenge one premise respectfully, for example whether the change is the same for every branch | Both panellists run branches, so this is the question closest to their own work; CO because it is the brief's second move |
| R3-F1 | "You'd be coaching our supervisors on escalations. Where is the line between your job and ours when a supervisor and a member disagree about what to escalate?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Propose seam principles rather than claiming to know the seam: the member's side first; the person who finds the problem keeps hold of it until it is handed over by name; you coach the supervisor's judgment and do not overrule it on the day. Mention what you have done at the scope the quote carries: you trained new tellers on your escalation script. Answer slot: if you have worked beside a branch manager on a disputed escalation, say what happened and what part was yours; if not, say so plainly and stay with the principles | F5; JD because it scores the coaching line, Peer in delivery. Principles, not claims, because you do not know Ashgrove's seam |
| R3-F2 | "What could you do in your first month that would genuinely help our branches?" | JD | [generic] | A reciprocity answer, as a plan and not a past: ask each branch which escalations cause the most trouble, and what a supervisor most wants from someone in this role, before changing anything. Give a plan you would actually follow | The peer reciprocity question: what you bring them, not what you need |
| R3-B1 | "You'd coach branch supervisors, people in the job you've just been in. Why would they listen to you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Stay with what the quotes carry: you have been a branch supervisor for the last three years, and you trained new tellers on your escalation script. Then a plan: listen to what supervisors already do before offering a method. Answer slot: if a supervisor or colleague has come to you for help with an escalation, say what happened; if none has, say so plainly and stay with the tellers | F5 and F7; the credibility probe on the coaching line, delivered as a Skeptic |
| R3-G1 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold only what the quotes carry: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log you handled; the tellers you trained on your escalation script. Hold through two follow-ups by returning to those facts, never by adding to them. Then concede specifically: "I've never worked in a contact centre." Then the plan. Do not fold on the rest to restore harmony | F1 and F2 under time pressure; the pressure persona scores composure, so JD in content, Pressure in delivery |

### Values / principles cheat sheet

A values-style round is detected: the recruiter's email names the panel as the values round, scored against the four values. Official names are from the text you copied on 12 October.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No row F1 to F9 carries a story for this. Selection scaffold (R3-C1): a decision where member and institution pulled apart. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | An explanation a member must hear twice is the fault of the writer | No row carries a story for this. Selection scaffold (R3-C2): a specific explanation that did not land, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Neighbours, Not Numbers | Each branch belongs to its town, not only to a table of figures | No row carries a story for this. Selection scaffold (R3-C3): a figure on one side and a person or town on the other. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | No row carries a story for this. Selection scaffold (R3-C4): a problem you found that was not yours, and how you kept hold. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| R3-X1 | "What is one escalation from your branch that you would have wanted handled differently?" | Asks the panel for their own case, which is "Own the Fix" from their side, and gives you real material for the case discussion |
| R3-X2 | "How do you see the move to hubs changing what your supervisors face day to day?" | Engages the brief's second move through the people it touches most, without arguing the plan |
| R3-X3 | "What would help your supervisors most from someone in this role in the first month?" | The reciprocity question for stakeholders you would work beside |

---

## Requirement coverage

| JD requirement | Fit rows | Questions |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | F1, F2 | R1-A4, R1-B1, R2-B1, R3-D1, R3-G1 |
| Report monthly on volumes and resolution times | F3 | R1-A5, R2-E1 |
| Coach branch supervisors on escalations | F5 | R2-C1, R3-F1, R3-B1 |
| Work with digital teams on self-service journeys | F6 | R2-C4, R2-D1 |
| 4+ years in financial-services customer operations | F7 | R1-A1, R1-B3 |
| Experience handling regulated complaints | F8 | R1-A4 |
| Confident presenting to senior leaders | F9 | R1-B2, R2-B2, R2-C3 |
| Comfortable with Excel reporting | F4 | R1-A5, R2-E2 |

Each of the four published values has its own VAL question (R3-C1 to R3-C4). Strategy questions: R1-A3, R2-B3, R2-D1, R3-D2.

## Prohibited claims

Not coached by this pack, each with its basis. Built from the fit snapshot because there is no dossier.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's formal complaints log, not the process end to end. R1-A4 and F1's slot stay inside the log |
| Has contact-centre experience, or knows where complaints get stuck there | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." Then a plan. R2-B1's slot asks only whether your branch work touched the channel |
| Has presented to senior leaders | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." Then a plan |
| Coached supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: you trained new tellers on your escalation script. The limit is the pack's observation: the material says tellers, not supervisors. R2-C1's slot stays inside the training |

## Sources

**Provided documents:** the JD (pasted); Ashgrove's four values (pasted, copied from the values page on 12 October 2026); the recruiter's email; your four-point summary of the June 2026 strategy brief (the brief itself was not pasted); your background message. No `tuesday-dossier.md` was present.

**Searches and fetches sent:** none. The values page is named as where you copied text from, not a link for me to read, so it was not fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the values cheat sheet or the VAL bank: the pasted text already gives all four values by name and definition |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email names three rounds, their lengths, who runs them and what they hold |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Could not have moved the CO bank: the four brief points you supplied fix the strategy questions written here |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names were given, so no query could be formed; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Your CV, as text** → the evidence cells quote your CV as well as your message, and F1, F3, F4, F5 and F8 are re-graded; lines that now stand alone may lift a `medium` row
- **The monthly complaints spreadsheet, with all member data removed, or a plain description of its columns** → F3 and F4 become inspected rather than reported, and R1-A5, R2-E1 and R2-E2 become mapped answers
- **Your answers to the slots in F1, F3, F4, F5, F6 and F8, in your own words** → those rows regenerate from your quotes, and R1-A4, R1-A5, R2-C1, R2-C4, R2-E1 and R3-F1 become story-mapped
- **One real example for each of the four values** → R3-C1 to R3-C4 and the cheat sheet become mapped stories instead of scaffolds
- **The panel's roles or names, and the Head of Member Services' name, once assigned** → an interviewer read, per-person persona weights, and a reverse question tied to someone's own path
- **The recruiter's answer on whether the case scenario is shared in advance** → if it is a pre-declared task, a build section for it; otherwise R3-D1 stays a practice shape
- **The strategy brief itself** → more brief points than the four used here, and current CO and CASE questions in its vocabulary
- **A deeper research pass (L2)**: up to 6 more searches and 2 more fetches, several more minutes, offered once → Ashgrove's recent public context and role-family interview reports, if you want it
- **A `tuesday-dossier.md` from an earlier role assessment** → would add a named top objection, allowed strategies for each weak area, and absolute prohibited claims; the pack stands without it
