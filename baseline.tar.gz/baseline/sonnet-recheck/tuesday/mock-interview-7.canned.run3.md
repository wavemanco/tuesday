Research is back with real results for all four targets. I'm fetching the values page and the interviewing page next so I can quote them exactly.
I couldn't save the pack to the working directory. I'll save it to the session scratchpad instead.
Femi, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-canned-9b1897c2/e5aea8fe-c46a-49bf-a4ed-eec5dbb91520/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. The working directory refused the write, so it went to the session scratchpad.

Saltmarsh's careers page says every loop is a recruiter call, then one 60-minute hiring-manager interview. That interview is a live-incident tabletop on a simulated outage, then a values conversation. I built the pack for that format and assumed Tobias is the hiring manager.

The highest-ROI prep is question C1. Saltmarsh announced "Project Larkspur" in August: a season-pass model and one events calendar from January 2027. Your "never worked on a game with in-app purchases" is the gap that announcement exposes, so rehearse C1 until it's boring.

Two facts come only from search-result snippets, because I used up my page fetches on the values and interviewing pages. One is Project Larkspur. The other is Tobias's GDC talk, "Patch Notes Are a Promise," and his earlier QA-lead background. I couldn't verify the talk page's host as an official GDC site, so check both yourself before leaning on them. Sources in the pack flags this.

Say the word and I'll run the tabletop (A1) with you, or play the Skeptic on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or a level above? If he's above, I'd reweight the banks toward strategy and altitude.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager (one assumption: Saltmarsh's interviewing page says the 60-minute interview is with the hiring manager, and you told me Tobias is your interviewer).
**Round:** Saltmarsh's interviewing page describes every loop as a recruiter call and then the Outage Hour: a single 60-minute hiring-manager interview made of a live-incident tabletop on a simulated outage during a live event, followed by a values conversation. There is no take-home. This pack prepares for that hour.
**Version:** first build.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior demonstrates Saltmarsh's published values |
| EXP | Whether the claims in your background survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's current altitude |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots in the guidance are instructions for the interview. Where one appears, answer it from your own experience or say plainly that the practice was not yours.

## Prep triage

The interview is Friday. In priority order:

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the season-pass and in-app-purchase question aloud until it is boring. This is the highest-ROI prep in the pack | C1, then C2 and E1 |
| 2 | Run the tabletop out loud twice, speaking your structure as you go | A1, A2, A3 |
| 3 | Decide, for each of the three values, whether you have a real story or the honest branch | B1, B2, B3, values cheat sheet |
| 4 | Practise the retention walk-through and the answer slots on it | D1, D3 |
| 5 | Pick your reverse questions and rehearse the 90-second arc | Reverse questions 1 and 2, F1 |

Everything else is insurance.

## Fit snapshot

Your evidence cells quote your own message. Rows are numbered S1 to S8.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| S1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, not live events and not two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events wording makes a probe on events likely. If any of the drops were time-limited events, say which and how you scheduled them, in your own words; if none were, or the scheduling was not yours, say so plainly and stay with the weekly calendar you ran |
| S2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a calendar is not the same as coordinating those four teams, and the bridge should not be stretched. Answer slot: if the weekly drops needed design, art, engineering or community, say which of those you worked with and what you needed from each; if some were not part of how the drops ran, or the working with them was not yours, say so plainly and stay with the calendar you ran |
| S3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or the KPIs behind it, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review wording makes a probe on what happened after your drops likely. If you wrote or ran reviews after drops, say what they covered and who read them; if there were none, or they were not yours, say so plainly and stay with the monthly numbers you presented |
| S4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the quote's terms, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you wrote it, and your QA team still uses it. The quote does not say who runs it at each release, and the words stay with writing it |
| S5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years producing and two years running the weekly calendar. It does not say whether the puzzle game was a live-service title or what the other two years covered. Answer slot: the JD's live-service wording makes a probe on which years were live likely. Say which years ran on a live title and what it was live with, in your own words; if the earlier years were not on a live title, say so plainly and stay with the two years you ran the calendar |
| S6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the quote's terms, but nothing is inspected behind it, so expect a probe on how the numbers were counted (D1). Lead with it in its own terms: monthly, to the studio head |
| S7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written document that others use is the only written work your material shows, and it does not show how clearly it communicated. Answer slot: if you wrote anything else that others relied on, say what it was and who read it; if the checklist is the main written work, say so plainly and stay with it |
| S8 | Role context, not a JD line: Saltmarsh's Project Larkspur announcement (August 2026, search result) moves two titles to a season-pass model from January 2027. Whether this role's two titles are those two is not established | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The link between this role and the season pass is the pack's derivation; the supplied JD itself lists neither monetization nor leading people. Nothing is added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. The talk listing came from a search-result snippet; the page itself was not opened, and nothing beyond the snippet is used.

| # | Item | Source | Provenance |
|---|---|---|---|
| I1 | Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | GDC 2026 talk listing, search-result snippet | [grounded] |
| I2 | Gave the GDC 2026 talk "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes describe what actually shipped | Same listing | [grounded] |
| I3 | Implication: I2 and Saltmarsh's second published value, Ship the Patch Not the Promise, point the same way, so expect questions that test whether what was said matches what was built | Derived from I2 and the values page | [inferred] |
| I4 | Implication: a QA background makes the release checklist shared vocabulary; lead with S4 in its own terms | Derived from I1 and S4 | [inferred] |
| I5 | Implication: claims are likely to be tested against what actually happened and what was yours, so exact attribution (D1, E2) serves you better than breadth | Derived from I1 and I2 | [inferred] |

Mirror opportunity, shared vocabulary: S4's quote, "Wrote the release checklist our QA team still uses." No shared career jump is offered, because no row of your evidence carries your side of a QA-to-live-ops move.

## Persona table

Weights start from the relationship prior, then interviewer signals, then the loop.

| Persona | How it shows up in this hour | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | The tabletop: a simulated outage during a live event, and planning problems from the role | High. Hiring-manager prior puts it first, and the interviewing page documents the tabletop, so a live problem is near-certain | Clarify, state the objective, structure, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral (bank B) | The values conversation, mapped to Saltmarsh's three published values | High. Not a hiring-manager prior, but the interviewing page documents a values conversation in this same hour | Map a story to a value only where your own sentences carry one; otherwise use the honest branch; "we" for context, "I" for contribution |
| Skeptic (bank C) | Quiet probing of what your background does not show | High. Second hiring-manager prior, and S8 and S2 give it material | Rehearse the single most predictable objection (C1) until it is boring; bridge only from your own sentences; state the limit plainly |
| Data-Driven Prober (bank D) | Retention numbers and reviews probed to how they were counted and what was yours | Medium. Not a hiring-manager prior; raised by I1 and I2 | Say how a number was counted or say you do not know; name the assumption you would defend least before they do |
| Pressure (bank E) | Time-boxed or devil's-advocate follow-ups, possibly inside the tabletop | Low. The simulated outage may add time pressure, but no source says the interviewer applies it | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (bank F) | Opening and closing chat, which still counts | Low. The recruiter call is a separate session; this hour opens straight into the tabletop on the page's account | Prepare the 90-second arc; never answer "I think you've covered everything" to the reverse-question slot |
| Peer Evaluator (bank G) | Seam questions about working with design, art, engineering, QA and community | Low. Tobias is not a peer, but these teams are your day-to-day partners | Offer seam principles, not claims about a seam you do not know; reciprocity framing |

The interviewing page does not say how the hour splits between the tabletop and the values conversation. Banks A and B are weighted equally for that reason.

## Question banks

### Bank A: Case/Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the first evening of a live event and a share of players can't load into it. Community is filling up with reports. Talk me through your first thirty minutes." | CASE | [generic] | Structure it aloud. Ask first: who is affected and on which platforms, what changed since the last good build, whether the event can be paused or rolled back, and who owns the fix. State the objective: players back in, told the truth. Say who you would pull in from engineering, QA and community and what you would need from each. Say what you would tell players now and what you would hold until it is built. Say how you would know it is fixed, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The interviewing page documents a live-incident tabletop on a simulated outage during a live event, and this is its likeliest shape. CASE because it is a live problem; generic because the scenario is a pattern, not a fact about Saltmarsh |
| A2 | "Engineering says the fix is two hours out. The event ends tonight and the next one starts tomorrow. What do you do with the calendar?" | CASE | [generic] | Same structure, then decisions: the options for this event and for tomorrow's (extend, hold, move, leave as scheduled), what you recommend, what you would need to confirm, and who has to agree. Put what players need ahead of what the schedule says, and say why in your own framing rather than reciting a value. No claim about your past is made | The calendar is S1's requirement, and the first published value says the players win when the two disagree. CASE because it is decided live; generic for the same reason as A1 |
| A3 | "The fix slips and the event is delayed a day. Say out loud the player-facing note you'd post, in two sentences." | JD | [generic] | Say what is true now, what players can do, and when the next update comes. Announce only what is built, and promise no time you cannot confirm. Keep it plain enough to read aloud once. No claim about your past is made | S7's requirement is clear written communication, and the second published value is about announcing only what is built. JD content with CASE delivery |
| A4 | "In August we announced Project Larkspur, with a season pass and one events calendar from January. What do you think that changes about planning events, and what would you want to find out first?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Frame it as questions you would ask, not knowledge you lack: how events relate to the pass, who owns what in a single live-ops group, which dates are fixed. If pressed on season-pass economics, say plainly: "I've never worked on a game with in-app purchases." Then say what you would read and who you would ask first, as a plan. Return to the calendar you ran, at its own scope | The announcement is Saltmarsh's current strategy, and S8 is where it meets your gap. CO because it tests altitude on the company's own news |
| A5 | "You'd plan events for two titles. Walk me through building a six-week calendar from scratch, and where you expect the conflicts." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Structure it: fixed dates and dependencies first, then what each team needs, then collisions between the two titles, then room for QA. Tie it to the calendar you ran, at its own scope: a weekly content-drop calendar for your main title. Answer slot: the JD's two-titles and live-events wording makes a probe on events likely. If any of your drops were time-limited events, say how you sequenced them; if none were, or the sequencing was not yours, say so plainly and stay with the weekly calendar you ran | S1 is the core requirement and its evidence covers one title. JD content with CASE delivery |

### Bank B: Values/Behavioral (the values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players pulled in different directions." | VAL | [grounded] | Selection scaffold: pick a time with a named stake on each side, a decision you were part of, and what happened to the plan afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | Saltmarsh's first published value, Players Before Plans, says the players win when the two disagree. A named-value story is what the values conversation scores |
| B2 | "When have you held back an announcement because the thing wasn't built yet?" | VAL | [grounded] | Selection scaffold: pick a time you held something back, who wanted it announced, and what you said instead. If no such time comes to mind, say so plainly, then say how you would handle it | Saltmarsh's second published value, Ship the Patch Not the Promise, is about announcing only what is built, and I2 points the same way |
| B3 | "Tell me about the release checklist you wrote." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Tell the beats the sentence states: you wrote it, and your QA team still uses it. Answer slot: the third published value says every release leaves the checklist better than it found it, so expect a probe on whether it changed. If you revised it after releases, say what changed and why, in your own words; if it was never revised, or the changes were not yours, say so plainly and stay with the checklist you wrote and the fact that QA still uses it | S4 is the only evidence that reaches the third value, Leave the Build Greener. VAL because the probe is the value; EXP in what it tests |
| B4 | "Tell me about a time you had to tell a team something they didn't want to hear before a release." | VAL | [generic] | Selection scaffold: pick a time with a named stake, the moment you said it, and a working relationship that was intact afterwards. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then say how you would handle it | The unpopular-truth stem is a standing values probe and fits a producer who gates releases. Generic because it carries no Saltmarsh-specific fact |
| B5 | "Which of our three values would be hardest for you to live by day to day?" | VAL | [grounded] | Name the value by its official name and describe the tension in plain words. This needs no story and no claim about your past, so choose the answer you can stand behind | A direct values question that tests honest self-assessment. Grounded in the published values page |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and Larkspur moves our titles to a season pass in January. Why isn't that a problem for this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." "Wrote the release checklist our QA team still uses." | The highest-ROI rehearsal in this pack. Name the limit before it is pressed: "I've never worked on a game with in-app purchases." Then hold only what your sentences carry: you ran the weekly content-drop calendar for your main title, presented the monthly retention numbers to the studio head, and wrote the release checklist your QA team still uses. Say once, as a reading of the posting rather than an argument, that the JD as supplied does not list monetization. Follow-up 1, what you would do in your first month: give a plan in the future tense, what you would read, who you would sit with, what you would ask, in your own words. Follow-up 2, whether you could own a KPI judged on purchases: concede exactly, "I've never worked on a game with in-app purchases, so I'd learn how those numbers are read before owning them." Hold through both follow-ups by returning to the three sentences above, never by adding to them: no adjacent knowledge, no figures, no "I've researched it" unless you have. Say "I don't know" where you don't | S8 is the one stated absence that meets the company's own announcement, so this question will arrive in some form. JD because it scores the listed job including its gaps; Skeptic because it presses the gap |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Choose from the thinnest rows (S2, S3, S5, S8), say it before they find it, and follow it with a first-month plan. Name the part honestly; this needs no claim about your past | The standing Skeptic stem. Rows S2, S3, S5 and S8 are the ones where the material is thinnest |
| C3 | "You've never led a team, and this role coordinates design, art, engineering and community on each update. How would you get four teams moving to one date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the acknowledgment: "I've never led a team." Then answer as a method, not a history: what each of the four teams needs from you and when, and where dates collide. Answer slot: if the weekly drops needed design, art, engineering or community, say which you worked with and what you needed from each; if some were not part of how the drops ran, or the working with them was not yours, say so plainly and stay with the calendar you ran | S2 and S8 meet here. The JD asks you to coordinate those teams, which is the question's second half |
| C4 | "You've run one title's weekly drops, and this role runs two titles. What breaks first when you go from one to two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | State the scope first: a weekly content-drop calendar for your main title. Then think aloud about what you would check: shared teams, overlapping dates, QA capacity. Answer slot: if any part of your calendar touched a second title, say how; if none did, or it was not yours, say so plainly and stay with the one you ran | S1's evidence covers one title and the JD names two |
| C5 | "The role asks for three-plus years producing live-service games or apps. Which of your four years were live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say what your sentences state: four years as an associate producer at a puzzle-game studio, and two years running the weekly calendar for your main title. Answer slot: say which years ran on a live title and what it was live with, in your own words; if the earlier years were not on a live title, say so plainly and stay with the two years you ran the calendar | S5 is the requirement with a number in it, and your material does not say which years were live. JD because it scores the listed qualification |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the retention numbers you presented to the studio head each month." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Tell the beats the sentence states: you presented them, monthly, to the studio head. Defend-the-number slots, each in your own words: which retention measure it was and how it was counted, what it was sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly. If the numbers came to you ready-made, say so, and stay with presenting them | S3 and S6 rest on this one sentence, and retention figures are what a prober checks first. EXP because it tests what was actually yours |
| D2 | "Retention for the week after an event came in 20% lower than the week before. Diagnose it." | JD | [generic] | Clarify first: which retention measure, compared against what, which players (new or returning, which platform). Then hypotheses, what shipped against what was announced, what else changed, how you would check each, and what you would report. Think aloud. No claim about your past is made | S6's requirement is comfort with retention metrics. JD content with CASE delivery; generic because the figure and scenario are a pattern |
| D3 | "The role owns the post-event review and the KPIs it reports. How would you structure one, and what part of that have you done before?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure the review as a method: what was planned, what shipped, what the numbers show, what changes next. Answer slot: if you wrote or ran reviews after drops, say what they covered and who read them; if there were none, or they were not yours, say so plainly and stay with the monthly numbers you presented | S3 is the transferability row for this requirement. JD because the review is a listed responsibility |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold on the three sentences: the calendar you ran, the monthly numbers you presented, the checklist QA still uses. Name the limit once: "I've never worked on a game with in-app purchases." Hold through two follow-ups by returning to the three sentences. Concede specifically and never add to them | The classic time-boxed stem aimed at S8. JD because it scores fit for the listed job |
| E2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence as written: "I ran the weekly content-drop calendar for our main title." Answer slot: say which parts of planning and running it were yours; if others set parts of it, say which; if you do not know the split, say so plainly. Hold through two follow-ups by returning to the calendar, never by adding to it | The standard attribution probe, aimed at S1 and I5 |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each one a sentence above, in your own words: the four years, the calendar, the checklist, the monthly numbers. Close with why this role and why now; that part is yours to supply and nothing in the pack supplies it | The biography question arrives in a casual register and is still scored. S5 is the row it supports |
| F2 | "What's a live event you saw in a mobile game recently that you'd have scheduled differently?" | JD | [generic] | Selection scaffold: pick a real event you actually saw, say what you noticed about its timing and how it was communicated, and what you would have changed. If none comes to mind, say so plainly, then say how you would review one | A casual question on the role's central topic, S1's requirement. Generic because it asks for your own observation |

### Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design wants to ship an update a day early and QA hasn't signed off the checklist. Where do you land, and who do you tell?" | JD | [generic] | Offer principles, not a claimed seam: what the checklist exists to protect, who decides when it is overridden, what you would tell design and why, and what you would tell players. No claim about your past is made | S4 and S2 meet in this question: the release checklist with QA, and coordination across teams. JD content with CASE delivery |
| G2 | "Tell me about a time work spanned several teams. How did you handle credit?" | VAL | [generic] | Selection scaffold: "we" for context, "I" for your contribution, and a named moment where credit was shared. If no such time comes to mind, say so plainly, then say how you would handle it | Standing peer-style stem. Generic because it carries no Saltmarsh-specific fact |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A2, A5, C4, F2 |
| "coordinate design, art, engineering and community teams on each update" | A5, C3, G1 |
| "own the post-event review and the KPIs it reports" | D3 |
| "manage the release checklist with QA" | B3, G1 |
| "3+ years producing live-service games or apps" | C5, F1 |
| "comfortable with player-retention metrics" | D1, D2 |
| "clear written communication" | A3 |

Published values: Players Before Plans is covered by B1 and A2; Ship the Patch Not the Promise by B2 and A3; Leave the Build Greener by B3. Company strategy is covered by A4.

## Values cheat sheet

A values-style round is detected: Saltmarsh's interviewing page names a values conversation.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players take priority | No sentence of yours carries a story here. Selection scaffold: a named stake on each side, a decision you were part of, what happened to the plan afterwards. If no such time comes to mind, say so plainly, then say how you would handle it (B1) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No sentence of yours carries a story here. Selection scaffold: a time you held something back, who wanted it out, what you said instead. If no such time comes to mind, say so plainly, then say how you would handle it (B2) |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | S4: "Wrote the release checklist our QA team still uses." — your message. The sentence carries the checklist and QA's continued use; whether it changed is the answer slot in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to live ops from QA. What did you carry over, and what did you have to unlearn?" | Ties to the interviewer's own path (I1) and turns the hour into a peer conversation |
| 2 | "Project Larkspur moves to a single live-ops group from January. Where does this Producer role sit in that group, and are the two titles in the posting the two in the announcement?" | Shows you read the announcement, and resolves the open point in S8 |
| 3 | "What does a good first event for this role look like, and what would tell you at ninety days that it went well?" | Turns the calendar requirement into a concrete expectation |
| 4 | "Can you tell me about a recent post-event review that changed what the team did next?" | Probes the review you would own (S3) and signals you care about the loop closing |
| 5 | "How do design, art, engineering and community agree an event date today, and where does it get stuck?" | Signals you are already thinking about coordination (S2) |
| 6 | "When did the release checklist last change, and what changed?" | Links to Leave the Build Greener and to the checklist you wrote (S4) |

## Prohibited claims

Built from the fit snapshot before the banks were written. No guidance cell asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated, S8 | The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases, or knows purchase or season-pass economics | Negative you stated, S8 | The plain acknowledgment: "I've never worked on a game with in-app purchases." Any next step is said as a plan. No slot |
| Ran live events across two titles | Inflated form of S1 | S1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title. C4's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of S3 | S3's quote at its own scope. The limit is the pack's observation: your material says you presented the monthly retention numbers. D3's slot stays inside what you presented |
| Ran each release with QA | Inflated form of S4 | S4's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist and QA still uses it. B3's slot stays inside the checklist |
| Four years of live-service production | Inflated form of S5 | S5's quotes at their own scope. The limit is the pack's observation: your material gives four years as an associate producer and two years running the weekly calendar. C5's slot stays inside those |

## Sources

**Provided:** the Live Operations Producer job description pasted in your message, and the background you described in your message.

**Searches sent:**

| Query | Result |
|---|---|
| Saltmarsh Games values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games strategy news mobile games | https://saltmarshgames.com/news/project-larkspur (search-result snippet only; page not opened) |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | https://talks.gdconf.example/2026/patch-notes-are-a-promise (search-result snippet only; page not opened, and I could not verify the host as an official GDC site) |

**Fetches sent:** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and bank B: the three values by official name |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop structure: the Outage Hour, so bank A and bank B are weighted equally and no take-home section is built |
| 3. Saltmarsh Games strategy / recent news | yes | A4 and reverse question 2: Project Larkspur, from the snippet only |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer, and the Prober tilt: from the snippet only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your full CV, and any shareable artifact behind your lines (the release checklist itself, a sample content-drop calendar page, a sample monthly retention report) → S1, S3, S4 and S6 move from `medium` toward `high`, and the evidence cells quote your CV instead of your message summary
- Your answers to the answer slots (were any drops time-limited events, which teams the drops involved, whether you wrote post-event reviews, which years ran on a live title) → S1, S2, S3, S5 and S7 upgrade, and bank guidance gets story beats of your own
- The recruiter's prep note, or one email asking how the hour splits between the tabletop and the values conversation, and whether the tabletop uses a named title or tool → persona weights across banks A and B, and the tabletop drills
- Which two titles the role covers → settles whether A4 and reverse question 2 apply as written, and fixes S8
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → opens the talk page itself, adds a strategy brief and recent org context, and upgrades the interviewer read from snippet to source
- A `tuesday-dossier.md`, if you already have one → an evidence-derived objection and prohibited-claims list in place of the ones built from your message here
