**Yes, it's worth applying, on conditions: your background meets R3, R4, R5, R6, R7 and R8 as `direct`, and the open items are your pay and location terms (R1, R2) and one independent check on the employer (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Salary $148,000–$166,000), R2 (Remote (US) or Denver office)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery); unclear: R10 (data contracts and ingestion from app and CRM)

R3 to R8 carry the case, and R9 is the row to frame carefully.

**Opportunity ledger.** The pay is stated and sits against your recruiter's band (RR3). The employer's size and funding facts rest only on its own site (RR1). The posting names no manager, team or success measures (RR2), and the equity terms are open (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Salary $148,000–$166,000), R2 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay range and the Remote (US)/Denver terms work for you (R1, R2); (2) the employer's funding is corroborated outside its own site (RR1); (3) BigQuery is presented as adjacent to your Snowflake work, never as experience you have (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` your paste and the company's about page as returned by search; no outside source found |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Posting status | Live and showing "Accepting applications"; the text matches what you pasted | `[grounded]` careers page fetched |
| Seniority | "5+ years" against a report norm of 5–8 years for Senior; your 6 years sits inside it | `[grounded]` JD and Datawright report, as you supplied them |
| Scope read | Ownership of one domain's reporting pipelines, which matches the report's typical scope; the posting says nothing about direct reports | `[inferred]` from the responsibilities against the report's scope norm |
| Market calibration | The posted $148,000–$166,000 starts $3,000 below the report's $151,000 median and ends $2,500 above its $163,500 upper quartile, for Series B–D companies. It is the employer's posted range, not an offer. | `[grounded]` report figures and the posting; `[inferred]` that "Salary" means base, since the report is base pay |
| Unknowns | Hiring manager, team size, on-call duty (the posting says "run"), first-year outcomes, equity terms | `[inferred]` from what the posting leaves out |
| Contradictions | None between your paste and the live pages | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Salary $148,000–$166,000 (a pay term) | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so there is nothing to grade; the range sits inside the report's band | `[grounded]` JD; floor not given | G3 |
| R2 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't stated | `[grounded]` JD; constraint not given | G3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You report 6 years in data engineering at a payroll company; prose self-report, nothing inspected yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily; no artifact inspected | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models; you haven't said how many people contributed | `[grounded]` your background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | You ran dbt on Snowflake. The requirement says "a cloud warehouse", so Snowflake meets it; BigQuery is R9 | `[grounded]` your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; no detail on DAG scale | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | none |
| R9 | BigQuery, the warehouse the role runs on | important | adjacent | medium | transferability | The posting's requirement list asks for "a cloud warehouse", but the role description names BigQuery. Limit: you haven't used it, and it differs from Snowflake in cost model and partitioning. Warehouse SQL and dbt transfer; BigQuery specifics don't. | `[inferred]` requirement from the role description; `[generic]` that warehouse switches are usually a short ramp for people who already run dbt | G1 |
| R10 | Data contracts and ingestion from the app and CRM | important | unclear | none | discovery | Nothing in what you've told me covers data contracts or app and CRM ingestion; your payroll sources may have been similar, but you haven't said | `[grounded]` the background is silent on both | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Seven-plus words of transferable warehouse and dbt work on Snowflake; no BigQuery use stated | It is the one named platform you haven't touched, so it is the likeliest probe | A side project, a migration evaluation, a certification or a sandbox project on BigQuery | A repo, a short dbt-on-BigQuery project, or a certificate | `[inferred]` that it is the likeliest probe, from the role description naming it |
| G2 | Data contracts and app/CRM ingestion (R10, important) | discovery | Silent on both | The mandate lists data contracts for analysts by name | Schema or SLA agreements with upstream teams or analysts; ingesting from a product database or a CRM such as Salesforce or HubSpot; testing that gates a load | A contract doc, a runbook, or a schema-change process | `[grounded]` silence in the background you gave |
| G3 | Pay floor and location terms (R1, R2, hard_gate) | hard_gate | The range and location terms are stated; your side isn't | These two are the only gates; unconfirmed, they cap the status | Not applicable: this asks whether the terms are met | None needed | `[grounded]` JD terms; your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Funding and size facts not corroborated outside the company's own site | risk_signal | low | "Series C ($52M, February 2026)" | The facts may well be true; two searches returned only the company's own about page | `[generic]` pattern for any employer whose facts come from one source, not a claim about this one | Can you share where the Series C was announced, and who the lead investor was? | unresolved |
| RR2 | Manager, team and success measures unnamed | unknown | — | "Build and run the pipelines" | The role may carry on-call and ownership duties without stated authority or a defined first-year outcome | `[inferred]` from the posting's silence | Who would I report to, how big is the data team, and what does success look like at 12 months? Is there an on-call rotation? | unresolved |
| RR3 | Pay stated, inside the report's band | positive_signal | — | "$148,000–$166,000 plus equity" | The employer is transparent on pay and the range is plausible for the title | `[grounded]` posting and report as you supplied them | What share of the range is typical for a candidate with six years? | noted |
| RR4 | Equity terms unspecified | unknown | — | "plus equity" | The grant size, vesting and strike could change the real value materially | `[inferred]` from the posting's silence | What is the equity grant range, vesting schedule and strike price for this level? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the resume with your dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up, since those are the two rows closest to the posting | see R5, R8 | `[grounded]` your background | pending your approval |
| A2 | State Snowflake plainly and keep BigQuery out of the claims; if G1 produces anything real, add it as adjacent work | see R9 | `[grounded]` your background | pending your approval |
| A3 | Check the funding independently (a press release, the investor's site) before spending effort on the loop | see RR1 | `[grounded]` register | pending your approval |
| A4 | Ask the verification questions in RR2 and RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background claims are self-report at intake, which is why R3 to R8 stand at `medium`, not `high`.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): posting live, text identical to your paste. Searched "Pellucid Learning Series C $52M tutoring Denver" and "Pellucid Learning raises Series C funding February 2026"; both returned only "About Pellucid Learning" (pellucidlearning.com/about), the company's own page, and no independent source. Moved: role reality (posting status, contradictions) and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand with the median, quartiles, seniority and scope norms, which fix the market calibration line and the pay comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Upgrade menu

- An independent source for the Series C (a press release or investor announcement) → RR1 closes.
- Your pay floor and where you are based → R1 and R2 move from `unclear` to `direct` or `hard_gate_fail`, and the decision firms up.
- An answer to G2, or an artifact such as a contract doc or runbook → R10 moves off `unclear`.
- Any BigQuery work, even small → R9 firms up.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper research pass on Pellucid Learning (funding and leadership changes, recent news, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can also save this as `tuesday-dossier.md` if you want a file to carry into later steps.

G3 (R1, R2) — Do the $148,000–$166,000 range and the Remote (US) or Denver terms fit your pay floor and where you live and are authorized to work?

G2 (R10) — Have you owned any agreement with upstream teams or analysts about the shape or freshness of data, or ingested from a product database or a CRM? What did you own, and what happened?

G1 (R9) — Have you used BigQuery in any form, whether a project, an evaluation or a certification?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.