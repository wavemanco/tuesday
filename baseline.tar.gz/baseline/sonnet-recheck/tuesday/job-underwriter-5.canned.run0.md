## Decision snapshot

**Yes, worth applying. R1 and R2 are the two terms the posting states and you haven't yet confirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts)

R8 has a credible Snowflake bridge with its limit named. R9 and R10 wait on your answers.

**Opportunity ledger.** The role reads as sound. Pay is disclosed and inside the market band (RR1), funding is recent (RR2), and scope matches the market norm (RR3). The open unknowns are the reporting line (RR4), the equity terms (RR5) and on-call expectations (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 holds: you can work remote from the US or from Denver.
  2. R2 holds: your pay floor is at or below the posted range.
  3. R8 is framed honestly as adjacent: dbt on Snowflake, not BigQuery use.
- **What would change this:** a failed R1 or R2 makes it `no_go` on that gate, however strong the skills match is.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page, as you copied it |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | One domain's pipelines (reporting), no direct reports named, 5+ years asked: the same shape as the report's typical Senior Data Engineer | `[grounded]` JD against the report's scope and years description |
| Market calibration | Posted $148,000–$166,000 against a report median of $151,000 and interquartile range of $139,000–$163,500 (n=2,310, Series B–D, Pellucid is Series C). The floor sits $3,000 under the median and the top sits $2,500 above the upper quartile | `[grounded]` JD and the recruiter's report; `[generic]` that this is a pattern for the cohort, not this employer's offer |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Unknowns | Hiring manager, equity terms, on-call expectations, data team size | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the About page; both were copied by you, not fetched by me | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are or your US work eligibility, so the term can't be checked. There is no statement of yours to grade, hence `none` | `[grounded]` JD term; your message silent | Ask whether you meet it (closing question R1) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The range sits inside the report's band (RR1), so a miss is unlikely but unconfirmed. Equity is unquantified (RR5) | `[grounded]` JD figures, your message silent on a floor | Ask your floor (closing question R2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company against a five-year minimum. A length-of-experience requirement isn't a gate. No CV or document seen, so `medium` | `[grounded]` your prose background | A CV or LinkedIn history would let me check the dates |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both is confirmed in your prose. "Strong" is the employer's word and daily use doesn't prove it | `[grounded]` your prose; `[generic]` that senior data engineering loops usually test SQL and Python live | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built a dbt project of about 180 models on Snowflake, and Snowflake is a cloud warehouse, so the requirement as worded is met. BigQuery is not in this requirement (see R8) | `[grounded]` your prose; reading of the JD's wording | A sanitized dbt docs lineage screenshot would raise to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration at your company is confirmed. DAG count and scale weren't stated and aren't assumed | `[grounded]` your prose | A sanitized DAG list would raise to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Whether you set it up or maintained it is covered by your wording, "set up" | `[grounded]` your prose | A sanitized suite config excerpt would raise to `high` |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The Requirements list asks for "a cloud warehouse" (R5) and BigQuery appears only in the responsibilities. Your dbt modelling on Snowflake carries across. The limit: you have never used BigQuery, so its own cost, partitioning and access conventions are unexercised | `[grounded]` you have not used BigQuery; `[inferred]` adjacency from dbt on Snowflake; `[generic]` that warehouses differ in those conventions | G1 |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | You describe Airflow pipelines but not what they ingested from. Source types are unstated, so only indirect context exists | `[grounded]` your prose silent on sources | G2 |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | The Great Expectations suite is related work, but a contract is a stated agreement between producers and consumers. I haven't equated the two | `[grounded]` your prose silent on contracts; `[generic]` that a data contract differs from a test suite | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Strong dbt on Snowflake, no BigQuery use | It is the one place the JD names a tool you haven't touched; a narrowed limit pre-empts the likeliest interview probe | A dbt-bigquery side project; querying BigQuery from a BI tool at work; a Snowflake migration you took part in | A short repo or notes from a BigQuery sandbox exercise | `[inferred]` bridge from dbt on Snowflake; `[generic]` that interviewers probe the named stack |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Airflow pipelines confirmed, ingestion sources unstated | Ingestion is the first item in the mandate | Pipelines pulling from a product database or event stream; API loads from a CRM such as Salesforce or HubSpot; customer-system loads at the payroll company | A sanitized DAG listing showing source systems | `[grounded]` prose silent on sources |
| G3 | Data contracts (R10, important) | discovery | Great Expectations suite exists; no stated producer-consumer agreement | Named as what analysts depend on, so likely to be probed | Schema-change alerts agreed with analysts; dbt model contracts or tests analysts relied on; a documented SLA on a table | A runbook, schema-change policy, or sanitized contract doc | `[grounded]` prose silent on contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed and inside the market band (R2) | positive_signal | — | "$148,000–$166,000 plus equity" | The range is competitive for the cohort, with a floor $3,000 under the report's $151,000 median and a top $2,500 above its $163,500 upper quartile | `[grounded]` JD and the recruiter's report | Where in the range would six years of experience be placed, and what decides it? | noted |
| RR2 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | A raise nine months ago suggests the role is funded | `[inferred]` from the raise date; the figure comes from the company's own page and is unchecked externally | Is this new headcount or a backfill? | noted |
| RR3 | Scope matches norm | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | One domain's pipelines and 5+ years match the report's typical Senior scope | `[grounded]` JD against the report | Which domains' pipelines would this role own, and who else is on the data team? | noted |
| RR4 | No hiring manager named | unknown | — | "The posting names no hiring manager" | The reporting line is unknown; postings often omit it | `[generic]` pattern, no claim about this employer | Who would I report to? | unresolved |
| RR5 | Equity terms unstated (R2) | unknown | — | "plus equity" | Grant size, vesting and valuation basis are unknown, so total pay can't be weighed | `[grounded]` JD silent | What is the equity grant, vesting schedule and latest valuation basis? | unresolved |
| RR6 | "Run" may include on-call | unknown | — | "Build and run the pipelines" | Operating pipelines may mean a pager rotation, which the JD doesn't mention | `[inferred]` from "run" against the JD's silence | Is there an on-call rotation, and how often would I be on it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location, US work eligibility and pay floor against R1 and R2 before applying | They are the two terms that could end the application | `[grounded]` R1, R2 rows | pending your approval |
| E1 | Lead with the Snowflake dbt project of about 180 models, Airflow and the Great Expectations suite you set up. State Snowflake by name and say you have not used BigQuery | These rows (R5, R6, R7) are the strongest, and naming Snowflake keeps R8 honest | `[grounded]` your prose | pending your approval |
| W1 | A small dbt-bigquery exercise on BigQuery's free sandbox, only if you want a stronger answer on R8 | Narrows G1's limit with something inspectable | `[inferred]` from G1 | pending your approval |
| Q1 | Ask RR2 to RR6's questions in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Your pasted About page and posting (copied 09:10 and 09:12 today) already fix the employer's existence, stage, size and that the posting was live at that time. I did not re-fetch it, so I can't see changes since 09:12 |
| 2. Role-family sweep | skipped | The Datawright 2026 report (n=2,310) you supplied fixes the market calibration and the pay and scope checks |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Your CV, or a sanitized dbt docs lineage screenshot, DAG list or Great Expectations config excerpt, would lift R3 to R7 toward `high` and let me check presentation.
- Your answers to R1 and R2 close the two gates, and the decision becomes `go` or `no_go`.
- Answers to G2 and G3 resolve R9 and R10.
- The hiring manager's name (from the recruiter or LinkedIn) would let me read their public work for RR4 and tune what to lead with.
- A deeper pass on Pellucid (funding verification outside its own page, leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you'd like, I can write this up as `tuesday-dossier.md` so a later step starts from it.

**Questions**

R1 — Are you based in the US (or able to work in Denver) with authorization to work there without sponsorship?

R2 — What is your minimum acceptable base salary?

G3 — Have you set up anything like a data contract: an agreed schema or SLA with analysts that you enforced or alerted on? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.