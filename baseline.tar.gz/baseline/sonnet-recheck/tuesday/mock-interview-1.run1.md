Web searches were refused here, so I'm building the pack from your inputs only and will record that in its Sources section. I'm writing the file now.
The write to the working directory was declined, so I'll save the pack to the session scratchpad instead, which is set aside for this.
Priya's prep pack is built and saved. It has 19 questions across six personas, each with a question type, answer guidance and a rationale.

The write to your working directory was declined, so the file is in the session scratchpad: `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-1-denied-eab8ce86/2a698d5e-92cb-4fa3-a6e8-2894587a9a35/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`

- **Web search was refused:** All three searches (Northwind's values, its interview process, Dan's public footprint) came back refused. The pack rests only on what you gave me. It states no Northwind values, loop details or facts about Dan beyond your description, and its Sources table shows which research targets are unavailable.
- **Weighting:** Dan is a peer who calls himself data-driven and comes from pricing, so the Data-Driven Prober (5 questions) and Peer Evaluator (4) lead. Skeptic and Case/Strategist get 3 each, Conversational and Pressure 2 each.
- **Highest-ROI prep is C1:** It's the sales-ops and quota-setting objection, and the guidance has three escalating follow-ups with exact wording. Priya's volume targets are kept separate from quota-setting throughout, and the pack warns her not to equate them.
- **The ~$400M figure:** It is her only headline number, so it gets three questions (A1, A2, F2). The guidance keeps her to "proposed" and "credited", not "led" or "owned".
- **The Compass and bundling questions:** The three Case/Strategist questions (D1 to D3) use only your research note, and one tests the partner-motion requirement.
- **Reverse questions:** There are six, including two tied to Dan's own path and one reciprocity question.
- **Evidence limit:** Her evidence cells are your one-line notes quoted verbatim, not a CV, and the requirements are your JD highlights. Anything Priya says in answer to a slot should be fed back so those rows can be rebuilt.

Say the word and I'll run a live drill, with me playing Dan as the Skeptic on C1.
I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind, her peer (both would report to the same VP). **Round:** one 60-minute conversation with Dan, per the coach's notes. **Built on:** the coach's inputs only (JD highlights, candidate summary, interviewer read, research note). Web research was refused in this session, so company values, loop structure and Dan's public footprint are not established (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. Not used here: no values source was read and no values round is detected |
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny and attribution is precise |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Whether you can think at Northwind's altitude, using its three stated priorities |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

Provenance labels: `[grounded]` traces to a provided document, `[inferred]` is derived with the derivation named, `[generic]` is a role-family pattern with no entity-specific claim. A question marked `[generic]` carries no claim about you.

**Highest-ROI prep in this pack: C1**, the question about sales-ops and quota-setting. A sales-strategy peer will reach for it in some form, and a rehearsed, non-defensive answer changes the conversation.

## Fit snapshot

Requirements are the JD highlights as the coach supplied them, not the full JD. Evidence is quoted from the coach's notes and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | The notes name the function and the company and do not show whether any GTM strategy for a new product line was yours. They state no absence either. Answer slot: the JD line makes a probe on this likely. If you set GTM for something new, say what and which part was yours, in your own words; if there was no such work, or it was not yours, say so plainly and say how you would start with little history. Your words stay at the quote: nine years in product strategy and ops at a large consumer-tech company |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote is adjacent growth work and does not reach whitespace across land, adopt, expand or renew, so the pack does not offer it as that. Words at its own scope: you proposed a store-surface change, and the uplift was credited to it. Answer slot: if the proposal drew on an analysis of where there was room to grow, say what it was and which part was yours; if it did not, or you cannot say, say so plainly and return to the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The tools are named in the quote's own terms. Nothing inspected sits behind the line, so expect a probe on what you ran yourself end to end. A3 rehearses that as a selection scaffold |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote carries a revenue model used in carrier negotiations. That is adjacent to designing a partner motion and does not reach it. Words at the quote: you built a partner-level revenue model that was used in carrier negotiations. The pack's observation: the material says model, not motion. Answer slot in A4 stays inside the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | Lead with the quote in its own terms: annual volume targets, set with consensus across organisations. Expect a probe on where the orgs disagreed; the notes do not say, so B3 holds it as an answer slot |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | The quote shows daily use of AI tools. It does not show whether any of it was applied to GTM work or to building an AI product. Answer slot in E2: what you use them for, in your own words; if it is routine use, say so plainly. Nothing here supports a claim to have built or launched an AI product |
| F7 | Sales-ops and quota-setting fluency, the working ground of a sales-strategy peer (a role-family expectation, not in the JD highlights) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the notes state it. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Annual volume targets (F5) are not offered as quota-setting experience; the notes keep the two apart |

## Reading the interviewer

Everything here comes from the coach's read of Dan's profile. It was not independently checked, because research was refused. Public professional footprint only.

| Signal | Source | Implication | Where it shows up |
|---|---|---|---|
| Describes himself as "relentlessly data-driven" | The coach's read of his profile | Expect every number to be taken to its inputs and assumptions, two levels deep | A1, A2, A5, R5 |
| Career spine in pricing and monetization roles | The coach's read of his profile | Case questions tilt to packaging, pricing and unit economics, his native language | D1, D3, R1 |
| One early-stage-startup chapter | The coach's read of his profile | Builder stories can land well; expect a probe on big-company pace. The notes carry no 0-to-1 story for you, so none is offered | C3, R2 |
| Peer: same VP, adjacent teams | The coach's notes | He is pricing what you add to, or take from, his work: seam, credit, disagreement | B1 to B4, R3, R4 |

Mirror opportunities: shared vocabulary only. Your F4 sentence, "built a partner-level revenue model used in carrier negotiations", sits next to his monetization spine, so revenue language is a natural common ground. No shared career jump is offered; neither the notes nor a quote shows one.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Reads the CV line by line, asks for inputs and assumptions | Top. The peer prior puts the Prober first, and his self-described "relentlessly data-driven" style moves it up | Know what you can and cannot say about how the CV figure was counted, and say plainly when you do not know. Name the assumption you would defend least before he does | A1 to A5 |
| Peer Evaluator | Seam-splitting, credit, "what would you need from me" | Top. The peer prior; the shared VP makes the seam question near certain | Reciprocity: say what you bring his team. Propose seam principles instead of pretending to know the seam | B1 to B4 |
| Skeptic | Quiet probing of the sales-ops gap and the consumer-tech to B2B move | Mid. The peer prior is light, but F7 is a stated gap in his own domain and the JD has two thin rows (F1, F4) | Rehearse the single predictable objection (C1) until it is boring; plain acknowledgment plus a plan | C1 to C3 |
| Case / Strategist | A live problem on Compass, bundling or partners | Mid. Not a manager round, but his pricing spine makes a packaging case likely, and the research note gives him live material | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully | D1 to D3 |
| Conversational | Opening biography, casual AI question | Low. A short warm-up is likely and still scored | A 90-second arc built only from your own sentences; treat the AI question as scored | E1, E2 |
| Pressure | Time-boxes and tests composure | Low. Peers rarely run it, but the gaps invite one or two sharp lines | Pause, restate, hold through two follow-ups, concede specifically | F1, F2 |

The values persona is omitted: one peer conversation, and no source documents a values round.

## Question banks

### A. Data-Driven Prober (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift credited to your store-surface proposal was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with what the sentence states: you proposed a store-surface change, and the uplift was credited to it. Answer slot: how the figure was counted, what it is most sensitive to, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly; that is an honest answer. Say what you do know and stop there. Never explain a method you could not repeat under a second question | F2 is the only quantified evidence, so a data-first peer opens here. EXP because it tests whether the figure survives scrutiny. First in the bank because the Prober reads the CV line by line |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption behind the figure you would defend least, before he asks. Answer slot: if you know of one, name it; if you do not know how the number was built, say that plainly instead. The pack does not name an assumption for you | The persona stem for this Prober, applied to F2's figure. EXP because it scores honest self-assessment of your own number. A candidate who names the weak point first gains credibility |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold. Pick one analysis that was entirely yours, and make sure you can say the question you started with, the data you worked from, what you found, and what changed because of it. Offer to walk through it end to end. If no analysis comes to mind that was entirely yours, say so plainly, then give the nearest thing your material does carry, or how you would approach one | F3 is a bare tool claim, so expect the probe. JD because the posting asks for independent analysis; it is delivered as an EXP-style walkthrough. A selection scaffold because no quoted sentence carries a specific analysis |
| A4 | "Tell me about the partner-level revenue model." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, using the quote's own beats: you built it, it was partner-level, it was used in carrier negotiations. Name the part of it you trust least, in your own words; if you do not know how an input was derived, say so. Answer slot: the JD's partner-motion line makes a probe on what you did with it likely. If the model shaped how partners were engaged, say how; if it informed the negotiations only, or the engagement was not yours, say so plainly and stay with the model. Do not say you led the negotiations | F4 is the evidence for a required line and the nearest thing to a partner-motion story. EXP because the Prober tests what you actually did. The slot guards the gap between a model and a motion |
| A5 | "Say we give you usage and contract data for one new product. How do you decide where the whitespace is across land, adopt, expand and renew, and what do you check before you believe the number?" | JD | [generic] | A live method, no claim about your past. Clarify first: how Northwind defines each stage, what the unit is (account or something else), and what data exists. Then segment, size the gap between current and plausible, and say what you would check before trusting it: definitions, duplicates, join keys, time windows, small samples. Name your weakest assumption aloud. Ask Dan how his team sizes it today | The JD's whitespace line (F2) as a data question, in the Prober's register. JD because it scores the stated requirement. `[generic]` because it is a pattern for the problem, not a fact about Northwind |

### B. Peer Evaluator (top weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between this role and sales strategy, and what happens when we disagree?" | JD | [generic] | Do not pretend to know the seam; ask Dan where he sees it today. Offer seam principles: who decides which decision, shared definitions for the numbers, no surprises before the VP sees anything. For disagreement, propose a rule: settle the data first, then take both options to the shared VP together. Add what you would bring his team. This answer makes no claim about your past; a disagreement story belongs to B3 | The seam question is the persona stem and near certain with a peer under one VP. JD because cross-functional influence (F5) is a stated requirement. `[generic]` because it is a pattern and the answer carries no claim |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quote's verbs: you proposed the change, and the credit was assigned to it. "We" for context, "I" for what you did. Answer slot: the JD's cross-functional line makes a probe on who else contributed likely. If others were involved, say who and what they did; if nothing here was shared, or you do not know how credit was assigned, say so plainly and stay with the proposal | The peer's credit-sharing probe lands on F2, the one credited result. EXP because it tests attribution honesty in a collegial register |
| B3 | "Tell me about a time you got several teams to agree on a number." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, with the quote's beats only: annual volume targets, and consensus across organisations. Call them volume targets throughout, never quotas. Answer slot: where the orgs disagreed is a likely probe. If they did, say what each wanted, what happened, and which part was yours; if there was no real disagreement, or it was not yours, say so plainly and stay with the targets | F5 is the cross-functional evidence, and a peer will test whether it is real. EXP because it checks one claim for substance. The open prompt supplies no event; its theme is the JD's influence line |
| B4 | "What would you need from my team in your first 90 days, and what would you bring?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" "skilled in SQL/Tableau" | The reciprocity answer. Open with the plain acknowledgment: "I have no classic sales-ops or quota-setting experience." Then the need, as a plan: how targets and quotas are actually built here, and access to the data. Then what you bring, at the quotes' scope: a partner-level revenue model that was used in carrier negotiations, and SQL and Tableau skills | The peer is pricing what the hire adds to his work, so need and contribution come together. JD because it scores readiness for the role. F7 and F4 are the rows it draws on |

### C. Skeptic (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | The deepest rehearsal in the pack. Level 1: the plain acknowledgment, "I have no classic sales-ops or quota-setting experience," then a plan, not a past: in the first weeks I would learn how targets and quotas are built here, from you and the sales leaders, before proposing anything. Then the adjacent sentence at its own scope: "I set annual volume targets with cross-org consensus." Level 2, "Why would sales leaders listen to you?": hold. Return to the same two sentences, add no credentials, and say what you would do to earn it. Level 3, "Isn't that basically quota-setting?": hold, then concede. "I haven't done the quota version. They may have things in common, and I'd rather learn where they differ than assume." The limit, named before it is asked for: the notes do not say what the targets were set against or who carried them, so do not describe either | The named highest-ROI objection, because F7 presses exactly where the peer is the expert. EXP because it tests the CV against his domain; the JD highlights do not list it. The Skeptic persona because the objection is quiet and persistent |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [inferred] Derived from the gap rows F1, F4 and F7 | Selection scaffold. Pick the requirement where your own material is thinnest, name the gap plainly in one sentence, and give the first thing you would do about it. Do not choose a gap in order to avoid C1; if you name quota-setting, you already have the words. If no weakness comes to mind, say so plainly, then name the area you would ask for help in first | The persona stem. JD because it scores honest self-assessment against the listed requirements. `[inferred]` because the choice is derived from the snapshot's thin rows, not from a quote |
| C3 | "This role owns GTM for two new product lines. What does zero-to-one look like for someone coming out of nine years at a large consumer-tech company?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | State the background in the quote's terms and make no zero-to-one claim. Answer slot: the JD's line makes a probe on whether you have set GTM for something new likely. If you have, say what and which part was yours; if not, or it was not yours, say so plainly and say how you would work with little history: what is known, what must be learned, a few metrics, and a fast review rhythm with Dan's team | F1 is a discovery row, and the startup chapter in Dan's path makes a big-company-pace probe plausible. JD because it scores the first stated responsibility. The pack does not supply a 0-to-1 story the notes lack |

### D. Case / Strategist (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass is launching into an enterprise base while a much larger platform vendor bundles against us. How would you approach packaging and pricing for it, and what do you need to know first?" | CASE | [grounded] Provided research note: priorities are enterprise expansion, the Compass launch, and profitability; the main threat is bundling by a much larger platform vendor | Clarify first: which segment, whether Compass is sold standalone or inside an existing plan, who buys it, and what the bundler includes. Then objective, segments, options (standalone, add-on, included in an expansion tier) with the trade-off against profitability, metrics, and risks, especially price anchoring against a bundle. Challenge one premise respectfully, for example whether price is the lever or proof of value is. Use his vocabulary and do not assert Compass facts you do not have | The research note's live material, in Dan's pricing language. CASE because it scores structure on a problem from the actual role. The CO bank item grounded in current strategy |
| D2 | "Bundling pressure is real for a new product line. Where could partners help or hurt, and how would you tell whether a partner motion is working?" | JD | [grounded] Provided research note: the main threat is bundling by a much larger platform vendor | Define the job a partner does (reach, delivery, integration or resale), then who you would want and why. Pick two or three leading indicators and one lagging one. Name the risks: channel conflict with direct sales, which is also his territory, and dependence on a partner that is itself exposed to the bundler. This is a live problem and carries no claim about your past | Partner-motion design is a required line (F4), so it needs a JD-tagged question. CASE delivery, JD scoring. The channel-conflict risk puts the peer's own turf into the answer |
| D3 | "Enterprise expansion, Compass and profitability are all priorities. For an emerging product, which would you protect first, and why?" | CO | [grounded] Provided research note: the three stated priorities | Take a position and say the assumption you would defend least. Ask what ordering the VP uses. Hold the position through a challenge, then concede specifically, for example where another ordering would be right. Do not claim knowledge of Northwind's numbers | The CO question on current strategy, and a hold-then-concede rehearsal against a pricing-minded peer. CO because it scores strategic altitude |

### E. Conversational (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: consulting, consumer tech, and now this?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc whose factual beats are only the quote's: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Answer slot: why B2B data infrastructure, and why now, in your own words; the notes do not carry your reasons, so none is supplied here | The opening question of almost any peer conversation. EXP because it exposes the CV's thread. The motive is an answer slot because the notes are silent |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] Derived from F6 | Say what the quote supports: you use AI tools daily. Answer slot: what for, one concrete use, in your own words; if it is routine use, say so plainly. You may ask Dan how Compass is positioned, as a question and not a claim. Do not describe building or launching AI products | "AI experience a plus" is a mid-list JD line, easy to miss, and the casual register is still scored. `[inferred]` because F6 is a low-confidence row |

### F. Pressure (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, rather than someone who's carried a number?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" | Pause and restate. One sentence of plain acknowledgment: "I have no classic sales-ops or quota-setting experience." Two sentences at the quotes' scope: a partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. One sentence on what you would do first. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede specifically: what you would be learning is how a quota is carried | The persona stem pointed at F7. EXP because it tests the CV under time pressure; it is the Pressure version of C1 |
| F2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold on the quote: "I proposed the change; the uplift was credited to it." Hold through two follow-ups by returning to that sentence. Answer slot: what part of the work beyond the proposal was yours; if the proposal was the extent of it, or you cannot separate your part from the rest, say so plainly. Never claim you drove, led or owned the result | The pack's single headline figure under attribution pressure. EXP because it tests precise credit. The Pressure persona because the sixty-second, interrupting form is how it often arrives |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 own GTM strategy for two new product lines | C3, C2, D1 |
| F2 identify whitespace across land/adopt/expand/renew | A5 |
| F3 run independent analysis in SQL and Tableau | A3, A5 |
| F4 partner-motion design experience required | D2, A4 |
| F5 strong cross-functional influence | B1, B2, B3, B4 |
| F6 AI experience a plus | E2 |
| F7 sales-ops and quota-setting (not in the JD highlights) | C1, B4, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've worked in pricing and monetization for most of your career. Where does that thinking most change a GTM plan for a new product?" | Tied to his path, in his native language. It turns an interview into a peer conversation |
| R2 | "You spent a chapter at an early-stage startup. What from it do you still use here?" | A second question tied to his own path. It invites the builder conversation without you claiming one |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows you are pricing what you add, not only what you need |
| R4 | "Where do your team and this role overlap today, and where is it unclear who decides?" | Surfaces the seam from B1 and shows you expect to share ground |
| R5 | "Which two or three numbers does the VP use to judge whether the new lines are working?" | Fits his data-first style and tells you how the role is really scored |
| R6 | "How do enterprise expansion, Compass and profitability show up in how your team is measured, and where do they pull against each other?" | Built from the research note. It signals homework and probes the same tension as D3 |

## Prohibited claims

Built locally from the fit snapshot. No guidance cell above asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I have no classic sales-ops or quota-setting experience." No slot |
| Set quotas, or volume targets "are basically quotas" | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for you: the notes keep volume targets and quota-setting apart |
| Led, drove or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says proposed and credited. A2 and F2 slots stay inside the proposal |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says model, not motion |
| Led or ran the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: the model was used in the negotiations |
| Has built or launched an AI product | Inflated form of F6 | F6's quote at its own scope: daily use of AI tools |

## Sources

**Provided documents:** the coach's message (JD highlights, the candidate summary, the interviewer profile read, and a research note on Northwind's three stated priorities and its main competitive threat). No `tuesday-dossier.md` was present. The loop is one 60-minute conversation with Dan, per the coach's words; no external loop source was read, so no values-style round is detected and the values cheat sheet is dropped.

**Searches sent (all refused):**

- `Northwind Data company values`: refused
- `Northwind Data interview process GTM strategy`: refused
- `Dan Kovac Northwind Data Director of Sales Strategy`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. It would have fed a values cheat sheet and VAL questions; none is built, and values are not stated from memory |
| 2. `Northwind Data interview process GTM strategy` | unavailable | Search refused. It would have confirmed the loop and any named rounds; persona weights rest on the peer prior and the coach's signals |
| 3. `Northwind Data strategy` / recent news | skipped | The coach's research note already supplies the priorities and the competitive frame the CO questions use (D1 to D3, R6) |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. The interviewer read rests only on the coach's description, and talks or writing are unknown |
| 5. representative GTM Strategy Lead JD | skipped | A JD was supplied; it fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the six JD rows now rest on the coach's highlights; mid-list requirements, named tools or methodologies in the full text would each get a question, and F1 to F6 requirements become exact quotes
- Priya's CV → evidence cells now rest on one-line notes; the CV's own sentences would sharpen F1, F2 and F6, and show whether anything supports a GTM or AI story
- Anything Priya states outside a drill in answer to a slot (for example what the ~$400M figure was counted on, what the volume targets were set against, or what she uses AI tools for) → the matching rows regenerate as quoted evidence
- The artifact behind the ~$400M figure, such as the experiment readout or finance attribution, and a sanitised view of the revenue model → medium rows F2 and F4 could rise toward high
- Search access for this session → Northwind's published values, its documented interview loop and Dan's public footprint, which would replace the unavailable rows above and add a tailored interviewer read
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs search access) → a strategy brief to sharpen D1 to D3 and the reverse questions
- The recruiter's guidance on the 60-minute format and any pre-declared deliverable → coverage of a graded deliverable, if one exists
- A `tuesday-dossier.md` from a prior role assessment → verified evidence and an underwriter-named objection, replacing the pack's own inference of C1
