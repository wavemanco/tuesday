Running the L1 research now: checking Quillfield exists as described, then a pay and scope check, then Tamsin Achebe's public professional footprint.
**Yes, I'd go for it, as a stretch application, once you've confirmed R1 and R2 work for you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast), R7 (Finance, billing or revenue data) · unclear: R3b (At a B2B software company)
- `important` — direct: R8 · adjacent: R9 (Quarterly forecast with the CFO)

R6 and R7 carry the widest limits, and the map names them.

**Opportunity ledger.** The employer matches its posting and the pay is stated (RR5, RR4). The posting's presence on Quillfield's own site, the team around the role and the first-year measures are unconfirmed (RR1, RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 work for you; (2) you frame R6 and R7 as adjacent and never as an owned forecast or billing experience; (3) RR1 resolves, with the role shown on Quillfield's own site.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` About Quillfield (quillfield.co.uk/about) |
| Mandate | Own the CRM and billing data, build pipeline and renewal reporting for sales and finance, and run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, and before that was a sales operations manager at Corvane Payments for four years. That she is hiring manager for this post comes from your recruiter, and the listing doesn't confirm it | `[grounded]` search listing for her role and history; `[grounded]` your recruiter's statement for the hiring-manager link |
| Scope read | Three jobs in one post: systems owner for CRM and billing data, reporting builder, and forecast co-owner. No team, reports or budget are stated | `[inferred]` from the responsibilities against the posting's silence on resources |
| Market calibration | The posted range's midpoint (£64,250) sits beside the UK B2B-software revenue-operations-lead median of £64,200 (interquartile range £57,800–£70,400), so there is no pay mismatch. Basis: one pay guide (Ledgerline 2026, n=438) from one search. It covers pay, not scope norms, so those were not established | `[generic]` pay band; `[grounded]` posting figure |
| Unknowns | Team size and reporting line; who owns the billing system today; first-year outcomes; share-option terms | — |
| Contradictions | None found between the posting and the company page. The role was not found on the company's own careers page, and the one address tried returned no page (RR1) | `[grounded]` company page read; careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days | hard_gate | unclear | none | hard_gate | The posting states the term. You haven't said where you're based or what you'll commute, so there's no constraint to grade | `[grounded]` posting; your message silent | G3 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The posting states the pay. You haven't given a floor, so whether it's met is not established | `[grounded]` posting; your message silent | G3 |
| R3a | 4+ years in revenue operations, sales operations or similar analytics | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations. That is self-reported with nothing inspectable yet, so it caps at `medium` | `[grounded]` your background message | offer: a title history or LinkedIn role dates would raise it |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You describe a B2B payments company. Whether it sells software, or is a payments service, isn't settled | `[grounded]` your message says "payments company", silent on product | upgrade menu |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified, which is specific, but no credential has been inspected | `[grounded]` your message | offer: the Salesforce credential's verification page would raise it to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | You use SQL weekly and Excel daily. Frequency of use doesn't show strength or modelling work, which the posting asks for | `[grounded]` your message; the posting's "strong" and "modelling" go beyond it | offer: a sanitized query or model you built |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review with your sales director, but finance owned the company forecast. Limit: you haven't owned a forecast number, and nothing here says what you produced for the UK team | `[grounded]` your message | G1 |
| R7 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | You've never worked on billing data. You rebuilt renewal dashboards, which are revenue-side, but working with finance on them isn't stated | `[grounded]` your message | G2 |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards. I haven't seen your CV, so I can't judge whether it communicates this | `[grounded]` your message | offer: a sanitized dashboard screenshot would raise it to `high` |
| R9 | Run the quarterly forecast with the CFO | important | adjacent | medium | transferability | You run a monthly pipeline review with the sales director. Limit: you haven't worked at CFO level or on a quarterly forecast cycle | `[grounded]` your message | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have; R9, important) | transferability | You run the pipeline review, but finance owned the company forecast. Nothing shows a forecast figure you produced yourself | R6 is a `must_have` and the posting names forecasting as a headline duty. A concrete forecast you produced would narrow the biggest limit | A UK-team or regional forecast you built, a commit or call number you owned, a forecast-versus-actual comparison you tracked, pipeline coverage inputs you supplied to finance | A sanitized forecast sheet, a pipeline-review deck, a forecast-versus-actual tab | `[grounded]` your message; `[generic]` that forecast ownership is the usual hard gap when moving into this title |
| G2 | Finance, billing or revenue data (R7, must_have) | discovery | The renewal dashboards touch revenue data, but your message doesn't say whose numbers they used or whether finance reviewed them | The requirement reads "billing or revenue data", so work with finance on revenue figures could count even without billing | Reconciling renewal values with finance, building renewal reporting from contract or invoice exports, a month-end or quarter-end close you supported | A renewal-dashboard screenshot, a data-source note, a finance-requested report | `[grounded]` your message silent on finance involvement |
| G3 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The posting sets two Bristol office days and £61,500–£67,000. Your constraints on both are unknown | A failed term would end the decision whatever the fit | — | — | `[grounded]` posting terms; your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not confirmed on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed elsewhere on the site, or only through the job board | `[grounded]` the one careers address tried returned no page, which is weak evidence; `[generic]` pattern that boards often carry postings before company sites do | Can you send me the link to this role on Quillfield's own careers page? | unresolved |
| RR2 | Three jobs in one post, no team stated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast with the CFO" | You may be accountable for systems, reporting and forecasting with no analyst support. Severity is `low` because the posting may simply omit the team | `[inferred]` from the responsibilities against silence on team and budget | Who does this role manage or work with day to day, and who owns the billing system today? | unresolved |
| RR3 | No first-year outcomes stated | unknown | — | "run the quarterly revenue forecast with the CFO" | A forecast-owning role without a definition of success could be judged on accuracy from the first quarter | `[inferred]` from the posting's silence on measures | What would a successful first year look like, including any forecast-accuracy expectation? | unresolved |
| RR4 | Pay stated and in line with the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The figure is disclosed and sits at the band's median. The options' value is unknown | `[grounded]` posting figure; `[generic]` band, per role reality | How are the share options structured (vesting, strike price, dilution since the Series A)? | noted |
| RR5 | Employer matches the posting | positive_signal | — | "Quillfield, the invoicing software company" | Quillfield exists as described and has recent funding | `[grounded]` About Quillfield (quillfield.co.uk/about) | What is the revenue-operations team's current size and structure? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Positioning line for you to say: "I rebuilt our pipeline and renewal dashboards, and I run the monthly pipeline review with our sales director." Every clause is your own sentence | R8, R9 | `[grounded]` your background message | pending your approval |
| E2 | If asked about R6 or R7, answer plainly in your own words: "I haven't owned the company forecast — finance did that — and I've never worked on billing data." Then give what you did own | R6, R7 | `[grounded]` your background message | pending your approval |
| A1 | Confirm R1 and R2 for yourself before investing in the process | R1, R2 | `[grounded]` posting terms | pending your approval |
| A2 | Ask the recruiter for the role's link on Quillfield's site, and whether Tamsin Achebe is the hiring manager | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Tried quillfield.co.uk/careers, which returned no page. Role reality's organization and contradictions rows, and RR1 and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software forecast CFO", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide) and the same About page. Market calibration and RR4. It gave pay but nothing on scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Role reality's hiring-manager row and E1's choice of which stories to lead with |

I can save all of this as a `tuesday-dossier.md` for later use if you'd like it.

## Upgrade menu

- Where you're based and your pay floor → R1 and R2 resolve, which is the fastest way to a firm `go` or `no_go`.
- Your current CV → I can check R3a, R4 and R8 for how well they're communicated, and any CV edit gets proposed for your approval.
- A sanitized forecast sheet or pipeline-review deck → G1, and R5 and R6 may firm up.
- A sanitized query, model or dashboard screenshot → R5 and R8 rise toward `high`.
- A Salesforce credential's verification page → R4 to `high`.
- Whether your employer's product is software → R3b resolves.
- The recruiter's answer on the careers-page link → RR1 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Have you produced or owned any forecast figure yourself, even for the UK team? And did your pipeline-review numbers feed finance's forecast? Say what was yours and what was finance's.

G2 — Did you work with finance on the revenue numbers behind the renewal dashboards, and where did those numbers come from?

G3 — Do both of the posting's terms work for you: two office days a week in Bristol, and £61,500–£67,000?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.