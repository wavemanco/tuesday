Search permission wasn't granted, so all three research calls were refused. I'm building the pack from what you gave me and will say so in it.
The write to the working directory was declined. I'll save the pack in the session scratchpad instead, which is meant for working files.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-1-denied-06fc9b97/dfff591f-027d-48f3-932b-9ff44c3930ef/scratchpad/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions across seven personas, each with a type tag, answer guidance and a rationale for inclusion and categorization. The working directory refused the first write, so the file went to the session scratchpad.

- **Weights:** I built it as a peer conversation with Dan. The Data-Driven Prober and Peer Evaluator carry the top weight, because he's a peer and describes himself as "relentlessly data-driven". His pricing background is why the strategy cases lean toward pricing, packaging and bundling.
- **Highest-ROI prep:** D1, the Skeptic question "I don't see classic sales-ops or quota-setting in your background." It has the deepest rehearsal, with two follow-ups and concession wording. It uses Priya's plain acknowledgment of the gap. Her volume-targets work stays at the scope you described, not offered as quota-setting.
- **Research:** All three web searches (company values, interview process, Dan's footprint) were refused, so nothing comes from the web. Company context rests on your research note. The interviewer read rests on your description of Dan, not his public footprint, and there is no values cheat sheet. The pack's Sources section says all of this.
- **Priya's evidence:** The evidence column quotes your notes on Priya word for word, so the guidance stays thin where your notes were one line. The ~$400M figure, the revenue model and the partner-motion requirement are where her own sentences would help most.
- **Prohibited claims:** Section 13 lists the claims the pack won't coach, such as "set quotas", "owned the $400M", "designed partner programs" and "owned pricing".

I can play Dan on D1, the Skeptic question, as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy, Northwind Data. Relationship: peer, both reporting to the same VP.
**Round:** one 60-minute conversation with Dan, per your message.
**Built on:** the round and relationship as you described them. The company research did not run (see Sources), so the company picture is your research note and nothing else.
**Highest-ROI prep in this pack: D1**, the sales-ops and quota-setting objection. It will be asked in some form, and it has the deepest rehearsal here.

## 2. How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse it in your own words, and say only what you actually did.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows how you work with others. No Northwind values source was read, so VAL rows here map to no published value |
| EXP | Work-experience deep-dive | Whether the claims on your background survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at Northwind's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

Coverage at a glance (counts of questions by persona and type, read off the banks in section 9):

| Persona bank | VAL | EXP | JD | CO | CASE | Total |
|---|---|---|---|---|---|---|
| A. Data-Driven Prober | 0 | 4 | 1 | 0 | 0 | 5 |
| B. Peer Evaluator | 2 | 0 | 3 | 0 | 0 | 5 |
| C. Case / Strategist | 0 | 0 | 1 | 1 | 1 | 3 |
| D. Skeptic | 0 | 0 | 2 | 1 | 0 | 3 |
| E. Pressure | 0 | 1 | 1 | 0 | 0 | 2 |
| F. Conversational | 0 | 1 | 1 | 0 | 0 | 2 |
| G. Values / Behavioral | 2 | 0 | 0 | 0 | 0 | 2 |
| Total | 4 | 6 | 9 | 2 | 1 | 22 |

## 4. Fit snapshot

The JD column quotes the JD highlights in your message. The evidence column quotes your notes on Priya, in the exact words you gave.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops at a large consumer-tech company, not taking a product to market, and the words stay at that scope: "For nine years I was in product strategy and ops at a large consumer-tech company." Answer slot: the JD's line makes a probe on bringing a new product to market likely. If any of that work was taking a product to market, say what and which part was yours; if there was no such work, or it was not yours, say so plainly and stay with the product strategy and ops role |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote reaches a growth outcome, not a search across customer stages, and the words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD names the stages, so a probe on how you looked for where growth was missing is likely. If the proposal came out of looking across stages or segments, say how you found it, in your own words; if it did not, or you do not know how it was found, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in the JD's terms, but nothing is inspected behind the line, and an interviewer who describes himself as data-driven will probe it. Lead with it in the quote's own terms: "I'm skilled in SQL and Tableau." A3 rehearses the probe |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks this requirement as required, so a probe on whether you designed how a partner channel works is likely. If any of the carrier work was designing how the partnership operated, say what and which part was yours; if the model was your part and there was no design work, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap in the JD's terms, but a line with nothing inspected behind it, so expect a probe on how the consensus was reached. Lead with it in the quote's own terms: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote says use. Your material does not show building or leading AI product work, and the words stay at use: "I use AI tools daily." F2's probe in bank F asks what that use is |
| F7 | Sales-ops and quota-setting depth. Not in the JD highlights; your notes name it as absent | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the notes say so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. F5's quote stays at its own scope and is not offered as quota-setting |

Requirement coverage, mapping each stated requirement to the questions that cover it:

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | B1, C3, D2 |
| identify whitespace across land/adopt/expand/renew | C2 |
| run independent analysis in SQL and Tableau | A3, C2 |
| partner-motion design experience required | B5, D2, A4 |
| strong cross-functional influence | B3, B2, B4, A5 |
| AI experience a plus | F2, C3 |
| Sales-ops and quota-setting depth (F7, not a JD line) | D1, E2 |

## 7. Reading the interviewer

Everything here comes from your description of Dan. Nothing was researched (searches were refused), so none of it comes from his public talks or writing. Public professional footprint only.

| Signal (as you described it) | Practical implication | Provenance |
|---|---|---|
| Profile self-describes as "relentlessly data-driven" | Every number you give is likely to be taken to its assumptions. The ~$400M figure in F2 is the first target (A1, A2, E1) | [inferred] from the persona rule that a data-driven self-description moves the Prober up |
| Career spine is "pricing and monetization roles" | Pricing, packaging and unit-economics angles are his native language (C1). Do not describe your own work in those terms: F4 says a revenue model, not pricing | [inferred] from the persona rule for a pricing or monetization spine |
| "one early-stage-startup chapter" | A weak signal, since it is one chapter. Be ready for why-leave-and-why-now (D3), and keep every answer to what you did | [inferred] from the persona rule for startup chapters, held lightly |
| Peer, same VP | He is judging what you would cost and contribute to his work: the seam (B1), credit (B2), reciprocity (B3, R1) | [grounded] your message, with the persona prior for peers |

Mirror opportunity: the shared vocabulary is revenue. Dan's spine is pricing and monetization; your side of it is the quote in F2, "proposed a store-surface change credited with a ~$400M ARR uplift". That quote says ARR, so offer it as ARR and leave the pricing and monetization labels to him. No career jump of his is known, so none is offered.

## 8. Persona table

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| A. Data-Driven Prober | Takes the ~$400M figure, the revenue model and the volume targets down to inputs and assumptions | Highest. Start from the peer prior (Peer Evaluator plus Prober); his data-driven self-description raises the Prober to the top weight | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know; name the weakest assumption before he does | [inferred] |
| B. Peer Evaluator | Seam between his team and yours, what you would need from him, credit across teams | Highest, level with A. It is the peer prior, and you report to the same VP | Reciprocity first; offer seam principles instead of pretending to know the seam; a disagreement story with spine and tact | [inferred] |
| C. Case / Strategist | Live problems in pricing, packaging and bundling, whitespace, and a launch | Middle. A peer rarely runs a formal case, but his pricing spine tilts the problems toward his native ground, and the role is about new lines | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | [inferred] |
| D. Skeptic | The sales-ops and quota-setting gap, the consumer-to-B2B move, why now | Middle. F7 is a stated gap, and a peer in sales strategy sits close to it | Rehearse D1 until it is boring; bridge only from what your material states; calibrated candor | [inferred] |
| E. Pressure | Time-boxed challenges on the ~$400M and on why you | Low to middle. Peers seldom stress-test, but the figure invites one pointed turn | Pause, restate, anchor in what you said; hold through two follow-ups before conceding anything real | [inferred] |
| F. Conversational | Opening biography and a casual question about AI | Low to middle. A 60-minute single conversation usually opens loosely, and AI is a JD plus | A 90-second arc; treat the casual AI question as scored | [inferred] |
| G. Values / Behavioral | Stem-style behavioral prompts | Low. Your note describes one conversation with Dan, and no source names a values round, so none is detected. A values round elsewhere in the process cannot be ruled out | Selection scaffolds ending in the honest branch | [inferred] |

The loop is a single conversation by your own account, so persona weights rest on that and on the peer prior, not on an archetype fallback.

## 9. Question banks

Depth follows weight: banks A and B are the top weight, C to D middle, E to G light.

### Bank A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F2, with only the beats the quote states: you proposed the change, and it was credited with the ~$400M ARR uplift. Say it at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then four slots, each in your own words. How it was counted: say how if you know; if you do not know, say so plainly. What the figure is sensitive to: name it if you know it. The assumption you would defend least: name it before he does. Which part was yours: say the part. Where any of these is not known to you, say plainly that you do not know how it was counted and return to the proposal | F2 holds the only figure in the material, and an interviewer who describes himself as data-driven goes there first. EXP because it tests whether a headline number survives scrutiny, not what the role needs |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you would defend least before he asks the next question. The pack names none, because nothing in your material does. Answer slot: if you know which assumption is weakest, say it and why; if you do not know how the figure was counted well enough to name one, say so plainly and say what you would check first to find out. A confident-sounding substitute is the one answer that breaks on the next question | The Prober's follow-ups go two levels deeper than the answer, and this is level two on F2. EXP for the same reason as A1 |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold on F3. Pick one analysis where the queries or the views were yours, where a decision or recommendation followed, and where you can say what was yours and what was not. It needs a named question, the data used, and an honest limit. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, "I'm skilled in SQL and Tableau", or how you would run one | The JD asks for independent analysis (F3), and the line has nothing inspected behind it. JD because it scores a stated requirement, delivered as a Prober probe |
| A4 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with the two beats the quote states: you built a partner-level revenue model, and it was used in carrier negotiations. Tell them in your own words at that scope. Answer slot: a follow-up on how the model was built is the likely probe from this interviewer; say what you know in your own words, and if you cannot reconstruct part of it, or part was not yours, say so plainly and return to the two beats | F4 is the closest the material gets to Dan's revenue-and-negotiation ground, so it is probed as work experience. EXP because it tests what was actually the candidate's |
| A5 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, with the beats the quote states: you set annual volume targets, with cross-org consensus. Say it as "I set annual volume targets with cross-org consensus." Your material says volume targets, and the words stay there. Answer slot: expect follow-ups on how the targets were reached; say what you know in your own words, and where part was not yours or you do not know, say so plainly and return to the quote | F5 is the closest the material gets to F7, so the line between them is rehearsed here. EXP because it tests the attribution of a CV claim |

### Bank B. Peer Evaluator (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and GTM for the new lines, and what happens when we disagree?" | JD | [inferred] derived from the role's GTM ownership and the two of you reporting to the same VP | Do not pretend to know Northwind's seam. Say you would first want to understand what his team owns, then offer two or three principles you would use to draw a line, in your own words, and one for disagreements: look at the same numbers first. Ask him what he would want to hold. Concede plainly that you will not know the real seam until you have seen how his team works | The peer is pricing what you add to or take from his load. JD because it scores the GTM ownership line (F1) in the first person |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold on F5. Pick a time work spanned teams and the credit was not simply yours; it needs a named stake, what you did versus what others did, how that was said in the room, and an intact relationship. "We" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I set annual volume targets with cross-org consensus", at that scope, or how you handle credit now | Credit-sharing probes are a Peer Evaluator stem. VAL because it scores behavior; no published value was read, so none is mapped |
| B3 | "What would you need from me to make a launch work, and what could you do for my team in your first month?" | JD | [generic] | Reciprocity first: lead with what you would bring his team, as a plan, then what you need. Name one concrete thing you would hand his team in month one and say how you would check it was useful to him. Claim no past deliverable. The needs side can include asking for his view of what the VP expects from the two of you | Tests cross-functional influence (F5) from the other side of the table. JD because the cross-functional line is a stated requirement; the reciprocity framing is the peer counter-strategy |
| B4 | "Tell me about a disagreement with a peer team and how it ended." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Selection scaffold on F5. The quote says consensus; it does not say there was a disagreement, so do not presume one. Pick a time you held a position against a peer team; it needs a stake, a moment you did not fold, tact, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The Peer Evaluator scores disagreement style with equals. VAL because it is behavioral |
| B5 | "Design a partner motion for a new product line: who are the partners, what do they sell, and how do they get paid?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | A live problem, so structure it aloud: clarify the product line and any existing channel, the objective, partner types, partner economics, the sales motion, metrics, risks; challenge one premise. The one adjacent item in your material is the model, said as a model: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any of the carrier work was designing how the partnership operated, say what and which part was yours; if there was no such work, or it was not yours, say so plainly and stay with the model | F4 is the required-requirement row with the widest gap; a peer asks what you would build together. JD because the partner-motion line is a stated requirement, delivered as a case |

### Bank C. Case / Strategist (middle weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Northwind faces bundling from a much larger platform vendor. For a new product line, how do you decide between selling it standalone and bundling it, and what do you need to know first?" | CO | [grounded] "bundling by a much larger platform vendor" — your research note | Clarify first: which product line, which part of the base, what the vendor's bundle contains. Then objective, segmentation, the standalone-versus-bundle logic on price, packaging and unit economics, metrics, risks. Tie the logic to profitability, which your note lists as a stated priority. Challenge one premise, for example whether the threat is felt equally across enterprise expansion. You do not know Northwind's real attach or pricing data, so say which data you would want. No claim about your past | The bundling threat is in your research note, and his pricing spine makes this his native ground. CO because it scores whether you can think at Northwind's altitude |
| C2 | "How would you find the whitespace across land, adopt, expand and renew for a new product line, and what would you pull first?" | JD | [grounded] "skilled in SQL/Tableau" | Clarify what whitespace means at each stage, then segment by stage, name the data you would pull and what you would distrust in it, and say aloud the assumption you would test first. Say you are skilled in SQL and Tableau and describe what you would do with them as a plan. Metrics and risks last | The JD names the stages (F2) and the tools (F3). JD because it scores the whitespace requirement, delivered as a case |
| C3 | "Take an AI-copilot launch like Compass into the enterprise base. How do you structure the GTM plan, and what do you want to know first?" | CASE | [grounded] "an AI copilot launch ('Compass')" and "enterprise expansion" — your research note | Ask first whether this is one of the two new lines; your note does not say. Then clarify buyer and existing accounts, objective, segmentation, motion, metrics tied to profitability, risks. Think aloud and challenge one premise. No claim about your past | Compass and enterprise expansion are two of the three stated priorities, and F1 is the GTM-ownership requirement. CASE because it is a live problem; the CO grounding comes from the research note |

### Bank D. Skeptic (middle weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in the pack.** Level 1: the plain acknowledgment, "I don't have classic sales-ops or quota-setting experience." Then what your material carries, at its own scope: "I set annual volume targets with cross-org consensus." Your material says volume targets; the words stay there. Then a plan, said as a plan: what you would ask him and the VP in the first weeks about what his team owns and where you would rely on it. Follow-up 1, "How is setting volume targets different from setting a quota?" Answer slot: if you know the difference from direct work, say it in your own words; if you do not, say so plainly and ask him what he sees as the difference. Follow-up 2, "What would you get wrong in your first quarter because of that gap?" Concede specifically: name the area you would depend on his team for, and do not answer "nothing". Hold the core through both: you have no quota-setting experience, and you do have the targets work at the scope it states. Never improve the quote | F7 is the biggest stated gap, and his seat is the closest to it. JD because it scores the gap against the role, delivered as a Skeptic probe |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Choose honestly. The pack's observation: the material reaches least for F1 (product strategy and ops, not taking a product to market) and F4 (a model, not motion design). Name one plainly at its quote's scope, then a ramp plan. Answer slot: which is truly weakest is yours to say; if you can say what part of it you have done, say it in your own words; if none, say so plainly. Calibrated candor beats bluffing a skill he may own | A Skeptic stem, aimed at the thinnest-evidence rows. JD because it scores the listed requirements, gaps included |
| D3 | "Why leave a large consumer-tech company for B2B data infrastructure, and why now?" | CO | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The reasons are yours; the pack supplies none. Answer slot: say your actual reasons in your own words. Check them against the three stated priorities in your research note, "enterprise expansion", "an AI copilot launch ('Compass')" and "reaching profitability", and name only the ones that genuinely pull you; if none does, say your real reason and borrow nothing. Keep the trajectory to what the quote states: two years in consulting, then nine in product strategy and ops | Why-here-and-why-now is the Skeptic's motivation probe, and F1 is the row it presses on. CO because it scores whether your reason connects to what Northwind is actually doing |

### Bank E. Pressure (light weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That ~$400M ARR — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, anchor. The position held is only what the quote carries: "I proposed the change, and it was credited with a ~$400M ARR uplift." Follow-up 1, "Credited by whom?" Follow-up 2, "Would it have happened without you?" Hold both by returning to the proposal, never by adding to it. Concede specifically: where you do not know how the credit was assigned, say so plainly. Answer slot: the share that was yours, if you know it, in your own words; if you do not know, say that. Do not fold on "I proposed it" to restore harmony | A direct stem aimed at F2, the only figure in the material. EXP because it tests attribution honesty |
| E2 | "Sixty seconds: why you rather than someone who has run sales strategy before?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" | A 60-second structure. One: acknowledge, "I don't have classic sales-ops or quota-setting experience." Two: the two quoted items at their scope, the model used in carrier negotiations and the volume targets set with cross-org consensus; let him draw the inference. Three: what you would bring his team, said as a plan. Hold through two follow-ups; concede that the sales-ops side is where you would lean on him | The time-boxed version of D1 (F7), with the adjacent evidence in F4 and F5. JD because it scores fit against the role |

### Bank F. Conversational (light weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built only from the beats the quote states: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Add two or three of the quoted work items at their own scope. Then the move to this role: your reason, in your own words, which the pack does not supply. End by turning it back to him | The opening biography question is scored even in a casual register. EXP because it is a walk through the background (F1) |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Start at the quote's scope: "I use AI tools daily." Answer slot: which tools and for what, in your own words; if some of it is personal rather than work, say so; if it is use and nothing more, say that, and do not describe building or leading. Tie it to Compass only as an interest, and only if it is true | F6 is a JD plus, asked here the way a rapport-builder would ask. JD because it scores a stated requirement |

### Bank G. Values / Behavioral (light weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Pick a time an analysis or a number said something leadership did not want to hear; it needs a named stake, a moment you did not soften it, and an intact relationship afterwards. "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A Values persona stem, with weight kept low because no values round is detected. VAL because it scores behavior; it fits a data-driven interviewer |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. Pick a decision where the customer's interest and an internal number pulled apart; it needs the choice you made, what it cost, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A Values persona stem, light weight. VAL because it is behavioral |

## 11. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "What could a new person on emerging products do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing your load on his team, not only yours | [generic] |
| R2 | "You came to sales strategy through pricing and monetization. What does that lens change about how you would run the motion for a new product line?" | Tied to his own path. It turns an interview into a peer conversation and shows you looked at his background | [grounded] your description of his career |
| R3 | "When the larger vendor's bundle shows up in deals, what does the data show you today?" | Ties the competitive threat in your research note to his data-driven habit, and invites him to show his thinking | [grounded] your research note |
| R4 | "What data do you most wish you had for the new lines that you do not have today?" | Speaks to a self-described data-driven interviewer and surfaces where the first analysis work would be | [generic] |
| R5 | "How do you and our VP decide where sales strategy time goes when a new line needs it?" | Gets at the seam from the process side and shows you are thinking about the shared reporting line | [grounded] your message: the same VP |
| R6 | "What would a good six months look like, in numbers you would trust?" | Anchors the role in measures he owns and trusts, and tells you what he will hold you to | [generic] |

## 13. Prohibited claims

Built from the fit snapshot before the banks were written. None of these is coached, and no slot, hold or bridge in the banks asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM, or took products to market | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says product strategy and ops, not go-to-market. C3 and D2 stay inside that role |
| Set sales quotas, or has quota-setting experience | Negative you stated, F7; also the inflated form of F5 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." F5's quote stays at its own scope. No slot |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The pack's observation: the material says proposed and credited, not delivered. E1's slot asks only which part was yours |
| Designed or ran partner programs | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material says a model, not motion design. B5's slot stays with the model |
| Owned pricing, or priced products | Inflated form of F4 | F4's quote at its own scope. His pricing spine makes this tempting; the material says a revenue model. No slot names pricing |
| Built or led AI products | Inflated form of F6 | F6's quote at its own scope: use. F2's slot stays with use |

## 14. Sources

**Provided documents.** Your message: role, company and level; the JD highlights; the notes on Priya; the description of Dan Kovac; the research note on Northwind's three stated priorities and the bundling threat. No `tuesday-dossier.md` was present.

**Searches sent.** All three were refused, so nothing was retrieved and nothing in this pack comes from a search.

| Query | Outcome |
|---|---|
| Northwind Data company values B2B data infrastructure | refused |
| Northwind Data interview process strategy GTM | refused |
| Dan Kovac Northwind Data Director of Sales Strategy | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. It would have named published values by their official names; no values-style round is detected here, so no cheat sheet is owed, and VAL rows map to no published value |
| 2. `Northwind Data interview process, GTM strategy` | unavailable | Search refused. It would have checked the loop; your own description already establishes one conversation with Dan, so persona weights stand on that |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three stated priorities and the bundling threat, which fix the CO bank |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. It would have added his public talks and writing to section 7, which rests on your description alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Full JD text → the JD column now quotes your highlights, not the posting; with the posting, requirement rows quote it directly and any mid-list item (a named tool or method) that was not in the highlights gets a question
- Priya's CV or resume lines, word for word → the evidence column holds your one-line notes, so every guidance cell is thin; her actual sentences would turn the transferability rows F1, F2 and F4 into story-mapped answers
- Priya's own answers on the ~$400M figure (how it was counted, what it is sensitive to, the weakest assumption, which part was hers) → upgrades A1, A2 and E1 from answer slots to rehearsed answers
- Permission for web search → company values and the loop, and Dan's public talks and writing; the interviewer read and R2 to R4 become researched, and a values cheat sheet appears if a values round turns up
- Deeper research pass (L2) → a strategy brief and Dan's footprint in more depth, up to 6 more searches and 2 more fetches, several more minutes; offered once, and it needs search permission
- Prep time available → a prioritized prep schedule sized to it
- The recruiter's guidance on focus areas or any pre-declared deliverable → coverage beyond the peer-round prior; usually one email to the recruiter
- A `tuesday-dossier.md` from a job-underwriter run → an evidence-derived objection and verified claims in place of the ones inferred here
