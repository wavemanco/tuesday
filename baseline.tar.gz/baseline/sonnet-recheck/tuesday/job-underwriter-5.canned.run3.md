Careers page and company page checked. Both match what you pasted. Here's the assessment.

## Decision snapshot

**Yes, this is worth applying to: R3, R4, R5, R6 and R7, the five must-haves, all land `direct`, and the posted pay sits at the market median (RR4). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery as the warehouse) · unclear: R9 (Data contracts), R10 (Ingestion from app and CRM)

R8 has a bridge with its limit named, and R9 and R10 wait on answers only you have.

**Opportunity ledger.** The role is concrete and transparent about pay and stack (RR4, RR5). What it leaves open is team size, reporting line and equity terms (RR1, RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 check out against your location, work authorization and pay floor (G1); (2) the BigQuery gap (R8) is presented as adjacent, never as BigQuery experience; (3) team size and reporting line verify acceptably in the loop (RR1, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company about page; funding and headcount are the company's own statements, with no independent coverage surfaced |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` careers page, fetched |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` careers page |
| Working pattern | Remote (US) or Denver office; the posting shows "Accepting applications" | `[grounded]` careers page, fetched |
| Scope read | One reporting domain end to end (ingestion, warehouse, contracts), with no team or direct reports named | `[inferred]` from the JD's scope list against its silence on team; `[generic]` that your Datawright report puts typical Senior scope at one domain's pipelines with no direct reports |
| Market calibration | Posted $148,000–$166,000 against Datawright 2026 (US, n=2,310; Senior Data Engineer, Series B–D): base median $151,000, interquartile range $139,000–$163,500. The low end sits $3,000 under the median and the high end $2,500 over the top of the range. Pellucid is Series C, inside that cohort. 5+ years against a typical 5–8 for "Senior" puts your 6 years inside it. Equity is excluded from the comparison | `[grounded]` posting and the report you supplied; `[generic]` that this is the norm for the title, not a claim about this employer's offer |
| Unknowns | Team size, reporting line, equity terms, first-year outcomes (none stated) | `[grounded]` posting silence |
| Contradictions | None: the fetched posting and about page match your pasted text | `[grounded]` pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or your work authorization, so the band grades a statement that doesn't exist yet | `[grounded]` JD term; your background is silent on it | G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given. The posted range itself is in hand (see RR4) | `[grounded]` JD term; no floor stated | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company. Self-reported, with nothing inspectable yet. Years of experience is a requirement, not a gate | `[grounded]` your stated background | offer: your CV with dates and titles would give the years a document |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a judgment the posting will test, so expect a technical screen | `[grounded]` your stated background; `[generic]` that screens for this title usually include live SQL or Python | offer: a sanitized code sample or repo link |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Snowflake meets "a cloud warehouse"; the posting's BigQuery is R8 | `[grounded]` your stated background | offer: a sanitized dbt docs or lineage page |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as your orchestrator. What you built versus maintained isn't stated | `[grounded]` your stated background | offer: a sanitized DAG file or Airflow UI screenshot |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Its coverage and who consumed the results aren't stated | `[grounded]` your stated background | offer: the suite config or data-docs page, sanitized |
| R8 | BigQuery as the warehouse | important | adjacent | medium | transferability | Bridge: dbt modelling on Snowflake. Limit: you've never used BigQuery, so anything specific to it is untested. Strengthener: a small dbt project run against BigQuery | `[grounded]` your statements that you've never used BigQuery and built dbt on Snowflake; `[generic]` that dbt modelling skills usually carry across warehouses while warehouse-specific tuning and cost behaviour do not | see G4 |
| R9 | The data contracts analysts depend on | important | unclear | low | discovery | Your dbt tests and Great Expectations suite are indirect context. Nothing you've said establishes contracts agreed with consumers | `[inferred]` from adjacent testing work; no claim made | G3 |
| R10 | Ingestion from app and CRM sources | important | unclear | low | discovery | Airflow work suggests ingestion exposure, but your sources and what you built aren't stated | `[inferred]` from the Airflow claim; no claim made | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, authorization, pay floor (R1, R2, hard_gate) | hard_gate | None of the three is stated | Either could end the process before skills matter | Not applicable: these are terms you meet or don't | None needed; your confirmation is the evidence | `[grounded]` no constraints given |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Airflow is named; sources and ingestion design aren't | It is the first item in the posting's mandate | Pulling from a product database or event stream; syncing a CRM or billing system; building an incremental load or backfill | An architecture sketch, a sanitized DAG, a source inventory | `[grounded]` background silent on sources; `[generic]` that ingestion design is a common interview topic for this title |
| G3 | Data contracts (R9, important) | discovery | Testing is shown; agreements with consumers aren't | It is named in the mandate, and "contract" may mean anything from schema checks to signed expectations | Agreed schemas or freshness expectations with analysts; a breaking-change process; owners named on models | A contract doc, a schema-change policy, a dbt model YAML with tests and owners | `[grounded]` background silent; `[generic]` that usage of "data contract" varies by company |
| G4 | BigQuery (R8, important) | transferability | Snowflake and dbt, no BigQuery | The posting names it in the mandate, not in the requirements list | Not a recall gap: you've said it's new | A small dbt project built on BigQuery, even a toy one | `[grounded]` your statement; `[inferred]` that the posting treats it as learnable, from "a cloud warehouse" in its requirements |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team size and breadth unstated | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may cover the whole stack as the sole data engineer, or sit inside a larger team | `[inferred]` from the scope list against the posting's silence on team | How many data engineers are on the team, and who owns ingestion and the warehouse today? | unresolved |
| RR2 | No hiring manager named | unknown | — | Posting names no hiring manager (your note) | Reporting line and who sets priorities are unknown | `[grounded]` posting silence | Who would this role report to, and which analysts would depend on the contracts? | unresolved |
| RR3 | Equity unspecified | unknown | — | "plus equity" | Grant size, vesting and strike terms may matter to total pay and aren't stated | `[inferred]` from the posting's silence | What is the equity grant range at this level, and what are the vesting and strike terms? | unresolved |
| RR4 | Salary stated, at or above market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the Datawright median ($151,000) and its top end is above that report's interquartile range ($163,500), so no seniority-pay mismatch | `[grounded]` posting and your report | Where in this range would an offer for six years of experience land? | noted |
| RR5 | Concrete stack and deliverables | positive_signal | — | "dbt-modelled warehouse in BigQuery" | The scope is concretely defined, not boilerplate | `[grounded]` posting names systems and outputs | What would a successful first year look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the dbt project (about 180 models, Snowflake), Airflow and the Great Expectations suite you set up in the top third of the resume; keep "Snowflake" explicit and don't list BigQuery as a skill | See R5, R6, R7, R8 | `[grounded]` your stated background | resume_edits_pending_approval |
| W1 | A small dbt project run against BigQuery before interviews | See R8, G4 | `[inferred]` from R8's limit | pending your approval |
| A1 | Say it plainly if asked: "I haven't used BigQuery; I built our dbt project on Snowflake." Both clauses come from your own sentences | See R8 | `[grounded]` your statements | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

If you want the resume tailored to this posting line by line, resume-tailor does that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality's organization and contradictions rows: the employer exists as described, the posting is live and matches your paste, so the standing employer-not-established entry doesn't apply. The search surfaced no independent coverage of the funding round |
| 2. Role-family sweep | skipped | Your Datawright report is in hand and fixes market calibration, RR4 and the scope read |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

## Dossier offer and upgrade menu

I can save all of this as `tuesday-dossier.md` if you'd like it to carry forward; say the word.

- Your CV with dates and titles, or any sanitized artifact (dbt docs or lineage page, Great Expectations config, a DAG file, a repo link): R3 through R7 can move from `medium` toward `high`.
- Answers to G2 and G3: R10 and R9 move off `unclear`.
- Your location, authorization and pay floor: R1 and R2 resolve, and the status likely moves to `go`.
- The hiring manager's name: sharpens the scope read and which story to lead with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

G1 — Are you in the US, authorized to work there without sponsorship, and is $148,000–$166,000 above your pay floor?

G2 — Which source systems fed your pipelines at the payroll company, how did data get into Snowflake, and which parts did you build yourself?

G3 — Did you ever agree schemas, freshness or change-handling expectations with the analysts or teams using your models, and what was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.