Running the company check on Quartzline and a role-family search for platform-API PM roles, then I'll write the assessment.
**Decision snapshot**

**No, you're not wasting your time on this role. It's a stretch application, not a long shot. Status: `conditional_go`.** This answers the Quartzline posting only. One posting can't answer whether the pivot as a whole is sound.

**Fit ledger**

- `must_have`: adjacent: R1b (PM-equivalent work, no title) · absent: R1a (3+ years PM experience, titled)
- `important`: direct: R3, R7 · adjacent: R2a (API products, implementer side), R4 (stakeholders incl. sales), R6 (owning the roadmap), R9 (launches with sales and support), R10 (specs, two squads) · unclear: R2b (shipped a product others adopted), R5 (agile delivery), R8 (adoption metrics)

R1a is the row to resolve first, and R3 and R7 are the rows to lead with.

**Opportunity ledger.** The scope is concrete: two named squads and defined responsibilities (RR4). Three things are unresolved: the employer is unverified (RR1), compensation isn't stated (RR2), and the titled-years requirement may be screened literally (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting and employer verify (RR1).
  2. Someone confirms that PM-equivalent work counts toward the 3+ years (R1a, RR3).
  3. Your adjacent work (R1b, R2a, R4, R6, R9, R10) is framed as adjacent. It is never presented as a PM title or as owning a product.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs; adoption metrics; launches with sales and support | `[grounded]` JD |
| Team | Two engineering squads | `[grounded]` JD |
| Scope read | A platform PM role whose users are external developers integrating an API. That is close to the clients you integrated for. | `[inferred]` from the JD's partner-integration language against your 30+ client integrations |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established. The role-family sweep could not run and the posting states no compensation. | — |
| Unknowns | Compensation, location, who the role reports to, adoption-metric targets, decision rights between the squads | `[grounded]` JD silent on each |
| Contradictions | None visible inside the JD | `[grounded]` JD only; no second source checked |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | none | capability | You've never held a PM title, so on a literal reading the years don't exist. This is a length-of-experience requirement, not a gate. | `[grounded]` your statement and the JD | Ask RR3's question; R1b carries the case |
| R1b | Same requirement, read as PM work done without the title | must_have | adjacent | medium | transferability | You coordinated engineers, clients and PMs on custom builds, wrote requirements documents, and ran quarterly roadmap-input sessions. Limit: input to a roadmap, not ownership of one. Confirmed in prose only, with nothing inspectable yet. | `[grounded]` your resume summary | Offer an artifact: a sanitized requirements doc or a roadmap-input summary |
| R2a | Shipped API or platform products | important | adjacent | medium | transferability | You led 30+ integrations of your employer's REST APIs end to end, on the consumer and delivery side. Limit: you did not say you designed or shipped the API itself. | `[grounded]` resume summary | Bridge case in the plan; see G1 |
| R2b | Same requirement, shipped a product others adopted | important | unclear | low | discovery | Only an unconfirmed memory lead exists: an internal request-triage tool that support agents adopted. It is a question, not evidence. | `[inferred]` from the memory lead | G1 question |
| R3 | Technical fluency: API docs, schemas | important | direct | medium | none | Postman, SQL and OpenAPI reading are stated, and the integration work backs them. No artifact has been inspected. | `[grounded]` resume summary | none |
| R4 | Stakeholder management across engineering, sales, customers | important | adjacent | medium | transferability | Engineers, client engineers and PMs are covered. Sales isn't mentioned, so this takes the lower fit. | `[grounded]` resume summary; sales is `[grounded]` silence | Name any sales contact you worked with, if one exists |
| R5 | Agile delivery experience | important | unclear | low | discovery | The resume is silent on sprints, backlogs or squads. | `[grounded]` resume silence | G2 question |
| R6 | Own the roadmap | important | adjacent | low | transferability | You ran quarterly roadmap-input sessions. Limit: input, not prioritization or ownership. Low because the evidence is indirect. | `[grounded]` resume summary | Bridge case in the plan |
| R7 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops plus quarterly client feedback sessions are discovery. A PM reader may not recognise it under solutions-engineering wording. | `[grounded]` resume summary | E1, pending approval |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent on adoption measures. SQL is stated, but no metric is. | `[grounded]` resume silence | G1 question |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You ran go-lives for client integrations. Limit: client go-lives, not product launches. | `[grounded]` resume summary | Bridge case in the plan |
| R10 | Write specs; drive delivery with two engineering squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers on custom builds. Limit: custom client builds, not a standing product squad. | `[grounded]` resume summary | G2 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped a product others adopted; adoption metrics (R2b, R8) | discovery | Nothing confirmed. An earlier conversation hinted at a request-triage tool that support agents used. | This is the nearest thing to PM-owned product evidence. Confirmed, it could lift R2b and R8 and strengthen R1b. | Building or specifying the tool; deciding what it did; a rollout to agents; usage counts, ticket-time changes, adoption by team | A screenshot, a usage number, a short internal write-up | `[grounded]` resume silence; `[inferred]` that a confirmed tool moves these rows |
| G2 | Agile delivery and specs (R5, R10) | discovery | Requirements documents and engineer coordination are stated. Delivery cadence is not. | A product role with two squads leans on this. | Writing tickets or acceptance criteria that engineers built from; joining sprint planning or demos; triaging bugs against a backlog | A sanitized requirements doc or ticket example | `[grounded]` resume silence; `[generic]` that squad-based roles lean on it |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be real and simply small. The search that would have checked this was not permitted, so nothing was confirmed either way. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's own careers page, and tell me who I'd interview with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (the posting gives no figure) | The figure may sit anywhere in the role-family band, which I could not check. | `[generic]`; no sweep ran | What range is budgeted for this role? | unresolved |
| RR3 | Titled-years requirement marked must-have | risk_signal | medium | "3+ years product management experience (must-have)" | A screener may read it literally, which would filter you out before your adjacent work is read. | `[generic]` hiring pattern, not a claim about this employer | Would the team count PM-equivalent work on custom builds and roadmap input toward the 3+ years, or does it need a PM title? | unresolved |
| RR4 | Concrete team and scope | positive_signal | — | "drive delivery with two engineering squads" | Scope is defined enough to be measurable; decision rights between the squads are still unstated. | `[grounded]` JD | Who sets priorities across the two squads, and does the PM have the final call? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line, current: "Ran quarterly roadmap-input sessions collecting client feedback for product." Proposed: "Ran quarterly client sessions that collected roadmap input for the product team." Move it next to the integration bullet. | R7. This is a reorder and rename only. It adds no ownership and no outcome. | `[grounded]` your resume summary | `resume_edits_pending_approval` |
| E2 | Resume line: "Led 30+ client integrations of our REST APIs, from scoping workshops through go-live." Put it first in the role. | R2a, R3, R7. Every clause traces to your summary. | `[grounded]` your resume summary | `resume_edits_pending_approval` |
| A1 | Confirm the posting is live on Quartzline's own careers page before investing effort. | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR3's question in the first recruiter conversation. | It tests whether R1a screens you out. | `[grounded]` RR3 | pending your approval |
| A3 | Optional work sample: a one-page spec for an improvement to an API integration pain point you saw repeatedly, labeled as an exercise and not as shipped work. | It narrows the limits on R6 and R10. | `[inferred]` from the transferability gaps | pending your approval |
| A4 | Seek a referral or warm introduction before applying cold. | A pattern at companies of this size, not a fact about Quartzline. | `[generic]` | pending your approval |

Everything in this plan is proposed and nothing is applied. The approval status covers the table and every piece of advice in this message. The bridge cases (R2a, R6, R9, R10) are to be described as adjacent work, never as PM ownership. If you decide to apply, resume-tailor can do the full line-by-line rewrite for this posting.

## Evidence status

Verified: none yet. Unverified lead: a request-triage tool from an earlier conversation. It's unconfirmed and used only to prompt G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company partner API platform careers"; refused. It would have confirmed the company and the live posting, feeding role reality's organization row and RR1. |
| 2. Role-family sweep | unavailable | Searched "platform API product manager hiring solutions engineer to product manager transition without PM title B2B SaaS"; refused. It would have fed the market calibration row, RR2, and how often similar postings accept non-titled PM experience (RR3). |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed. |

## Offer and upgrade menu

I can save this as `tuesday-dossier.md` if you want to carry it into other steps.

- The live careers-page link or the recruiter's email domain → RR1 closes; the `conditional_go` cap on employer verification lifts.
- Permission to run web search → targets 1 and 2 run, filling the market calibration row and RR2.
- The actual resume file rather than a summary → E1 and E2 become exact line edits.
- A sanitized requirements document or the integration playbook → R1b, R10 and R4 can reach `high`.
- A usage number, screenshot or short write-up of the triage tool, if it's yours → R2b and R8 move.
- The hiring manager's name → the scope read and which story to lead with.

**Questions**

G1 — An earlier conversation suggested you may have built an internal request-triage tool that support agents adopted. Is that right? If so, what did you own, who used it, and how did you know it was adopted?
G2 — On custom builds, did you write tickets, user stories or specs that engineers built from, and did the engineering teams work in sprints?
C1 — Do you have any non-negotiables for this move (location or remote, pay floor, travel)? I haven't checked the role against any yet.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.