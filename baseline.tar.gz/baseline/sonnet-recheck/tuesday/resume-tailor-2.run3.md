I've read the resume-tailor rules and I'm building your edit ledger now. It uses only what you wrote, so nothing in it is added.

Two things first. Nothing below is applied until you approve it. And the must-have, 3+ years of data engineering, can't be closed by rewording. You've held analyst titles, so I've named it as a gap below and haven't written around it.

## Edit ledger (proposed; not applied)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. SQL every day on Redshift, complex window functions and CTEs." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `compress` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke and added tests to it." | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | *(unchanged, moved below E4)* | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved to the last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |

- **Order:** E2 (dbt and the orders mart) leads because it's your closest match to warehouse work. E3 (star schema) and E4 (nightly job and tests) follow. Python is fourth and SQL last, since SQL is the least differentiating line for this role.
- **E3 keeps "with our then-DE".** That qualifier is the honest part, so it stays.
- **E4 only drops the first person and changes the tense.** "Our" stays, and no "owned" or "managed" appears.
- **Your title stays "Senior Data Analyst".** Retitling to anything with "Engineer" in it would be an upgrade, not an equivalent.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Named absence A1 below. No row can carry it. | `[grounded]` your title and history are analyst; `[generic]` a title screen on a must-have is usually the first filter |
| R2 | Production Python | important | `not_evidenced` | Your Python is described as analysis plus cron scripts. E5 shows it as written. Recall prompt C1. | `[grounded]` your own wording is "for analysis"; `[generic]` "production" implies unattended, monitored code |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | A nightly dbt job isn't an orchestrator, and you've never used Airflow. Recall prompt C2. | `[grounded]` "Never used Airflow or Spark"; `[generic]` dbt runs transformations, and orchestration means scheduling and dependencies across jobs |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E3. It is co-designed with the DE, not solo. | `[grounded]` your resume |
| R5 | Warehouse modelling | important | `surfaced_by_edit` | E2 and E3 (Redshift, the orders mart). | `[grounded]` your resume |
| R6 | Data quality | important | `surfaced_by_edit` | E4. You added tests to one job, and that is the extent of it. | `[grounded]` your resume |
| R7 | SLAs | important | `not_evidenced` | Nothing about deadlines or alerting. Recall prompt C3. | `[grounded]` no SLA language in your resume |
| R8 | Streaming, with Spark and Kafka named in the duties | preferred | `not_evidenced` | Named absence A2 below. | `[grounded]` "Never used Airflow or Spark. Never touched Kafka." |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | Python for analysis, plus "some scripting to pull vendor APIs on a cron". | Without any sign the scripts run unattended, a reader sees analyst Python. | Vendor-pull scripts others depend on; retries, logging or failure alerts; scripts running on a server rather than a laptop | A repo, a README, the cron entry, an alert email | `[grounded]` what the resume says; `[generic]` how "production" is read |
| C2 | Airflow or equivalent orchestration | important | A nightly dbt job you fix and test. | Orchestration is named in the duties, and this is the closest thing you have to it. | Setting or changing the nightly schedule; ordering jobs by dependency; dbt Cloud or a similar scheduler | The job config, a run-schedule doc | `[grounded]` what the resume says; `[generic]` what counts as "equivalent" is the hiring team's call |
| C3 | SLAs | important | Tests added to the job; no deadline or alerting mentioned. | Owning SLAs is in the duties. | An agreed "mart is ready by 7am" deadline; alerts on test failure; a freshness check | A Slack alert, a freshness test, a dashboard | `[grounded]` no SLA language in the resume; `[generic]` how these duties are read |

**Named absences (no row, nothing to pull):**

- **A1, 3+ years data engineering.** You've worked 5 years as an analyst and none under a data-engineering title. Closing it would take a role titled data engineer for about three years, or a hiring team that counts your dbt, modelling and pipeline-repair work as equivalent. No wording closes it. Whether this role is worth applying to with that gap is job-underwriter's call.
- **A2, streaming, Spark, Kafka.** You've never touched any of them, and streaming is listed only as a plus. Closing it would take a small hands-on project, such as a Kafka consumer feeding a table. Even then, a project can't be written up as work experience. For this role it's not worth chasing before applying.

## Not written, and why

- **"Data engineering experience" or any "3+ years" figure.** Your history is analyst work, and this is the must-have.
- **"Built and owned production pipelines".** You maintain and fix one nightly job and wrote some cron scripts.
- **"Orchestration experience" or "Airflow-equivalent".** Writing that would turn dbt scheduling into the JD's own term for your history.
- **"Modelled the warehouse".** You designed one star schema with a DE.
- **"Owned data quality and SLAs".** You added tests. SLAs appear nowhere in what you wrote.
- **"Production Python".** Your wording is "for analysis". It stays that way until C1 is answered.
- **Spark, Kafka, "streaming familiarity", or "Data Engineer" as a title.** None of these are in your history.
- **Hidden keyword text.** I'd refuse it, and you haven't asked for it.

## Parse-safety check

You pasted text, not a file, so I couldn't check layout. I can't tell you about multi-column layout, tables or text boxes, content in headers and footers, section headings, or file type. A `.docx` or a text-layer PDF is the safe choice when you send it. If you share the actual file, I'll run those checks.

## Upgrade menu (offers I'd build only if you say yes)

- **The real resume file or older versions.** Older versions often hold lines that were cut, which could turn some `not_evidenced` rows into real ones.
- **A link to your dbt repo or docs.** That would give me stronger evidence for E2 to E4 and for C2 and C3.
- **Your answers to the questions below.** Each confirmed answer upgrades its gap row.

## Questions (at most 3; answer in text, paste a voice transcript, attach a document, drop a link, or say skip)

- **C1:** Do the vendor-API scripts run unattended, feed tables someone else depends on, and handle failures with retries, logs or alerts? Where do they run?
- **C2:** What triggers your nightly dbt job: dbt Cloud, cron, or a tool owned by your DE? Did you set up or change that schedule or the job order?
- **C3:** Does anyone downstream expect the orders mart ready by a set time, and does a failure alert anyone?

Reply with "Approved: E1, E3 …" and "Rejected: E2 — reason", and I'll produce the resume from the approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.