Web search was blocked, so this read uses only what you pasted. Evidence status shows what that cost.

## Decision snapshot

**Yes, worth applying to, once the posting verifies and R1 is confirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R7a
- `important`: adjacent: R8 (Own pricing analytics for the pet product) · unclear: R7b (Recommendations for product)
- `preferred`: direct: R9

The questions that could move this sit on R1, R7b and R8. Your two worries reach the map differently. Pet-insurance inexperience shows up in R9 and RR5. Never having managed anyone has no row, because the JD names no reports.

**Opportunity ledger.** Plausible but unverified. The employer is not established (RR2), the salary is not stated (RR1), and authority and scope are unstated (RR3). The pet-specific ramp is open (RR5). The JD's tasks are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is confirmed live on Brindlemoor's own site (RR2); (2) R1 is confirmed by you; (3) authority and pet-ramp expectations are answered in the loop (RR3, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Existence not yet checked | `[grounded]` JD header; search blocked |
| Mandate | Own pricing analytics for pet insurance: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint not researched | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Compensation | Not stated in the pasted JD | `[grounded]` JD silent |
| Scope read | A single-product analytics seat under a Director. No reports or team size named, so no sign it is a people-management role | `[inferred]` from the JD's silence on reports |
| Market calibration | Not done. The role-family sweep did not run, and I won't estimate a band from memory | — |
| Unknowns | Salary; contract basis; team size; who signs off rate changes; data stack | — |
| Contradictions | None inside the JD as pasted. The careers-page comparison did not run | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but residence and right to work are not stated, and the JD says "Fully remote (UK)" | `[grounded]` JD; your employer's location is circumstantial | G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, stated in prose. A length requirement, not a gate. No document yet, so medium | `[grounded]` your background statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use, self-reported. A non-confidential query or notebook would raise it | `[grounded]` your background statement | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but nothing inspected | `[grounded]` your background statement | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Same evidence as R4. "Built and maintained" covers building and ongoing upkeep | `[grounded]` your background statement | none |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with underwriting. "Ran" does not say whether you designed them or only read them, so I resolve it downward until you say | `[grounded]` your background statement | G3 |
| R7a | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. That meets the JD's "underwriting or actuarial". It is not actuarial presenting, and should not be described as such | `[grounded]` your background statement | none |
| R7b | Recommendations for product | important | unclear | low | discovery | Your stated audience is underwriting. Nothing mentions product stakeholders | `[grounded]` your background statement silent | G2 |
| R8 | Own pricing analytics for the pet product | important | adjacent | medium | transferability | Bridge: you own the young-driver GLM. Limit: that is one book of a motor portfolio, not a whole product's pricing analytics, and not pet | `[grounded]` your background statement; `[inferred]` bridge | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years in motor insurance. Pet is not what you did | `[grounded]` your background statement; `[generic]` pet and motor pricing use different rating factors and claim drivers, so expect the transfer to be probed (RR5) | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based and able to work fully remote (R1, hard_gate) | hard_gate | Your UK insurer employment, but no statement of residence or right to work | A gate the inputs do not settle stays open, and it caps the decision | Not a recall item: a plain yes or no | None needed | `[grounded]` inputs silent |
| G2 | Recommendations to product (R7b, important) | discovery | Underwriting is your only named audience | The JD names product as a recipient of your recommendations | A pricing result taken to a product, commercial, marketing or distribution group; a proposition change that followed from a price test | A readout or deck from such a meeting, sanitized | `[grounded]` background silent; `[generic]` pricing seats in insurance often serve product owners as well |
| G3 | What you personally owned across tests and models (R6, R8) | discovery | "Ran 14 price tests" and "built and maintained" the young-driver GLM | Separates designing and reading tests from running them, and a book from a product | Choosing the test split, sample size and duration; writing the readout; setting the monitoring cadence for the GLM | A test readout, a model monitoring pack or GLM documentation, sanitized | `[grounded]` the two source clauses; `[inferred]` that ownership scope decides R6 and R8 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary not stated | unknown | — | none: the pasted JD states no pay | May sit outside your floor or the market, or simply be unpublished | `[grounded]` JD silent; no band, because the sweep did not run | What salary range is budgeted for this role? | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | May be too new or small for a footprint, or the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Authority and scope unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | Ownership may stop short of sign-off on rate changes, or the seat may carry mentoring or leadership duties | `[inferred]` from the JD's ownership language against its silence on decision rights and reports | Who signs off rate changes, and does this role have or expect reports or mentoring duties? | unresolved |
| RR4 | Concrete responsibilities | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is specific and matches a pricing analytics function | `[grounded]` JD | Which of these three is the first priority in the first 90 days? | noted |
| RR5 | Pet-specific ramp unknown | unknown | — | "insurance experience a plus" | The "a plus" wording suggests pet specifics are learnable, but expectations on day one are unstated | `[inferred]` from "a plus" in the JD; `[generic]` pet pricing differs from motor | How much pet-specific rating knowledge do you expect on day one, and what onboarding supports it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Brindlemoor's own careers site before spending application effort | see RR2 | `[grounded]` RR2 | pending your approval |
| E1 | Lead with three facts, worded as you gave them: the GLM rating model you built and maintained for the young-driver book; the 14 price tests you ran last year with underwriting; the quarterly pricing review you present to the head of underwriting. Say "ran", not "designed", until G3 settles it | see R4, R6, R7a | `[grounded]` your three statements | pending your approval |
| E2 | Say plainly that your insurance pricing is in motor, and bring a question about pet rating. Do not claim pet-specific experience | see R9, RR5 | `[grounded]` your statement | pending your approval |
| Q1 | Ask the RR1 to RR5 questions verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Brindlemoor pet insurance insurtech UK", "Brindlemoor careers Senior Pricing Analyst") were refused. It would have settled RR2 and the contradictions row |
| 2. Role-family sweep | unavailable | One search (UK senior pricing analyst salary, remote, pet insurance) was refused. It would have supplied the market calibration and set RR1 against a band |
| 3. Hiring manager's public footprint | unavailable | One search ("Odile Varga Director of Pricing Brindlemoor") was refused. It would have informed the scope read and which story to lead with |

I can offer the dossier as a file (`tuesday-dossier.md`) whenever you want to keep this assessment.

## Upgrade menu

- Search permission, or a link to the role on Brindlemoor's own careers page: RR2 closes or escalates, and role reality gains a checked organization row.
- Your CV: R2 to R7a move from self-report toward inspectable evidence.
- A sanitized price-test readout, GLM model documentation or monitoring pack, or the structure of a quarterly review deck: R4, R6 and R7a can rise to `high`.
- Your constraints (pay floor, notice period, any location limits): the hard-gates line stops saying "checks against them unknown".
- The salary range: RR1 closes against a band, once a sweep can run.

G1 — Are you UK-based with the right to work in the UK, and is fully remote fine for you?
G2 — Have you taken pricing results to a product, commercial or marketing group, not only to underwriting, and what changed as a result?
G3 — Of the 14 tests and the young-driver GLM, which parts did you personally own: test design, readouts, model monitoring? Give one example, with what happened.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.