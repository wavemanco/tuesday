Search access was refused, so I'm building the pack from what you gave me alone and saving it now.
The write to the working folder was denied, so I'll save the pack to the session scratchpad instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-denied-841a40c2/d1595c48-974a-4866-8f26-0d8b15075b70/scratchpad/Saltmarsh-Games_live-operations-producer_interview_pack.md`. It has 20 questions across six interviewer styles, and the interview day triage is in the file. I couldn't save it to the project folder because that write was denied.

I built it for a hiring-manager round and assumed Tobias would be that person. It has no company research. All four searches (values, interview process, strategy, Tobias himself) were refused, so it uses only your JD and your background. The pack's upgrade menu lists what each missing piece would add.

Say the word and I'll play the Skeptic on B1 ("Which part of this JD would you be weakest at on day one?"), the question the pack flags as your highest-value prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and has the recruiter said anything about format or a task to bring? The answer reweights every question bank.
Can you paste the CV wording for your calendar, checklist and retention lines? The pack currently quotes your message, so your CV's own words would replace those quotes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Format: 60 minutes, Friday. Relationship assumed: hiring manager (your note did not say). No company research is in this pack: every search was refused, so values, loop structure, strategy and the interviewer's public footprint are absent and the upgrade menu says what each would add.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used here: no values-style round was detected and no published values were read |
| EXP | Whether the claims on your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company, market and strategy knowledge. Generic here, because nothing was researched |
| CASE | A live problem from the role, scored on structure and reasoning |

Question IDs run by persona (A to E, then G). Fit-snapshot rows are F1 to F9. A line in an Answer guidance cell that begins "Answer slot" is an instruction for the interview, not a question for you to answer here.

## Prep triage

You have until Friday. Do these in order; each is tied to the pack.

1. B1, then B2 and B3, aloud, twice each. B1 is the highest-ROI prep in the pack: it is the objection most likely to be asked, and it sits where your material is thinnest (F1, F3).
2. D1, the 90-second arc, until it fits in 90 seconds using only its four lines.
3. A1, A3 and A5, said aloud as structures: clarify, then objective, then approach, then metrics, then risks.
4. C1 and E2, so you know exactly what you can and cannot say about the retention numbers.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not live events and not two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles lines make a probe on both likely. If any drops were timed events, or you worked on a calendar for a second title, say which, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | Your material names a calendar, not who worked on it, so the coordination is not shown. Answer slot: the JD names four teams, so expect a probe on each. Say which of design, art, engineering and community you worked with on a drop and what that looked like, in your own words; if you did not work with one of them, or the calendar was not where you coordinated them, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | The words stay at the quote: "I presented the monthly retention numbers to the studio head." Your material shows presenting a monthly report, not reviewing events or owning KPIs. Answer slot: the JD pairs a post-event review with the KPIs it reports, so expect a probe on both. If you reviewed drops after release, say what you looked at and what you did with it; if there was no such review, or the KPIs were not yours, say so plainly and stay with the numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: "I wrote the release checklist our QA team still uses." Lead with it in those terms. The pack's observation: the quote says wrote and still in use, not that you ran it at each release. Answer slot: if you also ran it at releases with QA, say how; if you wrote it and others ran it, say so plainly and stay with the checklist QA still uses |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The pack's derivation: weekly content drops suggest a live title for those two years, but your material does not say whether the title was live-service or what the other two years were. Answer slot: the 3+ years line makes a probe on how many years were live likely. Say how many of the four were on a live title, in your own words; if it was two, say two plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: "I ran the weekly content-drop calendar for our main title for the last two years." A cadence and a duration beat an adjective. Expect a probe anyway, because nothing inspectable stands behind the line |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement: "I presented the monthly retention numbers to the studio head." The pack's observation: presented, not computed or analysed, so expect the probe to go to how the numbers were counted (C1, E2) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written checklist that QA still uses is the nearest evidence; your material shows no other writing. Words: "I wrote the release checklist our QA team still uses." Answer slot: expect a probe for a sample. If you wrote anything else others relied on, say what, in your own words; if the checklist is your main example, say so plainly |
| F9 | No JD line: team leadership and in-app purchase experience, your own stated limits | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap you stated, so the words are yours: "I haven't led a team." and "I haven't worked on a game with in-app purchases." Follow each with how you would learn it, said as a plan and never as a past. Nothing added to make either gap feel smaller |

## Persona table

Weights start from the relationship prior for a hiring manager (Case/Strategist plus Skeptic). No interviewer information was researched, so nothing adjusts them. No loop source establishes the loop, so it falls back to the Generic archetype (screen, hiring manager, panel) with flat tilt: these weights rest on the relationship prior and on the assumption that Tobias is your hiring manager. If he is not, tell me and every bank reweights.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Live problems from the role: plan this calendar, diagnose this drop | Highest. Hiring-manager prior; the JD's calendar, coordination and KPI lines (F1, F2, F3) are all things to be tested live | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B, 5 questions) | Quiet probing of the gaps | Highest. Hiring-manager prior; your own stated limits (F9) and the thin rows (F1, F3, F5) give it material | Rehearse the single most predictable objection (B1) until it is boring; build bridges only from your quoted lines; concede plainly where the limit is stated |
| Data-Driven Prober (C, 3 questions) | Goes line by line through the retention and checklist claims | Medium. The JD names retention metrics and the evidence is one reporting line (F7) | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational/Rapport (D, 3 questions) | Biography, motivation, "what are you playing" | Medium. Pack's judgement, no source: a 60-minute conversation tends to open this way, and casual questions are still scored | A 90-second arc built only from your four quoted lines; a real, specific reason for this role |
| Pressure (E, 2 questions) | Time-boxed challenge, "how much was actually you" | Low to medium. It belongs more to skip-level rounds, but the Skeptic's follow-ups can turn into it | Pause, restate, hold through two follow-ups, concede specifically |
| Values/Behavioral (G, 2 questions) | Scenario probes | Low. No values-style round was detected and no published values were read | Choose instances where the hard truth actually landed; if none comes to mind, say so |
| Peer Evaluator | Omitted | No peer round is indicated. If your day includes design or engineering peers, say so and a bank is added | |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over the live-events calendar for two titles on Monday. What do you need to know before you plan the next eight weeks?" | CASE | [generic] | Clarify first: each title's goals for the period, what is already in production, the release windows and what QA needs, what design, art, engineering and community can each take on, and how events are judged. Then objective, segmentation by title and audience, approach, metrics, risks. Think aloud and challenge one premise, for example whether eight weeks is the right horizon. The question needs no claim about your past, so the guidance makes none | The JD's headline lines are the calendar and the coordination (F1, F2), and a hiring manager tests them live. CASE because it is a problem set in the actual role |
| A2 | "Engineering tells you an event's build will land two days late, and community has already announced the date. Walk me through your next hour." | CASE | [generic] | Facts first: what is late, why, and what can be cut. Then options: hold the date with reduced scope, move the date, or keep it with a stripped version. Who must decide, who must be told and in what order, what QA needs on the checklist before anything ships, and what you write down afterwards. No claim about your past | Tests coordination under constraint (F2) and the checklist (F4). CASE because it is a live scenario, JD-tagged content |
| A3 | "An event's retention comes in 20 percent below the previous event. Diagnose it." | CASE | [generic] | Clarify the metric and the comparison first: what counts as retention here, whether the cohorts and event lengths match. Then segment, check for confounds such as overlapping events or a bad build, list hypotheses by how cheap they are to check, say what you would look at first and what you would recommend. No claim about your past | The JD names retention (F7) and the KPIs an event reports (F3). CASE because it is a diagnose-this problem, with JD content |
| A4 | "You have room for one event slot next month: a new-player event or a lapsed-player event. How do you choose?" | CASE | [generic] | Ask what each title needs most, set an objective per audience, say how you would judge success before launching, name what each option costs design, art, engineering and community, and give a decision rule. Challenge one premise, for example whether the two are really exclusive. No claim about your past | The calendar is the first line of the JD (F1); choosing between events is the plan half of "plan and run". CASE because it is a prioritisation problem |
| A5 | "An event underperformed. Walk me through the write-up you would send the leads: what is in the first paragraph?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure it: the finding first, then outcome against the goal, what shipped against what was planned, the KPIs with their definitions, what you would change, owners and dates. For your own history say only: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event-review line makes a probe on whether you wrote reviews likely. If you wrote reviews after drops, say how they were structured; if there was no such review, or it was not yours, say so plainly and stay with the monthly numbers you presented | F3 and F8 meet here: the post-event review and the written communication the JD asks for. JD because it scores a stated requirement, CASE in delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Pick the line your material supports least and hold only what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head." The pack's observation is that F1 and F3 are the thinnest rows: live events across two titles, and post-event review and KPI ownership. Answer slot: if you reviewed drops after release, or any drops ran as events, say how, in your own words; if there was no such step, or it was not yours, say so plainly and return to the calendar and the numbers. Follow-up one, how you would close it: say it as a plan, what you would ask for in week one, never as a past. Follow-up two, whether that is a risk for them: concede without arguing the gap away, with "Here is what I have done: the calendar I ran and the numbers I presented. I would want to learn how your team runs its event reviews and KPIs before I changed anything" | This objection arrives in some form because F1 and F3 are where the JD presses hardest and the material is thinnest. JD because it scores the stated requirements; Skeptic because it asks you to price your own gap |
| B2 | "You haven't worked on a game with in-app purchases. How would you get up to speed on the commercial side of an event?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | Own it in one sentence you stated yourself: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: what you would ask for first (which KPIs each event is judged on, how they are defined, a past event review to read, who owns the numbers) and who you would learn from. Then the one adjacent line your quotes carry: "I presented the monthly retention numbers to the studio head." Do not claim monetisation knowledge you do not have; if asked for a figure you do not know, say so | F9 is a limit you stated, and an interviewer who reads your background sees it. JD because the KPIs line (F3) is where it would show |
| B3 | "You have never led a team, and this role coordinates design, art, engineering and community. How do you get work out of people who don't report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Own it: "I haven't led a team." Then stay inside the quotes: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Answer slot: the JD raises coordination across four teams. If you got work from people outside your function onto the calendar, say how you did it and what you relied on, in your own words; if the owners placed their own work, or you did not coordinate them, say so plainly and stay with the calendar and the checklist. Never say you managed or led a team | F2 and F9. Skeptic because it tests whether coordination without authority is real in your story |
| B4 | "Tell me about a time you had to move something on the weekly calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | An open prompt, so choose the instance. Pick one with a named change, who you had to tell, and what moved; keep the sentence's scope: "I ran the weekly content-drop calendar for our main title for the last two years." If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the calendar itself | F1 and F6: the calendar is your strongest line, so the Skeptic goes to the instance behind it. EXP because it tests what you actually did |
| B5 | "You have four years as an associate producer, and this is a producer role across two titles. What changes in the job for you?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Start from what the quotes carry: "I have four years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's producer scope makes a probe on which parts of the producer's job were already yours likely. If you owned any (planning, the review, the KPIs), say what and how you know; if they were your lead's, say so plainly and stay with the calendar, the checklist and the numbers | F5 and F1: the title step is the gap an interviewer can see before you speak |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say the sentence at its own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you know how retention was defined and counted, say so in your own words, and name the assumption behind the numbers you would defend least; if the numbers came from someone else's report and you did not see the counting, or you do not know the weakest assumption, say so plainly and return to presenting them. Say which part of producing the numbers was yours | F7 is a single reporting line with nothing inspectable behind it, which is what a prober goes to. EXP because it tests attribution |
| C2 | "Did the retention numbers you presented ever change what went on the calendar?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | Answer slot: the JD links the post-event review to the calendar's next plan, so expect this link. If yes, name one instance, what you saw, what you changed and what part of it was yours, in your own words; if the calendar and the numbers were separate, or the calendar was set by others, say so plainly and return to "I ran the weekly content-drop calendar for our main title for the last two years" | F3 and F7: the probe is whether reporting and planning were connected. EXP, with JD content |
| C3 | "Your release checklist is still in use by QA. Why do you think it has lasted?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say the sentence: "I wrote the release checklist our QA team still uses." Answer slot: say what made it work in your own words, from what you saw; if you do not know why it has lasted, say so plainly and describe what it covers. Do not supply a reason you cannot repeat under a second question | F4 and F8: the checklist is your clearest written artifact. EXP because it asks you to explain your own work |

### D. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc from four lines and nothing else: "I have four years as an associate producer at a puzzle-game studio"; "for the last two years I ran the weekly content-drop calendar for our main title"; "I wrote the release checklist our QA team still uses"; "I presented the monthly retention numbers to the studio head." Close with your D2 answer. Add no team sizes, titles or results the four lines do not state | F1, F3, F4, F5 and F7 in one pass. EXP because it is your career as a claim; the interviewer will pull on any thread |
| D2 | "What drew you to this role?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pick one JD line you can speak to honestly, such as "Plan and run the live-events calendar for two of our mobile titles", and connect it to the one thing your material carries: "I ran the weekly content-drop calendar for our main title for the last two years." The reason is yours; the pack could not research Saltmarsh, so a company-specific reason has to come from you. If no specific reason comes to mind, say so plainly, then say which part of the JD's scope you want to do more of | F1. Motivation is scored in every register |
| D3 | "What are you playing with in live events these days?" | CO | [generic] | Name a live game and an event you have really followed, one thing you noticed in how it ran its calendar, and one thing you would do differently. If nothing comes to mind, say so plainly, then say how you keep up. Do not name a game you have not followed | A casual question on a hot JD topic. CO because it tests market awareness; generic because no company or market research ran |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Suppose another candidate has already run events across two titles. Sixty seconds: why you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Pause, restate, then hold only the three lines: "I ran the weekly content-drop calendar for our main title for the last two years", "I wrote the release checklist our QA team still uses" and "I presented the monthly retention numbers to the studio head." Hold through two follow-ups by returning to them, never by adding scale. Concede specifically: you cannot speak to their record, and if pressed on monetisation, "I haven't worked on a game with in-app purchases." Close with what you would learn first, as a plan | F1, F3, F4 and F9. JD because it scores fit for the stated role; Pressure because it tests holding a position |
| E2 | "That retention reporting. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say exactly: "I presented the monthly retention numbers to the studio head." Answer slot: say which part of producing the numbers was yours; if you pulled or built them, say how in your own words; if someone else produced them and you presented, say so plainly and stay with presenting. Hold through two follow-ups by returning to the sentence, and concede explicitly anything you do not know about how they were counted | F7. The persona stem for attribution, aimed at the one metrics line |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to give leadership news they did not want to hear." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | A selection scaffold: pick a time with a named stake, a moment you said the hard thing, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, at its own scope: "I presented the monthly retention numbers to the studio head." Do not add that the numbers were bad or that anyone reacted | Included for coverage at low weight. EXP, not VAL, because no published values were read; F7 is the nearest line |
| G2 | "Tell me about a time design and engineering wanted different things from the same update." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | A selection scaffold: pick an instance with a named disagreement, what each side wanted, how it was resolved, who decided and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I ran the weekly content-drop calendar for our main title for the last two years." | F2. The JD names the teams to be coordinated, so the open prompt takes its theme from it |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, A4, B4 |
| "coordinate design, art, engineering and community teams on each update" | A1, A2, B3, G2 |
| "own the post-event review and the KPIs it reports" | A3, A5, B1, C2 |
| "manage the release checklist with QA" | C3 |
| "3+ years producing live-service games or apps" | B5, D1, E1 |
| "experience running a content calendar" | B4, D1 |
| "comfortable with player-retention metrics" | A3, C1, C2, E2 |
| "clear written communication" | A5, C3 |
| Your stated limits (F9), not a JD line | B2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When both titles want the same weekend for a major event, how is the slot decided?" | Shows calendar thinking across two titles, the JD's first line |
| R2 | "What does a good post-event review look like here, and who reads it?" | Moves the conversation to the review you will own and shows you care about what happens after launch |
| R3 | "Which KPIs is an event judged on here, and who owns their definitions?" | An honest, curious way to learn the commercial context without claiming it |
| R4 | "How do design, art, engineering and community get their asks onto the calendar today, and where does it hurt?" | Shows you think of coordination as a process that can be fixed |
| R5 | "What would you want to be different about the live-events calendar 90 days after I join?" | Turns the hour into a shared plan and tells you what success means to him |
| R6 | "What was your route into leading live operations, and what would you do differently?" | A career question to the interviewer. It is not tied to his actual path, because none of it was researched |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team, or the design, art, engineering or community teams | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." Coordination only as B3's slot allows |
| Worked on a game with in-app purchases, or owned monetisation | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: a weekly content-drop calendar for your main title. The limit is the pack's observation: the material says one title's content drops. B1's slot stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. The limit is the pack's observation: the material says presented, not owned |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses. C3's slot asks only why it has lasted |
| Owned or built the retention analysis | Inflated form of F7 | F7's quote at its own scope: you presented the numbers. C1 and E2 ask which part was yours |

## Sources

Provided documents: the job description text and your background summary, both in your message.

Searches sent, each refused (no results returned):

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games strategy mobile games news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Every call was refused. It would have fed a values cheat sheet if a values-style round were detected, and VAL questions by published value name |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Every call was refused. It would have named the real rounds and replaced the Generic archetype behind the persona weights |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Every call was refused. It would have grounded the CO and CASE banks in current priorities; they are generic instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Every call was refused. It would have supported the interviewer read, persona adjustments and a reverse question tied to his path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access (all four calls were refused) → rows 1 to 4 above: published values, the real loop, current strategy, and Tobias's public footprint. That would add an interviewer read, a reverse question tied to his path, and CO and CASE questions grounded in Saltmarsh's strategy. A deeper pass (6 more searches, 2 more fetches, several more minutes) is available once search works
- Pasted text from Saltmarsh's careers or values page, if you can copy it → the same loop and values facts without search
- Your CV's own wording for the calendar, checklist and retention lines → my quotes come from your message, so your CV's wording replaces them
- Answers to the slots in F1, F2, F3, F4, F5 and F8, given as plain statements outside any drill → those rows move from discovery or transferability toward none with real quotes
- A writing sample, such as the release checklist or a post-drop summary → F8 moves from low toward high
- The recruiter's prep email → whether a task, presentation or case is expected, and what the 60 minutes will cover
- If the Friday interview turns out to be several sessions, send the schedule → per-session mini-packs with their own weights
- A tuesday-dossier.md from an earlier job-underwriter run → verified evidence and a named top objection in place of the one inferred here
