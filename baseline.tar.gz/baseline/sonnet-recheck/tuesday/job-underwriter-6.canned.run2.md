**Yes, go for it, on one condition you can check today: R1 (Bristol, two office days a week) and R2 (£61,500–£67,000) must both work for you. Status: `conditional_go`.** Go in knowing R7 (forecast ownership) and R9 (billing data) are the gaps you'll be asked about. If R1 or R2 doesn't work for you, this becomes `no_go` unless Quillfield changes the term.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid, two days a week in the office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R5 · adjacent: R4 (at a B2B software company), R6 (Strong SQL and spreadsheet modelling), R7 (Experience owning a forecast) · unclear: R8 (Working with finance on billing or revenue data)
- `important`: direct: R10 · absent: R9 (Own … billing data)

R7 (`medium`) is a bridge with its limit named, and R9 has no evidence behind it.

**Opportunity ledger.** The pay is stated and sits inside the market band (RR2). The open items are RR1 (posting not seen on the company's careers page), RR3 (option terms) and RR4 (no team or reporting line stated).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two days a week in the office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 both work for you; (2) RR1 clears, meaning the role is confirmed open; (3) R7 is presented as adjacent and never as forecast ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about), snippet only |
| Role terms | Revenue Operations Lead, Bristol, hybrid with two office days a week, £61,500–£67,000 plus share options | `[grounded]` the posting you linked |
| Responsibilities | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` the posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. Hiring-manager status comes from your recruiter | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only; `[grounded]` recruiter via you |
| Reporting line | The Lead may sit under the Head of Revenue Operations; the posting doesn't say, and neither does the team size | `[inferred]` from her title against the posting's silence |
| Scope read | CRM, billing data, reporting and CFO-facing forecast under one title, with no direct reports or success measures stated | `[inferred]` from the posting's list against its silence on team and metrics |
| Market calibration | Median base for a UK B2B software revenue operations lead is £64,200, interquartile range £57,800–£70,400. The posted range sits inside it. This is a pay band and not Quillfield's offer, and it is UK-wide with no Bristol cut | `[generic]` search result "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example), n=438, snippet only |
| Unknowns | Which CRM Quillfield runs, option terms, team size, who owns the forecast with the CFO today, first-year outcomes | `[grounded]` posting silent on each |
| Contradictions | Posting content and the about page agree with your description. The company's own `/careers` URL I tried returned no page (see RR1) | `[grounded]` fetch result |

## Evidence map

Your background is in your message, so it counts as self-report: `medium` is the ceiling until you show an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether two office days work. Confidence grades your statement of the constraint, and there isn't one yet | `[grounded]` posting; nothing from you on location | G1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor isn't given. The range is inside the market band (RR2) | `[grounded]` posting; `[generic]` Ledgerline band | G1 |
| R3 | 4+ years in revenue ops, sales ops or a similar analytics role | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team, by your account. No CV or artifact yet | `[grounded]` your message | CV would let me check dates and titles |
| R4 | …at a B2B software company | must_have | adjacent | medium | discovery | Your employer is a B2B payments company. Whether it sold a software product is untested, so describe it as it actually is | `[grounded]` your message and posting | Confirm in your own words what the company sold |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The posting accepts either CRM, and which one Quillfield runs isn't stated | `[grounded]` your message and posting | Certification credential link would raise to high |
| R6 | Strong SQL and spreadsheet modelling | must_have | adjacent | low | discovery | You gave how often you use them (SQL weekly, Excel daily), not their depth. Modelling, as opposed to reporting, isn't evidenced | `[grounded]` your message | A sanitized query or workbook would show depth |
| R7 | Experience owning a forecast; running the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the company forecast. The bridge is the pipeline input. The limit is that the number and the CFO relationship were finance's | `[grounded]` your message | G3 |
| R8 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | The posting says billing or revenue data. You've never worked on billing data, but your renewal dashboards might draw on finance-owned revenue figures | `[grounded]` your statement on billing; `[inferred]` renewal dashboards may involve revenue data | G2 |
| R9 | Owning the company's billing data | important | absent | none | capability | No billing-data experience, in your words. The CRM half of "own our CRM and billing data" is R5 | `[grounded]` your message | Carried as a material risk; closure path in G4 |
| R10 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt pipeline and renewal dashboards. Finance as an audience isn't confirmed | `[grounded]` your message | A sanitized dashboard screenshot would raise to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | Neither term has been checked against your own limits | A failed gate sets the status to `no_go` however strong the fit | Not applicable: these are terms, not experience | None needed; your answer settles it | `[grounded]` constraints not given |
| G2 | Working with finance on revenue data (R8, must_have) | discovery | You've never touched billing data, but the posting accepts revenue data and your renewal work may qualify | Could move R8 from `unclear` to `adjacent` | Agreeing renewal or ARR figures with finance; reconciling bookings to closed deals; supplying finance with numbers for their forecast | A sanitized renewal dashboard, an ARR or bookings definition note, a reconciliation sheet | `[grounded]` your message; `[inferred]` that renewal work may involve finance data |
| G3 | Forecast ownership (R7, must_have) | transferability | You run the pipeline review, and finance owned the forecast | The posting's headline responsibility is a quarterly forecast with the CFO | Producing the commit or best-case view; tracking forecast against actuals; numbers you supplied that finance used | A sanitized pipeline review deck or a forecast-versus-actual sheet | `[grounded]` your message |
| G4 | Billing data (R9, important) | capability | No billing-data experience | The posting makes it part of the role | No qualifying experience to recall. A closure path instead: a short self-built exercise on sample invoice data, presented as a learning exercise and never as experience | A small workbook or query on sample data | `[grounded]` your message; `[inferred]` closure path derived from the gap |
| G5 | SQL and modelling depth (R6, must_have) | discovery | Frequency of use, not depth | "Strong" is the posting's word | A query joining CRM and renewal data; a scenario or cohort model in Excel | A sanitized query or workbook | `[grounded]` your message |
| G6 | B2B software setting (R4, must_have) | discovery | Employer described as a B2B payments company | The posting names the setting | Whether your company's product was a software platform | A product page or how your CV already describes it | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not seen on the company's own careers page | unknown | — | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | The role may be listed elsewhere on the site, or only on the job board. One guessed URL returning no page doesn't show the role is closed | `[grounded]` fetch of quillfield.co.uk/careers returned no page | Can you confirm this role is open and where Quillfield lists it? | unresolved |
| RR2 | Stated range sits inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | The range is disclosed and inside the interquartile range for the title | `[grounded]` posting; `[generic]` UK-wide Ledgerline band, not Bristol-specific, not Quillfield's offer | Is the range fixed for this role? | noted |
| RR3 | Share option terms unstated | unknown | — | "plus share options" | Grant size, vesting and strike price aren't given, so their value can't be judged. Options at a Series A company are usually hard to cash out early | `[grounded]` posting silent; `[generic]` pattern for companies at this stage | What is the option grant size, vesting schedule and strike price? | unresolved |
| RR4 | Wide mandate, team and reporting line unstated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast with the CFO" | Several jobs sit under a "Lead" title with no direct reports mentioned, and the split with the Head of Revenue Operations is unclear | `[inferred]` from the posting's list against its silence on team and metrics | Does this role have direct reports, and who owns the CFO forecast today? | unresolved |

## Application plan

All rows are proposals, pending your approval. Positioning below uses only things you told me.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle R1 and R2 yourself before investing further | see G1 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Ask your recruiter to confirm the role is open and where it is listed | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | Lead with the pipeline and renewal dashboard rebuild and the monthly pipeline review you run with your sales director | see R10, R7 | `[grounded]` R10, R7 rows | pending your approval |
| A4 | Say up front that finance owned the forecast at your company and that you haven't worked on billing data, with the pipeline review as the adjacent work | see R7, R9; naming the gaps first keeps the interview on what you can show | `[grounded]` R7, R9 rows | pending your approval |
| A5 | Ask RR1–RR4's verification questions verbatim in the process | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A6 | Optionally build the small sample-data exercise in G4 | see R9 | `[inferred]` from G4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software Bristol careers" and got "About Quillfield" (quillfield.co.uk/about), a snippet only. Fetched quillfield.co.uk/careers, which returned no page. The employer is established and matches your description. It moved the Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol" and got "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example), a snippet only. It moved Market calibration, R2 and RR2. It returned a pay band and no scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and got "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), a snippet only. It moved the Hiring manager and Reporting line rows. Only her role and career path were used |

I can write all of this up as a reusable `tuesday-dossier.md` if you want it kept.

**Upgrade menu**

- Your CV → R3 and R10 get checked against dates and wording, and any buried evidence shows up.
- A Salesforce credential link → R5 to `high`.
- A sanitized pipeline or renewal dashboard screenshot → R10 toward `high`, and R7 and R8 sharpen.
- A SQL query or Excel model you can share → R6.
- The recruiter's confirmation of the listing → RR1 closes.
- Option terms → RR3 closes.
- A deeper research pass on Quillfield (funding follow-on, leadership changes, hiring pattern, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Are both Bristol with two office days a week and the £61,500–£67,000 range workable for you?

G2 — Have you worked with finance on revenue figures, for example agreeing renewal or ARR numbers, reconciling bookings, or feeding your pipeline numbers into their forecast? What did you own, and what was the outcome?

G3 — In your monthly pipeline review, which numbers do you personally produce or call (commit, best case, coverage), and does anyone track how they compare with what closes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.