I've built the full prep pack. The save to your working folder was declined, so I'm trying the session scratchpad instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-canned-ecb4651c/fbe582c3-509b-4767-bab6-071de4e8f52e/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. My write to your working folder was declined, so it's in the session scratchpad instead.

I built it for the three rounds on 21 October as the recruiter described them. It has 28 questions with answer guidance, a shared fit snapshot, reverse questions for each round and a values cheat sheet. There's no interviewer read because the interviewers aren't assigned yet.

- **Biggest gap:** your note says you've never worked in a contact centre, and the JD covers branches and the contact centre. E1 (Round 2) is the question to rehearse hardest. K2 is the same question asked in a friendlier way by the panel.
- **Other gaps:** presenting above regional level (E3) and working with digital teams (G2), where the pack has nothing from you to build on.
- **Open slots:** where your material is silent, such as what your spreadsheet counted or whether it was Excel, the guidance leaves a slot for you to fill truthfully rather than guessing.
- **Dates:** your note puts the interviews on 21 October and the values copy on 12 October, but my session date is 5 November. I followed your dates and left out a prep-time schedule.
- **Research:** I ran no searches, because your JD, values text, recruiter email and strategy summary already cover everything. The strategy section rests on the four facts you relayed, not the brief itself.

Say the word and I'll play the sceptic on E1, the contact-centre question, as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 21 October (per the recruiter's email), prepared in loop mode.
**Interviewers:** Round 1 the recruiter; Round 2 the Head of Member Services, who would be your manager; Round 3 a panel of two branch managers. Names are not yet assigned, so there is no interviewer read.
**Built on:** your message (background, JD, values text, recruiter's email) and the 2026 strategy brief as you relayed it. No CV and no dossier were supplied.

## How to use this pack

- **Personas** are how a question arrives (friendly, sceptical, a live case). **Types** are what is being scored.
- Type key: **VAL** behavioural or values alignment against the four published values. **EXP** whether your experience claims survive scrutiny. **JD** a stated responsibility or requirement of the role. **CO** knowledge of Ashgrove and its strategy. **CASE** a live problem set in the role.
- Guidance is scaffolding, not a script. Every claim about your past rests on a sentence you wrote, quoted in the Provenance cell. An **answer slot** marks where the pack does not know and you do: answer it in your own words, and if the thing did not happen or was not yours, say so plainly.
- **Highest-ROI prep: E1** (Round 2, the contact-centre question). It is built on the one gap you stated outright, and the JD splits the role across branches and the contact centre, so it will arrive in some form in every round. K2 is the same objection in a friendlier voice.
- Question IDs run by persona: A to C Round 1, D to G Round 2, H to K Round 3. Fit-snapshot rows are F1 to F9.

## The fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches half) | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the log, not the process end to end, and nothing inspected sits behind it. The words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's opening responsibility makes a probe on what sat around the log likely. If any step before or after the logging was yours to run, say which and how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact centre half) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sheet is monthly and about complaints; your material does not show what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet showed. If it counted either, say how, in your own words; if it counted other things, or not those, say so plainly and stay with the sheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, and the words stay there: "I trained new tellers on our escalation script." The second quote puts you in the supervisor's seat, which is a fact about your role and no evidence of coaching anyone in it. Answer slot: the JD's coaching line makes a probe on how the training ran likely. Say who it was for and what the script covered, in your own words, and if any part was not yours, say so plainly. For supervisors, give a plan: what you would ask one first |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on what the years consisted of. Lead with it in the quote's own terms, six years in retail banking and the last three as a branch supervisor, and let them map it to customer operations rather than relabelling it yourself |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The quote says formal; your material does not say what rules governed the log. Words: "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect a probe on what governed the log. If you worked to a regulator's rules, name them and say what they required of you; if the log followed internal policy only, or the rules were someone else's to apply, say so plainly and stay with the log |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a short senior slot, said as a plan and never as a past. The quote sets a floor on what you have not done and says nothing about what you have done at or below regional level, so the pack does not fill that in (E3 holds the slot) |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names Excel, so expect a probe on the tool. If it was built in Excel, say so and describe what it did in your own words; if it was another tool, say which, plainly |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital teams. Answer slot: the JD's digital line and the brief's 40% digital target make a probe likely. If you have worked with a digital or product team, say what the work was and what was yours; if you have not, say so plainly and describe, as a plan, what you would want to know about where members get stuck |

## Grounding brief

Vocabulary to sound current. Facts come from the 2026 strategy brief the recruiter sent (June 2026), as you relayed it, and from the JD.

| Fact | Source | Provenance | How it can come up |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | strategy brief, as relayed in your message | [grounded] | Say "member service", the brief's own term; the target is not stated as a complaints target, so do not call it one. Feeds G1 and G2 |
| Consolidate eight branches into five hubs over 2027 | strategy brief, as relayed in your message | [grounded] | The likeliest topic for branch-manager panellists; handle as a question, never a criticism (D4, H3, RQ7) |
| Launch a small-business lending product in Q1 2027 | strategy brief, as relayed in your message | [grounded] | Not obviously in this role's scope; mention only if asked |
| Main competitive pressure is app-only banks | strategy brief, as relayed in your message | [grounded] | Frames why self-service and Plain Words matter together (A4, G1) |
| Member-owned, about 900 staff | JD | [grounded] | Use in A2 as the reason Members First, Always is more than a slogan here |

## Round 1: Recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; motivation and journey questions | High. The relationship prior for a recruiter screen, and the recruiter's email describes a plain 30-minute conversation. The risk is treating it as unscored | Pre-script the 90-second arc (A1) from the lines quoted in this pack; treat casual questions about JD topics as scored; never answer "I think you've covered everything" in the reverse-question slot |
| Skeptic | Quick knockout-style checks on requirements the material leaves open | Medium. A recruiter must settle F2, F5 and F6 before passing you on, in a friendly register | Rehearse the plain acknowledgment on F2 until it is boring, and keep it under thirty seconds |
| Values/Behavioral | One or two motivation-through-values questions | Low. The recruiter's email puts the values scoring in the panel round | Keep answers short; the full values work lives in Round 3 |

### Question bank

**A. Conversational (high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey in banking so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with three beats, each a clause you have already written: the six years in retail banking, the last three as a branch supervisor, and the complaints work, in your own words from the log and the spreadsheet lines. The order between the early years and the supervisor role is not in your material, so tell it as it happened and add nothing. Close with one sentence of your own on why this role | F5 and F1 are the spine of the arc, and an opener like this is scored for economy. EXP because it tests that the story holds together |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | The JD calls Ashgrove member-owned and the first published value is Members First, Always. Pick one value or one strategy fact you can speak to honestly and say why it matters to you; the reason is yours and is not in the material. Answer slot: if no value stands out yet, say so plainly and name what you want to find out. Do not recite the values page | Tests homework and motivation together. CO because it asks whether you know who they are; no fit row speaks to it |
| A3 | "Why this role rather than staying in branch banking?" | JD | [grounded] "the last 3 as a branch supervisor" | Your reason is not in the material, so give it in your own words and aim it at what you are moving toward, the member complaints process in the JD's opening responsibility, rather than at what you are leaving | Recruiters probe motivation consistency before passing a candidate on. JD because the answer should point at the stated role; F4 and F1 are the adjacent evidence |
| A4 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | From the 2026 strategy brief as you relayed it: 40% of member service digital by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, app-only banks as the main pressure. Pick two and say what you would want to understand about how they touch complaints. Ask it as a question; do not assert how complaints will change | The brief is the differentiator most candidates have not read. CO because it tests altitude; the grounding brief holds the facts |

**B. Skeptic (medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The short form of E1. Say "I haven't worked in a contact centre." Then what your material does carry: "I handled the branch's formal complaints log". Then one plan sentence: what you would learn first about the phone side and from whom. Do not apologise and do not add exposure you have not stated | F2 is the knockout-style check a recruiter has to settle. JD because it scores the opening responsibility; E1 is the deep rehearsal |
| B2 | "The role asks for 4+ years in financial-services customer operations. Where does yours sit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Say it in the quote's terms: six years in retail banking, the last three as a branch supervisor, and let them map it. If asked what the years held, answer from the log, the escalation-script training and the spreadsheet, each at the scope its line gives | F5 is a clean row, so this should be a short exchange; the probe is on what the years consisted of. JD because it scores the stated years |
| B3 | "The role handles regulated complaints. What did formal complaints at your branch involve?" | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F6: the log, and the word formal, are the beats the quote gives. Answer slot: if you worked to a regulator's rules, name them and what they required of you, in your own words; if the log followed internal policy only, or the rules were someone else's to apply, say so plainly and describe how you handled the log | F6 is the requirement the quote touches without showing, so this is where a recruiter checks it. JD because it scores the stated regulated-complaints requirement |

**C. Values/Behavioral (low)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our first value is Members First, Always: we decide from the member's side of the counter. What does that mean to you in practice?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one decision from your own work that has a named choice, what the member would otherwise have faced, and who you had to persuade. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", or how you would decide | Values coverage: the quote carries a log, not a decision made from the member's side, so this is the scaffold case (F1). VAL because it is scored against a published value |
| C2 | "Plain Words says if a member needs it explained twice, we wrote it wrong. When have you seen something explained badly to a member?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a time the wording of a letter, a script or a phone explanation confused someone; it needs the wording, what the member did next, and what changed. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I trained new tellers on our escalation script", and say that the line is about training on a script, not writing or changing one | Values coverage for Plain Words; F4 is the nearest row and says training, not rewriting. VAL because it scores a published value |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "How is the 20-minute escalation case set up, and is there anything I should read beforehand?" | A fact you cannot research, and it shapes Round 3. It reads as preparation |
| RQ2 | "How is complaint volume split today between the branches and the contact centre?" | The JD splits the role across both, so the answer tells you which half your first months lean on, and it shows you read the role |
| RQ3 | "Who will be on the Round 3 panel, so I can prepare for their branches?" | A recruiter can often supply names in one email, and names unlock the interviewer read the upgrade menu describes |

## Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes tied to the JD and the four values; STAR-shaped stories | High. The recruiter's email calls this round mostly behavioural | "We" for context, "I" for contribution; where the quotes carry no story, say so plainly and use the nearest thing |
| Skeptic | Quiet, persistent probing of the gaps: contact centre, senior presenting, what the spreadsheet counted | High. A hiring manager is derisking gaps, and F2 and F7 are stated gaps | Rehearse the one predictable objection (E1) until it is boring; calibrated candour over bluffing a competency they personally own |
| Case/Strategist | A live problem on the role's roadmap, most likely the digital shift | Medium. The hiring-manager prior, tempered by "mostly behavioural" | Clarify, then objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober | Reporting questions arriving as EXP | Low. Folded into E2 rather than given its own bank | Know what you can and cannot say about what the sheet counted, and say plainly when you do not know |

### Question bank

**D. Values/Behavioral (high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to coach someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4, at the quote's scope: the people were new tellers and the subject was the escalation script; tell it in your own words. Answer slot: the JD's coaching line makes a probe on what happened beyond the script likely. If you walked anyone through a live escalation, say what it was and what part was yours; if the training was the script only, or live cases were not yours, say so plainly and describe the training as it ran. Do not stretch tellers into supervisors | F4 is the nearest evidence for the coaching responsibility and the likeliest place to be probed. JD because it scores the stated coaching line |
| D2 | "Tell me about a time a problem you were handling needed someone outside your branch." | JD | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a time handling something at your branch meant involving people outside it; it needs a named stake, who you involved, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would involve other teams | F1 covers one branch's log, and the JD's scope is across branches and the contact centre. JD because it scores the opening responsibility |
| D3 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: it needs the truth, the person, the moment you did not soften it, and a relationship intact afterwards. If none comes to mind, say so plainly, then give the nearest thing your material carries, the spreadsheet line, at its scope: you built it and the regional manager uses it, which does not say it carried bad news. Do not supply an ending the material lacks | A managerial behavioural staple that also probes F7's seniority gap. VAL because it scores whether the hard truth landed |
| D4 | "Neighbours, Not Numbers: every branch is part of its town. Ashgrove plans to move from eight branches to five hubs over 2027. How would you keep complaints handling neighbourly through that?" | VAL | [grounded] | No claim about your past. Clarify first what changes for members whose branch becomes part of a hub, then the objective, who members will meet, where a complaint now lands, what you would track (volumes and resolution times are the JD's own measures), and the risks. Challenge one premise respectfully: you have read the plan, not the detail behind it | Values coverage for Neighbours, Not Numbers, set against the brief's consolidation. VAL because it is scored against the published value; CO in delivery |

**E. Skeptic (high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The role owns complaints across branches and the contact centre. You've never worked in a contact centre. How would you own that half?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI prep in the pack. Open with the plain acknowledgment: "I haven't worked in a contact centre." Name the limit before they press: what your material shows is the branch side, "I handled the branch's formal complaints log", and say no more than that about what you bring. Then the plan, in your own words: who you would sit with first and what you would listen for before changing anything. Follow-up 1, they say branch complaints are not contact-centre complaints: concede what is true, that you do not know how the phone side differs, and say finding out is your first step. Follow-up 2, they ask why they should back you over someone who has run a centre: hold on what is on the page, and concede that someone with that background starts ahead on that half. Never claim managing agents or call handling. Return to the plan each time; add no experience | F2 is the one gap you stated outright, and the JD's opening responsibility covers the contact centre, so this arrives in some form in every round. JD because it scores that responsibility. It gets the most follow-up levels, the exact concession wording, and the limit named before it is asked for |
| E2 | "Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F8, at the quote's scope: you built it, it is monthly, the regional manager uses it. Answer slot: the JD names volumes and resolution times and Excel, so expect probes on what it counted, how, and the tool. Say what it counted and how, in your own words, and name the weakest assumption in it before they do; if it counted other things, or you do not know how a figure was derived, say so plainly and stay with what it did track. If it was built in Excel, say so; if another tool, say which | F3 and F8 are the rows this question tests, and the spreadsheet is your most concrete artifact. JD because it scores the reporting and Excel requirements; EXP in delivery |
| E3 | "The role asks for confidence presenting to senior leaders. When have you presented at that level?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Say it plainly: "I've never presented to anyone above regional level." Do not pad. Then the plan, in your words: for a short senior slot, the decision you want, the evidence behind it, and what you need from them. Answer slot: if you have presented at regional level or below, say to whom and what; if you have not presented the sheet or anything else, say so plainly. The spreadsheet line says the regional manager uses it, not that you presented it | F7 is a stated gap, and a hiring manager owns this one personally. JD because it scores the senior-presenting requirement |

**G. Case/Strategist (medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Ashgrove wants 40% of member service on digital channels by 2028. Which complaints would you keep human, and why?" | CASE | [grounded] | No claim about your past. Clarify first what counts as a complaint rather than a service request, what members use today, and what rules apply to how a complaint can be taken. Then objective, segments (simple, sensitive, formal), approach, metrics (resolution time, repeat contact) and risks (trust, app-only banks). Challenge one premise respectfully: the 40% is about member service, not complaints | The one strategy-grounded case in the pack; F9's requirement meets the brief's headline target. CASE because it is a live problem set in the role |
| G2 | "Tell me about a time you worked with a digital or product team." | JD | [generic] | Your material carries nothing for this one (F9), so this is the scaffold case. Answer slot: if you have worked with a digital or product team, say what the work was and what part was yours; if you have not, say so plainly, then give a plan: the questions you would ask about where members get stuck, and how you would bring complaint data to a digital team | F9 is a discovery gap and the JD names the requirement, so the question will come. JD because it scores the stated digital line; generic because it is a pattern, not a claim about Ashgrove |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| RQ4 | "What would you want the monthly complaints report to change in the first six months?" | Reporting is a core JD line, and the answer tells you what success looks like to the person you would report to |
| RQ5 | "Where would you want me to start presenting to senior leaders, and what support would I have?" | It turns F7 into a development request rather than a defence, and you need the answer before accepting |
| RQ6 | "How does the digital team's work on self-service connect with complaints today?" | It tests the JD's digital line against the brief's 40% target and tells you how much of the role is digital |

## Round 3: Panel of two branch managers (60 minutes, includes a 20-minute escalation case; scored against the four values)

### Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | One question per value, scored against its published wording | High. The recruiter's email says the panel is the values round | Map a story to each value where a quoted line carries one, and use the honest branch where none does |
| Case/Strategist | The 20-minute complaint escalation case | High. Named in the recruiter's email; the format is not yet known | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam-splitting between branches and your function; credit; what you would need from them | Medium. Branch managers are the people your role coaches and works across, and the blend of two members' priors leans collegial | Reciprocity framing; propose seam principles, not a map you do not have |
| Skeptic | The contact-centre objection returning in collegial packaging | Medium. Folded into K2 rather than given its own bank | The same plain acknowledgment as E1; hold, then concede |
| Pressure | A push-back inside the case | Low. Folded into J2 | Pause, restate, hold a position through two follow-ups before conceding anything real |

### Question bank

**H. Values/Behavioral (high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Members First, Always: we decide from the member's side of the counter. Tell me about a time you decided something from the member's side." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a decision with a named choice, what the member would otherwise have faced, and who you had to persuade. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would decide | Values coverage for Members First, Always. F1's quote carries a log, not a decision, so this is the scaffold case. VAL because it scores the published value |
| H2 | "Plain Words: if a member needs it explained twice, we wrote it wrong. Tell me about a time you made something clearer for a member." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a time you made wording, a script or an explanation clearer; it needs the before, the change and what the member did next. If none comes to mind, say so plainly, then give the nearest thing your material carries, "I trained new tellers on our escalation script", which is training on a script, not rewriting one | Values coverage for Plain Words, with F4 as the nearest row. VAL because it scores the published value |
| H3 | "Neighbours, Not Numbers: every branch is part of its town. Tell me about a time local need and a number pulled in different directions." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a time at your branch when a local need and a target pulled apart; it needs a named local detail and the decision you made. If none comes to mind, say so plainly, then give the nearest thing your material carries, the supervisor role in that line, which names a seat and not a town. With branch managers on the panel, do not criticise the hub plan; ask about it | Values coverage for Neighbours, Not Numbers, in front of the people the consolidation touches most. F5 is the nearest row. VAL because it scores the published value |
| H4 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. Tell me about a time you stayed with a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1 at the quote's scope: you handled the log. Answer slot: whether any complaint you held was seen through to a solution is not in your material. If one was, say what it was, what you did and how it ended, in your own words; if none comes to mind that you saw through, say so plainly and describe what handling the log involved | Values coverage for Own the Fix, and it overlaps the JD's end-to-end ownership (F1). VAL because it scores the published value |

**J. Case/Strategist (high)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member complained twice at their branch and once to the contact centre about the same issue, and now wants to escalate formally. Walk us through what you would do." | CASE | [generic] | No claim about your past. Clarify what the issue is, what the member was told each time and what they have lost; objective (fix it and keep the member); segment what is owed to the member from what is owed to the process; one named owner from here, a reply in plain words, and a plan for updates; metrics (resolution time, repeat contact); risks (the hand-off between branch and centre, rules whose clocks you would ask about). Say aloud which value each step serves | The recruiter's email announces a 20-minute escalation case, and this is a pattern for it, not the real case. CASE because it is a live problem in the role; generic because the actual scenario is unknown |
| J2 | "Midway through, a branch manager says the supervisor followed the script and the member is being unreasonable. What do you do?" | CASE | [generic] | No claim about your past. Challenge the premise respectfully: following the script and the member's outcome are separate questions. Ask what the log shows, keep hold of the member's side without dismissing the supervisor, and offer a way to look at both. If pushed twice, hold the distinction and concede what is true: the supervisor may have followed the script and the script may still have failed the member | A branch manager on the panel will push from the branch's side; this is the Pressure persona inside the case. CASE because it extends the live problem |
| J3 | "How would you coach a supervisor who escalates too late?" | CASE | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | A hypothetical, so the answer is a plan. Start by asking the supervisor to walk you through their last escalation and listen first. You may say you have sat in a branch supervisor's seat, which your material says, and that your escalation-script training was for new tellers. Do not present either as coaching supervisors | F4's coaching requirement, asked as a plan rather than a record. CASE because it is a hypothetical in the role |

**K. Peer Evaluator (medium)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our branches sit alongside your function. Where is the seam on an escalation, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map you do not have: who decides what, who speaks to the member, who is told when. On disagreement, say you would agree the principle with the branch before the first escalation, not during it. No claim about your past | A peer-evaluator staple, and the opening responsibility spans branches and the contact centre (F1). JD because it scores that scope; generic because it is a pattern |
| K2 | "Many members' first contact will be the contact centre. You haven't worked in one, so what do you need from branch managers to run that side well?" | JD | [grounded] "Never worked in a contact centre"; "the last 3 as a branch supervisor" | The E1 objection in a collegial voice. Say "I haven't worked in a contact centre." Use reciprocity: what you would ask of them is where the phone hand-offs hurt branches, and what you offer is that you have sat in a branch supervisor's seat. No claim about running a centre | F2 returns here because the panel owns the branch side of the seam. JD because it scores the opening responsibility |
| K3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | "We" for context, "I" for contribution. The line says you built the sheet; answer slot: if others contributed to it, say who and what; if it was yours alone, say so plainly. Then say how you would credit others on shared work, as a plan | A Peer Evaluator stem about credit; F3 and F8 are where attribution would be tested. VAL because it scores collaborative behaviour |

### Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side, not the institution's | Scaffold ending in the honest branch (C1, H1). Nearest line, F1: "I handled the branch's formal complaints log" |
| Plain Words | Explain it once; if a member needs it twice the wording failed | Scaffold ending in the honest branch (C2, H2). Nearest line, F4: "trained new tellers on our escalation script" |
| Neighbours, Not Numbers | A branch belongs to its town; local need can outrank a count | Scaffold ending in the honest branch (D4, H3). Nearest line, F5: "6 years in retail banking, the last 3 as a branch supervisor" |
| Own the Fix | The person who finds a problem keeps it until it is solved | Mapped, with an answer slot (H4). F1: "I handled the branch's formal complaints log"; whether a complaint was seen through is yours to say, or to say it was not |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| RQ7 | "With eight branches becoming five hubs through 2027, where do you expect complaints to show it first?" | It uses the brief's consolidation and invites their branch-level knowledge, which speaks to Neighbours, Not Numbers |
| RQ8 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | The reciprocity question for the people the role works across |
| RQ9 | "When a branch manager and the complaints lead disagree on an escalation, how has that been settled so far?" | It reverses the seam question and tells you where decision rights sit today |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, D2, E1, K1, K2 | E1 is the deepest rehearsal |
| Report monthly on complaint volumes and resolution times | E2 | Also D4 and J1 as metrics |
| Coach branch supervisors on escalations | D1 | Also J3 |
| Work with digital teams on self-service journeys | G2 | Also G1 |
| 4+ years in financial-services customer operations | B2 | Also A1 |
| Experience handling regulated complaints | B3 | |
| Confident presenting to senior leaders | E3 | RQ5 turns it into a request |
| Comfortable with Excel reporting | E2 | The tool is an answer slot in E2 |

## Prohibited claims

Not coached by this pack. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not the process across branches |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and a script. The limit is the pack's observation: your material has tellers, not supervisors |

## Sources

**Provided documents:** your message (background, JD, the values text copied on 12 October 2026 from the Ashgrove values page, the recruiter's email, the 2026 strategy brief's four stated priorities). The strategy brief itself was relayed, not pasted. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text is in hand and fixes the values cheat sheet and the VAL questions; fetching the page it came from would have added nothing |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email fixes the loop: three rounds, who runs each, the case, and the values-scoring panel; persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The brief's four stated priorities are in hand and fix the CO and CASE questions and the grounding brief |
| 4. Interviewer name and Ashgrove | n/a | No names are assigned yet, so no query could be formed; the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your CV, pasted or attached → your own lines replace the message-sourced evidence cells, and the discovery rows F3, F6 and F8 may be re-graded
- Your answers to the slots: what rules governed the formal complaints log (F6), what the spreadsheet counted and whether it was Excel (F3, F8), whether you have ever advised another supervisor on an escalation (F4), whether you have worked with any digital team (F9) → story-mapped answers replace the scaffolds, and the guidance in B3, D1, E2, G2 and J3 tightens
- Real stories for the four values → the cheat sheet moves from scaffolds to mapped stories (C1, C2, H1, H2, H3)
- The panel's and the Head of Member Services' names and titles, once assigned → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The strategy brief itself, pasted or attached → exact wording for the grounding brief, which now rests on four facts you relayed
- Recruiter detail on the 20-minute case: format, whether it is a real pattern, any pre-reading → the case bank retuned to it; usually one email
- Ashgrove's regulator and the complaint-handling rules it applies → F6's slot and B3 can name the rules rather than asking you to
- How much prep time you have before 21 October → a prioritised schedule over this pack
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → recent organisational context, role-family loop reports and, once names exist, interviewers' public footprint
- A tuesday-dossier.md from an earlier assessment of this role, if you have one → confirmed evidence and any claims already ruled out are carried in without re-asking
