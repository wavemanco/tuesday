Web search was refused, so I'm building the pack from your message and the recruiter's email only. I'm writing the file now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-5-denied-48e45033/6e4a5de4-66d9-44e0-9989-b2d4f13b74cf/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It holds 20 questions across six personas, and the biggest piece is a build section for the 15-minute POV.

- **Assumption:** I built it for one 60-minute panel. Deepa is weighted Strategist plus Skeptic. Ross is weighted Prober plus Pressure, based only on "Ross will push on commercials". If you know more about how Ross interviews, the weights should change.
- **No outside research:** web search was refused, so all six searches came back empty. Nothing about Kelverton's values, strategy or the two interviewers is in the pack, and the company-knowledge questions are generic.
- **No job description or report:** the requirements come from the recruiter's own words, and I never received the market report. The POV section therefore gives you three thesis options, each with a required concession, plus the structure and timing. It has you pick one report item to cite and one to depart from. It does not recite the report.
- **Highest-value prep:** C1 is the question "you've never sold into rail, why should we believe you?" It, C2 and D2 are where I'd spend the most rehearsal time. The pack has you concede plainly first. After that it uses only what you told me: five years of bus and light rail network planning, and the ISV channel going from 6 partners to 40. The £4M stays "influenced" throughout.
- **Time plan:** the four hours are split into five blocks, starting with building and rehearsing the POV aloud.

Say the word and I'll play Ross or Deepa on C1, the question I'd most want you to practice live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the job description text? It would replace two role-family rows with real requirements, and show whether the role has any gate such as location or travel.
2. Can you give me the report's headline findings or section headings? That would let me make the POV theses and question A4 specific to it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday, 60 minutes, panel. **Panel (per the recruiter's email):** Deepa, VP Partnerships, your future manager; Ross, Commercial Director. **Shape (per the recruiter's email):** first 15 minutes, a short POV from you, no slides; the rest is Q&A, and Ross will push on commercials.

## How to use this pack

- Personas are how a question arrives. Types are what it scores. Every question carries both, plus the sentence of yours its guidance rests on.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", the pack does not know your answer; it is an instruction for the interview, and either honest branch is a good answer.
- Type key:

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values (no values round is expected in this loop, so no VAL questions) |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny; what was actually you |
| JD | Role-driven | Whether you can do the job as the recruiter described it, gaps included |
| CO | Company and strategy knowledge | Homework depth, and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Prep triage (about 4 hours, spread over the weekend)

| Order | Time | Do this | Sections and questions |
|---|---|---|---|
| 1 | 60 min | Build the POV spine: pick one thesis, one consensus item from the report, one divergence, one anti-pick, and the operator close | Graded deliverable; A1, A4, D3 |
| 2 | 60 min | Say the POV aloud twice, timed, from four signposts rather than a script. Aim for about 12 minutes so there is room for interruptions. Record one run and cut what drags | Graded deliverable; A1 |
| 3 | 45 min | Rehearse the objection until it is boring: say each answer aloud, hold through two follow-ups, concede exactly what is true | C1, C2, D2 |
| 4 | 45 min | Defend the £4M and the 6-to-40, including the assumption you would defend least | B1, B2, D1 |
| 5 | 30 min | Commercial framing, your 90-second arc, and pick three reverse questions | B3, A5, F1, Reverse questions |

Everything else in this pack is insurance.

## Fit snapshot

No job description was supplied and web search was refused, so the requirements below are the recruiter's own words, quoted, plus two role-family rows written as plain prose and labeled `[generic]`. No requirement here is a gate: nothing supplied states a term such as location, travel or pay. The JD would show whether there is one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | The quote is a payments ISV channel, not operator partnerships, and the words stay at that scope: "For four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the POV brief makes a probe on what carries across likely. If something about running that channel carries to operator partnerships, say what, in your own words; if nothing specific does, or the carry-over is not yours to claim, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Bus and light rail network planning is adjacent to train operating companies, and the words stay there: "For five years I was in transport consulting, in bus and light rail network planning." Answer slot: "the operator world from the other side" is your phrase and will be probed. If your planning work gave you a view of how operators work, say what, in your own words; if it did not, or the phrase claims more than the work showed, say so plainly and stay with the bus and light rail planning |
| F3 | "Ross will push on commercials." — recruiter email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | The quote carries a figure of influenced revenue, and the words stay in its terms: "roughly £4M of influenced revenue", never generated or closed. Defend-the-number slots, in your own words: how the £4M was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and stay with "influenced" |
| F4 | Carrying a revenue number directly: a role-family pattern for senior partnerships roles, not stated by this employer `[generic]` | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota; what I have is influenced revenue." Then how you would work with a commercial number here, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Prior selling into rail operators: a role-family pattern, not stated by this employer `[generic]` | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then what you would do in the first weeks to learn it, said as a plan and never as a past |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. The brief, in the recruiter's words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**What you can build on from your own material**

| Row | Sentence from that row's evidence cell | Use |
|---|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | One illustration, told at its scope and labeled as an analogy from payments, not as evidence about rail |
| F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | The operator-facing close, told at its scope: bus and light rail planning |

**The report.** It was circulated by their own strategy team, so both interviewers have read it and so has every prepared candidate. The pack has not seen it. Recite none of it. Bring one item from it to show you read it, then depart from it with reasons, then say what you would decline.

**Three defensible theses.** Pick one after matching it to the report; do not present all three. Each is a generic option, not a claim about Kelverton.

| Thesis | What it argues | Mandatory concession | What it means for the operators themselves | Grounding | Provenance |
|---|---|---|---|---|---|
| T1 Fewer, deeper | Put effort into a small number of operator relationships and make them joint, with shared goals and a shared review, instead of widening | Your own material shows partner count growing, "took it from 6 partners to 40", not deepening a few; concentration also leaves you exposed if one relationship goes | An operator gets a named counterpart and a regular joint review rather than a shared queue | F1, as the contrast | [generic] |
| T2 Open the edges | Build partners around the core product so operators get more from what they already use | Whether operators want more vendors around the product is unknown to you; your channel experience is a payments ISV channel, not rail | An operator gets additions without a bespoke project each time | F1, as the analogy | [generic] |
| T3 Commercial clarity first | Before adding partnerships, agree how value is shared and measured, so Kelverton and the operator read the same numbers | It is slower, and the commercial model is Ross's territory; your material says influenced revenue, not a direct quota (F4) | An operator can see what it pays for and what it gets back before committing more | F3, F4, as the limit | [generic] |

**Structure, about 12 minutes spoken, from four signposts**

| Minutes | Signpost | What to do |
|---|---|---|
| 1 | Frame | Say your three working assumptions and what would change your answer; invite a correction early |
| 2 | Starting point | One item from the report to show grounding, then what you would test before committing |
| 5 | The direction | Your thesis and the 18 months in three phases, with the one number you would watch in each |
| 1 | Concession and anti-pick | The mandatory concession in your own words, then one thing you would decline even if an operator asked (see D3) |
| 3 | Close on the operators | One sentence each on what an operator would notice by month 3, month 9 and month 18, taken from your thesis. Land here; do not end on Kelverton's benefit |

Differentiation: the consensus item proves grounding in one minute at most. The divergence and the anti-pick are what score as judgment, and the anti-pick is where the role's real job of saying no shows.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on operator partnerships; the POV itself is one (A) | Highest. Deepa is your future manager, which prior-weights Case and Skeptic, and the recruiter pre-declared a strategy deliverable | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Ross reading your figures to their assumptions (B) | High. The recruiter wrote "Ross will push on commercials"; Ross is a commercial seat, not a manager or a peer in the prior table, so the closest fit is Prober and Pressure. This is a judgment from one sentence, and you can recalibrate it | Know how each of your figures was counted, name the assumption you would defend least before they do, say plainly when you do not know |
| Skeptic | Deepa probing the gaps you have named yourself (C) | High. Manager prior, plus your own stated negatives (F4, F5), which is where this persona aims | Rehearse the single most predictable objection (C1) until it is boring; bridges only from what you said; a ramp plan |
| Pressure | Ross interrupting or time-boxing (D) | Medium. Same basis as the Prober; a commercial push often arrives as pressure | Pause, restate, hold through two follow-ups, concede only what is true |
| Peer Evaluator | Ross on the seam between partnerships and commercial (E) | Low to medium. Adjacent functions suggest it; nothing supplied confirms it | Offer seam principles instead of pretending to know the seam; say what you bring his team |
| Conversational | Opening and closing chat (F) | Low. A second-round panel, but openers are still scored | A 90-second arc; treat the closing "any questions" slot as scored |

Values / Behavioral is left out: the recruiter named no values round and no values were available to this pack.

## Question banks

### A. Case / Strategist (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | This is the graded deliverable; build it from the section above. If you use your own channel as an illustration, say it at its scope: you ran the ISV channel at a payments company and took it from 6 partners to 40, labeled as an analogy rather than evidence about rail. Land on the operators | The question is the recruiter's own brief, so it will be asked in some form; F1 is the only evidence bearing on it. JD because it scores the stated brief, with CASE delivery |
| A2 | "Which operator relationships would you invest in first, and which would you deliberately not? How do you choose?" | CASE | [generic] | Name your criteria aloud before naming any operator, then apply them. If you do not know the operators well enough to name them, say so plainly and say what you would ask first. The question needs no claim about your past, so the guidance makes none | Segmentation under uncertainty is how a strategist is scored, and it prepares the anti-pick; JD content with CASE delivery, `[generic]` because it is a pattern, not a fact about this employer |
| A3 | "Walk us through your first 90 days." | CASE | [generic] | Sequence it: what you would learn and from whom, what you would test, what you would stop. Present it as a plan, in the future tense, and name the one thing you would hold back from deciding until you had listened | A manager buys a ramp plan, and it is also the honest answer to F4 and F5; CASE because it is a live planning problem |
| A4 | "You've seen the strategy team's report. Where do you agree with it, and where would you depart from it?" | CO | [grounded] "which I've read" | Differentiate; do not recite. One item you would cite, in your own words and from the report itself, which the pack has not seen. Then one departure with your reason. Answer slot: if you agree with all of it, say so plainly and say where you think it is thinnest | A shared internal report is the consensus any prepared candidate assembles; F1 is untouched here because the question is about their document, not your history. CO because it scores homework at their altitude |
| A5 | "Imagine an operator tells you the latest release has added work for their team and given them nothing back. What do you do on the call, and what do you do afterwards?" | CASE | [generic] | Structure it: what you ask before you defend anything, what you acknowledge, who you bring in on Kelverton's side, what you commit to and by when, and what you check afterwards. Finish on what the operator now experiences differently. The question needs no claim about your past | It rehearses landing on the operators themselves, the recruiter's close (F2), without a claim about rail; CASE because it is a live problem set in the role |

### B. Data-Driven Prober (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You mention roughly £4M of influenced revenue. Walk me through how that number was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The headline figure, so defend the number: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words and before they ask. If you do not know how it was counted, say so plainly. Keep the quote's word, influenced | F3 is the headline figure and the first place a Prober digs, especially with Ross's commercial push; EXP because it tests attribution |
| B2 | "You took the channel from 6 partners to 40. What counted as a partner, and which part of that growth was yours?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Same four slots for the 6 and the 40: what counted, what it is sensitive to, the assumption you would defend least, which part was yours. Say what you know and nothing past it; "I don't know how that was counted" is an honest branch | F1 carries a second figure with the same exposure; EXP because the probe is attribution |
| B3 | "An operator asks what the partnership costs them and what they get back. How would you frame the commercials?" | CASE | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Do not posture. Say what you need before saying anything: what is being bought, who pays, over what term. Give principles, not prices, and acknowledge the commercial model is Ross's: ask how it is set today. Your own material is influenced revenue, not a direct quota, so frame it as learning from him | The recruiter's sentence about Ross's push makes this likely (F3); F4 is why the answer must be principles. CASE because it is a live commercial problem |
| B4 | "How would you know in 18 months whether operator partnerships are working? Give me three numbers." | CASE | [generic] | Name one number on the operator's side and one on Kelverton's side, plus a leading one. For each, say how it would be counted and the assumption you would trust least; that is the weakest-assumption move applied to a number you have not yet seen. Do not state a target | A Prober turns any metric into a counting question, and it puts a commercial measure in the POV; CASE because it is a design problem |

### C. Skeptic (4 questions; C1 is the highest-ROI rehearsal in this pack)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never sold into rail. Why should we believe you can build partnerships with operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Concede first, in your words: "I haven't sold into rail specifically." Then two facts at their scope: for five years you were in transport consulting, in bus and light rail network planning; for four years you ran the ISV channel at a payments company and took it from 6 partners to 40. Then your ramp as a plan (A3). Hold through two follow-ups. Follow-up one, "Bus and light rail aren't train operating companies": agree plainly, it is not, and return to the planning work. Follow-up two, "Payments isn't rail": answer slot, if something about running that channel carries over, say what, in your own words; if nothing specific does, say so plainly and stay with the channel you ran. Name the limit before they ask: the rail-specific selling is what you do not have | The objection is aimed at F5, the thinnest row, and it will be asked in some form, so this answer rehearsed until it is boring is what changes the interview. JD because it scores a stated requirement of the role |
| C2 | "You haven't carried a direct quota. If this role came with a commercial number, how would you be accountable for it?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain acknowledgment: "I haven't carried a direct quota; what I have is influenced revenue." Then a plan: what you would ask first (what the number is, who owns it, how credit is shared with commercial) and how you would report against it. Do not describe yourself as having been close to a quota | F4 is your own stated negative, so this question is certain once Ross hears it; JD because it scores the commercial side of the role |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two things you have told the pack and name it plainly: rail-specific selling, or a direct quota. Then say what you would do about it in the first weeks, as a plan. A weakness invented to sound modest is the worse answer | The stem is a Skeptic standard; F4 and F5 give you honest material, so a rehearsed answer costs nothing. JD because it asks about the role's demands |
| C4 | "Why this role, and why now?" | JD | [generic] | A selection scaffold: name the specific thing about this role or in the report that pulled you, and the reason the timing is yours rather than the market's. If no specific reason comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would go about finding out. Keep it to 60 seconds | Motivation consistency is what a Skeptic scores, and the guidance makes no claim about your past because your material states no motive |

### D. Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause, restate the question, answer in the quote's terms: influenced revenue. Hold there through two follow-ups. Answer slot: if you know which part was yours, say so in your own words; if you do not know the share, or it was not yours alone, say so plainly and return to "influenced". Concede only that, specifically, and never fold on the core claim to restore harmony | F3 again, in the register where composure is what is scored; EXP because it tests attribution |
| D2 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | About 150 spoken words. Concede first: "I haven't sold into rail specifically." Then two facts at scope (five years in bus and light rail network planning in transport consulting; four years running the ISV channel and taking it from 6 partners to 40), then what you would do in the first weeks. Do not claim those equal rail selling | F5 under time pressure; JD because it tests the stated requirement of the role, delivered as pressure |
| D3 | "We can't do everything. What would you decline in the next 18 months, even if an operator asked for it?" | CASE | [generic] | This is your anti-pick from the POV. State the criterion first, then one example. Show spine and tact together: say what you would offer the operator instead and how you would tell them. The question needs no claim about your past | Where the role's job includes saying no, this is where it shows (F2's operators close); CASE because it is a live trade-off |

### E. Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Partnerships and commercial sit side by side. Where is the seam, and what happens when we disagree about a deal?" | CASE | [generic] | Propose seam principles instead of pretending to know the seam: who owns the relationship, who owns the terms, how a disagreement is escalated and recorded. Reciprocity: say what partnerships gives commercial, not only what you need from it. The question needs no claim about your past | Ross's seat makes this plausible; nothing supplied confirms it (F3 is the closest basis). CASE because it is a live collaboration problem |
| E2 | "On a deal where partnerships opens the door and commercial closes it, how should credit be shared?" | CASE | [generic] | A principle, not a story: credit follows the contribution you can show, agreed before the deal and not after; say how you would raise it with Ross. Your material says influenced revenue, so expect the follow-up to turn to what influence meant in your channel; that is B1's slot, not a new claim | Credit is where a partnerships hire and a commercial director most often meet; CASE because it is hypothetical |

### F. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with three beats the sentences state: five years in transport consulting, in bus and light rail network planning; nine years in partnerships; the last four running the ISV channel at a payments company and taking it from 6 partners to 40. Answer slot: the first five years of the nine are not in your material; say what they were in your own words, with titles and dates as they stand on your CV | An opener that sounds casual is still scored, and the arc is where F1 and F2 meet; EXP because it tests the CV's story |
| F2 | "What drew you to Kelverton in particular?" | CO | [generic] | A selection scaffold: one specific thing from the report or the recruiter's brief, and why it matters to you. If nothing specific comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would want to find out | Homework depth, and it is a scored question in a friendly register; guidance stays generic because no research was available |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: the 18-month POV on operator partnerships | A1, A2, A3, A4, B4, and the POV build above |
| F2: land on what it means for the operators | A5, D3, C1, F1, and the operator close in the POV build |
| F3: Ross will push on commercials | B1, B2, B3, D1, E1, E2 |
| F4: carrying a revenue number directly | C2, C3, B3 |
| F5: selling into rail operators | C1, C3, D2 |

Every requirement above has a question. No JD means other stated requirements may exist that this table cannot show.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In 18 months, what would you want operators to be saying about Kelverton's partnerships that they wouldn't say today?" | Hands the operator close back to them and tests whether your POV matched their picture |
| R2 | "Where would you push back on what I've said today?" | Invites the objection while you are in the room, and shows you want it |
| R3 | "How are partnerships and commercial each measured today, and what does a good quarter look like for each?" (to Ross) | Concrete and on the seam, and it shows you are thinking about shared credit |
| R4 | "What could a new person on partnerships do in their first month that would genuinely help commercial?" (to Ross) | Reciprocity question for a counterpart seat |
| R5 | "What do operators ask of us most often that we have to say no to?" | Connects to your anti-pick and lets you calibrate it |
| R6 | "What would make you glad, at 90 days, that you hired me?" | Turns the ramp plan into their success criteria |

No reverse question is tied to an interviewer's own path: nothing about either interviewer's career was available.

## Prohibited claims

Built before the banks. Each entry is a claim this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't sold into rail specifically." No slot |
| Has carried a direct quota or owned a revenue number | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; what I have is influenced revenue." No slot |
| Generated, sold or closed £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, not generated or closed. B1, B2 and D1 slots stay inside the quote |
| Knows how train operating companies work | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning and "the operator world" in your own words, not train operating companies. The slot in F2 asks only what your planning work showed |
| Built the partner programme or designed how the channel works | Inflated form of F1 | F1's quote at its own scope: running the ISV channel and taking it from 6 partners to 40. The pack's observation is that the quote says running and taking, not building |

## Sources

**Provided documents:** your message; the recruiter's email, as quoted in your message. The market report attached to the recruiter's email was not in the material this pack received, so nothing in this pack is drawn from it.

**Searches sent, with what came back:**

- "Kelverton Rail values" (target 1): refused
- "Kelverton Rail interview process partnerships" (target 2): refused
- "Kelverton Rail strategy scheduling software train operating companies news" (target 3): refused
- "Deepa VP Partnerships Kelverton Rail" (target 4): refused
- "Ross Commercial Director Kelverton Rail" (target 4): refused
- "Senior Partnerships Manager job description rail technology train operating companies" (target 5): refused

No pages were fetched, and no dossier was present.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Search was refused. It would have decided whether a values cheat sheet exists; it moved nothing, and no values round is named in the recruiter's words either |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Search was refused. The loop here is fixed by the recruiter's own words (one 60-minute panel), so the persona weights rest on those words and the prior table; a loop report could have refined them |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Search was refused. It would have grounded A4 and F2 and added a grounding brief; both stay generic |
| 4. `{interviewer name} Kelverton Rail` | unavailable | Both searches were refused. It would have added the interviewer read and a reverse question tied to their paths |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Search was refused. It would have supplied inferred JD rows; the fit snapshot rests on the recruiter's words instead |

## Upgrade menu

- The job description text → F4 and F5 stop resting on role-family patterns, JD-tagged questions are re-grounded, and any gate such as location or travel would surface
- The report's headline findings, or its section headings → A4 and the POV theses move from generic options to grounded, and the consensus item and divergence can be chosen with you
- What "operator partnerships" covers at Kelverton, from the JD or one line to the recruiter → the choice among T1, T2 and T3 stops being a guess
- Web search permission → values, strategy, loop and interviewer footprint (targets 1 to 5); a deeper pass of up to 6 further searches and 2 further fetches, several more minutes, is available on request
- Both interviewers' full names or profile links → the interviewer read, persona weights read from their public footprint, and a reverse question tied to a path
- Your answers to the slots in F1, F2 and F3, given in the conversation outside a drill → those rows move from slots to quoted material, and the banks that draw on them (A1, B1, B2, C1, D1, F1) are regenerated
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and the objection worth the deepest rehearsal arrive pre-graded
