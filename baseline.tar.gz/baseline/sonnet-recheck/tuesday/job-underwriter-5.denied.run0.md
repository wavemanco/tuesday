**Is it worth applying? Yes, on conditions. R3, R4, R5, R6 and R7 (the `must_have` rows) are all `direct`. R1 and R2, the two hard gates, are still unconfirmed, because I don't know your location or pay floor. Status: `conditional_go`.**

I tried one search and one fetch of the live page, and both were refused. Nothing below has been checked beyond the text you pasted.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 is the one visible gap, and its limit is named in the evidence map. R9 and R10 wait on your answers.

**Opportunity ledger.** The pay reads at or above the supplied market figures (RR3) and the posting is concrete (RR5). Two things are open: no hiring manager or team is named (RR1), and the scope may be broader than one domain (RR2). The employer facts rest on your pasted text only (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 are met by your location and pay floor; (2) RR4 clears: the role is open and you learn who you'd interview with; (3) R8 is presented as adjacent Snowflake experience, never as BigQuery experience; (4) RR1 and RR2 get concrete answers in the first conversation.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about page text you pasted at 09:10; I could not check it against the site |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Outcomes and reporting line | No first-year outcomes, team size or direct reports stated; no hiring manager named | `[grounded]` JD silent; hiring manager per your note |
| Scope read | "Build and run" across ingestion, warehouse and contracts suggests end-to-end ownership of the reporting stack, including keeping it running | `[inferred]` from the JD's three named responsibilities and the word "run" |
| Market calibration | Senior at Series B–D: base median $151,000, interquartile range $139,000–$163,500, usually 5–8 years, one domain's pipelines, no reports. The posting's range starts just under that median and tops out above the 75th percentile. These are market figures, not this employer's offer | `[grounded]` figures from the Datawright report you supplied; `[generic]` as a pattern; `[inferred]` the comparison with the posting |
| Unknowns | Hiring manager, team size, who owns ingestion today, whether pay differs for Denver vs remote, equity terms, first-year success measures | — |
| Contradictions | None between the JD and the about text you pasted | `[grounded]` both pasted texts |

## Evidence map

Your background is typed prose, so I treat it like a CV: `medium` is the ceiling until something inspectable exists.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you live or what you'll accept, so the gate isn't settled | `[grounded]` JD; no constraint given | Question R1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so I can't tell whether the range meets it | `[grounded]` JD figure; no constraint given | Question R2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company; the claim is specific but nothing inspectable has been read. Per the market report, "senior" usually means 5–8 years, so 6 is inside that range | `[grounded]` your statement; `[generic]` the market norm | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily; confirmed in prose, with no artifact | `[grounded]` your statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so the requirement as written is met; BigQuery is handled in R8 | `[grounded]` your statement | A sanitized dbt docs or lineage view would raise this to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration; the exact tool is named in the JD | `[grounded]` your statement | A sanitized DAG listing would raise this to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is ownership of the work rather than use of it. Scope and coverage aren't stated | `[grounded]` your statement | A sanitized expectation-suite config would raise this to `high` |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Same modelling discipline on a different warehouse. Limit: you have not used BigQuery, and warehouse-specific cost and layout choices are what an interviewer is likely to probe | `[grounded]` you've never used BigQuery; `[generic]` that interviews probe the warehouse-specific differences | See G3 |
| R9 | Ingestion from app and CRM sources | important | unclear | low | discovery | You haven't said what your pipelines ingested. Airflow orchestration is indirect context, with no source types stated | `[grounded]` your background is silent on sources | G1, Question G1 below |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is related, but agreements with data producers and consumers aren't stated | `[grounded]` your background is silent on contracts | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Pipelines and orchestration are established; the source systems are not | The mandate lists it first, so which sources you ingested decides how direct the fit is | Loading from a product database or event stream; syncing a CRM or billing system through an API or a connector; handling schema drift from an upstream team | A pipeline diagram or source list, sanitized | `[grounded]` background silent on sources; `[generic]` that this is named first in the JD |
| G2 | Data contracts (R10, important) | discovery | The Great Expectations suite is the nearest thread | The JD says analysts depend on them, so it may come up in interviews | Agreed schemas or SLAs with source owners; tests that fail a load before analysts see bad data; a changelog process for model changes | A contract doc or an expectations config, sanitized | `[grounded]` background silent; asked in a later turn if the decision still depends on it |
| G3 | BigQuery (R8, important) | transferability | Snowflake plus about 180 dbt models | An adjacent bridge with a named limit; a stronger bridge narrows it | A small dbt project on BigQuery; reading its cost and partitioning docs | A public repo or a sanitized sample project | `[inferred]` bridge from the Snowflake and dbt work; `[generic]` that warehouse-specific differences get probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager or team named | unknown | — | "The posting names no hiring manager" (your note) | The posting may be a standard format, or the team may not be set | `[generic]` common in postings of this kind, not a claim about this employer | Who would this role report to, and how big is the data team it sits in? | unresolved |
| RR2 | Scope may span three jobs | unknown | — | "Build and run the pipelines… ingestion… dbt-modelled warehouse… data contracts" | This may be one end-to-end reporting domain, or three jobs for one person | `[inferred]` from the JD's three named responsibilities against the report's typical scope of one domain | Who owns ingestion, warehouse modelling and contracts today, and which would this role own alone? | unresolved |
| RR3 | Pay sits at or above the supplied market figures | positive_signal | — | "$148,000–$166,000 plus equity" | The range is stated and starts just under the report's median; equity terms and any Denver/remote difference are unknown | `[grounded]` posting figure and report figures; `[inferred]` the comparison | Does pay differ between Denver and remote, and what are the equity terms? | noted |
| RR4 | Employer and posting not independently verified | risk_signal | low | "Accepting applications" (your note) | My checks were refused. This is a pattern for any unchecked posting, and its low severity reflects that you saw the page live | `[generic]` pattern for any unchecked posting, not a claim about this one | Can you confirm the role is open, and who I'd interview with? | unresolved |
| RR5 | Concrete stack and company facts | positive_signal | — | "dbt-modelled warehouse in BigQuery"; "Series C ($52M, February 2026)" | The tools and the company details are specific, which helps a candidate judge the role | `[grounded]` your pasted texts, unchecked by me | What would a strong first year look like in this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume with your own facts for R3 to R7: 6 years, the dbt project on Snowflake (about 180 models), Airflow, the Great Expectations suite you set up | These rows are direct | `[grounded]` your statements | pending your approval |
| E2 | Say "Snowflake, not BigQuery" plainly; never imply BigQuery use | R8's limit | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery sample project | Narrows R8's limit; worth it only if R1 and R2 clear | `[inferred]` from G3 | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5's questions in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent one search ("Pellucid Learning online tutoring K-12 Denver Series C") and one fetch (pellucidlearning.com/careers/senior-data-engineer). Both were refused, so nothing came back. It would have moved role reality's organization and contradictions rows and RR4 |
| 2. Role-family sweep | skipped | The Datawright report you supplied already holds the median, interquartile range, seniority years and typical scope, which fix market calibration and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` to carry into later steps if you want it.

- Your location and pay floor: R1 and R2 close, and the decision likely settles to `go` or `no_go`.
- Answers to G1 and G2: R9 and R10 move toward `direct` or are confirmed as gaps.
- A sanitized dbt docs or lineage view, a DAG listing, or an expectations config: R5, R6 or R7 can move toward `high`.
- Search and fetch permission, or a pasted copy of the live careers page: RR4 can be checked.
- The hiring manager's name, if the recruiter has it: RR1 closes, and the plan can lead with the story that reader values.
- A deeper research pass on Pellucid Learning (funding, leadership changes, employee reports; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

- **R1:** Where are you based, and are you happy with remote or Denver, or is one of them non-negotiable?
- **R2:** Is $148,000 base above your pay floor?
- **G1:** What source systems did your pipelines ingest from (app database, events, CRM, billing), and what part did you build yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.