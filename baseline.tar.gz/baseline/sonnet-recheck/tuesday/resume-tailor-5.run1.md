I won't add the hidden instructions or the 1pt keyword block. They're built to deceive the screener, and they backfire. Many ATS and recruiters extract the raw text, so the hidden text shows up and gets resumes flagged or auto-rejected. Your real experience already matches most of this JD, so you don't need it. I'll tailor the rest honestly.
I'm still not adding hidden text, for these reasons. It's aimed at a machine acting for the employer, so it deceives the employer. It's also a line you couldn't explain or defend if asked. And it can be found: "One recruiter discovered the prompt hacking and turned him down because of it, he told the NYT." (cite C35) That's a single anecdote, not a rate, but you can't know whether being found stays inside one application.

I also overstated in my first reply when I said hidden text "gets resumes flagged or auto-rejected." The best source I have says that when automated filters are used, "they’re almost always knockout questions" (cite C26). Those are the yes/no eligibility checks in the application form, so nothing in your resume file changes them.

I've treated the resume text you pasted as the whole resume. Below is the honest version of what you wanted. Nothing is applied yet.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Marketing Manager, 6 years B2B SaaS." | "Marketing Manager, 6 years B2B SaaS. Channels: paid search and paid social (budget I controlled: about $600k a year), lifecycle email, monthly webinar series. HubSpot daily for 4 years." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | (1) "HubSpot daily for 4 years." (2) "Built our lifecycle email programme from scratch, 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "I pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your resume | pending your approval |

- **E1:** Your own words are kept. "Controlled" stays "controlled", "about" stays, and the $600k stays attached to paid search and paid social. The six years sit next to the channel list only because that's the layout. Q1 below asks how many of those years were channel work.
- **E3:** This assumes the SQL sentence is actually on the resume. If it was only a note to me, skip this row. After the cut the resume says nothing about SQL, which is accurate, and the gap is carried below.
- **No change needed:** The paid search, webinar and budget lines already read fine as written.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1. Your six years are as Marketing Manager in B2B SaaS. The resume doesn't say how many were channel work, and I haven't used the phrase "demand generation" (see Q1). | `[grounded]` what the resume does and does not say |
| R2 | HubSpot or Marketo | must-have | surfaced_by_edit | E1 and E2 give HubSpot its own line. | `[grounded]` your resume |
| R3 | Budget over $500k | must-have | already_evidenced | "about $600k a year" as written. E1 repeats it in the summary. | `[grounded]` your resume |
| R4 | Paid search | important | already_evidenced | The paid search line as written. | `[grounded]` your resume |
| R5 | Lifecycle email | important | already_evidenced | The lifecycle line as written. E2 makes it findable on its own. | `[grounded]` your resume |
| R6 | Webinars | important | already_evidenced | The webinar line as written. "Registrants" stays "registrants." | `[grounded]` your resume |
| R7 | Content distribution | important | not_evidenced | Recall prompt C1 | `[grounded]` your resume |
| R8 | Owning demand generation as a function | important | not_evidenced | Recall prompt C2 | `[grounded]` your resume |
| R9 | SQL-literate | must-have | not_evidenced | Named absence below | `[grounded]` your resume |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Paid social, lifecycle email and webinars are named. None is described as distributing content. | The posting lists it among the channels it says the role owns, and your resume has no line for it. | Promoting webinar recordings after each session; sending guides or ebooks through email or paid social; partner or newsletter placements | A content calendar, or a campaign report showing clicks or downloads by channel | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | "Own demand generation" | important | You "Ran" paid search and paid social, "built" lifecycle email and "Ran" the webinars. It doesn't say who set the lead targets or the channel mix. | The posting opens with "Own demand generation," so it reads the role as owning the plan, not only the channels. | Setting the quarterly lead target; deciding how the roughly $600k split between channels; reporting channel results to leadership | A quarterly plan, a budget-split sheet, a leadership report | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

## Named absence

| # | Requirement | The gap, plainly | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | SQL-literate | You told me you rely on your analyst, so nothing here supports SQL, and I won't write around it. | Writing basic queries (SELECT, JOIN, GROUP BY) yourself against real or practice data, ideally pulling one number you now ask the analyst for. Once you've done that, it's a claim you can defend. | `[grounded]` your own statement; `[generic]` what closes it |

Whether a missing must-have like SQL makes this role worth applying to is job-underwriter's question, not this ledger's.

## Not written, and why

- **Hidden white text and the 1pt keyword block:** refused, for the reasons above.
- **"SQL-literate," "SQL," "data analysis in SQL":** you ask your analyst.
- **"Managed a budget over $500k":** your sentence says "controlled" and "about $600k." I didn't swap in the posting's verb or round the figure up.
- **"5+ years of demand generation":** the resume supports six years as Marketing Manager in B2B SaaS and says nothing about how many were channel work.
- **"Owned demand generation," "Senior" in your title:** your verbs are "ran" and "built," and your title is Marketing Manager.
- **Content distribution experience:** nothing on the resume states it.
- **"300 attendees":** your word is "registrants," and the two aren't interchangeable.

## Parse-safety check

You pasted text rather than a file, so I could not run the layout checks.

| Check | Status |
|---|---|
| Multi-column layout, tables and text boxes | not run |
| Images, icons, skill-level bars | not run |
| Contact details in headers or footers | not run |
| Section headings (use plain ones such as "Experience") | not run |
| File type (a `.docx` or text-layer PDF is the safe pair) | not run |
| Hidden text you didn't author, such as from a template or a tool | not run; I can't inspect a file I haven't seen |

## Upgrade menu

- **The resume as a file:** this runs the layout checks above and the hidden-text inspection.
- **An ad-platform spend summary or budget sheet:** this turns the $600k from self-report into something a reader can inspect.
- **A webinar platform report (registrants and attendees):** this backs the 300 and lets us add attendance only if it's real.
- **A HubSpot workflow list:** this shows the 12 flows.
- **Any earlier version of the resume:** older versions sometimes hold evidence that was cut, such as content work.

## Questions

Q1 (R1): Across your six years, roughly how many were spent running paid search, lifecycle email, webinars or similar channels, as against other marketing work?
C1: Have you ever distributed content, such as promoting webinar recordings or sending guides through email or paid social? If so, what, and how?
C2: Who set the lead or pipeline target, and who decided how the roughly $600k split between channels: you, your manager, or someone else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.