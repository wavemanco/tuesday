The pack is built, but the write to the project folder was blocked. I'm saving it to my scratchpad folder instead, which doesn't need a permission prompt.
Dara, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-denied-1df56312/8f7c7155-eee9-491c-9aec-1195392a93f5/scratchpad/Ashgrove_member-experience-lead_interview_pack.md`. Writing to the project folder was blocked, so it's in the scratchpad folder.

I covered all three rounds on 21 October and used only what you sent me, with no web searches. I worked from your 12 October date, but the date I see is 5 November. If the rounds have moved or already happened, tell me and I'll rework it.

The pack has these parts:
- **Fit snapshot:** each JD requirement against your own words.
- **Question banks by round:** 28 questions across the recruiter screen, the Head of Member Services and the panel, plus reverse questions.
- **Values cheat sheet:** all four values.
- **Not coached:** a list of claims the pack won't coach.

The most likely objection is that you've handled one branch's complaints log and never worked in a contact centre, yet the role owns the process across branches and the contact centre. That is question D1 in round 2, and the pack gives you the wording for three follow-ups. Rehearse it first.

Several rows end in an "answer slot", where I couldn't tell from your note what you actually did. They cover regulated complaints, what the monthly spreadsheet counted, coaching at supervisor level, and any work with digital teams. Answering them from real experience will firm up the pack.

I can run a live drill of D1, with me playing the Skeptic. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

How many hours do you have before 21 October? Your answer lets me add a prioritised schedule.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 21 October, as the recruiter's email describes them. Round 1 is a 30-minute recruiter screen. Round 2 is 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural. Round 3 is 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation, scored against the four published values. Interviewers beyond their roles are not yet assigned, so there is no interviewer read.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding to speak from, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer from your own experience, in your own words, and either branch is a good answer.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behaviour shows the published values |
| EXP | Work-experience deep-dive | Whether your CV's claims survive scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem set in the role |

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | The quote already reaches the requirement. Say it in its own terms: six years in retail banking, the last three as a branch supervisor. Nothing is inspected behind it, so expect a probe on what the supervisor years covered, which you answer in your own words |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal complaints, not regulated ones, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's word regulated makes a probe on which rules the log answered to likely. If the formal complaints ran to external rules or deadlines, say which and what you did, in your own words; if you are not sure, or there were none, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | One branch's log is adjacent to owning a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened before and after the log likely. If you saw or set any of those steps, say which, in your own words; if the log was where your part began and ended, say so plainly |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote shows a monthly spreadsheet, not what it counted, and the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say how, in your own words; if it counted something else, or you are unsure, say so plainly and say what it did carry |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a monthly spreadsheet someone else relies on. Use the quote's own nouns. Name the software only if the spreadsheet was in Excel |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Training tellers on a script is adjacent to coaching supervisors, and the words stay at that scope: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on whether you have coached at that level. If you have guided another supervisor on an escalation, say what it was and what you did; if not, say so plainly and stay with the tellers |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Strong evidence here would be a time you took what you saw at the counter to whoever built or changed a digital route. Answer slot: if you have worked with any digital or online-banking team, say what the problem was and what you did; if you have not, say so plainly and say what you would ask a digital team for first |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated absence. Words: "I haven't presented above regional level." Then how you would prepare for it, as a plan and never as a past. Your material does not say how confident you were at regional level, so the pack does not claim it |

## Grounding brief (from the 2026 strategy brief, as you summarised it)

| Item | What it says | Source | Where it may surface |
|---|---|---|---|
| Digital share | Move 40% of member service to digital channels by 2028 | Strategy brief, June 2026 — your message | E1, E2, D2, H2 |
| Branch network | Consolidate eight branches into five hubs over 2027 | Strategy brief, June 2026 — your message | E1, I2, J1 |
| New product | Launch a small-business lending product in Q1 2027 | Strategy brief, June 2026 — your message | A3 |
| Competition | Main pressure is app-only banks | Strategy brief, June 2026 — your message | A3, E2 |

The brief is public and the recruiter sent it to you, so assume other candidates have read it. Bring one item to show you read it, then your own view.

---

# Round 1: recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, motivation, logistics | High. A recruiter screen sits in the Conversational plus light Skeptic prior (personas.md), and the screen is 30 minutes | Pre-script a 90-second arc and treat casual questions as scored |
| Skeptic (light) | Quiet knockout checks on gaps | Medium. The JD names a contact centre and regulated complaints, and a screen checks those early | Name the gap plainly before it is pressed; add a plan, not a claim |

## Question bank, round 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc told in these beats and no others: six years in retail banking, the last three as a branch supervisor; within that, the formal complaints log you handled, the escalation script you trained new tellers on, and the monthly complaints spreadsheet you built for your regional manager. Close on why this role, in your own words; the pack does not know your reason and supplies none | The arc draws on F1, F2, F5 and F7. EXP because it tests whether the CV story holds together; Conversational because the opener is the register of this round |
| A2 | "What draws you to Ashgrove, and to a member-owned credit union?" | CO | [grounded] | Anchor in what Ashgrove publishes, not general praise: its values page names "Members First, Always" and "Neighbours, Not Numbers". Say which line you recognise in how you already work, in your own words. The reason has to be yours, and the guidance makes no claim about your past | Motivation consistency is the staple of a recruiter screen. CO because it scores whether you read the published values, not the brochure |
| A3 | "What do you know about where we're heading?" | CO | [inferred] views derived from the brief's digital-share and app-only-bank lines | Do not recite the brief. Bring one item to show you read it, for example 40% of member service moving to digital channels by 2028, then one view of your own, labelled as a view. Views to test, not facts: complaints will increasingly start in one channel and finish in another; the harder cases will stay with people. Say which you would stand behind and why, in your own words | The differentiator question most candidates meet without a view. CO because it scores strategy fluency; derived from the grounding brief, so a view and not a fact |
| A4 | "Is there anything on timing, salary or notice we should know about?" | JD | [generic] | No claim about your past. Settle your figure, your notice period and your availability around the 21st before the call; the pack cannot supply them. Give a range, or say you would like to understand the role first, only if that is true for you | Logistics and knockout checks are the recruiter-screen prior, and the risk is treating them as unscored. JD because it tests terms of the role |
| A5 | "The role coaches branch supervisors on escalations. What's your experience with training or coaching?" | JD | [grounded] "trained new tellers on our escalation script" | Say it in those words: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on whether you have coached at supervisor level. If you have guided another supervisor on an escalation, say what the situation was and what you did; if not, say so plainly and stay with the tellers | F7 is the evidence and a transferability row, so the probe on level is likely. JD because it tests a stated responsibility |
| B1 | "The role handles regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | "I handled the branch's formal complaints log." Answer slot: the word regulated invites a probe on which rules the log answered to. If the formal complaints ran to external rules or deadlines, say which and what you did, in your own words; if you are not sure, or there were none, say so plainly and stay with the log you handled | F2 is a discovery row, so this is where the screen is most likely to check. JD because it scores a stated requirement; Skeptic because it checks the gap |
| B2 | "You haven't worked in a contact centre. How would you get up to speed?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first: "I've never worked in a contact centre." Then a plan, said as a plan: what you would ask to see and whom you would ask to sit with in your first weeks. Do not offer branch work as a stand-in; your material does not say it was | F4 is a stated gap and the JD names the contact centre. JD because it scores a stated requirement; Skeptic delivery |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose the gap you would name before they do. Both are your own statements, so either is honest: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Follow it with a plan in the future tense and no past claims | F4 and F9 are the two stated gaps. JD content, Skeptic delivery: it tests honest self-assessment |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1 | "Does this role manage the contact centre's complaints team directly, or work alongside it?" | The JD says the process spans branches and the contact centre, and the answer tells you what owning it means here |
| R2 | "Can you tell me the shape of the 20-minute case, and who the two branch managers are?" | A recruiter can often say in one email whether it is written, role-played or discussed, and the names unlock an interviewer read |
| R3 | "What happens after the third round, and when would you hope to decide?" | Practical, shows you are planning, and costs the recruiter nothing |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes, STAR-shaped stories | High. The recruiter described this round as mostly behavioural | Map a story to each prompt where one of your sentences carries it, a selection scaffold where none does; "we" for context, "I" for contribution |
| Skeptic | Probing the gaps for a would-be manager | High. A hiring manager is buying capability and derisking gaps (personas.md prior), and you have stated two gaps | Rehearse the single most predictable objection until it is boring; concede the specific, hold the core |
| Case / Strategist | Live problems set in the actual role | Medium. A hiring-manager prior, tempered because the 20-minute case sits in round 3 | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober | Line-by-line reading of the CV | Low. One reporting line on your background invites it | Know what you can and cannot say about the spreadsheet; say plainly when you do not know |

## Question bank, round 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through a difficult escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7, with the beats the quote states: the escalation script, and the new tellers you trained on it. Answer slot: the JD's coaching line makes a probe on a specific escalation likely. If you coached someone through a live one, say what it was and what part was yours, in your own words; if the training stayed with the script, say so plainly and describe the training as it happened | The theme comes from the JD's coaching line. F7 is the only evidence, so the probe lands exactly at its edge. VAL because it asks for a chosen instance |
| C2 | "When did you put a member ahead of an internal measure?" | VAL | [grounded] | Selection scaffold, no claim about your past. Pick an instance with a named stake, the measure it cut across, what you did and what changed for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem tied to the value Members First, Always. VAL because it scores a specific decision that demonstrates the value |
| C3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold. Your material carries the monthly spreadsheet your regional manager uses; whether it ever showed anything unwelcome is not in it. Pick an instance with a named stake, who it was uncomfortable for, how you said it and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values stem, and F5 is the nearest reporting evidence. VAL because the hard truth landing is what it scores |
| C4 | "A supervisor disagrees with how you told them to handle an escalation. What do you do?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | No past claim is needed. Ask what they saw first, agree what keeps the member safe, then coach the principle rather than the script. You can say you were a branch supervisor for the last three of your six years, and let them draw the inference | The theme comes from the JD's coaching line, and a manager checks how you disagree with equals. VAL delivery; F1 is the only fact used |
| D1 | "You've handled your branch's complaints log and you've never worked in a contact centre. Why should we trust you to own this across branches and the contact centre?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **The highest-ROI rehearsal in this pack.** State the limit before it is asked: "I've never worked in a contact centre." Hold the log at its own scope: "I handled the branch's formal complaints log." Follow-up 1, "a log is not a process": agree it is narrower and return to the log, adding nothing. Follow-up 2, "what would you do first": a plan, said as a plan, of what you would ask to see across branches and in the contact centre before changing anything. Follow-up 3, "so you can't do the job": concede the specific, that the contact centre is new to you, and hold the core by saying you would be learning that part openly. Answer slot: the JD's end-to-end line makes a probe on what happened before and after the log likely. If you saw or set any of those steps, say which, in your own words; if the log was where your part began and ended, say so plainly | F3 and F4 together are where the JD presses hardest, and a would-be manager is derisking exactly this. JD because it scores the headline requirement; Skeptic delivery |
| D2 | "I don't see digital self-service work in your background. How would you handle that part of the role?" | JD | [grounded] | Answer slot: if you have worked with any digital or online-banking team, say what the problem was and what you did; if you have not, say so plainly. Then a plan: what you would ask a digital team for first. The brief's 40% by 2028 target makes this likelier to be probed | F8 has no evidence at all, which is a discovery gap. JD because it scores a stated responsibility |
| D3 | "Imagine you're presenting complaint trends to our senior leaders. How would you structure it?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented above regional level." Then the structure, as a plan: the JD's two measures, volumes and resolution times; what has changed; what you need decided; one clear line to close. Concede it is new to you and say how you would prepare, in the future tense | F9 is a stated gap and the manager will be the one presenting you upward. JD because it scores a stated requirement; the question is a plan, not a past |
| E1 | "Complaints about the app are rising just as branches consolidate into hubs. How do you find out what's driving it, and who needs to know first?" | CASE | [inferred] derived from the brief's digital-share and eight-to-five hubs lines | Clarify first: which complaints, which channel, since when, which hubs. Then the objective, a split by channel, branch and complaint type, an approach that reads cases before guessing, and the JD's two measures, volumes and resolution times. Challenge one premise respectfully: whether the rise is the app or the change around it. Say who hears first and why, in your own words | A hiring-manager live problem built on the strategy. CASE because it asks about no past |
| E2 | "As 40% of member service moves digital by 2028, what happens to complaints that start in the app?" | CO | [inferred] derived from the brief's digital-share line | Take a position with one concession. A line to test: the channel changes but the owner does not, since "whoever finds the problem keeps hold of it until it is solved". Concede what you do not know about how Ashgrove's channels connect today. Do not recite the brief | The strategy differentiator for the manager round. CO because it scores thinking at the company's altitude |
| F1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5 and F6 with the beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel, so expect a probe on what it counted and what it was built in. If it counted volumes or resolution times, say how, in your own words; if it counted something else, or you are unsure, say so plainly and say what it did carry. Name the software only if you know | The only reporting evidence in your material. EXP because it tests what you actually built; Prober delivery |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R4 | "What would a good first six months look like for this role, in terms of complaint volumes and resolution times?" | Uses the JD's own measures and shows you already think in them |
| R5 | "Which complaints reach this role today, and which stay with the branches?" | Tests the end-to-end line of the JD and what you would own |
| R6 | "How does the digital team hear about what members complain about today?" | Opens the self-service line and shows interest in the seam |
| R7 | "What does a good escalation look like to you, and where does it go less well?" | Turns the coaching line into a conversation with your would-be manager |
| R8 | "How will the move to five hubs in 2027 change who handles a complaint?" | Ties the brief to the role, and a manager can answer from the inside |

---

# Round 3: panel of two branch managers (60 minutes, 20-minute case, scored against the four values)

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes against the four published values | High. The recruiter said the panel is also the values round and scores against the four values | One story or scaffold per value; "we" for context, "I" for contribution; harmony stories where the hard truth landed, and where your material shows none, say so |
| Case / Strategist | The 20-minute complaint escalation | High. Named in the recruiter's email as 20 of the 60 minutes | Clarify before structuring; ask which rules and deadlines apply, since the pack does not know them |
| Peer Evaluator | Seam-splitting, "what would you need from me" | Medium, inferred: the role coaches branch supervisors, so branch managers are the nearest stakeholders | Reciprocity framing; propose principles rather than pretending to know the seam |
| Skeptic | Quiet probing of reporting versus towns | Low. Two branch managers outside your would-be team | Concede the specific, hold the core |

## Question bank, round 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] | Selection scaffold, no claim about your past. Pick an instance with a named stake, what the internal side wanted, what you did and what changed for the member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is the value Members First, Always. VAL because the panel scores a specific decision, not slogan familiarity |
| G2 | "Tell me about a time something had to be explained twice, and what you did about it." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F7, with the beat the quote states: the escalation script you trained new tellers on. Answer slot: the value Plain Words makes a probe on wording likely. If the script's wording changed because someone needed it explained twice, say what changed and what part was yours; if it did not, or it was not yours, say so plainly and stay with the training | The theme is the value Plain Words. F7 is the only evidence that touches wording. VAL because it scores a specific instance |
| G3 | "When did you act on something about your branch's town that a figure would not have shown you?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold. You were a branch supervisor for the last three of six years; what you noticed about the town is not in your material. Pick an instance with a named stake, what you noticed, what you did and who in the town it affected. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme is the value Neighbours, Not Numbers. F1 is the only fact used. VAL because it scores a specific decision |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2, with the beat the quote states: you handled the branch's formal complaints log. Answer slot: the value Own the Fix makes a probe on one complaint, start to fix, likely. If one stayed with you to a fix, say what it was and what part was yours, in your own words; if it passed to someone else or ended at the log, say so plainly and stay with the log you handled | The theme is the value Own the Fix. F2 is the closest evidence. VAL because it asks for a chosen instance |
| H1 | "A member has complained twice about the same fee. The branch says it's resolved; the member has now written in a third time. Walk us through what you do." | CASE | [generic] | Clarify first: what the member has been told, by whom, and which rules and deadlines apply here, since the pack does not know yours. Then the objective, who owns it from now (whoever finds the problem keeps hold of it), the member's reply in plain words, what is recorded, and what the supervisor is coached on afterwards. Challenge one premise respectfully, such as whether resolved means the same to the branch and the member. Say where you would stop and ask | The 20-minute case is on a complaint escalation. CASE because it asks about no past; the scenario is a practice pattern, not a prediction of theirs |
| H2 | "The same complaint reaches us three times: in the app, at a branch counter, and by phone to the contact centre. What happens?" | CASE | [inferred] derived from the JD's "across branches and the contact centre" and the brief's digital-share line | Clarify: are they linked today, and who sees all three. Then one owner for the member, one record, and a reply in plain words. Name what you would not change before you understood the three routes. Challenge one premise, such as whether three records means three problems | Cross-channel ownership is the JD's headline line, and the case may lean on it. CASE because it asks about no past |
| H3 | "Write the first two sentences of a reply to a member who has been told the same thing twice." | CASE | [generic] | A Plain Words test. Say what happened, what you will do and by when, in words a member needs once; check the date with the panel before you commit to one. Read it aloud and cut anything a member would need explained | The panel hears Plain Words as part of the case. CASE because it is a live task with no claim about your past |
| I1 | "You'd be coaching supervisors who know their towns better than you. How do you do that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Reciprocity framing: ask what the supervisor sees first, and offer principles rather than a script. You can say you were a branch supervisor for the last three of your six years, and let the panel draw the inference. Do not claim what that taught you unless you can tell it as a story | The JD's coaching line puts branch managers closest to the outcome. JD because it scores a stated responsibility; Peer delivery |
| I2 | "Eight branches become five hubs over 2027. What should complaints feel like for a member whose branch changes?" | CO | [inferred] derived from the brief's eight-to-five hubs line | Do not take a view on which branches change; the panel knows the local detail and you do not. Ask what they are seeing. Offer a principle: the member should not have to explain twice, and whoever finds the problem keeps hold of it. Concede what you do not know | The brief's hub plan touches the panel's own branches, so it may come up. CO because it scores thinking at the company's altitude; derived, so a position and not a fact |
| J1 | "Our members are in towns, not on a dashboard. You've built a spreadsheet; how do you stop the reporting becoming the job?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the value Neighbours, Not Numbers makes a probe on whether the sheet changed anything in a branch likely. If something it showed led to action, say what and what part was yours; if it stayed on the sheet, say so plainly. Then a principle for the role, as a plan | Tests the reporting line against the values. EXP because it tests the CV claim; Skeptic delivery |

## Values / principles cheat sheet (official names, from the values page you copied on 12 October)

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | No quoted sentence carries a story. Scaffold: a decision where the member's side differed from the internal one, with a named stake, what you did and what changed for them. If none comes to mind, say so plainly, then give the nearest thing your material carries, F2's "I handled the branch's formal complaints log", or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording is at fault | F7: "trained new tellers on our escalation script". Beat: the script and the tellers you trained. Answer slot: if the wording of the script changed because someone needed it twice, say what changed; if not, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold: something about your branch's town that a figure would not have shown, with what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log". Beat: you handled the log. Answer slot: if one complaint stayed with you to a fix, say what and what part was yours; if not, say so plainly |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R9 | "What would you most want from the person in this role that you don't get today?" | Puts the branch managers' needs first and shows you are pricing what you add |
| R10 | "Which of the four values is most tested in your branch right now?" | Turns the values round into a conversation about their daily work |
| R11 | "How are your teams hearing about the move to five hubs, and where could complaint handling help?" | Connects the brief to their branches, and they hold the local picture |
| R12 | "Is there a complaint your branch handled that you'd want handled the same way everywhere?" | Gives you a seam principle to build on rather than a seam to guess |
| R13 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for people who are peers of the supervisors you would coach |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "4+ years in financial-services customer operations" | A1, C4, I1 |
| "experience handling regulated complaints" | B1 |
| "Own the member complaints process end to end across branches and the contact centre" | B2, D1, H1, H2 |
| "report monthly on complaint volumes and resolution times" | F1, D3, J1 |
| "coach branch supervisors on escalations" | A5, C1, C4, I1 |
| "work with digital teams on self-service journeys" | D2, E1, E2, H2 |
| "confident presenting to senior leaders" | B3, D3 |
| "comfortable with Excel reporting" | F1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process. D1's slot stays inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: the material says formal complaints, not regulated ones. B1's slot asks only which rules the log answered to |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: the material says a monthly spreadsheet, not what it counted. F1's slot asks only what it counted |
| Coached supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: the material says new tellers, not supervisors. A5's slot stays with the tellers |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't presented above regional level." No slot |

## Sources

Provided documents: the JD; the Ashgrove values text you copied on 12 October 2026 from ashgrovecu.org/about/values; the recruiter's email describing the process; the four points you gave from the 2026 strategy brief; your background as you wrote it. No interviewer profile and no `tuesday-dossier.md` were supplied. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text is pasted and fixes the cheat sheet and the VAL questions; naming the page as its source does not make it a link to read |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes the loop: three rounds, who, how long, the case, and the values scoring. It fixes the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points are in hand and fix the CO bank and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The names and roles of the Head of Member Services and the two branch managers → an interviewer read, persona weights re-read from their public footprint, and a reverse question tied to each one's path
- The shape of the 20-minute case (written, role-played or discussed, and whether anything is sent ahead) → a case build specific to it in place of H1 to H3's practice patterns
- The complaint rules and regulator that apply to Ashgrove (the recruiter can say in one email) → B1, D1 and H1 guidance that can use the real timelines
- Your answers to the slots on F2, F3, F5, F7 and F8 → those rows can move from discovery or transferability to quoted stories, and the banks regenerate
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, recent organisational context, and the interviewers' public footprint once named
- Your hours available before 21 October → a prioritised prep schedule tied to question IDs
- A `tuesday-dossier.md` from a job-underwriter pass → evidence-derived objections and prohibited claims in place of the ones built here, never a precondition
