Research tier: L0 — no searches. This skill runs none.

I built this from the prose you pasted, not from your resume file. Each "current line" below is your own sentence, quoted exactly, and I dropped the first-person "I" to match resume style. If you paste or attach the actual resume, I'll re-trace every row against its real wording.

The reading I'd start from is that your strongest assets are the dbt models, the orders-mart star schema, and the test and fix work on the nightly job. Three of the four must-haves (3+ years of data engineering, production Python, orchestration) aren't evidenced as written, and no rewording closes that. Whether that makes the role worth applying to is job-underwriter's call, not this ledger's.

## The edit ledger

All rows are `resume_edits_pending_approval`. Nothing is applied.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models, including the core orders mart. Designed the orders mart's star schema with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your pasted background | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your pasted background | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE" (moved to the second bullet) | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your pasted background | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Line 1: "Added tests to our nightly dbt job". Line 2: "Fixed our nightly dbt job when it breaks". Both follow E3. | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your pasted background | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote some Python scripts to pull vendor APIs on a cron; used pandas for analysis" | `surface` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your pasted background | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below the Python bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your pasted background | pending your approval |

- **E1** keeps the three claims as three separate sentences, so "designed with the DE" doesn't merge into "owned the model".
- **E4** puts the test work first because it is your only evidence on data quality. Each half traces on its own.
- **E5** keeps "some" and "a cron". Dropping either would make an ad-hoc script read like a pipeline.
- **Headline:** it stays "Senior Data Analyst". I proposed no retitle (see below).

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | not_evidenced | No row can carry it. Adjacent work (E2–E4) is analytics-side; see A1. | `[grounded]` your background is 5 years as a Senior Data Analyst; `[generic]` a titled-years requirement is often screened against job titles |
| M2 | Production Python | must-have | not_evidenced | E5 surfaces the adjacent cron scripts, but nothing says they run unattended or that others depend on them. See C1. | `[grounded]` "some scripting to pull vendor APIs on a cron" is all that's stated |
| M3 | Airflow or equivalent orchestration | must-have | not_evidenced | Nothing in your background shows what schedules the nightly job. See C2; Airflow itself is A2. | `[grounded]` you have never used Airflow |
| M4 | Dimensional modelling | must-have | surfaced_by_edit | E1 and E3 bring up the star schema, "with our then-DE" kept. | `[grounded]` your pasted background |
| M5 | Data quality | important | surfaced_by_edit | E4 (tests added to the nightly job). | `[grounded]` your pasted background |
| M6 | Owning SLAs | important | not_evidenced | See C3. Fixing the job when it breaks isn't the same as owning a freshness commitment. | `[grounded]` no SLA or deadline appears in your background |
| M7 | Batch pipelines, including Spark | important | not_evidenced | The nightly dbt job is adjacent, so I haven't called it a pipeline you built or own. Spark is A2. | `[grounded]` you have never used Spark |
| M8 | Streaming (Kafka) | preferred | not_evidenced | A3. | `[grounded]` you have never touched Kafka |
| M9 | Partnering with analytics on requirements | important | already_evidenced | E3 shows you working with the DE on the mart. It shows you on the analytics side, which the resume shouldn't flip. | `[grounded]` your pasted background |

## Recovery per gap

**Recall prompts.** These may close a gap if you have the experience. The questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, plus some API-pull scripting on a cron. It doesn't say who depends on the output or what happens when a run fails. | The JD says "production Python", and a cron script is only that if someone relies on it. | A script that loads vendor data into Redshift tables other teams query; retries or alerting on failure; code in a reviewed repo; a script you were paged or pinged about | The repo, a README or runbook, a failure-alert message | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Airflow or equivalent orchestration | must-have | The nightly dbt job exists and you've fixed it, but nothing says what runs it. | The JD accepts "equivalent", so a scheduler you've worked with could count where "never used Airflow" would not. | The dbt Cloud scheduler; a CI or Jenkins workflow; cron on a server; an Airflow instance the DE ran that you edited or debugged | A job config, a schedule definition, a screenshot of run history | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Owning data quality and SLAs | important | Tests were added and the job was fixed, with no deadline or consumer named. | Data quality and SLA ownership are in the JD's task list, and your tests are the nearest thing you have. | A morning deadline a dashboard depends on; a freshness test or alert; a failure where you traced the cause and changed something afterward | The test list, a postmortem note, an alert config | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences.** These are gaps no recall prompt will fill.

| # | Requirement | Absence | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | 3+ years data engineering | You have 5 years in analytics and none titled or scoped as data engineering. | Only time, or a different route in. Two candidates are an analytics-engineering role that bridges the two, or an internal move that makes pipeline ownership part of your job. Your answers to C1–C3 may show some DE-shaped work already. | `[grounded]` your stated background; `[inferred]` the routes, from the gap between your work and the JD |
| A2 | Airflow and Spark | You have used neither. | A small public project: an Airflow DAG that orchestrates a dbt run, and a Spark job on a public dataset. It would give you something to show, not something to claim as work experience. | `[grounded]` you've never used either; `[generic]` what a small project does for a transition candidate |
| A3 | Kafka and streaming | You have never touched them. | It's a "plus" in the JD. Closing it isn't worth it before the must-haves, so I'd leave it as an honest gap. | `[grounded]` you've never touched Kafka; `[inferred]` priority from the JD calling streaming a plus |

## Not written, and why

- **A "Data Engineer" or "Analytics Engineer" headline.** Your title was Senior Data Analyst. A retitle has to be an equivalent, not an upgrade.
- **"Built and owned pipelines" or "batch pipelines".** You maintained and fixed a nightly dbt job. Ownership is a different claim, and the first interview question would test it.
- **"Orchestration", "Airflow-style scheduling" or "workflow management".** These are the JD's words, and nothing you've told me supports them for your history.
- **"Production Python" or "production-grade scripts".** Production isn't established yet (see C1).
- **"Owned data quality and SLAs".** You added tests. Ownership and SLAs are separate claims, awaiting C3.
- **"Led" or "owned" the orders-mart dimensional model.** You designed the schema with the then-DE, so E3 keeps that wording.
- **"Partnered with analysts".** You were the analyst, and the phrase would flip which side of the table you sat on.
- **Any mention of Spark, Kafka or streaming.** None is supported.

## Parse-safety check

Your background came as pasted text, so I couldn't check layout. That means columns, tables, text boxes, headers and footers, icons, section headings and file type are all unchecked. Send the file and I'll run those.

One x offer, which I'll build only if you say yes: a short plan for the A2 side project, scoped to something you could finish in a few weekends. It would give you something real to point at for the Airflow and Spark gaps.

## Upgrade menu

- **Your actual resume as a .docx or text-layer PDF:** every row gets re-traced to your real wording, and the parse checks run.
- **The dbt project or its docs and lineage page:** this would let me quantify E2–E4 from what the project shows, such as test counts and model dependencies, and move those rows toward `high` confidence.
- **The vendor-API scripts or their repo:** this settles C1 on evidence, not on your say-so.
- **A run history or job config for the nightly job:** this settles C2.
- **An incident note or alert config:** this settles C3.

## Questions

C1 — Do the vendor-API scripts run unattended, load data other people use, and alert someone when they fail? If so, who relies on them?

C2 — What actually schedules and runs your nightly dbt job (dbt Cloud, CI, cron, or something the DE built)? Have you edited or debugged that scheduler yourself?

C3 — Is there a deadline the orders mart has to hit each morning, or a freshness check or alert on it? What did you change after the last time it broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.