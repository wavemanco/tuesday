I've read the prep-pack playbook and I'm now running a small round of company research (values, interview process, strategy, a typical job posting) before I write the three-round pack.
I couldn't save the pack as a file because write permission wasn't granted. Web search was also refused, so no company research ran. The full pack is below, built from your role summary and background only.

# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Interviewer names aren't known, so there is no interviewer read.

| Round | When | Who | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

## How to use this pack

- Personas are how a question arrives. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive. JD is role-driven. CO is company and strategy knowledge. CASE is a live problem from the role.
- An answer slot is an instruction for the interview, not a question for you now. Each has two honest branches: say what you did, or say plainly it wasn't yours or never existed.
- Question IDs are unique across the pack. The letter F is kept for fit-snapshot rows.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role summary you pasted. Evidence is your own words, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, not two squads of eleven, and the words stay there: "I have nine years in engineering, three of them as a team lead of six." Answer slot: the role's two squads and eleven engineers make a probe on scale likely. If you have led more than the six, or work across more than one team, say what and how, in your own words; if not, say so plainly and stay with the team of six |
| F2 | Leading leaders rather than only individual engineers. The role summary doesn't state this, so it's a scope question a director or VP may raise — role-family expectation | "I've never managed managers" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never managed managers." Then how you would learn it, said as a plan and never as a past |
| F3 | "own delivery" — role summary | "pushed a reliability quarter through against roadmap pressure" — your message; "My team's on-call burden dropped 60%" — your message | medium | [grounded] | transferability | The quotes carry a reliability quarter and an on-call figure, not ownership of feature delivery. Hold the words at their scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: if tracking and committing delivery dates was also yours, say how; if not, say so plainly and stay with the reliability quarter |
| F4 | "hiring" — role summary | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | Lead with the quote in its own terms: you run the loop, and the figure counts interviews, not hires or offers. Expect a probe on what the loop covers and who decides, and add no words to the quote |
| F5 | "growth for 11 engineers" — role summary | none given | none | [grounded] | discovery | Nothing in your material shows or denies this. Answer slot: if you have helped an engineer grow, say who, what, and what was yours, in your own words; if not, or it wasn't yours, say so plainly and say how you would start |
| F6 | "partner with hardware ... on roadmap" — role summary | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past |
| F7 | "partner with ... product on roadmap" — role summary | "against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches roadmap pressure without showing whether it was a partnership with product. Answer slot: if you worked with product to settle that quarter, say how and what was yours; if there was no such partnership, or it wasn't yours, say so plainly and stay with the reliability quarter |

No row is a gate: the role summary states no term such as location, travel or authorization.

## Round 1: hiring manager (Director of Engineering, Tuesday, 45 min)

**Persona weights**

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live problems on the real roadmap | high | Hiring-manager prior: they're buying capability and expect live problems on their actual roadmap | Clarify, then objective, approach, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet, persistent probing of the gaps | high | Hiring-manager prior: they're derisking, and F6 and F2 are gaps you stated | Rehearse the single most predictable objection until it's boring; candor, no bluffing |
| Conversational | Biography and motivation opener | medium | A 45-minute round usually opens with the journey, and casual questions are still scored | A 90-second arc built only from your own sentences |

The highest-ROI prep in the whole pack is B1, the hardware-roadmap objection (F6). The director will ask it in some form, and it returns in rounds 2 and 3 in other packaging.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Hardware and product both want the same squad's next quarter. What do you need to know first, and how do you decide?" | CASE | [generic] | Structure it aloud: what you'd ask each side first, what objective the quarter serves, how you'd split the options, the risks, and what you'd record. It needs no claim about your past, so the guidance makes none. Challenge one premise respectfully | A live problem from the role's two-sided roadmap partnership, where F6 and F7 are thinnest |
| A2 | "You take over two squads and eleven engineers. Walk me through your first thirty days." | CASE | [generic] | Structure it: listen first, who you meet and in what order, what you read, what you decide not to change yet, what you tell the squads. It's a plan, never a past. Say what you don't yet know and how you'd find out | F1 is the jump from one team to two, so the director will want the plan |
| A3 | "You own delivery for these services. How do you tell, week to week, whether a squad is on track?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" | Describe the signals you'd watch as a method, in general terms. If you reach for your own past, keep to the quote: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you tracked delivery against dates or commitments, say how, in your own words; if there was no such tracking, or it wasn't yours, say so plainly and stay with the reliability quarter | F3 is your evidence for the delivery requirement, and the quote stops at the quarter |
| B1 | "You would be partnering with hardware on the roadmap. Which part of that would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Say it plainly first: "I've never owned a hardware-adjacent roadmap." Then give a plan, never a past: what you'd ask hardware leads in your first weeks and what you'd read before your first roadmap meeting. Hold through two follow-ups by returning to the plan, not to a claim of hardware experience. Concede specifically if pushed: you don't yet know how hardware dates move, and you'd learn it | F6 is a gap you stated, and the Skeptic goes straight to it |
| B2 | "Your team was six. This is eleven across two squads. What changes?" | JD | [grounded] "3 as a team lead of 6" | Say the scope at its own size: "three of my nine years as a team lead of six." Answer slot: if any of what changes is something you've already done at more than six, say what, in your own words; if not, say so plainly and describe how you'd adapt. Then say you'd want to learn from the director how the squads are structured | F1 is the scale jump |
| B3 | "Have you led through other leads, or only managed engineers directly?" | EXP | [grounded] "I've never managed managers" | Your material states the answer: "I've never managed managers." Say it in one breath, then give a plan: how you'd work with whoever leads each squad day to day, and what you'd ask the director about it. Never describe leading leads as a past | F2 is a stated gap the director may ask directly |
| B4 | "That on-call number dropped 60%. How was that counted, and how much of it was you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the words as you said them, including "after". Answer slot: say how the 60% was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours, each in your own words; if you don't know how it was counted, say so plainly. Hold through two follow-ups, and concede only what you're actually unsure of | F3 is a headline figure, and skeptics go to its assumptions first |
| C1 | "So, walk me through the journey. Why this move, and why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Build a 90-second arc from the sentence's own beats: nine years in engineering, three as a team lead of six, now at a payments company. Answer slot: why industrial IoT and device management, and why now, in your own words; if the reason is mainly the role itself, say so plainly | Motivation consistency is the first thing a skeptic cross-checks |

**Reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How are the two squads split today, and who runs each one day to day?" | Answers the leading-leaders question (F2) with facts, and shows you're thinking about structure |
| R1.2 | "What does success look like at ninety days and at a year?" | Gives you the scoring sheet for the role |
| R1.3 | "How do hardware dates and software commitments get negotiated today, and where does it hurt?" | Targets F6 directly and reads as diligence |
| R1.4 | "Is this a new seat or a backfill, and what did the previous setup teach you?" | Surfaces why the role is open without assuming anything |
| R1.5 | "How do you like to hear about problems: early and rough, or once I have a plan?" | Tells you how to work with your would-be boss |

## Round 2: panel (two staff engineers and a product manager, Thursday, 60 min)

**Persona weights**

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Reads your claims closely, asks for inputs and denominators | high | Panel blends each member's relationship prior; staff engineers are technical specialists, and D1 and D3 carry a figure and a method | Know what you can and can't say about how each number was counted, and say plainly when you don't know |
| Peer Evaluator | Seam-splitting, "what would you need from us", disagreement with equals | high | Staff engineers will sit beside you and are pricing what the hire adds to or takes from their load | Reciprocity: what you bring their squads; propose principles for the seam rather than pretending to know it |
| Values/Behavioral and Conversational | Scenario probes from outside the function | medium | The product manager is cross-functional, the prior for a scored behavioral conversation | Story-map from your own sentences; "we" for context, "I" for what you did |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said about 40 interviews last year. What does running a hiring loop cover for you, and what is that figure counting?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Keep the number on its noun: about 40 interviews, last year. Answer slot: say how it was counted, what it's sensitive to, the assumption behind it you'd defend least, and which part was yours; if you shaped hiring decisions, say how, and if the decisions were others', say so plainly. Return to the quote: you run the loop for backend roles | F4 is a headline figure, and a figure gets a defend-the-number question |
| D2 | "A bad configuration goes out to a fleet of devices in the field. How do you run the response, and what do you expect your engineers to have built beforehand?" | CASE | [generic] | Structure it: limit the damage first, find out what reached which devices, restore, tell the people affected, then a blameless review and what to build so it can't repeat. Say what you'd ask your engineers instead of pretending to out-know them. No claim about your past | Staff engineers will test whether you can lead a technical incident without faking depth |
| D3 | "How do you decide when a squad should pause roadmap work for reliability?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" | Say your method in your own words, then the quote at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you used criteria or data to make that call, say what they were; if it was judgment with no formal rule, or the call wasn't only yours, say so plainly and return to the quarter | F3 is the closest your material comes to a reliability trade-off |
| E1 | "Our engineers will have strong technical opinions. Where do you step in, and where do you stay out?" | JD | [generic] | Offer principles, not a past: you step in on priorities, people and trade-offs, and stay out of choices your engineers know better than you. Say plainly where your own technical depth stops and how you'd use theirs | Peer Evaluator's seam question |
| E2 | "Tell me about a time you disagreed with a senior engineer on direction." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a position you held, and a working relationship that was intact afterwards, told without detail you can't back. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it | Persona stem for disagreement with equals; none of your sentences carries a story for it |
| G1 | "Tell me about a time you held a roadmap line under pressure." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-map from the sentence: a reliability quarter, roadmap pressure, and on-call burden that dropped 60% after. Answer slot: if you negotiated it, say how and what was yours; if nobody pushed back on you directly, or it wasn't yours alone, say so plainly | F3 and F7 are where the PM will look at how you behave on the roadmap |
| G2 | "Product wants a feature and the squad says reliability debt. How do we decide together?" | CASE | [generic] | Structure it: what each side is protecting, what data would settle it, a time-box, who has the last word. Propose how the two of you would agree the rule in advance. No claim about your past | A live problem on the product partnership (F7), asked by the person on the other side of it |
| G3 | "What do you need from product to run a good quarter?" | JD | [generic] | Reciprocity framing: what you need from product and what you bring them. Offer principles, not a past, and ask the PM how they like to work | A collegial version of F7's partnership probe |

**Reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What could a new manager do in their first month that would genuinely help your squads?" | Reciprocity for the staff engineers: shows you're thinking about their load |
| R2.2 | "What part of the device-management stack would you most want a new manager to understand before touching the roadmap?" | Invites them to teach you, turning F6 into a learning conversation |
| R2.3 | "Where does technical debt hurt most right now, and how is the work to fix it protected?" | Connects to reliability without claiming it transfers |
| R2.4 | "How do trade-offs between product requests and reliability work get made today, and who has the last word?" | For the PM: shows you're already thinking about the seam |
| R2.5 | "How early do hardware constraints reach the software squads?" | Targets F6 as practical diligence |

## Round 3: VP Engineering (Monday, 30 min, values and leadership philosophy)

**Persona weights**

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Scenario probes on how you lead | high | The recruiter's own words name this round as values and leadership philosophy | Story-map from your sentences; use a scaffold with its honest branch where none carries a story |
| Case/Strategist | Altitude questions about where a manager's attention goes | medium | Executive prior; with no company research, these stay generic | Think aloud at the right altitude; say what you haven't read |
| Pressure | Time-boxed challenge on the two stated gaps | medium | Executive prior; F2 and F6 are the natural targets | Pause, restate, hold through two follow-ups, concede what's real |
| Conversational | Informal questions about day-to-day leadership | medium | Thirty minutes leaves room for a few, and casual questions are still scored | Short arcs; never treat it as unscored |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What is your philosophy of leading engineers?" | VAL | [generic] | Selection scaffold: choose one belief, one thing you do because of it, and one moment where it cost you something, told without detail you can't back. If no moment comes to mind, say so plainly, then give the nearest thing your material carries, or how you'd handle it. Describe what you do and let the VP draw the inference | The recruiter named this round as leadership philosophy; none of your sentences states one |
| H2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-map only the beats the sentence states: a reliability quarter, roadmap pressure, and the on-call result you quoted. Answer slot: say who the pressure came from and how it landed; if it came from team planning and not leadership, or the truth wasn't yours to deliver, say so plainly. If it's the wrong story for the question, give the nearest thing your material carries | Persona stem for values interviewers; F3 is the only quoted sentence near it |
| H3 | "Tell me about a time you helped an engineer grow." | VAL | [generic] | Selection scaffold: a specific engineer, a concrete change in what they did, and your part in it, told without detail you can't back. If no such time comes to mind, say so plainly, then say how you'd start a growth plan for the engineers in this role | The role names growth, and F5 has no quoted evidence |
| H4 | "What do you look for when you hire, and what have you learned from running loops?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start with the quote at its scope: you run the loop for backend roles, about 40 interviews last year. Answer slot: say what you look for and what you've learned, in your own words; if the loop's design wasn't yours, say so plainly and say what part you own. Never describe a change you made to the loop unless you made it | F4 is your strongest evidence for a role responsibility |
| I1 | "Software, hardware and product pull in different directions in a company our size. Where should an engineering manager's attention go?" | CASE | [generic] | Think aloud at the altitude of the question: where you'd put your own time, who you'd align first, what you'd refuse to carry. Say what you don't know about how this company is set up. No claim about your past | A skip-level altitude question; generic because no research ran |
| I2 | "What do you know about where Larkfield is headed?" | CO | [generic] | No company facts are in this pack, so none are supplied. Say what you've actually read; if it's little, say so plainly and ask what the VP would want a new manager to understand first. Don't recite a guess | The honest cost of having no research is that this stays generic |
| J1 | "Thirty seconds: why should we hire a manager who has never managed managers and never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers"; "never owned a hardware-adjacent roadmap" | Hold with what your quotes carry: "I have nine years in engineering, three of them as a team lead of six," and "I run our hiring loop for backend roles." Concede plainly: "I've never managed managers and I've never owned a hardware-adjacent roadmap." Hold through two follow-ups, concede only what's real, then give a plan for both gaps. Don't fold on the core claim to restore harmony | F2 and F6 together: the pressure version of the pack's highest-ROI objection |
| K1 | "How would the engineers on your team describe working for you?" | VAL | [generic] | Say only what you've actually heard from them, in their terms, and who said it. If you haven't heard much directly, say so plainly and say how you ask for it. Don't predict what they'd say | None of your sentences states what engineers have said |

**Reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What do you want engineering leadership to be known for here in two years?" | Shows you think at the VP's altitude |
| R3.2 | "Where do engineering managers here tend to struggle, and how does the company support them?" | Invites candor and signals you'll ask for help early |
| R3.3 | "How does the company develop first-time managers of larger teams?" | Raises the scale jump in F1 as a question about support |
| R3.4 | "How do software, hardware and product disagreements get resolved at the top?" | Targets F6 and F7 at the level the VP sees them |
| R3.5 | "What is a value you've had to defend under pressure here?" | Turns a values round into a story the VP wants to tell |

## Requirement coverage

| Requirement | Fit row | Question IDs | Reverse questions |
|---|---|---|---|
| Lead two squads building device-management services | F1 | A2, B2, D2, E1, I1 | R1.1, R3.3 |
| Leading leaders (not stated in the role summary) | F2 | B3, J1 | R1.1, R3.2 |
| Own delivery | F3 | A3, B4, D3, G1, H2 | R1.2, R2.3 |
| Hiring | F4 | D1, H4 | none, and why: hiring questions are asked of you, not by you |
| Growth for 11 engineers | F5 | H3, K1 | R3.2, R3.3 |
| Partner with hardware on roadmap | F6 | A1, B1, I1, J1 | R1.3, R2.2, R2.5, R3.4 |
| Partner with product on roadmap | F7 | A1, G1, G2, G3 | R2.4, R3.4 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed or led managers | Negative you stated, F2 | The plain acknowledgment: "I've never managed managers." No answer slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No answer slot |
| Cut on-call load by 60% on your own | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the quote says "after", not "because". B4's slot stays inside the quote |
| Ran hiring and made the hiring decisions | Inflated form of F4 | F4's quote at its own scope: you run the loop, and about 40 counts interviews. D1's slot stays inside the quote |
| Already led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: a team lead of six. The limit is the pack's observation, not words for you |

## Sources

Provided documents: the role summary and background in your message. No dossier was present. The loop rests on your own description, which gives three sessions and who runs each.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Search refused. It would have given a values cheat sheet with official value names |
| 2. Larkfield Systems interview process | unavailable | Search refused. It would have confirmed or corrected the round structure |
| 3. Larkfield Systems strategy and news | unavailable | Search refused. It would have grounded I1, I2 and the CO bank; they stay generic |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form |
| 5. Representative engineering manager JD | unavailable | Search refused. It would have produced quoted, inferred requirement rows beyond the short role summary |

Queries sent, all refused: "Larkfield Systems industrial IoT company values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems industrial IoT strategy news device management"; "Engineering Manager industrial IoT device management platform job description hardware product roadmap".

## Upgrade menu

- The full job description text → F1 to F7 become exact quotes, and any requirement the summary leaves out gets a question
- The recruiter's notes on each round, including whether the panel has a presentation, case or take-home → focus areas and any graded deliverable get their own build section
- Interviewer names or profile links → an interviewer read, persona weights tuned to each person's public footprint, and a reverse question tied to their career path
- Larkfield's published values page, pasted or linked → a values cheat sheet for the VP round with each official value mapped to one of your quoted sentences
- Permission to run web search, or a pasted strategy brief → a grounding brief and strategy-based CO and CASE questions for rounds 1 and 3
- Your answers to the answer slots, stated outside a drill → the fit-snapshot rows they touch are regenerated with your own words
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and constraints on what each answer may claim

Say the word and I'll play the Skeptic on B1, the hardware-roadmap question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, once file writing is permitted.

Can you paste the full job description? I built this from the short role summary, and I can proceed without it, but the full text would turn the inferred rows into exact quotes.
Did the recruiter announce focus areas or a deliverable (presentation, case, take-home) for any round, especially the panel? That would add a dedicated build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.