Web search was denied, so the pack runs on your dossier alone. I'm now writing the prep pack for Thursday's hiring-manager round.
Writing to the working directory wasn't permitted, so I'll save the pack in the session scratchpad instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-4-denied-77f167ad/b173480f-5963-4fed-97c0-7c409e0813ff/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's in the session scratchpad because writing to the working directory wasn't permitted. It has 20 questions and 6 reverse questions, and it's built for a single 45-minute hiring-manager conversation using only your dossier.

- **No Quartzline research:** all three web searches (values, interview process, strategy) were refused. The pack asserts nothing about Quartzline's values, loop or strategy, and it has no company-strategy questions. The Sources section lists each refused search.
- **Highest-ROI prep:** question A1, "You haven't held a PM title or owned a roadmap — why you over a PM with three years of the job?" It's the objection your dossier named. The answer concedes in the dossier's own words, then states the 30+ integrations and the playbook at exactly their stated scope, and gives a ramp plan.
- **Roadmap ownership gets no bridge.** Your dossier marks it as a plain acknowledgment, so the pack coaches that and nothing more.
- **Answers only you can give:** the pack doesn't write these for you. They are marked as answer slots in the guidance, and covered are:
  - Agile delivery
  - API docs and schemas
  - adoption metrics
  - what happened to the roadmap-input sessions' output
  - how the 30+ figure was counted
- **R2 (shipped API or platform products):** your dossier gives it no strategy. I classed it as adjacent work and kept the answer at the integrations you led, without claiming a shipped product.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live. I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- Round: hiring manager, one 45-minute conversation, Thursday (interviewer's name not given)
- Built from: your tuesday-dossier.md (v1.1) and your message. No company research ran: the web searches were refused (see Sources), so nothing here asserts a fact about Quartzline's values, loop or strategy.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: where a cell says "answer slot", the content has to come from you, in your own words, and either honest branch is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows a company's published values |
| EXP | Whether a claim about your work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI prep is A1. The underwriter named that objection, and it will be asked in some form.

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`. Evidence cells quote the dossier's `verified_candidate_evidence`, in list order (entries 1 to 3). Confidence notes from the dossier (entry 1 high and inspectable, entry 2 high and inspectable, entry 3 medium, confirmed with limited inspectable proof) are carried in the Confidence column and the bridge text, never inside a quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [grounded] | transferability | Underwriter strategy: bridge, positioned as adjacent and never as PM experience. Words stay at the quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is said plainly, sourced from `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title or role." Then a ramp plan, said as a plan and never as a past |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile, responsibilities | none given | none | [grounded] | capability | Underwriter strategy: acknowledge_gap, recorded in `uncertain_or_weak_areas` as "Owning a roadmap and prioritization authority (R1 sub-claim)". No bridge. Words, sourced from `prohibited_claims: "Having owned a product roadmap"` and `prohibited_claims: "Having set prioritization for an engineering squad"`: "I haven't owned a product roadmap." and "I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan. The underwriter closed the bridge on this row, and this pack does not reopen it |
| F3 | "Shipped API or platform products" — dossier role_profile, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | medium | [grounded] | transferability | The dossier gives R2 no strategy, so this call is the pack's own observation: your material says client integrations led and a playbook written, and does not say a product was shipped. Words stay at the quotes: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: expect a probe on the go-live end of what you led. If any go-live was of something other teams built on, say what it was and which part was yours; if they were client projects, or not yours to put live, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | low | [grounded] | discovery | The quotes touch API work without showing docs or schemas. Answer slot: expect a probe on API docs and schemas themselves. If you read, wrote or reviewed any, say which and what part was yours, in your own words; if the work did not involve them, say so plainly and stay with the architecture and UAT stages in the quote |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [grounded] | transferability | The quotes show clients and product. They do not show engineering or sales. Entry 3 is confirmed with limited inspectable proof, so expect a probe and volunteer the limit before it is extracted. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you worked with engineering or sales on these, say who and on what; if the work was with clients and product only, say so plainly |
| F6 | "Agile delivery experience" — dossier role_profile, preferred | none given | low | [grounded] | discovery | Underwriter strategy: clarify, listed as "Agile delivery inside a product org (R5)". No verified entry speaks to Agile delivery, so nothing is quoted. Answer slot: if you have worked in Agile delivery, say how, in your own words; if you have not worked that way, say so plainly, and say what you would want to confirm about how this team defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile, responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | medium | [grounded] | transferability | The quote says clients of the vendor's APIs, and the JD says integration partners, so the words stay on clients. Answer slot: expect a probe on whether the people you scoped with were partners in the JD's sense. If they were, say so; if they were clients using the vendor's API, say so plainly and stay with the scoping and requirements stages in the quote |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile, responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | low | [grounded] | discovery | The quote names requirements and go-live and does not show specs written for an engineering squad. Answer slot: if you wrote specs for engineers, say what and for whom; if requirements reached engineers some other way, or someone else wrote them, say so plainly and stay with the stages in the quote |
| F9 | "Define and track adoption metrics" — dossier role_profile, responsibilities | none given | none | [grounded] | discovery | Your material does not show adoption measures either way. Answer slot: if you defined or tracked any adoption measure, say what was counted and how, in your own words; if you did not, say so plainly and say what you would want to know first |

## Persona table

Weights rest on the hiring-manager relationship prior. Your message establishes the loop as this one conversation. No interviewer profile exists, so no signal adjustments apply. No values-style round is detected, because no loop source documents one.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the missing PM title, roadmap ownership and Agile | Top. The hiring-manager prior favors it, and the underwriter named a specific objection. Bank A, 5 questions | Rehearse the A1 objection until it is boring. Bridge only from the three confirmed entries, with the limit said plainly, plus a ramp plan |
| Case/Strategist | Live problems from the role: a blocked partner, a flat adoption curve, two squads wanting the same capacity | Top. The hiring-manager prior favors it, and the JD's unknowns (decision rights, adoption baseline) give it material. Bank B, 5 questions | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully per case |
| Data-Driven Prober | Defend the number, the docs and schemas, the adoption metrics | Mid. The 30+ figure and the adoption responsibility invite it, but nothing says the interviewer reads this way. Bank C, 3 questions | Say plainly how a figure was counted, or that you do not know. Name the assumption you would defend least before they do |
| Peer Evaluator | The seam between this PM and the two squad leads, and credit across teams | Mid. Squad-lead authority is the dossier's top unresolved risk, and a hiring manager may test the seam collegially. Bank D, 3 questions | Offer seam principles instead of pretending to know the seam. Show spine and tact together |
| Conversational | The opener ("walk me through the journey") and a casual question about tooling | Low to mid. A 45-minute opener is likely, though it carries fewer scored probes. Bank E, 2 questions | A pre-scripted 90-second arc. Treat casual questions as scored |
| Pressure | Time-boxed "why you over a PM who has done this" | Low. Nothing in the material signals a stress style. Bank F, 2 questions | Pause, restate, hold the position through two follow-ups, concede only what is specific |
| Values/Behavioral | Scenario probes against published values | Low. No published values were read and no values round is detected, so there is no bank. D2 and D3 carry the behavioral stems | Selection scaffolds that end in the honest branch |

## Question banks

Requirement coverage, checked against the JD lines in the fit snapshot:

| Requirement | Covered by |
|---|---|
| 3+ years product management experience | A1, A2, E1, F1 |
| Own the roadmap for the partner-facing API platform | A1, A2, B2, D1 |
| Shipped API or platform products | A3, C1, F2 |
| Technical fluency: API docs, schemas | C2, E2 |
| Stakeholder management across engineering, sales, customers | D1, D3, A5 |
| Agile delivery experience | A4 |
| Run discovery with integration partners | B5 |
| Write specs and drive delivery with two engineering squads | B1, B4, A4 |
| Define and track adoption metrics | C3, B3 |

No question is CO-tagged: with research refused there is no source for Quartzline's strategy, so a CO bank would be invented. The upgrade menu says what unlocks it.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't held a product manager title or owned a roadmap. Why should we hire you into this role instead of a PM with three years of the actual job?" | JD | [grounded] dossier likely_interviewer_objections; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"`; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The underwriter named this objection, and it gets the deepest rehearsal. Four beats. 1) Concede first, in the sourced words: "I haven't held a product manager title or role, and I haven't owned a product roadmap." 2) Say what you did, at the quotes' scope and no wider: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I wrote the internal integration playbook my team uses." 3) Name the limit before it is asked for: this is adjacent work, and you are not presenting it as product management. 4) Ramp plan, said as a plan: in your first weeks you would sit in on partner discovery, read both squads' backlogs, and agree with the squad leads which decisions are yours alone. Follow-up 1, "what is different about doing it as the PM?": go back to the quotes, and say roadmap and prioritization are the parts you have not done. Follow-up 2, "a PM with three years would ramp faster": concede it specifically, on roadmap ownership and squad prioritization, and do not concede the quoted work. Hold the adjacent case through both follow-ups. Describe what you did and let them draw the inference | F1 and F2 are the biggest gaps, and the underwriter derived this objection from evidence you confirmed. JD because it scores the stated requirement, Skeptic because of the delivery |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas`: "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"` | The strategy on this area is acknowledge_gap, so the answer is a plain acknowledgment plus a ramp plan, and never a bridge. Name it directly: "Owning the roadmap and prioritization. I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp plan as a plan: ask the squad leads where decisions sit today, learn each squad's constraints, and decide who to sit with first. Do not follow the acknowledgment with "but I did X" | F2 is the row this question lands on. It is a persona stem, asked of the one requirement the underwriter found no evidence for |
| A3 | "The role needs someone who has shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote says: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: expect a probe on the go-live end of what you led. If any go-live was of something other teams built on, say what it was and which part was yours, in your own words; if they were client projects, or not yours to put live, say so plainly and return to the integrations you led. Do not widen "led integrations" into a product claim | F3 is a must-have and the dossier gives it no strategy, so the honest answer stays at the quote's scope. JD because it scores a stated must-have |
| A4 | "The JD lists Agile delivery experience. How would you describe yours?" | JD | [grounded] | Nothing in your confirmed material speaks to Agile delivery, so no past is coached. Answer slot: if you have worked in Agile delivery, say how, in your own words, including your part in it; if you have not worked that way, say so plainly, and say what you would want to confirm about how this team defines it. Both branches are fine | F6 is a clarify area: the evidence may exist and was not established. JD because it scores a stated requirement |
| A5 | "Walk me through those quarterly roadmap-input sessions, and what happened to what you fed to product." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on the quote's beats: the sessions were quarterly, they were roadmap-input sessions, and they fed client evidence to product. Tell those in your own words. This entry is confirmed with limited inspectable proof, so volunteer the limit before it is extracted: say it is your account, and if there is a written trace of a session, offer it. Answer slot on product's side: if you saw what product did with it, say what, in your own words; if you did not, or it was product's decision and not visible to you, say so plainly and stay with the sessions you ran. Do not describe these as owning or setting the roadmap | F5 carries this entry at medium confidence, and the dossier flags it for a probe. EXP because it tests what was actually yours |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says a missing field in the API is blocking their go-live, and one squad lead says it isn't on this quarter's plan. What do you do, and what do you write down for the squad?" | CASE | [generic] | Clarify first: how many partners are affected, what workaround exists, what the field is for. Then the objective, the options (workaround, swap scope, escalate), and who decides, which you ask and do not assume. Write down a short problem statement, the partner evidence, the decision needed and by whom. Close with risks and what you would measure. Think aloud, and challenge one premise respectfully, for example whether "not on the plan" means capacity or priority. The question needs no claim about your past, so the guidance makes none | F8 and the decision-rights unknown are tested together. CASE because it is a live problem from the role |
| B2 | "Sketch how you'd decide what goes on the partner API roadmap next quarter. What do you need to know first?" | CASE | [generic] | Say your framework aloud before using it. First questions: who decides what, how adoption is measured today and the baseline, what partner evidence exists, and each squad's capacity. Then criteria, trade-offs, and how the squad leads are brought in. Keep it as a method. Do not borrow the roadmap-input sessions as roadmap ownership | F2 is the gap this question presses. CASE because it asks for structure on a problem from the role |
| B3 | "Partner API adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Ask first how adoption is defined and measured and what the baseline is, since that is an open unknown in the dossier. Then segment partners (new or existing, by integration stage), list hypotheses (docs, auth, onboarding, missing endpoints, partner priorities), say what data would separate them, and name the first check | F9 and the dossier's adoption-baseline risk. CASE because it is a metric-drop diagnosis |
| B4 | "Two squads each want the same capacity: one for an endpoint a partner asked for, the other for platform reliability. How do you decide?" | CASE | [generic] | Ask what the decision rights are and who breaks ties. Name your criteria (partner impact, risk of not doing it, cost of delay) and how you would test them with the squad leads. Show you would bring evidence to the leads and not just a request. Say that the answer depends on facts you would gather first | F2 and F8. CASE because it is a trade-off problem set in the role |
| B5 | "Design a discovery plan to find out why integration partners stall before go-live." | CASE | [generic] | Objective first, then who to talk to (partners at different stages and the people who support them), the method, what you would look for, how findings become evidence for the squads, and the risk of hearing only the loudest partners. The guidance makes no claim about your past | F7. CASE because it is a live design problem from the role |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ end-to-end integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words, and the pack supplies none: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do. The dossier records the integration playbook as the inspectable backing for this entry, so offering to walk through it is available to you | The 30+ figure is the headline number in F1 and F3. EXP because probers test whether a number survives |
| C2 | "The role calls for fluency in API docs and schemas. Where does that show up in your work?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The quotes name architecture and a playbook. Say those at their scope. Answer slot: if you read, wrote or reviewed API docs or schemas, say which and what part was yours; if the work did not involve them, say so plainly, and say what you would read first on day one | F4 is an important requirement with only adjacent evidence. JD because it scores a stated requirement |
| C3 | "The role defines and tracks adoption metrics. What have you tracked?" | JD | [grounded] | No quote speaks to this, so no past is coached. Answer slot: if you defined or tracked an adoption measure, say what was counted and how, in your own words; if you did not, say so plainly, and say what you would want to know first, which is how adoption is measured today and the current baseline (reverse question 2). Do not name a metric you did not track | F9 is a responsibility with no evidence either way. JD because it scores a stated responsibility |

### Bank D: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our two squad leads have strong views on their own roadmaps. Where's the seam between your decisions and theirs, and what happens when you disagree?" | JD | [grounded] `prohibited_claims: "Having set prioritization for an engineering squad"` | Offer seam principles instead of pretending to know the seam: settle who decides before the conflict, bring evidence and not just a request, agree an escalation path. Then ask what the current split is (reverse question 1). The plain acknowledgment is sourced: "I haven't set prioritization for an engineering squad." For reciprocity, say what you would do for each squad lead, as a plan, and claim no track record at it | The dossier's top unresolved risk is decision authority against the two squad leads (F2). JD because it scores the stated responsibility |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold. Pick a time work crossed teams, and it needs a named contribution of yours and an outcome where the relationship held. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the peer style, and a behavioral probe that carries no published values here. F5 is the nearest row |
| D3 | "Tell me about a time you disagreed with an engineering or sales counterpart about what to do next." | JD | [generic] | Selection scaffold. Pick a disagreement with a named stake, what each side wanted, what you did, and how it ended and the working relationship afterwards. Use "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 shows no engineering or sales evidence, and the JD names both. JD content with a behavioral delivery |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: how did you get from client integrations to wanting a product role?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"` | A 90-second arc with three factual beats, each at its quote's scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "I wrote the internal integration playbook my team uses"; "I ran quarterly roadmap-input sessions feeding client evidence to product." Say the third as sessions and not as ownership, and volunteer that it is your account. Then the limit in one sentence: "I haven't held a product manager title or role." The last beat is your reason for this role and why now. The pack cannot supply it, so write one or two sentences and say them aloud twice | This is the opener most likely to start the conversation. F1, F3 and F5 supply the beats. EXP because it tests the story behind the CV |
| E2 | "What are you actually playing with in API docs and schema tooling these days?" | JD | [generic] | Selection scaffold. Pick something real you used or read recently that bears on API docs or schemas. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would explore first | F4 again, asked casually. Casual questions about a JD topic are still scored |

### Bank F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who's already done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Pause and restate the question. Give two beats from the quotes, at their scope, and the sourced limit: "I haven't owned a product roadmap" (`prohibited_claims: "Having owned a product roadmap"`). Hold the position through two follow-ups by returning to the same quotes. Concede only what is specific and sourced. Do not fold on the quoted work to restore harmony, and do not argue that it proves you would succeed | F1 under time pressure. A persona stem that tests whether you hold the bridge without inflating it |
| F2 | "Thirty-plus integrations: how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on the quote's own verb: you led them. Answer slot: of the stages in the quote (scoping, requirements, architecture, UAT, go-live), say which you ran yourself and which involved others, in your own words; if some were someone else's, say which, plainly. Hold through two follow-ups, then concede the specific shares you named | F1 and F3 rest on this entry. EXP because attribution is what the question scores |

## Reverse questions

Questions 1 and 2 come from the dossier's `questions_for_employer` and `opportunity_risks_to_validate`.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority over the two squads and the dossier found no evidence for it. The answer decides whether you can do the job, and the question reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption metrics as a responsibility and states no baseline. The answer tells you what you would be held to |
| 3 | "What would a strong first 90 days look like for someone who comes from integrations and not from a PM seat?" | It puts your ramp plan on the table and shows how much ramp they expect |
| 4 | "How do the two squads divide the platform today, and where does work cross between them?" | It maps the seam that D1 and B4 probe, from their side |
| 5 | "How does partner feedback reach the roadmap today, and where does this role sit in that?" | It shows where discovery output goes and who owns that path |
| 6 | "What would make you hesitate about hiring someone who hasn't held the PM title?" | It invites the A1 objection in your own time, so you can answer it with the hold-then-concede structure |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Entries 1 to 3 come from the dossier's `prohibited_claims`.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims: "Having held a product manager title or role"` | F1's quote at its own scope, plus the plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier `prohibited_claims: "Having owned a product roadmap"`, and the acknowledge_gap area on F2 | The plain acknowledgment: "I haven't owned a product roadmap." No bridge, no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims: "Having set prioritization for an engineering squad"` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No bridge, no slot |
| Setting or deciding what went on the roadmap through the roadmap-input sessions | Inflated form of F5's sessions quote | F5's quote at its own scope. The limit is the pack's observation, not words for you: your material says the sessions fed client evidence to product, not what product decided with it |
| Having shipped an API or platform product | Inflated form of F1 and F3 against R2 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says client integrations led and a playbook written, not products shipped. A3's slot stays inside that scope |

## Sources

- Provided: your tuesday-dossier.md (dossier_version 1.1, job-underwriter, 2026-08-14), consumed. Sections used: `handoff_to_mock_interview` (all fields) and `role_profile` (requirements, responsibilities and unknowns, standing as the JD). The `decision` section was read as context only. No `evidence_map`, `evidence_state` or `risk_register` section was present. The "seven years" figure appears only in the decision prose and in no verified entry, so it is not used anywhere in this pack.
- Provided: your message (hiring-manager round, one 45-minute conversation, Thursday).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused (permission not granted), so nothing came back from any of them:

- "Quartzline company values principles" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Search refused. It would have fed a values cheat sheet if a values-style round were documented, and VAL questions. Nothing moved |
| 2. Quartzline interview process, product management | unavailable | Search refused. It would have checked persona weights against a documented loop. Weights rest on the hiring-manager prior and your message |
| 3. Quartzline strategy or recent news | unavailable | Search refused. It would have fed CO questions and a grounding brief. No CO bank exists |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative role JD | skipped | The dossier's `role_profile` supplies the requirements the snapshot and JD questions use |

## Upgrade menu

- Search access, then a rerun of the three refused searches → Quartzline's values, documented loop and current strategy: CO questions and a grounding brief appear, persona weights get checked against the loop, and a values cheat sheet appears if a values round is documented
- Deep research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes, needs the same search access) → a strategy brief for the differentiator questions and the interviewer's published themes if a name is known
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email → focus areas and any announced deliverable, with a build section for each
- How much prep time you have → a triaged schedule that sequences A1 first
- Your answers to the slots in F3, F4, F5, F7, F8 and F9, said outside a drill → each answer is quoted into the snapshot and the rows that draw on it regenerate
- Notes or a deck from one of the roadmap-input sessions → the entry behind A5 and F5 moves from medium toward high confidence, and the probe loses its seam
