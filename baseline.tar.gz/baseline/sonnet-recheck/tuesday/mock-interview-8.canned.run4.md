The write to the working directory was declined, so I'm saving the pack to the session scratchpad instead. Same content, different path.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-8-canned-b59f8f25/f9a56b0a-2699-4297-ab46-5b4032d0da42/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. The write to the working directory was declined, so it's in the session scratchpad.

- **Build:** The pack has a shared fit snapshot, then a separate bank and set of reverse questions for each of the three rounds on 21 October. It also has a values cheat sheet for the panel, a requirement-coverage table, and a list of claims it won't coach. It's built only from what you gave me, with no searches.
- **Interviewers:** No interviewer names are assigned yet, so there's no interviewer read.
- **Strategy brief:** The strategy-brief material rests on the four points you relayed, not the document itself.
- **Date:** I worked from your 12 October date. My system clock says 5 November, which would put 21 October already behind us. If that's the case, the pack needs rethinking.
- **Highest-ROI prep (D1):** rehearse the "you haven't worked in a contact centre, yet this role owns complaints across branches and the contact centre" question until it's boring. The pack gives a four-level answer: concede first, state what you hold, then a plan, then two follow-ups.
- **Second priority (D3):** the "you haven't presented above regional level" question.
- **Answer slots:** Where your material is silent, the pack gives you an answer slot, not a story. These are on complaint ownership beyond the log, what the spreadsheet counted and whether it was Excel, supervisor coaching, digital-team work, and regulated complaints. Answer them honestly in your own words. If you tell me your answers, I'll fold them in and rebuild those rows.

Offers, none required:
- I can play the Skeptic on D1 as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed.
- I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode, three rounds on 21 October 2026: the recruiter (30 min), the Head of Member Services who would be your manager (45 min, mostly behavioural), and a panel of two branch managers (60 min: a 20-minute complaint-escalation case, scored against the four published values). No interviewer names are assigned yet, so there is no interviewer read. The pack is built from your JD, the pasted values page, the recruiter's email, your description of the June 2026 strategy brief and your own message. No searches were run.

## 1. How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Every question carries both.
- Types: VAL = behavioural or values alignment, tested against the published values. EXP = work-experience deep-dive, whether your claims survive scrutiny. JD = role and JD-driven. CO = company and strategy knowledge. CASE = a live problem set in the role.
- Guidance is scaffolding, not a script. Words in quotation marks are wording drawn from your own sentences. An answer slot is an instruction for the interview, not a question for you: answer it from your own experience, or say plainly it was not yours.
- Question IDs run by persona: A and B are round 1, C to E round 2, G to J round 3. Fit snapshot rows are F1 to F9.

## 2. Prep triage (nine days, 12 to 21 October)

1. Days 1 to 3: D1 aloud until it is boring. It is the highest-ROI prep in the pack: the contact-centre gap meets the JD's headline line, and a rehearsed, non-defensive answer changes the round-2 conversation.
2. Days 3 to 5: D3 and H3 (reporting upward), then two timed 20-minute runs of H1 and H2 for the round-3 case.
3. Days 5 to 7: choose your real examples for the scaffolds in G1, G3 and C3. The pack cannot supply them and does not try.
4. Day 7: write your honest answers to the answer slots under F1, F3, F4, F5, F7 and F9. Anything you tell me outside a drill enters the fit snapshot and the affected rows are rebuilt.
5. Day 8: A1 and A5 for round 1, and the reverse questions for all three rounds.

Everything else is insurance.

## 3. Grounding brief

| Fact | Source | Provenance | Where it surfaces |
|---|---|---|---|
| Member-owned, about 900 staff | JD | [grounded] | A4, A2 |
| Move 40% of member service to digital channels by 2028 | June 2026 strategy brief, as you relayed it | [grounded] | A4, E1, round 2 reverse questions |
| Consolidate eight branches into five hubs over 2027 | June 2026 strategy brief, as you relayed it | [grounded] | A4, E2, round 3 reverse questions |
| Small-business lending product in Q1 2027 | June 2026 strategy brief, as you relayed it | [grounded] | A4 only: it touches no JD requirement, so it earns no case |
| Main competitive pressure is app-only banks | June 2026 strategy brief, as you relayed it | [grounded] | A4, E1 |

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If you followed complaints past the log, say which steps were yours, in your own words; if the log was the part you held, or the rest was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says a monthly complaints spreadsheet; whether it showed volumes and resolution times is not in your material. Answer slot: the JD names those two measures, so expect a probe on what the spreadsheet counted. If it counted either, say which and how, in your own words; if it did not, or you did not set what it counted, say so plainly and stay with having built it |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the script, not supervisors: "I trained new tellers on our escalation script." Answer slot: if you ever walked a supervisor through an escalation, say how, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team, say what it was and what part was yours; if you have not, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | The quote already meets the years in role-relevant terms. A claim in your own message with nothing inspected behind it, so expect a probe on what the branch role covered; say it as the quote does |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The JD says regulated; your material says formal. Answer slot: if the log came under an outside body's complaint rules, say which rules, in your own words; if you do not know whether it did, or it did not, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then a plan for the first report, said as a plan. Never a claim to confidence you cannot evidence |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel; the derivation is that a monthly complaints spreadsheet may be Excel. Answer slot: if it was built in Excel, say so; if it was another tool, say that plainly and stay with having built it |

## 5. Requirement coverage

| Requirement | Questions |
|---|---|
| Own the complaints process end to end across branches | D2, H1, J1 |
| ...and the contact centre | B1, B2, D1 |
| Report monthly on complaint volumes and resolution times | D4, H3 |
| Coach branch supervisors on escalations | C2, H2 |
| Work with digital teams on self-service journeys | E1, C4 |
| 4+ years in financial-services customer operations | A1, A3 |
| Experience handling regulated complaints | B3 |
| Confident presenting to senior leaders | D3, C3, H3 |
| Comfortable with Excel reporting | D4 |
| The four published values | G1 to G4, A2 |

## 6. Round 1: recruiter screen (30 min)

Persona weights, from the recruiter-screen prior (Conversational plus a light Skeptic) and the loop source you gave me, the recruiter's email.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; casual questions that are still scored | Top, 5 questions. Recruiter-screen prior; the risk is treating it as unscored | A 90-second arc for the biography question (A1); treat every casual question as scored; use the reverse-question slot |
| Skeptic (light) | Knockout and gap checks in a friendly register | Lower, 3 questions. Prior for a screen; F2 and F8 are the gaps a screen would check | Say the gap first and plainly, then the plan |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Tell it in the order the quotes give it: six years in retail banking, the last three as a branch supervisor; then the three things you can name, each in those terms and no more: the complaints log you handled, the new tellers you trained on the escalation script, the monthly complaints spreadsheet you built. Close on why this role, in your own words; the pack cannot supply your reason. About 90 seconds | The standard opener for a screen, and the only place the whole story is told in one breath (F6, F1, F4, F3). EXP because it asks what you did |
| A2 | "Which of our four values feels most like how you already work?" | VAL | [grounded] | Choose the value that is truest, not the one that sounds best. Say it by its name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) and give one sentence of why, in your own words. If you reach for an example, use one from the cheat sheet in section 9. The panel scores against all four, so a value with no example behind it will be tested | The recruiter's email says the third round is the values round, so a screen is where the names are first used. VAL because it tests the published values |
| A3 | "What does your day-to-day look like as a branch supervisor?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Name what your material carries: the complaints log you handled and training new tellers on the escalation script. Anything else about the job, such as rota, targets or team size, is yours to add only if it is true and you can stand behind it; the pack does not know it. Keep it to 60 seconds | A screen checks that the role you hold matches the claim in F6, and the cheapest way to fail is to over-describe it. EXP because it tests what you actually did |
| A4 | "What have you noticed about where Ashgrove is heading?" | CO | [grounded] | Use the brief's own terms: 40% of member service to digital channels by 2028; eight branches into five hubs over 2027; a small-business lending product in Q1 2027; app-only banks as the main competitive pressure. Pick the two that touch complaints and say what each means from a member's side, which is the first value's test. Do not recite all four | Strategy fluency at the altitude of a screen. CO because it tests homework. Rests on your description of the brief, not the document |
| A5 | "What are you looking for next, and what is your notice period and pay expectation?" | JD | [generic] | These are facts only you hold: notice period, pay expectation, start date, dates you cannot do. Settle them beforehand. The posting you gave me states no pay, so ask the range (see this round's reverse questions) before you name a number | Logistics and knockout checks are standard in a screen. JD because it tests the terms of the role. No fit row applies |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers the contact centre as well as branches. What is your experience there?" | JD | [grounded] "Never worked in a contact centre" | Say it first and plainly: "I haven't worked in a contact centre." Then stop and let them respond. Then the plan, as a plan: the first two things you would find out about how complaints reach the centre, and who you would ask. No sentence about the centre is a claim about your past. Under 60 seconds | F2 is the gap a screen names first, and saying it before being asked is the move. JD because the line is in the posting |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick the one that is truer for you and say it in the quote's own scope: "I haven't worked in a contact centre," or "I haven't presented to anyone above regional level." Then the plan in one sentence. One is enough unless they ask for another; do not dress either as a strength | A persona stem that finds the biggest gaps (F2, F8) directly. JD because it scores honest self-assessment against the posting |
| B3 | "Tell me about your experience with regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Start with the words you have: "I handled the branch's formal complaints log." Answer slot: the JD's word is regulated and your material says formal. If the log came under an outside body's complaint rules, say which rules, in your own words; if you do not know whether it did, or it did not, say so plainly and stay with the log you handled | F7 is the one requirement a screen can check against a checklist. JD because it scores a stated requirement |

### Round 1 reverse questions

| Question | Why it lands |
|---|---|
| "Who owns complaints today across branches and the contact centre, and what is changing in that?" | Shows you read the JD's end-to-end line as a structure question, not a title |
| "When the third-round panel is assigned, could you share who is on it?" | Interviewers beyond their roles are not assigned yet; names unlock an interviewer read |
| "What does the 20-minute escalation case look like: real or fictional, and is there material beforehand?" | The recruiter's email names the case but not its format; the answer shapes H1 to H3 |
| "What is the pay range, and what is the decision timeline?" | The posting you gave me states neither, and a screen is where those are asked |
| "How does the digital team's self-service work connect to this role day to day?" | Scopes F5 honestly: you learn what is expected before round 2 |

## 7. Round 2: Head of Member Services, your would-be manager (45 min)

Persona weights, from the hiring-manager prior (Case/Strategist plus Skeptic), moved by the recruiter's note that this round is mostly behavioural. Values/Behavioral and Skeptic therefore sit level at the top, with the Case/Strategist lowest.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the published values; STAR-shaped stories | Top, 4 questions. The email says mostly behavioural | Map a story to a value where a quote carries one; otherwise use the scaffold and its honest branch; "we" for context, "I" for contribution |
| Skeptic | Quiet, persistent probing of the gaps: contact centre, end to end, reporting upward | Top, 4 questions. A manager buys capability and prices the gaps (F2, F8, F1) | Rehearse the one predictable objection (D1) until it is boring; concede plainly, then a plan |
| Case / Strategist | A live problem from the actual roadmap | Lowest, 2 questions. Prior is high for a manager, but the email says mostly behavioural | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | The quote carries the log and nothing about an outcome, so the story is yours to choose. If one fits, pick a complaint from the log you handled with a named stake, what you held onto, and how it ended; use "I" for your part and "we" for the context. Answer slot: if you saw it past the log to a fix, say which steps were yours; if the log meant recording and passing on, or the fix was not yours, say so plainly and stay with the log. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value Own the Fix is the nearest to the job's core, and F1 is the evidence. VAL because the published value is the theme |
| C2 | "Tell me about a time you helped a colleague through a difficult escalation." | VAL | [grounded] "trained new tellers on our escalation script" | The quote carries training new tellers on the script, so that is the story's only stated beat; say it as that. Answer slot: the JD asks about coaching supervisors, so expect a probe on a live escalation. If you walked anyone through one, say who they were and what you did, in your own words; if you only trained on the script, or no one was coached through a live one, say so plainly and stay with the training. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is a transferability gap, and this is where a manager tests it. VAL delivery on a JD theme |
| C3 | "Tell me about a time you told someone senior what they did not want to hear." | VAL | [generic] | A selection scaffold, not a mapped story: your material names nothing here. Pick a time with a named stake, a point where you did not back down, and a relationship intact at the end, where the hard truth actually landed. Senior means the most senior person you actually dealt with; say who, and do not inflate it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the Values interviewer, and the behavioural cousin of the F8 gap. VAL because it tests the unpopular-truth habit |
| C4 | "Tell me about a time you worked with another team to get something fixed for a member." | VAL | [generic] | A selection scaffold: name the other team, what each side held, what the member got, and what you would do the same way. The JD asks for work with digital teams and across branches and the contact centre, but your material names no cross-team example, so the example has to be yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The behavioural form of F5 and part of F1. VAL because it tests Own the Fix across a boundary |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre, and this role owns complaints end to end across branches and the contact centre. How would you do that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI prep in the pack, rehearsed in four levels. Level one, the concession first: "I haven't worked in a contact centre." Level two, what you hold, at its own scope: "I handled the branch's formal complaints log"; that is the branch side, and the pack says the limit so you can say it first. Level three, the plan as a plan: the first things you would learn (how a complaint reaches the centre, who holds it between channels), who you would ask, and what you would not change until you had. Follow-up one, "what worries you most about the centre?": answer from the plan, not from a claim about centres. Follow-up two, "what if the centre's way of working clashes with the branches'?": hold the plan, concede you do not yet know their way of working, and give the principle in the value's own words: "whoever finds the problem keeps hold of it until it is solved." Never add contact-centre knowledge you do not have | F2 meets the JD's headline line (F1), and a manager would ask it directly. JD because it scores the stated responsibility; the deepest rehearsal because it is certain to arrive in some form |
| D2 | "You handled the branch's formal complaints log. This role owns the process end to end across branches. What have you owned end to end?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if you followed complaints beyond the log, say which steps were yours and how you decided, in your own words; if the log was the part you held, or the wider process was not yours, say so plainly and describe the log. Hold through two follow-ups by returning to the log, never by adding to it. A concession in your words: "The log is the part I held; the wider process is what I would be taking on" | F1 is the end-to-end requirement and the likeliest place for the second probe. JD because it scores the stated line |
| D3 | "You have not presented above regional level, and this role presents to senior leaders. Why should we believe you will be confident?" | JD | [grounded] "I've never presented to anyone above regional level" | Concede first: "I haven't presented to anyone above regional level." Then the plan as a plan: what you would prepare for a first leadership report (what the leaders must decide, one page, the figures behind it), and when and with whom you would rehearse it. Confidence here is a plan and a willingness to be rehearsed on; do not claim a confidence you cannot evidence | F8 is the JD's presenting line and your own stated limit. JD because it scores a stated requirement; the second-deepest rehearsal |
| D4 | "The role reports monthly on complaint volumes and resolution times in Excel. Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Start with the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times and Excel, so expect a probe on what the spreadsheet counted and what it was built in. If it counted either measure, say how you counted it, what it is sensitive to and the assumption you would defend least; if it did not, or it was not Excel, say so plainly and stay with having built it | F3 and F9 are both read off one sentence, so a prober reads it closely. JD with EXP delivery |

### Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Digital is meant to take 40% of member service by 2028, and you would work with the digital teams on self-service journeys. Where do complaints sit in that, and where do you start?" | CASE | [grounded] | Clarify first: how the 40% is counted and whether complaints are in it. Objective, then segments: complaints a member can safely start in an app, complaints that need a person, complaints that start digitally and end in a branch. Approach, metrics (volumes and resolution times are the JD's two), risks. Challenge one premise politely, such as whether every complaint belongs in the 40%. Answer slot: expect "have you worked with a digital team?"; if you have, say what and your part, in your own words; if not, say so plainly and stay with your approach | The brief's headline target meets F5, a gap with no evidence either way. CASE because it is a live problem with no claim about your past |
| E2 | "Eight branches are becoming five hubs over 2027. What happens to complaints from the towns that lose a branch?" | CASE | [grounded] | Clarify: which branches, when, what members are told. Objective: a member keeps one owner and one clear route, whichever channel. Segments: members who raised complaints in person, in the closing branches. Metrics: volumes and resolution times by town. Risk: complaints that go unraised. The value to use is "every branch is part of its town" | Strategy fluency at hiring-manager altitude. CO because it tests the plan; CASE delivery |

### Round 2 reverse questions

| Question | Why it lands |
|---|---|
| "What would you want the monthly complaints report to look like for the leaders it goes to?" | Surfaces the audience bar for F3 and F8 before you build it |
| "In the first six months, what would tell you the contact-centre side of complaints was in good hands?" | Turns F2 from an objection into a shared goal |
| "How do you expect the branch consolidation to change who raises and who resolves complaints?" | Grounded in the brief's hub plan; shows you read it |
| "How do you see the split between complaints that move to self-service and those that stay person to person?" | Ties the 40% digital target to your own remit |
| "What do you wish a new Member Experience Lead had done in their first month?" | A reciprocity question for a manager; it asks what would genuinely help |

## 8. Round 3: panel of two branch managers, the values round (60 min)

Persona weights: the panel prior blends the top two personas of each member's relationship; the recruiter's email makes this the values round and sets a 20-minute case. No names are known, so the weights are per round, not per member.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four published values | Top, 4 questions. The email says the panel scores against the four values | One mapped story per value where a quote carries one, the scaffold elsewhere (section 9) |
| Case / Strategist | The 20-minute complaint-escalation case | Mid, 3 questions. A third of the hour | Clarify first; think aloud; challenge one premise |
| Peer Evaluator | Seam-splitting between branches and your role; what you would need from them | Mid, 3 questions. Branch managers' supervisors are the people the JD says you coach | Reciprocity framing; propose seam principles rather than claim to know the seam |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [generic] | A selection scaffold for Members First, Always: your material names no such decision. Pick a time with a named stake (what the member needed against what a process or target said), what you did, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No fit row carries this value. VAL because the published value is the theme |
| G2 | "Tell me about a time you made something clearer for a member or colleague." | VAL | [grounded] "trained new tellers on our escalation script" | The quote carries training new tellers on the script; tell that. Answer slot: Plain Words says if a member needs it explained twice, the wording is wrong. If you ever reworded the script or any member-facing text because something needed explaining twice, say what and how you knew, in your own words; if you did not, or the script was not yours to change, say so plainly and stay with the training | F4 is the nearest material, and the value is the published one. VAL |
| G3 | "Tell me about a time you thought about what a decision meant for the town your branch serves." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A selection scaffold for Neighbours, Not Numbers: your material names the branch role and no town-level example, so the example has to be yours. It needs a named stake for the town, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Rehearse it beside the brief's hub plan | F6 is only the role. VAL because the published value is the theme; worth rehearsing next to the brief's hub plan |
| G4 | "Tell me about a time you found a problem and stayed with it until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log" | The same story and the same answer slot as C1, cut to about 90 seconds. Own the Fix is scored here by name, so say plainly who held the problem at each step. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 carries the log, not an outcome. VAL |

### Bank H: Case / Strategist

These three are rehearsal cases set in the role. The real case will differ; every one is generic practice for the structure.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's complaint has been passed between a branch and the contact centre twice, and the member has written to say nobody owns it. The supervisor asks you to take it. Take us through what you do in the next 20 minutes." | CASE | [generic] | Clarify first: what the member has asked for, what has been promised, what clock applies (ask which rules and timelines govern; do not assume). Objective: the member has one named owner today. Segments: the member's need, the complaint's facts, the handoff between the two teams, the supervisor's learning. Then approach, metrics (time to resolution, complaints re-routed) and risks. Challenge one premise: whether the supervisor should keep the complaint with your coaching instead of handing it over. The guidance makes no claim about your past | The recruiter's email names a 20-minute escalation case; this is the rehearsal form. F1 and F2 are where it presses |
| H2 | "A supervisor in one of our branches sends you every complaint instead of resolving any. How do you coach them?" | CASE | [generic] | Clarify first: every complaint or certain kinds, what authority they have, what they are afraid of. Then the coaching plan: what they should resolve alone, what comes to you, how you review. Challenge "every": ask for the pattern before you coach. The guidance makes no claim about your past | The JD's coaching line (F4) in live form. CASE with a JD theme |
| H3 | "It is month-end. What goes on page one of the complaints report to our leadership?" | CASE | [generic] | Ask who reads it and what they decide. Start with the JD's two measures, volumes and resolution times; then what changed, what needs a decision, and what you are doing. One page. The guidance makes no claim about your past | F3 and F8 together: a report and an audience. CASE with a JD theme |

### Bank J: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Our branches and your role sit side by side. Where is the seam when a complaint comes in, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claim to know the seam: one named owner at every step; the branch keeps what it can fix; the member's route does not wait for a disagreement. Offer to agree the seam with them rather than announce it. On disagreement: hear the branch's reason first, say who decides, and keep the member moving. Show spine and tact together | A persona stem for peers. F1 is the end-to-end requirement; the seam is where it presses on branch managers |
| J2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a time work spanned teams; say whose work was whose and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; credit-sharing is a standard peer probe. No fit row carries it |
| J3 | "What would you need from us, and what would we get from you?" | JD | [grounded] "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | What you would bring, at the quotes' scope: you trained new tellers on the escalation script and built a monthly complaints spreadsheet your regional manager uses; say them in those words. What you would need: ask, do not claim: where escalations stall for their supervisors and what a useful monthly report would show them. Do not promise results | Reciprocity framing for a peer. F4 and F3 are the evidence, kept at their own scope |

### Round 3 reverse questions

| Question | Why it lands |
|---|---|
| "When a complaint escalates from your branch, what do you want to hear back, and how quickly?" | The role coaches branch supervisors; this asks what a good escalation looks like from their side |
| "Where do your supervisors find the escalation process hardest?" | Gives you raw material you do not have, without guessing it |
| "As eight branches become five hubs, what do you most want the complaints process to protect in your town?" | Ties Neighbours, Not Numbers to the brief's hub plan |
| "Where do members most often need a complaint outcome explained twice?" | Plain Words in the panel's own terms |
| "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel |

## 9. Values cheat sheet

Detected: the recruiter's email says the panel scores against the four values. Names are from the page you pasted.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries this. Selection scaffold in G1, ending in the honest branch |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "trained new tellers on our escalation script". Slot in G2 for any rewording |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor" carries the role only. Selection scaffold in G3, ending in the honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". Slot in C1 and G4 for any outcome |

## 10. Prohibited claims

Built from the fit snapshot before the banks, so the banks are written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not a process across branches. D2's slot stays inside the log |
| Has contact-centre experience | Negative stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Contradicted by F8's quote | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The pack's observation: it says a monthly complaints spreadsheet, not what it counted. D4's slot stays inside what it counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the script. C2's slot stays inside the training |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: the formal log. B3's slot stays inside the log |
| Built the report in Excel | Inflated form of F9 | F9's quote at its own scope. The pack's observation: it says spreadsheet, not Excel. D4's slot allows either answer |

## 11. Sources

Provided documents: the JD; the values page text you pasted (copied 12 October 2026 from ashgrovecu.org/about/values, not fetched); the recruiter's email, which is the loop source for all three rounds; your description of the June 2026 strategy brief, which is four points relayed by you, not the document; your own message. No dossier was present.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the cheat sheet and every VAL question; the four names are from it |
| 2. Ashgrove interview process, member-service roles | skipped | The recruiter's email names all three rounds, who runs each and the case; it fixes the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The four brief points you relayed fix the CO and CASE questions; the full document would move them further (see the upgrade menu) |
| 4. Interviewer name and Ashgrove | n/a | No name has been assigned, so there was no query to form; the upgrade menu says what a name would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 12. Upgrade menu

- Interviewer names, once assigned → an interviewer read, persona weights read from their public footprint, and a reverse question tied to their own path
- The full text of the June 2026 strategy brief → the CO and CASE questions, A4, E1 and E2, rest on the document rather than your four-point summary
- Your honest answers to the slots under F1, F3, F4, F5, F7 and F9 → those rows upgrade from discovery or transferability and the answer slots become mapped stories
- The recruiter's reply on the case format and on which complaint rules Ashgrove works under → H1 to H3 and F7 become sharper; one email
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → recent Ashgrove news and complaints-handling context, offered once and run only if you say yes
- A tuesday-dossier.md from an earlier look at this role, if you have one → verified evidence and agreed positioning that this pack would otherwise infer
