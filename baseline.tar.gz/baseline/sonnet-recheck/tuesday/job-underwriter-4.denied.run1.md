Search permission was denied, so this runs on your message alone, with no company or market research.

## Decision snapshot

**Yes, apply, on conditions. R2, R3, R4, R5, R6a and R7 land direct, and the pet-insurance gap (R10) sits at the preferred tier. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important`: direct: R8a · unclear: R8b (Recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain)

R6b and R8b wait on your answers. R10 is the pet-insurance bridge you raised yourself.

**Opportunity ledger.** The role is specific about its work (RR4). The employer is unverified because research was refused (RR1). The salary is withheld (RR2), and decision rights and team support are unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you can work fully remote from the UK, with any pay floor or other non-negotiable, which settles R1; (2) the employer and live posting verify (RR1); (3) the salary clears your floor (RR2); (4) the motor-to-pet bridge is framed as adjacent, never as pet-insurance experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Its existence is not established | `[grounded]` JD header; research refused |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | One pricing-analytics remit, and 4+ years sits below your 5 for a "Senior" title. No people management is stated, so your never having managed anyone is not a gap against this posting | `[inferred]` from the JD's three responsibilities and requirement list |
| Market calibration | Not available: the role-family search was refused, and no band is given from memory | `[generic]` none run |
| Unknowns | Salary, team size and reporting line, decision rights over model and price changes, contract basis | `[grounded]` JD silence |
| Contradictions | None found within the JD and your background. The JD was not checked against a careers page | `[grounded]` inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | none | hard_gate | The JD states the terms. You gave no constraints, so there is no statement of yours to grade and the gate is not established | `[grounded]` JD quote; user constraints not given | Question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, 2 as senior analyst. Self-reported with nothing to inspect, so `medium` | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a level, not something prose proves, so expect a technical probe | `[grounded]` your message | Offer: a sanitised query or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. The limit is motor, not pet, and R10 carries that | `[grounded]` your message | Offer: model documentation would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. That covers underwriting. Actuarial leads are not stated | `[grounded]` your message | Offer: a sanitised review deck would raise to high |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your message | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained" the model. Post-launch performance tracking is not stated, and a stated reading takes the lower claim | `[grounded]` your message, silent on monitoring | Gap G4 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. Whether you designed them or executed them is not stated | `[grounded]` your message | Question G3 |
| R8a | Recommendations for underwriting | important | direct | medium | none | Tests run with underwriting, and a quarterly review to the head of underwriting | `[grounded]` your message | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in your message touches a product team. This is a lead, not a claim | `[grounded]` your message, silent on product | Question G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance domain knowledge | preferred | adjacent | medium | transferability | The JD asks only for insurance experience as a plus, so this row is inferred from the product being pet. GLM pricing and price testing carry over from personal-lines motor, but you have worked on no pet product. Pet rating factors and claims patterns differ from motor | `[inferred]` from the JD's product line and your statement; `[generic]` that pet rating has its own factors | Gap G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Remote UK terms and your constraints (R1, hard_gate) | hard_gate | The JD states fully remote, UK. Your constraints are not given | A gate the inputs do not settle stays open and caps the decision | A UK base, right to work, a pay floor, any non-negotiable | Your own confirmation | `[grounded]` JD terms; your constraints absent |
| G2 | Recommendations for product (R8b, important) | discovery | Underwriting recommendations are clear. A product-side audience is not | The JD names product as an audience, so this decides whether R8b closes | A test result that changed a product feature, cover limit or renewal rule; a pricing proposal taken to a product owner | A readout, a deck, or an email thread | `[grounded]` JD audience; your message silent |
| G3 | Designing price tests (R7, must_have) | discovery | "Ran" 14 tests, with design ownership unstated | The JD says "design and read", so who set the test design matters | Choosing test and control cells, sizing a test, setting success measures, reading results | A test design note or readout | `[grounded]` JD wording against your wording |
| G4 | Monitoring rating models (R6b, must_have) | discovery | You maintained the model. Monitoring is not stated | The JD pairs "build and monitor" | Tracking actual against expected, checking for drift, scheduled refits | A monitoring pack or dashboard | `[grounded]` your message silent on monitoring |
| G5 | Pet-insurance bridge (R10, preferred) | transferability | Motor GLM pricing and price testing carry over. No pet exposure | A preferred row, but the likeliest interview objection | Any personal-lines product work with age, breed-like or vehicle-type rating factors | A model factor list | `[inferred]` bridge from motor GLM work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "Brindlemoor (insurtech)" | Unchecked because the search was refused, not because nothing was found. Small insurtechs often have thin footprints | `[generic]` pattern for companies of this size, not a claim about this one | Which legal entity employs this post, and is the vacancy live on your careers page? | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in the posting | The pay may sit above or below your floor, which I do not have | `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Authority and support unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean owning the analysis while sign-off on model and price changes sits elsewhere | `[inferred]` from "own" against silence on decision rights and team | Who signs off rating-model and price changes, and what team and tooling support this role? | unresolved |
| RR4 | Specific responsibilities and a named director | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is defined and reports toward a Director of Pricing | `[grounded]` JD | What would the first price test and first model review be? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role on Brindlemoor's own careers page and check the recruiter's email domain before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your own two facts in your own words: you built and maintained the GLM rating model for the young-driver book, and you ran 14 price tests last year with the underwriting team | see R4, R6a, R7 | `[grounded]` your message | pending your approval |
| A3 | Name motor GLM pricing as adjacent to pet and say plainly you have not worked on pet insurance. Claim no leadership, since the posting asks none | see R10 | `[grounded]` R10 row; JD lists no people-management requirement | pending your approval |
| A4 | Ask the RR1 to RR4 verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Prepare a sanitised SQL or Python sample to lift R3 from `medium` | see R3 | `[grounded]` R3 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches, "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst", were refused. They would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search, "Senior Pricing Analyst UK salary insurance pricing analyst remote", was refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | A name was given, but the one search, "Odile Varga Director of Pricing", was refused. It would have moved the scope read and which story the plan leads with |

I can offer the dossier as `tuesday-dossier.md` whenever you want it, with no pressure.

## Upgrade menu

- Your constraints: UK base, right to work and a pay floor. R1 resolves and the hard-gates line firms up.
- A link to the live posting, the careers page, or the recruiter's email domain: RR1 closes.
- The salary range: RR2 closes, and it can be set against your floor.
- A sanitised model document, notebook or query, a price-test readout, or a pricing review deck: R3, R4, R5 and R7 can move to `high`.
- Search permission granted: the three research targets run (up to 5 searches and 2 fetches), feeding role reality, RR1 and RR2.

**Questions**

G1 — Are you UK-based with the right to work there, and do you have a pay floor or any other non-negotiable for this move?

G2 — Have you made a recommendation that fed a product decision (a feature, a cover change, a renewal rule)? What was yours, and what happened?

G3 — For the 14 price tests, which did you personally design (cells, sample sizing, success measures), and which did you run to someone else's design?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.