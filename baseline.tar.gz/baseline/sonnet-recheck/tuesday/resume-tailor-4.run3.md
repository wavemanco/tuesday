Your ATS premise is probably only partly right. The bigger problem is that this resume, as you've described it, covers very little of this JD, so I've built an edit ledger and gap map instead of a keyword-stuffed rewrite.

**On the ATS premise.** The one study I have on this is small. In interviews with 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters" (cite C25). That is 2 recruiters, from a résumé-builder vendor, and the sample is too small to say how common it really is. What those recruiters described as automatic rejection was mostly the application form: "When automated filters are used, they’re almost always knockout questions" (cite C26), such as work authorization, licence and location. Where match scores exist, "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27), and 56% of recruiters in that sample ignored the feature or didn't have it. Whether keywords drive those scores is an inference. So keyword matching may be part of your problem, but I can't show it's the cause, and your résumé layout is a separate risk (see the parse-safety check).

**Method and one assumption.** I can only quote the text you pasted, not the PDF itself. The JD doesn't tier its requirements, so the priorities below are my reading of its list and its closing sentence. Nothing here is applied. Every row waits for your approval.

### Edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(Kubernetes not listed)* | Add to the skills list: "Kubernetes (two-month proof-of-concept, not run in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to first bullet under your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved to second bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |

The ledger is short because your evidence for this JD is thin. I won't pad it with rewording that adds claims. E1 keeps the "proof-of-concept, not production" qualifier on purpose, because dropping it would turn a PoC into production experience.

### Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | AWS | important | already_evidenced | "AWS (EC2, S3, RDS, IAM)" is in your skills as written | `[grounded]` |
| 2 | Python | important | already_evidenced | "Bash and Python scripting" as written | `[grounded]` |
| 3 | CI/CD pipelines | must-have | already_evidenced | Your Jenkins deploy pipeline and jobs; the literal term "CI/CD" isn't on your resume (see C3) | `[grounded]` |
| 4 | Kubernetes | must-have | surfaced_by_edit | E1, E3; PoC only, so this stays a partial match | `[grounded]` |
| 5 | Terraform | must-have | not_evidenced | Recovery C1; Ansible is config management and is not written as a substitute | `[grounded]` |
| 6 | AWS EKS | must-have | not_evidenced | Recovery C2; your resume doesn't say where the PoC ran | `[grounded]` |
| 7 | GitOps, ArgoCD, Helm | must-have | not_evidenced | Recovery C2 | `[grounded]` |
| 8 | Prometheus, Grafana, observability | must-have | not_evidenced | Recovery C3; CloudWatch is the nearest thing you have | `[grounded]` |
| 9 | SRE practices, platform reliability and developer experience | must-have | not_evidenced | Recovery C3 | `[grounded]` |
| 10 | GitLab CI/CD | must-have | not_evidenced | Named absence below; Jenkins is adjacent, not the same tool | `[grounded]` |
| 11 | Go | important | not_evidenced | Named absence below | `[grounded]` |
| 12 | Istio, service mesh | important | not_evidenced | Named absence below | `[grounded]` |
| 13 | Vault | important | not_evidenced | Named absence below; IAM is not secrets management | `[grounded]` |

By my count, 3 of 13 are already evidenced, 1 is partly surfaced, and 9 are not evidenced. That's a real fit gap. Keywords can't close it, and nothing in this skill writes around it. Whether the role is worth the effort is job-underwriter's question, not this one.

### Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | must-have | Ansible for config management, and no infrastructure-as-code tool for provisioning | The JD lists Terraform by name, and your resume has nothing that matches it | A module for a VPC or EC2 or RDS setup; a personal or sandbox AWS account; reviewing someone's Terraform; a CloudFormation stack | A repo, a plan/apply output, or a PR you reviewed | `[grounded]` what the resume does and does not say; `[generic]` what this costs on platform roles of this kind |
| C2 | AWS EKS, Helm, GitOps/ArgoCD | must-have | A two-month Kubernetes PoC with no stated platform or tooling | The PoC could be your strongest card, but only if it has specifics a reader can check | PoC on EKS vs. kind or minikube; Helm charts you wrote; any Argo CD or Flux trial; why it never shipped | A PoC write-up, manifests or charts, or a demo recording | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Observability, SRE practices, reliability and developer experience, CI/CD scope | must-have | CloudWatch for monitoring; a Jenkins pipeline you built and about 30 jobs you maintain | The JD ends with "own platform reliability and developer experience", and your resume doesn't say who relied on your pipeline or what happened when it failed | On-call rotation; alerts or dashboards you built; incident reviews; how many developers used your pipeline; whether it ran builds and tests as well as deploys | Dashboards, runbooks, an incident write-up, or pipeline usage numbers | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences.** For each one, closing the gap takes real work, not wording.

| Requirement | Gap | What closing it would take | Provenance |
|---|---|---|---|
| GitLab CI/CD | You've used Jenkins, not GitLab | A small personal project with a `.gitlab-ci.yml` pipeline; Jenkins experience gets you partway, but the JD names GitLab | `[grounded]` your resume; `[generic]` typical effort |
| Go | No Go on your resume | A small Go tool or exporter on a public repo; a few weeks of practice, not a rewording | `[grounded]` your resume; `[generic]` typical effort |
| Istio, service mesh | Nothing on your resume | Install Istio on a local cluster and write up what you did; if you can't, treat it as a known gap for this role | `[grounded]` your resume; `[generic]` typical effort |
| Vault | Nothing on your resume; IAM is access control, not secrets management | A sandbox Vault setup injecting secrets into a pod; otherwise a known gap | `[grounded]` your resume; `[generic]` typical effort |

### Not written, and why

- "Kubernetes experience" with no qualifier. You ran a two-month PoC that never reached production, and an interviewer will ask one question to find that out.
- "Terraform" or "infrastructure as code". Ansible is config management, and you gave me no Terraform.
- "Observability", "Prometheus" or "Grafana" for your CloudWatch work. That's the JD's vocabulary applied to different work, and no tool changes.
- "CI/CD (GitLab)", "GitOps" or "ArgoCD". You built a Jenkins deploy pipeline, and that's what the line says.
- "SRE practices", "platform engineering" or "developer experience" as things you did. Nothing you gave me says you owned reliability or served developers as customers.
- "Secrets management" or "Vault" from your IAM work, "service mesh", "Helm" and "EKS". None of these is on your resume.

### Parse-safety check

I haven't seen the PDF, only your description of it, so these are risks I can't confirm by inspection. I also couldn't check for hidden text a Canva template might carry.

| Check | Your description | What it costs |
|---|---|---|
| Multi-column layout | Two-column PDF | Parsers can read the columns interleaved, so dates and skills may detach from the roles they belong to |
| Images and icons | Icons for each skill | The icons can come out as garbage characters or be skipped, so skill information may be lost |
| Header content | Contact details in the header | Header content may be discarded as page furniture, so your email and phone may never reach the recruiter |
| File type | Canva-exported PDF | Whether it has a text layer varies, and a text-layer PDF or `.docx` is the safe pair |

This is a more likely cause of "keywords not matching" than anything in the wording. If a skill or your contact line doesn't survive parsing, no keyword work helps.

### Upgrade menu

- **The resume file itself.** I could run the parse-safety check properly and flag any hidden text a template added.
- **A repo, a PoC write-up or manifests.** These would let me upgrade the Kubernetes row from `medium` to `high` confidence.
- **Terraform code, Grafana dashboards or a runbook.** Any of these would turn a `not_evidenced` row into a real one.
- **An older resume version.** It may hold evidence your current one dropped.

### Questions

C1 — Have you written or reviewed any Terraform, even in a sandbox or on a personal project?
C2 — Where did your Kubernetes PoC run (EKS or elsewhere), and did it include Helm charts, Argo CD or Prometheus?
C3 — Were you on call or did you build alerts and dashboards, and roughly how many developers used your Jenkins pipeline?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.