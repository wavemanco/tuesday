Web search was denied, so this runs on the posting and what you told me. Employer checks and pay-band research are marked unavailable.

## Decision snapshot

**No, it isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin five days a week), R2 (Base $70–85k against your $150k floor)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO and content)
- `important` — unclear: R7 (Brand and PR), R8 (Partnerships and sales ops), R9 (Operating as a team of one)

R3, R4 and R5 are `direct`, so your fit on paper is real, and it does not touch R1 or R2.

**Opportunity ledger.** The pay is the severe flag (RR1). The rest of the register explains the "something feels off". A seven-function remit with no bench is the bundled-role pattern (RR2). After-hours work is treated as normal (RR3), and success metrics are left undefined (RR4). Whether Novaline exists as described is unchecked (RR5), and the equity is unquantified (RR7). The CEO reporting line is the one positive (RR6).

- **Hard gates:** failed: R1 (On-site Austin five days a week), R2 (Base $70–85k against your $150k floor).
- **Severe red flags:** RR1 (`severity: high`).
- **What would change this:** Novaline would have to offer fully remote work, or a Portland base, and a base of at least $150k. The posting says "no exceptions" for on-site work, and I'd treat the pay as fixed until they say otherwise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting header, as the employer's own claim, unchecked |
| Mandate | Own all revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site Austin, 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus unquantified equity | `[grounded]` posting |
| Scope read | A head-of-function title with a team of one and seven functions to cover | `[inferred]` from the function list against "team of one" |
| Market calibration | Not offered, because no role-family sweep ran. The posting's base is set against your floor instead (R2), and no market band is claimed | `[grounded]` posting figure and your stated floor |
| Unknowns | Budget, headcount plans, equity terms, what success means, who the CEO is | — |
| Contradictions | A "Head" title and board access sit beside a base that reads as a mid-level one, and "players who don't need a bench" sits beside owning sales ops | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit: remote-only, living in Portland, not relocating. The posting rules remote work out in terms | `[grounded]` posting and your intake message | Surface; only the employer changing terms resolves it |
| R2 | Base $70–85k (your hard constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The posting's top figure is about 57% of it. Equity doesn't change a base figure | `[grounded]` posting figure and your floor | Surface; only a changed offer resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years in growth, as growth lead then Head of Growth at two companies. How many of those years were in the lead and head roles isn't dated, so I read it downward. Confirmed in prose, with nothing inspected yet | `[grounded]` your message | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid. Your $8M to $40M ARR scale-up over three years with a budget you controlled is your own figure and wasn't inspected | `[grounded]` your message | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and are deep in Braze, confirmed in prose with no artifact yet | `[grounded]` your message | none |
| R6 | SEO/content | must_have | unclear | low | discovery | You didn't mention SEO or content. GA4 depth is indirect context, not SEO work | `[grounded]` silence in your message | Recoverable only if the role moves forward (G1) |
| R7 | Brand and PR | important | unclear | none | discovery | Nothing in your background covers either | `[grounded]` silence in your message | G2, if the role moves forward |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Nothing in your background covers either | `[grounded]` silence in your message | G3, if the role moves forward |
| R9 | Operating as a team of one | important | unclear | low | discovery | You built and managed teams of 3 to 7, which says nothing about working with no team | `[grounded]` your message | G4, if the role moves forward |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Paid, lifecycle and experimentation are established, SEO and content are not | A must-have, but R1 and R2 decide the case first, so closing it can't change the status | Owning a content calendar, technical SEO fixes, or organic-traffic targets alongside paid | Search-console or GA4 organic reports | `[grounded]` silence; `[inferred]` that closing it can't move the status |
| G2 | Brand and PR (R7, important) | discovery | Nothing stated | Part of the remit as posted | Launch or press work during the $8M to $40M scale-up, or brand-metric ownership | A press list, a brand-tracking report | `[grounded]` silence |
| G3 | Partnerships and sales ops (R8, important) | discovery | Nothing stated | Part of the remit as posted | Affiliate or referral partners, handing leads to sales, CRM routing | A partner program brief, a lead-routing doc | `[grounded]` silence |
| G4 | Solo operation (R9, important) | discovery | Teams of 3 to 7 are established, working with no team is not | The posting starts you as "a team of one" | Stretches where you ran growth alone or with contractors only | An org chart from the earlier period | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay far below your floor and the seniority asked (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | A head-level mandate is priced well under a head-level market | `[grounded]` posting figure against your floor; `[inferred]` that the title and years bar are priced above it, since no market sweep ran | What base range is budgeted for this role, and is it flexible? | confirmed |
| RR2 | Seven functions bundled into one person with no bench | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles are folded into one title with no committed budget or hires | `[inferred]` from the function list against "team of one" and silence on budget | What budget and headcount are committed for this role in its first twelve months? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine, not exceptional | `[inferred]` from "is just who we are" | In the last quarter, how many evenings or weekends did the growth function work, and what triggered them? | unresolved |
| RR4 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable for revenue with no agreed definition of success | `[inferred]` from the posting's wording | What outcome counts as success at six and twelve months, and who signs it off? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has real access and visibility | `[grounded]` posting states it | How often does this role present to the board, and on what? | noted |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | "Meaningful" may mean a small grant on undefined terms | `[inferred]` from the posting's undefined term | What percentage and vesting terms does the equity carry? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on this posting as written | see R1, R2 | `[grounded]` the two failed gate rows | pending your approval |
| P2 | If you proceed anyway, ask RR1 to RR5 and RR7 verbatim before investing in any loop, starting with RR1 and RR5 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P3 | Hold your R3, R4 and R5 story for roles that clear R1 and R2 | Those rows are your strongest ground | `[grounded]` map rows | pending your approval |

## Evidence status

Verified: none yet. Every claim about your background comes from your message and is unverified. No unverified leads or rejected inferences exist.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin". The search was refused, so no result came back. It would have settled RR5 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary base Series A startup 2026 e-commerce". The search was refused. It would have given the market calibration and sized RR1 against a band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like, I can save this as `tuesday-dossier.md` so it travels with you.

## Upgrade menu

- A link to the live posting on Novaline's own careers page, or the recruiter's email domain → RR5 closes or escalates.
- Permission to run web search → the employer check and the pay band run, and RR1 and RR5 firm up (a deeper pass after that is up to 5 more searches and 2 more fetches).
- Anything inspectable from your ARR scale-up, such as a board deck, a P&L or a cohort dashboard → R3, R4 and R5 move to `high`.
- Your SEO, content, brand, PR and partnership history → G1 to G3 close, though none can move the status.
- The CEO's or hiring manager's name → role reality's scope read.

RR5 — How did this posting reach you: Novaline's own careers page, a job board, or a recruiter? If it was a recruiter, what's their email domain?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.