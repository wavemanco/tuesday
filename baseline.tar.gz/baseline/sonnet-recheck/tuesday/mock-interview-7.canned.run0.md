The write to the working directory wasn't permitted, so I'm saving the pack to the session scratchpad instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-tuesday-rooms-case-7-canned-deef18af/cb979b4b-0a72-49ce-9537-9e118d00c857/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. I couldn't write to the project folder, so it went to the session scratchpad. I built it as a hiring-manager round, on the assumption that Tobias is the hiring manager.

Say the word and I'll play the Skeptic on B2, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager who will run your interview, and did your recruiter say what it will cover? The answers reweight the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: a single 60-minute interview on Friday, built as a hiring-manager round on the assumption that Tobias is the hiring manager who runs it. The loop rests on Saltmarsh's own interviewing page (Sources, target 2), not on an archetype.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: every statement about your own past rests on a sentence you wrote, quoted in the Provenance cell, and where your material is silent the guidance is an answer slot for you to fill in your own words, or to say plainly that it does not apply.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | The stated responsibilities and requirements of the role |
| CO | Knowledge of the company's strategy and recent moves |
| CASE | Structure and reasoning on a live problem set in the role |

## 3. Prep triage

You have until Friday. Do these in order; everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Say the two plain acknowledgments aloud until they are boring, then run the in-app-purchase answer with its three follow-ups | B2, B4, section 13 |
| 2 | Run each tabletop aloud once against a clock, thinking aloud in the order the guidance gives | A1, A2 |
| 3 | For each of the three values questions, pick one real instance you lived, or rehearse the honest branch | C1, C2, C3 |
| 4 | Say your sixty-second answer on why you, holding to what your sentences carry | E1 |
| 5 | Choose three reverse questions and say them aloud | Section 11 |

Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not live events and not two titles, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles wording makes a probe on scale likely. If any drops were timed events, or you worked across more than one title, say which and how, in your own words; if not, say so plainly and stay with the weekly calendar for the one title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with on a drop. Answer slot: the JD names four teams, so expect a probe on which you lined up and what you needed from each. If you worked with any of them, say which and what you needed, in your own words; if some were not part of the drops, or lining them up was not yours, say so plainly and say how you would coordinate them |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says monthly retention numbers were presented to the studio head, not a review of an event or KPIs owned, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event-review line makes a probe on what the numbers were read against likely. If any of what you presented was tied to particular drops, say how, in your own words; if the monthly numbers were not tied to drops, or what they meant was not yours to decide, say so plainly and stay with presenting them to the studio head |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the requirement's terms, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms — you wrote it, and QA still uses it — because a named artifact beats an adjective. Your material says wrote, not ran each release, and the words stay at wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The years and the title are in your words; whether the puzzle game ran as a live service is not, and the title is associate producer where the JD says producing. A length-of-experience line is not a gate, so it keeps its tier. Answer slot: the JD's live-service wording makes a probe on whether your title shipped updates after launch likely. If it did, say how updates reached players, in your own words; if the game was not run as a live service, or only part of those four years was, say so plainly and stay with the four years as an associate producer and the two years of the weekly calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: your strongest row, and a quote with nothing inspected behind it, so expect a probe. Lead with it in its own terms — weekly, one main title, two years. A calendar or drop schedule from that period that you can show would raise the band |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the requirement's terms: the quote shows retention numbers presented monthly, to the studio head. Expect a probe on how they were counted; that slot is D1's |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Your material gives a written document in use, not a writing sample, and the words stay at the quote: "I wrote the release checklist our QA team still uses." Answer slot: if you can say what made it usable for QA, say it in your own words; if you do not know why it stayed in use, say so plainly and stay with the fact that it did |

Your two stated limits, never having led a team and never having worked on a game with in-app purchases, are not rows here because the JD quotes above ask for neither; they sit in section 13 and drive bank B.

## 7. Reading the interviewer

| Signal and source | What it implies | Provenance |
|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio — GDC 2026 talk listing, snippet only | The release checklist and the QA hand-off are native ground for him, so expect depth on F4 and a live release decision in the tabletop (A2) | [inferred] |
| His GDC 2026 talk "Patch Notes Are a Promise" argues a live team is judged by how often its patch notes describe what actually shipped — same listing | Announcing versus shipping is likely to be a test in both halves of the hour: the player message in A1 and the values question C2. It echoes the company's published value "Ship the Patch Not the Promise" | [inferred] |
| Saltmarsh's interviewing page says the 60-minute interview is with the hiring manager | The pack assumes that is Tobias; if it is not, the weights in section 8 change | [inferred] |

Mirror opportunity: shared vocabulary only. Release checklist and QA are his ground and the sentence you can offer from F4 is "Wrote the release checklist our QA team still uses". Nothing in your material carries a shared career move, so none is offered.

## 8. Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event, then calendar questions on the two titles' shared calendar | Top, 5 questions. The interviewing page documents the tabletop as the first half of the hour, and the hiring-manager prior also puts this persona first | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely | [grounded] |
| Skeptic | The day-one-weakness probe, the in-app-purchase probe, the coordination-without-a-team probe | 4 questions. Hiring-manager prior, and your stated limits meet the company's announced season-pass model | Rehearse the single most predictable objection until it is boring; plain acknowledgment, named limit, then a plan stated as a plan | [inferred] |
| Values/Behavioral | The values conversation after the tabletop, built on the three published values | 4 questions. The interviewing page documents a values conversation in this hour, so it is guaranteed in this session | Map a story to a value only where one of your sentences carries it; otherwise pick a real instance or take the honest branch; we for context, I for contribution | [grounded] |
| Data-Driven Prober | Retention numbers probed line by line | 2 questions. Retention is in the JD, but no self-description from Tobias points to an analytics bent | Know what you can and cannot say about how each number was counted, and say plainly when you do not know | [inferred] |
| Pressure | Time-boxed answers inside the tabletop; a sixty-second why-you | 2 questions. The hiring-manager prior does not include it, and the tabletop supplies time pressure anyway | Pause, restate, hold the position through two follow-ups, concede specifically | [inferred] |
| Conversational | The opening biography question; a casual live-events question | 2 questions. An opener is still scored | A 90-second arc built only from your own sentences | [inferred] |
| Peer Evaluator | Not included | Omitted: under the assumption that Tobias is the hiring manager, a peer style is not plausible. A peer on the loop would add a bank | — | [inferred] |

## 9. Question banks

### A. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the middle of a weekend event and rewards have stopped granting for part of the player base. Community is seeing reports. You're the producer on the call — what do you need to know first, and what do you do?" | CASE | [inferred] | Think aloud in this order: what is affected, since when and for whom; the objective; affected players versus unaffected; who owns containment, who owns the message to players, who verifies the fix; what you would watch to know it is working; the risk of acting on too little. Challenge one premise politely, for example whether the event should keep running while you find out. Write the first player message aloud: it says only what is built and verified, the company's own line being "we announce what is built, not what is hoped", and players come first: "when the calendar and the players disagree, the players win". The question needs no claim about your past, so the guidance makes none | The tabletop on a simulated outage during a live event is the documented first half of the hour (Sources, target 2), so this is the most certain question in the pack. CASE because it is a live problem; it also scores the coordination requirement in F2 and the writing requirement in F8 |
| A2 | "The fix is ready, QA says the release checklist isn't fully green, and players are leaving the event by the hour. Ship or hold, and who decides?" | CASE | [inferred] "Wrote the release checklist our QA team still uses" | Clarify first: which checklist items are open, what each risks for players, what a hold costs, what a partial release could do. Then take a position and name the condition that would change it; say who you would bring into the decision and what gets written down afterwards. The build is left greener, in the company's words: "every release leaves the codebase and the checklist better than it found them". If you refer to your own checklist, stay at the quote: "I wrote the release checklist our QA team still uses". Do not describe deciding a release against it; your material says wrote | F4 is where Tobias is best placed to probe, given the reading in section 7. CASE because it asks for a live decision, not a past one |
| A3 | "From January 2027 both titles run on one shared events calendar. How would you build the first quarter, and what do you need to know before you start?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify which events must not collide, what each title's players expect, what the single live-ops group can staff, and where the season pass fixes dates. State the objective, split by title and by event type, place fixed anchors first and fill around them, say what you would measure, and name the risks: collisions, one team overloaded. Challenge one premise politely, for example whether one shared calendar means one shared cadence. If you refer to your own calendar, keep it at the quote: weekly, one main title. The shared calendar is wider than that, and you say so rather than imply otherwise | The announced move to one calendar (Sources, target 3) makes this the likeliest strategy-flavoured case, and F1 is the row it presses on. CASE because it is a planning problem set in the role |
| A4 | "Project Larkspur retires per-title event teams in favour of a single live-ops group. What does that change about what a producer here is for?" | CO | [grounded] | Stay inside the announcement, which reads "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from January 2027, and retires per-title event teams in favour of a single live-ops group". Give a view and label it as your view: a producer's coordination reaches across both titles. Say what you would want to ask about how the group is organised rather than assuming it. The question needs no claim about your past, so the guidance makes none | Only a source read within the last six months can ground this, and the announcement is dated August 2026. CO because it scores homework at the company's altitude; F1's two-title requirement is why it matters to this role |
| A5 | "An event underperformed against what we hoped. How do you run the review, and which KPIs would you report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Cover the review in order: what the event was meant to do, what the numbers show, what players said, what changes next time; say which measures you would report and why, in your own words. If you refer to your own experience, stay at the quote: "I presented the monthly retention numbers to the studio head". Answer slot: the JD's post-event-review line makes a probe on what those numbers were read against likely. If any were tied to particular drops, say how; if they were not, or what they meant was not yours to decide, say so plainly and stay with presenting them to the studio head | F3 is the requirement this scores and the transferability gap it carries. JD because it is the stated responsibility; the CASE shape is only delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team, and never worked on a game with in-app purchases" | Name one weakest part in a sentence, then the nearest thing your sentences carry, then a first-weeks plan stated as a plan. Your material points at three candidates and you choose the true one: two titles instead of one (F1), coordinating four disciplines, which your material does not show (F2), and in-app purchases, where the plain acknowledgment is "I haven't worked on a game with in-app purchases." The nearest thing you carry: "I ran the weekly content-drop calendar for our main title for the last two years." Say the weakness before the interviewer extracts it | The standard Skeptic opener; F1 and F2 are where the answer comes from. JD because it scores the stated role against the candidate |
| B2 | "Both titles move to a season-pass model in January 2027, and you've never worked on a game with in-app purchases. How would you handle that part of the job?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Say it plainly first, before it is asked for: "I haven't worked on a game with in-app purchases." Name the limit: what your sentences carry is a weekly calendar and monthly retention numbers presented, not purchase data, and you do not stretch one into the other. Then a plan stated as a plan: who you would learn the season-pass design from first, what you would read before the first calendar meeting, what you would ask before scheduling anything the pass depends on. Follow-up one, what would you do in your first month: the plan again, with the first question you would ask. Follow-up two, what wins when the pass and the players disagree: the company's own line, "when the calendar and the players disagree, the players win", offered as the principle you would bring, not as something you have done. Follow-up three, isn't that a big gap: concede it in one sentence, repeat the plan, and stop. Never claim a past with purchases | The stated limit meets the company's announced season-pass model, so some form of this question is the most predictable objection in the loop; rehearsing it until it is boring changes the interview. CO because its premise is the company's announced model, and F1 is the row whose scale it extends |
| B3 | "Which of the design, art, engineering and community teams have you needed to line up for a drop, and what did you need from each?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-map only what the quote carries: you ran the weekly content-drop calendar for your main title for two years. Answer slot: the JD's four teams make a probe on who you lined up likely. If you worked with any of them on a drop, say which and what you needed, in your own words; if some were not part of the drops, or lining them up was not yours, say so plainly and return to the calendar you ran. Say only what you did with a team | F2 is the requirement with no evidence in your material, so this is where a thin row is tested. JD because it scores the coordination requirement as written |
| B4 | "You haven't led a team. How would you get design, art and engineering to commit to a calendar that's yours?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Wrote the release checklist our QA team still uses" | Plain acknowledgment first: "I haven't led a team." Then read the JD's own verb, which is "coordinate design, art, engineering and community teams on each update". Then how you would do it, in the conditional: what you would bring each team before asking for a date, how a commitment gets written down, what you do when a date slips. The one thing from your past you can point to is a document: "Wrote the release checklist our QA team still uses". Never suggest you directed anyone | A stated limit that the JD's verb softens but does not remove, so it will come back in some form; F2 is the row it presses on. EXP because it tests what was actually yours |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold on the published value, "when the calendar and the players disagree, the players win". Pick an instance you actually lived where a planned drop and what was good for players pulled apart; it needs a named stake, what you did, who you told, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or say how you would handle it | The first of three published values, and the values conversation is documented for this hour. VAL because it scores behaviour against the value by name |
| C2 | "When have you held back from announcing something because it wasn't built yet?" | VAL | [grounded] | Selection scaffold on the published value, "we announce what is built, not what is hoped". Pick an instance you actually lived: what was hoped, who wanted it announced, what you said instead, and what happened after. If no such time comes to mind, say so plainly, then say how you would handle it. Pack makes no claim about your past here | The second published value, and Tobias's published talk on patch notes makes this the most likely values question to be asked with weight (section 7). VAL because it scores the value by name |
| C3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the checklist, and QA still uses it, which are the beats the sentence states; tell them in your own words. Answer slot: the value's own wording, "the checklist better than it found them", makes a probe on what was better likely. If you can say what the checklist changed for QA or for releases, say it; if there was no before-and-after you can speak to, or it was not yours to judge, say so plainly and stay with the fact that QA still uses it | The third published value, and the only one of the three that one of your sentences carries. VAL because it scores the value by name; F4 is the evidence |
| C4 | "Tell me about a time you had to deliver an unwelcome number to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7 only as far as the sentence goes: you presented the monthly retention numbers to the studio head. Answer slot: if any month's numbers were unwelcome, say what you said and what followed, in your own words; if none were, or nothing you presented landed as hard news, say so plainly and either choose an instance from elsewhere or say how you would handle it | A standard values stem for delivering an unpopular truth to leadership, and F7 is the nearest evidence. VAL because it scores how hard news was delivered, not the numbers |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how those monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped only on the sentence: monthly, retention numbers, presented to the studio head. Answer slot, four parts, each in your own words: how they were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours. If you do not know how they were counted, say so plainly; if someone else produced them and you presented, say that and stay with presenting them to the studio head | F7 is the headline-number row, and a counting probe is where a prober goes first. EXP because it tests what you actually did |
| D2 | "Which retention measures would you watch for a live event, and what would make you stop trusting them?" | JD | [grounded] | Name the measures in your own words; the JD only says "player-retention metrics", and the pack does not choose them for you. For each, say what it tells you and the assumption behind it you would trust least. If you do not know the standard measure, say so plainly and say how you would find out. Pack makes no claim about your past here | The JD's retention line (F7) without a CV figure to press on, so the prober asks it as a live question. JD because it scores the stated competence |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause, restate the question in a clause, then hold on what two sentences carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "Wrote the release checklist our QA team still uses". Hold through two follow-ups by returning to those sentences, never by adding scale to them. When pressed, concede specifically: the calendar was one title, and "I haven't worked on a game with in-app purchases." Do not fold the core claim to restore harmony | The gap in F1 and F5 is where a stress style presses. JD because it scores the fit to the stated role |
| E2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on "I ran" at its own scope. Answer slot: if parts were set or approved by someone else, say which and by whom; if the whole of it was yours, say so; if the calendar itself was set elsewhere and you ran it, say that plainly. Hold through two follow-ups, then concede exactly the part that was not yours | An attribution probe on F6, the strongest row, because strong rows are the ones probed for inflation. EXP because it tests attribution |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey. How did you end up here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Build a 90-second arc only from those four sentences: the four years, the weekly calendar, the checklist, the retention numbers, each at its own scope. Why live operations and why Saltmarsh are your own words; the pack has no sentence for them. Say what you actually found interesting; if you have no reason beyond the role, say so plainly and say what you would want to learn | The casual opener is scored for economy and for what it signals about F5's years. EXP because it walks the background |
| F2 | "What live event in a mobile game have you admired recently, and what would you have done differently on the calendar?" | JD | [generic] | Selection scaffold: pick one you have actually played; say what the event did that worked, what you would have measured, and one thing you would change. If you have not followed live events lately, say so plainly and name the one you know best. Pack makes no claim about your past here | A casual-register question on the role's own subject, scored even though it feels safe. JD because live events are the role |

## 10. Values cheat sheet

A values conversation is documented for this hour (Sources, target 2), and the three values are quoted from the official page (target 1).

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No sentence of yours carries a story here: scaffold at C1 ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No sentence of yours carries a story here: scaffold at C2 ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" — story-mapped at C3 |

## 11. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| G1 | "Your GDC 2026 talk is titled Patch Notes Are a Promise. How does your team tell, release by release, whether the notes matched what shipped?" | Tied to his own published talk; it invites his framework and shows you researched him, not only the company | [grounded] |
| G2 | "You came to live operations from QA. What did that change about how you run an event?" | Tied to his own career path; it turns an interview into a conversation about craft | [grounded] |
| G3 | "With one shared calendar from January 2027, what does the first quarter's calendar need to prove?" | Reads as diligence on the announced strategy and tells you what success is measured against | [grounded] |
| G4 | "Where does the season pass change what the calendar has to protect, and who would I learn that from in my first month?" | Converts the in-app-purchase gap into a ramp plan and asserts nothing about your past; you decide whether to raise it | [grounded] |
| G5 | "Looking back at the tabletop, what would you have wanted me to do more of?" | Invites live feedback and shows you treat the hour as a working session | [generic] |
| G6 | "Which of the two titles' calendars is in better shape for the move to one shared calendar, and where should a new producer look first?" | A practical question about the first weeks that signals you are already planning | [inferred] |

## 13. Prohibited claims

Built before the banks. None of these is coached, and no answer slot, hold, bridge or rationale asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative the candidate stated | "Never led a team, and never worked on a game with in-app purchases" — your message. The plain acknowledgment: "I haven't led a team." Then how you would coordinate, as a plan. No slot |
| Worked on a game with in-app purchases | Negative the candidate stated | The same quoted sentence. The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a ramp plan, as a plan. No slot |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: a weekly content-drop calendar for your main title. The limit is the pack's observation: your material says one title and drops, not two titles and events. A3 and E1 stay with the one title |
| Owned post-event reviews and the KPIs they report | Inflated form of F3 | F3's quote at its own scope: presented the monthly retention numbers to the studio head. A5's slot asks only what those numbers were read against |
| Managed the release process with QA, release by release | Inflated form of F4 | F4's quote at its own scope: wrote the checklist QA still uses. The limit is the pack's observation: your material says wrote, not ran each release |
| Three or more years producing live-service games | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer, and two years of the weekly calendar. The limit is the pack's observation: your material does not show the game was a live service |

## 14. Sources

Provided: the job description and your background, both in your message.

Searches and fetches sent:

| Query or URL | Returned |
|---|---|
| Search: Saltmarsh Games values | https://saltmarshgames.com/values |
| Fetch: https://saltmarshgames.com/values | Page text read in full: three values by name with definitions |
| Search: Saltmarsh Games interview process producer | https://saltmarshgames.com/careers/interviewing |
| Fetch: https://saltmarshgames.com/careers/interviewing | Page text read in full: the loop is a recruiter call, then a single 60-minute interview with the hiring manager, a live-incident tabletop then a values conversation; no take-home |
| Search: Saltmarsh Games mobile studio strategy news | https://saltmarshgames.com/news/project-larkspur — snippet only, page not fetched |
| Search: Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise — snippet only, page not fetched |

No dossier was present, so none was consumed.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet, section 10, and bank C: three values by official name |
| 2. Saltmarsh Games interview process producer | yes | Loop structure: the tabletop and the values conversation fix the persona weights, banks A and C, and section 10's condition |
| 3. Saltmarsh Games strategy or recent news | yes | A3, A4, B2 and G3, G4: one announcement, August 2026, read from the search snippet only because the fetch budget went to targets 1 and 2 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Reading the interviewer, section 7, and G1, G2; read from the search snippet only |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Your CV → the fit rows resting on your message alone can cite it, and F2 and F5 may change grade
- Which teams you worked with on each weekly drop, and whether your puzzle title shipped updates as a live service, said in your own words → F2 and F5 become story-mapped rows, and B3 stops being an answer slot
- Your recruiter's note on what the tabletop will cover, and whether anything written is assessed → the A bank is reweighted, and F8's row can be graded
- A deeper research pass — up to 6 more searches and 2 more fetches, several more minutes → a grounding brief, the full Project Larkspur announcement and the talk beyond its summary, and recent org context
- A tuesday-dossier.md from job-underwriter → the highest-ROI objection and the prohibited claims would arrive evidence-derived rather than inferred from this pack
