Search permission was declined, so this runs on your message alone. Here's the full assessment.

## Decision snapshot

**Yes, apply. R4 (GLM), R5 (presenting to underwriting) and R7 (price tests) are direct matches, and your pet-insurance gap sits in R10, a preferred row. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · adjacent: R6b (Monitor rating models)
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R10 is where the pet-insurance gap shows, in the preferred tier.

**Opportunity ledger.** Unverified rather than troubling: the employer is unchecked (RR1), pay is unstated (RR2), and team shape and data depth are unknown (RR3, RR4). One entry runs the other way: the scope is concrete and names a Director-level hiring manager (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1, that you can work remotely from the UK; (2) the employer and live posting verify, see RR1; (3) the salary is acceptable to you, see RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD as you pasted it; not checked externally |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD asks for none and mentions no reports | `[grounded]` JD silence; `[inferred]` that this fits your no-management background, unconfirmed (RR3) |
| Scope read | The craft asked for (GLM rating, price tests, presenting to underwriting) matches the work you describe, in a different line of business | `[inferred]` JD set against your stated work |
| First-year outcomes | Not stated in the JD | `[grounded]` JD |
| Market calibration | Not run, so no salary band is offered | `[grounded]` search unavailable, see Evidence status |
| Unknowns | Salary; contract basis; team size; whether a rating model already exists; how much policy and claims history sits behind it | `[grounded]` JD silence |
| Contradictions | None between the JD and your message; employer side unchecked | `[grounded]` the two inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You worked at a UK motor insurer, but your location and right to work are not stated, and no constraints were given | `[inferred]` from your UK employer; nothing confirmed | Ask whether you meet it (Q1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Confirmed and specific; no inspectable artifact | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Frequency is stated, depth is not | `[grounded]` your message | A sanitized query or notebook would raise this to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your message | A model summary or documentation excerpt would raise this to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting; underwriting is the audience named | `[grounded]` your message | A sanitized review deck would raise this to high |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4: you built the young-driver GLM | `[grounded]` your message | none |
| R6b | Monitor rating models | must_have | adjacent | medium | discovery | You said "maintained"; monitoring (performance tracking, drift) is not stated. Maintenance and monitoring are different work, so the lower reading holds | `[grounded]` your wording; `[generic]` that monitoring is usually a distinct duty | Ask what you tracked (Q2) |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. Whether you designed them or executed them is not stated | `[grounded]` your message | G3 below; not asked this turn |
| R8a | Recommendations for underwriting | important | direct | medium | none | The tests ran with the underwriting team and you present the quarterly review to their head | `[grounded]` your message | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing you described reaches a product team | `[grounded]` your message is silent on product | Ask (Q3) |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance, not pet | `[grounded]` your message | none |
| R10 | Pet-insurance product knowledge (not required by the JD) | preferred | adjacent | medium | transferability | The rating and testing craft carries over. Limit: you have not priced pet, and pet-specific rating factors and claims patterns are untested by your motor work | `[inferred]` from JD scope against your stated gap; `[generic]` that rating factors differ by line of business | Frame as adjacent, never as pet experience (P2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6b, must_have) | discovery | "Built and maintained" a GLM; no mention of ongoing performance tracking | The JD names "monitor" next to "build", so it is half of that responsibility | Actual-vs-expected tracking, drift or lift reports, scheduled model reviews, refit triggers you defined or ran | A monitoring dashboard screenshot, a refit note, or a review pack | `[grounded]` your wording; `[generic]` that this role family expects both halves |
| G2 | Recommendations to product (R8b, important) | discovery | Underwriting audience is clear; no product audience | The JD names underwriting and product as recipients | A test result that changed a product feature, cover tier or excess; working with a product or proposition manager | A recommendation memo or a sanitized slide | `[grounded]` your message is silent on product |
| G3 | Test design (R7, must_have) | discovery | "Ran 14 price tests" does not say who set hypotheses, sample size or control | "Design and read" is the first half of the JD's test duty | Choosing the test cell, setting the read-out window, writing the result up | A test plan or read-out | `[grounded]` your wording |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor rating craft only | It is preferred, not required, but it is the gap you named | A bridge case with its limit stated: the craft carries over, pet-specific factors do not | Short reading on pet pricing factors, or a worked example on public data | `[inferred]` bridge from motor work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Brindlemoor (insurtech)" | The search that would have checked this did not run, so this is a standing check and not a finding. Small insurtechs often have a thin footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | JD gives no figure | I have no band to compare against, so I cannot say whether pay fits a senior post | `[grounded]` JD silence; no calibration ran | What salary range is budgeted for this post? | unresolved |
| RR3 | Team shape and reporting line unstated | unknown | — | "Own pricing analytics" | The post may be a solo analyst role or sit within a team; the JD does not say | `[grounded]` JD silence | Does this role have direct reports, and who else works on pricing? | unresolved |
| RR4 | Existing model and data depth unstated | unknown | — | "build and monitor rating models" | A new book may have little history, which limits how finely a model or a price test can be read | `[generic]` pattern for young books | Is there an existing rating model, and how much policy and claims history sits behind it? | unresolved |
| RR5 | Concrete duties and a named Director-level hiring manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is specific, with deliverables a candidate can recognise | `[grounded]` JD and your message | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the GLM rating model you "built and maintained" for the young-driver book, then the 14 price tests run with underwriting | see R4, R6a, R7 | `[grounded]` your message | pending your approval |
| P2 | Say plainly that you have not worked on pet insurance and that your rating and testing work is in motor. Do not describe it as pet experience | see R10 | `[grounded]` your message | pending your approval |
| P3 | Ask the RR1 to RR4 questions verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Do not claim people management or leadership. The JD does not ask for it | see RR3 | `[grounded]` JD | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech UK" and "Brindlemoor Senior Pricing Analyst careers"; both were refused (permission not granted). Would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote"; refused. Would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing"; refused. Would have moved the scope read and which story P1 leads with |

## Dossier offer and upgrade menu

I can write this up as `tuesday-dossier.md` if you want to keep it or reuse it later.

- Search permission, or a pasted careers page: RR1 and role reality's organization row close, and a salary band can be set against RR2.
- Your location, right to work, and any pay floor or other must-haves: R1 moves to `direct` or `hard_gate_fail`, and I can check the role against the rest.
- An answer to G1 or G2: R6b or R8b moves up.
- A sanitized SQL/Python sample, model summary or review deck: R3, R4 or R5 moves from `medium` to `high`.
- The recruiter's answers on pay and team: RR2 and RR3 close.

## Questions

Q1 (R1) — Are you UK-based with the right to work in the UK?
Q2 (G1, R6b) — On the young-driver GLM, what did you track after launch, such as actual-vs-expected, drift or refit triggers, and was that yours?
Q3 (G2, R8b) — Has any price-test result of yours gone to a product or proposition team, and what did they do with it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.