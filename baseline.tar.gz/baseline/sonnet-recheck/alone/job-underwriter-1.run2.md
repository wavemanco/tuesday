I'll read the skill's reference files before building the assessment.
**Yes, apply. You are a fit on the core: R1, R2, R3, R4 and R5 land `direct`, and R6 is adjacent. Status: `conditional_go`.** The condition is that the employer and posting verify, because I couldn't check them.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R7a (Partner with product managers on roadmap decisions) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 (`low`) is the row to firm up first; R7b and R8 have no evidence yet.

**Opportunity ledger.** The employer is unverified because research didn't run (RR1), and pay is withheld (RR2). The metrics-layer remit may bundle modeling work (RR3), and success measures are unstated (RR4). One entry runs the other way: the team shape and tooling are concrete (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Harborlight's own careers page (RR1); (2) pay and level match what you'd accept (RR2); (3) what "metrics layer" means in practice is clarified, so R6 is claimed only as far as your evidence goes (R6, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app. Not independently verified | `[grounded]` JD header |
| Mandate | Own product analytics: metrics layer, A/B test design and analysis, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; healthcare data (HIPAA) a plus | `[grounded]` JD |
| Scope read | Reads as an individual-contributor-plus-mentor senior post: two juniors, no stated manager title | `[inferred]` from "mentor two junior analysts" with no line-management language |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established; the role-family sweep did not run, so there is no pay or scope band to set the post against | `[grounded]` research status below |
| Unknowns | Pay; location and work arrangement; who owns warehouse transformations; how success is measured; how clinician partnership works day to day | `[grounded]` JD silent on each |
| Contradictions | None found between the JD and your background; the JD was not checked against a careers page | `[grounded]` provided inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit subscription company is stated. Self-reported, nothing inspectable yet. Years of experience is graded on fit, not as a gate | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is stated; "expert" is a level no artifact shows. Hiring loops for this title commonly include a live SQL exercise | `[grounded]` your background; `[generic]` on the exercise | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, at about 2M subscribers. What was yours versus the team's in that test is unconfirmed, so expect a probe | `[grounded]` your background | A sanitized experiment readout or test-design doc would raise this to `high` |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. No inspectable artifact yet | `[grounded]` your background | A redacted dashboard inventory or screenshots would raise this to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. Confirmed, no sample inspected | `[grounded]` your background | A redacted memo would raise this to `high` |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" and a monthly metrics memo sit next to metric definition. Neither says you owned canonical metric definitions, a semantic layer or LookML models. Resolving that upward would be a guess | `[grounded]` what you wrote; `[inferred]` adjacency from governed dashboards | G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | transferability | You present to the VP Product monthly, which is confirmed. That you shaped roadmap decisions is not stated. The limit is that presenting is not the same as driving a decision | `[grounded]` your background | Name one decision your analysis changed |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinical or other domain-expert partners. Subject-matter partners such as nutrition or ops staff may exist and are unmentioned | `[grounded]` your background silent | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Six years in the field, but no mentoring is stated, and none is assumed | `[grounded]` your background silent | G2 |
| R9 | Healthcare data experience, HIPAA (a plus) | preferred | adjacent | medium | transferability | No healthcare work. You have handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse, which is real privacy-data work. The limit is that HIPAA covers protected health information and a separate compliance regime, which that work did not exercise | `[grounded]` your background; `[generic]` on HIPAA's scope | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed dashboards and a metrics memo, but nothing on who defined metrics or where definitions lived | It is the first-listed responsibility, so it is the likeliest probe. Whether you owned definitions decides if R6 moves to `direct` | A canonical definitions doc (active user, retention, churn); LookML measures and dimensions others reused; resolving metric disputes between teams; deprecating conflicting dashboards | LookML snippets, a metrics glossary, a definitions page, a dashboard governance policy | `[grounded]` your background silent on definitions; `[inferred]` that resolving it moves R6 |
| G2 | Mentoring (R8, important) | discovery | Silent | A named duty ("mentor two junior analysts") that you'd otherwise have to answer from a standing start | Code or query reviews for junior analysts; onboarding a new analyst; coaching someone through their first experiment readout; an intern you supervised | A review checklist, an onboarding doc, or a name and outcome you can discuss | `[grounded]` your background silent |
| G3 | Clinician partnership (R7b, important) | discovery | Silent | Domain-expert partnership is a named duty; any analog narrows the objection | Working with nutritionists, culinary, ops or customer-care leads who weren't analysts; translating their questions into metrics | A project brief or a decision that came from such a pairing | `[grounded]` your background silent |
| G4 | Healthcare data (R9, preferred) | transferability | GDPR/CCPA PII handling and the consent-state model | A plus, not a blocker, but the privacy bridge is your strongest honest answer | Bridge: consent-state modeling and PII handling carry over. Limit: no PHI, no HIPAA safeguards, no BAA context. Strengthener: a short note on your consent-state design | A sanitized design doc of the consent-state model | `[grounded]` your background; `[generic]` that healthcare employers ask about HIPAA specifically |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be new or small, the posting may be stale or aggregated, or it may not represent a live opening. Sized `medium` because most scale-ups are simply unverified at this stage | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR2 | Compensation and work arrangement unstated | unknown | — | JD gives title, stage and requirements, with no pay, level or location | The post may be priced below what 6 years and a program-ownership background command, or may simply not publish a band | `[inferred]` from the posting's silence; no market band was established | What is the budgeted salary range and level, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Metrics-layer ownership may bundle modeling work | unknown | — | "define and maintain the metrics layer" | Owning a metrics layer can drift into owning warehouse transformations, which the JD doesn't mention | `[inferred]` from the JD's wording against its silence on data-engineering support | Who owns the warehouse transformations beneath the metrics layer, and what engineering support does this role have? | unresolved |
| RR4 | Success measures unstated | unknown | — | "Own product analytics for our care-navigation app" | An "own it" mandate with no stated first-year outcomes can mean undefined accountability | `[inferred]` from the JD's silence on outcomes | What would success look like in this role at 90 days and at a year? | unresolved |
| RR5 | Concrete team shape and tooling | positive_signal | — | "mentor two junior analysts"; "build self-serve dashboards in Looker" | A defined reporting shape and a named BI tool suggest a built-out analytics function rather than a one-person start-up role | `[grounded]` JD states both | Who do the two junior analysts report to today, and how long has the team existed? | noted |

## Application plan

Every row below is proposed, including the prose advice, and nothing is final until you approve it. Each carries its own `pending your approval`.

**Resume edits.** `resume_edits_pending_approval`. Each line uses your own wording and is not yet a baseline.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Lead the experience section with it | R3 | `[grounded]` your background, wording kept | pending your approval |
| E2 | "Built the company's Looker instance from scratch: 40+ governed dashboards." | R4 | `[grounded]` your background | pending your approval |
| E3 | "Write the monthly metrics memo read by the exec team; present monthly to the VP Product." | R5, R7a | `[grounded]` your background | pending your approval |
| E4 | "Handled GDPR/CCPA consumer PII; built the consent-state model for the data warehouse." | R9 | `[grounded]` your background | pending your approval |

**Other proposed actions.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Positioning: lead with experimentation and Looker, state plainly that your privacy work is consumer data, not health data, and don't use "metrics layer" or "mentored" until G1 and G2 are confirmed | R3, R4, R6, R8, R9 | `[grounded]` the map rows named | pending your approval |
| A1 | Confirm the posting on Harborlight's own careers site before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Put the questions of RR2, RR3 and RR4 verbatim to the recruiter or hiring manager | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app Series C" and "Harborlight Health careers Senior Product Analyst"; both were refused. It would have moved role reality's organization and contradictions rows and let RR1 resolve |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range 2026 Looker experimentation"; refused. It would have supplied the market calibration line and let RR2 be set against a band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can write all of this into a `tuesday-dossier.md` for you to keep, if you'd like that.

- **Live research on Harborlight** (employer, live posting, pay band): this would resolve RR1 and RR2 and add a market calibration line. Say the word and I'll run it if you approve search access.
- **A redacted experiment readout, dashboard inventory or metrics memo**: raises R3, R4 or R5 to `high`.
- **An answer to G1**: R6 can move to `direct` and the decision firms up.
- **A hiring manager's name**: role reality's scope read, and which story to lead with for that reader.

## Questions

1. **Constraints.** Do you have a pay floor, location or work-arrangement limits, or a visa or schedule term? Any of these could become a hard gate, and the posting is silent on them.
2. **G1.** Did you own metric definitions at your company, such as a canonical definition of retention or churn that others built on? If so, where did they live (LookML, a doc, a glossary), and who relied on them?
3. **G2.** Have you mentored or reviewed the work of junior analysts? Who, what did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.