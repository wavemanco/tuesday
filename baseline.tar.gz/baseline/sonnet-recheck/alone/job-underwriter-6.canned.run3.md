## Decision snapshot

**Yes, worth applying to, as a stretch with two named gaps (R6, R7a). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid, two days in office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R7b (Working with finance on revenue data) · absent: R7a (Working with finance on billing data)
- `important`: direct: R8

The decision turns on R6 and R7a. R7b (`low`) is the row where one answer from you could change the picture.

**Opportunity ledger.** Sound on what I could check: the employer exists and the salary sits inside the market band (RR5), and a revenue operations head is in post (RR6). The open items are an uncorroborated listing (RR1), a bundled scope (RR2), no stated first-year outcomes (RR3) and unstated option terms (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid, two days in office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 are checked against your own limits on location and pay; either one failing makes this `no_go`. (2) The role is confirmed live on Quillfield's own channels (RR1). (3) R6 and R7a are presented as what they are: adjacent pipeline work and an unproven area, never forecast or billing ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, which makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` Quillfield "About" page (search result) |
| Mandate | Own CRM and billing data, build the pipeline and renewal reporting that sales and finance run on, and run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posted range sits inside that band, close to the median. This is a market band, not Quillfield's offer, and it covers pay only (no scope norms found) | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting for the figure |
| Reporting line | Probably under Tamsin Achebe, who is publicly listed as Head of Revenue Operations at Quillfield and previously spent four years as a sales operations manager at Corvane Payments | `[grounded]` search-result snippet of her profile; `[inferred]` that she is the manager the recruiter named, from the matching name and company; `[inferred]` that this is the reporting line |
| Scope read | Four jobs in one post: CRM ownership, billing data, reporting, and the forecast | `[inferred]` from the posting's responsibility sentence |
| First-year outcomes | None stated | `[grounded]` posting is silent |
| Unknowns | Team size, which billing system, who owns the forecast model today, option terms, whether this is a new post or a backfill | — |
| Contradictions | None between the posting and the About page. Quillfield's careers page could not be fetched, so the listing is not corroborated there (RR1) | `[grounded]` fetch of quillfield.co.uk/careers returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You gave no location or schedule limit, so there is no statement to grade. Whether the terms suit you is not established | `[grounded]` posting terms; no candidate statement | G3 |
| R2 | Salary £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | You gave no pay floor. The figure is stated and sits in the market band, but I can't call it met without your floor | `[grounded]` posting; `[generic]` band | G3 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team, so the years and function match. The posting says "software company" and you said "payments company", so I haven't assumed the product was software | `[grounded]` your intake message; self-report, nothing inspected | Say plainly what the company sold when you apply |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified and you rebuilt the dashboards. The credential is checkable but I haven't seen it | `[grounded]` your intake message | A credential link would raise this to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily is confirmed use. "Strong" and "modelling" (as opposed to reporting) are not shown | `[grounded]` your intake message; the modelling question is open | Covered by G1 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which feeds a forecast. You have never owned the company forecast, and finance did. The bridge stops short of building the number, being accountable for it, or presenting it to a CFO | `[grounded]` your intake message; the limit is your own statement | G1 |
| R7a | Working with finance on billing data | must_have | absent | none | capability | You say you have never worked on billing data. I have no adjacent evidence for it yet | `[grounded]` your intake message | Closure path in G2 |
| R7b | Working with finance on revenue data (the posting says "billing or revenue data") | must_have | unclear | low | discovery | Renewal dashboards touch revenue figures. Whether you worked with finance on them or reconciled them is not established, and I won't upgrade it from the dashboards alone | `[inferred]` from the renewal dashboards you built | G2 |
| R8 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt both sets of dashboards. Whether finance used them is unconfirmed | `[grounded]` your intake message | A sanitized screenshot would raise this to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have), with modelling depth (R5) | transferability | The monthly pipeline review is a real bridge. Nothing shows a forecast you built or were accountable for | The posting makes running the CFO forecast a headline duty, so this is the likeliest probe | A UK-team or renewals forecast you submitted to your sales director or finance; a weighted-pipeline or coverage model; commit-versus-actual tracking you maintained; Excel models others relied on | A sanitized forecast-versus-actual sheet, a coverage model, a forecast dashboard screenshot | `[grounded]` your own limit on forecast ownership; `[generic]` that forecast ownership is the central test for this title |
| G2 | Finance data work (R7a, R7b, must_have) | discovery | R7a is your own "no". R7b is open: the renewal dashboards may involve reconciling to finance's numbers | The posting says "billing or revenue", so a real R7b answer could carry the requirement | Reconciling renewal or bookings figures against finance's records; month-end or quarter-end closes with finance; contract value, invoice or failed-payment data from your payments job | A reconciliation sheet or a renewal report finance signed off | `[grounded]` your intake message; `[inferred]` that payments data may offer a bridge |
| G3 | Location and pay fit (R1, R2, hard_gate) | hard_gate | The posting states both terms. Your limits aren't known | A failed gate means `no_go` however strong the fit elsewhere | — | — | `[grounded]` posting terms |

For R7a, a realistic closure path is to learn Quillfield's billing system and its data model before an interview, and to ask which system it is (RR2's question covers it). Wording can't close this gap.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Listing not corroborated on the company careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The careers page may sit at another address, or the role may be advertised only on the job board | `[inferred]` from the fetch returning no page | Is this role listed on your own careers site, and is it a new post or a replacement? | unresolved |
| RR2 | CRM, billing data, reporting and forecast bundled in one post | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting … and run the quarterly revenue forecast" | The post may carry several jobs, softened by a Head of Revenue Operations being in place | `[inferred]` from the posting's responsibility sentence; `[grounded]` her listed title | Who else is on the revenue operations team, and who administers the billing system today? | unresolved |
| RR3 | No first-year outcomes stated | unknown | — | "run the quarterly revenue forecast with the CFO" | A demanding mandate with no stated success measures | `[grounded]` posting silent on outcomes | What would success look like at 90 days and at one year? | unresolved |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | The options' size, vesting and strike price are unknown | `[grounded]` posting silent on terms | What is the option grant, vesting schedule and strike price for this post? | unresolved |
| RR5 | Salary inside the market band | positive_signal | — | "£61,500–£67,000" | The posted figure is stated and consistent with the role-family band | `[grounded]` posting; `[generic]` Ledgerline band | What does the range depend on within the post? | noted |
| RR6 | A revenue operations head is in post | positive_signal | — | "Head of Revenue Operations, Quillfield" | The function has an owner, so the lead is unlikely to be building it alone | `[grounded]` profile snippet; `[inferred]` from that title | What is the split of work between the head and this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check location, the two office days and your pay floor against R1 and R2 before spending effort | The gates decide `no_go` | `[grounded]` G3 | pending your approval |
| A2 | Lead with the pipeline review you run with your sales director and the dashboards you rebuilt, for a reader who is a revenue operations head with a payments sales-operations background | These are your strongest verified rows (R8, R4) and the bridge to R6 | `[inferred]` from her public title and prior role; `[grounded]` R4, R8 | pending your approval |
| A3 | Say plainly that finance owned the company forecast and that your input was the pipeline review. Don't write "owned" or "ran" the forecast | Truthfulness: R6 is `adjacent`, and "owned" would be a claim at `none` | `[grounded]` R6, your own statement | pending your approval |
| A4 | Ask the register's verification questions (RR1–RR4) verbatim in the loop | They double as interview preparation | `[grounded]` register | pending your approval |
| A5 | Build one small sanitized forecast-versus-actual or reconciliation sample from non-confidential data, if G1 or G2 turns up nothing | It narrows the limit on R6 and R7 | `[inferred]` from G1, G2 | pending your approval |

I haven't seen your CV, so no resume edits are proposed yet. Any wording on it would be `resume_edits_pending_approval`.

## Evidence status

Verified: none yet. Your intake message is self-report, so its claims sit at `medium` at most.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved the market calibration row and RR5. It gave no scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), read as a snippet only. Moved the reporting-line row, RR6 and A2 |

I can save all of this as `tuesday-dossier.md` for you to keep.

## Upgrade menu

- Your CV would let me map claims against your own wording, and propose repositioning edits for approval.
- A Salesforce credential link would raise R4 to `high`.
- A sanitized dashboard screenshot would raise R8 to `high`. A forecast-versus-actual sheet or coverage model would firm up R6 and R5.
- Your location and pay floor would settle R1 and R2.
- The recruiter's answers on RR1 to RR4 would close or reduce the open items.
- A deeper research pass on Quillfield (funding follow-ups, leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G3 — Does Bristol with two office days a week work for where you live, and is £61,500–£67,000 above your pay floor?

G1 — Have you built or maintained any forecast, even for the UK team or renewals only, or an Excel revenue model? If so, who used it, and what was actually yours?

G2 — Did you reconcile renewal or revenue figures with finance, or work with payment or invoice data at your current employer? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.