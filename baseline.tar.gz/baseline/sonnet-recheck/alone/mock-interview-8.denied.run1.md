I've built your prep pack for the three rounds on 21 October. The recruiter's email set the structure, so it has a shared fit snapshot and a separate bank for each round. The panel round also has a cheat sheet for the four values.

You said you copied the values on 12 October and the rounds are on 21 October. This session's clock reads 5 November. I built for the dates you gave. If 21 October has already passed, tell me what happened and I'll rework the pack as follow-up prep.

- **Research:** I ran no searches. Your pasted values, the recruiter's email and the strategy points already fixed everything a search could change. The pack's Sources section shows each target and why it was skipped.
- **Strongest evidence:** Your complaints log, the monthly spreadsheet you built and the teller escalation training are your best material. The pack keeps your answers at exactly that scope.
- **Gaps you stated:** You said you've never worked in a contact centre and never presented above regional level. The pack coaches you to say each plainly, then give a plan, and never to cover them over.
- **Where the pack asks you for facts:** Your material is silent on what the spreadsheet counted, whether it's Excel, what rules governed the log, coaching supervisors, and digital teams. The pack leaves answer slots for those and does not fill them in for you.
- **Highest-ROI prep:** Question B4, in the Head of Member Services round. It asks what makes you the right person for a process across branches and the contact centre when you've handled one branch's log.

The pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-denied-d0c1e84f/2c09deda-59cc-41d9-96e6-c56dea131f98/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md

Say the word and I'll play the Head of Member Services on B4 with live follow-ups, then give you feedback against that question's guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara. Loop mode: three rounds on 21 October, per the recruiter's email. Interviewers beyond their roles are not yet assigned, so no interviewer read is included. Round 1 is the recruiter (30 minutes). Round 2 is the Head of Member Services, your would-be manager (45 minutes, mostly behavioural). Round 3 is a panel of two branch managers (60 minutes, including a 20-minute complaint-escalation case), and it is also the values round.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioural or values alignment: does past behaviour show the published values |
| EXP | Work-experience deep-dive: do your own claims survive a follow-up |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework and altitude |
| CASE | A live problem from the role, worked aloud |

An answer slot is an instruction for the interview, not a question for this chat. Where one appears, answer it from your own experience, and if the practice it names was not yours or never existed, the honest branch is to say so plainly and return to what you did.

## Fit snapshot (shared across all three rounds)

No row is a hard gate: the JD's years requirement is experience, not a term you meet or do not.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and nothing was inspected behind it. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If you had any part in what happened to a complaint beyond logging it, say what and whose decision it was; if not, say so plainly and stay with the log |
| F2 | "the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote reaches a monthly complaints spreadsheet and does not show what it counted. Answer slot: the JD names volumes and resolution times. If the spreadsheet counted either, say what was counted and how; if it did not, say so plainly and say what it did hold |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel, and ambiguity resolves downward. Answer slot: say which tool it is built in; if it is Excel, say what you did in it in your own words; if it is another tool or you are unsure, say so plainly |
| F5 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then a plan for it, said as a plan. Never a claim to senior-leader presenting |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | The years are there; the JD's phrase and yours differ. Lead in your own terms: six years in retail banking, the last three as a branch supervisor, and let the interviewer make the match |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says a formal log, not what rules governed it. Words stay at "I handled the branch's formal complaints log." Answer slot: say what handling it involved and what part was yours; if part of it was recording for others to act on, say so plainly and return to the log |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you have ever helped a fellow supervisor with an escalation, say what and what part was yours; if not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent, which is not the same as no experience. Answer slot: if you have ever flagged or fed back on an online or app journey, say what and what part was yours; if not, say so plainly and say what you would ask a digital team first |

## Grounding brief (from the strategy points you sent)

| Point (as you gave it) | Why it matters in this loop | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | Connects straight to the JD's self-service line (F9). Expect it in Rounds 1 to 3; bring a question about complaints in digital channels, not a recital | [grounded] |
| "consolidate eight branches into five hubs over 2027" | Bears on "Neighbours, Not Numbers". Round 3 interviewers are branch managers, and the interviewers are unassigned, so do not assume whose branch is affected; be neutral and respectful | [inferred] |
| "launch a small-business lending product in Q1 2027" | A new product is a new kind of member contact. A light point only: be ready to say you would want to know how complaints on it will be captured | [inferred] |
| "the main competitive pressure is app-only banks" | Frames the digital push as defensive. In Round 3, think about what members still want from a person when something goes wrong | [grounded] |

The brief is equally available to every candidate. Bring one point to show grounding, then one view of your own on how it touches complaints.

---

# Round 1: Recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly journey and motivation questions | 5 questions. Recruiter-screen prior is conversational plus a light skeptic, and casual questions here are still scored | A short arc for the journey question; treat every casual question about a JD topic as scored |
| Skeptic (light) | Knockout checks on the two gaps you have stated | 2 questions. Same prior; F2 and F5 are the two obvious checks | Say each gap first, plainly, then the plan |
| Prober (light) | One question on the spreadsheet | 1 question. It is the only artifact in your material, and a recruiter may test it | Know what it holds; say plainly what you do not know |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Ninety seconds, three beats: six years in retail banking; the last three as a branch supervisor; then where you want to go. Stop before detail the quote does not carry. Answer slot: why complaints in particular. If a moment pointed you here, say it; if it was gradual, say so | F6 is the evidence and the recruiter will check it against the JD. EXP because it tests your own story, delivered conversationally |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Choose something you actually care about from what you have read: the posting calls Ashgrove member-owned, and the values include "Neighbours, Not Numbers" and "Members First, Always". Say in your own words why one of them matters to you. Do not claim familiarity with Ashgrove beyond the values page and the strategy points | A motivation check at the front of nearly every screen. CO because it tests homework; the values are the raising source |
| A3 | "Why move from branch supervision into a lead role on complaints?" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Name the two things your material carries, in those terms: you handled the branch's formal complaints log, and you built the monthly complaints spreadsheet. Answer slot: the reason is yours. If you sought the complaints work out, say what drew you; if it came to you, say so plainly and say what kept you with it | Motive consistency is the recruiter's job. F7 and F3 are the evidence the move rests on |
| A4 | "What have you picked up about where Ashgrove is heading?" | CO | [grounded] | Pick two points from the brief in its own words: moving 40% of member service to digital channels by 2028, and consolidating eight branches into five hubs over 2027. Link one to the complaints role as a question you would want answered, not a statement about what Ashgrove does. Do not recite all four | The brief is shared with every candidate, so judgment, not recall, is what separates answers. CO because it scores strategy awareness |
| A5 | "Anything we should know on notice period, pay expectations or location?" | JD | [generic] | Logistics are scored for clarity. Answer slot: your notice period, pay expectation and location constraints are yours to state; none are in your material and this pack supplies none. Say them plainly, or ask what the range is | Recruiter screens carry knockout checks. `[generic]` because it is a pattern, not a fact about Ashgrove |
| A6 | "This role covers the contact centre. How do you feel about not having worked in one?" | JD | [grounded] "Never worked in a contact centre" | Say the fact first: "I've never worked in a contact centre." Then the plan: you would want time with the people who take the calls and the complaints that reach them before suggesting changes. Nothing that implies an equivalent; do not offer a comparison from your branch work | F2 is a stated gap, and a recruiter will raise it early because it is a knockout in a friendly voice. JD because it scores the stated requirement |
| A7 | "You'd be reporting monthly to senior leaders. How do you feel about presenting to them?" | JD | [grounded] "I've never presented to anyone above regional level" | Say the fact first: "I've never presented to anyone above regional level." Then the plan: ask who the audience is and what format they want, and rehearse with your manager before the first one. Answer slot: if you have presented results at regional level, say how it went; if they were sent rather than presented, say so plainly | F5 is a stated gap against a named requirement. JD because it is the stated requirement, asked kindly |
| A8 | "Tell me about the complaints spreadsheet. What tool is it in, and what does it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the quote states: you built it, it is monthly, your regional manager uses it. Answer slot: say which tool it is in; the JD names volumes, resolution times and Excel, so if it counted either or is built in Excel, say what and how; if it did not, say so plainly and say what it held. Weakest-assumption slot: if one part of it would be challenged, say which you would defend least; if you do not know how a figure in it was counted, say that | F3 and F4 are the discovery gaps a recruiter can check in one question. EXP because it tests what is actually yours |

## Reverse questions for Round 1

| Question | Why it lands |
|---|---|
| "Will I be given anything for the 20-minute case beforehand, or does it come in cold?" | It is a practical question that tells you how to prepare, and it shows you are treating the case as a graded part of the loop |
| "How does the panel's scoring against the four values feed into the final decision?" | It shows you read the values and the process, and gets a sense of weight across the rounds |
| "What does the first quarter look like for whoever takes this role?" | A forward-looking question that lets the recruiter describe priorities, and gives you something to tie to in Round 2 |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Experience-based "tell me about a time" questions | 3 questions. The recruiter said the round is mostly behavioural | Story-map where a quote carries a story, use a selection scaffold where none does; "we" for context, "I" for contribution |
| Skeptic | Probes on the contact-centre and senior-presenting gaps | 3 questions. A hiring manager is buying capability and de-risking gaps, and F2 and F5 are stated | Rehearse the single objection until it is boring: hold what the quotes carry, concede the rest specifically |
| Prober | Asks what the log and spreadsheet actually contain | 2 questions. A manager who reads closely will go to F3, F4 and F7 | Know what you can and cannot say about how things were counted; say plainly when you do not know |
| Case/Strategist | A reporting design question and a digital-channels question | 2 questions. The hiring-manager prior includes live problems, though the live case is announced for Round 3 | Clarify, then structure, then answer; use Ashgrove's own words |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you helped a colleague handle an escalation better." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F8: the tellers were new, and what you trained them on was the escalation script. Those are the beats the quote states; tell them in your own words. Answer slot: the JD asks about coaching supervisors. If you have helped a fellow supervisor with an escalation, say what and what part was yours; if not, say so plainly and stay with the tellers and the script. If no moment comes to mind, say so plainly, then give the nearest thing your material does carry | The coaching line in the JD is the part of the role your material carries only at teller level (F8). VAL because it scores behaviour, with a JD theme |
| B2 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a message you put in plain words, and a relationship still intact afterwards. Say what you said and what changed, not a version where everyone agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem that fits a role reporting monthly to senior leaders. `[generic]` because no quoted sentence carries a story for it |
| B3 | "Tell me about a time you disagreed with how a complaint was being handled." | VAL | [grounded] | Selection scaffold: pick a case where the disagreement was about the member's outcome, name who you raised it with, and say what happened. Plain Words and Own the Fix are both visible if you choose well, without mentioning them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The theme comes from the JD's escalation line. VAL because it scores judgment and spine |
| B4 | "This role owns the process across branches and the contact centre. You've handled one branch's log and haven't worked in a contact centre. What makes you the right person?" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "Never worked in a contact centre" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I handled the branch's formal complaints log, and I built the monthly complaints spreadsheet our regional manager uses." Then concede before asked: "I've never worked in a contact centre." The limit, as the pack's observation: your material says one branch's log, not the process across branches. Follow-up 1, "that's one branch": return to the log at its own scope; answer slot: if the log or spreadsheet reached other branches in any way, say how; if not, say so plainly. Follow-up 2, "what do you do in 90 days": a plan, not a past: learn how the contact centre handles complaints from the people doing it, ask who owns what between branch and contact centre today, change nothing first. Follow-up 3, "they won't take direction from someone who hasn't done their job": concede the point specifically ("that's fair, I haven't, and I'd need to earn it by learning their work first") and do not fold on the core: the log and the spreadsheet at their own scope | F1 and F2 together are the sharpest objection to this candidate, and one that will arrive in some form. JD because it scores the stated requirement; the Skeptic delivers it, so the hold-then-concede structure applies |
| B5 | "What's your experience of presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Say the fact first: "I've never presented to anyone above regional level." Hold through a second follow-up ("our senior team is blunt, how will you cope?") by answering with a plan: agree what decision each report is for, keep page one to the point, and rehearse with your manager first. Answer slot: if you presented to your regional manager, say how it went; if the spreadsheet was sent rather than presented, say so plainly | F5 is a stated gap against a named requirement, so a manager will test it. JD because it scores the requirement |
| B6 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one of the two in your own words and say it first. Then the first-weeks plan for it, said as a plan. Do not invent a weakness that sounds safe, and do not claim you have none. Calibrated candor beats bluffing a competency your interviewer owns | F2 and F5 are the candid answers, and a manager reading your material will expect one of them. JD, delivered as a Skeptic stem |
| B7 | "Walk me through the branch's formal complaints log. What did handling it involve?" | EXP | [grounded] "I handled the branch's formal complaints log" | The beats the quote states: a formal complaints log, the branch's, handled by you. Answer slot: the JD asks for experience handling regulated complaints, so expect a probe on what governed the log. If rules or deadlines outside the branch applied to entries and you worked to them, say what they were and what your part was; if you do not know what governed it, or the log was a record others acted on, say so plainly and return to the log | F7 is the requirement your material reaches least directly. EXP because it tests what was actually yours; JD because it carries the regulated-complaints line |
| B8 | "What's in the spreadsheet you built, and which part would you trust least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the quote states: you built it, it is monthly, your regional manager uses it. Weakest-assumption slot: name the part you would defend least, in your own words; if you do not know how something in it was counted, say that plainly. Answer slot: if it counted volumes or resolution times, say how each was counted; if it did not, say so plainly and say what it held | F3 and F4 are the defend-the-number items. A figure explained by the pack would be one you could not repeat, so none is supplied |
| B9 | "Design the monthly complaints report for our senior leaders. What goes on page one?" | CASE | [grounded] | Clarify first: who reads it, what decision it supports. Then the two measures the JD names, volumes and resolution times, in plain words a reader needs no second explanation for. Split by branch, contact centre and digital channel; add a line on how members were treated, not only counts. Risk to name: what counts as a complaint may differ between channels, so ask. No claim about your past | The JD's reporting line asks for exactly this deliverable. CASE because it is a live problem; Plain Words is visible in the design |
| B10 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that do to complaints?" | CO | [grounded] | Think aloud: what member service includes; how complaints enter through digital routes; where a self-service journey that fails could go unseen; what the complaints lead would want from digital teams. Answer slot: the JD asks you to work with digital teams. If you have flagged or fed back on an online or app journey, say what and what part was yours; if not, say so plainly and say what you would ask the digital team first | F9 is silent in your material, and the JD's self-service line is the strategy's main hook. CO because it tests altitude; CASE in delivery |

## Reverse questions for Round 2

| Question | Why it lands |
|---|---|
| "Where does the complaints process work well today, and where does it leak between branches and the contact centre?" | It shows you think end to end and gives you the manager's real picture |
| "Who would I be presenting to, and how often?" | It addresses the F5 gap head-on and gets the format without claiming anything |
| "How does the 40% digital target change what the complaints lead is accountable for?" | It ties the role to the strategy brief and invites the manager's view |
| "What would you want to see from me in the first three months?" | It makes the manager define success, and gives you a measure to work toward |

---

# Round 3: Panel of two branch managers, including the values round (60 minutes)

## Persona weights

The panel's members are not named, so the personas below are blended for the panel as a whole.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Stories scored against the four published values | 4 questions. The recruiter said the panel scores against the four values, so one question each | Map a story to each value; where none is carried by your material, use the scaffold and its honest branch |
| Case/Strategist | The 20-minute complaint-escalation case, plus one strategy question | 4 questions. 20 of the 60 minutes are a case, per the recruiter | Clarify, then structure, then answer; think aloud; challenge one premise respectfully |
| Peer Evaluator | Seam questions: the branches are the panel's, the role coaches their supervisors | 1 question. Branch managers sit beside the supervisors you would coach (inferred from the role) | Reciprocity: what you bring their branch, not only what you need |
| Skeptic | The supervisor-coaching gap in collegial packaging | 1 question. F8's gap returns here because it is their staff | Hold what the quotes carry; say plainly what is not yours |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided from the member's side of the counter when it was the harder option." | VAL | [grounded] | Value: Members First, Always. Selection scaffold: pick a decision with a named alternative that was easier for the branch, say who it was harder for, and say what the member's outcome was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value is the raising source, and no quoted sentence in your material carries a member-side decision, so this is a scaffold. VAL because it scores published values |
| C2 | "When has something you explained needed explaining twice?" | VAL | [grounded] "trained new tellers on our escalation script" | Value: Plain Words. Story-mapped on F8: the beats are the tellers and the escalation script. Answer slot: if anyone needed it explained twice and you changed the wording or how you taught it, say what changed; if that never happened, or the script was not yours to change, say so plainly and describe how you taught it | The value's own test is "if a member needs it explained twice, we wrote it wrong", and F8 is the nearest material. VAL because it scores the value |
| C3 | "Tell me about something you did for a branch's community, beyond the counter." | VAL | [grounded] | Value: Neighbours, Not Numbers. Selection scaffold: pick something specific to a town, say what you did and who benefited. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not stretch a routine task into community work | No quoted sentence carries a community story, so this is a scaffold. VAL because the value is published |
| C4 | "Tell me about a problem you found that wasn't yours, and what you did to keep hold of it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Value: Own the Fix. Selection scaffold: a problem you found, why it was not yours, and the moment you kept hold of it until it was solved. Answer slot: if the spreadsheet began as a fix for a problem you found, say what the problem was and how you kept hold of it; if it was asked of you, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry | The value's own definition is "whoever finds the problem keeps hold of it". F3 is the only artifact you built, so it is the one place a story might sit; it is not assumed |
| C5 | "A member has complained three times. Each time the branch says the contact centre has it, and the contact centre says the branch has it. They arrive at the counter. Walk us through it." | CASE | [generic] "our escalation script" from "trained new tellers on our escalation script" | Structure: clarify what the member was told and what has been logged; objective, the member leaves knowing who holds it; today, one named owner (Own the Fix); tell the member in plain words (Plain Words); then trace why it bounced, record it, report it. Challenge one premise respectfully, such as whether it was ever logged as formal. Answer slot: if your escalation script covers a handoff like this, say what it told tellers to do; if not, say so plainly and say how you would structure it | The recruiter named a complaint-escalation case; this is a pattern for it, not a prediction of the actual scenario. CASE because it is a live problem with no claim about your past |
| C6 | "Same member: the contact centre told them something different from what the branch said. What do you do, and what changes so it can't happen again?" | CASE | [generic] "Never worked in a contact centre" | First the member: who holds it, what is the right answer, tell them in plain words. Then the cause: where each channel records what it tells members. Ask the contact centre to walk you through its side before proposing any change, and say plainly "I haven't worked in a contact centre, so I'd start by asking how they handle it." Then how you would review it jointly | This case presses on F2 from inside the work. CASE because it asks for structure; the stated gap is acknowledged, not hidden |
| C7 | "A branch supervisor escalates every complaint to you without trying anything first. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Clarify why they escalate: unclear script, fear of getting it wrong, or something else. Agree what they can resolve themselves, keep the supervisor holding the member's case while you help, and check back. Say plainly that the nearest thing in your material is teaching tellers a script, not coaching supervisors | The JD's coaching line, set as a decision. F8 is the nearest material, so the limit is named before it is asked for |
| C8 | "App-only banks are Ashgrove's main competitive pressure. What do members still want from a branch when something goes wrong?" | CO | [grounded] | Think aloud and mark it as a view. Ask what a member wants when the issue is emotional or complex, where self-service journeys might fail and send people to a counter, and what Plain Words and Neighbours, Not Numbers mean for a hub. Say plainly that you do not know Ashgrove's complaint data. No claim about what app-only banks do | The competitive frame is in the brief you were sent. CO because it tests strategic altitude; the panel are branch managers, so ground it in the counter |
| C9 | "You'd coach our supervisors, but the branches are ours. Where's the seam between your role and a branch manager's, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map you cannot know: the member keeps one owner; the branch manager owns the branch's decisions; the lead owns the process and the reporting. When you disagree, bring the case facts, not a position. Reciprocity: say what you would give their branch, such as reporting on its own complaints, and ask what they would want | A peer stem. JD because it tests the role boundary; the panel are the people the seam affects |
| C10 | "Our supervisors have years in the job. Why would they listen to you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Hold what the quotes carry: six years in retail banking, the last three as a branch supervisor, and you trained new tellers on the escalation script. Answer slot: if you have coached a fellow supervisor, say what and what part was yours; if not, say so plainly. Then a plan: listen to what is hard about escalations for them first | F8 and F6 are the evidence for credibility. A Skeptic's version of the coaching line, asked collegially |

## Values cheat sheet

| Value | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, not the branch's | No quoted sentence carries a story. Scaffold C1, with its honest branch |
| Plain Words | If a member needs it twice, the wording failed | F8: "trained new tellers on our escalation script". See C2 |
| Neighbours, Not Numbers | Each branch is part of its town | No quoted sentence carries a story. Scaffold C3, with its honest branch |
| Own the Fix | The person who finds a problem keeps hold until it is solved | F3: "I built the monthly complaints spreadsheet our regional manager uses". See C4, with its answer slot |

## Reverse questions for Round 3

| Question | Why it lands |
|---|---|
| "What do your supervisors find hardest about escalations, and what would help you most from this role?" | Reciprocity with branch managers: it puts their need first and tells you what the role must give them |
| "As the hubs take shape, what would you want a complaints lead to protect for your branch's members?" | It speaks to Neighbours, Not Numbers without assuming whose branch is affected |
| "Which of the four values is hardest to hold in a branch day to day?" | It shows you read the values and invites an honest answer, which is a real signal |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches (F1) | B4, B7, C5 |
| the contact centre (F2) | A6, B4, C6 |
| report monthly on complaint volumes and resolution times (F3) | A8, B8, B9 |
| comfortable with Excel reporting (F4) | A8, B8 |
| confident presenting to senior leaders (F5) | A7, B5, B6, B9 |
| 4+ years in financial-services customer operations (F6) | A1, A3, C10 |
| experience handling regulated complaints (F7) | B7 |
| coach branch supervisors on escalations (F8) | B1, C7, C10 |
| work with digital teams on self-service journeys (F9) | A4, B10, C8 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not the process across branches |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says a formal log, not what governed it |
| Worked in, or has contact-centre equivalent experience | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F5 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Coached supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says tellers and a script, not supervisors |

## Sources

Provided documents: the job description; the four published values as you pasted them (copied on 12 October 2026 from ashgrovecu.org/about/values); the recruiter's email on the three rounds; the four strategy points from Ashgrove's June 2026 strategy brief as you gave them; your background message. No dossier was present. Searches sent: none. Pages fetched: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | The four values are pasted, so the values cheat sheet and the VAL questions stand on them |
| 2. `Ashgrove interview process member services` | skipped | The recruiter's email fixes the three rounds, who runs each and which is the values round, so persona weights and round structure follow it |
| 3. `Ashgrove strategy` / recent news | skipped | The four strategy points you gave fix the grounding brief and the CO questions |
| 4. interviewer name and company | n/a | No names have been assigned, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- The interviewers' names and roles, once assigned → an interviewer read, per-member persona weights for the panel, and a reverse question tied to a real career path
- Any pre-reading or brief for the 20-minute case → C5 to C7 move from `[generic]` patterns to the actual scenario
- Your answers to the slots in F3, F4, F7, F8 and F9, said outside a drill → those rows are regenerated with your words in the evidence column, and several bank answers become story maps
- Your branch's escalation script and an anonymised view of the monthly spreadsheet, if you are free to share them → F3, F4 and F8 can move from medium to high confidence, because those are the artifacts a retail-banking supervisor keeps
- The full text of the strategy brief → the grounding brief moves from your summary to quoted lines, and CO questions sharpen
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports and recent organisational context; say the word if you want it
- How much prep time you have → a prioritised prep triage, sized to it
- A tuesday-dossier.md from job-underwriter, if you have one → verified evidence and a prohibited-claims list that could tighten the bank
