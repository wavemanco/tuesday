I'll read the reference files the skill requires before building the assessment.
**Short answer: probably yes on fit, but not yet.** The posting contradicts itself on working pattern (R1), and you need to settle that before you spend effort. Status: `hold_pending_answers`.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote working pattern)
- `must_have` — direct: R2, R3, R4a, R5, R6, R7 · unclear: R4b (monitor rating models)
- `important` — unclear: R8 (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance domain)

R1 decides the status. R10 is a bridge with its limit named in the map.

**Opportunity ledger.** The scope and reporting line are clear (RR3). The JD and the company's careers page disagree on where the work happens (RR1). Salary (RR2) and team and tooling (RR4) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote working pattern); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers:**
  - Your own answer on whether four days a week in Leeds is workable. This is Q1 below.
  - Brindlemoor's answer on which version is true (RR1).
  - If the role is genuinely remote, or Leeds works for you, this likely moves to `go`. If it is office-based and that doesn't work for you, it becomes `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, pet-insurance insurtech. The careers page for this role is live and says "Accepting applications" | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD and careers page |
| Reporting line | Director of Pricing, Odile Varga | `[grounded]` JD; careers page confirms "reports to the Director of Pricing" |
| Working pattern | **Contradiction.** The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both texts |
| People management | Not stated as a requirement or a responsibility | `[grounded]` JD silence |
| Pet-insurance experience | Not listed as a requirement. The JD asks for "insurance experience a plus" | `[grounded]` JD |
| Hiring manager | Director of Pricing. Public footprint: spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result snippet; the profile page was not fetched |
| Compensation | Not in the JD as pasted or in the careers-page text retrieved. A 2026 UK survey of senior pricing analysts at insurers and insurtechs (n=612) gives a median base of £58,400 and an interquartile range of £52,100–£64,900. This is the band to expect, never Brindlemoor's offer (RR2) | `[generic]` Pricewell 2026 survey snippet; `[grounded]` for the missing salary |
| Market calibration | Only salary was searched. How this title and scope compare with role-family norms is not established | `[generic]` |
| Unknowns | Working pattern, salary, team size, data and tooling, first-year outcomes | `[grounded]` JD and careers page silence |

## Evidence map

Your background was given as prose, which counts as self-report. Nothing is above `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working pattern | hard_gate | unclear | none | hard_gate | The JD says remote and the careers page says Leeds four days a week. You have not told me where you are based or what you will accept, so no constraint of yours is on record | `[grounded]` both texts; `[grounded]` no stated constraint | Q1; RR1's question to Brindlemoor |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You gave 5 years in pricing analytics at a UK motor insurer. Self-report, no document yet. Years of experience is not a gate | `[grounded]` your background | CV to confirm |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your insurer's young-driver book. Confirmed and specific, no inspectable artifact yet, so expect a probe | `[grounded]` your background | A sanitized model-documentation page would raise this |
| R4a | Build rating models | must_have | direct | medium | none | Same evidence as R3: you built and maintained that model | `[grounded]` your background | As R3 |
| R4b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which may include performance monitoring. You did not say so, so I won't assume it | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | Q2 |
| R5 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team | `[grounded]` your background | A sanitized test readout would raise this |
| R6 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is self-assessed | `[grounded]` your background | A code sample would raise this |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting is covered; actuarial leads are not mentioned | `[grounded]` your background | A review deck would raise this |
| R8 | Turn results into recommendations for underwriting and product | important | unclear | none | discovery | Underwriting is plausibly covered by your tests and reviews. Nothing you said touches product | `[grounded]` your background silent on product | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain (inferred from the product named in the JD; the JD does not list it) | preferred | adjacent | medium | transferability | Motor GLM pricing is credible adjacent work. The limit: you have exercised none of pet-specific pricing. Pet and motor differ in rating factors and claims data | `[inferred]` from your motor work and the JD's product; `[generic]` that the two lines differ | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | Two sources disagree and your constraints are not on record | A gate that can flip the decision either way | Not applicable: this is a term you meet or don't | The recruiter's or hiring manager's written answer | `[grounded]` the two texts |
| G2 | Monitoring rating models (R4b, must_have) | discovery | The CV prose says built and maintained, but not how performance was tracked | A must-have at `unclear`. The hiring manager's published talk is on monitoring, so a real example is the one most worth having | A regular model-performance review; actual-vs-expected tracking; drift or segment checks; a re-fit triggered by what monitoring showed | A monitoring pack, a dashboard screenshot, a re-fit paper | `[grounded]` your wording; `[inferred]` the talk topic makes this the likeliest probe |
| G3 | Recommendations to product (R8, important) | discovery | Underwriting recommendations are evidenced; product ones are not | Posting names both audiences | A test result that changed a product feature, cover tier or pricing structure; a pricing review that fed product planning | A recommendation paper or review slide | `[grounded]` your background silent on product |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor pricing carries over. Pet-specific rating does not | Preferred and inferred, so a risk to frame honestly, not a blocker | Any personal-lines work outside motor; any work on claims-cost or frequency drivers that would transfer | A short note on what you would check first in an unfamiliar book | `[inferred]` bridge from your motor work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts itself (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | Either the JD or the careers page is out of date, or the role is office-based and the remote claim is wrong | `[inferred]` from two texts disagreeing | Is this role fully remote, or based at the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | No figure in the JD or the careers text retrieved | Pay may sit above or below the survey band, or the company simply doesn't publish it | `[inferred]` from the silence against the `[generic]` survey band | What salary range is budgeted for this role? | unresolved |
| RR3 | Scope and reporting line stated | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The mandate is defined and has a named owner | `[grounded]` careers page | What would a successful first year look like? | noted |
| RR4 | Team size, data and tooling unstated | unknown | — | Neither source mentions them | A single analyst owning a product's pricing may have little support. This is not evidenced either way | `[inferred]` from silence | Who else works on pricing for this product, and what data and tooling are in place? | unresolved |

The standing check on whether the employer exists as described passed. The company's own careers page for this role is live and matches the JD on title, product and reporting line. It does not match on working pattern, which is RR1.

## Application plan

I have not applied any of this. Everything below is proposed, and nothing in the table or the notes beneath it is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern before anything else: answer Q1, and put RR1's question to the recruiter | R1, RR1 | `[grounded]` R1 and RR1 | pending your approval |
| E1 | `resume_edits_pending_approval`. Lead with these, each worded from your own sentences: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests with the underwriting team (state the year)"; "Present the quarterly pricing review to the head of underwriting"; "Senior analyst for the last 2 of 5 years in pricing analytics at a UK motor insurer". Do not add outcomes or metrics you haven't confirmed | R3, R4a, R5, R7, R2 | `[grounded]` your background | pending your approval |
| A2 | If G2 yields a true monitoring example, put it near the top. Her published talk is on monitoring rating models in small books | R4b, hiring manager row | `[inferred]` from the talk title | pending your approval |
| A3 | Pet-insurance framing, if asked: "I haven't worked on pet insurance. My GLM pricing work in motor carries over; pet-specific rating factors are what I would learn first." Say no more than that | R10 | `[inferred]` bridge, limit stated | pending your approval |
| A4 | People management, if asked: say plainly you haven't line-managed anyone. The JD does not list it | JD silence | `[grounded]` JD silence; your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and surfaced the working-pattern contradiction: R1, RR1, role reality |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote"; result "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. It moved the compensation calibration (RR2). Scope norms were not established |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor"; result "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. It moved role reality's hiring-manager row and A2 |

## Dossier and upgrade menu

I can save all of this as a `tuesday-dossier.md` you can carry forward, if you want it.

What more inputs would unlock:

- Your actual CV: R2 and the other prose-based rows get checked against a document.
- A sanitized model-documentation page or monitoring pack: R3, R4a and R4b rise toward `high`.
- A sanitized price-test readout: R5 rises toward `high`.
- A code sample: R6 rises toward `high`.
- A review deck or a product-facing recommendation: R7 and R8.
- The recruiter's answer on working pattern: R1 and RR1 close.
- The budgeted salary: RR2 closes and gets set against the survey band.
- A deeper research pass on Brindlemoor (funding, leadership changes, public staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

Q1 (G1, R1) — Where are you based, and would four days a week in the Leeds office work for you, or is remote a requirement?

Q2 (G2, R4b) — Have you personally tracked how your young-driver GLM performed after launch (for example actual-vs-expected checks, drift, or a re-fit that monitoring triggered)? What did you own, and what happened?

Q3 (pay, no row yet) — Do you have a pay floor for this move? If so, I'll add it as a gate row and check it against the survey band.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.