The pack is written. I'm running a quick check on its formatting, then I'll give you the summary.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-canned-0d4c6002/4c9404b3-21d0-4ab1-a236-42083b6bb791/scratchpad/ashgrove_credit_union_member_experience_lead_interview_pack.md`.

I built it as a three-round loop from your JD, the recruiter's email, the values text you pasted and your summary of the June strategy brief. It has 31 questions: 8 for the recruiter, 11 for the Head of Member Services and 12 for the panel. The panel round also has a values sheet, with a scaffold for each of the four values. No interviewer names exist yet, so there is no interviewer read.

- **Highest-ROI prep:** B5, the contact-centre objection. You told me you've never worked in a contact centre, and the JD says the role owns complaints "across branches and the contact centre". Expect that question in some form.
- **Second objection:** B6, presenting to senior leaders, since you've never presented above regional level.
- **Where your material is thin:** the pack only uses your own sentences. The "own the process end to end", "coach supervisors" and "regulated complaints" lines each rest on one sentence of yours, so those answers are written as slots. The pack also lists the stretched versions it won't coach, such as "owned the process", "coached supervisors" and "handled regulated complaints".
- **Research:** I ran no searches. Everything came from what you pasted.

Please check one date. Your note puts the rounds on 21 October and the values copy on 12 October, but my calendar reads 5 November. I built the pack for the rounds as you described them. If they moved or have already happened, tell me and I'll re-aim it.

Say the word and I'll play the Skeptic on B5. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste your CV, or just the lines about the complaints log and the spreadsheet? Several rows rest on one sentence each now, and anything fuller would firm them up.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop, three scheduled rounds on 21 October as the recruiter's email gives them. Interviewers beyond their roles are not yet assigned, so there is no interviewer read.

| Round | Who (per the recruiter's email) | Length | Shape |
|---|---|---|---|
| A | The recruiter | 30 minutes | Screen |
| B | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| C | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

The single most likely objection to you is the contact-centre gap (row F2). Its rehearsal is B5, the highest-ROI prep in this pack. The second is presenting to senior leaders (F8), rehearsed in B6.

## How to use this pack

- Personas describe how a question arrives. Types describe what is being scored.
- Type key: VAL is behavioural and values alignment. EXP is a work-experience deep-dive. JD is role and JD-driven. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Say only what you actually did, in your own words.
- Provenance labels: grounded means traceable to something you or Ashgrove supplied. Inferred means derived, with the derivation named. Generic means a pattern with no claim about you or Ashgrove.
- Answer slots are instructions for the interview, not questions for this chat. Each has two honest branches, and the second always allows that the thing never happened or was not yours.
- You supplied no figures, so none appear anywhere in this pack. If you have real ones, they would become defend-the-number questions.
- All answer wording in the banks is proposed language, pending your approval.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says a branch's log and teller training, not a process and not across sites, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what you owned likely. If any outcome on the log was yours to decide, say which and how you decided, in your own words; if the log was a record someone else acted on, or none of it was yours to decide, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses; it does not say what the spreadsheet counted. Answer slot: the JD's volumes and resolution-times wording makes a probe on what it counted likely. If it counted how many complaints came in or how long they took to close, say how each was counted; if it counted something else, or those were not tracked, say so plainly and describe what it did hold |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message, "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script, not supervisors, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether any of it was with people at supervisor level likely. If you have taught or guided a supervisor on escalations, say what and how it went; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent: it neither shows digital work nor says there was none. Answer slot: if you have worked with a digital or product team on anything members used without staff help, say what the work was and what part was yours; if you have not, say so plainly and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it in its own terms, six years in retail banking, the last three as a branch supervisor, and let the interviewer map it to customer operations. Add nothing to it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your sentence says formal complaints; it does not say whether outside rules governed them. Answer slot: the JD's regulated-complaints line makes a probe on this likely. If set rules or deadlines governed that log, say what they were and which part of following them was yours; if you are not sure any did, or none applied, say so plainly and stay with the branch's formal complaints log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated limit. Words: "I haven't presented to anyone above regional level." Then a plan, never a past. Your material does not show what, if anything, you presented at regional level or below. Answer slot: if you have presented to your regional manager or to anyone below that level, say what and how it went; if you have not, say so plainly |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Say it as written. Your sentence says spreadsheet, not Excel. Answer slot: if it was Excel, say so; if it was another tool, say which, and say plainly what you have used for reporting |

Coverage of the JD by question ID. The JD lists nine items once F1 and F2 are split.

| Requirement | Questions |
|---|---|
| F1 own the process end to end | A1, B2, B7, C5 |
| F2 across branches and the contact centre | A6, B5, C11 |
| F3 monthly reporting | B8, B9, C10 |
| F4 coach branch supervisors | B3, B4, C6, C8, C9 |
| F5 digital teams and self-service | A8, B10, B11, C7 |
| F6 4+ years in financial-services customer operations | A4 |
| F7 regulated complaints | A7 |
| F8 presenting to senior leaders | A6, B6 |
| F9 Excel reporting | A5, B8 |
| Headline figure on the CV | — none, and why: you supplied no quantified claim, so no defend-the-number question exists. B8 and B9 are the nearest rehearsal |

## Grounding brief

From the June 2026 strategy brief as you summarised it. I have not seen the brief itself, and it is about five months old by my calendar, so check for anything newer before treating it as current.

| Item as you gave it | What it means for you | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | Ties directly to the JD's self-service journeys line, so expect digital questions in every round. Complaints raised in digital channels become part of the role's scope to think about | [inferred] from the JD line and the brief item |
| "consolidate eight branches into five hubs over 2027" | Branch managers on the round C panel may be affected; whether their own branches are, the material does not say. Use it to ask, not to assume | [inferred] from the brief item |
| "launch a small-business lending product in Q1 2027" | A new product is a new source of member questions and possible complaints; a sensible thing to ask about, not a claim about Ashgrove's plans | [inferred] from the brief item |
| "the main competitive pressure is app-only banks" | Shapes why a member would stay and what self-service has to match; the CO questions use it | [inferred] from the brief item |

## Round A: Recruiter screen (30 minutes)

Persona weights, with the reasoning shown.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, light company questions | Top, 5 questions. Recruiter screens sit in a friendly register and the recruiter's email gives a 30-minute slot | Prepare a 90-second arc; treat casual questions as scored; never answer "I think you've covered everything" to the reverse slot |
| Skeptic | Quiet probing of the JD's gaps | Mid, 3 questions. The screen is where gaps get noticed first, and rows F2, F5 and F7 give plenty to probe | State the limit before they find it; bridge only from what you actually said |

Proposed answer wording in this bank: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each the quote's own: the six years in retail banking, the last three as a branch supervisor; the formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet. Tell them in your own words in about 90 seconds. Answer slot: why this move and why now is not in your material, so say the true reason in one sentence; if there is one reason you would rather not lead with, leave it out rather than inventing another | F1, F3 and F6 are the rows an opening arc has to carry; EXP because the recruiter is checking that the story matches the application |
| A2 | "Why this move, and why now?" | JD | [generic] | A motivation answer makes no claim about your past, so none is supplied. Answer slot: say the real reason in your own words, and keep it consistent with the answer you will give the Head of Member Services in round B, because the three rounds will compare notes. If the honest reason is partly practical, say so plainly rather than dressing it up | Recruiters check motivation consistency across a loop; JD because it tests the move into this specific role |
| A3 | "What do you know about Ashgrove and where it's heading?" | CO | [grounded] | Choose two items from the Grounding brief you can talk about without notes and say why each matters to complaints, as your own view, with the digital move first because the JD names it. Use the values by name only if you can attach a reason: for example Plain Words, because the role is about complaints. Do not recite the brief; the recruiter sent it to you, so reciting it scores as homework only | Strategy fluency is the cheapest way to separate yourself in a screen; CO because it tests homework depth |
| A4 | "The role asks for 4+ years in financial-services customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor. Stop there and let the recruiter map it. Do not restate the years as "customer operations" yourself | F6 is a knockout-style check that should take ten seconds; JD because it scores a stated requirement |
| A5 | "The role needs comfort with Excel reporting. Where does Excel come into your work?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was Excel, say so and describe what you built in your own words; if it was another tool, say which, and say plainly what you have used for reporting. Name no function or feature you did not use | F9 is a casual-register question on a JD plus-skill, asked as a rapport item and still scored; JD because it checks a stated requirement |
| A6 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the limit before they do, in first person: "I've never worked in a contact centre." If you add the second, it is also yours to say: "I haven't presented to anyone above regional level." Then one plan sentence in future tense for each, for example learning the contact-centre side before changing anything. A plan is not a past, so claim nothing you have done. Skip filler such as "I learn fast" | F2 and F8 are your two stated gaps; the Skeptic opens with this question, and B5 is the long version. JD because it scores honest self-assessment against the listed duties |
| A7 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the sentence as it stands: "I handled the branch's formal complaints log." Answer slot: if set rules or deadlines governed that log, say what they were and which part of following them was yours; if you are not sure any did, or none applied, say so plainly and stay with the log. Do not use "regulated" about your own work unless you can say what made it so | F7 is the row where your word and the JD's word differ; inferred because the bridge is the pack's derivation. JD because it scores a stated requirement |
| A8 | "The role works with digital teams on self-service journeys. What have you done in that space?" | JD | [grounded] | Your material is silent here, so the guidance is the slot. Answer slot: if you have worked with a digital or product team on anything members used without staff help, say what it was and what part was yours; if you have not, say so plainly, then say what you would ask a digital team first. The 40% digital target in the Grounding brief is a good thing to name in the plan half | F5 is the row with no evidence, and the strategy puts digital front and centre; JD because it scores a listed duty |

Reverse questions for round A.

| # | Question | Why it lands |
|---|---|---|
| RA1 | "How is the complaints process split between branches and the contact centre today, and who owns it end to end now?" | Shows you read the end-to-end line and want to understand the current owner |
| RA2 | "What would the Head of Member Services most want to see from this role in the first 90 days?" | Gets the manager's priority before round B and prepares you for it |
| RA3 | "Is the case in the panel round built on a real kind of escalation, and is there anything I should read beforehand?" | Cheap process question that signals preparation |
| RA4 | "Who receives the monthly complaints reporting today?" | Connects to the reporting duty and tells you who your audience would be |
| RA5 | "Where do you think a new lead would need the most support?" | Invites the recruiter to name how they see the gaps, which tells you what to emphasise in rounds B and C |

## Round B: Head of Member Services, your manager (45 minutes, mostly behavioural)

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | STAR-shaped scenarios | Top, 4 questions. The recruiter's email calls this round mostly behavioural | Use "we" for context and "I" for what you did; where no story comes to mind, say so plainly and give the nearest thing your material does carry |
| Skeptic | Probes the gaps from a manager's side | Mid, 3 questions. A future manager is derisking, and F1, F2 and F8 are the places to probe | Rehearse the contact-centre objection until it is boring |
| Data-Driven Prober | Goes line by line through the spreadsheet and the log | Low, 2 questions. The only quantifiable item you named is the spreadsheet | Know what you can and cannot say about how it was built |
| Case/Strategist | A live problem on the digital move | Low, 2 questions. The role works with digital teams and the strategy puts digital first | Clarify, structure, then answer; think aloud |

Proposed answer wording in this bank: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time that has a named stake, a moment where you said the uncomfortable thing, and a relationship that was intact at the end. Use "we" for context and "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not make up the ending | The role reports to senior leaders and your material does not show a leadership story, so this is the likely stretch in a behavioural round. VAL because it scores behaviour, not knowledge |
| B2 | "Tell me about a complaint that was hard to resolve." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one complaint, say what made it hard, what you did, and what happened to the member. If one comes to mind that you handled, tell it with the parts that were yours. If no such complaint comes to mind, say so plainly, then give the nearest thing your material does carry: "I handled the branch's formal complaints log." Add no detail the real case does not have | The role is about complaints and F1 is the only evidence you gave, so this is the obvious behavioural opener. VAL, with EXP flavour because it tests what you actually did |
| B3 | "Tell me about a time you got a colleague to change how they handled something." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold, because the JD's coaching line raises the theme: a named person or group, what they were doing, what you changed, what was different afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you trained new tellers on the escalation script. Do not describe training as coaching of supervisors | F4 is the nearest evidence for the coaching duty and sits at teller level; VAL because it scores behaviour that the JD requires |
| B4 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4, with the beats the sentence states: new tellers, the escalation script, you training them. Tell it in your own words. Answer slot: the JD's coaching line makes a probe on how you taught it likely. If you chose the format, the order or how you checked tellers had it right, say what you did; if there was a set method, or none of that was yours, say so plainly and describe the training you gave. Say nothing about who wrote the script | F4 is where the coaching duty meets your evidence, and this is the likely walk-through; EXP because it tests what was actually yours |
| B5 | "You've never worked in a contact centre, and this role owns the complaints process across the contact centre. How would you own that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack, and the hold is only what the quotes carry. Open with the limit: "I've never worked in a contact centre." Then what your material does carry, at its own scope: "I handled the branch's formal complaints log." Then a plan in future tense, for example learning how the contact centre handles complaints before changing anything. Follow-up one: "What's different about a contact-centre complaint?" Answer slot: say what you genuinely know, in your own words; if you do not know yet, say so plainly and say who you would ask. Follow-up two: "Will the team accept a lead who hasn't done their job?" Hold: do not claim equivalence; concede specifically that you would be learning their side. Follow-up three: "How long until you're credible?" Give only a timeframe you would stand behind. Practise until it is boring | F2 is the stated gap against a JD line that names the contact centre, and the manager owns the outcome of the hire, so this question will be asked in some form. JD because it scores a listed duty; Skeptic because it probes a gap |
| B6 | "This role presents to senior leaders. You haven't presented above regional level. Why should we back you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Words: "I haven't presented to anyone above regional level." Answer slot: if you have presented to your regional manager or to anyone below that level, say what and how it went; if you have not, say so plainly. Then a future-tense plan, for example agreeing the first presentation's audience with the Head of Member Services. Hold the limit; do not argue that regional is close enough | F8 is the second-most predictable objection; JD because it scores a stated requirement |
| B7 | "What part of a complaints process have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold is the quote: "I handled the branch's formal complaints log." Answer slot: if any outcome on the log was yours to decide, say which and how you decided, in your own words; if the log was a record someone else acted on, or none of it was yours to decide, say so plainly and describe how you handled it. Hold through two follow-ups by returning to the log; never add to it | F1 is the row where the JD's end-to-end line presses hardest; JD because it scores the stated duty |
| B8 | "Walk me through what was on that monthly spreadsheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 with the quote's own beats: you built it, it was monthly, it was about complaints, and your regional manager used it. Answer slot: if it counted how many complaints came in or how long they took to close, say how each was counted and which count you would trust least; if it counted something else, or those were not tracked, say so plainly and describe what it did hold. If you do not know how a number was counted, say that | F3 and F9 are your only reporting evidence; there is no headline figure, so this is the nearest defend-the-number rehearsal. EXP because the Prober reads for assumptions |
| B9 | "How much of that spreadsheet was actually your work?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else shaped it, or you started from something that already existed, say who and what; if it was all yours, say so plainly. Hold through two follow-ups by returning to what you built; concede precisely what was not yours | F3 uses the word "built", which is a magnet for attribution probes; EXP, Pressure delivery |
| B10 | "The strategy says 40% of member service moves to digital by 2028. What do you want to know before deciding how complaints should work in digital channels?" | CASE | [grounded] | Clarify first, aloud: which channels, which complaints, what members use today, what must stay with a person. Then objective, segments, approach, metrics, risks. Challenge one premise respectfully, for example which kinds of complaint should not be self-service. No claim about your past is needed | F5 and the brief's first item; CASE because it asks about no past and scores structure |
| B11 | "App-only banks are the main competitive pressure. What would make a member stay with Ashgrove, and what does that mean for how we treat complaints?" | CO | [grounded] | Structure it: what an app-only bank is good at, what Ashgrove's published values claim to offer, where a complaint is the moment of truth. Use one value by name: for example Own the Fix, "whoever finds the problem keeps hold of it until it is solved". Give a view and say it is a view | F5 and the brief's competitive line; CO because it tests whether you can think at the company's altitude |

Reverse questions for round B.

| # | Question | Why it lands |
|---|---|---|
| RB1 | "Where does the complaints process break down today: in the branch, in the contact centre, or in the handoff?" | Echoes Own the Fix and tells you what you would be inheriting |
| RB2 | "How will the move to digital change which complaints reach a person?" | Ties your role to the strategy's biggest target |
| RB3 | "What does good look like at three months and at twelve?" | A manager hears a candidate who wants a clear bar |
| RB4 | "Who could help me learn the contact-centre side in the first month?" | Turns the gap into a plan and invites the manager's support |
| RB5 | "How will the move from eight branches to five hubs change who I'd be coaching?" | Shows you read the strategy and thought about the coaching duty |

## Round C: Panel of two branch managers (60 minutes, with a 20-minute case; scored against the four values)

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | One scenario per published value, scored | Top, 4 questions. The recruiter's email says the panel scores against the four values | Map a story to each value, or say plainly where none comes to mind |
| Case/Strategist | The 20-minute complaint-escalation case | Mid, 3 questions. A third of the round is the case | Ask before you structure; say the framework aloud |
| Peer Evaluator | Branch managers whose supervisors you would coach | Mid, 3 questions. Panel members are the people your coaching affects | Reciprocity: what you bring their branches, not only what you need |
| Pressure | A devil's-advocate challenge | Low, 2 questions. Possible from a two-person panel but not signalled | Pause, restate, hold through two follow-ups |

Proposed answer wording in this bank: pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Values scaffold for Members First, Always: a named decision, what pulled the other way, what you chose and why, how it ended. Use "I" for your decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you handled the branch's formal complaints log. Do not turn the log into a story it does not tell | The panel scores each value, and the question is the value's own wording; VAL because it tests behaviour against a published value |
| C2 | "Tell me about a time you made something complicated plain for a member or a colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Values scaffold for Plain Words: the complicated thing, who needed it, what you changed so they did not need it twice, how you knew. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you trained new tellers on the escalation script. Say nothing about how clearly you explained it unless you can give the evidence | Plain Words is the value most visible in a complaints role; VAL |
| C3 | "Tell me about a time you thought about your branch as part of its town and not just its numbers." | VAL | [generic] | Values scaffold for Neighbours, Not Numbers: a named situation, what the numbers said, what the town needed, what you did. If no such time comes to mind, say so plainly, then say how you would weigh the two when a branch consolidates. Give no local detail you cannot name | The panel are branch managers, and this value speaks to their daily trade-off; VAL |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Values scaffold for Own the Fix: the problem you found, who else could have dropped it, what kept it with you, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you handled the branch's formal complaints log. Do not describe a log as ownership of a fix | The JD's end-to-end line is Own the Fix by another name; VAL, with EXP flavour |
| C5 | "A member's complaint has been passed between a branch and the contact centre three times, and they've now written in angry. Walk us through what you do." | CASE | [generic] | Say your framework aloud, then ask: what the member wants, what has been promised, how long it has run, which rules apply here, who holds it now. Then act: one owner, a call to the member, plain words (Plain Words), then why it bounced and what you would measure. Do not claim you have faced this | F1 and F2 meet here, in the case the recruiter described; CASE because it tests structure on a live problem |
| C6 | "A branch supervisor escalates a complaint you think should have been settled at the counter. How do you handle that conversation?" | CASE | [generic] | Ask before you tell: what they tried, what stopped them. Then agree what good looks like next time, and what you would change in your own guidance if it was unclear. No claim about your past is needed | F4: the coaching duty as a live moment; CASE because it asks about no past |
| C7 | "Eight branches become five hubs over 2027. What happens to complaints in that transition, and what would you watch?" | CASE | [grounded] | Clarify: which branches, when, what members are told. Then segments (members of closing branches, others), the risk (a town that feels left behind: Neighbours, Not Numbers), and what you would watch (volumes and resolution times by branch). Offer a view and say what would change it. Do not claim to know Ashgrove's plan | F5 and the strategy brief; CASE with CO flavour |
| C8 | "You'd coach our supervisors on escalations. Where's the seam between your role and ours, and what happens when we disagree?" | JD | [grounded] | Propose principles and not a map of a seam you cannot see: the branch holds the member day to day, the role sets the standard and supports, and decision rights on escalations are agreed in advance. Then say it is theirs to describe and ask how they would draw it. No claim about your past is needed | F4 is the duty; Peer Evaluator because these are the people on the other side of the seam. JD because it scores a listed duty |
| C9 | "You were a branch supervisor yourself. What would you have wanted from a complaints lead?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Start with the quote: "the last 3 as a branch supervisor." Answer slot: say in your own words what would actually have helped you; if nothing comes to mind, say so plainly and ask them what their supervisors would say. Do not describe a particular incident unless it happened | F4 and F6; a reciprocity-style question that uses your actual vantage point. JD because it scores the coaching duty |
| C10 | "A branch fixes a recurring problem, and your monthly report goes to senior leaders. Whose name is on it?" | JD | [generic] | Credit goes to the branch by name. Say how: the report names the team, and you tell them before it goes up. Honest about what you would not know yet: how Ashgrove currently credits. No claim about your past is needed | F3, as a credit and collaboration probe; JD because it concerns the monthly reporting duty |
| C11 | "Sixty seconds: why you, rather than someone who has worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the quotes carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede specifically: "I've never worked in a contact centre." Hold through two follow-ups by returning to the same sentence; do not claim you are better, only what you bring. Pause before you answer | F2 as a pressure test; Pressure because it is time-boxed, JD because it scores the listed duty |
| C12 | "What's one thing in our strategy you'd push back on?" | CO | [grounded] | Choose one item you can reason about, say what it is meant to achieve, and challenge one assumption respectfully, for example the pace of the digital move. Offer what you would want to know before pushing harder. Do not present a criticism as a fact about Ashgrove | Pressure from a devil's-advocate angle; CO because it tests judgement at the company's altitude |

### Values cheat sheet (round C)

Value names are Ashgrove's, as you copied them on 12 October 2026. Working meanings are paraphrases. No fit-snapshot row carries a story for any value, so each row is a selection scaffold.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's position | Scaffold in C1. The nearest your material carries is F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." If no real decision comes to mind, say so plainly |
| Plain Words | The burden of clarity is the organisation's, not the member's | Scaffold in C2. The nearest your material carries is F4, "trained new tellers on our escalation script." If no real example comes to mind, say so plainly |
| Neighbours, Not Numbers | A branch counts beyond its figures | Scaffold in C3. No row speaks to this value. If no real example comes to mind, say how you would weigh it |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | Scaffold in C4. The nearest your material carries is F1. If no real example comes to mind, say so plainly |

Reverse questions for round C.

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What do your supervisors find hardest about escalations today?" | Asks the people who live it, which Plain Words and Members First both reward |
| RC2 | "What would you want from this role that you don't get now?" | Reciprocity: tells them you are thinking about their load |
| RC3 | "Where branches consolidate, how should complaints from that town be handled?" | Conditional on the hubs plan and points at Neighbours, Not Numbers |
| RC4 | "How do you decide today whether a complaint is settled at the counter or escalated?" | Shows you want the real practice before proposing change |
| RC5 | "What would a good first month look like from where you sit?" | The reciprocity question from the persona guidance, and a clean way to end |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says a branch's log, not a process. B7's slot stays inside the log |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." The material says tellers, not supervisors. B4's slot stays with the tellers |
| Wrote or designed the escalation script | Inflated form of F4 | The sentence says "our escalation script" and that you trained tellers on it; nothing about writing it. B4's slot stays on the training |
| Has worked in a contact centre | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot; B6 asks only about regional level or below |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The material says formal, not regulated. A7's slot asks only what governed the log |
| Designed or ran the organisation's complaints reporting | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." B8's slot asks only what the spreadsheet held |

## Sources

Provided documents: the job description you pasted; the values text you copied from ashgrovecu.org/about/values on 12 October 2026 (not re-fetched); the recruiter's email; your summary of the June 2026 strategy brief (the brief itself not seen); your background paragraph. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet: the values text you pasted already supplies all four values by name |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email establishes the loop, with who runs each session and what it holds |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: your summary of the June brief supplies current priorities and recent moves |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names were given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the lines about the complaints log and the spreadsheet → rows F1, F3, F4, F6, F7 and F9, which each rest on one sentence now, can move up a confidence band, and any figures become defend-the-number questions
- Your answers to the answer slots (A7, B4, B7, B8, B9 above all) → each enters the fit snapshot as quoted evidence and the rows that draw on it regenerate
- A real story for any of the four values → the values cheat sheet moves from scaffolds to mapped stories, and C1 to C4 become story-mapped
- The interviewers' names → a reading of their public footprint, persona weights tuned to each, and a reverse question tied to their own career path
- The full strategy brief → the grounding brief and the CO and CASE questions rest on its own words, not a summary
- Which rules govern complaints at Ashgrove (the recruiter can usually answer in one email) → F7 and A7 can be grounded
- What the round C case is built on (one email to the recruiter) → C5 and C6 can be aimed more tightly
- Time available before each round → a prioritised prep schedule
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes: recent organisational context and, once names exist, interviewers' public talks and writing
- A tuesday-dossier.md from a prior underwriting pass → verified evidence and prohibited claims arrive pre-checked, and the highest-ROI objection comes from the underwriter and is not inferred here
