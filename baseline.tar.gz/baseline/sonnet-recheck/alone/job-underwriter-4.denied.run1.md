I'll read the reference files the skill requires before building the assessment.
**Yes, apply, with conditions. Status: `conditional_go`.** Your motor-pricing work covers the must-haves (R2, R3, R4, R5, R6, R7a, R8) directly. The open items are the unverified employer, the pet-insurance domain, and whether you're UK-based.

You haven't managed anyone, and the JD doesn't ask for it (see "Line management" in Role reality).

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7a, R8
- `important`: unclear: R7b (recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product domain)

R10 is the real gap, and it's a bridge with a stated limit. R7b is a discovery gap, not a negative.

**Opportunity ledger.** The duties are concrete and a named hiring manager is given (RR4). The employer is unverified (RR1), and the salary (RR2) and the scope of "own" (RR3) are not stated.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you're UK-based and can work from there (R1); (2) Brindlemoor verifies as a live employer with this role on its own site (RR1); (3) the pet bridge is framed as adjacent, never as pet-pricing experience (R10); (4) the salary clears your floor, which you haven't given me (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling pet insurance | `[grounded]` JD header as pasted; not independently verified (RR1) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as given by you; no footprint researched |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Seniority read | "Senior" title with a 4+ year floor; your 5 years, the last 2 as senior analyst, sits inside that | `[inferred]` from the JD's floor against your stated years |
| Line management | The JD lists no people-management requirement. It says "own", but states no reports or team | `[grounded]` JD silence; whether the role has reports is an unknown (RR3) |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Compensation | Not stated. No market band is given here because no role-family sweep ran | `[grounded]` JD silence; band not calibrated (see Evidence status) |
| Unknowns | Employer verification, salary, team size and reporting line, how success is measured, whether product work means a named product team | — |
| Contradictions | None within the JD as pasted | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You haven't said where you're based or your right to work. A UK motor insurer employer points to the UK but doesn't establish it, so I carry it as unconfirmed | `[grounded]` JD term; your location not stated; `[inferred]` UK from your employer | Confirm in G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. It's your own account with no document inspected. A years requirement is graded on fit, not treated as a gate | `[grounded]` your intake text | none; dated CV roles would raise it to high |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", confirmed in your words, no artifact seen | `[grounded]` your intake text | A sanitized query or notebook would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Limit: one book, motor | `[grounded]` your intake text | A sanitized model-documentation extract would raise it to high |
| R5 | Build and monitor rating models | must_have | direct | medium | discovery | Building and maintaining are stated. What you monitored, how often, and what you did when it drifted are not, so monitoring is carried at the lower reading | `[grounded]` your intake text; monitoring detail absent | G4 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. Which parts (design, sizing, read-out) were yours isn't stated, so I don't claim design alone | `[grounded]` your intake text | G4 |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | You worked the tests with underwriting and present the quarterly pricing review to the head of underwriting | `[grounded]` your intake text | none |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product team. Motor pricing reviews may involve one, so there's a thread to pull but no confirmed claim | `[grounded]` silence in your intake text | G3 |
| R8 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "or", so actuarial audiences aren't needed | `[grounded]` your intake text and JD wording | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your intake text | none |
| R10 | Pet-insurance product domain (implied by "our pet-insurance product") | preferred | adjacent | medium | transferability | You've said you haven't worked on pet. The carry-over is insurance rating mechanics, GLM and test discipline. Limit: pet rating usually turns on different risk factors from young-driver motor, which you haven't exercised | `[inferred]` requirement from the JD's product description; `[grounded]` your statement; `[generic]` that pet and motor rating differ in factors | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK base and right to work (R1, hard_gate) | hard_gate | Nothing states where you live or work from | It's the one term that can sink an application regardless of fit | n/a: this is a yes/no term | None needed | `[grounded]` silence in your intake |
| G2 | Pet-insurance domain (R10, preferred) | transferability | Motor GLM and tests carry over mechanically; pet-specific rating factors are untouched | It's the objection most likely to be raised, though the JD says only that insurance experience is "a plus" | Any rating factor you modelled that behaves like age, breed or a claims-inflation trend; any renewal or retention pricing work; anything on health or vet-style cost trends | Not needed; framing, not an artifact, narrows this one | `[grounded]` your statement; `[inferred]` that it's the likeliest objection from the JD's product focus |
| G3 | Recommendations to product (R7b, important) | discovery | No product-side contact in the background given | It's the only named audience in the JD you haven't evidenced | Presenting test results to a product or proposition team; a rate change that needed product sign-off; a pricing paper that went beyond underwriting | A pricing review deck extract, with figures sanitized | `[grounded]` silence in your intake |
| G4 | Monitoring and test design ownership (R5, R6; must_have) | discovery | Build, maintain and "ran" are stated; monitoring routines and design-versus-execution are not | These are the two duties in the JD that go beyond "built a model" | Model drift or actual-vs-expected tracking you set up; test sizing or hypothesis work; deciding when to stop or roll out a test | A monitoring dashboard screenshot, a test design note, a read-out summary, all sanitized | `[grounded]` intake text names the activities but not the detail |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be new or small with little public footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Nothing here shows which. I couldn't check, so this is an absence of confirmation, not a finding | `[generic]` pattern for companies of this size, not a claim about this one | Is this role live on your own careers site, and who is in the interview loop? | unresolved |
| RR2 | Salary not stated | unknown | — | (JD lists no pay) | The figure may sit anywhere relative to a senior pricing role, or the company may simply not publish it. No band is available to compare against | `[inferred]` from the JD's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | "Own" with no stated team, reporting line or success measure | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole pricing analyst on the product, or part of a team, and the JD doesn't say which | `[inferred]` from the JD's scope wording against its silence on team and metrics | Who else is on the pricing team, who does this role report to, and what would success look like in year one? | unresolved |
| RR4 | Duties specific and manager named | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The mandate is concrete and maps onto a recognizable pricing workflow, with a Director-level hiring manager named | `[grounded]` JD | What is the first pricing question you'd want this role to answer? | noted |

## Application plan

Everything below is proposed, not final. Nothing is finalized until you approve it, and your approval covers both the table and the wording in the rows.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Edit the CV summary, `resume_edits_pending_approval`. Proposed: "Pricing analyst with five years at a UK motor insurer, the last two as senior analyst. Built and maintained the GLM rating model for the young-driver book. Ran 14 price tests in a year with the underwriting team. Present the quarterly pricing review to the head of underwriting." Every clause traces to your intake sentences: the five years and senior-analyst period, the GLM build and maintenance, the 14 tests "with the underwriting team", and the quarterly review. Hold back "designed" and "monitored" until G4 answers. | see R2, R4, R6, R7a, R8 | `[grounded]` your intake text | pending your approval |
| P1 | Positioning: order your CV and cover note the way the JD lists the duties (rating models, price tests, recommendations to underwriting). Describe pet as the new domain, with your GLM and test work as the transferable part. Don't present motor experience as pet-pricing experience | see R10 | `[grounded]` JD order; `[grounded]` your statement | pending your approval |
| A1 | Confirm your UK base, then verify the posting on Brindlemoor's own careers site before spending effort on a tailored application | see R1, RR1 | `[grounded]` R1, RR1 | pending your approval |
| Q1 | Put the register's verification questions (RR1 to RR4) to the interviewer verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Optional: a one-page sanitized extract of the GLM documentation or a test read-out, to move R4 or R6 toward `high` | see R4, R6 | `[grounded]` R4, R6 rows | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused. It would have established the employer, the live posting and any contradictions (RR1, Role reality) |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; the call was refused. It would have given a market calibration line and a salary band against RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have informed the scope read and what P1 leads with |

I haven't researched Brindlemoor. Everything about the company comes from your paste.

I'll offer the full dossier file (`tuesday-dossier.md`) whenever you want it, with no pressure.

## Upgrade menu

- Permission for web search, or a link to Brindlemoor's careers page: targets 1 to 3 run, which could close RR1 and give a salary band for RR2.
- A deeper research pass on Brindlemoor (funding and leadership changes, public reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.
- Your salary floor and any other non-negotiables: the hard-gate checks stop being "unknown".
- A sanitized model-documentation extract or a test read-out: R4 and R6 move toward `high`.
- Your CV with dates: R2 and R9 firm up.

## Questions

G1 — Are you based in the UK and able to work there without sponsorship? Do you also have a salary floor or other non-negotiables I should check this role against?
G3 — Have you ever taken pricing results to a product, proposition or commercial team rather than underwriting? What did you present and what was decided?
G4 — For the young-driver GLM and the 14 price tests, which parts were personally yours (monitoring, test design, sizing, read-out), and which were the team's or underwriting's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.