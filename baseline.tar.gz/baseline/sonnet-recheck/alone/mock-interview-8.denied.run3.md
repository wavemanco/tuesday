Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-denied-5e4b9839/ba020a70-e1b6-465a-8285-b2aabdd3cbf3/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop from the recruiter's email, with about 30 questions across the rounds. The interviewers have no names yet, so the persona weights come from their roles. I ran no web searches. The JD, values, strategy summary and process email you pasted covered everything the research would have fed.

I used your dates (today the 12th, interviews on the 21st) to size the prep schedule to nine days. My own clock reads 5 November, so if 21 October has already passed, tell me what happened and I'll rework the pack.

The highest-ROI prep is question 2B1, the contact-centre answer. You said you've never worked in one, and the Head of Member Services would own the cost of that gap. The pack has you name the limit first, hold only what your own sentences say, and state a learning plan as a plan. It then walks you through three follow-ups. The second weak spot is presenting above regional level (1B2 and 2B3), also from your own words.

Three things in the pack mean you need to supply the material:
- **Values stories:** only Own the Fix matches something you wrote. For the other three values I gave selection criteria, so you'll need real instances.
- **The spreadsheet and complaints log:** several answer slots ask what the spreadsheet counted, which tool it was in, and what rules applied to the formal complaints log. Those are yours to fill.
- **Your reason for moving:** the pack has none for you, so you'll need to write it.

Say the word and I'll play the Head of Member Services on 2B1, with live follow-ups. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Mode:** Loop, three rounds on 21 October (per the recruiter's email)
**Interviewers:** roles only so far — the recruiter (30 min); the Head of Member Services, who would be your manager (45 min, mostly behavioural); a panel of two branch managers (60 min, including a 20-minute complaint-escalation case, and also the values round). Names are not assigned yet.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.
- Types: VAL (behaviour against Ashgrove's published values), EXP (your experience survives scrutiny), JD (a requirement in the job description), CO (company and strategy knowledge), CASE (a live problem).
- Labels: `[grounded]` traces to something you or Ashgrove supplied, `[inferred]` is this pack's derivation, `[generic]` is a pattern with no claim about Ashgrove or you.
- An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch: say what you did, or say plainly it was not yours or did not exist. Both are good answers.
- Question IDs read round, persona letter, number: 2B1 is round 2, Skeptic, first question. Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Data-Driven Prober, G Peer Evaluator, H Pressure.

## Prep triage

Sized to the nine days between 12 and 21 October in your note. The order is by what changes the outcome most.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the contact-centre answer aloud until it is boring, including all three follow-up levels. This is the highest-ROI prep in the pack | 2B1, then 1B1 and 3H1 |
| 2 | Say your one-sentence acknowledgment about presenting, and outline a first senior update | 1B2, 2B3 |
| 3 | Find a real instance for each value and each behavioural prompt, using the selection criteria; write the stake and your own step for each | 3C1 to 3C4, 2C1 to 2C3 |
| 4 | Practise the case three times, timed to 20 minutes, thinking aloud | 3D1 |
| 5 | Settle your answers on the spreadsheet and the log: what each counted or covered, and what you do not know | 2E1, 2E2, 1A4 |
| 6 | Fix your 90-second arc and your reason for Ashgrove | 1A1, 1A2 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and the script you trained new tellers on, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end to end line makes a probe on how far your handling reached likely. If any step beyond the log was yours, say which and how, in your own words; if the log was where your part ended, or there was no step beyond it, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD (the contact-centre half of the same line as F1) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past, with your first step in your own words. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says the spreadsheet is monthly, that you built it, and that your regional manager uses it; it does not say what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD makes a probe on what the spreadsheet counted and how a figure was produced likely. Say what it counted, in your own words; if you do not know how some figure was produced, or part of it was not yours, say so plainly and stay with the spreadsheet |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and the escalation script. Words: "I trained new tellers on our escalation script." Answer slot: the JD's audience sits beyond new tellers, so expect a probe on who else you have coached. If anyone, say who and what you did, in your own words; if no one, or nothing beyond that script, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a named piece of work with a digital or product team, your part in it, and what changed for members. Answer slot: the JD names digital teams, so expect a probe. If any of your work touched a digital channel, say what and which part was yours, in your own words; if none did, say so plainly and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence reaches the length in other terms than the JD's. Keep your sentence's terms and let the interviewer map them: six years in retail banking, the last three as a branch supervisor. Nothing is added, and the JD's phrase is not borrowed for your history |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your material says a formal log and nothing about what rules governed it, so this is a discovery lead and not a claim. Answer slot: the JD asks for experience here, so expect a probe on what formal meant in practice. If you know what rules or timescales applied to the log, say what they were and what your part was in following them, in your own words; if you do not know, or none applied, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then a plan for a first senior audience, said as a plan and never as a past. Nothing added to soften it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The JD names a tool and your sentence names a spreadsheet; the pack does not assume they are the same. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on which tool it was in and what you built into it. Say which tool and what it did, in your own words; if what you built was simpler than the probe assumes, or part of it was not yours, say so plainly and stay with what you built |

## Grounding brief

Source: the strategy lines you sent from Ashgrove's June 2026 brief. The pack has your four-line summary, not the brief's text, so use the brief's own wording once you have read it. The brief is equally available to every prepared candidate: bring one item to show you have read it, then your own view of what it means for complaints.

| Item | In your words | Use in the interview | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" — your message | Ask whether complaints count toward the 40% before building a case on it; ties to the JD's digital-teams line (2D1, 2D2) | [grounded] |
| Hubs | "consolidate eight branches into five hubs over 2027" — your message | Use the brief's word, consolidate. The branch-manager panel is closest to this; do not guess which branches or what happens to staff (3D2) | [grounded] |
| Lending | "launch a small-business lending product in Q1 2027" — your message | Treat as a new kind of member who may need a complaints route; ask, do not assert (3D3) | [grounded] |
| Competition | "the main competitive pressure is app-only banks" — your message | Frame digital self-service around what members already expect; assert nothing about any competitor's practice (3D3, 2D1) | [grounded] |

## Round 1 — Recruiter, 30 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (A) | Friendly walk-through of your career, what you know about Ashgrove, what you do now | high — the relationship prior for a recruiter screen is Conversational plus a light Skeptic, and the email gives this round 30 minutes with the recruiter | A 90-second arc; treat casual questions as scored |
| Skeptic (B), light | Knockout checks on the two gaps you have named: contact centre and presenting upward | medium — a screen checks knockouts in a friendly register, and both gaps are JD lines | Plain acknowledgment, then the ground you have, then a plan |
| Values/Behavioral (C), light | A casual "which value stood out" | low — the email says the panel is the values round, so a formal values score here is unlikely; a casual one is still possible | One honest value, said in its own words |

### Bank A — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "So — walk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats the quotes state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log you handled and the escalation script you trained new tellers on; the monthly complaints spreadsheet you built that your regional manager uses. Fourth beat is yours: why this role, in your own words. The pack holds no reason for you, so write it from what drew you. Add no team sizes or results you did not give | The opener to almost every screen. F6, F1 and F3 are the rows the arc carries, and the reason for moving is the one beat the pack cannot supply |
| 1A2 | "What do you know about Ashgrove, and what drew you to us?" | CO | [grounded] | Bring one strategy item in plain words, for example the move of 40% of member service to digital channels by 2028 or the consolidation of eight branches into five hubs over 2027, then say in your own words why it matters for a complaints role. Use member-owned, the JD's word. What drew you is yours to give. Do not recite all four strategy points | Recruiters check homework and motivation in a friendly register. The brief is equally available to rival candidates, so one item plus your own link is the differentiator. CO because it scores company knowledge |
| 1A3 | "Looking at the role, which parts are closest to what you do now?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the two parts your quotes carry, each at its own scope: the log you handled and the script you trained new tellers on, and the monthly spreadsheet you built. Then name the parts you have not done, plainly: contact centre and presenting above regional level. Answer slot for the digital-teams line: if any of your work touched a digital channel, say what and which part was yours; if none did, say so plainly | A recruiter screens against the JD list. Naming the gaps yourself, once, keeps them from becoming the thing they find. F1, F3, F2, F8 and F5 are the rows in play |
| 1A4 | "Tell me about the complaints work you do day to day in the branch." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the sentence: the log you handled and the script you trained new tellers on, in your own words. Answer slot: expect a probe on what formal meant in practice and where your part in a complaint ended. If you know what rules or timescales applied to the log, say what they were and your part; if you do not know, or none applied, or your part ended at the log, say so plainly and describe what you did with it | F1 and F7 are the rows most likely to be tested early. EXP because it tests what was actually yours |

### Bank B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1B1 | "The role covers the contact centre as well, and you've been in branches. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Acknowledge first, plainly: "I haven't worked in a contact centre." Then the ground the quote carries, at its own scope: the branch's formal complaints log and the escalation script you trained new tellers on. Then a plan stated as a plan: what you would want to learn first, in your own words. Keep it to 30 seconds; the full version is 2B1 | A shorter run of the loop's highest-ROI objection (F2), because a screen is where knockouts are checked |
| 1B2 | "You'd be presenting to senior leaders. How have you found presenting upward so far?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Acknowledge, and stop there: "I haven't presented to anyone above regional level." Then a plan stated as a plan: how you would prepare for a first senior audience, in your own words. Answer slot: if you have presented to your regional manager, say what and how it went; if you have not, say so plainly | F8 is a gap you have stated, so the honest short answer is the strong one. JD because it scores the stated requirement |
| 1B3 | "We're asking for four years or more in customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in your sentence's terms: six years in retail banking, the last three as a branch supervisor. Do not restate it in the JD's phrase; let them map it. Answer slot: expect a probe on which of those years included complaints work. If you can say, say it in your own words; if the complaints work covered only part of those years, or you are not sure, say so plainly and stay with the years and the setting | F6, the length requirement, is likely screened literally. Keeping your own terms avoids a claim you cannot defend |

### Bank C — Values/Behavioral (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1C1 | "Which of our values stood out to you, and why?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pick the one your honest story supports and say it in its own words: Members First, Always; Plain Words; Neighbours, Not Numbers; or Own the Fix. If you pick Own the Fix, the ground your material carries is the log you handled. Answer slot: any story of staying with a complaint until it was solved is yours to tell, with your part in it; if none comes to mind, say so plainly and choose the value you can speak to honestly. Do not pick all four | The panel scores values formally, so a casual preview here is free rehearsal. VAL because it tests the published values by name; F1 is the only row that carries a story |
| 1C2 | "Why a member-owned credit union?" | VAL | [grounded] | Say your reason in your own words. The pack has none to offer, and your material does not show credit-union experience, so do not claim any. Tie it, if true for you, to one value by name rather than to a general wish to help | Member-owned is in the JD's first line, so the reason behind it is a natural early probe. VAL because the honest answer is a values answer |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How does the panel score against the four values — a question per value, or a conversation scored afterwards?" | Shows you know that round is scored on values and lets you prepare to the format |
| R1.2 | "Is the 20-minute escalation case a scenario I can read beforehand, or does it start cold?" | Practical and specific; the answer changes how you rehearse 3D1 |
| R1.3 | "Do you know yet who will be on the panel, and from which branches?" | Interviewers are unassigned; a name or branch unlocks a tailored read and reverse question |
| R1.4 | "What is the Head of Member Services most focused on for this role in the first six months?" | Recruiters often hear this from the hiring manager; it points round 2 at the real priority |

## Round 2 — Head of Member Services (your future manager), 45 minutes

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (C) | Real-instance prompts about escalations, communication, pushing back, coaching | high — the email calls the round mostly behavioural | Selection criteria per prompt; I for contribution, we for context |
| Skeptic (B) | Probing the contact-centre gap, the jump from one branch to the whole process, and presenting upward | high — the hiring-manager prior is Case plus Skeptic, and this person would own the consequences of the gaps | Rehearse 2B1 until it is boring: name the limit, hold the quoted ground, state the plan as a plan |
| Case/Strategist (D) | A question on the digital shift and on working with the digital team | medium — the hiring-manager prior includes live problems, tempered by the email saying mostly behavioural | Clarify, objective, segmentation, approach, measures, risks; challenge one premise respectfully |
| Data-Driven Prober (E) | Walk-through of the spreadsheet and of what formal meant | low — the interviewer is a manager reading a short background, not a peer evaluating analysis | Know what each thing counted or covered, and say plainly what you do not know |

### Bank C — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2C1 | "Tell me about a time you escalated a complaint. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. The log you handled and the script you trained new tellers on are your setting. Pick one escalation from your own work with a named stake for the member, your own step, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log you handled or the script you trained tellers on, or how you would handle one | Escalation is a JD theme and the Own the Fix value in action. VAL because it scores the behaviour; F1 carries the setting only |
| 2C2 | "Tell me about a time a member left unhappy with how you handled their complaint." | VAL | [grounded] | Selection scaffold. Pick a real case where the outcome was not what the member wanted, with what you did, what landed and what you would do differently. A hard truth that landed beats a tidy ending. If no such time comes to mind, say so plainly, then give the nearest thing from your own work or how you would handle one | Complaints are the whole job, and this tests candour and the Members First value. VAL; no quoted sentence carries a story here, so it is a scaffold |
| 2C3 | "Tell me about a time you told a senior person something they did not want to hear." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The monthly reporting duty sends uncomfortable figures upward, so a manager checks for spine. VAL; a persona stem, not a claim about Ashgrove |
| 2C4 | "Tell me about a time you coached someone through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the sentence: new tellers and the escalation script, in your own words. The pack observes that your material says tellers, not supervisors. Answer slot: expect a probe on who else you have coached and whether any of it was alongside a live case. If so, say who and what you did; if not, say so plainly and stay with the tellers and the script | The JD's coaching line is the F4 row. JD because it scores that requirement |

### Bank B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2B1 | "You haven't worked in a contact centre, and you'd own the process there too. How would you earn that team's trust?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI prep in the pack.** Four moves. (1) Name the limit before they press: "I haven't worked in a contact centre." (2) Hold only what the quotes carry: the branch's formal complaints log you handled and the escalation script you trained new tellers on. (3) State the plan as a plan, in your own words: what you would want to learn first and from whom, and that you would ask before you tell. (4) Follow-ups. Level 1, "They know the phones better than you; what do you add?": return to the log and the script, and add nothing about contact-centre work. Level 2, "What if the contact-centre lead says the branches are the problem?": hold that you would want to see how a complaint reaches the centre before judging, and concede you cannot yet say where it goes wrong. Level 3, "Why you over someone who has run a contact centre?": concede they have what you have not, then return to the quoted ground without claiming to outdo them. Concession wording: "That's a real gap. On day one I'd be learning how the centre handles complaints, not telling them." Do not fold on the plan to make the room warmer | The manager would own the cost of this gap, so it arrives in some form. F2 is a gap you stated, so the rehearsal is candour held under three levels of pressure. JD because it scores the contact-centre half of the first requirement |
| 2B2 | "You've worked one branch's complaints. This role runs the process across every branch and the contact centre. What's the jump?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold at the sentence's scope: "I handled the branch's formal complaints log." Concede the jump is real; the pack observes that your material says the log, not the process end to end. Answer slot: if any step beyond the log was yours, say which and how, in your own words; if the log was where your part ended, or there was no step beyond it, say so plainly and stay with the log. Then a plan stated as a plan: map what happens to a complaint across branches and the centre before changing anything | F1 is where the JD's end to end line presses hardest. JD because it scores the first requirement |
| 2B3 | "You'd report monthly to senior leaders, and you haven't presented above regional level. What would your first one look like?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Acknowledge: "I haven't presented to anyone above regional level." Then a plan stated as a plan, with a structure you can say aloud: the one-line takeaway first, what changed, what you need from them. The ground you have is the spreadsheet you built and your regional manager uses. Answer slot: expect a probe on whether you presented its content yourself. If you did, say how it went; if your regional manager simply used it, say so plainly | Combines F8 and F3: the gap you stated and the monthly reporting it will be tested against |

### Bank D — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2D1 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for how we handle complaints?" | CASE | [grounded] | No claim about your past. Think aloud. Clarify first: what counts toward the 40%, whether complaints are in scope, which complaint types a member could start digitally. Objective, then segmentation (complaints a member can raise and see through online, and ones that need a person), approach, measures (complaint volumes and resolution times are the JD's own), risks (a member who cannot self-serve gets stuck; a digital complaint nobody sees). Challenge one premise respectfully, for example whether a complaint should count toward a service-channel target. Say each step in words a member would not need twice | Strategy-grounded and aimed at the manager's digital interface. CASE because it is a live problem, with CO content from the brief |
| 2D2 | "How would you work with the digital team on a self-service complaints journey?" | JD | [grounded] | Answer slot (F5): if any of your work touched a digital channel, say what and which part was yours; if none did, say so plainly. Then the method, which claims no past: what you would ask the digital team first, what a member sees when the journey fails and a person has to take over, and how you would know it worked | The JD's digital-teams line is the F5 row, where your material is silent. JD because it scores that requirement |

### Bank E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2E1 | "Walk me through the monthly complaints spreadsheet you built. What does it show?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the sentence: you built it and your regional manager uses it. Answer slot: say what it counted, which tool it was in, and how you would describe how a figure was produced; if you do not know how some figure was produced, or part of it was not yours, say so plainly and stay with what you built. Name, in your own words, the figure in it you would defend least before they ask; if you cannot name one, say so | F3 and F9 both rest on this one sentence. JD because it scores the reporting and tool requirements; the probe style is EXP |
| 2E2 | "You handle formal complaints today. What made them formal, and what did that mean for how you handled them?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use your own word, formal, and do not borrow the JD's wording for your own work. Answer slot: if you know what rules or timescales applied, say what they were and your part; if you do not know, or none applied, say so plainly and stay with the log | F7 is a low-confidence discovery row, so the pack derives the probe from the JD and the word formal. JD because it scores that requirement |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Where does the complaints process work well end to end today, and where do members get lost?" | An ownership question; it also tells you the manager's real problem |
| R2.2 | "Do branch and contact-centre complaints reach you as one set of figures or two?" | Ties to the monthly reporting duty and shows you think about the numbers' shape |
| R2.3 | "What would you want the first monthly report to senior leaders to show?" | Asks what the audience needs, which is the honest way to start closing the presenting gap |
| R2.4 | "How is the digital team deciding which self-service journeys come first against the 2028 target?" | Shows you read the strategy and want to work with that team |
| R2.5 | "What does a good first 90 days look like in this role?" | Gives you a measure to work to, and tells you whether the manager has one |

## Round 3 — Panel of two branch managers, 60 minutes (case and values)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (C) | One scored prompt per value | high — the email says the panel is the values round and scores against the four values | A story per value where your quotes carry one, a selection scaffold where they do not |
| Case/Strategist (D) | The 20-minute complaint-escalation case, and strategy cases around hubs and lending | high — the email gives the case 20 of the 60 minutes | Clarify, then structure, thinking aloud; challenge one premise |
| Peer Evaluator (G) | Where the seam sits between a branch manager and the complaints lead; what happens when you disagree | medium — branch managers are the people whose branches this role works through; this is the pack's inference from their roles | Propose seam principles, not facts about Ashgrove; reciprocity framing |
| Pressure (H) | A time-boxed "why you over someone who has run a contact centre" | low — nothing in the email suggests it; a panel could still press the contact-centre gap | Hold-then-concede, as in 2B1 |

### Values cheat sheet

Values are Ashgrove's published four, from the page you copied on 12 October.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter, not the institution's | No quoted sentence carries a story. Scaffold in 3C1, ending in its honest branch |
| Plain Words | If a member needs it explained twice, the writer got it wrong | No quoted sentence carries a story. F1 offers the script you trained tellers on only as the nearest ground. Scaffold in 3C2 |
| Neighbours, Not Numbers | Every branch is part of its town; local presence matters beyond the figures | F3: "I built the monthly complaints spreadsheet our regional manager uses." The sentence gives the numbers side only; what you did to keep a branch more than a figure is an answer slot in 3C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence gives the log and the script; a complaint you saw through is an answer slot in 3C4 |

### Bank C — Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3C1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [grounded] | Selection scaffold. Pick a decision where the member's interest and a process or target pulled apart, with what you chose, what it cost and what happened. A hard truth that landed beats a tidy ending. If no such time comes to mind, say so plainly, then give the nearest thing from your own work or how you would handle one | Members First, Always, named as a published value. No quoted sentence carries a story, so this is a scaffold |
| 3C2 | "When have you made something clearer so a member would not need it explained twice?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick a real instance with what was unclear, what you changed, and whether the member understood next time. Answer slot: if you changed any wording in the script you trained new tellers on, or in anything members were told, say what and why; if you did not write or change any, say so plainly. If no instance comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle one | Plain Words, named as a published value. F1 is only the nearest ground; it says nothing about wording |
| 3C3 | "You built a monthly complaints spreadsheet, and this role reports in numbers. How do you keep a branch as more than a number?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the sentence at its scope: you built the spreadsheet and your regional manager uses it. Then the method, which claims no past: what you would put beside a figure so a branch's town and members stay visible. Answer slot: if you have used what the spreadsheet showed to decide something about a particular branch, say what; if not, say so plainly | Neighbours, Not Numbers, and the one value that sits against the role's reporting duty. F3 is the row it is tested on |
| 3C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The ground your sentence carries is the log you handled. Answer slot: pick one complaint from your own work and say where it started, your steps and how it ended; if none comes to mind that you saw through, say so plainly, then give the nearest thing, the log you handled, or how you would keep hold of one. A stance worth having ready: escalating a complaint is not letting go of it | Own the Fix, named as a published value, and the likeliest to map to your quotes. F1 supports only the setting |

### Bank D — Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3D1 | Practice scenario, not Ashgrove's actual case: "A member has complained twice about the same fee. The branch told them one thing and the contact centre another. They now want to speak to the manager. Walk us through what you do." | CASE | [generic] | A 20-minute plan. Minutes 0 to 3, clarify: what the member has been told and by whom, what exactly the complaint is, what clock if any is running, who holds it now, what the member wants. Then objective, from the member's side. Segment into the immediate fix, the cause, and what the member is told and in what words. Approach with one named owner throughout. Measures, risks, and one respectful challenge to a premise, such as whether the manager is the right first step. Ask what the panel would expect the branch to do and what the centre; do not describe how Ashgrove's process works. Practise on two more scenarios you invent | The recruiter says the case is a complaint escalation; the real one will differ. The pack labels this generic and makes no claim about Ashgrove or you. CASE because it is a live problem |
| 3D2 | "Ashgrove is consolidating eight branches into five hubs over 2027. Where do complaints go, and what do you watch?" | CASE | [grounded] | No claim about your past. Do not say complaints will rise. Say what you would look at first: complaint types by branch, what members of a consolidating branch are told and in what words, and who keeps hold when a complaint spans the old site and the new hub. Name Neighbours, Not Numbers as the test. Do not guess which branches or what happens to staff; this panel is closest to it | Branch managers are closest to the consolidation in the brief. CASE with strategy content |
| 3D3 | "Ashgrove launches small-business lending in Q1 2027, and app-only banks are the main competitive pressure. What should the complaints process be ready for?" | CO | [grounded] | No claim about your past, and none about any competitor. Questions to carry: what a new business member needs from a complaints route, who owns a first complaint on a new product, how a branch sees its status, and what members already expect from digital channels. Bring one item from the brief and then your own view | The brief supplies two strategy lines this question joins. CO because it tests thinking at the company's altitude |

### Bank G — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3G1 | "Our supervisors will ask what's in this for them. How would you coach them on escalations?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | Two grounded points only: you have been a branch supervisor for the last 3 years, and you trained new tellers on the escalation script. Method, which claims no past: start from what a supervisor needs in the moment, keep it short, say it in plain words. Answer slot: if you have coached anyone beyond new tellers, say who and what you did; if not, say so plainly and stay with the tellers | The panel are branch managers, who work with supervisors every day. F4 is the row and your own role gives a supervisor's view |
| 3G2 | "Where's the seam between a branch manager and the person who owns complaints, and what happens when we disagree?" | CASE | [generic] | Propose principles, not facts about Ashgrove: one named owner of a complaint at any time, the branch brings what it knows of the member and the town, the complaints lead owns the process and the figures, and disagreements go to the member's side and the evidence first. Say you would test the seam with them rather than assume it | A persona stem for the peers in the room. CASE because it is a live seam problem |

### Bank H — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3H1 | "Sixty seconds: why you rather than someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause and restate. Hold the quoted ground: six years in retail banking, the last three as a branch supervisor, the log you handled, the script you trained new tellers on. Concede plainly that someone who has run a contact centre has what you have not. Add no claim to outdo them. If pressed again, hold again, and do not fold on the core | The time-boxed form of 2B1, in case a panel member presses the gap. JD because it scores the contact-centre half of the first requirement |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new complaints lead do in the first month that would genuinely help your branch?" | The reciprocity question for people you would work alongside |
| R3.2 | "When a complaint escalates from your branch, what do you want to hear back, and how quickly?" | Asks for their definition of good before you offer yours |
| R3.3 | "How are you thinking about complaints through the move to hubs?" | Shows you read the strategy and care about the branches affected |
| R3.4 | "Which of the four values do you see tested hardest when a complaint comes in?" | Puts the values in their own working experience and shows you took them seriously |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches | 1A4, 2B2, 3D1 |
| across the contact centre | 1B1, 2B1, 3H1 |
| report monthly on complaint volumes and resolution times | 2B3, 2E1, 2D1 |
| coach branch supervisors on escalations | 2C4, 3G1 |
| work with digital teams on self-service journeys | 2D2, 2D1 |
| 4+ years in financial-services customer operations | 1B3, 1A1 |
| experience handling regulated complaints | 2E2, 1A4 |
| confident presenting to senior leaders | 1B2, 2B3 |
| comfortable with Excel reporting | 2E1 |

## Prohibited claims

The pack will not coach these. Each is built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's sentence at its own scope. The limit is the pack's observation: the material says one branch's log, not the process end to end. 1A4 and 2B2 keep the slot inside the log |
| Any work in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders, or to anyone above regional level | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot beyond 1B2's regional-manager question |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's sentence at its own scope: new tellers and the escalation script. 2C4 and 3G1 ask only who else, beyond them |
| Handled regulated complaints | Inflated form of F7 | No words for you. The pack's observation is that the material says a formal log; the slots ask only what applied to it |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's sentence at its own scope. The pack's observation is that the material says the spreadsheet, not what it counted; 2E1 asks what it counted |
| Skilled in Excel reporting | Inflated form of F9 | F9's sentence at its own scope. The pack's observation is that the material says a spreadsheet, not the tool; 2E1 asks which tool |

## Sources

**Provided documents:** the job description, Ashgrove's four published values (pasted, copied on 12 October 2026 from the About page), the recruiter's email on the process, a four-line summary of Ashgrove's June 2026 strategy brief, and your background in your message. The brief itself was not read.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | You pasted the four values, so the cheat sheet and VAL questions are fixed. The named URL is the source of the pasted text, not a link to read |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email gives the three sessions, who runs each and what each holds, which fixes the round structure and persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | Your four-line summary of the June 2026 brief fixes the grounding brief and the CO and CASE questions; the brief's own text would sharpen their wording |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each person's path
- The strategy brief's text → the grounding brief and 2D1, 3D2 and 3D3 move to its exact wording and figures
- What the monthly spreadsheet counted, which tool it was in, and whether you presented its content to your regional manager → F3 and F9 move from discovery; 2E1, 2B3 and 1B2 become story-mapped
- What rules or timescales applied to the branch's formal complaints log → F7 moves from a low-confidence discovery row; 1A4 and 2E2 sharpen
- Whether you have coached anyone beyond new tellers → F4; 2C4 and 3G1
- Any work with a digital channel or digital team → F5; 2D2
- One or two real instances per value and per behavioural prompt → 3C1 to 3C4 and 2C1 to 2C3 become story-mapped instead of selection scaffolds
- Your reason for Ashgrove, and for a member-owned credit union → the fourth beat of 1A1 and the answers to 1A2 and 1C2
- The recruiter's answer on the case format (R1.2) → 3D1 tuned to the real format
- A deeper research pass (offered once): up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's strategy, any interviewers' public talks, candidate reports of the loop and recent organisation news → a fuller grounding brief and interviewer reads
- A tuesday-dossier.md from an earlier evidence review → user-confirmed evidence and a ranked objection list in place of this pack's inferences
