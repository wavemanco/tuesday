Running the L1 research now: a search for Quartzline's official site, then a role-family sweep for platform API PM scope and pay.
**Not a waste of your time, but a stretch rather than a good bet: R1a (3+ years in a PM role) is absent, R3, R4a and R6 are `direct`, and R1b, R2 and R8 are `adjacent`. Status: `conditional_go`.** I couldn't research Quartzline because search permission wasn't granted. Company facts are unverified, and that alone caps the status at `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM work, any title), R2 (shipped API or platform products), R8 (own the roadmap) · unclear: R4b (stakeholder work with sales) · absent: R1a (3+ years in a PM role)
- `important` — direct: R6 · adjacent: R7 (specs, delivery with two squads), R10 (launches with sales and support) · unclear: R5 (agile delivery), R9 (adoption metrics)

The outcome turns on R1a, R1b and R2, where your work sits beside the requirement and not on it.

**Opportunity ledger.** The scope is concrete (RR6). But the employer is unverified (RR1), pay is absent (RR2), and nothing says how firmly the 3-year bar is held (RR3). Roadmap authority (RR4) and location (RR5) are open.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) the 3-year bar proves flexible enough to weigh adjacent platform and integration work, see R1a, R1b, RR3; (3) you frame R2 and R8 as adjacent, with their limits named.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently verified (research unavailable) |
| Mandate | Own the roadmap for the partner-facing API platform, with discovery, specs, delivery, adoption metrics and launches | `[grounded]` JD |
| Scope | Two engineering squads; partners, sales and support as counterparts | `[grounded]` JD |
| Hiring bar | Only the 3+ years line carries "(must-have)"; the other requirements are listed untiered | `[grounded]` JD |
| Background pattern | Platform and API PM roles often draw people from engineering, solutions or technical-account backgrounds | `[generic]` role-family pattern, not a claim about Quartzline |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Market calibration | Not run, because the role-family sweep was unavailable; no pay band offered | — |
| Unknowns | Level, salary, location, roadmap authority, how firmly the years bar is held | `[grounded]` JD silence |
| Contradictions | None visible within the pasted JD | `[grounded]` JD |

## Evidence map

Nothing is above `medium` because your background is prose, unprobed, with no artifact inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as a held PM role | must_have | absent | none | discovery | You have never held a PM title, so titled years are zero. It is `discovery` rather than `capability` because the CV may omit product-owner work done under another title. Postings that tag a years bar "must-have" are commonly screened on title when applications arrive cold. | `[grounded]` your statement; `[generic]` screening pattern | Answer G1; see plan A2, A3 |
| R1b | The same requirement, read as PM-type work under any title | must_have | adjacent | low | transferability | Near-PM work: roadmap-input sessions, requirements documents, coordinating engineers and product managers on custom builds. Limit: nothing stated shows you owned a backlog, prioritization or a product's outcomes. Low rather than medium because whether this adds up to "3 years" is a judgment, not your claim. | `[grounded]` CV prose; `[inferred]` the summing | Answer G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the integration playbook the whole team uses. Limit: that is the consumer-side of the API; nothing stated shows you shipped or managed the API product itself. | `[grounded]` CV prose, unprobed | Answer G1; a sanitized playbook excerpt would add an artifact |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading, and integration architecture across 30+ integrations. Self-reported, no inspectable artifact yet. | `[grounded]` CV prose | A sanitized playbook excerpt would raise it to `high` |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran client workshops. | `[grounded]` CV prose | none |
| R4b | Stakeholder management with sales | must_have | unclear | none | discovery | The CV is silent on sales. | `[grounded]` CV silence | Answer G3 on a later turn |
| R5 | Agile delivery | important | unclear | none | discovery | The CV is silent. Your integrations ran as scoped projects to UAT and go-live, which is not the same thing as sprint delivery. | `[grounded]` CV silence | Ask on a later turn |
| R6 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client roadmap-input sessions are discovery with the people who integrate the API. The CV frames them as delivery work. Limit: the purpose stated was implementation scope and feedback to product, not deciding a product bet. | `[grounded]` CV prose | Edits E1 and E2, pending your approval |
| R7 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and coordination of engineers on custom builds. Limit: those were custom client builds, not a standing squad's product backlog, and whether engineers built from what you wrote is unconfirmed. | `[grounded]` CV prose | Answer G2 |
| R8 | Own the roadmap | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product, which is an input to someone else's roadmap. Limit: nothing stated shows you decided what got built or said no. I tiered it `must_have` as the first-listed duty. | `[grounded]` CV prose; `[inferred]` the tiering | Answer G2 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. SQL makes it plausible. The only thread is an unconfirmed note from an earlier conversation about a triage tool support agents adopted. That prompts a question and is not treated as evidence. | `[grounded]` CV silence; `memory_lead` unverified | Answer G1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind you coordinated across the client and engineering. Limit: client go-lives, not product releases coordinated with internal sales and support. | `[grounded]` CV prose | Answer G1 (the support-side thread) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-ownership work outside the CV, such as an internal tool (R9, R2, R10, R1a) | discovery | The CV shows no tool you built, no usage metrics, and no sales or support partnership. An earlier-conversation note suggests a request-triage tool that support agents adopted, but that is unconfirmed. | It could supply the only evidence on adoption metrics (R9) and on something you shipped (R2). It could also narrow R1a, and it is the likeliest thing to move the decision. | A tool, workflow or integration helper that others used; support or sales agents using something you made; tracking who used it | Usage numbers or a dashboard screenshot, a short write-up, a launch note | `[grounded]` CV silence; `[inferred]` that it is decision-moving |
| G2 | Deciding what gets built (R8, R7, R1b) | transferability | You fed client feedback to product and coordinated engineers on custom builds. Nothing stated shows you deciding priority. Limit: input to a roadmap is not ownership of one. | R8 is a `must_have` at `adjacent`, and this is the gap interviewers for this role are most likely to press. | Ordering custom-build requests, saying no or not-yet to a client ask, a requirements document engineers built from, a roadmap change that came out of your sessions | A sanitized requirements document, or the summary you sent to product | `[grounded]` CV prose; `[generic]` that roadmap ownership is the pressure point |
| G3 | Sales partnership (R4b) | discovery | The CV is silent. | It is a `must_have` that is unclear, but a minor one. It ranks below G1 and G2 and is not asked this turn. | Joint customer calls, deal support, scoping handoffs | An email thread or a handoff document | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Here the check did not run, so this is unverified rather than negative. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Quartzline's own careers site, and tell me who I'd be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | no salary appears in the pasted JD | The figure may or may not fit your target. I have no band to compare it with. | `[grounded]` JD silence | What is the salary range for this role? | unresolved |
| RR3 | Flexibility of the years bar unknown | unknown | — | "3+ years product management experience (must-have)" | The bar may be a literal filter or a proxy for platform and product judgment. | `[inferred]` from the explicit "(must-have)" tag | How firmly is the three-year requirement held, and would integration and platform experience be weighed? | unresolved |
| RR4 | "Own the roadmap" with no stated decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Roadmap ownership may be shared with sales or leadership. | `[inferred]` from the ownership claim against silence on decision rights | When sales and partner requests conflict, who decides priority? | unresolved |
| RR5 | Location and work arrangement not stated | unknown | — | no location appears in the pasted JD | Unknown, and your constraints haven't been given either. | `[grounded]` JD silence | Where is the role based, and what is the in-office expectation? | unresolved |
| RR6 | Scope and metrics concretely stated | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The role is defined around a platform, two squads and a metric, not a vague mandate. | `[grounded]` JD | Which adoption metrics exist today, and what does success look like in year one? | noted |

## Application plan

Everything in this section, the table and the prose beneath it, is proposed and pending your approval. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Quartzline's own careers page before tailoring anything | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Look for a human route in (a referral, or a short note to the hiring manager) as well as the form | see R1a. Cold applications to a stated years bar tend to be screened on title | `[generic]` how hiring often works, not a fact about Quartzline | pending your approval |
| A3 | Put RR3's question to the recruiter early, before investing in a tailored application | see R1a, R1b, RR3 | `[grounded]` RR3 | pending your approval |
| A4 | Lead with R6, R3 and R4a. Describe R2 and R8 as adjacent in your own words: you worked the consumer side of the API and fed product, and you did not own a roadmap | see R2, R8. Say what was actually you. | `[grounded]` map rows | pending your approval |

| # | Current line (your words) | Proposed | Status |
|---|---|---|---|
| E1 | "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live." | Add a summary line: "Solutions engineer and implementation lead, seven years at an enterprise-software vendor: led 30+ client integrations of its REST APIs end to end, and ran quarterly roadmap-input sessions that collected client feedback for product." | `resume_edits_pending_approval` |
| E2 | Bullets: roadmap-input sessions and the integration playbook sit lower in the list | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses" to the top; wording unchanged | `resume_edits_pending_approval` |

I checked both edits clause by clause against your sentences; neither adds a title or a claim. Wording cannot create PM years. R1a stays a real gap that only a flexible bar, a referral or new evidence from G1 and G2 can offset.

Offered extra (not built): a one-page partner-API discovery brief written from one of your real integrations. It would test R2's limit directly. Say yes and I'll draft it for your approval.

## Evidence status

Verified: none yet. Unverified leads: a triage tool support agents may have adopted, from an earlier conversation. It is unconfirmed and only prompts G1. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology company careers Product Manager Platform APIs" was refused because permission wasn't granted. It would have moved RR1 and role reality's organization and contradictions rows. |
| 2. Role-family sweep | unavailable | The search "Product Manager API platform B2B Series B salary range requirements transition from solutions engineer" was refused for the same reason. It would have moved market calibration and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

If you'd like this assessment kept, I can save it as `tuesday-dossier.md`.

**Upgrade menu**
- Search permission (targets 1 and 2) → RR1 can close or stay open, and RR2 gets a role-family pay band.
- The live posting link or Quartzline's careers page → RR1.
- An answer to G1 → R9, R2, R10 and possibly R1a.
- A sanitized requirements document, or the roadmap-input summary you sent to product → R6, R7 and R8 can reach `high`, and G2 narrows.
- A sanitized slice of the integration playbook → R3 to `high`.
- The hiring manager's name → role reality's scope read, and who to write to under A2.
- Your pay floor and location constraints → hard-gate checks stop being unknown.

**Questions**

G1 — Did you build an internal tool, such as a request-triage tool that support agents adopted? If so, what did you own, how was adoption measured, and is there anything you can show?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Can you recall a time you decided what got built, such as ordering custom-build requests, turning down a client ask, or writing a requirements document engineers built from? What was yours and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Orientation — Do you have non-negotiables for a PM move, such as a salary floor, location or work arrangement, or a minimum level? Answer in text, paste a voice transcript, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.