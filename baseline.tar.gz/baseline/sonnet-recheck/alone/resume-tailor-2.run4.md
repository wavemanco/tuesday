Dev, I read your pasted summary as your resume lines and quoted each line verbatim. I made no edits to the document, and every row below is `pending your approval`.

**Where you stand.** The JD makes "3+ years data engineering" a must-have, and your material shows five years as an analyst, not as a data engineer. Reordering and rewording can't change that, so I haven't written a line that tries to. What your material does support is real: dimensional modelling, about 25 dbt models, and tests on the nightly job. I've moved that to the top. The gaps are Airflow, Spark and Kafka (you said you've never used them), plus anything that would show production Python or SLAs. Those are in the gap tables with ways to close them. Whether this role is worth applying to with that must-have unmet is job-underwriter's question, not this resume's.

Convention for the rows: bullets drop the leading "I" or "I've", as is usual on a resume. Nothing else about the verbs changes.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail, moving into data engineering from analytics." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics." | `[grounded]` your resume line and your message | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." (moved to first bullet) | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | "Built and maintained about 25 dbt models, including the core orders mart." (moved to second bullet) | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks, and added tests to it." (moved to third bullet) | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." (moved to fourth bullet) | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged — moved to last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` resume | pending your approval |

Two choices to know about:
- **E4** keeps "our nightly dbt job" and does not call it a "pipeline", which is the JD's word.
- **E5** keeps "for analysis" and "some". Those qualifiers are the honest part of the line.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | `not_evidenced` | E1 states "5 years" as an analyst and claims no data engineering years. Recovery: C3. | `[grounded]` resume shows analyst years only |
| M2 | Production Python | important | `not_evidenced` | E5 keeps the Python line as written. Recovery: C1. | `[grounded]` "for analysis", "some scripting" |
| M3 | Airflow or equivalent orchestration | important | `not_evidenced` | Airflow is a named absence (N1). Whether the nightly dbt job's scheduling counts as "equivalent" is open. Recovery: C2. | `[grounded]` "Never used Airflow" |
| M4 | Dimensional modelling | important | `surfaced_by_edit` | E2 and E3 put it first. The star schema was designed "with our then-DE". | `[grounded]` resume |
| M5 | Data quality | important | `surfaced_by_edit` | E4 ("added tests to it"). The line makes no ownership claim. | `[grounded]` resume |
| M6 | SLAs | important | `not_evidenced` | Nothing in your material mentions a deadline or commitment on the nightly job. Recovery: C2. | `[grounded]` resume is silent |
| M7 | Spark and batch pipelines | important | `not_evidenced` | Spark is a named absence (N2). | `[grounded]` "Never used … Spark" |
| M8 | Streaming (Kafka) | preferred | `not_evidenced` | Named absence (N3). | `[grounded]` "Never touched Kafka" |
| M9 | Partner with analytics on requirements | important | `surfaced_by_edit` | E2 shows working alongside a data engineer. You stood on the analytics side of that relationship, and no line claims the engineering side. | `[grounded]` resume |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | Python "for analysis" and "some scripting to pull vendor APIs on a cron". Nothing says who depended on the scripts, or whether they ran with logging, retries or alerts. | The JD lists production Python as a requirement. "For analysis" reads as analyst work to a reader who has never met you. | A vendor-API script that others' reports depended on; one that failed overnight and you fixed; one in a shared repo with review; one with retries, logging or alerting | The script repo or a link, a failure alert, a README | `[grounded]` what the resume says and omits; `[generic]` what this costs on applications of this kind |
| C2 | Orchestration and SLAs | important | A "nightly dbt job" you fixed and added tests to. Who schedules it, what runs after it, and whether a deadline applies are not stated. | The JD lists Airflow or equivalent orchestration and ownership of SLAs, and nothing in your material speaks to either. | A scheduler such as dbt Cloud or cron that you configured or changed; dependencies between jobs; alerts on failure; a "mart ready by X am" expectation that you met or had to defend | Scheduler config, a dbt run history, an incident note | `[grounded]` what the resume says and omits; `[generic]` what this costs on applications of this kind |
| C3 | 3+ years data engineering | must-have | 5 years as a Senior Data Analyst; DE-adjacent work is real but is not titled or described as engineering. | It is the one requirement the JD marks must-have, and "years" is the most literal thing a reader checks. | Stretches where loading, modelling or maintaining data for others was most of the job; on-call or break-fix duty; work you did that a DE would otherwise have done | An old role description, team org chart, tickets or commit history | `[grounded]` the resume's analyst title and years; `[generic]` what this costs on applications of this kind |

Named absences (nothing in your material to pull from):

| # | Requirement | The absence | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | Airflow | You have never used it. | A small personal project: port your vendor-API script into an Airflow DAG and put it in a repo. It would honestly read as a personal project, not production. | `[grounded]` the absence; `[generic]` the closing path |
| N2 | Spark | You have never used it. | A hands-on project on a public dataset, or an internal task where a Spark job replaces a heavy SQL step. Without one, this stays a gap for this JD. | `[grounded]` the absence; `[generic]` the closing path |
| N3 | Kafka and streaming | You have never touched it. The JD calls streaming a plus, not a requirement. | A small producer and consumer project would give you something to talk about. For this application it is not worth closing first, because it is the lowest-weighted item in the JD. | `[grounded]` the absence; `[generic]` the closing path |

## Not written, and why

- **"Data Engineer" as a title, or "3+ years data engineering".** Your title is Senior Data Analyst and the years are analytics years. A retitle would be an upgrade, not an equivalent.
- **"Production Python" or "production pipelines".** You write Python "for analysis" with "some scripting". Production is a claim about who depended on it, and your material doesn't say.
- **Airflow, Spark or Kafka in a skills list, or "orchestration experience".** You said you've never used them, and cron plus a nightly dbt job is not a stated equivalent.
- **"Batch pipelines".** The JD's word for what you did is not your word. You fixed and tested a nightly job.
- **"Owned data quality and SLAs".** You "added tests to it". Ownership and any SLA are not in your material.
- **"Built the orders mart star schema" without "with our then-DE", or "led" the design.** That would change the verb and the scope.
- **"dbt models on Redshift".** You wrote SQL on Redshift and built dbt models, but never said they ran on it, so I haven't joined the two.
- **"Partnered with analytics on requirements".** You were the analytics side. The line would flip which side of the table you sat on.
- **Rejected rows:** none yet.

## Parse-safety check

You pasted text, not a file. I could not run any of these checks: multi-column layout, tables and text boxes, images and icons, content in headers or footers, file type. Your section headings aren't visible in the paste either, so I can't judge whether a parser would recognise them. If you send the actual file, I'll run the full check.

## Upgrade menu

- **The resume file (.docx or PDF):** unlocks the full parse-safety check and a check for hidden text carried over from a template.
- **A link or screenshot of the vendor-API scripts or the dbt project:** can raise C1 and C2 from your own word to something inspectable.
- **An older resume version or old role descriptions:** may hold DE-adjacent work that was cut, which could change M1.
- **Offer, beyond the spec:** a short "why I'm moving into data engineering" paragraph for the application, built only from the same traced sentences. It would give a reader a reason to weigh your dbt and modelling work against the missing DE title. I'll draft it only if you say so.

## Questions

C1 — Where do the vendor-API scripts run, who uses what they produce, and what happens when one fails (alerts, retries, logs, a repo)?

C2 — What schedules your nightly dbt job, and was there ever a deadline for the orders mart to be ready, or an alert you set up or responded to?

C3 — Beyond the 25 dbt models, which parts of your five years were closest to engineering work (loading data, on-call, building tables others depend on), and for how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.