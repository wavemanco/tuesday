I'll read the reference files the skill requires before building the assessment.
**Yes, it looks worth applying to, provided R1 and R2 (both hard gates) hold for you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery as the warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 has a credible bridge with its limit named. R9 and R10 are open questions about your history, not known absences.

**Opportunity ledger.** The posting is live and matches the company's own about page (RR5), and the pay is stated and sits inside the market band you were sent (RR1). The reporting line, the on-call scope and the equity terms are unknowns (RR2, RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed met; (2) the BigQuery gap (R8) is framed as adjacent, never as BigQuery experience; (3) the reporting line and on-call scope verify in interviews (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the company's own about page, fetched. The funding figure is the company's own statement, not independently confirmed |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain's pipelines, with no direct reports named | `[inferred]` from the JD naming no reports. It matches the typical scope in the Datawright report, `[generic]` for the title at Series B–D companies |
| Compensation | $148,000–$166,000 plus equity. The posting does not say whether the range is base | `[grounded]` JD |
| Market calibration | Base median $151,000, interquartile range $139,000–$163,500, and "senior" typically 5–8 years. The posting's floor is $3,000 under the median and its ceiling is $2,500 over the 75th percentile. Your 6 years sits inside the typical range | `[grounded]` the Datawright 2026 report as you pasted it. `[generic]` as a pattern for Series B–D companies, never this employer's offer |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager, team size, on-call expectations, equity terms, whether the range is base | `[grounded]` JD silence |
| Contradictions | None. The live careers page and what you pasted read identically, and the page shows "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

Your background was typed into the conversation and is treated like a CV: self-report with no inspectable artifact yet, so `medium` is the ceiling on a first pass. I have not seen your CV.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and ability to work in the US were not given, so this is not established. Confidence is `none` because you have stated no constraint to grade | `[grounded]` JD term, candidate side not given | Gate question in the closing block |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given, so the range cannot be checked against one. The range is stated, which is a positive for RR1 | `[grounded]` JD term, candidate floor not given | Gate question in the closing block |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You said 6 years of data engineering at a B2B payroll company. Confirmed and specific, with no inspectable artifact | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You said you use both daily. The claim is specific but there is nothing to inspect, so expect a probe on depth | `[grounded]` your stated background | A sanitized repo or model excerpt would raise it |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so the requirement as written is met. The BigQuery question is R8 | `[grounded]` your stated background | A dbt docs or lineage screenshot would raise it |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You said you used Airflow for orchestration, and Airflow is the tool the posting names | `[grounded]` your stated background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. Confirmed and specific, with no artifact | `[grounded]` your stated background | A sanitized suite excerpt would raise it |
| R8 | BigQuery as the warehouse behind dbt | important | adjacent | medium | transferability | The posting names BigQuery in the mandate, and the requirements list says only "a cloud warehouse". Your adjacent work is dbt on Snowflake. The limit is that you have never used BigQuery, so any BigQuery-specific behavior is untested by your history. Both are SQL cloud warehouses that dbt targets, which is why the bridge is credible | `[grounded]` your statement that you have never used BigQuery. `[generic]` that the two warehouses are comparable under dbt | See G1 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | You described dbt, Airflow and test work. Neither confirms nor rules out ingestion work, so it is open | `[grounded]` silence in your background | See G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite may be related work, but you have not said analysts or upstream teams relied on agreed guarantees from it | `[grounded]` silence in your background, `[inferred]` possible link to R7 | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | dbt on Snowflake, about 180 models. Never used BigQuery | The mandate names it, so it is the most visible stack difference | Bridge: your dbt-on-Snowflake work. Limit: no BigQuery use. A small personal dbt project run against BigQuery would narrow the limit | A short public repo with a README, built only if you choose to | `[grounded]` your statement. `[inferred]` that a work sample would narrow the limit |
| G2 | Ingestion from the app and CRM (R9, important) | discovery | Nothing about how data reached your warehouse | The mandate lists ingestion first, so a clear yes here moves the fit | Loading data from an application database, an event stream or a CRM export into the warehouse. A managed connector or custom Airflow extract jobs. Change data capture or incremental loads | An architecture sketch, a DAG screenshot, a runbook | `[grounded]` silence in your background. `[generic]` that the mandate lists ingestion first |
| G3 | Data contracts for analysts (R10, important) | discovery | The test suite exists, and nothing says analysts or other teams relied on specific guarantees | The role is defined around contracts analysts depend on | Agreed schemas or freshness expectations with upstream teams. Test thresholds analysts counted on. A broken-contract incident you handled | A contract doc, a test config, an incident note, any of them sanitized | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | No seniority-pay mismatch: the range brackets the $151,000 median and tops out just over the 75th percentile | `[grounded]` JD range against the pasted Datawright figures. `[generic]` for the market side | Is the range base salary, and is there a bonus on top? | noted |
| RR2 | Reporting line and team unstated | unknown | — | "Build and run the pipelines" | You may be the only data engineer, or part of a small team. The posting names no hiring manager | `[inferred]` from the JD naming no manager, team or reports | Who would I report to, and how many people work on data engineering today? | unresolved |
| RR3 | On-call and operational load unstated | unknown | — | "Build and run" | "Run" suggests operational ownership of pipelines, with incident response possible | `[inferred]` from the verb "run" and the JD's silence on on-call | Is there an on-call rotation for pipeline incidents, and who shares it? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and valuation are not given, so its value is unknown | `[grounded]` JD gives no terms | What is the equity grant, the vesting schedule and the current valuation basis? | unresolved |
| RR5 | Employer and posting established | positive_signal | — | "Accepting applications" | The posting is live and matches the company's own description. The funding and headcount figures are the company's own claims | `[grounded]` careers and about pages fetched | Can you share how the data team fits into the 264-person organization? | noted |

## Application plan

Each row below is proposed and pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume with three lines, each traced to your own words: built the dbt project on Snowflake (about 180 models); used Airflow for orchestration; set up the Great Expectations test suite. I would not add scope or ownership words you have not stated | R5, R6, R7 | `[grounded]` your background as typed | resume_edits_pending_approval |
| E2 | Frame BigQuery plainly as adjacent: "dbt on Snowflake, no BigQuery use yet", never as BigQuery experience | R8 | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small public dbt project run against BigQuery, if you want to narrow R8 before an interview | R8 | `[inferred]` from G1 | pending your approval |
| Q1 | Ask the verification questions from RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Series C Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about), and fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It moved role reality's organization and contradictions rows and set RR5. The employer is attributable, so there is no failed-attribution entry |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration line and the pay check in RR1, so a search could not change either |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can save all of this as `tuesday-dossier.md` if you want a file to carry forward.

## Upgrade menu

- Your location and pay floor, answering the gate question below: R1 and R2 close, and the status likely moves to `go`.
- Your CV: I can check that R3 to R7 are communicated at the scope you described, and test E1 against your actual wording.
- A dbt docs or lineage screenshot, a sanitized Great Expectations suite excerpt, or a short repo: R4, R5 and R7 can move from `medium` to `high`.
- Answers to G2 and G3: R9 and R10 resolve or become named gaps.
- The hiring manager's name, if you learn it: the scope read and the story to lead with can be tailored to that reader.
- A deeper research pass on Pellucid Learning (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. R1 and R2 — Do both hold for you: are you located in the US (or willing to be in Denver), and does $148,000–$166,000 clear your pay floor?
2. G2 — Have you built or owned a pipeline that brought data from a product database, event stream or CRM into your warehouse? What did you own, with which tools, and at what scale?
3. G3 — Did analysts or another team depend on agreed schema, freshness or test guarantees from your pipelines? What did you own, and was it written down anywhere?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.