I'll read the reference files the skill points to before building the assessment.
**Yes, it's worth applying, with conditions. Status: `conditional_go`.** Your experience matches the stated requirements (R3, R4, R5, R6, R7 and R8, all `direct`), and the pay range is credible against your recruiter's report. Two things are still open: whether the location and pay terms work for you (R1, R2), and whether your ingestion and data-contract experience matches what the role needs (R10, R11). I'm treating you as at the applying stage.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 has a credible bridge with its limit named. R10 and R11 are the rows most likely to change the status.

**Opportunity ledger.** The employer and posting agree across both pages you copied, and the role sits at a stage matching your pay report's cohort (RR1). The posted range sits at or above the report's median (RR2). Open items are the unnamed hiring manager and team (RR3), the unstated equity terms (RR4) and the unstated operational load behind "build and run" (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the location, US work authorization and pay floor you hold are compatible with R1 and R2; (2) your ingestion and contract experience holds up on the two questions below (R10, R11); (3) the BigQuery gap is stated plainly as adjacent, never as BigQuery experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About page text you copied |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow or similar, data quality testing, SQL and Python | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Reads as one reporting domain (app and CRM into a warehouse for analysts), with no direct reports mentioned | `[inferred]` from the JD's list of responsibilities and its silence on reports |
| Market calibration | The report gives a base median of $151,000 and an interquartile range of $139,000–$163,500. The posted floor is $3,000 below the median and the ceiling is $2,500 above the 75th percentile. "Senior" typically means 5–8 years, and your 6 sit inside that. Typical scope is one domain's pipelines with no direct reports, which matches the posting. Equity is on top of base, and the report figure is base only | `[grounded]` the report's figures and the JD's range; `[generic]` the typical-scope pattern, not a claim about Pellucid |
| Unknowns | Hiring manager and team size; equity size and vesting; on-call load; whether this is a new or backfill role; first-90-day outcomes (none stated) | `[grounded]` JD silence |
| Contradictions | None between the JD and the About page as you pasted them | `[grounded]` both texts |

## Evidence map

Your background is prose at intake, so it is treated as CV-equivalent, and `medium` is the ceiling until you show an artifact. I haven't seen your CV, so presentation gaps can't be judged yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated your location, US work authorization or office willingness, so the gate is not established. Confidence is `none` because there is no statement of yours to grade | `[grounded]` JD terms; constraints not given | Question G3 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given. The range itself sits at or above the report median | `[grounded]` JD range; floor not given | Question G3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You have 6 years in data engineering. Years of experience is graded as fit, not as a gate. It is stated and specific but uninspected | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. The claim is specific but has no artifact yet | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. That is a substantial claim, and a repo or dbt docs page would raise it | `[grounded]` your background | Optional: dbt docs or lineage screenshot, sanitized |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement does not name BigQuery. BigQuery appears in the responsibilities instead (R9) | `[grounded]` JD wording and your Snowflake work | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You run Airflow for orchestration and the JD names Airflow. The claim is uninspected | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is a direct match for data quality testing. A suite config would raise the band | `[grounded]` your background | Optional: sanitized suite config |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Your dbt work on Snowflake carries over. The limit is that you have never used BigQuery, so its billing model, partitioning and clustering, and access model are untested by your work. A hiring team may or may not weigh that heavily | `[grounded]` your Snowflake work and "never used BigQuery"; `[generic]` that hiring teams tend to probe warehouse-specific cost and performance | Optional work sample, see W1 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Your background doesn't say what sources you ingested, such as product databases, SaaS APIs or CRM exports, or how. There may be relevant work that isn't visible yet | `[grounded]` silence in your background | Question G1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is adjacent, since it enforces quality. A contract is an agreed schema or SLA with producers and consumers, and nothing so far says you did that | `[grounded]` your suite; `[inferred]` the adjacency to contracts | Question G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R10, important) | discovery | Nothing yet about your data sources or how they were ingested | It is the first-named responsibility in the JD, so an unclear answer is the largest open row on the fit side | Syncing a CRM or a SaaS tool into the warehouse; replicating an application database; building or maintaining connectors or incremental loads; handling schema changes from a producing team | A DAG, a connector README, a data-flow diagram | `[grounded]` background silence; `[inferred]` that this row could move the status |
| G2 | Data contracts (R11, important) | discovery | The Great Expectations suite is the closest evidence, and it doesn't show agreements with data producers or consumers | The JD names contracts as something analysts depend on | Agreeing a schema or freshness expectation with an app team; versioned model interfaces; blocking a breaking change; documenting guarantees for analysts | A contract doc, a schema-change policy, a dbt model contract or exposure file | `[grounded]` background; `[inferred]` adjacency |
| G3 | Location, work authorization and pay floor (R1, R2, hard_gate) | hard_gate | Your constraints are not given | Both gates are unconfirmed, so they are the quickest way to a `no_go` | Not applicable, since this is a term you meet or don't | None needed | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting consistent; funded at the cohort's stage | positive_signal | — | "Series C ($52M, February 2026)" | The company is real, funded and hiring, as described | `[grounded]` both pasted pages; `[generic]` that the report's Series B–D cohort is the right comparison | Is this role new or a backfill, and where does it sit in the data team? | noted |
| RR2 | Posted pay consistent with the market | positive_signal | — | "$148,000–$166,000 plus equity" | No seniority-compensation mismatch is indicated: the range straddles the median and reaches above the 75th percentile | `[grounded]` the report's figures and the JD's range | Is the range for this level fixed, and where would my experience place me in it? | noted |
| RR3 | Hiring manager and team unnamed | unknown | — | "Build and run the pipelines" | Team size and reporting line are unknown. This may be a lone data engineer or a member of a team | `[grounded]` the posting names no manager; `[inferred]` team-size ambiguity from the JD | Who would I report to, and how many data engineers and analysts are on the team? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant size, vesting and strike terms are unknown, so total compensation can't be compared to the report's base figures | `[inferred]` from "plus equity" with no terms | What are the equity grant size, vesting schedule and latest valuation basis? | unresolved |
| RR5 | Operational load behind "build and run" | unknown | — | "Build and run the pipelines" | "Run" may include on-call or pager duty for pipelines, which the posting doesn't state | `[inferred]` from the verb "run" with no operating terms | Is there an on-call rotation for these pipelines, and how often would I be on it? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle your location, authorization and pay floor against R1 and R2 before spending effort | The cheapest way to find a `no_go` | `[grounded]` the R1 and R2 rows | pending your approval |
| E1 | Lead the CV with your own facts, in your own terms: the dbt project on Snowflake of about 180 models you built, Airflow orchestration, and the Great Expectations suite you set up. I can't draft exact lines until I see your CV | R3 through R8 are your strongest rows | `[grounded]` your background | resume_edits_pending_approval |
| W1 | Optionally, build a small dbt project on BigQuery using a public dataset, to turn "never used BigQuery" into something you can show | R9 is the one adjacent row you can close with an artifact | `[inferred]` from the R9 limit | pending your approval |
| P1 | In interviews, state it as: "dbt on Snowflake, and I have not used BigQuery." Don't describe it as BigQuery experience | R9 is adjacent, and interviewers can check the claim | `[grounded]` your own "never used BigQuery" | pending your approval |
| Q1 | Ask the verification questions of RR1, RR3, RR4 and RR5 in the loop | The register doubles as interview preparation | `[grounded]` the register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | You pasted the careers posting and the About page, so the employer's description, the posting's wording and its consistency are already in hand. It would have fed the contradictions row and the standing failed-attribution entry, and neither needs a search |
| 2. Role-family sweep | skipped | Your recruiter's Datawright report, with its median, interquartile range, seniority and scope norms, fixes the market calibration line and the pay comparison already |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form. A name would feed the scope read and the plan's positioning |

If you'd like, I can write this up as `tuesday-dossier.md` to keep or hand to a later session.

## Upgrade menu

- **Your location, work authorization and pay floor:** R1 and R2 close to `direct` or `hard_gate_fail`, and the status becomes `go` or `no_go`.
- **Your CV:** presentation gaps can be judged, and E1 becomes exact wording.
- **A dbt docs site or lineage screenshot, a Great Expectations suite config or an Airflow DAG (sanitized):** R5, R7 and R8 move from `medium` to `high`.
- **Answers to G1 and G2:** R10 and R11 resolve and the status firms up.
- **A BigQuery sample project:** R9's limit narrows.
- **The hiring manager's name:** the scope read and positioning sharpen.
- **A deeper research pass on Pellucid** (funding history, leadership changes, public employee and candidate reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

**G1 —** Have you ingested data from a product database, a CRM or another SaaS tool into your warehouse? What did you own, what tool or approach did you use, and what happened when the source schema changed?

**G2 —** Have you ever agreed a schema, freshness or quality expectation with a team that produced or consumed your data, beyond running tests against it? What did you own and how was it enforced?

**G3 —** Where are you based, are you authorized to work in the US without sponsorship, are you willing to be in Denver if needed, and what is your pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.