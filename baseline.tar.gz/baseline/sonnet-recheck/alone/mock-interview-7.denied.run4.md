I'll start by reading the reference files the skill points to.
Fixing one section reference in the pack, then I'll present it.
Femi, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-denied-da87507e/e12620dc-03a9-44cd-b726-c882fe6dfec4/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it as a hiring-manager round, because I don't know whether Tobias would be your manager. It has 20 questions across six interviewer styles, weighted toward live case problems and a skeptical probe of your gaps.

All four web searches were refused (company values, interview process, strategy, and Tobias), so nothing in the pack is about Saltmarsh beyond your JD. There is no company-specific question and no section on Tobias. The Sources section lists each refused search.

The highest-ROI rehearsal is question B1: "You haven't worked on a game with in-app purchases. How would you get up to speed?" It is built from the gap you named yourself. Practise it aloud with the plain acknowledgment, a learning plan, and a hold on the retention and calendar work you've actually done. Next are B2 (one title's content drops versus two titles' live events) and B3 (presenting retention numbers versus owning the post-event review).

Say the word and I'll play the skeptical interviewer on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the person you'd report to, a skip-level, or a peer, and did the recruiter mention any focus areas or a task to prepare? A skip-level would raise the time-pressure questions.
2. Do you want me to retry company research, including a deeper pass (up to 6 more searches and 2 more fetches, several more minutes)? Pasting Saltmarsh's values or careers page would also work.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** one 60-minute conversation on Friday. Built as a hiring-manager round, because the material gives the interviewer's title but not whether Tobias would be your manager. Web research was refused in this session, so everything about the company is absent and nothing here is a claim about Saltmarsh beyond the JD you supplied.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No values-style round is detected here, so this pack has no VAL questions |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge. None here: the research that would ground it was refused |
| CASE | A live problem from the role, scored on structure and reasoning |

Bank letters skip F so that question IDs never collide with the fit-snapshot rows (F1 to F9).

## 2. Prep triage

Sized to about one day, since the interview is Friday. Do these in order; everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Say B1 aloud three times, including the plain acknowledgment and both follow-ups. This is the highest-ROI prep in the pack | B1 |
| 2 | Write your answers to the slots in B2, B3 and B5 in your own words, then say them aloud | B2, B3, B5 |
| 3 | Time a 90-second arc for the journey question | D1 |
| 4 | Talk through two cases out loud, clarifying before structuring | A2, A3 |
| 5 | Pick three reverse questions you would genuinely ask | Section 6 |

Everything else is insurance.

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not a live-events calendar and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles wording makes a probe on both likely. If any of what you ran was an event with its own start and end, say how it was planned, in your own words; if it was only weekly drops, or you never planned across more than one title, say so plainly and stay with the weekly calendar for your main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination with any of the four disciplines. The JD asks for coordinating, not leading, and your stated limit on leading is F9. Answer slot: if any weekly drop needed work from design, art, engineering or community, say which of them and what your part was, in your own words; if you did not work with a discipline, or someone else handled it, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting monthly retention numbers sits next to a post-event review and its KPIs without being the same thing, and the words stay at: "Presented the monthly retention numbers to the studio head." Answer slot: if any of those presentations looked back at a specific drop or event, or you chose which numbers went in, say so in your own words; if the numbers were a monthly report prepared elsewhere or with no look-back at a drop, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap on the artifact, but a line with nothing inspected behind it, so expect a probe on what is on it and who else shaped it. Lead with the quote's own terms: you wrote it, and QA still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are in the first quote. Neither quote says the title was live-service. Answer slot: expect a probe on how live the title was. Say how the main title was updated and run after release, in your own words; if it was not a live game in that sense, say so plainly and stay with the weekly calendar. Length of experience is not a gate, so this is a probe to rehearse and not a bar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Closed in the quote's own terms. Lead with it as written, and expect a probe on cadence and what went into a drop, which is yours to answer from memory |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Closed on presenting; the quote does not say how the measures were defined. Answer slot: expect a probe on which retention measures and how each was defined. Say which and how, in your own words; if you did not define them, or do not know how one was counted, say so plainly and stay with presenting them |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist is the one written artifact in your material, and it shows writing, not clarity; the words stay at: "Wrote the release checklist our QA team still uses." Answer slot: if any writing beyond the checklist was yours, say what it was, in your own words; if none was, say so plainly and stay with the checklist |
| F9 | Not in the JD. Role-family expectation, written as prose: mobile live-ops roles commonly touch in-app-purchase performance and sometimes people leadership | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [generic] | capability | A gap you stated, and wording cannot close it. Words: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The JD itself does not ask for either |

## 4. Persona table

Loop: one 60-minute session with Tobias Wrenfield, Head of Live Operations, from your own message. Nothing else about the loop is established, so weights rest on the hiring-manager relationship prior plus your own framing, and no interviewer signals could be read.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems from the job: plan a calendar, review an event, handle a slipping update | 5. Hiring-manager prior is Case plus Skeptic, and the JD is a list of things done live | Clarify, then objective, then options, then metrics and risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B) | Quiet probing of what the JD asks and your background does not show | 5. Same prior. You stated two limits yourself (F9), and F1, F3 and F5 each stop short of the JD's wording | Rehearse B1 until it is boring: plain acknowledgment, a plan stated as a plan, and a hold on what your own sentences carry |
| Data-Driven Prober (bank C) | Definitions and attribution behind the retention work and the checklist | 3. The JD names retention metrics and KPIs, and your material has no figures to defend, so the probe is on definitions | Know what you can and cannot say about how each measure was defined; say plainly when you do not know |
| Conversational (bank D) | Friendly opener, the journey question, casual questions that are still scored | 3. Any 60-minute conversation opens this way | A 90-second arc built only from sentences you wrote, plus honest motivation |
| Pressure (bank E) | Time-boxed challenges on why you, and how much was you | 2. Raised if Tobias is a skip-level rather than a manager; no signal either way | Hold through two follow-ups, then concede specifically; never fold the core claim |
| Peer Evaluator (bank G) | Seams between disciplines, credit, disagreement | 2. The JD makes coordination across four disciplines central, though Tobias is unlikely to ask as a peer | Propose seam principles, not invented history |
| Values / Behavioral | Not banked | Low. No values-style round is detected: no loop source documents one, and the loop here is one named conversation | none |

## 5. Question banks

Highest-ROI prep in the pack: **B1**. It is the objection built from a gap you stated yourself, and F3's KPI wording is where it presses hardest. B2 and B3 come next.

### Bank A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The art team tells you on Monday that the art for an event launching in two weeks won't be ready until three days before launch. What do you do?" | CASE | [generic] | Clarify first: what the event is for, what is fixed (the date, whether it is announced) and what can move (scope, art fidelity, date). Then options with a cost each, a recommendation, the risk you are accepting, and who you tell and when. Say your hypothesis aloud before the framework. The question needs no claim about your past, so the guidance makes none | The JD's coordination line (F2) as a live decision; CASE because it scores structure under a slipping dependency |
| A2 | "Two titles each have an event planned for the same week. Walk me through how you'd plan the next eight weeks across both." | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify the objective for each title, what is shared and what is not, and what can move. Sequence, name the review points, and challenge one premise, such as whether the collision is real. If you anchor in your own work, stay at the quote's scope: "I ran the weekly content-drop calendar for our main title." Do not describe planning across two titles unless you did | F1 and F6 are the evidence; the question is the JD's two-titles line turned into a plan. CASE with JD content |
| A3 | "An event ended last week. The players who joined during it are retaining worse than the ones before. How do you review it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Define the retention measure and window first. Check the two cohorts are comparable, list what else changed in the period, rank hypotheses by how cheaply each can be tested, and say what decision the review serves. Name the weakest assumption in your own diagnosis before they do. Anchor only at the quote's scope: you presented those numbers, which is not the same as having diagnosed a drop | F3 and F7 are the evidence; CASE because it is a diagnosis delivered live, with the JD's post-event review as the source |
| A4 | "You join and your first event is on a title you haven't played. What do you need in your first week?" | CASE | [generic] | Play it. Then talk to design, art, engineering, community and QA about how updates currently ship, read earlier reviews of past events, and agree what a good result means before planning. The guidance makes no claim about Saltmarsh | Stands in for a CO question, which this pack cannot ground. CASE because it tests the clarify-first habit |
| A5 | "You have two good event ideas and room for one. How do you choose?" | CASE | [generic] | State the objective, then compare on what each needs from each discipline, how reversible it is, and what you would learn from it. Make a recommendation, name the assumption you hold least firmly, and say what would change your mind | JD's calendar ownership (F1) as a prioritisation decision; CASE |

### Bank B: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. If the titles you'd run have them, how would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The deepest rehearsal, with three follow-up levels. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan said as a plan: what you would ask for and from whom in the first weeks. Hold on what your own sentences carry, at their scope: "Presented the monthly retention numbers to the studio head." Follow-up 1, "so you can't read a revenue KPI": concede only what you have not done, repeat the plan, do not claim a skill you have not stated. Follow-up 2, "what would you get wrong first?": answer slot, say what you think it would be, in your own words; if you do not know, say so plainly. Follow-up 3, "why take that risk?": return to the quotes, without describing what they prove | Premised on F9, a gap you stated; the JD never names purchases, so the conditional wording keeps the question honest. JD because it scores the role against the gap, with hold-then-concede as the Skeptic's bar |
| B2 | "You ran content drops for one title. This role is a live-events calendar across two. What's different, and why wouldn't that be a stretch?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start at the quote's scope: "I ran the weekly content-drop calendar for our main title." Answer slot: if any of what you ran was an event with its own start and end, say how it was planned, in your own words; if it was only weekly drops, or you never planned across two titles, say so plainly and stay with the calendar you did run. Concede the step up as a step, and say how you would take it | F1 is the headline requirement and where the material stops short; JD with a Skeptic delivery |
| B3 | "The role owns the post-event review and the KPIs it reports. What part of that have you owned?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | The hold is only what the quote carries: "Presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went in, or any presentation looked back at a specific drop, say so in your own words; if the numbers came from elsewhere or there was no look-back, say so plainly and stay with presenting them. Hold through two follow-ups by returning to what you presented, never by adding to it | F3 holds the gap between presenting and owning; JD because it scores a named requirement |
| B4 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. What happens when one of them doesn't deliver?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge plainly: "I haven't led a team." The JD asks for coordinating, so keep the answer on that. Answer slot: if a drop of yours ever depended on one of those disciplines and it slipped, say what happened and what part was yours, in your own words; if that never arose, or it was handled by someone else, say so plainly. Then how you would raise it early and who decides, said as a plan | F2 and F9 together; JD because coordination is a listed duty |
| B5 | "Walk me through how your main title worked as a live game after release." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the two sentences as written. Answer slot: say how the main title was updated and run after release, in your own words; if it was not a live game in the sense the JD means, say so plainly and stay with the weekly calendar. Do not call it live-service unless it was | F5, where the years are met and the live-service element is silent |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention measures did you present each month, and how were they defined?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which measures and how each was defined, in your own words; if you did not define them, or do not know how one was counted, say so plainly and stay with presenting them. Name the assumption behind a measure you would defend least, if you know one | F7; the quote carries no figure, so the probe is on definitions. EXP because it tests the claim |
| C2 | "What belongs in a post-event review besides retention?" | JD | [generic] | Start from what decision the review serves, then what you would want to see to make it. Say plainly where your own experience stops. The guidance makes no claim about your past | F3's requirement turned into a view on content; JD |
| C3 | "What is on the release checklist you wrote, and how do you know it works?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Start with the quote as written. Answer slot: say what is on it and who else shaped it, in your own words; if it has been revised since, say what prompted that; if it has not, or you do not know, say so plainly. QA still using it is the fact the quote carries | F4; EXP because the line has nothing inspected behind it |

### Bank D: Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here, and why live operations?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | Build a 90-second arc from those four sentences and nothing else: four years as an associate producer, the calendar, the checklist, the retention numbers. Why live operations and why Saltmarsh are yours to answer; the pack holds no research on the company, so do not recite any | The standard opener; F5 to F7 are the beats. EXP |
| D2 | "Tell me about a time a release didn't go the way you'd planned." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt, themed on the JD's release-checklist line. Pick an instance with a named stake, what you did and what changed afterward. If you use the checklist, stay at the quote's scope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4's requirement; EXP because it asks you to choose an instance |
| D3 | "Imagine the post-event review goes to people who weren't in the room. What do the first three lines say?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Lead with the outcome against the goal, then the one number that matters, then the next decision. Say where your own writing stops: the one written artifact in your material is the checklist, at its scope | F8, written communication; CASE because it is a live writing task |

### Bank E: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who's already run live events and worked with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; "Never led a team, and never worked on a game with in-app purchases." | Pause and restate. Hold on the calendar, at its scope. Concede specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups; do not fold the core claim to restore harmony, and do not describe what your sentences prove | F1 and F9 under time pressure; JD with Pressure delivery |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The hold is the quote: "Wrote the release checklist our QA team still uses." Answer slot: if QA or others contributed, say what they did and what you did; if you wrote it alone, say that. Be exact and unbothered | F4's attribution probe; EXP |

### Bank G: Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design wants to ship Friday, QA wants one more day, and community has already announced the date. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify what QA's day covers and what the announcement committed to, then options, who decides, and the communication each option needs. The checklist can be your shared reference, at the quote's scope; do not describe having made this call | F2 and F4; CASE with a Peer delivery |
| G2 | "When an update spans design, art, engineering and community, how do you handle credit and blame?" | JD | [generic] | Principles: name contributions specifically, treat a miss as a process question first. If a moment from your own work comes to mind where credit was shared, use it; if none does, say so plainly and say how you would handle it | F2's coordination duty; JD |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A2, A5, B2 |
| Coordinate design, art, engineering and community teams | A1, B4, G1, G2 |
| Own the post-event review and the KPIs it reports | A3, B3, C2 |
| Manage the release checklist with QA | C3, D2, E2, G1 |
| 3+ years producing live-service games or apps | B5, D1 |
| Experience running a content calendar | A2, B2 |
| Comfortable with player-retention metrics | A3, C1 |
| Clear written communication | D3 |
| Your stated gaps (F9), not a JD line | B1, B4, E1 |

No VAL or CO question appears: no values-style round is detected, and the research that would ground a CO question was refused.

## 6. Reverse questions

No interviewer profile exists, so none of these is tied to Tobias's own path.

| Question | Why it lands |
|---|---|
| "How do the two titles' calendars interact today? Do events ever compete for the same people or the same release window?" | Mirrors the JD's two-titles duty and shows you plan by constraint |
| "What does the post-event review look like right now, and which KPIs does it report?" | The JD makes you owner of both, so asking for the starting point is the right first question |
| "What would a strong first ninety days look like? I haven't worked on a game with in-app purchases, so I'd want to know where to learn first." | Names your stated gap on your own terms, which is the opposite of being caught on it |
| "Who do I work with most closely across design, art, engineering and community, and where do handoffs strain?" | Coordination is the job; asks for the real seams instead of assuming them |
| "How does QA sign off on a release today, and what would you change about the checklist?" | Connects your one inspectable artifact to the work you would inherit |
| "Tell me about an event you're proud of, and one you'd run differently." | Invites a story rather than a status answer, and signals interest in the craft |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for one title |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. B3's slot stays inside what you presented |
| Led or managed the design, art, engineering and community teams | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Has worked on in-app purchases or monetisation | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Managed each release with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist, and QA still uses it |
| Four years producing live-service games | Inflated form of F5 | F5's quotes at their own scope: an associate producer at a puzzle-game studio, and a weekly calendar for the main title. B5's slot asks how live the title was |

## 9. Sources

Provided documents: the JD text and the background you wrote in your message. No dossier was consumed.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was refused, so none returned anything:

- "Saltmarsh Games values mobile game studio" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games strategy news mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet if a values round were documented, and the themes of VAL questions. No section 10 and no VAL bank |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have confirmed the loop and refined persona weights. They rest on your own description and the hiring-manager prior |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded CO questions and a grounding brief. A4 stands in, labeled generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have produced an interviewer read and a reverse question tied to his path. Both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Whether Tobias would be your manager or a skip-level, and anything the recruiter said about focus areas or a deliverable → persona weights recomputed (Pressure up for a skip-level), and a build section for any announced deliverable
- Web research, approved or pasted: Saltmarsh's values page, careers page or a recent news piece → CO questions and a grounding brief, a confirmed loop, a values cheat sheet if a values round is documented. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add strategy and recent organisation context
- Tobias's public talks or writing → an interviewer read and a reverse question tied to his own path
- Your answers to the slots in F1, F2, F3, F5, F7 and F8 → those rows move from probe-and-slot to story-mapped guidance, and the affected bank cells are regenerated
- The release checklist itself, an export of the weekly calendar, or a monthly retention deck → F4, F6 and F7 can rise from medium once something is inspected
- A tuesday-dossier.md carrying verified evidence and a prohibited-claims list → a sharper highest-ROI objection and evidence-based limits on weak areas
