I'll read the reference files the skill points to before building the assessment.
**Yes, apply, with two checks first: `conditional_go`.** Your evidence meets the stated requirements R2, R3, R4, R5, R6, R7a and R8 on your own account. The conditions are that the remote-UK term (R1) is confirmed and the employer verifies as real (RR1), because web research was refused in this session.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7a, R8
- `important` — unclear: R7b (Recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R6 (`medium`) turns on whether you designed the tests or ran tests designed elsewhere.

**Opportunity ledger.** The responsibilities are concrete (RR3), but I could not confirm Brindlemoor exists as described (RR1), and the posting as pasted gives no salary (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed, meaning you are UK-based and can work fully remote; (2) the posting and employer verified live, per RR1; (3) the pet-insurance gap framed honestly as adjacent (R10), never as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, pet-insurance product | `[grounded]` JD header; existence and stage not established |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as you gave it; public footprint not researched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| People management | The JD lists no line management, so "never managed anyone" is not a stated gap | `[grounded]` JD silent on reports |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | An individual-contributor senior analyst post reporting into a pricing director, with 4+ years asked against your five | `[inferred]` from the JD's wording against your background |
| Market calibration | Not calibrated: the role-family sweep did not run, so there is no salary or scope band | `[generic]` none available |
| Unknowns | Salary, team size, whether pet data and tooling are mature, whether "UK" means residence or right to work | — |
| Contradictions | None within the pasted JD; no careers page to compare it against | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You stated no location or constraints; a UK motor insurer employer suggests UK-based but does not establish it | `[inferred]` from your UK employer | G3 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics", the last 2 as senior analyst. Self-reported with no document yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". "Strong" has no inspectable artifact behind it yet | `[grounded]` your background | offer: a sanitized script or notebook would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book". Motor, not pet, which R10 covers | `[grounded]` your background | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained is stated; monitoring as a distinct activity is not, so the lower reading is taken | `[grounded]` your background | confirm monitoring work if any (not asked, low impact) |
| R6 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests last year with the underwriting team". Design and reading are not separated from running | `[grounded]` your background | G1 question |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Tests run with underwriting and the quarterly review presented to the head of underwriting | `[grounded]` your background | none |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing stated about product teams. The JD names product beside underwriting | `[grounded]` your background silent on product | G2 question |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review presented to the head of underwriting | `[grounded]` your background | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance product knowledge | preferred | adjacent | medium | transferability | Not a stated requirement; included because you would own this product. GLM rating and price testing carry over. Limit: no pet data or pet rating factors exercised, and a different factor set would be new to you | `[inferred]` from the role scope; `[generic]` that pet and motor books rate on different factors | G4, bridge case |

R10's `requirement_source` is inferred from "pricing analytics for our pet-insurance product", not from a listed requirement.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Remote-UK term (R1, hard_gate) | hard_gate | Nothing states your location or work constraints | A gate the inputs do not settle stays open and could change the status | — | Nothing needed beyond your statement | `[grounded]` no constraints given |
| G1 | Test design ownership (R6, must_have) | discovery | "Ran 14 price tests" does not say who chose the test structure, the samples, or the read-out method | R6 is a must_have, and the JD names designing and reading tests | Choosing the control and test cells; setting sample size or run length; writing the read-out and the recommendation | A test plan, a read-out deck, or a results summary | `[grounded]` background wording; `[generic]` that roles like this probe design versus execution |
| G2 | Product-facing recommendations (R7b, important) | discovery | Underwriting audience evidenced; product audience not | Product is half of the JD's stated audience | Pricing changes agreed with a product or proposition team; a test result that changed a product feature | A recommendation paper or deck | `[grounded]` background silent on product |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor GLM and price testing carry over; no pet data | The likeliest interview objection, though preferred rather than required | Any non-motor book or product line; any vet-cost or animal-risk data work | A short note on how the motor GLM factors would map | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, or the posting may be stale. Medium rather than high because no off-domain contact or urgency pressure is visible | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not in the posting | unknown | — | (the JD as pasted gives no salary) | The figure may sit below what five years' pricing experience commands, or may be disclosed later in the process | `[inferred]` from the pasted text's silence | What is the salary range budgeted for this post? | unresolved |
| RR3 | Responsibilities are concrete and map to measurable work | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope appears defined; success is gradeable | `[grounded]` JD | What would a good first six months look like for this role? | noted |
| RR4 | Resources and authority unstated | unknown | — | "Own pricing analytics" | May own the analytics without a team, tooling budget or rate-filing authority | `[inferred]` from the JD's silence on team, tooling and decision rights | Who else is in pricing, and which pricing decisions does this role make itself? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Brindlemoor's own careers page for the live posting, and ask the recruiter for the role's source before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your own three facts, in your own terms: built and maintained the young-driver GLM rating model; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting. Say "ran", not "designed", until G1 is answered | see R4, R6, R7a, R8 | `[grounded]` your background, audited clause by clause against your sentences | pending your approval |
| A3 | State the pet gap plainly and offer the bridge: motor GLM and price testing, no pet data yet. Do not imply pet experience | see R10 | `[inferred]` bridge from your motor work | pending your approval |
| A4 | If asked about management, say you have not line-managed. The JD lists no reports | see Role reality | `[grounded]` JD silent on reports | pending your approval |
| A5 | Ask the verification questions of RR2 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

I have not seen your CV, so there are no CV edits to propose. The plan above is advice on what to say, and each block needs your approval before use.

## Evidence status

Verified: none yet. Your background is self-reported at CV standing. There are no memory leads.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was refused, so none ran. It would have settled whether Brindlemoor exists as described and whether the posting is live (RR1, Role reality's organization and contradictions rows) |
| 2. Role-family sweep | unavailable | Refused as above. It would have given the market calibration line and a salary band to set against RR2 |
| 3. Hiring manager's public footprint | unavailable | Refused as above. A name was given, so the query was formable. It would have informed the scope read and which verified story to lead with in A2 |

I did not retry the searches.

## Dossier offer

I can save all of this as `tuesday-dossier.md` if you want a file to keep or reuse.

## Upgrade menu

- Grant search permission and I'll run the three L1 targets, which would settle RR1, add a market band for RR2, and sharpen A2 for Odile Varga.
- Your CV would let me propose truthful edits and re-grade R3 and R5 against it.
- A sanitized script, notebook or test read-out would raise R3 or R6 toward `high`.
- Your answer on location closes R1 and the hard-gates line.
- A product-facing recommendation example would move R7b.

## Questions

G3 — Are you UK-based and able to work fully remote from the UK, and do you have any other hard constraints (salary floor, hours, travel) I should check this role against?

G1 — On your 14 price tests, what did you personally own: choosing the cells and sample size, running them, or reading out results?

G2 — Have you ever taken a pricing result to a product or proposition team rather than underwriting, and what did they do with it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.