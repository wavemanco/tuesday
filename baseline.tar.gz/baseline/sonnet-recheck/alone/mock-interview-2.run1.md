I'll read the reference files the skill points to before building the pack.
The pack is written and saved. I'm sending the closing message now.

Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-2-denied-96d141b3/1f5f2b10-d581-46af-8d95-58d908d2fa22/scratchpad/Atlas-Freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles, a fit table of the JD against your own words, the reverse questions, and a list of claims the pack won't coach.

- **Round assumption:** I didn't know who you're meeting or what kind of round it is, so the interviewer styles are weighted evenly. Two are weighted up because of the JD and your gaps.
- **Biggest objection:** A1 is the question to rehearse most: you're a senior shift manager over 3 supervisors, and this role leads 12 across 4 sites.
- **Other gaps:** Power BI is a stated gap with a plain answer ready (A2, E2). Terminal versus warehouse work and "5+ years of leadership" are also likely probes (A3, A5).
- **Strong points:** The pick-path result, the surge plan, and the green belt each have a question where you can hold your own words (C1, B2, D3).
- **No research on Atlas:** Web search was refused in this session, so the pack contains nothing about Atlas Freight itself. There are no values, no loop structure, and no strategy, and the questions that depend on them are marked generic. Read their site and recent news yourself before the interview.

Say the word and I'll play the Skeptic on A1 and follow up on what you actually say.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, and in what kind of round (your would-be manager, a peer, a recruiter screen), and did the recruiter mention any focus areas or something to prepare? The answer would reweight every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: unknown. Round type and relationship: unknown, so the persona weights below are flat priors with two shown tilts.

## How to use this pack

- Personas describe how a question is asked: who is across the table and in what style. Types describe what is being scored.
- Type key: VAL is behavioral or values alignment. EXP is a deep-dive into your experience. JD is a stated requirement of the role. CO is knowledge of the company and its strategy. CASE is a live problem from the role.
- Answer guidance is scaffolding, not a script. Every statement about your past in this pack is a sentence you wrote, quoted next to the claim. Where the pack does not know something, it says so and leaves an answer slot: an instruction for the interview, not a question for you now.
- Question IDs run A to E, then G and H. There is no bank F, so IDs never collide with the fit-snapshot rows F1 to F8.

## Prep triage

Sized to "next week"; no hours were stated. The few things worth doing well, in order:

1. A1 and A2, out loud, until they are boring. A1 is the highest-ROI prep in this pack (reason in the persona table).
2. C1 and C2: settle your own answers to the four slots a figure raises, before anyone asks.
3. B1 to B3: say one case structure aloud for each, clarifying first.
4. D1: a 90-second arc.
5. Read Atlas Freight's own website and recent news yourself. This pack could not research the company (see Sources).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material describes a shift and a site, and warehouse and distribution work; the JD says four sites and terminals. The words stay at that scope: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on what would carry across sites likely. Say, in your own words, which parts of your shift's work you'd expect to carry and which you wouldn't; if you can't say, say so plainly and name what you'd ask first |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The sentence states the plan and the two years; it does not show what the plan was measured on, and linking it to on-time performance is this pack's derivation. Answer slot: the JD's on-time line makes a probe on how the surge plan was judged likely. If it was judged on a measure, say which and what it showed, in your own words; if it wasn't, or you don't know, say so plainly and stay with the plan you ran |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [inferred] | transferability | The sentence is about mis-picks, not cost per shipment; your material does not show a cost measure, and the bridge does not stretch to one. The words: "I cut the mis-pick rate 40% by redesigning the pick path." The figure raises its own four slots, covered in C1 and C2: how it was counted, what it is sensitive to, the assumption you'd defend least, and which part was yours |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors; the JD says 12. The words: "I'm currently a senior shift manager over 3 supervisors." The step to twelve is rehearsed as a plan, never as a past (A1). Answer slot: the JD's twelve makes a probe on what changes with scale likely. Say, in your own words, what you'd expect to change and what you'd ask first; if you don't know, say so plainly and say how you'd find out |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" states a skill level, not what was made with it. Answer slot: the JD's reporting line makes a probe on what you've built likely. If you built reports other people used, say what they showed and who read them; if your Excel work was your own analysis, or not reporting, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | The sentence counts years in warehouse and distribution operations, not years leading; the JD asks for leadership years, and the pack reads your sentence at its lower reading. The words: "I have 7 years in warehouse and distribution ops." Answer slot: expect a probe on which of those years were spent supervising or managing. If you can say when that began, say so in your own words; if the early years were not leadership, say so plainly and count from when they were |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The sentence already reaches the requirement; say it in your own words: "I'm green belt certified." It doesn't say which body certified it, and nothing is inspected behind it, so expect a probe. Answer slot: if the certification has been used at work since, say where and how, in your own words; if it stood on its own, say so plainly |

## Persona table

No loop source established this loop, so the weights rest on the Generic archetype (screen, hiring manager, panel; flat weights) and no interviewer signals exist. Two tilts are shown: Skeptic is deepest because the most predictable objection lives there, and Case is next because the JD is a "drive and own" operating role (derived from the JD's own verbs, `[inferred]`).

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5 questions) | Quiet, persistent probing of scale, terminal versus warehouse work, and tools | High. F1, F4 and F6 are where this material is thinnest against the JD, and a skeptic goes where the material is thin. Highest-ROI prep: A1, the step from 3 supervisors to 12 | Rehearse A1 until it is boring: hold the quoted sentence, concede the scale step specifically, give the ramp as a plan |
| B. Case / Strategist (4) | Live operating problems: on-time slips, surge planning, cost, reporting | High. The JD is built from operating verbs (own, drive, build); a hiring manager would test them live | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober (3) | Reads your lines closely and asks how a number was counted | Medium. One headline figure is in your material (F3), and probers go straight at those | Know what you can and can't say about how it was counted; name your weakest assumption first |
| D. Conversational / Rapport (3) | Friendly opener, casual scored questions | Medium. Flat prior; any first conversation opens this way | Pre-script the 90-second arc; treat casual JD-topic questions as scored |
| E. Pressure (3) | Time-boxed, devil's advocate | Medium-low in this register, flat prior; the tool and scale gaps are natural pressure points | Pause, restate, hold the quoted position through two follow-ups, concede specifically |
| G. Peer Evaluator (2) | Seam-splitting between site and regional roles | Low to medium. Unknown whether a peer is in the loop; a site-based operations role makes it plausible | Propose seam principles instead of pretending to know the seam; offer what you bring them |
| H. Values / Behavioral (2) | Scenario prompts | Low. No values-style round is detected: no loop source was read and the Generic archetype reads no. Questions here use persona stems only | Selection scaffolds with an honest fallback branch |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors, and this role leads twelve across four sites. How do you see that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The deepest rehearsal in the pack. First say what is true, in your words: "I'm currently a senior shift manager over 3 supervisors." Then concede the scale specifically before they do: twelve is four times three, and across four sites. Follow-up 1, "What breaks first at twelve?": answer with your own judgment, labelled as judgment, not as something that happened. Follow-up 2, "Why not hire someone who has already done it?": hold the quoted sentence, concede that you'd be learning the scale, and give your first-month plan in your own words as a plan. Answer slot: say what you'd expect to change and what you'd ask first; if you don't know, say so plainly and say how you'd find out. Never claim more than the three | F4 is the pack's widest gap against the JD and the objection most likely to arrive in some form. JD because it scores the stated requirement; it sits in Skeptic because it is aimed at the gap |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick the weakest part honestly rather than a flattering one. The material gives you a plain answer: "I haven't used Power BI." Then, as a plan and not a past, how you would learn it and who you would ask. Concede it without apology and without padding. If asked what you do have, "solid Excel" is the sentence the material carries, at its scope | F6 is the one requirement where the gap is stated outright, so this stem has a ready, honest answer. JD because it scores a listed tool; Skeptic delivery |
| A3 | "Your background is warehouse and distribution, and this role runs freight terminals. What carries over and what doesn't?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the sentence: "I have 7 years in warehouse and distribution ops." Then structure the rest as judgment: the pieces of that work you'd expect to carry over, the pieces you'd expect to be different, and what you'd learn first, all said in your own words as expectations, not as things you've done. Answer slot: if you don't know how terminal work differs, say so plainly and say who you'd ask and what | F1 holds the terminal-versus-warehouse limit as the pack's observation. JD because the term is the JD's own |
| A4 | "Why this move, and why now?" | JD | [generic] | Pattern only, since the question needs no claim about your past: pick one true reason tied to the scope the JD describes (the sites, the on-time and cost responsibilities), one true reason about the company that you have verified yourself, and say what you want out of the next three years. Do not run down your current employer | The standard motivation probe Skeptics run on a candidate stepping up in scope. `[generic]` because it is a pattern for the problem, not a fact about Atlas |
| A5 | "The JD asks for five or more years of operations leadership. How many of your seven were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the sentence, then the number. Answer slot: if you can say when you started supervising or managing, say so, in your own words; if the early years were not leadership, say so plainly and count from when they were. A smaller true number beats a larger one you can't defend on the second question | F7 is a discovery row: the material doesn't show how many years were leadership. JD because it scores the stated minimum |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four sites has slipped for three weeks running. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: how on-time is defined and measured, versus what, since when, and whether the slip is real or a measurement change. Objective: restore it without breaking cost. Segment: by lane, shift, inbound versus outbound, and cause (labor, equipment, volume, upstream carriers). Approach: confirm the pattern, find the biggest segment, test one cause at a time. Metrics and risks last. Say the structure aloud; challenge one premise respectfully. Makes no claim about your past | F2's requirement as a live problem. CASE because it scores structure; `[generic]` because it is a pattern |
| B2 | "Peak season is coming and we need a surge plan for all four sites. What do you need to know first?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with the one sentence you can stand behind: "I ran the site's peak-season surge plan two years running." Then treat the question as new: the four sites are the question's premise, not yours. Clarify demand forecast, labor sources, site constraints, and what service level is non-negotiable; then structure. Answer slot: say which parts of the plan you ran you'd keep and why, in your own words; if you'd start from a blank page, say that | F1 and F2 both lean on the surge plan, so it is the natural bridge into the four-site problem. CASE because it is live |
| B3 | "Cost per shipment is above plan at the terminals. Where do you look first, and how will you know a fix worked?" | CASE | [generic] | Clarify what is in the numerator and denominator before touching causes: this is the weakest-assumption move for a metric you are about to own. Then segment (labor, handling touches, rework and damage, transport, utilization), pick the largest, name the trade-off with on-time performance, and say what result would convince you and what would not. Makes no claim about your past | F3 shows no cost measure in the material, so cost is rehearsed as a problem rather than a story. CASE; `[generic]` because it carries no fact about Atlas |
| B4 | "You have twelve supervisors across four sites and one reporting pack every Monday. What's on the first page?" | CASE | [grounded] "solid Excel", "never used Power BI" | Start from audience and decision: who reads it, what they decide. Then five or six measures with written definitions, trend against target, and exceptions. Build it in Excel first if asked what tool: "solid Excel" is the sentence you can stand on, and the dashboard tool is a plan, not a past (A2). Answer slot: if you have built a Monday-style pack, say who read it and what it changed; if you haven't, say so plainly and describe how you'd build one | F5 and F6 together: the reporting requirement as a design problem. CASE with JD content |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Beats the sentence states: the mis-pick rate, the 40% cut, the pick-path redesign. Tell them in your own words. Four slots a figure raises, each in your words: how it was counted; what it is sensitive to; the assumption you'd defend least, said before they ask; which part was yours. If you don't know how some part was counted, say so plainly. Never explain a method you can't repeat under a second question | F3 is the only quantified claim, the magnet for probers. EXP because it tests whether the number survives scrutiny |
| C2 | "How much of that was actually you, and how much was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence's own attribution: you describe it as your cut by your redesign. Answer slot: say who else was involved and what they did, and which part was yours, in your own words; if it was shared more than the sentence reads, say so plainly. Credit given exactly is a credibility gain | Pressure-register version of C1's attribution slot; the audit's attribution axis is where this figure is weakest. EXP |
| C3 | "What have you built in Excel that other people relied on?" | JD | [grounded] "solid Excel" | The sentence says a skill level, so start there and say what it is: "solid Excel". Answer slot: the JD's reporting line raises this probe. If you built a file or report other people used, say what it did and who used it; if you did not, or it was your own analysis only, say so plainly and stay with the skill | F5 is a discovery row; the question is premised on the JD's reporting requirement, so the second branch allows that nothing like this exists. JD |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | A 90-second arc with three beats: where you started (the 7 years in warehouse and distribution ops), where you are (senior shift manager over 3 supervisors), and why this role. Answer slot: name the steps between those two in your own words, only as many as you can speak to cleanly; if you'd rather skip the middle, say so and go straight to why this role | The biography question is scored in a casual register. F1 and F7 supply the only beats this material carries. EXP |
| D2 | "What do you know about Atlas Freight?" | CO | [generic] | The pack could not research Atlas, so it holds no facts about them and will not invent any. Before the interview, read their site and recent news yourself; arrive with two things you learned and one question that follows from them. Say where you learned them | CO is the homework check. `[generic]` because no research reached the pack; the upgrade menu says what research would add |
| D3 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Open with "I'm green belt certified." Answer slot: if you're applying it at work now, say where and how, in your own words; if it isn't in active use, say so plainly and say what you'd reach for first in this role | F8 is the JD's plus-skill, asked casually; casual questions about hot JD topics are still scored. JD |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run multiple sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running", "cut mis-pick rate 40% by redesigning the pick path", "green belt certified" | Pause, restate the question in a clause, then hold what is true in order: "I ran the site's peak-season surge plan two years running", "I cut the mis-pick rate 40% by redesigning the pick path", "I'm green belt certified." Concede the multi-site experience plainly and specifically, once. Hold through two follow-ups by returning to those three sentences, never by adding to them | F1, F2, F3 and F8 are what the candidate has to put against the scale gap, so this question needs the strongest hold the material carries. JD with Pressure delivery |
| E2 | "You've never used Power BI, and this role is built around reporting. Why should I take that risk?" | JD | [grounded] "never used Power BI", "solid Excel" | Concede first and plainly: "I haven't used Power BI." Hold: "solid Excel", at its scope, and that the tool is a plan. Follow-up 1, "Everyone says they'll learn it": answer with what you would do in your first weeks, in your own words, as a plan. Follow-up 2, "What if you can't?": say what you'd do about that too; do not fold on the core point | F6 plus F5, rehearsed under pressure. The negative in the Question has its source in the quote. JD |
| E3 | "Two minutes: what would you change about how you ran the surge plan?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Start with the sentence, then answer. Answer slot: if there is something you'd do differently, say what and why, in your own words; if not, say so plainly and stay with the plan you ran. Don't invent an incident to look reflective | F2 and F1's surge-plan sentence, pressure-tested. The question presupposes no failure. EXP |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side. Where's the seam between a site's own supervisors and a regional operations manager, and what happens when we disagree?" | JD | [generic] | Don't pretend to know the seam; propose principles instead: who decides what, what gets escalated and when, which numbers everyone agrees on first. Offer reciprocity: what you'd bring the site, and what you'd need from them. Say how you'd want a disagreement surfaced. Makes no claim about your past | The persona stem applied to F1 and F4's multi-site, multi-supervisor structure. JD because it scores how the role works with sites |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a time work spanned teams and credit mattered: it needs a named piece of work, who else was involved, and what you did about credit. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stock peer probe on attribution honesty. EXP; `[generic]` because no sentence carries a story for it |

### H. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time with a named stake, a message that was hard to hear, and an intact relationship afterward. Use "we" for context and "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem; no company values were read, so it tests generic virtue rather than published values. VAL |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose a time where the metric and the customer pulled apart, you picked, and you can say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. In freight, pick a customer you can name in general terms | The persona stem, fitting a logistics role. VAL; `[generic]` for the same reason |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, B2, G1 |
| "drive on-time performance" | B1, B2, E3 |
| "cost-per-shipment down" | B3 |
| "lead a team of 12 supervisors" | A1, B4, G1 |
| "build reporting in Excel/Power BI" | A2, B4, C3, E2 |
| "5+ years operations leadership required" | A5, D1 |
| "Lean/Six Sigma a plus" | D3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does Atlas measure on-time performance today, and which of the four sites is furthest from where you want it?" | Shows you treat on-time as something you will own, and asks for the definition before you inherit the number |
| R2 | "What's included in cost per shipment here, and who owns each component?" | The clarify-first move from B3, turned into a question about the company |
| R3 | "What does reporting for the supervisors look like today: what's built, and in what tool?" | Lets you size the reporting ramp honestly and signals you are planning for it |
| R4 | "How are the twelve supervisors spread across the four sites and shifts, and where is the leadership bench strongest?" | Treats the scale step as something to plan with them, not something to defend |
| R5 | "What would success look like at 90 days and at a year?" | Gives you the interviewer's own yardstick to work to |
| R6 | "What could a new operations manager do in their first month that would genuinely help your team?" | The reciprocity question: it turns the interviewer from judge into a colleague, and it is useful whoever turns out to be across the table |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran multi-site or freight-terminal operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift and a site, warehouse and distribution. A3's slot stays on what you'd expect to carry over |
| Led twelve supervisors or a multi-site team | Inflated form of F4 | F4's quote at its own scope: 3 supervisors. A1's slot asks only what you'd expect to change |
| Improved on-time performance | Inflated form of F2 | F2's quote at its own scope: the surge plan and the two years. The slot asks only what the plan was measured on |
| Reduced cost per shipment | Inflated form of F3 | F3's quote at its own scope: the mis-pick rate. C1's slots ask only how the figure was counted |
| Built Excel reporting or dashboards for management | Inflated form of F5 | "solid Excel" at its own scope. C3's slot asks what, if anything, you built that others used |
| Has used Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't used Power BI." No slot |
| Has 7 years of operations leadership | Inflated form of F7 | F7's quote at its own scope: years in warehouse and distribution ops. A5's slot asks how many were spent supervising or managing |
| Led Lean or Six Sigma projects with measured savings | Inflated form of F8 | "green belt certified" at its own scope. D3's slot asks only whether it is in use |

## Sources

Provided: the job description pasted in your message; your background, as written in your message.

Searches sent (all three were refused because web search was not permitted in this session; nothing came back and nothing is used from them):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Fetches sent: none.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Every call was refused. Would have moved the values cheat sheet (section dropped; no values page is in hand) and VAL questions H1 and H2, which stay on persona stems |
| 2. Atlas Freight interview process, operations manager | unavailable | Every call was refused. Would have moved persona weights and the loop structure; the pack uses the Generic archetype and says so |
| 3. Atlas Freight strategy and recent news | unavailable | Every call was refused. Would have moved CO and CASE questions grounded in current strategy; D2 and B1 to B3 are `[generic]` |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

No tuesday-dossier.md was present. Sections dropped because their condition failed: graded deliverables (none announced), grounding brief (no strategy research), reading the interviewer (no interviewer information), values cheat sheet (no values-style round detected and no values in hand), delivery coaching (no assessment).

## Upgrade menu

- The interviewer's name, title and relationship to the role → an interviewer read, persona weights read from their public footprint instead of flat priors, and a reverse question tied to their own path
- The recruiter's prep email, or any focus areas or exercise they mentioned → coverage of a pre-declared deliverable and a reweighted bank; usually one email to the recruiter
- Atlas Freight's careers or values page pasted, or permission for web research → a values cheat sheet if a values round is documented, and D2, B1 to B3 and H1 to H2 become grounded in what Atlas actually says
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief behind the CO and CASE questions, and role-family loop reports
- Your answers to the slots, in your own words (what the surge plan was measured on, how many of the 7 years were spent leading people, what you have built in Excel, how the 40% was counted) → F2, F5, F7 and C1 move from discovery or low confidence toward grounded
- The green belt certificate, with its issuing body and level → F8 from medium toward high; a before-and-after pick-path report or the sheet behind the 40% → F3 and C1 from medium toward high
- A tuesday-dossier.md from job-underwriter → verified evidence, per-gap strategy limits and the objection worth the deepest rehearsal read from evidence rather than inferred
