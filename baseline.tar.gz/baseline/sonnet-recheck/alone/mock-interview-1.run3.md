Searches were refused here, so this pack rests on your note and the JD and profile text you pasted. I'm writing it now.
Priya's prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-1-denied-05a30074/fd920725-55b9-44dc-a997-ce48e96edb27/scratchpad/northwind_data_senior-gtm-strategy-lead_interview_pack.md`. I built it for one 60-minute peer conversation with Dan, with no pre-declared deliverable.

The pack has 23 questions in seven persona banks, each tagged by type with answer guidance, a provenance cell and a rationale. It also has a fit snapshot, interviewer read, persona table, requirement-coverage table, reverse questions and a prohibited-claims list.

- **Web research:** both searches (Northwind's values, Dan's public footprint) were refused, so none of it ran. Everything rests on your pasted note and profile, and the pack's Sources section says so.
- **Highest-ROI prep:** D1, the "no classic sales-ops or quota-setting" objection. It's Priya's stated gap, and it sits in Dan's own function.
- **Persona weights:** the Data-Driven Prober and the Peer Evaluator rank highest. Dan's "relentlessly data-driven" self-description and the peer relationship drive that.
- **Evidence quotes:** these come from your description of Priya, not her CV. The JD requirements are your highlights, not the full text.
- **Coaching limits:** the guidance only claims what those quotes say. Where an interviewer would probe past them (partner-motion design, the ~$400M figure, GTM ownership), it gives answer slots with an honest "that wasn't mine" branch.

Say the word and I'll play Dan as the Prober on A1 or as the Skeptic on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

1. Did the recruiter name any focus areas or a deliverable (a case, a presentation) for the Dan conversation?
2. Can you paste the full JD text or Priya's CV lines? I'll proceed without them if not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Round:** one 60-minute conversation.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

Question IDs are letters by persona: A Prober, B Peer Evaluator, C Case/Strategist, D Skeptic, E Conversational, G Pressure, H Values. F is skipped because F1 to F7 are fit-snapshot rows.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company's strategy, competition and recent moves |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI prep in this pack is **D1**, the quota and sales-ops objection. Dan owns that function, so it will arrive in some form.

## Fit snapshot

The requirements below come from the JD highlights in your message, not from the full JD text. The highlights state no hard gate (a location, travel, pay or credential term). Evidence is quoted from your message describing Priya, not from her CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops at a consumer-tech company, not owning a GTM strategy. The words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-lines line makes a probe likely on whether any of that work took an offering to market. If any did, say which and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | A headline figure with nothing inspected behind it, and adjacent to the lifecycle requirement rather than reaching it. The words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours; "I do not know how it was counted" is an honest branch. Answer slot: the JD's whitespace line makes a probe likely on whether the work found where growth was not yet captured. If it did, say how, in your own words; if it did not, or it was not yours, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap in terms, but a skill line with nothing inspected behind it, so expect a "show me" probe. Lead with the quote's own terms, then choose one analysis you can walk end to end (A3) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not a partner motion, and the word "required" makes this the row Dan is most likely to press. The words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you can say how the negotiations used the model, say so in your own words; if you cannot, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Expect "how did you get the consensus" (B2); a named record beats an adjective, so lead with the sentence |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | none | Derived from a usage statement with no tools or uses named; extending it to a product launch like Compass is the pack's derivation, not your history. The words stay at usage: "I use AI tools daily." Answer slot: name the tools and one concrete use if you can; if your experience is using rather than building, say so plainly |
| F7 | Sales-ops and quota mechanics, the working language of the peer's function (not a JD line; the pack's reading) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap the material states and wording cannot close. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Reading the interviewer

Everything here comes from the profile text in your message. Public footprint beyond it was not researched, because the search was refused.

| Signal | Provenance | What it means for the conversation |
|---|---|---|
| Self-describes as "relentlessly data-driven" | [grounded] your message | Every number you give gets probed to its inputs and assumptions. Prepare the defend-the-number answers (A1, G2) first |
| Career spine in pricing and monetization roles | [grounded] your message | Case questions will likely lean to pricing, packaging and unit economics (C4). Say your hypothesis early and concede where his pricing depth exceeds yours |
| One early-stage-startup chapter | [grounded] your message | Expect probes on pace and thin data (D3). The material gives you no startup story, so none is offered |
| Director of Sales Strategy, a peer under the same VP | [grounded] your message | He sits on the seam with this role and likely owns quota-side mechanics (B1, B2). Reciprocity framing fits better than audition framing |
| Shared vocabulary: revenue and monetization | [inferred] his path as a pricing and monetization career, set against F4's quote | Pair his path with your own words exactly: "built a partner-level revenue model used in carrier negotiations". Use it as a bridge to his language, not as proof of his experience |

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A) | Reads claims line by line; asks how the ~$400M figure was counted and for one analysis end to end | High. Peer prior is Peer Evaluator plus Prober, and his self-description raises the Prober further | Know what you can and cannot say about how each figure was counted, and say plainly where you do not know; name the weakest assumption first (F2, F3) |
| Peer Evaluator (B) | Seam-splitting between Sales Strategy and GTM, what you need from him, credit across teams | High. Peer prior, and the role sits beside his function | Reciprocity framing; propose seam principles without pretending to know the seam; spine and tact together (F5, F7) |
| Case/Strategist (C) | Live problems on Compass, the bundling threat and pricing | Medium. A peer is not the hiring manager, but his pricing spine and your research note make the cases native to him | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud; challenge one premise respectfully |
| Skeptic (D) | Quiet probing of the quota, partner-motion and B2B gaps | Medium. The gaps are real (F4, F7) and he owns the adjacent function | Rehearse D1 until it is boring; hold what the quotes carry; concede the rest specifically |
| Conversational (E) | The "walk me through the journey" opener and a casual AI question | Medium. In a single 60-minute conversation the opener is near certain, and the AI plus is asked casually | A 90-second arc built on F1's sentence; treat casual AI chat as scored (F6) |
| Pressure (G) | Time-boxed "why you" and "how much was actually you" | Low. Peers seldom stress-test, but both stems can arrive collegially | Pause, restate, hold a position the quotes carry through two follow-ups, concede specifically |
| Values/Behavioral (H) | A behavioral story or two | Low. No values-style round is documented: your note describes one conversation with a peer, and Northwind's published values were not retrieved | Pick stories from the scaffolds; "we" for context, "I" for contribution |

## Question banks

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | State the sentence at its own scope: you proposed a store-surface change credited with a ~$400M ARR uplift. Answer slot: how the figure was counted; if you know, say so in your own words, and if you do not know how it was counted, say so plainly. Answer slot: what the figure is most sensitive to, and the one assumption behind it you would defend least; name it before Dan does, or say you cannot name one. Answer slot: which part of the result was yours; if the credit was shared or assigned by others, say so plainly. Never supply a method you cannot repeat under a second question | F2 is the CV's headline metric and the likeliest place a data-driven peer starts. EXP because it tests whether the number survives and what was yours |
| A2 | "Tell me about the partner-level revenue model you built for the carrier negotiations. What was it for?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe it at the quote's scope: a partner-level revenue model, used in carrier negotiations. Answer slot: if you can say what question it answered in those negotiations and who used it, say so in your own words; if you do not know how it was used beyond that sentence, say so plainly and return to the model you built. Offer to walk it end to end only if you can | F4 is the one partner artifact in the material, and Dan's pricing spine makes a revenue model his native ground. EXP because it checks the claim, not the requirement |
| A3 | "Show me an analysis you did yourself, end to end, in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt, so pick one: say the quote's terms, then the question the analysis answered, what you pulled or built, what you concluded and what you would do differently. Selection criteria: it must be one you can defend to the level of the query or the view, and one where the conclusion changed a decision you can name. If no single example comes to mind, say so plainly, then give the nearest thing your material carries, which is that you are skilled in SQL and Tableau, or say how you would approach it | The JD requires independent SQL and Tableau work (F3), and a self-described data-driven interviewer asks for the artifact. JD because it scores a stated requirement; the Prober delivery is why it ranks here |
| A4 | "A dashboard from another team says renewals are up 12 percent. How do you decide whether to trust it?" | CASE | [generic] | Structure it aloud: the metric's definition and cohort; where the data comes from and how it is refreshed; reconcile to a second source; check mix and timing effects; say how confident you are and what would change your mind. The question needs no claim about your past, so the guidance makes none | Tests data hygiene in the register Dan will use. CASE because it is a live reasoning problem; `[generic]` because it is a pattern, not a fact about Northwind |
| A5 | "You get one metric to hold a new product line to in its first year. Which one, and what would make it lie?" | CASE | [generic] | Pick one, justify it against the lifecycle stage, then name two ways it can mislead (a definition shift, a mix effect) and the companion measure that exposes each. Say the structure aloud before the answer. Concede what you would need to learn about Northwind's data first | Probers ask for the failure mode of a metric as well as the metric. CASE because it is a live problem; links to profitability only through the research note, so the guidance stays generic |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between Sales Strategy and GTM for the new lines, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: decision rights by question (who owns segmentation, who owns targets, who owns partner terms), a named tiebreak path, and a shared metric. Say you expect him to own quota mechanics. Concede you do not yet know how Northwind draws the line, and say how you would find out | Peer prior; the seam is the peer's core worry. JD because it scores the responsibilities of the role; `[generic]` because no Northwind seam facts were established |
| B2 | "You set annual volume targets with cross-org consensus. How did you get the consensus?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; [grounded] "No classic sales-ops or quota-setting experience." | State the sentence at its own scope. Answer slot: the JD's cross-functional line makes a probe on how agreement was reached likely. If you can say where the groups differed and how it resolved, say so in your own words; if there was no real disagreement, or it was not yours to resolve, say so plainly and return to the sentence. Do not call these quotas: the plain statement is "I haven't had classic sales-ops or quota-setting experience" | F5 is the cross-functional evidence and F7 is the limit beside it; Dan will test the line between targets and quotas. EXP because it checks what was actually the candidate's |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Principle first: "we" for context, "I" for contribution, and name the other teams in your answers before you are asked. Answer slot: which part of the ~$400M result was yours and which part belonged to others; if you cannot separate them, say so plainly | A persona stem for peers, and F2 is the figure most exposed to a credit probe. VAL because it scores a collaboration value; the EXP link is the reason the quote sits here |
| B4 | "What would you need from me in your first ninety days, and what could you give my team?" | JD | [generic] | Reciprocity framing: ask for his view of how targets are allocated and where the new lines' sellers feel friction; offer analysis in SQL and Tableau and revenue modeling, in the quote's terms: "skilled in SQL/Tableau" and "built a partner-level revenue model". The offer is a plan, not a past | Peers price what the hire costs and contributes to their work. JD because it scores how you would do the role beside him |
| B5 | "Product wants more seller attention for Compass; I want focus on enterprise expansion. Where do you land?" | CASE | [grounded] | Clarify what the quota and capacity facts are, state a position, then name the concession you would make to Dan and the evidence that would change your mind. Hold the position through one push, concede explicitly on the part he owns | Combines two of your note's priorities into a seam disagreement. CASE because it is a live problem with a pressure edge; grounded in your research note |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass launches inside an enterprise-expansion push. Sketch the GTM plan. What do you need to know first?" | CASE | [grounded] | Clarify before structuring: which of the two new lines Compass is, who the first buyers are, and what profitability means for the plan. Then objective, segmentation across land, adopt, expand and renew, approach, metrics, risks. Challenge one premise respectfully, for example whether Compass should lead with expansion or with new logos | Direct use of your note's priorities (enterprise expansion, the Compass launch, profitability). CASE with JD content because the role owns GTM for new lines |
| C2 | "A much larger platform vendor bundles a competing product at no extra cost. How does that change your land and expand motion?" | CO | [grounded] | State the hypothesis early: a bundle wins on convenience and loses where standalone depth matters. Then which segments you would defend, which you would not contest, and what a partner angle could add. Concede that you do not know Northwind's win and loss data, and say what you would pull first | Your note names bundling as the main competitive threat. CO because it tests altitude on the company's actual strategy; CASE is the delivery |
| C3 | "Size the whitespace for a new line across land, adopt, expand and renew. Where do you look first?" | JD | [grounded] "skilled in SQL/Tableau" | Start from the installed base: which accounts are in each stage, then where the new line has not been offered. Say that you would run the first cut yourself in SQL and Tableau, in the quote's terms. Name the two cuts you would make and the single number you would show first. State the assumptions aloud | The JD's whitespace line (F2) as a live problem with F3 as the tool. JD because it scores a stated requirement; CASE is the delivery |
| C4 | "Would you price a copilot like Compass as an add-on, include it in a bundle, or charge by usage?" | CASE | [grounded] | Ask what the current price architecture and buyer are before answering. Then state a hypothesis with its trade-off against the bundling threat and the profitability goal. Concede early that pricing is his native ground and ask which constraint you may be missing | His pricing and monetization spine, with Compass and the profitability priority from your note. CASE because it is a live problem; the Prober register shows in the demand for a stated hypothesis |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; [grounded] "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal in the pack.** First answer, after a pause: "I haven't had classic sales-ops or quota-setting experience." Then the sentence you can stand on, kept at its own scope: "I set annual volume targets with cross-org consensus." Then the plan, said as a plan: you would rely on Sales Strategy for quota mechanics and learn how targets are allocated before proposing anything that touches them. Follow-up one, "so you learn on my team's time": hold, and say what you would bring to the seam in the meantime, in the quotes' terms ("skilled in SQL/Tableau"). Follow-up two, "what would you design first anyway": hold at the lifecycle whitespace analysis, and concede explicitly that quota-linked decisions wait on his input. Never say your target-setting was quota-setting, and never soften the first sentence | F7 is the candidate's own stated gap and sits in the peer's own function, so this objection arrives in some form. JD because it scores the role's seam; Skeptic because it probes the gap, not a number |
| D2 | "The JD says partner-motion design experience is required. Where have you designed a partner motion?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you can say how the negotiations used the model, say so in your own words; if you cannot, or it was not yours, say so plainly and stay with the model. The pack's own reading is that the material says a model and not a motion, so let him ask the next question rather than widening the answer. Then a plan: how you would learn Northwind's partner structure in the first weeks | F4 is the row where "required" invites a literal screen. JD because it scores the stated requirement; Skeptic delivery because the premise comes from the JD and not from the quote |
| D3 | "You have spent nine years inside a large company. How do you work when there is no playbook and the data is thin?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Open prompt on pace and thin data, aimed at his startup chapter. Selection criteria: pick a time you had to decide before the data was there, with a named stake, what you used instead, and how you checked afterward. If no such time comes to mind, say so plainly, then give how you would handle it: a hypothesis, the smallest test, and the threshold that would change the decision | His one early-stage chapter makes a pace probe likely, and F1 is the big-company evidence. EXP because it asks for a past instance; the scaffold applies because no quote carries one |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc using the sentence's own beats: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Answer slot: why this role and why now; give your own reason, in your own words, and no one else's. End on the part of the role you want to own, then stop | In a 60-minute single conversation this opener is close to certain, and it is scored even in a casual register. EXP because it tests whether the biography is told economically and matches the CV |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Say it at its own scope: "I use AI tools daily." Answer slot: name the tools and one concrete recent use; if what you do is use them rather than build them, say so plainly. Then a view on Compass as a product launch, framed as a question you would ask, not as experience | The JD lists AI experience as a plus (F6), and rapport interviewers ask hot topics casually. `[inferred]` because the link to Compass is the pack's derivation |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has carried a quota?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; [grounded] "No classic sales-ops or quota-setting experience." | Pause, restate the question, then hold: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus" are what you offer. Concede specifically: "I haven't had classic sales-ops or quota-setting experience." Hold through two follow-ups by returning to those sentences, never by claiming to be better | A time-boxed form of the D1 objection in a different register. JD because it scores fit to the role; Pressure delivery because it tests composure |
| G2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: which part was yours; if others built or measured it, say so plainly. Do not move the number up or down under pressure. Concede uncertainty specifically, for example the one assumption you would defend least, and hold the core sentence through two follow-ups | The persona's own stem, aimed at F2, the figure most exposed to an attribution probe. EXP because it checks the claim; the hold-then-concede structure is the rehearsal |

### H. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No quote carries this story, so this is a selection scaffold. Pick a time where the stake was named, the truth was specific, you did not fold, and the relationship was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem with no values-style round documented, so low weight. VAL because it scores a behavior; the scaffold applies because no sentence of the material carries it |
| H2 | "Tell me about a time you got a group with competing interests to agree." | VAL | [grounded] "set annual volume targets with cross-org consensus" | Story map on the quote: annual volume targets, set with cross-org consensus; those are the beats it states, told in your own words. Answer slot: the JD's cross-functional line makes a probe on where the interests differed likely. If they differed, say how and which part was yours; if they did not, or it was not yours, say so plainly and stay with the sentence | F5 is the one consensus story the material carries. VAL because it asks for a behavior; the overlap with B2 is deliberate, since a peer probes the same story twice |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, C4, D3, E1 |
| "identify whitespace across land/adopt/expand/renew" | C3, A1 |
| "run independent analysis in SQL and Tableau" | A3, A4, C3 |
| "partner-motion design experience required" | D2, A2 |
| "strong cross-functional influence" | B1, B2, B5, H2 |
| "AI experience a plus" | E2, C4 |

## Grounding brief

Taken from your research note only; nothing here was independently checked.

| Item | Provenance | What to do with it |
|---|---|---|
| Three stated priorities: enterprise expansion, an AI copilot launch ("Compass"), reaching profitability | [grounded] your message | Use the three as the vocabulary for C1, C4 and B5 |
| Main competitive threat: bundling by a much larger platform vendor | [grounded] your message | Use it in C2; do not assert facts about the vendor |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You have spent much of your career in pricing and monetization. How do you see packaging decisions for new lines: where does Sales Strategy want a vote, and where would you hand it to GTM?" | Ties to his own path and turns the seam into a peer conversation | [grounded] your message, career spine |
| R2 | "What could a new person in this role do in their first month that would genuinely help your team?" | Reciprocity question for a peer; shows you are pricing what you add to his work | [generic] |
| R3 | "You also spent time at an early-stage startup. What did it change about how you build a number?" | Invites the story behind his one non-pricing chapter and signals you read his path, not only the company | [grounded] your message, startup chapter |
| R4 | "Which metric do you trust most, and which least, in how land, adopt, expand and renew are tracked today?" | A data-driven peer answers this with substance, and it previews what the analysis work will start from | [inferred] from the JD's lifecycle line and his self-description |
| R5 | "Where does the bundling threat show up first in what you see, and how are the two new lines prioritized against profitability?" | Shows you read the priorities and asks for his view rather than reciting your own | [grounded] your message, research note |
| R6 | "In six months, what would make you say this hire was the right call?" | Sets the success bar with the person who will work beside you | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience, including calling the annual volume targets "quotas" | Negative you stated, F7, and F5's quote is about volume targets | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Designed partner motions or owned partner go-to-market | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation, not words for you: the material says a revenue model used in negotiations, not a partner motion. D2's slot stays inside the model |
| Owned GTM strategy for product lines or took offerings to market | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not GTM ownership. The slot in F1 asks only what that work covered |
| Drove or owned the whole ~$400M ARR uplift | Inflated form of F2, whose quote says "credited with" | F2's quote at its own scope, with the defend-the-number slots in A1 and G2 |
| Built AI products or AI features | Inflated form of F6, whose quote says "uses AI tools daily" | F6's quote at its own scope, and the slot in E2 |

## Sources

Provided documents: your message, with the JD highlights, the candidate summary, the interviewer profile text and your research note. No dossier was present.

Searches sent, both refused, so nothing came back:

- "Northwind Data company values principles" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Search refused. It would have given published value names for VAL themes. No values-style round is detected, so no cheat sheet was due either way |
| 2. Interview process for this role family | skipped | Your own words establish the loop: one 60-minute conversation with a peer. Persona weights follow that |
| 3. Strategy and recent news | skipped | Your research note already supplies the three priorities and the bundling threat the CO and CASE questions use |
| 4. Interviewer public footprint | unavailable | Search refused. It would have added talks or writing to the interviewer read and a tailored reverse question |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six requirement quotes become exact JD lines, any hard gate (location, travel, pay) gets checked, and the coverage table is rechecked
- Priya's CV text → the evidence column quotes her CV rather than your summary of it, and F1 to F6 can be regraded
- A walkthrough of the revenue model, or the internal write-up that credits the ~$400M uplift → F2 and F4 can move from medium toward high, since those are the inspectable artifacts for this domain
- Her answers to the slots in F1, F2, F4 and F6, given outside a drill → those rows and the questions that draw on them are regenerated with her words
- The recruiter's focus areas or any pre-declared deliverable → a build section, and persona weights reread against what the round is meant to cover
- Dan's public talks or writing (the search was refused; pasted text works) → a fuller interviewer read and a tailored reverse question
- Northwind's published values page, pasted → VAL themes in H1 and H2 grounded in the company's own names, and a values cheat sheet only if a values-style round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; it needs search permission, which was refused here) → a fuller grounding brief on the Compass, bundling and profitability priorities
- A tuesday-dossier.md from job-underwriter → verified evidence and a prohibited-claims list in place of the locally built one, and the D1 objection evidence-derived rather than inferred
