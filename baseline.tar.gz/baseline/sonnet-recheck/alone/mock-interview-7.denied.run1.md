I'll read the reference files before building the pack.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-denied-76d9f8e3/0a97501a-feef-4452-92cd-ef2b1c05fbcf/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`.

It has 22 questions across seven interviewer styles, a fit table, a prep schedule for Friday, six reverse questions and a list of claims it won't coach.

- **Assumption:** I built it for a hiring-manager-level round, because Tobias heads the function the role sits in. Your note didn't say how he relates to the role.
- **Research:** my four web searches (Saltmarsh's values, interview process and strategy, plus Tobias) were all refused, so none ran. The pack holds nothing about Saltmarsh or Tobias beyond what you gave me. It has no values section or interviewer read, and the company-knowledge questions are generic. The Sources section records this.
- **Most likely hard question (B1):** "You haven't led a team and you haven't worked on a game with in-app purchases. Why should I trust you with two live titles?" It has the deepest rehearsal: concede both gaps plainly, then hold only what you wrote about the calendar, the release checklist and the retention numbers. The thinnest parts of your background are events versus content drops, running two titles instead of one, and coordinating four disciplines.

Say the word and I'll play Tobias as the Skeptic on B1, with follow-ups that react to what you say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, a skip-level or a peer? And did the recruiter say anything about focus areas or an exercise to prepare? Either answer would reweight the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Length:** 60 minutes, Friday.
**Round and relationship:** not confirmed. This pack assumes a hiring-manager-level conversation, because the interviewer is the head of the function the role sits in. If that is wrong, the persona weights in section 8 change.
**Research:** none of the company or interviewer searches returned anything (see Sources). Everything about Saltmarsh and Tobias is therefore absent, not guessed.

## 2. How to use this pack

- **Personas** describe how a question is asked (a quiet skeptic, a live case, a friendly chat). **Types** describe what it is scoring. Rehearse both: the same content arrives in different delivery.
- Type key: **VAL** values and behavior, **EXP** work-experience deep-dive, **JD** role and JD requirements, **CO** company and industry knowledge, **CASE** a live problem from the role.
- Provenance labels: `[grounded]` traces to the JD or to your own words, `[inferred]` is a derivation from something adjacent, `[generic]` is a role-family pattern with no claim about you or Saltmarsh.
- Guidance is scaffolding, not a script. Every sentence about your past is one you wrote, quoted in the Provenance column. An answer slot is an instruction for the interview, not a question for now.

## 3. Prep triage (interview Friday)

1. **B1**, out loud, at least three times with someone pushing the two follow-ups. It is the highest-ROI prep in this pack.
2. **D1**, the 90-second journey, built from four of your own sentences.
3. **A1, A2 and A3**, said aloud as live cases: clarify, structure, then answer.
4. **C1 and C3**, the retention questions, including saying plainly what you do not know about how the numbers were counted.
5. **Reverse questions** (section 11): pick three and write them down.

Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message, "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives four years and the title associate producer, and does not say whether the puzzle title ran as a live service. Words: those two sentences at their own scope. Answer slot: the JD says live-service, so expect a probe on that. If the title ran as a live service, say how in your own words; if it did not, say so plainly and stay with the weekly calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | Your strongest row, but a message line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, content drops, your main title, two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a content-drop calendar for one title, not events and not two titles, and the words stay there. Answer slot: the JD says events across two titles, so expect a probe on both. If any of your drops were events as the JD means them, say which and what you planned, in your own words; if they were content releases and not events, say so plainly and stay with the weekly calendar for your main title |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | discovery | Your stated limit is leading a team. The JD says coordinate, and your material neither shows nor denies coordination. Answer slot: if you worked with any of design, art, engineering or community on a drop, say which and what you needed from them, in your own words; if you did not, or your work with them was not on the drops, say so plainly. Words you may use for the stated limit: "I haven't led a team." |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the monthly retention numbers, not that you reviewed events or defined the KPIs, and the words stay at presenting. Answer slot: the JD says post-event review and KPIs it reports, so expect a probe on both. If you took part in reviewing a release afterward, say what the review looked at, in your own words; if reviews were not part of your work, or you did not choose the numbers, say so plainly and stay with presenting the monthly retention numbers |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | The quote already reaches the requirement: you wrote it, and QA still uses it. It says wrote, not that you ran each release, so keep the verb. Expect a probe on the checklist itself, covered in D2 |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement: you presented retention numbers monthly to the studio head. No figure is in your material, so a prober will ask how the numbers were counted. C1 rehearses that, including not knowing |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The one written artifact your material names is the checklist, and the bridge is only that sentence: a document another team still uses. Nothing is added about how it reads |
| F9 | Familiarity with in-app-purchase monetization on mobile titles (role-family expectation, not in the JD) | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## 8. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems from the role: plan the calendar, resolve a clash, diagnose a retention drop | High. Hiring-manager prior is Case plus Skeptic, and the JD is a planning-and-coordination job. 5 questions | Clarify, objective, segmentation, approach, metrics, risks. Think aloud; challenge one premise respectfully per case |
| Skeptic (B) | Quiet probing of the distance between one-title content drops and two-title live events, and your stated limits | High. Same prior; F3, F4 and F9 are the thin rows. 5 questions | Rehearse B1 until it is boring. Build only from sentences you wrote, state the limit plainly, then give a plan |
| Data-Driven Prober (C) | How the retention numbers were counted, what is yours in them | Medium. The JD names retention metrics and KPI ownership; nothing is known of Tobias's style. 3 questions | Say what you know about how the numbers were counted and say plainly what you do not; name the assumption you would defend least, if you know one |
| Conversational (D) | Opening chat, the journey question, what you play | Medium. Any 60-minute conversation opens this way, and these answers are still scored. 3 questions | A 90-second arc built from your own sentences; treat casual questions on live-ops topics as scored |
| Pressure (E) | Interrupting, time-boxing, probing how much was you | Low. No signal that this loop is stress-style. 2 questions | Pause, restate, hold the claim you can back through two follow-ups, concede specifically |
| Values / Behavioral (G) | Scenario stories | Low. No values-style round is established for this loop and no published values were available. 2 questions | Selection scaffolds with an honest branch; we for context, I for your contribution |
| Peer Evaluator (H) | Seam-splitting between live ops and design or art | Low. Tobias is assumed to be the hiring manager, but a team member may join. 2 questions | Offer seam principles, not a pretended seam; reciprocity framing |

The loop is unknown, so no values-style round is assumed and no values cheat sheet is included. Letter F is skipped in the banks so question IDs do not collide with fit-snapshot rows.

## 9. Question banks

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We run live events on two mobile titles at once. Sketch how you would plan the next eight weeks of the calendar. What do you need to know first?" | CASE | [generic] | Clarify before you structure. Ask what each title's audience and goals are, what is already committed, how much design, art, engineering and community capacity each update has, and which KPI the events are meant to move. Then the objective, the cadence, the dependencies, the metrics, the risks. Think aloud and state one premise you are challenging | Mirrors the JD's first duty (F3) as a live problem, and asks nothing about your past; CASE because it scores structure |
| A2 | "Two events are due the same week and engineering can only support one. How do you decide, and who do you tell?" | CASE | [generic] | Structure: what each event is meant to move, what slipping each one costs, the options (stagger, shrink scope, move one), who decides and who is informed among design, art, engineering and community, and what you would record for the post-event review. Say what you would need to know before deciding | The JD's coordination line (F4) as a decision under constraint; CASE because the interviewer scores reasoning, not the right answer |
| A3 | "A retention measure on one of the titles dropped after last week's update. Diagnose it." | CASE | [generic] | Ask which retention measure the team reports and how it is defined, what the baseline was, and what else changed that week (the update, an event, the player mix, a release bug). Segment, rank hypotheses, say what you would check first and what you would do before you know the cause | Retention comfort (F7) tested as a diagnosis; CASE with a JD flavor |
| A4 | "We want an event that lifts both engagement and spend. What would you ask the team before it goes on the calendar?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Ask who owns the spend goal and how it is measured, what the economy side can and cannot change, what guardrails exist for players, and how success will be judged afterward. Keep your role as the producer who holds the calendar, dependencies and review together. If the interviewer turns to your own spend experience, the plain line is "I haven't worked on a game with in-app purchases", rehearsed in B1 | The monetization gap (F9) arrives here as a planning question, where asking good questions is the honest strength; CASE because it is a live problem |
| A5 | "An event has ended. What goes into the post-event review, and which KPIs does it report?" | CASE | [generic] | Fix the objective and the KPIs before the event, never after. Cover result against objective, a baseline for comparison, what the update process did well and badly, and the decisions for the next event. Say who you would want to own each number. Candidate-side note: this is a design answer, not a description of your past | The JD's review-and-KPI line (F5) as a design question; CASE because it scores structure |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't led a team and you haven't worked on a game with in-app purchases. Why should I trust you with two live titles?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | **Highest-ROI prep in this pack.** Concede first and specifically: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then hold only what you wrote: you ran the weekly content-drop calendar for your main title for two years, you wrote the release checklist QA still uses, and you presented the monthly retention numbers to the studio head. Follow-up 1, "one title is not two": hold the quote at its scope, concede it is one title, and say what changes in plan form. Follow-up 2, "who covers the monetization side?": concede again, then name the first two things you would learn and from whom, as a plan. Follow-up 3, "that sounds like a junior role": return to the quotes, never add to them. Never claim leading, owning KPIs or running events. Answer slot: the second follow-up asks how you would learn monetization; name the people and steps in your own words | F3, F4 and F9 are where the material is thinnest and the JD presses hardest, so some form of this question is the most predictable in the loop; JD because it scores fit against the stated duties |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick the part your material shows is thinnest and say it plainly. Per this pack's analysis the thinnest are events across two titles (F3), coordinating four disciplines (F4) and monetization (F9). If you choose monetization, the plain line is "I haven't worked on a game with in-app purchases", followed by how you would close it. A named weakness plus a plan is stronger than a vague one | The persona's standard stem, tuned to the three rows with the biggest gaps; JD because it scores honest self-assessment against the listed duties |
| B3 | "The role coordinates design, art, engineering and community on every update. Tell me about a time you coordinated people across disciplines to ship something." | EXP | [grounded] "Wrote the release checklist our QA team still uses", "Never led a team, and never worked on a game with in-app purchases" | Selection scaffold: pick a time when your work depended on another discipline, with a named stake, what you needed from them, and how you handled it when something was not ready. Coordinating is not leading; do not claim the second. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that you wrote the release checklist QA still uses, or say how you would handle it | F4 is silent in your material, so this open prompt lets you choose the instance; EXP because it asks what you actually did |
| B4 | "You ran the calendar for your main title. This role runs it for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the sentence at its scope: you ran the weekly content-drop calendar for your main title for two years. Concede it is one title in your material. Answer slot: if you touched any other title's calendar, say so; if not, say so plainly. Then answer the "what changes" half as a plan: shared teams, clashing dates, who needs what when | F3's scale gap, asked directly; JD because it scores the one-to-two-title step |
| B5 | "Why live operations, why mobile, and why now?" | JD | [generic] | Your material gives one fact for the first part: the weekly content-drop calendar you ran, in those words. Why you want this work, why mobile, and why Saltmarsh are yours to say, and this pack has no research on the studio to help. Prepare three honest sentences, one for each | The Skeptic's motivation probe; JD because it tests that your story hangs together, and `[generic]` because the pack holds nothing on your reasons or the studio |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Anchor in the sentence: you presented the monthly retention numbers to the studio head. Answer slot: if you know how the retention measure was defined and counted, say so in your own words; if you do not know how it was counted, say so plainly. Name the assumption behind the numbers you would defend least, if you know one. Say which part was yours: presenting them, or also producing them | F7 is the evidence for retention comfort and has no figure, so the defend-the-number slots apply; EXP because it tests attribution |
| C2 | "Which retention measures would you watch after an event, and why?" | JD | [generic] | A design answer: decide the measures before the event, compare against a baseline, separate the event's effect from the title's normal pattern, and say what you would ask the team about how they are already defined. Do not describe measures you have not used as though you had | Retention comfort (F7) tested forward; JD because it scores the stated requirement |
| C3 | "Did the retention numbers ever change what you put on the calendar?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head", "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if they did, give one instance and say what part of the decision was yours; if they did not, or that decision was not yours, say so plainly and stay with presenting the numbers and running the calendar | F5 links the numbers to a review loop, and the JD's KPI line makes this probe likely; EXP because it asks what you actually did |

### D. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats, one per sentence: four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar you ran for your main title, the release checklist QA still uses, the monthly retention numbers you presented to the studio head. Keep the title as you wrote it. End on why this role, in your own words | The biography question is scored for economy; EXP because it tests whether the story matches the CV |
| D2 | "Tell me about the release checklist your QA team uses." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say what the sentence says: you wrote it, and QA still uses it. Answer slot: the JD says manage the release checklist with QA, so expect a probe on what it covers and how it changes. If you updated it or ran it for releases, say how; if it was written once and QA took it from there, say so plainly. Do not describe contents you did not write | F6 and F8 rest on this one sentence, so expect it to be probed; EXP because it asks about your own artifact |
| D3 | "What are you actually playing these days, and what do you notice about how they run their events?" | CO | [generic] | Name two live mobile games you really play and one thing each does with its calendar, such as its cadence or how it announces events. Choose honest ones; an invented hobby fails the next question | The casual question that carries the CO signal; no research on Saltmarsh was available, so the pack cannot name the studio's titles |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause and restate the question. Hold the sentence: you ran the weekly content-drop calendar for your main title for two years. Answer slot: if others supplied the content or set what went into each drop, say so plainly and say which part was yours; if you set it, say that. Do not widen the claim under a second push | F2 is the claim a pressure probe tests; EXP because it is an attribution question |
| E2 | "Sixty seconds: why you over someone who has run a team on a monetized title?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses" | Concede what the other person has: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then the sentences you did write: the calendar, the checklist. Do not run the other candidate down | A time-boxed version of B1; JD because it scores fit against the stated duties |

### G. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: it needs a named stake, a moment you did not soften it, and a relationship still intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that you presented the monthly retention numbers to the studio head, or how you would handle it | The persona's standard stem; no published Saltmarsh values were available, so VAL is a general behavioral screen here |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold, with players as the customer: pick a time with a named metric, a named player-side cost, and your actual decision. If no such time comes to mind, say so plainly and say how you would weigh it | The persona's standard stem; `[generic]` because your material holds no sentence this question rests on |

### H. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where is the seam between live ops and design, and what happens when we disagree?" | JD | [generic] | Offer principles, not a pretended seam: who owns the date, who owns the content, who breaks a tie, what gets written down. Add what you would bring the other team, not only what you need | The persona's standard stem applied to the JD's coordination line (F4) |
| H2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | We for context, I for contribution. The one sentence you can use is that you wrote the checklist QA still uses; say what was yours and leave the rest to the others. If a cross-team piece of work comes to mind that your material does not carry, say so plainly and tell it as it was | The persona's standard stem; VAL because it scores collaborative honesty |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, B1, B4 |
| "coordinate design, art, engineering and community teams on each update" | A2, B3, H1 |
| "own the post-event review and the KPIs it reports" | A5, C3 |
| "manage the release checklist with QA" | D2 |
| "3+ years producing live-service games or apps" | B1, B2, D1 |
| "experience running a content calendar" | A1, B4, E1 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | D2 — no separate question; it is shown by how you write, not by a spoken answer |

## 11. Reverse questions

| Question | Why it lands |
|---|---|
| "What does a strong first 90 days look like across the two titles?" | Signals you are already thinking about the job and gives you the interviewer's own yardstick |
| "How is the live-events calendar owned today, and where does the producer's call end and design's begin?" | Goes straight at the seam that B1, A2 and H1 probe; the answer tells you whether you would own dates or only track them |
| "Which KPIs does the post-event review report today, and who set them?" | Shows you read the JD's review line, and the answer tells you how much of F5 the job really is |
| "How do the two titles differ in cadence and audience, and how much of the calendar do they share?" | Shows you are thinking about scale, which is the step from your one-title experience |
| "How do monetization goals enter event planning, and who owns that conversation?" | An honest way to engage the gap you have already named, and it shows you intend to learn it |
| "Where have strong producers found this role hardest?" | Invites candor and gives you a chance to address that concern before the interview ends |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F4 and F9 | "I haven't led a team." No answer slot; coordination is a separate question in B3 |
| Has worked on a game with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Planned and ran live events across two titles | Inflated form of F3 | F3's quote at its own scope: a content-drop calendar for your main title. The limit is the pack's observation, not words for you: the material says one title and drops, not events and not two titles |
| Owned the post-event review and the KPIs | Inflated form of F5 | F5's quote at its own scope: you presented the monthly retention numbers to the studio head. The material says presented, not defined or owned |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope: you wrote the checklist QA still uses. The material says wrote, not ran each release |
| Producer of a live-service game for four years | Inflated form of F1 | F1's quotes at their own scope: four years as an associate producer, and the weekly calendar. The material does not say the title was a live service |

## 14. Sources

**Provided documents:** the job description pasted in your message, and your background as written in your message. No dossier was present.

**Searches sent (all refused, nothing returned):**
- "Saltmarsh Games mobile studio values" — refused
- "Saltmarsh Games interview process Live Operations Producer" — refused
- "Saltmarsh Games news strategy mobile titles" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call refused. Would have fed a values cheat sheet if a values round is documented; none is established, so the section is dropped and G1 and G2 are general screens |
| 2. Saltmarsh Games interview process, live operations | unavailable | Every call refused. Would have fixed the loop and the persona weights; the archetype fallback is Generic (screen, hiring manager, panel), and weights rest on the hiring-manager assumption |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call refused. Would have grounded CO questions and a grounding brief; D3 is `[generic]` and no brief is included |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every call refused. Would have supplied the interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- Whether Tobias is your hiring manager, a skip-level or a peer, plus any recruiter guidance on focus areas or a pre-declared exercise → persona weights reset, and a graded-deliverable section if one was announced
- Search access, or pasted pages from the Saltmarsh values page, careers page and any interview guide → values cheat sheet if a values round exists, loop-based persona weights, `[generic]` rows (D3, G2) become `[grounded]`
- A pasted public profile or talks by Tobias Wrenfield → an interviewer read and a reverse question tied to his own path
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a company strategy brief and sharper CO and CASE questions
- Your answers to the answer slots in F1, F3, F4 and F5, said outside a drill → those rows regenerate on your own words and the matching questions get story maps instead of slots
- The release checklist itself, a content-calendar export or a retention deck from your last studio → F2, F5, F6 and F7 can move from medium toward high confidence
- A `tuesday-dossier.md` from an earlier evidence review → verified evidence and a named top objection in place of the inferred ones here
