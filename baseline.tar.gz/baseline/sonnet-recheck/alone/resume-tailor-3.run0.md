I'm working from the prose you gave me and your dossier excerpt. I read the skill's rules for this and built the edit ledger below. Nothing has been applied.

I haven't seen your CV file. Each "current line" below is your own sentence as you wrote it here, and each trace quotes that sentence. The dossier names the same role, so I used it as given: its pending edit E1 appears below as row E1 and went through the same audit as every other row.

## Edit ledger

All rows land as pending your approval.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (buried with other duties) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your background prose; dossier edit E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your background prose | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to the third bullet, after E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your background prose | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own Skills line | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your background prose | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your background prose | pending your approval |

- **Wording stays yours.** E3 keeps "client feedback for product" and does not become "informed the roadmap". E4 keeps "Comfortable in", so it doesn't read as "wrote specs".
- **E5 stays as two sentences.** It names your real title and says nothing about product management.
- **Order matters because the first bullets are what a quick reader sees.** The integrations come first, the playbook second and the roadmap sessions third.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier calls it adjacent, a transferability gap, medium confidence. E1, E2 and E3 show integration leadership and client feedback. Roadmap ownership and prioritisation authority are not evidenced. See C1. | `[grounded]` dossier R1 |
| R2 | Shipped API or platform products | important | `not_evidenced` | Dossier calls it adjacent, medium confidence. You led integrations of APIs, but your material doesn't say you shipped an API product. See C2. | `[grounded]` dossier R2 |
| R3 | Technical fluency | important | `surfaced_by_edit` | E2 and E4 | `[grounded]` your background prose |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 show client-facing delivery and feedback sessions. The phrase "stakeholder management" itself is not written anywhere. | `[grounded]` your background prose |
| R5 | Discovery with integration partners | important | `surfaced_by_edit` | E3 only. Your sessions were with clients of your vendor, not integration partners, so the lines stay in your words. | `[grounded]` your background prose |
| R6 | Specs and driving delivery with two engineering squads | important | `not_evidenced` | Named absence below. E4 shows OpenAPI fluency, not spec authorship. | `[grounded]` your background prose |
| R7 | Define adoption metrics | important | `not_evidenced` | See C3. | `[grounded]` your background prose |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM | must-have | Seven years of integration and implementation work, with roadmap input collected from clients. It does not show who decided what went on a roadmap. | A titled-years requirement may be read literally by a screener, and "never held a PM title" is the risk to carry. | A prioritisation call you made between competing client requests; a recommendation of yours that product adopted; a feature request you owned from intake to release | A roadmap-session summary, a ticket history, an email to product | `[grounded]` what your material says; `[generic]` how titled-years requirements get screened |
| C2 | Shipped API or platform products | important | You led integrations of your company's REST APIs. It does not say you shaped or released any API capability. | The role is to own a platform that partners build on. | A client-driven change to an endpoint or the docs that went live; a spec review you took part in before release; a playbook step that changed product behaviour | A release note, a changelog entry, a spec diff | `[grounded]` what your material says; `[generic]` what this role weighs |
| C3 | Define adoption metrics | important | No metrics appear in your material. | The role asks for adoption metrics, and an integration count is not one. | Time-to-integrate across your 30+ clients; how many integrations went live and stayed live; which clients stalled and where | An integration tracker, a status report | `[grounded]` what your material says; `[generic]` what this role weighs |

**R6 named absence.** Your material doesn't show writing specs or driving delivery with engineering squads. Closing it would take one concrete example of you working with engineers on a client-driven change, or a spec you drafted. If no such example exists, the honest route is to say you are moving from the client-facing side toward product.

## Not written, and why

Pending your approval, like every other block here.

- **"3+ years of product management" or any PM title.** You never held one, and this is the must-have.
- **"Owned the roadmap", "prioritised", "defined the roadmap".** You collected feedback "for product". The decision was theirs.
- **"Shipped API products".** Leading client integrations is not shipping a product.
- **"Discovery with integration partners" or "partner-facing platform".** Those are the JD's words. Yours are clients of your own vendor.
- **"Wrote specs" or "spec authorship".** You wrote "Comfortable in … OpenAPI specs".
- **"Worked with engineering squads", "defined adoption metrics".** Nothing in your material says either.
- **Widening the playbook ("company-wide", "adopted across the org").** Your sentence says "the whole team".
- **Dossier rejected inference:** "built an internal request-triage tool". It was a memory lead and you could not confirm ownership. It stays out.
- **Dossier rejected inference:** "has been the customer of a partner API platform". You worked vendor-side, so that inverts which side of the table you sat on.

## Parse-safety check

You sent plain text, so I could not check layout. That means no check on columns, tables, text boxes, images or skill bars, header or footer content, or file type. Your section headings are conventional (Summary, Experience, Skills) if your file uses them. I found no hidden text, but only in what I could see.

## Upgrade menu

- **Paste or attach the CV itself.** That unlocks `cut` rows for lines irrelevant to this role, verbatim current lines and the real parse check.
- **A sanitized page of the playbook or an OpenAPI file you wrote.** That could turn "Comfortable in … OpenAPI specs" into a stronger, checkable line.
- **Any release note, changelog or roadmap-session summary that shows your input landing.** That is the strongest way to move C1 and C2.

## Questions

C1 — Was there a time you decided which client request went ahead, or product adopted a recommendation from your roadmap sessions? What was it?
C2 — Did any client-driven change to an API, its docs or its behaviour go live because of your input, and what was your part?
C3 — Do you have any numbers on your integrations, such as time-to-integrate or how many went live and stayed live?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.