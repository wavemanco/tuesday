I'll read the reference files the skill points to before building the ledger.
Sam, I haven't changed anything yet. Every edit below is a proposal waiting for your approval.

## Is it the keywords?

The evidence I can cite doesn't show keyword auto-rejection as the usual cause, though it does exist. A résumé-builder vendor interviewed 25 US recruiters. It reports "AI/content auto-rejection configured: 8% of recruiters", which is two people, in a sample the vendor itself calls themes rather than representative statistics. The same interviews say "When automated filters are used, they’re almost always knockout questions". Those are yes/no checks on work authorization, license or location. You answer them in the application form, and no resume wording changes them.

Match scores may affect ranking: "Many teams use match scores/filters to prioritize who gets reviewed first". But "Low score ≠ auto-reject", and in that sample "56% either ignore the feature or don’t have it available". That keywords drive those scores is an inference.

Two things follow:

- **Parsing:** your Canva layout is the more concrete risk (see the parse-safety check below). If the parser mangles the file, the content never reaches a reader.
- **Gaps:** several of this JD's named tools are `not_evidenced` in your material (rows R2, R4, R5, R6, R7, R8, R9, R10, R11, R12 in the map). No honest rewording closes those, so I haven't tried to.

Whether this role is worth applying to with those gaps is job-underwriter's question, not this one.

**Assumptions:**
- I only have your description of the resume, not the file. The "current lines" below quote your message.
- The JD doesn't tier its requirements, so I set the priorities myself from the title and duties.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Kubernetes (proof-of-concept, not in production), Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |
| E2 | Skills (applied after E1) | the E1 line | "Python and Bash scripting, AWS (EC2, S3, RDS, IAM), Docker, Kubernetes (proof-of-concept, not in production), Jenkins, Ansible for config management, CloudWatch for monitoring." | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved directly below the deploy-pipeline bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | "Built our deploy pipeline in Jenkins." and, as its own line, "Maintain about 30 Jenkins jobs." | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |
| E5 | Summary | *(no current line, if your resume has none)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a two-month Kubernetes proof-of-concept that did not go to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |

- **E1 and E2:** these are the only places the word Kubernetes enters your skills list, and the qualifier travels with it.
- **E5:** the three sentences stay separate. I left out "last year" because it will go stale. Tell me the actual year if you want it back.
- **Dropped an idea:** I didn't propose adding the literal string "CI/CD". Your sentence says "deploy pipeline", not what the other Jenkins jobs do.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes, hands-on | must-have | `surfaced_by_edit` | E1, E3, E5. It is a two-month proof-of-concept, not production. | `[grounded]` |
| R2 | Production Kubernetes on AWS EKS | must-have | `not_evidenced` | Recall prompt C1 | `[grounded]` |
| R3 | AWS | important | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" as written | `[grounded]` |
| R4 | Terraform | must-have | `not_evidenced` | Recall prompt C2. Ansible is config management and does not stand in for it. | `[grounded]` |
| R5 | Helm, ArgoCD, GitOps | important | `not_evidenced` | Recall prompt C1 | `[grounded]` |
| R6 | Istio, service mesh | important | `not_evidenced` | Named absence A1 | `[grounded]` |
| R7 | Prometheus, Grafana | important | `not_evidenced` | Named absence A2 | `[grounded]` |
| R8 | Monitoring, observability practice | important | `already_evidenced` | "CloudWatch for monitoring" covers monitoring only. Observability is the JD's word, not yours. | `[grounded]` |
| R9 | Vault | important | `not_evidenced` | Named absence A3 | `[grounded]` |
| R10 | CI/CD pipelines | must-have | `already_evidenced` | The Jenkins deploy pipeline and about 30 jobs (E4 makes them easier to scan) | `[grounded]` |
| R11 | GitLab CI | must-have | `not_evidenced` | Named absence A4 | `[grounded]` |
| R12 | Python | must-have | `already_evidenced` | "Bash and Python scripting" (E2 moves it earlier) | `[grounded]` |
| R13 | Go | important | `not_evidenced` | Named absence A5 | `[grounded]` |
| R14 | SRE practices | must-have | `not_evidenced` | Recall prompt C3 | `[grounded]` |
| R15 | Owning platform reliability and developer experience | must-have | `not_evidenced` | Recall prompt C3. You build and maintain a pipeline, but your material doesn't say you own reliability or who uses it. | `[grounded]` |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Kubernetes (EKS), Helm, ArgoCD, GitOps | must-have | A two-month proof-of-concept that "never went to production". It doesn't say what ran it, how you deployed to it, or where. | These are the JD's central tools. Detail about the proof-of-concept is the only Kubernetes evidence you have. | Deploying with Helm charts or plain manifests; running it on EKS or self-managed; wiring a Git-driven deploy; a staging cluster others used | Manifests or charts in a repo, a README or write-up of the proof-of-concept, a diagram | `[grounded]` what your resume says; `[generic]` the proof-of-concept detail is what a reviewer weighs |
| C2 | Terraform | must-have | Ansible for config management, and AWS services listed. Nothing about provisioning infrastructure as code. | It is a named must-have, and Ansible is a different tool and a different job. | Terraform or another provisioning tool on AWS, a module you wrote, a state or backend setup | A repo, a pull request, a runbook | `[grounded]` what your resume says; `[generic]` named tools are what a screener looks for |
| C3 | SRE practices; reliability and developer experience | must-have | A pipeline you built and maintain, and CloudWatch monitoring. No incidents, on-call, alerting or users are mentioned. | The JD says "you will own platform reliability and developer experience". Nothing yet shows ownership of either. | On-call rotations, incident response, CloudWatch alarms you set up, post-incident reviews, developers relying on your pipeline | An incident write-up, an alarm list, a runbook | `[grounded]` what your resume says; `[generic]` this is what the role description centres on |

## Named absences

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | Istio, service mesh | Nothing in your material touches a service mesh. | A hands-on lab on a cluster, which only counts if you can describe what you configured. | `[grounded]` the gap; `[generic]` the closing path |
| A2 | Prometheus, Grafana | You list CloudWatch only. | Running both against a cluster, for instance on top of your proof-of-concept. | `[grounded]` the gap; `[generic]` the closing path |
| A3 | Vault | Nothing in your material mentions secrets management. IAM is a different thing. | Real use at work, or a self-hosted lab you can discuss in detail. | `[grounded]` the gap; `[generic]` the closing path |
| A4 | GitLab CI | Your pipeline experience is Jenkins. | Re-building one pipeline in GitLab CI. The concepts transfer, but the line stays unwritten until you have done it. | `[grounded]` the gap; `[generic]` the closing path |
| A5 | Go | Your scripting is Bash and Python. | Writing a small tool in Go. It's a longer road than the others, so it may not be worth closing for this application. | `[grounded]` the gap; `[generic]` the closing path |

## Not written, and why

- **"Platform Engineer" as your title:** you're a DevOps Engineer. A clearer equivalent is allowed, but this would be an upgrade.
- **Terraform, ArgoCD, GitOps, Helm, Istio, Vault, Prometheus, Grafana, EKS, GitLab or Go in any list:** your material shows none of them. A keyword you can't discuss costs more in the interview than it gains.
- **"Kubernetes experience" without the proof-of-concept qualifier, or cutting "never went to production":** this would turn a two-month trial into production work.
- **"Observability" for CloudWatch monitoring:** that is the JD's word for a broader practice than the one you stated.
- **"Infrastructure as code" for Ansible:** same reason. You wrote config management.
- **"Owned platform reliability" or "improved developer experience" for the Jenkins work:** you built and maintain a pipeline. Ownership and who benefited are not in your material.

## Parse-safety check

I haven't seen the file, so this is based only on your description.

| Check | What your description raises | What it costs | Could I check it |
|---|---|---|---|
| Multi-column layout | A two-column PDF | A parser may read the columns interleaved, so skills and dates can detach from roles | Not on the real file |
| Icons for each skill | Icons beside skills | If an icon carries information, such as a skill level, that information is simply absent from the extracted text | Not on the real file |
| Contact details in the header | Contact details in the header | Parsers may treat headers as page furniture and discard them, which can make you unreachable | Not on the real file |
| Text layer, section headings, file type | Unknown | A PDF with a real text layer is one of the two safe file types, the other being `.docx` | No |
| Hidden text from a template | Unknown | You could carry text you didn't write and can't see | No |

I report these and don't redesign anything.

## Upgrade menu

These are offers, not part of the ledger above, and I'll build them only if you say so:

- **Attach the real PDF.** I could run the text-extraction and hidden-text checks above on the file itself, which turns the "not on the real file" cells into findings.
- **Attach the proof-of-concept repo or write-up.** It could move R1 and parts of R2 and R5 from description to evidence, with new rows built from your own text.

## Questions

C1 — During the Kubernetes proof-of-concept, what did you deploy and how (Helm, plain manifests, EKS or self-managed), and did anyone besides you use it?

C2 — Have you written any Terraform, or other provisioning code for AWS, beyond Ansible?

C3 — Have you handled incidents, been on call, or set up alerting for a service other people depended on, and if so what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.