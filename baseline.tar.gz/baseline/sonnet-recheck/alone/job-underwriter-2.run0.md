Web search wasn't permitted, so this read uses only your resume and the JD.

# Job Underwriting: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, applying isn't a waste of your time, but this posting is a reach. Its stated must-have, 3+ years of product management experience (R1a), is absent as titled years. Your case rests on R1b and R2, which are adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3 · adjacent: R1b (PM work done under another title), R2 (Shipped API or platform products) · absent: R1a (3+ years PM experience, as titled years)
- `important`: direct: R4a, R7 · adjacent: R6 (Own the roadmap), R8 (Write specs and drive delivery), R10 (Coordinate launches) · unclear: R4b (Stakeholder management with sales), R5 (Agile delivery), R9 (Define and track adoption metrics)

R1a is the row the posting itself flags as must-have, and R1b and R2 carry the case against it.

**Opportunity ledger.** The role is concretely scoped on its face (RR4). The employer is unverified (RR1), compensation is not in the pasted text (RR2), and the years requirement may be applied literally (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The employer and posting verify on Quartzline's own careers page (RR1).
  2. Someone at Quartzline confirms that product work done under another title is read as counting toward the 3+ years (RR3). If the answer is titled PM years only, R1a decides this posting and I would re-run the decision expecting it to drop.
  3. R2 and R1b are framed as adjacent, with their limits stated, and never as API-product ownership or PM tenure.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. The existence and stage are not checked against any outside source | `[grounded]` JD header; not externally verified (search refused) |
| Mandate | Own the roadmap of the partner-facing API platform, run discovery with integration partners, write specs, drive delivery with two engineering squads, track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | The JD states none | `[grounded]` JD silence |
| Scope read | A mid-level product post on a single platform, with two squads and a defined partner audience | `[inferred]` from the title carrying no "Senior", the 3+ years figure, and the two-squad scope |
| Market calibration | Not run, because the role-family sweep was refused. No salary band is offered, and the JD states no compensation | `[grounded]` JD silence; calibration unavailable |
| Unknowns | Reporting line, compensation, location or work pattern, whether an API platform already exists with adoption data, and what "agile delivery" means in practice | — |
| Contradictions | None inside the pasted JD. It could not be checked against a careers page | `[grounded]` JD text as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled PM years | must_have | absent | none | capability | You said you have never held a PM title, and the JD marks this the must-have. This row grades the titled years only. The adjacent work is in R1b, and solutions-engineering years must not be presented as PM years | `[grounded]` your statement and the JD | Carry as the material risk. See G1 and RR3 |
| R1b | Product-management work done under another title | must_have | adjacent | medium | transferability | Roadmap-input sessions for product, requirements documents, and coordinating engineers and product managers on custom builds are real product-adjacent work. Limit: you fed product's roadmap and are not described as owning priorities or a roadmap | `[grounded]` your resume text; limit `[inferred]` from the absence of ownership language | See G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the integration playbook the team uses, so you know an API product from the consumer and implementer side. Limit: the resume does not say you built or shipped an API or platform product | `[grounded]` your resume text; limit `[inferred]` | See G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading and 30+ integrations fit this directly. It is resume prose with nothing inspected, so `medium`, and expect a technical probe | `[grounded]` your resume text | Offer: a sanitized integration architecture diagram or playbook excerpt would raise it to `high` |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your own engineers, the client's engineers and PMs, and ran scoping workshops with clients | `[grounded]` your resume text | None |
| R4b | Stakeholder management with sales | important | unclear | none | discovery | The resume is silent on sales | `[grounded]` resume silence | See G4 |
| R5 | Agile delivery experience | important | unclear | none | discovery | Scoping, UAT and go-live describe phased delivery. They do not say whether you worked in sprints or with engineering squads | `[grounded]` resume silence on agile practice | See G5 |
| R6 | Own the roadmap for the partner-facing API platform | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product. Limit: that is input to a roadmap, not ownership of one | `[grounded]` your resume text; limit `[inferred]` | None beyond R1b's |
| R7 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly feedback sessions with clients who integrate with your APIs are the same activity. They were your employer's clients, not platform partners | `[grounded]` your resume text | None |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and integration architecture are real specification work. Limit: they were client-specific, and you coordinated engineers on custom builds without being described as driving a squad's backlog | `[grounded]` your resume text; limit `[inferred]` | None beyond R1b's |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Nothing on the resume covers this. A prior-conversation lead about an internal request-triage tool that support agents adopted is unconfirmed, so it can only prompt a question | `[grounded]` resume silence; lead is a `memory_lead` | See G3 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launch-shaped coordination. Limit: they are client go-lives, not product launches, and sales involvement is unknown (R4b) | `[grounded]` your resume text; limit `[inferred]` | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM experience without the title (R1a, R1b, must_have) | capability | No titled PM years, and a real set of adjacent activities | This is the one requirement the JD marks must-have. If the employer reads it literally, nothing in your wording changes the outcome | A stretch where you owned a prioritization call, a backlog, or a roadmap item, even informally | A roadmap-input session summary or a prioritized-request list, sanitized | `[grounded]` your statement; `[generic]` closure paths are an internal move into product at your current employer, or roles that do not state a years figure |
| G2 | Shipped API or platform product (R2, must_have) | transferability | Integrator and documenter of your employer's APIs, with the playbook as a reusable asset | A bridge with its limit stated holds up in interview | Tooling, SDK samples, or onboarding assets that clients used, or an API change you drove from client feedback | The playbook (sanitized), a changelog, a client onboarding guide | `[inferred]` bridge from the resume text |
| G3 | Adoption metrics (R9, important) | discovery | Silent resume; an unconfirmed lead about a triage tool | Metrics ownership is a named responsibility, and a confirmed tool with adoption evidence could move R9 and also bear on R2 | Building something that others adopted, and any usage figures you tracked, such as agents using it, tickets routed, or time saved | A screenshot, usage numbers, or a short write-up | `[grounded]` resume silence |
| G4 | Sales stakeholders and launches (R4b, R10) | discovery | The resume names engineers, clients and PMs but no sales | The JD asks for launch coordination with sales and support | Co-running a go-live with account executives, pre-sales scoping with sales, or briefing support before a launch | A kickoff plan, a handover note | `[grounded]` resume silence |
| G5 | Agile delivery (R5, important) | discovery | Phased delivery is described; sprint practice is not | A cheap check that could close a row | Sprint planning, standups, or backlog grooming with an engineering team | A Jira board or sprint-review screenshot, sanitized | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not in the pasted JD | unknown | — | no compensation line in the pasted text | The range may be withheld on the posting, or the paste may have dropped it | `[inferred]` from the pasted text's silence | What is the salary range budgeted for this role? | unresolved |
| RR3 | 3+ years of PM experience flagged as the one must-have | risk_signal | medium | "3+ years product management experience (must-have)" | The only requirement marked must-have may be screened literally by years. How strictly it is applied is unknown | `[inferred]` from the JD flagging this requirement and no other | Does the 3+ years need to be under a PM title, or does product-facing work from a solutions engineering role count? | unresolved |
| RR4 | Scope is concrete: two named squads, a defined partner audience, adoption metrics named as a duty | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The role is a defined job with measurable outcomes rather than a vague mandate | `[grounded]` JD text | Which adoption metrics exist today, and who tracked them before this hire? | noted |

## Application plan

`resume_edits_pending_approval`: each proposed line traces to your own resume sentences, and none adds a title, a product ownership claim, or a number you did not give.

| # | Proposed edit | Traces to | Provenance | Status |
|---|---|---|---|---|
| E1 | Summary line: "Solutions engineer and implementation lead with 7 years leading REST API integrations, scoping through go-live, across 30+ client integrations." | "7 years as a solutions engineer / implementation lead"; "Led 30+ client integrations of our REST APIs end to end" | `[grounded]` your resume text | pending your approval |
| E2 | Move "Ran quarterly roadmap-input sessions collecting client feedback for product" and "Wrote the internal integration playbook the whole team uses" into a top-of-resume group titled "Product collaboration", wording unchanged | Both are your own sentences; the group name rests on "coordinated... product managers" and the roadmap-input sessions | `[grounded]` your resume text | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR3 question of a recruiter or hiring contact early, and say plainly that your product-adjacent work was done in a solutions engineering role. Suggested lead: "7 years on the integrating side of REST APIs: 30+ integrations from scoping to go-live, plus quarterly roadmap-input sessions for product. I have not held a PM title." | R1a, RR3. Every clause of the lead traces to your resume and your statement | `[grounded]` your resume text and statement | pending your approval |
| A3 | Prefer a named introduction or a direct message to the hiring side over a cold submission | Literal screening of years figures is common, and a person who has read the adjacent evidence is the usual way past it | `[generic]` role-family pattern, not a fact about Quartzline | pending your approval |
| W1 | A sanitized one-page work sample, such as a playbook excerpt or a roadmap-input session summary, to raise R3 and R2 | R3, R2 | `[grounded]` rows R3, R2 | pending your approval |

## Evidence status

Verified: none yet. Your resume and pasted background count as self-report, so `medium` is the ceiling on first pass. Unverified leads: a prior-conversation mention of an internal request-triage tool that support agents adopted. Details are unconfirmed, so it is used only as a question (G3).

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform" and "Quartzline careers Product Manager Platform APIs". Both were refused because search permission wasn't granted. They would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary Series B B2B SaaS; career change solutions engineer to product manager". It was refused. It would have moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer and upgrade menu

I can package all of this into a `tuesday-dossier.md` whenever you want it.

- Search permission granted: I would retry the three targets above, which could settle RR1 and calibrate scope and pay (RR2). I could then offer a deeper company pass (up to 5 more searches and 2 more fetches).
- The recruiter's answer to RR3: R1a and the decision would resolve either way.
- A sanitized integration architecture diagram or playbook excerpt: R3 to `high`, and part of R2's bridge.
- A confirmed account of the triage tool: R9, and possibly R2.
- Your pay floor, location needs and any other non-negotiables: the hard-gates line becomes a real check.
- The hiring manager's name: scope read, and which story to lead with.

## Questions

**G3:** Did you build the request-triage tool support agents adopted? What did you own, how many people used it, and how did you know it worked? (I haven't treated it as fact.)

**G4:** In your go-lives and scoping work, did you work alongside sales, such as account executives or pre-sales? If so, what did you do together?

**Constraints and stage:** I've assumed you are still evaluating, not applying. What are your non-negotiables on pay, location and anything else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.