I'll read the reference files the skill points to before building the assessment.
**Yes, it's worth applying, on conditions. R1 and R2, the two hard gates (location and pay), are still unconfirmed against your own limits. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 (`medium`) is adjacent with its limit named below, and R9 and R10 wait on your answers.

**Opportunity ledger.** The posting is live on the company's own domain and matches your paste (RR1), and its pay range sits around the market median in your report (RR2). Equity terms (RR3), team and reporting line (RR4) and first-year outcomes (RR5) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 against your own location and pay floor; (2) the team, reporting line and first-year outcomes verify in interviews, see RR4 and RR5; (3) R8 is framed as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` your paste of the company's about page; funding and headcount not independently checked |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One reporting domain's pipelines; no direct reports are mentioned | `[inferred]` from the JD's single-domain mandate and its silence on reports |
| Market calibration | The Datawright 2026 report (n=2,310) puts base for Senior Data Engineer at Series B–D companies at a $151,000 median, IQR $139,000–$163,500. "Senior" typically means 5–8 years, with one domain's pipelines and no direct reports. The posting's 5+ years and single-domain scope are in line with that. Your 6 years sit inside the typical range | `[generic]` Datawright report as sent by your recruiter, not independently checked; `[grounded]` JD for the posted figures |
| Unknowns | Equity terms, team size, who the role reports to, success measures, how many source systems feed the warehouse | `[grounded]` JD silent on each |
| Contradictions | None between the JD you pasted and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you work from the US. Confidence is `none` because there is no statement of yours to grade | `[grounded]` JD term; your constraints not given | G1's question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Pay is stated, but your floor isn't known, so the gate is unsettled. Against the market report the range spans the median ($151,000) and its top is just above the upper quartile ($163,500) | `[grounded]` JD figure; `[generic]` report band | G1's question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. Intake prose is self-report, so `medium` | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily, as you describe. No artifact inspected, so expect a probe | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project built on Snowflake, about 180 models. Snowflake is a cloud warehouse, so the requirement as written is met. The BigQuery gap is carried by R8 | `[grounded]` your stated background | offer: a dbt docs or lineage screenshot would raise to high |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, as you state. The extent of your ownership isn't stated, so I assert only that you used it | `[grounded]` your stated background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Confirmed and specific, no artifact yet | `[grounded]` your stated background | offer: suite config or Data Docs output would raise to high |
| R8 | BigQuery as the warehouse | important | adjacent | medium | transferability | Posted under responsibilities, not requirements. Your 180-model dbt project on Snowflake is real warehouse-modelling work. The limit: you have never used BigQuery, so its cost and partitioning model and its dialect are untested | `[grounded]` JD responsibilities and your statement; `[generic]` that dbt skills carry across warehouses with a ramp | bridge case in G2 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | You haven't said what you ingested at the payroll company or how. A responsibility in the JD, not a titled requirement | `[grounded]` JD; your background silent | G3's question |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | A test suite is related to contracts but is not the same thing, and you haven't described anything with analysts as consumers | `[grounded]` JD; your background silent | G4's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The JD states its terms. Your side of both is unknown | Decides whether any further effort is worth spending | Your US location or Denver access; the base you would accept | Nothing to attach | `[grounded]` constraints not given |
| G2 | BigQuery (R8, important) | transferability | Snowflake and dbt at scale, no BigQuery | The likeliest objection to the application | Hands-on time in any BigQuery project, including personal or training work | A small personal or sandbox BigQuery project | `[inferred]` bridge from the dbt and Snowflake work; `[generic]` that warehouse switches are usually a ramp, not a blocker |
| G3 | Ingestion from app and CRM (R9, important) | discovery | The sources feeding your payroll warehouse are not described | A named responsibility, and one a payroll product would exercise | Loading from a product database, an event stream, or a CRM or billing system; connectors, CDC or API pulls | An architecture diagram or DAG screenshot, sanitized | `[grounded]` background silent; `[generic]` that ingestion design is commonly probed at this level |
| G4 | Data contracts (R10, important) | discovery | Great Expectations is established. Agreements with downstream consumers are not | Analysts depending on the contracts is the JD's own framing | Agreeing schemas or freshness with analysts; alerting on breaking changes; documented model ownership | A schema-change policy, a model-docs page, or a test-to-owner map | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting established | positive_signal | — | "Accepting applications" | The role is live on the company's own careers page and matches the pasted JD | `[grounded]` careers page fetched | Is this role still open, and what is the process and timeline? | noted |
| RR2 | Pay in line with market | positive_signal | — | "$148,000–$166,000 plus equity" | Range spans the report median, top just above the upper quartile; no seniority-pay mismatch visible | `[grounded]` JD; `[generic]` Datawright band as supplied, not independently checked | Where in the range would my background place me? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Amount, type and vesting are unknown, so total pay can't be compared | `[grounded]` JD names equity without terms | What is the equity grant, type and vesting schedule for this level? | unresolved |
| RR4 | Team and reporting line unstated | unknown | — | no hiring manager named; "Build and run the pipelines" | Unclear if you would be the sole data engineer or one of several, and whether "run" means on-call duty | `[inferred]` from the JD's silence on team and its build-and-run wording | Who is on the data team, who does this role report to, and is there an on-call rotation? | unresolved |
| RR5 | No stated first-year outcomes | unknown | — | JD lists requirements only | Success measures for the role aren't visible | `[grounded]` JD silent | What would a strong first 90 days and first year look like for this role? | unresolved |

## Application plan

Everything below is proposed and nothing is final until you approve it. The prose in the notes beneath is covered by that approval too.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and pay floor against R1 and R2 before spending application effort | see R1, R2, G1 | `[grounded]` R1, R2 rows | pending your approval |
| E1 | Resume line: "Built the company's dbt project on Snowflake, about 180 models" | R5. Traces to: "Built our dbt project on Snowflake — about 180 models" | `[grounded]` your sentence | resume_edits_pending_approval |
| E2 | Resume line: "Set up the Great Expectations test suite" | R7. Traces to: "I set up our Great Expectations test suite" | `[grounded]` your sentence | resume_edits_pending_approval |
| E3 | Resume line: "Used Airflow for orchestration" | R6. Traces to: "Airflow for orchestration" | `[grounded]` your sentence | resume_edits_pending_approval |
| E4 | Cover note line: "My warehouse experience is Snowflake with dbt; I haven't used BigQuery yet" | Names R8's limit before they ask | `[grounded]` your statement | pending your approval |
| Q1 | Ask the RR3, RR4 and RR5 verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

No bullet makes a claim your sentences don't hold. I left out data contracts and ingestion (R9, R10) until you answer G3 and G4.

## Evidence status

Verified: none yet. Your background is intake prose, so every claim sits at `medium` or below until an artifact is inspected.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Senior Data Engineer careers" and fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live and matches your pasted JD, which moved role reality's contradictions row and RR1. I did not fetch the about page, so the company facts rest on your paste |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes market calibration and RR2, so a search could not change them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Dossier offer

I can save all of this as `tuesday-dossier.md` if you want it.

## Upgrade menu

- A current CV, or a dbt docs or lineage screenshot, would move R5 toward `high`.
- Great Expectations suite config or Data Docs output would move R7 toward `high`.
- Your location and pay floor would settle R1 and R2, the two unconfirmed gates.
- A diagram, DAG screenshot or schema-change policy would settle R9 and R10.
- A small BigQuery sandbox project would narrow R8's limit.
- The hiring manager's name, once you have it, would open the people-research target and sharpen which story to lead with.
- A deeper pass on Pellucid (funding, leadership changes, candidate and employee reports, recent news; up to 5 more searches and 2 more fetches) would firm up RR1 and the opportunity ledger. Say the word and it runs.

## Questions

G1 — Where are you based, and is $148,000 a base you would accept?

G3 — At the payroll company, what fed your warehouse (product database, events, CRM or billing system), and who built those ingestion paths?

G4 — Did you agree schemas, freshness or breaking-change rules with the analysts or other teams who used your models? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.