Running two research searches (the company, then salary norms for the role), then the full assessment.
**Should you apply? Yes. Am I a fit? On the core of the role, yes, though I couldn't verify the employer.**

I ran two web searches (the company, and salary norms for this role). Both were refused, so nothing below is checked against the live web. Where the research would have mattered, I've said so.

## Decision snapshot

**Yes, apply. You're a fit on the core of the role: R1, R2, R3, R4 and R6 are `direct`. Status: `conditional_go`.** The condition is that the posting and employer verify.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (define and maintain the metrics layer)
- `important` — adjacent: R7a (partner with product managers) · unclear: R7b (partner with clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data experience, HIPAA)

R5 (`low`) is the row most worth firming up. R7b and R8 are unanswered rather than weak.

**Opportunity ledger.** The role is plausible but unverified. The employer could not be checked (RR1), pay and location are not in the text you gave me (RR2), and metrics-layer support and first-year success measures are unstated (RR3, RR4). One entry runs the other way: the responsibilities are concrete and a junior team appears to exist (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify (RR1); (2) pay and location are compatible with your constraints, once you give them (RR2); (3) you can show your governed Looker work covered metric definitions (R5, G1); (4) R9 is framed as adjacent, never as health-data experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header, as stated and not independently checked |
| Mandate | Own product analytics for the app: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, PM and clinician partnership, and mentoring two junior analysts | `[grounded]` JD |
| Requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; HIPAA data experience a plus | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Scope read | One senior individual contributor across metrics, experimentation, BI, stakeholder partnership and mentoring; no stated team, budget or tooling beneath it | `[inferred]` from the JD's five responsibilities against its silence on support |
| Market calibration | Not run. The role-family search was refused, and model memory isn't a source for pay or title norms, so no band is offered | `[grounded]` search refused |
| Unknowns | Salary, location or remote policy, data-engineering support, success measures, whether the juniors are direct reports | `[grounded]` absent from the JD text provided |
| Contradictions | None visible inside the JD text; not cross-checked against the company's careers page | `[grounded]` JD as pasted |

## Evidence map

I have your background as prose only, with no CV or documents. Under the evidence rules, nothing from unprobed prose rises above `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit company of about 2M subscribers, stated by you; nothing inspected yet | `[grounded]` your intake prose | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse. "Expert" is self-graded and nothing here tests it. Analyst hiring loops commonly test SQL live or by take-home | `[grounded]` intake prose; `[generic]` on screening | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. "At scale" is unquantified: traffic and sample sizes are unstated. Expect probes on power and guardrails | `[grounded]` intake prose; `[generic]` on what such probes cover | A sanitized readout of the pricing test would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` intake prose | A screenshot or export of the Looker project structure would raise this to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" and a monthly metrics memo sit close to this. You haven't said you defined metrics centrally (for example in LookML or a semantic layer), who owned the definitions, or how they were versioned. Lower band taken because the link is my inference | `[inferred]` from "governed" against silence on metric definitions | G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` intake prose | A sanitized memo excerpt would raise this to `high` |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | You present monthly to the VP Product. Working with PMs, and an analysis changing a roadmap, are not stated | `[grounded]` intake prose; the roadmap link is not stated | G3 |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing stated about working with domain experts such as clinicians. Evidence may exist in other forms | `[grounded]` intake prose silent | G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing stated about mentoring or managing analysts | `[grounded]` intake prose silent | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You have handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse. You have not worked with health data. The bridge is privacy-governed personal data; the limit is that this is not HIPAA or protected health information experience | `[grounded]` intake prose; the limit is your own statement | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards, but nothing on who defined metrics or where | A `must_have` at `adjacent`; confirming it is the likeliest way to move R5 to `direct` | Writing the canonical definition of a retention, churn or conversion metric; LookML measures or a semantic layer others reused; resolving a metric-definition dispute | LookML project structure, a metric dictionary, a definitions doc | `[grounded]` what you've said; `[inferred]` that this could move R5 |
| G2 | Mentoring (R8, important) | discovery | The intake is silent | The JD names two juniors, so this is a visible part of the job | Reviewing junior analysts' queries or analyses, onboarding a new analyst, running an analytics review, informal coaching | A review checklist or onboarding doc, or a named person you coached | `[grounded]` silence; `[inferred]` JD emphasis |
| G3 | PM partnership (R7a, important) | discovery | VP-level presentations, not PM-level partnership | The JD frames the job as turning analysis into roadmap decisions | A test result that changed what shipped; a recurring session with PMs | A roadmap decision linked to a test readout | `[grounded]` your statements |
| G4 | Clinician partnership (R7b, important) | discovery | Nothing stated | A role-specific requirement with no prior-employer analogue visible | Working with a nutrition, culinary or operations expert on an analysis or test | A shared analysis or an expert-reviewed test design | `[grounded]` silence |
| G5 | Healthcare data (R9, preferred) | transferability | Consent-state model and GDPR/CCPA work | It's a "plus", so a minor factor, but the likeliest probe | Consent and access controls, PII minimisation, pseudonymisation, working with a privacy or legal team | A description of the consent-state model (without confidential details) | `[grounded]` your statement; the limit stated in R9 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The search was refused, so this is unchecked rather than contradicted. The entity may be too new or small to have a footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location absent | unknown | — | (not in the JD text provided) | The full posting may state them, or they may be withheld | `[inferred]` from silence in the text provided | What is the salary band for this role, and is it remote, hybrid or on-site? | unresolved |
| RR3 | Metrics-layer ownership without stated support | unknown | — | "Own product analytics… define and maintain the metrics layer" | The role may own definitions with no data-engineering support beneath them | `[inferred]` from scope language against silence on support | Who owns the warehouse models beneath the metrics layer, and what engineering support does the analyst get? | unresolved |
| RR4 | No success measures stated | unknown | — | (no first-year outcomes in the JD) | A broad mandate with no stated definition of success | `[grounded]` JD silent | What would a strong first year look like for this role? | unresolved |
| RR5 | Concrete responsibilities and a named junior team | positive_signal | — | "mentor two junior analysts" | Scope reads as defined, with an existing team | `[grounded]` JD | Are the two analysts direct reports or a dotted line? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the company's own careers page before writing anything | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the experimentation program, the Looker build and the exec memo, in that order | R3, R4, R6 are the `direct` must-haves | `[grounded]` the map | pending your approval |
| A3 | Resume line, your own words: "Built the company's Looker instance from scratch — 40+ governed dashboards" | R4; traces to your sentence | `[grounded]` intake | `resume_edits_pending_approval` |
| A4 | Cover-note line: "I've handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse; I haven't worked with health data." | R9; honest bridge with its limit | `[grounded]` intake | pending your approval |
| A5 | Ask RR1–RR5's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Don't describe the consent-state model or GDPR/CCPA work as HIPAA or health-data experience. I'd drop any phrasing that implies it.

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app Series C careers Senior Product Analyst"; refused. It would have confirmed the entity and posting (RR1) and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker 2026"; refused. It would have supplied the market calibration and checked the RR2 pay gap |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Dossier offer

If you'd like, I can write all this up as a `tuesday-dossier.md` you can keep or hand to a later session.

## Upgrade menu

- Allow web search, or paste the company's careers-page posting → RR1 resolves, and pay and location (RR2) may appear. The decision would likely move from `conditional_go` to `go`.
- A deeper diligence pass (funding, leadership churn, public employee reports; up to 5 more searches and 2 more fetches) → RR1 and the risk register firm up, once L1 has run.
- Your CV → I can check it against the map and find buried evidence, especially for R5 and R8.
- A sanitized pricing-test readout, Looker project export or metrics memo excerpt → R3, R4 or R6 move from `medium` to `high`.
- The hiring manager's name → the scope read and which story to lead with.

## Questions

C1 — What are your non-negotiables here: a pay floor, location or remote requirements, and any work-authorization or schedule limits? Without these I can't check the role's hard gates.

G1 — In the Looker work, did you personally define the canonical metrics (retention, churn, conversion), where did those definitions live, and did other teams reuse them?

G2 — Have you mentored, onboarded or reviewed the work of other analysts? What did you own, and for roughly how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.