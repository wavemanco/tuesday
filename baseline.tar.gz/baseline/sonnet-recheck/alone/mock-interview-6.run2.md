I'll read the references the skill requires before writing anything.
I'm fixing an ID collision I spotted in the pack: the Round 2 question IDs F1–F3 clash with the fit-snapshot row IDs. I'll rename them to P1–P3, update the references, and then present the pack.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-6-denied-528ea834/d6a60a1d-bfae-4aa4-a722-3492162b4b7e/scratchpad/Larkfield_Systems_engineering_manager_interview_pack.md`.

It has a shared fit snapshot, then a section for each round with persona weights, a question bank (8–9 questions per round) and reverse questions. It also has a prep triage schedule, a requirement-coverage table and a list of claims the pack won't coach.

I built it from your role summary and the four sentences you gave about your background, with no JD or CV text. The web searches I tried (values, interview process, strategy) were refused by the permission check, so there's no company research in it. That means no values cheat sheet, and the Round 3 questions are themed on the recruiter's phrase "values and leadership philosophy". The company-strategy questions are generic.

The most useful prep is question B1 in Round 1: "You've never owned a hardware-adjacent roadmap. How do you handle that?" It comes back in other forms in Rounds 2 and 3, so one well-rehearsed answer covers all three. The pack gives the exact concession and two follow-up levels. The second thing to rehearse is the 60% on-call figure, which is probed in all three rounds.

Where your material is silent, such as growing engineers or device-management work, the pack gives answer slots for you to fill from your own experience, not invented stories.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job description and your CV? Either one turns the thinner rows into your own wording and the JD's.

Has the recruiter said anything about prep for Tuesday or Thursday (a case, a presentation, a topic list), or given you names or titles for the five interviewers? Either would reshape the round banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_Systems_engineering_manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role: Engineering Manager, industrial IoT, about 600 people, two squads, 11 engineers.

| Round | When | Interviewer(s) | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager | 45 min | Your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel: two technical peers, one cross-functional partner |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

No interviewer names or profiles were given, so there is no interviewer read in this pack. No company research ran (see Sources), so company-specific content is limited to your role description.

## How to use this pack

- Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored.
- Type key: VAL is values and behavioral alignment. EXP is a deep-dive on your own experience and attribution. JD is the stated role and its gaps. CO is company and strategy knowledge. CASE is a live problem from the actual role.
- Provenance labels: `[grounded]` traces to what you gave me, `[inferred]` is derived from an adjacent source, `[generic]` is a role-family pattern with no claim about you or Larkfield.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview, not a question for me: answer it from your own experience, and either branch is a good answer.
- Shared across all three rounds: the fit snapshot, the prohibited claims and the sources. Each round then has its own persona weights, question bank and reverse questions.
- The single highest-ROI prep in the pack is B1 (the hardware roadmap question, Round 1). Rounds 2 and 3 return to the same gap in other packaging (P2, E3, J1), so one well-rehearsed answer pays off three times.

## Prep triage

| Step | When | Do | IDs |
|---|---|---|---|
| 1 | Before Tuesday | Rehearse the hardware-gap answer aloud until it is boring: first answer, two follow-ups, the exact concession | B1, then J1 |
| 2 | Before Tuesday | Rehearse the 60% on-call figure once: how it was counted, what else changed, which part was yours. It is asked in three rounds | D1, P1, J2 |
| 3 | Before Tuesday | Write your 90-second arc and say it twice | C1 |
| 4 | Before Tuesday | Run the first-hour and replan cases out loud, thinking aloud before structuring | A1, A2 |
| 5 | Between Tuesday and Thursday | Send me what the Director actually asked, so I can re-weight rounds 2 and 3 | — |
| 6 | Between Tuesday and Thursday | The seam-and-disagreement answer, the hiring-loop answer, the reliability-quarter disagreement story | E1, E2, P3 |
| 7 | Between Thursday and Monday | Your leadership philosophy in two principles, each tied to something you did, and the sixty-second pitch | I1, I2, J1 |

Everything else in the banks is insurance.

## Fit snapshot (shared)

Requirements are quoted from the role description you gave me (and, for row F8, the recruiter's description of round 3). Evidence cells hold your sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message, role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads, and the words stay at that scope: "Three of my nine years in engineering have been as a team lead of six." Answer slot: eleven engineers across two squads makes a probe on scale likely. If any of your lead role reached beyond a single team, say how, in your own words; if not, say so plainly and stay with the team of six |
| F2 | "Lead two squads building device-management services" — your message, role description (the device-management part) | none given | none | [grounded] | discovery | Your material does not show work on device management or industrial IoT, so there is nothing quoted to bridge from. Answer slot: the role names device-management services, so a probe on the domain is likely. If any of your work touched devices or the services around them, say what and which part was yours; if none did, say so plainly, then say what you would learn first, as a plan and not as a past |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message, role description (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The sentence says you pushed a reliability quarter through, and nothing in it says who answered for what shipped. The words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you decided what that quarter would contain and when it ran, say how you decided, in your own words; if you did not, say so plainly and stay with the sentence |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message, role description (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | transferability | The sentence says you run the loop for backend roles, so the words stay there: "I run our hiring loop for backend roles." The figure attaches to interviews, and the sentence does not say whether you conducted them or the loop did. Answer slot: say plainly which, in your own words. If the decision to hire was yours, say so; if it was not, say so plainly and stay with the loop |
| F5 | "own delivery, hiring and growth for 11 engineers" — your message, role description (the growth part) | none given | none | [grounded] | discovery | Your material does not show work on growing engineers. Answer slot: the role puts growth under you, so a probe is likely. If you have helped an engineer grow, say whose growth and what you did, in your own words; if your team lead role did not include that, say so plainly, then say what you would do first with eleven people, as a plan |
| F6 | "partner with hardware and product on roadmap" — your message, role description (the hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | You stated the negative, so the words are yours to give back: "I've never owned a hardware-adjacent roadmap." The role says partner, which is a different thing from owning, and your material does not show whether you have worked alongside hardware teams. Answer slot: if you have worked alongside a hardware team, say how; if not, say so plainly, then give the ramp as a plan: who you would meet first and what you would ask them |
| F7 | "partner with hardware and product on roadmap" — your message, role description (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | The sentence shows roadmap pressure and a quarter pushed through, and does not show a partnership with product. The words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you held the conversation with the people who set the roadmap, say what you proposed and what was agreed; if it was settled another way, or not by you, say so plainly and stay with the sentence |
| F8 | "values and leadership philosophy" — the recruiter's description of round 3, in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | discovery | No sentence of yours states a leadership principle; the reliability quarter is the one decision your material carries. Answer slot: if the principle behind that decision is one you act on, say it in your own words; if you cannot name one, say so plainly and stay with the sentence |

## Round 1 — Tuesday, Director of Engineering (45 min)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of F1, F2, F5 and F6 | Top weight. Hiring manager is a prior for derisking gaps, and four of the eight rows are discovery gaps | Rehearse the hardware answer (B1) until boring; calibrated candor, then a concrete ramp |
| Case/Strategist | Live problems from the role: replan a quarter, run an incident | Top weight. Hiring-manager prior; the role description names delivery and partnering on roadmap | Clarify, objective, options, risks; think aloud; challenge one premise politely |
| Prober | Reads the 60% line closely | Mid weight. One headline figure in your material, and a boss pricing risk will check it | Know what you can say about how it was counted; say plainly where you do not know |
| Conversational | Opens with "walk me through the journey" | Lower weight, but the opener is scored and sets the tone for 45 minutes | A 90-second arc built from your own sentence; do not relax |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A hardware team tells you their release date has moved by a quarter. You have two squads and 11 engineers. How do you replan?" | CASE | [generic] | Say what you need to know first: what is committed to whom, what actually depends on the hardware date, and how much of the work can decouple from it. Then objective, two or three options (resequence, descope, split the dependency), who you talk to first, what you tell the squads, and what you would watch. Think aloud, challenge one premise politely, and make no claim about your past: the question needs none | Live problem from the role description's "partner with hardware and product on roadmap"; `[generic]` because it is a pattern for the problem, not a fact about Larkfield. CASE because it scores structure |
| A2 | "A device update goes wrong at a customer site and devices stop reporting. Take me through your first hour as the manager, not the engineer." | CASE | [generic] | Structure it by role: who owns the technical call, what you decide (stabilize or roll back), who needs to hear from you and when, what you keep in writing, and what the review afterwards looks like. Say aloud where you would rely on your engineers' judgment because the domain is theirs. The scenario is a pattern invented for rehearsal, not a statement about Larkfield's products, and the guidance claims nothing about your past | Tests whether a manager with no stated domain history can run an incident through other people (F2). CASE because it is a live problem; the device scenario is a rehearsal device |
| A3 | "What does your first 90 days look like?" | JD | [generic] | A plan, not a past: who you meet and in what order (eleven engineers, the hardware and product partners), what you want to learn before changing anything, and the one thing you would hold off on. Say the plan in your own words; it makes no claim about what you have done | Hiring managers ask it to see whether you will ramp on the domain gap (F2, F6) or ignore it |
| B1 | "You've told us you've never owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. How do you handle that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | **The highest-ROI prep in the pack.** First answer: "I've never owned a hardware-adjacent roadmap." Then the F6 slot: if you have worked alongside a hardware team, say how; if not, say so plainly. Then the ramp as a plan: who you would meet first, what you would ask them. Follow-up 1, "So you'd be learning on our time?": hold by naming what you do bring from your own sentences (a team lead of six for three of nine years; a reliability quarter pushed through against roadmap pressure) and concede specifically that the hardware side is new. Follow-up 2, "What would worry you most?": name one thing about the hardware dependency you would want to understand first, in your own words, as a plan. Never claim hardware work, and never soften the negative | The Director is buying capability and pricing the gap; F6 is the row where the material is thinnest and the role presses hardest. JD because it scores the stated requirement; Skeptic delivery |
| B2 | "You've led six people. This role is eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | The hold is only what the quote carries: "Three of my nine years in engineering have been as a team lead of six." Say team lead, not manager, as your sentence does. Then the F1 slot: if any of your lead role reached beyond a single team, say how; if not, say so plainly. Then what you would do first with eleven people, as a plan. Concede that two squads is a step up and say what you would want to learn about how they work today | F1 is where scale presses; the question is premised on your own sentence plus the role's numbers. JD because it scores the lead-two-squads requirement |
| B3 | "Tell me about a time you helped an engineer grow." | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" and "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Selection scaffold, from the role's growth line: pick one named person, what they could not yet do, what you did, and where they are now. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: you run the hiring loop for backend roles, and you have been a team lead of six. Or say how you would approach growth for eleven people, as a plan. Do not describe coaching you did not do | F5 has no evidence either way, so the pack builds a selection scaffold and no story. JD because growth is a stated responsibility; open prompt, so the honest branch is built in |
| C1 | "Walk me through the journey. Why an engineering manager role, why Larkfield, why now?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Ninety seconds in three beats the sentence states: nine years in engineering, three of them as a team lead of six, now at a payments company. Why this role and why Larkfield are yours to say, in your own words: your material does not carry the motive. Answer slot: say what drew you to leading across squads and to industrial IoT; if the pull is mostly the management step, say that plainly | The opener is scored even when it feels casual; Conversational delivery over an EXP spine |
| D1 | "That 60% drop in on-call burden: how was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence at its own scope: it dropped after you pushed the quarter through. Then the defend-the-number slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Do not say the quarter caused the drop unless you can show it | Headline figures are magnet targets; this is the only one in your material. EXP because it scores attribution and honesty about the number |

### Reverse questions (Round 1)

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does good look like for this role at ninety days, and what would worry you at six months?" | Makes your future boss name his own bar, which tells you what you are really being hired against |
| R2 | "How is the work split between the two squads today, and where does that split hurt?" | Shows you are already thinking about the manager's real unit of work, and answers F1's scale question from his side |
| R3 | "How does the roadmap get negotiated between engineering, hardware and product, and where does it tend to break down?" | Turns your hardware gap (F6) into curiosity about the seam, and gets you the real process |
| R4 | "What do new managers here tend to underestimate?" | Signals humility without conceding capability, and surfaces what the Director is quietly worried about |
| R5 | "How do you like to be kept informed, and when do you want to be pulled in?" | A boss relationship question; shows you plan to manage up, not just down |

## Round 2 — the Thursday after, panel of two staff engineers and a product manager (60 min)

Persona weights follow the panel rule: the top two personas of each member's relationship, blended. The staff engineers are technical peers (Peer Evaluator and Prober); the product manager is cross-functional (Values/Behavioral and Conversational).

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between manager and staff engineers, "what would you need from me", disagreement style | Top weight. Two of three panelists are technical peers who will work for or beside you | Reciprocity framing: what you bring them, not only what you need; propose seam principles rather than pretend to know the seam |
| Prober | Pushes on the 60% figure and on how you run a hiring loop | Top weight. Staff engineers verify depth, and two of your sentences carry figures or loop claims | Know what you can and cannot say about how each was counted; name the assumption you would defend least before they do |
| Values/Behavioral | The PM asks scenario questions, often with product-versus-engineering tension | Mid weight. Cross-functional prior; the role's "partner with hardware and product on roadmap" line raises the theme | A selection scaffold with an honest branch where no story comes to mind; "we" for context, "I" for contribution |
| Conversational | A casual question about what you are exploring in the domain | Lower weight, but casual questions about hot role topics are still scored | Treat it as scored; answer honestly about where you are on the domain |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "As a manager, where is the line between your call and the staff engineers' call on technical direction, and what happens when we disagree?" | CASE | [generic] | Propose seam principles and not a fixed seam: you own what, when and who; they own how, and they get a say on what is shippable; disagreements go to the evidence first and to you for the call when it is a tradeoff between delivery and quality, with the reasoning said out loud. Reciprocity: say what you would want from them and what you would give them, such as context on the roadmap and cover when they push back. Say you would ask the panel how it has worked in the past. No claim about your past | The Peer Evaluator's core question; `[generic]` because it is a stance, not a fact about you or Larkfield. CASE because it is a live scenario about the role |
| E2 | "You pushed a reliability quarter through against roadmap pressure. How did you handle the disagreement?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The sentence says you pushed the quarter through against roadmap pressure, and the beats are those clauses. Answer slot: if you held the conversation with the people behind the pressure, say what you proposed and what was agreed, in your own words; if it was settled another way, or not by you alone, say so plainly and return to the sentence. Stay with what happened; do not make the disagreement bigger than it was | Peer and cross-functional panelists use disagreement stories to price how you behave under tension (F7). VAL because it scores behavior, EXP-adjacent because it rests on your own sentence |
| E3 | "What would you need from product to run two squads well, and what would you bring them?" | JD | [generic] | A short list of needs and a short list of offers, both principles: clear priorities with the reasoning, early warning on hardware dependencies, and in return honest estimates and a say in sequencing. Say the reciprocal half first. It makes no claim about your past | The PM is pricing partnership fit (F7); reciprocity answers "does this hire reduce my load" |
| P1 | "What was actually in the reliability quarter, and which part of the drop came from which part?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence at its own scope. Answer slot: if you chose what went into the quarter, say what and why, in your own words; if you did not, or you do not know which part moved the figure, say so plainly and return to the sentence. Name the assumption behind the 60% you would defend least before they do, if you know one; if you do not know how it was counted, say that | Staff engineers will want the mechanism behind the headline number. EXP because it scores attribution; the question presupposes only the quarter and the figure, both in your sentence |
| P2 | "Your engineers will know more than you about how the devices work. How do you review their designs?" | CASE | [generic] | Say plainly what you do not know and how you would work around it: questions that need no domain depth (what fails first, what is reversible, how it rolls out, who is paged), reliance on the staff engineers for the technical bar, and your own role as the person who keeps the decision honest about tradeoffs. Make no claim to device knowledge: your material does not carry any (F2) | Staff engineers are checking whether a manager with no stated domain history will be a drag. CASE because it is a live role problem |
| P3 | "What do you screen for when you run a hiring loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say the sentence: you run the hiring loop for backend roles. Answer slot: if you set or shaped the criteria, say how, in your own words; if the criteria were set by others, or were not written down, say so plainly and describe the loop you run. On the figure, say plainly whether you conducted about 40 interviews or the loop did | Staff engineers will interview candidates for the team, so how you hire is how their next colleague arrives (F4). EXP because it scores what you actually ran |
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold with a candidate story: your sentence is a decision made against roadmap pressure, and its beats are the clauses it states. Answer slot: if there was a conversation with leadership, say who it was unpopular with and what you said, in your own words; if the pressure never reached that level, or the call was shared, say so plainly and stay with the sentence. If no such time comes to mind, say so, then give the nearest thing your material carries | A persona stem used as an open prompt; the PM probes how hard truths land. VAL because it scores behavior, and the reliability quarter is the only decision your material carries |
| G2 | "Tell me about a time you and a product partner disagreed on priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Open prompt from the role's partner-with-product line. Selection criteria: a named stake, a moment you held your position or changed it for a reason, and a working relationship intact afterward. The nearest thing your material carries is the reliability quarter against roadmap pressure; say who the pressure came from only if you know. If no such time comes to mind, say so plainly, then say how you would handle it | The PM is the cross-functional partner for F7. VAL because it scores disagreement style |
| H1 | "What have you been reading or trying out lately in industrial IoT or device management?" | JD | [grounded] | Answer slot: if you have read or tried anything in this space, say what and what you made of it; if you have not, say so plainly and say what you would start with. A real answer about a small thing beats a performed one. Your material carries no domain history (F2), so claim none | A conversational stem on the role's one stated domain. JD because device management is the role's stated field; casual register, scored |

### Reverse questions (Round 2)

| # | Question | Why it lands |
|---|---|---|
| S1 | "What could a new manager do in the first month that would genuinely help your work?" | The reciprocity question for the staff engineers: it makes you a load-reducer, not a load |
| S2 | "How does a disagreement between a staff engineer and a manager usually get settled here?" | Shows you want the real norm before you set one, and tests the seam you offered in E1 |
| S3 | "What technical decision from the last year would you make differently?" | Invites honesty from technical peers and tells you where the team's weak spots are |
| S4 | "How does product learn what hardware can and cannot do, and when?" | For the PM: aims straight at the seam where your F6 gap sits, as curiosity |
| S5 | "What do you most want the manager of these squads to understand about the customer's deployments?" | Shows interest in the product reality, and gets you a real list to learn from |

## Round 3 — the following Monday, VP Engineering (30 min)

The recruiter described this round as "values and leadership philosophy". At 30 minutes, expect four or five questions: prepare J1, I1, I2 and J2 first. Company values were not available (see Sources), so the values questions are themed on the recruiter's own words and the persona stems, and there is no values cheat sheet in this pack.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario questions about leadership and about what you do when values collide with delivery | Top weight. The recruiter's own words name the round "values and leadership philosophy" | Two principles you act on, each tied to a decision; selection scaffolds with an honest branch where nothing comes to mind |
| Pressure | Time-boxed answers, "sixty seconds", "how much of that was you" | Mid weight. Skip-level prior, and a 30-minute round time-boxes by itself | Pause, restate, hold your position through two follow-ups, concede specifically, never fold on the core |
| Case/Strategist | Altitude questions: what this team is for, when to say no | Mid-low weight. Skip-level prior is strategy-heavy, but no company strategy research was available, so these stay role-level | Hypothesis aloud, labeled as a hypothesis; ask the VP to correct it |
| Conversational | A closing "what draws you to leading engineers" | Low weight | Answer from your own sentence; keep it short |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What is your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Selection scaffold: two principles you actually act on, each tied to a decision where it cost you something. The pack does not supply your principles; they are yours to state. The one decision your material carries is the reliability quarter pushed through against roadmap pressure, and its beats are those clauses. Answer slot: if a principle sits behind that decision, say it in your own words; if you cannot name one, say so plainly and stay with the sentence | The recruiter's own words raise this question (F8). VAL because it scores whether your behavior demonstrates a stated philosophy |
| I2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a named customer stake, a metric you let slip or overrode, and a relationship still intact. Your material carries no sentence about customers, so the pack builds no story. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it. Do not stretch the reliability quarter into a customer story | A persona stem used as an open prompt; the VP round is a scored values conversation. VAL because it scores behavior against a published-style value, and `[generic]` because nothing quoted carries it |
| I3 | "You've told us you've never managed managers. How does your leadership change as the teams you lead get larger?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" and "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Plain acknowledgment first: "I've never managed managers." Then the pack's observation, which is not words for you: the role as described has you leading 11 engineers directly, so this is more likely a growth question than a gate. Say what you would want to learn about leading at that scale, as a plan, and what you do now as a team lead of six, in the quote's terms. Do not claim management you did not do | Skip-level interviewers probe the next level up (F1). VAL because it scores how you describe your own leadership growth |
| J1 | "Sixty seconds: why should I hire a team lead from a payments company to lead two squads in industrial IoT?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I run our hiring loop for backend roles — about 40 interviews last year" and "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" and "I've never managed managers and never owned a hardware-adjacent roadmap" | Time-boxed to sixty seconds. Hold with only your sentences: nine years in engineering, three as a team lead of six, you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Concede specifically and before they ask: "I've never owned a hardware-adjacent roadmap." Then the ramp as a plan. Hold through two follow-ups by returning to those sentences, never by adding to them | The capstone pitch, and the Pressure persona's favorite. JD because it scores fit to the role; the concession is the B1 concession, reused |
| J2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, restate, and answer at the sentence's scope: the drop came after you pushed the quarter through. Answer slot: say plainly which parts were yours and which were others', in your own words; if you do not know how the figure was counted, say so. Hold through the second follow-up without adding detail the sentence does not carry | A pressure stem on the one figure in your material; EXP because it scores attribution under pressure (D1 and P1 are the same figure in other styles) |
| K1 | "What is the job of a device-management team in a company like ours, as opposed to a payments team?" | CO | [generic] | Say your hypothesis aloud and label it as one: reason from the role description you were given (device-management services, partnering with hardware and product on roadmap), say plainly what you do not know about Larkfield, and invite the VP to correct you. Make no claim about the company beyond the role description | A strategy-altitude question; CO is `[generic]` here because company research was unavailable, and a labeled hypothesis is the honest form |
| K2 | "With eleven engineers and a hardware partner, what would make you say no to a request?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Criteria, not stories: what the request costs, who bears it, what it displaces, and what you would offer instead. The one saying-no decision your material carries is the reliability quarter against roadmap pressure, at the sentence's scope. Answer slot: if you said no to someone and it cost you something, say what, in your own words; if the call was not yours to make, say so plainly and stay with criteria | The role includes saying no on the roadmap; the sentence is the nearest evidence. CASE because it is framed as a live decision |
| L1 | "What draws you to leading engineers rather than being one?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: your material carries the three years as a team lead of six; the pull toward it is yours to say. Say what you found in those three years in your own words, and if the pull is partly the next scale, say so plainly. Keep it to two sentences | A low-pressure closing question that is still scored for honesty and motive |

### Reverse questions (Round 3)

| # | Question | Why it lands |
|---|---|---|
| V1 | "What is the leadership behavior you most want to see in managers here, and rarely get?" | Invites the VP's philosophy and gives you something concrete to calibrate to |
| V2 | "When the roadmap and reliability pull in different directions, how do you want a manager to handle it?" | Aims straight at your reliability-quarter decision, as a question, with no claim attached |
| V3 | "How do the company's values show up in a decision you made recently?" | Turns a values round into a conversation, and gets a real example to compare with your own |
| V4 | "How is the engineering organisation expected to change over the next year, and where does this role sit in it?" | Strategy altitude from a candidate who could not research it: you ask rather than assert |
| V5 | "What would a strong first six months look like from your seat?" | Gets the VP's definition of success on the record, and shows you are planning |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "Lead two squads building device-management services" (scale) | B2, A3, R2 |
| "Lead two squads building device-management services" (domain) | A2, P2, H1, K1 |
| "own delivery, hiring and growth for 11 engineers" (delivery) | A1, E2, K2 |
| "own delivery, hiring and growth for 11 engineers" (hiring) | P3 |
| "own delivery, hiring and growth for 11 engineers" (growth) | B3, I3 |
| "partner with hardware and product on roadmap" (hardware) | B1, A1, J1 |
| "partner with hardware and product on roadmap" (product) | E2, E3, G2 |
| "values and leadership philosophy" | I1, I2, I3, G1 |
| Headline figure on your material (60%) | D1, P1, J2 |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed a team of six, or managed engineers | Inflated form of F1: your sentence says team lead | F1's quote at its own scope, "Three of my nine years in engineering have been as a team lead of six". The limit is the pack's observation: your material says team lead, not that you managed people |
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope. A probe on scale is answered inside the team of six |
| Has managed managers | Negative you stated, F6 and I3 | The plain acknowledgment: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The F6 slot asks only about working alongside hardware teams |
| Owned delivery for the team | Inflated form of F3: your sentence says you pushed a reliability quarter through | F3's quote at its own scope. The limit is the pack's observation: your material says the quarter, not who answered for delivery. The slot stays inside the quarter |
| Cut on-call burden by 60% | Inflated form of the figure in F3: your sentence says it dropped after you pushed the quarter through | F3's quote at its own scope. The limit is the pack's observation: the sentence gives sequence, not cause |
| Owned hiring for a team | Inflated form of F4: your sentence says you run the loop for backend roles | F4's quote at its own scope. The slot asks which of the interviews were yours |

## Sources

Provided documents: your message (the role description, the three-round schedule, the recruiter's description of round 3, and four sentences about your background). No full job description and no CV file were provided. The loop was established by your own words (three sessions, who runs each, what each holds), so no archetype fallback was used.

Searches sent, all three refused by the host's permission check, none retried:

| Query | Result |
|---|---|
| Larkfield Systems industrial IoT company values | refused |
| Larkfield Systems interview process engineering manager | refused |
| Larkfield Systems strategy news industrial IoT device management | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have fed a values cheat sheet and the Round 3 themes; with no values in hand there is none, and Round 3 rests on the recruiter's words and persona stems |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked the round formats; the persona weights rest on your description of the three rounds |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current strategy; K1 and the case questions stay generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you pasted fixes the requirement column; a full JD would add rows, which the upgrade menu offers |

## Upgrade menu

- The full job description → every requirement row currently quoted from your one-paragraph role description gets the JD's own wording, and mid-list items that are not in the paragraph (a named tool or method) get their own questions
- Your CV, or any sentences about your work → rows F2, F3, F5 and F7 move from discovery toward your own words, and the question banks get more stories mapped to your sentences in place of selection scaffolds
- Your answers to the answer slots in F1, F4, F5, F6 and F7 → each of those rows regenerates around what you actually did, and the matching questions (B2, B3, P3, B1, E2) get story-mapped guidance
- Interviewer names or LinkedIn profiles → an interviewer read per person, persona weights per panelist, and a reverse question tied to each interviewer's own path
- What the recruiter says about Tuesday and Thursday, or any announced case, presentation or topic list → coverage for any pre-declared deliverable, and re-weighted banks
- The company's published values page, pasted → a values cheat sheet for Round 3, mapping each value to one of your sentences or to a selection scaffold
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs the search permission this host refused) → a grounding brief on strategy and a current-strategy CO or CASE bank for Round 3
- A working-style assessment, if you have one → a delivery-coaching table keyed to question IDs
- A tuesday-dossier.md from the job-underwriter skill → verified evidence, a named highest-ROI objection and prohibited claims arriving ready-made; never a prerequisite
