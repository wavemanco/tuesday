I'll read the reference files the skill requires before building the assessment.
**Yes, go for it, on conditions. Status: `conditional_go`.** The conditions are R1 (confirm you're UK-based), RR1 (verify Brindlemoor and the live posting) and the framing of R10 (below).

**Fit ledger**

- `hard_gate` — unclear: R1 (UK-based, fully remote)
- `must_have` — direct: R2, R3, R4, R5a, R6a, R7 · unclear: R5b (Monitor rating models), R6b (Design price tests)
- `important` — adjacent: R8 (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R5b and R6b each turn on one detail your wording leaves open. R10 is adjacent, not direct.

**Opportunity ledger.** The duties are concrete (RR5). The employer is unverified (RR1), the pasted JD states no pay (RR2), and reports and decision rights are unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) you confirm you're UK-based (R1); (3) the pet gap is framed as adjacent, never as pet experience (R10, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product. Its existence is not established | `[grounded]` JD as you pasted it; the search was refused (see Evidence status) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Her public footprint was not researched | `[grounded]` your message |
| Requirements split | 4+ years pricing or actuarial analytics, SQL and Python, GLM and presenting to underwriting or actuarial leads are listed as requirements. Insurance experience is "a plus" | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| People management | The JD states no management requirement and no reports. Your "never managed anyone" is not a gap against any row | `[grounded]` JD silence |
| Scope read | Reads as an individual-contributor senior role on one product | `[inferred]` from the title and the JD's silence on reports |
| Market calibration | Not established. The role-family sweep did not run, so I offer no title norm or pay band rather than fill one from memory | `[grounded]` Evidence status below |
| Unknowns | Salary, reports, decision rights, team size, first-year outcomes, and whether the posting is live | `[grounded]` JD silence |
| Contradictions | None visible in the JD as pasted. It could not be checked against a careers page | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | The JD says "Fully remote (UK)". A UK motor insurer suggests but doesn't settle that you're UK-based with the right to work. You've stated no constraints, so there is no statement of one to grade | `[grounded]` JD; `[inferred]` UK base from "UK motor insurer" | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | "5 years pricing analytics at a UK motor insurer" meets the length. It's self-reported with no CV inspected, so it stays `medium` | `[grounded]` your background | CV dates will confirm |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is stated use. Depth isn't stated, so expect a probe on "strong" | `[grounded]` your background | A sanitized script or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book" is specific. The scope is one book, and no artifact has been inspected | `[grounded]` your background | A sanitized model spec, factor-review deck or validation note would raise to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same claim as R4. It's a separate row because the JD lists it as a duty. Scope is the young-driver book | `[grounded]` your background | None; shares R4's artifact |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained". Monitoring (tracking against expectation, refresh triggers) isn't stated. It's `low`, not `none`, because maintenance is a concrete thread | `[grounded]` your wording | G2 |
| R6a | Run price tests with underwriting | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team" is specific and recent. No readout has been inspected | `[grounded]` your background | A sanitized test readout would raise to `high` |
| R6b | Design price tests | must_have | unclear | low | discovery | "Ran" doesn't say who set the design: test and control, sizing, success measure. I resolve that downward and don't assume it | `[grounded]` your wording | G3 |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which matches the audience | `[grounded]` your background | A sanitized review deck would raise to `high` |
| R8 | Recommendations for underwriting and product | important | adjacent | medium | discovery | The underwriting half is backed by R6a and R7. Work with product stakeholders isn't stated, so I take the lower band | `[grounded]` your background | G4, asked after the higher-ranked questions |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | None |
| R10 | Pet-insurance product knowledge (implied by "our pet-insurance product", not a listed requirement) | preferred | adjacent | medium | transferability | You've never worked on pet. Your rating-model and price-test method carries over. Pet-specific rating factors and claims patterns appear nowhere in your background. The JD frames insurance as "a plus", so this is preferred-tier | `[inferred]` from the JD's product mention; `[grounded]` your statement | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R10, preferred) | transferability | Carries over: GLM and price-test method. Limit: no pet rating factors or claims exposure stated. Strengthener: a short proposal note (W1) | It's the most visible difference between your background and the product | Any pricing, claims or analytics work on a non-motor line; any pet-related project, however small | A sanitized note or project excerpt | `[inferred]` bridge from your motor work; `[generic]` that a change of product line is a common interview probe |
| G2 | Model monitoring (R5b, must_have) | discovery | "Maintained" is stated, but monitoring isn't | A must-have row at `unclear`; the answer could move it to `direct` | Tracking actual vs expected, drift checks, refresh decisions, a monitoring pack | A monitoring dashboard or review note | `[grounded]` your wording |
| G3 | Test design (R6b, must_have) | discovery | You ran 14 tests; who designed them isn't stated | Same as G2: a must-have that could move to `direct` | Choosing test and control, sizing, defining the success measure, reading significance | A sanitized test plan or readout | `[grounded]` your wording |
| G4 | Product-side recommendations (R8, important) | discovery | The underwriting side is evidenced, the product side isn't | Half of the JD's recommendation duty | Presenting a price change to a product or proposition team | A paper or deck for that audience | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. This is unchecked, not negative, because the search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and say who I'd be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | No salary figure in the JD as pasted | The figure may sit below what a senior role pays elsewhere, or may simply not be published. I have no band to test it against | `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Reports and growth path unstated | unknown | — | "Senior Pricing Analyst … Own pricing analytics" | The role may be purely individual-contributor, or may be expected to grow a team | `[inferred]` from the title and the JD's silence on reports | Does this role have direct reports now, or is one expected? | unresolved |
| RR4 | Decision rights unclear | unknown | — | "turn the results into recommendations for underwriting and product" | The wording implies sign-off sits with underwriting and product. The role may be accountable for models without authority over rate changes | `[inferred]` from "recommendations" against the JD's silence on authority | Which pricing decisions does this role make itself, and which does it recommend? | unresolved |
| RR5 | Duties named concretely | positive_signal | — | "build and monitor rating models, design and read price tests" | The work is defined, not generic | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver book." Keep "young-driver book" as written | R4, R5a. Your sentence, unchanged in scope | `[grounded]` your background | resume_edits_pending_approval |
| E2 | CV line: "Ran 14 price tests last year with the underwriting team." Don't write "designed" until G3 is answered | R6a, R6b | `[grounded]` your background | resume_edits_pending_approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting." Don't write "actuarial" or "product" | R7, R8 | `[grounded]` your background | resume_edits_pending_approval |
| P1 | Positioning: lead with GLM model, price tests and the quarterly review. On pet, say plainly that you haven't priced it and that the method is what you'd bring from motor | R10, G1 | `[grounded]` your statement | pending your approval |
| W1 | Optional one-page note on how you'd adapt your approach to a pet book, labelled a proposal and not experience | G1 | `[inferred]` bridge | pending your approval |
| Q1 | In interviews, ask the verification questions of RR1 to RR5 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the posting is live on Brindlemoor's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | If asked about managing people, say plainly that you haven't | The JD asks for none | `[grounded]` your statement | pending your approval |

Nothing in this plan is final until you approve it. That covers the CV lines (E1 to E3), the positioning advice (P1), the work sample (W1), the interview questions (Q1) and the actions (A1, A2).

## Evidence status

Verified: none yet. Your background is self-reported, so it is leads for verification, not proof.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search sent and refused (permission not granted). It would have settled whether Brindlemoor exists as described and whether the posting is live (RR1, role reality's Organization row) |
| 2. Role-family sweep | unavailable | Search sent and refused. It would have given the market-calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | unavailable | Search for Odile Varga sent and refused. It would have informed the scope read and which story P1 leads with |

## Dossier offer and upgrade menu

I can write all of this to `tuesday-dossier.md` for you to carry forward, if you'd like.

- **Search permission, or the pasted careers-page text or a posting link:** settles RR1, gives a pay band for RR2, and covers Odile Varga's public professional footprint for the scope read.
- **Your CV:** checks the dates behind R2 and shows which rows the CV buries.
- **Your pay floor and any other non-negotiables:** turns the hard-gate checks from unknown into real ones.
- **A sanitized model spec or factor review, test readout, review deck, or code sample:** raises R3, R4, R5a, R6a and R7 from `medium` to `high`.
- **Answers to G1 to G4:** G2 and G3 could move R5b and R6b to `direct`.

## Questions

**Q1 (R1):** Are you UK-based with the right to work in the UK? A yes or no is enough.

**Q2 (G3):** Of the 14 price tests, who set up the design (what was tested, the control, how big, what counted as a result)? Which part was yours and which was underwriting's?

**Q3 (G2):** After the young-driver model went live, what did you track to know it was still working? What would trigger a refresh, and who ran that?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.