I'll read the reference files before building the ledger.
I've drafted the ledger for Tessellate's Senior Backend Engineer role, Priya. I only had your prose, not the CV file. So "Current line" below is your own sentence as you pasted it, and I treated it as self-report. Nothing is applied. Every row waits for your approval.

The CV already covers most of the role: Go, p99 latency, incident command and onboarding are all there. What it mostly needs is reordering, so the strongest evidence comes first. Three requirements aren't evidenced yet (product partnership, distributed systems, designing and shipping services), and they are laid out below.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your pasted CV | pending your approval |
| E2 | Current role | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet under the current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your pasted CV | pending your approval |
| E3 | Current role | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in the ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your pasted CV | pending your approval |
| E4 | Current role | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Line 1: "On-call rotation every fourth week for two years." Line 2: "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your pasted CV | pending your approval |
| E5 | Current role | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year; pair with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your pasted CV | pending your approval |

If you approve the rows, the bullet order under your current role is E2, E3, E4, E5.

- **E4 splits the sentence on purpose.** Your sentence doesn't say the six incidents happened inside the two on-call years, and a joined line would imply they did.
- **E3 keeps 40k requests/minute attached to one service.** It does not become a figure for the pipeline.
- **E5 keeps your words, "onboarding" and "pair".** It does not become "mentored".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts "7 years" first. Your CV doesn't say all 7 were backend, so the line says "Senior Software Engineer", not "backend". | `[grounded]` your CV states the 7 years and the ledger-pipeline services; it doesn't say all 7 years were backend work |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 puts "Go and Rust daily for 4 years" in the summary. Your CV doesn't say which of your services are in Go (see C3). | `[grounded]` your CV states daily Go use but not which services run on it |
| R3 | Go services at high request volume | important | `surfaced_by_edit` | E3 | `[grounded]` the 40k requests/minute figure is yours; whether that counts as "high volume" is the reader's call |
| R4 | Design and ship services | important | `not_evidenced` | See C3. "Own" says what you hold now, not that you designed or shipped it. | `[grounded]` your CV says "own", not "designed" |
| R5 | Drive down p99 latency | important | `surfaced_by_edit` | E2 | `[grounded]` your CV |
| R6 | Distributed systems at scale | must-have | `not_evidenced` | See C2. Kafka and gRPC are in your tools list, and a tool listed is not a tool owned. | `[grounded]` your CV lists the tools but doesn't say how you used them |
| R7 | Strong incident response | must-have | `surfaced_by_edit` | E4, line 2 | `[grounded]` your CV |
| R8 | Own on-call for your services | important | `surfaced_by_edit` | E4, line 1. Your CV says you're on a rotation, not that it covers your own services. | `[grounded]` your CV |
| R9 | Experience mentoring (mid-level engineers) | must-have | `surfaced_by_edit` | E5. Your CV describes onboarding new hires and doesn't give their level. | `[grounded]` your CV |
| R10 | Partner with product on roadmap sequencing | important | `not_evidenced` | See C1. Nothing in your CV touches this. | `[grounded]` your CV is silent on product work |

## Recall prompts for the gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Partner with product on roadmap sequencing | important | Services, latency, incidents and onboarding. Nothing about working with product or deciding what ships first. | The posting lists it as a duty of the role, and your CV currently gives no sign of it. | Arguing for the cache-layer rework ahead of other work; negotiating a deadline or scope with a product manager; deciding what to cut when the ledger pipeline got a new requirement | A planning doc, a roadmap ticket, a design review thread | `[grounded]` the CV has no product-facing line; `[generic]` roadmap partnership is a standard senior-role duty |
| C2 | Distributed systems at scale | must-have | Three ledger-pipeline services, a service at about 40k requests/minute, and Kafka and gRPC in the tools list. It doesn't say how the services talk to each other or what had to stay consistent. | It's a must-have, and "ledger pipeline" plus a tools list is the only evidence now. | Consistency or ordering problems across services; what happens when a Kafka consumer lags or a downstream call fails; a retry, idempotency or failover decision you made | An architecture diagram, a post-incident review, a design doc | `[grounded]` what the CV does and doesn't say; `[generic]` must-haves with thin evidence are the likeliest to be probed in screening |
| C3 | Production Go in your services, and designing and shipping them | must-have | "Go and Rust daily for 4 years" and "own three services". It doesn't say which services are in Go, or whether you built them or took them over. | Production Go is a must-have, and "design and ship" is the first duty listed in the role. | The balance-read service rebuilt in Go; a service you wrote from the first commit; one you took over and then reworked | A repo, a design doc, a launch note | `[grounded]` what the CV does and doesn't say; `[generic]` interviewers usually ask what you built versus what you inherited |

## Not written, and why

- **"Mentored mid-level engineers"**: you onboard new hires and don't say their level. The posting's word is "mentor", and yours is "onboarding" and "pair".
- **"Designed and shipped Go services"**: "own" doesn't tell us who built them, and your CV doesn't say which services are in Go.
- **"Distributed systems at scale"** and **"high-throughput services"**: these are the posting's phrases for work your CV doesn't describe that way. 40k requests/minute is your figure. Whether it counts as "at scale" is for the reader to judge.
- **"Owned on-call for my services"**: you're on a rotation, and your CV doesn't say it covers only your own services.
- **"Led incident response"** or **"ran an incident program"**: you were incident commander on six incidents, which is a different thing.
- **"Reduced latency across services"**: your result is for one path, the balance-read path.
- **"Six incidents over two years"**: your sentence doesn't tie the two together, so E4 keeps them apart.
- **"Partnered with product"** or **"shaped the roadmap"**: nothing in your CV supports it.

## Parse-safety check

I couldn't run any of the six checks (multi-column layout, tables and text boxes, images and skill bars, content in headers or footers, non-standard headings, file type), because I have your text and not the file. Contact details in a header or footer are the one worth checking by hand.

## Upgrade menu

- **Your CV as a .docx or text-layer PDF**: lets me run the parse check and quote your real bullet wording in the "Current line" column.
- **Older CV versions**: may hold evidence on C1 to C3 that your current CV dropped.
- **A repo link, design doc or Datadog dashboard screenshot for the p99 work**: gives me something inspectable behind the 380ms to 95ms figure, and may help C2 and C3.

## Questions

C1 — Have you ever argued for, negotiated or sequenced work with a product manager, for example getting the cache-layer rework prioritised? If so, what happened?
C2 — How do your three services communicate, and have you handled consistency, ordering or failure between them (Kafka lag, retries, idempotency)?
C3 — Which of your three services are written in Go, and did you design any of them from the start?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.