I'll read the reference files the skill points to before drafting.
The pack is written. I've checked it against the format rules and I'm sending it now.

Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-canned-826e6bf5/a3641d12-6be2-491c-acae-51112d02dbdb/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions, a fit snapshot, a values sheet, reverse questions and a list of claims it won't coach.

I assumed Tobias is your hiring manager, because Saltmarsh's careers page describes the interview as "a live-incident tabletop on a simulated outage during a live event, then a values conversation," with no take-home. The weights lean on that: a tabletop bank first, then values, then the Skeptic.

The question to rehearse hardest is C1, "Which part of this job would you be weakest at on day one?" Your message gives it two stated gaps (no team led, no in-app purchases), and the company's August 2026 announcement moves both titles to a season-pass model.

The pack found Tobias's GDC 2026 talk and the announcement only as one-line search summaries. I didn't open those pages, so read them tonight if you can.

Say the word and I'll play Tobias on the tabletop (A1) or the Skeptic on C1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say anything about what Friday's hour will focus on? If he's not your manager, every bank reweights.
Do you want a deeper research pass on the Larkspur announcement and Tobias's talk (up to 6 more searches and 2 more fetches, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, because the company's careers page puts the single 60-minute session with the hiring manager (see Sources). If he is not your future manager, the persona weights below change.
**Round:** Friday, 60 minutes. Built on the assumption that Friday is tomorrow (today is Thursday 5 November 2026).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: does what you claim survive scrutiny, and what was actually yours |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth, thinking at the company's altitude |
| CASE | Hypothetical or live problem: structure and reasoning on a problem from the actual role |

A question that fits two types carries its primary type, and the rationale names the second.

## Prep triage

Everything here is ordered. Do these, in this order, and stop.

| Order | What | Where |
|---|---|---|
| 1 | Say the weakest-part answer aloud three times, with the three follow-ups, until the acknowledgments sound boring rather than apologetic | C1, then C2 |
| 2 | Run the tabletop twice against a timer, thinking aloud: clarify, objective, who you pull in, what players hear, the decision, what gets written down. Then read your first player message out loud | A1, A2 |
| 3 | Pick two real stories for the values half. B3 and B4 are the two your own sentences already carry; for B1 and B2, choose a true instance or rehearse the honest branch | B3, B4, B1, B2 |
| 4 | Time your 90-second journey | F1 |
| 5 | Choose three reverse questions | Reverse questions |

Everything else is insurance.

## Fit snapshot

Evidence cells hold your own words only. Where a cell says what the pack observes, that is the pack's analysis, not words for you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The sentence gives four years as an associate producer and does not say how much of that was live-service work. Answer slot: the JD asks for 3+ years of live-service producing, so expect a probe on how long the game was being updated while you were there and what your part was. Say it in your own words; if the live-service part is fewer years than four, say the number plainly and stay with the years the sentence states |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, content drops, your main title, the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | The sentence is one title and content drops; the JD is two titles and live events. The words stay at the sentence's own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The step to two titles is not in your material and the pack does not write it for you |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | The calendar sentence does not say which teams a weekly drop touched. The JD's verb is coordinate, and the pack reads that as a different thing from leading a team, which your message says you have not done. Answer slot: expect a probe on who the weekly drop involved. If design, art, engineering or community were part of it, say which and what you needed from each; if only some were, or none, say so plainly and stay with the calendar |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | The sentence is presenting monthly retention numbers, a different thing from a review after an event. The words stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's KPI line makes a probe on where the numbers came from likely. If you chose or calculated any of what you presented, say which and how, in your own words; if the numbers came to you and you presented them, say so plainly and stay with the presentation |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | Your strongest row. Lead with it in the sentence's own terms: you wrote it, and QA still uses it. The sentence does not say how each release was run through it, so the words stop there |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | Lead with it as stated: monthly, retention numbers, the studio head. Expect a probe on which measures were in them, since nothing inspected sits behind the line |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The sentence shows a written document that a team still uses; it does not show how clear the writing was or that anyone said so. Answer slot: if a written piece of yours drew comments from the people who used it, say what they said; if none did, say so plainly and stay with the checklist |
| F9 | How events connect to in-app purchases: a role-family expectation, not a JD line | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The JD does not mention purchases; the pack raises the row because the company's August 2026 announcement describes a season-pass model (Sources) |

## Reading the interviewer

Public professional footprint only. Both facts below come from one search-result summary each; the pages were not opened.

| Fact | Provenance | What it means for you |
|---|---|---|
| Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, gave a GDC 2026 talk titled "Patch Notes Are a Promise"; his argument is that a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Precision about what was built versus what was hoped is likely to be his lens. It matches the published value "Ship the Patch Not the Promise", so A2, B2 and D2 are where it will show. Refer to the talk only as far as you have actually read or watched it |
| He was previously a QA lead at a console studio | [grounded] | Release checklists are native territory for him, so F6 will be probed closely and in detail. Shared vocabulary is the opening, not shared background: "Wrote the release checklist our QA team still uses" (F6) |
| Not established: whether he is the hiring manager for this role | [grounded] | The persona weights assume he is. The first question in the message that came with this pack asks you to confirm |

## Persona table

The loop is documented by a loop source (the careers page), so the weights follow the named session rather than an archetype: one 60-minute hiring-manager session, a live-incident tabletop first and a values conversation after it.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop on a simulated outage during a live event, plus calendar and checklist problems | High. The careers page names the tabletop as the first half of the hour | Clarify, objective, who you pull in, what players are told, the decision, what is written down. Think aloud. Challenge one premise respectfully |
| B. Values / Behavioral | The values conversation, keyed to Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener | High. The careers page names a values conversation as the second half | One story or honest branch per published value. "We" for context, "I" for contribution |
| C. Skeptic | Probing the gaps: in-app purchases, no team led, associate title, one title versus two | Medium-high. The hiring-manager prior is Case plus Skeptic, and your message gives it material (F9, F4, F1) | Rehearse C1 until it is boring. Acknowledge what you stated plainly, bridge only from your own sentences, add a plan said as a plan |
| D. Data-Driven Prober | Retention numbers, the post-event review | Medium. The JD names retention metrics and KPIs (F5, F7). The pack found no sign that he describes himself as data-driven | Know what you can and cannot say about how the numbers were counted, and say so plainly when you do not know |
| E. Pressure | Time-boxed or interrupting follow-ups inside the tabletop | Low. No source documents time-boxing; a live-incident format can feel like it | Pause, restate, hold the position the sentences carry through two follow-ups, concede specifically |
| F. Conversational | An easy opener; "walk me through your journey" | Low-medium. The recruiter call is a separate step on the careers page, but openers inside the hour are still scored | A timed 90-second arc built from your own sentences |

A Peer Evaluator bank is left out: the documented loop has no peer session.

## Question banks

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Saturday, an hour into a weekend event. Players report event rewards aren't arriving and the reports are climbing. You're the producer on call. Talk me through the first hour." | CASE | [inferred] | Think aloud in this order: what you need to know first (what is affected, how many players, since when, whether it is getting worse); the objective (stop the damage, then restore trust); who you pull in and what you ask of each; what players hear and when; the decision on pausing or extending; what gets written down for the review. Let the first player-facing decision lean on the published value: "when the calendar and the players disagree, the players win". Name one premise you would challenge. The question asks about no past, so the guidance makes none | The careers page describes the tabletop as a simulated outage during a live event; this scenario is a practice stand-in for it, not the real prompt, hence inferred. CASE because it scores structure under a live problem |
| A2 | "Write me the first message to players. Read it out as you'd post it." | CASE | [inferred] | Say only what is confirmed: what players are seeing, that you know, what is being done, when the next update comes. Promise no fix time unless one exists, in line with the published value "we announce what is built, not what is hoped". Read it aloud in under thirty seconds, then say what you left out and why. The question asks about no past, so the guidance makes none | Covers the JD's written-communication line (F8) in a live form and meets the interviewer's public theme (Reading the interviewer). A practice stand-in for the tabletop, hence inferred. JD content, CASE delivery |
| A3 | "From January 2027, Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar. What do you need to know before you plan the first quarter of it?" | CO | [grounded] | Clarify before structuring: what the season pass is meant to move; how events relate to the pass; what each title's event cadence is today; who owns what once a single live-ops group forms; what the review will report. Use the announcement's own terms (season-pass, shared calendar, single live-ops group) and say what you have read and what you have not. Challenge one premise respectfully. The question asks about no past, so the guidance makes none | Project Larkspur is the company's August 2026 announcement (Sources; summary only, the page was not opened). CO because it tests homework at the company's altitude; CASE in delivery. The pack found no strategy detail beyond the summary |
| A4 | "Thursday morning. Design wants the event live tonight, and QA says the checklist isn't green. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Clarify what is red, how serious it is and what that checklist item protects. Lay out the options (hold the date, cut scope, ship with the failure named and watched) and decide by who is affected, leaning on "Players Before Plans" and "Leave the Build Greener". You may mention the checklist at the sentence's own scope: you wrote it, and QA still uses it. Add nothing about how it was enforced | The JD's checklist line (F6) and the interviewer's QA background (Reading the interviewer) point here. CASE because it is a live trade-off; JD content |
| A5 | "Two titles want the same Saturday for their events, and art can only finish one. Who decides, and how do you get there?" | CASE | [generic] | Clarify what each event is for and what slipping costs each; whether either can move a week; who holds the authority to decide (ask, don't assume). Bring the trade-off with a recommendation to that person. Note that from January a shared calendar turns this into a standing calendar problem. The question asks about no past, so the guidance makes none | JD coordination line (F4) as a live problem. Generic because it is a pattern for the problem, not a fact about this employer. CASE with JD content |

### B. Values / Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] | Selection scaffold: pick a time a schedule you were holding collided with something players experienced. It needs a named stake, the decision you made or influenced, and what happened to the date. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The published value "Players Before Plans" (values page). Open prompt, so the theme comes from the value. VAL because it scores one specific value |
| B2 | "Tell me about a time you made sure what was announced matched what was built." | VAL | [grounded] | Selection scaffold: pick a time something was about to be described before it was finished, or described more broadly than it was. It needs what was going to be said, what was true, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The published value "Ship the Patch Not the Promise" and the interviewer's public theme (Reading the interviewer). Open prompt, theme from the value |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F6: you wrote the checklist, and QA still uses it. Those are the beats the sentence states; tell them in your own words. Answer slot: the published value is about leaving the checklist better than found, so expect a probe on what the checklist changed. If it replaced something or fixed something that had been going wrong, say what and what part was yours; if it was written fresh, or at someone's request, or you cannot point to what it changed, say so plainly and stay with "wrote it, and QA still uses it" | The published value "Leave the Build Greener" names the checklist directly. F6 is the evidence and the likeliest place to be probed. VAL because it scores that value |
| B4 | "Tell me about a time you had to give leadership numbers they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Map on F7: the monthly retention presentation to the studio head is the setting, and that is all the sentence states. Answer slot: the question asks for an unwelcome message. If there was a month the numbers were unwelcome, say what the number was, what you said and what happened; if there was no such month, or you were passing along numbers someone else had drawn, say so plainly and describe how you presented | Persona stem for unpopular truths, tied to "Ship the Patch Not the Promise". F7 is the only setting your material carries. VAL because it scores honesty under pressure; EXP-adjacent |

### C. Skeptic (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | **Highest-ROI prep in this pack.** Choose the gap you would name first and say it plainly: "I've never worked on a game with in-app purchases." Hold then concede through three follow-ups. (1) "Why take that risk?" Return to what the sentences carry: you ran the weekly content-drop calendar for your main title for two years, and you wrote the release checklist QA still uses. Add nothing to them. (2) "How soon would you be useful on a season-pass event?" Concede that you cannot give a date; say the first thing you would learn and who you would ask, as a plan in your own words, and promise no speed. (3) "Have you managed anyone?" Say: "I've never led a team." Answer slot: the JD asks you to coordinate several teams, so expect a probe on working with people who did not report to you. If you have, say how, in your own words; if you have not, say so plainly and stay with the calendar and the checklist | This is the objection most likely aimed at this candidate: the material has two stated gaps and one title's calendar against a two-title job (F9, F4, F3). Deepest rehearsal because it is asked in some form and a calm, specific concession changes the interview. JD because it scores the stated requirements, gaps included |
| C2 | "We're moving both titles to a season-pass model. You haven't worked on in-app purchases. How do you plan events around something you haven't done?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Say it plainly first: "I've never worked on a game with in-app purchases." Then change register to a plan, in questions rather than a claimed past: what the pass is meant to do, what you expect events to do for it, who owns pricing and reward balance, what you must never promise players. Concede that this is learning, not experience. Do not describe any purchase-related work | F9 is a gap you stated, and the August announcement (Sources) makes it live for this role. JD because it scores a stated requirement area; the pack treats it as the hardest follow-up to C1 |
| C3 | "The role asks for 3+ years producing live-service games. Your title was associate producer. How much of your four years was live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | The sentences carry four years as an associate producer and two years running the weekly content-drop calendar. Answer slot: say in your own words how long the game was being updated while you were there and what your part was; if the live-service part covers only the two years of the calendar, say "two years" plainly and do not round up. Do not turn associate producer into producer. Hold through two follow-ups by returning to the sentences | F1 and F2. The experience requirement is likely to be checked against the title and the years, so this is where the title gets tested. JD because it scores the stated requirement |

### D. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented. Which measures, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The setting is what the sentence states: monthly retention numbers, the studio head. Answer slots, in your own words: which measures were in them, how each was counted, what they are most sensitive to, which assumption behind them you would defend least, and which part of producing them was yours. "I don't know how that one was counted" is an honest answer; say it plainly rather than guess. Name no measure or method you did not use | F7 is the evidence and the likeliest place a prober digs. EXP because it tests what the numbers meant and what was yours; JD-adjacent |
| D2 | "Design the post-event review for a weekend event. What goes in it, and what does it decide?" | JD | [generic] | Structure: the purpose (what the next event does differently); what was planned versus what shipped, which meets the interviewer's public theme; player-side measures, retention among them because the JD names it; team-side items, such as checklist items that failed; one decision and one owner per follow-up; who receives it. The question asks about no past, so the guidance makes none | The JD's review and KPI line (F5). The nearest evidence is a monthly presentation, not a review, so this is rehearsed as a design problem. JD content, CASE delivery |
| D3 | "Seven-day retention for players who joined during last weekend's event is down 20% on the previous event. Diagnose it." | CASE | [generic] | Clarify first: what exactly is down (cohort, window, definition), against what baseline, since when, and whether the event itself or the build changed. Then segment, rank hypotheses by how cheaply each can be checked, say what data would confirm each, and say what you would tell the team in the meantime. Name the assumption you would defend least. The question asks about no past, so the guidance makes none | Persona stem for a dropped metric, set in the JD's retention line (F7). CASE because it scores structure; the pack made the figure up as a practice number |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run in-app-purchase events and led a team?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate. Hold what the sentences carry: you ran the weekly content-drop calendar for your main title for two years, and you wrote the release checklist QA still uses. Concede specifically: "I've never led a team, and I've never worked on a game with in-app purchases." Do not claim you would be better; say what you bring and where it stops. Hold through two follow-ups by returning to those two sentences, never by adding to them | Pressure stem aimed at the gaps in F9 and F4. JD because it scores the stated requirements; Pressure in delivery |
| E2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Pause. Answer slot: say which part was yours. If you only presented numbers others produced, say so plainly and stay with presenting them to the studio head each month. Use "we" for context and "I" for contribution. Hold through two follow-ups; concede exactly what was not yours and nothing more | Attribution probe on F7 in its pressure form. EXP because it tests what was the candidate's |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | A ninety-second arc with three beats. Two are the sentences' own: four years as an associate producer at a puzzle-game studio, and the last two running the weekly content-drop calendar for your main title. Answer slot for the third beat: say in your own words what draws you to live operations at Saltmarsh; if one of the three published values reflects it, name it and say why, and if none does, say what does. End pointing at the job, not apologizing for gaps | Casual register is still scored. F1 and F2 supply the beats. EXP because it tests whether the story holds together; the third beat is motivation |
| F2 | "Walk me through a typical week of the calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2: weekly, content drops, your main title, two years. Those are the beats the sentence states. Answer slot: the JD asks you to coordinate design, art, engineering and community on each update, so expect a probe on who the weekly drop touched. If those teams were part of it, say which and what you needed from each; if only some were, or none, say so plainly and stay with the calendar | F2 is the evidence and F4 is why it will be probed. EXP because it tests what was actually the candidate's |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A5, F2 |
| "coordinate design, art, engineering and community teams on each update" | A1, A5, F2 |
| "own the post-event review and the KPIs it reports" | D2, D1, D3 |
| "manage the release checklist with QA" | A4, B3 |
| "3+ years producing live-service games or apps" | C3, C1 |
| "experience running a content calendar" | F2, F1 |
| "comfortable with player-retention metrics" | D1, D3, B4, E2 |
| "clear written communication" | A2 |
| Published value: Players Before Plans | B1, A1 |
| Published value: Ship the Patch Not the Promise | B2, A2 |
| Published value: Leave the Build Greener | B3, A4 |

## Values cheat sheet

The values-style round is documented: the careers page names a values conversation as the second half of the hour. Value names are from the values page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When a schedule and the players' experience disagree, the players' side decides | Selection scaffold (B1): pick a time a schedule you held collided with players' experience; it needs a named stake, your decision, and what happened to the date. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (F2) or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (B2): pick a time what was said and what was built had to be brought into line. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (F6) or how you would handle it |
| Leave the Build Greener | Each release leaves the code and the checklist in better shape than before | F6: "Wrote the release checklist our QA team still uses". The beats are that you wrote it and QA still uses it; B3 holds the slot on what it changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to live operations from QA. What from that background do you wish every live producer had?" | Tied to his public path (previously a QA lead, [grounded] from a search summary). It turns the checklist conversation into a peer conversation |
| 2 | "In your GDC talk you argued that a live team is judged by how often its patch notes describe what actually shipped. How does your team check that today?" | [grounded] from the talk's one-line summary. Refer to the talk only as far as you have actually read or watched it. It shows you researched him and meets the value "Ship the Patch Not the Promise" |
| 3 | "The posting says two of our mobile titles; the August announcement describes one shared events calendar and a single live-ops group from January 2027. Where does this role sit on day one, and where after January?" | [grounded] from the announcement summary. It shows you read both documents and it asks about the role's real shape |
| 4 | "What would a strong first ninety days look like for someone who has run a weekly calendar and written the release checklist but hasn't worked on in-app purchases?" | Turns C1 into a ramp conversation. Use it only after the gap has come up or you have raised it honestly yourself |
| 5 | "When design, art, engineering and community disagree about an update's date, who decides?" | Tests the coordination point (F4) and shows whether the role carries direct reports, which the posting does not say |
| 6 | "Can you give an example of a post-event review that changed what the next event looked like?" | Meets the review line (F5) and gets a concrete picture of what a good review does here |

## Prohibited claims

Not coached in this pack. Each entry says why and what the honest form is.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated, F4 and F9 | "I've never led a team." No slot |
| Worked on in-app purchases, monetization or season-pass events | Negative you stated, F9 | "I've never worked on a game with in-app purchases." Then a plan said as a plan, never a past |
| Owned the post-event review and the KPIs it reports | Inflated form of F5 | F5's sentence at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: your material says presenting the numbers, not the review or the KPIs it reports |
| Ran the live-events calendar across two titles | Inflated form of F3 | F3's sentence at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: your material says one title and content drops |

## Sources

**Provided documents:** the JD text and your message (background).

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Query or fetch | Result |
|---|---|
| Search: "Saltmarsh Games company values" | https://saltmarshgames.com/values |
| Search: "Saltmarsh Games interview process live operations producer" | https://saltmarshgames.com/careers/interviewing |
| Search: "Saltmarsh Games strategy news mobile" | https://saltmarshgames.com/news/project-larkspur (summary only) |
| Search: "Tobias Wrenfield Saltmarsh Games" | https://talks.gdconf.example/2026/patch-notes-are-a-promise (summary only) |
| Fetch: https://saltmarshgames.com/values | Returned the three values by name with a one-line definition each |
| Fetch: https://saltmarshgames.com/careers/interviewing | Returned the loop description: a recruiter call, then the Outage Hour, a 60-minute hiring-manager interview with a live-incident tabletop and then a values conversation; no take-home |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; B1 to B3; the value lens in A1, A2 and A4 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | The loop is established: one session, tabletop then values. Persona weights, section order and the values cheat sheet follow from it |
| 3. `Saltmarsh Games strategy news mobile` | yes | A3, C2 and reverse question 3, from the announcement summary only; the fetch budget went to targets 1 and 2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer and reverse questions 1 and 2, from the talk summary only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is your future manager, and anything the recruiter said about Friday (focus areas, how the hour splits between tabletop and values) → persona weights move from assumed to documented
- An incident from your own calendar, such as anything that went wrong or slipped on a content drop → A1 and A2 gain a mapped follow-up, and B1 and B2 may gain a mapped story
- Your answers to the slots in F1, F4, F5 and F8 → those rows regenerate and the questions that draw on them tighten
- Inspectable artifacts: the release checklist, a content calendar page, a monthly retention deck → F2, F6 and F7 can move from medium to high confidence
- The full text of the Project Larkspur announcement and the talk page → A3 and the interviewer read move from summary-level to detail
- A tuesday-dossier.md from job-underwriter → an evidence-derived top objection and a prohibited-claims list; this pack inferred both
