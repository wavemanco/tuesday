I'll read the skill's reference files before building the pack.
The prep pack is written and saved. I'm sending it over now.

Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-4-denied-4b425094/38c642f9-fea2-4c82-b13f-5d373938045e/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`.

I built it for your 45-minute hiring-manager conversation, using your dossier for the requirements, your three confirmed evidence sentences, the weak areas and the prohibited claims. It has 20 questions across five personas. A1 is the one to rehearse most: the underwriter's "never held the title or owned a roadmap" objection.

The three company searches (values, interview process, strategy) were refused in this session. The case questions are therefore generic rather than grounded in Quartzline, and the Sources section shows that.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** 45-minute conversation with the hiring manager (name not given), Thursday
- **Built on:** your dossier (conditional_go), consumed for requirements, confirmed evidence, weak areas, the named objection, risks and prohibited claims. Company research was refused in this session, so company-specific content is labeled `[generic]` (see Sources).
- **Highest-ROI prep in this pack: A1.** The underwriter named that objection, from evidence you confirmed. Rehearse it until it is boring.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: use your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Past behavior against the company's published values |
| EXP | Whether claims about your work survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Reasoning on a live problem set in the actual role |

An **answer slot** is an instruction for the interview, not a question for me. It names a probe the interviewer is likely to make and gives two honest branches: say what you did, in your own words, or say plainly that you did not. Either branch is a good answer. If you answer a slot to me outside a drill, I will treat it as new material and regenerate the rows it touches.

## 2. Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from `verified_candidate_evidence`; the confidence notes the underwriter attached to those entries are in the Confidence column and the bridges, not in the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy for this area is bridge, and the limit is its condition: position the work as adjacent, never as PM experience. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." The pack's observation: that sentence says input to product, and your material shows no PM title or PM years. Do not convert the work into equivalent PM years |
| F2 | "Shipped API or platform products" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | This pack graded the row; the underwriter's weak-area list does not include R2. The quote is high-confidence evidence with an inspectable playbook behind it, but of integration work, so the requirement is only adjacent. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." The pack's observation: your material says the vendor's REST APIs and does not show whose product decisions shaped them. Answer slot: the requirement makes a probe on the API itself likely. If any integration you led led to a change in the API, say what changed and what part was yours; if none did, or the API was the vendor's alone, say so plainly and stay with the integrations |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch the requirement without showing whether API documentation or schemas were part of the work. Answer slot: expect a probe on API docs and schemas. If you read, wrote or reviewed any in those integrations, say which and what you did with them; if you did not work with them directly, say so plainly and stay with the architecture stage and the playbook as quoted |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes carry client-facing work and a feed to product; they do not show engineering or sales as parties. Words stay at those two sentences. Answer slot: the requirement names engineering and sales, so expect a probe on each. If you worked with either on these integrations or sessions, say who and about what; if not, say so plainly and stay with the clients and product as quoted. The second quote is medium-confidence, confirmed with limited inspectable proof, so expect it to be probed |
| F5 | "Own the roadmap for the partner-facing API platform" — dossier role_profile | none given | none | [grounded] | capability | The underwriter recorded this as an `acknowledge_gap` area (roadmap ownership and prioritization authority), and `prohibited_claims` lists it. A gap wording cannot close. Words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first and from whom. Never a bridge here |
| F6 | "Agile delivery experience" — dossier role_profile | none given | low | [grounded] | discovery | The underwriter's strategy is clarify: the evidence may exist and was not established, and no verified entry speaks to it. Answer slot: the requirement says agile delivery, so expect a probe on how you have worked with agile teams. If you worked inside a sprint or squad process, say how and in what role; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines delivery |
| F7 | "Run discovery with integration partners" — dossier role_profile | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches partner and client evidence without showing whether it was discovery as the posting means it. Answer slot: expect a probe on how you gathered what you fed to product. If you ran interviews or other structured conversations to get it, say what and how; if the evidence came from the integration work itself, say so plainly and stay with the sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile | none given | none | [grounded] | discovery | Your material is silent on this, which makes it discovery, not a finding of absence. Answer slot: expect a probe on specs. If you wrote requirements or specs that engineers built from, say for what and who built it; if not, or it was someone else's, say so plainly and stay with the requirements and UAT stages named in F2's quote |
| F9 | "Define and track adoption metrics" — dossier role_profile | none given | none | [grounded] | discovery | Your material is silent here too. Answer slot: if you defined or tracked any measure of how integrations went live or were used, say what was measured and what part was yours; if not, say so plainly and say what you would measure first |

## 3. Persona table

Weights are a shown judgment. Change them if you know something I don't.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Quiet, persistent probing of the title and roadmap gap; "why you instead of a PM with the actual job" | Highest. The hiring-manager relationship prior is Case plus Skeptic, because they are buying capability and de-risking gaps. The underwriter also named this exact objection from your confirmed evidence, and made the squad-authority question a condition | Rehearse A1 until boring. Bridge only from the three confirmed sentences, say the limit before it is asked for, and add a ramp plan |
| Case/Strategist (weight 5) | Live problems from the role: discovery plan, a flat-adoption diagnosis, a three-way prioritization, a spec walk-through | High. The same hiring-manager prior, and the role profile gives four responsibilities to build problems from. Rows are `[generic]` because company strategy research was refused | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober (weight 4) | Reads the claims line by line; asks how 30-plus was counted, what the playbook holds, what the sessions produced | Mid. Your headline number is on the dossier, and one confirmed entry is medium-confidence with limited inspectable proof, which the underwriter said to expect a probe on | Know what you can and cannot say about how the figure was counted; volunteer the limit on the sessions before it is extracted |
| Conversational (weight 4) | Opening biography, motivation, "what's your experience with agile", first-month plan | Mid. A 45-minute conversation opens warmly and the casual questions are still scored | A 90-second arc built only from your three sentences; treat casual JD-topic questions as scored |
| Pressure (weight 2) | Time-boxed "sixty seconds, why you" and "how much of that was you" | Low. The hiring-manager prior does not favor it, but the Skeptic's questions can arrive time-boxed | Pause, restate, hold the position through two follow-ups, concede specifically |
| Values/Behavioral (not weighted) | A scored behavioral round on published values | Not weighted: no loop source documents a values round, and the values-page search was refused, so no published values are in hand | None needed this session |
| Peer Evaluator (not weighted) | Seam-splitting between adjacent teams | Not plausible: the interviewer is the hiring manager, not a peer. The squad-lead seam appears as a CASE (B3) and as reverse question 1 | None needed |

Persona weights rest on the relationship prior and your dossier. No source on Quartzline's own loop was available, and your note establishes only this one session.

## 4. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The deepest rehearsal, four levels. (1) Pause, restate the question in a clause, then concede first, in these words (`prohibited_claims`, `acknowledge_gap`): "I haven't held a product manager title or owned a product roadmap." (2) Then say what you did at its own scope and stop: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product." Let the interviewer draw the inference. (3) Name the limit before they do: "That's adjacent to the job, not the job." (4) Ramp plan, in the future tense only: before proposing anything you would ask which decisions belong to the squad leads and how adoption is measured today (reverse questions 1 and 2). Follow-up one, "a PM with three years has made priority trade-offs you haven't": hold by agreeing plainly (`prohibited_claims`: "Having set prioritization for an engineering squad"), then return to the two sentences. Follow-up two, "why take that risk": concede that the risk is real and that the decision is theirs; do not argue you are better, and do not add to the two sentences | The underwriter named this objection from evidence you confirmed (F1, F5). Asked as the underwriter wrote it because both negatives in it have a dossier source. JD because it scores the title and years requirement |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Lead with the true answer the dossier supports (`acknowledge_gap`, `prohibited_claims`): "I haven't owned a product roadmap or set priorities for an engineering squad." Then the nearest sentence you have, at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Then the ramp plan in one sentence. Answer slot: agile delivery inside a product org is the other open area. If you have worked inside a product team's delivery process, say how; if not, say so plainly and say you would want to learn how these squads run | Stem for the Skeptic. F5 is the likeliest weakest-area answer and F6 the second; JD because it scores honest self-assessment against the listed job |
| A3 | "The posting asks for three years of product management. How do you see your background against that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Bridge with its limit, in this order: the plain acknowledgment (`prohibited_claims`), "I haven't held a product manager title"; then "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product"; then say it is adjacent work. Never translate it into equivalent years of PM experience | The same objection as A1 in a gentler register. F1 is the row it draws on; JD because the years requirement is the stated bar |
| A4 | "The role needs someone who has shipped API or platform products. What's the closest thing in your background?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-map on the sentence and tell its beats in your own words: the 30-plus integrations, end to end, and the stages it names — scoping, requirements, architecture, UAT, go-live. Answer slot: expect a probe on the API itself. If any integration you led led to a change in the API, say what changed and what part was yours; if none did, or the API was the vendor's alone, say so plainly and stay with the integrations. State the limit in your own words rather than leaving the interviewer to find it | F2 is the adjacent-evidence row and the second most likely place to be probed after F1; JD because it scores R2 |
| A5 | "Why move into product management now, and why this role?" | JD | [generic] | The reason is yours; the pack will not supply one. Selection criteria: one reason you can say in a sentence, tied to what the posting says the role does (partner discovery, specs with squads, adoption metrics) and not to a title. If the sessions are what drew you, say it with the one sentence you have: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if that work is what drew you toward product, say so; if something else did, say that instead. Under a minute | The Skeptic's why-here-why-now stem. `[generic]` because the pack holds no stated motive; JD because it scores fit with the role's actual content |

### B. Case/Strategist

All five are `[generic]` rows: they are live problems built from the dossier's role profile, with no company strategy behind them.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've just joined. Sketch how you'd run discovery with integration partners over your first sixty days. What do you need to know first?" | CASE | [generic] | Clarify first: who the partners are and how they are segmented, what decisions discovery must feed, and what is already known about adoption. Then objective, approach (who you would talk to, in what order, with what questions), how you would record and share what you learn, and risks. Think aloud. Make no claim about past discovery work | Draws on the role's discovery responsibility (F7). CASE because it is a live plan with no past in it |
| B2 | "Suppose adoption of a partner API has been flat for a quarter. How would you diagnose it?" | CASE | [generic] | Start by asking how adoption is defined, since the posting names the metric and the dossier records that the baseline is unknown. Then segment partners (new, stalled, live), walk the stages from sign-up to production traffic, separate causes (docs, errors, versioning, sales motion, partner priorities), and say what data you would pull first. You may use the stage words from your own integration work: scoping, requirements, architecture, UAT, go-live. Answer slot: expect a follow-up on the adoption-metrics line. If you have defined or tracked a measure of how integrations went live or were used, say what was measured and what part was yours; if not, say so plainly and say what you would measure first | F9 is the requirement it covers. CASE because the diagnosis is the scored part |
| B3 | "Two squads, three asks: a large partner wants a custom endpoint, sales wants a webhook for a pilot, and an engineering lead wants time for versioning cleanup. How do you decide what goes first?" | CASE | [generic] | Say what you would ask first, including who decides what here; that is the dossier's open authority question, and asking it is a strength. Then criteria (partner and adoption impact, cost of delay, effort and risk), make assumptions explicit, recommend an order with a trigger to revisit, and say who you would consult. If asked whether you have done this, the plain answer is sourced in `prohibited_claims` and `acknowledge_gap`: "I haven't set priorities for an engineering squad." Then the ramp plan. You are scored on reasoning, not on the right pick | F5 and the squad-authority risk. CASE because it is a prioritization problem set on the role's real tension |
| B4 | "Walk me through how you'd write a spec for a new endpoint and take it through delivery with a squad." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Structure: the partner problem and the evidence for it, the contract (endpoints, schema, errors), acceptance criteria, rollout and deprecation, the adoption measure. Name where you would ask the squad lead rather than decide. If asked about your history, your material carries "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I wrote the internal integration playbook my team uses," and nothing wider. Answer slot: expect a probe on whether you have written specs that engineers built from. If you have, say what and who built it; if not, or it was someone else's, say so plainly and stay with the requirements and UAT stages the first sentence names | F8 and F6 meet here. CASE with a JD slot attached |
| B5 | "A partner says your API's pagination makes their sync fail. What do you ask first?" | CASE | [generic] | Clarify: which endpoint, what error or symptom, what volumes, which API version, and whether the behavior matches the documentation. Then separate a bug, a documentation gap and a design limit, reproduce from the docs and schema, and say how you would report back to the partner and to the squad. Think aloud. Make no claim about past technical work | F3's requirement, tested as a live problem rather than a claim. CASE because it scores structured technical reasoning |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 30-plus integrations. How were they counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say the sentence at its own scope. Then the four slots a headline figure raises, in your words. How the integrations were counted: if you know, say; if you don't, say plainly "I don't know how it was counted." What the count is sensitive to. The assumption behind it you would defend least; name it before they do. Which part was yours. The pack supplies none of these | Every headline figure gets a defend-the-number question. F2 is the row; EXP because it tests attribution |
| C2 | "Tell me about the playbook." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats are only what the sentence states: you wrote it, it is internal, your team uses it. "I wrote the internal integration playbook my team uses." Be ready to open it; it is the inspectable artifact the underwriter recorded, so any detail you give should be one you can point to in it | High-confidence and inspectable, so the lowest-risk story you have (F3 touches it). EXP |
| C3 | "Walk me through the quarterly sessions where you fed client evidence to product." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the sentence states: quarterly, sessions, client evidence, fed to product. This entry is confirmed with limited inspectable proof, so volunteer the limit before it is extracted: say what you can point to and say plainly what you cannot. The pack does not write that limit for you. Answer slot: the roadmap line makes a probe on what product did with the evidence likely. If you know of a roadmap change that followed, say what it was and what part was yours; if you don't know, or product decided without a visible link, say so plainly and stay with the sessions. Hold the line that the sessions were input, not decisions (`prohibited_claims`: "Having owned a product roadmap") | The medium-confidence entry and the one an interviewer can most easily push past its scope (F1, F7). EXP |
| C4 | "Tell me about a time you had to bring engineering, sales and customers to one decision." | EXP | [generic] | The theme is the requirement's own. Selection criteria: a named decision, the parties on each side, what you did, and an intact relationship afterward. The nearest sentences your material carries are "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product," and neither names engineering or sales. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | F4 shows no quote that names two of the three groups, so this is a scaffold, not a story map. EXP because it tests a real instance |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each its sentence at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs"; "I wrote the internal integration playbook my team uses"; "I ran quarterly roadmap-input sessions feeding client evidence to product." Close on what draws you to Platform APIs, in your own words, tied to the posting's partner-discovery line. Do not state a total duration unless it is one you can document; the pack holds none | The warm opener is scored. EXP; F1 to F4 are the rows it seeds |
| D2 | "What are you most interested in about partner-facing APIs these days?" | JD | [generic] | Selection criteria: something you have actually read, looked at or worked through, and why it matters for a platform API. If nothing comes to mind, say so plainly, then give the nearest thing your material carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Do not recite trends you have not read | The casual JD-topic stem is scored. `[generic]` because no company research was available; JD |
| D3 | "What would you want to be doing in your first month?" | JD | [generic] | A ramp plan, future tense only: learn which decisions belong to the squad leads and how adoption is measured today, meet partners, sit in on how each squad plans and delivers, and propose nothing until you have heard. This is also where the clarify area (F6) turns into a question you ask them | Doubles as the ramp plan A1 and A2 point to. JD |
| D4 | "Just so I pitch the day-to-day right, what's your experience with agile teams?" | JD | [grounded] | Answer slot: the posting says agile delivery. If you have worked in sprints or in a squad process, say how and in what role; if you never worked that way, say so plainly, and ask what delivery looks like for these two squads. Nothing about your past goes in beyond what you say here | The clarify area (F6), asked casually, so the answer should be a question-shaped honest one. JD |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who's done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Pause, restate, then hold and concede. Concede first (`prohibited_claims`): "I haven't held a product manager title." Hold on the two sentences at their scope and the ramp plan, and no more. If pushed twice, concede specifically that the risk is real and leave the decision with them. Never fold on the sentences; never add to them | A1 time-boxed (F1). JD |
| E2 | "That integration work: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Hold the sentence's own verb: it says "led." Answer slot: how the 30-plus were split between you and others. If you led all of them, say so; if you led some and others led or did parts, say which plainly; if you don't know the split, say that. Do not widen "led" and do not retreat from it unprompted | The attribution probe; the figure raises "which part was yours" (F2). EXP |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| "3+ years product management experience" | A1, A3, A5, E1 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B3, C3 |
| "Shipped API or platform products" | A4, C1, C2, E2 |
| "Technical fluency: API docs, schemas" | B5, B4 |
| "Stakeholder management across engineering, sales, customers" | C4, B3 |
| "Agile delivery experience" | D4, A2, B4 |
| "Run discovery with integration partners" | B1, C3, D3 |
| "Write specs and drive delivery with two engineering squads" | B4, B3 |
| "Define and track adoption metrics" | B2 |

## 5. Reverse questions

The first two come from the underwriter's unresolved risks and employer questions. They do double duty: they read as diligence, and they answer something you need to know before accepting.

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The posting asserts authority over the roadmap; your material cannot show it either way. Their answer tells you whether the role is a decision-maker or a coordinator, which changes whether the ramp plan is realistic | [grounded] |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The posting names adoption metrics as a responsibility but states no baseline. A vague answer tells you the first job is defining the measure | [grounded] |
| 3 | "What would you want to have seen from me by day thirty and by day ninety for this to look like the right hire?" | Gets the hiring manager's real bar, in their words, and shows you are planning the ramp | [generic] |
| 4 | "Have you seen someone move into this kind of role from outside product management? What helped them and what didn't?" | Brings the gap into the open on your terms and surfaces how they weigh adjacent backgrounds | [generic] |
| 5 | "How do requests from sales and from partners reach the roadmap today?" | Tests the stakeholder seam the posting names, and tells you where decisions really get made | [generic] |
| 6 | "What would make you say in six months that this hire was the right call?" | A direct close that asks them to define success; useful as a last question | [generic] |

## 6. Prohibited claims

Built before the question banks, and binding on every cell. The first three come from the dossier's `prohibited_claims`; the last two are inflated forms of sentences you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims`: "Having held a product manager title or role" | The two sentences at their own scope, and the plain acknowledgment `prohibited_claims` supports: "I haven't held a product manager title." Do not convert the work into equivalent PM years |
| Having owned a product roadmap | `prohibited_claims`: "Having owned a product roadmap" | "I ran quarterly roadmap-input sessions feeding client evidence to product," and the plain acknowledgment "I haven't owned a product roadmap." No slot asks you to say how you owned one |
| Having set prioritization for an engineering squad | `prohibited_claims`: "Having set prioritization for an engineering squad" | The plain acknowledgment "I haven't set priorities for an engineering squad," then a ramp plan. No slot |
| Shipped an API or platform product | Inflated form of F2 | The F2 quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation: the material says the vendor's REST APIs and does not show whose decisions shaped them. A4's slot stays inside the integrations |
| Shaped the product roadmap | Inflated form of F1 and F7 | The quote at its own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the material says input to product. C3's slot asks only what followed the sessions |

## 7. Sources

**Provided:** the dossier (`tuesday-dossier.md`, version 1.1, pasted into the conversation). Sections consumed:

- `handoff_to_mock_interview`: verified candidate evidence, weak areas with their allowed strategies, the named objection, opportunity risks, employer questions and prohibited claims.
- `role_profile`: the requirements and responsibilities, standing as the posting's lines.
- `decision`: context only. Its prose summarizes your background more broadly than any verified entry does (it cites seven years of integration leadership), so the pack carries no clause from it about what you did.

The inline dossier carried no `evidence_map`, `evidence_state` or `risk_register`, so the grading of F2, F3, F4 and F7 is this pack's own, labeled `[inferred]`.

**Searches sent (all refused, nothing returned):**

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. Would have supplied the company's published values for VAL questions; a values cheat sheet is only built when a values round is documented, and none is |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. Would have documented Quartzline's loop; persona weights rest on the relationship prior and your dossier instead |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. Would have grounded a CASE or CO question in current strategy; B1 to B5 are `[generic]` as a result |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the requirements and JD-tagged questions |

## 8. Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their own career path
- The recruiter's prep notes, if any → focus areas for this conversation, and a build section if a deliverable was announced
- Search access, then a rerun → the three refused targets: Quartzline's values, loop and strategy; the B-bank rows could become `[grounded]` in company terms. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, and only if you say so
- Your answers to the slots in F2, F3, F4, F6, F7, F8 and F9, said to me outside a drill → those rows regenerate from your own words, with the guidance cells that draw on them
- The integration playbook, and any notes or agendas from the quarterly sessions → the inspectable artifacts that would move the roadmap-input sessions' confidence from medium toward high
- The underwriter's `evidence_map` → official grading for R2 to R4 and R5, in place of this pack's own
