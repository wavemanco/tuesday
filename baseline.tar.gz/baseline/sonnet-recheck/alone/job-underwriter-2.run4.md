I'll read the reference files the skill points to before building the assessment.
Nadia, this is the full first-pass assessment for the Quartzline role.

## Decision snapshot

**Not a waste of time to apply, but this posting is a stretch. R1a (3+ years PM experience, titled) and R7 (own the roadmap) are absent on what you've told me, while R3 is `direct` and R1b and R2 are `adjacent`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM work under other titles), R2 (shipped API or platform products) · absent: R1a (3+ years PM experience, titled), R7 (own the roadmap)
- `important` — direct: R4 · adjacent: R5 (discovery with integration partners), R6 (specs and delivery with two squads) · unclear: R8 (adoption metrics), R9 (launches with sales and support), R10 (agile delivery)

R1b and R2 carry the bridge, with their limits named in the map. R1a is the row no wording can change.

**Opportunity ledger.** The scope is concrete on its face (RR4). The employer is unverified (RR1). How flexibly the years requirement is applied (RR2), the salary (RR3) and the first-year definition of success (RR5) are all unknown.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. RR1 clears: the posting verifies on Quartzline's own careers page.
  2. RR2 comes back flexible, or you get a human route in.
  3. You position R1b and R2 as adjacent and never claim PM-titled years or shipped-API ownership.
- **What would change this:** a specific, confirmed answer to G1 could move R2, R7 and R8. A literal answer on RR2 makes this posting a `no_go` for you.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B. Its existence and the live posting are not verified | `[grounded]` JD header |
| Mandate | Own the roadmap of a partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated requirements | 3+ years PM experience (marked must-have); shipped API or platform products; technical fluency; stakeholder management across engineering, sales and customers; agile delivery | `[grounded]` JD |
| Hard gates | None stated: no location, authorization, pay or travel terms in the posting | `[grounded]` JD silence |
| Scope read | An individual-contributor PM owning one product surface with two squads. The 3+ years floor points to a mid-level post | `[inferred]` from "own the roadmap" and "two engineering squads"; `[generic]` that a years floor of this size usually signals mid-level |
| Market calibration | Not established. No salary band or title-norm comparison is given, because the role-family sweep returned nothing | `[grounded]` see Evidence status |
| Unknowns | Compensation, reporting line, decision rights, first-year outcomes, location or remote terms, how the years requirement is screened | `[grounded]` JD silence |
| Contradictions | None inside the JD. It could not be compared with a careers page | `[grounded]` JD; no page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | none | capability | You've never held a PM title, so the titled years are absent. A years requirement is not a gate: it keeps its tier and is graded on fit. Work near it sits in R1b. Employers often apply such floors literally | `[grounded]` your statement; `[generic]` that years floors are often screened literally | Wording cannot close this. Don't state PM years; ask RR2 |
| R1b | Product-management work done under other titles | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product, wrote requirements documents, and coordinated engineers and product managers on custom builds. Limit: these fed product and supported delivery. Nothing you've said shows deciding what got built or prioritizing across customers. Medium because it is intake prose with no artifact yet | `[grounded]` your resume prose | G2; a sanitized roadmap-input output would raise it |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the integration playbook the team uses, so you know the API from the implementing side. Limit: nothing says you launched, versioned or owned adoption of an API product. The triage-tool note is a lead, not evidence | `[grounded]` resume prose; memory lead used for a question only | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, reading OpenAPI specs and integration architecture across 30+ integrations are specific. Medium because there's no inspectable artifact yet, so expect a probe | `[grounded]` resume prose | Optional: a sanitized architecture diagram or playbook excerpt would raise it to high |
| R4 | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran client-facing workshops through to go-live. This is claimed for engineering and customers only; sales is not stated (see R9) | `[grounded]` resume prose | none |
| R5 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions are real customer-facing discovery. Limit: the clients were your employer's customers, and nothing says you turned feedback into prioritized product decisions | `[grounded]` resume prose | G2 |
| R6 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | discovery | Requirements documents, UAT, go-live and custom-build coordination are delivery-side work. It's unknown whether engineers built from your documents in a backlog, or whether you coordinated client implementations instead | `[grounded]` resume prose | G2 |
| R7 | Own the roadmap and prioritization | must_have | absent | none | discovery | Your resume shows input to product, not ownership. I tiered this `must_have` because it is the posting's first listed responsibility. The gap is discovery because the unconfirmed triage-tool lead might show owned scope | `[inferred]` tier from JD ordering; `[grounded]` resume | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Your resume is silent on metrics. Low because the only thread is an unconfirmed prior-context note about a tool support agents adopted | `[grounded]` resume silence; lead unconfirmed | G1 |
| R9 | Coordinate launches with sales and support | important | unclear | none | discovery | Your resume describes coordination with engineers, client engineers and product managers, not sales, support or product launches. Client go-live is a different kind of event from a product launch | `[grounded]` resume prose | G1 touches support |
| R10 | Agile delivery | important | unclear | none | discovery | Your resume doesn't mention sprints, backlogs or ceremonies | `[grounded]` resume silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning something others adopted (R2, R7, R8, R9) | discovery | No product, tool or workflow you launched or measured appears in your resume. A prior-context note about a request-triage tool that support agents used is unconfirmed | Confirmed specifics could move four rows, two of them `must_have` | A tool, script or workflow others used; deciding what it did; tracking usage; rolling it out and training users; changing it from feedback | A demo or screenshot, a README, usage numbers, a rollout note, before/after request volume | `[grounded]` resume silence, lead unconfirmed; `[inferred]` that confirmation moves these rows |
| G2 | Specs, prioritization, agile cadence (R6, R10, R7) | discovery | Your resume shows requirements documents, UAT and go-live, but not whether engineers built from your documents or who set priorities | Separates coordinating client implementations from driving a team's delivery | Requirements that became tickets or stories; sprint or backlog sessions on custom builds; a say in which builds got engineering time; release sign-off | A sanitized requirements document, a ticket screenshot, a release plan | `[grounded]` resume prose; `[inferred]` distinction from the JD's "drive delivery with two engineering squads" |
| G3 | Titled PM years (R1a) | capability | You have no titled PM years | The years can't be edited into existence | — | Closure path: ask how RR2 is handled before investing; look for roles that credit non-titled product work; an internal move into product, which you may be placed for after running roadmap-input sessions with product; optionally a clearly labeled sample spec (below) | `[grounded]` your statement; `[generic]` that internal moves and flexible-years roles are common routes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small for a footprint, the posting may be stale, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Years requirement against a non-PM title history (R1a) | unknown | — | "3+ years product management experience (must-have)" | The team may apply the years literally or credit product work done under other titles. The posting doesn't say | `[inferred]` from the must-have marking against the JD's silence on equivalents | How does the team treat the 3+ years requirement for someone who has done product-facing work, such as roadmap input, requirements and cross-team delivery, under a solutions or implementation title? | unresolved |
| RR3 | Compensation withheld | unknown | — | No compensation stated in the posting | The range is unknown and can't be set against a market band here | `[grounded]` JD silence | What is the budgeted salary range for this role? | unresolved |
| RR4 | Concrete scope and delivery capacity | positive_signal | — | "run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics" | The role has a defined surface and named delivery capacity | `[grounded]` JD | Who sets the two squads' priorities when roadmap and platform work conflict? | noted |
| RR5 | Success definition and reporting line unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may carry roadmap accountability without stated first-year outcomes or decision rights | `[inferred]` from the mandate against the JD's silence on outcomes and reporting | What would a good first year look like, and who does the role report to? | unresolved |

## Application plan

Every row below, the edits table and the positioning rows alike, is a proposal and is not final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Verify the posting on Quartzline's own careers page before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Look for a human route in (a referral or a direct note to the recruiter or hiring manager) rather than a cold submission | see R1a, RR2; wording can't answer a literal years screen | `[generic]` role-family pattern on how years floors are applied | pending your approval |
| P3 | State the title gap yourself in your first lines, then name the product-facing work in your own words (R1b) | The resume has no PM title, and candor protects R1b | `[grounded]` R1a, R1b | pending your approval |
| P4 | Lead with R3 and the R2 bridge: 30+ client integrations and the playbook, framed as implementing and documenting your employer's APIs, never as shipping them | see R2's limit | `[grounded]` R2, R3 rows | pending your approval |
| P5 | Optional work sample: a one-page spec for a partner-facing API change drawn from patterns you saw across integrations, sanitized and labeled as a sample, not shipped work | narrows R1b and R6 limits | `[inferred]` from R1b, R6 transferability | pending your approval |
| P6 | Ask RR2, RR3 and RR5 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P7 | For the wider pivot, weigh API, platform or integration PM roles, where your integration record is the substance, against generalist PM roles | see R2, R3 | `[generic]` role-family pattern | pending your approval |

**Proposed resume edits — `resume_edits_pending_approval`**

| # | Current | Proposed | Audit against your sentences |
|---|---|---|---|
| E1 | "Ran quarterly roadmap-input sessions collecting client feedback for product." | Same words, moved into the first three bullets of the role | Reorder only; nothing added |
| E2 | No summary line | "Solutions engineer and implementation lead, 7 years; led 30+ client integrations of the company's REST APIs end to end and ran quarterly roadmap-input sessions collecting client feedback for product." | Each clause traces to your sentences. "30+" stays on integrations, and "the company's" stands in for "our" |
| E3 | "Comfortable in Postman and SQL and reading OpenAPI specs" | Skills line: "Postman, SQL; reading OpenAPI specs" | "Reading" is kept so it doesn't become authoring |

Language that fails the audit and stays out: "product management experience", "owned the roadmap", "shipped API products", "defined adoption metrics", and the triage tool until G1 is confirmed.

**Offer beyond this spec:** a side-by-side of this posting against other role shapes for your pivot. Your question is about the pivot, not just this posting. I'd build it only on your approval.

## Evidence status

Verified: none yet. Unverified leads: a prior-context note that you may have built an internal request-triage tool adopted by support agents. It's unconfirmed and drives G1 only. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology API platform careers Product Manager Platform APIs"; the call was refused, so nothing came back. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "Product Manager API platform B2B SaaS Series B salary range scope career transition from solutions engineer"; the call was refused. It would have fed the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as a `tuesday-dossier.md` if you'd like to reuse it.

## Upgrade menu

- A link to Quartzline's own careers page or the live posting, or the recruiter's email domain → RR1 closes and the contradictions row gets checked.
- Allowing web search in this session, or a pasted salary survey for this title → the market calibration row and RR3 get a band to compare against.
- A demo, screenshot, README or usage numbers for the triage tool → R2, R7, R8 and possibly R9 move.
- A sanitized requirements document or ticket screenshot that engineers built from → R6 and R10 firm up.
- A sanitized roadmap-input session output or summary → R1b and R5 can reach `high`.
- A sanitized integration architecture diagram or playbook excerpt → R3 to `high`.
- Your non-negotiables (pay floor, location, travel) → hard-gate rows get created and checked.
- The hiring manager's name → footprint research and a positioning lead for that reader.
- Deeper research on Quartzline (funding, leadership churn, candidate reports; up to 5 more searches and 2 more fetches) → say the word and it runs, once search is permitted.

## Questions

G1 — An earlier conversation suggested you may have built an internal request-triage tool that support agents adopted. That's unconfirmed. Is it right, and if so, what did you own, who used it, how did you know it was adopted, and did you decide what it did?

G2 — On a custom build, did your requirements documents go to engineers who built from them in tickets or sprints, and did you have any say in which builds got engineering time first?

Constraints — Are there non-negotiables for a move, such as a salary floor, location or hybrid days, or travel, that I should check Quartzline against? The posting states none.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.