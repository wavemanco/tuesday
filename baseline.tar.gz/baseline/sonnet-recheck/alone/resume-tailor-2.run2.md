I built this from your pasted description, treating each of your sentences as a resume line. Nothing below is applied, and every row waits on your approval.

The main finding is in the coverage map. Your material doesn't support the JD's one stated must-have, 3+ years of data engineering (R1). No wording can fix that, so I haven't tried to. What your material does support is real: the orders mart and its star schema, the dbt models, and the nightly job fixes. The ledger puts those first. Whether this role is a realistic target is job-underwriter's question, not this resume's.

## Edit ledger (resume edits pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your description | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer." | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your description | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke; added tests to it." | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your description | pending your approval |
| E4 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged — moved below the dbt model, star schema and nightly job bullets)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your description | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `reframe` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your description | pending your approval |

- **Kept qualifiers:** E2 keeps "with our then-data engineer", so the design credit stays shared. E3 keeps "our", and E5 keeps "some".
- **E1 stays two sentences,** so the dbt claim isn't merged into the title line.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your 5 years are analytics. E2 and E3 show pipeline-adjacent work, but they don't establish data-engineering years. See named absence N1. | `[grounded]` your description and the JD |
| R2 | Production Python | important | `not_evidenced` | E5 shows the Python you actually have. Nothing says the cron scripts feed anything others depend on. See G2. | `[grounded]` your description |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | E3 shows a nightly dbt job you fixed. Nothing says you built or configured its scheduling. See G1. | `[grounded]` your description |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E2, with E1 as support. The line keeps your word, "star schema", rather than the JD's. | `[grounded]` your description |
| R5 | Data quality | important | `surfaced_by_edit` | E3 shows "added tests". The JD says "own data quality", and your sentence supports adding tests, not ownership. | `[grounded]` your description |
| R6 | SLAs | important | `not_evidenced` | No mention of a deadline or uptime target for the job. See G3. | `[grounded]` your description |
| R7 | Streaming experience | preferred | `not_evidenced` | You have never touched Kafka. See named absence N2. | `[grounded]` your description |

## Gap handling: recall prompts

The question each row implies is asked in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Airflow or equivalent orchestration | important | You fixed the nightly dbt job. It doesn't say what schedules or runs it, or whether you set that up. | Without it, R3 reads as zero, even though you may have touched scheduling. | dbt Cloud job schedules you configured; a GitHub Actions or cron trigger you wrote; ordering the vendor pulls before the dbt run | A job config, a workflow file, a scheduler screenshot | `[grounded]` what the resume says; `[generic]` what an orchestration gap costs on pipeline roles |
| G2 | Production Python | important | Python for analysis, plus "some scripting" on a cron. It doesn't say what the scripts feed. | "Production" turns on whether other people or tables depended on those scripts. | Vendor pulls feeding the orders mart or other teams' dashboards; scripts with logging, retries or alerts | The script repo, a README, an alert config | `[grounded]` what the resume says; `[generic]` how screeners read analysis-grade Python |
| G3 | SLAs | important | Nothing about timing or reliability targets. | The JD says "own data quality and SLAs", and a stated deadline would give that line something real to attach to. | A "dashboards ready by morning" expectation; tracking whether the job landed on time; an incident you fixed under a deadline | A run-history screenshot, an incident note | `[grounded]` what the resume says; `[generic]` what SLA ownership means on DE teams |

## Named absences

| # | Gap | What closing it would take | Provenance |
|---|---|---|---|
| N1 | R1: 3+ years of data engineering. Your years are analytics, and this is the must-have. | Evidence that your pipeline work (the vendor pulls, the nightly job) was data-engineering scope, via G1–G3. If it wasn't, the honest options are to apply knowing this will read as unmet, or to aim at roles that ask for less. | `[grounded]` your description; `[generic]` how experience-years requirements get read |
| N2 | R7: streaming. You have never used Kafka, and this is a plus, not a requirement. | A small personal project would be real, inspectable evidence, but only once it exists. Until then it stays off the resume. | `[grounded]` your description |
| N3 | Spark and Airflow, named in the duties line. You have never used either. They're a tools list rather than requirements, except Airflow's "or equivalent" in R3. | Same as N2: only built-and-inspectable work counts. | `[grounded]` your description |

## Not written, and why

- **"Data Engineer" as a title or headline, or any "years of data engineering".** Your title and years are analytics, and this is the must-have.
- **"Production Python" or "built production pipelines".** You wrote "some scripting to pull vendor APIs on a cron". Calling that a pipeline is a different kind of work, and nothing says anything depended on it.
- **"Orchestrated" or "managed pipelines in an orchestration tool".** You fixed the nightly job, and nothing says you built or scheduled it.
- **"Owned data quality" or "met SLAs".** You added tests, and no SLA appears anywhere in your material.
- **"Led" or "architected the warehouse model".** You designed the star schema "with our then-DE", so the shared credit stays.
- **Any Spark, Kafka or streaming familiarity.** You've never used them.
- **"Dimensional modelling" in place of "star schema".** It's the JD's word, not yours. R4 still maps to your star-schema line.

## Parse-safety check

You pasted text, not a file. I could not check layout (columns, tables, text boxes), headers and footers, section headings, file type, or hidden text. Send the file and I'll run those.

## Upgrade menu

- **The resume file itself:** I'd quote your exact wording instead of your summary, check parsing, and see any bullets you didn't paste.
- **The orders mart repo or docs, with the star schema:** this is the inspectable artifact that would move E2 from a self-reported claim to a verified one.
- **The vendor-pull scripts or the dbt job config:** either could change R2 and R3 from `not_evidenced` to real rows.
- **An older resume version:** it may hold lines your current one dropped.

## Questions

G1 — What triggers your nightly dbt job (dbt Cloud schedule, cron, GitHub Actions, something owned by someone else), and did you set up or change that schedule yourself?
G2 — Do your vendor-API cron scripts load tables that the orders mart or other teams rely on, and do they have logging, retries or alerts?
G3 — Does the nightly job have to finish by a certain time for anyone, and did anyone track whether it did?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.