I'll read the reference files before building the ledger.
Sam, I'd check the keyword theory before spending time on it. I'd also say up front that for this posting, no wording change can fix the gap. The edits below only reorder and restate what you've told me.

**What the evidence says about ATS rejection.** The best sample I have is a vendor's interviews with 25 US recruiters. Only 8% (two people) had AI or content auto-rejection configured, and the vendor itself calls the sample themes rather than representative statistics. What those recruiters said most often rejects without a person is knockout questions on the application form, such as work authorization, required licence and location. Where match scores exist, they mostly decide who gets reviewed first. A low score isn't an auto-reject, but in high-volume roles it can push you down the pile. So keywords can matter for ranking, and a rejection with no human read is more likely a form-question knockout. Check which questions the Ridgemount form asked you. This posting lists about 20 tools and your resume evidences a handful of them. I won't write the missing ones in, because you'd have to defend each in an interview. Whether the role is worth applying to at all is job-underwriter's question, not this one.

I only have your summary of the resume, not the document. "Current line" below means your wording as you gave it to me. Nothing is applied yet.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." (kept as three separate sentences) | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | Two bullets: "Built our deploy pipeline in Jenkins" / "Maintain about 30 Jenkins jobs" | `split` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged wording — moved directly below the Jenkins bullets, and the qualifier stays attached)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E4 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "Python and Bash scripting; Docker; AWS (EC2, S3, RDS, IAM); Jenkins; Ansible for config management; CloudWatch for monitoring" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` resume | pending your approval |

- **E1:** the summary puts your strongest traceable evidence first. The Kubernetes sentence keeps "never went to production" in full.
- **E2:** the split is for scannability only. "About 30" stays on the jobs, not the pipeline.
- **E3 and E4:** these change position, not content. Python moves up because the JD names it. "Scripting" stays, because "Python developer" would be a different claim.
- **Cuts:** I haven't proposed any, because I haven't seen the rest of the resume.

## Coverage map

I read the priorities off the posting, which doesn't rank anything. Correct them if you know better.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes, hands-on exposure | must-have | `surfaced_by_edit` | E1, E3. Reads as a two-month proof-of-concept, not production | `[grounded]` your PoC sentence; `[inferred]` priority from the JD's first-listed tool |
| M2 | Kubernetes in production, AWS EKS | must-have | `not_evidenced` | Your PoC never went to production and no EKS is mentioned. See C1 | `[grounded]` resume; `[inferred]` priority |
| M3 | Terraform | must-have | `not_evidenced` | Ansible config management is a different tool and job. See C2 | `[grounded]` resume; `[inferred]` priority |
| M4 | CI/CD pipelines | must-have | `already_evidenced` | "Built our deploy pipeline in Jenkins" is a pipeline you built. The literal string "CI/CD" isn't claimed (see the prohibited list) | `[grounded]` resume; `[inferred]` priority |
| M5 | GitLab specifically | important | `not_evidenced` | Jenkins is adjacent, not the same tool. See the named absences | `[grounded]` resume; `[inferred]` priority |
| M6 | Python | important | `already_evidenced` | "Bash and Python scripting"; E4 moves it up | `[grounded]` resume; `[inferred]` priority |
| M7 | AWS | important | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" | `[grounded]` resume; `[inferred]` priority |
| M8 | Prometheus, Grafana, observability | must-have | `not_evidenced` | Only CloudWatch is stated. See C3 | `[grounded]` resume; `[inferred]` priority |
| M9 | SRE practices, owning platform reliability | must-have | `not_evidenced` | Maintaining 30 jobs doesn't say what you did about reliability. See C3 | `[grounded]` resume; `[inferred]` priority |
| M10 | ArgoCD, GitOps, Helm | important | `not_evidenced` | Nothing stated. C1 may reveal some | `[grounded]` resume; `[inferred]` priority |
| M11 | Istio, service mesh | important | `not_evidenced` | Named absence below | `[grounded]` resume; `[inferred]` priority |
| M12 | Vault | preferred | `not_evidenced` | Named absence below | `[grounded]` resume; `[inferred]` priority |
| M13 | Go | preferred | `not_evidenced` | Named absence below | `[grounded]` resume; `[inferred]` priority |
| M14 | Developer experience | important | `not_evidenced` | Nothing says who used your pipeline or what changed for them | `[grounded]` resume; `[inferred]` priority |

## Gap handling: recall prompts (pending your approval)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes in production, EKS, Helm, ArgoCD | must-have | A two-month PoC that never went to production. It doesn't say what cluster, tooling or workload it covered. | These sit at the head of the JD, and an unspecified PoC reads as exposure only. | A PoC cluster on EKS; an app deployed via a Helm chart; a GitOps tool tried in the PoC; ingress or mesh tried | The PoC write-up, a README, an architecture diagram, a repo | `[grounded]` what the resume says; `[generic]` how a PoC without detail reads |
| C2 | Terraform | must-have | Ansible and an AWS service list. No provisioning tool is named. | It is a named core tool in the JD and currently has no evidence at all. | Terraform in a personal AWS account; a Terraform change you made at work through a teammate's module; a CloudFormation template you wrote (adjacent, not the same) | A repo, a PR, a module | `[grounded]` what the resume says; `[generic]` cost of a missing core tool |
| C3 | SRE practices, observability, reliability ownership | must-have | CloudWatch for monitoring and ~30 maintained jobs. Nothing on alerts, on-call or incidents. | The JD ends on "own platform reliability", so a monitoring tool name alone doesn't answer it. | CloudWatch alarms you set and who got paged; an incident you fixed or a post-mortem you wrote; dashboards in any tool; an on-call rotation | Alarm config, a runbook, a post-mortem | `[grounded]` what the resume says; `[generic]` what the JD's last sentence asks for |

**Named absences (pending your approval).**

| Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|
| Go (preferred) | No Go anywhere in your material. | A small real tool written in Go, months of use before it carries weight. Low priority against C1–C3. | `[grounded]` resume |
| Istio, service mesh (important) | Nothing stated. | Production Kubernetes comes first. Installing Istio in a practice cluster would let you say exactly that and no more. | `[grounded]` resume |
| Vault (preferred) | Nothing stated. | Moving a real secret, such as Jenkins credentials, into Vault on a personal project. Not worth chasing for this role alone. | `[grounded]` resume |
| GitLab CI/CD (important) | Jenkins is adjacent, not the same tool. | Rebuilding a Jenkins-style deploy pipeline in a GitLab project would give you honest, specific evidence. | `[grounded]` resume |

## Not written, and why

- **"Terraform" or "infrastructure as code".** Ansible config management is a different tool and a different job.
- **"Kubernetes" in the skills line, "production Kubernetes", or "EKS".** A tool listed is not a tool owned, and your PoC never went to production.
- **"CI/CD".** You said "deploy pipeline", which covers the deploy side. If your Jenkins jobs also build and test code, say so and it becomes a row.
- **"GitLab".** Your pipeline is in Jenkins.
- **"Observability", "Prometheus" or "Grafana".** Your only monitoring tool is CloudWatch.
- **"Platform reliability", "SRE practices" or "owned reliability".** Maintaining jobs is not the same kind of work, and you haven't described incidents, alerts or SLOs.
- **"Platform Engineer" as your title, or "improved developer experience".** Your title is DevOps Engineer, and you haven't said who used the pipeline or what changed for them.
- **GitOps, Helm, ArgoCD, Istio, Vault and Go.** Nothing in your material supports them.

## Parse-safety check

I haven't seen the file, so this rests on your description. It also could not check whether the PDF has a selectable text layer, whether your section headings are conventional, or whether it contains any hidden text from the template.

| Check | Finding | Cost |
|---|---|---|
| Multi-column layout | Two columns will be read linearly, so the text interleaves. | Dates can detach from the roles they belong to. |
| Icons for each skill | Icons render as garbage characters or get skipped. | Any skill conveyed only by an icon is absent. |
| Contact details in the header | Headers are often discarded as page furniture. | You could be unreachable even where the content parsed. |

If you want the checks I couldn't run, upload the PDF. I've made no layout recommendations, only reported what breaks.

## Upgrade menu

- **The actual PDF or its text.** This lets me run the full parse check and quote your real lines instead of your summary.
- **A PoC write-up, repo or diagram.** This is the inspectable artifact that would raise the Kubernetes evidence.
- **Any older resume version.** It may hold evidence this one dropped.
- **The application form's questions.** Knockout questions are the likelier hard rejection, and I can check whether any of them would fail you.

## Questions

C1 — In the Kubernetes PoC, what did you actually set up: which platform (EKS or something else), and did you use Helm, ArgoCD, Prometheus/Grafana or Istio in it?

C2 — Have you written or run Terraform anywhere (work, a side project, a course), and what did it provision?

C3 — On your Jenkins and AWS systems, have you handled alerts, on-call or incidents, and did you set up any CloudWatch alarms or dashboards?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.