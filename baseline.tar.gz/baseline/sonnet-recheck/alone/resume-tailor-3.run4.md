I'll read the reference files the skill points to before building the ledger.
Nadia, here is the ledger. Nothing is applied yet.

**Dossier use:** I used the evidence_map rows R1 and R2 as they stand (both `adjacent`, `medium`), the pending edit E1, and both rejected inferences. I read `decision: conditional_go` and acted on none of it. I only have an excerpt, so I'm assuming its `role_profile` is this same Quartzline role. I also couldn't check whether your CV has changed since the dossier. Your CV reached me as prose, so every row traces to your own sentences as self-report. I couldn't see your real layout, so the "current line" cells are your sentences, not lines from a file.

## Edit ledger

`resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." on its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; inherited from dossier E1 and re-audited | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, placed first under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, placed second under the role, after E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Summary | *(no current line)* | "7 years as a solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

Audit notes, row by row:
- **E1:** The words are unchanged. "the whole team" keeps its scope and is not widened to the company. The dossier's edit still traces to your sentence.
- **E2, E3:** These change position only. "30+" stays attached to "client integrations", because your sentence doesn't say 30 clients.
- **E4:** It is three of your sentences kept as three sentences. The only added words are "as a", for grammar. I did not join them into one clause, because that would blur what each one claims. The summary names your real title up front and does not imply PM years.
- **Not proposed:** I didn't write a row for the playbook line or the tools line beyond E1. "Comfortable in Postman, SQL, OpenAPI specs." already stands as written.

## Coverage map

Priorities: the JD labels only the first as must-have. I've read the other listed requirements as `important` and the responsibilities as `important` or `preferred`.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier reads it as `adjacent`, `transferability`, `medium`: integration leadership is adjacent, and roadmap ownership and prioritisation authority are not evidenced. See N1 and C1. | `[grounded]` your CV has no PM title or PM years; dossier row inherited |
| R2 | Shipped API or platform products | important | `not_evidenced` | Dossier reads it as `adjacent`, `medium`. You led integrations of your vendor's APIs, and no sentence says you shipped one. See C2. | `[grounded]` CV and dossier |
| R3 | Technical fluency | important | `already_evidenced` | "Led 30+ client integrations of our REST APIs end to end." and "Comfortable in Postman, SQL, OpenAPI specs." No row needed. | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E4 put the client-facing integration work first. The evidence is client-side only. Nothing in your material covers engineering squads or internal leadership. | `[grounded]` CV |
| R5 | Own the roadmap | important | `not_evidenced` | E3 surfaces roadmap-input sessions, which are adjacent. Ownership and prioritisation authority aren't evidenced (dossier R1 reasoning). See C1. | `[grounded]` CV and dossier |
| R6 | Run discovery with integration partners | important | `surfaced_by_edit` | E3 and E4 surface "collecting client feedback for product". These are your clients, not integration partners, and I haven't relabelled them. | `[grounded]` CV |
| R7 | Write specs, drive delivery with two engineering squads | important | `not_evidenced` | "OpenAPI specs" appears only as a tool you're comfortable in, not as authored specs. See C2. | `[grounded]` CV |
| R8 | Define adoption metrics | preferred | `not_evidenced` | No sentence mentions measuring usage or adoption. See C3. | `[grounded]` CV |

## Gap handling

### Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap and prioritisation (R1, R5) | must-have | Sessions that collected client feedback "for product". It doesn't say who decided what was built. | The must-have is PM years, and prioritisation authority is the piece the dossier says is missing. | A shortlist you ranked and sent to product; a request you pushed through or declined; a client-facing commitment you set on timing | The write-up or deck from a session; a ranked request list | `[grounded]` what the CV says and omits; `[generic]` why it matters on applications of this kind |
| C2 | Shipped API products; specs and delivery (R2, R7) | important | Integration work on your employer's APIs. No sentence about writing requirements or being involved in a release. | A reader can't tell integrating an API from shipping one. | A change request or requirements write-up engineering built from; a beta or early release you ran with clients; a deprecation or migration plan | A spec, change request, launch note or release note | `[grounded]` what the CV says; `[generic]` what the gap costs |
| C3 | Adoption metrics (R8) | preferred | Nothing on measuring usage or outcomes. | The role has you define adoption metrics, so any number you tracked would be direct evidence. | Time-to-go-live, number of endpoints a client used, integration success rates | A dashboard, report or screenshot | `[grounded]` CV; `[generic]` role pattern |

### Named absence

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | 3+ years PM (R1) | You have never held a PM title, and no sentence of yours shows years of PM work. Nothing in the ledger can close that. | Only C1 could: it would need to show product decisions you made under another title, and only if you confirm it. If it doesn't, apply knowing this must-have is met by adjacency alone. | `[grounded]` your CV and your note "Never held a PM title" |

## Not written, and why

- **"Product management experience" or any PM title or years.** You haven't held the title, and the JD makes it a must-have. Adjacent work is in E2 to E4. The gap is in N1.
- **Retitling "solutions engineer / implementation lead" to anything with "product".** A retitle must be an equivalent, and this one would be an upgrade.
- **"Owned" or "drove the roadmap".** You collected client feedback "for product". The dossier says ownership and prioritisation authority are not evidenced.
- **"Shipped API products".** You led integrations of your vendor's APIs. That is adjacent work, not shipping.
- **"Authored OpenAPI specs".** Your sentence says "Comfortable in … OpenAPI specs", which is familiarity, not authorship.
- **"Integration partners" or "partner discovery" for your clients and feedback sessions.** "Partners" and "discovery" are the posting's words, and yours are "client" and "feedback". The word change would move who you were working with.
- **"Managed stakeholders" or "worked with engineering squads".** Your material doesn't mention either.
- **"Defined adoption metrics".** Nothing in your material measures adoption.
- **From the dossier's rejected_inferences, unaltered:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership". It stays out, and I haven't re-asked about it.
- **From the dossier's rejected_inferences, unaltered:** "has been the customer of a partner API platform — candidate worked vendor-side". It stays out.

## Parse-safety check

Your CV arrived as pasted prose, so I could not run any of these checks:
- multi-column layout
- tables and text boxes
- images, icons and skill bars
- contact details in headers or footers
- non-standard section headings
- file type

If you send the file, I'll run all six. Nothing in the proposed text uses hidden or invisible content.

## Upgrade menu

- **Your CV as a .docx or text-layer PDF:** this would give me your real lines to quote verbatim and let me run the parse checks above.
- **The integration playbook, or its table of contents:** an inspectable document would back E1 beyond self-report.
- **A roadmap-input session output:** the summary or deck you gave product could turn R5 and R6 from adjacent into evidenced. It would also show what you did versus what product decided.
- **A spec, change request or launch note:** any one of these would answer C2.
- **A usage or go-live dashboard, report or screenshot:** this would answer C3.

C1 — In your quarterly roadmap-input sessions, did you decide which client requests went forward to product, or did you hand over the list and product decided?
C2 — Did anything you wrote, such as requirements, a change request or a beta plan, get built by engineering into your employer's API or platform, and what was your part?
C3 — Did you track any number on how clients used the APIs or how integrations went, and who saw it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.