I'll read the reference files the skill points to before building the pack.
The pack is written. I'm sending the file to you now, then I'll close with the offers and my questions.
Femi, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-canned-9876602b/9e43a778-b81d-4154-9931-cd07548641af/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions.

I built it for what Saltmarsh's interviewing page calls the Outage Hour. That's one 60-minute session with the hiring manager: a live-incident tabletop on a simulated outage, then a values conversation. I assumed Tobias is that hiring manager and that you have about a day of prep, since the interview is Friday.

The question to rehearse most is C1. Saltmarsh's August news moves both titles to a season-pass model, and you've said you've never worked on a game with in-app purchases. The pack coaches the plain acknowledgment, then what your background does carry, then a plan stated as a plan.

Say the word and I'll play Tobias as the Skeptic on C1, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the hiring manager running your session, and did your recruiter say anything about the scenario or format? Either answer reweights the personas and the case bank.
2. Do you want a deeper research pass on Saltmarsh's strategy and Tobias's talks and writing? It's up to 6 more searches and 2 more fetches, and takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (the pack was built on that assumption; see the persona table for why)
**Round:** one 60-minute session. Saltmarsh's interviewing page describes it as the Outage Hour: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.
**Built on:** your JD and your background message, plus L1 research (Sources). Sized for about a day of prep, since the interview is Friday.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values |
| EXP | Whether your background claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and titles |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: C1**, the season-pass question. It is asked at exactly the point where your material is thinnest, so rehearse it until it is boring.

## Prep triage

| Order | Do this | Where |
|---|---|---|
| 1 | Say C1 aloud five times, including both follow-ups, until the plain acknowledgment comes out without a wince | C1 |
| 2 | Run the tabletop twice out loud, timed, thinking aloud: clarify, objective, segments, approach, metrics, risks | A1, A2, E1 |
| 3 | Pick one real story per Saltmarsh value, or decide you have none and rehearse the honest branch | B1, B2, B3, cheat sheet |
| 4 | Fill in the answer slots in B3, D1 and F1 from your own memory; write one sentence each | B3, D1, F1 |
| 5 | Pick your three reverse questions | Reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title and weekly content drops, with no events and no second title in it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events line makes a probe on events likely. If any of the drops were timed events, say how they were scheduled and what part was yours, in your own words; if they were not events, or the scheduling was not yours, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The JD's verb is coordinate; your second sentence is about leading, so it says nothing either way on coordinating. Answer slot: expect a probe on which of those four disciplines you worked with on each drop. If you worked with any, say which and what you needed from them, in your own words; if you did not, or someone else did the coordinating, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting the numbers, not owning a review or setting the KPIs, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: if you wrote or ran any review of how a drop performed, say what it covered; if there was no such review, or it was not yours, say so plainly and stay with presenting the monthly retention numbers |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with the checklist in the quote's own terms, that you wrote it and your QA team still uses it, because a named artifact beats an adjective. The quote says writing; expect a probe on how it was kept up, which B3 and E2 rehearse |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years are there, and the length is not a gate. Your material does not say whether the puzzle game was run as a live service. Answer slot: if it was, say what that meant for how your team worked, in your own words; if it was not, or you are unsure how to categorise it, say so plainly and stay with the four years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap; the quote is the requirement in your own terms. Lead with the calendar, the cadence and the two years exactly as the sentence has them, and expect a probe on how drops were prioritised, which the quote does not carry |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only it: "Each month I presented the retention numbers to the studio head." Your material says presenting them, not how they were defined or counted, so the probe on definitions is rehearsed in D1 as a slot |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written artifact touches the requirement without showing whether it reaches it. Answer slot: if you wrote player-facing notes, announcements or update posts for your drops, say how they were checked before they went out, in your own words; if you did not write them, or nothing checked them, say so plainly and stay with the checklist you wrote |
| F9 | Context, not a JD line: "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from January 2027, and retires per-title event teams in favour of a single live-ops group." — Saltmarsh news page, search result | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. The news names a season-pass model; it does not say how the pass is sold, so neither the pack nor you should assume |

## Reading the interviewer

| What | Detail | Provenance | What to do with it |
|---|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | [grounded] | The interviewing page names the hiring manager as the interviewer of the single 60-minute session, so the pack assumes that is him |
| Earlier path | Previously a QA lead at a console studio | [grounded] | Expect depth on QA, checklists and release calls: A5, B3, E2 |
| Published argument | GDC 2026 talk, "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | [grounded] | Expect questions on announced versus shipped: B2, B4. Do not recite the talk back to him; use the idea only where it genuinely fits an answer, in your own words |
| Shared vocabulary | His QA background and your checklist: "Wrote the release checklist our QA team still uses." — your message (F4) | [grounded] | Say the checklist in those words, then stop. No shared career jump is offered: no row carries your side of one |

Public professional footprint only. Both facts about him come from search-result snippets; the talk page and the news page were not opened.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event, plus a shared-calendar planning question | High. The interviewing page names the tabletop as the first half of the session, and a hiring manager's prior is live problems from the real roadmap | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values / Behavioral | The second half: a values conversation against Saltmarsh's three published values | High. The interviewing page names a values conversation, so a values-style round is detected; the values page supplies the three names | Choose a story per value where one of your sentences carries one; where none does, rehearse the honest branch rather than inventing the ending |
| Skeptic | Probes on the season pass, no team-lead history, and associate-level title | Medium. A hiring manager prior, and your own message states two gaps | Rehearse C1 until boring; bridges only from what you stated, limits said plainly, plus a ramp plan |
| Data-Driven Prober | Retention definitions and who chose what was reported | Medium. The JD names KPIs and retention, and your retention line is the only quantified-area claim | Say plainly how much you know about how the numbers were counted; name the assumption you would defend least |
| Pressure | Time-boxed status updates inside the tabletop | Low to moderate. A tabletop on an outage invites interruption, but nothing documents a stress style | Pause, restate, hold the position through two follow-ups, concede specifics |
| Conversational / Rapport | The opening biography and a casual question on their titles | Low. Likely at the start; still scored | A 90-second arc from your own sentences |
| Peer Evaluator | None expected | Very low. The session is with the hiring manager, not a peer | No bank; a reciprocity reverse question is not needed |

## Question banks

### A. Case / Strategist (weight: 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a four-day live event. At 14:00 the event reward is failing to grant for a share of players and the community channel is filling up. You're the producer on call. What do you need to know first, and what do you do in the first thirty minutes?" | CASE | [inferred] derived from the interviewing page's description of a live-incident tabletop on a simulated outage during a live event | Clarify aloud first: which players, since when, what exactly fails, who is on call. Then objective (stop the harm to players, keep what you say true), segments (affected and unaffected), approach (engineering and QA for cause, community for what players see, design for what the event can tolerate), what you tell players and when, metrics to watch (support volume, participation, retention of the affected cohort), risks. Challenge one premise, for example whether the event should keep running while the cause is unknown. The player update says only what is confirmed, with the time of the next one. The question needs no claim about your past, so the guidance makes none | The tabletop is the documented first half of the session, so a scenario of this shape is the likeliest opening; CASE because it scores structure, not a right answer |
| A2 | "Engineering says the fix is six hours away and the event ends in four. Extend it, compensate players, or let it end?" | CASE | [inferred] derived from the same tabletop description, with Saltmarsh's value "when the calendar and the players disagree, the players win" as the likely scoring lens | State the options, the criteria you will choose by (what players lose, whether the fix time is known or hoped, what each option costs the calendar), and make a call aloud. Then name what you would want to know that would change it. If the fix time is an estimate, say so to players. Use the value as a tie-breaker only if it is genuinely how you would decide, in your own words. No claim about your past | A follow-up that turns the tabletop into a decision under a stated value; CASE with VAL scoring |
| A3 | "From January our two titles share one events calendar and one live-ops group. Sketch how you would plan the first quarter. What do you need to know first?" | CASE | [grounded] on the Project Larkspur news page; "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify before structuring: what the season pass changes about cadence, what is shared and what stays per-title, how much content and QA capacity each cycle has, where the two titles' events could collide. Then structure: objective, calendar skeleton, dependencies on design, art, engineering, community and QA, review points. Say where this extends past your material: your sentence carries one main title, so reason aloud about the second rather than claiming to have done it. Challenge one premise, for example whether a shared calendar suits both titles equally | The strategy move changes the job in the JD, so this is the differentiator question; F1 is where it presses; CO content, CASE delivery |
| A4 | "What should a post-event review report, and which KPI would you trust least?" | JD | [grounded] on the JD's "own the post-event review and the KPIs it reports" | Start with the review's job: did the event do what it was for, and was what players were told true to what shipped. Then a short list of what it reports (participation, retention for the cohorts the event touched, support volume, what failed) and the one you trust least and why: that is the weakest-assumption move. Say how you would fix each KPI's definition before the event rather than after. No claim about your past | The JD gives the review and its KPIs to the role; F3 is where the material is thinnest, so the answer stays a method |
| A5 | "A release candidate for an event update fails QA the day before go-live. Walk me through the call." | CASE | [generic] | Ask first: what failed, how severe, who is affected, what a fix costs in time. Options: slip, ship with the issue disclosed to players, cut the affected piece. Say who you want in the decision and what you ask of QA, make the call aloud, state what players are told, and say what goes into the checklist afterwards. No claim about your past | The JD's checklist-with-QA line, delivered live; the interviewer's QA background makes it likelier; F4 is the row it draws on |

### B. Values / Behavioral (weight: 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed, and which one won." | VAL | [grounded] on the values page: "when the calendar and the players disagree, the players win"; "I ran the weekly content-drop calendar for our main title for the last two years." | Selection criteria: a time you changed or held a date because of what players would experience; it needs a named stake, what it cost, and what you told players. If no such time comes to mind, say so plainly, then either say how you would handle it or stay with what your sentence carries, that you ran the weekly content-drop calendar for your main title for two years | The first published value, asked in its own words; no quote carries a story for it, so the pack gives a scaffold and the honest branch |
| B2 | "Tell me about a time you had to correct something you had announced." | VAL | [grounded] on the values page: "we announce what is built, not what is hoped" | Selection criteria: something announced before it was finished; it needs what was said, what was true, and how you put it right. If no such time comes to mind, say so plainly, then say how you would handle it. Do not choose a story where the correction never actually happened | The second value and the interviewer's published argument point the same way, so this is the likeliest values probe; no quote carries a story for it |
| B3 | "You wrote the release checklist your QA team still uses. How does it get better after each release?" | VAL | [grounded] on the values page: "every release leaves the codebase and the checklist better than it found them"; "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and your QA team still uses it, which are the beats the quote states; tell them in your own words. Answer slot: the third value makes a probe on whether the checklist changed after releases likely. If it did, say what prompted a change and what part of it was yours; if it did not, or the changes were not yours, say so plainly and stay with the checklist you wrote | The third value names the checklist, and F4 is the one row that carries it; VAL because it scores the value, EXP because it tests the claim |
| B4 | "Patch notes are a promise. How would you make sure a patch note is true before it goes out?" | VAL | [grounded] on the GDC 2026 talk snippet and the JD's "clear written communication" | Structure: who verifies each line, when the notes freeze, what happens when a feature slips, who signs off, what players are told when it does. Answer slot: the JD's written-communication line makes a probe on notes you wrote likely. If you wrote player-facing notes or announcements for your drops, say how they were checked before they went out; if you did not write them, or nothing checked them, say so plainly and say how you would check them. Do not quote his talk back at him | The interviewer's own published theme, plus F8's requirement; VAL content, CASE delivery |
| B5 | "Tell me about a time you gave someone senior a message about a date, a scope or a number they did not want." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Selection criteria: a named stake, what you said, how it landed. If no such time comes to mind, say so plainly, then say what your material carries, that you presented the monthly retention numbers to the studio head, without describing how it was received, or say how you would handle it | A persona stem for the behavioural half; F3 and F7 are the nearest rows, and they say presenting only |

### C. Skeptic (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Both titles are moving to a season-pass model. You've said you've never worked on a game with in-app purchases. How would you approach planning events under a season pass?" | CO | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Hold-then-concede. Open with the plain acknowledgment, in the quote's words: you have never worked on a game with in-app purchases. Then what your material carries, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then a plan, said as a plan: how you would learn how the pass is structured, how events relate to it, who decides what an event is for, and what the post-event review would report beside retention. Follow-up 1, expect retention against revenue: reason aloud on a stated criterion and say what you would want to know. Follow-up 2, expect why take the risk: concede the gap in one sentence, return to the calendar sentence, and stop. Hold through both by returning to what the quotes carry | F9 is the pack's biggest gap and the company's own news raises it, so this is the objection most likely to arrive; CO because it scores strategy fluency, with Skeptic delivery |
| C2 | "This role coordinates design, art, engineering and community teams on each update. You've said you've never led a team. How does that change how you'd do it?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Hold-then-concede. Acknowledge plainly, in the quote's words, that you have never led a team, and note that the JD's verb is coordinate. Answer slot: if you coordinated across disciplines on your drops, say which and how a disagreement was settled; if you did not, or someone else did, say so plainly and stay with the calendar you ran. Then how you would work, as a plan: what you would ask each discipline for and when | The JD names four disciplines and your message states the negative, so this probe is predictable; F2 is where the material is silent |
| C3 | "The posting asks for three years producing live-service games, and you've been an associate producer for four. What did producing look like at your level?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Say it at its own scope: "4 years as an associate producer at a puzzle-game studio." and, within it, the calendar sentence. Answer slot: the JD's live-service line makes a probe on what the role covered beyond the calendar likely. If other decisions were yours, say which and what you decided, in your own words; if the calendar is what was yours, or there were no other decisions, say so plainly and stay with the calendar you ran. Let them draw the comparison with the title | The requirement is years of producing and the title says associate; F5 is the row, and the slot keeps the answer inside the quote |
| C4 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] derived from the thinnest fit-snapshot rows, F2, F3 and F9 | Pick one from the rows where your material is thinnest and say it in one plain sentence. Then the ramp, as a plan: what you would ask for, learn and check in the first weeks. The choice is yours, and the honest one is better than the comfortable one | A persona stem for the Skeptic; calibrated candour is what it scores |

### D. Data-Driven Prober (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were defined." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: monthly, and to the studio head, which are the beats the quote states. Answer slot: the JD's retention line makes a probe on definitions likely. If you know how they were counted, say it in your own words and name the assumption you would defend least; if you do not know how they were counted, or it was not yours, say so plainly and stay with presenting them each month | F7 is the only retention evidence and a prober reads it line by line; EXP because it tests what the line means |
| D2 | "When has a retention number surprised you, and what did you do about it?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Selection criteria: a number that moved against what you or the studio head expected; it needs what moved, what you looked at first, and what changed afterwards. If no such time comes to mind, say so plainly, then say what your material carries, that you presented the monthly retention numbers to the studio head, or say how you would investigate a surprising number | An open prompt on the JD's retention line; F7 carries presenting, not diagnosing |
| D3 | "Who decided which numbers went into that monthly presentation?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F3: monthly, and to the studio head. Answer slot: the JD's line on owning the KPIs the review reports makes a probe on who chose what was reported likely. If you chose or helped choose, say how, in your own words; if the set was fixed, chosen by someone else, or there was no choice to make, say so plainly and stay with presenting them each month | F3 is where ownership of the KPIs is thinnest; EXP because it scores attribution |

### E. Pressure (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. We're mid-outage, players are angry on every channel, and I'm the executive asking for a status. Go." | CASE | [inferred] derived from the tabletop description | Pause, restate the question in a sentence, then three beats: what is known, what is not known, when the next update comes. Hold the format through two interruptions by restating in one sentence. Concede uncertainty specifically rather than guessing. No claim about your past | Composure inside the tabletop; CASE because the content is a live problem |
| E2 | "You say you wrote the release checklist. How much of that was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold-then-concede on F4: the quote at its own scope, that you wrote it and your QA team still uses it. Answer slot: if others contributed, say who and what; if it was yours alone, or built from something you were given, say so plainly, then return to the checklist you wrote. Hold through two follow-ups by returning to that sentence, never adding to it | The standard attribution probe aimed at F4, the strongest row; EXP with Pressure delivery |

### F. Conversational (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you end up in live operations?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc using only those four sentences as beats: the four years, the calendar, the checklist, the retention numbers. Answer slot: nothing in your material says why Saltmarsh or why live operations. Say it in your own words; if the honest reason is the role itself, say so plainly rather than inventing a Saltmarsh-specific one | Casual, but the first impression and the motivation check; F5 and F1 supply the beats |
| F2 | "Have you played Tidepool Tactics or Lantern Row, and what did you notice about how their events run?" | CO | [grounded] on the Project Larkspur news page naming both titles | Before Friday, play whichever you can and note one thing that works and one thing you would ask about. The JD says two titles without naming them, so confirm which in the reverse questions. If you have played neither, say so plainly and say what you would look at first. No claim about your past | A casual homework check on the titles named in the strategy news; CO because it scores company knowledge |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A3, F2 |
| Coordinate design, art, engineering and community teams on each update | A1, C2 |
| Own the post-event review and the KPIs it reports | A4, D3 |
| Manage the release checklist with QA | A5, B3, E2 |
| 3+ years producing live-service games or apps | C3, F1 |
| Experience running a content calendar | A3, B1, F1 |
| Comfortable with player-retention metrics | D1, D2, D3 |
| Clear written communication | B4 |
| Value: Players Before Plans | B1, A2 |
| Value: Ship the Patch Not the Promise | B2, B4 |
| Value: Leave the Build Greener | B3 |

## Values cheat sheet

| Value (official name, source: saltmarshgames.com/values) | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what is good for players conflict, the players' side decides | No row carries a story. Selection scaffold: pick a time you changed or held a date because of what players would experience, with a named stake and a cost; if no such time comes to mind, say so plainly, then say how you would handle it (A2, B1) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No row carries a story. Selection scaffold: pick a time you corrected something announced early, with what was said, what was true and how you fixed it; if no such time comes to mind, say so plainly, then say how you would handle it (B2, B4) |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than before | F4: "Wrote the release checklist our QA team still uses." — your message. The beats are those the sentence states; whether it changed after releases is B3's answer slot |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You came into live operations from QA. What did that change about how you run a release?" | Ties to his own path and invites him to talk about the checklist side, where F4 is your strongest row | [grounded] on the talk page snippet describing him as previously a QA lead at a console studio |
| R2 | "Project Larkspur moves to one live-ops group and one shared calendar from January. Where does this role sit in that group, and what does the first quarter look like?" | Shows you read the strategy move and turns A3 into a conversation | [grounded] on the Project Larkspur news page |
| R3 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How do you measure that on your team today?" | Engages his published idea with a real question rather than a recitation | [grounded] on the GDC 2026 talk snippet |
| R4 | "Which two titles would I be producing for, and how do events work across them under a season pass?" | Resolves the JD's unnamed titles and the season-pass structure behind C1 | [grounded] on the JD's "two of our mobile titles" and the news page |
| R5 | "What would someone new to in-app purchases need to learn in the first ninety days to do this job well?" | Turns the biggest gap into a plan the interviewer helps write, rather than a defence | [generic] |
| R6 | "What does a good post-event review look like to you, and which number do you trust least?" | Mirrors A4 and signals you think about definitions before results | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F2 and F9 | The plain acknowledgment from your sentence: "Never led a team, and never worked on a game with in-app purchases." In the interview: "I've never led a team." No slot |
| Has worked on a game with in-app purchases, or on monetised events | Negative you stated, F9 | "I've never worked on a game with in-app purchases." Then a plan, said as a plan. No slot |
| Planned live events across two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one main title's weekly content-drop calendar, not events and not two titles. A3's slot stays inside the calendar you ran |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says presenting the numbers, not owning a review. D3's slot asks only who chose what was presented |
| Managed the release process with QA day to day | Inflated form of F4 | F4's quote at its own scope. The pack's observation: your material says writing the checklist, which QA still uses, not running releases. E2's slot stays inside the checklist |
| Produced a live-service game at producer level | Inflated form of F5 | F5's quote at its own scope. The pack's observation: your material says associate producer and a puzzle-game studio, with nothing on how the game was run. C3's slot stays inside the role you held |

## Sources

**Provided:** the JD text and your background message. No dossier, CV file, assessment or recruiter notes were provided.

**Searches and fetches sent:**

| Query or fetch | What came back |
|---|---|
| Search: "Saltmarsh Games values" | https://saltmarshgames.com/values |
| Search: "Saltmarsh Games interview process live operations producer" | https://saltmarshgames.com/careers/interviewing |
| Search: "Saltmarsh Games strategy news mobile" | https://saltmarshgames.com/news/project-larkspur |
| Search: "Tobias Wrenfield Saltmarsh Games" | https://talks.gdconf.example/2026/patch-notes-are-a-promise |
| Fetch: https://saltmarshgames.com/values | The page text: three values and their one-line meanings |
| Fetch: https://saltmarshgames.com/careers/interviewing | The page text: recruiter call, then the Outage Hour |

The news page (dated August 2026 in its snippet) and the talk page were read as search-result snippets only; they were not fetched.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet, B1 to B3: the three values by name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: one session, tabletop then values conversation; persona weights, A bank, values-style round detected |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3, C1, F2, F9 and R2: Project Larkspur, season pass, shared calendar |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, B4, R1 and R3 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your recruiter's note on the Outage Hour (the shape of the scenario, how the hour splits, whether anyone else joins) → persona weights and the A bank tuned to the real format
- Confirmation that Tobias is the hiring manager running your session → the interviewer read and persona weights move from assumed to confirmed
- Your answers to the slots in F1, F2, F3, F5, F8, B3 and D1, a sentence each in your own words → those rows move from discovery to quoted material and the guidance regenerates around them
- The content calendar or a post-event or retention review you produced, which are the artifacts a live-ops producer keeps → F1, F3 and F7 can rise from medium confidence to high
- A tuesday-dossier.md from job-underwriter → the highest-ROI objection and each weak area's allowed strategy come from verified evidence instead of being inferred here
