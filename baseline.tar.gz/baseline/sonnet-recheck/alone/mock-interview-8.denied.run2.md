I've read the skill's references. I'm now writing the prep pack for your three-round loop and saving it as a markdown file.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-denied-0ed7ce29/018e4c8f-3527-489e-bb2f-2824b1c7b6c4/scratchpad/ashgrove_member-experience-lead_interview_pack.md`.

I built it as a three-round loop from the recruiter's email, using only what you pasted. I ran no searches, and I haven't read the strategy brief itself, only the four points you relayed. No interviewer names are assigned, so there is no interviewer read.

The pack has about 28 questions across the three rounds, plus a fit snapshot, a values cheat sheet, reverse questions for each round, and a list of claims it won't coach.

The most important rehearsal is **C1**, the contact-centre objection in round 2. You've said you've never worked in a contact centre, and the JD asks you to own the process across it. The pack gives you four levels of follow-up: concede plainly, then hold only what you've actually said. Next most repeated are presenting above regional level and the complaints log.

Say the word and I'll play the Head of Member Services on C1, with live follow-ups and feedback against the pack's guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

How many days or hours of prep do you have before the loop? Your note says 21 October, but my session clock reads 5 November, so if that date has passed or moved, give me the new one and I'll size a rehearsal order to it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop, three scheduled rounds on 21 October (dates as given in the recruiter's email).

| Round | Who | Length | What it holds | Bank |
|---|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen | A and B |
| 2 | Head of Member Services, your future manager | 45 minutes | Mostly behavioural | C, D and E |
| 3 | Panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation; also the values round, scored against the four values | F, G, H and I |

The interviewers are known by role only, and no names are assigned yet, so there is no interviewer read. The loop is established by the recruiter's own email, so no archetype fallback is used.

## How to use this pack

- Personas describe how a question is asked. Types describe what is scored. Rows are tagged with both.
- Type key:
  - VAL: whether past behaviour shows Ashgrove's published values.
  - EXP: whether your claims survive a walk-through.
  - JD: whether you can do the listed job, gaps included.
  - CO: whether you can think at the company's altitude, using its strategy.
  - CASE: a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch.
- The single highest-ROI rehearsal in this pack is **C1**, the contact-centre objection. It will be asked in some form in round 2 and probably again in round 3. Rehearse it until it is boring. The next most repeated probes are B2, C5 and H2 (presenting to senior people) and A4 and C6 (the complaints log).

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on years, but it is a self-reported line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: "6 years in retail banking, the last 3 as a branch supervisor." The JD says customer operations and the line says retail banking. Let the interviewer make that mapping, and do not rename your work |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal log. It does not show which rules or deadlines governed it. The words stay at the quote: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on what rules or deadlines, if any, the log was kept to likely. If it was kept to particular rules or deadlines, say which and what your part was, in your own words. If you do not know what governed it, or it was kept to branch practice, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD, branch side | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log, not a process across branches. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on where your part of a complaint started and stopped likely. Say where it started and where it stopped, in your own words. If you do not know what happened to it after your part, say so plainly and stay with the log you handled |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact centre side | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre handling, and nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built a monthly spreadsheet. It does not show what it counted. The words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted and how. Say what it counted, how each figure was counted, what it is sensitive to, and the assumption you would defend least, in your own words. If you do not know how a figure was derived, say so plainly and stay with the spreadsheet |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The line says spreadsheet, not Excel, and where a sentence admits two readings the pack takes the one that claims less. Answer slot: the JD makes a probe on tool and skill likely. Say which tool it was built in, and any feature you relied on, in your own words. If it was simple, say so plainly and stay with the spreadsheet |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers, not supervisors. The words stay at that scope: "I trained new tellers on our escalation script." Answer slot: the JD's supervisor line makes a probe on who you have trained likely. If you trained anyone beyond new tellers, say who and what your part was. If not, say so plainly and stay with the new tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated gap. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. The pack's reading: whether Ashgrove's senior leaders sit above your regional level is not established, so rehearse as if they do. No claim of leadership-level presenting, and no claim of confidence the material does not carry |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this, which is not the same as a gap you have stated. The June 2026 brief's digital target makes the line central, not mid-list. Answer slot: if you have worked with a digital team or on a self-service journey, say what and which part was yours, in your own words. If not, say so plainly and say what you would ask the digital team first |

## Grounding brief

All four rows come from the 2026 strategy brief as you relayed it. I have not read the brief itself.

| Point | Provenance | What it means for answers |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | Feeds F9, B4, C2 and E1. Expect "digital" to appear in every round, not only the digital question. |
| Consolidate eight branches into five hubs over 2027 | [grounded] | Feeds G3. Two of the three rounds involve people who may be inside this change, so ask rather than predict. |
| Launch a small-business lending product in Q1 2027 | [grounded] | A new product line means a new complaint type. This is a possible aside in A3 or E1, not a pillar. |
| Main competitive pressure is app-only banks | [grounded] | Gives A3 and E1 a competitive frame: a slow or repeated complaint is a reason to leave. Use it as your reading, labelled as one. |

The brief is dated June 2026. If anything has been announced since, the recruiter is the place to check.

## Persona tables (weights shown with reasoning)

### Round 1: recruiter, 30 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured: the journey, why Ashgrove, what you know | High. The relationship prior for a recruiter screen is conversational, and 30 minutes leaves room for little else | A 90-second arc; treat casual questions about the JD's hot topics as scored |
| B. Skeptic, light | Knockout-style checks on the gaps in a friendly register | Medium. The JD names a contact centre, regulated complaints and senior presenting, and your own message states two of those as absent | Say the stated gaps plainly, add one sentence of plan, and stop |
| Others | Not expected | Low. A 30-minute screen does not carry cases or pressure, so no bank | None needed |

### Round 2: Head of Member Services (your manager), 45 minutes, mostly behavioural

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C. Skeptic | Quiet probing of the gaps: contact centre, digital, coaching, senior presenting | High. A hiring manager is buying capability and derisking gaps, and the JD's gaps line up with F4, F9, F7 and F8 | Rehearse C1 to boredom; hold only what the quotes carry |
| D. Values/Behavioral | Stories: an unpopular truth, a member ahead of a metric | Medium to high. The recruiter's email says "mostly behavioural" | Selection scaffolds that end in the honest branch |
| E. Case/Strategist | Role problems on digital and reporting | Medium. The hiring-manager prior says case, but "mostly behavioural" pulls it down | Clarify, structure, then answer |
| Conversational, Pressure | Not the main register | Low. Nothing in the email points that way | Pause before answering if interrupted |

### Round 3: panel of two branch managers, 60 minutes, with a 20-minute case and the values scoring

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| F. Values/Behavioral | One story per published value | High. The recruiter's email says the panel is the values round, scored against the four values | Map a story or a scaffold to each value (values cheat sheet) |
| G. Case/Strategist | The complaint-escalation case, plus strategy cases | High. Twenty of the sixty minutes is a case | Clarify, objective, approach, metrics, risks; think aloud |
| H. Peer Evaluator | The seam between your coaching and their management; presenting numbers to them | Medium. The JD has you coaching branch supervisors and the panel is two branch managers. I read that as a seam you will be asked about | Seam principles, not a pretended seam; reciprocity |
| I. Skeptic | The gaps return from round 2 | Medium to low. The panel is two people with different priors, and the names are unassigned, so I blend | Same discipline as C1 |
| Pressure | Time-boxed pushes inside the case | Low | Hold, then concede specifically |

## Question banks

### Round 1: recruiter

Persona A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. What have the six years looked like, and why this role now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A 90-second arc with the beats the quote states: six years in retail banking, the last three as a branch supervisor. Tell them in your own words. Answer slot: the closing beat, why this role and why Ashgrove now, is yours alone. Say it in your own words, and name one of the published values only if that is honestly why. Stop at ninety seconds | The opener of most screens, in a casual register that is still scored. F1 is the evidence the arc rests on. EXP because it tests whether the arc matches the record |
| A2 | "What is it about Ashgrove specifically?" | VAL | [grounded] | Choose the one published value you honestly recognise and give its official name and Ashgrove's own words for it: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix. Then give one sentence of why it landed with you. Answer slot: if none matches what you have actually done, say what drew you to a member-owned credit union, in your own words, and no more. Keep the strategy for A3 | Motivation consistency is the core of a screen, and the value names are published, so they are checkable. VAL because it tests a published value by name |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Name two of the brief's four points accurately: 40% of member service digital by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, app-only banks as the main pressure. Pick the one that touches complaints and say what it means for the complaints process, as your reading and labelled as one. Do not recite all four. The recruiter sent you the brief and will hear a recital as homework, not judgment | The recruiter supplied the brief, so this is checkable. CO because it tests altitude |
| A4 | "The role needs experience handling regulated complaints. Where does yours sit?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the sentence at its own scope: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on what rules or deadlines, if any, the log was kept to likely. If it was kept to particular rules or deadlines, say which and what your part was, in your own words. If you do not know what governed it, or it was kept to branch practice, say so plainly and stay with the log. The honest branch is a limit, not a confession | F2 is the row a screen can check in one question. JD because it scores a stated requirement |

Persona B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The shortest answer in the pack. Words from the quote: "I've never worked in a contact centre." Then one sentence of plan, said as a plan: what you would do first to learn it. Stop there. No claim to contact-centre handling, and nothing added to shrink the gap. The full rehearsal is C1 | F4 is a stated gap asked as a plain check, and a plain check deserves a plain answer. JD |
| B2 | "How comfortable are you presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Words from the quote: "I've never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare for a leadership audience. Do not say "very comfortable" or "confident"; the quote supports neither. The full rehearsal is C5 | F8 is stated, and the JD names the requirement. This and B1 are the two places a screen can stop you. JD |
| B3 | "What would be hardest for you in the first month?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose between the two gaps your own message states, the contact centre and presenting above regional level, and say which you would rank harder and why, in your own words. Add one thing you would do about it. Answer slot: if a different part of the JD is harder for you, say which and why. Do not offer a strength dressed as a weakness | F4 and F8 are the stated gaps, and "weakest on day one" is the Skeptic's standard stem. JD |
| B4 | "Have you worked with digital teams on self-service journeys?" | JD | [grounded] | Answer slot: if you have worked with a digital team or on a self-service journey, say what and which part was yours, in your own words. If not, say so plainly and say what you would ask the digital team first. Nothing beyond that | F9 has no evidence, and the 40% digital target makes the requirement central. JD |

### Round 2: Head of Member Services

Persona C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked in a contact centre, yet this role owns the complaints process across it as well as the branches. How do you handle that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "6 years in retail banking, the last 3 as a branch supervisor." | **Highest-ROI prep in the pack.** Level one, concede first and plainly: "I've never worked in a contact centre." Then hold only what the quotes carry: "I handled the branch's formal complaints log." Level two, "what do you do in your first thirty days?": a plan, said as a plan. Clarify before acting, ask the contact centre team how complaints reach them and where they go next, and change nothing until you have listened. Level three, "contact-centre complaints have no counter, so what do you lose?": say plainly you do not yet know what is lost and what you would look at to find out. Do not describe contact-centre practice you have not worked in. Level four, "why not hire someone who has?": hold on the sentences you have, the six years and the log, and concede the learning curve. Never claim the centre side. If interrupted, return to the sentence, not to adding to it | F4 is the one stated gap the JD names in its first line, so this objection arrives in some form. JD because it scores the stated requirement; the pack gives it the most follow-up levels |
| C2 | "I don't see digital teams or self-service anywhere in your background. How would you handle that part of the role?" | JD | [grounded] | Answer slot: if you have worked with a digital team or on a self-service journey, say what and which part was yours, in your own words. If not, say so plainly. Then give the structure that needs no past: what you would want to learn first (which complaints begin in the app or website, and what members try before they complain), how you would decide what should not move to self-service, and what you would ask the team for. All of it as a plan. No claims | F9 has no evidence and the brief's digital target is the lead priority. JD |
| C3 | "The role coaches branch supervisors on escalations. Tell me about the closest thing you've done." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Words at scope: "I trained new tellers on our escalation script." Say who, what the script was for and how you ran it, only as far as you can say in your own words. Answer slot: the JD's supervisor line makes a probe on who you have trained likely. If you trained anyone beyond new tellers, say who and what your part was. If not, say so plainly and stay with the new tellers. Do not rename the training or add outcomes you cannot point to | F7 is adjacent work, and a manager scoring coaching will ask for the nearest example. JD, with EXP delivery |
| C4 | "Tell me about the monthly complaints spreadsheet. What did it count, and how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The words: "I built the monthly complaints spreadsheet our regional manager uses." Hold the verb you used, built. Answer slot: the JD asks for volumes and resolution times, so expect the probe on what it counted. Say what it counted, how each figure was counted, what it is sensitive to, and the assumption you would defend least, in your own words. If you do not know how a figure was derived, say so plainly. Answer slot: say which tool it was built in and any feature you relied on, in your own words; if it was simple, say so plainly. Where someone else supplied data or a format, say that too | F5 and F6 are the only evidence for reporting and Excel. EXP because it tests attribution; the defend-the-number move applies to any figure it raises |
| C5 | "Tell me about the most senior group you've presented to, and how it went." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Selection scaffold: pick the most senior audience you have actually presented to. It needs a named audience, the one point you had to land, and one thing you would do differently. Your own message puts your highest audience at regional level or below. If no presentation comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would prepare for one. Do not describe a room you were not in | F8 is stated, and the same probe returns at B2 and H2. JD |
| C6 | "Walk me through how a complaint moved through the log you handled." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Tell it at the scope the quote carries: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on the steps and on what governed them. Say the steps in the order you actually handled them, in your own words, and what rules or deadlines applied if you know. If you do not know, or there was no fixed step, say so plainly and describe how you handled the log | F2 and F3 together. EXP because it tests whether the log claim survives a walk-through |

Persona D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, the moment you did not soften it, and the relationship intact at the end. Choose one where the hard truth actually landed, and say what happened afterwards only as you know it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The recruiter calls this round mostly behavioural, and the stem is a staple. VAL because it maps to Plain Words and Own the Fix |
| D2 | "When did you put a member ahead of an internal metric or process?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick a time what the member needed and what the process or target wanted pulled apart. It needs a named decision, what it cost, and the member's outcome only as you know it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", at that scope, or how you would decide | Members First, rehearsed once before the panel scores it at F1. VAL |

Persona E: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants 40% of member service in digital channels by 2028. What should complaints data tell the digital team first?" | CO | [grounded] | Case structure. Clarify: what the data holds today (channel, complaint type, time to resolve) and what counts as member service in the 40%. Objective: the move must not create complaints, and the ones that need a person must stay with a person. Approach: separate complaint types that begin in a channel from those a channel causes. Metrics: resolution time and repeat contacts by channel. Risk: a digital journey that hides a complaint rather than resolving it. Challenge one premise respectfully, for example whether 40% is a ceiling or a floor for complaint handling. No claims about your past | The digital target leads the brief. CO with CASE delivery, built on the brief's number |
| E2 | "Walk me through what would be on page one of the monthly complaints report you'd bring me." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the decision the reader has to make, then the JD's two named measures, volumes and resolution times. Agree what counts as a complaint, when the clock starts and stops, and whether a branch and the contact centre use the same definition before you compare them. Say what you would flag as uncertain. Your own words for the past: "I built the monthly complaints spreadsheet our regional manager uses." Everything beyond that is plan. If asked which tool, see C4 | F5 and F6. JD, delivered as a CASE |

### Round 3: panel of two branch managers

Persona F: Values/Behavioral (one question per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Members First, Always. Selection scaffold: pick a time what the member needed and what the process or the clock wanted pulled apart. It needs a named decision, what it cost you, and the member's outcome only as you know it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", at that scope, or how you would decide | The panel scores against the four values, so each gets a question. VAL |
| F2 | "Tell me about a time something had to be explained twice, and what you changed so it didn't." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain Words. Selection scaffold: pick something written or said that a member or colleague needed explained twice. It needs the wording, what you changed in it and how you knew it worked, only as you know it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I trained new tellers on our escalation script", at that scope, or how you would rewrite it | The value's own test is "explained twice". VAL |
| F3 | "Tell me about your branch and its town. What do its members need that a monthly number wouldn't show?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Neighbours, Not Numbers. The quote carries three years as a branch supervisor. Answer slot: the value says every branch is part of its town, so expect a probe on the town itself. If you can name something about your branch's members that the numbers would not show, say it and how you came to know it, in your own words. If you cannot, say so plainly and say what you would ask a branch manager to learn it | F1 carries the branch role. F5's monthly reporting sits closest to this value's name, so the panel may press here. VAL |
| F4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Own the Fix. The quote carries the log you handled. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on one complaint. If there is a complaint from that log you kept hold of through to a solution, say what it was and what part was yours. If the log was a record and not something you pursued, or the solution was not yours, say so plainly and stay with the log. One complaint, not a pattern | F3 carries the log. VAL, and the case at G1 tests the same value live |

Persona G: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Practice case. A member has complained three times about the same fee, and each time the complaint has been passed between a branch and the contact centre. They walk into your branch today. What do you do in the next hour, in the next week, and for the process?" | CASE | [generic] | The scenario is mine; the real one will differ, so rehearse the structure. Spend the first three minutes on clarifying questions: what the member is asking for, what they have been told, who holds the complaint right now, and what clock or deadline applies (ask which, do not assume). Objective: the member leaves knowing who owns it and what happens next. Next hour: take it on at the counter. Next week: find where it was dropped and fix that. Process: what the pattern says and where to fix it at the source. Metrics: time to resolve and repeat contacts. Risks: a promise you cannot keep, another handoff. Say your structure aloud and challenge one premise respectfully | The recruiter's email says 20 minutes of the panel is a complaint-escalation case. CASE; `[generic]` because it is a pattern for the problem, not a fact about Ashgrove |
| G2 | "Practice case. Complaints at one branch have doubled over two months while the others are flat. What do you do?" | CASE | [generic] | Clarify before diagnosing: what changed (staffing, a product, how complaints are recorded, one issue), and whether the definitions and clock are the same across branches. Segment by type, channel and member group. Form two or three hypotheses and say what evidence would separate them. Speak to the branch manager before the figure goes up the line. Beware a recording change that looks like a surge. Metrics: volume and time to resolve against the others. Do not assume the cause | A pattern case on the reporting side of the role. CASE |
| G3 | "Eight branches are becoming five hubs over 2027. What happens to complaint handling in a town that loses its branch?" | CO | [grounded] | Clarify what a hub offers locally and which channels stay. Objective: the member still has a named person who keeps hold of the complaint. Approach: map where complaints from affected towns start, keep one owner across channels, and put the change in plain words. Metrics: complaints and time to resolve in affected towns against elsewhere, before and after. Risks: complaints about the consolidation itself, and a digital channel that does not suit every member. The panel are branch managers and the change concerns branches, so ask rather than predict, and do not say which will close. No claims about your past | The brief's consolidation point, aimed where it lands hardest. CO with CASE delivery |

Persona H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our supervisors report to us. Where is the line between you coaching them on escalations and us managing them, and what happens when we disagree?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Propose seam principles rather than pretend to know the seam. Ask what they want from the coaching. Offer that coaching covers how a complaint is escalated and the branch manager keeps line management. Agree who tells whom and when. If you disagree, say so in private first, with the member's case on the table. The nearest example of your own is "I trained new tellers on our escalation script"; do not call it coaching supervisors | F7 is adjacent work, and the panel are the people on the other side of the seam. The reporting line in the Question is my illustration of a branch; if theirs differs, the principle holds. JD with Peer delivery |
| H2 | "You'll show complaint trends to a room of branch managers who feel the numbers are unfair to their branch. How do you handle that?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Plan, not past. Pre-wire each manager before the room. Agree definitions first. Show the same measure for every branch and name the limits of the figures. Invite the manager's context before the verdict, and treat a number as a prompt to ask, not a verdict. Your own words for the past are only: "I built the monthly complaints spreadsheet our regional manager uses." | F5 and F8 together as a live problem; the audience is peers, so Peer delivery. CASE |

Persona I: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Which of our four values would be hardest for you to live up to, and why?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: name the value and the reason in your own words. Avoid a strength dressed as a weakness, and add what you would do about it. The pack does not pick for you. If it helps, consider whether a monthly-numbers role pulls against a value with "Numbers" in its name; that is a reading to test, not a script | F5 sits closest to the value that names numbers. VAL with Skeptic delivery |

## Values cheat sheet (round 3)

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's position, not the branch's or the process's | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The sentence carries the log, not a decision from the member's side. Selection scaffold at F1 ends with the honest branch |
| Plain Words | If a member has to hear it twice, the wording failed | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries training on a script, not plain wording. Selection scaffold at F2 ends with the honest branch |
| Neighbours, Not Numbers | Each branch belongs to its town | F1: "6 years in retail banking, the last 3 as a branch supervisor." It carries the branch role; the town beat is an answer slot at F3 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It carries the log; keeping hold is an answer slot at F4 |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, C1, C6, G1, G2 |
| "report monthly on complaint volumes and resolution times" | C4, E2, H2 |
| "coach branch supervisors on escalations" | C3, H1 |
| "work with digital teams on self-service journeys" | B4, C2, E1 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | A4, C6 |
| "confident presenting to senior leaders" | B2, C5, H2 |
| "comfortable with Excel reporting" | C4, E2 |

## Reverse questions

Round 1: recruiter

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What happens after the panel, and when would you expect a decision?" | Logistics, asked before you need them |
| R1-2 | "Can you tell me who the two branch managers are, or which branches they run?" | Turns the unnamed panel into people you can research |
| R1-3 | "Is this role new, or replacing someone, and what has changed since?" | Shows you are thinking about the role's shape, not only getting in |
| R1-4 | "What have the strongest candidates tended to show you for this role?" | Invites information a recruiter holds and you cannot research |
| R1-5 | "Is there anything in my background you would want me to address before the managers meet me?" | Surfaces an objection while you can still answer it |

Round 2: Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would a good first ninety days look like for this role?" | Lets your future manager set the bar you will be held to |
| R2-2 | "From your seat, where do complaints currently go wrong between branches and the contact centre?" | Shows ownership thinking and fills the gap F4 leaves |
| R2-3 | "Who does the monthly report go to, and what decision does it feed?" | Tells you how senior the audience really is, which F8 depends on |
| R2-4 | "How do you expect the move to five hubs to change this role?" | Ties the role to the strategy without reciting it |
| R2-5 | "How do you like to hear bad news from me?" | A manager-style question that signals you plan to raise problems early |

Round 3: panel

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do your supervisors find hardest about escalations today?" | Asks for their experience before offering any of yours |
| R3-2 | "What would make this role useful to a branch manager, rather than another layer?" | Names the worry a branch manager is likely to hold and invites it |
| R3-3 | "How are you thinking about the move to hubs, and what do you hope complaint handling protects?" | Opens the Neighbours, Not Numbers conversation on their terms |
| R3-4 | "Which of the four values does your branch find hardest to hold on a busy day?" | Shows you take the values as practice, not slogans |
| R3-5 | "What could a new person in this role do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the complaints process end to end across branches and the contact centre | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log. G1 and C6 stay inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says formal, and does not say what governed it. A4 and C6 ask only what the log was kept to |
| Has worked in a contact centre, or knows contact-centre handling from the inside | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers. C3 asks only who else was trained |
| Reported complaint volumes and resolution times to management | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material does not say what it counted |
| Advanced Excel skills | Inflated form of F6 | F6's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material says spreadsheet, not the tool or its features |

## Sources

Provided documents: the JD text; Ashgrove's four values as you copied them from ashgrovecu.org/about/values on 12 October 2026; the recruiter's email about the process; the 2026 strategy brief's four points as you relayed them (the brief itself was not read); your background statement.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text is in hand and fixes the values cheat sheet and the VAL bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the loop (three rounds, who runs each, what each holds), so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The brief's four points you relayed fix the grounding brief and the CO bank. A sweep for anything since June is in the deeper-research offer |
| 4. interviewer name plus company | n/a | No names are assigned, only roles, so there was no query to form. The interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names (the Head of Member Services and the two branch managers) → an interviewer read from their public professional footprint, persona weights per panel member, and at least one reverse question tied to a person's own path.
- Your CV → more of your own sentences to quote, which would lift the medium rows in the fit snapshot and turn selection scaffolds in F1, F2, D1 and D2 into story-mapped answers.
- Your answers to the answer slots in F2 (what the log was kept to), F3 (where your part started and stopped), F5 and F6 (what the spreadsheet counted and what tool), F7 (who you trained) and F9 (any digital-team work) → the rows that draw on them regenerate from your own words.
- The recruiter's answer on whether the case materials come in advance, and whether the branch managers will be named → a graded-deliverable section if a pre-read exists. Usually one email.
- The full text of the June 2026 strategy brief → CO questions that quote it directly rather than your relay of four points.
- Prep time before 21 October → a prioritized rehearsal schedule sized to it.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → anything announced since the June brief, recent organisational context, and role-family loop reports.
- A tuesday-dossier.md from job-underwriter → verified evidence, a named top objection and allowed strategies per weak area, in place of the objection this pack inferred. Not required.
