I'll start by reading the reference files the skill points to.
Reading's done. I have everything I need to build this as a three-round loop pack, so I'm writing it now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-canned-d24b4421/c5dc99c0-8ada-4d97-86eb-37419a8bb7be/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop for 21 October. My clock reads 5 November, not 12 October. If 21 October has already passed, tell me and I'll turn this into a debrief.

- **Structure:** each round has its own persona weights, 8 to 10 questions with answer guidance, and 5 reverse questions. Round 3's values cheat sheet maps the four values to C1–C4, and a table at the end shows which question covers each JD requirement.
- **Rehearse B5 first.** It's the contact-centre question: the JD's first line names the contact centre and you said you've never worked in one. Expect it in some form in all three rounds (A4, B5, C6, C10).
- **Senior presenting is the second open gap.** You said you've never presented above regional level, so the pack coaches you to say that plainly and follow it with a plan. It does not coach you to claim senior presenting.
- **Answer slots:** where your background doesn't show something the JD asks for, the guidance gives an instruction with two honest branches instead of an answer. That covers digital teams, what the spreadsheet counted, whether the complaints were regulated ones, and whether it was Excel. Your answers would let me turn those into proper stories.
- **Research:** I ran no searches. Your pasted values, the recruiter's email, the JD and the strategy brief points already covered every research target. The brief points are the four you relayed to me, not the brief itself.
- **No interviewer read:** Ashgrove hasn't assigned names yet, so that section is missing. The upgrade menu says what names would add.

Say the word and I'll run a live drill, with me as the Head of Member Services pressing B5. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 21 October 2026. **First version** (no changes to report).

| Round | Length | Who | What the recruiter's email says |
|---|---|---|---|
| 1 | 30 min | The recruiter | No focus stated |
| 2 | 45 min | Head of Member Services, who would be your manager | Mostly behavioural |
| 3 | 60 min | Panel of two branch managers | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not yet assigned, so there is no interviewer read in this pack.

## How to use this pack

- **Personas describe how a question is asked; types describe what is scored.** Each round has its own persona weights, with the reasoning shown so you can overrule it.
- **Type key.** VAL: past behaviour against Ashgrove's published values. EXP: whether your own claims survive scrutiny. JD: a stated requirement in the posting. CO: homework on Ashgrove's strategy. CASE: a live problem from the role.
- **Provenance key.** `[grounded]` traces to something you gave me. `[inferred]` is my derivation, with the derivation named. `[generic]` is a pattern with no claim about Ashgrove or about you.
- **Guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted in the row. Where your material is silent, the guidance is an **Answer slot**: an instruction for the interview with two honest branches, one of which is "that wasn't a thing, or it wasn't mine". Slots are not questions to me.
- **Highest-ROI prep: B5** (the contact-centre question). The JD's first line names the contact centre, and you have said you have not worked in one. Expect it in some form in all three rounds (A4, B5, C6, C10). Rehearse it until it is boring.

## Fit snapshot (shared across rounds)

Evidence is quoted from your message. Requirements are quoted from the JD you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log and training on the script, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far your part ran likely. If you had a part in stages beyond the log, say which and what was yours, in your own words; if you had none, or it was not yours, say so plainly and stay with the log and the script training |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote reaches monthly complaints reporting that you built and your regional manager uses; it does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what it counted. If it counted either, say which and how, in your own words; if it counted neither, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quotes carry training new tellers on the escalation script and three years as a branch supervisor; they do not show coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on supervisors likely. If you ever advised another supervisor through an escalation, say what the situation was and what part was yours; if you did not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this, and the strategy brief's 40% digital target makes a probe likely. Answer slot: if you have worked with a digital team or on a self-service channel, say what it was and what part was yours; if you have not, say so plainly and say what you would ask the digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. A years-of-experience line is not a gate. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The quote says formal complaints log, not regulated complaints, and the material does not show whether the two are the same. Answer slot: the JD says regulated, so expect a probe on what made the log's complaints formal. If they were regulated complaints, say so and in what sense, in your own words; if you do not know, or they were not, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Never a claim to senior presenting |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel, and does not show the tool. Answer slot: the JD says Excel, so expect a probe on the tool. If it was Excel, say so; if it was another tool, say which, plainly, and stay with the spreadsheet you built |

No row is a gate: the JD's requirements are experience and capability lines, not licences or legal terms, so no gate question is asked.

## Grounding brief (strategy brief, June 2026, as you relayed it)

I have the four points you gave me, not the brief itself. Use them as stated and add nothing to them.

| Point | Source | How to use it | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, per your message | Frames F5; use in A6 and B9; ask what it means for complaints rather than asserting | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, per your message | Directly touches a panel of branch managers; use in C3 and C8, and ask rather than opine | [grounded] |
| Launch a small-business lending product in Q1 2027 | Strategy brief, per your message | Optional context in A6; no complaints angle is claimed here | [grounded] |
| Main competitive pressure is app-only banks | Strategy brief, per your message | Optional context in A6 and B9 | [grounded] |
| Member-owned, about 900 staff | The JD you pasted | Context for how large the complaints process has to be; claim nothing further | [grounded] |

---

# Round 1: the recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; "walk me through the journey"; casual questions on JD topics | High. The recruiter-screen prior is Conversational plus a light Skeptic, and the email states no focus, so the prior stands | Pre-script a 90-second arc from your own quoted sentences (A1); treat casual questions on the contact centre and strategy as scored (A4, A6); use the reverse-question slot |
| Skeptic (light) | Knockout-style checks in a friendly register | Medium. Same prior. F2 and F8 are requirements you have said you do not meet, so the screen is the first place they can be tested; the email does not say they will be | Name the limit in your own quoted words before it is asked for, then give the plan (A3, A4, A8) |
| Values / Behavioral | Scenario probes | Low here. The email puts the values scoring in round 3 | Covered in round 3 |
| Case / Strategist | Live problems | Low here. The email names no case in this round | Covered in rounds 2 and 3 |

## Bank A: Conversational (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with only the beats those sentences state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Tell each in your own words and add no stages. Answer slot: close on why this role now. The reason is yours; if you have more than one, say the one you would defend under a second question | The biography question is the Conversational persona's standard opener. F6, F1 and F3 supply the beats. EXP because it is scored on whether your claims are stated at their real scope |
| A2 | "What's drawn you to Ashgrove, and to this role?" | CO | [grounded] | Use Ashgrove's own published words, not general praise. Pick the one value or strategy point that is truly why you applied: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix; or the brief's digital target, hub plan or small-business product. Criteria: you can say in one sentence why it matters to you and connect it to complaints work. If none of them is truly why you applied, say so plainly and give the reason you do have | Motivation consistency is what a recruiter screen can check cheaply. CO because it is scored on whether you speak Ashgrove's language rather than a generic one |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Name one of the two, in the quotes' own terms, before you are asked for the other: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Then stop and give a plan. Answer slot: the plan is yours; say the first two things you would do about it, in your own words. If you cannot yet say, say so plainly and say who you would ask. Do not dress either gap as smaller than the sentence says | The Skeptic stem for a screen, aimed at F2 and F8. JD because it scores the stated requirements, including the ones you do not meet |
| A4 | "The role covers the contact centre as well as the branches. How does your experience fit?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold, in order. Say "I've never worked in a contact centre", then the branch side at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. Answer slot: if your branch work ever crossed with a contact centre, say what and what part was yours; if it never did, say so plainly and say how you would find out how that side works. The limit is the pack's observation: your material is branch-side throughout | The first line of the JD covers both channels, and F2 is a stated gap, so this arrives early. JD because it is the stated requirement, asked casually |

## Bank B (Skeptic, light) and strategy awareness (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A5 | "Is there anything practical we should know — start date, hours, pay expectations?" | JD | [generic] | The pack holds none of your facts here. Settle your own answers before the call: earliest start, hours, pay range, anything fixed. Say each plainly. Answer slot: if one is not decided, say so and say when you will be able to | Practical checks belong to the recruiter prior. `[generic]` because the pack knows nothing about your constraints. JD is the closest of the five types, not a perfect one |
| A6 | "What do you know about where Ashgrove is heading?" | CO | [inferred] | Name the targets as the brief gives them: 40% of member service on digital channels by 2028; eight branches into five hubs over 2027; the small-business lending product in Q1 2027; app-only banks as the main competitive pressure. Then add one thought on what it means for complaints, put as a question you would want answered, not a fact. Derivation: the complaints angle is this pack's inference from the 40% target; the brief does not say it. Answer slot: if you have worked with a digital team or a self-service channel, say what and what part was yours; if not, say so plainly | The Conversational persona asks hot-topic questions casually. F5 is the JD line this touches. CO because it scores homework at Ashgrove's altitude |
| A7 | "What makes this the right next step after three years as a branch supervisor?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Anchor on the sentence: six years in retail banking, the last three as a branch supervisor. Then the step. Answer slot: the reason is yours; say what pulls you to the lead role, in your own words, without claiming lead-level work you have not described | A motivation-consistency check. F6 supplies the tenure; JD because the role is a step beyond supervisor |
| A8 | "Tell me about a time you presented to senior people." | JD | [grounded] "I've never presented to anyone above regional level." | The honest main branch is the quote: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say to whom, what it was and what part was yours; if not, say so plainly. Then give a plan for presenting to senior leaders, in your own words, as a plan and never as a past | F8 is a stated gap and the JD names senior presenting. The open prompt's theme comes from the JD |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "For the 20-minute escalation case on 21 October, is there anything I should prepare or know in advance, such as format or materials?" | The email names the case but not its format; the answer tells you whether it is a live exercise or has a pre-read |
| 2 | "Who will be on the panel, and which branches do they run?" | Names unlock the interviewer read this pack lacks; the email says interviewers are not yet assigned |
| 3 | "How is the role split between branches and the contact centre today, and who does the contact centre team report to?" | It is where your material is thinnest (F2), and the answer shapes your plan for B5 |
| 4 | "Is there anything in my background that gives you pause, so I can address it?" | It invites the F2 and F8 objections into the open early, where you have rehearsed them |
| 5 | "What does the process look like after round 3, and when do you expect to decide?" | Practical, and it shows you have read the three-round shape the email set out |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" scenarios, STAR-shaped | High. The hiring-manager prior is Case plus Skeptic, but the email says the round is mostly behavioural, so this moves up | Select stories from your own quoted material; "we" for context, "I" for contribution; where no sentence carries a story, use the scaffold and its honest branch (B1 to B4) |
| Skeptic | Quiet, persistent probing of the gaps by someone who would own the outcome | High. A future manager is derisking, and F2, F5 and F8 are open. B5 is the highest-ROI prep in the pack | Rehearse B5 until it is boring; bridge only from what you have quoted; give a plan, never a claimed past (B5 to B7) |
| Case / Strategist | A live problem from the actual role | Medium. The manager prior says high, but "mostly behavioural" pulls it down; two cases are included in case one appears | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully (B8, B9) |
| Conversational | Chatty openers | Low. The email does not suggest it | Covered by A1 |

## Bank: Values / Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you handled a complaint that was hard to settle." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The log is your setting but the quote carries no particular complaint, so select one. Criteria: you can follow it from first report to outcome, the decisions that were yours are separable from other people's, and you can say what you would do differently. "We" for context, "I" for what you did. If no such complaint comes to mind, say so plainly, then describe how you handled the log in general, or how you would handle one | The JD's complaints line makes this the staple behavioural question for F1. EXP because it tests what was actually yours |
| B2 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the one sentence: you trained new tellers on the escalation script. The new tellers, the script and your role as trainer are the beats the quote states; tell them in your own words. Answer slot: the JD's coaching line points at supervisors, so expect a probe on anyone more senior than a teller. If you coached a supervisor or colleague through a live escalation, say what happened and what part was yours; if you did not, say so plainly and stay with the tellers | F4 is the thinnest part of a JD line the manager will care about. JD because it scores the stated coaching requirement; the open prompt's theme comes from the JD |
| B3 | "When have you put a member's interest ahead of an internal target or metric?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick a time with a named stake, a decision that was yours, and something it cost; say what you weighed from the member's side. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, handling the branch's formal complaints log, or how you would decide | The customer-over-metric stem, tied to the first published value, Members First, Always. VAL because it scores behaviour against a published value |
| B4 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] | Selection scaffold. Choose a case where the hard truth actually landed, not one that stayed polite. Criteria: a named stake, what you said, how it was received, what changed. If no such time comes to mind, say so plainly, then say how you would deliver it. The pack claims no past here | The standard Values stem. `[generic]` because it carries no claim about you or Ashgrove. VAL because it scores the willingness to deliver the hard truth |

## Bank: Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "The role covers the contact centre as well as branches. How would you approach that side in your first weeks?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI prep.** Open with the limit, in your own quoted words, before it is pressed: "I've never worked in a contact centre." Then the plan. Answer slot: the plan is yours; say the first things you would ask to see, hear or sit in on, in your own words. If you cannot yet say, say so plainly and say who you would ask. Follow-up 1, "Then how can you own a process that runs through it?": hold by returning to the branch side at its own scope, the log and the script training, adding nothing. Follow-up 2, "What if the team will not take advice from someone who has not done their job?": concede the specific limit, that this is a real risk and the sentence above is why, then say what you would do about it, as a plan. Follow-up 3, "What do you bring that we could not hire elsewhere?": answer only from the quoted branch work and your own account of what you would do; claim no contact-centre insight | F2 is a stated gap against the first line of the JD, so this is the objection most likely to be asked in some form. JD because it scores a stated requirement. Deepest rehearsal means three follow-ups and the concession wording set out in advance |
| B6 | "The monthly reporting goes to senior leaders. Are you ready to present it?" | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say it first: "I've never presented to anyone above regional level." Then what you do have, at its scope: you built the monthly complaints spreadsheet your regional manager uses, which is a report built, not a presentation given. Answer slot: if you have spoken to your regional manager about what the spreadsheet showed, say what and how it went; if you have not, say so plainly. Then your plan for a first senior presentation, in your own words, as a plan | F8 is the second stated gap; the manager would be the one sponsoring you in front of leaders. JD because it scores the stated requirement |
| B7 | "Tell me more about the formal complaints log you handled — how did it work?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Describe in your own words what handling the log meant day to day; the quote carries only that you handled the branch's formal complaints log. Answer slot for F7: the JD says regulated, so expect a probe on what made the complaints formal. If they were regulated complaints, say so and in what sense; if you do not know, or they were not, say so plainly. Answer slot for F1: if you had a part in stages beyond the log, say which; if you had none, say so plainly and stay with the log | F7 and F1 both rest on this one sentence, so a prober reads it closely. EXP because it tests the exact scope of what you handled |

## Bank: Case / Strategist (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B8 | "Sketch how you would build the monthly complaints report for the whole credit union. What do you need to know first?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Think aloud in order. Clarify: who reads it, what decision it supports, what data exists in branches and in the contact centre. Objective. Definitions: the JD names complaint volumes and resolution times, so say how you would define each before counting. Metrics, risks. Challenge one premise respectfully. Answer slot for F3: for your own spreadsheet, if it counted volumes or resolution times, say which and how; if not, say so plainly and stay with the spreadsheet you built. Answer slot for F9: if it was Excel, say so; if another tool, say which | The JD's reporting line plus a manager who will read the output. CASE because it is a live problem from the role; F3 and F9 are the rows it touches |
| B9 | "The plan is to move 40% of member service to digital channels by 2028. What does that mean for how we handle complaints?" | CO | [inferred] | Take the 40% as the brief's figure and ask, rather than assert, about everything else. Clarify what counts as digital and which complaints start where. Then structure: who owns a complaint raised in an app (Own the Fix: whoever finds it keeps hold of it); how the member hears the outcome in plain words (Plain Words); what you would measure. Derivation: the complaints angle is this pack's inference from the 40% target. Answer slot: if you have worked with a digital team or a self-service journey, say what and your part; if not, say so plainly and say what you would ask the digital team first | The JD's digital line and the brief's headline target meet here. CO because it scores strategy fluency; F5 is the row it exposes |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want to be different about how members' complaints are handled a year from now?" | It asks for the manager's own agenda rather than a generic one |
| 2 | "How are complaint volumes and resolution times reported today, and who reads them?" | Tied to the JD's reporting line (F3); the answer also tells you how senior the audience is (F8) |
| 3 | "How does the contact-centre side of complaints work with the branches today, and where does it strain?" | Goes straight at F2 and gives you material for your plan |
| 4 | "How are you thinking about the 40% digital target in terms of complaints?" | Uses the brief's headline number and gets the manager's view on F5's territory |
| 5 | "What would you want me to do in the first month, and what support would there be for presenting to senior leaders?" | Names F8 as a plan rather than a worry, and asks for the support early |

---

# Round 3: panel of two branch managers (60 minutes, values round, with a 20-minute case)

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | High. The email says the panel scores against the four values | One story per value where a quoted sentence carries one; otherwise the scaffold and its honest branch (C1 to C4) |
| Case / Strategist | The 20-minute complaint-escalation case | High. The email names it and its length | Clarify before structuring; think aloud; use Ashgrove's own words (C5 to C7) |
| Peer Evaluator | "What would you need from us" and seam questions | Medium. The JD has you coaching branch supervisors on escalations; branch managers are the branch side of that seam. This is the pack's inference, not something the email says | Reciprocity first; propose principles rather than pretending to know their seam (C8, C9) |
| Skeptic / Pressure | A direct challenge on F2 and F8 | Medium-low. By round 3 the gaps have usually been aired, but a panel can ask them cold | Hold, then concede specifically (C10) |

## Bank: Values / Behavioral (4 questions, one per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. The quote says you handled the branch's formal complaints log; it names no decision of yours. Pick a time where the member's side and the branch's side pulled apart, the choice was yours, and you can say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, handling the log, or how you would decide | Members First, Always, in the panel's own phrase. VAL because it scores behaviour against that value |
| C2 | "Tell me about a time something you wrote or explained to someone had to be explained again." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped only as far as the quote: you trained new tellers on the escalation script, so the tellers, the script and your role are the beats. Answer slot: Plain Words invites a probe on wording. If a teller or member ever needed the script or a letter explained twice, say what it was and what happened next; if that never happened, or the wording was not yours, say so plainly and stay with the training. Do not claim to have written the script | Plain Words: "if a member needs it explained twice, we wrote it wrong". F4's training is the closest sentence you have. VAL because it scores the value |
| C3 | "Tell me about a time what the numbers said and what a branch or town needed pulled apart." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold. The quotes give you the numbers side, a monthly complaints spreadsheet you built, and the branch side, three years as a branch supervisor, but no occasion where the two pulled apart. Pick one you can describe, where you chose or advised, and say what happened for the branch's members. If none comes to mind, say so plainly, then give those two facts at their own scope, or how you would weigh them. Do not offer a view on which branches should close | Neighbours, Not Numbers. The 2027 hub plan makes this live for a panel of branch managers; that link is the pack's inference, not something the email says. VAL because it scores the value |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. The log is your setting; choose a problem you can follow from when you found it to when it was solved, where you kept hold of it yourself and can say what you did when the next step belonged to someone else. If no such problem comes to mind, say so plainly, then give the nearest thing, handling the branch's formal complaints log, or how you would keep hold of one. "We" for context, "I" for contribution | Own the Fix: "whoever finds the problem keeps hold of it until it is solved". It mirrors the JD's end-to-end ownership line (F1). VAL because it scores the value |

## Bank: Case / Strategist (3 questions; C5 is the closest to the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member has complained about the same problem for the third time. The branch records it as resolved; the member says it is not. Walk us through what you do." | CASE | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Think aloud in order. Clarify: what the member was told each time, what "resolved" meant on the record, who holds it now, which rules and time limits apply here (say you would check them, quote none). Objective: the member's problem solved and the record true. Owner: name who keeps hold of it, then stay with them (Own the Fix). What the member is told, in plain words. What is recorded and escalated. What pattern you would look for across branches. Challenge one premise, such as "resolved" in whose terms. Answer slot: if a repeat complaint ever came through the log you handled, say what happened and what part was yours; if none did, say so plainly and answer as a plan | The scenario is this pack's invention, so `[generic]`; the email gives only the case's topic. CASE because it is a live problem; the quote enters only as your starting point |
| C6 | "A branch supervisor escalates a complaint to the contact centre and the contact centre sends it back. Who holds it, and what do you do?" | CASE | [generic] "Never worked in a contact centre" | Principle first: whoever finds it keeps it until it is solved. Clarify what each side believes, what the member has been told, and what the clock is. Then the handoff: who confirms, in plain words and in writing, that the other side has it, and what you do afterwards so it does not recur. You have said you have not worked in a contact centre, so ask what the contact centre needs from a branch to take a case; ask it as a question, not a claim. This question asks for no past | A seam case between the two channels in the JD's first line. `[generic]` because the scenario is invented. CASE because it is a live problem from the role |
| C7 | "A supervisor keeps escalating complaints they could settle at the counter. How would you coach them?" | CASE | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Clarify first: what is being escalated, why, and what the supervisor is worried about. Objective. Then approach: listen, agree what they own, change one thing at a time, check back. Measure. Answer slot: the JD's coaching line points at supervisors. If you have coached a colleague at your own level or above, say what and your part; if you have not, say so plainly and note that the coaching your material carries is training new tellers on the escalation script | F4 is the row this lands on, and the panel are the people whose supervisors it would concern. `[generic]` because the scenario is invented. CASE because it is a live problem |

## Bank: Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C8 | "Over 2027, eight branches become five hubs. What does that ask of the complaints process?" | CO | [inferred] | The panel runs branches, so they hold the live view and you do not. Ask rather than assert: which complaints change hands when branches merge, who holds the open ones, what members in each town are told and in what words. Take the plan as the brief states it and no more. Say nothing about which branches or what is lost. This is where Neighbours, Not Numbers will be tested. Derivation: the complaints angle is this pack's inference from the hub plan | The hub plan touches this panel directly. CO because it scores strategy fluency at Ashgrove's altitude |
| C9 | "We are busy. What would you need from us, and what would we get from you?" | JD | [generic] | Reciprocity first: lead with what a branch gets, then what you need, both as principles you hold rather than a claimed past. Answer slot: name the two things you would offer a branch in the first months, in your own words; if you cannot yet say, say what you would ask them | The Peer Evaluator's standard seam question; `[generic]`, no claim about you or Ashgrove. JD because the role works with branch supervisors on escalations |

## Bank: Skeptic (1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C10 | "You have not worked in a contact centre or presented above regional level. Why should we back you?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold, then concede. Hold on what the quotes carry: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log, training new tellers on the escalation script. Concede both gaps in their own words: "I've never worked in a contact centre" and "I've never presented to anyone above regional level." Hold through two follow-ups by returning to the quotes, never by adding to them. Answer slot: your plan for each gap is yours to state; if you cannot yet say, say so plainly | The Pressure stem on F2 and F8 together. JD because it scores the stated requirements; the panel is whom the hold-then-concede structure is for |

## Values cheat sheet

Values are the published names, copied by you on 12 October 2026 from ashgrovecu.org/about/values.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a decision of yours. F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." is the setting only. Scaffold at C1, ending in its honest branch |
| Plain Words | If a member needs it explained twice, the wording failed | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." carries training on a script, not wording. Mapped as far as the quote, with an answer slot at C2 |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor." gives the branch side only. Scaffold at C3, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | F1's sentence is the setting; it shows no problem followed to a solution. Scaffold at C4, ending in its honest branch |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "How will the move from eight branches to five hubs in 2027 change what you need from the complaints process?" | Uses the brief's hub plan and asks the panel for their view of it |
| 2 | "When a complaint escalates from your branch today, what works and what frustrates you?" | Invites their experience; the answer is also free material for C5 to C7 |
| 3 | "Which of the four values is hardest to hold on a busy day in your branch?" | It is a values round, and the question turns the scorers into storytellers |
| 4 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | The reciprocity question; it offers help before asking for any |
| 5 | "What have you seen the move towards digital do to the conversation at the counter?" | Uses the brief's 40% target and asks the people who stand at the counter |

---

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| "Own the member complaints process end to end" | A4, B1, B7, C4, C5 | F1 |
| "across branches and the contact centre" | A3, A4, B5, C6, C10 | F2; the highest-ROI objection |
| "report monthly on complaint volumes and resolution times" | B8, B6 | F3 |
| "coach branch supervisors on escalations" | B2, C2, C7 | F4 |
| "work with digital teams on self-service journeys" | A6, B9 | F5 |
| "4+ years in financial-services customer operations" | A1, A7 | F6 |
| "experience handling regulated complaints" | B7, C5 | F7 |
| "confident presenting to senior leaders" | A3, A8, B6, C10 | F8 |
| "comfortable with Excel reporting" | B8 | F9; one question, with the tool as an answer slot |

All four published values are covered: C1 (Members First, Always), C2 (Plain Words), C3 (Neighbours, Not Numbers), C4 (Own the Fix).

## Prohibited claims

This pack will not coach these, and why. Two kinds of entry: wordings that stretch a sentence you wrote, and negatives you stated. A requirement none of your sentences speaks to (F5) is silence and sits in an answer slot, not here.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's formal complaints log, not the process end to end. B7's slot stays inside the log |
| Worked in, or with, a contact centre | Negative you stated, F2 | "I've never worked in a contact centre." Then a plan, never a past. No slot on a claimed contact-centre history |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: you built the monthly complaints spreadsheet your regional manager uses. The slot asks only what it counted |
| Coached branch supervisors | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: you handled the branch's formal complaints log. The slot asks only what made them formal |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." Then a plan, never a past |
| Built the reporting in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. The slot asks only which tool |

## Sources

**Provided documents:** the job description you pasted; Ashgrove's four values, pasted (copied from ashgrovecu.org/about/values on 12 October 2026); the recruiter's email on the three rounds, pasted; four points from the June 2026 strategy brief as relayed in your message (the brief itself was not read); your background, in your message. No interviewer information was provided.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix the values cheat sheet and C1 to C4; nothing a search could return would change them |
| 2. `Ashgrove interview process member services` | skipped | The recruiter's email establishes the loop: three sessions, with who runs each and what each holds. Persona weights follow it |
| 3. `Ashgrove strategy` / recent news | skipped | The four brief points in your message fix the CO bank (A6, B9, C8); a search would not change them. The brief's full text would deepen it, listed in the upgrade menu |
| 4. `{interviewer name} Ashgrove` | n/a | No names were given, so there was no query to form; the interviewer read is absent and the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Interviewer names, once assigned** → an interviewer read for rounds 2 and 3, persona weights adjusted to their public footprint, and a reverse question tied to their own paths.
- **Deeper research (up to 6 more searches and 2 more fetches, several more minutes; offered once)** → interviewer footprint once names exist, role-family loop reports, and recent organisation context for the CO bank.
- **The strategy brief itself** → CO and CASE questions grounded in more than the four points you relayed.
- **Your answers to the answer slots on F1, F3, F4, F5, F7 and F9** → those rows regenerate with your own sentences quoted, and the matching guidance cells become story-mapped rather than slots.
- **An anonymised copy of the monthly complaints spreadsheet, and the escalation script** → F3, F4 and F9 can move from medium confidence toward high, since a spreadsheet and a script are what this field can inspect.
- **The recruiter's reply on the 20-minute case format** → a build section if there is a pre-read or a required deliverable.
- **How much prep time you have before 21 October** → a prioritised schedule of the few things worth doing first.
- **A tuesday-dossier.md from an earlier evaluation of this role** → verified evidence and agreed prohibited claims to replace the ones built here.
