I've built the ledger from the sentences you pasted. Nothing is applied, and every row is pending your approval.

**Assumptions.**
- I treated each sentence you pasted as a current resume line, because I don't have your formatted document.
- Reorder rows keep your words exactly, "I" included. If you want resume voice throughout (dropping "I" and "I've"), say so and I'll add that as its own row.
- Your title stays "Senior Data Analyst". Retitling to anything with "engineer" in it would be an upgrade, not an equivalent, so no row proposes it.

**What the edits can do.** They lead with your dbt and star-schema work, which supports the dimensional-modelling requirement (R4) and part of data quality (R6). They can't cover the rest. R1, R2, R3, R5, R7 and R8 are `not_evidenced`, and three of those (R1, R2, R3) are must-haves. Whether to apply at all with three must-haves open is job-underwriter's call, not this resume's.

## Edit ledger — resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your pasted resume | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged — moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your pasted resume | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged — moved to second bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your pasted resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Two bullets: "Fixed our nightly dbt job when it breaks." and "Added tests to our nightly dbt job." (third and fourth bullets) | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your pasted resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | *(unchanged — moved to fifth bullet)* | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your pasted resume | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged — moved to last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your pasted resume | pending your approval |

- **E1:** the three sentences stay separate. "With our then-DE" stays attached to the star schema, so it doesn't read as sole design ownership.
- **E4:** the split uses only your words. The tests bullet is now visible as its own line, and it does not say you owned data quality.
- **E5:** your sentence doesn't say the cron scripts are written in Python, so I haven't said so. I kept "some" and "on a cron" as you wrote them.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | None of your sentences describes data engineering work; named absence A1 | `[grounded]` your title and sentences say analyst |
| R2 | Production Python | must-have | `not_evidenced` | E5 shows Python for analysis and some cron scripting, which does not establish production use; see C1 | `[grounded]` your sentence says "for analysis" |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | You have never used Airflow; the nightly dbt job in E4 is something you fixed, not something you built or scheduled; see C2 | `[grounded]` your sentences |
| R4 | Dimensional modelling (model the warehouse) | must-have | `surfaced_by_edit` | E1, E3, with E2 as supporting context; limited by "with our then-DE" | `[grounded]` your sentences |
| R5 | Build and own batch pipelines | important | `not_evidenced` | E2 and E4 are adjacent (dbt models, nightly job upkeep) but say nothing about building or owning pipelines; see C3 | `[grounded]` your sentences |
| R6 | Data quality | important | `surfaced_by_edit` | E4 puts "Added tests to our nightly dbt job" on its own line; limited to tests, not ownership | `[grounded]` your sentence |
| R7 | SLAs | important | `not_evidenced` | No sentence mentions deadlines, uptime or alerting; see C3 | `[grounded]` nothing in your sentences |
| R8 | Streaming experience | preferred | `not_evidenced` | Never touched Kafka; named absence A3 | `[grounded]` your sentence |

## Gap handling

Recall prompts. Each carries a question in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python "for analysis" and "some scripting to pull vendor APIs on a cron". It doesn't say what language the scripts use, where they load data, or whether anything depended on them. | A must-have with only analysis-level Python on the page leaves the requirement unmet on a first read. | The cron scripts loading into Redshift; retry or failure handling you added; a downstream model or report that relied on a script's output | A repo or script, a cron entry, or an alert or failure ticket | `[grounded]` what the resume does and does not say; `[generic]` how a reader treats "production" on DE postings |
| C2 | Airflow or equivalent orchestration | must-have | The nightly dbt job is something you fixed, with nothing on what scheduled it. | The posting accepts "equivalent", so what actually ran the job decides whether anything counts. | Scheduler configuration you changed; dependency or ordering between jobs; rerun or backfill steps you handled | A dbt Cloud or scheduler config, a runbook, or a job-failure thread | `[grounded]` what the resume does and does not say; `[generic]` how "or equivalent" is read |
| C3 | Build and own batch pipelines; data quality and SLAs | important | dbt models and nightly job upkeep, with no mention of ingestion, loads, alerting or deadlines. | These are the duties the role describes, and ownership is the line an interviewer probes first. | Ingestion or loads into Redshift you wrote or maintained; alerts you set up; a freshness or delivery deadline you were held to | Alert configuration, a freshness test, or an incident write-up | `[grounded]` what the resume does and does not say; `[generic]` what interviewers probe on ownership |

Named absences. Each carries a closing path.

| # | Gap | What closing it would take | Provenance |
|---|---|---|---|
| A1 | 3+ years data engineering. This is a years requirement, not a gate, and your five years are analyst years. | Answers to C1–C3 may surface adjacent pipeline work worth adding, but they won't change the title. Real closing paths: target roles that accept an analytics background, or a public pipeline project listed as a project, not as years. | `[grounded]` what the resume says; `[generic]` what each path involves |
| A2 | Spark. You've never used it. It appears in the duties, not in the requirements list. | A small Spark job on a public dataset, listed as a personal project, takes weeks. Skipping it is reasonable while the requirements list doesn't name it. | `[grounded]` your sentence and the posting; `[generic]` effort involved |
| A3 | Streaming and Kafka. You've never touched Kafka, and the posting calls streaming a plus. | A small producer and consumer project could close it, listed as a project. For a plus, leaving it absent is a defensible call. | `[grounded]` your sentence and the posting; `[generic]` effort involved |

## Not written, and why

```text
Not written, and why:

- "Data engineer" or "analytics engineer" as a title — your title is Senior Data Analyst;
  a retitle here would be an upgrade, not an equivalent.
- "3+ years data engineering" — no sentence of yours describes data engineering work.
- "Production Python pipelines" — you wrote Python "for analysis" and "some scripting to
  pull vendor APIs on a cron"; neither says production.
- "Python scripts pulling vendor APIs" — your sentence doesn't say the scripts are Python.
- "Built and owned batch pipelines" — you fixed the nightly dbt job and added tests;
  you didn't say you built or owned it.
- "Orchestration experience" — the posting's word; yours is a dbt job you fixed.
- "Owned data quality and SLAs" — you added tests; SLAs appear nowhere in your material.
- "Designed the warehouse model" or "led the star schema" — you designed it
  "with our then-DE".
- "Partnered with analytics on requirements" — you were the analyst; the posting's
  phrasing puts the candidate on the engineering side of that relationship.
- Spark, Kafka, streaming — never used, so none appear anywhere, including a skills list.
```

## Parse-safety check

Your resume arrived as pasted text, so I couldn't run any layout checks. These checks need the file: multi-column layout, tables and text boxes, images or skill bars, contact details in headers or footers, non-standard section headings, and file type. Send the .docx or PDF and I'll run them. The bullets above are plain text and add no tables, columns or icons.

## Upgrade menu

These would move rows from your own report toward inspectable evidence:
- Your dbt project, or its docs page or test config. It would support E1–E4 and R6.
- The vendor-API cron scripts, or a screenshot of the cron entries, which bear on C1.
- Whatever schedules the nightly dbt job: a scheduler config, runbook or failure thread, which bears on C2.
- Any alert, freshness test or deadline attached to the orders mart, which bears on C3.
- Beyond what's owed, I can draft a short project description if you build a small Airflow or Kafka project. It would be labelled as a personal project, and I'd only build it on your approval.

## Questions

C1 — What language are the vendor-API cron scripts in, where do they load the data, and has anything downstream depended on them?
C2 — What runs your nightly dbt job (dbt Cloud, cron, or something else), and have you ever changed its schedule, ordering or retries yourself?
C3 — Which parts of the pipeline feeding the orders mart (ingestion, loads into Redshift, alerting, delivery deadlines) have you worked on yourself, and for how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.