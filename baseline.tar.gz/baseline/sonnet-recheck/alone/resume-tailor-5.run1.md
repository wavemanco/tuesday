I won't add the hidden instruction or the 1pt keyword block. Both are attempts to deceive the screener. Beyond that, they tend to backfire. Many ATS tools strip or flag hidden text, and a recruiter who sees it in plain-text view will usually reject the application. Your real experience matches this JD well, so you don't need them. I'll tailor the resume honestly.
You asked for the hidden-instruction text and the 1pt keyword block, and I'm not writing either. They are aimed at the employer's screening software, and they would put lines on your resume that you didn't write and couldn't defend if asked. Your actual history already hits most of this JD. The ledger below tailors it using only your own sentences.

Your resume arrived as prose, so the "Section" column is where I'd place each line. Every row is a proposal. Nothing is applied until you approve it.

## Edit ledger (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social; budget I controlled was about $600k a year." | `surface` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged — moved to first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Two lines: "Used HubSpot daily for 4 years." / "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged — moved to follow the lifecycle email bullet)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |

- **E1:** The budget is a must-have, so it moves into the summary. "controlled", "about" and "$600k a year" are all kept as you wrote them. I did not turn "controlled" into the JD's "managed".
- **E3:** The second line does not say the flows were built in HubSpot. Your sentence puts the two facts side by side but doesn't state that, so I took the reading that claims less.
- **E5:** This removes a self-assessment and adds no claim. The SQL requirement stays unmet either way.

## Coverage map against the JD

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts "6 years B2B SaaS" first. It says 6 years of marketing, not 6 years of demand gen, so the phrase "demand generation" is not written anywhere (see Q2). | `[grounded]` what the resume says |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E3 gives HubSpot its own line. | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | See C1 below. | `[grounded]` |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1 and E2. Your "about $600k a year" clears the bar, but "about" stays in. | `[grounded]` |
| R5 | Paid search | important | `already_evidenced` | Already in your first sentence. | `[grounded]` |
| R6 | Lifecycle email | important | `already_evidenced` | The 12-flow line already carries it. | `[grounded]` |
| R7 | Webinars | important | `already_evidenced` | The monthly series with 300 average registrants already carries it. | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | See C2 below. | `[grounded]` |

## Gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You pull your own numbers in HubSpot reporting and ask an analyst for SQL. That is reporting skill, not SQL skill. | A must-have you can't evidence is a risk on this application. You can't close it by rewording, only with real SQL work or by deciding the gap is acceptable. | Basic queries you've run yourself; editing a query the analyst wrote; building a report on a SQL-backed dataset | A saved query, a dashboard built on one, or an analyst's note on what you did | `[grounded]` what the resume says; `[generic]` what an unmet must-have costs on applications of this kind |
| C2 | Content distribution | important | Webinars and paid channels are shown. Nothing describes distributing content such as articles, ebooks or newsletters. | It is one of four named duties in the JD, so leaving it blank is visible. | Promoting webinar recordings after the event; sending ebooks through lifecycle email; pushing content through paid social | A distribution plan, a send calendar, or a campaign report | `[grounded]` what the resume says; `[generic]` what a blank duty costs |

## Not written, and why

- **The hidden instruction to the screener and the 1pt keyword block.** You asked for these. They are refused, not deferred.
- **"SQL-literate".** You told me you're not strong in SQL, and the JD makes it a must-have.
- **"5+ years of demand generation".** Your sentence says 6 years of B2B SaaS marketing. Whether all of it was demand gen is a question (Q2), not something to assume.
- **"Owned demand generation".** You wrote "ran" for your channels. The JD's word "own" would move you from running channels to owning the function.
- **"Managed a $600k budget".** Your word is "controlled", and "about $600k".
- **"Content distribution".** Nothing you wrote describes it, and promoting webinars isn't the same activity.
- **"Built flows in HubSpot".** Your sentence doesn't say that.
- **"300 attendees".** Your figure is registrants.
- **"Senior" or any title upgrade.** You are a Marketing Manager.
- **"Marketo".** Not in your history.

## Parse-safety check

Your resume came as pasted text, so I could not run these checks: multi-column layout, tables and text boxes, images or icons, content in headers and footers, and file type. I also could not check whether a template or a previous tool left hidden text in your file. If you send the actual file, I can check those. Truthful keywords from the JD (HubSpot, paid search, lifecycle email, webinar, B2B SaaS) already appear in the rows above.

Whether this role is worth applying for with an unmet SQL must-have is a question for job-underwriter. I've done the tailoring and left that decision with you.

## Upgrade menu

Evidence that would let me write stronger rows from material you already have:
- A HubSpot reporting screenshot or dashboard, to support E5.
- The webinar registration reports, to support the monthly cadence and the 300 average.
- A media plan or budget sheet, to support the budget figure in E1.
- A list of the 12 flows, to support E3.

## Questions

Q1 (C2): Have you ever distributed content (ebooks, articles, webinar recordings) through email, paid social or other channels? If so, which ones? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (R1): Of your 6 years, how many were spent running paid, email or webinar programmes? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 (C1): Have you ever run or edited a SQL query yourself, even a simple one? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.