I'll read the reference files the skill requires before building the pack.
I'm writing the prep pack now. Research is done: Saltmarsh's values page, its interview-process page, the Project Larkspur announcement, and Tobias's GDC talk listing.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-canned-8476e64f/97b2cde7-9b14-4889-9fde-443691e0e99f/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across six personas.

I assumed Tobias is the hiring manager you'd report to. Saltmarsh's interviewing page says every loop is one 60-minute "Outage Hour" with the hiring manager. That is a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. So the pack puts the tabletop first and the values conversation second.

The highest-ROI prep is C1. Saltmarsh announced Project Larkspur in August 2026, which moves both titles to a season-pass model. You told me you've never worked on a game with in-app purchases. The pack gives you hold-then-concede wording that starts with the plain acknowledgment. It adds nothing to what you actually did.

Research covered Saltmarsh's values page, the interviewing page, the Larkspur announcement and Tobias's GDC listing. The Larkspur and talk facts come from search-result text only, not the full pages.

I can play the Skeptic on C1, the question the pack names as highest-ROI. Say the word and we'll run it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager you'd report to, and has the recruiter said anything about what the Outage Hour covers? The answer reweights the Case and Skeptic banks.
Do you want a deeper research pass? It would use up to 6 more searches and 2 more fetches and take several more minutes. It would add a Saltmarsh strategy brief and more on Tobias's talk.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** the Outage Hour, a single 60-minute interview. Saltmarsh's own interviewing page describes it as a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home.
**Built on this assumption:** Tobias is the hiring manager you would report to. The interviewing page says the Outage Hour is run by the hiring manager, but nothing you sent confirms that Tobias holds that role for this job. If he is not, the Skeptic weight in the persona table is the part that moves.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether the claims about your own work survive scrutiny |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role, with structure and reasoning scored |

Three labels appear throughout. `[grounded]` means traceable to your message, the JD, or a page read in Sources. `[inferred]` means derived from those, with the derivation named. `[generic]` means a role-family pattern with no claim about Saltmarsh or about you.

**The highest-ROI prep in this pack is C1.** It is the in-app-purchase question, and it will arrive in some form. Rehearse it until it is boring.

## Prep triage

Friday is a day away, so these are in priority order. Everything after item 4 is insurance.

| Order | Do this | Why |
|---|---|---|
| 1 | Say C1 aloud three times, with someone interrupting if you can | It is the objection aimed at your thinnest material |
| 2 | Run A1 and A2 against a clock: fifteen minutes of thinking aloud, then the player message | The first half of the hour is a tabletop |
| 3 | Pick your stories for B1, B2 and B4, or decide you have none and rehearse the honest branch. Write B3 out | The second half is the values conversation, and only B3 has a story your material carries |
| 4 | Say D2 and D3 aloud, including "I don't know how that was counted" if it is true | Those are the numbers and the checklist you will be asked to defend |
| 5 | Read Saltmarsh's values page and the Project Larkspur announcement once more | A3 and the reverse questions use them |

## Fit snapshot

Every quote in the evidence column is from your message. The row IDs (R1 onward) are what the rest of the pack refers to.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not live events and not two titles. Keep the words at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on moving from one calendar to two likely. If any of your calendar work spanned more than one title, or included timed events, say how, in your own words. If it did not, say so plainly and stay with the one calendar you ran |
| R2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | A calendar is not coordination of four disciplines, and the bridge should not be stretched. Answer slot: if any of those four teams had work in your weekly drops, say which and what your part was, in your own words. If some were not part of your drops, or the coordination sat with someone else, say so plainly and stay with the calendar you ran |
| R3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or set the KPIs, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: expect a probe on whether a review followed a content drop. If you ran or contributed to one, say what it looked at and what your part was. If there was no such review, or it was not yours, say so plainly and stay with the monthly numbers you presented |
| R4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with it as written: you wrote the release checklist, and your QA team still uses it. Nothing inspected sits behind the line, so expect a probe on it. The quote says wrote, not that you ran it release by release, so do not stretch it to that |
| R5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer at a puzzle-game studio. It does not say whether the title ran as a live service. Answer slot: the JD's live-service line makes a probe on that likely. If the title ran live, say how in your own words. If it did not, say so plainly and stay with the four years |
| R6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran it, weekly, for your main title, for the last two years |
| R7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. It says presented, so a probe on how the numbers were counted is likely (D2). Lead with the quote's terms: monthly, retention numbers, to the studio head |
| R8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | A checklist is one kind of writing. Your material does not show player-facing or team-facing updates, and the words stay at the quote's scope: "Wrote the release checklist our QA team still uses." |
| R9 | Working on a game with in-app purchases (not in the JD; role-family context, since the August 2026 announcement describes a season-pass model) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past (C1). Nothing is added to make the gap feel smaller |
| R10 | Leading a team (not in the JD, which asks for coordination, covered in R2) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Words: "I haven't led a team." The JD asks you to coordinate, not to lead, so keep those two apart. Then a plan for how you would get agreement, never a past |

## Reading the interviewer

Public professional footprint only. Both rows come from search-result text; the talk page itself was not fetched.

| Fact | Source | Provenance |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | GDC 2026 talk listing, as returned by search | [grounded] |
| Previously a QA lead at a console studio | Same listing | [grounded] |
| His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped | Same listing | [grounded] |

What this means for the hour:

- **Accuracy of what you say is the theme.** His stated argument is about announcements matching what shipped. Expect close attention to B2, A2 and anything you claim about your own work. Claiming less, precisely, fits that.
- **The checklist is shared ground.** He came up through QA and your sentence is about QA. R4's quote, "Wrote the release checklist our QA team still uses.", is the one line of yours that sits in his vocabulary. Tell it as written (D3, B3).
- **Do not fish for rapport.** Use the shared professional territory above and nothing personal.
- **Reverse questions 1 and 2 are built on this footprint.**

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | The tabletop: a simulated outage during a live event, with new facts arriving as you answer | Highest. Saltmarsh's interviewing page documents the tabletop as the first half of a single 60-minute loop, and a hiring-manager round leans toward case problems | Clarify, then objective, then options, then who you pull in, then what you tell players, then the review. Say the framework aloud and restate each new fact before you use it |
| Values / Behavioral (bank B) | A values conversation in the second half, tied to Saltmarsh's three published values | Very high. The same page documents the values conversation as part of the hour. Only one of your sentences (R4) carries a values story, so this bank is mostly scaffolds | Map the one story your material carries, and use selection criteria with the honest branch everywhere else |
| Skeptic (bank C) | Quiet probing of the in-app-purchase and team-leadership gaps, and of one title versus two | High. Hiring-manager prior, plus two gaps you stated yourself and a season-pass move in the August 2026 announcement | Rehearse C1 until it is boring. Say the plain acknowledgment first, hold what your quotes carry, concede one specific thing |
| Data-Driven Prober (bank D) | Line-by-line on the retention numbers, the calendar and the checklist | Medium. The JD asks for comfort with retention metrics, and his talk is about accuracy of claims. This is reasoning from his stated argument, not a read of his personality | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Pressure (bank E) | Time-boxed challenges inside the tabletop, or a sixty-second push on why you | Low to medium. A live-incident format tends to carry time pressure, but nothing documents a stress style | Pause, restate, anchor in what you said, hold through two follow-ups, concede one specific thing |
| Conversational (bank F) | A friendly opener before the tabletop begins | Low to medium. An opener is likely in any hour, and it is still scored | A 90-second arc built only from your four sentences |

## Question banks

Banks are in weight order. A is the tabletop. B is the values conversation.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event: the reward-claim button is failing for some players on one of the titles, and community is seeing angry posts. You have the next fifteen minutes. What do you do?" | CASE | [inferred] | Say your structure aloud first. Clarify: what exactly is failing, for whom, since when, and what is known versus guessed. Objective: stop the harm to players, then restore. Options: hold the event, extend it, or fix forward, each with its cost. Who you pull in (engineering, QA, design, community) and what you need from each. What players hear and when. What the review captures afterward. Expect new facts mid-answer: restate the new fact, say what it changes, then continue. Challenge one premise respectfully, for example whether it is safe to keep the event running while you diagnose. The question needs no claim about your past, so the guidance makes none | The interviewing page documents a live-incident tabletop in the first half, so this is the likeliest shape of the hour. `[inferred]` because the format is documented and this scenario is the pack's own. CASE because it scores structure under a live problem |
| A2 | "Draft the first message players see. What does it say, and what does it refuse to say?" | CASE | [inferred] | Say the sentences aloud. What is confirmed, what is being investigated, what players should do meanwhile, when the next update comes. What it refuses to say: a fix time you cannot back, a cause you have not confirmed, compensation nobody has agreed. Concede that any first message is partial, and say what you would update. Saltmarsh's value "Ship the Patch Not the Promise" is about announcing what is built, not what is hoped, so this is where it applies; say it in your own words if you use it | The values page raises announce-what-is-built, and the interviewer's talk argues the same point (reading section), so this question is likely and the answer is judged on restraint. R8 is the written-communication requirement. CASE delivery, JD content |
| A3 | "From January 2027 the two titles share one events calendar and the per-title event teams fold into a single live-ops group. If you were planning that first shared quarter, what do you need to know first, and what breaks first?" | CO | [grounded] | Clarify first: what the season-pass cadence promises players, who arbitrates when the two titles want the same slot, how work moves from per-title teams, and what has already been announced. Then segment: event types and what each depends on. Approach: one visible calendar and one conflict rule. Metrics: how you would see whether the shared calendar helps each title. Risks: announced items colliding, handover gaps. Use Saltmarsh's own terms: season pass, shared events calendar, single live-ops group. If the plan has moved since August, ask whether this is still the plan rather than correcting anyone. The question needs no claim about your past, so the guidance makes none | The announcement is the one dated strategy move in the research, and it changes what this job is for. Whether the JD's two titles are the two in the announcement is the pack's inference, not a fact, so ask (reverse question 3). CO because it tests current-strategy fluency, with CASE delivery |
| A4 | "Both titles want the same weekend. One has an announced event, the other a new-season launch, and engineering can support only one. How do you decide?" | CASE | [inferred] | Ask first: what has been announced to players, what each would cost to slip, what engineering can actually do, what QA needs. Then decide with a visible rule, for example announced commitments weigh more than planned ones. Say who you tell and when. Concede that someone loses the slot. The published value "Players Before Plans" says the players win when the calendar and the players disagree; use it as a test of your answer, in your own words | The JD's two-titles line (R1) makes calendar collisions the natural live problem, and the value is a raising source. `[inferred]` from the JD line and the values page. CASE because it scores decision structure |
| A5 | "The event has ended. What goes in the post-event review, and which numbers do you report up?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: what the event was for, what you would measure it against, what you cannot separate from the rest of the week, what you would change next time. If you name retention, say how you would count it. Tell your own history as the quote does: "Presented the monthly retention numbers to the studio head." Make no claim to having owned a review. Weakest-assumption move: name, in your own words, the assumption behind the figures you would report that you would defend least. If you do not know how a figure would be counted, say so plainly | R3 and R7 are the post-event-review and KPI requirements, and this is where they are tested as a decision. JD because it scores a stated responsibility; CASE delivery |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players pointed in different directions." | VAL | [grounded] | Selection scaffold. Pick a time a schedule date and what players would experience pulled apart. It needs a named stake, the call you made and who you told, and where it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack does not map a story here because none of your sentences carries one | The value "Players Before Plans" is on Saltmarsh's published values page. VAL because it scores behavior against a published value |
| B2 | "Tell me about a time you chose not to announce something because it was not built yet." | VAL | [grounded] | Selection scaffold. Pick a time you held back an announcement. It needs what you were asked to say, why it was not ready, who pushed back, and what you said instead. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value "Ship the Patch Not the Promise" is published, and the interviewer's talk argues the same point. It is the likeliest values probe, and no sentence of yours maps to it. VAL |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on R4. The beats the sentence states: you wrote the release checklist, and your QA team still uses it. Tell those in your own words. Answer slot: the values page says every release leaves the checklist better than it found it, so expect a probe on whether the checklist changed after you wrote it. If you revised it, say what and why. If it did not change, or the changes were not yours, say so plainly and stay with the checklist you wrote and the fact that QA still uses it | "Leave the Build Greener" is published, and R4 is the only sentence of yours that touches it. Likely and also the strongest story you have. VAL |
| B4 | "Tell me about a time you had to give a team or leader news they did not want." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Your material shows you presented monthly numbers to the studio head. It does not show whether any set carried unwelcome news. Answer slot: if a set did, say what you said and what happened. If none did, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Choose a story where the hard truth landed | A standard behavioral probe that fits the announce-what-is-built value. R3 is the closest row. VAL |
| B5 | "What would you want to leave greener in your first ninety days?" | VAL | [inferred] | A plan, not a past. Say what you would look at first (the release checklist and the review as they exist today), what you would ask the team, and what you would not change before you have seen it. The guidance makes no claim about your past | Tests the third value prospectively, because your material carries only one story for it. `[inferred]` from the published value |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our two titles are moving to a season pass, and you haven't worked on a game with in-app purchases. What do you do about that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | **The highest-ROI rehearsal in this pack.** Hold-then-concede. First, the plain acknowledgment, before any "but": "I haven't worked on a game with in-app purchases." Then hold only what your quotes carry, at their own scope: "I ran the weekly content-drop calendar for our main title for the last two years." and "Presented the monthly retention numbers to the studio head." Do not say these carry over to a paid pass; let the interviewer draw that. Concede one specific thing in your own words: what you expect is different about planning around something players have paid for. Then your ramp, as questions: how the pass is structured, what each event is meant to deliver to pass holders, and what the team tracks to know it is working. Follow-ups to rehearse. "How is that different from a free game's calendar?": say what you do not know yet and what you would find out. If you have a view from outside, say it labeled as an outsider's view. If you do not, say so. "What would you get wrong in your first month?": name one thing in your own words, and do not borrow one. "Why take that risk?": return to the quotes and add nothing. Hold through two follow-ups | R9 is the gap you stated yourself, and the August 2026 announcement makes a season-pass model central to the job. It is aimed where your material is thinnest, which is where a pack is most tempted to thicken it. JD because it scores the role's context; the delivery is a Skeptic's |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one you can answer plainly and say it first: "The weakest part would be X." Your material gives you three honest candidates: in-app purchases (R9), the step from one title's calendar to two (R1, quote above), and having presented rather than owned the review (R3). Then give a ramp, not an excuse. Do not pick a gap and then explain it away | The standard Skeptic opener, and the three candidates come from the fit snapshot. JD because it scores honest self-assessment against the listed role |
| C3 | "You ran a weekly content-drop calendar. This job coordinates design, art, engineering and community on every update. Which of those did your drops involve, and what was your part?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the sentence as written. Answer slot: the JD's coordination line is the raising source, and your sentence does not say which teams your drops involved. If any of the four had work in your drops, say which and what your part was, in your own words. If some did not, or the coordination sat with someone else, say so plainly and stay with the calendar you ran | R2 is the thinnest requirement row after R9 and R10, so this is the probe it invites. JD |
| C4 | "You haven't led a team. How do you get four disciplines to hold one date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment first: "I haven't led a team." The JD asks for coordination, so keep the two apart; do not argue that coordination is leadership. Answer slot: if any of your drops needed another discipline to hold a date, say how that was agreed, in your own words. If none did, say so plainly. Either way, close with a plan: what you would ask each team for first, so that no one is surprised later. Hold through a second push, and concede that you have not done it at this scale | R10 is a stated gap, and the JD's four-discipline line makes it a natural follow-on to C3. JD |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The beats the sentence states: weekly, content drops, your main title, the last two years. Tell those in your own words. Answer slot: the JD's calendar line makes a probe on how a drop got onto the calendar and who agreed it likely. If those decisions were yours, say how. If they were set by someone else, or there was no approval step, say so plainly and stay with the calendar you ran | R6 and R1 are the calendar requirements, and this is the first place the claim is tested. EXP because it scores what was actually yours |
| D2 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the sentence states: monthly, retention numbers, the studio head. Answer slot, the defend-the-number set: which measures were in the set, how each was counted, what the numbers were sensitive to, which assumption you would defend least, and which part was yours (whether you produced them or presented numbers someone else produced). Name the weakest assumption before they do. If you do not know how a figure was counted, say so plainly | R7 and R3. It is the likeliest place a prober digs, and the JD asks for comfort with retention metrics. EXP |
| D3 | "Walk me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the sentence states: you wrote it, and your QA team still uses it. Answer slot: if asked why a particular line is on it, answer in your own words. If you do not remember, say so plainly. Do not describe how it is used release by release unless you were there | R4, and the interviewer's QA background (reading section) makes this the question he can judge fastest. EXP |
| D4 | "A retention number moves the week after an event. How do you tell whether the event did it?" | JD | [generic] | A hypothetical, so the guidance makes no claim about your past. Say what else changed that week, what you would compare against, what you cannot separate, and what you would tell the room given that uncertainty. Name the assumption you would defend least | R7 asked as a live problem. JD content, CASE delivery. `[generic]` because it is a pattern, not a fact about Saltmarsh |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for a role that runs two titles, when you have run one calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate the question. Hold: the quote, at its own scope. Concede one specific thing: one title, not two. If any of your work spanned more than one title, say so; if it did not, say so plainly. Do not add to the quote under time pressure, because the second follow-up is where an addition breaks | R1 is the gap, and a sixty-second box is the likeliest way it arrives under pressure. JD |
| E2 | "That retention work. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: "Presented the monthly retention numbers to the studio head." Answer slot: if you also chose or produced the measures, say which. If the numbers were produced by someone else, say so plainly and stay with presenting them. Concede what you do not know about how they were built | R7 and R3. It is the standard attribution probe aimed at your one quantitative sentence. EXP |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you end up here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences, in that order. Then a reason for Saltmarsh. Answer slot: pick which of the three published values reads true to you, name it by its official name, and say why. If none does, say what draws you instead. Also answer slot: the JD's live-service line makes a probe on whether your title ran as a live service likely. If it did, say how, in your own words. If it did not, say so plainly | R5 is the live-service row, and the opener is scored even when it feels casual. EXP |
| F2 | "What is a live event you have seen done well in any game recently, and what did it get right?" | CO | [generic] | Selection scaffold. Pick one you can describe from the player's side: what it asked of players, how it ended, and what it got right. If none comes to mind, say so plainly and name what you would look at to find one. The guidance makes no claim about your past | A casual-register question that tests market awareness. `[generic]` because it is a pattern, not a fact about Saltmarsh |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4, D1, E1 |
| "coordinate design, art, engineering and community teams on each update" | A1, C3, C4 |
| "own the post-event review and the KPIs it reports" | A5, D2, D4, E2 |
| "manage the release checklist with QA" | D3, B3 |
| "3+ years producing live-service games or apps" | F1, E1 |
| "experience running a content calendar" | D1 |
| "comfortable with player-retention metrics" | D2, D4, A5, E2 |
| "clear written communication" | A2, D3 |

## Values cheat sheet

A values conversation is documented as the second half of the Outage Hour (Sources). The names below are Saltmarsh's official ones, and the working meanings are paraphrased from its values page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quote of yours carries a story. Selection scaffold at B1, ending in the honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote of yours carries a story. Selection scaffold at B2, ending in the honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | R4: "Wrote the release checklist our QA team still uses." Beats as stated, plus the answer slot at B3 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "You came to live operations through QA. What did that teach you about running events that you would want a new producer to learn early?" | Ties to his own path and invites him to teach, which turns an interview into a conversation | [grounded] |
| 2 | "Your GDC talk argues that patch notes are a promise. After an event, how does the team check that what was announced matched what shipped?" | Shows you have read his stated argument and asks about the practice behind it | [grounded] |
| 3 | "With the per-title event teams folding into one live-ops group from January, where does this role sit, and are the two titles in the JD the two in the Project Larkspur announcement?" | Shows current-strategy fluency and resolves the pack's one inference | [grounded] |
| 4 | "What would a strong first ninety days look like for this producer, and what would you want to have seen by the end?" | Signals you are planning the job, not just getting it | [generic] |
| 5 | "How is a post-event review used here: who reads it, and what has one changed?" | Tests whether R3's ownership line means what it says | [generic] |
| 6 | "What do candidates most often miss in the Outage Hour?" | A process question that is cheap to ask and usually answered | [generic] |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, R10 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or any monetization experience | Negative you stated, R9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of R1 | R1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a content-drop calendar for one main title |
| Owned the post-event review and its KPIs | Inflated form of R3 | R3's quote at its own scope. The material says presented the numbers |
| Managed the release checklist release by release | Inflated form of R4 | R4's quote at its own scope. The material says wrote, and that QA still uses it |
| Produced a live-service game for 3+ years | Inflated form of R5 | R5's quote at its own scope. The material says four years as an associate producer at a puzzle-game studio |

## Sources

**Provided:** the JD text, and your message describing your background.

**Searches sent (4):**

| Query | What came back |
|---|---|
| Saltmarsh Games values | https://saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | https://saltmarshgames.com/careers/interviewing |
| Saltmarsh Games strategy news mobile | https://saltmarshgames.com/news/project-larkspur (result text only, not fetched) |
| Tobias Wrenfield Saltmarsh Games | https://talks.gdconf.example/2026/patch-notes-are-a-promise (result text only, not fetched) |

**Fetches sent (2):** https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both returned.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; B1 to B5; the three values by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure (the Outage Hour); persona weights; values round detected |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3 and C1's premise; reverse question 3. Result text only, so the date and the shared-calendar and season-pass facts are as that text states them |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer; reverse questions 1 and 2. Result text only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's note on what the Outage Hour scenario covers, or on how it is scored → reshapes the A bank, and may replace A1 and A4 with the real scenario's shape
- Confirmation that Tobias is the hiring manager you would report to → settles the Skeptic weight and whether the persona table should be reweighted
- Your answers to the answer slots in R1, R2, R3 and R5 (what your drops involved, whether a review followed them, whether the title ran as a live service) → each becomes a quoted sentence in the fit snapshot, and R1 to R5 can move from discovery or transferability toward a grounded story
- A redacted copy of the release checklist, a retention report, or a sample content calendar → the artifact that could raise R4, R6 and R7 from medium to high confidence
- A prior underwriting dossier, if you have one → graded evidence and a prohibited-claims list from a separate reading of your material
