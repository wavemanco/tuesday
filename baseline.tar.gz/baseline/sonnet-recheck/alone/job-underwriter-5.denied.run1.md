I've read the skill's references. Next I'm checking Pellucid's careers and about pages to confirm the company exists and the posting is live, which is research target 1.
**Yes, it's worth applying to, on two conditions: you're US-based (or can work from Denver), and $148,000–$166,000 plus equity clears your floor. R1 and R2 are the hard gates I can't check yet. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5a, R5b, R6, R7
- `important`: adjacent: R8 (BigQuery as the warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 has a credible bridge from Snowflake with its limit named. R9 and R10 are open because your account says nothing about them.

**Opportunity ledger.** The stated terms are sound. Pay and scope read as ordinary for the title (RR3, RR5). The manager, team and equity terms are unknown (RR2, RR4). The employer and posting rest on text you pasted, which I couldn't check myself (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm R1 and R2 yourself.
  2. The posting is still live and the employer checks out on the day you apply (RR1).
  3. The BigQuery bridge is framed as adjacent, never as BigQuery experience (R8), and the Great Expectations suite isn't called data contracts unless you confirm that (R10).
- **What would change this:** it becomes `no_go` if you can't be in the US or Denver, or if the pay range sits below your floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; not independently checked |
| Posting status | Shown as "Accepting applications" at 09:12 today | `[grounded]` your report; I couldn't open the page to confirm |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack named | dbt, BigQuery, Airflow "or similar", data quality testing, Python, SQL | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD |
| Market calibration | The Datawright 2026 report (n=2,310, Series B–D) gives a base median of $151,000 and an interquartile range of $139,000–$163,500 for Senior Data Engineer. The posted low end is $3,000 under the median, and the top is $2,500 over the upper quartile. The report's typical seniority is 5–8 years against the posting's 5+ | `[grounded]` the recruiter's report, taken as provided and not independently checked; `[inferred]` the comparison |
| Scope read | One team's remit across ingestion, modelling and contracts. Whether that is "one domain, no reports" (the report's typical scope) or most of the data stack depends on team size, which the posting doesn't state | `[inferred]` from the JD's three responsibilities against the report's typical scope |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager, reporting line, team size, equity type and amount, how "data contracts" are enforced today | `[grounded]` JD silence |
| Contradictions | None between the posting and the about text as pasted | `[grounded]` both pasted texts |

## Evidence map

Your background was given as prose, so it counts as self-report. No requirement can rise past `medium` until something inspectable is attached, and I haven't seen your CV.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based. The JD's location terms are clear. Whether you meet them is unestablished, and no wording changes that | `[grounded]` JD quote; you gave no location | Answer G1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so I can't say whether the range clears it. The range sits at or above the report's median (see RR3) | `[grounded]` JD quote and the recruiter's report; no floor given | Answer G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You describe 6 years of data engineering at a B2B payroll company. It's specific and plausible, with nothing inspectable yet | `[grounded]` your intake message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a judgement that a technical screen will test | `[grounded]` your intake message; `[generic]` that technical screens test this | none |
| R5a | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. The number is yours, and the model count is the only scale you gave | `[grounded]` your intake message | Offer: a sanitized dbt docs or lineage screenshot would support raising this to `high` |
| R5b | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. This row meets the requirement as written. BigQuery specifically is R8 | `[grounded]` your intake message and JD wording "a cloud warehouse" | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. How much you authored versus maintained wasn't stated, and I'm not assuming either | `[grounded]` your intake message | Be ready to say what you personally built in Airflow |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. That is a first-person claim and a close match to the requirement | `[grounded]` your intake message | Offer: a sanitized suite config or checkpoint would support raising this to `high` |
| R8 | BigQuery as the dbt-modelled warehouse | important | adjacent | medium | transferability | The JD names BigQuery in the role description but only asks for "a cloud warehouse" in requirements. Your dbt-on-Snowflake work carries over. The limit is that you've never used BigQuery, so its specifics are untested. A small personal dbt project on BigQuery would narrow that | `[grounded]` your statement that you never used BigQuery; `[inferred]` the bridge from dbt-on-Snowflake | See G4 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Nothing you've said covers source ingestion from an application or a CRM. Pipelines at a payroll company may have involved sources, but I won't assume what or how | `[grounded]` the JD responsibility and your silence on it | Answer G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is an adjacent thread. Tests are not contracts with analysts. Whether analysts relied on tables you owned, and under what agreed expectations, is unknown | `[grounded]` the JD responsibility; `[inferred]` the thread from the suite | Answer G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The JD's terms are clear. Your location and floor aren't in what you gave me | Either one failing ends this role, whatever the fit | A US home address or a plan to relocate; a pay floor you've stated to the recruiter | None needed, since your own word settles it | `[grounded]` JD terms and your silence on them |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Nothing on source systems or how data arrived in your warehouse | The role is largely about ingestion, so this decides how strong the fit reads | Loading from a production application database; syncing a CRM or similar SaaS source; running a managed connector or writing your own extractor | A sanitized DAG, an architecture sketch, a README | `[grounded]` your silence on it; `[generic]` that ingestion work is typically probed in this role family |
| G3 | Data contracts (R10, important) | discovery | The Great Expectations suite exists. Nothing says analysts relied on agreed expectations | The JD says analysts depend on these contracts, and the word "contract" is a likely probe | Agreed schema or freshness expectations with a downstream team; a documented SLA; blocking a bad load before analysts saw it | A sanitized expectation suite, a schema doc, a runbook | `[grounded]` the JD and your account; `[generic]` that contract language gets probed |
| G4 | BigQuery (R8, important) | transferability | Snowflake plus dbt, no BigQuery | An adjacent row, with the limit named | A small personal dbt project on BigQuery | The repo | `[inferred]` the bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not independently verified | risk_signal | low | "Accepting applications" (your report) | The posting and company text are consistent with each other as you pasted them. I couldn't open either page, so liveness and company facts rest on your copies | `[generic]` pattern for companies of this size, not a claim about this one | Can you confirm this role is open and who the hiring manager is? | unresolved |
| RR2 | Hiring manager, reporting line and team size unstated | unknown | — | "Build and run the pipelines" | The role may be one of a team or may be the main data engineer; the JD doesn't say | `[grounded]` the posting names no manager (your report) | Who does this role report to, and how many data engineers are on the team? | unresolved |
| RR3 | Stated pay at or above the market median | positive_signal | — | "$148,000–$166,000 plus equity" | The range sits within the report's interquartile range at the low end and slightly above its upper bound at the top | `[grounded]` JD and the report as provided; `[inferred]` the comparison | Where in the range do offers for this role land, and what moves them? | noted |
| RR4 | Equity unspecified | unknown | — | "plus equity" | Type, amount and vesting are unstated, so its value can't be set against the cash range | `[grounded]` JD silence | What is the equity: instrument, amount, vesting and the current valuation basis? | unresolved |
| RR5 | Seniority and scope fit the market norm | positive_signal | — | "5+ years data engineering" | The JD's years bar sits inside the report's typical 5–8 years for Senior, and no direct reports are mentioned | `[inferred]` the JD against the report's typical scope | Which pipelines would this role own first? | noted |

## Application plan

Every row below, wording included, is `pending your approval`. The CV edit is `resume_edits_pending_approval`. I've limited it to what you stated.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the careers page on the day you apply and confirm the posting is still live | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV's data-engineering section with three claims in your own terms: the dbt project (about 180 models) on Snowflake, the Great Expectations test suite you set up, and Airflow for orchestration. Add "6 years of data engineering at a B2B payroll company" | R3, R5a, R6, R7 | `[grounded]` your intake message; I haven't seen the CV, so presentation gaps are unassessed | resume_edits_pending_approval |
| E2 | State BigQuery plainly. Proposed wording: "My warehouse work has been on Snowflake; I haven't used BigQuery." Don't describe Snowflake work as BigQuery experience | R8 | `[grounded]` your statement | pending your approval |
| W1 | Optional work sample: a small personal dbt project on BigQuery | R8 | `[inferred]` narrows the limit | pending your approval |
| Q1 | In the loop, ask the verification questions from RR2 and RR4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. The leads are your prose claims, which would need an inspectable artifact to rise.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring K-12 Denver Series C" and fetched pellucidlearning.com/careers/senior-data-engineer. Both calls were refused because permission wasn't granted. They would have moved role reality's organization, posting status and contradictions rows, and RR1 |
| 2. Role-family sweep | skipped | The recruiter's Datawright report is in hand and fixes the market calibration row and RR3 and RR5 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no name to query |

I can save this as `tuesday-dossier.md` to carry forward if you'd like.

## Upgrade menu

- Permission to search and fetch pages: it would let me confirm the posting is live and the company facts, closing RR1 and the unavailable target 1 row.
- Your CV, or its text: it would let me assess presentation gaps on R3, R5a, R6 and R7, which I can't do from prose.
- A sanitized dbt docs or lineage screenshot, or a Great Expectations suite config: either could raise R5a or R7 to `high`.
- Answers to G2 and G3: they would resolve R9 and R10, the rows most likely to move the decision from `conditional_go` to `go`.
- A deeper pass on Pellucid (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs once search permission is granted.

**G1 (R1, R2)** — Are you based in the US, or able to work from Denver? Does $148,000–$166,000 plus equity clear your pay floor?

**G2 (R9)** — Have you built ingestion from an application database or a CRM or similar SaaS source into your warehouse? Which source, and what did you personally own?

**G3 (R10)** — Did analysts or other teams depend on tables you were responsible for, with agreed expectations such as schema or freshness? Was that written down anywhere?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.