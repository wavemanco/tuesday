I'll read the reference files the skill points to before building the assessment.
**Yes, go for it, Renata.** R2, R3, R4, R5, R6a and R7 land `direct`, and R1 (the working pattern) is the open question · `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important`: adjacent: R8 (Recommendations for underwriting and product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance product domain)

R6b and R8 are discovery gaps your answers below can close. R10 has a credible motor-pricing bridge with its limit named.

**Opportunity ledger.** The mandate is concrete and the manager is named (RR5). But the working pattern contradicts itself across two sources (RR1), the employer's basics are not independently established (RR2), and pay is withheld (RR3). Team structure is unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as one you accept, see R1 and RR1; (2) the employer's basics verify, see RR2; (3) the pet-insurance bridge is framed as adjacent, never as pet experience, see R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Stage, size and regulatory set-up are not established | `[grounded]` JD header; `[grounded]` the one company search returned no results |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD and careers page |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD; careers page agrees |
| Working pattern | The JD says "Fully remote (UK)"; the live careers page says "Leeds office four days a week" | `[grounded]` both texts, see RR1 |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Compensation | Not stated in what you pasted | `[grounded]` JD |
| Scope read | An individual-contributor senior post. The JD names no direct reports and no line management, so having never managed anyone does not conflict with it. "Own" on a single product suggests a small or lead-analyst remit | `[grounded]` JD lists no management duty; `[inferred]` small remit from "own" plus one product |
| Market calibration | UK senior pricing analysts at insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (Pricewell 2026, n=612). This is the band to expect, never Brindlemoor's offer (RR3). Title and scope norms were not searched | `[generic]` one salary-survey result, read from the search snippet only |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). Before Brindlemoor she was head of pricing analytics at Calloway Re for six years. Monitoring looks like a live concern for this team | `[grounded]` public profile snippet; `[inferred]` monitoring relevance from the talk topic |
| Unknowns | Working pattern, salary, team size and support, first-year outcomes, company stage | — |
| Contradictions | JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` page fetched |

## Evidence map

Your background was typed into the conversation, so it counts as self-report of the same standing as a CV. Nothing has reached `high` yet. I have not seen your CV.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not yet said what working pattern you need, so there is nothing to grade. The role's own terms contradict each other (RR1) | `[grounded]` JD against careers page; no candidate constraint given | G1: tell me which patterns you accept |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, 2 as senior analyst. Confirmed and specific, no inspectable artifact yet | `[grounded]` your background as typed | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". "Strong" is unprobed, so expect a technical probe | `[grounded]` your background as typed | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. The scope is one book | `[grounded]` your background as typed | A sanitized model-documentation extract would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background as typed | none |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4: built the young-driver GLM | `[grounded]` your background as typed | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained" the model. That may include performance monitoring, but you never said so, so it stays a lead. This is the duty Odile Varga's public talk is about | `[grounded]` "maintained" is all the evidence; `[inferred]` monitoring may be part of it | G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | You "ran 14 price tests last year with the underwriting team". Whether you designed them or executed them is not stated, so expect a probe on which parts were yours | `[grounded]` your background as typed | Be ready to say what was yours |
| R8 | Recommendations to underwriting and product | important | adjacent | low | discovery | You ran tests with underwriting and present results to the head of underwriting. Making recommendations is not stated, and nothing mentions product. Taking the lower band | `[grounded]` as typed; `[inferred]` recommendation-making from presenting results | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background as typed | none |
| R10 | Pet-insurance product domain (inferred from "pet-insurance product") | preferred | adjacent | medium | transferability | Bridge: motor GLM rating and price testing is the same craft on an insurance book. Limit: you have not worked on pet claims or pet rating factors, and a different line has different rating factors and claims drivers | `[inferred]` requirement from JD scope; `[generic]` that lines differ in rating factors | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD offers fully remote; the careers page says Leeds four days a week; you have not stated what you need | A gate. If you need fully remote and the careers page is current, this role fails for you | — | Written confirmation from the recruiter of the current pattern | `[grounded]` the two texts; `[inferred]` the outcome depends on your constraint |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" the young-driver GLM, with no monitoring detail | A must-have; it is also the topic of the hiring manager's published talk | Tracking actual-versus-expected after launch; a regular model-performance review; recalibrating or refitting after a drift or a shift in the book; alerts or a dashboard others used | A sanitized monitoring pack, a model-review deck, a dashboard screenshot | `[grounded]` CV-equivalent silence; `[inferred]` relevance from the talk |
| G3 | Recommendations to underwriting and product (R8, important) | discovery | Tests run with underwriting and a quarterly review presented. No stated recommendation, nothing for product | The JD's closing clause; the underwriting side is probably there, the product side is unknown | Recommending a rate change from a test result; a test readout that changed a decision; taking results to product, marketing or commercial | A sanitized test readout or a review deck | `[grounded]` as typed; `[generic]` that this clause usually sits with the senior post |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor pricing only | Preferred and you have named it yourself. The bridge is real, and its limit decides how you frame it | Frequency and severity modelling, rating-factor selection, claims-trend work that carries across lines | A short note on how you would approach pet rating from your motor method, labelled a hypothesis | `[inferred]` bridge from the motor evidence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts itself | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale or generic. Severity rises to high if you need fully remote | `[grounded]` both quotes; `[inferred]` which is current is unknown | Is this role fully remote, or based in the Leeds office four days a week, and is there any flexibility? | unresolved |
| RR2 | Employer not established from independent sources | risk_signal | low | "Brindlemoor (insurtech)" | The company may be small or new with a thin footprint. Its own careers page is live and the hiring manager's profile names it, so I take the lower severity | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` the one company search returned nothing | What stage and size is the company, how big is the pricing team, and does Brindlemoor carry the underwriting risk itself or price for a partner? | unresolved |
| RR3 | Compensation withheld | unknown | — | No salary stated in the JD | The figure may sit above or below the band in role reality | `[inferred]` from the posting's silence, against the `[generic]` survey band | What is the salary range for this role? | unresolved |
| RR4 | Team and support unstated | unknown | — | "Own pricing analytics" | "Own" may mean sole analyst, with no stated data-engineering or tooling support | `[inferred]` from "own" against the JD's silence on team | Who else sits in pricing, and what data and tooling support does this role have? | unresolved |
| RR5 | Concrete mandate and named manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The responsibilities are specific and the reporting line is consistent across JD and careers page | `[grounded]` JD and careers page | What would a good first year look like for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open the CV with three lines in your own words: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting". Do not add "designed", "led" or "monitored" until G2 or R7 confirms them | R4, R6a, R7, R5. I have not seen your CV, so this is reordering only | `[grounded]` your background as typed | `resume_edits_pending_approval` |
| E2 | Cover note, one line: "My pricing experience is five years on a motor book; I have not worked on pet insurance" | R10: say the limit first, so it does not read as a hidden gap | `[grounded]` your background as typed | pending your approval |
| W1 | A one-page note on how you would approach pet rating from your motor method, labelled a hypothesis and not experience | R10, G4 | `[inferred]` from the motor evidence | pending your approval |
| A1 | Ask the recruiter, before investing in the loop, which working pattern is current | R1, RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR1 to RR5 questions verbatim in the interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Read Odile Varga's published talk before you apply. Lead with R4, R7 and R5; add monitoring only if G2 confirms R6b | Her public talk is on monitoring | `[grounded]` profile snippet; `[inferred]` relevance to this reader | pending your approval |
| F1 | If asked about line management, say you have not managed anyone; the JD lists no management duty | Plain candour on a gap that is not a requirement | `[grounded]` JD | pending your approval |

Everything in this section is proposed, and none of it is final until you approve it: the CV lines, the cover wording, and the prose advice in rows A2 and F1 alike.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so company profile not established) and "Brindlemoor careers Senior Pricing Analyst", which returned "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst); fetched that page. Confirmed the posting is live; surfaced the working-pattern contradiction (R1, RR1); fed RR2 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK salary insurance remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from the snippet only. Fed the market calibration and RR3. Scope and title norms were not swept |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from the snippet only. Fed the scope read and plan row A2 |

If you'd like, I can write this up as a `tuesday-dossier.md` to carry forward.

**Upgrade menu**

- Your working-pattern requirement, location and pay floor would settle R1 and run the pay check, which is not run now.
- Your CV or a prior CV would let me check for presentation gaps and turn E1 from description-based into CV-based.
- Answers to G2 and G3 would resolve R6b and R8.
- A sanitized model-monitoring pack would raise R6b, and a sanitized price-test readout would raise R7 (and could support R8), each toward `high`.
- The recruiter's answers on working pattern and salary would close RR1 and RR3.
- A deeper research pass on Brindlemoor (funding and leadership changes, hiring pattern, public employee reports; up to 5 more searches and 2 more fetches). Brindlemoor has little independent footprint, so this would help; say the word and it runs.

**Questions**

G1 — Which working patterns could you accept: fully remote only, hybrid with some office days, or Leeds four days a week? And roughly where are you based?

G2 — After the young-driver GLM went live, did you track how it performed against what you expected? What did you watch, how often, and what did you do with what you saw?

G3 — When a price test finished, were you the one who recommended the price change to underwriting? Have you ever taken results to anyone beyond underwriting, such as product or commercial?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.