I'll read the reference files the skill points to before building the assessment.
**Yes, apply. R1, the only hard gate, is unconfirmed rather than failed, and RR1 (employer unverified) keeps this at `conditional_go` instead of `go`.**

## Decision snapshot

Status: `conditional_go`

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7a
- `important` — adjacent: R10 (Pet-insurance rating knowledge) · unclear: R7b (Recommendations to product)
- `preferred` — direct: R9

R10 carries the pet-insurance limit you named. R7b waits on evidence of product-side work.

**Opportunity ledger.** Three entries are unresolved. The employer could not be verified (RR1), no salary is stated (RR2), and the remit, team and decision rights are unstated (RR3). One entry runs the other way: the duties are concrete and the hiring manager is named (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. RR1 clears: the role is live on Brindlemoor's own careers site.
  2. R1 is confirmed.
  3. G1 confirms you designed the price tests, so "design" can be claimed.
  4. The pet-insurance gap (R10) is framed as adjacent, never as pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, pet-insurance product. I could not confirm the company or the posting independently | `[grounded]` JD header; verification `unavailable` (see Evidence status) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint not researched | `[grounded]` your message |
| Seniority read | "Senior" with 4+ years sits close to your 5 years, the last 2 as senior analyst | `[inferred]` from the JD's years figure against your stated history |
| First-year outcomes | Not stated. The likeliest early work is monitoring existing rating models and reading running price tests | `[inferred]` from the responsibilities list |
| Domain | Pet insurance, which is new to you. The JD calls insurance experience "a plus", not pet-specific | `[grounded]` JD and your statement |
| People management | The JD asks for none, and team size is unstated | `[grounded]` JD silence |
| Market calibration | Not established. The role-family sweep could not run, so no salary band is given | `[grounded]` search refused |
| Unknowns | Salary, team size and reporting line, who signs off rate changes, success measures, employer verification | `[grounded]` JD silence |
| Contradictions | None between the JD and your background. The JD was not cross-checked against the employer's own page | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but your location and right to work were not stated. Confidence is low because it rests on that inference | `[inferred]` from your UK employer | Asked in the closing block (G4) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics, the last 2 as senior analyst. Self-reported, nothing inspected | `[grounded]` your background | Offer: a dated role description or reference would raise to `high` |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is self-assessed with no artifact | `[grounded]` your background | Offer: a sanitized query or notebook sample would raise to `high` |
| R4 | GLM experience, building and monitoring rating models | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Limit: one book, and "maintained" is your word for monitoring | `[grounded]` your background | Offer: sanitized model documentation or a GLM output pack would raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | Offer: a sanitized review deck would raise to `high` |
| R6 | Designing and reading price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" does not say whether you designed them or read the results. I took the lower reading | `[grounded]` your background | Asked in the closing block (G1) |
| R7a | Turn results into recommendations for underwriting | must_have | direct | medium | none | Your quarterly review to the head of underwriting and your test work with that team both point this way. Whether the recommendations were yours is unstated | `[grounded]` your background | Offer: a sanitized test readout would raise to `high` |
| R7b | Turn results into recommendations for product | important | unclear | low | discovery | Nothing you said touches a product team | `[grounded]` silence in your background | Asked in the closing block (G2) |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance rating knowledge | important | adjacent | medium | transferability | Your GLM, price-test and underwriting-review work is on motor. Limit: you have not worked with pet-specific rating factors or claims patterns. The JD does not list this as required; I inferred it because the product is pet insurance | `[inferred]` from the JD's product against your stated lack of pet experience | Bridge case in G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R6, must_have) | discovery | 14 tests run with underwriting, with no detail on who set the design, sample or read-out | "Design and read price tests" is half of the role's stated test work | Choosing test cells and control groups; setting how long a test ran; writing the read-out and the recommendation | A sanitized test plan or read-out | `[grounded]` your "ran 14 tests" against the JD's "design and read" |
| G2 | Product-side recommendations (R7b, important) | discovery | Only underwriting is mentioned | The JD names product as an audience | A pricing change you took to a product or proposition team; a rate or feature decision you advised on | A sanitized recommendation paper | `[grounded]` silence in your background |
| G3 | Pet-insurance domain (R10, important) | transferability | Carries over: GLM rating, price tests, underwriting reviews, all on motor. Limit: none of it touched pet-specific rating factors. Strengthener: a short written note on how you would approach a pet book, built only from what you know | You named this gap yourself | n/a | A one-page approach note (a work sample) | `[inferred]` bridge from your stated work; limit from your own statement |
| G4 | UK-based, remote (R1, hard_gate) | hard_gate | Location not stated | A gate; the question asks whether it is met | n/a | none needed | `[grounded]` JD term against your silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | The pasted JD gives no compensation | The figure may sit below what a senior role should pay, or the company may not publish it | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Remit, team and decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may own the analytics yet only recommend, with no say over rate changes | `[inferred]` from the JD's scope language against its silence on authority | Who is on the pricing team, and who signs off a rate change? | unresolved |
| RR4 | Concrete duties and a named hiring manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is specific and tied to a pricing director | `[grounded]` JD | What would a successful first year look like for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with: "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer" | R4 | `[grounded]` your sentence | resume_edits_pending_approval |
| E2 | CV line: "Ran 14 price tests last year with the underwriting team". Add "designed" only if G1 confirms it | R6 | `[grounded]` your sentence | resume_edits_pending_approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting" | R5, R7a | `[grounded]` your sentence | resume_edits_pending_approval |
| E4 | Cover-note line: "I haven't worked on pet insurance; my rating-model, price-test and underwriting-review work has been on a motor book" | R10 | `[grounded]` your statements | pending your approval |
| A1 | Find the role on Brindlemoor's own careers site, or check the recruiter's email domain, before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2, RR3 and RR4 questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | If team size or people management comes up, say plainly that you have not managed anyone; the JD asks for no management | RR3 | `[grounded]` JD silence and your statement | pending your approval |

Every row above is proposed. None is final until you approve it.

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech UK" and "Brindlemoor careers Senior Pricing Analyst"; both refused, nothing returned. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; refused. It would have given the market calibration line and a check on RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have shaped the scope read and which story to lead with |

## Upgrade menu

I can build a `tuesday-dossier.md` from this if you want to keep or reuse the analysis.

- Search permission granted: targets 1 to 3 rerun. RR1 and the market calibration could close, and the application plan could lead with a story chosen for Odile Varga.
- Your pay floor, notice period and any other non-negotiables → hard-gate checks against them, currently unknown.
- A sanitized test plan or read-out → R6 and R7a to `high`.
- Sanitized GLM model documentation → R4 to `high`.
- A sanitized review deck → R5 to `high`.
- A one-page note on how you would approach a pet book → narrows the R10 limit.

Questions:

G4 — Are you UK-based, and able to work fully remotely from the UK without needing sponsorship?

G1 — For the 14 price tests: did you choose the test design, such as cells, controls and duration, and write the read-out and recommendation yourself, or did others set the design?

G2 — Have you taken a pricing finding to a product or proposition team, or advised on a feature or rate decision? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.