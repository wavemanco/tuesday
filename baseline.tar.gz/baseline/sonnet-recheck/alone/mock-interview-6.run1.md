I'll read the reference files the skill points to before building the pack.
The pack is written, and I'm about to hand it over. I built it in loop mode, with a shared fit snapshot and a bank of questions for each of your three rounds. The web searches I tried for Larkfield's values, interview process and strategy were refused, so none of the research that depends on them is in it.

Your pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-6-denied-2590c391/8708db50-c981-4787-9796-4100ee0a18ce/scratchpad/larkfield-systems_engineering-manager_interview_pack.md`. It has 34 questions: 11 for Tuesday, 12 for Thursday and 11 for Monday, each with five reverse questions.

- **What it's built on:** only the role summary and background in your message, since I had no full JD, CV or interviewer names.
- **Highest-ROI prep:** the step from a team lead of six to two squads. It is Tuesday's first question (T-A1), with a three-level follow-up ladder, and I expect some version of it in all three rounds.
- **What I left out:** the values cheat sheet for Monday and any questions grounded in Larkfield's strategy, because the searches were refused. The Larkfield-specific questions are labelled generic.
- **Your stated limits:** "never managed managers" and "never owned a hardware-adjacent roadmap" are handled as plain acknowledgments in your own words, each followed by a plan.

Say the word and I'll play the Director on T-A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD and your CV, or tell me to go on without them? Did the recruiter give any focus areas for Thursday's panel or Monday's VP round, or ask for a deliverable such as a presentation?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role as you described it: "Engineering Manager — Larkfield Systems (industrial IoT, ~600 people)" — your message.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (name not given) | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Panel: two staff engineers and a product manager (names not given) | 60 min | Future collaborators and direct stakeholders |
| 3 | The following Monday | VP Engineering (name not given) | 30 min | Skip-level; the recruiter's description was "values and leadership philosophy" |

The loop rests on your own words, which fix the number of sessions and who runs each, so no archetype fallback is used. Persona weights are per round and the reasoning is shown in each round's table.

## How to use this pack

- Personas describe how a question is asked; types describe what is being scored. Rehearse both: a skeptic and a rapport-builder can ask the same question and score different things.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive (does the claim survive scrutiny). JD is role-driven (can you do the listed job, gaps included). CO is company and strategy knowledge. CASE is a live hypothetical or problem set in the role.
- Question IDs: T for Tuesday, H for Thursday, M for Monday, then the persona letter and number (T-A1 is Tuesday, persona A, question 1).
- Guidance is scaffolding, not a script. Every sentence about your past comes from your own words, quoted in the Provenance column. An answer slot is an instruction for the interview: answer it from your own experience, or say plainly that the practice was not yours or never existed. Both branches are good answers.
- The highest-ROI prep in this pack is T-A1 (the step from a team lead of six to two squads). It will arrive in some form in all three rounds, so it carries the deepest rehearsal.

## Prep triage (two weeks, three rounds)

1. Before Tuesday: say T-A1 and T-A2 aloud until the concession wording is boring. Then T-C1 and T-C2 (know how each figure was counted, or be ready to say you do not know). Then T-B1 for structure, and T-A3 in your own words.
2. Between Tuesday and Thursday: H-D1 and H-A1 (the 60% figure again, in panel packaging), H-C1, H-B1, H-D2.
3. Between Thursday and Monday: M-A2 and M-B1 (your leadership philosophy at 30 seconds and at 2 minutes), M-A1, M-B2.
4. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. No gate rows: the role description names no authorization, location, schedule or credential term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says a team lead of six, not two squads, with nothing inspected behind it, and the words stay at that scope. Your material does not say whether the two squads have leads of their own, and the pack does not assume it. Plain acknowledgment, from your own words: "I've never managed managers." Answer slot: if the step from one team to two is raised, say how you would divide your attention across them, as a plan and never as a past; if you have led across more than one team, say what part was yours; if you have not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery element) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries a reliability quarter pushed through and an on-call drop that came after it, not delivery of a roadmap, and the words stay there. Answer slot on the figure: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring element) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap against the hiring element, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you run the hiring loop for backend roles. Answer slot on the figure: "about 40 interviews" can be read as interviews through the loop or interviews you sat in; say which, and if you do not know how it was counted, say so plainly. Until you say otherwise the pack takes the lower reading |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth element) — role description in your message | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the role names growth, so expect a probe on developing engineers. If you have helped someone grow, say what you did and what part was yours, in your own words; if growth of others was not part of your lead role, say so plainly and say what you would do in your first ninety days, as a plan |
| F5 | "partner with hardware and product on roadmap" (the hardware element) — role description in your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | The quote is a stated limit on owning a roadmap, and it does not show whether you have worked alongside hardware people. Plain acknowledgment, from your own words: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked with hardware colleagues in any form, say how and what part was yours; if you have not, say so plainly and say how you would learn the seam in your first weeks, as a plan |
| F6 | "partner with hardware and product on roadmap" (the product element) — role description in your message | "pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches roadmap tension without showing who was on the other side or how it was settled, and the words stay at the quote. Answer slot: if you worked the trade-off out with a product counterpart, say how and what part was yours; if the call was made above you, or was not a negotiation, say so plainly and stay with the reliability quarter |
| F7 | "industrial IoT" and "device-management services" — role description in your message | "currently at a payments company" — your message | none | [grounded] | discovery | Your material places you in payments and says nothing about devices. Answer slot: if any of your work touched physical devices or the services that manage them, say what and what part was yours; if none did, say so plainly and name what you would learn first |
| F8 | "values and leadership philosophy" — the recruiter's description of Monday's round, in your message | none given | none | [grounded] | discovery | Your material states no leadership beliefs. Selection scaffold: pick one belief about leading people, one decision from your own work that shows it, and what the decision cost you; if no decision comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Lead two squads building device-management services (F1) | T-A1, T-A2, T-B1, H-D2, M-B2, M-C1 |
| Own delivery (F2) | T-A4, T-B3, T-C1, H-A1, H-A2, H-D1, M-A1 |
| Hiring (F3) | T-C2, H-A4, M-A4 |
| Growth of engineers (F4) | H-B3, M-A3 |
| Partner with hardware on roadmap (F5) | T-A2, H-B1, H-B2, H-C3, M-B3 |
| Partner with product on roadmap (F6) | T-A4, T-B3, H-C1, H-C2 |
| Industrial IoT and device-management domain (F7) | T-A3, T-B1, T-B2, T-D2, M-B3, M-C2, M-D1 |
| Values and leadership philosophy (F8) | M-A1, M-A2, M-B1, M-D2 |

---

## Round 1 — Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

| Persona | Weight | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | High | Quiet, persistent probing of the scale step and the hardware gap | Hiring-manager prior is Case plus Skeptic: they are buying capability and de-risking gaps. Your own message names two limits, so the gaps are known to you and will be found by them | Rehearse T-A1 until it is boring: hold the quoted scope, concede the two stated limits plainly, give a plan |
| Case/Strategist | High | Live problems from the squads' actual work | Same prior; the role description names concrete squads and a roadmap with hardware and product | Clarify before structuring, think aloud, challenge one premise respectfully |
| Data-Driven Prober | Medium | Reads your figures line by line | Not in the hiring-manager prior; raised because two of your lines carry figures that invite counting questions | Know how each figure was counted, or say plainly you do not know |
| Conversational | Low | Opening biography and why-this-role | Every first round opens this way; low because it rarely carries the score | A 90-second arc built only from your own words |
| Pressure | Low | Not expected from this seat | A would-be boss in 45 minutes has little reason to stress-test composure | Pause, restate, anchor in what you said |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "You've led a team of six. Here you'd be accountable for eleven engineers across two squads. What makes you ready for that step?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6"; "I've never managed managers" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: nine years in engineering, three of them as a team lead of six. Hold through two follow-ups by returning to that, never by adding to it. Concede specifically when pressed: "I've never managed managers." Then a plan, said as a plan: how you would learn the two squads in your first weeks, in your own words. Answer slot: if any part of leading six carried over to leading across two teams, say which part and why, in your own words; if you have not led across teams, say so plainly. Follow-up ladder below the table | F1 is the scale step and the most predictable objection in all three rounds; JD because it scores the stated lead-two-squads requirement |
| T-A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Name one, plainly, and choose the one that is true. Both limits are in your own words, so either is honest: "I've never owned a hardware-adjacent roadmap" or "I've never managed managers." Then the ramp plan: the first two conversations you would have and what you would want to learn from each, as a plan. Calibrated candor beats bluffing a competency the Director personally owns | F5 and F1 hold your two stated limits; Skeptic stem, JD tag because it scores honest self-assessment against the listed requirements |
| T-A3 | "Why leave a payments company for industrial IoT, and why now?" | JD | [grounded] "currently at a payments company" | Your material gives no reason, so none is supplied here. Answer slot: say your reason in your own words, and keep to what you know of Larkfield from what you have actually read. If the move is about the work and not the title, say so only if that is true. Keep it under 60 seconds | F7 has no evidence on the domain, so motivation consistency is where a skeptic starts; JD because it scores fit with the stated industry |
| T-A4 | "Tell me about a time you held a line on engineering priorities against the roadmap. What did it cost?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F2 and F6, with only the beats the quote states: a reliability quarter, pushed through, against roadmap pressure, and the on-call drop that followed. Tell them in your own words. Answer slot on cost: if it cost you or the roadmap something, say what; if there was no cost you know of, say so plainly. Answer slot on counterpart: if you worked it out with product, say how and what part was yours; if the call was made above you, say so | The role names partnering with product on roadmap, so a pushed-back-on-roadmap story is the likeliest behavioral probe; EXP because it tests what was actually yours |
| T-B1 | "You inherit two squads building device-management services and a full roadmap. What do you need to know first, and how do you spend your first 30 days?" | CASE | [generic] | Clarify, then objective, approach, metrics, risks. Clarifying families to ask the Director: what the squads own and what they depend on, how work is prioritised today, who the hardware counterparts are, what good looks like at 90 days. Say the framework aloud before using it. Challenge one premise respectfully, for example whether a full roadmap is the right starting point. The question needs no claim about your past, so the guidance makes none | Hiring-manager prior is Case; live problems on the actual roadmap are the usual format. Generic because no company material could be fetched |
| T-B2 | "A fleet of devices in the field stops reporting after your squad ships a service change. Hardware says it's your service; your team says it's their firmware. What do you do?" | CASE | [generic] | Structure it: what you ask first (scope of impact, what changed, what each side can show), how you contain the customer impact, how you keep the two sides working on evidence rather than blame, what you record afterwards. Make no claim about past incidents; the question asks about none | Seam between squads and hardware is the role's core tension (F5); generic because it is a pattern for the problem, not a fact about this team |
| T-B3 | "Product asks for a feature this quarter and your engineers say on-call load is already too high. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Decide aloud with criteria: customer impact, size of the on-call problem, what product actually needs by when, what can be sequenced. You may point to the reliability quarter at the quote's scope, as one occasion on which you pushed reliability work through; do not present it as a method you have applied repeatedly | F2 and F6 make this the most natural case for your own material; CASE because it is a decision under trade-off |
| T-C1 | "Walk me through how that 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number, in your own words. Answer slots: how it was counted; what it is sensitive to; the assumption behind it you would defend least, named before they do; which part was yours. If you do not know how it was counted, say so plainly. Keep the quote's "after": do not say the quarter caused the drop unless you can show it | F2's figure is a magnet for probers; EXP because it tests how well you know your own number |
| T-C2 | "When you say about 40 interviews last year, what is that 40 counting?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say which reading is true: interviews that went through the loop, or interviews you sat in. If you do not know exactly, say so plainly and give the range you are sure of. Then what you run in the loop, in your own words, at the quote's scope: the loop for backend roles | F3 carries a figure with two readings; EXP because it tests attribution and counting |
| T-D1 | "So — walk me through your path so far, and what's led you here." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6"; "currently at a payments company" | A 90-second arc with the beats the quotes state: nine years in engineering, three of them as a team lead of six, currently in payments. Answer slot: the step to this role is yours to explain in your own words; do not fill it with a reason you do not hold | Opening question of nearly every first round; EXP because it checks the CV line against how you tell it |
| T-D2 | "What are you actually playing with these days in anything device-related?" | JD | [grounded] | Answer slot: if you have touched physical devices or the services around them in any form, say what and what part was yours; if not, say so plainly and say what you have started to read or would start with. A casual question about a hot JD topic is still scored | F7 shows no domain evidence, and Conversational stems ask about the JD's plus-skills casually; JD because it scores the domain |

Follow-up ladder for T-A1 (the deepest rehearsal): after your first answer, expect three levels. First, "You've never managed managers. Does that matter here?" Hold the quote, concede the limit plainly, no softening. Second, "What would you do in month one that would tell us you can run two squads?" A plan in your own words, naming what you would watch for. Third, "What's the first thing you'd probably get wrong?" Answer slot: name something true; if you cannot name one, say so plainly and say how you would find out. Never answer any level by adding experience the quotes do not carry.

### Reverse questions for Tuesday

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "What does success look like in this role at 90 days and at a year, and where do you expect a new EM to find it hardest at first?" | Turns the gap you will already have named into a shared plan, and shows you are measuring yourself against the role |
| T-R2 | "Do the two squads have leads of their own today, and how do you see the EM working with them?" | Surfaces whether the managing-managers limit matters in practice, without asking for reassurance |
| T-R3 | "Where does the roadmap depend most on hardware dates, and how is that dependency managed today?" | Shows you are already thinking about the seam you have not owned |
| T-R4 | "If reliability, delivery and growth pull against each other, which would you want a new EM to protect first?" | Reveals the Director's real priority order and invites them to talk about how they decide |
| T-R5 | "What is the hiring plan for the squads this year, and who owns the bar?" | Hiring is one of the three elements of the role; it also tests whether the ownership you are being offered is real |

---

## Round 2 — The Thursday after, panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | Weight | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | High | Staff engineers checking the figures and the engineering judgment behind them | Panel prior blends the top two personas of each member's relationship. Technical specialists tilt to Prober plus Pressure; two of the three seats are staff engineers | Know your figures and what they are sensitive to; offer to walk through the work |
| Peer Evaluator | Medium | Seam-splitting: where the EM ends and staff engineers begin; what you would need from them | Staff engineers and a PM will work beside you daily, which the prior table does not list as a relationship; this is a judgement to recalibrate if you know more | Reciprocity: say what you bring them and not only what you need; propose seam principles, do not pretend to know the seam |
| Values/Behavioral | Medium | The product manager asking behavioral questions about partnering | Cross-functional prior is Values/Behavioral plus Conversational; the role names partnering with product | Stories only from your own material; we for context, I for contribution |
| Pressure | Low | Short challenges to scale and attribution | Technical-specialist prior includes it, but a panel rarely holds composure tests for long | Hold through two follow-ups, then concede specifically |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H-A1 | "You said on-call burden dropped 60% after the reliability quarter. What else changed in that period?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The weakest-assumption move. Answer slot: if you know of other changes in that period, name them and say how you thought about them; if you did not check, say so plainly rather than defending a causal claim. Keep the quote's "after" and do not turn it into "because" | F2: engineers separate before-and-after from cause, and the staff seats are the likeliest to; EXP because it tests whether you know the limits of your own figure |
| H-A2 | "What was the roadmap pressure, and how did you decide the reliability work was worth it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Describe the pressure only as far as the quote does: there was roadmap pressure, and you pushed the reliability quarter through. Answer slot: if you weighed the choice in some way, say how, in your own words; if it was a judgement call without a formal process, say so plainly. Do not name a framework you did not use | F2 and F6: a decision under trade-off is how engineers judge a manager; EXP because it tests what was yours |
| H-A3 | "How do you tell whether a team's service is healthy without reading its code yourself?" | CASE | [generic] | State the signals you would ask for and from whom, and how you would separate what the team tells you from what the data shows. This is how you would do it, not a claim about what you have done | Staff engineers test technical credibility of an EM who may not code daily; generic because it is a pattern |
| H-A4 | "You run a hiring loop for backend roles. What do you look for in a staff-level engineer, and how do you know your loop works?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | What you screen for is yours to say in your own words. Answer slot on whether the loop works: if you have a way of checking, say what; if you have not checked, say so plainly. The loop is for backend roles, so do not claim a staff-level loop unless it was one | F3: hiring is one of the three elements, and staff engineers are the people you would hire; JD because it scores a stated requirement |
| H-B1 | "Our work sits between hardware and product. Where does the EM end and a staff engineer begin, and what happens when we disagree?" | JD | [generic] | Offer principles, not a map you do not have: who decides what, how disagreement is surfaced early, how a decision is recorded. Name what you would not do (override technical direction to protect a date). A disagreement story from your own material is an answer slot: if you have one, say what you did and what part was yours; if not, say so plainly and stay with the principles | Peer-persona stem on the seam; generic because it asserts nothing about this team's actual seam |
| H-B2 | "What would you need from the staff engineers in your first month?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Reciprocity framing first: what you bring them (a manager who protects focus and says no to the roadmap when it is warranted only if you can point to that in your own material). Then what you need, which can honestly be the hardware seam: "I've never owned a hardware-adjacent roadmap" | F5: the gap is where a peer-collegial probe lands, and a candid ask converts it |
| H-B3 | "How do you help a staff engineer keep growing when the next step isn't management?" | JD | [grounded] | Answer slot: the role names growth of engineers. If you have helped someone grow, say what you did and what part was yours, in your own words; if growth of others was not part of your lead role, say so plainly and say what you would do, as a plan. Do not claim a coaching practice | F4 has no evidence; staff engineers will test it because it is about them |
| H-C1 | "Tell me about a time you and a product partner disagreed on priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map on F6 using only the beats the quote states: roadmap pressure, a reliability quarter pushed through. Answer slot: who held the other side and how it was settled, in your own words; if the call was made above you, or there was no one on the other side, say so plainly and tell the reliability quarter as it stands | The PM is the likeliest to ask; the role names partnering with product |
| H-C2 | "A customer commitment lands mid-quarter and would break your squads' plan. Walk me through the conversation you'd have with me." | CASE | [generic] | Structure: what you need to know about the commitment, what it displaces, what you offer instead, how you keep the decision visible. Speak to the PM as a partner and not as an obstacle | PM-led case on the roadmap seam; generic because it is a pattern |
| H-C3 | "How would you keep a roadmap honest when hardware dates move?" | CASE | [grounded] "I've never owned a hardware-adjacent roadmap" | Say the limit first, in your own words: "I've never owned a hardware-adjacent roadmap." Then reason aloud from principles: separate what is committed from what is dependent, state the dependency date and what you do if it slips, tell product early. A principle is how you would think, not an account of what you did | F5: the PM will test the hardware-roadmap gap from the product side; CASE because it is a live problem |
| H-D1 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold then concede. Hold what the quote says: you pushed the reliability quarter through. Concede specifically where the quote is silent: answer slot, which part of the drop was yours and which was the team's, in your own words; if you cannot separate them, say so plainly | Pressure stem on attribution; EXP because it tests candor under a short, hard question |
| H-D2 | "Sixty seconds: why you over a candidate who has already led two squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Time-boxed. Lead with the two things your own words carry: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Concede the scale plainly rather than arguing it. Do not claim you outrank a candidate you know nothing about | F1 through F3: a direct comparison with a stronger candidate is the stress version of T-A1 |

### Reverse questions for Thursday

| # | Question | Why it lands |
|---|---|---|
| H-R1 | "To the staff engineers: what do you most want a manager to do more of, and less of?" | Shows you are listening for what the people you would manage need |
| H-R2 | "Where does the squads' technical debt hurt most, and how heavy is on-call today?" | Invites the engineers to describe the real work and connects to a topic you have rehearsed |
| H-R3 | "To the product manager: how are priority disagreements between product and engineering settled today?" | Shows you are thinking about the partnership before you are in it |
| H-R4 | "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity question for the PM as a peer; it shows you think about their load |
| H-R5 | "What is the hardest part of working with the hardware side that I should know before I start?" | Names the seam candidly and treats the panel as the people who know it |

---

## Round 3 — The following Monday, VP Engineering, 30 min

### Persona weights

| Persona | Weight | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | High | Scenario probes on how you lead and decide | The recruiter described the round as "values and leadership philosophy", which detects a values-style round from a loop source, outweighing the skip-level prior toward Case | One story per question from your own material; we for context, I for contribution; land the hard truth |
| Pressure | Medium | Time-boxed answers, challenge to scale | Skip-level prior includes Pressure, and 30 minutes forces compression | Pause, restate, hold through two follow-ups, concede specifically |
| Case/Strategist | Low | Altitude questions on what a manager of two squads is for | Skip-level prior tilts Case, reduced here by the recruiter's description of the round | Think aloud, name the trade-off, do not claim company facts you have not read |
| Conversational | Low | Opening and closing; why Larkfield | A 30-minute round still opens with motivation | A short arc of your own, no scripted flattery |

The values cheat sheet is not included: no published Larkfield values were in hand, because the searches for them were refused (see Sources). The upgrade menu says what would restore it.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-A1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Only if the reliability quarter fits: the beats the quote states are a reliability quarter pushed through against roadmap pressure. Answer slot: who in leadership you spoke to, what you told them and how you know it landed, in your own words; if you were not the one who raised it, or it did not land, say so plainly and choose the nearest occasion your material does carry. Never supply the ending | Persona stem for a values round; F2 and F6 are the closest material to it, and the hard truth landing is the part the quote does not show |
| M-A2 | "What do you believe about leading people, and what has shaped that?" | VAL | [grounded] | Selection scaffold, ending in its honest branch: pick one belief you actually hold, one decision from your own work that shows it, and what the decision cost you. If no decision comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Keep it to two minutes | F8: the recruiter's description is the raising source; this is the question the round is built around |
| M-A3 | "Tell me about a time you helped someone on your team grow." | VAL | [grounded] | Selection scaffold: pick an occasion with a named person, what you did, and what changed; answer slot per F4: if you have such an occasion, say what you did and what part was yours; if growth of others was not part of your lead role, say so plainly and say what you would do in this role, as a plan | F4 has no evidence and the role names growth; a VP assessing leadership philosophy is likely to test it |
| M-A4 | "How does the way you run a hiring loop reflect what you believe about people?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Describe the loop at the quote's scope: you run it for backend roles. Answer slot: what you actually do in it, and what belief it reflects, in your own words; if the loop is mostly set by others, or does not reflect a belief you hold, say so plainly. Do not claim a hiring philosophy you cannot point to in what you do | F3: your strongest leadership material is hiring, so it is where a values question lands |
| M-B1 | "Thirty seconds: what is your leadership philosophy?" | VAL | [generic] | A compression drill of M-A2. Belief, example, cost. Say it aloud with a timer; if you cannot say it in 30 seconds you do not yet hold it clearly. The guidance makes no claim about your past | 30-minute round plus time-box; Pressure delivery on a Values question |
| M-B2 | "You've never managed managers. Why should I put you over two squads?" | JD | [grounded] "I've never managed managers"; "9 years engineering, 3 as a team lead of 6" | Hold then concede. Hold: nine years in engineering, three as a team lead of six. Concede in the same breath: "I've never managed managers." Hold through two follow-ups by returning to the quote; add a plan for how you would learn it. Never argue that leading six is the same as leading managers | F1: the VP version of T-A1, compressed and from a seat with more authority to say no |
| M-B3 | "You're coming from payments into hardware-adjacent work. What will be hardest for you to adjust to?" | JD | [grounded] "currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Answer slot: name what you honestly expect to be hardest, in your own words, and what you would do about it in your first months. The hardware-adjacent roadmap is a limit you have stated: "I've never owned a hardware-adjacent roadmap." Do not claim you already know how hardware changes behave | F5 and F7: domain and seam are the two places the story is thin |
| M-C1 | "What does a manager of two squads owe the company that a team lead of one team does not?" | CASE | [generic] | Think aloud through scope, trade-offs across teams, hiring and growth at a larger size, and communicating upward. This is a view of the role, not a claim about what you have done. Name one thing you expect to change about how you spend your time | Altitude question at skip-level; generic because it is a pattern |
| M-C2 | "What do you think makes device management hard for the teams that build it?" | CO | [generic] | Say what you know and no more. You have not read anything about Larkfield's own strategy through this pack, so keep to the problem in general terms and say plainly what you would want to learn. Do not state a company fact you have not read | Research was refused, so this is a generic CO question; it becomes grounded if you supply the company material |
| M-D1 | "What drew you to this role and to Larkfield?" | CO | [generic] | Your reason is yours; the pack has none to give. Answer slot: say it in your own words, citing only what you have actually read about the company, and say plainly what you are still learning. A reason you cannot back with a fact is the one a VP tests | Motivation consistency across a three-round loop: this answer must match what you said on Tuesday |
| M-D2 | "What would you like me to know about you that this process hasn't shown?" | VAL | [generic] | Pick one thing from your own material and say it in one minute. If nothing comes to mind, say so plainly and say what you would want a new manager to be known for in a year | The conversational close of a values round; also the slot where candidates are tempted to inflate |

### Reverse questions for Monday

| # | Question | Why it lands |
|---|---|---|
| M-R1 | "What do you want engineering leadership to look like in two years, and what does this role contribute?" | Pitches your question at the VP's altitude |
| M-R2 | "What separates the managers who thrive here from the ones who don't?" | Invites the VP to state their values in their own terms, which is what this round scores |
| M-R3 | "How do you develop engineering managers here?" | Signals you plan to grow, and addresses the managing-managers limit from the side of the company |
| M-R4 | "What is the toughest trade-off engineering is making right now?" | Shows you can think at the company's altitude, and gives you something real to reflect on afterwards |
| M-R5 | "What did you hope to learn about me today that you haven't yet?" | Gives the VP a chance to name a doubt, and gives you one last turn to answer it |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers or led a multi-team organisation | Negative the candidate stated, F1 | The plain acknowledgment from your own words: "I've never managed managers." No slot, then a plan |
| Owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment from your own words: "I've never owned a hardware-adjacent roadmap." No slot, then a plan |
| Led two squads, or a team of eleven | Inflated form of F1 | F1's quote at its own scope: "9 years engineering, 3 as a team lead of 6." The limit is the pack's observation: your material says a team of six, not two squads |
| Cut on-call burden by 60% through the reliability quarter, or owned the reliability outcome | Inflated form of F2 | F2's quote at its own scope, keeping its "after". The limit is the pack's observation: your material says the drop came after the quarter, and nothing about cause |
| Hired about 40 people, or sat in every interview | Inflated form of F3 | F3's quote at its own scope: "I run our hiring loop for backend roles — about 40 interviews last year." The limit is the pack's observation: the figure counts interviews, and the material does not say whose |

## Sources

Provided documents: your message (the role description, the three rounds and their lengths, your background). No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Query sent: "Larkfield Systems industrial IoT company values" — refused. Would have fed the values cheat sheet for Monday and the VAL questions by value name |
| 2. Larkfield Systems interview process | unavailable | Query sent: "Larkfield Systems interview process engineering manager" — refused. Would have checked the loop against your recruiter's description and added loop-report persona signals |
| 3. Larkfield Systems strategy and recent news | unavailable | Query sent: "Larkfield Systems industrial IoT device management strategy news" — refused. Would have grounded the CO questions (M-C2, M-D1) in current priorities |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form |
| 5. Representative engineering manager JD | skipped | The role description in your message fixes the requirement rows; a full JD would add lines but not change the rows that exist |

## Upgrade menu

- Web search permission for this session → the values cheat sheet for Monday, grounded CO questions (M-C2, M-D1), and a loop check against your recruiter's description
- The full JD text → any requirement beyond the three lines in your message becomes a quoted row, and the `[inferred]` row F6 may become `[grounded]`
- Your CV → fit snapshot evidence beyond your message, which would let F4, F5, F6 and F7 carry a story where one exists
- Your answers to the slots in F1 through F8 → the rows they draw on regenerate with your words, and the bank guidance becomes story-mapped
- The interviewers' names → an interviewer read, persona weights adjusted from public footprint, and reverse questions tied to each path
- The recruiter's guidance on the panel and Monday's round (focus areas, any deliverable) → coverage of a pre-declared deliverable, and a sharper persona weighting for Thursday
- A tuesday-dossier.md from the job underwriter → a verified-evidence base and an underwriter-derived objection instead of one inferred here
