I'll read the reference files the skill points to before drafting.
Your prep pack for Tuesday is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-5-denied-6c3bedfb/bca19036-ec3b-4fd6-8f79-8e1573a9067f/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it as a two-person panel, Deepa as your manager and Ross as the commercial voice, using only the recruiter's email and what you told me about your background. I couldn't see the market report because its text wasn't in the conversation. Web search was also refused, so nothing in the pack comes from research on Kelverton or the panel. The pack states company-specific gaps as gaps instead of guessing, and the report-dependent parts are method only.

- **Spend most prep on question C1.** It's Ross pressing on your two stated gaps: no direct quota and no selling into rail. The pack gives you a plain acknowledgment, a bridge limited to what you actually said, and a worded concession. It also gives three follow-ups to rehearse, plus the "£4M of influenced revenue" defence (B1, B2).
- **The 15-minute POV has a build section.** It has a minute-by-minute beat table, three theses (each with its concession), an anti-pick and a two-minute close on what it means for operators. Open by saying which meaning of "operator partnerships" you're assuming.
- **Don't recite the report.** Its authors are in the room. Bring one consensus item from it, then one reasoned divergence.
- **The four hours are scheduled.** The prep triage splits them: 90 min on the POV, 60 on C1 and Ross-style questions, 45 on the report, 30 on reverse questions, 15 on your journey arc.

I can play Ross or Deepa live on C1, the question the pack names as the highest-value prep, with follow-ups that react to what you actually say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, or tell me to carry on without it? Pasting it would let the pack quote the real requirement lines and settle what "senior" means for this role.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel, Tuesday. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your spoken POV on where you would take Kelverton's operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Remaining 45 minutes: Q&A, with Ross pushing on commercials. All of this is from the recruiter's email, as you quoted it.

**Built on:** no job description, no interviewer profiles, and a market report I could not see (see Sources). Company-specific facts are left out rather than guessed.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Rehearse both: the same objection arrives as a quiet question from Deepa and a time-boxed challenge from Ross.
- **Type key.** `VAL` = published values alignment (none banked: no values round detected). `EXP` = does the CV line survive scrutiny. `JD` = the role's stated asks (here that means the recruiter's stated asks, because no JD was supplied). `CO` = company and strategy knowledge. `CASE` = live problem.
- **Guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. Where the pack cannot know something, it leaves an answer slot with an honest second branch. Say only what you did, in your own words.

## Prep triage (four hours, over the weekend)

| Order | Block | Time | Do this | Sections and IDs |
|---|---|---|---|---|
| 1 | Build and time the POV | 90 min | Draft the 15-minute talk from the beat table, then say it aloud twice with a timer. Choose your two theses and the anti-pick last | Graded deliverable; A1, A4 |
| 2 | The objection | 60 min | Rehearse C1 to three follow-ups, then B1 and B2. Get someone to play Ross and interrupt | C1, B1, B2, D1 |
| 3 | Report differentiation | 45 min | Reread the market report once. Pick one consensus item and one divergence for A3, and the operator close for A4 | A3, A4, A2 |
| 4 | Reverse questions | 30 min | Pick three, one for Ross, one for Deepa, one for both | Reverse questions |
| 5 | The journey arc | 15 min | Say F1 aloud in 90 seconds | F1 |

Everything else in this pack is insurance.

## Fit snapshot

The requirements below are the recruiter's own words as you quoted them, plus your description of the company; there is no JD. Evidence cells hold only your sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says the ISV channel at a payments company, not operator partnerships, and the words stay at that scope: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: the recruiter's "where you'd take" line makes a probe on who set the channel's direction likely. If you chose which partners to add or in what order, say how you decided, in your own words; if those choices were set by others, or there was no such choosing, say so plainly and stay with the channel's growth from 6 to 40 |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, quoted in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning; it does not establish heavy rail, or who the clients were. The words stay at the quote: "For five years I did network planning in transport consulting, in bus and light rail." Be ready to say plainly which side "the other side" was. Answer slot: the recruiter's close line makes a probe on how near you were to operators likely. If you worked directly with an operator's own teams, say who and on what; if your clients were someone else, or the work was at arm's length, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials" — recruiter's email, quoted in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material gives an influenced figure and states no direct quota, and the words stay there: "I took the channel from 6 partners to 40, roughly £4M of influenced revenue. I've never carried a direct quota; what I've carried is influenced revenue." Answer slot: for the figure, say how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; "I don't know exactly how it was counted" is an honest answer. Never describe the figure as revenue you closed or owned |
| F4 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. This is the company context you gave, not a stated requirement, and your own sentence makes it the likeliest probe. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past: "In my first weeks I'd sit in on operator conversations before proposing anything." Never a claim to rail selling, and nothing added to make the gap feel smaller |
| F5 | "Senior Partnerships Manager" — your message (the role title) | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | none | No gap the material shows, but a CV-style line with nothing inspected behind it, and no JD to say what seniority the role asks. Lead in the quote's own terms: nine years in partnerships, the last four running the ISV channel at a payments company |
| F6 | "no slides needed, just talk us through it" — recruiter's email, quoted in your message | none given | none | [grounded] | discovery | Your material does not show whether you have presented a point of view to senior people without slides. Answer slot: if you have, say when and to whom, in your own words; if not, say so plainly and say how you prepared this one |

## Graded deliverable: the 15-minute POV

The recruiter announced this, so it is graded. Three asks are explicit: a POV on where you would take operator partnerships over 18 months, no slides, and a close on what it means for the operators themselves.

### Facts you may build on

| Fact (fit-snapshot row) | Exact sentence | How to use it |
|---|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel" | One sentence, early, so the panel knows where your view comes from. Do not narrate the channel's history |
| F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" | Use at most once, and only as context for a sequencing argument (see T3). Expect Ross to ask how it was counted: B1 |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Use in the operator close, at its own scope, with the F2 slot answered |
| F3 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Say the first half yourself before anyone asks: it removes the objection's surprise value |

### Open by fixing the question

Spend the first minute reading the brief aloud. "Operator partnerships" can mean working with operators as customers and co-developers, or building partners around operators. Say which you are assuming, say you will flag where the other reading changes the plan, and invite correction. This is the clarify move a Case interviewer scores, and it costs 30 seconds. Provenance: `[inferred]`, derived from the recruiter's phrase "our operator partnerships" in F1's requirement.

### Beat table (15 minutes)

| Minutes | Beat | What goes in it | Provenance |
|---|---|---|---|
| 0:00 to 1:00 | Frame | Your reading of "operator partnerships"; one sentence from F5; the three-part shape you will follow | `[inferred]` |
| 1:00 to 3:00 | Where things stand | One consensus item from the market report, to prove grounding. You choose it; I have not seen the report | `[inferred]` |
| 3:00 to 9:00 | Three moves over 18 months | Months 0 to 6, 6 to 12, 12 to 18, one thesis per period, each with its concession | `[generic]` |
| 9:00 to 11:00 | What I would not do | The anti-pick, with the reason | `[generic]` |
| 11:00 to 13:30 | What this means for the operators | The operator close below | `[generic]` |
| 13:30 to 15:00 | Risks and first 90 days | What you would test first; your own stated gaps (F3, F4) named as part of the plan; invite challenge | `[generic]` |

### Theses (pick two as the spine; the third is a sequenced bet)

| Thesis | Argument | What it means for operators | Mandatory concession | Differentiation or anti-pick | Provenance |
|---|---|---|---|---|---|
| T1 Depth before breadth | Co-develop with a small number of operators first, and treat them as design partners before widening | The operators who go deep get a say in what gets built and a named counterpart; the rest get a clear sequence and a date | Slower coverage across the operator list, and concentration risk if one of the few leaves; some operators hear "later" | Consensus candidates walk the report's shortlist item by item. Bring one item to show grounding, then argue for fewer, deeper partnerships than the shortlist implies | `[generic]` |
| T2 Commercial shape from day one | Tie each operator partnership to an outcome the operator defines and a path from pilot to contract, so Ross can see conversion, not activity | The operator knows at the start what success is, and what it pays when that is met; no open-ended pilots | You do not know Kelverton's pricing or contract model, and procurement rules may slow paid pilots. Say so and name what you would learn first | Speaks directly to the Commercial Director in the room. Most POVs stay on relationships | `[generic]` |
| T3 Ecosystem layer later | In months 12 to 18, once reference operators exist, bring third-party partners around them | Operators get vetted complementary options without procuring each separately | Depends on T1 producing references first; adds management overhead and a possible overlap with direct sales (E1) | Your F1 sentence says "from 6 partners to 40", so expect "why not repeat that here". The honest divergence is sequencing: not before the references exist. This is the anti-pick for the first six months: do not launch a broad partner programme | `[generic]` |

These are role-family patterns. Replace or discard any that the market report makes moot; they become `[grounded]` only when the report text is in the pack.

### The operator close (spoken, about 2 minutes)

Three sentences, each in operator terms, built from the report and from F2 at its own scope:

1. What an operator's planning or scheduling team has at month 18 that it does not have today (name one concrete thing from the report).
2. What the operator commits or pays, and when.
3. What the operator can hold Kelverton to, named as a commitment you would want written down.

Do not describe what operators need as fact about their world beyond what the report or your F2 sentence carries; say "my reading is" where it is a reading.

## Persona table

The loop is established by the recruiter's email as you quoted it: one 60-minute panel, two named people, a 15-minute POV then Q&A. Weights start from the relationship priors (hiring manager: Case and Skeptic; the Commercial Director's role pulls toward Prober and Pressure) and move on what your own material shows.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa, on the POV and its follow-ups: "what would you need to know first" | High. The 15-minute POV makes this the session's spine, and a future manager buys capability | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Ross, on the £4M and the word "influenced" | High. The recruiter wrote "Ross will push on commercials", and the only number in your material is an influenced figure (F3) | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the weakest assumption before he does |
| Skeptic | Either panelist, on rail and on quota | High. Your own sentence states both gaps (F3, F4), which makes them the most predictable probes | Rehearse C1 until it is boring: plain acknowledgment, quote-scoped bridge, a plan |
| Pressure | Ross, time-boxing and interrupting | Medium. A Commercial Director in a 60-minute panel may; no source says he is a stress interviewer, so this rests on the role prior only | Pause, restate, hold through two follow-ups, concede one specific thing |
| Peer Evaluator | Ross, on the seam between partnerships and direct sales | Medium. Ross runs commercial; whether partnerships and direct sales share operators is something the pack does not know, so the bank asks about principles, not the actual seam | Reciprocity: what the seam gives his team; propose seam principles rather than pretending to know it |
| Conversational | Either, in the opening minutes | Low. A POV-first format leaves less room for chat, but "walk me through the journey" is cheap to prepare | A 90-second arc built from F1, F2, F5 |
| Values/Behavioral | Not banked | Low. No values page was read and no loop source names a values round, so none is detected | Not applicable here; see upgrade menu |

## Question banks

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on where operator partnerships go over 18 months (F1) | A1, A2, A3, A5 |
| Land on what it means for operators (F2) | A4, A5, C4 |
| Commercials (F3) | B1, B2, B3, B4, C1, D3, E1, E2 |
| Rail and operator context (F4) | C1, C2, C4, D1, F2 |
| Seniority (F5) | D2, F1 |
| Presenting without slides (F6) | A1, and the beat table above |
| Motivation (not a stated requirement; a Skeptic staple) | C3 |
| Values alignment | none, and why: no values-style round detected |

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | This is the POV itself: use the beat table. Use your own history only as the quotes carry it, at most one sentence: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: expect a probe on what decided which partners were added between 6 and 40. If you set that, say how you decided, in your own words; if the criteria were set by others, or there was no explicit criteria, say so plainly and stay with the channel's growth. Then F6's slot: if you have presented a point of view without slides before, say when; if not, say how you prepared this one | The announced deliverable, so the single most certain item in the session (F1, F6) |
| A2 | "Suppose we can go deep with only three operators over the next year. How do you choose, and what do you say no to?" | CASE | [generic] | A live problem, so the guidance makes no claim about your past. Clarify first: what "deep" means and what Kelverton wants from the three. Then criteria in a sentence each (fit with Kelverton's direction, reference value to other operators, commercial attractiveness, readiness to commit), how you would test them, and what you would decline and why. Name the premise you would challenge: three may be the wrong number | Makes you commit to the anti-pick out loud; tests the T1 thesis under pressure (F1) |
| A3 | "Our strategy team circulated a market report last quarter. Which of its conclusions would you push back on?" | CO | [inferred] derived from your statement that the recruiter attached the report and that you have read it | The pack has not seen the report, so it supplies the method, not the content. Bring one consensus item to prove grounding, then one divergence with your reasons. Do not recite the shortlist: the panel's own team wrote it. If you find nothing to push back on, say which conclusion you would test first and how | Differentiating from a shared source is the CO bar. Labeled `[inferred]` because the question's premise is the report's existence, not its contents (F1) |
| A4 | "Pick one operator. What is different for their team in 18 months if your plan works?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The recruiter asked you to land on this, so rehearse it as a stand-alone two-minute answer: the operator close above. Describe the change in the operator's terms, from the report or your own reading, not from claims about what operators need. Use your own background only as the quote carries it: five years in transport consulting, in bus and light rail network planning. Answer slot: if you worked directly with an operator's own teams, say who and on what; if your clients were someone else, or the work was at arm's length, say so plainly and stay with the network planning | The close the recruiter named, so a miss here reads as not listening (F2) |
| A5 | "Eighteen months in, one of our largest operator partners tells us they won't renew. What do you do in the first week?" | CASE | [generic] | A hypothetical, so no claim about your past. Clarify what you know (why, who decided, what the contract allows), separate what is recoverable from what is not, say who you would call and in what order, and what you would not promise. Close with what you would change in the partnership design so the same cause does not recur | Tests composure and structure on a realistic problem; links the POV to operating reality (F1) |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through the £4M: how was it counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The weakest-assumption move. In your own words: how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. Say "roughly" as you wrote it. If you do not know how it was counted, say so plainly. Never restate it as revenue you owned or closed | A headline metric is a magnet for probers, and Ross was named as pushing on commercials (F3) |
| B2 | "'Influenced revenue': what is the difference between that and revenue you owned, and where does the line fall?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold only what your sentence says: "I've never carried a direct quota; what I've carried is influenced revenue." Then answer in your own words where the line fell in your figure, which part was yours, and what you do not know about how it was assigned. Do not add that the influence was substantial or decisive unless you can say how | The distinction Ross is likeliest to press, in his vocabulary (F3) |
| B3 | "How would you structure an operator partnership commercially: who pays for what, and how do we know it's working?" | JD | [generic] | A hypothetical, so no claim about your past. Lay out two or three structures (for example paid pilot with conversion terms, co-development, shared-success terms), what each trades, and the measure you would agree up front. State what you do not know about Kelverton's pricing and contracts, and what you would need to learn before choosing | The "commercials" push in its constructive form; T2 under questioning (F3) |
| B4 | "You took the channel from 6 partners to 40. Which of those partners mattered most to the £4M, and which didn't?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | A defend-the-number probe on what the figure is sensitive to. Answer slot: if you can say how the revenue was spread across the partners, say so in your own words; if you do not know the split, or it was not tracked that way, say so plainly and stay with what you do know. Name the concentration risk if the split was uneven, only if it was | Tests whether the 6 to 40 story survives a second level (F3) |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Ross will push on commercials, so let me begin there. You've never carried a direct quota and you've never sold into rail specifically. Why should we trust you with ours?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI prep in this pack: your own sentence states both gaps, so this arrives in some form. Hold-then-concede, three levels. Open with the plain acknowledgment: "That's right: I've never carried a direct quota, and I haven't sold into rail specifically." Then only what the quotes carry: "I took the channel from 6 partners to 40, roughly £4M of influenced revenue," and five years of network planning in bus and light rail. Concession, worded in advance: "I haven't carried a direct quota, so in my first weeks I'd want to agree with Ross how my number is defined and counted." Follow-up 1, "influenced isn't owned": agree it is not, and hold the figure at its scope. Follow-up 2, "why would an operator take your call": answer from the F2 slot, or say you would earn it. Follow-up 3, "the role carries a direct target": accept it and say what you would need agreed. Never say your experience is equivalent to a quota | The most predictable objection to this candidate. The limit is named before it is asked for: the material says influenced revenue, not owned (F3, F4) |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Choose from the gaps you have already stated, because a manufactured weakness is read as one. Say it plainly, then a plan: what you would do in the first weeks about it. Do not name a strength as a weakness | A standard Skeptic stem; your stated gaps are the honest answer (F4) |
| C3 | "You've spent the last four years in payments. Why rail, why us, why now?" | CO | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Your material does not state your reasons, so the pack will not supply them. Answer slot: give the real reason in a sentence or two; if your five years in transport consulting are part of it, say how, in your own words; if they are not, leave them out. For the "why us" half, use one specific thing from the report rather than the company description | Motivation consistency is scored by a Skeptic; CO because "why us" needs homework (F5) |
| C4 | "Transport consulting was before the payments years, and it was buses and light rail. What makes you think you understand a train operator's world?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Hold the sentence at its scope: five years of network planning in bus and light rail. Concede, as the pack's observation turned into your words: "That's bus and light rail, not heavy rail, so I'd expect to learn where it differs." Answer slot: if you worked directly with an operator's own teams, say who and on what; if the work was for other clients or at arm's length, say so plainly. Do not say you "know" the operator world beyond what you meant by "the other side" | The sector-transfer probe, aimed at where F2 is thinnest |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate. Concede first: "They'd have the rail selling I haven't." Then the case in what the quotes carry: the channel moved from 6 partners to 40, roughly £4M of influenced revenue, and an operator-side planning background. Do not claim you learn faster; say what you would do in the first 90 days. Stop at sixty seconds | Pressure form of C1 (F4, F3) |
| D2 | "That move from 6 to 40: how much of that was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Precise attribution. Answer slot: say which parts were yours, which were the team's or the partners' own momentum, in your own words; if you cannot separate them, say so plainly and name what you do know. Hold the phrase "running the ISV channel" and no more | The attribution-honesty probe; shrinking an inflated claim gracefully is the skill being scored (F1, F5) |
| D3 | "Stop. You've said 'influenced' three times. One sentence: what will you be accountable for here?" | JD | [generic] | No claim about your past. Offer a one-sentence proposal ("I'd propose to be accountable for X, measured as Y, and I'd want to agree that with Ross"), concede you do not yet know how Kelverton sets its numbers, and ask the clarifying question you would need answered. Do not pretend to know the role's target | Tests composure and whether you can commit to a number without a JD to lean on (F3) |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "When an operator is both a prospect for my direct team and a partner for yours, who owns the relationship and who gets the credit?" | CASE | [generic] | No claim about your past. Propose principles rather than pretending to know Kelverton's actual seam: one owner for the day-to-day, a shared account plan, credit rules agreed before a deal, an escalation path. Ask how it works today before settling on a design | Ross's seam question; the pack does not know the real seam, so it asks for principles (F3) |
| E2 | "How would you handle credit when a partner-influenced deal closes through our sales team?" | JD | [generic] | No claim about your past. State the principle you would propose and the reason (partners stop investing when credit is unclear), and what you would want agreed in writing before the first deal. Show what it gives his team, not only what you need | Reciprocity framing: what the hire does for Ross's team (F3) |
| E3 | "Tell me about a time you disagreed with a sales leader and how it ended." | EXP | [generic] | An open prompt, and none of your sentences carries it, so this is a selection scaffold: pick a time with a named stake, a moment you said something difficult, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | Disagreement style with equals is what a Peer scores; theme from the persona stem (F3) |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with the beats your two sentences state: five years in transport consulting, in bus and light rail network planning; then nine years in partnerships, the last four running the ISV channel at a payments company. Answer slot: your reason for moving from consulting into partnerships is not in your material. If there was a deliberate reason, say it in your own words; if there was not, say so plainly and move on. End on why this role | The warm-up that is still scored; the arc is built from the two sentences that frame the whole application (F2, F5) |
| F2 | "What's caught your attention recently in how operators plan and run their services?" | CO | [generic] | No claim about your past. Answer slot: if something in the market report or your own reading caught your attention, name it and what you make of it; if you have followed little beyond the report, say so plainly and say what you would read first. One specific point beats three generalities | A casual question about the role's home topic, still scored (F4) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "For the operator partnerships you have today, what does a good one look like twelve months in, from the operator's side?" | It repeats the recruiter's own frame back to them and gets you the success measure you need for T2 |
| 2 | "How is the partnerships number set today, and what part of it would sit with me rather than with the commercial team?" | Aimed at Ross. It puts your stated gap (F3) on the table as a question about accountability rather than as an apology |
| 3 | "Where does an operator sit when it is both a customer and a partner: who owns the relationship day to day?" | Names the seam from E1 and shows you are already thinking about how the roles fit together |
| 4 | "Is there anything in the market report you are less sure of than the document makes it sound?" | Treats the report as a living document, which separates you from a candidate who recited it (A3). Ask only if you have a specific point behind it |
| 5 | "What would need to be true in 90 days for you to feel this hire was right?" | Gets the scoring criterion out of Deepa in her own words |
| 6 | "How do you like to work with someone in their first quarter: what do you want to see, and how often?" | Aimed at Deepa as your future manager; it signals you are already working out how to work with her |

No question is tied to either panelist's career path because no profile was available.

## Prohibited claims

What this pack will not coach, because your material does not carry it.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a direct quota, or a number | A negative you stated (F3) | "I've never carried a direct quota; what I've carried is influenced revenue." No slot |
| Sold into rail | A negative you stated (F4) | "I haven't sold into rail specifically." Then a plan, never a past. No slot |
| Generated, closed or owned £4M of revenue | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, with nothing on how it was counted. B1's slot stays inside the figure |
| Built the ISV channel from nothing | Inflated form of F1 | F1's quote at its own scope: the channel went "from 6 partners to 40". The material says running the channel, not founding it |
| Advised or planned for train operating companies | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The material says bus and light rail, not heavy rail, and does not say who the clients were. C4's slot stays inside the planning work |

## Sources

**Provided:** your message, which quotes the recruiter's email (panel, 60 minutes, 15-minute POV, "no slides needed", "Ross will push on commercials") and gives your background. The market report is described in your message as attached and read, but its text was not in the conversation I can read, so nothing in this pack draws on it.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

Queries sent, all refused (the host did not grant search permission):

- `Kelverton Rail company values`: refused
- `Kelverton Rail interview process partnerships manager`: refused
- `Kelverton Rail scheduling software train operating companies strategy news`: refused
- `Deepa VP Partnerships Kelverton Rail`: refused
- `Senior Partnerships Manager rail technology train operating companies job description`: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have decided whether a values section is warranted and supplied official value names. None is banked |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Would have checked the loop and persona weights. The recruiter's email already fixes this session's shape, so the weights rest on that |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Would have fed the CO bank and a grounding brief. A3, A2 and F2 are therefore method-only |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Would have fed an interviewer read and a reverse question tied to their paths. Only the Deepa query was sent; Ross was not searched once the host refused |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Would have supplied requirement lines for the fit snapshot. They come from the recruiter's words instead |

No dossier was present. No values-style round is detected: no loop source names one, and no values page was read.

## Upgrade menu

- The market report's text (paste it) → a grounding brief section, and A3, A2, the POV's consensus item and the operator close move from method-only to report-grounded; the POV theses can be rewritten against what it says
- The JD text → the requirement rows quote the JD instead of the recruiter's words, mid-list requirements get their own JD questions, seniority (F5) gets a real bar, and any gate the JD sets (location, travel) is surfaced
- Search access in this session → values, strategy, loop and interviewer research can be re-run, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can be offered once
- Deepa's and Ross's public profiles or bios (pasted) → an interviewer read, persona weights adjusted to each, and a reverse question tied to each path
- Your answers to the answer slots (what decided partner additions between 6 and 40, how the £4M was counted and which part was yours, which operators you worked with, whether you have presented without slides) → F1, F2, F3 and F6 become story-mapped `[grounded]` rows and A1, A4, B1, B4, C4 and D2 sharpen
- The partner or influenced-revenue report behind the £4M (an export or dashboard view) → F1 and F3 can rise from medium confidence, because there would be an inspectable artifact behind them
- A prior underwriting dossier, if you have one → the objection, the allowed strategies and the prohibited claims would come from verified evidence rather than from this pack's reading
