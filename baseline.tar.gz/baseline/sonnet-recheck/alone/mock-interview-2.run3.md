I'll read the reference files the skill requires before building the pack.
Search was refused, so the company-side research is unavailable. I'm building the pack from your JD and background and will say so in Sources.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-2-denied-cf70caf8/ed106c16-4fb7-4af0-81af-c146dca4859b/scratchpad/atlas-freight_operations-manager_interview_pack.md`. It has 22 questions, a fit snapshot against the JD and a prep schedule for the week.

I assumed a hiring-manager round, since you don't know who you're meeting.

The company research did not run. The host refused all three web searches, so nothing in the pack comes from the web. There is no Atlas values sheet, loop structure or strategy brief, and the pack's one company question (B5) is generic. Do 30 minutes on Atlas's own site yourself.

**Highest-ROI prep:** question A2, "You're over three supervisors today and this role has twelve." Your material supports leading three supervisors, so rehearse holding that and conceding the size difference specifically.

Say the word and I'll play the Skeptic on A2, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is interviewing you, and is it a hiring manager, a peer, or someone more senior? Whatever the recruiter said about focus areas or a take-home would reshape the banks.

If you allow web search, or paste Atlas's values and careers pages, I'll fill in the company side. Will you do either?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees), from the JD you pasted
- **Interviewer and relationship:** not known. This pack assumes a hiring-manager round, because you said you don't know who is interviewing you. Persona weights follow that assumption and are shown in section 5, so you can change them if you learn more.
- **Version:** first pass

## 1. How to use this pack

Personas describe how a question arrives (the interviewer's style). Types describe what is being scored. Every question carries one of each.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No question in this pack carries it, because no published values were available (see Sources) |
| EXP | Whether your background survives scrutiny: what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its business |
| CASE | A live problem from the role, scored on structure and reasoning |

The guidance is scaffolding, not a script. Wherever it says **Answer slot**, the pack does not know the answer, because your material does not say. Fill the slot from what actually happened, in your own words. If the honest answer is "that wasn't mine" or "that didn't exist", say that plainly. It is a good answer.

Provenance labels: `[grounded]` is traceable to your JD or your message. `[inferred]` is this pack's derivation, named where it is used. `[generic]` is a pattern for the role family with no claim about Atlas or about you.

## 2. Prep triage (sized to about a week)

1. **A2, three times out loud.** It is the question this pack names as the highest-ROI prep (section 6, bank A). Rehearse the hold-then-concede until it is boring.
2. **A1, A5 and C3.** The Power BI answer and the years-of-leadership answer. Both are short, and both are asked in some form almost certainly.
3. **C1 and D2.** Defend the 40% mis-pick number and say exactly which part was you.
4. **B1, B2, B3.** Say the case structure aloud: clarify, segment, hypothesize, data, action, metrics.
5. **E1.** Your 90-second arc.
6. **Write out your answers to the Answer slots** in A2, A3, A5, C1 and C4. Written answers are the fastest way to find out what you actually know.
7. **Insurance:** everything else. Separately, spend 30 minutes reading Atlas's own website. This pack could not research the company, so that homework is yours.

## 3. Fit snapshot

Evidence cells hold only your own words. Confidence grades your evidence, and nothing in your material has an inspected artifact behind it, so nothing is graded `high`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a shift you manage, not terminals and not four sites. Keep the words at that scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's four-sites line makes a probe on multi-site work likely. If any of your work spanned more than one site, say which and what your part was, in your own words; if it did not, say so plainly and stay with the operations you do run |
| F2 | "drive on-time performance" — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The surge plan touches service levels, but your material does not show whether on-time performance was measured. Answer slot: the JD's on-time line makes a probe on how service was measured likely. If on-time or another service measure was tracked, say which and what it showed; if none was, say so plainly and stay with the surge plan you ran |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | The mis-pick result is a quality result, and your material does not show a cost measure. The bridge is not stretched. Answer slot: the JD's cost-per-shipment line makes a probe on cost likely. If any cost was counted for the mis-pick work, say what was counted; if none was, say so plainly and say what cost measure you would track first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your quote carries three supervisors, and the JD asks for twelve. Hold the quote at its scope: "I'm currently a senior shift manager over 3 supervisors." The step up in span is the pack's observation, and it is the objection A2 rehearses. Answer slot: if you have led, covered for, or coordinated any supervisors beyond those three, say how many and in what role; if not, say so plainly and return to the three |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a skill statement, and your material does not show what reporting you have built in it. Answer slot: the JD says build reporting, so expect a probe on what you have produced. If you build reports, say what one shows and who reads it; if your Excel work is analysis and not reporting, say so plainly and stay with the Excel skill |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to dashboard or Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years of operations is in your message, and how many of those years involved leading people is not. A years requirement is a risk to rehearse, not a gate. Answer slot: if you can say how many of the 7 years you led others and in what role, say it, in your own words; if the leading years are fewer, say so plainly and describe what you lead today |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification claim with nothing inspected behind it, so expect a probe on what you applied. Lead with it in your own terms: "I'm green belt certified." The certificate itself is the artifact that would raise this row to `high` |

## 4. Prohibited claims

What this pack will not coach, and why. These were built from the fit snapshot before the question banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says warehouse and distribution operations, not terminals and not four sites. A3's slot stays inside what you have run |
| Led or managed twelve supervisors | Inflated form of F4 | F4's quote: "currently a senior shift manager over 3 supervisors". A2's slot asks only whether any supervisors beyond those three were yours |
| Drove on-time performance, or reduced cost per shipment | Inflated forms of F2 and F3 | The mis-pick quote and the surge-plan quote at their own scope. C4's slot asks only what measures you watch |
| Seven years of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops" says operations. A5's slot asks only how many of those years you led others |
| Built reports or dashboards in Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Led Lean or Six Sigma projects | Inflated form of F8 | "green belt certified" at its own scope. E2's slot asks only whether the certification was applied, and the pack does not assume the pick-path work used it |

## 5. Persona table

The loop is not documented, because company research was unavailable. The weights below rest on the hiring-manager prior plus the shape of your fit snapshot, and the fallback is the generic archetype (screen, hiring manager, panel) with flat weights outside that prior. If you learn the real rounds, send them and the weights will be recomputed.

| Persona (bank) | How it shows up | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Skeptic (A), 5 questions | Quiet probing of scale, Power BI, and years of leadership | Highest. The hiring-manager prior includes the Skeptic, and F1, F4 and F7 are scale gaps while F6 is a stated gap | Rehearse the one predictable objection (A2) until it is boring; state the limit before it is asked; build bridges only from your quoted sentences |
| Case / Strategist (B), 5 questions | Live operations problems: on-time slip, cost drift, peak surge, first 90 days | High. The hiring-manager prior includes it, and the JD's two headline metrics invite a diagnosis | Clarify, segment, hypothesize, data, action, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (C), 4 questions | Line-by-line on your numbers and tools | Medium. You have one headline number, and the JD names Excel, Power BI and two metrics | Know how the 40% was counted or say plainly that you don't; name the weakest assumption before they do |
| Pressure (D), 3 questions | Time-boxed and devil's-advocate versions of the scale objection | Medium-low. Nothing in your material signals this style, and it is rehearsed because the scale objection can arrive this way | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational (E), 3 questions | Biography opener, Lean casually, motivation | Medium. Every loop has an opener, and the JD's plus-skill gets asked casually | A prepared 90-second arc; treat casual questions as scored |
| Peer (F), 2 questions | Seam between terminals, credit across teams | Low. A four-site operation may put other terminal managers in the loop, but nothing here says so | Offer seam principles, not claimed knowledge of Atlas's seams; bring reciprocity |

No Values bank is included. No published values were in hand, and the generic archetype does not assume a values round.

## 6. Question banks

### Bank A: Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Name the Power BI gap first, in your own plain words: "I've never used Power BI." Then say what you would do first to learn it, as a plan, in your own words. If a second area is also honestly thin for you, name it. Do not offer Excel as a substitute for a tool you haven't used | F6 is the stated gap, so this question will find it. JD because it scores a listed requirement; the candor is the test |
| A2 | "You're over three supervisors today and this role has twelve. Why should we believe you can step up to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI rehearsal in this pack.** Hold: "I'm currently a senior shift manager over 3 supervisors." Name the limit before they do: the role's span is larger than the three you lead today. Follow-up 1, "that's a quarter of the span": concede the size difference specifically and say what you would do in your first weeks with twelve people, in your own words. Follow-up 2, "what makes you think it scales": answer from what you do with your three today, in your own words. Answer slot: if any supervisors beyond those three have been yours to lead, cover or coordinate, say how many and in what role; if not, say so plainly and return to the three. Follow-up 3, "have you ever led more than three": that same slot. Never claim the three is equivalent to twelve | F4 is where the JD presses hardest and where F1 and F7 add to the pressure, so this objection arrives in some form. JD because it scores the stated requirement; it gets the most follow-up levels because it is the likeliest rejection reason |
| A3 | "What's different about terminal operations from the warehouses you've worked in?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: the JD says terminal operations. If any of your work touched freight terminals, cross-dock or outbound linehaul, say what and your part in it; if not, say so plainly and stay with warehouse and distribution. Then turn it into a question for them about what a terminal day looks like, which is honest and shows curiosity. Do not assert how terminals work from general knowledge as though you had run one | F1 is a transferability gap and the most natural place for an interviewer to test it. JD because it scores the first line of the JD |
| A4 | "Why leave your current role, and why a regional carrier?" | EXP | [generic] | A selection scaffold, because no sentence of yours carries your reasons: pick the true reasons, state them in one or two sentences each, and tie them to something in the JD you actually want, such as the number of sites or the size of the team. If your honest reason is different from the JD's draw, use your honest reason | Motivation consistency is a standard Skeptic probe and it is cheap to rehearse. EXP because it tests your own story |
| A5 | "The role needs five-plus years of operations leadership. How much of your seven years has been leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say the 7 years in your own terms: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years you led others and in what role; if the leading years are fewer than seven, say so plainly and describe what you lead today. A shorter honest number is better than a round one that the next question pulls apart | F7 is the one requirement with a number on it, and screens often read such lines literally. JD because it scores a stated requirement |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our terminals has slipped over the past month. Walk me through your first week." | CASE | [generic] | Clarify first: how Atlas defines on-time, which lanes or customers, what window, when it started. Then segment (inbound or outbound, shift, day of week, customer, lane), form two or three hypotheses, name the data you need, and separate a quick fix from a structural one. Say who you would involve and how you would know it worked. Think aloud and state your hypothesis early. Make no claim about your past | The JD's on-time line (F2) makes this a natural live problem. CASE because it scores structure, not a right answer |
| B2 | "Cost per shipment is flat while volume has grown. Where do you look?" | CASE | [generic] | Split the ratio first: what is in the numerator and what is in the denominator at Atlas. Then walk the cost buckets you would check, labor and overtime, dock and handling, linehaul, rework and claims, and utilization. The one adjacent fact your material carries is "cut mis-pick rate 40% by redesigning the pick path"; use it only as an example of a quality lever, and do not say it lowered cost unless you know that it did | F3 is thin, so this question tests whether you can reason about cost without a cost claim. CASE with JD content |
| B3 | "A peak surge hits all four terminals at once and overtime budget is tight. How do you prioritize?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it as a decision: what you would ask first, what you protect (service on the most important freight), what flexes, and how you decide with limited information. You can say "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-sites line makes scaling the likely follow-up. If parts of your plan would carry across sites, say which, in your own words; if you only ran it for one, say so plainly and describe how you would adapt it | Your surge plan is the strongest matching story for a multi-site problem, and the follow-up probes F1's scale gap. CASE with EXP content |
| B4 | "You inherit twelve supervisors across four sites. Sketch your first 30, 60 and 90 days." | CASE | [generic] | Learn before changing: who they are, what each site's numbers look like, what the supervisors say gets in their way. Then pick one or two visible fixes and one structural change, and say how you would measure each. Be explicit about what you would not change yet. This is a plan for the future, so make no claim about your past | F4's scale gap becomes a forward-looking plan here, which is the legitimate way to answer a span question you have not yet lived. CASE because it is a role-specific plan |
| B5 | "What do you understand about how a regional carrier like ours operates differently from a national one?" | CO | [generic] | Research was not available for this pack, so this answer is yours to build. Spend 30 minutes on Atlas's own site and note service area, terminals and customers. Say what you learned and where your knowledge ends: "here is what I've read, and here is what I'd like to learn from you." Never assert facts about Atlas you did not read | No company research was possible, so CO is the weakest-covered type in the pack. It is included so the first live encounter with the question is not the interview |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40% by redesigning the pick path. How was that counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the result in your own words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how the 40% was counted and over what period; what it is sensitive to; the assumption behind it you would defend least; and which part was yours versus the team's. If you don't know how it was counted, say so plainly. Never supply a baseline or method you can't repeat under a second question | F3 carries your only headline figure, and a Prober goes to it first. EXP because it tests attribution and how well you know your own number |
| C2 | "What do you use Excel for in your current role?" | JD | [grounded] "solid Excel" | Say "solid Excel" at its own scope. Answer slot: the JD says build reporting. If you build reports, say what one shows and who reads it, in your own words; if your use is analysis and not reporting, say so plainly and stay with the Excel skill. Do not describe a report you did not build | F5 is thin on what was built. JD because it scores the Excel half of the reporting requirement |
| C3 | "You haven't used Power BI. How would you have a working dashboard in your first 60 days?" | JD | [grounded] "never used Power BI" | Begin with the plain acknowledgment: "I've never used Power BI." Then give a plan in your own words: what you would ask for (training, an analyst to pair with), which first dashboard you would build, and which of the JD's metrics it would show. A plan, never a past | F6 is a stated capability gap. A plan with a named first deliverable is the strongest honest bridge. JD because it scores the Power BI half of the reporting requirement |
| C4 | "What service and cost measures do you watch in your current role?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Name the measures you actually watch, in your own words. Answer slot: the JD names on-time performance and cost per shipment. If those are among your measures, say how you track them; if not, say so plainly, name what you do watch, and say how you would add those two measures. Never state a figure you can't source | F2 and F3 are both thin, and the JD's two headline metrics need an answer that is honest about what you track today. JD because it scores both stated metrics |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run a multi-terminal operation?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause and restate the question. Hold on what you can stand behind, in your own words: the seven years, the pick-path result, the surge plan you ran, and the certification. Concede specifically that multi-site scale is the part of the JD your material speaks to least. Do not claim you are better than a candidate you can't see, and do not fold on the core claim to restore the mood | The Pressure version of A2. JD because it scores fit directly; the hold-then-concede structure is the drill |
| D2 | "That mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence as you said it: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts were yours and which were the team's, in your own words; if the data or the layout work was someone else's, say so plainly. Concede that you can't speak for others' contributions, which is honest and not a fold | Attribution is the Pressure persona's favorite probe of a headline number (C1's twin). EXP because it tests what was actually the candidate's |
| D3 | "Our supervisors are tenured and set in their ways. You'd be coming in over twelve of them. They won't listen to you." | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Do not argue. Pause, restate their concern in one sentence, and answer from what you do with your three today, in your own words. Answer slot: if you have had to win over supervisors who resisted, say what happened and what you did; if no such time comes to mind, say so plainly and say what you would do in the first weeks | F4's scale gap with a human edge. The question asserts nothing about you, so any past in your answer comes from your own slot. JD because it scores the leadership requirement |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc with four beats: the seven years, where you are now, the pick-path result, the surge plan. Say each in your own words and keep each at its quote's scope. Close on why this role, in one sentence that is true for you. Rehearse it to 90 seconds with a timer | Every loop opens this way, and a casual opener is still scored. EXP because it tests whether your story is coherent and economical |
| E2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say "I'm green belt certified." Answer slot: the JD lists Lean and Six Sigma as a plus. If you currently apply any of the tools, say which and where; say whether the pick-path redesign used belt methods, and if it did not, say so plainly and describe that work as it was. If you don't currently apply them, say so and say what you would use first | F8 is a lead strength with a cert behind it but nothing inspected. JD because it scores the plus-skill, asked in a casual register |
| E3 | "What's drawing you to a regional freight business?" | EXP | [generic] | A selection scaffold: pick the reasons that are really yours (the size, the scope of four sites, the team, the kind of work) and say each in a sentence. If you have no strong pull toward freight specifically, say what draws you to the role and be straightforward about that | Motivation questions come in the friendly register too. EXP because it tests the candidate's own story |

### Bank F: Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our four terminals share carriers and customers. Where's the seam between one terminal and the network, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not claimed knowledge of Atlas's seams: who owns the decision, what gets escalated, what data both sides agree on first. Say how you disagree with an equal: state your view, ask for theirs, and agree on what evidence would settle it. Bring reciprocity: what you offer that terminal's manager in return | The four-sites structure (F1) makes the seam a natural peer topic. CASE because it is a live collaboration problem |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others contributed to the pick-path work, say who and how you made sure they were credited; if it was largely your own work, say so plainly. Do not invent a team or a credit-sharing moment | Credit-sharing is a standard peer probe, and it links back to C1 and D2. EXP because it tests attribution habits |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A3, B1, B3, F1 |
| Drive on-time performance | B1, C4 |
| Cost-per-shipment down | B2, C4 |
| Lead a team of 12 supervisors | A2, B4, D1, D3 |
| Build reporting in Excel/Power BI | A1, C2, C3 |
| 5+ years operations leadership | A5, D1 |
| Lean/Six Sigma a plus | E2 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four terminals today, and which one is hardest to move?" | Uses the JD's own metric and tells you where your first 90 days would go |
| R2 | "How are the twelve supervisors spread across the four sites, and what has changed in that team in the last year?" | Shows you are thinking about the team you would inherit and its span |
| R3 | "Who produces terminal reporting today, and what does it run on?" | Turns the Power BI gap into a question, and surfaces who could help you ramp |
| R4 | "Where do you see the biggest cost-per-shipment lever right now: labor, linehaul, dock, or rework?" | Invites their view on the second headline metric |
| R5 | "What would make you say in a year that this hire was a clear success?" | Gets the real scoring criteria in their words |
| R6 | "What are the next steps, and who else would I meet?" | The loop could not be researched, so this gets the process from the source |

## 8. Sources

Provided documents: the JD text you pasted, and your message describing your background. Nothing else was read.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Three searches were sent and all three were refused by the host, so nothing from the web is in this pack.

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics news strategy terminals": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fed a values cheat sheet and VAL questions; both are absent |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have fixed the loop and the persona weights; the weights rest on the hiring-manager prior and the generic archetype, said plainly in section 5 |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have fed CO questions and a grounding brief; B5 is generic and the brief is absent |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 9. Upgrade menu

- Permission for web search, or a paste of Atlas's values page and careers page → a company values cheat sheet, current CO questions, and a loop-based persona weighting in place of the generic one
- A deeper research pass (offered once: up to 6 more searches and 2 more fetches, several more minutes; it needs search permission) → a grounding brief on Atlas's strategy and recent moves
- The interviewer's name and role, or the round type → persona weights read from their public footprint, and a reverse question tied to their path
- The recruiter's prep email → any pre-declared focus area or deliverable, and coverage that is stated rather than assumed
- Your written answers to the Answer slots in A2, A3, A5, C1 and C4 → upgraded fit rows F1, F4, F7 and F3 (and F2, F5 through C2 and C4)
- The green belt certificate and a before-and-after sheet for the pick-path change → F8 and the mis-pick claim could rise from `medium` to `high`
- A sample of the shift report or KPI sheet you use today → F5 could move from guessed to evidenced
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and constraints for the prohibited list; not required
