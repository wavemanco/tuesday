Research is back on all three targets. I'm checking Quillfield's own careers page to see whether this posting is live there, then I'll write the assessment.
# Revenue Operations Lead at Quillfield: should you apply?

## Decision snapshot

**Yes, worth applying, as a stretch: R7 (owning a forecast) and R11 (billing data) are requirements you've told me you haven't met. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R4, R5, R10 · adjacent: R3 (4+ years at a B2B software company), R6 (spreadsheet modelling), R8 (Run the quarterly forecast with the CFO) · unclear: R9 (Working with finance on billing or revenue data) · absent: R7 (Experience owning a forecast), R11 (Own billing data)
- `important`: direct: R12

R7 and R11 are the rows you have confirmed you don't meet, and R8 is the nearest bridge to the forecast duty.

**Opportunity ledger.** The employer is established and the stated salary sits inside the market band (RR1). The posting is unconfirmed on Quillfield's own site (RR2), and team size, authority and the forecast ramp are unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days a week), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) R1 and R2 meet your own limits; (2) R9 turns up real finance-facing revenue work in your history; (3) RR4's answer shows Quillfield expects to ramp someone on the forecast and billing data, not hand it over on day one.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` About Quillfield page, search result snippet |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe is Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` search result snippet; the profile page itself was not opened |
| Scope read | Four duties (CRM data, billing data, reporting, a CFO-facing forecast) sit in one hire. The forecast and billing duties are the ones furthest from your background | `[inferred]` from the posting's duty list against your stated history |
| Market calibration | UK-wide pay guide for revenue operations leads at B2B software companies: median base £64,200, interquartile range £57,800–£70,400, n=438. The posting's range sits inside that interquartile range, with its midpoint (£64,250) close to the median. The band is not Bristol-specific, and I read only the snippet | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` the posting's own figure |
| Unknowns | Whether the role manages anyone; who owns the forecast model today; how long the ramp is; any stated first-90-day outcomes | `[grounded]` posting is silent on each |
| Contradictions | None between the posting and the About page. The careers page I tried, quillfield.co.uk/careers, returned no page, so the posting is not confirmed on Quillfield's own site | `[grounded]` fetch result |

## Evidence map

Your background is typed prose, so it counts as self-report. That caps most rows at `medium` until there's something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you live or what you will commute. Nothing settles whether the term is met | `[grounded]` no constraint given | Ask G4 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | You haven't given a floor, so I can't say whether the range meets it. The range itself is inside the market band | `[grounded]` posting; no floor given | Ask G4 |
| R3 | 4+ years in revenue operations or sales operations at a B2B software company | must_have | adjacent | medium | discovery | Five years in sales operations, two of them running RevOps for the UK team, clears the years. Whether a B2B payments company counts as "software" is unconfirmed, so I took the lower fit | `[grounded]` your stated history; `[inferred]` that "payments company" may or may not read as software | Confirm in your own words what the product was |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. Confirmed and specific, but nothing inspected yet | `[grounded]` your stated certification | A certification ID or credential page would raise to `high` |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly. "Strong" is a depth claim I haven't probed, so expect a technical probe | `[grounded]` your stated usage | A sanitized query or dashboard source would raise to `high` |
| R6 | Spreadsheet modelling | must_have | adjacent | medium | discovery | Excel daily is regular use, but it doesn't say whether you build models (scenarios, forecasts) as opposed to analysis and reporting | `[grounded]` your stated usage; the gap is in what's unsaid | A sanitized model or workbook would settle it |
| R7 | Experience owning a forecast | must_have | absent | none | transferability | You confirmed finance owned the company forecast. The requirement is ownership, and your pipeline review is adjacent, not the same kind of work. The bridge is R8 | `[grounded]` your statement | Ask G1; the bridge and its limit are in R8 |
| R8 | Run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which feeds forecasting. Limits: it is monthly, not quarterly; it is with a sales director, not a CFO; and finance owned the company forecast | `[grounded]` your stated review; limits from your own statement | A sanitized pipeline review pack would show how close it is |
| R9 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. The posting says "billing or revenue", and your renewal dashboards touch revenue data, but I don't know whether finance was involved | `[grounded]` your statement; `[inferred]` that renewal reporting may count | Ask G2 |
| R10 | Own CRM data | must_have | direct | medium | none | You were Salesforce admin certified and rebuilt the pipeline and renewal dashboards, which sit on CRM data. Quillfield's CRM is unnamed, so tool fit is unconfirmed | `[grounded]` your stated work; the posting names HubSpot or Salesforce | Confirm which CRM Quillfield runs |
| R11 | Own billing data | must_have | absent | none | capability | You've never worked on billing data. Adjacent revenue work may exist (R9), but billing data itself is untouched | `[grounded]` your statement | Name the closure path in the plan (A2); G2 may surface adjacent work |
| R12 | Build the pipeline and renewal reporting sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance ran on them is unknown | `[grounded]` your stated work | A sanitized dashboard screenshot would raise to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R7, R8) | transferability | A monthly pipeline review with the sales director, and a confirmed statement that finance owned the company forecast | R7 is `absent` and R8 is `adjacent`; the forecast is the heaviest duty in the posting and your biggest stated gap | Building the pipeline-weighted or renewal forecast numbers finance consolidated; a quarterly or annual plan you modelled inputs for; a forecast-accuracy review you ran | A sanitized pipeline-review pack or forecast input sheet | `[grounded]` your statement; `[inferred]` that forecast ownership is the heaviest duty, from the posting's duty list |
| G2 | Finance and billing or revenue data (R9, R11) | discovery | No billing data work. Renewal dashboards touch revenue data, but finance's involvement is unstated | R9 could move from `unclear` to `adjacent`; R11 may stay `absent` | Reconciling renewals or bookings against finance's figures; building a report finance signed off; a data fix that involved invoices or ARR | A sanitized renewal dashboard or a reconciliation note | `[grounded]` your statement; `[inferred]` that renewal reporting may count as revenue data |
| G4 | Location and pay terms (R1, R2) | hard_gate | No constraints given | A failed gate would end the application however strong the fit is | Not applicable: this is a yes or no on your own limits | None | `[grounded]` no constraints given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The pay is a credible offer for the title, not withheld or vague | `[grounded]` posting figure against the `[generic]` band in role reality | What are the share options worth, and what is the vesting schedule? | noted |
| RR2 | Posting not confirmed on the company's own site | unknown | — | "jobs.tallyboard.example/quillfield/revenue-operations-lead-2291" | The role may be listed only on the job board, or Quillfield's careers page may sit at a different address | `[inferred]` from one guessed careers URL returning no page, which does not show the posting is absent | Can you confirm the role is open at Quillfield and who it reports to? | unresolved |
| RR3 | Team and authority unstated for a "Lead" title | unknown | — | "Revenue Operations Lead" with no mention of reports or budget | "Lead" may mean leading people, or may mean the senior individual contributor under the Head of Revenue Operations | `[inferred]` from the title against the posting's silence on team | Does this role manage anyone, and which decisions does it make itself versus Tamsin Achebe's? | unresolved |
| RR4 | Forecast and billing data duties with no ramp described | unknown | — | "run the quarterly revenue forecast with the CFO"; "own our CRM and billing data" | The posting may expect these on day one, or may expect a ramp. It states no first-90-day outcomes | `[inferred]` from the duty list against the posting's silence on ramp | Who owns the forecast model and the billing data pipeline today, and how is the first quarter supposed to go for this hire? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the monthly pipeline review you run with your sales director, and the pipeline and renewal dashboards you rebuilt | These are the closest verified evidence to R8 and R12 | `[grounded]` R8, R12 rows | pending your approval |
| A2 | State the gaps plainly instead of stretching: "I run the monthly pipeline review with our sales director; finance owns the company forecast, and I haven't owned it. I haven't worked on billing data." Then ask RR4 | Every clause traces to your own sentences; R7 and R11 are confirmed gaps, so the candid line is also the safe one | `[grounded]` your statements | pending your approval |
| A3 | Ask RR2, RR3 and RR4 verbatim with the recruiter before investing in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Keep the forecast gap on a closure path, not a claim: if G1 surfaces forecast-input work, add it; otherwise present R8 as adjacent with its limits | The bridge is `adjacent`, never ownership | `[grounded]` R7, R8 rows | pending your approval |

## Evidence status

Verified: none yet. Everything above is your own prose background, so the claims are leads, not proof. No prior-context leads were used.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization and contradictions rows and RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved role reality's market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved role reality's hiring manager row and plan A1; I read the snippet only |

A deeper pass would run two more targets: company diligence, and a news sweep. The offer is below.

I can also write all of this up as `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- Your CV or a prior resume: other evidence may sit there, which would firm up R3, R6 and R10.
- A sanitized pipeline review pack or a dashboard screenshot: R8 and R12 could reach `high`, and it would show how close R8 is to the forecast duty.
- A Salesforce certification ID: R4 to `high`.
- Your answers to G1, G2 and G4: they decide whether R9 moves and whether R1 and R2 clear.
- Quillfield's own careers link, or the recruiter's email domain: closes RR2.
- A deeper research pass on Quillfield (funding and leadership churn, public candidate and employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

G1 — Have you ever built or maintained a forecast number, such as a pipeline-weighted or renewal forecast, even one finance later consolidated? What did you own and what did finance own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you worked with finance on revenue data, for example reconciling renewals or bookings, or a report they relied on? What exactly did you do?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G4 — Do the posting's terms (Bristol, two office days a week, £61,500–£67,000) meet your own limits?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.