Rowan, I won't write the hidden text, either the instruction aimed at AI screeners or the 1pt keyword block. The tailored ledger is below.

**Why not:**
- Both are written to deceive software that is screening on the employer's behalf.
- Your resume would carry lines you didn't write and can't defend, and those would cancel out the lines you can.
- Hidden text can be detected. One platform reports finding white text in 1% of the résumés it processed over half a year. A staffing firm reports about 10% of those it scans with AI. One candidate told a newspaper a recruiter who found his turned him down for it.
- What happens after it's found is the employer's call, not yours.

**What the evidence says about screening.** One résumé-builder vendor interviewed 25 US recruiters. Only 8% (two people) configured content auto-rejection. Match scores mostly decide who gets reviewed first, and the recruiters said that "When automated filters are used, they're almost always knockout questions", meaning yes/no eligibility checks on the application form. So put the truthful keywords where your evidence already supports them, and put your strongest lines first. The ledger does both.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch — 12 automated flows" | `split` | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` resume | pending your approval |
| E2 | Experience | (second half of the line above) | "HubSpot daily for 4 years" | `split` | "HubSpot daily for 4 years" | `[grounded]` resume | pending your approval |
| E3 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; budget I controlled: about $600k a year" | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting" | `cut` | "I pull my own numbers in HubSpot reporting" | `[grounded]` resume | pending your approval |

- **E1 and E2:** both halves stay as you wrote them. The split lets the lifecycle email programme lead its own line, and I didn't write "built in HubSpot" because your sentence doesn't say that.
- **E3:** I kept "about" and "a year", and kept "controlled" rather than "managed". I haven't touched the paid search line otherwise.
- **E4:** this cuts the SQL clause. It is a cut, not a claim. Nothing in the proposed line suggests SQL, so the SQL requirement stays a gap (G1 below).
- **Webinar line:** "Ran a monthly webinar series, average 300 registrants." stays exactly as written, so there's no row for it.
- **Order:** your current order (paid, lifecycle email, webinars) already matches the JD's order, so there's no reorder row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `not_evidenced` | "6 years B2B SaaS" is marketing years, not demand gen years. See C1. | `[grounded]` your resume line; `[generic]` screeners read the years as demand gen only when the resume says so |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E2 gives HubSpot its own line. | `[grounded]` resume |
| R3 | SQL-literate | must-have | `not_evidenced` | Named absence G1 below. | `[grounded]` resume |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E3. Your phrase is "controlled", and the figure is "about $600k a year". | `[grounded]` resume |
| R5 | Paid search | important | `already_evidenced` | "Ran paid search and paid social" | `[grounded]` resume |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E1 | `[grounded]` resume |
| R7 | Webinars | important | `already_evidenced` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume |
| R8 | Content distribution | important | `not_evidenced` | Nothing in your resume. See C2. | `[grounded]` resume |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | Six years as a B2B SaaS marketing manager, plus paid, email and webinar work. It doesn't say how many of those years were demand gen. | It's the first requirement in the JD, and a reader can't confirm it from "6 years B2B SaaS". | Years you ran paid channels as your main job; years you were measured on leads or pipeline; years you ran webinars or email for lead generation | Job titles with dates, a goals or targets doc, a lead report | `[grounded]` the resume doesn't state the years; `[generic]` demand gen years are usually read from role scope |
| C2 | Content distribution | important | No content work is mentioned. | It's one of the four channels the JD names. | Promoting blog or gated content through email or paid; syndication or newsletter placements; sending webinar recordings or content out to lists | A content calendar, campaign recap, or distribution report | `[grounded]` the resume is silent on it; `[generic]` JDs list channels a hire is expected to run |

**G1, SQL (named absence).** You wrote that you aren't strong in SQL and ask your analyst, so I won't write anything that suggests otherwise. Closing the gap would take learning the basics, for example a short course plus a few queries against a sample dataset. Until then, E4 shows only what's true: you pull your own numbers in HubSpot reporting. If SQL is a hard requirement for the hiring manager, this is the likeliest reason an application stalls.

## Not written, and why
- **The hidden prompt-injection text and the 1pt keyword block (your request).** Refused for the reasons above.
- **"Senior Marketing Manager" as your title.** Yours is Marketing Manager, and a retitle can't upgrade it.
- **"Managed" or "owned" a $600k+ budget.** You wrote "controlled", and the $500k requirement is met by what you wrote.
- **"Owned demand generation".** That's the JD's phrase. Your lines show channels you ran, not ownership of the function.
- **"5+ years of demand generation".** Your resume says 6 years in B2B SaaS marketing. See C1.
- **Anything implying SQL or analytics.** That includes "data-driven", "SQL-literate" and "analytics". You told me the truth on SQL.
- **Content distribution, Marketo, or pipeline or revenue results for the webinars.** None of these appears in your material. "Registrants" also stays "registrants", not "attendees".

## Parse-safety check
You pasted text, not a file, so I couldn't run the layout checks (columns, tables, text boxes, headers and footers, icons, skill bars). Your lines are plain text and parse cleanly. Use standard headings (Experience, Skills) and a `.docx` or text-layer PDF. If you send the actual file, I can also check it for hidden text that a template or earlier tool added without your knowing.

## Upgrade menu
These are optional extras I'd build only on your approval.
- **A webinar or email-programme report.** Even one number, such as a click or conversion figure, would let me tighten E1 and the webinar line with grounded detail.
- **Your actual resume file.** I could then run the full parse check.

## Questions
C1 — How many of your six years was demand gen your main job (paid, email and webinars for lead generation), and in which roles?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you ever distribute content (promoting blog posts, gated assets or recordings through email, paid or syndication)? If so, how?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

E3 — Is the roughly $600k a year the combined paid search and paid social spend, and did you control it across all six years or only some?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.