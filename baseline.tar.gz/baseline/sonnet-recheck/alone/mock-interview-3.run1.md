I'll start by reading the skill's reference files.
Web search was refused, so I'm building the pack from your message alone and marking what that costs. I'm writing the file now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-3-denied-4223289b/9c2cd18c-e2a5-4bf9-8bf6-f999fff46b78/scratchpad/stripe_product-operations-manager_interview_pack.md`.

I built it for a final round with an unknown interviewer, using only what you told me. You gave no JD or CV, and my four web searches were refused. So nothing in it is Stripe-specific. It has 21 questions across seven interview styles, a requirement-coverage table, reverse questions, and a tracker for what's still missing.

The most useful thing to rehearse is the "which part of this role would you be weakest at on day one?" question (A1) and its follow-up (A4). Without your CV I can't tell which gap an interviewer would press on, but this question comes up in nearly every final round.

I can play the Skeptic on A1 and A4 as a live drill if you want to try it.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting (future manager, peer, skip-level or cross-functional), and did the recruiter name any focus areas or a deliverable? Your answer reweights every question bank.
2. Can you paste the JD and your CV? Without them the evidence column stays blank, and you can also tell me to proceed without them.
3. Does the role's location and work authorization fit you? The pack flags this as unconfirmed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer: not given. Relationship to you: not given. This pack is built from your request alone: no JD, no CV, no interviewer, and no web research (the searches were refused). Everything below is therefore labeled `[generic]`, and the upgrade menu at the end says what each missing input would change.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Rehearse out loud: each guidance cell is meant to be spoken in 90 to 120 seconds. Guidance is scaffolding, not a script. This pack holds no sentence about your past, because none was provided, so every story slot is a selection scaffold that you fill from what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you understand the company's strategy and altitude |
| CASE | Structure and reasoning on a live problem from the role |

Highest-ROI prep: the day-one-weakness objection, A1 then A4. It is asked in some form in nearly every final round, and a calm, specific, rehearsed answer changes the tone of the conversation.

## Fit snapshot

No background was provided, so this is the worksheet variant: every evidence cell reads `none given`. The requirements are role-family patterns written as plain prose, not quotations, because no JD was supplied or fetched. Fill the evidence column yourself, with your own sentences, before you rehearse the banks.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate product launches or rollouts across several teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a launch you coordinated across more than one team, with your specific role, something you personally changed, and a stated outcome. Selection scaffold: pick a launch whose schedule was at risk. If no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define, track and report product performance metrics (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: what was counted, over what period, against what denominator, and which part was yours. Selection scaffold: pick one figure you can defend. If none comes to mind, or you do not know how a figure was counted, say so plainly, then give the nearest thing your material does carry, or how you would find out |
| F3 | Build or improve operating cadences, planning and review processes (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a process you introduced or changed, who used it, and what you would do differently. Selection scaffold: pick a process, not a one-off project. If no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would design one |
| F4 | Influence senior stakeholders without formal authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a moment you disagreed with someone more senior, what you said, and what happened to the relationship. Selection scaffold: it needs a named stake and an intact relationship at the end. If no such moment comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Turn customer or internal feedback into product priorities (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a piece of feedback you gathered, how you weighed it, and what changed because of it. Selection scaffold: pick a case where the feedback pointed away from an internal preference. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Diagnose issues with data tooling such as SQL or dashboards (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a tool you used yourself and a question it answered for you. Selection scaffold: name the tool and the question, not the toolset. If you did not use such a tool, say so plainly, then give the nearest thing your material does carry, or how you would learn it |
| F7 | Work authorization and location for the role's office (role-family gate, no source) | none given | none | [generic] | hard_gate | Your material does not establish it. A gate is a term you meet or do not; wording cannot close it |

## Persona table

No loop source established how Stripe's final round is run, so the weights rest on a pattern, not on this company's documented process. The fallback is the Generic archetype: flat weights, said plainly. Your relationship to the interviewer is unknown, so the table blends the priors for each possibility: hiring manager (Case and Skeptic), peer (Peer and Prober), skip-level (Case and Pressure), cross-functional (Values and Conversational). Tell me who you are meeting and I will reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gap between your background and the role; why this role, why now | Medium. Hiring-manager prior; also holds the pack's highest-ROI objection, so it gets one extra question | Rehearse the day-one-weakness answer until it is boring; name a limit plainly and give a concrete ramp plan |
| Case / Strategist | Live problems set in the role: diagnose, plan, design a process | Medium. Hiring-manager and skip-level prior; the role is process-heavy, so cases are natural | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Values / Behavioral | Scenario prompts scored for how you behaved | Medium. Cross-functional prior; Stripe's published values were not retrieved, so these are generic stems | Pick stories you can tell in your own words; use "we" for context and "I" for what you did |
| Data-Driven Prober | Asks how a number was counted and which assumption is weakest | Medium. Peer prior | Know what you can and cannot say about each figure; say plainly when you do not know |
| Peer Evaluator | Seam-splitting between product operations and adjacent teams; credit and disagreement | Medium. Peer prior | Reciprocity: what you bring their team; propose seam principles rather than pretending to know the seam |
| Conversational | Friendly openers such as the walk-me-through-your-journey question | Medium. Cross-functional prior; the risk is treating it as unscored | A tight 90-second arc; treat casual questions as scored |
| Pressure | Interrupts, time-boxes, questions motive | Lower. It leads the priors only for skip-level and bar-raiser-style rounds; it rises if you meet one | Pause, restate, hold a position through two follow-ups, concede specifically |

## Question banks

Provenance is `[generic]` throughout: no row asserts anything about your past. If a question asks you to choose an instance, the guidance is a selection scaffold ending in an honest branch.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick one real area from your own self-assessment of F1 to F6, name it plainly in one sentence, say what you would do in the first 30 days to close it, and stop. Do not pick a fake weakness. If nothing comes to mind, say so plainly, then name the area where you have the least to show | The pack's highest-ROI rehearsal: asked in some form in most final rounds; F1 to F6 are the rows it draws on. JD because it scores the role's stated demands |
| A2 | "Why product operations rather than product management?" | JD | [generic] | Say what draws you to running the machinery of product work, in your own words, then name what you would not want to give up. Keep it to motive and preference, not claims about what you have done. If you are unsure, say what you are testing about yourself | Motivation consistency is the Skeptic's core score; no row is needed because it asks about the future |
| A3 | "Why Stripe, and why now?" | CO | [generic] | Stripe-specific facts were not retrieved, so this answer needs your own reading of Stripe's public materials; build it from two things you read yourself, in your words. Do not rely on this pack for company facts | CO because it tests homework depth; `[generic]` because no research ran |
| A4 | "You've named your weakest area. Why should we take that risk?" | JD | [generic] | Hold, then concede: restate the limit in one sentence, give the ramp plan, and say what you would want from the team to close it faster. Hold through two follow-ups; do not suddenly claim the gap is smaller. Concede specifically, such as "I have not done X" only if that is true | The deepest level of the A1 objection; hold-then-concede is the Pressure-style bar for a Skeptic question |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A feature launch has slipped twice and three teams blame one another. You have just joined the program. What do you need to know first, and what do you do in week one?" | CASE | [generic] | Clarify first: what was promised, to whom, what changed between dates, who decides. State the objective. Then segment: dependencies, decisions, communication. Propose a first-week plan and one metric. Challenge one premise, such as whether the slip is a scheduling problem or a scoping problem | Live problem from the F1 requirement; presupposes nothing about your past |
| B2 | "Adoption of a recently launched feature is 20 percent below target. Diagnose it." | CASE | [generic] | Clarify what adoption means and how the target was set; split the funnel (awareness, access, first use, repeat use) and by segment; form hypotheses, say which data would confirm each, and state what you would do if the data were not available | Tests F2 and F5 through a concrete diagnosis |
| B3 | "Design the operating cadence for a product organization with many teams. What exists, and what would you refuse to create?" | CASE | [generic] | Start from the decisions the cadence must support, not the meetings. Name the artifacts, who owns each, and a cost test for every recurring meeting. The refusal half is the differentiator: say one thing you would not create and why | Tests F3; the refusal clause scores judgment |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time where the truth landed and the relationship held; it needs a named stake and what you actually said. Use "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem; draws on F4 |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two actually conflicted; name the metric, the customer harm you weighed, and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem; draws on F5. Stripe's own wording of its values was not retrieved, so no value is named here |
| C3 | "A senior leader asks you to drop a metric that makes their launch look bad. What do you do?" | VAL | [generic] | A hypothetical, so no past claim is needed. Ask what the metric is for; separate the leader's concern from the data; offer a way to present it honestly with context; say where you would not move, which is misreporting | Tests the same spine as C1 without needing a story; F2 and F4 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Choose a result you would put a number on. Walk me through how that number was counted." | EXP | [generic] | Selection scaffold: choose a figure you can explain exactly: what was counted, over what period, against what denominator, and which part was yours. If no such figure comes to mind, or you do not know how it was counted, say so plainly, then give the nearest thing your material does carry, or how you would find out | The defend-the-number drill, ready before a CV exists; F2 |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name, in your own words, the weakest assumption you know of before they do. That move turns a gotcha into credibility. If you do not know of one, say so plainly and say how you would test it | Follow-up to D1; F2 |
| D3 | "A weekly dashboard shows the headline metric up 8 percent while support contacts are also up. What is your read?" | CASE | [generic] | Ask what the metric counts and whether definitions changed; list at least two hypotheses that make both true; say which cut of the data you would pull first and what would change your mind | Live analysis problem; F2 and F6 |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: who decides, who prepares the decision, who owns the follow-through. For disagreement: surface the data, state your recommendation, and commit once decided | Peer prior; F4 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an instance where credit was split; say what you did to make others' contribution visible. If no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; F4 |
| E3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity framing: give one thing you need (context, access, a decision-maker) and one thing you will offer their team in return | Peer prior; tests whether the hire reduces or adds to their load |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two reasons in your own words and one honest acknowledgment of what an internal candidate has that you do not. Stop at sixty seconds | Persona stem; scores composure under a time-box |
| G2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Selection scaffold: separate what you did from what the team did, in one sentence each. Hold through two follow-ups; concede only what is true. If no such result comes to mind, say so plainly, then give the nearest thing your material does carry | Persona stem; attribution honesty, F1 and F2 |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc with three beats: where you started, the turn that led toward product operations, why this role. Build it from your CV once you share it; tell it only with facts you can stand behind | Persona stem; the opener that is easy to treat as unscored |
| H2 | "What are you actually playing with in your work tooling these days?" | JD | [generic] | Name one tool and one real use. The JD's plus-skills were not available, so I cannot say which tool matters here. If you are not using anything new, say so plainly and say what you would try | Persona stem; F6 |
| H3 | "What would you want to be doing a year into this role?" | JD | [generic] | Describe the kind of problems you want to own, not a title. Tie it to what the team needs, which you can ask about in the reverse questions | Future-facing; no claim about the past |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 launches and rollouts | A1, B1, G2 |
| F2 metrics and reporting | B2, C3, D1, D2, D3, G2, H2 |
| F3 operating cadences | B3 |
| F4 senior stakeholder influence | C1, C3, E1, E2 |
| F5 feedback into priorities | B2, C2 |
| F6 data tooling | D3, H2 |
| F7 work authorization and location | none: a gate is surfaced, not rehearsed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How does product operations here measure whether it is succeeding, and what would a good first year look like?" | Shows you think in outcomes and gives you the scorecard to prepare against |
| R2 | "Where do product and engineering teams most often get stuck on process, and what has been tried?" | Invites a real problem you can respond to, not a pitch |
| R3 | "Which decisions in this role are mine, and which do I recommend?" | Clarifies altitude and authority, which a process role is easily confused about |
| R4 | "What would make this hire a mistake six months in?" | Surfaces the interviewer's real worry while you can still address it |
| R5 | "Is there part of the interview process I have not met that I should prepare for?" | Recovers the loop structure this pack could not establish |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question; strongest if the interviewer is a peer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed | No sentence of yours was provided, so there is no wording to inflate and no stated negative to protect | Add your CV or a few sentences about your work and this section is rebuilt against them |

## Sources

Provided documents: your message (company, role, final round). No JD, CV, interviewer profile, assessment or recruiter guidance was supplied.

Searches sent, all refused (permission not granted), none returned results:

- "Stripe operating principles values": refused
- "Stripe interview process product operations manager": refused
- "Stripe strategy 2026 news annual letter": refused
- "Stripe Product Operations Manager job description": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have fed the values cheat sheet and the VAL questions; both are omitted or generic |
| 2. `Stripe interview process product operations` | unavailable | Would have set the loop structure and persona weights; weights fall back to the Generic archetype |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current strategy; they are generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; no interviewer read |
| 5. representative `Product Operations Manager` JD | unavailable | Would have given quotable requirements; F1 to F6 stay unquoted prose |

## Upgrade menu

- The JD text: F1 to F6 become quoted requirements, JD-tagged questions become `[grounded]`, and any mid-list requirement gets its own question
- Your CV or a few sentences about your work: the evidence column fills, selection scaffolds become story maps, defend-the-number questions attach to your real figures, and the prohibited-claims section is rebuilt
- Who you are meeting and your relationship to them: persona weights stop being flat, and the question order and reverse questions retune
- A name or profile for each interviewer: an interviewer read and a reverse question tied to their path
- The recruiter's prep email: coverage of any pre-declared deliverable, and the loop structure; if your final is several sessions, send the schedule and I will build per-session mini-packs
- Search permission: values cheat sheet from the official page, documented loop structure, and strategy-grounded CO and CASE questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can follow if you want it
- A `tuesday-dossier.md` from an earlier fit analysis: verified evidence, allowed strategies per weak area, and prohibited claims, in place of the locally built list
