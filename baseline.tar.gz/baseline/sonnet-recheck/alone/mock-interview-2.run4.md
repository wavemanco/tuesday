I'll read the reference files the skill requires before building the pack.
Web search was refused, so Atlas Freight itself can't be researched. I'm building the pack from your JD and background only, and I'll mark that in Sources.
Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-2-denied-ff37f64d/57f93f5b-b4a3-4241-9fd1-b7f84df5c200/scratchpad/Atlas_Freight_operations-manager_interview_pack.md.

I built it for a hiring-manager round, since you don't know who is interviewing you. It holds 21 questions across seven interviewer styles. The web search I tried for Atlas Freight was refused, so the pack uses only your JD and background. Nothing in it about the company's values, interview process or strategy is researched, and the Sources section says so.

The pack names B1 as the highest-ROI prep. It's the "you lead 3 supervisors today and this role leads 12 across four sites" question.

Say the word and I'll play the Skeptic on B1, with follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is this a first-round screen, a conversation with your future manager, or a later round? The recruiter's invite or email usually says, and the answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas_Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer and relationship: not known. Built on the assumption of a hiring-manager round, which is a prior and not something read from your loop. Nothing about Atlas Freight was researched (web search was refused), so company claims are absent rather than guessed.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say what you actually did, in your own words, and where a cell says "answer slot", fill it from your real experience or take the plain honest branch.

| Type tag | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy (none in this pack, since no research ran) |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

You said the interview is next week. If you tell me the days or hours you have, I will resize this.

1. B1, aloud, until it is boring. It is the question most likely to be asked in some form.
2. C1 and E1, aloud. Both test the same 40% figure from two directions.
3. B3. Your Power BI answer should take twenty seconds and no more.
4. A1, A2 and A4 as spoken cases, thinking aloud and clarifying before you structure.
5. D1, your ninety-second arc.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift manager over 3 supervisors and "the site's" plan, and shows neither terminals nor more than one site. Words, at their own scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4 sites make a probe on scope likely. If any of your work involved terminal operations as the JD uses the term, or spanned more than one site, say which and what was yours; if none did, say so plainly and stay with the site's plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is the measure in your material; on-time and cost-per-shipment are not in it. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost figures at your site, say which and what you know about how they moved; if you did not, or it was not yours, say so plainly and stay with mis-pick |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your words stay at 3: "I'm currently a senior shift manager over 3 supervisors." The difference to the JD's 12 is the pack's observation, not words for you. Answer slot: if your work has ever covered more supervisors than those 3, say when and how many; if it has not, say so plainly and stay with the current role |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [grounded] | discovery | Your material gives seven years in operations and a current leadership role, and does not show how many of the seven years were spent leading people. Answer slot: if some of the seven years were in roles leading people, say which roles and for how long; if only the current role was, say so plainly and describe that role as it stands |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [grounded] | discovery | The quote touches the tool and does not show reporting built in it. Answer slot: if you built reports in Excel, say what they covered and who used them; if you did not, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote reaches the Six Sigma half in the JD's own terms. Lead with it as it stands, and expect a probe on how it was applied. Your material does not mention Lean by name |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live ops problems from the JD: diagnose on-time, explain cost per shipment, plan a first 30 days | High. A hiring-manager round buys capability and the JD is built around operating metrics | Clarify, then structure, then answer. Say the framework aloud. Challenge one premise politely |
| Skeptic | Probes the span (F1, F3), the leadership years (F4) and the Power BI gap (F6) | High. These are the biggest distances between the JD and your quotes | Rehearse B1 until it is boring. Hold what the quotes carry and put the ramp in future tense |
| Data-Driven Prober | Goes line by line through your 40% figure and asks for on-time and cost numbers | Medium. You gave one headline figure and the JD names two metrics you did not mention | Say how the 40% was counted if you know, and say plainly if you do not. Name the assumption you would defend least before they do |
| Conversational/Rapport | Opens with your journey and asks casually about Lean and data tools | Medium. Most rounds open this way, and "Lean/Six Sigma a plus" is the kind of topic that arrives casually | Prepare the ninety-second arc (D1) and treat casual questions as scored |
| Pressure | Time-boxes you and asks how much of the result was actually you | Low. There is no signal that this loop is a stress format | Hold through two follow-ups, then concede specifically |
| Peer Evaluator | Asks about seams between sites and credit across teams | Low. It rises only if a site peer is on the loop, and I do not know that | Offer seam principles, not claims about a seam you have not seen |
| Values/Behavioral | Scenario prompts mapped to company values | Low. No loop source was read and the generic archetype assumes no values round | Keep two scaffolds ready; no published values were retrieved |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your four terminals has slipped over three weeks. How do you diagnose it, and what do you need to know first?" | CASE | [generic] | Clarify first: how on-time is defined and measured, which lanes and shifts, and what changed. Then segment, choose what data to pull, separate a quick fix from a structural one, and say how you would check findings with the supervisors on the ground. The question needs no claim about your past, so the guidance makes none | JD line on on-time performance (F2) rendered as a live problem; CASE because it scores structure |
| A2 | "Cost-per-shipment is above target at two of the four sites. How do you work out why, and what would you refuse to cut?" | CASE | [generic] | Break cost-per-shipment into its parts and its denominator, compare the two sites against the others, form hypotheses before cutting anything, and name the service level you would protect. The anti-pick, what you would refuse to cut, is the part that shows judgment | JD line on cost-per-shipment (F2); CASE because it asks for reasoning, not history |
| A3 | "Volume surges sharply across all four sites for six weeks. What does your plan cover in the first week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it as a case: demand picture, labor and capacity, handoffs between sites, daily check-ins, escalation triggers. Where it helps, say what you ran at its own scope: "I ran the site's peak-season surge plan two years running." Describe the plan's contents only as far as you can stand behind them | F1's surge-plan quote gives the one story you can attach to this case; CASE because the problem is live, JD because it tests the multi-site scope |
| A4 | "You start with 12 supervisors across four sites and uneven standards. What do your first thirty days look like?" | CASE | [grounded] "currently a senior shift manager over 3 supervisors" | Structure: listen and observe at each site first, agree one set of metric definitions, set a one-to-one rhythm, and pick a single early improvement. If you reference your current team, state it at its size: 3 supervisors. Do not describe it as bigger | F3 is the gap this case probes; CASE because it asks for a plan, not a record |
| A5 | "How would you structure the weekly operations report for four sites? Which numbers, and how do you decide?" | CASE | [grounded] "solid Excel" | Start from the reader and the decisions they make, tie the core numbers to on-time and cost-per-shipment, keep definitions identical across sites, and add exceptions. Name the tool honestly: "solid Excel" is the quote. Answer slot: if you built reports in Excel, say which and for whom; if you did not, say so plainly and answer as a design | F5 and F6 meet here; CASE and JD because the JD names reporting and the question tests how you think about it |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're over 3 supervisors today, and this role leads 12 across four sites. What makes you think you can step up to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **Highest-ROI prep in this pack.** Say the difference yourself before it is pressed: "Right now I'm a senior shift manager over 3 supervisors; this role is 12 across four sites, and that is a bigger span." Hold there through two follow-ups by returning to the sentence, never by adding to it. Answer slot: if your work has ever covered more supervisors or more than one site, say when and what you were responsible for; if not, say so plainly and stay with the current role. Follow-up 1, "what breaks first at 12?": answer as a plan in future tense, naming what you would watch in the first weeks. Follow-up 2, "how would you handle a supervisor at one site who runs behind the others?": a hypothetical, so structure it. Follow-up 3, "what would you want from me in your first ninety days?": name what you would ask for. The limit is named before it is asked, and the concession is stating the span accurately | F3 is the single most predictable objection, and the guidance stays at its quote | 
| B2 | "Your background reads as warehouse and distribution. This job is terminal operations. Where does it translate and where does it not?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the background in those words: "7 years in warehouse and distribution ops." Answer slot: if any of that work involved terminal operations as the JD uses the term, say which part and what was yours; if none did, say so plainly and describe the warehouse and distribution work as it was. Then give a ramp plan in future tense | F1 is where the JD's terminal and multi-site wording presses on the quote; JD because it scores the stated requirement |
| B3 | "The role builds reporting in Excel and Power BI. Where do you stand on Power BI?" | JD | [grounded] "never used Power BI" | Say it plainly and briefly: "I've never used Power BI." Then a plan, never a past: how you would learn it and the timeframe you would set yourself. Excel: "solid Excel" is the quote; answer slot: if you built reports in Excel, say which; if not, say so plainly. Do not describe any reporting you did not build | F6 is a stated gap, so the honest form is short and plan-shaped; F5 supplies the Excel half |
| B4 | "The posting asks for five years of operations leadership. Walk me through the leadership years in your seven." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start from the quotes at their scope: seven years in operations, currently over 3 supervisors. Answer slot: if some of the seven years were in roles leading people, say which roles and for how long; if only the current role was, or none were, say so plainly and describe the current role as it stands | F4 is `low` confidence and `discovery`, which is why this probe is likely; JD because it is a listed requirement |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick the weakness you can speak to honestly, name it first, concede it once, and give a ramp plan. Power BI is the one you have stated: "I've never used Power BI." Calibrated candor beats bluffing a skill the interviewer may personally own | F6 gives a sourced weakness; JD because it asks you to rank the requirements against yourself |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate by 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the figure as you stated it: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F2's headline figure, and the one a prober will test first; EXP because it checks attribution |
| C2 | "Tell me about your green belt certification." | EXP | [grounded] "green belt certified" | Say it as it stands: "green belt certified." Answer slot: if you applied it to the pick-path redesign or anywhere else, say where and how; if it was certification without a project of your own, say so plainly. The JD says Lean/Six Sigma; if you used Lean tools, say which, and if you did not, say so plainly | F7 is the cleanest match to the JD's plus, and the probe will be on how it was applied |
| C3 | "On-time performance and cost-per-shipment are the numbers this role lives by. What have you tracked on those?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked on-time or cost figures at your site, say which and what you know about how they moved; if you did not, or it was not yours, say so plainly and stay with "I cut mis-pick rate 40% by redesigning the pick path." Do not link mis-pick to cost unless you can show the link | F2 is the distance between your measure and the JD's two; JD and EXP both apply, and EXP leads because it tests what you actually tracked |

### D. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A ninety-second arc with only the beats the quotes state: seven years in warehouse and distribution operations, now a senior shift manager over 3 supervisors. Answer slot: why this role and why now, in your own words, since your material does not say | The opener is scored even when it feels casual; F4 supplies the arc |
| D2 | "What are you playing with in Lean or data tools these days?" | JD | [grounded] "green belt certified" | Answer slot: if you are using any Lean or analysis tools now, say what; if not, say so plainly, then say what you would work on first. "Green belt certified" and "solid Excel" are what you can stand behind | F7 and F5 are the JD's plus-skills; JD because the topic is a listed plus |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40% result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold through two follow-ups by returning to the sentence: "I cut mis-pick rate 40% by redesigning the pick path." Concede specifically. Answer slot: if others contributed, say who and what; if it was yours throughout, say so plainly. Never add to the sentence to win the exchange | F2's figure again, from the pressure side; EXP because it tests attribution |
| E2 | "Sixty seconds: why you over a candidate who has already led twelve supervisors?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Pause, restate, then say what you bring in the quotes' own terms. Concede that the other candidate may have the span; do not claim otherwise. Hold your position without becoming defensive | F3 is the gap this pressure aims at; JD because it scores fit to the stated requirement |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When a shipment misses cutoff at one site and the next site picks it up, where is the seam and what happens when we disagree?" | JD | [generic] | Propose principles rather than pretending to know the seam: one definition of on-time, one named owner for each handoff, disagreements settled with data and not blame. Bring what you would give their team, not only what you need | Multi-site scope (F1) from a peer's angle; JD because it tests the stated requirement |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection criteria: pick an occasion where work spanned teams, with a named other party, what each did, and how credit was shared. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "ran the site's peak-season surge plan two years running", or how you would handle it | A persona stem; VAL because it tests behavior, and generic because no values were retrieved |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not fold, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem; generic because no published values were retrieved |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: the metric, the customer need, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem; the customer-versus-metric tension suits a delivery-focused role |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B2, F1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C3 |
| "lead a team of 12 supervisors" | A4, B1, E2 |
| "build reporting in Excel/Power BI" | A5, B3 |
| "5+ years operations leadership required" | B4 |
| "Lean/Six Sigma a plus" | C2, D2 |
| Headline figure on your CV: the 40% | C1, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which is furthest from where you want it?" | It uses the JD's own metric and shows you think in sites, not in one building |
| R2 | "How are the twelve supervisors spread across the sites, and what does the strongest one do that the others could copy?" | It treats the span as a design problem and asks what good already looks like |
| R3 | "What reporting exists today, and what would you want built first?" | It brings the Power BI question into the open on your terms |
| R4 | "What support is there for someone learning your reporting tools in the first months?" | It is honest about the gap and signals you plan to close it |
| R5 | "What does success look like in the first six months?" | It lets you hear the interviewer's real scoring sheet |
| R6 | "What is the hardest part of this job that the posting does not say?" | It invites the candid answer and shows you want the real job |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says a shift manager over 3 supervisors and "the site's" plan. B2's slot asks only whether any work involved terminal operations |
| Led a team of twelve supervisors | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors." B1's slot asks only whether your scope ever went beyond that |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | "I cut mis-pick rate 40% by redesigning the pick path." C3's slot asks only what you tracked |
| Five or more years of operations leadership | Inflated form of F4 | The two F4 quotes at their scope. B4's slot asks only which years involved leading people |
| Built reporting in Excel | Inflated form of F5 | "solid Excel" at its scope. The slots in A5 and B3 ask only what you built, if anything |
| Has used Power BI | Negative you stated, F6 | The plain acknowledgment: "I've never used Power BI." No slot |

## Sources

Provided documents: the JD text and the background summary, both pasted into your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent, all three refused by the host's permission check and none returning a result:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight strategy news terminals" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have named the published values for VAL questions and for a values cheat sheet if a loop source documented a values round. As it stands, G1, G2 and F2 are generic |
| 2. Atlas Freight interview process, operations | unavailable | Would have set the loop structure and the persona weights. They rest on the hiring-manager prior and the generic archetype instead, which assumes no values round |
| 3. Atlas Freight strategy and recent news | unavailable | Would have grounded a CO question and a strategy-based case. The pack has no CO questions |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative operations manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission, or the recruiter's answers on values and loop structure → Sources rows 1 to 3 stop being unavailable; a values cheat sheet if a values round is documented; a CO question grounded in strategy
- Deep research, offered once: up to 6 more searches and 2 more fetches, several more minutes, and it needs the search permission above → a grounding brief, loop reports and recent organization context
- Who you are meeting and whether it is a first or final round → persona weights and bank depth recomputed
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- The recruiter's focus areas or any announced task, such as a presentation → a build section for it
- Your answers to the slots in F1, F2, F3, F4, F5, C1 and C2, sent outside a drill → those rows are regenerated from your own words and the thinnest ones firm up
- A sample of your reporting, the before-and-after sheet behind the 40%, or the green belt project record → F2, F5 and F7 can move from medium or low toward high confidence
- A `tuesday-dossier.md` from the job underwriter → verified evidence and a named top objection in place of the inferred one
- Days or hours of prep time available → the triage resized
