I'll start by reading the skill's reference files.
Web search was refused, so I'm building the pack from your message alone. Anything that would have come from research is labeled `[generic]` or left out.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-3-denied-88d8dad7/776c485c-a10d-4dc6-8ce6-fc0dac4cb705/scratchpad/stripe_product-operations-manager_interview_pack.md`.

I built it with no CV, no job description, no interviewer details and no research. My four web searches were refused, so nothing in it comes from Stripe's own pages. That means the fit snapshot is a worksheet of generic role requirements. The persona weights are flat and the questions are generic. There is no values cheat sheet, and the Stripe-specific question (A3) is homework for you. The pack lists B1, "Which part of this role would you be weakest at on day one?", as your highest-priority rehearsal.

Say the word and I'll play the Skeptic on B1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who is your final round with: a future manager, a peer, a skip-level or a panel? Did the recruiter name any focus areas, a number of sessions or a deliverable? The answer reweights every question bank.
2. Can you paste the job description and/or your CV? If you'd rather not, say so and I'll leave the pack as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer name and relationship: not given. This pack assumes flat persona weights and no CV, JD or research, and says where that shows.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Because no CV was supplied, no cell says what you did. Every question about your past is a selection scaffold that ends in an honest branch. Send a CV and those become story-mapped answers.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company and think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot (worksheet variant)

No CV or background was provided, so every evidence cell reads `none given`. No JD was supplied and the representative-JD search was refused. The requirements below are role-family patterns written as plain prose, labeled `[generic]`. They are not quotes from Stripe's posting. No requirement was identified as a gate, because no posting text exists to show one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or releases across several teams (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is one launch or release where several teams had to be ready together, with your own part named exactly. Selection scaffold: pick an occasion with a named date, the teams involved and a moment something had to be decided; if no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Build and run operating rhythms such as planning, reviews and status reporting (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, with who used it and what changed. Selection scaffold: pick one recurring process, say whether you designed it, inherited it or ran it, and what you would change; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use data to judge product health and guide decisions (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a metric you used to run something, with how it was counted and what it misses. Selection scaffold: pick a metric you can explain end to end; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Align stakeholders and influence without authority (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement between teams, what you did and how the relationship stood afterward. Selection scaffold: pick a case with a named stake and an outcome you can describe accurately; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structure ambiguous problems and build scalable process (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a messy problem you turned into a repeatable process, with the before and after. Selection scaffold: pick one problem that had no owner or no process; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate clearly with senior stakeholders (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a time you briefed or challenged someone senior, and the result. Selection scaffold: pick one occasion; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Understand the company's product domain (role-family pattern, no JD) | none given | none | [generic] | discovery | This is homework, not experience. Read the company's own current public material before the interview. This pack could not research it, so it states nothing about Stripe's products or strategy |

## Persona table

Loop: no loop source was read, and "final round" alone does not establish how many sessions you have or who runs them. The pack falls back to the Generic archetype (screen, hiring manager, panel) with flat weights. No values-style round is detected, so there is no values cheat sheet, and Values gets two questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (rehearsal method) |
|---|---|---|---|
| A. Case/Strategist | Live problems on launches, cadences, metrics | Medium-high. A product operations role is mostly structuring messy cross-team work, so expect at least one live problem | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| B. Skeptic | Probes gaps, motivation, day-one weaknesses | Medium-high. Final rounds usually test remaining doubts, and your gaps are unknown to this pack, so it prepares the universal ones | Rehearse the weakest-point answer until it is boring. Use plain candor plus a ramp plan |
| D. Data-Driven Prober | Pushes on how numbers were counted | Medium. Product operations work is metric-heavy, but no CV figures are known | Know how each figure you cite was counted. Say plainly when you do not know |
| C. Values/Behavioral | Scenario probes on conflict and customers | Medium-low. No loop source documents a values round and no published values are in hand | Pick stories where the hard truth landed. Use "we" for context and "I" for contribution |
| F. Conversational | Casual opener and "what are you learning" | Medium. Almost every conversation starts here, and it is scored | Prepare a 90-second arc. Treat casual questions as scored |
| G. Peer | Seam-splitting, credit, collaboration | Medium-low. It rises sharply if you meet a peer, which you have not said | Offer seam principles, not claimed knowledge of their seam. Frame what you bring |
| E. Pressure | Time-boxed challenge to your motives | Low-medium. It is more likely from a senior interviewer, whose seniority is unknown | Pause, restate, hold through two follow-ups, then concede specifically |

Highest-ROI rehearsal: B1, "Which part of this role would you be weakest at on day one?" It is asked in some form to nearly every candidate. This pack cannot yet name the objection specific to you, because it has no CV. Once it does, B1 and B3 are the first questions to sharpen.

## Question banks

Every question here is `[generic]`. The persona's stem or a generic role problem raises the theme, not a document. No cell says what you did, because nothing was provided to say it from.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out. Engineering says it is on track, support says it is not ready, and sales is already promising customers a date. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: who owns the date, what "ready" means for each team, what is reversible. Then objective, stakeholders, approach (one readiness view with named owners and a go/no-go decision point), metrics, risks. Think aloud. Challenge one premise, such as whether the date is fixed. Makes no claim about your past | Tests F1 and F5 as a live problem. CASE because it scores structure, not history |
| A2 | "Design the operating rhythm for a product organization that ships often. What would you put in place, and what would you refuse to add?" | CASE | [generic] | Clarify scale and what is broken. State two or three principles. Name a minimal set of meetings, artifacts and metrics. Say what you would refuse and why: the anti-pick shows judgment. Makes no claim about your past | Covers F2. The "refuse to add" clause scores judgment, which operations roles are hired for |
| A3 | "Which Stripe product or area would you most like to support, and what do you think its biggest operational challenge is?" | CO | [generic] | Homework. This pack could not research current strategy, so read Stripe's own recent public material before the interview. Pick one area, state what you read, and label anything you are guessing as a guess. Do not assert facts about the company you have not checked | Covers F7. The pack carries no company fact, so it supplies no answer. CO because it scores homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Name the real one in a sentence. Follow with a concrete ramp plan phrased as what you would do, not as something already done. Do not claim you have no weakness. If nothing seems weak, say so plainly and name where you would most want early feedback | This arrives in some form in most final rounds. JD because it scores honest self-assessment against the listed job |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Three beats in your own words: what draws you to the function, why this company (from material you read yourself), why now. Build each beat only from things you actually did or know. If one beat is thin, say so rather than inflating it | The motivation-consistency probe. EXP because the answer must survive follow-ups on your own history |
| B3 | "Tell me about the experience you have that is closest to product operations, and where it falls short." | EXP | [generic] | Selection scaffold: pick the nearest work, describe it at its true scope, say where it stops, and give a ramp plan for the rest. If no such work comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F1 and F5 for transferability. EXP because it scores precise attribution |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a case with a named stake, what you said, and how it landed. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F4 and F6. The theme comes from the persona stem, not from a published Stripe value, which this pack could not fetch |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, what you chose and the cost. The cost is what makes it credible. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Same stem source. VAL because it scores behavior, not opinions |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a result you reported with a number. How was it counted?" | EXP | [generic] | Selection scaffold: pick a figure you can explain end to end: what was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. If no such figure comes to mind, say so, then give the nearest thing your material carries | Covers F3. The defend-the-number rehearsal, with the CV's figures unknown |
| D2 | "Tell me about a metric you have used to run something. What does it fail to capture?" | EXP | [generic] | Name the metric, what it measures, and one honest blind spot. Naming the flaw yourself converts a gotcha into credibility. If none comes to mind, say so plainly, then give the nearest thing your material carries | Covers F3. EXP because the blind spot must be your own knowledge |
| D3 | "An adoption metric dropped 20 percent week on week. Diagnose it." | CASE | [generic] | Clarify the definition and instrumentation before hypotheses. Check data issues, then segment (time, cohort, platform, region), then product or external causes. State what you would check first and why. Makes no claim about your past | Covers F3 as a live diagnosis. CASE because the structure is scored |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over the other finalists?" | EXP | [generic] | Pause, restate the question, then give two reasons that only your own material supports. Avoid claims about the others. If a reason feels thin, say less rather than more | Pressure stem. EXP because it scores what you can actually stand behind |
| E2 | "Take the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Pick one whose attribution you can state precisely. Hold through two follow-ups, then concede specifically what was others' work. Do not fold on the core claim to restore harmony. If no result comes to mind, say so plainly, then give the nearest thing your material carries | Covers attribution honesty. EXP; pressure is the delivery |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc: where you started, the through-line, why this role. This pack cannot write it, because it has no CV. It can be drafted from the sentences you give it | The standard opener, and it sets the interviewer's frame. EXP because it is checked against your CV |
| F2 | "What are you working on or learning at the moment that bears on this role?" | JD | [generic] | Name one real thing and why it matters to the role. If nothing comes to mind, say so plainly and name what you would start learning | Casual, but scored for genuine interest |
| F3 | "What would you want to learn in your first 90 days?" | JD | [generic] | Two or three learning goals, tied to listening before changing. A plan, not a claim about your past | Pairs with B1. JD because it scores ramp thinking |

### G. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Product operations sits between product, engineering and other teams. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know theirs. Say how you would disagree: evidence first, a named decision owner, escalate only after a real attempt. Ask what the seam looks like today | Covers F1 and F4. JD because it scores the role's core interface |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion with shared work and say how credit was handled. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Covers F4. VAL because it scores partnership behavior |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 | A1, B3, G1 |
| F2 | A2 |
| F3 | D1, D2, D3 |
| F4 | C1, C2, G1, G2 |
| F5 | A1, A2, B3 |
| F6 | C1, E1 |
| F7 | A3 |

Mid-list items, such as a named tool or methodology, cannot be covered without the posting. They are listed in the upgrade menu.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like in this role at 90 days, and how will you know?" | Shows you plan to be measured, and surfaces the real bar |
| R2 | "Which parts of product operations here are well established, and which are still being figured out?" | Signals you can work in unfinished territory and shows where you would add value |
| R3 | "Where does this team's remit end and the product, engineering and program teams' begin?" | Tests whether the seam is understood, which is a risk you will own |
| R4 | "What is the hardest thing a recent launch or planning cycle ran into, and what did it change?" | Invites a real story instead of the polished one |
| R5 | "How is the team's work measured, and how do you know a process is helping?" | Shows you think about operations as a product with its own metrics |
| R6 | "What would you want me to know about this role that the posting does not say?" | Hands the interviewer room to name unspoken concerns |
| R7 | "What could a new person do in their first month that would genuinely help your team?" | Use if you meet a peer. A reciprocity question |

None is tied to an interviewer's path, because no interviewer was named.

## Prohibited claims

No entries yet. Your material contains no sentences to inflate, and a requirement no sentence speaks to is an answer slot, not a prohibited claim. This list fills in once a CV arrives. Until then, do not use any answer here to describe your past in more than your own words.

## Sources

Provided documents: your message (company, role, round type). No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Query "Stripe values operating principles users first move with urgency": refused. Would have moved the values cheat sheet and VAL questions tied to published values |
| 2. `Stripe interview process product operations` | unavailable | Query "Stripe interview process product operations manager": refused. Would have moved loop structure and persona weights. Fallback to the Generic archetype, with flat weights |
| 3. `Stripe strategy` / recent news | unavailable | Query "Stripe strategy 2026 annual letter stablecoins agentic commerce": refused. Would have moved CO and CASE questions grounded in strategy. A3 is `[generic]` |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Query "Stripe Product Operations Manager job description responsibilities qualifications": refused. Would have moved the fit snapshot requirement rows, from `[generic]` prose to `[inferred]` quotes |

## Upgrade menu

- The JD text → F1 to F7 become `[grounded]` quoted requirements, any gate (location, authorization, schedule) appears as its own row, and mid-list tools or methods get questions
- Your CV or a few lines of background → the fit snapshot gets verbatim evidence, the Skeptic and Prober banks become story-mapped, the objection specific to you replaces B1 as the named top priority, and the F1 arc can be drafted
- Who you meet and their role (manager, peer, skip-level, panel) → persona weights move off flat, and the reverse questions can be tuned
- Interviewer names → an interviewer read from their public footprint, and a reverse question tied to their path
- The recruiter's prep email → stated focus areas, the session schedule, and any pre-declared deliverable. If your final is several sessions, send the schedule and I can build a mini-pack per session
- Permission to run web search → Stripe's published values, documented loop structure and current strategy replace the `[generic]` rows in the values, CO and persona sections. A deeper pass would add up to 6 more searches and 2 more fetches and takes several more minutes
- A `tuesday-dossier.md` from an earlier evaluation, if you have one → verified evidence and a sharper top-objection pick, never a prerequisite
