I'll read the reference files the skill points to before writing anything.
Both searches were refused, so I'm going ahead without search results. I'm building the pack from what you gave me.
The prep pack for Priya is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-1-denied-c006cd48/c61dd5da-bfb8-4a0f-9c73-be55536a8172/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`.

I built it for one 60-minute peer conversation with Dan. It rests on your JD highlights, your summary of Priya, your description of Dan and your research note. Both web searches (Northwind's values page and Dan's public footprint) were refused, so nothing about Northwind or Dan comes from the web.

The pack has 20 questions, weighted as follows:
- **Data-Driven Prober (5):** Dan's "relentlessly data-driven" self-description puts this first.
- **Peer Evaluator (4):** both of them report to the same VP, so the seam between their teams matters.
- **Case/Strategist (4):** Dan's pricing background tilts the cases toward packaging and discounting.
- **Skeptic (3), Conversational (2), Pressure (2).**

Other sections: a fit snapshot, a reading of Dan, a persona table, a requirement-coverage table, seven reverse questions (one tied to Dan's own career path, one for reciprocity), a prohibited-claims list and sources.

- **Highest-ROI prep:** D1, the "no sales-ops or quota-setting" objection. Rehearse Priya's concession in the words you gave me, then the nearest thing she did have, then a ramp plan.
- **Runner-up:** A1, because a data-driven peer will probe how the ~$400M uplift was counted.
- **Values questions:** the pack has none. A single peer conversation doesn't establish a values round, and I couldn't read Northwind's values page.

Where a probe is likely but your summary doesn't say, the guidance leaves an answer slot for Priya's own answer instead of supplying one. Her answers will turn those slots into real stories.

Say the word and I'll play Dan as the Prober on A1, or as the Skeptic on D1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two answers would change the pack:
1. Has the recruiter said what Dan will focus on, or asked Priya to bring anything? A declared deliverable would add a build section, and a stated focus would reweight the banks.
2. Can you paste the full JD? I'll proceed on the highlights otherwise. The full text would let me check each JD-tagged question against the posting's own wording and add any requirement the highlights left out.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind — her peer; both report to the same VP. **Round:** one 60-minute conversation.

Built on: the JD highlights you pasted (not the full JD), your summary of Priya's background, Dan's profile as you described it, and your research note. No web research was available in this session (see Sources).

## How to use this pack

- **Personas are how a question is asked; types are what it is scoring.** Rehearse both: the same question arrives as a collegial aside, a data challenge, or a time-boxed push.
- **Guidance is scaffolding, not a script.** It is built only from sentences you gave me about Priya. Where a probe is likely and her material does not say, the cell holds an answer slot: a place for her own answer, with an honest second branch. Nothing in a slot is a claim until she says it.
- **Highest-ROI prep: D1.** The most predictable objection is that her background is product strategy and ops, with no sales-ops or quota-setting, for a role that owns land, adopt, expand and renew. It gets the deepest rehearsal (most follow-ups, exact concession wording, the limit named before Dan asks). The runner-up is A1, because a self-described data-driven peer will take the ~$400M figure apart.

| Type | What it is scoring |
|---|---|
| VAL | Past behavior against the company's published values. None in this pack: no values-style round is established for a single peer conversation, and no values page could be read |
| EXP | Whether CV claims survive scrutiny and attribution is precise |
| JD | The stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge, thinking at Northwind's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

Requirements are quoted from the JD highlights in your message. Evidence is quoted from your message. Confidence and gap type are defined in the suite's evidence conventions; confidence grades Priya's evidence, provenance grades what this pack wrote on top of it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says strategy consulting, then strategy and ops, and the words stay at that scope: two years in strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Answer slot: the JD's GTM line makes a probe likely on how close that work came to customers; if any of it did, say how and what you decided, in your own words; if none did, say so plainly and stay with strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | discovery | The sentence touches revenue growth but does not show how the opportunity was found or where in a customer lifecycle it sat. Answer slot: the JD's whitespace line makes a probe on how the opportunity was identified likely; if you found it through analysis, say what you looked at; if it came from elsewhere, or not through analysis, say so plainly and stay with the proposal. The figure also raises the four defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | No gap on the tools, but a self-description with nothing inspected behind it; a query or a dashboard Priya can show would raise it. Lead with the sentence in its own terms: skilled in SQL and Tableau. Expect a probe on one analysis she ran herself |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in carrier negotiations, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a probe on what your part was beyond building the model; if there was more, say what and how you decided; if there was not, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only it: "I set annual volume targets, with consensus across orgs." Add no pushback, negotiation or escalation the sentence does not state |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | discovery | The sentence names neither a tool nor a task, so it stays a lead until she fills it in. Derived from the JD's plus-skill line. Answer slot: name one tool and one task you actually used it for; if the use is lighter than daily, or narrower, say so plainly |
| F7 | Sales-ops and quota-setting fluency — not in the JD highlights; the pack's reading of what a role owning land, adopt, expand and renew expects (plain prose, unquoted) | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | A gap Priya has stated, so the acknowledgment may be given back in her terms: "I don't have classic sales-ops or quota-setting experience." Then how she would learn it, said as a plan and never as a past. Nothing added to make it smaller, and F5's targets are never renamed quotas |

## Reading the interviewer

Public professional footprint only; all of it comes from your description, since search was unavailable.

| Item | Reading | Provenance |
|---|---|---|
| Career pattern | "pricing and monetization roles", with "one early-stage-startup chapter" — your message | [grounded] |
| Self-description | "relentlessly data-driven" — your message | [grounded] |
| Relationship | Peer, same VP — your message | [grounded] |
| Implication 1 | Expect every number to be probed to its assumptions; lead each figure with how it was counted, before he asks. Drives bank A | [inferred] |
| Implication 2 | Pricing and monetization is his native vocabulary, so frame cases in packaging, discounting and attach terms. Drives bank C | [inferred] |
| Implication 3 | A peer is pricing what the hire adds to or takes from his own load; keep the reciprocity question (R2) ready. Drives bank B | [generic] |
| Implication 4 | A startup chapter can bring speed and scrappiness probes against big-company pace; no row of the snapshot carries Priya's side of a startup story, so it is not offered as a shared jump | [inferred] |
| Mirror opportunity | Shared vocabulary of revenue modeling: his pricing and monetization roles against F4's sentence, "built a partner-level revenue model used in carrier negotiations". Offer it as vocabulary, not as a shared career jump | [inferred] |
| Boundary | Shared background of any personal kind is not used as a strategy | [generic] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Reads the numbers line by line; follow-ups go two levels deep on inputs and assumptions | Highest. Peer prior (Prober beside Peer Evaluator), raised by Dan's self-description as "relentlessly data-driven". 5 questions | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption first |
| B. Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement | High. Peer prior; same VP means he is judging how you would sit beside him. 4 questions | Reciprocity framing; propose seam principles, not a map you cannot know; a disagreement story that shows spine and tact |
| C. Case/Strategist | Live problems on the actual roadmap, pricing-flavored | High. His pricing and monetization spine tilts cases toward packaging and unit economics, and your research note gives live material (enterprise expansion, Compass, profitability, bundling). 4 questions | Clarify, objective, segment by land/adopt/expand/renew, approach, metrics, risks; challenge one premise respectfully |
| D. Skeptic | Quiet, persistent probing of the background gap and motivation | Medium. The snapshot's biggest gap is F7, and a peer would be the one to absorb the ramp cost. 3 questions | Rehearse D1 until it is boring; bridge only from adjacent sentences; a concrete ramp plan |
| E. Conversational | Chatty opener, casual questions that are still scored | Medium-low. A 60-minute conversation opens with the journey, and the AI plus-skill tends to arrive casually. 2 questions | A 90-second arc; treat the casual AI question as scored |
| F. Pressure | Time-boxed or devil's-advocate challenges | Low. Not a peer prior, but a data-driven peer can turn collegial pressure on attribution. 2 questions | Pause, restate, hold through two follow-ups, then concede specifically |
| Values/Behavioral | Not included | No values-style round is established for a single peer conversation, so the bank is dropped rather than padded | — |

## Question banks

Provenance sits before the guidance and carries every candidate sentence the guidance rests on. Answer slots are instructions for the interview, not questions for this conversation.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR figure on your CV — walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say it at the sentence's scope: you proposed the change, and it was credited with a ~$400M ARR uplift. Keep "proposed" and "credited". Answer slot: say how the figure was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly, and naming the weak spot before Dan does is the move. Never describe a method you cannot repeat under a second question | F2 holds the only quantified claim, and a self-described data-driven peer is the likeliest to take it apart. EXP because it tests counting and attribution; Prober because the follow-ups go two levels deep |
| A2 | "Walk me through the partner-level revenue model you built for the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe it in the sentence's terms: a partner-level revenue model, used in carrier negotiations. Answer slot: Dan will likely probe where the model was weakest; name the assumption you would defend least, in your own words, and if you do not know how it was validated, say so plainly. Expect a probe on what your part was beyond building it; if there was more, say what and how you decided, and if there was not, say so plainly and stay with the model | F4 is the evidence for the partner requirement and is nearly all model, so Dan will test its depth. EXP because it checks what was hers; the weakest-assumption move is the Prober bar |
| A3 | "Tell me about the last analysis you ran end to end yourself, in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | The sentence carries the tool claim only: skilled in SQL and Tableau. Selection scaffold: pick one analysis where you wrote the queries or built the view yourself, and tell it as the question you were answering, the data you used, what you found, and what happened next. Answer slot: if someone else pulled the data or built the view, say so plainly and say which part was yours. If no such analysis comes to mind, say so plainly, then offer to walk Dan through how you would run one | F3 is a requirement with nothing inspected behind it, and the JD says independent. JD because it scores the listed requirement; an open prompt so it supplies no event |
| A4 | "A product line's renewal rate is flat but expansion revenue fell. What would you pull first, and what would you want defined before you pull it?" | CASE | [generic] | No past is claimed. Clarify first: what counts as expansion, which cohort, which period, and whether the fall is volume or price. Then segment by land, adopt, expand and renew, say which data you would want at each stage, and what result would change your view. Challenge one premise out loud, such as whether the two metrics are even measured the same way. Think aloud so Dan can follow the SQL logic | A data-driven peer will want to see how she thinks in the data, not only how she describes it. CASE because it is a live diagnosis; it also covers the whitespace requirement in F2 from the analysis side |
| A5 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Tell the beats the sentence states: annual volume targets, set, with consensus across orgs. Answer slot: Dan will likely probe what the targets were based on and whether the orgs disagreed; say what they were based on if you know, and if the orgs disagreed say what happened and what part was yours; if they did not, or you were not the one who resolved it, say so plainly. If Dan says "so you set quotas", answer with F7's plain acknowledgment and the targets at their own scope, and do not agree to the word | F5 is also where the quota-setting gap in F7 will first be pressed, in Prober form. EXP because it tests what was hers; it sits in bank A because the probe is about inputs |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where do you see the seam between your work and mine, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of a map you cannot know: who owns which data, who decides on a call that crosses both teams, and how a disagreement gets surfaced early. Say you would ask Dan where he sees the seam before assuming. For disagreement, say what you would do first (bring the numbers, agree on the decision owner, escalate to the shared VP only after both views are written down). Ask him what he needs from you | Same VP means the seam is the question. JD because it scores the cross-functional requirement in F5; `[generic]` because it is a pattern, not a fact about Northwind's org |
| B2 | "Tell me about a time you got several orgs behind a number or a plan, and someone pushed back." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on the sentence: annual volume targets, set, with consensus across orgs. Tell those beats in your own words. Answer slot: the pushback is Dan's premise, not the sentence's; if someone did push back, say who, what they wanted and what you did; if no one did, or the consensus came without a hard moment, say so plainly and describe how the consensus was reached | F5 is the only influence evidence, so this is the story he will ask for. An open prompt: its theme comes from the JD's influence line and the Peer stem, and the pushback is held as a slot, not supplied |
| B3 | "How do you handle credit when the work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer the principle first: name your part and name the others' parts, in the specific verbs of the work. Then the sentence at its scope: you proposed the change; it was credited with an uplift. Answer slot: if others carried it forward, say what they did; if you do not know who carried it, say so plainly. Never upgrade "proposed" | The peer credit probe returns the F2 attribution objection in collegial packaging. EXP because it tests attribution honesty; Peer because it is about sharing credit with equals |
| B4 | "The role calls for partner-motion design experience. What partner work have you done, and what would you need from my team to do it here?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold at the sentence: you built a partner-level revenue model that was used in carrier negotiations. Answer slot: if your part went beyond the model, say what and how you decided; if it did not, say so plainly and stay with the model. For the second half, ask for inputs and decision rights rather than assuming them: what Dan's team already knows about partners, and who decides when a partner term touches pricing. Offer in return what you can build for his team | JD names this as required, and F4 is only adjacent. JD because it scores the stated requirement; the reciprocity half is the Peer bar |

### C. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a competing data-infrastructure product into its suite. How does that change land and expand for one of our new lines?" | CASE | [grounded] research note: bundling by a much larger platform vendor is the main competitive threat | Clarify first: which line, which segment, and whether the bundle is free, discounted or priced separately. Then segment by land, adopt, expand and renew and say where the bundle bites hardest. Approach: a packaging or pricing response, a differentiation response, a partner response, and what you would test first. Metrics: win rate against the bundle, discount depth, expansion rate. Challenge one premise, such as whether the bundle is truly substitutable for the use case. Use Dan's pricing language; state a view and its risk | The competitive threat in your note is the likeliest live case, and Dan's pricing spine makes it native ground. CASE with CO content, because it tests Northwind's own strategic frame |
| C2 | "Compass, our AI copilot, is one of the company's stated priorities. What do you need to know first to think about its adoption and expansion?" | CO | [grounded] research note: an AI copilot launch ('Compass') is a stated priority | Clarify before opining: is it a standalone product or an add-on, who buys it and who uses it, what adoption means for it, and how it ties to the enterprise expansion priority. Then offer a first hypothesis about where adoption could stall, flagged as a hypothesis. Do not claim Compass is one of the two lines in the JD; that is not in your material. Ask what Dan's team already measures | CO because it tests current strategy; the AI plus in the JD makes Compass a likely thread. F6 is the only AI evidence, and this question deliberately asks no history of it |
| C3 | "Profitability and enterprise expansion are both priorities. Where do they pull against each other in a GTM plan, and where do you land?" | CO | [grounded] research note: enterprise expansion and reaching profitability are stated priorities | Name the tension in concrete terms: cost to win and serve larger accounts, discount depth, payback time, and what you would stop doing. Take a position and say what data would change it. A pricing-minded peer will test whether you land somewhere; say what you would give up. Avoid facts about Northwind's margins; you do not have them | Two of the three stated priorities collide here, and a monetization-spine peer cares about the trade-off. CO because it needs the priorities, with CASE reasoning |
| C4 | "You would own GTM strategy for two new product lines at once. How would you decide where to spend your first 90 days?" | JD | [grounded] "own GTM strategy for two new product lines" — JD highlights | A plan, not a past. Clarify what stage each line is in and what is already known. Prioritize by size of the whitespace, strength of the evidence and cost of acting, and say which one thing you would produce first. Name where you would sit with Dan's team in week one. Say what you would not do in 90 days | F1 is the JD headline and the one requirement with the widest gap in the snapshot. JD because it scores the stated responsibility; CASE delivery |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background is product strategy and ops at a consumer-tech company, and there's no sales-ops or quota-setting in it. In a role that owns land, adopt, expand and renew, where does that hurt you on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "set annual volume targets with cross-org consensus" and "skilled in SQL/Tableau" | **Highest-ROI rehearsal.** Structure: (1) Concede first, in the stated words: "I don't have classic sales-ops or quota-setting experience." Name the limit before he does. (2) Nearest thing, at each sentence's own scope: you set annual volume targets with consensus across orgs; you are skilled in SQL and Tableau; do not call the targets quotas. (3) A ramp plan in the future tense: what you would learn first, from whom, and what you would ask Dan to walk you through. Follow-ups to rehearse. FU1 "Targets aren't quotas": agree, restate the sentence, add nothing. FU2 "So I'd spend my time teaching you": say what you would bring to his team and what you would take off it, as a plan. FU3 "Why not hire someone from a SaaS sales strategy seat": concede the gap again, specifically, and do not claim to be better; say what you offer, no more than the sentences carry. Hold the concession through all three without adding experience | F7 is the biggest gap and Dan is the peer who would absorb the ramp. JD because it scores a requirement the role implies; Skeptic because the probe presses the gap. The deepest rehearsal: most follow-ups, exact concession wording, limit named before it is asked for |
| D2 | "Why leave a large consumer-tech company after nine years for a 3,000-person B2B data company?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Selection scaffold for the motivation: two reasons that are yours, one about the role (in the JD's own words) and one about the move away; a reason that survives the follow-up "and what would make you leave here". Answer slot: if there was a specific moment or conversation that tipped it, say so in your own words; if there was not, say so plainly and give the reasons you hold. Do not invent a push or pull | Motivation consistency is what the Skeptic scores, and the tenure in F1 invites the question. EXP because the answer is about her own path |
| D3 | "Your biggest number came from a store-surface change. Finding whitespace across land, adopt, expand and renew is different work. Why would your approach carry over, and how did you find the opportunity behind that change?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the proposal at its scope. Pack observation, not words for you: your material shows a store-surface proposal, not expansion or renewal work. Answer slot: if you found the opportunity through analysis, say what you looked at; if it came from elsewhere, or not through analysis, say so plainly and stay with the proposal. For transfer, give a plan in the future tense: the first cut of customer data you would look at in an enterprise base and what would tell you it was worth pursuing. Do not claim the two kinds of work are the same | F2 is the requirement's only evidence and the Skeptic will separate the two kinds of work. JD because it scores the whitespace line; the how-found half is the discovery slot |

### E. Conversational / Rapport Builder (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey: consulting, then nine years in consumer tech, now here." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" and "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc on the beats the first sentence states: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Mention the three pieces of work in your own words, each at its sentence's scope: the revenue model used in carrier negotiations, the annual volume targets set with consensus across orgs, the proposal credited with the uplift. Close on why this role; answer slot: your reason, in your own words, and if you do not have a sharp one yet, say what you are weighing | The opener is scored. EXP because it is the CV spoken aloud; Conversational because the register is casual |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | The sentence is thin, so build the answer from your own detail. Answer slot: name one tool and one thing you used it for, and say whether you built it or used it; if your use is lighter than daily, or narrower, say so plainly. Do not suggest you have built AI products. Link it only if true, to what a copilot launch like Compass would need from GTM | F6 is a plus-skill asked casually and still scored. JD because it scores the plus line; the label is `[inferred]` because the sentence is low-confidence |

### F. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That $400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, then hold at the sentence: "I proposed the change; it was credited with a ~$400M ARR uplift." FU1 "So you didn't build it": hold, return to "proposed", add no role. FU2 "Credited by whom": answer slot: if you know who credited it and how, say; if you do not know, say so plainly. Concede specifically what you do not know about counting. Never fold on "proposed" and never extend it to "drove" | F2 is the figure most likely to be pushed. EXP because it tests attribution; Pressure because the bar is hold-then-concede, not content |
| F2 | "Sixty seconds: why you over a candidate who has run quota-carrying sales strategy?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "skilled in SQL/Tableau" and "set annual volume targets with cross-org consensus" | Pause, then three beats: concede the gap in the stated words, offer the two sentences at their scope (skilled in SQL and Tableau; set annual volume targets with consensus across orgs), and say what you would do first as a plan. Hold through two follow-ups without claiming to be better than the other candidate or adding experience. A concession said calmly is the point | A time-boxed form of D1, because a peer may rehearse the same objection under pressure. JD because it scores fit to the role; Pressure for the format |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C4, C1, C2, C3 |
| "identify whitespace across land/adopt/expand/renew" | D3, A4, C1 |
| "run independent analysis in SQL and Tableau" | A3, A4 |
| "partner-motion design experience required" | B4, A2 |
| "strong cross-functional influence" | B1, B2, B3, A5 |
| "AI experience a plus" | E2, C2 |
| Sales-ops and quota-setting (not a JD line; the pack's reading) | D1, F2, A5 |
| Your research note's priorities and threat: enterprise expansion, Compass, profitability, bundling | C1, C2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization roles and one early-stage company. What draws that background into sales strategy, and what did the earlier chapters change about how you work?" | Tied to Dan's own path. Turns an interrogation into a peer conversation and shows she read him, not just the company |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it answers his unspoken one, whether the hire adds to or takes from his load |
| R3 | "For the two new lines, which GTM decisions sit with your team today and which are still open?" | Probes the seam from B1 with a concrete line; shows she is thinking about decision rights |
| R4 | "How is the bundling threat showing up in your pipeline today, and which numbers do you watch for it?" | A data-driven peer will answer in numbers, and it signals that she took the competitive threat seriously |
| R5 | "How is success for Compass being defined: adoption, expansion, or something else?" | Ties to a stated priority and to the AI plus; reveals what the role will be measured on |
| R6 | "What would good look like for this role at six months, in numbers you would track?" | Speaks Dan's language and surfaces the scoreboard before she is on it |
| R7 | "Where would you most want this role to disagree with you?" | Shows spine and tact for a peer relationship, and invites the seam conversation directly |

## Prohibited claims

Built locally from the fit snapshot, before the banks. Nothing in the pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed or owned a partner motion | Inflated form of F4 | F4's sentence at its own scope. The limit is the pack's observation: the material says a revenue model used in carrier negotiations. B4 and A2 keep their slots inside the model |
| Has set quotas, or has sales-ops experience | Negative Priya stated, F7; also the inflated form of F5's targets | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot. F5's targets stay targets |
| Drove or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's sentence at its own scope: proposed, credited with. A1 and F1 slots ask only how it was counted, what it is sensitive to, the weakest assumption and which part was hers |
| Ran go-to-market for a product launch | Inflated form of F1 | F1's sentence at its own scope: strategy consulting, then product strategy and ops. The limit is the pack's observation, not words for her |
| Built or shipped AI products | Inflated form of F6 | The sentence at its own scope, and only once E2's slot confirms what it covers. F6 is low confidence and stays a lead |

## Sources

**Provided documents:** your message (JD highlights, Priya's background summary, Dan's profile as described, your research note on Northwind's priorities and competitive threat). The full JD text was not supplied; JD-derived rows rest on the highlights.

**Searches sent (both refused; nothing came back):**
- "Northwind Data B2B data infrastructure company values" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The search was refused. It would have supplied published value names to theme VAL questions; no values-style round is established, so nothing else would have moved |
| 2. Northwind interview process, GTM strategy | skipped | Your words fix the loop (one 60-minute peer conversation with Dan), so persona weights and structure are set |
| 3. Northwind strategy and recent news | skipped | Your research note supplies the priorities and the competitive threat the CO and CASE questions use |
| 4. Dan Kovac, Northwind Data | unavailable | The search was refused. It would have added talks or writing to the interviewer read and a sharper reverse question; the read uses only your description |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six JD rows in the snapshot get checked against the posting's own wording, and any mid-list requirement missing from the highlights gets a question
- Anything the recruiter said about what Dan will focus on or whether to bring something → persona weights reset and a build section if a deliverable was declared
- Search access on this session → rerun targets 1 and 4: Northwind's published values and Dan's public talks and writing, for a sharper interviewer read and reverse question R1
- The document behind the ~$400M attribution (the finance or launch readout, whatever your field calls it) → F2 moves from medium toward high and A1 and F1 gain exact language
- A SQL query or Tableau view Priya can show → F3 moves toward high and A3 gets a real story
- Priya's answers to the answer slots in F1, F2, F4, F5 and F6 → those rows get quoted evidence and the banks regenerate with story maps instead of slots
- A tuesday-dossier.md with verified evidence and a prohibited-claims list → would replace the locally built list and tighten the objection ranking
