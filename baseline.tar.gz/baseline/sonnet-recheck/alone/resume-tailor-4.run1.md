I'll read the reference files the skill points to before building the ledger.
The keyword theory is only partly supported, and the bigger problem is a content gap that no wording change can fix. Nothing below is applied, and every row is `pending your approval`.

**On the premise.** I can't tell from here why you were rejected. The one study I can cite is a vendor's interviews with 25 US recruiters, which its own authors call themes, not representative statistics. In it, content-based auto-rejection was rare: "AI/content auto-rejection configured: 8% of recruiters." (cite C25). What did reject without a person was the application form: "When automated filters are used, they're almost always knockout questions" (cite C26). Match scores mostly set the review order: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). That source speaks of scores, not keywords, so a link to keywords is my inference. This JD lists about 16 technologies and your resume evidences few of them. A low rank or a human "no" on content is at least as likely as a parser silently binning you. This job may also be a stretch right now. Whether to keep applying to roles like it is job-underwriter's question, not this skill's.

## Edit ledger (proposed, `pending your approval`)

I only have your summary, not the PDF, so "Current line" is your own sentence. Positions are proposals, and I assumed the Jenkins and Kubernetes lines currently sit lower.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, including "never went to production", moved to the second bullet)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E3 | Skills | "Bash and Python scripting" | "Python scripting, Bash scripting" | `split` | "Bash and Python scripting" | `[grounded]` your message | pending your approval |
| E4 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | Add beside Docker: "Kubernetes (proof-of-concept, two months, last year; not in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |

The ledger is short because the missing keywords are mostly missing experience, and rewording can't supply that. E4 keeps the full qualifier on purpose, since a tool listed bare would read as a tool owned.

## Coverage map

The JD doesn't rank its requirements. The priorities are my reading, weighted by the duty line, "You will own platform reliability and developer experience."

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | `surfaced_by_edit` | E2, E4. Proof-of-concept level only; nothing in production | `[grounded]` your PoC sentence; `[inferred]` priority |
| 2 | AWS EKS | must-have | `not_evidenced` | Your AWS list is EC2, S3, RDS, IAM; EKS isn't in it. See C1 | `[grounded]`; `[inferred]` priority |
| 3 | Terraform | must-have | `not_evidenced` | Ansible is on the resume, but it's a different kind of tool. See named absences | `[grounded]`; `[inferred]` priority |
| 4 | CI/CD pipelines | must-have | `surfaced_by_edit` | E1. Your sentence says "deploy pipeline" | `[grounded]`; `[inferred]` priority |
| 5 | GitLab CI | important | `not_evidenced` | Jenkins only. See named absences | `[grounded]`; `[inferred]` priority |
| 6 | Python | important | `surfaced_by_edit` | E3 | `[grounded]`; `[inferred]` priority |
| 7 | Prometheus, Grafana, observability | important | `not_evidenced` | CloudWatch is on the resume. See C2 | `[grounded]`; `[inferred]` priority |
| 8 | SRE practices; owning platform reliability | important | `not_evidenced` | See C2 | `[grounded]`; `[inferred]` priority |
| 9 | Developer experience | important | `not_evidenced` | See C3 | `[grounded]`; `[inferred]` priority |
| 10 | Helm, ArgoCD, GitOps | important | `not_evidenced` | Possibly inside the PoC. See C1 | `[grounded]`; `[inferred]` priority |
| 11 | Istio, service mesh | preferred | `not_evidenced` | See named absences | `[grounded]`; `[inferred]` priority |
| 12 | Vault | preferred | `not_evidenced` | IAM isn't secrets management. See named absences | `[grounded]`; `[inferred]` priority |
| 13 | Go | preferred | `not_evidenced` | See named absences | `[grounded]`; `[inferred]` priority |

## Gap handling: recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | EKS, Helm, ArgoCD, GitOps | must-have | One Kubernetes proof-of-concept, two months, never in production. It doesn't say where it ran or what it used. | Kubernetes, EKS and Helm are the JD's core terms. Their absence is what a keyword match would show. | Which platform it ran on (EKS or other); Helm charts you wrote or reused; a Git-driven deploy you tried | PoC write-up, manifests or charts, repo, demo notes | `[grounded]` the PoC sentence; `[generic]` the JD's emphasis on its first-listed terms |
| C2 | Observability, SRE practices, owning reliability | important | CloudWatch for monitoring, and about 30 Jenkins jobs maintained. Nothing on alerting, incidents or on-call. | The role is framed as owning reliability. A reader will look for evidence of it. | CloudWatch alarms or dashboards you built; on-call or incident work; post-incident writeups; uptime or latency targets | Alarm configs, dashboard screenshots, runbooks, incident notes | `[grounded]` your CloudWatch and Jenkins sentences; `[generic]` how reliability-owning roles are read |
| C3 | Developer experience; CI side of CI/CD | important | A deploy pipeline you built. It doesn't say who uses it, or whether it builds and tests code as well as deploys. | The JD names developer experience as half the job. | Teams that deploy through your pipeline; build or test stages; changes that made deploys faster for developers | Pipeline definition, a Jenkinsfile, team count, an internal doc | `[grounded]` the pipeline sentence; `[generic]` how developer-facing roles are read |

## Gap handling: named absences

- **Terraform:** you have Ansible but no Terraform, and they aren't the same kind of tool. To close it, write and apply a small Terraform setup (for example a VPC plus an EKS cluster) in a personal AWS account and put the repo on the resume. That takes weeks, not hours. For this role it's worth closing, because Terraform is a must-have.
- **GitLab CI:** you have Jenkins only. To close it, build one real pipeline in GitLab CI, even on a side project. Without that, it stays a gap.
- **Go:** not evidenced anywhere. It's listed last and Python is also named, so I'd leave it unless you've written any. Closing it means a small Go project.
- **Istio and service mesh:** nothing to pull from. Installing it in a PoC cluster would give you a truthful line. For this application I'd leave it.
- **Vault:** nothing to pull from. Running Vault in a test cluster is a small, closable project, but it isn't worth doing for this role alone.

## Not written, and why

- "Kubernetes experience" or "production Kubernetes": the PoC never went to production.
- "CI/CD pipeline": you wrote "deploy pipeline", and the CI half isn't stated. C3 asks about it.
- "Infrastructure as code": Ansible for config management is a different kind of work, and Terraform isn't evidenced.
- "Observability", "Prometheus" or "Grafana": you have CloudWatch, which is a different tool and a different kind of work.
- "EKS", "Helm", "GitOps" or "ArgoCD": nothing says the PoC used them. C1 asks.
- "Owned platform reliability" or "SRE": maintaining about 30 Jenkins jobs is maintenance of a pipeline, not ownership of reliability.
- "Improved developer experience": the pipeline sentence says nothing about who used it or what changed for them.

## Parse-safety check

I can't open your PDF. Below is what I can tell from your description, and what I couldn't check.

| Check | What breaks | What it costs | Your file |
|---|---|---|---|
| Multi-column layout | Parsers read linearly and can interleave the columns | Text mixes together; dates can detach from the roles they belong to | Risk: you described it as two-column |
| Images and icons for skills | Icons can render as garbage characters or be skipped | Any information carried only by an icon is absent | Risk: depends on whether each skill's name is also text |
| Contact details in the header | Headers can be discarded as page furniture | You could become unreachable | Risk: depends on whether Canva made it a true header or ordinary page content, which I can't tell |
| Text boxes, headings, hidden text | Varies | Varies | Not checked: no file |

If you copy the text out of the PDF into a plain text editor, the order and any missing lines will show you what a parser sees.

## Upgrade menu

- **The PDF itself:** I could run the parse-safety check properly and replace my paraphrased "Current line" cells with your exact lines.
- **Older resume versions:** these often hold lines the current one dropped, such as Terraform, Helm or monitoring work.
- **PoC artifacts (write-up, manifests, repo):** these could turn C1 into rows that carry `[grounded]` evidence.
- **Answers to C1–C3:** these are the most valuable input, because they can turn `not_evidenced` rows into real ones.

C1 — What platform did the Kubernetes proof-of-concept run on, and did it use Helm, ArgoCD or anything else from the JD?
C2 — Have you built CloudWatch alarms or dashboards, carried on-call, or worked an incident that anyone else would remember?
C3 — Who deploys through your Jenkins pipeline (how many people or teams), and does it also build and test, or only deploy?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.