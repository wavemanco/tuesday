I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**No, this posting isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Base pay $70–85k)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO/content), R7 (Brand, PR, partnerships, sales ops)
- `important`: unclear: R8 (Team of one to start)

R3, R4 and R5 are the substance you match. R1 and R2 fail whatever the substance.

**Opportunity ledger.** The mandate is bundled and thinly resourced (RR3, RR4), with always-on expectations (RR5) and no success definition (RR6). It's priced below your floor (RR2) and tied to an office you can't take (RR1). Its one plain virtue is that it states its terms openly (RR9). That is probably the "off" feeling, and it holds up.

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days a week), R2 (Compensation: $70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting would have to allow remote work from Portland and offer a base of at least $150k. No application wording or positioning closes either gap. Only the employer changing the terms, or you changing a constraint, does.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one". These are the posting's own claims, and the employer is not yet verified (RR8) | `[grounded]` JD header, as the posting's claim |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships and sales ops, which is seven functions in one seat | `[grounded]` JD |
| Reporting line | The CEO, with a dotted line to the board | `[grounded]` JD |
| Team and resources | "A team of one to start". No budget, headcount plan or timeline is stated | `[grounded]` JD, for the quote and the silence |
| Working pattern | On-site in Austin five days a week, "no exceptions", plus "evenings and weekends when it matters" | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside", with no percentage, vesting or strike given | `[grounded]` JD |
| First-year outcomes | None stated. "Success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | The title and "8+ years growth leadership" signal a head-of-function mandate. The "team of one" and the pay point to hands-on execution across all seven functions | `[inferred]` from the JD's title and years requirement against its resourcing and pay language |
| Market calibration | Not established. The role-family sweep did not run, so I'm stating no market band and not filling one in from memory | `[generic]` no band given. See the Research tier line below |
| Unknowns | Whether Novaline exists as described, whether the posting is live on its own site, paid budget, equity terms, and what "success" means | `[grounded]` JD silence |
| Contradictions | Within the JD: "8+ years growth leadership" sits beside "a team of one", so you would be a leader with no one to lead. The JD was not checked against a careers page | `[inferred]` from the two JD phrases |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin office 5 days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint, which is specific and confirmed. The fit is failed because the posting requires daily on-site presence and rules out exceptions | `[grounded]` JD quote and your statement | None. Only changed terms resolve it |
| R2 | Base pay $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The fit is failed because the top of the posted band is $65k under your floor | `[grounded]` JD quote, your statement, and the arithmetic | None. Only changed terms resolve it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth, as growth lead and then Head of Growth at two B2C subscription companies. That clears the number on its face. How many of the 9 years were in a lead or head title isn't stated. Intake prose is self-report, so `medium` is the ceiling and an interviewer would probe the split | `[grounded]` your stated background | Only if you proceed: confirm the year you first held a lead title |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid, with budget control, while scaling one company from $8M to $40M ARR over three years. Channel mix and spend levels aren't stated | `[grounded]` your stated background | Only if you proceed: a sanitized channel and budget report would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, SQL and GA4. There's no inspectable artifact yet | `[grounded]` your stated background | Only if you proceed: a sanitized lifecycle program summary would raise it to `high` |
| R6 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention SEO or content. SEO and content are often a separate specialization from paid and lifecycle, so silence isn't proof of absence | `[grounded]` silence in your stated background; `[generic]` for the specialization pattern | See G1 |
| R7 | Brand, PR, partnerships, sales ops | must_have | unclear | none | discovery | Your background doesn't mention any of the four. This is a bundle of distinct functions, and one `unclear` covers all four because nothing is stated for any of them | `[grounded]` silence in your stated background | See G2 |
| R8 | Operating as a team of one to start | important | unclear | low | discovery | You built and managed teams of 3–7, which is the opposite of the posted setup. Hands-on solo execution is plausible at the earlier lead stage but unconfirmed | `[inferred]` from team-building against the "team of one" language | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | No mention of SEO or content work in your background | A `must_have` row at `unclear`. It can't move the status while R1 and R2 stand | Owning a content calendar or organic channel targets; managing an SEO agency against traffic or revenue goals; owning landing-page or content experiments | A channel report showing organic or content-attributed revenue | `[grounded]` silence in your stated background; `[inferred]` that it can't move the status, from R1 and R2 |
| G2 | Brand, PR, partnerships, sales ops (R7, must_have) | discovery | No mention of any of the four | A `must_have` row at `unclear`. Same limit as G1 | Running affiliate or co-marketing deals; owning a brand refresh or press launch; building CRM-to-sales handoffs or lead routing | A partnership agreement, a press placement list, a lead-routing spec | `[grounded]` silence in your stated background; `[inferred]` that it can't move the status |
| G3 | Solo hands-on execution (R8, important) | discovery | Team-building is evidenced, but hands-on solo work isn't | An `important` row at `unclear`. It matters only if you proceed | The period before your teams existed, when you ran campaigns, email and analytics yourself | A before-the-team campaign report or dashboard | `[grounded]` your stated background; `[inferred]` that the pre-team period may count |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your constraint (see R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting's own terms rule out a Portland-based remote hire outright | `[grounded]` JD quote against your stated constraint | Is there any remote or hybrid component to this role, now or planned? | confirmed |
| RR2 | Posted pay is below your floor (see R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The top of the band is $65k under your floor, and equity is unquantified. No market band was established, so I make no claim about the market | `[grounded]` JD quote and arithmetic; `[generic]` for the absence of a band | What is the full compensation range, including the equity percentage, vesting and strike? | confirmed |
| RR3 | Bundled specializations under one title | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several roles are folded into one seat at a single salary. I lowered it from `high` because the market band wasn't established | `[inferred]` from the JD's seven-function list against its pay and "team of one" | Which of these seven functions are expected in the first six months, and which are later? | unresolved |
| RR4 | Responsibility without stated authority or resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench" | You'd be accountable for all revenue growth with no stated budget, headcount plan or decision rights. "8+ years growth leadership" sits beside "a team of one" | `[inferred]` from the JD's scope language against its silence on resources | What paid budget and headcount are committed, and on what timeline? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime may be a standing expectation, with no stated compensation or recovery time | `[inferred]` from the JD's wording; `[generic]` that "just who we are" phrasing is a recognized always-on pattern | In the last quarter, how many evenings and weekends did the team work, and how is that time compensated or recovered? | unresolved |
| RR6 | Success metrics absent on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for all revenue growth has no stated definition of success | `[inferred]` from the JD's wording against its mandate scope | What revenue or pipeline outcome would define success at 6 and 12 months? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The posting gives no percentage, vesting schedule or strike price | `[grounded]` JD silence | What percentage, vesting schedule and strike price does the equity grant carry? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Research was refused, so this is unverified, not found false | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and say who I'd interview with? | unresolved |
| RR9 | Terms stated plainly and a CEO reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The posting states pay, location and schedule up front, which let this screening run on the page alone. Direct access to the CEO is also stated | `[grounded]` JD quotes | How often does this role meet with the board, and who sets its priorities day to day? | noted |

## Application plan

Every row and every line of advice here is proposed. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this posting as written | R1 and R2 are failed gates, and no CV language changes them | `[grounded]` R1, R2 | pending your approval |
| A2 | Screen future postings against your two terms first: remote or Portland-based, and base at least $150k | You can read both gates on the page, as you just did here | `[grounded]` your stated constraints | pending your approval |
| A3 | If you proceed anyway, ask RR3, RR4, RR5 and RR6 verbatim before investing in a loop, and draft no CV edits until RR8 verifies | The register doubles as interview preparation for a `no_go` you choose to override | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your stated background is self-report of CV standing, so those claims are leads for verification, not proof. Stage is assumed to be evaluating, since none was stated.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin" and "Novaline Head of Growth job Austin careers". Both were refused because search permission wasn't granted. It would have moved role reality's Organization and Contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base compensation 2026". It was refused for the same reason. It would have moved role reality's market calibration row and RR2's calibration against a band |
| 3. Hiring manager's public footprint | n/a | The posting names only "the CEO", so there is no name to search. A name would feed the scope read and the plan |

## Upgrade menu

- A link to the role on Novaline's own careers page, or the recruiter's email domain: RR8 resolves and the Contradictions row can be checked.
- Search permission granted so the lookups can run: targets 1 and 2 fill, RR2 gets a market band, and the market calibration row is replaced with the real band.
- The CEO's name: target 3 can run and the scope read firms up.
- The equity terms in writing: RR7 closes.
- Answers on SEO/content, brand, PR, partnerships and sales ops, and solo execution (G1, G2, G3): R6, R7 and R8 firm up. They matter only if R1 and R2 change.
- A sanitized channel, budget and revenue report from the $8M→$40M ARR period: R3, R4 and R5 can reach `high`.

I can also write this up as `tuesday-dossier.md` if you want a record of the screen.

**Questions:** none this turn. Nothing a reply could change would move the status while R1 and R2 stand.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.