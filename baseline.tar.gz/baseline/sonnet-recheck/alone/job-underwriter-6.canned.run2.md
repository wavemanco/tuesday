I've read the posting and run three searches (company, pay band, hiring manager). Next I'm checking whether Quillfield's own site lists this role, then I'll write up the assessment.
# Job Underwriting: Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, apply, but as a stretch rather than a clean fit. R7 (owning a forecast) is `adjacent`, R9 (owning billing data) is `absent`, and R1 and R2 need your confirmation first. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 salary)
- `must_have`: direct: R3, R4, R5 · adjacent: R6 (spreadsheet modelling), R7 (owning a forecast) · unclear: R8 (working with finance on billing or revenue data)
- `important`: absent: R9 (owning billing data)

R9 has no stated evidence behind it. R7 (`medium`) rests on your monthly pipeline review, and its limit is named in the map.

**Opportunity ledger.** The employer exists as described (RR1). Pay is stated and sits inside the sampled band (RR2), and the working pattern is explicit (RR3). Unknowns are the reporting line and who owns the forecast today (RR4), the one-person scope (RR5) and the success measures (RR6). The posting was not found on Quillfield's own site, though that was one guessed URL (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (£61,500–£67,000 salary); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the pay band fit your limits, which settles R1 and R2; (2) the posting is confirmed live with Quillfield, per RR1; (3) R7 and R9 are presented as what they are (adjacent and absent), never as ownership.
- **What would flip it:** if either R1 or R2 conflicts with a limit of yours, that gate fails and the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Hiring manager | You were told Tamsin Achebe. Her public profile lists her as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` your recruiter; `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" |
| Scope read | One person carries four jobs: CRM owner, billing-data owner, reporting builder and forecast co-runner. No team is mentioned | `[inferred]` from the posting's four responsibilities against its silence on staffing |
| Reporting line | Probably to the Head of RevOps, since she is the named hiring manager and holds the more senior title | `[inferred]` from her public title against the posting's title |
| Market calibration | The posted band sits inside the interquartile range of the pay guide and close to its median (£64,200, IQR £57,800–£70,400, n=438). The basis is one search snippet that was not opened, so it is a band to expect, not this employer's offer. Scope norms for the title were not searched | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting's figure |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Unknowns | Who owns the forecast today; new post or backfill; team around the role; option terms; success measures | — |
| Contradictions | None found. The posting is on a third-party board, and quillfield.co.uk/careers returned no page, so live status on Quillfield's own site is unconfirmed | `[grounded]` fetch result |

## Evidence map

Your background was typed rather than supplied as a CV, so it is self-report and every candidate claim below is capped at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You have not stated where you live or whether you can commute, so the gate is not established. Confidence is `none` because no constraint of yours has been given | `[grounded]` posting; your constraints not given | Asked in G4 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | Your pay floor has not been given, so the gate is not established. The band is stated, so the posting is not the unknown | `[grounded]` posting; your floor not given | Asked in G4 |
| R3 | 4+ years in revenue ops, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team. Typed self-report with no inspectable artifact yet. Your employer is a B2B payments company, and whether it counts as "software" is the employer's reading to make | `[grounded]` your background | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, plus the dashboard rebuilds. A certification record would raise this to `high` | `[grounded]` your background | Offer: certification record |
| R5 | Strong SQL | must_have | direct | medium | none | SQL weekly. Weekly use shows regular use, and "strong" is the posting's word, not yours | `[grounded]` your background | none |
| R6 | Spreadsheet modelling | must_have | adjacent | medium | discovery | Excel daily is established. Modelling (building a forecast or scenario model, as distinct from using Excel) is not stated | `[grounded]` your background; no modelling stated | Offer: a sanitized workbook |
| R7 | Experience owning a forecast (and running the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the forecast. That carries over as the input side. The limit is that you have never owned the company forecast, and nothing places you in a room with a CFO | `[grounded]` your background | Asked in G1 |
| R8 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You built renewal dashboards, but where their numbers came from and whether finance touched them is not stated. The posting says "billing or revenue", so revenue data could count | `[grounded]` your background; `[inferred]` that the renewal dashboards might touch revenue data | Asked in G2 |
| R9 | Owning billing data (a responsibility, not in the posting's requirements list) | important | absent | none | capability | You stated you have never worked on billing data. Not re-asked | `[grounded]` your statement | Closure path in G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R7, must_have) | transferability | You run the monthly pipeline review and finance owned the forecast. The bridge is real, and its limit is that you never owned the number | A `must_have` at `adjacent`. A confirmed input you owned narrows the objection most likely to be raised | A commit or best-case call you made; coverage ratios or a renewal forecast you supplied to finance; a number you were held to in the review | A sanitized pipeline-review deck or a forecast-input sheet | `[grounded]` your background; `[generic]` that forecast ownership is the likeliest objection for this title |
| G2 | Finance on billing or revenue data (R8, must_have) | discovery | The renewal dashboards' source and any finance involvement are unstated | The requirement says "billing or revenue", so revenue-data work with finance could close it | Reconciling renewal figures to finance's revenue numbers; agreeing field definitions (ARR, renewal date, churn) with finance; fixing a mismatch between CRM and finance | A sanitized dashboard screenshot or a definitions doc | `[grounded]` your background silent on the source; `[inferred]` that this could move R8 |
| G3 | Owning billing data (R9, important) | capability | No stated billing-data work | Named as an owned responsibility in the posting. It is the clearest gap, and wording cannot close it | A realistic path: working through invoice and subscription data in SQL; a short self-built reconciliation exercise using public or sample data; asking in the interview what the billing data's source systems are | None yet | `[grounded]` your statement; `[inferred]` closure path |
| G4 | Location and pay gates (R1, R2) | hard_gate | Neither is established against your own limits | A failed gate means no go however strong the rest is | n/a | Your own statement | `[grounded]` posting; your constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the company's own careers page | unknown | — | quillfield.co.uk/careers returned no page | The role may sit under a different careers URL or only on the job board. One guessed URL is weak evidence | `[generic]` pattern for companies of this size, not a claim about this one | Is this role listed on Quillfield's own careers site, and is it still open? | unresolved |
| RR2 | Pay stated and near the sampled median | positive_signal | — | "£61,500–£67,000 plus share options" | The band looks market-normal; option terms are the open part | `[grounded]` posting; `[generic]` band | What are the option terms (vesting, strike, size), and is the band fixed for this grade? | noted |
| RR3 | Working pattern stated explicitly | positive_signal | — | "Bristol, hybrid: two days a week in the office" | Little ambiguity about location terms | `[grounded]` posting | Which two days, and is that fixed? | noted |
| RR4 | Forecast ownership and reporting line unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may be accountable for a forecast that the Head of RevOps and the CFO also hold | `[inferred]` from the posting against her public title | Who owns the revenue forecast today, and who would I report to? | unresolved |
| RR5 | Four responsibilities, no team named | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… run the quarterly revenue forecast" | One person may be carrying several jobs. Low because "Lead" may mean a team exists | `[inferred]` from the posting's responsibilities against its silence on staffing | Is there a team or analyst support, and how is time expected to split across CRM, billing data and forecasting? | unresolved |
| RR6 | No success measures stated | unknown | — | Posting lists responsibilities but no outcomes | Success may be undefined for a demanding mandate | `[grounded]` posting silent | What would good look like at six and twelve months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume edit: "Rebuilt our pipeline and renewal dashboards" and "Run the monthly pipeline review with the sales director", placed above the tools list, using your own wording and no forecast language | R3, R4, R7 | `[grounded]` your sentences | resume_edits_pending_approval |
| E2 | Resume edit: "Salesforce admin certified" and "SQL weekly, Excel daily" stated as you gave them, with "ran revenue operations for the UK team, last 2 of 5 years" | R3, R4, R5 | `[grounded]` your sentences | resume_edits_pending_approval |
| P1 | Positioning: lead with the dashboard rebuilds and the monthly pipeline review. Say plainly that finance owned the forecast and that you owned the pipeline input to it, once G1 confirms what that was. Treat billing data as a stated learning area, not a claim | R7, R9 | `[grounded]` your statements | pending your approval |
| P2 | Lead with the pipeline-and-renewal reporting story for the hiring manager, since her public profile shows a sales-operations background | Her role history | `[inferred]` from her public profile | pending your approval |
| A1 | Confirm location, pay floor and the live listing before investing in an application | R1, R2, RR1 | `[grounded]` risk register | pending your approval |
| Q1 | Ask RR4, RR5 and RR6's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | A one-page sanitized walkthrough of a renewal dashboard and its data source | R6, R8 | `[grounded]` R6 and R8 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers"; read "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Role reality's organization row confirmed; RR1 opened |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Market calibration `[generic]`, pay only |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Role reality's hiring-manager and reporting-line rows; P2 |

I can turn this into `tuesday-dossier.md` if you'd like to keep it, and there's no pressure either way.

## Upgrade menu

- Your CV: R3–R7 are currently read from typed prose, so the map would be rebuilt against the real wording.
- A record of your Salesforce certification: R4 goes to `high`.
- A sanitized renewal dashboard screenshot or workbook: R6 and R8 firm up.
- A sanitized pipeline-review deck or forecast-input sheet: R7's bridge strengthens.
- Your location and pay floor: R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- The recruiter's answer on whether the post is new or a backfill, and on reporting line: RR4 and RR5 narrow.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G4 — Do the Bristol hybrid terms (two office days a week) and the £61,500–£67,000 band sit within your non-negotiables?

G1 — In your monthly pipeline review or your work with finance, was there a number you committed to or an input you owned that fed the company forecast? What was yours, and what was finance's?

G2 — Where did the renewal dashboards' figures come from, and did you reconcile or agree definitions with finance at any point?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.