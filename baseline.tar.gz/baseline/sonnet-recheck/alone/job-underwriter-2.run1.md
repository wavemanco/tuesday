Web search was refused by permissions, so this runs on your JD and resume alone. I'm assuming you're still evaluating, not yet applying.

# Quartzline — Product Manager, Platform APIs

## Decision snapshot

**No, this isn't a waste of your time, but it's a stretch. R1b (3+ years in a titled PM role) is absent against a stated must-have, while R3 and R4 are direct. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1a (Product management work itself), R2 (Shipped API or platform products) · absent: R1b (3+ years in a titled PM role)
- `important` — direct: R4 · adjacent: R6 (Discovery with integration partners), R7 (Own the roadmap), R8 (Specs and delivery with two engineering squads) · unclear: R5 (Agile delivery), R9 (Adoption metrics), R10 (Launches with sales and support)

R1b decides how this application has to be routed, and R3 and R4 carry the case for it.

**Opportunity ledger.** The posting's scope reads as concrete (RR5). The employer is unchecked (RR1), pay is unstated (RR2), roadmap decision rights are unstated (RR3), and how strictly the years requirement is applied is open (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) a person at Quartzline confirms the years requirement can flex for your background, or you reach a person rather than a filter, see R1b and RR4; (3) every bridge you use (R1a, R2, R6, R7, R8) is framed as adjacent work, never as PM ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as the posting describes it. Not independently checked | `[grounded]` JD header; unverified, see RR1 |
| Mandate | Own the partner-facing API platform roadmap; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stage | Assumed evaluating | `[inferred]` from your question, asked before any application |
| How the years requirement reads | The JD labels only "3+ years product management experience" as must-have. It is a length-of-experience requirement, not a legal or credential bar, so it is graded on fit like the others (R1a, R1b). Wording like this is commonly applied literally by recruiters or filters, so plan around it | `[inferred]` from the JD's "(must-have)" label; `[generic]` that such wording is commonly screened literally |
| Scope read | A partner-facing API platform with two squads reads as one platform area owned by one PM. Reporting line and decision rights are unstated | `[inferred]` from the JD's responsibilities against its silence on authority |
| Why the posting suits your background | The weight on API fluency (R3) and integration partners (R6) lines up with your integration work. The weakest match is the PM title itself (R1b) | `[inferred]` JD set against your resume |
| First 90 days, first year | Not stated | `[grounded]` JD silent |
| Location, pay, work pattern | Not stated | `[grounded]` JD silent |
| Market calibration | Not available. The role-family sweep did not run, so there is no band, and the posting's silence on pay stands unmeasured (RR2) | `[grounded]` research status below |
| Unknowns | Pay, location, decision rights, reporting line, strictness of the years requirement, success measures | — |
| Contradictions | None visible between the JD and your resume. The JD was not compared with Quartzline's careers page (unavailable) | `[grounded]` the two inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product management experience, the work itself ("3+ years product management experience") | must_have | adjacent | medium | transferability | Credible adjacency: you wrote requirements documents, coordinated engineers and product managers on custom builds, and ran quarterly roadmap-input sessions. Limit: none of that is stated as owning a roadmap, a backlog or prioritisation | `[grounded]` your resume summary; intake prose, so `medium` is the ceiling | Gap queue G2 |
| R1b | 3+ years in a titled PM role (same JD line) | must_have | absent | none | capability | You confirmed you have never held a PM title, so no titled years exist. No wording changes that. The nearby work is carried in R1a | `[grounded]` your statement; `[generic]` that titled years are often read literally | Carry as the material risk; route through a person (A1) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs and wrote the integration playbook. Limit: that is the delivery side of an API product, and nothing says you owned, designed or shipped the API itself. An internal tool is only an unconfirmed lead | `[grounded]` resume; `[inferred]` that product managers, not you, owned the API product, from your coordinating "product managers" on custom builds | G1 |
| R3 | Strong technical fluency: API docs, schemas | must_have | direct | medium | none | 30+ end-to-end integrations, integration architecture, and Postman, SQL and OpenAPI reading all state this. No inspectable artifact has been seen | `[grounded]` resume | Optional: a sanitized architecture diagram or the playbook would raise it |
| R4 | Stakeholder management across engineering, sales and customers | important | direct | medium | none | You coordinated your engineers, the client's engineers and product managers, and ran client workshops. Limit: sales is not mentioned, and support is covered under R10 | `[grounded]` resume | none |
| R5 | Experience with agile delivery | important | unclear | low | discovery | The resume is silent on sprints, backlogs or squads | `[grounded]` resume silence | Carried as a minor risk; see G3 |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions are close to partner discovery. Limit: the workshops scoped one client's implementation, and the roadmap sessions fed product rather than deciding what was built | `[grounded]` resume; ambiguity resolved downward | G2 |
| R7 | Own the roadmap | important | adjacent | medium | transferability | You supplied roadmap input. Nothing shows prioritisation or sign-off authority | `[grounded]` resume | G2 |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and coordinating engineers on custom builds are adjacent. Limit: writing for a product squad's backlog is not evidenced | `[grounded]` resume | G2 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent beyond SQL skill. An earlier-conversation lead about an internal triage tool is unconfirmed and not counted | `[grounded]` resume silence; memory lead unconfirmed | G1 |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | Your go-lives were client integrations, a different kind of launch from a product release. Nothing states work with sales or support | `[grounded]` resume | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption metrics (R2, R9) | discovery | The resume has nothing you built that others adopted or any adoption measure. A prior-conversation mention of a request-triage tool for support agents is unconfirmed | Confirmed, it is the nearest thing to evidence for R2 and R9, which sit at `adjacent` and `unclear`; unconfirmed, it cannot be used | An internal tool or dashboard others used; an integration template or connector reused across clients; a change to API docs or onboarding that you drove; any usage figure you tracked | Usage numbers, a README, screenshots, before and after ticket counts | `[grounded]` resume silence; `[inferred]` that the tool matters here, from the lead; `[generic]` that API-platform roles probe adoption |
| G2 | Roadmap, prioritisation and spec ownership (R1a, R6, R7, R8) | transferability | Adjacent evidence: requirements documents, custom-build coordination, roadmap-input sessions. Limit: no ownership of prioritisation or a squad backlog. Strengthener: one concrete case where your client feedback changed what product built, or a sanitized requirements document engineers built to | R1a is a `must_have` row and R7 and R8 are the responsibilities themselves, so a stronger bridge narrows the likeliest objection | Feedback from a roadmap session that led to a shipped feature; a custom build later reused by other clients; a requirements document an engineer built from | A sanitized requirements document, a roadmap-session summary, a release note | `[grounded]` resume; `[generic]` that this is the likeliest objection for a first PM role |
| G3 | Agile delivery (R5) | discovery | Resume silent | A listed requirement a hiring manager can probe quickly | Working in sprints with product engineers; attending standups or planning on custom builds | A sprint board export, a delivery timeline | `[grounded]` resume silence |
| G4 | Titled PM years (R1b) | capability | No titled PM years exist | The JD marks this must-have | Not closable by wording. Paths: a PM-scope stretch inside your current employer, an internal title change, or an employer that waives the years | A written statement from a hiring contact that background can substitute | `[grounded]` your statement; `[generic]` that these are the usual closure paths |
| G5 | Launches with sales and support (R10) | discovery | Go-lives are client launches, not product launches | An important row at `unclear` | Enablement for support or sales when a client went live; a handover pack | A go-live checklist, a handover document | `[grounded]` resume |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The check did not run, so the employer and the live posting are unconfirmed. Small or new companies often have thin footprints | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Quartzline's careers site, and tell me who I would interview with? | unresolved |
| RR2 | Compensation not stated | unknown | — | no pay figure in the posting | PM pay may differ from your current solutions-engineer pay, in either direction | `[inferred]` from the posting's silence; no market band was researched | What range is budgeted for this role? | unresolved |
| RR3 | Roadmap decision rights unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may be accountable for the roadmap without final say over priorities or squad capacity | `[inferred]` from the JD's scope language against its silence on authority | Who signs off the platform roadmap, and who sets the two squads' priorities? | unresolved |
| RR4 | Strictness of the years requirement unknown | unknown | — | "3+ years product management experience (must-have)" | The label may be applied literally, or it may flex for strong adjacent backgrounds | `[inferred]` from the JD labelling only this requirement must-have | How strictly is the 3-year requirement applied, and have you hired into this role from implementation or solutions-engineering backgrounds? | unresolved |
| RR5 | Scope is named concretely | positive_signal | — | "drive delivery with two engineering squads; define and track adoption metrics" | The team size and success measure are specific enough to evaluate | `[grounded]` JD states both | What does success look like at twelve months, and which adoption metrics does the role own? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reach a person before or alongside the application (the hiring manager, a recruiter, or a contact at Quartzline), and ask RR4 | R1b is the row a literal screen can end | `[generic]` how screening of such requirements commonly works; `[grounded]` R1b | pending your approval |
| A2 | Verify the employer and the live posting before investing in the loop | RR1 | `[grounded]` RR1 | pending your approval |
| A3 | State plainly that you have not held a PM title, and lead with the integration depth and the roadmap-input sessions | Candor on R1b makes R1a and R3 credible | `[grounded]` R1a, R1b, R3 | pending your approval |
| A4 | Ask RR2 and RR3 in the first conversation | Pay and decision rights are both unstated | `[grounded]` register | pending your approval |
| A5 | Do not describe the triage tool as product experience until G1 is answered | It is an unconfirmed memory lead | `[grounded]` the lead's status | pending your approval |

**Proposed resume edits — `resume_edits_pending_approval`**

| # | Current | Proposed | Source trace | Status |
|---|---|---|---|---|
| E1 | "7 years as a solutions engineer / implementation lead at an enterprise-software vendor" | "Solutions engineer and implementation lead with 7 years at an enterprise-software vendor: led 30+ client integrations of REST APIs end to end, and ran quarterly roadmap-input sessions collecting client feedback for product." | your summary, line 1 and the integrations and roadmap-input lines; "30+" stays on integrations | `resume_edits_pending_approval` |
| E2 | Coordination line placed after the integration bullets | Move "Coordinated our engineers, the client's engineers, and product managers on custom builds" up beside E1 | your own sentence, only reordered | `resume_edits_pending_approval` |
| E3 | Playbook line | "Wrote the internal integration playbook the whole team uses" | your own sentence | `resume_edits_pending_approval` |

**Proposed note to a hiring contact — pending your approval**

> "I haven't held a PM title, so I want to be upfront about that. For seven years as a solutions engineer and implementation lead I've led 30+ client integrations of my company's REST APIs and run quarterly sessions collecting client feedback for product. Does the team consider candidates with that background for this role?"

Each clause follows one of your sentences: "never held a PM title", the seven years, the 30+ integrations, "our REST APIs" and the quarterly sessions. The table rows, the edits and the note are separate proposals. Nothing in them is final until you approve it.

## Evidence status

Verified: none yet. Unverified leads: a prior-conversation mention of an internal request-triage tool that support agents adopted (unconfirmed, prompts G1 only). Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology partner API platform Series B"; the call was refused by permissions. It would have moved role reality's Organization and Contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "Product Manager platform APIs salary range requirements solutions engineer transition to product management"; the call was refused by permissions. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Dossier offer: I can package this as `tuesday-dossier.md` to carry forward whenever you want it.

## Upgrade menu

- Granting web search access, so L1 can run → RR1 and the Organization row verify or stay open, and a market band lands in the calibration row and RR2.
- The hiring manager's name → the scope read and which of your stories to lead with.
- An answer to G1, plus any usage figures or a README → R2 and R9 may move.
- An answer to G2, plus a sanitized requirements document or a feedback-to-roadmap example → R1a, R6, R7 and R8 may move.
- Your non-negotiables (pay floor, location) → hard-gate rows get built, and the Hard gates line stops reading "unknown".
- The recruiter's answer on RR4 → R1b's routing and the decision simplify.
- A prior resume or profile → it may hold evidence the current one dropped.

## Questions

1. **G1** — Did you build something, such as a tool, dashboard, template or script, that other people adopted? What did you own, who used it, and how did you know it was used?
2. **G2** — Was there a case where your client feedback or requirements changed what product or engineering actually built? What was your part, and did it reach other clients?
3. **Constraints** — What is your pay floor for a move, and are there location or schedule limits? A PM pivot can change both.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.