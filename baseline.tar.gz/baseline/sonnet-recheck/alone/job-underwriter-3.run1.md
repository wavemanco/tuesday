I'll read the reference files the skill points to before building the assessment.
# Job Underwriting Assessment: Head of Growth at Novaline

## Decision snapshot

**No, this posting isn't worth pursuing as written. R1 and R2 are both hard gates and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin five days a week), R2 (Base pay of at least $150k)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (SEO and content)
- `important`: unclear: R7 (Brand and PR), R8 (Partnerships and sales ops), R9 (Operating as a team of one)

R3, R4 and R5 are your strength, and R1 and R2 decide the outcome whatever those rows say.

**Opportunity ledger.** What feels off is visible in the register. Seven functions are bundled into one title at a stated $70–85k (RR3), with no team or budget named (RR4). The posting also writes in always-on hours (RR5) and has no defined success metrics (RR6). The employer itself is not yet established (RR7). The posting does state its pay and reporting line up front (RR8).

- **Hard gates:** failed: R1 (On-site in Austin five days a week), R2 (Base pay of at least $150k).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 would have to become remote or Portland-based, and R2 would have to reach at least $150k base. The posting says "no exceptions" on location and states a $70–85k band.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one", Austin office. These are the posting's own claims, not independently established | `[grounded]` posting header; not verified (research unavailable) |
| Mandate | Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and authority | "A team of one to start"; reports to the CEO with a dotted line to the board. No budget, headcount or decision rights are stated | `[grounded]` posting; silence on budget `[inferred]` from absence |
| Working pattern | On-site Austin five days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figure | `[grounded]` posting |
| Success metrics | None defined: "success metrics will evolve as we learn" | `[grounded]` posting |
| First 90 days and first year | Not stated | `[grounded]` posting silence |
| Scope read | The scope reads as several departments' work for one person, set against a salary that sits beside an 8+ years leadership requirement | `[inferred]` from the posting's function list against its stated pay and team size |
| Market calibration | Not established. The role-family search was refused, so there is no band to compare $70–85k against | `[generic]` none available; upgrade menu |
| Unknowns | Budget, revenue baseline, funding and runway, equity size, who the board contact is, whether the Austin rule has any flex | — |
| Contradictions | "Team of one" beside "own all revenue growth" and board exposure. Not checked against a careers page | `[inferred]` from the posting's own wording |

## Evidence map

Your background is typed prose, so it counts as self-report: confidence stops at `medium` until something inspectable backs it. Your two constraints are the exception, because your own specific word is the strongest evidence a constraint can have.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin five days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement of the limit, which is specific and your own. The fit fails because the posting rules out remote work and you rule out relocating. Wording cannot fix this | `[grounded]` posting quote plus your stated constraint | Only changed terms or a revised non-negotiable resolve it; see RR1 |
| R2 | Base pay of at least $150k (your constraint) against $70–85k base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor. The fit fails because the top of the stated band sits $65k under it. Equity is excluded because your floor is on base | `[grounded]` posting figure plus your stated constraint | Only changed terms or a revised floor resolve it; see RR2 |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You report 9 years, as growth lead and then Head of Growth at two B2C subscription companies. This is a length-of-experience requirement, so it is graded as fit and not as a gate. Prose self-report only | `[grounded]` your stated background | offer: a CV or LinkedIn history would raise it to `high` |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid. Your $8M to $40M ARR scale-up over three years, with a budget you controlled, is stated. Your exact personal share of that result is not stated | `[grounded]` your stated background | offer: a spend-and-CAC summary would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze, SQL and GA4 | `[grounded]` your stated background | offer: a sanitized lifecycle map or dashboard would raise it |
| R6 | SEO and content | must_have | unclear | none | discovery | Your summary doesn't mention SEO or content. That is silence, not a lack of experience | `[grounded]` silence in your summary | see G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Not mentioned in your summary | `[grounded]` silence in your summary | see G2 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Not mentioned in your summary | `[grounded]` silence in your summary | see G2 |
| R9 | Operating as a team of one | important | unclear | none | discovery | You managed teams of 3–7. That doesn't show whether you have worked with no team | `[grounded]` your stated team sizes | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R6, must_have) | discovery | Nothing on SEO or content in your summary | A `must_have` row at `unclear`, but it can't move the status while R1 and R2 stand | Owning an organic channel's targets, briefing writers, or running a content programme tied to subscriptions | A traffic or organic-conversion report, a content calendar | `[grounded]` silence in your summary |
| G2 | Brand, PR, partnerships and sales ops (R7, R8, important) | discovery | Nothing in your summary | Same limit as G1 | Running a co-marketing partnership, handling press during a launch, or owning a sales-ops handoff | A partnership agreement or launch plan | `[grounded]` silence in your summary |
| G3 | Working with no team (R9, important) | discovery | Team sizes of 3–7 only | Same limit as G1 | A period or project where you executed solo | A project summary | `[grounded]` your stated team sizes |

I have asked nothing about these rows: no answer could move `no_go`.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflicts with your remote-only constraint (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Terms are fixed by the employer's own statement | `[grounded]` posting quote against your constraint | Is any remote or Portland-based arrangement open for this role? | unresolved |
| RR2 | Base pay conflicts with your $150k floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The band may reflect a junior-priced bundle of roles, and equity of unknown size doesn't change base | `[grounded]` posting figure against your floor | What is the budgeted base ceiling, and what equity percentage and terms come with it? | unresolved |
| RR3 | Bundled specializations with a seniority-pay mismatch | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" with "8+ years" | Several departments' work for one person at a pay level that may sit below market for that mandate; a risk until the role-family sweep runs | `[inferred]` from the function list against the stated pay; the market comparison is `[generic]` and unchecked | Which of these seven functions are in scope in year one, and which do you expect to hire for? | unresolved |
| RR4 | Responsibility without stated resources | risk_signal | medium | "own all revenue growth end to end ... a team of one to start" | You may be accountable for revenue with no stated budget, tooling or hires | `[inferred]` from the posting's silence on budget | What budget, tools and headcount are committed for the first year? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine and not exceptional | `[inferred]` from the phrasing | How often have people in this team worked evenings or weekends in the last quarter? | unresolved |
| RR6 | Absent success metrics on a demanding mandate | risk_signal | low | "success metrics will evolve as we learn" | You could be measured against targets set after the fact | `[inferred]` from the phrasing | What would a successful first 12 months look like in numbers? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, or the posting may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about Novaline; my lookup was refused | Can you point me to this role on Novaline's own careers site, and say who I would interview with? | unresolved |
| RR8 | Pay and reporting line stated up front | positive_signal | — | "Report to the CEO with a dotted line to the board"; "$70–85k base" | The posting is open about both | `[grounded]` posting | What does the dotted line to the board involve in practice? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply to this role as written | see R1, R2, RR1, RR2 | `[grounded]` R1 and R2 rows | proposed, pending your approval |
| A2 | Optional: before dropping it, ask the recruiter or CEO RR1's and RR2's questions. The posting says "no exceptions", so I'd expect no change | A short reply settles R1 and R2 | `[inferred]` from the posting's own wording | pending your approval |
| A3 | On future postings, check location and stated base against your two constraints before spending effort | Both gates were visible in the posting text | `[grounded]` R1 and R2 rows | proposed, pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Novaline e-commerce enablement startup Austin Series A" was refused. It would have moved role reality's organization row and RR7 |
| 2. Role-family sweep | unavailable | Search "Head of Growth salary startup Series A base salary range 2026" was refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no person, only "the CEO", so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` if you want a file to keep or reuse.

## Upgrade menu

- Permission to search, so the Novaline lookup and a market band can run → RR7 and RR3 become checkable and role reality's calibration row fills in.
- A CV or LinkedIn history → R3, R4 and R5 can reach `high`.
- Any SEO, content, brand or partnerships work you've done → R6, R7 and R8 move from `unclear`.
- A link to the live posting or Novaline's careers page → RR7 resolves.

I'm asking no questions this turn, because no answer could move a `no_go` that rests on R1 and R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.