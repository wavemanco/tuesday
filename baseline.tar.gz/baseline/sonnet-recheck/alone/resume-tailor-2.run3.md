I'll read the reference files the skill points to before building the ledger.
Dev, this is the ledger for the Bellhaven Data Engineer role. Nothing has been applied; every row waits for your approval.

Your resume fits the analytics-engineering half of this job well: dbt, a star schema you co-designed, and tests on a nightly job. It does not yet show the engineering half: orchestration, production Python, SLAs, streaming. The JD makes "3+ years data engineering" a must-have, and a Senior Data Analyst title will not meet that on a first read. That is a risk to weigh, not a hard gate. Whether to apply anyway is job-underwriter's question, not this one. What I can do here is make sure everything you did do is visible and nothing you didn't do is claimed.

I worked from pasted prose, so I have no employer names, dates or section headings. I treated your sentences as one Experience section and left your first-person voice alone.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged text, moved to first bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged text, moved to second bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your resume | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged text, moved to third bullet)* | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Line 1: "Fixed our nightly dbt job when it breaks." Line 2: "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your resume | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged text, moved to last bullet)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your resume | pending your approval |
| E6 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart, and designed the orders mart's star schema with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume | pending your approval |
| E7 | Skills | *(no current line)* | "Redshift, dbt, SQL (window functions, CTEs), Python (pandas)" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your resume | pending your approval |

- **E1:** "with our then-DE" stays attached. The design was shared, and that qualifier is the honest part.
- **E4:** I split the line so "added tests" stands alone, since it is your only data-quality evidence. Neither half says "owned".
- **E6:** the two claims are joined, not blended. "Built and maintained" and "designed with" keep their own verbs, and "about 25" stays "about".
- **Python line:** I left it unchanged. "For analysis" qualifies it, and I could not tell whether the cron scripting sits under that qualifier. Ambiguity resolves downward, so I did not lift the scripting out.

To approve, reply in this form: `Approved: E1, E2, ...` / `Rejected: E_ — reason`.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | `not_evidenced` | Your title is analyst; nearby work (dbt models, nightly job) is in E2–E4 but is not engineering years. See C1 | `[grounded]` your title and bullets; `[generic]` titled-years requirements are usually read literally |
| M2 | Production Python | important | `not_evidenced` | Your line says "for analysis"; the cron scripts are the nearest evidence. See C2 | `[grounded]` your Python line |
| M3 | Airflow or equivalent orchestration | important | `not_evidenced` | You wrote "Never used Airflow"; what schedules the nightly dbt job is unknown. See C3 | `[grounded]` your resume |
| M4 | Dimensional modelling | important | `surfaced_by_edit` | E1 and E6. The star schema is evidenced, but as co-design with the then-DE | `[grounded]` your star schema line |
| M5 | Own data quality | important | `surfaced_by_edit` | E4, line 2. Tests were added to the nightly job; nothing says you owned quality overall | `[grounded]` your tests line |
| M6 | Own SLAs | important | `not_evidenced` | Nothing in the resume mentions deadlines, alerting or uptime. See C3 | `[grounded]` absence in your resume |
| M7 | Streaming experience | preferred | `not_evidenced` | Named absence A1 | `[grounded]` "Never touched Kafka." |
| M8 | Spark (named in the duties, not the requirements list) | preferred | `not_evidenced` | Named absence A2 | `[grounded]` "Never used Airflow or Spark." |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years as an analyst, with dbt modelling and nightly-job maintenance. It does not say whether you built or owned data pipelines | It is the only must-have in the JD, and your title does not satisfy it on a first read | Owning a source-to-mart load end to end; being the person who fixes the nightly run; building the vendor-API ingestion; taking over pipeline work when the DE left | The dbt project repo or docs, a pipeline diagram, a runbook | `[grounded]` what the resume does and does not say; `[generic]` what an unmet years requirement costs |
| C2 | Production Python | important | Python "for analysis", plus "some scripting to pull vendor APIs on a cron" | A cron script nobody depends on reads as analysis; one others rely on reads as production | Vendor scripts that run unattended and feed a table people use; retries, logging or failure alerts; code in git and reviewed; deployed to a server | A script repo or a README for the vendor pulls | `[grounded]` your Python line; `[generic]` how screeners read "production" |
| C3 | Orchestration and SLAs | important | A nightly dbt job you fix and test. It does not say what runs it or who depends on it finishing | The JD says "own data quality and SLAs"; scheduling and a delivery deadline are the closest analogues you might have | A dbt Cloud or cron schedule you configured; a time by which the orders mart must be ready; failure alerts; backfills you ran | The job's schedule config, an alert history, a stakeholder message about a deadline | `[grounded]` your nightly-job line; `[generic]` what orchestration evidence looks like |

**Named absences** (no recall prompt, because nothing in your history suggests something to pull):

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| A1 | Streaming (Kafka), preferred | You have never touched Kafka, and this is a plus, not a requirement | A small public project, such as a Kafka consumer loading into a warehouse table, takes weeks to build and could be linked from the resume. Without it, the honest move is to leave the plus uncovered. It will not decide this application | `[grounded]` "Never touched Kafka."; `[generic]` project-based closure |
| A2 | Spark, preferred | You have never used Spark, and it appears in the duties, not the requirements | A small batch job in Spark on a public dataset would close it. For this role, leaving it open is reasonable | `[grounded]` "Never used Airflow or Spark."; `[generic]` project-based closure |

## Not written, and why

- **"Data Engineer" as a title, or "3+ years of data engineering".** You were an analyst for five years, and the nearby work is adjacent, not equivalent.
- **"Built and owned batch pipelines".** You fixed and added tests to the nightly job. You did not say you built or owned it, and "pipelines" is the JD's word, not yours.
- **"Production Python".** You wrote "for analysis". Cron scripts are not described as production.
- **"Orchestrated pipelines" or any orchestration claim.** A dbt job is not an orchestrator, and you said you never used Airflow.
- **"Owned data quality and SLAs".** You added tests. No SLA appears anywhere in your account.
- **"Partnered with analytics on requirements".** You were the analytics side. The JD's word flips which side of the table you stood on.
- **"Led warehouse modelling".** You designed the star schema with the then-DE.
- **Streaming, Kafka or Spark in any form.** Never used.

## Parse-safety check

You pasted text, so I could not run any of the six checks: multi-column layout, tables and text boxes, images or skill bars, headers and footers, non-standard headings, and file type. Resumes in text form sometimes carry hidden text from templates, and I could not look for that either.

## Upgrade menu

- **The resume as a file (.docx or PDF).** This lets me run the parse-safety checks and look for hidden text a template may have left behind.
- **Older resume versions.** They sometimes hold pipeline or ingestion work the current one dropped, which could close C1.
- **A link to your dbt project or Python scripts, or a screenshot of the job schedule.** An inspectable artifact moves C1–C3 from your word to checkable evidence.

## Questions

C1 — Which stretch of your five years included building or owning data pipelines, as opposed to analysis, and what exactly did you own?
C2 — Do the vendor-API cron scripts run unattended, does anyone depend on their output, and are they in git or deployed anywhere?
C3 — What runs your nightly dbt job, and is there a time the orders mart has to be ready by, with someone expecting it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.