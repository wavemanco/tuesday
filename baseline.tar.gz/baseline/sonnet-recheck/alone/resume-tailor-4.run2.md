I'll read the reference files before building the ledger.
I've read the skill's rules and your details, and I'm now writing the full edit ledger.

**First, a correction.** The evidence on keyword auto-rejection is thin. In one vendor's interviews with 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters" (cite C25). That's two people, in a sample the vendor says shows themes rather than representative statistics. The same source says "When automated filters are used, they’re almost always knockout questions" (cite C26). Those are work authorization, location or licence checks on the application form, and nothing on a resume changes them. Match scores exist: "Many teams use match scores/filters to prioritize who gets reviewed first" (cite C27). But "56% either ignore the feature or don’t have it available" (cite C27), and that keywords drive the scores is an inference. So I can't confirm a keyword filter is why you're being rejected.

The coverage map below shows the bigger issue. Most of this JD's stack isn't on your resume, and I won't write keywords you can't defend in an interview. Whether this role is worth chasing at its current gap is job-underwriter's question. I've done the resume work in full.

I haven't seen your PDF. Every "current line" below is your own description of it, so the quotes are your words as you typed them to me, not the document's.

## Edit ledger — pending your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged — placed directly after the Jenkins pipeline line, ahead of lower-relevance bullets)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume as described | pending your approval |
| E2 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Kubernetes (proof-of-concept only), Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume as described | pending your approval |
| E3 | Summary | *(no current line)* | "DevOps engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume as described | pending your approval |

- **E1:** a reader who stops early meets your two most JD-relevant bullets first. Position is the only lever here. It adds no claim.
- **E2:** "Kubernetes" now appears in your skills list, so a parser can find it. The "(proof-of-concept only)" qualifier stays attached.
- **E3:** this is three of your sentences kept as three. It doesn't blend them, so the PoC can't read as part of the pipeline work. Reject it if you don't want a summary section.
- **Few rows:** there are only three because the honest ones are few. Your resume mostly lacks the JD's words, and the fix for that is experience, not wording.

## Coverage map

The JD doesn't tier its requirements. The priorities below are my reading of its order and its closing sentence.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes | must-have | `surfaced_by_edit` | E1, E2, E3 make a two-month PoC findable. It never reached production, so these edits don't make it equivalent to production experience. | `[grounded]` your PoC line; `[inferred]` priority |
| M2 | AWS (EC2, S3, RDS, IAM) | must-have | `already_evidenced` | Skills line, as written. | `[grounded]` your skills line |
| M3 | AWS EKS | must-have | `not_evidenced` | Recall prompt C2. | `[grounded]` EKS appears nowhere in your material; `[inferred]` priority |
| M4 | CI/CD pipelines | must-have | `already_evidenced` | Your Jenkins deploy-pipeline line, as written. It states the deploy half. | `[grounded]` your Jenkins line; `[inferred]` priority |
| M5 | CI/CD on GitLab | important | `not_evidenced` | Named absence N1. | `[grounded]` your Jenkins line names no GitLab |
| M6 | Terraform | must-have | `not_evidenced` | Recall prompt C1. | `[grounded]` Ansible is your only provisioning-adjacent tool; `[inferred]` priority |
| M7 | Python | important | `already_evidenced` | Skills line, as written. | `[grounded]` "Bash and Python scripting" |
| M8 | Go | preferred | `not_evidenced` | Named absence N2. | `[grounded]` Go appears nowhere in your material |
| M9 | Prometheus, Grafana, observability | important | `not_evidenced` | Recall prompt C3. You have CloudWatch for monitoring, which isn't the same tools. | `[grounded]` your CloudWatch line; `[inferred]` priority |
| M10 | SRE practices; owning platform reliability and developer experience | must-have | `not_evidenced` | Recall prompt C3. | `[grounded]` nothing in your material states on-call, SLOs or ownership of reliability; `[inferred]` priority from the JD's last sentence |
| M11 | ArgoCD, GitOps, Helm | important | `not_evidenced` | Recall prompt C2. | `[grounded]` none appear in your material |
| M12 | Istio, service mesh | important | `not_evidenced` | Named absence N3. | `[grounded]` not in your material |
| M13 | Vault | important | `not_evidenced` | Named absence N4. | `[grounded]` not in your material |

## Recovery per gap

**Recall prompts.** These are gaps where you may have something I can't see. The questions they imply are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | must-have | Ansible for config management; no provisioning or infrastructure-as-code tool named. | Terraform is the first IaC tool the JD names, and the resume has nothing a screener or reviewer could match it to. | A Terraform module for a non-prod environment; CloudFormation or similar for AWS resources; a pipeline step that ran Terraform someone else wrote | A repo, a PR, a module README | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | AWS EKS, Helm, ArgoCD and GitOps | must-have | A two-month Kubernetes PoC that never reached production, with no cluster type, packaging or deploy method stated. | The JD's Kubernetes stack is EKS plus Helm plus ArgoCD. Knowing what the PoC actually used decides which of those you can truthfully claim. | The PoC ran on EKS; apps packaged with Helm charts; manifests deployed from Git, even by hand; a write-up of what you learned | PoC notes, a diagram, manifests or charts, a demo recording | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Prometheus, Grafana, SRE practices, reliability ownership | must-have | CloudWatch for monitoring. Nothing on alerting design, on-call, incidents or reliability targets. | The JD closes on "own platform reliability", and a resume with monitoring but no reliability work reads as support rather than ownership. | CloudWatch alarms and dashboards you built; being on call; leading an incident write-up; any uptime or response target you worked to | A dashboard screenshot, a runbook, a post-incident review | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences.** These are gaps where I see nothing to pull.

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| N1 | GitLab CI/CD | You build and maintain pipelines in Jenkins and name no GitLab CI. | A small real pipeline in GitLab CI, for example migrating one Jenkins job as a personal project. | `[grounded]` the gap; `[generic]` the closing path |
| N2 | Go | Your scripting is Bash and Python. | A small tool written in Go, published. It's listed last in the JD, so it's the least worth closing. | `[grounded]` the gap; `[generic]` the closing path |
| N3 | Istio and service mesh | Nothing in your material touches service mesh. | A lab install of Istio on a test cluster. That's a learning exercise, not production experience, and I'd only write it up as exactly that. | `[grounded]` the gap; `[generic]` the closing path |
| N4 | Vault | Nothing in your material touches secrets management. | A small Vault integration in a test pipeline. If you already handle secrets in Jenkins, tell me and I'll treat it as a recall prompt. | `[grounded]` the gap; `[generic]` the closing path |

## Not written, and why

- **"Platform Engineer" as your title.** You are a DevOps Engineer, and a retitle to the JD's title is an upgrade, not an equivalent.
- **"CI/CD pipeline" for your Jenkins pipeline.** You wrote "deploy pipeline", which is the deploy half. I don't know it also built and tested.
- **"Kubernetes experience" or any production-Kubernetes wording.** Yours was a two-month PoC that never went to production.
- **"Infrastructure as code" or "Terraform" from Ansible.** Config management is a different kind of work.
- **"Observability" or "Prometheus/Grafana" from CloudWatch.** Monitoring with one tool isn't the same as the JD's stack.
- **"EKS", "Helm", "ArgoCD" or "GitOps".** You haven't said you used any of them.
- **"Owned platform reliability" or "improved developer experience".** Nothing you wrote says you owned either.
- **"Managed 30 Jenkins jobs".** You wrote "maintain about 30", and I'm keeping "about".
- **A keyword block listing the whole JD stack in Skills.** A tool listed is not a tool owned, so every line would be an unsupported claim.

## Parse-safety check

I only have your description, not the file, so I couldn't run any of this on the real document.

| Check | Your resume | What breaks | What it costs | Provenance |
|---|---|---|---|---|
| Multi-column layout | Two columns | Parsers read linearly and can interleave the columns | Text can scramble and dates can detach from roles | `[generic]` |
| Images, icons, skill-level bars | Icons for each skill | Icons render as garbage characters or the line is skipped | Anything carried only by an icon is absent | `[generic]` |
| Content in headers or footers | Contact details in the header | Headers can be discarded as page furniture | Contact details can be lost | `[generic]` |
| Unusual file type | Canva PDF | Varies by parser | A text-layer PDF or `.docx` is the safe pair. I can't tell whether yours has a text layer. | `[generic]` |

These are the risks. I haven't recommended a redesign, and a check on the actual file would tell us which of them are real.

## Upgrade menu

- **The resume as a file or pasted text.** I could quote your lines verbatim, check for text-layer and hidden-text problems, and run the parse checks above for real.
- **Answers to C1–C3.** Each answer can turn a `not_evidenced` row into a real, defensible line.
- **A repo, PoC notes or diagrams.** These move claims from self-report to inspectable proof.
- **Earlier resume versions.** They sometimes hold evidence the current one dropped.

## Questions

C1 — Have you written or modified any Terraform, CloudFormation or similar infrastructure-as-code, even in non-prod? What was it?
C2 — What did the Kubernetes PoC actually run on (EKS or something else), and how did you package and deploy to it (Helm, plain manifests, anything GitOps-style)?
C3 — Beyond CloudWatch, did you build alerting or dashboards, take part in on-call, or run incident follow-ups? What exactly?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.