I'll read the skill's reference files before building the pack.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-canned-6cd7e164/26b8168f-d688-4ce2-ba0b-f13405f7cf0c/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions. I built it assuming Tobias is your hiring manager, because Saltmarsh's careers page describes one 60-minute interview with the hiring manager.

- **Format:** The page calls it the "Outage Hour". The first half is a live-incident tabletop on a simulated outage during a live event, and the second half is a values conversation. It says there is no take-home. That is why the Case and Values banks carry the most weight.
- **Highest-ROI prep:** C1. Expect "you haven't worked on a game with in-app purchases, and both titles are moving to a season pass in January." The pack has you state the limit first, then say only what you did (the weekly content-drop calendar, the checklist, the monthly retention numbers), then give a week-one plan.
- **Also covered:** your lack of team leadership and the posting's four-team coordination line (C2). Saltmarsh's three published values are mapped in the cheat sheet. The checklist you wrote is a likely probe, because "Leave the Build Greener" is about it (B3, E2).
- **Caveat on Tobias:** What I found on him comes from one search snippet on a placeholder-style domain (`gdconf.example`) that I couldn't corroborate. The snippet says he gave a GDC 2026 talk called "Patch Notes Are a Promise" and was previously a QA lead. Confirm both before you mention them on Friday.
- **Caveat on Project Larkspur:** The Larkspur strategy item (the two titles moving to a season pass and one shared events calendar) is also from a snippet only. Read the full announcement before Friday.
- **Answer slots:** Several of your answers need your own input, such as whether those four years were all on a live-service title and which teams you worked with on drops. The pack leaves those as slots for you to fill truthfully, including "that wasn't mine."

Say the word and I'll play Tobias as the Skeptic on C1, or run the tabletop opener (A1).
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the person you'd report to, and has your recruiter said anything about what the Outage Hour scenario will cover? Either answer could reweight the Case and Skeptic banks.
2. Do you want a deeper research pass, with up to 6 more searches and 2 more fetches and several more minutes, to read the Larkspur announcement and Tobias's talk properly?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations, assumed to be the hiring manager because Saltmarsh's published loop has one 60-minute interview, with the hiring manager (see Sources). Interview: Friday, 60 minutes.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Past behaviour against Saltmarsh's published values |
| EXP | Whether your own claims survive scrutiny; what was actually you |
| JD | A stated responsibility or requirement in the posting |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role, answered by thinking aloud |

Provenance labels: `[grounded]` traces to your message, the JD or a cited source. `[inferred]` is derived from an adjacent source, with the derivation named. `[generic]` is a role-family pattern with no claim about you or Saltmarsh. Where a guidance cell says "answer slot", it is an instruction for the interview, not a question for you now: answer it from your own experience, or say plainly that the practice was not yours or did not exist.

## Prep triage

Built for roughly one evening, because the interview is Friday. Do these in order.

1. Rehearse C1 aloud until it is boring. It is the highest-ROI prep in this pack.
2. Run one tabletop (A1, then A2) out loud, clarifying questions first. The first half of the hour is a tabletop.
3. Rehearse B3 and E2 together: both are about the checklist you wrote.
4. Read Saltmarsh's values page and the Project Larkspur announcement in full, once each. This pack worked from a snippet of the announcement.
5. Settle your answer to the answer slots on F1 and F5. Say what is true, even if it is "that wasn't mine".

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on the weekly calendar, and does not show how many of those years were on a live-service title. The words stay at the quotes: "I spent four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Answer slot: the JD's 3+ years line makes a probe on how long the title was live likely. If it was live for more of the four years than the two you ran the calendar, say how long, in your own words; if it was live for those two only, say so plainly and stay with the two years of calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran the weekly content-drop calendar, for the main title, for the last two years. A named cadence and scope beat an adjective |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title; the JD's wording is a live-events calendar for two titles. The words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say what went on the weekly calendar and how you decided what went on it, in your own words; if the contents were set elsewhere, or deciding them was not yours, say so plainly and describe how you ran the calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which of the four disciplines you worked with on drops. Your message says you have not led a team; that is a statement about leading, and the material is silent on coordinating. Answer slot: the JD's four-team line makes a probe on who you worked with likely. If you worked with any of them on a drop, say which and what you did with each, in your own words; if none, or it was not yours, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the monthly numbers, not that you produced them or owned a review. The words stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe on what followed a drop likely. If a review followed drops, say how it ran and which part was yours, in your own words; if there was none, or it was not yours, say so plainly and stay with the monthly presentation |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the quote's own terms: you wrote it and QA still uses it. It is a line from your message with nothing inspected behind it, so expect a probe, and Saltmarsh's third published value (every release leaves the checklist better than it found it) makes the checklist's history a likely question. Answer slot: if the checklist changed after releases, say what prompted each change, in your own words; if it did not, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | Lead with it in the quote's terms. Expect a probe on how the numbers were counted. Answer slot: say which retention figures you presented, how each was counted, what it was sensitive to, and which part of producing it was yours, in your own words; if you did not produce them, or do not know how one was counted, say so plainly and describe what you presented |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote is written work another team uses. Lead with it in its own terms: "I wrote the release checklist our QA team still uses." The careers page describes no take-home, and the checklist itself is the artifact that would raise this row |
| F9 | "a season-pass model with one shared events calendar from January 2027" — Saltmarsh news, search result snippet (not in the JD; raised because the role plans calendars for two titles) | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap you stated, and not one the JD names. The pack raises it because the announcement puts a season pass on two of the studio's titles; whether this role touches it is not established, and linking a season pass to in-app purchases is the pack's reading. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work |

## Reading the interviewer

Public professional footprint only. One source, and it is thin: confirm it yourself before saying anything from it in the room.

| Public item | Source | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games | Talk listing, snippet only (see Sources) | He owns the function you would join, so the Outage Hour is his scenario and his scoring |
| GDC 2026 talk "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes describe what actually shipped | Same listing, snippet only | Expect close questions on whether what you say you did matches what you did; this is the same idea as Saltmarsh's second value. Read or watch the talk before Friday if you can find it |
| Described as previously a QA lead at a console studio | Same listing, snippet only | If correct, he will read your checklist as a QA person would (B3, E2). The listing's host domain is a placeholder-style one and nothing corroborates the QA detail, so do not mention his background unless you have confirmed it |

Mirror opportunity: shared vocabulary only, not a shared career jump. The checklist is the common ground: "Wrote the release checklist our QA team still uses" (F6). Do not build on it beyond that quote.

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | Highest. Saltmarsh's interviewing page says the single 60-minute interview opens with a live-incident tabletop. Weight 5 | Clarify, then objective, approach, metrics, risks, thinking aloud; challenge one premise politely |
| Values/Behavioral | The second half: a values conversation | High. The same page names a values conversation, and the values page publishes three. Weight 4 | One story per value where your material carries one; otherwise pick an instance with a named stake, and use the honest branch |
| Skeptic | Probing the gaps in the fit snapshot | Medium-high. A hiring manager derisks gaps, and F9 and F4 are open. Weight 3 | Rehearse C1 until boring; limit first, then what the quotes carry, then a plan |
| Data-Driven Prober | Close questions on what you did versus what shipped | Medium. The listed talk is about notes matching what shipped, which suggests exact attribution; this rests on one snippet. Weight 3 | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Pressure | Time-boxed or interrupting challenges | Medium-low. Tabletops are time-pressured by design, but the pages describe no stress format. Weight 2 | Pause, restate, hold through two follow-ups, concede only the specific limit |
| Conversational | Opener and "why Saltmarsh" | Low-medium; likely at the start. Weight 2 | A 90-second arc; treat casual questions as scored |
| Peer Evaluator | Not banked | The published loop has one interviewer, the hiring manager, so no peer round is described | None |

## Question banks

Highest-ROI prep in the pack: C1.

### A. Case/Strategist (weight 5): the Outage Hour tabletop

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're the producer on call. Two days into a live event, a share of players report the event screen won't load. What do you need to know in the first five minutes, and who do you pull in?" | CASE | [generic] | Clarify aloud before you structure: how many players, which platforms, since when, whether it started with a release, what players can still do. Then the objective (stop the harm, tell players the truth), who you bring in first and why (the JD names design, art, engineering and community as the teams on each update), and what players hear and when. Challenge one premise politely, such as whether the fault is the event or the build. The question needs no claim about your past, so the guidance makes none | The published first half of the loop is a tabletop, so this is the likeliest opening; CASE because it scores clarifying and structure; `[generic]` because the scenario is a pattern, not Saltmarsh's actual one |
| A2 | "Engineering says give them an hour before saying anything to players. Community wants to post now. What do you do?" | CASE | [inferred] | Do not pick a side first. Ask what each knows and who decides player communications. Propose a principle: say what is known, what is not, and when the next update comes. Saltmarsh's published wording is "we announce what is built, not what is hoped", so avoid promising a fix time. Concede that the hour may be right on a point you cannot see. The question needs no claim about your past, so the guidance makes none | Derived from the second published value applied to a seam between teams (F4's requirement); CASE because it is a live decision |
| A3 | "The outage is over. What goes on the first page of the post-event review, and which numbers does it report?" | CASE | [generic] | Structure aloud: what happened and when, player impact, cause, what changes before the next event, and which checklist items change. For the numbers, say which you would ask for, which need a baseline, and the assumption you would trust least. Use a figure from your own work only if you can say how it was counted. No claim about your past is needed here | F5 is the weakest-evidenced of the role's owned outputs, so the review is rehearsed as a live problem; CASE with JD content |
| A4 | "From January 2027, Tidepool Tactics and Lantern Row share one events calendar and the per-title event teams fold into one live-ops group. How would you plan the first month of that calendar?" | CO | [grounded] | Clarify first: who owns conflicts between the two titles' events, what the season pass fixes in advance. Say that you know the plan only from the public announcement. Every prepared candidate will cite it, so cite it once to show you read it, then give one reasoned view of your own on the calendar's biggest risk and how you would test it. The question needs no claim about your past, so none is made | The strategy item that separates prepared candidates; it comes from a search snippet, so read the full announcement; whether the JD's two titles are these two is not established (see reverse question 3) |
| A5 | "Retention fell in the week after an event ended. Diagnose it." | CASE | [generic] | Clarify: which players, which retention measure, compared with what, and whether anything else shipped or broke that week. Then competing hypotheses (the event ending, a release, an outage, something outside the game), how you would test each, and the assumption you would trust least in your own diagnosis. The question needs no claim about your past, so none is made | Tests the JD's retention line (F7) as a live problem; CASE with JD content |

### B. Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The calendar is the setting your quote gives, but nothing in it carries a disagreement, so choose the instance: a plan that had to give for a player-facing reason, with a named stake, what you did, what it cost the plan, and where things stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly calendar you ran, or how you would handle it | The first published value is "Players Before Plans"; F2 is the nearest evidence; VAL because it scores behaviour against a published value |
| B2 | "Tell me about a time what was announced about a release and what shipped didn't match." | VAL | [grounded] | Pick an instance with a named stake, what you said, what shipped, and what you did about the gap. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. This is the value closest to the interviewer's listed talk, so do not offer a story you cannot defend line by line | The second published value is "Ship the Patch Not the Promise"; nothing in the snapshot carries this story, so it is a scaffold; VAL |
| B3 | "Tell me about the release checklist you wrote: how did it come to be written, and has it changed since?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F6: you wrote it, and QA still uses it; those are the beats the quote states. Answer slot: the third published value makes the checklist's history a likely probe. If it changed after releases, say what prompted each change, in your own words; if it did not, or you did not own it afterwards, say so plainly and stay with the fact that you wrote it and QA still uses it | The third value is "Leave the Build Greener"; F6 is the strongest quote for it; VAL with EXP content, since a checklist history is probed for attribution |
| B4 | "Tell me about a time you had to put a number or a fact in front of leadership that they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: the setting is that you presented the monthly retention numbers to the studio head. Answer slot: if any figure was unwelcome, say what it was, how you said it and what happened, in your own words; if none was, say so plainly and stay with the monthly presentation. Choose a story where the hard truth actually landed; if your material shows none, say so rather than supplying an ending | A persona stem for the values interviewer, matched to the one place your material has you in front of leadership; VAL |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and Tidepool Tactics and Lantern Row move to a season pass in January. How do you handle that on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The deepest rehearsal. Level 1: say the limit first, plainly: "I haven't worked on a game with in-app purchases." Then say what the quotes carry, at their own scope: you ran the weekly content-drop calendar for the main title for two years, and you presented the monthly retention numbers to the studio head. Stop there and let them draw the inference. Then a plan, never a past: what you would ask in week one (who owns the pass's design, what the calendar must carry for it, what the review reports) and who you would learn from. Level 2, "so who covers the gap?": hold the plan, concede that you would lean on colleagues who have run one until you have shipped one. Level 3, "how do you know your calendar experience applies?": concede specifically that you do not know until you have seen how the pass is built. Never fold the core: the calendar and the numbers are real. No slot: the negative is yours | The likeliest objection to this candidate in this loop, aimed at F9 and sharpened by the announcement; JD because it tests fit to the work; the season pass to in-app purchase link is the pack's reading, so ask what the pass involves |
| C2 | "You haven't led a team, and this role coordinates design, art, engineering and community on every update. Why would those teams work with you?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment first: "I haven't led a team." The posting's own verb is coordinate, so say that back and ask what coordination looks like at Saltmarsh. Answer slot: say which of the four disciplines you worked with on drops and what you did with each, in your own words; if none, or it was not yours, say so plainly and return to the calendar you ran. Hold through two follow-ups; never claim you led | F4 is the open row and F1's team question sits beside it; JD because it scores a stated responsibility |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; "Never led a team" | Choose one honestly from your own material, give the limit in a sentence and one concrete first-week action. Do not name a weakness that is a strength in disguise. If you pick the in-app purchase gap, you are already inside C1; if you pick another row, use that row's answer slot | A stem the skeptic persona asks of every candidate; JD because it ranges over the whole posting |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented each month were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold at the quote: you presented them to the studio head. Answer slot: say how each figure was counted, what it was sensitive to, the assumption you would defend least, and which part was yours, in your own words; if you do not know how one was counted, or you did not produce them, say so plainly. The pack supplies no method or baseline | F7 is the line a prober reads first; EXP with JD content |
| D2 | "On the weekly calendar you ran: what went on it, and who decided?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F2 and F3: you ran the weekly content-drop calendar for the main title for two years. Answer slot: the JD's plan-and-run line makes a probe on who decided the contents likely. If you decided, say how; if it was set elsewhere or by someone else, say so plainly and describe how you ran the calendar. Say "ran", never "owned" | The attribution probe the listed talk's theme suggests; EXP |
| D3 | "After a drop shipped, what happened next on your team?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | Answer slot: the JD's post-event review line makes this probe likely. Say what happened after drops, in your own words; if nothing formal followed, or it was not yours, say so plainly and return to the monthly presentation | F5 is a thin row, and this is the open form of the probe; EXP |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over a candidate who has run a monetized live-ops calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause and restate. Hold with what the quotes carry: you ran the weekly content-drop calendar for the main title for two years, wrote the release checklist QA still uses, and presented the monthly retention numbers to the studio head. Concede the one stated limit: "I haven't worked on a game with in-app purchases." Hold through two follow-ups without adding a claim to fill the silence | Hold-then-concede on F9; JD because it compares you with the role's ideal |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Pause, then hold at the quote: you wrote it, and QA still uses it. Answer slot: if QA or anyone else wrote or changed parts of it, say who and what; if not, say so plainly. Concede any part that was not yours before the second follow-up | F6 is checkable by the person asking, and the interviewer's listed background may make this likelier; EXP |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built only from those four sentences, in that order, in your own words. Answer slot: why live operations, and why now. Your material carries no motive, so give your own reason; if the move is about the work rather than this company, say so | The opener is scored too; EXP |
| F2 | "What drew you to Saltmarsh specifically?" | CO | [grounded] | Use what Saltmarsh has published: the three values by name, the Project Larkspur direction, and the live-ops approach in the listed talk if you have confirmed and read it. Pick the one that is genuinely yours. Answer slot: if you have played either title, say what you noticed; if you have not, say so plainly and say what you looked at instead | The most predictable casual question; CO because it tests homework |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4, D2, C3 |
| "coordinate design, art, engineering and community teams on each update" | C2, A1, A2 |
| "own the post-event review and the KPIs it reports" | A3, D3, D1 |
| "manage the release checklist with QA" | B3, E2 |
| "3+ years producing live-service games or apps" | F1, E1, C3 |
| "experience running a content calendar" | D2, B1 |
| "comfortable with player-retention metrics" | A5, D1 |
| "clear written communication" | A3, B3; no dedicated writing exercise, because the careers page describes no take-home |

## Values cheat sheet

A values conversation is documented in the loop, so this section applies.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players conflict, the players win | F2: "I ran the weekly content-drop calendar for our main title for the last two years" is the setting, but no quote carries a disagreement. Selection scaffold in B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote carries it. Selection scaffold in B2, ending in its honest branch |
| Leave the Build Greener | Each release should leave the code and the checklist better than it found them | F6: "Wrote the release checklist our QA team still uses". Story in B3, with the answer slot on how it changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What did working in QA teach you about running live events that you would want a new producer to learn early?" | Ties to his own path. Ask it only if you have confirmed his background; otherwise swap in "what do you wish producers learned earlier?" |
| 2 | "How does Saltmarsh measure whether patch notes match what shipped, and what does the producer's post-event review report on that?" | Connects his published theme to the role's review-and-KPI line (F5). Use it only if you have read or watched the talk |
| 3 | "With Project Larkspur moving both titles to one shared events calendar, how does that change what this role plans and coordinates, and who owns conflicts between the titles?" | Shows you read the announcement and resolves the open question of whether the JD's two titles are the Larkspur titles |
| 4 | "What would a strong first 90 days look like, and what would you want me to have learned about the season pass by month three?" | Converts your stated gap (F9) into an agreed ramp, in the interviewer's words |
| 5 | "Which part of the Outage Hour do strong candidates tend to under-prepare?" | Shows you treat the format as the thing being scored, and costs nothing to ask |
| 6 | "What does the post-event review you would most like to read contain that most reviews leave out?" | Uses the one output the role owns; the answer shows his bar |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F4 context: "Never led a team" — your message | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or any monetization work | Negative you stated, F9: "never worked on a game with in-app purchases" — your message | "I haven't worked on a game with in-app purchases." No slot |
| Planned and ran live-events calendars for two titles | Inflated form of F3 | F3's quote at its own scope; the limit is the pack's observation: the material says a weekly content-drop calendar for one main title. D2's slot stays inside the calendar |
| Owned the KPIs or ran post-event reviews | Inflated form of F5 | F5's quote at its own scope; the limit is the pack's observation: the material says you presented the monthly numbers. D3's slot asks only what followed a drop |
| Four years of live-service production | Inflated form of F1 | F1's quotes at their own scope: associate producer for four years, the weekly calendar for two. F1's slot asks only how long the title was live |

## Sources

Provided: the job description and your background, both in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Queries sent:
- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur (snippet only; not fetched)
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only; not fetched; host is a placeholder-style domain and nothing corroborated it)

Fetched: the values page and the interviewing page, in full.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Values cheat sheet; B1 to B3; the published value names |
| 2. Interview process | yes | Persona weights, the loop structure (one 60-minute interview with the hiring manager: tabletop, then a values conversation, no take-home), and the detection of a values-style round |
| 3. Strategy and recent news | yes | A4, C1, F9 and reverse questions 3 and 4, from a snippet only |
| 4. Interviewer name and company | yes | The interviewer read, E2's rationale and reverse questions 1 and 2, from a snippet only and uncorroborated |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Recruiter confirmation that Tobias is the hiring manager, plus anything on what the Outage Hour scenario covers: reweights the personas and tunes A1 and A2 to the real scenario.
- The full Project Larkspur announcement pasted in: A4, C1, F9 and reverse questions 3 and 4 move from a snippet to the full text.
- The text of Tobias's talk, or confirmation of his background: replaces the one-line interviewer read and lets reverse questions 1 and 2 be used without a caveat.
- Your answers to the answer slots, especially on F1, F4 and F5: each answer enters the snapshot as a quote and upgrades its row from discovery to a mapped story.
- The release checklist itself, a content-calendar export, or a monthly retention slide: the artifacts that would raise F2, F6, F7 and F8 from medium to high.
- A tuesday-dossier.md from an earlier evidence-recovery pass: would add user-confirmed evidence and an underwriter-chosen objection; the pack does not depend on one.
