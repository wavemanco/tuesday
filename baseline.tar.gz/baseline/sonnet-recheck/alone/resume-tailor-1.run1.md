I'll read the reference files before building the ledger.
Your CV came in as prose, so each "current line" below is the sentence you wrote to me, quoted exactly. If your CV file words any of them differently, tell me. I also don't know the order of your real CV, so the reorder rows assume the order you wrote in. Nothing below is applied yet.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV prose | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged, moved to the first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV prose | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV prose | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Two bullets: "On-call rotation every fourth week for two years." and "I've run six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV prose | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged, moved to sit directly after the two E4 bullets)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV prose | pending your approval |

- **E1:** the sentences stay separate. Joining "7 years" to "payments company" would read as seven years at that company, which you didn't say.
- **E2 and E3:** I left both bullets unchanged and kept them as two bullets. Joining them would imply the balance-read path is the 40k-requests/minute service, and you haven't said it is.
- **E4:** the split gives the incident-commander line its own bullet. It doesn't attach the six incidents to the two-year window, because your sentence doesn't.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | already_evidenced | Your 7 years are stated as software engineering. The service ownership and the 4 years of Go/Rust are the backend evidence, and no row claims more than that. | `[grounded]` "Senior Software Engineer, 7 years." |
| R2 | Production Go | must-have | surfaced_by_edit | E1 and E2. Your CV says Go daily for 4 years but not which of your three services are in Go (see question R2). | `[grounded]` "Go and Rust daily for 4 years, Python before that." |
| R3 | Distributed systems at scale | must-have | not_evidenced | Recall prompt C1 | `[grounded]` Kafka and gRPC are listed as tools, with no work described around them |
| R4 | Strong incident response | must-have | surfaced_by_edit | E4 | `[grounded]` "I've run six incidents as incident commander." |
| R5 | Experience mentoring | must-have | surfaced_by_edit | E5. This is onboarding pairing with new hires. Their level isn't stated. | `[grounded]` "I pair with them for their first month." |
| R6 | Design and ship Go services at high request volume | important | surfaced_by_edit | E2 covers ownership and volume. Your CV says "own", not "design" or "ship". | `[grounded]` "about 40k requests/minute at peak" |
| R7 | Drive down p99 latency | important | surfaced_by_edit | E3 | `[grounded]` "from 380ms to 95ms" |
| R8 | Own on-call for your services | important | surfaced_by_edit | E4 covers the rotation. Your CV doesn't say the rotation covers the services you own. | `[grounded]` "On-call rotation every fourth week for two years" |
| R9 | Partner with product on roadmap sequencing | important | not_evidenced | Recall prompt C2 | `[grounded]` nothing in your CV touches product or roadmap work |

## Recall prompts (the questions are in the closing block)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Kafka and gRPC appear in a tools list, and you own three services in one pipeline. Nothing describes how they interact or what that work involved. | A tools list alone doesn't show the work behind a must-have. | A service of yours producing or consuming Kafka events; a gRPC call between your ledger services; a slowdown or failure in one service that reached another | A design doc, an architecture diagram, or an incident write-up | `[grounded]` what your CV does and doesn't say; `[generic]` what an unevidenced must-have costs on an application like this |
| C2 | Partner with product on roadmap sequencing | important | Nothing about product or roadmap work appears. | This is a named responsibility, and a missing one is visible. | Deciding with a product manager what to build first on one of your services; trading a feature against reliability work; scoping a project | A planning doc, a ticket thread, or a roadmap you contributed to | `[grounded]` what your CV doesn't say; `[generic]` how this responsibility is usually weighed |

## Not written, and why (pending your approval to leave out)

- **"Designed and shipped Go services":** you wrote "own". Design and shipping are different claims.
- **"Distributed systems at scale":** this is the JD's phrase. Kafka and gRPC are tools you list, and you haven't described owning distributed work.
- **"Mentored mid-level engineers":** you onboard new hires, and you haven't said what level they are. The word change from "onboarding" and "pair" to "mentored" would also change the kind of work.
- **"Senior Backend Engineer" as your title:** yours is Senior Software Engineer. I proposed no retitle.
- **"Owned on-call for the services you built":** you did a rotation. You haven't said it covers your own services.
- **Cutting p99 on the 40k requests/minute service:** you haven't said these are the same service. I also haven't said the p99 work was in Go.
- **Build-cache or developer-tools experience:** your cache work is on a balance-read path. That is a different system.
- **A programme of incident response:** you ran six incidents as incident commander. Nothing says you led a practice.
- **Any product or roadmap partnership:** there is nothing to trace it to.

## Parse-safety check

Your CV arrived as pasted prose, so I could not check layout columns, tables or text boxes, headers and footers, section headings, file type, or hidden text left behind by a template or tool. The ledger's proposed lines are plain one-line bullets, so they add no parse risk.

## Upgrade menu

- **Your CV as a file (.docx or PDF):** I could then run the parse-safety and hidden-text checks, and quote your exact current lines instead of this prose.
- **A p99 dashboard screenshot or write-up for the balance-read work:** it gives the E3 numbers an inspectable source.
- **A redacted post-incident review from one of the six incidents:** it backs the incident-commander line.
- **A design doc or diagram for your ledger pipeline:** it could turn C1 into a real row.
- **Earlier CV versions:** they sometimes hold evidence the current one dropped.

## Questions

R2 — Which of your three ledger-pipeline services are written in Go, and is the 40k requests/minute one among them?

C1 — Describe one piece of work where your services depend on each other or on Kafka. What part was yours?

C2 — Have you ever helped decide with product what to build first on one of your services? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.