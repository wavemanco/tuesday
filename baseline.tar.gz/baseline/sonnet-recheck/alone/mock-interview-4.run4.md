I'll read the skill's reference files first.
The pack is written and saved. The only step left is this summary.

Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-4-denied-a7d0e49e/ab633b24-5587-40ef-9828-6ec81efca8c7/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for a 45-minute hiring-manager round from your dossier's confirmed evidence, gap strategies, prohibited claims and employer questions. It has 20 questions across six personas, reverse questions, and a list of claims it won't coach.

The three web searches I tried (Quartzline's values, interview process and strategy) weren't permitted, so none of the pack rests on outside research. The case questions in bank B are generic patterns, and there's no company-strategy question or values sheet.

- **Rehearse first (A1):** the underwriter's objection. Concede the title and roadmap gap plainly, bridge from the integrations while naming the limit, then give a ramp plan. A2 and A3 follow.
- **The seam to prepare for (D3):** the roadmap-input sessions are confirmed with limited proof. Expect the question "what happened to the evidence you fed in?" and volunteer the limit first.
- **A gap in the dossier:** it lists "shipped API or platform products" (R2) as high priority but grades no weak area for it. The pack treats it as an adjacent-evidence gap (F3, A3).
- **Dossier date:** the dossier is dated 2026-08-14, so role facts are as of then.

I can play the Skeptic on A1 as a live drill whenever you want. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

- Round: one 45-minute conversation with the hiring manager (your message). Interviewer name not given.
- Built on: your tuesday-dossier.md (job-underwriter, conditional_go), plus your message. No outside research was available (see Sources).
- Highest-ROI prep: question A1, the objection the underwriter named. Then A2, A3 and D3.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether a claim about your work survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned out loud |

Each answer-guidance cell uses only sentences you confirmed to the underwriter, quoted in the Provenance column. An "Answer slot" is an instruction for the interview, not a question for you now: answer whichever branch is true, in your own words.

## Fit snapshot

Sources of the evidence column: the three confirmed claims in the dossier's `verified_candidate_evidence`. Confidence and gap-type calls on F1, F2 and F6 are the underwriter's; F3, F4 and F5 are this pack's own derivation under the routing rule, and the dossier does not grade them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | Dossier strategy: bridge, with the limit the underwriter named: adjacent, never PM experience. A length-of-experience requirement, not a gate. Words: the two quotes at their own scope, that you led the integrations and that you ran the sessions. The pack's observation: the material is integration work plus roadmap input, not a PM role. The second quote is confirmed with limited inspectable proof, so volunteer its limit before a prober extracts it. Answer slot: expect a probe on what came of the sessions; if you can say what product did with what you fed in, say it in your own words; if you cannot point to an outcome, say so plainly and stay with the sessions as you ran them |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | Dossier allowed_interview_strategy: acknowledge_gap, and prohibited_claims: "Having owned a product roadmap". The underwriter found no credible evidence, so no bridge is coached here. Words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: what you would learn first about which decisions would be the squad leads' and which yours. No answer slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier lists R2 as high priority but grades no weak area for it; this row is the pack's derivation. The quote is integration work at its own scope and does not say whether any of it reached the API or platform product itself, so the bridge is not stretched. Answer slot: the JD's first must-have line makes a probe on what sat on the other side of those integrations likely; if any of your work changed the API or the platform itself, say what and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | Architecture is the nearest word the quote carries, and it names a stage of the integrations, not API docs or schemas. Answer slot: the JD's technical-fluency line makes a probe on docs and schemas likely; if you read, wrote or reviewed any, say which and what part was yours; if you did not, say so plainly and stay with the architecture stage of the integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes carry client integrations and a session feeding product, each at its own scope; the material is silent on engineering and sales. Answer slot: the JD's stakeholder line makes a probe on the other people around those integrations likely; if people from engineering or sales were part of any of them, say who and what you did with them, in your own words; if not, say so plainly and stay with the client work |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Dossier strategy: clarify. No verified entry speaks to this requirement itself, so nothing is quoted and no story is mapped. Answer slot: the JD's agile delivery line makes a probe likely; if you have worked to an agile delivery process, say which and what your part was, in your own words; if you never worked that way, say so plainly, then say what you would want to confirm about how this team defines it |

## Persona table

Reasoning is shown so you can recalibrate. Your message establishes one 45-minute conversation with the hiring manager, so the weights start from the hiring-manager prior (Case/Strategist and Skeptic) and are adjusted by the dossier. No interviewer profile exists, so no interviewer-signal adjustment was made.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the PM-title and roadmap gap, motivation, the API-product gap | Highest. Hiring-manager prior, and the underwriter named a specific objection (F1, F2) | Rehearse the A1 objection until it is boring; bridge only from the quoted integration and session sentences, with the limit said first; concede the roadmap gap plainly |
| Case/Strategist (bank B, 5 questions) | Live problems from the role: partner discovery, adoption diagnosis, prioritising between two squads | Highest. Hiring-manager prior; the JD's responsibilities (roadmap, discovery, specs, adoption metrics) are all case-able | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; use the dossier's two unknowns as your clarifying questions |
| Conversational (bank C, 3 questions) | Biography opener, "walk me through one" | Medium. Any 45-minute conversation opens this way; casual questions are still scored | Pre-script the 90-second arc from the three quoted sentences |
| Data-Driven Prober (bank D, 3 questions) | Defends the 30+ count, the playbook, the roadmap-input sessions | Medium. A headline figure sits in F1, and one claim is confirmed with limited inspectable proof | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Pressure (bank E, 2 questions) | Time-boxed challenge on attribution and authority | Low. Nothing in the inputs signals a stress style | Pause, restate, hold the quoted sentence, concede specifically |
| Peer Evaluator (bank F, 2 questions) | Seam with the two squad leads, credit across teams | Low. The squad-lead authority question is open in the dossier, so it may arrive collegially | Propose seam principles rather than pretending to know the seam |

Values/Behavioral is not weighted: your inputs name no values-style round and no published Quartzline values were available. The Skeptic and Case banks together carry the highest-weight depth.

## Question banks

### Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The underwriter's named objection and the deepest rehearsal here. Move 1, concede first and plainly, in words the dossier's prohibited_claims and acknowledge_gap fields source: "I haven't held the product manager title, and I haven't owned a roadmap." Move 2, bridge with the limit said: "What I have is adjacent. I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I also wrote the internal integration playbook my team uses." Say adjacent; never call it PM work. Move 3, ramp as a plan, not a past: what you would learn first from the squad leads about which decisions are theirs, and how adoption is measured today. Follow-up 1, "That is zero of the three years": hold by returning to the integrations sentence, concede the years plainly, do not argue the number. Follow-up 2, "What did you do with roadmaps?": say only "I ran quarterly roadmap-input sessions feeding client evidence to product" — input, not ownership. That claim is confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Answer slot: expect a probe on what came of the sessions; if you can say what product did with what you fed in, and how you know, say it in your own words; if you cannot point to an outcome, say so plainly and stay with the sessions as you ran them. Follow-up 3, "Why not hire the PM who has done it?": concede that they will have roadmap repetitions you do not, then return to the integrations sentence | The underwriter derived this from evidence you confirmed (likely_interviewer_objections); F1 and F2 are where it presses. JD because it scores the PM-experience requirement; it is the single most predictable question in the loop |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name it plainly, in words the dossier's prohibited_claims and acknowledge_gap fields source: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp, as a plan: you would ask which of those decisions are the squad leads' and which would be yours, and learn how adoption is measured today, before proposing anything. No bridge on this one; the underwriter looked and found nothing to bridge with | F2 is the clearest honest weakness, and this is the Skeptic's stem for it. JD because it scores the roadmap-ownership responsibility |
| A3 | "Your integration work was for clients. What do you know about building the API they integrate with?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start at the quote's own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Stop there before reaching for more. Answer slot: if any of your work changed the API or the platform itself, say what and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations you led. Then turn to what you would want to learn from the squads about how the platform is built | R2 is a must-have and the dossier does not grade it; F3 is the pack's derivation, so this is where an unrehearsed answer would stretch. JD because it scores that requirement |
| A4 | "Why a product role, and why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The reason is yours to state; the pack does not supply one. Give two beats you can stand behind: what pulled you toward product work, in your own words, and the nearest thing your material carries, "I ran quarterly roadmap-input sessions feeding client evidence to product." Keep it at that scope and name the limit: it was input, not ownership. If no clear pull comes to mind, say so plainly, then say what you want to test in this role | The motivation probe is the Skeptic's second line after the gap itself, and F1's second quote is the only product-facing sentence you confirmed. JD because it tests consistency of the move into this role |
| A5 | "I don't see agile delivery in your background — how would you handle that here?" | JD | [grounded] | The guidance makes no claim about your past. Answer slot: if you have worked to an agile delivery process, say which and what your part was, in your own words; if you never worked that way, say so plainly. Either way, finish by saying what you would want to confirm about how this team defines it. It is a preferred requirement, so give it a short answer and move on | F6 is a clarify area: the evidence may exist but was not established. JD because it scores the preferred requirement; low rehearsal weight |

### Bank B — Case/Strategist

No Quartzline research was available, so every case below is `[generic]`: patterns for the problem, not facts about this company. The guidance makes no claim about your past.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you would run discovery with our integration partners in your first sixty days. What do you need to know first?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: who the partners are and how they differ, what the current picture of their needs is, and who owns which decisions today. Then objective, how you would segment partners, the approach, what you would measure, the risks. Say your assumptions aloud and challenge one premise respectfully | The role's discovery responsibility, asked as a live problem. CASE because it scores structure and clarification rather than history |
| B2 | "Partner API adoption fell twenty percent this quarter. Diagnose it." | CASE | [generic] | Open with the definition: what counts as adoption here, and what the baseline is, which the dossier shows is still unclear for this team. Then segment partners, list hypotheses before data, name what you would check first and what would change your mind. State the assumption you would trust least | The adoption-metrics responsibility, and the dossier's open unknown about how adoption is measured. CASE because the answer is reasoning, not recall |
| B3 | "Sales wants a partner-requested endpoint; engineering wants to pay down a versioning problem. One squad, one quarter. How do you decide?" | CASE | [generic] | Answer as how you would reason, not as what you have done. Criteria first, then the evidence you would want from each side, then who decides, which you would clarify rather than assume. Say how you would disagree and still commit. The prioritisation authority is an open question in the dossier, so ask it | Tests the prioritisation the role owns without inviting a claim to prior authority. CASE; it also lets you show reasoning on the F2 gap without bridging it |
| B4 | "A change you want to ship would break integrations your partners already run. How do you write the spec and plan the rollout?" | CASE | [generic] | Structure: who is affected and how many, what a safe migration path looks like, how you tell partners and when, what you would want engineering to confirm, what done means. Ask which versioning conventions the platform already uses before proposing one | The specs-with-two-squads responsibility and the technical-fluency requirement. CASE because it tests spec thinking live |
| B5 | "In your first ninety days, what would you produce, and what would you deliberately leave alone?" | CASE | [generic] | A plan, never a past. Lead with listening and learning the squads' current roadmap, the adoption baseline and the decision rights; name one or two things you would produce for them; name what you would not touch until you understood it. This is also the ramp plan that A1 and A2 point to | The natural close to the roadmap-ownership gap in F2. CASE because it tests judgment about sequencing |

### Bank C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats and no more: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "I wrote the internal integration playbook my team uses"; "I ran quarterly roadmap-input sessions feeding client evidence to product." The third is confirmed with limited inspectable proof, so say it at its own scope. Dates, titles and anything else are yours to add only if true; the pack supplies none. End on why this role in your own words | The biography question is almost certain in a 45-minute conversation, and F1's quotes are the only story the pack can map. EXP because it tests whether the account survives follow-ups |
| C2 | "Pick one of those integrations and walk me through it end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The beats are the ones the sentence states: scoping, requirements, architecture, UAT, go-live. Which integration, and every detail inside it, is yours; the pack does not know them. Where a call was yours, say so; where it was the client's or someone else's, say so plainly. Hold "I led it" at that scope | The "end-to-end" word invites exactly this walk-through. EXP because it tests what was actually yours; F1 and F3 draw on it |
| C3 | "What is in the integration playbook you wrote that you are proudest of?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | State it at its own scope: you wrote the internal integration playbook your team uses. What it contains, and which part you would single out, is yours to say; the pack does not know. If you cannot single one out, say so plainly and describe how your team uses it. It is a confirmed, inspectable artifact: bring it, or offer to share it | The playbook is the only high-confidence inspectable artifact in the dossier. EXP; it supports F1 and F5 |

### Bank D — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say thirty-plus integrations. How was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The number belongs to integrations, not to clients or projects. Four slots, each in your own words: how it was counted; what the count is sensitive to; the assumption behind it you would defend least; which part of the integrations was yours. The pack supplies none of them. If you do not know exactly how it was counted, say so plainly. Hold "I led" at its own scope | A headline figure is the Prober's first target. EXP because it scores precise attribution; F1 and F3 depend on it |
| D2 | "How comfortable are you reading and critiquing API docs and schemas?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you read, wrote or reviewed any API docs or schemas, say which and what your part was, in your own words; if you did not, say so plainly and stay with the architecture stage of the integrations you led. Architecture is the nearest word you confirmed, and it does not say what you did in it | R3 is important and the dossier does not grade it; F4 is a discovery row. JD because it scores that requirement |
| D3 | "Those roadmap-input sessions — what happened to the evidence you fed in?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The one claim the underwriter marked medium: confirmed, little inspectable proof, so expect this probe and volunteer the limit first. Say what the sentence says: you ran quarterly sessions feeding client evidence to product. Answer slot: if you can say what product did with it, and how you know, say it in your own words; if you do not know what came of it, or there is nothing to point to, say so plainly and stay with the sessions as you ran them | F1's second quote is where a prober will find the seam. EXP because it tests whether the claim holds past the first follow-up |

### Bank E — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Those integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate. Hold the sentence you confirmed: "I led them." Hold through two follow-ups by returning to it, never by adding to it. Then concede specifically: answer slot, say which parts were not yours, in your own words; if you cannot name any, say so plainly rather than inventing a split | The attribution probe the persona exists for. EXP; the hold is only what F1's first quote carries |
| E2 | "Our squad leads know this platform far better than you do. Why would they listen to you?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having set prioritization for an engineering squad" | Concede the first half without defending: they know the platform better. Hold on what you confirmed: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Concede in the dossier-sourced words from prohibited_claims and acknowledge_gap: "I haven't set prioritization for an engineering squad." Then plan, not past: you would learn their platform and their priorities first, and ask which decisions are theirs | The squad-lead authority question is open in the dossier and F2 is the gap beneath it. JD because it scores stakeholder management with engineering |

### Bank F — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "The PM and the squad leads share the roadmap. Where is the seam, and what happens when you disagree?" | JD | [generic] | The guidance makes no claim about your past. Do not pretend to know the seam; offer principles instead: who holds each kind of decision should be agreed early and written down, disagreements go to evidence first, and the person who loses the call still commits. Then ask the employer question about which roadmap decisions the PM makes alone | The dossier names squad-lead authority as unevidenced; a peer-style probe can arrive this way even from a hiring manager. JD because it scores the stakeholder requirement |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A scaffold: pick an occasion where your work and another team's results were entangled. It needs a named split of what was yours and what was theirs, and how credit was named. If no such occasion comes to mind, say so plainly, then say how you would handle it | A standard collegial probe. VAL because it tests behavior, not a published value; it supports F5 |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, A4, E2 |
| R2 Shipped API or platform products | A3, C2, D1 |
| R3 Technical fluency: API docs, schemas | D2, B4 |
| R4 Stakeholder management across engineering, sales, customers | E2, F1, F2, B3, C3 |
| R5 Agile delivery experience | A5 |
| Own the roadmap | A1, A2, B3, F1 |
| Run discovery with integration partners | B1 |
| Write specs and drive delivery with two engineering squads | B4, F1 |
| Define and track adoption metrics | B2 |

No CO question: the Quartzline strategy searches were refused, so a CO question would have to be generic and the case bank carries that load instead.

## Reverse questions

Two come from the dossier's `questions_for_employer` and two from its `opportunity_risks_to_validate`; they also answer what you need to know before accepting.

| # | Question to ask | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted in the JD but not evidenced. It reads as diligence, and the answer tells you what the role really is |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier flags adoption metrics as a named responsibility with no stated baseline. It shows you think in measures, and you need the baseline before you could own it |
| RQ3 | "How do the two squads divide the platform today, and where do their priorities tend to collide?" | Builds on the same authority unknown and prepares you for the seam probes in bank F |
| RQ4 | "What would you want a new PM to learn from the squads before proposing changes to the roadmap?" | Matches the ramp plan you give in A1 and B5, and shows you intend to listen first |
| RQ5 | "What would success look like for this role at six months?" | A generic closer that gives you the manager's own measure; useful whatever the answers above turn out to be |

## Prohibited claims

What this pack will not coach, and why. The first three come straight from the dossier.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims. Implied forms such as "effectively the PM" are not coached either | F1's quotes at their own scope, and the plain acknowledgment the prohibited_claims field sources: "I haven't held the product manager title." |
| Having owned a product roadmap | Dossier prohibited_claims, and acknowledge_gap for F2 | "I haven't owned a product roadmap." Plus the ramp plan as a plan |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Plus the ramp plan as a plan |
| Shipped API or platform products | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material says integrations of the vendor's REST APIs, not shipping an API product |
| Managed stakeholders across engineering, sales and customers | Inflated form of F5 | F5's quotes at their own scope. The pack's observation: they carry client integrations and sessions feeding product, and nothing on engineering or sales |
| Shaped or influenced the product roadmap through the sessions | Inflated form of F1's second quote | The quote at its own scope: sessions feeding client evidence to product. The pack's observation: what product did with the evidence is not in the material |

## Sources

- Provided: tuesday-dossier.md pasted in your message (dossier_version 1.1, written by job-underwriter, dated 2026-08-14; the pack takes its role facts as of that date). Sections consumed: `handoff_to_mock_interview` (all fields), `role_profile` (requirements, responsibilities, unknowns), `decision` (context only). The pasted dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so none were consumed.
- Provided: your message — one 45-minute conversation with the hiring manager, interview on Thursday.
- Loop: established by your words (one session, the hiring manager); no other loop source was read, and no archetype fallback was applied.
- Searches sent, all refused (permission not granted): "Quartzline company values"; "Quartzline interview process product manager"; "Quartzline strategy partner API platform news". Nothing came back, and nothing from them is used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline company values | unavailable | Call refused. Would have fed a values cheat sheet and VAL questions; none built, and no values-style round is detected from your inputs |
| 2. Quartzline interview process, product manager | unavailable | Call refused. Would have confirmed loop structure; persona weights rest on your stated round and the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Call refused. Would have grounded a CO question and anchored bank B in Quartzline's current priorities; bank B stays generic |
| 4. Interviewer name and company | n/a | No name was given, so no query could be formed; there is no interviewer read |
| 5. Representative product manager JD | skipped | The dossier's `role_profile` fixes the requirements and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's note on what the 45 minutes will cover, or any pre-declared deliverable → coverage firmed up and a build section if one was announced
- Search access for Quartzline's values, loop and strategy, and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a CO question grounded in current strategy, bank B anchored in it, and a values cheat sheet if a values round is documented
- Notes, agendas or any outputs from the quarterly roadmap-input sessions → the claim behind D3 and A1 can move from medium toward high, since inspectable proof is what raises the band
- Your answers to the answer slots on F1, F3, F4, F5 and F6, said outside a drill → those rows regenerate from your own words
- The raw CV behind the confirmed claims → more exact quotes for F3, F4 and F5, which are this pack's derivations and not the underwriter's grades
