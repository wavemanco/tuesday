**Yes, worth applying to. Treat it as a stretch role with two real gaps, R6 (forecast ownership, `adjacent`) and R7b (billing data, `absent`), and apply on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 plus options)
- `must_have`: direct: R3a, R4 · adjacent: R6 (Owning a forecast) · unclear: R3b (B2B software company setting), R5 (Strong SQL, spreadsheet modelling), R7a (Working with finance on revenue data) · absent: R7b (Billing data)
- `important`: direct: R8

R6 has a bridge with its limit named, and R7b is the row to prepare an honest answer for.

**Opportunity ledger.** The employer is real and consistent with the posting. The open questions are scope: no team or reporting line is stated (RR2, RR3), and the role is not yet confirmed on Quillfield's own site (RR1). Pay sits inside the market band (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (£61,500–£67,000 plus options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  - (1) A Bristol office two days a week and the pay band both work for you (R1, R2).
  - (2) You frame R6 and R7b honestly as gaps, not as experience.
  - (3) The interviews show a realistic scope and reporting line (RR2, RR3).
  - If R1 or R2 doesn't work for you, the status becomes `no_go` with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. It was founded in Bristol in 2018, has 96 employees, and closed a £11M Series A in April 2025 | `[grounded]` company About page, fetched |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Terms | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| First-year outcomes | Not stated in the posting | `[grounded]` posting silence |
| Scope read | A hands-on post spanning CRM, billing data, reporting and forecasting at a 96-person company. The posting names no team or reports for a "Lead" title | `[inferred]` from the posting's scope list against its silence on team, plus the About page headcount |
| Market calibration | £61,500–£67,000 sits inside the typical range for UK B2B software revenue operations leads: median £64,200, interquartile range £57,800–£70,400, n=438. That is a pattern, not this employer's offer. Option value is unknown | `[generic]` Ledgerline 2026 pay guide, search snippet only; `[grounded]` posting for the figure |
| Hiring manager | A Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches the recruiter's account, but the posting does not name a manager | `[grounded]` search result snippet, profile not opened; `[grounded]` posting silence |
| Unknowns | Reporting line; who owns the forecast number today; team or reports; option terms; success measures; whether this is a new post or a backfill | `[grounded]` posting silence |
| Contradictions | None between the posting and the About page. The role itself was not found on Quillfield's own site | `[grounded]` About page fetched; no careers page surfaced |

## Evidence map

Everything below comes from your message, which counts as self-report, so nothing is above `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You gave no location or commuting constraint, so there is nothing to grade it against | `[grounded]` posting; your message silent | Answer G1 |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor was given. The figure is stated in the posting, so only your floor is missing | `[grounded]` posting; your message silent | Answer G1 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You stated 5 years in sales operations, the last 2 running revenue operations for the UK team. That is confirmed and specific but unprobed, and years of experience is not a gate | `[grounded]` your stated background | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | You said "B2B payments company". Whether it counts as a software company depends on what it sold, and you haven't said | `[grounded]` your wording against the posting's | G5 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, which is specific. It is `medium` until a credential record is inspected | `[grounded]` your stated certification | Offer the credential record |
| R5 | Strong SQL and spreadsheet modelling | must_have | unclear | low | discovery | "SQL weekly, Excel daily" shows how often you use them, not depth or whether you build models. I haven't up-rated frequency into "strong" | `[grounded]` your stated usage | G4 |
| R6 | Experience owning a forecast (the posting also says "run the quarterly revenue forecast with the CFO") | must_have | adjacent | medium | transferability | You have not owned the company forecast, because finance did. Adjacent: you run the monthly pipeline review with your sales director and rebuilt the pipeline and renewal dashboards. Limit: no forecast accountability and no CFO-level exposure stated | `[grounded]` your own statement of what you haven't owned | G2 |
| R7a | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | Your renewal dashboards touch revenue data, but you haven't said whether finance used them or worked with you on them | `[grounded]` your message; the finance link is not stated | G3 |
| R7b | Billing data (the posting says "own our CRM and billing data") | must_have | absent | none | capability | You confirmed you have never worked on billing data. No adjacent evidence is stated | `[grounded]` your own statement | Closure path in G6, not a question |
| R8 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Limit: whether finance was among their users is not stated | `[grounded]` your stated dashboards | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The posting states both terms; you stated no constraint on either | Either one failing ends the application whatever the fit elsewhere | Your commute to Bristol, your base-pay floor, how you value options | Nothing to attach; your word is the evidence | `[grounded]` posting; your message silent |
| G2 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review plus the dashboards; finance owned the company forecast | A `must_have` at `adjacent`, and the posting says you would run the forecast with the CFO. A stronger bridge narrows the likeliest objection | Giving a pipeline call or commit that finance rolled up; tracking the UK team's quarterly number against actuals; a pipeline-to-bookings model; a variance review | A sanitized variance or bridge workbook, a pipeline-review pack template, a dashboard screenshot | `[grounded]` your message; `[generic]` that forecast ownership is the likeliest objection |
| G3 | Working with finance on revenue data (R7a, must_have) | discovery | Renewal dashboards exist; finance's use of them is unknown | A confirmed finance link would make R7b's gap look adjacent instead of absolute | Finance asking you for renewal numbers; reconciling a renewals extract to finance's figures; agreeing definitions such as ARR or churn with finance | A definitions sheet, a reconciliation, an email thread (sanitized) | `[grounded]` your message; `[inferred]` that this could soften R7b |
| G4 | SQL and spreadsheet modelling depth (R5, must_have) | discovery | Frequency of use only | Resolvable cheaply, and it should lift R5 from `unclear` | Queries joining CRM tables; a renewal or pipeline model with assumptions; a rebuilt report that replaced a manual one | A query sample, a sanitized workbook | `[grounded]` your message |
| G5 | B2B software setting (R3b, must_have) | discovery | "B2B payments company", product type not stated | Low effort to settle | What the company's product was, and whether sales ran on subscription or recurring revenue | The company's product page | `[grounded]` your wording |
| G6 | Billing data (R7b, must_have) | capability | Confirmed none | The role says it owns billing data, so this is the gap most likely to be probed | Closure path: learn how invoices, credit notes and subscription periods map to recurring revenue, then reconcile a renewals extract against a billing export | A small reconciliation as a work sample | `[grounded]` your statement; `[generic]` the closure path |

G5 and G6 carry no question this turn: G5 is low-impact, and G6 is a confirmed absence.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not confirmed on the company's own site | risk_signal | low | The posting is hosted on a job board; one search and one fetch found only the About page | The listing may be an aggregated copy, or the careers page may simply not be indexed. The employer itself is established, so this is narrow | `[inferred]` from one search and one fetch finding no careers page | Is this role currently open, and is it a new post or a backfill? | unresolved |
| RR2 | Wide scope with no team stated | unknown | — | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast" | The "Lead" may be a one-person function across CRM, billing data, reporting and forecasting | `[inferred]` from the posting's scope list against its silence on team | Does this role have direct reports or analysts, and who is on the team today? | unresolved |
| RR3 | Reporting line and forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | A Head of Revenue Operations is already listed at Quillfield, so forecast accountability may be shared or the role may sit under that head | `[inferred]` from the posting's wording against the hiring manager's listed title | Who owns the forecast number — this role, the head of revenue operations, or the CFO — and who does this role report to? | unresolved |
| RR4 | Pay inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | The base is stated and sits near the market median. Option terms are not stated | `[grounded]` posting; `[generic]` pay guide band | What are the option terms: number, strike price and vesting? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle location and pay (G1) before putting effort in | R1, R2 | `[grounded]` map rows | pending your approval |
| A2 | Ask the questions in RR1 to RR3 verbatim with the recruiter or Tamsin | They double as interview preparation | `[grounded]` register | pending your approval |
| A3 | Open with your own career path (E1), since her listed path also runs from sales operations to revenue operations | Her pattern is a published career line, not a stated preference | `[inferred]` from the search snippet | pending your approval |
| W1 | Optional: a small sanitized work sample, such as a pipeline-to-forecast bridge or a renewals-to-billing reconciliation | G2, G6 | `[generic]` closure path | pending your approval |

Proposed application lines, `resume_edits_pending_approval`. I haven't seen your CV, so these are drawn from your message only, each clause traced to your own words:

| # | Proposed line | Source | Status |
|---|---|---|---|
| E1 | "Five years in sales operations at a B2B payments company, the last two running revenue operations for the UK team." | Your background line | pending your approval |
| E2 | "Salesforce admin certified; I rebuilt our pipeline and renewal dashboards and run the monthly pipeline review with our sales director." | Your background line | pending your approval |
| E3 | Interview framing, pending your approval: "Finance owned our company forecast, so I haven't owned one, and I haven't worked on billing data." Then give what you did own. | Your own statements | pending your approval |

Interview rehearsal for the forecast and billing questions is mock-interview's job, not this one's.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead Bristol"; it returned "About Quillfield" (quillfield.co.uk/about), which I fetched. It moved role reality's organization and contradictions rows and RR1. No careers page surfaced |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol scope forecast"; it returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide), snippet only. It moved the market calibration row and RR4. It returned nothing on typical scope |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; it returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. It moved the hiring-manager row, RR3 and A3 |

If you'd like, I can save all of this as `tuesday-dossier.md` to carry forward.

**Upgrade menu**
- Your CV → map rows move from your typed background to CV-sourced evidence, and I can propose real CV edits.
- A Salesforce credential record → R4 to `high`.
- A sanitized dashboard screenshot or pipeline-review pack → R3a, R8 to `high`.
- A SQL query sample or sanitized workbook → R5 resolves.
- A sanitized forecast or variance workbook → R6's bridge strengthens.
- The recruiter's answers on reporting line, team, forecast ownership and option terms → RR2, RR3 and RR4 close.
- A link to the role on Quillfield's own careers site → RR1 closes.
- A deeper research pass on Quillfield (funding follow-ups, leadership changes, staff reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Does a Bristol office two days a week, with a £61,500–£67,000 base, work for you?

G2 — Have you ever produced or defended a number that finance rolled into the company forecast, such as a pipeline commit or a quarterly call for the UK team? What did you own, and how did it compare with the actual?

G3 — Did anyone in finance use your renewal dashboards or data, and if so, for what, and did you agree any definitions with them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.