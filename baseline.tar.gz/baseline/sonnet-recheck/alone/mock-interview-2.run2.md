I'll read the skill's reference files before building the pack.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-2-denied-4ee7b2aa/faf75da7-2288-4186-b5bb-c19c25af038e/scratchpad/atlas-freight_operations-manager_interview_pack.md`. It has 21 questions across seven interviewer styles and 7 reverse questions. It also has a fit table that quotes your own words against each JD line, and a list of claims the pack won't coach.

I built it for an unknown round with flat weights, since you don't know who you're meeting. Web search was refused in this session, so nothing in it comes from Atlas Freight's own pages. There are no company-values or strategy questions, and the pack's Sources section says so.

**Highest-ROI prep: question A2.** Your current role is 3 supervisors, and this one leads 12 across four sites. The pack gives you a hold, a concession and a ramp plan for it, with three follow-ups to expect. After A2, rehearse these:
- **A3:** the Power BI question. Your answer is one plain sentence, "I've never used Power BI," then a plan.
- **A1:** how many of your seven years involved leading people. The JD's 5+ years is about leadership, not time in operations.
- **C1:** how the 40% mis-pick reduction was counted. The pack gives you no method; you either know it or say you don't.

Several answers have slots for things only you know, such as any earlier larger team, any terminal work, or tracking of on-time or cost numbers. Fill those from your own experience, or say plainly it wasn't yours.

I can play the Skeptic on A2 as a live drill whenever you want. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, or convert the pack to Word.

Who is interviewing you: a hiring manager, a peer, or someone senior, and has the recruiter said what they'll focus on? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
- **Interviewer and relationship:** not known. You said you don't know anything about who's interviewing you, so there is no interviewer read in this pack.
- **Built on this assumption:** a first full-loop pack with flat persona weights, because the round type and the interviewer's relationship to the role are unknown. Any answer to that reweights every bank.
- **Research:** web search was refused in this session, so nothing here comes from Atlas Freight's own pages. Company facts, values and loop structure are absent rather than guessed (see Sources).

## How to use this pack

Personas are how a question arrives; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether the claims on your background survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (thin in this pack, since research did not run) |
| CASE | A live problem from the role, reasoned aloud |

**Highest-ROI prep in this pack: A2**, the step from three supervisors to twelve across four sites. It will be asked in some form. Rehearse it until it is boring, then do C1 and A3.

An answer slot is an instruction for the interview, not a question for you now: answer from your own experience, or say plainly that the practice was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution, and a senior shift manager role, not terminals and not four sites. Words stay at that scope: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's terminals and four sites make a probe likely on whether your work has covered more than your own shift or one site. If any of it did, say which and what part was yours; if not, say so plainly and stay with the role you hold |
| F2 | "drive on-time performance and cost-per-shipment down" (the on-time half) — JD | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | The sentence shows a surge plan run, and does not show whether on-time performance was tracked. Answer slot: if you tracked on-time performance or any delivery-timeliness measure, say what it was and what happened to it; if you did not, say so plainly and say what you would measure first |
| F3 | "drive on-time performance and cost-per-shipment down" (the cost half) — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | The sentence shows a mis-pick rate cut, and does not show any cost measure. Words stay at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked any cost measure at your site, say which and what it did; if you did not, say so plainly and say what you would track first |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is the scope the sentence carries; twelve is four times that. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on span of control likely. If an earlier role or project had you leading more people, say which and what part was yours; if not, say so plainly and stay with the three you lead |
| F5 | "build reporting in Excel/Power BI" (the Excel half) — JD | "solid Excel" — your message | low | [inferred] | discovery | The sentence says Excel skill, and does not say what was built with it. Answer slot: the JD says build reporting, so expect a probe on what you produced. If you built reports others relied on, say what they showed and who used them; if your Excel work was your own analysis only, say so plainly |
| F6 | "build reporting in Excel/Power BI" (the Power BI half) — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The sentences show seven years in operations and a current leadership role, and do not show how many of the seven years involved leading people. A titled-years line like this is likely screened literally, so expect the question. Answer slot: say how many of the seven years you led people and in which roles; if it is fewer than five, say so plainly and return to the role you hold now |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the requirement. Lead with it in its own terms: you are green belt certified. Expect a probe on where it has been used (D2) |

No row is a hard gate: the JD's experience line is a length-of-experience requirement, not a credential or legal bar, so it is graded like the others.

## Persona table

The relationship is unknown, so weights are flat to start, then tilted by what the fit snapshot shows. Change them if you learn more.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of scale, background mismatch and why this role now | High: F1, F4 and F7 are scale and fit rows, and F6 is a stated gap, so these are where a hiring manager looks first | Rehearse A2 until it is boring: hold what your quotes carry, concede the size of the step, then a plan (A1 to A5) |
| Case / Strategist | Live ops problems: diagnose an on-time drop, cut cost, plan a surge | High: the role is defined by on-time performance and cost-per-shipment, and the JD gives no other way to test them live | Clarify, objective, segmentation, approach, metrics, risks; think aloud (B1 to B4) |
| Data-Driven Prober | Reads the background line by line and works the 40% to its assumptions | Medium-high: F3 holds the one quantified claim you gave | Know how the figure was counted, or say plainly you don't (C1 to C3) |
| Conversational | Friendly opener, then casual questions on JD topics | Medium: every first conversation opens this way | A 90-second arc built only from your own sentences (D1 to D3) |
| Pressure | Interrupts, time-boxes, challenges how much was you | Medium-low: more likely if the interviewer is senior | Pause, restate, hold through two follow-ups, concede specifically (E1, E2) |
| Values / Behavioral | Past-behavior stories; the themes here are persona stems, not Atlas Freight's published values, which were not retrieved | Medium-low: no loop source says there is a values round | Selection scaffolds ending in the honest branch (F1, F2) |
| Peer | Seam between sites, credit and disagreement | Low: an interviewer who runs an adjacent site or function would raise it | Seam principles, reciprocity (G1, G2) |

## Question banks

Types: VAL, EXP, JD, CO, CASE. Provenance carries the label, plus every sentence of yours the guidance rests on.

### A. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role asks for 5+ years of operations leadership. How does your background meet that?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Say it at the quotes' scope: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's leadership line makes a probe on how many of the seven years involved leading people likely. Give the number and the roles in your own words; if it is fewer than five, say so plainly and return to the role you hold now. Do not stretch the seven years into leadership years | F7 is the requirement and the likeliest place to be probed; JD because it scores a stated requirement |
| A2 | "This role leads twelve supervisors across four sites, and you currently lead three. How do you see that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **The highest-ROI rehearsal in this pack.** Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Concede the size, specifically: twelve is four times three, and the step is real. Answer slot: if an earlier role or project had you leading more people or covering more than one site, say which and what part was yours; if not, say so plainly and stay with the three you lead. Then a plan, said as a plan: what you would do first with twelve supervisors you have not yet worked with, in your own words, committing only to what you would genuinely do. Follow-up 1 to expect: how would you split your time across four sites. Follow-up 2: what do you do if one site's supervisors push back on you. Follow-up 3: so you haven't done this before. Answer each by returning to the quote and the plan, never by adding to the quote | F4 and F1 are the widest gap between your sentence and the JD, so this objection arrives in some form; JD because it scores the stated requirement |
| A3 | "The role builds reporting in Excel and Power BI. Where do you stand on Power BI?" | JD | [grounded] "never used Power BI"; "solid Excel" | First sentence, plainly: "I've never used Power BI." Then Excel at its scope: you have said solid Excel. Answer slot: if your Excel work included reports others relied on, say what they showed and who used them, in your own words; if it was your own analysis only, say so plainly. Close with a plan, said as a plan: what you would do first to be working in Power BI, committing only to what you would honestly do. Do not describe any Power BI exposure | F6 is a stated limit, so the question is certain; the answer is a short acknowledgment and a plan, not a defense. JD because the tool is named in the posting |
| A4 | "Your background is warehouse and distribution, and this is terminal operations. What's different?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I have 7 years in warehouse and distribution ops." Answer slot: the JD says terminal operations, so expect a probe on the difference. If any of your work was in a terminal setting, say how it compared; if not, say so plainly and say what you would want to learn first about terminals. Make no claim about how terminals work that you cannot stand behind | F1 pairs the quote with the JD's terminal wording; JD because it scores the role as listed |
| A5 | "Why leave your current role, why Atlas Freight, and why now?" | CO | [generic] | Selection scaffold: your real reasons, in your own words, in order. The role-specific part should come from the JD's own scope (four sites, twelve supervisors, on-time and cost). The company-specific part is empty in this pack because research did not run: use what you actually know about Atlas Freight, and if you know little, say what drew you to the role itself. If no clear reason comes to mind, say so plainly, then give the nearest thing that is true | Motivation consistency is a standard Skeptic probe; CO because "why here" tests homework, and `[generic]` because no company facts were retrieved |

### B. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals slips over three weeks. Diagnose it. What do you need to know first?" | CASE | [generic] | Clarify before you structure: how on-time is defined and measured, which flows or lanes, what changed three weeks ago. Segment: inbound versus outbound, by shift, by dock or lane, by customer. Form two or three hypotheses, say what data would confirm each, name a quick fix and a lasting one, and the risk of each. Think aloud and state the structure before using it. This question asks about no past, so the guidance claims none | The JD's on-time performance line (F2's requirement) asked as a decision instead of a record; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost-per-shipment is up. How do you decide where to start?" | CASE | [generic] | Clarify what is in the measure and over what period. Break it into its parts (labor, transport, handling, damage and claims, rework) and ask which part moved, then which site. Pick the part with the largest movement and the most control, say how you would test the cause before changing anything, and what you would watch afterward. Make no claim about your past | The JD's cost-per-shipment line (F3's requirement) as a live problem; CASE because the interviewer scores structure |
| B3 | "A peak-season surge hits all four sites at once, and one site is short on supervisors. How do you allocate?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: demand by site, what is fixed versus movable, which service commitments are at risk, who can cover whom, what you escalate. If asked what you have done in peak, the sentence is: "I ran the site's peak-season surge plan two years running." Tell it in your own words with only those beats: the site's, the surge plan, two years. Do not add what the plan contained | The nearest of your stories to the role's scale problem (F2 holds the quote); CASE delivery with an EXP follow-up if they ask for your experience |
| B4 | "You have twelve supervisors across four sites. What does a good start-of-day look like so they run one rhythm?" | CASE | [generic] | Say what every supervisor must see and report each day, how exceptions escalate, how short the check-in stays, and how you would check that it works. Offer it as a principle you would test with the supervisors, not as a system you already run. Make no claim about your past | Tests the leadership requirement (F4's) as design; `[generic]` because it is a pattern |

### C. Data-Driven Prober (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State it at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words. Name the weakest assumption before they do. If you don't know how it was counted, say so plainly; that is an honest branch. This pack does not supply a baseline or method | F3 holds your one quantified claim; EXP because the Prober's job is to test whether it survives |
| C2 | "Walk me through the pick path redesign." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats are the ones the sentence states: a mis-pick rate, a pick path, a redesign. Tell it in your own words with the terms you used at the time. Answer slot: if parts of the redesign were not yours, say which and whose; if all of it was, say so plainly. Do not add steps, tools or results the sentence does not state | The likely first follow-up to C1; EXP |
| C3 | "Which operational numbers matter most to you, and why?" | JD | [grounded] | Selection scaffold, in your own words: pick the two or three numbers you really watch, and say why. Answer slot: the JD names on-time performance and cost-per-shipment, so expect a probe on both. If you track either, or a close equivalent, say what it showed; if you do not, say so plainly and say how you would start tracking it | F2 and F3 are discovery rows; JD because the posting names both measures |

### D. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc in three parts. Now: "I'm currently a senior shift manager over 3 supervisors." Before: "I have 7 years in warehouse and distribution ops," with the steps between and why you moved, in your own words (answer slot: only you can fill the middle; if a step is unremarkable, say it briefly). Next: why this role, in your own words. Two proof points can ride along at their own scope: the pick path redesign and the surge plan | Every conversation opens this way, so the arc is scored; EXP because it is your story in sequence |
| D2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Open with it: you are green belt certified. Answer slot: if you have applied it on the job, say where and what you did, in your own words; if the belt has not yet been used beyond the certification, say so plainly and say where you would use it first in this role | F8 is the plus in the JD; asked casually, it is still scored |
| D3 | "What would you want to learn in your first 90 days?" | JD | [generic] | Pick from the true list: four sites and their people, how on-time and cost are measured today, and Power BI, which you have said you have never used. Say what you would do, as plans, in the order you would do them | Pairs an honest ramp with the gaps in F4 and F6; `[generic]` because the shape is a pattern |

### E. Pressure (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold the sentence at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part was yours and which was not, in your own words; if you don't know how the credit divides, say so plainly. Hold through two follow-ups by returning to the part you can stand behind, and concede only what is true and specific | The standard pressure test on F3; EXP because it scores attribution under stress |
| E2 | "Sixty seconds: why you over a candidate who already runs a multi-site operation?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Three beats from your sentences, nothing more: the seven years and the role you hold now; the pick path redesign and the surge plan at their scope; the green belt. Concede first, specifically, that the other candidate may have run more sites, then say what you bring. Do not claim you match their scale | F1 and F4 are the gaps the comparison presses; JD because it scores fit to the posting |

### F. Values / Behavioral (weight: medium-low)

These use persona stems. Atlas Freight's published values were not retrieved, so none is mapped here.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a point where you did not fold, and a relationship that was intact at the end. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Standard values-persona stem; `[generic]` because it names no company value |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where the customer and a number pulled apart, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Fits a role judged on on-time and cost together, where the two can conflict |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side. Where is the seam between them, and what happens when two site leads disagree about shared resources?" | CASE | [generic] | Offer seam principles rather than pretending to know the seam: one owner per decision, a shared view of the numbers, a stated way to escalate. Say what you would ask first. Make no claim about your past | An interviewer who runs an adjacent site would ask this; `[generic]` because it presupposes nothing about you |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: a time work crossed teams, what was yours, how you named others' parts. If no such time comes to mind, say so plainly, then give the nearest thing your experience does carry, or how you would handle it | Standard peer stem; tests whether you share credit precisely |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A4, B1, B4, G1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, B3, C3 |
| Lead a team of 12 supervisors | A2, B4 |
| Build reporting in Excel/Power BI | A3 |
| 5+ years operations leadership | A1, A2 |
| Lean/Six Sigma a plus | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and what does good look like?" | Shows you think in definitions first, and the answer tells you what you would be judged on |
| R2 | "How are the twelve supervisors spread across the four sites, and where is the team strongest?" | Signals you are already thinking about the span of control (F4) rather than avoiding it |
| R3 | "What reporting exists today, and what do you wish you had? How much of it is in Excel and how much in Power BI?" | Puts the Power BI gap (F6) on your terms and asks what to build first |
| R4 | "What would make the first 90 days a success from your point of view?" | Turns the ramp plan into the interviewer's own criteria |
| R5 | "What has made cost-per-shipment hardest to move so far?" | Shows you treat the number as a problem to solve, and tells you where the role's real difficulty sits |
| R6 | "Which site would you want me to spend my first weeks at, and why?" | Treats the four-site scope as a plan, and the answer tells you where the pressure is |
| R7 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer; ask it only if your interviewer turns out to be one |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led twelve supervisors, or a multi-site team | Inflated form of F4 and F1 | F4's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." The limit is the pack's observation: your material says three supervisors, not twelve and not several sites. A2's slot stays inside the role you hold |
| Owned terminal operations | Inflated form of F1 | F1's quotes at their own scope: warehouse and distribution ops, and a senior shift manager role. A4's slot asks only whether any of your work was in a terminal setting |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 and F3 | F2's and F3's quotes at their own scope: the surge plan you ran, and the mis-pick rate you cut. The limit is the pack's observation: your material does not show either measure |
| Has 5+ years of operations leadership | Inflated form of F7 | F7's quote at its own scope: 7 years in warehouse and distribution ops. A1's slot asks only how many of those years involved leading people |
| Has built reporting in Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never used Power BI." No slot |
| Has used Lean or Six Sigma to deliver a result | Inflated form of F8 | F8's quote at its own scope: green belt certified. D2's slot asks only where you have applied it |

## Sources

Provided documents: the job description text and your background summary, both in your message. No CV file and no interviewer information were provided.

Searches sent, all refused ("refused" means the call returned nothing):
- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics news strategy` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Search was refused. Would have fed a values cheat sheet and CO questions; neither is in this pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | Search was refused. Would have set the loop and persona weights; the weights are flat and no values-style round is assumed |
| 3. `Atlas Freight strategy` / recent news | unavailable | Search was refused. Would have fed CO questions and a grounding brief; A5's company part is left for you |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type, who you are meeting, and anything the recruiter said about focus areas → persona weights recomputed, and any announced deliverable gets its own build section
- The interviewer's name and title → an interviewer read and a reverse question tied to their own path
- Search access, or Atlas Freight's careers and values pages pasted in → a values cheat sheet if a values round is shown, current company facts for CO questions, and the loop structure
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), once search is available → a strategy brief and role-family loop reports for CO and CASE questions
- Your answers to the slots in A1, A2, A4 and C3 (how many years you led people, any earlier larger team, any terminal work, any on-time or cost tracking) → rows F1, F2, F3, F4 and F7 move from discovery or transferability toward grounded evidence
- The green belt certificate → F8 moves from medium to high
- A sample of a report you built in Excel → F5 moves from low toward medium
- The report or sheet where the mis-pick rate was tracked → C1 and C2 can use the real counting method, and F3 moves from low toward medium
- Your prep hours available before next week → a prioritized prep schedule
- A tuesday-dossier.md from an earlier evidence pass, if you have one → verified evidence and a stricter prohibited-claims list; this pack does not need it
