I'll read the reference files the skill points to before building the pack.
Your prep pack for all three rounds is saved. I built it in loop mode: one fit snapshot shared across the rounds, then a separate bank, persona table and reverse questions for each round.

I assumed your role description is the whole job description and your four sentences are the whole of your background.

- **Research didn't run.** My three web searches were refused, so nothing in the pack comes from Larkfield's own materials. There is no values cheat sheet, and no question is grounded in their strategy. The Monday values themes come from the recruiter's description and standard values prompts.
- **No interviewer reads.** You didn't give names, so Thursday's personas are assigned by role (staff engineers, product manager) and not by person.
- **Most likely objection (T-A2).** You've never owned a hardware-adjacent roadmap, and the role partners with hardware on the roadmap. T-A2 rehearses that answer at three levels of follow-up.
- **Your numbers will get probed.** The 60% on-call drop and the 40 interviews each have a defend-the-number question. The pack never supplies how they were counted.
- **Never managed managers.** The role description doesn't say whether the squads have leads who report to you. I put that in as a question for the Director (T-R1) so you find out without volunteering the gap.

The pack covers 29 questions across the three rounds, plus six reverse questions per round. It also has a requirement-coverage table, a list of claims it won't coach, and the sources.

Files are in `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-6-denied-21a45772/dad89f56-71c5-4948-abf4-a1ce00f041fb/scratchpad/`:
- `larkfield-systems_engineering-manager_interview_pack.md`

Say the word and I'll play the Director on T-A2, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter say anything about Thursday's panel or Monday's round beyond what you've told me, such as a case, a presentation or specific topics? A declared deliverable would get its own build section.
Can you paste the full job description and your CV? Without them the pack runs on your short summaries, and several rows would upgrade to quotes from the real text.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Mode: loop — three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (name not given) | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager (names not given) | 60 min | Panel |
| 3 | The following Monday | VP Engineering (name not given) | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

Built on one assumption: the role description you gave is the whole job description, and your four sentences are the whole of your background. Every row below says which.

## How to use this pack

- Personas describe how a question arrives; types describe what is scored. Each round has its own persona table, so you meet each style on purpose.
- Types: VAL (behavioral or values alignment), EXP (work-experience deep-dive), JD (role or job-description driven), CO (company and strategy knowledge), CASE (hypothetical or live problem).
- IDs carry the round: T for Tuesday, P for Thursday's panel, M for Monday. Letters are personas within a round.
- Guidance is scaffolding, not a script. Where it quotes you, the quote is the ceiling: say what the sentence says and no more.
- An answer slot is an instruction for the interview, not a question for you now. Each has two honest branches: you did it and can say how, or there was no such step or it was not yours and you say so plainly.
- Highest-ROI prep in the whole pack: T-A2. It will be asked in some form, and a rehearsed, non-defensive answer changes the Tuesday conversation.
- Rehearse in round order. The reverse questions for each round sit with that round.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description you gave me. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — your role description | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | A team lead of 6 is adjacent to two squads and does not reach it. Words stay at the quote's scope: nine years in engineering, three of them as a team lead of 6, after checking what the 3 counts. Answer slot: the two squads make a scale probe likely. If any part of those years went beyond your team of 6, say what and which part was yours; if none did, say so plainly and stay with the team you led |
| F2 | "building device-management services" — your role description | "currently at a payments company" — your message | low | [grounded] | discovery | The quote gives your current domain and does not show whether any of your work touched devices. Answer slot: the device-management line makes a probe on the nearest thing you have built likely. If any service you worked on handled devices or fleets, say what and your part; if none did, say so plainly and stay with how you would get up to speed |
| F3 | "own delivery" — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence says you pushed a reliability quarter through, which is adjacent to owning delivery and does not reach it. Words: "I pushed a reliability quarter through." Answer slot: if delivery commitments for your team were yours to make, say how you made them; if they were set elsewhere, or not tracked that way, say so plainly and stay with the quarter |
| F4 | "own delivery, hiring and growth for 11 engineers" — your role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote already speaks to hiring in role-relevant terms, so lead with it in its own terms: you run the loop for backend roles. It is a figure with nothing inspected behind it, so expect a probe on what the 40 counts and which interviews were yours. Keep "about" |
| F5 | "growth for 11 engineers" — your role description | none given | none | [grounded] | discovery | Your material does not show whether engineers' growth was yours to own. Answer slot: if you have been responsible for an engineer's growth, say who or what and which part was yours, in your own words; if you have not, say so plainly and say what you would do first. M-A3 is a selection scaffold for it |
| F6 | "partner with hardware and product on roadmap" — your role description | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your own sentence is a stated negative on owning, so the plain words are yours: "I've never owned a hardware-adjacent roadmap." The requirement says partner, and your material is silent on that. Answer slot: if you have worked alongside a hardware team on anything, say what and which part was yours; if you have not, or it was not yours, say so plainly and give the plan as a plan |
| F7 | "partner with hardware and product on roadmap" — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a roadmap conversation at its own scope and does not say who the pressure came from. Words stay at "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you can say who held the other side and what moved, in your own words, do; if the pressure did not come from product, or there was no negotiation, say so plainly |
| F8 | Managing managers — the role description does not say whether the two squads have leads reporting to this role | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [generic] | capability | A gap wording cannot close, and you stated it. Words: "I've never managed managers." Then how you would learn it, said as a plan and never as a past. The description does not say this is required, so T-A3 and the first reverse question for Tuesday find out |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| F1 Lead two squads | T-A4, T-A3, T-B3, M-B1 | |
| F2 Device-management services | T-A1, T-B1, P-B3 | CASE-led; no quote carries domain experience |
| F3 Own delivery | T-B1, T-B2, T-B3, M-D1, P-C1 | |
| F4 Hiring | T-C2, P-B2, M-A4 | |
| F5 Growth | M-A3, T-B3 | Selection scaffold; no quote |
| F6 Partner with hardware | T-A1, T-A2, T-B1, P-D1 | T-A2 is the deepest rehearsal |
| F7 Partner with product | T-B2, P-A4, P-D1 | |
| F8 Managing managers | T-A3, M-B1, M-B2 | |
| Headline figure: on-call burden dropped 60% | T-C1, P-B1 | Defend-the-number |
| Headline figure: about 40 interviews | T-C2 | Defend-the-number |

---

# Round 1 — Tuesday: Director of Engineering, hiring manager (45 min)

## Persona table

Loop source: your message (who runs the round and its length). No interviewer name, so weights rest on the relationship prior alone.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of domain, hardware, and people-management gaps | Highest. The hiring-manager prior is Case/Strategist plus Skeptic, and F2, F6 and F8 are rows where your material shows no evidence. The person is your would-be boss, so they are pricing risk | Rehearse T-A2 until it is boring. Say the stated negative plainly, then a plan in the future tense. Never move from a plan into a past you did not state |
| Case/Strategist | Live problems from the two squads' roadmap | High. Same prior, and the role description's roadmap line invites planning problems | Clarify, then objective, options, who you would talk to, metrics, risks. Think aloud and challenge one premise respectfully |
| Data-Driven Prober | Defend-the-number on the two figures | Medium. F3 and F4 each carry a figure, and a 45-minute round has room for two probes | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Conversational | The opening "walk me through your journey" | Lower weight but near-certain as an opener. It is still scored | A 90-second arc built only from your quoted sentences, ending on your own reason for the role |
| Values/Behavioral, Pressure, Peer | Not banked for this round | Low. The prior for this relationship does not include them, and Monday carries the values and pressure weight | Covered in rounds 2 and 3 |

## Question bank — Skeptic (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "You're at a payments company today. Which part of this role would you be weakest at on day one?" | JD | [grounded] "currently at a payments company" "I've never managed managers and never owned a hardware-adjacent roadmap" | Name the weakest part first, before they do, in your own words. The sentence your material gives you is "I've never owned a hardware-adjacent roadmap" (or the people-management half of the same sentence). Say it plainly with no softener, then give the plan in the future tense: who you would sit with first and what you would ask them. Answer slot: the device-management line makes a follow-up on the nearest thing you have built likely. If anything you worked on touched devices or fleets, say what and your part; if nothing did, say so plainly and stay with how you would get up to speed | F2, F6 and F8 are the three rows with the least evidence, and "weakest on day one" is the Skeptic's stem. JD because it scores the stated requirements, including their gaps |
| T-A2 | "You've never owned a hardware-adjacent roadmap, and this role partners with hardware on the roadmap. How do you handle that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Highest-ROI rehearsal. Level 1: "I've never owned a hardware-adjacent roadmap." Say it and hold; make no claim to hardware work. The limit, named before they press: your material says owned, not partnered, so the next question is whether you have worked alongside hardware at all. Answer slot: if you have worked alongside a hardware team on anything, say what and which part was yours; if you have not, or it was not yours, say so plainly. Level 2, "partnering isn't owning, so what do you do differently?": the one roadmap conversation your material carries is "I pushed a reliability quarter through against roadmap pressure". Tell it at that scope and say plainly whether hardware figured in it. Level 3, "what will you get wrong in your first 90 days?": concede one specific thing you do not yet know, in your own words, then give the plan: who you would sit with first. Never turn partner into run | F6 is where the role presses hardest against the stated negative and F7 is the only adjacent quote, so this objection arrives in some form. JD because it scores the roadmap-partnership line; Skeptic because it is aimed at the gap |
| T-A3 | "You've never managed managers. If one of these squads has a lead who reports to you, how would you run that relationship?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Say it plainly: "I've never managed managers." Then structure the hypothetical aloud, as "I would" and never as a past: what you would ask the Director first about how each squad is led, what you would expect from a lead, how often you would talk and about what, and where you would stay out. Do not describe managing a lead, because your material carries none | F8 is a gap you stated, and the role description does not say it is required. The question is a hypothetical, so it scores structure; JD because it tests the stated leadership line |
| T-A4 | "You were a team lead of 6. Here it's eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Tell it as the sentence says: nine years in engineering, three as a team lead of 6, after confirming what the 3 counts. Answer slot: the two squads and eleven engineers make a scale probe likely. If any part of those years went beyond your team of 6, say what and which part was yours; if none did, say so plainly and stay with the team you led. Then what you would do differently, as a plan in your own words | F1 is adjacent evidence for the scale the role asks. JD because it scores the stated team size |

## Question bank — Case/Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-B1 | "A hardware partner tells you a firmware release will slip six weeks, and one of your squads has committed to a feature that depends on it. Walk me through your next two weeks." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: how firm the slip is, who else depends on it, who the commitment was made to. Then the objective, the options you see, the order you would talk to people and what you would tell each, the measure you would watch, and the risk you would carry. Think aloud and challenge one premise respectfully | The roadmap-partnership line in F6 and the delivery line in F3 both reduce to this situation, asked as a decision. CASE because it scores structure; the scenario is a pattern, not a fact about this employer |
| T-B2 | "Product wants a new capability this quarter, and on-call load on your squads is already climbing. How do you decide, and who do you talk to?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it: what you need to know, how you would weigh the capability against the load, who is in the conversation, what you would put in front of them. If you reach for your own quarter, keep to the sentence: "I pushed a reliability quarter through against roadmap pressure". Answer slot: the product-partnership line makes a probe on how that conversation went likely. If you can say who pressed and what was agreed, in your own words, do; if the pressure did not come from product, or there was nothing to negotiate, say so plainly and answer as a plan | F7 is the nearest adjacent evidence, and F3 is the delivery line. CASE with JD content because the situation comes straight from the role |
| T-B3 | "You've just taken over two squads and eleven engineers. What do you do in your first 90 days?" | CASE | [generic] | No claim about your past. Say what you would want from the Director before day one, then a sequence in your own words: what you would learn first, what you would leave alone, what you would commit to by day 30, 60 and 90. Name the measure you would pick if you have one; the pack does not pick it for you | F1, F3, F4 and F5 are the role's four ownership lines, and a first-90-days question touches all four. CASE because it scores sequencing |

## Question bank — Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-C1 | "Your on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Say "after", as your sentence does, and do not upgrade it to "because of me" unless you can defend the link. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do. The pack supplies no method, baseline or measure | F7 and F3 both rest on this figure, so a prober starts here. EXP because it tests whether the claim survives scrutiny |
| T-C2 | "You mention running the hiring loop and about 40 interviews last year. How was that counted, and which of them were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Keep the sentence's own scope: you run the hiring loop for backend roles, and the figure is "about 40". Defend-the-number, in your own words: what the 40 counts, what it is sensitive to, the assumption you would defend least, and which interviews you held yourself. Say plainly if you do not know. Do not turn "about 40 interviews" into "I conducted 40 interviews" unless that is true | F4 carries a figure with nothing inspected behind it, which is exactly where a prober digs. EXP because it tests attribution |

## Question bank — Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-D1 | "So — walk me through the journey. How did you get from where you are to wanting an engineering manager role here?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" "currently at a payments company" | A 90-second arc with the beats your sentences state: nine years in engineering, three as a team lead of 6, currently at a payments company. End on why this role, in your own words; the pack has no source for your reasons and writes none. Keep it under 90 seconds | The opener is nearly certain and is scored for economy and genuine interest. F1 and F2 supply the beats. EXP because it tests the story's coherence |

## Reverse questions — Tuesday

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "Do the two squads each have a lead who would report to me, or would I work directly with all eleven engineers?" | It finds out whether F8 matters here, and it reads as diligence rather than as volunteering a gap |
| T-R2 | "How do hardware and software priorities get traded against each other on the roadmap today, and where do the squads sit in that?" | It shows you are aiming at the hardware seam, which is the part of the role you have least evidence for, and it gives you something real to learn |
| T-R3 | "What would good look like for these two squads at six months, and how would you and I know?" | It turns the hiring manager into a collaborator on the outcome and gives you the measure they will use on you |
| T-R4 | "How are on-call and reliability work protected from roadmap pressure here today?" | It ties to your own reliability sentence without claiming anything about it, and it tells you whether the next quarter looks like the last |
| T-R5 | "What is the biggest risk to these squads' delivery that you would want me to have an opinion on early?" | It invites the manager to name their real worry, which tells you what to emphasise on Thursday and Monday |
| T-R6 | "What would make you say, in six months, that the hire worked?" | It converts an interrogation into an agreement about success, and the answer is a free preview of how they will judge your gaps |

---

# Round 2 — Thursday: panel of two staff engineers and a product manager (60 min)

## Persona table

Loop source: your message (panel composition and length). Names are not given, so personas are assigned by role, which is a generic inference, and the interviewer read is absent.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from us", credit, disagreement | Highest. The panel blend takes each member's top two personas: staff engineers, who would work under or beside you, and a product manager at the seam, all pull toward partnership fit | Reciprocity first: what you bring them, then what you need. Offer seam principles rather than pretending to know their seam |
| Data-Driven Prober | Attribution and counting probes from the staff engineers | High. Staff engineers read a manager's claims for technical substance, and F3 and F4 each carry a figure | Hold the sentences' scope, name the weakest assumption yourself, and say plainly where your knowledge ends |
| Values/Behavioral | Scenario prompts from the product manager | Medium. A cross-functional interviewer's prior is Values/Behavioral plus Conversational. Published values are not in hand, so the themes come from the role description and the persona stems | A story only where a quoted sentence carries one, a selection scaffold ending in its honest branch where none does |
| Case/Strategist | One roadmap-planning problem | Low to medium. The product manager's roadmap line from the role description invites one. It takes the slot a Conversational weight would have taken, which shows up inside the other personas anyway | Clarify, objective, options, trade-offs made visible, one premise challenged |
| Skeptic, Pressure | Not banked as separate styles | Low. The prior for a panel does not include them. The Skeptic material returns in collegial packaging inside Peer questions | Covered by T-A2 and M-B1 |

## Question bank — Peer Evaluator (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-A1 | "A staff engineer on one of your squads and you disagree on the technical direction. Where does your call end and theirs begin?" | CASE | [generic] | No claim about your past. Offer a principle in your own words for where a manager's call ends and an engineer's begins, say what you would want to know about how decisions are made here, and end on what you would bring them. Do not pretend to know the seam | The Peer stem is "where is the seam, and what happens when we disagree". CASE because it is a live problem with no claim about your past |
| P-A2 | "Tell me about a time work spanned more than one team. How was credit handled?" | VAL | [generic] | Selection scaffold: pick a piece of work that crossed teams, say "we" for context and "I" for your contribution, name what someone else got credit for, and say where it ended with the relationships intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The credit probe is a Peer stem. No quoted sentence carries a cross-team story, so this is a scaffold, not a story map |
| P-A3 | "What would you want from the staff engineers in your first month, and what would they get from you?" | VAL | [generic] | Reciprocity framing: lead with what they would get from you, then what you need. Principles in your own words; claim nothing you have not done | A panel of peers prices what the hire costs and contributes to their work. VAL because it scores partnership fit |
| P-A4 | "Tell me about a time you and product disagreed on priorities." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | If the reliability quarter is the time, tell it at its scope: "I pushed a reliability quarter through against roadmap pressure". Answer slot: if you can say who held the other side, what moved on each side and which part was yours, in your own words, do; if the pressure did not come from product, or there was no disagreement you can describe, say so plainly, then pick the nearest time you can speak to, with a named stake, a move on each side and the relationship intact, or say how you would handle it | The role description's product-partnership line raises this theme, and F7 is the only adjacent quote. EXP because it tests what was actually yours |

## Question bank — Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-B1 | "Your on-call burden dropped 60% after that quarter. Which part of that was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The part your sentence states is the pushing: "I pushed a reliability quarter through". Answer slot: if you chose what the quarter contained, or did any of the work in it, say which, in your own words; if the contents were set or done by others, or you cannot say, say so plainly and stay with the pushing. Name the assumption in the figure you would defend least, or say you do not know how it was counted | Staff engineers go below the headline, and the same figure may meet you twice across the loop. F7 and F3 rest on it. EXP because it scores attribution |
| P-B2 | "What is your hiring bar for a backend engineer, and how do you calibrate it across interviewers?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The sentence you can stand on is "I run our hiring loop for backend roles". Answer slot: the role description says hiring is yours here, so a probe on the bar and on calibration is likely. If you set or calibrated the bar, say how, in your own words; if it was set by someone else, or there was no calibration step, say so plainly and stay with running the loop | F4 is your strongest row, and staff engineers care about who joins their team. JD because it scores the hiring line |
| P-B3 | "A senior engineer brings you a design for how devices enrol and update. What do you ask them?" | CASE | [generic] | Clarify first, then the questions a manager can ask without owning the design: what problem it solves, how it fails, how it is rolled back, who is paged, and what it depends on. Say where your knowledge ends. Answer slot: the device-management line makes a probe on the nearest thing you have built likely. If any service you worked on touched devices or fleets, say what and your part; if none did, say so plainly and stay with how you would review the design | F2 is the thinnest row for the engineers who will judge your technical credibility. CASE because it is a live review |

## Question bank — Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-C1 | "Tell me about a time you had to tell a partner that a commitment would not hold." | VAL | [generic] | Selection scaffold: pick a time with a named commitment, a partner who depended on it, what you said and when, and the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The delivery and partner lines in the role description raise this theme. No quote carries a story, so it is a scaffold |
| P-C2 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Selection scaffold: a named customer need, an internal metric that pulled the other way, what you decided, who disagreed and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard Values stem, and the product manager is the person most likely to ask it. No quote carries a story |

## Question bank — Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-D1 | "Product, hardware and you are in a planning room and everyone wants their commitment first. How would you run that cycle?" | CASE | [generic] | No claim about your past. Clarify what the shared goal is before accepting that everyone wants first, then the criteria you would use, how you would make trade-offs visible, and what you would want to learn about how this company's cycle works. Challenge one premise respectfully | F6 and F7 together are the role's roadmap-partnership line, asked as a process. CASE because it scores structure |

## Reverse questions — Thursday

| # | Question | Why it lands |
|---|---|---|
| P-R1 | "What could a new manager do in their first month that would genuinely help your team?" | The reciprocity question for a peer panel: it asks what you can give before what you need |
| P-R2 | "What would you most want a new manager of these squads to leave alone, and what would you want them to push on?" | It signals respect for the engineers' judgment and surfaces the seam you would otherwise guess at |
| P-R3 | "When a technical direction is contested, how does it get settled here?" | It tests the decision rights the P-A1 answer rests on, and it is a question only someone expecting to work there asks |
| P-R4 | "Where do product and hardware roadmaps conflict most today, and how is that resolved?" | It addresses the product manager directly on the F6 and F7 lines and gives you the real seam to learn |
| P-R5 | "What is the on-call experience like for the squads today?" | It ties to your reliability sentence without claiming anything, and the staff engineers know the answer first-hand |
| P-R6 | "What is one decision from the last year you would make differently?" | It invites candour from the panel and tells you how this team handles being wrong |

---

# Round 3 — Monday: VP Engineering (30 min), "values and leadership philosophy"

## Persona table

Loop source: your message, including the recruiter's description of this round. That description documents a values-style round, so Values/Behavioral is guaranteed here. The company's published values are not in hand, so there is no values cheat sheet, and the themes come from the recruiter's words, the role description and the persona stems.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts and "what is your philosophy" | Highest. The recruiter's description names it directly, and the cross-functional and values prior is Values/Behavioral plus Conversational | Map a story only where a quoted sentence carries one; "we" for context and "I" for contribution; pick stories where the hard truth landed, and say so where your material does not show it |
| Pressure | Time-boxed challenges on the gaps | Medium. The skip-level prior is Case/Strategist plus Pressure, and 30 minutes forces time-boxing. F8 is the obvious target | Pause, restate, hold through two follow-ups, concede one specific thing, never fold the core |
| Conversational | Motivation and "what kind of leader" | Medium. A values round runs conversationally, and the casual register is still scored | Pre-script a 90-second arc and a real answer to why this company |
| Case/Strategist | One altitude-level problem | Low. The skip-level prior includes it, but the recruiter's description says values, not strategy | Clarify, structure, say how you would decide and what you would tell the VP |

## Question bank — Values/Behavioral (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-A1 | "What is your leadership philosophy?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pick two or three principles you actually act on, in your own words; the pack writes none for you. Each gets one thing you did that the VP can check, and your material carries three sentences to choose among: the team lead of 6, the hiring loop, the reliability quarter. Describe what you did and let the VP draw the inference, because an inference you assert for yourself is the one that gets tested. Answer slot: if a principle has nothing behind it yet, say it as what you aim to do and not as something you have done | The recruiter's description names this round's subject. F1, F3 and F4 are the sentences you can point at. VAL because it scores whether behaviour matches stated philosophy |
| M-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pick one where the hard truth actually landed. If the reliability quarter is the one, tell it at its scope: "I pushed a reliability quarter through against roadmap pressure". Answer slot: whether leadership took the point and what changed, in your own words, if you can say; if the quarter was not that, or you cannot say how it landed, say so plainly, then pick the nearest time you can speak to, or say how you would deliver it | The standard Values stem, and F7 is the only quote that comes near it. VAL because it scores whether a hard truth landed, and the pack does not supply the ending |
| M-A3 | "Tell me about a time you helped an engineer grow." | VAL | [generic] | Selection scaffold: pick a specific engineer, what they needed, what you did and what they did, and an outcome that is theirs to claim. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role description names growth for eleven engineers, and F5 is the row with no quote. A scaffold with its honest branch is the only safe form |
| M-A4 | "Tell me about a time a hire did not turn out the way you expected." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | The sentence carries only that you run the hiring loop for backend roles, and the figure is "about 40". Pick the time you can speak to, say what you learned in your own words, and keep your part exact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role description names hiring, and F4 is your strongest row, so a values interviewer tests it with a hard case. VAL because it scores what you learned |

## Question bank — Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-B1 | "Sixty seconds: why should we trust you with eleven engineers when you've never managed managers?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" "I've never managed managers and never owned a hardware-adjacent roadmap" | Pause and restate. Hold what the sentences carry: nine years in engineering, three as a team lead of 6, and "I've never managed managers." The limit, named before they press: your material gives a team of 6, not eleven. Follow-up 1, "so we are taking a risk": hold by returning to the team of 6, never by adding to it. Follow-up 2, "what would you do differently from someone who has?": concede one specific thing in your own words, then give the plan as "I would" | F8 is a stated negative, and F1 is the adjacent quote. VAL with JD content because a VP tests judgement about people and the role's size |
| M-B2 | "Imagine another finalist has managed managers and owned a hardware-adjacent roadmap. Sixty seconds: why you?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Concede plainly that the other finalist has what you have not, in your own words, and make no claim of equivalence. Hold on two or three things you can name from your own sentences: the hiring loop you run, the reliability quarter you pushed through, the team you led. No superlatives; let the VP draw the comparison | F8 and F6 are the stated negatives, so the comparison is the natural pressure question. VAL because it scores composure and honest self-assessment |

## Question bank — Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-C1 | "What drew you to industrial IoT, and to Larkfield?" | CO | [generic] | The pack could not research Larkfield (see Sources), so it supplies no company fact. Your answer needs your own reason. One sentence grounded in something you have read about them, with where you read it, beats any generic line. If you have not read anything yet, say what you are curious about instead | A values conversation opens on motivation. CO because it tests homework, and `[generic]` because research did not run |
| M-C2 | "A year from now, what do you want the engineers on your squads to say about working for you?" | VAL | [generic] | State one or two things you actually aim for, as aims and not as achievements, each with one concrete thing you would do. No claim about your past | It is the philosophy question in a casual register, so it is scored. VAL because it tests whether the aims match the leadership philosophy |

## Question bank — Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-D1 | "You inherit two squads: one is behind on delivery, the other is stretched thin by on-call. Where do you spend your first month?" | CASE | [generic] | No claim about your past. Clarify what you would ask the Director and the engineers first, then the criteria for where time goes, what you would not do yet, and what you would tell the VP about it. Say your reasoning aloud and challenge one premise respectfully | F3 and F5 meet in a decision about where a manager's attention goes. CASE because it scores altitude and reasoning |

## Reverse questions — Monday

| # | Question | Why it lands |
|---|---|---|
| M-R1 | "What does the engineering org need its managers to be able to do in the next year that it did not need two years ago?" | It meets a VP at their altitude and tells you what leadership means here |
| M-R2 | "What has separated your strongest managers here from those who struggled?" | It asks for the VP's own philosophy, which is the round's subject, and it hands you what to emphasise next |
| M-R3 | "How do you think about balancing reliability against roadmap commitments at your level?" | It ties to your reliability sentence without claiming anything and invites the VP's real stance |
| M-R4 | "How does Larkfield develop its engineering managers?" | It signals appetite for growth from a candidate who has not managed managers, and it is a real question about your path |
| M-R5 | "What would you want me to have worked out by the end of my first 90 days?" | It converts the values conversation into a shared outcome |
| M-R6 | "Where do you see the relationship between hardware and software engineering heading, and what would you want a manager here to prepare for?" | It addresses the one area of the role you have least evidence for, from the person who sets the direction |

---

# Claims this pack will not coach

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or led leads | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never managed managers." Then a plan in the future tense. No answer slot |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never owned a hardware-adjacent roadmap." T-A2's slot asks only about working alongside a hardware team, never about owning |
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material gives a team lead of 6, not two squads or eleven |
| Owned delivery for the squads | Inflated form of F3 | F3's quote at its own scope: "I pushed a reliability quarter through." The limit is the pack's observation: the sentence says pushed, not owned delivery commitments |
| The reliability quarter caused the 60% drop | Inflated form of F3 | F3's quote at its own scope, which says "after". The limit is the pack's observation: the sentence gives order, not cause |
| Partnered with product on the roadmap | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the sentence says "roadmap pressure" and does not say who it came from. P-A4's slot asks who held the other side |
| Held about 40 interviews yourself, or made the hiring decisions | Inflated form of F4 | F4's quote at its own scope: you run the hiring loop for backend roles, and the figure is "about 40 interviews". The limit is the pack's observation: the sentence does not say who held the interviews or who decided |

# Sources

Provided documents: your message — the role description, the three rounds and who runs each, the recruiter's description of Monday's round, and your four sentences of background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Every call was refused. It would have moved the values cheat sheet, which is absent, and the VAL themes for Monday, which now come from the recruiter's words and the persona stems |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Every call was refused. It would have moved whether a published loop differs from the one you described and which round formats are documented. Persona weights follow your own description of the three rounds |
| 3. Larkfield Systems strategy and recent news | unavailable | Every call was refused. It would have moved a CO or CASE question grounded in current strategy. M-C1 is `[generic]` for that reason and no question is grounded in company strategy |
| 4. Interviewer names at Larkfield Systems | n/a | No names were given, so there was no query to form. The interviewer read is absent |
| 5. Representative Engineering Manager job description | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

# Upgrade menu

- The names of the Director, the two staff engineers, the product manager and the VP → an interviewer read for each, persona weights assigned per panel member instead of by role, and reverse questions tied to their public paths
- The full job description text → the eight fit-snapshot rows quote its own words instead of your summary, F8 can be sourced or dropped depending on whether it says the squads have leads, and the coverage table gets checked against the real requirement list
- Your CV → evidence cells quote CV lines as well as your message, and the questions that now rest on a single sentence can rest on more
- The paging report or on-call dashboard behind the 60% figure → T-C1 and P-B1 can move from `medium` to `high` confidence, because the number could be inspected
- Your hiring loop's interview scorecard or rubric → P-B2 and T-C2 can move from `medium` to `high` confidence
- Your own answers, in your own words, to the answer slots: whether you have worked alongside a hardware team, whether any service you worked on touched devices or fleets, whether you have been responsible for an engineer's growth, and whether the pressure in your reliability quarter came from product → F2, F5, F6 and F7 regenerate from them
- The recruiter's prep email for Thursday and Monday → any declared case, presentation or topic list gets its own build section, and Monday's round can be confirmed as values-style
- Search access, or the Larkfield values and careers pages pasted in → a values cheat sheet mapping each published value to your quoted stories, and a documented loop to check your round descriptions against
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, covering a strategy brief, interviewer talks and writing, role-family loop reports and recent organisation context, which would turn M-C1 and the CASE questions from generic to grounded in current strategy
- A `tuesday-dossier.md` from an earlier underwriting pass, if you have one → verified evidence with its own confidence bands, a named highest-objection rehearsal, and binding prohibited claims
