Here is the ledger. Nothing is applied until you approve specific rows. I worked from the resume lines you pasted, so every "current line" below is quoted from your message, not from your document. If your real resume words things differently, send it and I'll re-quote.

Tailoring can only reorder and surface what you wrote. It will not make this read as 3+ years of data engineering (R1 below), and I haven't tried to. Whether to apply with that must-have gap is job-underwriter's question, not this skill's.

I've dropped the first-person "I" in the proposed lines, which is normal resume voice and changes no claim.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your resume lines | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to the first bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the second bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to our nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis: pandas" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E7 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Some scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E8 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | *(unchanged, moved below the modelling, dbt, and scripting bullets)* | `reorder` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` | pending your approval |

- **E4 and E5** split the nightly-job line so the tests stand on their own. The sentence says you fixed the job and added tests. It doesn't say you owned or built it, so neither row does.
- **E7** keeps "some". That qualifier is the honest part, and dropping it would be a scope change. C2 below is how it could legitimately get stronger.
- **Not proposed:** a retitle. "Senior Data Analyst" stays as it is.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Five years as an analyst, with adjacent work in E1–E5. Nothing states data-engineering duties or a data-engineering role. See C1. | `[grounded]` your lines say analyst and "then-DE" |
| R2 | Production Python | important | `not_evidenced` | E7 surfaces the cron scripts. Nothing says they run in production, so the word stays out. See C2. | `[grounded]` |
| R3 | Airflow or equivalent orchestration | important | `not_evidenced` | You wrote "Never used Airflow". The nightly dbt job and the cron are adjacent, but nothing names a scheduler. See C3. | `[grounded]` |
| R4 | Dimensional modelling | important | `surfaced_by_edit` | E1 and E2, for the orders-mart star schema. | `[grounded]` |
| R5 | Data quality | important | `surfaced_by_edit` | E5, tests only. Owning data quality is not what the line says. | `[grounded]` |
| R6 | SLAs | important | `not_evidenced` | No delivery-time or freshness commitment appears. See C4. | `[grounded]` |
| R7 | Build and own batch pipelines | important | `not_evidenced` | E4 shows fixing the nightly job, not building or owning it. | `[grounded]` |
| R8 | Partner with analytics on requirements | important | `not_evidenced` | You sit on the analytics side, and the one partnership you describe is with the then-DE. | `[grounded]` |
| R9 | Spark (named in the duties, not the requirements list) | preferred | `not_evidenced` | Named absence. See below. | `[grounded]` you wrote "Never used Airflow or Spark" |
| R10 | Streaming experience, Kafka | preferred | `not_evidenced` | Named absence. See below. | `[grounded]` you wrote "Never touched Kafka" |

## Gap handling

**Recall prompts:**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years of analytics work with dbt modelling, a nightly-job fix, and added tests. It doesn't show data-engineering duties or hours. | The JD calls this a must-have. Application forms often ask for years of experience in a yes/no field, and the resume can't change that answer. | Backfills you ran; schema or source changes you handled; a source or pipeline you were the named owner of; requirements you gathered for the orders mart | A pipeline or lineage doc, a PR history, a ticket trail | `[grounded]` what the resume does and does not say; `[generic]` forms often carry eligibility checks (cite C26) |
| C2 | Production Python | important | "Some scripting to pull vendor APIs on a cron" and pandas analysis. Nothing says who depends on the scripts or what happens when they fail. | "Production" is a specific word. Without evidence it stays out of the resume. | The scripts run unattended; others consume their output; you handle their failures or alerts; they live in a repo with review | The repo, a README, an alert history | `[grounded]` what the resume says; `[generic]` what "production" usually implies |
| C3 | Orchestration (Airflow or equivalent) | important | A nightly dbt job and a cron. Neither is described as run by a scheduler or orchestrator. | The JD names Airflow or equivalent. A named scheduler is the closest true match to "equivalent". | dbt Cloud, GitHub Actions, or another scheduler running the nightly job; job dependencies or retries you configured | A scheduler config or job list | `[grounded]` what the resume says; `[generic]` equivalence is judged on what the tool does |
| C4 | Data quality and SLAs | important | You added tests to the nightly job. The resume doesn't say what they check or who relies on the output's timing. | The JD says "own data quality and SLAs". Tests alone are narrower than that. | Tests that block a bad run; an agreed ready-by time for a mart; alerts when tests fail | The dbt test list, a freshness check, a stakeholder agreement | `[grounded]` what the resume says; `[generic]` what the duty typically covers |

**Named absences:**
- **Spark, streaming and Kafka (R9, R10):** you have none of these, and the JD lists streaming only as a plus. Closing it would take a small hands-on project, for example consuming a Kafka topic into a table. Until you've done it, it doesn't belong in the resume, not even in a skills list. For this role it's the least costly gap to carry.
- **Partnering with analytics (R8):** you've been the analytics-side stakeholder, so the relationship is reversed from what the JD describes. Closing it takes real requirements-gathering work done for someone else's reporting. If C1 turns up an example, it can become a row.

## Not written, and why

- "3+ years data engineering", or any "Data Engineer" title or descriptor. Your title is Senior Data Analyst, and the JD makes the years a must-have.
- "Owned / built batch pipelines" for the nightly dbt job. You fixed it and added tests.
- "Orchestrated pipelines" or any Airflow-equivalent claim. No scheduler is named in your material.
- "Production Python" or "production-grade scripts". You wrote "some scripting", not production use.
- "Ingestion pipelines" for the vendor-API scripts. Pulling data on a cron is not the same kind of work, and the word would raise the status of the work.
- "Owned data quality and SLAs". You added tests, and no delivery commitment appears.
- "Modelled the warehouse". You designed the star schema for one mart, with the then-DE.
- "Partnered with analytics on requirements". The JD's phrase would move you to the other side of that relationship.
- Spark, Kafka, or streaming anywhere, including a skills list.

## Parse-safety check

The resume arrived as pasted text, so I could not check multi-column layout, tables or text boxes, icons or skill bars, content in headers or footers, section headings, or file type. If you send the file, I'll run those. For file type, a `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu (proposed, built only on your say-so)

- **Your actual resume file:** lets me run the parse check and quote your exact words.
- **The dbt repo or test list, and the scheduler config:** could turn R3 and R5 into stronger rows.
- **The cron scripts' repo or README:** could answer C2.

## Questions

C1 — Is there any stretch where you did more than fix the nightly job: owned a source, ran backfills, handled schema changes, or gathered requirements for a mart?

C2–C3 — Where do the nightly dbt job and the cron scripts run (which scheduler or tool), and who depends on their output?

C4 — What do the tests you added check, and has anyone relied on a ready-by time for the data?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.