I'll read the reference files the skill points to before building the ledger.
Priya, I've built the ledger below. Nothing is applied yet, and every row waits for your approval.

I treated each sentence you pasted as a "current line", and the quotes beside each edit are your words. You pasted prose rather than a CV file, so I haven't seen your real layout or wording. Paste the file and I'll re-check each row against the actual lines.

Your bullets already run in the order the JD asks for: owned services and volume, p99, on-call, then onboarding. I didn't reorder them. The edits are small, and the gaps matter more than the edits.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Currently at a payments company, owning three services in our ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV sentences. The three claims stay as separate sentences. | pending your approval |
| E2 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year), pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV. I did not write "mentor", because you didn't. | pending your approval |
| E4 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Go, Rust, Kafka, Postgres, gRPC, Datadog, Terraform" | `merge` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV. Python is dropped from the list, since you wrote it as earlier work. | pending your approval |

The 40k requests/minute bullet and the p99 bullet (380ms to 95ms) stay exactly as you wrote them. Both already carry their numbers and qualifiers.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts "7 years" beside service ownership. The word "backend" isn't on your line, and I didn't add it. | `[grounded]` your CV |
| R2 | Production Go | must-have | `not_evidenced` | "Go … daily for 4 years" is stated (E1, E4). Which language your three services use isn't. See C1. | `[grounded]` your CV |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | The 40k requests/minute bullet shows volume. Kafka appears only in a tools list. See C2. | `[grounded]` your CV |
| R4 | Strong incident response | must-have | `already_evidenced` | The on-call and incident commander bullet as written (E2 only tightens it). | `[grounded]` your CV |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E3. Your CV says new hires, not mid-level engineers, so the match is partial. | `[grounded]` your CV |
| R6 | Own services at high request volume | important | `already_evidenced` | The 40k requests/minute bullet, unchanged. | `[grounded]` your CV |
| R7 | Design and ship services | important | `not_evidenced` | You say "own", not "design" or "build". See C1. | `[grounded]` your CV |
| R8 | Drive down p99 latency | important | `already_evidenced` | The p99 bullet, unchanged. | `[grounded]` your CV |
| R9 | Own on-call | important | `already_evidenced` | The on-call bullet (E2). | `[grounded]` your CV |
| R10 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your CV. See C3. | `[grounded]` your CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go; design and ship services (R2, R7) | must-have | "Go and Rust daily" and "own three services" are separate sentences. Nothing joins them or says whether you built the services. | Production Go is a must-have, and the join between your Go work and your services is currently left for the reader to guess. | A service you wrote in Go that is live; a Go service you inherited and substantially changed; the cache-layer rework, if it was Go. | Repo link, PR, design doc, service README | `[grounded]` what the CV says and omits; `[generic]` what an unstated join costs on applications of this kind |
| C2 | Distributed systems at scale (R3) | must-have | A 40k requests/minute service and Kafka in a tools list. It doesn't say how the services interact. | This is a must-have, and a tool in a list is not a tool owned. | Your services consuming or producing Kafka topics; handling retries, ordering or duplicate messages across services; the cache layer's behaviour under load. | Architecture diagram, design doc, postmortem | `[grounded]` what the CV says and omits; `[generic]` what a bare tools list costs on applications of this kind |
| C3 | Partnering with product on roadmap sequencing (R10) | important | Nothing. | The JD names it as a responsibility, and your CV is silent. | Agreeing with a product manager which of two projects went first; pushing back on scope or timing; helping plan a quarter. | Planning doc, roadmap ticket thread | `[grounded]` what the CV omits; `[generic]` what silence on a named responsibility costs |

If C3 has no honest answer, the gap is real. It sits at the "important" tier rather than must-have, and the other seven rows still carry your application. Closing it would take a project where you sequenced work with a product counterpart.

## Not written, and why

- **"Production Go services" or "Go services handling 40k requests/minute":** you haven't said which language those services use. Held until C1.
- **"Designed and shipped":** you said "own". Held until C1.
- **"Distributed systems", "event-driven" or "Kafka-based pipeline":** Kafka is only a list item in your CV. Held until C2.
- **"Mentored mid-level engineers":** you onboard new hires, and their seniority isn't stated. "Mentor" is also the JD's word, not yours.
- **"Partnered with product" or "drove roadmap":** there is no source for either.
- **"Senior Backend Engineer" as your title:** your title is Senior Software Engineer.
- **"Cut p99 by 75%":** this is arithmetic on your numbers, but it's a new figure you didn't write. I can propose it as its own row if you want it.
- **Dropping "about" or "at peak" from the 40k figure:** both qualifiers are yours and stay.

## Parse-safety check

You pasted text rather than a file, so I could not run any of these checks:
- multi-column layout
- tables and text boxes
- images and skill-level bars
- contact details in headers or footers
- non-standard section headings
- file type

Send the file and I'll run all six.

## Upgrade menu

- **Your CV as a file** lets me check parse risks and quote your exact lines.
- **A repo link, PR or design doc for the cache-layer rework** would back the p99 claim and answer C1.
- **An architecture diagram or postmortem** would give C2 something inspectable.
- **A planning doc or roadmap thread** would answer C3.

## Questions

C1 — Which of your three ledger-pipeline services are written in Go, and did you build them or inherit them?
C2 — How do your services interact with each other (Kafka topics, gRPC calls, shared Postgres), and where does that path break under load?
C3 — Have you decided what to build first or later together with a product manager? If so, what was the decision?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.