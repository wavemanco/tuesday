I'll read the reference files the skill points to before building the assessment.
**No, this posting isn't worth pursuing. R1 and R2, both hard gates, fail, so the status is `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin five days a week), R2 (Compensation of $70–85k base)
- `must_have`: direct: R4, R5, R6 · unclear: R3 (8+ years growth leadership)
- `important`: unclear: R7 (SEO and content), R8 (Brand and PR), R9 (Partnerships), R10 (Sales ops), R11 (Operating as a team of one)

R4, R5 and R6 are solid matches on paper, but they cannot offset R1 and R2.

**Opportunity ledger.** Your sense that something is off is borne out by the register. The posting's terms break both of your constraints (RR1, RR2). It also bundles seven functions into one seat with no team (RR3), expects always-on availability (RR4), gives no stable success definition for an all-revenue mandate (RR5), and leaves the equity unquantified (RR6). I couldn't verify the employer (RR7). The posting does state its pay and location terms plainly, so the conflicts show up before you spend any effort (RR8).

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days a week), R2 (Compensation: $70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posting's terms would have to differ on both gates. R1 would have to allow work from Portland, and R2 would need a base at or above your $150k floor. The posting says "no exceptions" on location, so that is the employer's to change. No wording on your side solves it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, described as Series A and "profitable since day one"; these descriptions are the posting's own and are unverified here | `[grounded]` posting header; RR7 for the unverified part |
| Seat | Head of Growth, reporting to the CEO with a dotted line to the board | `[grounded]` posting |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and resources | "A team of one to start"; no budget stated | `[grounded]` posting, for the team; the budget is silent |
| Working pattern | On-site in Austin five days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside", with no percentage, vesting or strike given | `[grounded]` posting |
| First-year outcomes | Not stated; "success metrics will evolve as we learn" | `[grounded]` posting |
| Scope read | Seven functions for one person is the remit of a growth department, not a single seat | `[inferred]` from the posting's own function list against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so no market band is offered for the title, scope or pay | `[grounded]` evidence status below |
| Unknowns | Marketing budget; equity terms; who the customers are, since the posting doesn't say whether e-commerce enablement is sold to businesses or consumers; who defines success | `[grounded]` posting silence |
| Contradictions | The title and mandate ("Head of", "own all revenue growth", 8+ years) sit against a $70–85k base and no team | `[inferred]` from tension between the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in our Austin office 5 days a week, "no exceptions" (your constraint: remote-only, based in Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own confirmed statement of the constraint. The fit fails because the posting rules out remote work in terms. | `[grounded]` posting and your intake message | Surface only; employer-side change only |
| R2 | Compensation: $70–85k base (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your confirmed floor. The posting's top figure is below your floor, and equity is unquantified, so it cannot be counted toward base. | `[grounded]` posting and your intake message | Surface only; employer-side change only |
| R3 | 8+ years growth leadership | must_have | unclear | low | discovery | You state 9 years in growth, working as growth lead and then Head of Growth. How many of those years were in a lead or head role is not stated, so the claim resolves downward. This is a length-of-experience requirement, not a gate. | `[grounded]` intake message; tenure split not stated | Confirm leadership-title years if the role ever clears R1 and R2 |
| R4 | Own all revenue growth end to end | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. Confirmed and specific, with no inspectable artifact yet, so expect a probe. Limit: that was a B2C subscription company, and this employer's buyer is not stated. | `[grounded]` intake message; `[inferred]` the buyer-type limit, from the posting's silence and its "sales ops" line | Offer: a sanitized ARR or channel dashboard export would raise this to high |
| R5 | Paid acquisition | must_have | direct | medium | none | You say you owned paid at both companies. Confirmed and specific, with no inspectable artifact yet. | `[grounded]` intake message | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze. Confirmed and specific, with no inspectable artifact yet. | `[grounded]` intake message | none |
| R7 | SEO/content | important | unclear | none | discovery | Your stated background does not mention SEO or content. | `[grounded]` intake message silence | See G2 |
| R8 | Brand and PR | important | unclear | none | discovery | Your stated background does not mention brand or PR. | `[grounded]` intake message silence | See G2 |
| R9 | Partnerships | important | unclear | none | discovery | Your stated background does not mention partnerships. | `[grounded]` intake message silence | See G2 |
| R10 | Sales ops | important | unclear | none | discovery | Your stated background does not mention sales ops. | `[grounded]` intake message silence | See G2 |
| R11 | Operating as a team of one | important | unclear | none | discovery | You managed teams of 3–7. Whether you executed hands-on across functions without a team is not stated. | `[grounded]` intake message; solo execution not stated | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leadership tenure (R3, must_have) | discovery | 9 years in growth is stated; the lead and head portion is not | Would settle a must-have, but R1 and R2 still decide the status | Dated titles at each company, from growth lead through to Head of Growth | A LinkedIn work history or CV with dates | `[grounded]` intake message; `[generic]` that titled years are often screened literally |
| G2 | SEO/content, brand/PR, partnerships, sales ops (R7, R8, R9, R10, important) | discovery | The background names paid, lifecycle, experimentation and analytics only | Four functions the posting bundles in; none changes the status while R1 and R2 fail | Owning an SEO programme or editorial calendar; a launch with PR; a co-marketing or affiliate deal; CRM-to-sales handoff work | Channel reports, a partnership agreement, a content calendar | `[grounded]` intake message silence |
| G3 | Solo hands-on execution (R11, important) | discovery | Team-leading is evidenced; working with no bench is not | Bears on RR3 | A period when you ran channels yourself, such as before your first hire | A role history showing the pre-team period | `[grounded]` intake message; `[inferred]` that the pre-team period may exist, from "growth lead" preceding "Head of" |

These rows carry no questions. No answer to them moves the status, so none is asked below.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (R2), against a Head-level title | red_flag | high | "$70–85k base plus meaningful equity upside" | Base pay conflicts with your floor. Whether it is also below market for the title is not established, because the sweep did not run. | `[inferred]` from the posting's title and years against its stated base | Is the stated base the full cash budget for this role? | confirmed |
| RR2 | Five on-site days, no exceptions, against remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The location term is firm by the employer's own account. | `[grounded]` posting states it | Is any remote arrangement possible for this role? | confirmed |
| RR3 | Seven functions, one person, no stated budget | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one" | Several full roles are folded into one title, with responsibility but no named resources. | `[generic]` bundled-specialization and responsibility-without-resources patterns, not a claim about this employer | What budget and first hires are committed for year one? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine and not occasional. | `[generic]` always-on-expectations pattern | In the last quarter, how many evenings or weekends did the team work? | unresolved |
| RR5 | No definition of success on an all-revenue mandate | risk_signal | medium | "Own all revenue growth… success metrics will evolve as we learn" | You may be accountable for revenue with no agreed yardstick. | `[generic]` absent-success-metrics pattern | What would make year one a success to the CEO, in numbers? | unresolved |
| RR6 | Equity unquantified | risk_signal | low | "meaningful equity upside" | The equity may be small or undefined. Severity is set at `low` because the posting may simply be leaving details for later. | `[generic]` evasive-terms pattern | What percentage, strike price and vesting schedule apply? | unresolved |
| RR7 | Employer not established | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Stage and profitability are the posting's own claims. The searches could not run, so nothing was checked. | `[generic]` standing check on unverified employers; the verification itself did not run | Can you point me to this role on your own careers site? | unresolved |
| RR8 | Pay and location terms stated plainly | positive_signal | — | "$70–85k base… no exceptions" | Explicit terms let a mismatch show up before application effort is spent. | `[grounded]` posting | Who set the base range, and is it fixed for this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't submit an application on the posting's current terms | See R1, R2, RR1, RR2 | `[grounded]` R1 and R2 rows | pending your approval |
| A2 | If you proceed anyway, ask RR1, RR2 and RR3 verbatim before any interview time is spent | The register becomes essential preparation if you go against a `no_go` | `[grounded]` register | pending your approval |
| A3 | Screen future postings on your two constraints (remote, base of at least $150k) before reading the rest | These two terms are what failed here | `[grounded]` your stated constraints | pending your approval |
| A4 | For a role that does clear both gates, lead with "scaled one of my two B2C subscription companies from $8M to $40M ARR over three years, with a budget I controlled", with the caveat that it has no inspectable artifact yet | See R4 | `[grounded]` your intake message, each clause traced to your own sentence | pending your approval |

No resume edits are proposed. This approval line covers all four rows above and the prose advice in A3 and A4.

## Evidence status

Verified: none yet. Stage assumed: evaluating.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches on "Novaline e-commerce enablement startup Series A Austin" and "Novaline Head of Growth careers Austin" were both refused for permission, and no page was read. It would have moved role reality's organization and contradictions rows and RR7. |
| 2. Role-family sweep | unavailable | The search on "Head of Growth salary Series A startup base salary 2026" was refused for permission. It would have moved the market-calibration row and RR1's below-market check. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I'm offering to build `tuesday-dossier.md` from this assessment, if you want a file you can keep.

## Upgrade menu

- Search permission, or a link to the role on Novaline's own careers page, would let me verify the employer and close RR7. It cannot change R1 or R2, so the status would stay `no_go`. If you do grant it, a deeper pass of up to 5 more searches and 2 more fetches could follow.
- A sanitized ARR or channel-performance dashboard export would raise R4, R5 and R6 from `medium` to `high` for any later role that clears your constraints.
- Dated titles for each role would resolve R3.
- Anything on SEO/content, brand/PR, partnerships, sales ops or solo execution would resolve R7, R8, R9, R10 and R11.

No questions this turn. R1 and R2 fail on terms you've already confirmed, and no answer to the open gap rows would change that.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.