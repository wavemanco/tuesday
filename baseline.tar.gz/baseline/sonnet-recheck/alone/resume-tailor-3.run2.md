I tailored your CV against Quartzline's posting and the Tuesday dossier. Nothing is applied. Every row below is a proposal until you approve it.

**Assumptions I built on:**
- **Layout:** You pasted your CV as prose, so I don't know your layout. The section names are my guesses: Summary and Experience.
- **Dossier:** Its role matches this posting, so I used it as is. Its `conditional_go` decision isn't my call, so I left it alone.
- **Confidence:** I carried the dossier's `medium` confidence on R1 and R2 over unchanged. Tailoring verifies nothing.
- **Inherited edit:** The dossier's E1 is already in the ledger below. It went through the same audit as my own rows.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (inside a longer entry) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV, and the dossier's pending edit E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged — moved to the first Experience line)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged — moved directly under the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged — kept as its own line, placed after E3)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |

- **E1:** Same sentence, so "the whole team" stays exactly as you wrote it.
- **E4:** "Comfortable in" stays. I did not turn it into "authored OpenAPI specs".
- **E5:** The three sentences stay separate. I did not join them into one claim about product work.
- **Titles:** I left your title alone. The summary says what you were, and the CV doesn't claim a PM title.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | The dossier rates this `adjacent` with a transferability gap. Integration leadership is adjacent, but roadmap ownership and prioritisation authority are not evidenced. Recovery is C1. | `[grounded]` dossier evidence_map R1, "integration leadership is adjacent; roadmap ownership and prioritisation authority not evidenced" |
| R2 | Shipped API or platform products | important | `not_evidenced` | The dossier rates this `adjacent`. You led integrations of APIs that your employer's product teams shipped. Recovery is C2. | `[grounded]` dossier evidence_map R2 and your CV |
| R3 | Technical fluency | important | `already_evidenced` | "Led 30+ client integrations of our REST APIs end to end." and "Comfortable in Postman, SQL, OpenAPI specs." E2 and E4 only move them. | `[grounded]` your CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | Client-side only, via E2 and E5. Working with engineering or internal stakeholders is not evidenced. | `[grounded]` your CV |
| R5 | Run discovery with integration partners | important | `surfaced_by_edit` | E3 and E5. Your sessions were with clients, not partners, and they collected feedback. I did not call them discovery. | `[grounded]` your CV |
| R6 | Own the roadmap for the API platform | important | `not_evidenced` | The same gap as R1. Feeding roadmap input is not owning one. Recovery is C1. | `[grounded]` dossier R1 reasoning and your CV |
| R7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Nothing in your CV says you wrote specs or worked with engineering squads. Recovery is C3. | `[grounded]` your CV |
| R8 | Define adoption metrics | important | `not_evidenced` | Named absence, below. | `[grounded]` your CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM, with roadmap and prioritisation authority (R1, R6) | must-have | You ran roadmap-input sessions that collected client feedback for product. It does not say whether you had any say in what got built or in what order. | This is the must-have, and it is the one the dossier flagged as unevidenced. | A request you pushed through to a shipped change; a ranked list you handed product that they used; a decision you made about what an integration-driven fix would include | A feedback summary, a roadmap doc with your input, a release note | `[grounded]` what your CV does and does not say; `[generic]` what an unevidenced must-have costs on applications of this kind |
| C2 | Shipped API or platform products (R2) | important | You led integrations of your employer's REST APIs. It does not say you shipped any API, tool or feature yourself. | You'd be competing against people who can say they shipped one. | A client-facing integration kit you published; an API change or doc set you specified; a sandbox or sample collection clients used | A Postman collection, a spec, a launch note | `[grounded]` what your CV does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Writing specs and driving delivery with engineering (R7) | important | Nothing in your CV mentions specs or engineering delivery. | The posting names two squads, so this is a core part of the day job. | A written requirement or ticket set engineering built from; a bug or API fix you drove through to release | A spec, a ticket set, a release note | `[grounded]` what your CV does and does not say; `[generic]` what this costs on applications of this kind |

**Named absence, adoption metrics (R8).** Your CV states no adoption measures, and the posting lists defining them as a duty. Closing it would take real numbers you already tracked, such as integrations completed or time to go live. If you never tracked any, this stays an interview conversation and not a resume line.

## Not written, and why

- **Rejected inferences (from the dossier, unaltered):**
  - "Built an internal request-triage tool" — a memory lead, and you could not confirm ownership.
  - "Has been the customer of a partner API platform" — you worked vendor-side.
- **"Product management experience", or any PM-sounding title** — you have never held one, and the 3+ years is a must-have. The gap stays in the map.
- **"Owned the roadmap" or "set product priorities"** — you ran input sessions. Collecting feedback for product is not deciding what gets built.
- **"Ran discovery with integration partners"** — the posting's words are discovery and partners. Yours are roadmap-input sessions and clients. Changing the words would change which side of the table you sat on.
- **"Shipped API products"** — you led integrations of APIs. That is a different kind of work from shipping them.
- **"Wrote specs" or "authored OpenAPI specs"** — your CV says you are comfortable in OpenAPI specs, not that you wrote them.
- **"Drove delivery with engineering"** or any adoption-metric claim — nothing in your CV supports either.

## Parse-safety check

You gave me pasted text, not a file. I could not run the checks for columns, tables, text boxes, images or skill bars, headers and footers, or file type. I also could not look for hidden text from an old template. If you send the actual file, I'll run all of them. Check these yourself for now:
- Use plain section headings: Summary, Experience, Skills.
- Don't put contact details in a header or footer.
- Send a `.docx` or a text-layer PDF.

## Upgrade menu

- **Your actual resume file:** this unlocks the parse checks and the hidden-text scan.
- **Older resume versions:** earlier versions often hold evidence the current one dropped, which could help with C1 to C3.
- **Artifacts for the `medium` rows:** a Postman collection, an OpenAPI spec you wrote, an excerpt of the playbook, or a summary from a roadmap-input session. For this field those are the inspectable proof that could raise them toward `high`.

## Questions

C1 — Did anything from your roadmap-input sessions end up shipped or reprioritised, and what was your part in that?
C2 — Did you ever publish or ship something clients used directly, such as an integration kit, sample collection, API doc set or sandbox?
C3 — Did you ever write a requirement, ticket set or spec that engineering built from? If so, what was it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.