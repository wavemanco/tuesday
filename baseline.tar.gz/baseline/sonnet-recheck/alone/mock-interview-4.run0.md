I'll read the reference files before writing anything.
Renaming the reverse-question IDs from R1–R6 to Q1–Q6, because they collide with the requirement IDs R1–R5. I'm rerunning the edit without the shell variable.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-4-denied-36e61c88/586f1249-ee26-43e6-8b03-1e29041d9b81/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, a single 45-minute conversation, and I asked you no questions because your message and the dossier covered what the pack needed. It has 20 questions across five interviewer styles, a fit snapshot, reverse questions and a prohibited-claims list.

- **Web search was refused.** I sent three Quartzline searches and none ran. The pack has no values, loop or strategy research, and the case questions are generic or built from your own confirmed evidence. The Sources section lists each search as refused.
- **Most important rehearsal:** A1 is the dossier's own objection, that you have never held the title or owned a roadmap. A2, E1 and E3 are variants of it. The pack gives you the concession wording from the dossier's `prohibited_claims`, a hold limited to your three confirmed sentences, and a ramp plan.
- **R2 (shipped API or platform products) has no grade in your dossier.** It lists R2 as a must-have but has no weak-area entry for it. I graded it myself as a `discovery` gap in F3, and A4 prepares you for the likely probe on it.
- **No duration is used anywhere.** The dossier's decision line mentions seven years, but none of your three confirmed claims states a duration.

Several answer slots (F3, F4, F6, F7) are left for you to fill in your own words. Where you didn't do the thing, say so plainly. The upgrade menu at the end of the file lists what would sharpen the pack.

I can run a live drill with me playing the Skeptic on A1, the question I'd rehearse first.
I can also save an updated `tuesday-dossier.md` recording the R2 grading gap and anything this prep exposes, so job-underwriter can verify it later.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

- Interviewer: the hiring manager (name not given). Format: one 45-minute conversation.
- Built on: your dossier's handoff and role profile, plus your note on the round. Web search was not available, so company research is absent (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and rehearse only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned aloud |

This pack has no VAL questions (no values-style round is documented anywhere in what I had) and no CO questions (company research was unavailable, so they would only be generic).

An answer slot is an instruction for the interview, not a question for you now. It says what to say if the practice was yours and what to say if it was not. Both branches are fine. Everything in the Fit snapshot, persona counter-strategies, question banks and reverse questions is proposed language, pending your approval.

## Fit snapshot — pending your approval

Origins: dossier V1, V2 and V3 are the three entries of `verified_candidate_evidence` in the order the dossier gives them. Confidence notes the dossier appends to them are not part of the quotes; they appear in the Confidence column and in the bridge.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD, dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [grounded] | transferability | The dossier's strategy is bridge, positioned as adjacent and never as PM experience. Words are the two quotes at their own scope: you led the client integrations, scoping through go-live, and you ran the quarterly sessions that fed client evidence to product. The limit is the pack's observation: your material is integration leadership and roadmap input, and it does not show the title or years in the seat. A1 rehearses this |
| F2 | "Own the roadmap for the partner-facing API platform" — JD responsibility, dossier role_profile | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area, "Owning a roadmap and prioritization authority (R1 sub-claim)", and lists `prohibited_claims`: "Having owned a product roadmap". Words, sourced by those fields: "I haven't owned a product roadmap." Then a ramp plan said as a plan and never as a past. No bridge and no slot; V3 sits under F1 and F8, and is not offered here |
| F3 | "Shipped API or platform products" — JD, dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | The dossier lists R2 as high priority but carries no weak-area entry for it, so this row is the pack's own grade. The quotes say integrations led and a playbook written; the step to shipping a product is not in them. Answer slot: the JD's R2 line makes a probe likely on whether anything you led went out as a product rather than as a client integration. If something did, say what it was and which part was yours, in your own words; if nothing did, or it was not yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — JD, dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Wrote the internal integration playbook her team uses" — dossier V2 | medium | [inferred] | discovery | The quotes name REST APIs, an architecture stage and a playbook; they do not name API docs or schemas. Answer slot: R3 names both, so a probe on them is likely. If you read or wrote either as part of that work, say how, in your own words; if not, say so plainly and stay with the REST integrations and the architecture stage |
| F5 | "Stakeholder management across engineering, sales, customers" — JD, dossier role_profile R4 (customer side) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | presentation | Reword only those quotes: the integrations were client work from scoping through go-live, and the sessions fed client evidence to product. Say it in those terms. The phrase stakeholder management is the JD's, not yours, and stays out of sentences about your past. V3 is medium in the dossier, so expect a probe |
| F6 | "Stakeholder management across engineering, sales, customers" — JD, dossier role_profile R4 (engineering and sales sides) | none given | none | [grounded] | discovery | Strong evidence here would be a named instance with an engineering or sales counterpart; your material has none. Answer slot: R4 names both sides, so expect a probe on each. If you worked with either on that work, say with whom and on what, in your own words; if not, say so plainly and stay with the customer side |
| F7 | "Agile delivery experience" — JD, dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier's strategy is clarify, and no verified entry speaks to this requirement, so there is no quote to use. Answer slot: R5 names agile delivery, so a probe is likely. If you worked inside an agile team's delivery, say what it looked like and which part was yours; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines it |
| F8 | "Run discovery with integration partners" — JD responsibility, dossier role_profile | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | The quote says sessions that fed client evidence to product; it does not say discovery, and the words stay at the quote. The dossier grades it medium: confirmed, limited inspectable proof. Volunteer that limit before a prober extracts it. No slot, because a responsibility line is not a requirement line |
| F9 | "Define and track adoption metrics" — JD responsibility, dossier role_profile | none given | none | [grounded] | discovery | Nothing in your material speaks to it. Strong evidence would be a metric you reported against, with how it was counted. No slot; B2 is a live problem that asks nothing about your past |
| F10 | "Write specs and drive delivery with two engineering squads" — JD responsibility, dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | discovery | The quote's requirements and architecture are stages of client integrations, not specs for a squad, and the words stop there. Decision authority against the two squad leads is the dossier's unverified question; Reverse Q1 asks it. No slot |

## Persona table — pending your approval

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the background mismatch and the gaps | Highest. The hiring-manager prior is Case plus Skeptic, and the dossier names a specific objection built from F1 and F2 | Rehearse the named objection until it is boring: concede what the dossier sources, hold only what the quotes carry, name the ramp as a plan | A, 5 questions |
| Case / Strategist | Live problems from the actual role: discovery, adoption, specs, squad trade-offs | High. Same hiring-manager prior; the role's duties are naturally live problems | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully | B, 5 questions |
| Conversational | Friendly walk-through and casual probes on technical fluency and working style | Medium. You described it as a conversation, so an opening biography question is likely, and casual questions are still scored | A 90-second arc built only from your quotes; treat casual questions on the JD's topics as scored | C, 4 questions |
| Data-Driven Prober | Reads the CV line by line and presses on the 30+ figure and on what was yours | Medium. The dossier's evidence leads with a headline figure, which is where a prober starts | Know what you can and cannot say about how the figure was counted; say plainly when you do not know | D, 3 questions |
| Pressure | Time-boxes, interrupts, questions motive | Lower. Nothing in my material says this round is a stress format, so it arrives as follow-ups to the Skeptic's questions rather than as a style of its own | Pause, restate, hold through two follow-ups, concede specifically | E, 3 questions |
| Peer Evaluator | Seam-splitting between teams | Low. The interviewer is the hiring manager, not a peer. The squad-lead seam is rehearsed as B3 | Propose seam principles rather than pretending to know the seam | none |
| Values / Behavioral | Stories mapped to published values | Not detected. No document I had describes a values round, and no published values are in hand | n/a | none |

The weights rest on your note that this is one 45-minute conversation with the hiring manager, plus the relationship prior. No source I read documents Quartzline's actual loop.

## Question banks — pending your approval

The highest-ROI prep in this pack is A1. The dossier's underwriter named that objection from evidence you confirmed, so it arrives in some form. A2, E1 and E3 are its variants.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | Say the limit before it is asked for, in this order. Concede, in words sourced by the two `prohibited_claims` fields: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Hold only what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live, and I ran quarterly roadmap-input sessions that fed client evidence to product." Frame it as adjacent work, never as PM experience, which is the dossier's condition. Follow-up one, what have you touched on a roadmap: return to the sessions at the quote's scope and stop. Follow-up two, that is still zero years: concede title and years again in the same words, do not argue the count, hold that the adjacent work is real. Follow-up three, why not hire the PM: give the ramp as a plan, learning which decisions sit with the PM and which with the squad leads (Reverse Q1). Describe the work and let them draw the inference; do not say it proves you can do the job | F1 is the largest gap and F2 the plainest, and the underwriter named this objection, so it is the likeliest question of the hour. JD because it scores R1; Skeptic because it presses the background mismatch |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `acknowledge_gap`: "Owning a roadmap and prioritization authority (R1 sub-claim)"; `prohibited_claims`: "Having owned a product roadmap"; `prohibited_claims`: "Having set prioritization for an engineering squad" | Name the weakness that is real and name it first. Plain words, sourced by the fields in Provenance: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a plan, said as a plan: how you would learn where roadmap decisions sit between the PM and the two squad leads, and which would be yours. Do not offer a smaller weakness to soften it. If they ask for a second one, agile delivery is next, and C4 rehearses it | F2 is the capability gap the dossier says to acknowledge, and a weakest-point question aims straight at it. JD because it asks about fit to the listed duties |
| A3 | "Walk me through the roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F8 and nothing wider. The beats the quote states are the quarterly cadence, the sessions as roadmap input, and the client evidence that went to product; tell them in your own words. The dossier grades this medium, confirmed with limited inspectable proof, so volunteer that limit yourself: say what the sessions were, and say plainly where what you can speak to stops. If a follow-up goes past the quote, say that and come back to the sessions | F8 is the evidence nearest the roadmap and the one the dossier warns will be probed. EXP because it tests what was actually yours |
| A4 | "The role asks for shipped API or platform products. Where does your experience sit against that?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Start with the two sentences at their own scope: you led the client integrations, scoping through go-live, and you wrote the internal integration playbook your team uses. Answer slot: the JD's R2 line makes a probe likely on whether anything you led went out as a product rather than as a client integration. If something did, say what it was and which part was yours, in your own words; if nothing did, or it was not yours, say so plainly and stay with the integrations. Do not call the integrations shipped products | F3 is a must-have the dossier lists as high priority without grading it, so this is the likeliest second probe. The question is open and presupposes nothing; JD because it scores R2 |
| A5 | "Why move from integration work into product, and why here, why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The reason has to be yours and specific, so the pack does not write it. Pick a moment or pattern from your own integration work that made you want to be on the product side; it needs a concrete example you can describe and a reason that points toward this role rather than away from the last one. If no such moment comes to mind, say so plainly, then give the nearest thing your material does carry: you ran quarterly roadmap-input sessions feeding client evidence to product. The why-Quartzline half needs the company's own material, which this pack lacks (see the upgrade menu) | F1 is where a motivation probe starts, because the move is adjacent rather than direct. JD because motivation for this role is scored against the role |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Three integration partners tell you onboarding takes too long. What do you do in your first two weeks to find out why?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify first, aloud: too long against what, measured from which point to which, whether the three share a segment. Then objective, approach, metrics, risks. For the journey you can use the stage list in your own sentence, scoping, requirements, architecture, UAT, go-live, and ask which stage the time goes in. Challenge one premise: three partners is a signal to check, not yet a pattern. Your two-week plan is a plan, not a past | The role's discovery duty (F8) turned into a live problem. CASE because it scores structure; the guidance makes no claim beyond the stage list |
| B2 | "Partner API adoption looks flat. How do you define adoption, and what would you track?" | CASE | [generic] | Ask how adoption is counted today and what the baseline is; the dossier lists the measurement as an unknown and the baseline as a risk to validate, so you are asking what you genuinely need. Then define it: separate reaching a partner, getting a partner live and keeping a partner active, because flat on one can hide movement on another. Name the weakest assumption in your own definition before they do. Claim no past tracking of any of these | F9 has no evidence behind it, so this is rehearsed as a live problem. `[generic]` because the metric options are a pattern, not a fact about Quartzline |
| B3 | "A squad lead wants to ship a fix for one big partner; you think it crowds out the wider platform. You disagree. How does it go?" | CASE | [generic] | Decision rights first: ask who owns this call today, since the dossier lists decision authority against the squad leads as unverified. Then restate each side's case in its own terms, say what evidence would change your mind, and agree the escalation path in advance. Offer seam principles rather than pretending to know the seam. Avoid any story of overruling a squad lead: `prohibited_claims`: "Having set prioritization for an engineering squad" bars it | F10 and F6 meet here, and the question tests the authority seam the dossier flags. CASE because it is a decision under disagreement |
| B4 | "You inherit two squads, a backlog of partner requests and one quarter. How do you decide what goes first?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure it: the goal for the quarter, the success measure, then sort requests by partner segment and strength of evidence, ask each squad what each item costs, decide the order and what you would say no to, and say how you would tell the people affected. The input you can speak to from your own work is client evidence: you ran quarterly roadmap-input sessions feeding client evidence to product. Say that, then say how you would weigh it against what the squads know. Do not say you have prioritized for a squad | F2 is the gap this question presses hardest, so it is rehearsed as a decision with the honest input. CASE because it tests reasoning on the role's own problem |
| B5 | "What goes into a spec you would hand a squad for a new partner-facing endpoint?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Walk it in order: the partner problem and its evidence, the contract (endpoints, schema, errors), versioning, the success measure, the rollout. Think aloud about what the squad would ask you. From your own work you can say your integrations carried requirements and architecture stages, at that scope: client integrations, not specs for a squad. Answer slot: R3 names API docs and schemas, so a probe on how you read or write them is likely. If you did either, say how, in your own words; if not, say so plainly and stay with the REST integrations | F4 and F10 are the technical-fluency rows. JD because it scores R3, delivered as a CASE |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in the order the quotes give: the integrations you led, the playbook you wrote, the sessions you ran. One sentence each in your own words, adding nothing the sentences do not state. End on why this role, so the arc points forward (A5's answer). No duration is used: no verified entry carries one, so add yours as a quote and I will use it | F1, F3 and F8 together are the whole story you can tell, and the opener sets what gets probed next. EXP because it tests what you say you did |
| C2 | "How comfortable are you reading an API's docs and schemas?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The casual register is still scored. Answer slot: R3 names API docs and schemas. If you read or wrote them as part of the REST integrations, say how, in your own words; if not, say so plainly and stay with the REST integrations and the architecture stage, then say what you would get fluent in first | F4 is the technical-fluency row, asked in the friendly register. JD because it scores R3 |
| C3 | "Engineering, sales and customers all want different things from a platform. How do you handle that?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Customer side, in the quotes' terms: the integrations were client work from scoping through go-live, and the sessions fed client evidence to product. Engineering and sales: the JD names both and your quotes name neither. Answer slot: if you worked with either on that work, say with whom and on what, in your own words; if not, say so plainly and stay with the customer side, then say how you would want the three to meet | F5 is presentable and F6 is open, so the question is rehearsed with a slot for the open half. JD because it scores R4 |
| C4 | "The role involves agile delivery with two engineering squads. What has that looked like for you?" | JD | [grounded] | The dossier's strategy here is clarify, and no confirmed sentence speaks to it, so nothing about your past goes in the answer unless you supply it. Answer slot: R5 names agile delivery. If you worked inside an agile team's delivery, say what it looked like and which part was yours; if you never worked that way, say so plainly, then say what you would want to confirm about how this team defines it | F7 is a preferred requirement with no evidence yet. JD because it scores R5; the question presupposes the practice, so the second branch allows that it never existed |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep the number attached to its noun: 30+ integrations. Four slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and do not reconstruct a method now. The dossier grades this high on an integration playbook it was given; name that playbook if it helps | F1, F3 and F5 all rest on this figure, so it is the first number a prober tests. EXP because it tests attribution |
| D2 | "You said end-to-end — which stages were you running yourself?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The sentence says you led the integrations and lists scoping, requirements, architecture, UAT and go-live. Answer slot: expect a probe on which of those stages you ran yourself and which others did. Say which, in your own words; if some were not yours, say so plainly and return to what the sentence states, that you led the integrations | The stage list invites a stage-by-stage probe on F1, F3 and F10. EXP because it separates leading from doing |
| D3 | "Tell me about the integration playbook." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped with the beats the quote states: you wrote it, it is internal, your team uses it. Describe what it covers in your own words; the pack does not know. It is the inspectable artifact behind your material, so say it can be shown if your employer allows. Do not present it as API documentation; your material does not say it is | F3 and F4 both lean on this sentence, and an artifact invites a closer look. EXP because it tests what you actually produced |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role" | The time-boxed A1. Pause, restate the question, then three beats: the concession in the sourced words, "I haven't held a product manager title or role"; the two quotes at their own scope; what you would learn first. If interrupted, finish the concession sentence before anything else. Hold the position through two follow-ups; the position is that the adjacent work is real, not that it equals the PM's | F1 delivered under time pressure. JD because it scores R1 |
| E2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate. Hold the sentence: you led the integrations. Answer slot: say which stages were yours and which others did, in your own words; if some were not yours, say so plainly and return to the word led. Concede that specifically and do not fold on the core claim | D2 under pressure. EXP because it tests attribution honesty |
| E3 | "Running input sessions is not owning a roadmap, is it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having owned a product roadmap" | Agree, in words sourced by the field: "No, I haven't owned a product roadmap." Then hold the sessions at the quote's scope: you ran quarterly sessions that fed client evidence to product. If pushed that you are stretching, restate what the quote carries and stop; do not defend the label and do not add to it | F2 and F8 meet here, and the objection returns in a harsher register. EXP because it tests whether the claim is sized to the evidence |

## Requirement coverage

| Requirement or duty | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, A3, A5, C1, E1, E3 |
| R2 Shipped API or platform products | A4 |
| R3 Technical fluency: API docs, schemas | B5, C2, D3 |
| R4 Stakeholder management across engineering, sales, customers | C3, B3 |
| R5 Agile delivery experience | C4 |
| Own the roadmap for the partner-facing API platform | A1, A2, B4, E3 |
| Run discovery with integration partners | A3, B1 |
| Write specs and drive delivery with two engineering squads | B3, B4, B5, C4 |
| Define and track adoption metrics | B2 |
| Headline figure: 30+ integrations | D1 |

## Reverse questions — pending your approval

| # | Question | Why it lands |
|---|---|---|
| Q1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority against the two squad leads as asserted but not evidenced. The answer tells you what F2 costs on day one, and it asks as diligence |
| Q2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier names the responsibility without a baseline. The answer tells you what you would be held to, and it shows you think in measures |
| Q3 | "How is the partner API work divided between the two squads today?" | It tests the seam B3 rehearses and shows you are thinking about delivery, not only discovery |
| Q4 | "What would you want a PM here to have learned by the end of the first quarter that they did not know on day one?" | It turns the ramp plan from A1 and A2 into the manager's own definition of success |
| Q5 | "Someone coming from the integration side would bring client evidence first. Where would you want that to sit alongside what the squads already know?" | It states your adjacent route as a strength to be fitted rather than a defect, in the manager's own terms |
| Q6 | "Is there anything about my background you would want to test further before we finish?" | It hands the manager the chance to name the objection live, while you can still answer it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims` item in the dossier | F1's quotes at their own scope, plus the plain acknowledgment the field sources: "I haven't held a product manager title or role" |
| Having owned a product roadmap | `prohibited_claims` item, and the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment: "I haven't owned a product roadmap." F8's quote stays at sessions that fed client evidence to product. No slot |
| Having set prioritization for an engineering squad | `prohibited_claims` item in the dossier | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quotes at their own scope. The limit is the pack's observation: your material says client integrations and a playbook, not a shipped product. A4's slot stays inside the integrations |
| Ran product discovery with partners | Inflated form of F8 | F8's quote at its own scope: sessions that fed client evidence to product. The limit is the pack's observation: your material says input sessions, not discovery |

## Sources

Provided: your note that the round is a 45-minute conversation with the hiring manager; `tuesday-dossier.md`, dossier_version 1.1, a version this pack can read.

The dossier supplied: `handoff_to_mock_interview` (verified evidence, strategy per weak area, the named objection, reverse-question seeds, prohibited claims) and `role_profile` (requirement text and responsibilities, as the JD). `decision` was read as context only. The dossier's `unknowns` were used as analysis, never as quotes. `evidence_map`, `evidence_state` and `risk_register` are not in this dossier. Its decision line mentions years of integration leadership, but no verified entry carries a duration, so no cell uses one. The dossier lists R2 as high priority with no weak-area entry; F3 is this pack's own grade.

Searches sent, all refused, so nothing came back from any:

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have named published values as sources for VAL questions. No values round is detected, so section 10 would not have appeared either way |
| 2. Quartzline interview process, product manager | unavailable | Would have documented the loop beyond your own words. Persona weights rest on the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded a CO or CASE question in current strategy. B1 to B5 are labeled `[generic]` or grounded in your quotes instead |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission → rows 1 to 3 above become `yes`: published values, the documented loop, and current strategy, so B-bank cases can be grounded in Quartzline's own priorities. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent org context
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep note → focus areas and any pre-declared deliverable, which the pack currently assumes are absent
- Your own words on the answer slots in F3, F4, F6 and F7 → those rows move from `discovery` to a quoted gap type, and A4, B5, C2, C3 and C4 become story-mapped
- Anything you can show from the roadmap-input sessions, such as an agenda, a readout sent to product, or shared notes → F1, F5 and F8 move from `medium` toward `high`
- How long you led integration work, as a confirmed number → C1 and F1 gain a duration they currently lack
- Anything you led that went out as a product rather than a client integration → F3, and A4's slot
- The full JD text → the responsibility rows (F2, F8, F9, F10) become quoted JD lines, which lets their questions carry slots
