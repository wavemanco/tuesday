I'll read the reference files the skill points to before building the pack.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-denied-ac0ac3d3/f4a5b49b-9c78-42ac-a6cb-2f0ce57e7e4a/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop with one shared fit snapshot, a persona mix for each round, and 31 questions: the recruiter (A1–A8), the Head of Member Services (B1–B11) and the panel (C1–C12). I ran no searches, because your pasted values, the recruiter's email, the strategy points and the JD already fix everything a search could change. It also has a values sheet for the panel round, reverse questions for each round, and a list of claims the pack won't coach.

- **Biggest exposure:** the contact-centre gap. The JD says "across branches and the contact centre" and you said "Never worked in a contact centre". B5 is the question to rehearse hardest, because it will come up in some form in all three rounds.
- **Second:** presenting to senior leaders (A6, B6). Your own words are "I've never presented to anyone above regional level", and the pack coaches saying that plainly, then a plan.
- **Values round:** none of your sentences carries a story for any of the four values. Each value is a "pick a real occasion" scaffold, with an honest fallback if none comes to mind. The pack won't invent stories for you.
- **Answer slots:** where the JD asks for something your words don't show, such as what your spreadsheet counted or how the complaints log was governed, the guidance is an answer slot. You say what's true, or say plainly that it wasn't yours. The upgrade menu lists what to send me to replace those slots with your own words.
- **Date:** I took 21 October as upcoming, going by your 12 October dating. My session clock reads 5 November, so if that date has passed, the timing assumptions are off.

I can run a live drill, playing the Head of Member Services on B5, the contact-centre question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
I can convert the pack to a Word document if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop, three rounds on 21 October. Round 1 (A): the recruiter, 30 minutes. Round 2 (B): the Head of Member Services, who would be your manager, 45 minutes, mostly behavioural. Round 3 (C): a panel of two branch managers, 60 minutes, including a 20-minute case on a complaint escalation. The panel is also the values round and scores against the four values. Interviewer names are not yet assigned, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Rehearse aloud, since each guidance cell is sized for 90 to 120 seconds.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether your own account of your work survives follow-ups |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know where Ashgrove is heading |
| CASE | A live problem from the role, scored on structure |

Reading the cells: an "Answer slot" is an instruction for the interview, not a question for you now. If you did the thing, say how, in your own words. If there was no such step, or it was not yours, say so plainly and go back to what your own words carry.

Highest-ROI prep in the pack: B5, the contact-centre objection. The JD's headline duty is to own the process "across branches and the contact centre", and your message says "Never worked in a contact centre". It will be asked in some form in all three rounds (A3, B5, C9), so B5 gets the deepest rehearsal. Second is the senior-leaders objection (A6, B6).

## Fit snapshot (shared by all rounds)

Evidence quotes are your own words from your message. No hard gates (a licence, location or similar term) appear in the JD, so no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far beyond your own branch the work reached likely. If any of it reached other branches, say which and how, in your own words; if it did not, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | A monthly complaints spreadsheet is the reporting that exists in your material; what it showed is not in it, and the bridge should not be stretched. Answer slot: if the spreadsheet counted anything, say what it counted; if you are unsure what it counted, say so plainly, and say what you would count first |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal complaints; it does not say how the log was governed. Answer slot: the JD's word makes a probe on that likely. Say how the log was kept, what went into it, who it went to and what was yours to decide; if you do not know how it was governed, or none of that was yours, say so plainly and describe the log as you kept it |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material says tellers and a script; the JD says supervisors and coaching, and the bridge stays at the quote's scope: "trained new tellers on our escalation script." Answer slot: if you have coached anyone at supervisor level or above on escalations, say who and what changed; if not, say so plainly, and say how you would |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD's line makes a probe likely. If you have worked with a digital team on anything members use themselves, say what and which part was yours; if you have not, say so plainly |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the quote in its own terms: six years in retail banking, the last three as a branch supervisor |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms; reword nothing beyond it: "I built the monthly complaints spreadsheet our regional manager uses." Your material says spreadsheet and does not name the tool, so say Excel only if it was Excel |

## Grounding brief (from the 2026 strategy brief the recruiter sent)

Use the brief's own terms so you sound current. These are the points you pasted, not the whole document.

| Point | In the brief's words | Where it is used | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | A5, B9 | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | A5, B10, C3 | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | A5 | [grounded] |
| Competition | "the main competitive pressure is app-only banks" | A5, B11 | [grounded] |

---

# Round 1 (A): recruiter, 30 minutes

## Persona table, Round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | A friendly opener, a biography question, motivation, casual questions on the JD's headline topics | High. A recruiter screen's prior is conversational, and the recruiter's email says "30 minutes with me" | A pre-scripted 90-second arc; treat casual questions on complaints, reporting and Excel as scored |
| Skeptic, light | Knockout checks on the gaps | Medium. Recruiter screens check knockouts in a friendly register (prior), and your message names two absences, so those are the likeliest topics [inferred] | State each absence plainly in your own words, then the plan; never circle it |

## Bank A

### Conversational (6 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey, and what's drawn you to this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A 90-second arc with the two beats the quote states, in your own words: six years in retail banking, the last three as a branch supervisor. The reason for the move is yours and is not in your material. Answer slot: say the real reason in one sentence, tied to one of Ashgrove's values in their words (see A4). If the real reason is plain, say it plainly, because a true reason survives follow-ups | F7 is the evidence for the experience requirement, and the biography question is the opener of a screen. EXP because it tests whether your account of your own path holds |
| A2 | "Tell me about the complaints work you did in your branch." | EXP | [grounded] "I handled the branch's formal complaints log" | Open with the quote's words: "I handled the branch's formal complaints log." The beats it states are the log, the branch and formal complaints. Answer slot: the JD asks for regulated complaints, so expect a probe on how the log was governed. Say how the log was kept, what went into it, who it went to and what was yours to decide; if you do not know how it was governed, or none of that was yours, say so plainly and describe the log as you kept it | F4 is the JD's regulated-complaints requirement, and this is where the recruiter checks it. EXP because it tests what was actually yours |
| A4 | "Why a credit union, and why Ashgrove?" | CO | [grounded] | Choose, by what is true for you, one of Ashgrove's values in its own words, for example "Members First, Always — we decide from the member's side of the counter" or "Neighbours, Not Numbers — every branch is part of its town", and say in a sentence why it matters to you. The question needs no claim about your past, so the guidance makes none. Do not borrow a value you do not hold | Motivation consistency is the recruiter's main job in a screen, and the values page you pasted supplies the vocabulary. CO because it tests knowing this employer; the values sit in the shared row above |
| A5 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Use the brief's words: "move 40% of member service to digital channels by 2028" and "consolidate eight branches into five hubs over 2027" are the two to carry; "launch a small-business lending product in Q1 2027" and "the main competitive pressure is app-only banks" are the others. Put one open question beside each, such as what happens to complaints as service moves digital, or how complaint handling travels as eight branches become five hubs. These are questions you are asking, not findings. Claim nothing beyond the brief | The recruiter sent you the brief, so being fluent in it is expected. CO because it scores homework depth; the small-business lending point has no stated link to complaints, so it is vocabulary only |
| A7 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it as it is: "I built the monthly complaints spreadsheet our regional manager uses." Your material says spreadsheet and not the tool, so say Excel only if it was. Answer slot: if the spreadsheet counted anything, say what it counted; if you are unsure what it counted, or someone else set that, say so plainly and say what you would count first | F9 is the evidence for this mid-list requirement, the kind a screen asks once and casually. JD because it is a stated requirement |
| A8 | "Which of our four values do you most identify with?" | VAL | [grounded] "I handled the branch's formal complaints log" | Pick the value that is true for you, then one occasion from your own work that shows it: a named stake, a decision that was yours, an outcome. If no occasion comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", at that scope, or how you would handle it | The recruiter's email says the panel scores against the values, so a screen may sample them. VAL because it asks for a specific decision, not slogan familiarity |

### Skeptic, light (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A3 | "The role covers the contact centre as well as branches — what's your experience on that side?" | JD | [grounded] "Never worked in a contact centre", "I handled the branch's formal complaints log" | Plain and first: "Never worked in a contact centre." Do not circle it. Then stay with what you carry: "I handled the branch's formal complaints log." Then a plan, said as a plan: two things you would do in your first weeks to learn how complaints reach and move through the contact centre, things you would actually start. Describe no contact-centre work as something you have done or seen | F2 is a stated absence against the JD's headline duty, so the recruiter will check it. JD because it scores the stated requirement; the full rehearsal is B5 |
| A6 | "The role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level.", "I built the monthly complaints spreadsheet our regional manager uses." | Say it plainly: "I've never presented to anyone above regional level." Then a plan: the first senior audience you would want to put the monthly complaints picture in front of, and how you would prepare. The material you would take there is reporting you already build, "I built the monthly complaints spreadsheet our regional manager uses.", said at that scope with no claim about presenting it. Do not claim confidence from experience you do not have | F8 is a stated absence against the JD's presenting requirement. JD because it scores the stated requirement; the second rehearsal is B6 |

## Reverse questions, Round 1

| Reverse question | Why it lands |
|---|---|
| "Who will I meet in the manager round and on the panel, once that's assigned?" | Interviewers are not yet assigned, and names unlock a tailored read of each |
| "Is the escalation case in the panel round built from a real situation, and is there anything I should read first?" | The recruiter's email names the 20-minute case, and asking shows you are preparing for it |
| "How does the panel score against the four values: a scorecard or a discussion?" | The email says the panel scores against them, and the answer tells you how specific your stories must be |
| "How is complaints work organised today between branches and the contact centre, and where does this role sit?" | It turns your stated gap into curiosity about the structure |
| "What happens after the 21 October rounds, and when would you expect to decide?" | Closes the loop on process without sounding casual |

---

# Round 2 (B): Head of Member Services, 45 minutes

## Persona table, Round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts, STAR-shaped | Highest. The recruiter's email calls the round "mostly behavioural" | A story per prompt where your words carry one, and a selection scaffold with an honest branch where they do not; "we" for context, "I" for your part |
| Skeptic | Probes the gaps your message names, from the person who would manage you | High. The hiring-manager prior is Skeptic and Case, and your message names two absences against the JD | Rehearse B5 until it is boring; concede exactly, hold what your words carry |
| Case / Strategist | A live problem on their roadmap, in the brief's vocabulary | Medium. The hiring-manager prior is high, lowered because the email says "mostly behavioural" | Clarify, objective, segmentation, approach, metrics, risks, aloud; challenge one premise respectfully |

## Bank B

### Values / Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you escalated a complaint above your own level." | JD | [grounded] "trained new tellers on our escalation script" | Pick a case where you passed a complaint upward. It needs the member's stake, why it went up, who took it and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script", at that scope, or how you would handle one | The JD names escalations, and F5 is the nearest evidence. JD because it scores the escalation duty; behavioural in delivery |
| B2 | "Tell me about a complaint you took all the way to a resolution." | VAL | [grounded] "I handled the branch's formal complaints log" | The value is Own the Fix: "whoever finds the problem keeps hold of it until it is solved." Pick one case where you kept hold of it: what the problem was, what you did, what the end state was, and what you handed on, if anything. If no case comes to mind, say so plainly, then give "I handled the branch's formal complaints log" at that scope, or how you would keep hold of one | F1 is the nearest evidence for a value the panel will also score. VAL because it asks for a specific decision, not the slogan |
| B3 | "Tell me about a time you helped someone get better at handling a difficult conversation." | JD | [grounded] "trained new tellers on our escalation script" | The quote carries these beats: you trained new tellers, and the subject was the escalation script. Tell those in your own words. Answer slot: if you saw a teller handle a member differently afterwards, say what you saw; if you did not, or cannot say, say so plainly and stay with the training as quoted | F5 and the JD's coaching duty. JD because coaching supervisors is a stated duty; the delivery is behavioural |
| B4 | "Tell me about the monthly complaints spreadsheet your regional manager uses." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The quote carries four beats: you built it, it is monthly, it is about complaints, your regional manager uses it. Tell those in your own words. Answer slot: how it came to exist; if you were asked to build it, say by whom, and if you started it yourself, say so. Then what it counted, in your own words; if you are unsure what it counted, say so plainly. Hold "I built it" and add nothing about what it let anyone decide | F3 and F9 both rest on this sentence, so it is the most probable EXP probe in the round. EXP because it tests attribution |

### Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "You'd own complaints across branches and the contact centre. You've not worked in a contact centre — why should I trust you with that half?" | JD | [grounded] "Never worked in a contact centre", "I handled the branch's formal complaints log" | The highest-ROI rehearsal in the pack. Level 1, concede first and exactly: "Never worked in a contact centre." Hold the claim your words carry, "I handled the branch's formal complaints log", and do not stretch it to the whole process. Level 2, "what would you not know?": name, in your own words, two or three things about contact-centre complaint handling you would need to learn, and say what you do not know, not what you guess. Level 3, "what do you do in your first 90 days?": a plan with an order, who you would listen to first, what you would read, what you would leave unchanged until you understood it. Level 4, "the contact-centre lead says you can't understand their work": agree that they know it better and ask them to teach you. Never fold to "I can't do that half", and never assert that branch work equals contact-centre work | F2 is a stated absence against the JD's headline duty, so this objection arrives from a manager in some form. JD because it scores the stated requirement; Skeptic in delivery |
| B6 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre", "I've never presented to anyone above regional level." | Choose from your own two sentences, not a third: "Never worked in a contact centre" or "I've never presented to anyone above regional level." Name one plainly and give the ramp as a plan with a first step you can keep. If asked "and the other?", say it too, in the quote's words | F2 and F8 are the two stated absences, so the manager can ask for either. JD because it asks you to assess yourself against the posting |
| B7 | "What's the widest view of complaints you've had: a branch, a region, more?" | EXP | [grounded] "I handled the branch's formal complaints log", "I built the monthly complaints spreadsheet our regional manager uses." | Your material carries two sentences: "I handled the branch's formal complaints log" and "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: whether the spreadsheet covered more than your own branch is not in your material. If it did, say how many branches and how; if it covered your branch only, or you are unsure, say so plainly and stay with the log and the spreadsheet as quoted | F1 is where "end to end across branches" presses hardest. EXP because it tests scope honestly |
| B8 | "The role works with digital teams on self-service journeys. What have you done with digital teams?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer slot: if you have worked with a digital team on anything members use themselves, say what and which part was yours. If you have not, say so plainly and speak from where you have sat: "6 years in retail banking, the last 3 as a branch supervisor", then say what you would ask a digital team first | F6 has no evidence in your material, and the JD names the duty. JD because it is a stated requirement that earns its own question |

### Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B9 | "We want 40% of member service on digital channels by 2028. A member's complaint raised in the app is stuck between a digital team and a branch. How do you start?" | CASE | [grounded] | Say your structure aloud. Clarify first: what the member asked, what has been logged, what time limits you are working to (ask, do not assume). Objective: the member is heard once and answered in plain words. Ownership: one named person keeps hold of it. Then how often this happens, what to measure (resolution time, repeat contacts), and the risk. Challenge one premise respectfully: is this a digital problem or a handoff problem? The question asks about no past, so the guidance makes no claim about yours | The 40% target is from the brief and the JD pairs complaints with self-service journeys. CASE because it is a live problem from the actual role |
| B10 | "Eight branches become five hubs over 2027. What happens to complaints during that, and what would you watch?" | CASE | [grounded] | Clarify first: which sites, in what order, who owns complaints at a merged site. Objective: no complaint lost or delayed in a handover. What to watch: volumes and resolution times by site before and after, the two measures the JD names for the monthly report. Risk: members of a closing branch, which ties to "Neighbours, Not Numbers — every branch is part of its town". Give it as a view to test with the interviewer, not a finding | The consolidation is in the brief and touches your role's ownership. CASE with CO content, since it scores strategy fluency |
| B11 | "App-only banks are our main competitive pressure. How could complaint handling be part of our answer?" | CO | [grounded] | Offer a view, labelled as a view, and test it with the interviewer: what a member would notice about how a complaint is handled here, such as a named person who keeps hold of it, in plain words. Ask whether that matches how they see it. Claim nothing about any competitor's practice | The brief names the competitive frame, and a view tied to your function shows you can think at the company's altitude. CO because it scores strategy fluency |

## Reverse questions, Round 2

| Reverse question | Why it lands |
|---|---|
| "What would a good first 90 days look like to you, and what would you want me to have learned or changed?" | Your future manager's answer sets your plan, and it shows you plan in order |
| "How does the contact-centre side of complaints work today, and who would I work with first?" | It owns the gap in B5 and gets you a first name to learn from |
| "How are complaint volumes and resolution times reported to leaders today, and what do you wish they showed?" | The JD names both as the monthly report; the answer shows what leaders actually use |
| "With branches becoming hubs through 2027, how do you see complaints ownership changing?" | Ties to the brief and shows you think about the transition |
| "Where does the digital team sit on self-service today, and where does complaints work meet their roadmap?" | Addresses F6 and the 40% target |

---

# Round 3 (C): panel of two branch managers, 60 minutes, including a 20-minute case

## Persona table, Round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | A prompt per value, scored against the four | Highest and guaranteed. The recruiter's email says the panel "is also the values round" | A story per value where your words carry one, a scaffold where they do not (see the values sheet below) |
| Case / Strategist | The 20-minute case on a complaint escalation, with follow-ups | High. The email names it | Structure aloud; one named owner; plain words to the member |
| Peer Evaluator | Seam-splitting between the complaints lead and the branches; coaching their supervisors | Medium. The role coaches branch supervisors, and branch managers are plausibly those supervisors' managers [inferred] | Reciprocity: what you bring their supervisors, and principles for the seam, not a pretended map |
| Pressure | Attribution and sixty-second probes | Low. Panels sometimes close with them; the email names no stress element | Hold, then concede exactly |

One further reading, labelled as inference: with eight branches becoming five hubs over 2027, branch managers may press "Neighbours, Not Numbers" against the consolidation [inferred]. Have a view, stated as a view (see C3).

## Bank C

### Values / Behavioral (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a call from the member's side of the counter." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Members First, Always. Pick a decision that was yours and not policy: the member's situation, who might have disagreed, what you decided, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "6 years in retail banking, the last 3 as a branch supervisor", at that scope, or how you would decide | The panel scores each value. VAL because it needs a specific decision |
| C2 | "Tell me about a time something had to be explained twice, and what you changed." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words: "if a member needs it explained twice, we wrote it wrong." Pick one occasion where wording was the problem, what you changed, and what happened to the next explanation. Answer slot: the nearest sentence in your material is "trained new tellers on our escalation script"; whether the script was ever reworded is not in it. If you reworded something, say what and why; if not, or it was not yours, say so plainly | The value is the shortest of the four and the easiest to claim; F5 is the nearest evidence. VAL because it asks for a specific change |
| C3 | "Tell me about a time a branch's town shaped a decision you made." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Neighbours, Not Numbers: "every branch is part of its town." Pick a decision where a local detail changed what you did: the detail, your decision, the effect. If none comes to mind, say so plainly, then give the nearest thing your material carries, "6 years in retail banking, the last 3 as a branch supervisor", at that scope, or how you would decide. Expect this to be pressed against the hub plan; have a view on how hubs can keep local presence, said as a view | The inference in the persona table suggests this value gets the hardest push. VAL because it scores a published value |
| C4 | "Tell me about a problem you found that wasn't strictly yours, and what you did next." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix: "whoever finds the problem keeps hold of it until it is solved." Pick one case: the problem, why it was not strictly yours, what you did, how it ended. If none comes to mind, say so plainly, then give "I handled the branch's formal complaints log" at that scope, or how you would keep hold of one. One story can serve B2 and C4; use two if you have two | The fourth value, and F1 is the nearest evidence. VAL because it scores a published value |

### Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member's complaint has been through the branch and the contact centre and is still open. They say they'll move their account and tell the town. You have 20 minutes: how do you handle it?" | CASE | [generic] | Say your structure aloud. (1) Clarify: what the complaint is, whether it is logged as formal, what the member has been told and by whom, what time limits apply (ask, do not assume). (2) Objective: the member heard, answered in plain words, fixed or clearly explained. (3) Ownership: one person keeps hold of it. (4) Route: who decides the remedy, and what the branch can do today. (5) The member: one call, plain words, a date for the next contact. (6) Record and root cause: why it passed between two channels. (7) Report: how it shows in the monthly figures. Challenge one premise respectfully, such as whether the threat to leave should change fairness of handling. The question asks about no past, so the guidance makes none; expect the real case to differ | The email says 20 of the 60 minutes are a case on a complaint escalation. `[generic]` because the real case is theirs; this is a pattern. CASE because it is a live problem from the actual role |
| C6 | "Now the supervisor who first handled it says you're blaming them. What do you say?" | CASE | [grounded] "trained new tellers on our escalation script" | Structure it as a coaching conversation: separate the member's outcome from who erred, ask for their account first, agree what to change in the escalation step, and treat it as learning. Answer slot: your nearest evidence is "trained new tellers on our escalation script", and supervisors are a different audience. If you have coached anyone at supervisor level or above on escalations, say who and what changed; if not, say so plainly and describe how you would | F5 against the JD's coaching duty, under pressure from a branch manager's side. CASE because it is a live follow-up |
| C7 | "What would you put in the monthly report on this complaint and the others?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Offer a proposal, not a history: the JD names volumes and resolution times; say what else you would want and why, and ask what leaders use now. About your past, say only "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if the spreadsheet counted anything, say what it counted; if you are unsure, say so plainly | F3 is the reporting requirement and C5 sets it up. JD because it scores the stated duty |

### Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C8 | "Our supervisors are stretched. How would you coach them on escalations without adding to their load?" | JD | [grounded] "trained new tellers on our escalation script" | Reciprocity first: ask the panel what escalations cost their supervisors now. Then offer principles to agree with them, such as short sessions built on real cases, not a finished design. Your nearest evidence is "trained new tellers on our escalation script"; supervisors are a different audience, so say that, and say how you would find out what they need | F5, from the branch managers whose supervisors you would coach. JD because coaching is a stated duty |
| C9 | "When a complaint is in my branch, where does your role end and mine begin?" | CASE | [generic] | Propose principles, not a pretended map, and say they are for agreeing: the branch manager keeps the member relationship and the local call; the complaints lead keeps the process, the escalation standard and the reporting. Add how you would settle a disagreement, such as agreeing in advance who has the last word on remedy and who on process. The question needs no claim about your past, so the guidance makes none | The seam is the peer persona's core probe. `[generic]` because it is a pattern for the problem |
| C10 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use "we" for context and "I" for your contribution; "I built the monthly complaints spreadsheet our regional manager uses." is an "I" sentence at its own scope. Answer slot: name one occasion when work spanned teams and say which part was yours; if none comes to mind, or the part was not yours, say so plainly and describe how you would share credit | A stock peer probe, and F9 is the sentence your attribution rests on. EXP because it tests what was actually yours |

### Pressure (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C11 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Pause, restate the question, then hold the claim your words carry: "I built the monthly complaints spreadsheet our regional manager uses." Hold it through two follow-ups. Answer slot: if anyone asked for it or shaped it, say who and what; if it was all yours, say so; if you are unsure what it counted, say so plainly. Concede exactly what was not yours and fold nowhere else | F3 and F9 rest on one sentence, so attribution is the likeliest pressure. EXP because it tests attribution |
| C12 | "Sixty seconds: why you for this role?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor", "I handled the branch's formal complaints log", "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each in the quote's words: "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses." Add no adjectives such as "end to end". Then name one gap yourself before they do: "Never worked in a contact centre", with the plan | A closing probe that pulls F7, F1 and F3 together. JD because it scores the fit against the posting |

## Values / principles cheat sheet (Round 3)

All four values come from the page you pasted. No sentence of yours carries a story for any of them, so each row is a selection scaffold ending in its honest branch, with the nearest evidence named.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide as the member would see it | Selection scaffold (C1): a decision that was yours, a named stake, a real ending. If none comes to mind, say so plainly and give the nearest thing your material carries, F7: "6 years in retail banking, the last 3 as a branch supervisor", or how you would decide |
| Plain Words | Wording that needs no second explanation | Selection scaffold (C2): one occasion where wording was the problem and what you changed. If none, say so plainly and give F5: "trained new tellers on our escalation script", at that scope |
| Neighbours, Not Numbers | A branch is part of its town | Selection scaffold (C3): a decision a local detail changed. If none, say so plainly and give F7: "6 years in retail banking, the last 3 as a branch supervisor", or your view on how hubs stay local |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold (B2, C4): a problem you kept hold of to an end state. If none, say so plainly and give F1: "I handled the branch's formal complaints log", at that scope |

## Reverse questions, Round 3

| Reverse question | Why it lands |
|---|---|
| "When a complaint lands in your branch, what do you want from a complaints lead, and what don't you want?" | Reciprocity: it prices what the hire costs the branch managers |
| "What could a new complaints lead do in the first month that would help your supervisors?" | A peer-round reciprocity question, tied to the coaching duty |
| "As sites merge into hubs, what do you most want to keep local?" | Takes Neighbours, Not Numbers into their own terms |
| "What does a strong escalation look like to you, and where do they go wrong now?" | Shows you want their definition before you offer yours |
| "Which of the four values gets tested most when a complaint goes badly?" | Turns the values round into a conversation about their branches |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A3, B5, B7, C5, C9 |
| Report monthly on complaint volumes and resolution times | A7, B4, B7, C7 |
| Coach branch supervisors on escalations | B1, B3, C6, C8 |
| Work with digital teams on self-service journeys | B8, B9 |
| 4+ years in financial-services customer operations | A1, C12 |
| Experience handling regulated complaints | A2, C5 |
| Confident presenting to senior leaders | A6, B6 |
| Comfortable with Excel reporting | A7, B4 |
| Four values (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) | A8, B2, C1, C2, C3, C4 |
| Strategy (digital shift, hubs, app-only banks) | A5, B9, B10, B11 |
| Strategy (small-business lending) | — none, and why: the brief states no link to complaints, so it is vocabulary in A5 only |

## Prohibited claims

Built from the fit snapshot before the banks were written. Each entry says what this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the branch's log, not the process across branches |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "Never worked in a contact centre." Then a plan, never a past. No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." Then a plan. No slot |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: "trained new tellers on our escalation script." The limit is the pack's observation: the material says tellers |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says formal complaints and does not say how the log was governed. A2's slot stays inside the log |
| Reported monthly to leaders on how long complaints took to resolve | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." A7's slot asks only what the spreadsheet counted |
| Built Excel reporting | Inflated form of F9 | F9's quote at its own scope, with the tool named only if it was Excel |

## Sources

Provided documents: the JD; the four values as pasted (copied from ashgrovecu.org/about/values on 12 October 2026, per your message); the recruiter's process email; the four points of the 2026 strategy brief as you quoted them; your background message. The pack is built on your dating of today as 12 October 2026, with 21 October upcoming. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names the three rounds, their lengths and who runs them, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The brief points you quoted fix the CO questions and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No name was given, so there was no query to form; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or a redacted sample of your monthly complaints report → F3, F7 and F9 could rise from `medium` to `high`, and the quotes would come from documents, not a message
- Your answers to the answer slots (what the spreadsheet counted, how the complaints log was governed, whether any work reached other branches, any coaching above teller level, any work with a digital team), given in a message outside a drill → F1, F3, F4, F5 and F6 are regenerated from your actual words
- One real example for each of the four values, in your own words → the four selection scaffolds on the values sheet become mapped stories
- Why you want this role and this move → the A1 arc becomes a script built on your actual reason
- The interviewer names once assigned → an interviewer read, persona weights tuned per person, and a reverse question tied to each person's path
- How much prep time you have → a prioritised schedule sized to it
- The recruiter, by one email: what format the 20-minute case takes and whether there is pre-reading → CASE rehearsal tuned to it
- A deeper research pass (offered once): up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's wider strategy context, interviewer footprints once named, and reports of this loop → a fuller grounding brief and sharper CO questions
- A `tuesday-dossier.md` from the job-underwriter → an evidence-derived objection instead of an inferred one, and strategy constraints per weak area
