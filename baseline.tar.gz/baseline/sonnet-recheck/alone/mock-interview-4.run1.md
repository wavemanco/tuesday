I've read the skill's rules and am now running the default research pass on Quartzline: values, interview process and recent strategy.
Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-4-denied-0f058067/a70e7265-328a-40db-98a6-869e6a453507/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md. It has 20 questions across six interviewer styles, built for a 45-minute hiring-manager round. Web search was refused, so nothing in it is a researched fact about Quartzline. The company-knowledge question (D3) says so rather than inventing strategy.

Two things from the pack to know before Thursday:

- **Rehearse A1 first.** It is your dossier's objection: you've never held the PM title or owned a roadmap, so why you over a PM with three years of the actual job. The coaching is to concede both points first. Then bridge using only your three confirmed claims, with the limit stated: this is adjacent work, not PM experience. Four follow-ups are scripted. The roadmap-input sessions are your thinnest claim, so say yourself what you can show.
- **R2 wasn't on the underwriter's weak-area list.** I graded "Shipped API or platform products" as a transferability gap, because your evidence is client integrations of the vendor's APIs rather than releasing an API product. A4 rehearses that probe, with answer slots for you to fill from what you actually did.

The pack also has the six reverse questions (the dossier's two squad-lead authority and adoption-baseline questions are V1 and V2). Its prohibited-claims section lists the three prohibited claims from your dossier, plus two stretched wordings I added from your own quotes.

Say the word and I'll play the Skeptic on A1, the objection the underwriter named as the highest-ROI prep.
I can also save a tuesday-dossier.md update recording what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, this Thursday. Interviewer: the hiring manager, name not given. Built from the underwriting dossier you carried in (decision: conditional_go) and nothing else; web research was refused, so nothing in this pack is a researched fact about Quartzline.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack: no published values were in hand and no values round is detected |
| EXP | Whether your claims survive scrutiny and attribution probes |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` rests on the dossier or your quoted sentences, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Quartzline. Where an answer slot appears, it is an instruction for the interview: answer whichever branch is true for you, and say so plainly if the practice was not yours.

**Highest-ROI prep: A1.** The underwriter named this objection from evidence you confirmed: you have not held the title or owned a roadmap, so why hire you over a PM with three years of the actual job. A1 gets the deepest rehearsal and P1 (a time-boxed version) repeats it under pressure.

## Fit snapshot

Requirement text is the dossier's `role_profile`, which stands as the JD's lines. Evidence is quoted from the dossier's `verified_candidate_evidence`; the dossier carries no `evidence_map`, so gap types and confidence on rows F3 to F5 are this pack's own derivation. The confidence note the underwriter attached to each entry is applied in the Confidence column and the bridge, not quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [grounded] | transferability | Underwriter's strategy is `bridge`, with its limit: the bridge is positioned as adjacent, never as product-management experience. The material shows integration work, not product-management work. Say the title point yourself before it is asked, sourced to `prohibited_claims`: "I haven't held a product manager title." Then the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." |
| F2 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas, R1 sub-claim | none given | none | [grounded] | capability | Underwriter's strategy is `acknowledge_gap`: no bridge, and none is coached here. Words, sourced to `acknowledge_gap` and `prohibited_claims`: "I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then a plan, never a past: in the first weeks you would learn how decisions are split between the PM and the two squad leads, and how adoption is measured today |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | Pack's own reading, since the underwriter did not list R2 as a weak area: your material says client integrations of the vendor's APIs, not the release of an API product, and the words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: R2 makes a probe on where your work met the product side likely. Say which of those stages (scoping, requirements, architecture, UAT, go-live) you handled yourself and what you did in each, in your own words; if a stage was not yours, or you did not do that, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes touch REST APIs and architecture without showing API docs or schemas. The playbook is inspectable, so offer to walk through it. Answer slot: R3 names API docs and schemas, so expect a probe on them. If you read or wrote either in those integrations, say which and how, in your own words; if not, say so plainly and stay with the REST API integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes show clients and product; they do not show engineering or sales. The roadmap-input sessions are confirmed with limited inspectable proof, so expect a probe and volunteer what you can and cannot show. Answer slot: R4 names engineering, sales and customers. If you worked with engineering or sales on these, say who and what your part was; if you did not, say so plainly and stay with the client side and the stages in the first quote |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Underwriter's strategy is `clarify`, and no verified entry speaks to this requirement. Answer slot: R5 names agile delivery, so expect a probe on how you have worked in it. If you worked that way, say how and what your part was, in your own words; if you never did, say so plainly and say what you would want to confirm about how this team defines and runs it |

## Persona table

Weights are a shown judgment. Starting point: the relationship prior for a hiring manager, which the persona reference sets at Case/Strategist plus Skeptic. Adjustments: the underwriter named a specific Skeptic objection (up); the JD names adoption metrics and a 30+ figure sits in your evidence (Prober to mid); two squads and an unevidenced decision-authority line make a Peer-style seam question plausible (low). No interviewer profile exists, so no signal adjustment. Loop: your own words establish one 45-minute hiring-manager session, so no loop archetype is assumed; no values-style round is detected, so the Values persona gets no bank.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap | High: relationship prior plus the underwriter's named objection | Rehearse A1 until it is boring; concede the two sourced negatives first, bridge only from the quotes with the limit named, then a ramp plan | A, 5 questions |
| Case/Strategist | Live problems from the role: adoption, prioritization, discovery, schema changes | High: hiring-manager prior, and the JD responsibilities are live-problem material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; say "here is how I would approach it", never a past tense for work you have not done | B, 5 questions |
| Data-Driven Prober | Reads your evidence line by line and asks how the 30+ was counted | Medium: one headline number and a playbook that can be inspected | Know what you can and cannot say about how the figure was counted; offer to walk the playbook end to end | C, 3 questions |
| Conversational | Opens with the journey and "why this role" | Medium: opening minutes of most hiring-manager conversations, and still scored | A 90-second arc built only from the three quotes, with the adjacent limit said aloud | D, 3 questions |
| Peer Evaluator | Seam questions with the two squad leads | Low: the JD names two squads and decision authority is unevidenced, but the round is not a peer round | Propose seam principles instead of pretending to know the seam; ask the decision-rights question | E, 2 questions |
| Pressure | Time-boxes and interrupts the title objection | Low: possible if the manager tests composure on the gap | Pause, restate, hold through two follow-ups, concede specifically | P, 2 questions |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter's objection, asked as written; both negatives are sourced (`uncertain_or_weak_areas` acknowledge_gap, and `prohibited_claims`). Order: concede, bridge at its limit, plan. Concede first: "I haven't held a product manager title, and I haven't owned a roadmap." Then only what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs"; "I wrote the internal integration playbook my team uses"; "I ran quarterly roadmap-input sessions feeding client evidence to product". The last is confirmed with limited inspectable proof, so say what you can and cannot show before they ask. Name the limit yourself: this is adjacent work, not product-management work. Follow-up 1, which trade-offs have you made: return to the quotes and concede that setting priorities is the part you have not done. Follow-up 2, why not the PM with the title: do not argue you are better; say what you bring in the quotes' own words and let them draw the inference. Follow-up 3, what if a squad lead disagrees with you: a how-I-would-approach answer, never a past; you would first want to understand how decisions are split. Follow-up 4, your first ninety days: a plan to learn the decision split, how adoption is measured and its baseline, and what the squads are building now. Never fold on the core: the adjacent work is real; never stretch it | F1 and F2 are exactly where this objection lands, and the underwriter named it, so it gets the most follow-up levels; JD because it scores the first requirement |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas` acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name one thing, not a list. The sourced candidate is the roadmap and prioritization piece: "Owning a roadmap and setting priorities is the part I haven't done." Then the ramp plan from F2: learn the decision split with the squad leads and the adoption baseline. Calibrated candor beats bluffing something the interviewer personally owns | Skeptic stem aimed at F2, the one row with no bridge; JD because it scores the role's roadmap responsibility |
| A3 | "Tell me about working in an agile delivery cycle." | JD | [grounded] | Open prompt on R5, with no quoted sentence behind it, so no story is mapped. Answer slot: if you worked that way, say how and what your part was, in your own words; if you never did, say so plainly, then say what you would want to confirm about how this team defines and runs it, and return to the integrations in F1 at their own scope | F6 is a `clarify` area: the evidence may exist and was never established; JD because R5 is a stated requirement |
| A4 | "The role asks for shipped API or platform products. Where in your work did you touch the product itself rather than a client's integration of it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: say which of scoping, requirements, architecture, UAT and go-live you handled yourself and what you did in each, in your own words; if any stage was not yours, or the premise does not match your work, say so plainly and stay with the integrations. Do not stretch the integrations into something else | F3 is where this probe lands and the underwriter did not flag it, so rehearse it; JD because it scores R2 |
| A5 | "Why leave integration work for product, and why here, why now?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Three beats. What draws you to this role: your reason, in your own words; this pack does not know it and will not supply one. The nearest thing your material carries: "I ran quarterly roadmap-input sessions feeding client evidence to product", with the limit on what you can show. Then the plan from A1. Do not describe the move as a step you have already taken | Motivation consistency is the core Skeptic score; F1 and F5 are the evidence behind it; JD because it scores fit against R1 |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has been flat for two quarters. What do you need to know first, and how would you diagnose it?" | CASE | [generic] | Clarify first: how adoption is defined today (signed up, live in production, call volume) and the baseline, which is also an open question in the dossier. Then objective, segmentation of partners, hypotheses, metrics, risks. Challenge one premise respectfully, for example whether flat means the same thing across partner types. The question asks about no past, so the guidance makes no claim about yours | Live problem from the adoption responsibility in role_profile; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Two squads, one quarter, and three partner requests that conflict. How do you decide what goes first?" | CASE | [generic] | Frame it explicitly as "here is how I would approach it". Criteria and trade-offs in your own words, then the decision-rights question: which of these calls are the PM's alone and which belong to the squad leads. Keep the verbs conditional; this is the area where past-tense phrasing would imply work `prohibited_claims` rules out | Tests the F2 gap in the form a hiring manager actually uses, as a live decision; CASE with JD content |
| B3 | "Design a discovery plan for five integration partners whose needs diverge." | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: what you need to learn, how you would select and sequence partners, what you would capture, how it feeds the roadmap and who decides. The one quote is the nearest thing your material carries and stays at its scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Do not extend it into how those sessions were run unless you can say so in your own words | Discovery with integration partners is a stated responsibility; F5 holds the only related evidence and it is medium |
| B4 | "Name the first three metrics for a partner API dashboard, and tell me which one you would trust least." | CASE | [generic] | Propose metrics, then name the assumption behind the one you trust least, before they do. That move converts a gotcha into credibility. Tie it to the open question of how adoption is measured today | Metric question, so it carries the weakest-assumption move; CASE with Prober delivery |
| B5 | "A partner needs a breaking schema change. Walk me through how you would handle it with the squads and the partner." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Structure: what you ask engineering first, what you ask the partner, how the change is staged and communicated, what you would document. Answer slot: R3 names API docs and schemas. If you read or wrote either in your integrations, say which and how, in your own words; if not, say so plainly and stay with the REST API integrations and the playbook | F4 is a `discovery` row; JD content (R3), CASE delivery |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. The 30+ counts client integrations, so keep it attached to that noun | Headline number, so a defend-the-number question; F1 and F3 both rest on it |
| C2 | "Walk me through the integration playbook you wrote — what is in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The quote carries the playbook and that your team uses it; nothing about its contents or reach. Answer slot: describe its parts in your own words and who uses it, at the scope the quote gives; if you cannot say, say so. It is the most inspectable thing you have, so offer to walk it end to end | F4 and the dossier's own confidence band make this the best-supported item and the one most worth showing |
| C3 | "Tell me about the roadmap-input sessions you ran — how did they work?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: quarterly, you ran them, client evidence, to product. Confirmed with limited inspectable proof, so expect a probe. Answer slot: say what you can show from those sessions, in your own words; if there is nothing you can show, say so plainly and describe the sessions as you ran them. Do not describe what product did with the evidence unless you can say it in your own words | F5's medium-confidence claim, rehearsed so the limit is volunteered before it is extracted |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each one of the quotes in your own words, then the adjacent limit said aloud: this is integration work moving toward product, not product experience. Close on your own reason for the role, which this pack does not supply | The arc is the answer to the title objection delivered casually; F1 |
| D2 | "What are you actually playing with in API products these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Pick something recent that involves API docs or schemas, because R3 raises the topic. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, "I wrote the internal integration playbook my team uses", or how you would build fluency | Casual question on a JD topic, still scored; F4 |
| D3 | "What do you know about Quartzline and its partner API platform?" | CO | [generic] | This pack has no researched facts about Quartzline: search was refused. The only sourced material is the role description: a roadmap for the partner-facing API platform, discovery with integration partners, two engineering squads, adoption metrics. Say what the role description says, then ask. Before Thursday, read their public docs and changelog yourself and replace this answer with what you find | CO question the pack cannot ground; honest about it instead of inventing strategy |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our two squad leads each have strong views on their backlog. Where is the seam between you and them, and what happens when you disagree?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Offer seam principles, not a seam you claim to know: who decides what, how disagreements surface, what evidence settles them. Ask which decisions the PM makes alone. Answer slot: R4 names engineering; if you disagreed with an engineer or colleague on an integration, say who, over what and how it ended; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, the integrations in the quote, or how you would handle it | Decision authority is the dossier's unvalidated risk; F5 and F2 |
| E2 | "Tell me about a time you had to keep engineering, sales and a customer pointed the same way." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt on R4. The quote carries the integrations and their stages; it does not show engineering or sales. Answer slot: say which of engineering or sales was involved and what your part was; if neither was, say so plainly and stay with the customer side and the stages you named | R4 coverage; F5 |

### P. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The A1 answer cut to three sentences: the sourced concession ("I haven't held a product manager title"), the quote at its own scope ("I led 30+ end-to-end client integrations of the vendor's REST APIs"), and what you would ask or learn first. If interrupted, pause, restate in one clause, hold, and concede specifically rather than broadly | Same objection as A1 under time pressure; F1 |
| P2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold at the quote: you led them. Answer slot: which of the stages in the quote were yours and which belonged to others, in your own words; if any were not yours, say so plainly. A precise partial attribution scores higher than an overclaim | Attribution probe on the headline claim; F1 |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1, 3+ years product management experience | A1, A2, A5, D1, P1 |
| R1 sub-claim, roadmap and prioritization authority | A1, A2, B2, E1 |
| R2, shipped API or platform products | A4, C1 |
| R3, technical fluency | B5, D2 |
| R4, stakeholder management | E1, E2 |
| R5, agile delivery | A3 |
| Responsibility: roadmap for the partner API platform | A1, B2 |
| Responsibility: discovery with integration partners | B3, C3 |
| Responsibility: adoption metrics | B1, B4 |
| Responsibility: write specs and drive delivery with two squads | none, and why: no verified evidence speaks to it, and a question about it would presuppose a practice; it enters as the ramp plan in A1 and the decision-rights question in B2 |

## Reverse questions

No interviewer profile exists, so none of these is tied to the interviewer's path, and the round is not a peer round, so there is no reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| V1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Dossier question. The job description asserts the authority and nothing in your material shows it; the answer tells you whether the role is the one described, and it reads as diligence |
| V2 | "How is partner API adoption measured today, and what is the current baseline?" | Dossier question. Adoption metrics are a named responsibility with no stated baseline; you need it to know what success means, and it shows you think in measures |
| V3 | "How do the two squads take on partner requests today, and where does that process strain?" | Surfaces the seam from B2 and E1 and shows you are looking for the real problem rather than a role description |
| V4 | "What would a good first ninety days look like for this role?" | Lets the manager state the success bar, which you can then answer against; it matches the ramp plan in A1 |
| V5 | "Where would you expect someone coming from an integration background to need the most support?" | Raises your own gap first, in the register of A2, which reads as self-awareness and gets you real information |
| V6 | "What does discovery with integration partners look like today, and who runs it?" | Tests how much of the discovery responsibility is already built, relevant to C3 and B3 |

## Prohibited claims

Built before the banks and binding on every cell. The first three come from the dossier's `prohibited_claims`; the last two are wordings built locally from your quotes.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims` | The plain acknowledgment this field supports: "I haven't held a product manager title." Then the quote in F1 at its own scope |
| Having owned a product roadmap | `prohibited_claims`; `uncertain_or_weak_areas` acknowledge_gap | "I haven't owned a product roadmap." A plan for learning it, said as a plan. No slot |
| Having set prioritization for an engineering squad | `prohibited_claims` | "I haven't set priorities for an engineering squad." No slot, and B2 is answered in the conditional |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says client integrations of the vendor's APIs, not the release of an API product. A4's slot stays inside the quote's stages |
| Shaped the roadmap through the roadmap-input sessions | Inflated form of F5 | F5's quote at its own scope, with its medium-confidence caveat. The limit is the pack's observation: your material says the sessions fed client evidence to product, not what product did with it |

## Sources

Provided documents: tuesday-dossier.md, pasted in the conversation (version 1.1, generated 2026-08-14). Sections consumed: `role_profile` (requirements and responsibilities, standing as the JD), `handoff_to_mock_interview` (verified candidate evidence, weak areas with allowed strategies, the likely objection, opportunity risks, employer questions, prohibited claims) and `decision` (context only). Not present in the dossier: `evidence_map`, `evidence_state`, `risk_register`. The persona weights rest on the relationship you stated (hiring manager, one 45-minute session), not on any documented Quartzline process.

Searches sent, all refused, nothing returned:
- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline partner API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have fed a values cheat sheet if a values round were detected; none is, so the pack lost no section |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have checked the loop and the hiring-manager format; the persona weights rest on your stated round instead |
| 3. `Quartzline strategy` and recent news | unavailable | The search was refused. It would have grounded D3 and given the CO bank real content; D3 is `[generic]` instead |
| 4. interviewer name and company | n/a | No name was given, so there was no query; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` already fixes the requirements, so no representative JD was needed |

## Upgrade menu

- Interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep note (focus areas, any pre-declared exercise) → coverage assumed from the round type becomes coverage stated, and any deliverable gets its own build section
- Allowing web search → D3 becomes a grounded CO question, a values sheet appears if a values round turns up, and the loop can be checked; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief
- Your answers to the slots in A3, A4 and E2 (and the stage and docs slots in B5 and E1) → rows F3 to F6 move from this pack's derivation to your quoted words
- A roadmap-input session agenda, or the written output product received from one → the medium-confidence claim behind F5, A5 and C3 can rise; the playbook itself already supports the high-confidence claim behind C2
- The full job description text → the responsibilities become quotable raising sources, so more slots and questions can name them
- How many hours you have before Thursday → a prioritized prep schedule, with everything beyond it marked as insurance
