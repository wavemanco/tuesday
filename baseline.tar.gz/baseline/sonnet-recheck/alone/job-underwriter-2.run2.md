I'll read the reference files the skill requires before building the assessment.
**Not a waste of your time, but a reach. R1a (3+ years titled PM experience), the one requirement the JD explicitly marks must-have, is absent. It's a screening risk, not a hard gate, and the rest of your background lands adjacent or direct. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (PM work without the title), R2 (Shipped API or platform products) · unclear: R4b (Sales as a stakeholder) · absent: R1a (3+ years titled PM experience)
- `important` — adjacent: R6 (Discovery with integration partners), R8 (Specs, two squads), R9 (Launches with sales and support) · unclear: R5 (Agile delivery), R7 (Adoption metrics)

R1b and R2 carry your case, and R1a is the row no rewording can fix.

**Opportunity ledger.** The role is specific and well scoped (RR4), but the employer is unverified (RR1), pay is unstated (RR2), and decision rights over the roadmap are unstated (RR3). How strictly the titled-years line is applied is the risk that matters most to you (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify as live and real — RR1; (2) the employer confirms that sustained product-adjacent work without the title is weighed against the 3+ years — R1a, RR5; (3) your answers on ownership hold up as specific, confirmed evidence — G1, G2, R2, R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header as provided; not verified (RR1) |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| First-90-day and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A single-product platform PM role with two squads; narrower than a group-level remit | `[inferred]` from "two engineering squads" and one named product |
| Market calibration | Not run, so no band for title, scope or pay | `[generic]` none; the research was not available (see Evidence status) |
| Unknowns | Salary; decision rights; whether the squads are dedicated; how "3+ years" is applied; what "shipped API or platform products" must mean | `[inferred]` from the JD's silence |
| Contradictions | The JD asks for "shipped API or platform products" as a product-owner credential, while your background is integrating a vendor's APIs for clients; that tension is the substance of R2. No contradiction between JD and resume on facts. | `[inferred]` JD against your stated background |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled years | must_have | absent | none | capability | You state you've never held a PM title, so titled years are zero. No rewording changes that; work done without the title is R1b. | `[grounded]` your statement | none — carried as a screening risk (RR5) |
| R1b | The same requirement, as PM work done without the title | must_have | adjacent | medium | transferability | Confirmed intake prose: quarterly roadmap-input sessions collecting client feedback for product; requirements documents; coordinating engineers and PMs on custom builds. Limit: you fed input to product, and nothing yet shows you decided priorities or owned trade-offs. Intake prose has no inspectable artifact, so `medium`. Some employers read this as a near miss on titled years. | `[grounded]` your stated work; `[generic]` that titled-years lines are often screened literally | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the playbook the team uses. That is deep API fluency from the integration side. Limit: you integrated and shipped client implementations, not the API product itself. A recalled internal triage tool is an unconfirmed lead. | `[grounded]` your stated work; `[inferred]` limit from the JD's "shipped" | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, plus 30+ end-to-end REST integrations. Confirmed prose, no artifact yet; expect a probe. | `[grounded]` your stated skills | none |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client scoping workshops and UAT. | `[grounded]` your stated work | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | Nothing in your background mentions working with sales. Low, not none, because client-facing implementation work often touches sales. | `[grounded]` silence; `[generic]` that implementation roles touch sales | G3 |
| R5 | Agile delivery | important | unclear | low | discovery | Coordinating build work is stated; whether it ran in sprints or against a backlog is not. | `[grounded]` silence on method | none until asked |
| R6 | Run discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly roadmap-input sessions are client discovery. Limit: your clients were customers of your vendor's APIs, and you passed findings on rather than deciding what to build. Resolved downward from "direct". | `[grounded]` your stated work; `[inferred]` limit | G1 |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | No metrics work is stated. A recalled triage tool "adopted by support agents" would bear on this, but it is a memory lead, unconfirmed. | `[grounded]` silence; memory lead, unverified | G2 |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and integration architecture are real spec work. Limit: written for client builds, not a product backlog; team count and cadence are unstated. | `[grounded]` your stated work | G1 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind. Limit: they were customer implementations, not product launches, and sales involvement is unstated (G3). | `[grounded]` your stated work; `[inferred]` limit | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product decisions you owned (R1b, R2, R6, R8; must_have) | transferability | Strong input into product, and spec work for client builds; no stated ownership of what got built or prioritized | R1a cannot move, so how closely R1b and R2 approach product ownership is the case. Resolving it decides how strong the application is. | Deciding which client requests became a custom build and which were refused; a roadmap item you championed that shipped; an API gap you got fixed | A requirements doc, a roadmap-input summary (sanitized), a playbook excerpt, a before/after of something that shipped | `[grounded]` limits from your stated work; `[inferred]` that this decides the case |
| G2 | Adoption of something you built (R2, R7) | discovery | Memory suggests an internal request-triage tool that support agents adopted; nothing confirmed | It could bear on R2 (a product built and adopted) and R7 (adoption tracked) | An internal tool, script, dashboard or process others adopted; how you knew it was used; what you changed after | A screenshot, usage numbers, a short write-up | `[grounded]` memory lead only; `[inferred]` relevance |
| G3 | Sales and launch coordination (R4b, R9) | discovery | Nothing stated about working with sales or on launches beyond client go-lives | R4b is a must-have row and currently `unclear` | Briefing sales on an integration capability; joint client calls; a launch checklist or comms for a release | A launch plan, enablement deck, or release note | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | JD gives no salary | The figure may differ from your current pay; the posting does not let me say. | `[inferred]` from the JD's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Roadmap ownership without stated decision rights | unknown | — | "Own the roadmap … drive delivery with two engineering squads" | Accountability may sit with this role while priorities are set elsewhere; squad capacity is unstated. | `[inferred]` from the JD's scope against its silence on authority | Which roadmap decisions does this role make alone, and are both squads dedicated to the API platform? | unresolved |
| RR4 | Scope is specific and named | positive_signal | — | "partner-facing API platform", "two engineering squads", "adoption metrics" | One product, a named audience and named delivery partners; the work matches the ground you know. | `[grounded]` JD | What does success look like in year one? | noted |
| RR5 | The titled-years requirement may be applied literally | risk_signal | medium | "3+ years product management experience (must-have)" | The line may be screened by title (R1a), so adjacent work could be dismissed before anyone reads it. | `[generic]` pattern for how such lines are often applied, not a claim about this employer | How is the 3+ years applied: would sustained product-adjacent work without the title be considered? | unresolved |

## Application plan

Everything here, the rows and any wording, is proposed, `pending your approval`, and nothing is final until you approve it. Each block is marked separately.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Quartzline's own careers page before spending effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Look for a human route in (a referral or a direct note to the hiring manager) rather than relying on the application form | see R1a, RR5 | `[generic]` how titled-years screens commonly work | pending your approval |
| A3 | Resume edits (below) to put the roadmap-input sessions and playbook in the lead lines | see R1b, R8 | `[grounded]` your stated work | `resume_edits_pending_approval` |
| A4 | Ask RR1–RR5's questions verbatim in a recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | A one-page work sample, such as a spec for an API change with an adoption measure, only if G1 or G2 yields material | see R2, R7 | `[inferred]` from the rows | pending your approval |

**Proposed resume framing — `resume_edits_pending_approval`.** Reorder only; no new claims:

- Lead with: "7 years as a solutions engineer / implementation lead; led 30+ client integrations of our REST APIs end to end."
- Then: "Ran quarterly roadmap-input sessions collecting client feedback for product."
- Then: "Wrote the internal integration playbook the whole team uses."
- No PM title or "product ownership" phrasing. Every clause above is yours.

**Proposed cover-note sentence — `pending your approval`.** "I haven't held a product-manager title. For seven years I led 30+ client integrations of our REST APIs end to end and ran quarterly roadmap-input sessions collecting client feedback for product." It meets the titled-years gap head-on without claiming it away.

## Evidence status

Verified: none yet. Unverified lead: a possible internal request-triage tool that support agents adopted, from agent memory. It prompts G2 only and is not evidence.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology API platform careers Product Manager Platform APIs"; the call was not permitted. It would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | Searched "platform API product manager salary requirements transition from solutions engineer to product manager"; the call was not permitted. It would have moved the market calibration row, RR2 and RR5. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Upgrade menu

- Permission to search: reruns targets 1 and 2 (within the remaining budget) and could clear RR1 and fill the market calibration row.
- Your answer on G1: R1b, R2, R6 and R8 move toward `direct` or are confirmed at their current limits.
- Your answer on G2 (and any artifact): R2 and R7 resolve; a triage tool with usage evidence could raise R7 toward `high`.
- Your answer on G3: R4b and R9 resolve.
- A requirements doc, a sanitized roadmap-input summary or the integration playbook: raises R1b, R2 and R8 above `medium`.
- The hiring manager's name: scope read and which story to lead with.

The dossier offer: I can save all of this as `tuesday-dossier.md` if you want a record to carry forward.

## Questions

1. **G2** — Is there a tool, script, dashboard or process you built that other people adopted? What did you own, how did you know it was used, and did you change it afterward? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G1** — In your roadmap-input sessions or custom builds, was there a case where you personally decided what got built, prioritized or turned down? What was it, and what happened? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **Constraints** — Do you have a pay floor, location or work-arrangement non-negotiables, and would you accept a PM salary below your current solutions-engineering pay? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.