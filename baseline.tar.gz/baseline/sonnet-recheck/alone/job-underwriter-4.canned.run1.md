I've run three searches. The careers page lists the role as Leeds office four days a week, which contradicts the "fully remote" JD. I'm fetching that page to check it.
# Brindlemoor — Senior Pricing Analyst (Odile Varga, Director of Pricing)

## Decision snapshot

**Probably yes on fit, but not yet: the posting contradicts itself on where the job is (R1). Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R9 (Pet-insurance product domain)
- `preferred`: direct: R8

R1 decides whether the rest matters, and R9 is where the move from motor to pet shows.

**Opportunity ledger.** The employer's own careers page disagrees with the JD you pasted on working pattern (RR1) and withholds the salary (RR2). Scope and decision rights are unstated (RR4). One entry runs the other way: the role reports into a named, publicly active pricing practitioner (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers:** (1) which working pattern is current, and whether it works for you (R1, RR1); (2) the salary against your floor (RR2). If R1 meets your terms, this moves to `conditional_go`, on the condition that the motor-to-pet move is framed as adjacent (R9). If you need fully remote and the role is Leeds four days a week, R1 fails and the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, UK insurtech with a pet-insurance product. Its careers page lists this role as live ("Accepting applications") and says it reports to the Director of Pricing. Stage and headcount are not established | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | **Contradiction.** The JD says "Fully remote (UK)"; the careers page says "Leeds office four days a week". Neither is resolved here | `[grounded]` both sources |
| Outcomes and management | No first-year outcomes stated. No line-management duty listed, and whether the role has reports is unstated | `[grounded]` JD silence |
| Scope read | One product, an analyst-level post with a senior title. Recommendations go to underwriting and product, and decision rights are not described | `[inferred]` from the mandate wording against the JD's silence on authority |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. The posting states no salary, so this is a band to expect, never Brindlemoor's offer. Your 5 years, 2 of them senior, sit against a 4+ year ask | `[generic]` pay survey (comp only; scope norms not searched); `[inferred]` for the years comparison |
| Hiring manager | Odile Varga: spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books); previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile snippet |
| Unknowns | Salary, working pattern, team size, which decisions the role owns, how success is measured | — |

## Evidence map

Your background was typed into the conversation, so it counts as CV-equivalent self-report. That caps every candidate claim at `medium` until something inspectable is shown.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location or schedule constraint, so there is no statement to grade. The JD and the careers page disagree, so the role's terms do not settle it either | `[grounded]` JD and careers page, which disagree | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics at a UK motor insurer, 2 of them as senior analyst. Specific, but self-reported with no inspectable artifact | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a level nothing here has probed | `[grounded]` your background | A code sample or sanitized notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. The work is on a motor book, not pet | `[grounded]` your background | A sanitized model spec or factor-selection note would raise to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | discovery | "Built and maintained" covers the build. What monitoring you ran is not stated. The hiring manager's published topic is monitoring, which is a reason to pin this down | `[grounded]` your background; `[inferred]` that monitoring detail matters for this reader, from her talk title | G3 |
| R6 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests last year with the underwriting team" is specific. It does not say whether you designed them, read them, or both, so it resolves to the lower reading | `[grounded]` your background | G4 |
| R7 | Present to underwriting or actuarial leads; recommendations for underwriting and product | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | A sanitized review deck would raise to `high` |
| R8 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R9 | Pet-insurance product domain | important | adjacent | low | transferability | The JD frames the role around "our pet-insurance product" and does not list pet experience as required. It is a scope signal, not a stated requirement. Your GLM and price-test work is the adjacent evidence. It has not touched pet data or pet-specific rating factors, and the claim that it carries over is a derivation | `[inferred]` adjacency from your motor GLM work; `[generic]` that rating factors differ between lines of insurance | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | JD says fully remote and the careers page says Leeds four days a week; you have not said whether either works | A gate: wording cannot fix it, and it decides between `no_go` and moving forward | Not applicable: a term, not experience | The employer's written confirmation of the current working pattern | `[grounded]` the two sources disagree |
| G2 | Pet-insurance domain (R9, important) | transferability | Motor GLM and price-test work. No pet data or pet rating factors | The most likely objection, since you have not worked on pet insurance. The case to make is adjacent, with its limit named | Adjacent: young-driver rating on a motor book. Limit: no pet-specific work. Strengthener: a short sanitized note on how you handled a thin or volatile segment in the young-driver book, if that is true | A sanitized factor-selection or segment note | `[inferred]` bridge from the motor GLM work; `[generic]` that domain switches are the usual objection |
| G3 | Monitoring of rating models (R5, must_have) | discovery | "Maintained" is stated; what was tracked and how often is not | A must-have, and a topic the hiring manager has spoken on publicly | Tracking actual against expected on the young-driver model; scheduled refits or recalibrations; performance reporting that fed the quarterly review; alerts when the model drifted | A sanitized monitoring report or dashboard screenshot | `[grounded]` background silent on monitoring detail; `[inferred]` relevance from her talk title |
| G4 | Price-test design versus reading (R6, must_have) | discovery | "Ran 14 price tests" does not separate design from analysis | A must-have. The JD says "design and read", so which parts were yours shapes the story | Choosing test and control splits; setting sample size or duration; reading results and writing the recommendation | A sanitized test write-up | `[grounded]` background wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | JD and careers page disagree on working pattern (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale, or the role may have moved from remote to office-based after the JD was written | `[inferred]` from the two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week, and which is current? | unresolved |
| RR2 | Salary not stated | unknown | — | No salary appears in the JD | The figure may sit anywhere in the market band in role reality, and the posting gives no way to tell | `[inferred]` from the JD's silence against the `[generic]` band | What base salary range is budgeted for this role? | unresolved |
| RR3 | Reports into a named, publicly active pricing practitioner | positive_signal | — | Careers page: "reports to the Director of Pricing"; her 2025 forum talk "Small Books, Loud Errors" | The role sits under a leader with published practice in model monitoring, which supports real pricing depth above it | `[inferred]` from the reporting line and her public talk | How does the pricing team monitor its rating models today, and what would this role own in that? | noted |
| RR4 | Decision rights and success measures not described | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend without owning any pricing decision, and no first-year outcome is stated | `[inferred]` from the JD's silence on authority and outcomes | Which pricing decisions does this role own versus recommend, and what would success look like at twelve months? | unresolved |

## Application plan

Every row below is a proposal pending your approval. That covers the table and the positioning line in P1; nothing is finalised until you say so. I have not seen your CV, so check E1 against it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the working pattern with the recruiter or Odile's team before writing anything | see R1, RR1 | `[grounded]` the contradiction | pending your approval |
| E1 | `resume_edits_pending_approval`: put three lines near the top, in your own words: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting". Do not upgrade "ran" to "designed" until G4 is answered | see R4, R6, R7 | `[grounded]` your sentences | pending your approval |
| P1 | Positioning: lead your story with the young-driver GLM and what you tracked on it once G3 is answered. Present the motor-to-pet move as adjacent work, never as pet experience | see R5, R9; a choice of emphasis for this reader, not a claim about what she wants | `[inferred]` from her published talk topic | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Contradiction recorded: the pasted JD ("Fully remote (UK)") against the careers page ("Leeds office four days a week"), unresolved.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the posting is live and the reporting line, and surfaced the working-pattern contradiction (R1, RR1). The page gave no stage, headcount or salary |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), search snippet only. Moved the market calibration and RR2. It said nothing on scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Moved role reality's hiring-manager row, RR3, R5's reasoning and P1 |

I can write this up as `tuesday-dossier.md` if you'd like a file to keep.

**Upgrade menu**

- Your CV, or sanitized artifacts (a model spec, a monitoring report, a test write-up, a review deck): raises R2, R3, R4, R5, R6 and R7 toward `high`, and sharpens E1.
- The employer's confirmation of the working pattern: closes R1 and RR1, and settles the decision.
- Your pay floor and any location or schedule limits: adds gate rows checked against the posting.
- The budgeted salary: closes RR2 against the band.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news, public candidate reports; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

- Q1 (G1, R1): Is fully remote a requirement for you, or would four days a week in Leeds be workable?
- Q2 (RR2): What is your minimum acceptable base salary for a role like this?
- Q3 (G3, R5): What did you personally track on the young-driver GLM after it went live (for example actual versus expected, refits, or drift reports), how often, and who saw the results?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.