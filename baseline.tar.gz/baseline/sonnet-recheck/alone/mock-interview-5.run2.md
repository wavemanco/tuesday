I'll read the reference files the skill requires before building the pack.
Bash isn't approved in this session, so I'll do the reordering with direct edits instead.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-5-denied-de17ad79/a92d7045-ec73-44f0-ad6e-88cd04f0bef2/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

- **What it's built on:** your message and the recruiter's email as you quoted it. There is no JD, and I haven't seen the market report, so nothing in the pack comes from it. All five of my web searches were refused, so nothing came from outside your message. That also means no look at Deepa or Ross's public background.
- **POV build:** the pack has a full section for the 15-minute POV. It covers three theses, each with a concession you say aloud. It also covers how to depart from a report their own strategy team wrote rather than recite it, and a timed run sheet that ends on what it means for the operators.
- **Highest-ROI prep:** B1, where Ross's commercial push meets the two limits you stated: you've never sold into rail, and you've never carried a direct quota. It has three follow-up levels.
- **Triage:** the four hours are sized in the pack, with about 100 minutes on the POV and 40 on B1.
- **One thing to settle early:** "operator partnerships" doesn't say whether operators are customers, co-developers or a channel. The pack suggests opening your POV by saying how you read it and inviting a correction.

Say the word and I'll play Ross on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the JD (if you have it) and the report's recommendations section? Either would turn several `[generic]` rows into `[grounded]` ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

- **Round:** second round, one 60-minute panel on Tuesday.
- **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), per the recruiter's email as you quoted it.
- **Shape, per the same email:** the first 15 minutes are your POV with no slides, the rest is Q&A, and "Ross will push on commercials".
- **Built from:** your message only. There is no JD, the market report was not pasted so nothing in this pack comes from it, and every search was refused (see Sources). Where the pack would have used any of those, it says so.

## 1. How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say the beats in your own words.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values (none detected for this round, so no VAL questions) |
| EXP | Whether what you claimed about your past survives scrutiny, including what was actually you |
| JD | Whether you can do the stated job, gaps included |
| CO | Whether you can think at the company's altitude and know the market it sits in |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now: if you did the thing, say how in your own words; if there was no such step, or it was not yours, say so plainly and return to what your quoted words carry.

## 2. Prep triage (4 hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 100 min | Build the POV spine, then say it aloud twice against a 15-minute timer | Section 4 |
| 2 | 40 min | Say B1 aloud through all three follow-up levels until the limit comes out first and calmly | B1 |
| 3 | 40 min | Write, then say, your answers to the slots in C1, C2 and D1. If the way the 6-to-40 and the £4M were counted can be recovered from your own records, recover it; if not, rehearse saying you do not know | C1, C2, D1 |
| 4 | 30 min | Talk through A4 and D3 once each: Ross's commercial case and where your own plan fails | A4, D3 |
| 5 | 20 min | Time the 90-second arc, and pick two reverse questions | E1, section 7 |
| Buffer | 10 min | Rest | |

Everything else in this pack is insurance.

## 3. Fit snapshot

No JD was supplied, so the requirements are the recruiter's own words and your role title, quoted. Nothing is graded against a JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "Never sold into rail specifically" — your message | medium | [grounded] | transferability | Your material carries an ISV channel at a payments company and a stated limit on rail, not operator partnerships, with nothing inspected behind the count. Words, at the quote's own scope: "I ran the ISV channel at a payments company and took it from 6 partners to 40, roughly £4M of influenced revenue." Answer slot: the recruiter asks for operator partnerships, so expect a probe on what carries over from the channel. If some part of how it grew carries over, say which, in your own words; if none obviously does, or the part was not yours, say so plainly and stay with the 6 to 40 |
| F2 | "land on what it means for the operators themselves" — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and does not say which side "the other side" is. Words, at the quote's own scope: "I spent 5 years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter asks you to land on operators, so expect a probe on what operators would notice. If that work gave you a view of operators' priorities, say what you saw; if it did not, or it was a different side of the table, say so plainly and stay with network planning |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue, with nothing inspected behind it, and you have stated the quota limit. Words: "I haven't carried a direct quota; my number was influenced revenue." Then the figure at its own scope. Answer slot, the four a figure raises, each in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F4 | "Senior Partnerships Manager" — role title in your message | "9 years in partnerships" — your message; "last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead with the facts in the quotes' own terms: 9 years in partnerships, the last 4 running the ISV channel at a payments company. A named record beats an adjective |

No requirement here is a gate: the material names no authorization, location, travel or schedule term. A JD may.

## 4. Graded deliverable: the 15-minute POV

The recruiter's words: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it" and "Please land on what it means for the operators themselves."

### 4a. Grounded facts to build on

| # | Fact | Draws on | Provenance |
|---|---|---|---|
| 1 | The brief is 15 minutes, no slides, an 18-month horizon, and a close on the operators themselves | The recruiter's email, quoted above | [grounded] |
| 2 | The market report was circulated internally by their strategy team last quarter, and you have read it. The pack has not seen it | Your message | [grounded] |
| 3 | "took it from 6 partners to 40, roughly £4M of influenced revenue" | F1 | [grounded] |
| 4 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | F2 | [grounded] |
| 5 | "never carried a direct quota, only influenced revenue" | F3 | [grounded] |

### 4b. Open by saying your reading of the brief

"Operator partnerships" is the recruiter's phrase, and it does not say whether the operators are customers, co-developers or a channel. Spend the first 30 seconds saying how you read it and inviting a correction; the rest of the POV then stands on a reading both panelists have agreed to. [inferred] from the phrase as quoted; the report may settle it, and the pack cannot check.

### 4c. Three defensible theses

Pick one. Every one carries a concession you say aloud, and all three are role-family patterns, not claims about Kelverton, so test each against the report before choosing.

| Thesis | Mandatory concession | Where it departs from the consensus answer | Provenance |
|---|---|---|---|
| T1. Depth before breadth: choose a small number of operator partnerships and agree a joint plan with each in the operator's terms before widening | It means saying no to some operators' asks, which some will read as neglect, and it needs operator-by-operator knowledge your material does not yet show you have (F1, F2) | A broad-coverage shortlist is what a prepared candidate assembles from the report; this one narrows it and says what is left out | [generic] |
| T2. Make operator-side outcomes the unit of every partnership: a short list of outcomes the operator's own people would recognise, reviewed on a fixed cadence, with Kelverton's commercial measure tied to them | Outcomes are influenced rather than controlled, and Ross will say outcomes are not revenue. F3's own words apply here: "only influenced revenue" | It puts the operator's measure first and the vendor's second, which a revenue-led shortlist rarely does | [generic] |
| T3. Bring other parties (integrators, data providers, consultancies) into operator partnerships so operators get more without Kelverton building it | It makes Kelverton depend on third parties' quality, and your channel record (F1) is of ISV partners, not operators | It extends the partnership rather than deepening it, and only works if operators want it | [generic] |

### 4d. Differentiate from the report, never recite it

The report came from their own strategy team, so recitation scores as homework. Bring one conclusion you agree with to prove you read it, then one place you diverge, with your reason and what would change your mind. Neither the conclusion nor the divergence can come from this pack, which has not seen the report: both are yours to fill.

The anti-pick: the role includes saying no, so name one thing in the report, or one thing the panel would expect, that you would not do in 18 months, and why. One pull to resist: proposing a bigger channel because a channel is what your material carries (F1). Unless the report or the panel says operators want one, that is the answer the pack would decline. [inferred]

### 4e. The close the recruiter asked for: what it means for the operators

End on the operator, in the operator's words rather than ours. Three parts, each said in a sentence: what an operator gets by month 18 that it does not get today; what it costs the operator (sponsor time, data, a decision); and what the operator can hold Kelverton to. The third gives Ross a commercial hook and makes the close land. Name the measure in operator terms yourself; the pack supplies none.

### 4f. Timing

| Minutes | Beat |
|---|---|
| 0:00 to 1:00 | Your reading of "operator partnerships", and an invitation to correct it |
| 1:00 to 4:00 | The one conclusion from the report you agree with, and what it does to your plan |
| 4:00 to 10:00 | Your thesis, with the 18 months in three stages: the first 90 days, to month 9, to month 18 |
| 10:00 to 12:00 | Your concession, your divergence from the report, and what you would test first |
| 12:00 to 15:00 | The close on the operators, then stop |

Say any figure from your own record as influenced, every time.

## 5. Persona table

The loop is one session, established by the recruiter's own words, so no archetype fallback applies. The weights rest on those words and on the relationship priors, not on any documented Kelverton process.

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Deepa turning your POV into live problems: sequencing, an operator's unmet ask, how you'd measure success | High. She is "your future manager" (recruiter's words), so the hiring-manager prior applies (Case/Strategist plus Skeptic), and a 15-minute POV invites case-style follow-ups | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic (B, 5 questions) | The gaps: no rail selling, no direct quota, bus and light rail rather than train operating companies (F1, F2, F3) | High. The same hiring-manager prior, plus limits you have stated yourself, and Ross's commercial push meets them head on | Rehearse B1 until it is boring: name the limit first, hold, concede specifically, then give a ramp plan as a plan |
| Data-Driven Prober (C, 3 questions) | Ross taking both headline figures down to their assumptions | Medium. "Ross will push on commercials" (recruiter's words) and two figures sit in F1 and F3. The recruiter's wording does not say whether the push is about numbers, so it gets 3 questions rather than 5 | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know; name the weakest assumption before they do |
| Pressure (D, 3 questions) | Ross interrupting, time-boxing, asking how much was actually you | Medium. "Push" could mean content depth rather than style, and the pack cannot tell which from one word | Pause, restate the question, anchor in what you actually said, hold through two follow-ups before conceding anything real |
| Conversational (E, 2 questions) | The unstructured Q&A, the biography opener, the "any questions for us" slot | Low to medium. It is scored even when it feels friendly | A pre-timed 90-second arc; never answer "I think you've covered everything" |

Not included: Values/Behavioral, because no values-style round is detected (the recruiter's words name none), and Peer Evaluator, because neither panelist is a peer by the recruiter's words. If either appears, B4 and E1 are the nearest ground.

## 6. Question banks

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Of everything in your 18 months, what do you do in the first 90 days, and what do you deliberately not do?" | JD | [generic] | Structure it as a plan: the one thing you must learn before you act, the one or two moves that follow from the thesis you chose in section 4, and one thing you would refuse to start early, and why. Make the "not do" real, something you would be tempted by. If part of it depends on facts you do not have yet, say what you would ask first | Deepa is the hiring manager and the POV invites a sequencing probe; F1 is the requirement it presses on. JD because it scores the stated POV, with CASE delivery |
| A2 | "An operator tells you the thing they most want from us is not something we offer. What do you do?" | CASE | [generic] | Clarify first: what outcome sits behind the ask, and whether it is a real gap, a misunderstanding or a preference. Then the three honest answers, yes, not yet and no, and what each costs. Say who you would bring in and what you would say to the operator in the room. Promise nothing you cannot see the way to deliver | The question forces operator-side thinking, which the recruiter asked you to land on (F2), and the role includes saying no. CASE because it is a live problem from the role |
| A3 | "Which conclusion in the market report do you read differently from the strategy team, and what does that change in your plan?" | CO | [generic] | The pack has not seen the report, so everything report-specific is yours to fill. Name one conclusion you agree with and what it does to your plan, then one you read differently, with your reason and what would change your mind. Say it respectfully: the people asking circulated or have read it. If you read nothing differently, say what you would test first | Both panelists are likely to know the report, so this probes whether you can depart from it with reasons (F1). CO because it scores whether you can think at the company's altitude |
| A4 | "A large operator will pilot with us but will not pay for the pilot. What terms do you want before you say yes?" | CASE | [generic] | Clarify what the pilot is for, who sponsors it inside the operator and what happens at the end. Terms to put on the table: a named sponsor, a time box, success criteria agreed in writing beforehand, a decision date that converts the pilot to paid or ends it, and what each side puts in. Say where you would walk away. Concede that you do not yet know Kelverton's pricing or pilot policy and would check it first. Say it as how you would think, not as something you have done | Ross will push on commercials, and this is a commercial structure problem that needs no quota (F3). CASE because it is a live deal problem |
| A5 | "What would you measure at months 6, 12 and 18 to know your plan is working, in the operators' terms and in ours?" | CASE | [generic] | One operator-side measure someone at the operator would recognise, one Kelverton-side commercial measure, and one leading indicator per period. Say how you would count each before Ross asks, and name the one you trust least. If you offer influenced revenue as the Kelverton-side measure, expect to be asked for a direct one; B1 rehearses that | It joins the operator close (F2) to the commercial push (F3). CASE with CO content, because the measures have to fit Kelverton's own model |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail, and you've never carried a direct quota. Why should we trust you with operator partnerships commercials?" | JD | [grounded] "Never sold into rail specifically" "never carried a direct quota, only influenced revenue" "took it from 6 partners to 40, roughly £4M of influenced revenue" | The highest-ROI rehearsal in this pack. Name the limit before it is asked for, in your words and only as far as your message goes: "I've never sold into rail specifically, and I've never carried a direct quota; my number was influenced revenue." Then what your quotes carry, at their own scope: you ran the ISV channel and took it from 6 partners to 40, roughly £4M of influenced revenue. Keep the word influenced every time. Follow-up one, "so what was actually yours?": use the four slots in C2. Follow-up two, "would you accept a direct target?": decide before Tuesday and say it plainly, and if you would want to know how the target is set first, say that. Follow-up three, "so you cannot commit to a number?": add nothing to the record, concede it is a limit, then say how you would learn the commercial model in your first 90 days, as a plan | F3 is where your stated limits meet Ross's commercial push, so some form of this is the most likely objection. JD because it scores the commercial requirement, with Pressure delivery. It has three follow-up levels, the most in the pack |
| B2 | "Which parts of running your ISV channel carry over to operators, and which don't?" | JD | [grounded] "last 4 at a payments company running the ISV channel" "took it from 6 partners to 40, roughly £4M of influenced revenue" | Open on what the quotes say: you ran the ISV channel at a payments company and took it from 6 partners to 40. Answer slot: if some part of how it grew carries over to operators, say which and why, in your own words; if none obviously does, or the part was not yours, say so plainly and stay with the 6 to 40. Then name one thing you expect to differ about operators and how you would find out; if you do not know yet, say that | F1 is the evidence for the operator requirement, and it is adjacent rather than direct, so this is the likeliest probe on it. JD because it scores the stated requirement |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" "never carried a direct quota, only influenced revenue" | Choose the weakness you actually believe, in one sentence: your stated limits are rail selling and a direct quota, and either is a true answer; do not invent a safer one. Then the ramp as a plan in two beats: who you would learn from and what you would have understood by day 90. Do not present the plan as something already done | F1 and F3 carry the stated limits. JD because it scores honest self-assessment against the role, which the Skeptic tests |
| B4 | "You spent five years in transport consulting and nine in partnerships. What took you from one to the other, and why this role, now?" | EXP | [grounded] "9 years in partnerships" "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The pack does not know your reasons, so they are yours to supply. Give one specific, true reason for each move, consistent with each other and with E1, and with no criticism of a previous employer. If there was no single reason, say that and give the nearest true thing | Motivation consistency is what the Skeptic scores, and F2 and F4 are the two moves it asks about. EXP because it tests whether the career story holds together |
| B5 | "Your operator experience is bus and light rail. How much of that transfers to train operating companies?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "Never sold into rail specifically" | Say what the quote says: 5 years in transport consulting, in bus and light rail network planning. Answer slot: if any of that work touched how operators plan or run service, say what you saw; if it did not, or it was a different side of the table, say so plainly and stay with the network planning. Then say what you would go and learn about train operating companies, as a plan. Do not say you know their world | F2 is adjacent rather than direct, and the question tests the exact seam. JD because it scores the operator-knowledge requirement |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The ISV channel went from 6 partners to 40. How was that counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Four slots, each in your own words: how the 6 and the 40 were counted, what the 40 is most sensitive to, the assumption behind it you would defend least (name it before they do), and which part of the growth was yours. If you do not know how it was counted, say so plainly and say what you do know. Do not reconstruct a method you cannot repeat under a second question | F1 holds the first headline figure, and the Prober reads figures down to assumptions. EXP because it tests the claim, not the job |
| C2 | "Roughly £4M of influenced revenue: what does influenced mean in that figure?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" "never carried a direct quota, only influenced revenue" | The same four slots as C1, for this figure: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Say it with the acknowledgment your message supports: "I haven't carried a direct quota; this is influenced revenue." Keep the word influenced whenever you say the number | F3 holds the second headline figure, and Ross's commercial push lands here first. EXP because it is a defend-the-number question |
| C3 | "Give me a rough approach to forecasting partnership-influenced revenue from operators over the next 18 months. What do you need first?" | CASE | [generic] | Clarify what counts as influenced here, the sales cycle, which operators, and the baseline. Structure it by segment and stage, list your assumptions explicitly, and name the weakest. Give a range, not a point, and say what data you would request. Use no number from your own past as the baseline | It tests commercial reasoning without needing a quota, which is where F3 is thin. CASE because it is a live forecasting problem from the role |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result: how much of it was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold-then-concede. Pause and restate the question. Anchor in what you said: you ran the ISV channel and took it from 6 partners to 40, and the figure is influenced revenue. Hold through two follow-ups. The concession is specific, and it is a slot: say, in your own words, who else contributed and how; if it was all you, say that plainly; if you do not know the split, say so. Do not fold on running the channel, and do not extend it | The attribution probe is the standard Pressure move on F1. EXP because it tests what was actually yours |
| D2 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" "took it from 6 partners to 40, roughly £4M of influenced revenue" "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Concede first, plainly: "I haven't sold into rail specifically." Then two beats, each a quoted fact at its own scope: the ISV channel from 6 to 40 partners, roughly £4M of influenced revenue; 5 years in transport consulting, in bus and light rail network planning. Close with what you would do in your first 90 days. Let them draw the inference: do not say you understand operators better than someone who has sold to them | F1 and F2 are your two adjacent strengths and the stated limit sits beside them. JD because it scores fit against the role, Pressure in delivery |
| D3 | "Tell me where your plan is most likely to fail." | CASE | [generic] | Name the weakest assumption in your own POV before they do: the one under the thesis you chose. Say what would show it failing early and what you would do then. Be specific, not general. If pressed on why you presented it anyway, hold: say what you would test in the first 90 days | It tests whether you can hold a plan you have just conceded the weakness of (F1). CASE because it is a live problem on your own POV |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships" "last 4 at a payments company running the ISV channel" "took it from 6 partners to 40, roughly £4M of influenced revenue" "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc in four beats, each a clause the quotes state: 9 years in partnerships; the last 4 running the ISV channel at a payments company, from 6 partners to 40, roughly £4M of influenced revenue; before that, 5 years in transport consulting, in bus and light rail network planning; then why this role, which is a slot for your own reason, consistent with B4. You may lead with the transport thread if you want the operator thread first. Time it | F4 and F1 are the spine of the biography, and the arc is the casual question most likely to be scored. EXP because it is the CV told aloud |
| E2 | "Any questions for us?" | CO | [generic] | Pick two from section 7: one for Deepa's remit and one for Ross's. Never say "I think you've covered everything". Ask the question that resolves what "operator partnerships" means early, if the POV has not already settled it | The Q&A is unstructured, so this slot is the one most likely to be scored as a preparation signal |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 operator-partnership POV | A1, A3, B2, D1, D3, and section 4 |
| F2 land on what it means for the operators | A2, A5, B5, D2 |
| F3 commercials | A4, A5, B1, B3, C1, C2, C3, D2 |
| F4 Senior Partnerships Manager | B4, E1 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "When you say operator partnerships, which would you point to today as working best, and what makes it work?" | It settles whether operators are customers, co-developers or a channel, which your whole POV rests on |
| 2 | "Which number would this role be measured on in the first year, and who sets it?" | It brings the commercial question to Ross on your terms, after you have named your own limit |
| 3 | "What would you want operators to say differently about us by month 18?" | It ties the conversation to the operators' side, which the recruiter asked you to land on |
| 4 | "The report was circulated last quarter. What has changed since, in your view?" | It shows you read it and are thinking about how current it is, without disagreeing with it |
| 5 | "Who should I spend my first 30 days with: operators, product, support, someone else?" | It is a ramp plan asked as a question, which answers the day-one weakness before the Skeptic does |
| 6 | "What would make this a no for you after today?" | It surfaces any remaining doubt while you can still answer it |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Generated, sourced, closed or won roughly £4M | Inflated form of F1 and F3 | The quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not direct. C1 and C2 slots stay inside the figure |
| Carried a quota or owned a revenue target | Negative you stated, F3 | "I haven't carried a direct quota; my number was influenced revenue." No slot |
| Sold into rail, or knows rail buyers | Negative you stated, F1 | "I've never sold into rail specifically." No slot |
| Built the ISV channel from nothing | A claim your quote contradicts | The quote: "took it from 6 partners to 40". Nothing more |
| Knows train operating companies from the inside, or their scheduling | Inflated form of F2 | The quote at its own scope: "5 years in transport consulting (bus and light rail network planning". The limit is the pack's observation: your material says bus and light rail network planning, not train operating companies. B5's slot stays inside the network planning work |

## 9. Sources

Provided: your message, including the recruiter's email as you quoted it. The market report was described but not supplied, so nothing in this pack draws on it. No dossier was present.

Searches sent, all refused (no results came back):

- `Kelverton Rail values`: refused
- `Kelverton Rail interview process partnerships manager`: refused
- `Kelverton Rail strategy train operating companies scheduling software news`: refused
- `Deepa VP Partnerships Kelverton Rail`: refused
- `Senior Partnerships Manager rail technology job description train operating companies`: refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The call was refused. It would have fixed the values cheat sheet, which is dropped here because no values-style round is detected either way |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | The call was refused. It would have checked the loop; the recruiter's own words establish this round, so the weights stand |
| 3. `Kelverton Rail strategy` and recent news | unavailable | The call was refused. It would have grounded A3 and A5 and added the grounding brief |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | The call was refused. It would have supplied the interviewer read and a reverse question tied to a public career path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The call was refused. It would have given the fit snapshot requirements to grade against |

## 10. Upgrade menu

- The JD text → F1 to F4 gain requirements quoted from it, mid-list requirements get JD questions, and any gate (location, travel, a right-to-work term) is checked
- The market report's recommendations, pasted → section 4d gets a named consensus item and anti-pick, and A3 moves from `[generic]` to `[grounded]`
- Search permission for this session → official values and recent news, a public-footprint read on Deepa and Ross, and a reverse question tied to a path of theirs
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once, needs the same permission
- How the 6-to-40 and the £4M were counted, and who else contributed, said in your own words outside a drill → F1 and F3 move from answer slots to story-mapped rows, and C1, C2 and D1 are rewritten
- The recruiter's answer to what "operator partnerships" covers → section 4b stops being an assumption, and A1 and A2 are retuned
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence, per-gap strategy limits and a named top objection replace the ones this pack inferred
