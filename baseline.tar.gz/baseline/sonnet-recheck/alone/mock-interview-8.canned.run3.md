I'll read the reference files first.
Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-canned-1d3d9384/50543760-1029-416c-9d4f-a1e51b4a760e/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. It has one mini-pack per round, 27 questions in all.

I ran no searches, because your JD, values, recruiter email and strategy summary already covered everything a search would have fed. Your recruiter's email dates the rounds 21 October and you copied the values on 12 October, but my calendar reads 5 November. If those rounds have passed or moved, tell me and I'll rebuild the pack around what happened.

- **Biggest objection:** Your message says you've never worked in a contact centre, and the JD's headline duty covers the contact centre. Question C1 in Round 2 rehearses this: say the limit before they ask, hold only what your complaints-log work shows, and concede specifically under two follow-ups. B1 is the short version for the recruiter screen.
- **Second gap:** You've never presented above regional level. C2 and C4 cover it, and B4 is the short Round 1 version.
- **Answer slots:** Several questions end with an "answer slot" instead of a script, where your material is silent or thin. These are regulated complaints, what your monthly spreadsheet counted, which tool it was, coaching supervisors, and digital work. Your real answer, or an honest "that wasn't me", goes there. Answering them outside a drill would strengthen the matching rows.
- **Values round:** The cheat sheet covers all four values. Only Own the Fix and Plain Words have a quoted sentence of yours behind them, and each of those carries a single beat. Members First and Neighbours, Not Numbers are selection scaffolds, because nothing you wrote carries a story for them.
- **Hubs and branch managers:** The panel are branch managers and the strategy consolidates eight branches into five hubs, so expect pressure on Neighbours, Not Numbers. K3 rehearses that.

I can play the Skeptic on C1 as a live drill, with follow-ups and feedback against the pack's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds, all on 21 October 2026 per the recruiter's email.

| Round | Length | Who | Relationship |
|---|---|---|---|
| 1 | 30 minutes | The recruiter (name not given) | Recruiter screen |
| 2 | 45 minutes | The Head of Member Services (name not given) | Your future manager, "mostly behavioural" |
| 3 | 60 minutes | A panel of two branch managers (names not given) | Panel, including "a 20-minute case on a complaint escalation", and the values round: "they score against the four values" |

Interviewer names are not assigned beyond these roles, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: every line of proposed wording below is pending your approval, and you should say it only in your own words and only if it is true for you.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | How you structure a live problem from the role |

Provenance labels: `[grounded]` traces to something you or Ashgrove supplied, `[inferred]` is this pack's derivation, `[generic]` is a pattern with no claim about you or Ashgrove. Where guidance rests on your past, the Provenance cell quotes your own sentence.

The single highest-ROI rehearsal in this pack is **C1** (Round 2), with **B1** as its short form for Round 1. Your own message states you have never worked in a contact centre, and the JD's headline duty covers the contact centre. This question will arrive in some form.

## Fit snapshot

Your background came in your message, not a CV, so every evidence cell cites "your message". Nothing has been inspected behind these lines.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (branches half) — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "I handled the branch's formal complaints log." The pack's observation: your material says one branch's log, not the process across branches. Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any further step was yours, say which and what you decided, in your own words; if the log was the extent of your part, or there was no such step, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (contact-centre half) — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The pack's observation: your material says formal, and does not show which outside rules governed the complaints. Answer slot: expect a probe on what rules or deadlines applied to the complaints in the log. If any did, say which and what they required of you, in your own words; if none did, or you did not work to them, say so plainly and stay with the log |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Words stay at the quote's scope: you built it, and your regional manager uses it. The material does not say what it counted. Answer slot: say what it counted and which part of it you would trust least, in your own words; if you do not know how a figure in it was reached, say so plainly and stay with having built it |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Words stay at the quote's scope: "I trained new tellers on our escalation script." The pack's observation: your material says tellers and a script, not supervisors or coaching. Answer slot: expect a probe on a real escalation you guided someone through. If you did, say what happened and what part was yours; if not, say so plainly and stay with training the tellers |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." The pack's observation: your material does not say whether Ashgrove counts regional level as senior, so that sentence is the whole claim. Then how you would prepare, said as a plan and never as a past |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your message says spreadsheet and does not name the tool. Answer slot: say which tool it was. If it was Excel, say what you would defend as its most involved part; if it was another tool, or Excel only lightly, say so plainly and stay with the spreadsheet you built |
| F8 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms: six years in retail banking, the last three as a branch supervisor, because a named record beats an adjective |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD's line makes a probe likely. If you have worked with a digital team or on a self-service journey, say what it was and what part was yours; if not, say so plainly and return to the complaints log you handled |

Proposed wording in the bridge column: pending your approval.

## Grounding brief

From the 2026 strategy brief published in June 2026, as you described it to me. I have your summary, not the brief itself.

| Item | What the brief says, as you reported it | Used in | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | A3, K2 | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | K3, V3 | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | A2 | [grounded] |
| Competitive frame | "the main competitive pressure is app-only banks" | A2, K2 | [grounded] |

Use these as vocabulary, not as a recital: the panel can read the same brief.

## Persona table

| Persona | Where it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Round 1 | High in Round 1. A recruiter screen tilts conversational with light probing, and the email names no focus areas | Rehearse the 90-second arc in A1 from your three quoted sentences; treat casual questions about digital and strategy as scored |
| Skeptic | Round 1 light, Round 2 heavy | High in Round 2. The Head of Member Services is your future manager, who is buying capability and derisking gaps, and your message states two limits the JD presses on | Rehearse C1 until it is boring: limit first, hold what the quote carries, concede specifically |
| Values / Behavioral | Round 2, Round 3 | Medium in Round 2 because the email says "mostly behavioural". Highest in Round 3 because "they score against the four values" | Map a story to each published value where one of your sentences carries it; use the selection scaffolds with their honest branch where none does |
| Case / Strategist | Round 3, light in Round 2 | High in Round 3: the email names "a 20-minute case on a complaint escalation" | Clarify, objective, owner, actions, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Round 2 | Medium. The JD asks for monthly reporting and Excel, and you built a monthly complaints spreadsheet | Know what you can and cannot say about what it counted; say plainly when you do not know |
| Peer Evaluator / stakeholder | Round 3 | Medium. The JD has you coaching branch supervisors, which puts branch managers on the receiving end of your work [inferred] | Reciprocity: what you bring and what you need; offer seam principles, not a claim to know their seam |
| Pressure | Any round | Low. No source suggests a stress format; hold-then-concede in C1 covers it | Pause, restate the question, hold through two follow-ups |

## Round 1: Recruiter screen (30 minutes)

Weights: Conversational high, Skeptic light. Expect motivation, knockout checks against the JD, and logistics.

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey. How did you get here, and why this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with only the beats those sentences state: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you built the monthly complaints spreadsheet your regional manager uses. Answer slot: why this role is yours to say in your own words; the pack does not write your reason. Rehearse it to 90 seconds and stop | The biography question opens most screens and is scored. F8, F1 and F4 supply the arc; EXP because it tests whether the story is yours |
| A2 | "What do you know about Ashgrove, and what draws you to a member-owned credit union?" | CO | [grounded] | Name one value by its exact name and one strategy item from the grounding brief, and say in your own words how it connects to complaints. Do not recite the list. Whether you are a member or have used Ashgrove's services is yours to say; the pack has nothing on it. A candidate who can name an app-only competitor pressure and a Q1 2027 lending launch sounds current | Recruiters score homework and motivation in a friendly register. CO because it tests knowledge of the strategy; grounded in the brief you were sent |
| A3 | "What have you done on digital or self-service?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: the JD's digital-teams line makes this likely. If you have worked with a digital team or on a self-service journey, say what and what part was yours; if not, say so plainly and return to the complaints log you handled. Then, as a plan only, say what you would want to learn before suggesting any journey change, tied to the 40% digital aim | F9 is a silent row, so the honest branch is rehearsed before it is probed. JD because it scores a stated requirement |
| A4 | "Why are you looking to move now?" | JD | [generic] | One forward-looking reason, in your own words, tied to the role's complaints focus. No criticism of your current employer. The pack has nothing on your reasons, so it supplies none | Motivation consistency is the recruiter's standing check; generic because it is a pattern, not a fact about you. JD because it scores fit with the role |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. You come from branches. Where does that leave you?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Short form of C1. Limit first: "I haven't worked in a contact centre." Hold what the quote carries: "I handled the branch's formal complaints log." Then one plan sentence on what you would learn first about how the contact centre receives and logs complaints. Do not claim contact-centre exposure or equivalence | F2 is the gap the JD's headline duty presses hardest. JD because it scores a stated requirement; the full rehearsal is C1 |
| B2 | "The role asks for 4+ years in financial-services customer operations. Talk me through yours." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in the quote's own terms and stop: six years in retail banking, the last three as a branch supervisor. Answer slot: if asked what the work covered day to day, say in your own words; the pack lists none of it | A knockout-style check on F8, which the message already meets. JD because it scores the years requirement |
| B3 | "Have you handled regulated complaints?" | JD | [inferred] "I handled the branch's formal complaints log" | Hold at the quote's scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what rules or deadlines applied to the complaints in the log. If any did, say which and what they required of you; if none did, or you did not work to them, say so plainly and stay with the log | F3 is a discovery row, so the honest answer depends on facts only you hold. JD because it scores a listed requirement |
| B4 | "The role presents to senior leaders. Have you done that?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Say the limit plainly and stop: "I've never presented to anyone above regional level." Do not say the spreadsheet was presented; the quote says your regional manager uses it. Then a plan: ask what format leaders want and rehearse the first one with your manager | F6 is stated by you and the screen is where it surfaces cheaply. JD because it scores a listed requirement |

Proposed wording above: pending your approval.

### Round 1 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| RA1 | "Can you tell me anything about the format of the 20-minute case, such as whether materials come in advance?" | Recruiters can usually answer process questions, and it shows you are preparing a structured response |
| RA2 | "How does the complaints process split today between the branches and the contact centre?" | Shows you are already thinking about the seam the JD asks you to own |
| RA3 | "What would the Head of Member Services most want to hear from a candidate in round two?" | Asks for the recruiter's read of the manager without presuming it |
| RA4 | "Which rules or regulator does the complaints process sit under at Ashgrove?" | Shows you know the JD's "regulated" word needs a specific answer, and fills a gap in your material |

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

Weights: Skeptic high, Values/Behavioral medium, Prober medium. The email says "mostly behavioural", so expect stories, with the Skeptic's questions coming as gaps in them.

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role owns complaints across branches and the contact centre. You haven't worked in a contact centre. Convince me you can own a process in a channel you haven't worked in." | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "6 years in retail banking, the last 3 as a branch supervisor" | **Highest-ROI rehearsal.** Say the limit before it is asked for: "I haven't worked in a contact centre." Hold what the quotes carry: you handled the branch's formal complaints log, over six years in retail banking, the last three as a supervisor. Follow-up 1, "What makes you think it carries over?": concede you do not yet know how the contact centre differs, then say as a plan what you would ask first, such as how calls become logged complaints and where timing is measured. Follow-up 2, "Ownership means decisions from day one": concede specifically that you would lean on contact-centre colleagues for the first decisions in that channel, and name what you would ask them. Hold the core: you know formal complaints from the branch side. Never claim the channels work alike | F2 is the largest stated gap against the JD's headline duty. JD because it scores the stated requirement; it carries the deepest follow-up chain in the pack |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Name one limit before being pressed, from the two your message states, and choose the one you honestly think is larger. One sentence of limit, one of plan. Naming both can read as candour; naming one you cannot stand behind does not. Answer slot: if a third area is yours to name, say it; the pack has no material on it | The Skeptic's stem is aimed at F2 and F6. JD because it scores self-assessment against the listed duties |
| C3 | "You'd coach branch supervisors on escalations. What have you done on that front?" | JD | [grounded] "trained new tellers on our escalation script" | Hold at the quote's scope: "I trained new tellers on our escalation script." Answer slot: if you guided anyone through a live escalation, say what happened and what part was yours; if not, say so plainly and stay with training the tellers. Then as a plan only, say how you would begin with a supervisor, such as asking them to talk you through a recent escalation first | F5 is adjacent evidence with a step up in audience. JD because it scores a stated duty |
| C4 | "You'd present monthly to senior leaders. How would you run the first one?" | CASE | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Limit first, in the quote's words. Then structure the plan aloud: ask what decisions they want from it, lead with the headline, show complaint volumes and resolution times (the JD names both), say what you would not claim yet, and ask for feedback after. Do not say you have presented the spreadsheet | F6 plus F4. CASE delivery of a JD requirement; a plan shows you can prepare for what you have not done |

### Bank D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said it plainly, and an intact working relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. Generic because the pack has no story of yours that carries it; VAL because it tests behaviour over assertion |
| D2 | "Tell me about a time you coached a colleague through a difficult escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on the one beat the quote states: you trained new tellers on the escalation script, told in your own words. Answer slot: the JD asks about coaching on escalations, so expect a probe on a real one. If you walked someone through a live one, say what happened and what was yours; if not, say so plainly and stay with training them | F5, rehearsed so the honest limit is ready. EXP because it tests what was actually yours |
| D3 | "Tell me about the hardest complaint you've handled." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one that was in the log you handled, with a named stake, a decision that was yours, and what the member ended with. Say only what happened. If no one stands out, say so plainly, then give the nearest thing your material carries, or how you would approach it | F1 and F3 are your only complaint-handling evidence. VAL/EXP: it shows Own the Fix and Members First in action, if a real story exists |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet. What did it count?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the quote says: you built it, and your regional manager uses it. Answer slot: say what it counted and which part of it you would trust least, in your own words; naming that before they do is a credibility gain. If you do not know how a figure in it was reached, or part of it was someone else's, say so plainly and stay with having built it | F4 is where a prober tests the one reporting claim you have. EXP because it tests attribution and the weakest assumption |
| E2 | "Excel reporting is on the JD. Tell me about the reporting you've built." | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Hold at the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say which tool it was. If Excel, say what you would defend as its most involved part; if another tool, or Excel only lightly, say so plainly and stay with what you built | F7 is a discovery row with the tool unnamed. JD because it scores a listed requirement |

Proposed wording above: pending your approval.

### Round 2 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| RB1 | "Given I haven't worked in a contact centre, what would you want me to learn first?" | Converts the biggest objection into a joint plan and signals candour |
| RB2 | "What would make you say, twelve months in, that this hire was the right call?" | Asks the manager for their own scorecard |
| RB3 | "Where do complaints sit in the plan to move 40% of member service to digital by 2028?" | Ties the role to the brief and tests how far digital teams are already involved |
| RB4 | "What are the complaint types or channels that worry you most right now?" | Shows you want to start where the manager's pain is |

## Round 3: Panel of two branch managers (60 minutes, with a 20-minute case)

Weights: Values/Behavioral high (scored against all four values), Case high (20 minutes), Peer/stakeholder medium. Delivery tip: this is the third round of the day, so rehearse short answers.

### Bank V: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold for Members First, Always: pick a time with a named stake, the decision, what it cost someone on your side, and what the member ended with. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own wording raises the theme. Generic because no quoted sentence carries it |
| V2 | "Tell me about a time something needed explaining twice." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. Story-mapped on the one beat the quote states: you trained new tellers on the escalation script. Answer slot: if the wording of that script ever came up while you trained them, say what; if it never did, say so plainly and stay with training them. Then what you would write plainly, as a plan | The value says "if a member needs it explained twice, we wrote it wrong". F5 is the nearest sentence you have, and the slot lets the premise be false |
| V3 | "Tell me about a time a decision looked right on the numbers but wrong for the town." | VAL | [generic] | Selection scaffold for Neighbours, Not Numbers: pick a time with a named trade-off, who bore it, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Expect this value to be pressed by K3 | Branch managers will hear this value through their own towns. Generic because no quoted sentence carries it |
| V4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. The quote carries one beat: you handled the branch's formal complaints log. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on a complaint you saw through. If one stayed with you from first report to close, say what happened and what was yours; if the log was the extent of your part, say so plainly and stay with the log. Include where it did not get solved if that is true | The only value the quoted material comes near. VAL because it tests behaviour against the published wording |

### Bank K: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | A practice case, not their case: "A member has complained three times about the same fee error and says they will close their account. The branch says it is resolved; the contact centre shows it open. What do you do?" | CASE | [generic] | Clarify first: what the member has been told and by whom, what they want, and which rules or deadlines apply. State the objective: fix the member's problem, tell them in plain words, and record it properly. Name one owner now. Split today's actions from this week's. Say what you would track, such as repeat complaints on the same issue. Challenge one premise respectfully, such as what "resolved" means to each side. Think aloud | The email names the case as "a 20-minute case on a complaint escalation". Generic because the real case is unknown; the structure is the rehearsal |
| K2 | "We aim to move 40% of member service to digital channels by 2028. What does that mean for how complaints are raised and handled?" | CO | [grounded] | Ask which journeys move first. Then walk member to channel to log to owner. Name the risk of a complaint raised where no person sees it, tie it to Plain Words, and name what you would track by channel, such as time to resolve and repeat contact. Do not claim you have built a digital journey; F9 holds that limit | The brief's digital aim is the current priority. CO and CASE: it tests the company's altitude |
| K3 | "We are consolidating eight branches into five hubs over 2027. A member in a town that loses its branch has a complaint. What does Neighbours, Not Numbers look like?" | CO | [grounded] | Treat the tension openly and respectfully; do not critique the plan. Ask what is already decided. Then structure: how the member can raise it in person, by phone or digitally, who owns it, and how local feeling reaches the decision. Do not invent facts about which towns | The panel are branch managers and the brief puts branches at the centre of 2027. CO because it tests the brief; VAL because it presses a value |

### Bank P: Peer / stakeholder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "You'd coach our supervisors on escalations. What do you need from us, and what do you bring?" | JD | [grounded] "trained new tellers on our escalation script" "6 years in retail banking, the last 3 as a branch supervisor" | Reciprocity. What you bring, at the quotes' scope: six years in retail banking, the last three as a branch supervisor, and you trained new tellers on the escalation script. What you need: say how the managers would like problems in their branch raised, as a question to them | F5 and F8. Peer evaluators price what the hire costs and adds to their own work |
| P2 | "Where does your ownership of a complaint end and a branch manager's start? What happens when we disagree?" | JD | [generic] | Offer seam principles, not a claim to know their seam: a member sees one owner; the branch keeps decisions about its own people; facts are agreed together first; an unresolved disagreement goes to the Head of Member Services. Ask for their view of where it sits today | The JD's end-to-end ownership collides with branch authority; generic because it is a pattern |
| P3 | "A supervisor handles an escalation in a way that works for the member but breaks your process. What do you do?" | CASE | [generic] | A live problem, no past claimed. Thank the supervisor and the outcome first; ask what they saw; separate member outcome from process breach; fix the process or the practice, not the person; say what you would record | Tests Own the Fix against Plain Words and the seam. CASE because it is a live problem from the role |

Proposed wording above: pending your approval.

### Values cheat sheet

Published values, copied from the page on 12 October 2026 as you reported it.

| Value (official name) | Working meaning | Mapped story, or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, V1: a named stake, the decision, what it cost your side, what the member ended with. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | F5, "trained new tellers on our escalation script", carries one beat. V2 holds the slot for whether wording ever came up |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, V3, pressed again by K3. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1, "I handled the branch's formal complaints log", carries one beat. V4 holds the slot for a complaint you saw through |

### Round 3 reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| RC1 | "Where do your supervisors find escalations hardest right now?" | Puts the panel's own problem first, which is the job you would do for them |
| RC2 | "How are the hub changes shaping how members raise complaints?" | Shows you read the brief and the people it affects, without taking a position |
| RC3 | "What would make you pick up the phone to me when a complaint in your branch is going wrong?" | Reciprocity: tells you how they want to be partnered |
| RC4 | "Which of the four values is hardest to keep in your branch at the moment?" | Honest and specific; branch managers score the values and know their cost |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "4+ years in financial-services customer operations" | A1, B2 |
| "Own the member complaints process end to end across branches and the contact centre" | B1, C1, C2, K1, P2 |
| "experience handling regulated complaints" | B3, D3 |
| "report monthly on complaint volumes and resolution times" | C4, E1 |
| "coach branch supervisors on escalations" | C3, D2, P1 |
| "work with digital teams on self-service journeys" | A3, K2 |
| "confident presenting to senior leaders" | B4, C2, C4 |
| "comfortable with Excel reporting" | E2 |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The pack's observation: your material says one branch's log, not the process across branches. The slot stays inside the log |
| Handled regulated complaints | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says formal, not which outside rules applied. B3's slot asks only what rules or deadlines applied to the log |
| Reported monthly on complaint volumes and resolution times | Inflated form of F4 | F4's quote at its own scope. E1's slot asks only what the spreadsheet counted |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope. C3's slot stays with training tellers |
| Has contact-centre experience, or that the two channels work alike | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Is practised at presenting to senior leaders | Negative you stated, F6 | The plain acknowledgment F6 gives: "I've never presented to anyone above regional level." No slot |

## Sources

**Provided documents:** the JD text; the four values, copied from the Ashgrove values page on 12 October 2026 (as you reported); the recruiter's email on the process; your summary of the June 2026 strategy brief (the brief itself was not supplied); your background as written in your message. No dossier was present. No CV was supplied.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values are in hand and fix the values cheat sheet; the URL is where the text came from, not a link to read |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes the loop: three sessions, who runs each, the case, and the values round |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the brief supplies the four items that feed K2, K3 and A2; the upgrade menu offers the brief itself and deeper research |
| 4. Interviewer names | n/a | No names were given, so there is no query to form; the upgrade menu says what names would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names (the Head of Member Services and both branch managers) → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own paths
- Your CV text → fit rows F1, F4, F5 and F8 move from message-only quotes to CV lines, and may supply stories for the scaffolds in D1, D3, V1 and V3
- Your answers to the answer slots (F1, F3, F4, F5, F7, F9), given outside a drill → each row regenerates with your own words as evidence, and the matching bank guidance becomes story-mapped
- The strategy brief itself, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; say yes and I will run it) → a fuller grounding brief, recent organisation context, and CO questions beyond the four items you summarised
- A line from the recruiter on the format of the 20-minute case, and which rules or regulator govern Ashgrove's complaints process (usually one email) → K1 becomes closer to the real case, and F3 and B3 can name the actual rules
- Your prep time available → a prioritised schedule sized to it
- A tuesday-dossier.md from job-underwriter → the highest-ROI objection derived from confirmed evidence, a strategy constraint per weak area, and a hard prohibited-claims list
