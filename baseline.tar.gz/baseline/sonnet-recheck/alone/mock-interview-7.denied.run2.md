I'll read the skill's reference files first.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-denied-2b6179f9/358cfaba-fca9-4908-9063-4a6f54c5f569/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across seven interviewer styles, and the five facts you gave me are mapped to the JD line by line.

I built it for a hiring-manager round with Tobias, since your note doesn't say how he relates to the role. That puts the most weight on live case problems and on probing your gaps.

Web search was refused, so no company or interviewer research ran. Everything about Saltmarsh Games comes from the JD you pasted. That leaves out values, loop structure, strategy and anything about Tobias himself. The Sources section lists the four refused searches.

The question to rehearse most is B1: "You haven't worked on a game with in-app purchases, so how would you approach monetization in live events?" It leads with your own plain acknowledgment, holds only what you wrote, then gives a plan with three follow-ups.

Say the word and I'll play Tobias as the Skeptic on B1 and give you feedback against its guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias who you'd report to, and has the recruiter said anything about the format or a task to prepare? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- Candidate: Femi
- Interviewer: Tobias Wrenfield, Head of Live Operations (name and title from your message). Relationship assumed: hiring manager. Nothing you sent says who he is to the role, so the weights below rest on that assumption.
- Round: 60 minutes, Friday. Format and focus areas unknown; no recruiter guidance supplied.
- Research: no company or interviewer research ran. All four searches were refused (see Sources). Everything about Saltmarsh Games in this pack comes from the JD you pasted; nothing comes from the web.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Every question carries both, plus a Provenance label so you can see what each piece of guidance stands on.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes. No values were found, so VAL questions here take their themes from the JD |
| EXP | Whether your claims survive scrutiny: what you actually did |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its strategy |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: `[grounded]` means traceable to your message or the JD you pasted; `[inferred]` means derived by this pack and the derivation is named; `[generic]` means a role-family pattern with no claim about Saltmarsh or about you.

Answer slots are instructions for the interview, not questions for you now. Where the pack cannot know what you did, it says what Tobias is likely to probe and gives two honest branches: say how, in your own words, or say plainly that it was not yours or did not exist. Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

You have until Friday. In this order, the few things done well:

1. B1, aloud, three times, with a person or a recording. It is the highest-ROI prep in this pack.
2. F1 and F2, hold-then-concede. Rehearse the pause, the hold and the concession, each out loud.
3. D1, your 90-second arc, timed.
4. A1, A2 and A4 once each as thinking-aloud case answers: clarify, structure, metrics, risks.
5. C1: decide what you can and cannot say about how the retention numbers were counted.
6. Pick three reverse questions and say them aloud.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives the four years and the title, and does not show whether the title was run as an ongoing service. Words: "I have four years as an associate producer at a puzzle-game studio." Answer slot: the JD's line makes a probe on how the four years map likely. If the title was run as an ongoing service, say how, in your own words; if it was not, or you are unsure, say so plainly and stay with the four years and the weekly content-drop calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as it stands: "For the last two years I ran the weekly content-drop calendar for our main title." Expect a probe, because a line with nothing inspected behind it is a lead, not proof |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | transferability | The derivation: the quote is a drop calendar for one title, and the JD names a live-events calendar across two. Words stay at the quote's scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: expect a probe on both the events and the second title. If the calendar ever held anything beyond content drops, say what; if you had any hand in a second title's schedule, say what part; if neither, say so plainly and stay with the main title's weekly calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD's coordinate line makes a probe on cross-team work likely. If your drops involved design, art, engineering or community, say which and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | transferability | The derivation: presenting monthly numbers is adjacent to reporting an event review's KPIs, and the quote does not say you owned a review. Words at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran any review after a content drop, say how it worked and what was yours; if there was none, or it was not yours, say so plainly and stay with presenting the monthly numbers |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on the numbers. Lead in the quote's own terms: you presented the monthly retention numbers, to the studio head. Answer slot: how the numbers were counted, what they were sensitive to, the assumption you would defend least, and which part was yours; if you do not know how a figure was counted, say so plainly |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The quote says you wrote the checklist and that QA still uses it; it does not say how releases ran against it. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you ran releases against it with QA, say how, in your own words; if you did not, or it was not yours, say so plainly and stay with having written it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The derivation: a checklist is a written artifact, and the quote does not show how clear it was or who else read it. Answer slot: if other writing of yours was read and acted on by others, say what it was; if the checklist is the only example, say so plainly and stay with it |
| F9 | Leading a team (not a line in the JD; raised by your message) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would get four disciplines moving together, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Experience with in-app purchases (not a line in the JD; raised by your message) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |

## Persona table

Weights come from three passes. Relationship prior: a hiring manager is buying capability and derisking gaps, so Case/Strategist and Skeptic lead. Interviewer signals: none, because no profile was found. The loop: no source describes Saltmarsh's loop, so this falls back to the generic archetype (screen, hiring manager, panel) with flat tilt, and no values-style round is detected. If you know anything here that I don't, recalibrate.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Live problems from the role: plan an event, diagnose a retention dip, resolve a collision | 5. Top prior for a hiring manager; the JD is a planning-and-coordination job, so live problems are the natural test | Clarify, objective, segmentation, approach, metrics, risks. Think aloud; challenge one premise respectfully |
| B Skeptic | Quiet probing of the gaps you named: in-app purchases, never leading a team, one title, the years | 5. Second top prior, and you have named two gaps yourself (F9, F10), which makes them askable directly | Rehearse B1 until it is boring. Bridges only from what you wrote; where nothing carries it, say the limit plainly, then a ramp plan |
| C Data-Driven Prober | Reads your line on retention numbers and asks how they were counted | 3. You will present retention; the JD names retention metrics and the KPIs of a post-event review. Mid weight because no signal says this interviewer is analytics-heavy | Know what you can and cannot say about how the numbers were counted; name the weakest assumption before he does |
| D Conversational | Friendly opener, journey question, what you play | 3. Every interview opens this way and it is scored; the JD asks for clear communication | A timed 90-second arc; treat casual questions about live games as scored |
| E Peer Evaluator | Seam questions between design, art, engineering, community and the producer | 2. He is more likely your manager than a peer, but the JD's coordinate line invites the seam question | Reciprocity: what you bring each team; propose seam principles, not a map you cannot know |
| F Pressure | Time-boxed challenge and attribution probes on your lines | 2. Gaps invite a sharper tone, but nothing says this loop is stress-style | Pause, restate, hold through two follow-ups, concede specifically |
| G Values/Behavioral | Behavioral prompts on the JD's themes | 2. No published values were found and no values round is detected, so themes come from the JD only | Story-map where a quote carries one; otherwise a selection scaffold with its honest branch |

## Question banks

Highest-ROI prep: B1. It will be asked in some form, and it is the one place where the material is thinnest.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're planning a four-week event on one of our titles. What do you need to know first, and how would you build the calendar around it?" | CASE | [generic] | Clarify before structuring: the event's objective, which players it targets, fixed dates and dependencies, each discipline's lead time, what the last event did. Then objective, segments, calendar approach (anchor the fixed dates, then fill), metrics you would judge it by, top risks. Think aloud and challenge one premise respectfully, such as whether four weeks is the right length. It makes no claim about your past | F3's requirement is the calendar; CASE because a hiring manager tends to test on the live problem. `[generic]` because no research gave this company's cadence |
| A2 | "A key retention number dropped after last week's event. How do you diagnose it?" | CASE | [generic] | Clarify which metric, which cohort, against what baseline. Separate what changed (event content, a release, a bug, an overlapping event) from what did not. Segment: new versus returning players, platform, region. State hypotheses, the first data you would ask for, and what you would do before the cause is confirmed. Say aloud the assumption you would trust least | F6 and F5 are where retention and reviews enter; CASE because it asks for reasoning on a live metric, not a past |
| A3 | "Two events both want next weekend, and engineering says only one can ship cleanly. How do you decide?" | CASE | [generic] | Ask what is fixed. Name your criteria (player impact, readiness, risk, how reversible each is). Say who decides and who is consulted. Give a recommendation, and the trade-off you accept. Say how you would tell the team that loses. Hold the recommendation through a push-back; concede only on a new fact | F3's requirement covers two titles' calendars; CASE with a pressure edge. No claim about your past |
| A4 | "Art is two days late on an event asset, and community has already announced the date. What do you do?" | CASE | [generic] | Facts first: what is late, what the smallest shippable version is, what moving costs. Then options (cut scope, ship in part, move the date), who needs to hear what and when, and what you would record for the review. Say which of these is your call and which you escalate, as a plan | F4's requirement: coordination across disciplines on each update. CASE because it tests behavior under a slip, not a record |
| A5 | "What goes in a post-event review, and which KPIs would you report from it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it: what the event was meant to do, what happened against that, what to repeat, stop or change. Choose a few KPIs tied to the objective and name the one you would trust least and why. For your own past, stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran any review after a content drop, say how it worked and what was yours; if there was none, or it was not yours, say so plainly and stay with presenting the monthly numbers | F5 is the evidence for the requirement and it is thin; JD because the JD names the review and its KPIs, with CASE delivery |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you approach the monetization side of live events here?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | The deepest rehearsal in this pack. Beat 1, plain and first: "I haven't worked on a game with in-app purchases." Do not qualify it. Beat 2, hold only what you wrote: "For the last two years I ran the weekly content-drop calendar for our main title." Stop there; do not call it equivalent. Beat 3, a plan and never a past: before touching an event plan, ask who owns pricing and offers, ask to read recent post-event reviews, play the titles as a player. Follow-up 1, "what would you check first?": name one thing, and say you would confirm it with whoever owns it. Follow-up 2, "is that a dealbreaker?": concede specifically that it is a real gap, and ask what ramp they expect. Follow-up 3, "what would you get wrong?": name one honest risk in your own words | F10 is a gap you named, so the Skeptic can ask it directly. The JD's lines say nothing on monetization, so how much weight it carries here is not known from the material; the guidance prepares for it anyway. JD because it scores fit; Skeptic delivery |
| B2 | "The JD asks for three-plus years producing live-service games. How do your four years line up?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say it at the quotes' scope: "I have four years as an associate producer at a puzzle-game studio, and for the last two years I ran the weekly content-drop calendar for our main title." Do not rename the title. Answer slot: expect a probe on whether the title was run as an ongoing service; if it was, say how, in your own words; if it was not, or you are unsure, say so plainly and stay with the four years and the weekly calendar | F1 is a discovery row: the material does not show whether the years reach the requirement, so this is the probe that settles it |
| B3 | "You ran the calendar for your main title. We run two titles in parallel. How would you handle two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Hold: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you had any hand in a second title's schedule, say what part; if not, say so plainly and stay with the main title. Then a plan: get one view of both calendars' shared constraints (team capacity, release windows) before planning either, and keep each title's player needs separate | F3 is a transferability row; JD because the JD names two titles |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Choose one requirement and name it in a sentence. Say what you would do about it in your first weeks, as a plan. Choose the one you would need most help on, not the safest. If no single requirement stands out, say so plainly and name the one you would want a second opinion on. Do not claim you are strong everywhere | The JD is the scoring sheet and F3 to F5 and F8 to F10 are where this pack found limits; the answer is a self-assessment, so it must be yours |
| B5 | "You haven't led a team, and this role coordinates design, art, engineering and community on each update. How do you get four disciplines moving together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Say plainly: "I haven't led a team." Then the JD's word is coordinate, and what you can say of your own work is the calendar you ran. Answer slot: if any of your drops needed other disciplines to move, say how you got them there and what part was yours; if none did, or it was not yours, say so plainly and stay with the calendar. Then a plan: one shared calendar, early heads-up on asks, decisions recorded | F9 is the gap you named; F4's slot lives here too. JD because it scores the coordination line |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention numbers did you present each month, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Open at the quote: "I presented the monthly retention numbers to the studio head." Answer slots, in your own words: which numbers; how they were counted; what they were sensitive to; the assumption you would defend least; which part was yours, producing or presenting. If you do not know how a figure was counted, say so plainly and say how you would find out. Do not name a method you cannot repeat under a second question | F6 is the evidence and a Prober's first target; EXP because it tests whether the line survives |
| C2 | "What did you change in a later calendar because of what those numbers showed?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: the JD's review-and-KPI line makes this probe likely. If a reading changed a later drop, say which and what was yours; if none did, or the numbers were not used that way, say so plainly and stay with presenting them monthly | F5 and F6: the step between reporting a number and acting on it is not in your material, so it is asked as a slot |
| C3 | "If you could only report three numbers from an event, which would you choose, and which would you trust least?" | JD | [generic] | Pick three tied to the event's objective, not to what is easy to pull. Name the one you would trust least and why, in one clause, and what would change your mind. This makes no claim about your past | The weakest-assumption move rehearsed on a live question; F5's requirement is the KPIs a review reports |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you get here, and why this role?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message and "I ran the weekly content-drop calendar for our main title for the last two years." — your message and "Wrote the release checklist our QA team still uses." — your message and "Presented the monthly retention numbers to the studio head." — your message | A 90-second arc, five beats: four years as an associate producer at a puzzle-game studio; for the last two years, the weekly content-drop calendar for your main title; the release checklist your QA team still uses; presenting the monthly retention numbers to the studio head; then why this role. Answer slot for the last beat: your reason, in your own words; if the reason is simpler than a pitch, say it plainly. Stop at 90 seconds | F1 to F7 supply the beats. EXP because it tests whether the biography is consistent; Conversational delivery |
| D2 | "What have you played of ours, and what would you change about how we run events?" | CO | [generic] | No company facts were found for this pack, so this one needs you. Before Friday, play both titles and note one observation each about their events or cadence. Offer an observation as a question, not a verdict. If you have not had the time, say so plainly and ask which event he would want you to look at first | CO because it tests homework. `[generic]` because the research that would ground it was refused |
| D3 | "What live games do you play, and what do their calendars do well?" | JD | [generic] | Pick a game you actually play and one thing its calendar does that you noticed as a player. Say what you would borrow or avoid. If none comes to mind, say so plainly and name the closest thing you follow | A casual question about the JD's calendar topic; casual questions are still scored |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design, art, engineering and community all sit around one update. Where is the seam between you and them, and what happens when we disagree?" | CASE | [generic] | Propose seam principles, not a map you cannot know: the producer owns the calendar and the asks; each discipline owns its craft and estimates; disagreements surface early with options and are decided by whoever owns the outcome, then recorded. Say what you bring each team (a clear plan, early warning) as well as what you need. Ask where the seam sits today | F4's requirement; CASE because it asks for a method. No claim about your past |
| E2 | "Tell me about a time you worked through a disagreement with someone on another team." | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | No quoted sentence of yours carries a disagreement story, so this is a selection scaffold. Pick a time with a named stake, a point where you held a position, and a working relationship intact afterward. The nearest thing your message carries is the release checklist your QA team still uses; it says you wrote it, not how any disagreement went. If no such time comes to mind, say so plainly, then give that nearest thing, or how you would handle it | The JD's coordinate line is the raising source; F7 is the closest cross-team evidence |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has already run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message and "Presented the monthly retention numbers to the studio head." — your message and "Never led a team, and never worked on a game with in-app purchases." — your message | Pause and restate the question. Hold twice: "For the last two years I ran the weekly content-drop calendar for our main title," and "I presented the monthly retention numbers to the studio head." Concede specifically: "I haven't worked on a game with in-app purchases." Do not argue the other candidate down and do not call your work equivalent. If pushed to "so you're weaker," concede what is true, and ask what ramp he would expect | B1 under time pressure. F10 is the gap; JD because it scores fit |
| F2 | "Walk me through the release checklist you wrote for your QA team. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." — your message | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else contributed or QA edited it, say so plainly; if it was only yours, say that. Answer slot: if you ran releases against it with QA, say how; if not, say so and stay with having written it. Hold through two follow-ups and never add a step the quote does not carry | F7 is the evidence for the JD's checklist line; EXP because attribution probes target exactly this kind of sentence |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time a result was worse than the team expected, and how you reported it." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." — your message | No quote of yours carries this story, so it is a selection scaffold. Pick a time you reported a result nobody wanted, with a named stake and an intact relationship afterward. The nearest thing your message carries is presenting the monthly retention numbers to the studio head, which does not say any of them was bad news. If no such time comes to mind, say so plainly, then give that nearest thing, or how you would handle it | The JD's post-event review line is the raising source; F5 and F6 are the nearest evidence |
| G2 | "Tell me about something you wrote that other people had to act on." | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Story-map on the quote: you wrote it, your QA team uses it, and they still do. Answer slot: the JD asks for clear written communication, so expect a probe on how you knew it was clear. If QA told you or changed it, say what; if you have no such signal, say so plainly and stay with the fact that they still use it | F8 is a discovery row; this is the probe that settles it |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | B2, D1 |
| "experience running a content calendar" | B3, D1, D3 |
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A3, B3 |
| "coordinate design, art, engineering and community teams on each update" | A4, B5, E1, E2 |
| "own the post-event review and the KPIs it reports" | A5, C2, C3, G1 |
| "comfortable with player-retention metrics" | A2, C1 |
| "manage the release checklist with QA" | F2 |
| "clear written communication" | G2 |
| In-app purchases (raised by your message) | B1, F1 |
| Leading a team (raised by your message) | B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for the producer on one of these two titles, and what would you want shipped by day 30?" | It shows you are planning to deliver, and it surfaces his actual expectations, which no JD line gives |
| R2 | "How is each title's calendar set today: who sets the cadence, and where does the producer have the final call?" | It targets the decision rights behind the JD's plan-and-run line |
| R3 | "How does the team decide whether an event worked: which KPIs go in the review, and who reads it?" | It shows you care about the review loop the JD gives the role |
| R4 | "I haven't worked on a game with in-app purchases. How do you bring a new producer up on that side?" | It converts the gap you named into a ramp conversation and shows you would rather ask than bluff |
| R5 | "Where do design, art, engineering and community most often collide on an update, and what has helped?" | It asks about the real friction behind the coordinate line and invites a story from him |
| R6 | "What is the hardest part of this role that the JD does not say?" | It invites candor and often yields the real screening criterion |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the weekly content-drop calendar for your main title. B3's slot stays inside that calendar |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says you presented the monthly retention numbers. A5's slot asks only what review, if any, was yours |
| Owned or produced the retention analysis | Inflated form of F6 | F6's quote at its own scope: you presented the numbers. C1's slot asks which part was yours |
| Managed the release process with QA | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist QA still uses. F2's slot stays inside the checklist |

## Sources

Provided documents: the JD text you pasted; your background as written in your message. No dossier was present.

Searches sent, each refused (the permission was not granted):

- `Saltmarsh Games mobile studio values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games strategy news` — refused
- `Tobias Wrenfield Saltmarsh Games` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet; none is built, and no values-style round is detected from the inputs |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have set the persona weights from a documented loop; they rest on the hiring-manager prior and the generic archetype instead |
| 3. `Saltmarsh Games strategy news` | unavailable | Would have grounded CO and CASE questions in current strategy; D2 and the case bank are `[generic]` instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission for web search (all four calls here were refused) → targets 1 to 4 run: published values, a documented loop, current strategy and Tobias's public footprint, so the persona weights, a CO bank and a tailored reverse question stop being `[generic]`
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, offered once) → a strategy brief for the case bank and a deeper read of his talks and writing
- The recruiter's note on format, focus areas or any task to prepare → coverage of a pre-declared deliverable and a better persona weighting; whether Tobias is your future manager reweights every bank
- Your own words on the slots in F1, F3, F4, F5, F7 and F8 → those rows gain specifics and the bridges stop being slots
- The release checklist itself, a screenshot of the content-drop calendar, or one monthly retention deck → F2, F6 and F7 move from medium to high, because an inspectable artifact is what raises the band in production roles
- Hours available before Friday → the prep triage resizes to your real time
- A tuesday-dossier.md from a job-underwriter run → verified evidence and an evidence-derived objection ranking in place of the inferred one
