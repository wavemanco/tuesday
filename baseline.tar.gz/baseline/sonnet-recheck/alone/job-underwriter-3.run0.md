I'll read the reference files first.
## Decision snapshot

**No — this posting isn't worth pursuing on its terms. R1 and R2, both hard gates, fail. Status: `no_go`.** Your sense that something is off is borne out by the posting's own terms, not by anything missing from your profile.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base $70–85k), R2 (On-site in Austin, 5 days a week)
- `must_have` — direct: R3, R4, R5
- `important` — unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Execute as a team of one)

Your substance matches on R3, R4 and R5, but that fit does not offset R1 or R2.

**Opportunity ledger.** The posting bundles functions and resources them thinly (RR3, RR7), prices the seniority low (RR6), signals always-on hours (RR4) and leaves success undefined (RR5). Against your constraints it conflicts on pay and on location (RR1, RR2). Its positives are a CEO reporting line and a stated profitable position (RR9), and the employer itself is unverified (RR8).

- **Hard gates:** failed: R1 (Base $70–85k), R2 (On-site in Austin, 5 days a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** R1 and R2 would both have to change: a base of at least $150k, and Portland-remote permitted. The posting says "no exceptions" on location, so wording or positioning cannot solve either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one", Austin office | `[grounded]` JD header; the entity itself is not externally verified (RR8) |
| Mandate | Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget, tooling or hiring plan stated | `[grounded]` JD states the team size and is silent on budget |
| Working pattern | On-site in Austin five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no equity figure or terms | `[grounded]` JD |
| First-year outcomes | None stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions in one hire, where one hire covering all seven is broader than the posting's own team-of-one framing resources | `[inferred]` from the JD's function list against its team size; `[generic]` that these functions are commonly separate specialist roles |
| Market calibration | Not run, because the role-family sweep was refused (see Evidence status), and no band is quoted from memory. From the JD alone, the posted top of $85k is $65k under your $150k floor and the bottom is $80k under | `[grounded]` JD figure and your stated floor |
| Unknowns | Budget, decision rights, equity size and terms, how success will be measured, who the CEO is, any remote flexibility | `[grounded]` JD silence |
| Contradictions | A "Head of" title with a board dotted line, set against a team of one and a $70–85k base | `[inferred]` from the JD's own terms; no careers-page cross-check was possible |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k (your floor: $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own specific floor. Fit fails because even the top of the posted band is below it. The equity is unquantified and is not base | `[grounded]` JD and your stated constraint | Surface only; the employer changing terms is the only resolution |
| R2 | On-site in Austin five days a week, no exceptions (you are remote-only, in Portland) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated remote-only limit. The JD says "no exceptions", so no flex is signalled | `[grounded]` JD and your stated constraint | Surface only; no workaround is proposed |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth: Growth lead, then Head of Growth, at two B2C subscription companies. This is prose self-report, so `medium`; expect a titles-and-dates probe | `[grounded]` your intake message | An ARR bridge or board-deck page would raise it to `high` |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid and scaled one company from $8M to $40M ARR over three years with a budget you controlled. The ARR growth is the company's total, so do not attribute it to paid alone | `[grounded]` your intake message | A channel P&L or spend-to-revenue report would raise it to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, SQL and GA4. No inspectable artifact yet | `[grounded]` your intake message | A sanitized Braze program map or lifecycle dashboard would raise it to `high` |
| R6 | SEO/content | important | unclear | none | discovery | Your summary lists paid, lifecycle and experimentation and does not mention SEO or content. That is silence, not absence | `[grounded]` your intake message | See G1 |
| R7 | Brand, PR and partnerships | important | unclear | none | discovery | Nothing in your summary touches these. Silence, not absence | `[grounded]` your intake message | See G2 |
| R8 | Sales ops | important | unclear | none | discovery | Nothing in your summary touches sales ops. Silence, not absence | `[grounded]` your intake message | See G3 |
| R9 | Execute across all channels as a team of one | important | unclear | none | discovery | Leading teams of 3–7 shows you led people, not that you ran every channel alone. The two are different kinds of work, so one does not stand in for the other | `[grounded]` your intake message | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, important) | discovery | No SEO or content ownership stated | Moot while R1 and R2 fail; it would matter only if the terms changed | Owning an organic channel or a content calendar; setting SEO targets; commissioning or editing content | A traffic report, content roadmap or ranking export | `[grounded]` silence in your summary |
| G2 | Brand, PR and partnerships (R7, important) | discovery | Nothing stated | Same: moot unless R1 and R2 change | Running a partnership or affiliate program; a PR launch; brand-campaign ownership | A partner-program summary or launch brief | `[grounded]` silence in your summary |
| G3 | Sales ops (R8, important) | discovery | Nothing stated | Same | Handoff design between marketing and sales; CRM routing; pipeline reporting | A routing spec or funnel report | `[grounded]` silence in your summary |
| G4 | Solo execution (R9, important) | discovery | Team leadership stated; hands-on solo execution not stated | Same, and it is also what the posting's team-of-one framing tests | Periods when you ran channels yourself, such as an early-stage stint before the team existed | A dashboard or campaign set you personally built | `[grounded]` your intake message; `[generic]` that team-of-one mandates probe hands-on depth |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay conflicts with your floor (see R1) | red_flag | high | "$70–85k base plus meaningful equity upside" | Base sits $65–80k under your floor, and equity cannot be counted as base | `[grounded]` JD figure and your constraint | Is the base negotiable above $85k, and what is the equity grant and its terms? | unresolved |
| RR2 | Location conflicts with remote-only (see R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The employer states no flexibility | `[grounded]` JD and your constraint | Is there any remote arrangement for this role? | unresolved |
| RR3 | Bundled specializations, team of one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… a team of one to start" | Several specialist roles folded into one title at a junior-leaning price | `[inferred]` from the function list against the team size; `[generic]` that this is a common pattern | When do you plan to hire the first reports, and with what budget? | unresolved |
| RR4 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours are framed as culture, not as an exception | `[inferred]` from the JD's phrasing; `[generic]` that such wording often signals unbounded hours | How often did the last person in this role work evenings or weekends, and is there time back for it? | unresolved |
| RR5 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable for results with no agreed definition of success | `[inferred]` from the JD's silence on outcomes | What would success look like at 6 and 12 months, and who decides? | unresolved |
| RR6 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required… $70–85k base" | Years and mandate may be priced below market. The sweep that would confirm this was refused, so it stays a risk signal rather than a finding | `[inferred]` from the JD alone; no market band was obtained | How was this salary range set for an 8+ year hire? | unresolved |
| RR7 | Responsibility without stated authority or resources | risk_signal | medium | "Own all revenue growth end to end" | The posting names no budget, tooling or decision rights | `[inferred]` from the JD's silence | What budget and decision rights come with the role? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | low | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Research did not run, so existence and posting status are unchecked, not found false. I took the lower severity for that reason | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who I would interview with? | unresolved |
| RR9 | CEO reporting line and stated profitability | positive_signal | — | "Report to the CEO… profitable since day one" | The company claims a direct senior line and a funded position. These are its own claims | `[grounded]` JD, as the company's own claims | Who is the CEO, and what is the revenue plan this role owns? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply on the posted terms | R1 and R2 fail | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you proceed against `no_go`, carry the register's questions (RR1 to RR7) into the first call; the pay and location questions go first, so you learn quickly whether either term moves | The register becomes your interview preparation | `[grounded]` register | pending your approval |
| A3 | Filter future searches for postings that state a base of at least $150k and allow Portland-remote | These are your two constraints | `[grounded]` your stated constraints | pending your approval |

No CV edits are proposed, since the recommendation is not to apply, so there is no `resume_edits_pending_approval` table. Each plan row above is a proposal and needs your approval before you act on it.

## Evidence status

Verified: your constraint statements on R1 and R2. R3, R4 and R5 rest on your intake prose, which is unverified self-report, and no leads from earlier conversation were used. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search ("Novaline e-commerce enablement startup Austin Series A") was refused, so nothing was read. It would have moved RR8 and the contradictions row, and whether the posting is live |
| 2. Role-family sweep | unavailable | One search ("Head of Growth salary Series A startup 2026 base compensation range") was refused. It would have moved the market-calibration row and RR6 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I did not retry the refused searches.

I can package this analysis as `tuesday-dossier.md` if you want it saved.

## Upgrade menu

- Permission to run the two refused searches → RR8 resolves (does Novaline exist as described, is the posting live), and R1 and RR6 get a market band. Neither changes the status while R1 and R2 stand.
- A link to the live posting on Novaline's own careers page → RR8 closes.
- The hiring manager's or CEO's name → the scope read in role reality.
- A channel P&L or ARR bridge page → R3 and R4 to `high`. A Braze program map or lifecycle dashboard → R5 to `high`.
- Any SEO, partnership or sales-ops work you have not yet mentioned → G1 to G3 move from unclear to a graded fit.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.