Checked the live posting with one fetch and one search. The assessment follows.

## Decision snapshot

**Yes, worth applying, on conditions. R1 (location) is unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery specifically) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts for analysts)

R8 has a credible bridge with its limit named. R9 and R10 are open on discovery, not on any evidence against you.

**Opportunity ledger.** The posting is transparent and priced inside the supplied market data (RR1), and it is live and matches your copy (RR5). Open items are who you would report to and the team's size (RR2), whether the scope is one domain or several (RR3), and a funding claim that rests on the company's own page (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed; (2) team, reporting line and scope verified early (RR2, RR3); (3) the BigQuery bridge framed as adjacent, never as BigQuery experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company about page, copied by you and returned by search |
| Mandate | Pipelines behind tutoring-platform reporting: ingestion from app and CRM, dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD, fetched and matching your copy |
| Pay and location | $148,000–$166,000 plus equity; remote (US) or Denver office | `[grounded]` JD |
| Seniority signal | 5+ years data engineering | `[grounded]` JD |
| Scope read | Three layers (ingestion, modelling, contracts) under one title; "build and run" suggests operating the pipelines too, possibly on call | `[inferred]` from the JD's wording against its silence on team and on-call |
| Market calibration | Report band for Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500. The posted $148,000 sits just under the median and $166,000 just above the upper quartile. "Senior" typically means 5–8 years and one domain's pipelines with no direct reports | `[grounded]` the Datawright report as you supplied it; `[generic]` as a pattern, not a claim about this employer |
| Unknowns | Hiring manager, team size, on-call, equity terms, first-year outcomes | `[grounded]` posting silent on each |
| Contradictions | None: the fetched posting matches your copy | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: US remote or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you are based or any location limits, so there is no statement to grade; the JD's terms are stated | `[grounded]` JD; no candidate statement | Ask whether the gate is met (question R1) |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company in your account. Prose self-report with no document yet, so `medium` | `[grounded]` your background; years are a tiered requirement, not a gate | CV or LinkedIn dates would raise to high |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use stated; no artifact inspected | `[grounded]` your background | Not needed at this stage |
| R4 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. "Built" is the verb you used, so no ownership beyond that is claimed | `[grounded]` your background | A sanitized model lineage graph or repo structure would raise to high |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; the JD's own wording is generic | `[grounded]` JD wording and your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named in your account, the JD's own example | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | A sanitized suite or coverage summary would raise to high |
| R8 | BigQuery specifically | important | adjacent | medium | transferability | Adjacent: warehouse modelling in dbt on Snowflake carries over. Limit: you have never used BigQuery, so its cost model, partitioning and clustering, and SQL dialect are unexercised. Tiered `important` because the JD names BigQuery in the mandate, not in its requirements list | `[grounded]` your stated gap; `[inferred]` that the bridge is credible; `[generic]` that warehouse differences are usually learnable but get probed | Gap G1 |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Nothing you gave speaks to ingestion sources; payroll pipelines almost certainly ingested something, but that is not evidence | `[grounded]` background silent on ingestion | Question R9 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Great Expectations is adjacent to contracts but is not the same thing; whether you defined schemas or SLAs with consumers is unknown | `[grounded]` background silent on contracts | Question R10 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake plus dbt modelling at scale, no BigQuery use | The posting names BigQuery in the mandate, so it will be raised | A small dbt-on-BigQuery project, even a sandbox; any GCP exposure at the payroll company | A repo or short write-up from a small BigQuery project, if you choose to build one | `[inferred]` bridge from Snowflake; `[generic]` that this gets probed |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Background does not mention ingestion sources | Ingestion is the first item in the mandate | Loading from an operational database, a CRM or SaaS API (Fivetran, Airbyte, or custom), CDC, or event pipelines | An architecture diagram, a DAG listing, a design doc | `[grounded]` background silence |
| G3 | Data contracts (R10, important) | discovery | Background does not mention contracts or consumer agreements | The mandate says analysts depend on them | Schema agreements with analysts or app teams, dbt contracts or tests on exposed models, SLAs on freshness | A schema spec, a contract doc, a dbt YAML sample | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and inside the supplied band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is market-competitive for the title and stage; equity terms are unstated | `[grounded]` JD range and your report's figures | Where in $148,000–$166,000 would this role land, and what are the equity terms? | noted |
| RR2 | Hiring manager and team unnamed; "build and run" | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You might be a lone or near-lone data engineer, possibly with on-call | `[inferred]` from the JD's wording against its silence | Who would I report to, how many data engineers are on the team, and is there an on-call rotation? | unresolved |
| RR3 | Scope breadth against the report's one-domain norm | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may span more than one domain's pipelines | `[inferred]` from the JD against `[grounded]` the report's typical scope | Is this role the owner of all reporting pipelines, or one domain, and who else touches the warehouse? | unresolved |
| RR4 | Funding and size rest on the company's own page | unknown | — | "Series C ($52M, February 2026)" | Probably accurate, but one search returned only that page | `[grounded]` search returned the about page alone | What runway does the February 2026 round give, and how is data-team headcount planned? | unresolved |
| RR5 | Posting live and consistent | positive_signal | — | "Accepting applications" | The role is open and the company's careers text matches what you copied | `[grounded]` careers page fetched | What does the interview process and timeline look like? | noted |

## Application plan

Everything below is a proposal (`resume_edits_pending_approval`); no CV wording, positioning or outreach is final until you approve it, and that covers the advice in this table as much as any edit.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project on Snowflake (about 180 models), Airflow orchestration and the Great Expectations suite you set up, in your own verbs | R4, R6, R7 | `[grounded]` your background | pending your approval |
| E2 | Name Snowflake as the warehouse. State no BigQuery use, and say in the cover note that you are ready to transfer the modelling skills | R8, G1 | `[grounded]` your background | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery project to narrow R8's limit | G1 | `[inferred]` from the gap | pending your approval |
| A1 | Confirm the location gate before investing in the loop | R1 | `[grounded]` JD | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions in early conversations | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about) only; fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality's contradictions row: posting live and text matching your copy; RR4: the funding claim found nowhere beyond the company's page |
| 2. Role-family sweep | skipped | Your supplied Datawright report holds the pay band, tenure norm and scope norm, which fix market calibration and RR1 and RR3 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Dossier offer

I can write all of this up as `tuesday-dossier.md` if you want it saved.

## Upgrade menu

- Your CV or LinkedIn dates, or a sanitized model lineage graph, would raise R2, R4 and R7 toward `high`.
- Your pay floor and location limits would turn R1 into a checked gate and let RR1 be held against your floor.
- An answer on ingestion or contracts would resolve G2 or G3, and each could move an `important` row from `unclear`.
- A hiring manager's name would unlock role reality's scope read and which story to lead with.
- A deeper pass on Pellucid (funding, leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) would test RR4. Say the word and it runs.

## Questions

R1 — Are you based in the US, or able to work from Denver, and is there any limit on location or hours that would matter here?

R9 — Have you built ingestion from an operational database, a CRM or an API at the payroll company? What did you own, and what happened?

R10 — Did you agree schemas, freshness or quality expectations with the analysts or app teams who consumed your models? What did you own, and what was written down?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.