I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, it's worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R8 (`medium`) has a credible bridge with its limit named, and R9 and R10 turn on what you did at the payroll company.

**Opportunity ledger.** The pay and the scope read as sound (RR2, RR6). The employer is not independently verified because my research calls were refused (RR1). Equity terms, team, manager and success measures are unstated (RR3, RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R1 and R2 are confirmed against where you live and your pay floor.
  2. RR1 clears: the posting is confirmed live on the company's own careers site.
  3. R8 is framed as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). These are the figures from the about page text you pasted. I could not read the page myself. | `[grounded]` your pasted about-page text, not independently verified |
| Mandate | Build and run the reporting pipelines behind the tutoring platform: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | Remote (US) or Denver office; $148,000–$166,000 plus equity (terms unstated) | `[grounded]` JD |
| Posting status | The posting shows "Accepting applications". This is your report from 09:12 today. I could not re-check it. | `[grounded]` your statement |
| Scope read | The three named areas (ingestion, warehouse modelling, contracts) read as one reporting domain's pipelines. That matches the one-domain, no-direct-reports scope your pay report calls typical for the title. Team size and whether you'd be the only data engineer are unstated. | `[inferred]` from the JD's scope language against the Datawright report's typical-scope note |
| Market calibration | The report gives a Series B–D Senior Data Engineer base median of $151,000, interquartile range $139,000–$163,500, and "Senior" typically means 5–8 years. The posting's low end is $3,000 under that median and inside the range. Its top is $2,500 above the range's upper bound. Your 6 years sits inside 5–8. The report states base pay, so the comparison assumes the posting's "salary" means base (RR2). | `[generic]` role-family pattern from the report as your recruiter provided it; `[grounded]` the posting's figures |
| Unknowns | Hiring manager, team size, decision rights, equity terms, success measures | `[grounded]` the JD names none of these |
| Contradictions | None between the pasted JD and about text. Both are your copies, so this is not a check against the live pages. | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have stated no location or work-authorization constraint, so nothing grades. Whether you can work from the US or Denver is not established. | `[grounded]` JD term; your message silent on location | Q1 in the closing questions |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You gave no pay floor, so the range cannot be met or failed yet. The range is close to market (RR2). | `[grounded]` JD range; your message silent on a floor | Q2 in the closing questions |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. This is prose self-report, not inspected, so `medium` and expect a probe on scope. Years of experience are a requirement here, not a gate. | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. Daily use is stated and specific, but "strong" has no inspectable proof yet. | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake meets the JD's "a cloud warehouse" wording. BigQuery specifically is R8. | `[grounded]` your stated background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You say Airflow was used for orchestration. Which DAGs you wrote is unstated, so the claim stays at `medium`. | `[grounded]` your stated background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. That is a specific ownership claim without an inspectable artifact yet. | `[grounded]` your stated background | none |
| R8 | BigQuery warehouse (the JD's own stack) | important | adjacent | medium | transferability | You have the same dbt practice on Snowflake. You have never used BigQuery, so warehouse-specific behaviour is unexercised. Warehouses differ in SQL dialect and cost model. | `[grounded]` your statement; `[generic]` that warehouses differ in these ways | G1 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Six years of data engineering with Airflow suggests ingestion work, but you haven't said which sources or who owned them. It is a lead, not a claim. | `[inferred]` from your stated background; the JD names the task | G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is adjacent quality work. Nothing says you agreed contracts with data producers or consumers. | `[inferred]` adjacency from the Great Expectations claim | G3, Q3 in the closing questions |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake plus dbt experience, no BigQuery use | The JD names BigQuery as the warehouse, so this is the likeliest probe. The adjacent case, with the limit stated plainly, is the honest answer. | A small dbt project run against BigQuery. Claim only what you actually build. | A sandbox repo or a sanitized dbt run log | `[inferred]` bridge from R5; `[generic]` that stack-named gaps get probed |
| G2 | Ingestion from app and CRM sources (R9, important) | discovery | Pipelines are implied by your role, but the sources and ownership are unstated | A core responsibility in the JD, so a clear example would move R9 from `unclear` | Loading a SaaS CRM or product events into the warehouse; building or fixing an Airflow ingestion DAG; handling schema changes from a source system | An Airflow DAG file (sanitized) or a lineage diagram | `[grounded]` your background silent on sources |
| G3 | Data contracts (R10, important) | discovery | Great Expectations suite exists. Producer or consumer agreements are not mentioned. | The JD names contracts as something analysts depend on | Agreeing column definitions or freshness expectations with analysts; failing a load when a source schema broke; documenting model guarantees in dbt | A dbt schema file with tests (sanitized) or a short contract doc | `[inferred]` adjacency from the Great Expectations claim |
| G4 | Location eligibility (R1, hard_gate) | hard_gate | Not stated | If you cannot work from the US or Denver, wording cannot fix it | n/a | n/a | `[grounded]` JD term; your message silent |
| G5 | Pay floor against the range (R2, hard_gate) | hard_gate | Not stated | The range is close to market, but your own floor decides whether it holds | n/a | n/a | `[grounded]` JD range; your message silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | My research calls were refused, so none of this is independently confirmed. I rate severity `low` rather than `medium` because you copied both texts from the company's own pages this morning and the posting shows live to you. | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` the refused calls | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated and in line with the report | positive_signal | — | "$148,000–$166,000 plus equity" | The range overlaps the report's interquartile range. It may not be base pay, and the report is for Series B–D companies. | `[grounded]` the JD range and report figures as provided; `[generic]` that the two are comparable | Is the $148,000–$166,000 base salary? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The grant type, size and vesting are not given, so equity cannot be valued. | `[grounded]` the JD says nothing further | What is the equity: grant type, size range, and vesting schedule? | unresolved |
| RR4 | Team, manager and decision rights unstated | unknown | — | The posting names no hiring manager. "Build and run the pipelines" | You may be the only data engineer accountable for the reporting pipelines, or part of a team. | `[inferred]` from the JD's silence against the report's typical-scope note | Who would I report to, how many data engineers are on the team, and who decides what the analysts' contracts cover? | unresolved |
| RR5 | Success measures unstated | unknown | — | "the data contracts our analysts depend on" | No first-90-days or first-year outcome is named, so accountability has no stated definition of success. | `[grounded]` JD states no outcomes | What would a good first six months look like for this role? | unresolved |
| RR6 | Coherent role and stack | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The responsibilities and the requirements list match each other, which reads as a real, scoped opening. | `[inferred]` from comparing the JD's two sections | Which analyst teams use the warehouse today, and how do they raise data issues? | noted |

## Application plan

Resume edits table, `resume_edits_pending_approval`. Each line below traces to your own sentences about your background:

| # | Current framing | Proposed | Why | Provenance | Status |
|---|---|---|---|---|---|
| E1 | "Built our dbt project on Snowflake — about 180 models" | "Built the payroll company's dbt project on Snowflake, about 180 models" | R5; puts the JD's lead requirement first | `[grounded]` your stated background | resume_edits_pending_approval |
| E2 | "I set up our Great Expectations test suite" | "Set up the Great Expectations data-quality test suite" | R7 | `[grounded]` your stated background | resume_edits_pending_approval |

Other proposed actions:

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | If asked about BigQuery, say you've built dbt on Snowflake and haven't used BigQuery. | R8; the plain version is the one that survives follow-ups | `[grounded]` your statement | pending your approval |
| W1 | Optional: build a small dbt project on BigQuery and cite only what you built. | G1 | `[inferred]` from the R8 gap | pending your approval |
| Q1 | In interviews, ask the verification questions of RR1, RR3, RR4 and RR5 verbatim. | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Settle R1 and R2 for yourself before spending application time. | Both are unconfirmed gates | `[grounded]` the map | pending your approval |

## Evidence status

Verified: none yet. Your background is prose self-report, not inspected. I am treating the JD and about-page texts as your copies, not as pages I read.

Research tier: L1 — searches 1 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every call was refused by the host's permissions. They were fetch "pellucidlearning.com/careers/senior-data-engineer", fetch "pellucidlearning.com/about", and search "Pellucid Learning Series C $52M online tutoring K-12 Denver". It would have moved the organization and contradictions rows in role reality, and RR1. |
| 2. Role-family sweep | skipped | The Datawright report in hand already fixes the market calibration line and the pay check (RR2). |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form. |

I can save all of this as `tuesday-dossier.md` if you'd like.

## Upgrade menu

- Permission for search and fetch, which would let me check the live careers page, the about page and the funding claim. That would close or confirm RR1 and fill the organization row.
- A deeper research pass (up to 5 more searches and 2 more fetches), which only makes sense once the calls above can run.
- A sanitized Airflow DAG file, dbt schema file with tests, or Great Expectations suite excerpt would raise R6, R7 and R4 toward `high`. The Great Expectations excerpt and the dbt schema file would also inform R10.
- Your location and pay floor settle R1 and R2.
- A hiring manager's name would add the footprint read in role reality and tell me which story to lead with.

## Questions

Q1 (R1). Are you able to work from somewhere in the US, or from Denver, for this role?

Q2 (R2). Does a base of $148,000–$166,000 clear your minimum, and what is your floor?

Q3 (R10). Have you ever agreed with analysts, or with the teams producing source data, what a table's columns, freshness or quality guarantees would be? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.