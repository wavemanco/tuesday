I'm running two quick searches: one to check that Novaline exists as described, and one for the market pay band for this role. Then I'll write up the assessment.
**Not worth pursuing: R1 and R2, both hard gates, fail. Status: `no_go`.** Your instinct is right. You fit the work on paper, but the pay and the location are each over one of your two hard constraints, and the posting has other problems too.

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base pay $70–85k against your $150k floor), R2 (On-site in Austin 5 days a week against remote-only)
- `must_have`: direct: R4, R5 · adjacent: R3 (8+ years growth leadership) · unclear: R6 (SEO/content)
- `important`: unclear: R7 (Brand and PR), R8 (Partnerships and sales ops), R9 (Operating as a team of one)

R1 and R2 decide the outcome whatever R3, R4 and R5 show.

**Opportunity ledger.** The posting folds seven functions into one role and prices it low (RR1, RR2), expects evenings and weekends (RR3), and defines no success metrics (RR4). Its authority and budget are unstated (RR5), and I couldn't verify the employer (RR6). The plain statement of pay and location is the one positive (RR7).

- **Hard gates:** failed: R1 (Base pay $70–85k against your $150k floor), R2 (On-site in Austin 5 days a week against remote-only).
- **Severe red flags:** none found.
- **What would change this:** only the employer changing the terms (R1 and R2) or you revising a non-negotiable. Better wording on your side can't fix either gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup that describes itself as Series A and profitable since day one | `[grounded]` JD header and body, as the posting's own claim. Not verified outside the posting (RR6) |
| Mandate | Own revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Reporting line | CEO, with a dotted line to the board | `[grounded]` JD |
| Team and resources | "A team of one to start"; no budget, tools or hiring plan stated | `[grounded]` JD, silent on the rest |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside" with no figure. That is $65–80k below your floor | `[grounded]` JD figure and your stated floor |
| Success metrics | None stated: "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | Seven functions, a board-level line and a team of one, priced at $70–85k, don't fit together as one role | `[inferred]` from the scope list against the stated pay and resources |
| Market calibration | Not established. The pay-band search was refused, so I won't put a market figure against $70–85k | `[grounded]` the search was unavailable |
| Unknowns | Marketing budget, equity terms and percentage, headcount plans, who sets the metrics | `[grounded]` JD silence |
| Contradictions | None between the JD and a careers page; no page could be checked | `[grounded]` no fetch made |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay $70–85k (your floor: $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated floor. Fit fails because the top of the range is $65k under it | `[grounded]` JD and your statement | none; only the employer raising pay or you revising the floor resolves it |
| R2 | On-site in Austin 5 days a week (you: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint. The JD says "no exceptions", so there is no remote path | `[grounded]` JD and your statement | none; same as R1 |
| R3 | 8+ years growth leadership | must_have | adjacent | medium | discovery | You have 9 years in growth, with growth lead then Head of Growth titles. The years spent in leadership roles aren't stated, so the 8+ isn't confirmed. Prose self-report caps at `medium` | `[grounded]` your background as typed | n/a unless the gates reopen |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid and controlled a budget while scaling $8M to $40M ARR over three years. Limit: B2C subscription, not e-commerce enablement | `[grounded]` your background as typed | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze. Same B2C-subscription limit | `[grounded]` your background as typed | none |
| R6 | SEO/content | must_have | unclear | none | discovery | Your background doesn't mention SEO or content ownership, so there is no evidence either way | `[grounded]` silence in your background | see G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Nothing in your background mentions either | `[grounded]` silence in your background | n/a unless the gates reopen |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Nothing in your background mentions either | `[grounded]` silence in your background | n/a unless the gates reopen |
| R9 | Operating as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7, which says nothing about solo execution across seven functions | `[grounded]` your background; `[generic]` that solo-operator roles weigh hands-on execution over management | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6, must_have) | discovery | Your background is silent on SEO and content | It is the one must-have row left open, but R1 and R2 fail regardless | Owning an organic channel or content calendar; directing an SEO agency; owning content-driven landing pages | A channel report or traffic dashboard from GA4 | `[grounded]` silence in your background |
| G2 | Solo operation (R9, important) | discovery | Managing 3–7 people is not the same as executing alone | Matters only if the gates reopen | Stretches with no team; hands-on campaign builds in Braze or SQL | A campaign build or analysis you did yourself | `[inferred]` from team size against the solo requirement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seniority-pay mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The pay may sit well below what the seniority and scope normally command. I can't confirm that without the market sweep, so it stays a signal | `[inferred]` from the JD's own years and pay; `[generic]` that a market band would be needed to confirm | What is the full compensation, including equity percentage, vesting and strike price? | unresolved |
| RR2 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several full roles may be folded into one title | `[inferred]` from the seven-function list | Which of these functions are real priorities in the first year, and what is the budget for each? | unresolved |
| RR3 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Overtime may be routine rather than occasional, and it comes alongside the lowest pay | `[inferred]` from the framing as culture, not exception | How many evenings and weekends were worked in the last quarter, and by whom? | unresolved |
| RR4 | Absent success metrics | risk_signal | medium | "success metrics will evolve as we learn" | Accountability for revenue growth with no stated targets | `[grounded]` JD wording | What would you want to see from this role at 90 days and at 12 months? | unresolved |
| RR5 | Responsibility without authority or resources | unknown | — | "team of one"; "dotted line to the board" | Budget, tooling and decision rights are unstated | `[grounded]` JD silence | What budget does this role control, and which decisions does it make without CEO sign-off? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and who would I report to? | unresolved |
| RR7 | Pay and location stated plainly | positive_signal | — | "$70–85k base"; "On-site in our Austin office 5 days a week — no exceptions" | The employer states its two hardest terms up front, so you can screen it out early | `[grounded]` JD | Is the range final, or negotiable for the right candidate? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | see R1, R2 | `[grounded]` R1, R2 | pending your approval |
| A2 | Screen future postings for the two gates before reading further. Pay above $150k and a remote option decide your shortlist | see R1, R2 | `[grounded]` your constraints | pending your approval |
| A3 | If you contact them anyway, ask only whether pay and location are fixed, and don't submit an application until they answer. Ask RR1 and RR5 verbatim | see RR1, RR5 | `[grounded]` register | pending your approval |

No CV or outreach wording is proposed this turn. Nothing above is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth"; the search was refused. It would have moved role reality's contradictions row and RR6 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary range Series A startup base salary 2026"; the search was refused. It would have moved the market calibration row and confirmed or cleared RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd like to offer to write this up as `tuesday-dossier.md`, which keeps the evidence map and register in one file you can reuse. Say the word and I'll emit it.

**Upgrade menu**

- Search permission, if you grant it: the employer check would settle RR6, and the pay sweep would settle RR1 and fill the market calibration row.
- A link to the live posting on Novaline's own careers page: it would settle RR6 and check the JD against the page.
- A recruiter's or founder's written answer on pay and remote terms: it would settle R1 and R2, which are the only rows that could change the decision.
- A hiring manager's name: it would add a scope read for role reality.
- A GA4 channel report or an SEO example: it would settle R6.

**Questions:** none this turn. Your constraints and the posting's own terms settle both gate rows, so nothing I could ask would change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.