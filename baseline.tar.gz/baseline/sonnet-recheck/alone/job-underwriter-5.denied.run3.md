I'll read the references the skill requires before building the assessment.
**Yes, it's worth applying, but not yet a clean yes. Status: `conditional_go`.** Your location, right to work and pay floor aren't established (R1, R2). I also couldn't check the employer independently (RR1). Neither is a mark against your fit.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (US-based remote or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts)

R8 (`medium`) is a credible bridge with its limit named. R9 and R10 wait on your answers.

**Opportunity ledger.** The stated pay sits at or above the report's median (RR4) and the stack and deliverables are concrete (RR5). Against that, the employer is not independently confirmed (RR1), and the reporting line and team size (RR2) and the equity terms (RR3) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (US-based remote or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you clear R1 and R2; (2) the opening and employer verify live, RR1; (3) BigQuery is framed as adjacent, never as experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted at 09:10; I could not read the page myself (RR1) |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Posting status | "Accepting applications" when you copied it at 09:12 | `[grounded]` your report; not checked by me |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| Scope read | Looks like ownership of one domain's pipelines. The JD mentions no direct reports | `[inferred]` from the JD's single reporting domain and its silence on reports |
| Market calibration | The report puts Senior Data Engineers at Series B–D companies at a $151,000 median (interquartile range $139,000–$163,500), "Senior" at 5–8 years, and scope at one domain with no direct reports. The posted band's midpoint ($157,000) is inside that range. The JD's 5+ years and single-domain scope match the report's norm. Series C is the stage the report covers. This is a pattern, not a claim about what Pellucid will offer. | `[generic]` Datawright 2026 report you supplied, compared with `[grounded]` posting figures; `[inferred]` that the stage matches the cohort |
| First 90 days / first year | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager (the posting names none), team size, equity terms, how the app and CRM sources are structured | `[grounded]` JD and your note |
| Contradictions | None between the JD and about text as pasted, but both are your copies from the same site, so this is not independent confirmation | `[grounded]` pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office, i.e. US-based and able to work in the US | hard_gate | unclear | none | hard_gate | You haven't stated where you are, your right to work or any location limits, so there's no claim to grade. The posting doesn't mention work authorization | `[grounded]` JD terms; your message silent | G1 question |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor stated, so the stated band can't be tested against one | `[grounded]` JD figure; your message silent | G1 question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It's stated in prose with no inspectable proof yet. Years of experience aren't a gate | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily", specific but unprobed | `[grounded]` your stated background | offer: a sanitized code sample would raise this to high |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. BigQuery is a separate row | `[grounded]` your stated background | offer: a sanitized dbt docs or lineage screenshot would raise this to high |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration". Your ownership of the DAGs wasn't stated, so claim use, not design | `[grounded]` your stated background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Coverage and results weren't stated | `[grounded]` your stated background | offer: a sanitized suite config or data-docs page would raise this to high |
| R8 | BigQuery as the warehouse | important | adjacent | medium | transferability | Carries over: dbt modelling and warehouse SQL on Snowflake. Limit: you've never used BigQuery, so its tooling, cost model and operations are untested. The JD names BigQuery in the mandate but doesn't list it under Requirements | `[inferred]` requirement from the mandate sentence; `[generic]` that BigQuery's cost and partitioning model differs from Snowflake's | G4 bridge in plan A3 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't say which source systems your pipelines ingested from or what you owned in ingestion | `[grounded]` your message silent on sources | G2 question |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite may sit near this, but nothing says you defined agreements with producers or consumers | `[grounded]` your message silent; `[inferred]` possible adjacency | G3 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, right to work and pay floor (R1, R2, hard_gate) | hard_gate | Nothing stated about your location, authorization or pay floor | Two hard gates are unconfirmed, so the status can't pass `conditional_go` until they're settled | Not applicable: these are terms you meet or don't | None needed; your own statement is the evidence | `[grounded]` inputs silent |
| G2 | Ingestion from the app and CRM (R9, important) | discovery | Pipelines are described, but not their source systems or your part in ingesting them | Ingestion is the first thing the mandate lists | Loading a product database or event stream; syncing a CRM or billing system; handling a third-party API or file feed; fixing a source that broke the load | A sanitized DAG listing or ingestion diagram | `[grounded]` inputs silent; `[inferred]` that this could lift R9 to adjacent or direct |
| G3 | Data contracts (R10, important) | discovery | Great Expectations tests are known; agreements with data producers or consumers are not | Contracts are named in the mandate | Schema or freshness checks agreed with upstream teams; versioned models with documented changes; alerting a producer when a source broke | A sanitized contract, schema-check config, or the incident write-up | `[grounded]` inputs silent; `[inferred]` that the GE suite may be adjacent |
| G4 | BigQuery (R8, important) | transferability | Strong dbt on Snowflake; no BigQuery use | The gap most likely to be probed, because the stack is named in the mandate | A personal or sandbox project on BigQuery; any BigQuery exposure you've had | A small dbt project run against BigQuery | `[inferred]` bridge from R5; `[generic]` that stack gaps are the likeliest objection for a named stack |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not independently confirmed | risk_signal | low | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)" | I couldn't check these facts against an outside source, so they rest on the company's own page. Severity is low rather than medium because the text is from the company's official pages and describes a specific, checkable entity | `[generic]` pattern for any employer whose research couldn't run, not a claim about this one | Is the Senior Data Engineer opening still active, and who is the hiring manager? | unresolved |
| RR2 | Reporting line and team size unstated | unknown | — | "Build and run the pipelines" | The role may be the only data engineer, or one of several | `[inferred]` from the JD's silence on team and manager | Who does this role report to, and how many data engineers are on the team? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Value and vesting can't be judged without terms | `[inferred]` from the missing terms | What is the equity grant, vesting schedule and current valuation basis? | unresolved |
| RR4 | Pay band at or above market | positive_signal | — | "$148,000–$166,000 plus equity" | Stated pay is not below the report's median, so there's no seniority-pay mismatch | `[grounded]` posting figures and your supplied report | Is the band fixed, or does it vary by level? | noted |
| RR5 | Stack and deliverables are concrete | positive_signal | — | "a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The JD names tools and outputs rather than vague scope | `[grounded]` JD | What does success look like at 90 days and 12 months? | noted |

## Application plan

All rows are proposals pending your approval. That covers resume wording and positioning advice as well as the actions; nothing is finalized until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle G1 before spending effort | R1, R2 are unconfirmed hard gates | `[grounded]` R1, R2 | pending your approval |
| E1 | Lead the resume with three truthful lines: "Built the dbt project (about 180 models) on Snowflake"; "Set up the Great Expectations data-quality test suite"; "Used Airflow for orchestration". Don't claim Airflow ownership, design, or BigQuery work | see R5, R6, R7 | `[grounded]` your stated background | pending your approval |
| A2 | Use R5 as your lead story: it's your strongest, matches the mandate, and the dbt discipline carries across warehouses | see R5, R8 | `[inferred]` from R5's strength against the mandate | pending your approval |
| A3 | Say plainly that your warehouse is Snowflake and you've not used BigQuery. Optionally build a small dbt project on BigQuery's free sandbox to narrow the gap | see R8, G4 | `[generic]` common way to close a stack gap | pending your approval |
| Q1 | Ask the questions in RR1, RR2 and RR3 verbatim in the recruiter screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both calls were refused: a search for "Pellucid Learning online tutoring K-12 Denver Series C $52M" and a fetch of pellucidlearning.com/careers/senior-data-engineer. They would have confirmed the company exists as described and the posting is live, which feeds role reality's organization and contradictions rows and RR1. Those rows now rest on your pasted text |
| 2. Role-family sweep | skipped | The Datawright report's figures are in hand and fix the market calibration line and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'd offer the deeper pass only once the L1 check has run: up to 5 more searches and 2 more fetches on funding and leadership news, hiring patterns and public employee reports.

## Dossier offer

If you'd like, I can write all of this into a `tuesday-dossier.md` you can keep or reuse.

## Upgrade menu

- Your location, right to work in the US, and pay floor: R1 and R2 close, and the decision likely moves to `go`.
- Your CV, plus a sanitized dbt docs or lineage page, Great Expectations config or data-docs page, or a DAG listing: R5, R6, R7 can rise to `high`.
- Answers on source systems and contracts: R9 and R10 resolve.
- The hiring manager's name: sharpens role reality's scope read and which story to lead with.
- Web access granted for target 1 (the company site and live posting): RR1 can close, or hold if the check fails.
- The deeper research pass above: say the word and it runs after that.

## Questions

G1 — What are your non-negotiables on location, right to work in the US and pay floor, and does Remote (US) or Denver at $148,000–$166,000 clear them?

G2 — What source systems did your payroll pipelines ingest from (product database, event stream, CRM or billing exports, third-party APIs), and which parts of the ingestion did you personally own?

G3 — Did you ever set explicit agreements with the teams producing or consuming your data (schema checks, freshness expectations, versioned models, alerts to a producer when a source broke), and what was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.