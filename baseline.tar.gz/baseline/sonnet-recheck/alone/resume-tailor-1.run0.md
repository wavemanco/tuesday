I'll read the reference files the skill requires before building the ledger.
I've built the ledger below, and nothing in it is applied yet. You pasted prose rather than a CV file, so each "current line" is your own sentence from your message.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV prose | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV prose | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV prose | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Line 1: "On-call rotation every fourth week for two years." Line 2: "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV prose | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year), pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV prose | pending your approval |

- **E1** keeps your sentences as separate claims. It leaves out the 40k figure because E3 already carries it.
- **E2** changes position only. The p99 result is the strongest match to the JD, so it should be the first thing a reader meets.
- **E4** splits the line because the original doesn't say the six incidents all fell inside the two on-call years. Two lines keep both claims true without tying them together.
- **E5** keeps your verbs, "onboard" and "pair". It doesn't say "mentor".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years backend | must-have | surfaced_by_edit | E1 puts "7 years" first. Your prose gives 7 years as a Senior Software Engineer and doesn't say what the earlier years were, so the backend share is unstated. | `[grounded]` your CV prose |
| M2 | Production Go | must-have | surfaced_by_edit | E1 leads with "Go and Rust daily for 4 years". Your prose doesn't say which of your three services are in Go. | `[grounded]` your CV prose |
| M3 | Distributed systems at scale | must-have | not_evidenced | Adjacent facts exist (three pipeline services, Kafka and gRPC listed, 40k requests/minute) but nothing states a distributed design. See C1. | `[grounded]` your CV prose |
| M4 | Strong incident response | must-have | surfaced_by_edit | E4 gives "Ran six incidents as incident commander" its own line. | `[grounded]` your CV prose |
| M5 | Experience mentoring | must-have | surfaced_by_edit | E5 shows onboarding and a month of pairing. It doesn't establish "mentoring" or "mid-level", because your prose gives neither the new hires' level nor any mentoring beyond month one. | `[grounded]` your CV prose |
| M6 | Go services at high request volume | important | surfaced_by_edit | E3 carries the 40k requests/minute figure on the service it belongs to. | `[grounded]` your CV prose |
| M7 | Drive down p99 latency | important | already_evidenced | The 380ms to 95ms bullet already says it. E2 only moves it to first position. | `[grounded]` your CV prose |
| M8 | Own on-call for your services | important | surfaced_by_edit | E4 shows the rotation and the duration. Your prose describes a rotation, not sole ownership of your services' on-call. | `[grounded]` your CV prose |
| M9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your prose touches product partnership. See C2. | `[grounded]` your CV prose |

## Gap handling (pending your approval)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Three ledger-pipeline services, one at about 40k requests/minute, plus Kafka and gRPC in a tools list. It never says how the services are spread across machines or what happens when parts fail. | A tools-list entry reads as exposure, not ownership, and this is a must-have that a reader will look for stated plainly. | Partitioning or consumer-group design you chose; a failure or retry path you designed (for example idempotent writes in a ledger); a migration or capacity change on a multi-instance service | A design doc, an architecture diagram, a postmortem, or a Datadog dashboard | `[grounded]` what your prose does and doesn't say; `[generic]` what an unstated must-have costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing about working with product or deciding what ships first. | The JD names this as a core duty, so silence leaves a visible hole, though it is weighted below the must-haves. | Negotiating the order of ledger-pipeline work with a product manager; deciding what to defer when the cache rework competed with other work; scoping a feature with product | A planning doc, a ticket thread, or a roadmap note | `[grounded]` what your prose does and doesn't say; `[generic]` how such duties are weighted on postings like this |

## Not written, and why (pending your approval)

- **"Senior Backend Engineer" as your title.** Your title is Senior Software Engineer, and a retitle must be an equivalent, not the JD's own title.
- **"Mentored mid-level engineers."** You onboard and pair with new hires. Their seniority isn't stated, and onboarding is a different kind of work from mentoring.
- **"Owned on-call for my services."** You described a rotation every fourth week.
- **"Go services handling 40k requests/minute."** Your prose doesn't say that service is in Go. Until you confirm it, the 40k figure stays attached only to "one of the three services".
- **"Distributed systems at scale" or "high-throughput distributed services."** Kafka and gRPC are listed tools, and a tool listed is not a tool owned.
- **"Partnered with product" or "shaped the roadmap."** Nothing in your prose supports it.
- **"Build-cache" or "developer-tools" experience.** Reworking a balance-read cache layer is not that, and the JD doesn't list it as a requirement.
- **"Reduced incidents" or "built the incident process."** You said you ran six incidents, nothing more.
- **"Cut p99 across services."** Your bullet is about one path, the balance-read path.

## Parse-safety check

You pasted text, so I could not check layout, columns, tables, text boxes, headers and footers, icons or skill bars, or the file type. The one thing I can see is that the headings I'm proposing are standard: Summary and Experience. If you send the file itself, I'll run the full check, including a scan for hidden text left by a template or earlier tool.

## Upgrade menu

- **The CV as a file (.docx or text-layer PDF):** unlocks the full parse-safety check.
- **A prior CV version:** may hold evidence your current one dropped, such as earlier backend years for M1.
- **A design doc, postmortem or dashboard screenshot for the cache rework:** gives M3 and M7 something inspectable to rest on.

## Questions

C1 — Is there anything about how your services run across multiple machines, or how they handle failure, that you designed or decided yourself?
C2 — Have you ever worked with a product manager to decide what to build first or what to defer?
M2 — Which of your three services are in Go, and is the 40k requests/minute one among them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.