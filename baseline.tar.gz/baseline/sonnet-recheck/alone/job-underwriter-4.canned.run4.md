I'll read the reference files the skill requires before building the assessment.
# Should you go for it? Brindlemoor, Senior Pricing Analyst

## Decision snapshot

**Yes, it's worth pursuing on fit, but it can't be a go yet. The JD you pasted says fully remote, and Brindlemoor's own careers page says Leeds office four days a week (R1, RR1). Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R7, R8 · adjacent: R6 (Monitoring rating models)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

Your answer on location settles R1, and one more answer from you on monitoring (G1) firms up R6.

**Opportunity ledger.** The mandate and reporting line are stated (RR4). Against that, the working pattern conflicts between the posting and the employer's own page (RR1), the salary is withheld (RR2), little about the company beyond its careers page could be found (RR3), and team size is unstated (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers for the hold:** (1) whether you can work from Leeds four days a week, or need fully remote (R1); (2) Brindlemoor confirming which working pattern is real (RR1). If you need fully remote and Brindlemoor confirms the office pattern, R1 becomes `hard_gate_fail` and the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech. Its own careers page (brindlemoor.co.uk) lists this role. A search for the company and its pet-insurance product returned nothing, so size, stage and who underwrites the product are not established | `[grounded]` JD header and careers page; `[grounded]` empty search result |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, and recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week". These contradict each other and I have not resolved it | `[grounded]` both texts |
| Management scope | The JD lists no line-management duty. Whether the role has reports is unstated | `[grounded]` JD silence |
| Hiring manager's footprint | Odile Varga is Director of Pricing. She gave a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books. Before Brindlemoor she was head of pricing analytics at Calloway Re for six years | `[grounded]` search result for her public profile page (snippet only, page not fetched) |
| Scope read | A senior analyst owning one product's pricing end to end, which sits at your current level. Her talk suggests model monitoring matters to her | `[inferred]` from the JD's mandate against the careers page's reporting line and her talk title |
| Market calibration | A survey of UK insurers and insurtechs puts senior pricing analyst base pay at a £58,400 median, with an interquartile range of £52,100 to £64,900 (n=612). This is the band to expect, not Brindlemoor's offer, and the JD withholds the salary | `[generic]` Pricewell 2026 survey (snippet only); `[grounded]` JD silence on salary |
| First-90-days outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Salary, team size, data and modelling stack, who underwrites the product | — |
| Contradictions | Remote (JD) against Leeds four days (careers page) | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK), set against your working-pattern constraint, which you haven't given | hard_gate | unclear | none | hard_gate | The JD says fully remote and the careers page says Leeds four days. Your own constraint is unstated, so neither reading can be checked. Confidence is `none` because there is no statement of yours to grade | `[grounded]` JD, careers page, and the absence of a stated constraint | Ask whether you can work Leeds four days a week; verify with Brindlemoor (RR1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years' pricing analytics at a UK motor insurer, the last two as senior analyst. Self-reported, nothing inspected yet | `[grounded]` your background as stated | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", confirmed in prose but with no artifact | `[grounded]` your background as stated | Optional: a sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. No inspectable artifact | `[grounded]` your background as stated | Optional: a model-documentation excerpt would raise it to `high` |
| R5 | Build rating models | must_have | direct | medium | none | Covered by "built and maintained" the young-driver GLM, limited to that one book | `[grounded]` your background as stated | none |
| R6 | Monitor rating models | must_have | adjacent | low | discovery | You said "maintained", which is near monitoring but doesn't say it. I took the lower band. Whether you tracked live model performance (drift, actual-versus-expected) is unconfirmed | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | Question G1 below |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" doesn't say how much of the design and analysis was yours | `[grounded]` your background as stated | Confirm your ownership split before it goes on the CV |
| R8 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD also names recommendations to product, which your background doesn't evidence | `[grounded]` your background; `[grounded]` JD | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background as stated | none |
| R10 | Pet-insurance product knowledge | preferred | adjacent | low | transferability | The role is a pet-insurance product, but the JD doesn't require pet experience. Your motor rating and testing work is a credible bridge. Its limit is that you haven't worked with pet-specific rating factors or claims patterns. I took the lower band because the bridge is my inference | `[inferred]` bridge derived from your motor GLM work; `[generic]` that pet and motor rating differ in their factors | Frame it as adjacent and never as pet expertise |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R6, must_have) | discovery | You maintained the young-driver GLM. Nothing says whether you tracked live performance or what you did when it drifted | A must-have at `adjacent`, and the hiring manager's published talk is about monitoring | Actual-versus-expected tracking, a monitoring dashboard or pack, a refit triggered by drift, flagging a rating-factor problem to underwriting | A monitoring pack, a dashboard screenshot, a model-review paper | `[grounded]` your wording; `[inferred]` that it matters most to this reader, from the talk title |
| G2 | Pet-insurance knowledge (R10, preferred) | transferability | Motor rating and test experience, with no pet exposure | Preferred only, so a minor risk | Frequency and severity modelling, renewal or retention pricing, any exposure to animal or health-claim data | None needed | `[inferred]` bridge; `[generic]` that pet rating factors differ from motor |
| G3 | Working pattern (R1, hard_gate) | hard_gate | The posting's two sources disagree and your constraint is unknown | Decides the status | Whether Leeds four days a week is workable for you | A reply from Brindlemoor on the real pattern | `[grounded]` JD and careers page |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicted across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be stale or copied from an earlier version of the role. Severity is `medium` because it only becomes severe if you need remote work | `[inferred]` from the two texts disagreeing | Is this role fully remote, or office-based in Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | JD gives no salary | The figure may sit anywhere in the survey band, or the employer simply doesn't publish it | `[inferred]` from the posting's silence against the `[generic]` band | What salary band is budgeted for this post? | unresolved |
| RR3 | Employer footprint beyond its careers page not found | risk_signal | low | "Brindlemoor (insurtech)" | A search for the company and its pet product found nothing. It may be small or new. This is a pattern for companies of this size, not a claim about this one | `[generic]` pattern for companies of this size, not a claim about this one | Who underwrites the pet product, and how large is the pricing team? | unresolved |
| RR4 | Mandate and reporting line stated | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | Scope and the reporting line are clearly defined | `[grounded]` JD and careers page | Which price decisions does this role own, and which go to underwriting? | noted |
| RR5 | Team size and tooling unstated | unknown | — | "Own pricing analytics" | "Own" may mean sole analyst, which would suit you only if support and data access exist | `[inferred]` from the JD's wording against its silence on team | Who else is on the pricing team, and what is the modelling and data stack? | unresolved |

## Application plan

Everything in this table is a proposal and is **pending your approval**. That covers the prose-style advice in P1 as well as the resume lines in E1.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Odile before investing in the loop | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV lead lines, in your own words: "built and maintained the GLM rating model for the young-driver book"; "ran 14 price tests last year with the underwriting team"; "present the quarterly pricing review to the head of underwriting". Don't add "monitored", "designed", "led" or any pet claim | See R4, R5, R7, R8; every clause traces to your sentences | `[grounded]` your background as stated | resume_edits_pending_approval |
| P1 | If G1 is confirmed, put the monitoring story near the top, because the hiring manager has spoken publicly on monitoring models in small books. If it isn't, don't claim it | See R6, G1 | `[inferred]` from the talk title | pending your approval |
| A2 | Ask RR1, RR2, RR3 and RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Weigh any offer against the survey band (median £58,400, interquartile range £52,100 to £64,900) | See RR2 | `[generic]` survey band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results, so not established) and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the contradictions row, R1, RR1 and RR3. The live posting contradicts the pasted JD on location |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote". It returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. Moved market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor". It returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. Moved the footprint row, the scope read, G1 and P1 |

I can package this as a `tuesday-dossier.md` if you'd like to keep or reuse it.

**Upgrade menu**

- Your working-pattern constraint (where you live, whether Leeds four days a week is workable) → R1 settles, and the status moves to `conditional_go` or `no_go`.
- A monitoring pack, dashboard or model-review paper → R6 firms up and G1 closes.
- A sanitized model-documentation excerpt or query sample → R3 and R4 rise to `high`.
- Brindlemoor's reply on working pattern, salary and team → RR1, RR2 and RR5 close.
- A deeper research pass on Brindlemoor (funding, leadership, public staff reports, recent news; up to 5 more searches and 2 more fetches) → RR3 firms up. Say the word and it runs.

**Questions**

R1 — Can you work from Leeds four days a week, or do you need fully remote? And are there any other terms you wouldn't trade (pay floor, hours)?

G1 — In your motor role, did you track the live performance of the young-driver GLM, for example actual against expected or drift? If so, what did you own, what did you do when it moved, and is there a pack or dashboard you could share?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.