Loading is done; I'm running the L1 research searches (company values, interview process, strategy, interviewer), then I'll build the pack.
Using Edit instead.
Femi, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-denied-6f4fc089/dbfa2ac8-65f4-4b61-bc27-e24fe7f1326b/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`.

- **Assumption:** I built it as a hiring-manager round, since you didn't say how Tobias Wrenfield relates to the role.
- **Research:** Web search was denied here, so all four of my searches (company values, interview process, strategy, Tobias Wrenfield) were refused. Nothing in the pack is about Saltmarsh beyond your JD and your own words. The Sources section lists each refused query. There are no company-specific questions or interviewer read, and the values section is absent.
- **Highest-ROI prep:** Question A1. Your sentence says you ran the weekly content-drop calendar for your main title. The JD asks for a live-events calendar across two titles. The pack coaches you to say exactly what you ran and stay inside it.
- **Your two stated gaps:** The pack coaches plain, unqualified answers for "I haven't led a team" and "I haven't worked on a game with in-app purchases." Those are rehearsed in A2 and A3 and again in E1.
- **Other gaps:** For the lines your sentences don't cover, the answer guidance is a slot for you to fill from your real experience, or to say plainly it wasn't yours. Examples are whether any drop counted as an event, and how the checklist items were chosen. The pack never supplies those details for you.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias Wrenfield the person you'd report to, or a more senior interviewer, and has the recruiter said anything about the format of the hour? The answer reweights the banks.
2. Can you allow web search so I can rerun the research on Saltmarsh and Tobias Wrenfield's public work? A deeper pass would be up to 6 more searches and 2 more fetches, and take several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations (title from you; nothing else about him is known to this pack). Format: 60 minutes, Friday. Relationship assumed: hiring manager, not confirmed, so the persona weights below rest on that prior.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No published values were available to this pack, so no question carries this tag |
| EXP | Whether the claims in your background survive follow-up questions, and what was actually you |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you know the company and can think at its level |
| CASE | A live problem from the role, scored on structure and reasoning |

Question IDs run by persona. Fit-snapshot rows are F1 to F9, so the question bank letters skip F and the peer bank is G.

## Prep triage (the interview is Friday)

1. Say A1 and A2 aloud until the plain sentences feel boring. A1 is the highest-ROI prep in this pack.
2. Build the 90-second arc in D1 from your own four sentences.
3. Run C1 and C3, the two questions that sit on your retention and checklist lines.
4. Think aloud through B1 to B4 once each, using the clarify-then-structure order.
5. Pick three reverse questions and rehearse how you ask them.

Everything else is insurance.

## Fit snapshot

Quotes in the evidence column are your own sentences from your message. Gap and bridge language is spoken aloud, so it stays inside those sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two years on the calendar. It does not say whether the title was run as a live service. Answer slot: the JD's "producing live-service" line makes a probe likely. If your main title was a live game that you updated on a schedule, say so in your own words; if the four years included other work, or the title was not run that way, say so plainly and stay with the two years on the calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you ran the weekly content-drop calendar for your main title, for two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your sentence says a weekly content-drop calendar for your main title. The pack's observation is that the JD says live events and two titles, and your sentence says drops and a main title. The words stay at your scope: "I ran the weekly content-drop calendar for our main title." Answer slot: if any of those weekly drops contained something you would call an event, say what and what part was yours; if none did, say so plainly and stay with the drops |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message; "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The JD says coordinate, and your sentence says you have not led a team; the bridge keeps those two apart. Words you can use: "I haven't led a team." Answer slot: if you worked with design, art, engineering or community on a drop, say which and what you did there, in your own words; if you did not, or QA was the only group, say so plainly and stay with the calendar and the checklist |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your sentence says you presented monthly retention numbers to the studio head. The pack's observation is that the JD says own the review and its KPIs, and the sentence says presented. The words stay at your scope: "I presented the monthly retention numbers to the studio head." Answer slot: if the studio looked back at drops after they shipped and any part of that was yours, say what; if there was no such review, or it was not yours, say so plainly and stay with the monthly presentations |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but a one-line claim, so expect a probe on which retention measures were in those numbers. Lead with it in its own terms: monthly, retention numbers, the studio head. Answer slot: if you know which measures they were and how they were counted, say so in your own words; if someone else produced them or you do not know, say so plainly and stay with presenting them |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Your sentence reaches the requirement in its own terms: you wrote the checklist and QA still uses it. The pack's observation is that the sentence says wrote, not that you ran each release against it, so the words stay at "wrote" and "still uses", and the JD's word "manage" is not borrowed |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is a written document that another team uses, which touches the requirement without showing how clear your writing is. Answer slot: if you have a written piece you could point to, say what it is; if there is none you can share, say so plainly and stay with the checklist |
| F9 | Comfort with in-app purchases in a live-events setting (a role-family pattern; no JD line names it) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| 3+ years producing live-service games or apps | A1, A5, D1, E1 |
| Experience running a content calendar | A1, E2, B1 |
| Plan and run the live-events calendar for two titles | A1, B1, B2 |
| Coordinate design, art, engineering and community on each update | A3, G1, G2 |
| Own the post-event review and the KPIs it reports | B3, C2 |
| Comfortable with player-retention metrics | C1, C2, B4 |
| Manage the release checklist with QA | C3 |
| Clear written communication | D3 |

F9 is not a JD line; it is covered by A2.

## Persona table

No loop source was available, so the weights rest on the hiring-manager prior and the generic loop pattern, flat beyond that. If the recruiter tells you who else you meet and in what format, the weights change.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (Bank A, 5 questions) | Quiet probing of the scope step: one main title to two, drops to events, no team led, no in-app purchases | High. The hiring-manager prior puts it first, and F3, F4 and F9 are gaps in your own words | Rehearse A1 until it is boring; state each limit once in your own sentence and return to what you ran |
| Case / Strategist (Bank B, 4 questions) | Live problems from the role: two calendars, a clash, a post-event review, a retention drop | High. The hiring-manager prior puts it beside the Skeptic, and the JD is about planning and decisions | Clarify, then objective, segments, approach, metrics, risks; think aloud and challenge one premise politely |
| Data-Driven Prober (Bank C, 3 questions) | Retention numbers and the checklist taken apart line by line | Medium. The JD names retention and KPIs, and F5 and F6 rest on one sentence each | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational (Bank D, 3 questions) | The opening walk-through and a casual chat about games | Medium. A 60-minute conversation tends to open with your story, and casual questions here are still scored | A 90-second arc built from your own sentences; treat the games question as scored |
| Pressure (Bank E, 2 questions) | A time-boxed "why you" and an attribution challenge | Low. The hiring-manager prior does not include it, but the stated gaps make one challenge possible | Pause, restate, hold the sentence you said, concede the stated limit once |
| Peer Evaluator (Bank G, 2 questions) | Seam and disagreement scenarios across design, art, engineering and community | Low. The interviewer is a function head, but the JD asks you to coordinate those four groups, so one scenario is likely | Propose seam principles instead of pretending to know the seam; show spine and tact together |

Values / Behavioral is not weighted: no published values were available to this pack, so no values round is detected. Stories in Bank G and D can still serve it.

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You ran the weekly content-drop calendar for your main title. This role runs the live-events calendar for two titles. What would be different for you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Open with your sentence as it stands: "I ran the weekly content-drop calendar for our main title for the last two years." Then say, as a plan, what you would want to learn about the two calendars before changing anything. Answer slot: the JD pairs a live-events calendar with two titles, so expect a probe on whether anything on your calendar was an event rather than a drop. If something was, say what and what part was yours; if not, say so plainly and stay with the weekly drops. Hold through two follow-ups by returning to the calendar you ran, never by widening it, and concede the scope in your own sentence's terms: your main title, weekly drops | F3 is where the JD's own wording presses hardest on your material, so this objection arrives in some form. JD because it scores a stated requirement; the Skeptic delivery is why it sits in this bank |
| A2 | "What would be hardest for you on day one, given you haven't worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Say it once, plainly, in your words: "I haven't worked on a game with in-app purchases." Do not qualify it. Then the plan, said as a plan: you would ask how revenue figures into the events in each title and what the post-event review reports, and learn the rest from the people who own it. Then return to your sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Hold that through two follow-ups; concede only the negative you stated. Do not say your work proves it transfers, and let the interviewer draw that line | F9 is a gap you named yourself, so the honest answer can be rehearsed to the word. JD because it tests the role's fit; the pack does not know whether this will be raised, only that it is the cheapest to prepare |
| A3 | "Have you led people or a team before?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." | Answer in your own words: "I haven't led a team." Then the JD's verb: it says coordinate, not lead. Answer slot: if you worked with design, art, engineering or community on a drop, say which and what you did there; if you did not, say so plainly and stay with the calendar you ran. Do not stretch coordination into leading | F4 keeps the JD's verb apart from the thing you said you have not done. JD because the requirement is the interviewer's scoring line; EXP-style attribution follows |
| A4 | "Why live operations, and why Saltmarsh, and why now?" | CO | [generic] | Selection scaffold, because the pack could not research the company. Give two reasons that are true: what you want more of in this work, taken from the JD's own list of calendar, review and KPIs; and one thing about Saltmarsh's titles that you looked at yourself. If no specific reason about Saltmarsh comes to mind, say so plainly, then say what draws you to live operations. Do not borrow a reason from this pack | The motivation probe is one of the Skeptic's stems. CO because it tests homework; the pack holds no company facts, so it carries no claim about Saltmarsh. F3 is the scope step your reasons must make sense of |
| A5 | "You're an associate producer applying for a producer role. What changes?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Start from the title as you hold it: "4 years as an associate producer at a puzzle-game studio." Then take the JD's list: a calendar for two titles, the post-event review and its KPIs, coordination across four groups. For each item, say whether it was part of your associate role or not. Answer slot: if any item was already part of your role, say which and what you did; if none was, say so plainly and say which you would learn first | F1 and F4 hold the title step. EXP because it tests what the title covered; JD content, with delivery as a title challenge |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You take over the live-events calendar for two titles on Monday. What do you need to know first, and what does your first month look like?" | CASE | [generic] | Clarify before structuring. Ask what each title's events are meant to change, what is already committed and who signs it off, where the two calendars touch the same teams or release windows, and what the post-event review reports today. Then objective, segments (each title, each team), approach, metrics, risks. Think aloud and name one assumption you would test first. The question needs no claim about your past, so the guidance makes none | JD's calendar line (F3) turned into a decision. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Two events, one per title, land in the same week and engineering can support one. Walk me through the call." | CASE | [generic] | Structure it: what each event is tied to and how flexible its date is; who has the authority to decide and who must be told; the options (move one, shrink one, add support); how you would tell design, art and community; what you would record. No claim about your past, so the guidance makes none | The coordination line in F4, asked as a decision. CASE because it scores structure under a trade-off |
| B3 | "An event underperforms against what the team expected. How do you run the post-event review?" | CASE | [generic] | Clarify what the target was and who set it. Then separate how the event ran from how it was designed, say what you would compare it with, what you would write down, and what changes in the next calendar slot. Keep it a method, not a story: nothing here claims you have done this | The JD's post-event review line (F5), asked as a method. CASE because you build it live; JD because the requirement is the interviewer's own |
| B4 | "A retention number drops after an update ships. Diagnose it." | CASE | [generic] | Clarify which retention measure and which players first. Line up the drop against the release date and what changed in the update. Segment by player group and platform. State your hypotheses, the order you would test them, and what you would tell the teams meanwhile. Ask what the release checklist covered | Retention is on the JD (F6). CASE delivery with JD content; the Prober will push on definitions, so say which measure you mean |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Which retention measures were in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you did in your sentence's terms: you presented the monthly retention numbers to the studio head. Answer slot: the JD asks for comfort with retention metrics, so expect a probe on the measures. If you know which measures they were and how they were counted, say so in your own words, and name the assumption behind them that you would defend least; if someone else produced them, or you do not know how they were counted, say so plainly and stay with presenting them each month | F6 and F5 rest on this one sentence. EXP because it tests the sentence; the weakest-assumption move is the credibility gain, and where you cannot make it the honest branch is to say you do not know |
| C2 | "Which retention measure would you watch after an event, and what could make it misleading?" | JD | [generic] | Choose the one measure you can define exactly in one sentence, and say what would make it misleading: that is the weakest-assumption move, applied to your own pick. Then say what else you would look at beside it. The question asks for your view, so the guidance makes no claim about your past | The JD's KPI line (F5) put as a concept question. JD because it scores the stated metrics requirement |
| C3 | "You wrote the release checklist QA still uses. How did the items get on it, and who decided?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats your sentence states: you wrote it, and QA still uses it. Answer slot: the JD says manage the checklist with QA, so expect a probe on how its items were chosen. If you decided them, or settled them with QA, say how, in your own words; if it was built from a template or the items were handed to you, say so plainly and stay with the fact that you wrote it. Do not describe a process you did not run | F7 is a clean line the Prober will take apart, since "wrote" and "manage" are different verbs. EXP because it tests what was yours; JD content |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc made only of your four sentences: the four years as an associate producer at a puzzle-game studio; the calendar you ran for your main title for the last two years; the checklist you wrote and QA still uses; the retention numbers you presented each month. Answer slot: the first two years are not in your sentences; say what they were if you wish, in your own words, or leave them out. End on why this role, in your own reason | F1 and F2 give the spine. EXP because it is the biography question; the register is Conversational, so brevity is the score |
| D2 | "What are you playing right now, and what do you notice about how it runs its events?" | CO | [generic] | Pick a game you really play, and say what you notice about its cadence and what a player sees. This is a casual question that is still scored, so have one real answer ready. The pack cannot supply it and makes no claim about your past | A games-studio chat probes taste as a proxy for interest. CO because it checks engagement with the field; nothing here is entity-specific |
| D3 | "What does a good update note for the other teams look like to you?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Give your own view of a good note: what it must let a reader do without asking you. Answer slot: if you wrote update or release notes for other teams, say what they held; if you did not, say so plainly, and stay with the checklist you wrote and the team that uses it | F8 is a low-confidence row on the JD's written-communication line. JD because it scores that requirement |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already run live events on a title that sells things?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold: three things, each at its own scope, as you said them: the weekly content-drop calendar for your main title, the checklist you wrote, the monthly retention numbers you presented. Concede once, specifically: "I haven't worked on a game with in-app purchases." Do not claim to be better than the other producer; hold through two follow-ups and concede only that | F9 and F3 are what a time-boxed challenge will aim at. JD because the content is the role's fit; Pressure is the delivery |
| E2 | "How much of that content calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence as written: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you decided what went into each week, say how; if others set the content or priorities, say which parts, plainly, and describe what you ran. Do not defend a share you cannot name | F2 and F3 hold the attribution; the stem tests honesty under interruption. EXP because it tests what was yours |

### Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design wants a bigger event than engineering can fit into the release. Where do you land, and what happens when they disagree with you?" | CASE | [generic] | Propose principles, not a verdict: ask what each side needs and what the event is meant to change, decide on a stated basis, say who you tell and in what order, and say how you disagree with a peer without taking over their call. The question asks about no past, so the guidance makes none | The coordination line in F4 as a seam question. CASE because it is a live trade-off |
| G2 | "Tell me about a time you disagreed with someone in design, art, engineering or community about what shipped." | EXP | [generic] | Selection scaffold, because none of your four sentences carries this story. Pick a real time with a named stake, a position you stated, and a working relationship that was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your experience does hold, or how you would handle it | The JD names those four groups (F4) and your sentences show none of them. EXP because it asks for a real instance |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "How are the two titles' calendars set today, and where do they collide?" | The JD pairs one calendar with two titles; it shows you thought about the seam rather than the title |
| RQ2 | "What does the post-event review report today, and which of its numbers does the team trust least?" | It goes to the JD's KPI line and signals you will read the numbers critically |
| RQ3 | "How does the release checklist run with QA today, and where does it hurt?" | The JD's checklist line, asked as a problem to solve rather than a task to receive |
| RQ4 | "Which of design, art, engineering and community is hardest to align on an update, and why?" | It shows you expect the coordination work to be the job |
| RQ5 | "I haven't worked on a title with in-app purchases. What would you want me to learn first?" | It turns the gap you named into a request for direction; ask it only if you have already said the gap in the room |
| RQ6 | "What would a good first ninety days look like in this seat?" | A direct way to learn what the interviewer expects in the first weeks |

No reverse question is tied to Tobias Wrenfield's own path, because nothing about it is known to this pack.

## Prohibited claims

This pack will not coach these. The honest form of each is what you can say.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F4 | The plain acknowledgment: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says drops for a main title. A1's slot stays inside the drops |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says presented the monthly numbers |
| Managed the release process with QA | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says wrote and still uses. C3's slot stays inside the checklist |
| Four years producing live-service games | Inflated form of F1 | F1's quotes at their own scope: four years as an associate producer, two years on the calendar. The limit is the pack's observation: your material does not say the title was run as a live service |
| Drove retention or owned the retention analysis | Inflated form of F6 | F6's quote at its own scope. C1's slot stays inside the numbers you presented |

## Sources

Provided documents: the job description text you pasted, and your message describing your background. Nothing from a dossier.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have moved the values cheat sheet and the VAL questions |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | The search was refused. It would have moved the loop structure and persona weights |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The search was refused. It would have moved the CO questions and a grounding brief |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have moved the interviewer read and a tailored reverse question |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent: `Saltmarsh Games values mobile game studio` (refused); `Saltmarsh Games interview process Live Operations Producer` (refused); `Saltmarsh Games strategy news 2026` (refused); `Tobias Wrenfield Saltmarsh Games Head of Live Operations` (refused).

## Upgrade menu

- Permission to run web search → values, loop structure, current strategy and Tobias Wrenfield's public footprint; this turns the four `unavailable` rows above into research, adds an interviewer read and a tailored reverse question, and may add a values cheat sheet
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Saltmarsh's strategy and recent organization changes, for the CO bank
- The recruiter's prep email, or the format of the day → documented rounds and persona weights in place of the hiring-manager prior; any pre-declared deliverable gets its own build section
- Whether Tobias Wrenfield is your future manager or a skip-level → reweights every bank
- Your own answers to the answer slots in F1, F3, F4, F5, F6 and F8 → those rows become quoted evidence and their bridge language is rewritten from it
- A content-calendar screenshot, the release checklist, or one retention slide (with confidential details removed) → the inspectable artifacts that could raise F2, F6 and F7 from `medium`
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a named most-likely objection in place of the one inferred here
