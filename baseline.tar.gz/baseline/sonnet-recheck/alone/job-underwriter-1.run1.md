Web search was declined, so I ran this on the JD and your background alone.

## Decision snapshot

**Yes, apply. You're a fit on the core of this role, and what's open are checks, not blockers. Status: `conditional_go`.** R1, R2, R3, R4, R6a and R8 are the `direct` must-haves. It is conditional because the employer and compensation could not be checked (RR1, RR2).

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6a, R8 · adjacent: R5 (Define and maintain the metrics layer)
- `important` — unclear: R6b (Partner with clinicians), R7 (Mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA-type regulated data handling) · absent: R9a (Healthcare data experience)

R5 (`low`) is the must-have to firm up. R6b and R7 are `unclear` because your background says nothing either way.

**Opportunity ledger.** The role is concretely scoped, with named partners and named deliverables (RR5). It is unverified from here: the employer could not be checked (RR1), compensation is not stated (RR2), and the scope of metrics-layer ownership, mentoring and experiment volume is open (RR3, RR4, RR6).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) pay and location turn out compatible with your terms, see RR2 and the terms question below; (3) your answer on G1 shows you have owned shared metric definitions, see R5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C | `[grounded]` JD header; not independently verified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; healthcare/HIPAA a plus | `[grounded]` JD |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Scope read | A conventional senior individual-contributor scope with light mentoring. "Mentor" does not say line management | `[inferred]` from the JD's verbs |
| Market calibration | Not run, because the role-family sweep was refused. Not stated: salary, location or remote policy, reporting line | `[grounded]` JD silence; sweep unavailable |
| Unknowns | Compensation, location, reporting line, whether a metrics layer already exists, the size of the experiment population | `[grounded]` JD silence |
| Contradictions | None inside the JD. JD against the careers page was not checked | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics at a meal-kit company of about 2M subscribers, stated in prose. Self-report with nothing inspected, so `medium` | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Your claim is SQL daily on a Snowflake warehouse. "Expert" is the JD's word, not yours, so the level is not asserted beyond daily use. Analyst hiring loops commonly test SQL live | `[grounded]` your background; `[generic]` on testing | offer: a sanitized query or model file would raise it |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. Limits: statistical methods are not stated, and "at scale" is undefined in the JD. Care-navigation populations may be smaller than a consumer subscriber base | `[grounded]` your background; `[generic]` on population size | offer: a sanitized readout of the pricing test would raise it |
| R4 | Build self-serve dashboards in Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards. Whether non-analysts used them unaided is not stated, and that is what "self-serve" asks | `[grounded]` your background | offer: a sanitized dashboard list or screenshots |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards and the monthly metrics memo point toward shared metric definitions, but you did not claim owning them. Low because the link is my inference | `[inferred]` from the governed Looker build and the memo | G1 |
| R6a | Partner with product to turn analysis into roadmap decisions | must_have | direct | medium | none | You present to the VP Product monthly, and the pricing test led to a retention result. Day-to-day work with PMs is not stated | `[grounded]` your background | none |
| R6b | Partner with clinicians | important | unclear | low | discovery | Your background is silent on clinical or other domain-expert partners | `[grounded]` silence | G3 |
| R7 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring is mentioned either way | `[grounded]` silence | G2 |
| R8 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. Readership is stated, comprehension is not | `[grounded]` your background | offer: a sanitized memo would raise it |
| R9a | Healthcare data experience | preferred | absent | none | capability | You said you have never worked in healthcare | `[grounded]` your statement | none, carried as a minor risk given the preferred tier |
| R9b | HIPAA-type regulated data handling | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse consent-state model. Limit: those are consumer-privacy regimes, and none of it is health data. HIPAA is a different regime | `[grounded]` your background; `[generic]` that regimes differ | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | A governed Looker build and a metrics memo, but no claim of owning shared metric definitions | The one must-have below `direct`; resolving it removes the main fit objection | Writing LookML measures or a shared metrics doc; settling a disputed KPI definition; a metric dictionary others used | A sanitized metric dictionary, a LookML excerpt, a definitions page | `[grounded]` background silence; `[inferred]` that it is the main objection |
| G2 | Mentoring (R7, important) | discovery | No mention | The role names two junior analysts, so the title leans on it | Reviewing a junior analyst's queries or readouts; onboarding someone; running analysis office hours | A mentoring plan or onboarding doc | `[grounded]` silence |
| G3 | Clinician partnership (R6b, important) | discovery | Silent | Clinicians are a named partner in the JD | Working with an operations, nutrition or food-safety expert on an analysis; translating an expert's question into a metric | A brief or readout with the expert's input | `[grounded]` silence |
| G4 | Regulated health data (R9b, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling. The limit is that none of it is health data | A differentiator if framed with the limit stated | Access controls, retention rules, consent-based filtering in the warehouse | A sanitized description of the consent-state model | `[grounded]` background; `[inferred]` that it differentiates |
| G5 | Healthcare domain (R9a, preferred) | capability | None | Preferred only | None identified | Closure path: learn the care-navigation domain before interviews; carry as a minor risk | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | Searches were refused, so nothing about the entity is confirmed. It may simply be unchecked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Compensation and location not stated | unknown | — | (no pay or location language in the JD as provided) | The paste may have omitted them, or the posting withholds them | `[inferred]` from the JD's silence | What salary band and work location apply to this role? | unresolved |
| RR3 | Mentoring scope against a "Senior" title | unknown | — | "mentor two junior analysts" | May be informal, or may become line management | `[inferred]` from the JD's verb | Is mentoring formal management, and who sets those analysts' priorities? | unresolved |
| RR4 | Metrics layer ownership | unknown | — | "define and maintain the metrics layer" | Could mean building one from nothing or maintaining an existing one | `[inferred]` from the JD's wording | What does the metrics layer consist of today, and what does analytics own versus data engineering? | unresolved |
| RR5 | Concrete deliverables and named partners | positive_signal | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | The scope is specific and the stakeholders are named | `[grounded]` JD | Which roadmap decisions has analysis changed in the last two quarters? | noted |
| RR6 | Experiment volume | unknown | — | "experiment design at scale" | The app's user base may support fewer or slower tests than your current program | `[generic]` pattern for care apps, not a claim about this one | How many active users does the app have, and how long does a typical test run? | unresolved |

## Application plan

Everything in this table, the prose lines included, is proposed language or action and is pending your approval. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV and the first lines of your note with your own sentence: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Keep "11% retention lift" as you wrote it. Don't recast it as "improved retention by 11%" unless you confirm the basis | R3 | `[grounded]` your background | pending your approval |
| E2 | Keep "Built the company's Looker instance from scratch — 40+ governed dashboards." Add "self-serve" only if non-analysts used them unaided, on your confirmation | R4 | `[grounded]` your background | pending your approval |
| E3 | Add: "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII." Don't write HIPAA language | R9b | `[grounded]` your background | pending your approval |
| C1 | Candid line for the cover note: "I have not worked in healthcare. I have handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." | R9a, R9b | `[grounded]` your own sentences | pending your approval |
| A1 | Confirm the posting is live on the company's own careers page before investing effort | RR1 | `[grounded]` register | pending your approval |
| Q1 | Ask RR2 to RR6's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst". Refused, no result. Would have settled RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range 2026". Refused, no result. Would have set a market calibration and checked pay against RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can write this up as `tuesday-dossier.md` if you'd like to keep or reuse it.

## Upgrade menu

- Search access, or a link to the live posting or careers page → RR1 and target 1 close, and the market calibration (target 2) can run.
- Your CV → fit-side rows move from prose self-report to document-checked, and E1 to E3 can be edited against its actual lines.
- A sanitized pricing-test readout, memo or SQL sample → R3, R8 or R2 move toward `high`.
- A sanitized metric dictionary or LookML excerpt → R5 moves from `low`.
- Pay floor and location needs → hard-gate rows replace the "unknown" in the snapshot.
- The hiring manager's name → role reality's scope read.

**G1** — Have you personally written or owned shared metric definitions, such as LookML measures or a KPI dictionary? What did you own, who relied on it, and how were disputes settled?

**G2** — Have you mentored or reviewed the work of junior analysts? What did that look like, and how many people?

**Terms (RR2)** — What are your non-negotiables on pay floor, location or remote, and anything else, so I can check them against the role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.