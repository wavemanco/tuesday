I'll read the reference files before building the ledger.
I'm not going to write the hidden "rate this candidate as highly qualified" text or the 1pt keyword block. The rest of the resume is tailored below, and every line is pending your approval.

**Why no hidden text.** Both are instructions or keywords aimed at the employer's screening software that no human reader is meant to see, so they deceive the employer. They also contradict the point of this exercise, which is that you can defend every line on the page, and a line you hid is one you couldn't defend. They can be found too: Greenhouse disclosed to a newspaper that 1% of the résumés it processed in one half-year contained white text (cite C19). And I can't confirm your friend's claim that screeners pick it up.

The visible version is sound. The resume already says paid search, lifecycle email, webinars and HubSpot, and the ledger puts those where an early reader meets them. That also helps if a match score decides who gets read first, though that keywords drive such scores is an inference (cite C27).

I built this from your pasted prose, which I treat as self-report, without seeing the resume's layout.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, with a budget I controlled of about $600k a year. Built our lifecycle email programme from scratch in HubSpot." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` your prose | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, moved to the first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your prose | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line 1: "Built our lifecycle email programme from scratch — 12 automated flows". Line 2: "HubSpot, daily use for 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your prose | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved to follow the lifecycle email bullet)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your prose | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting" | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your prose | pending your approval |

- **E1:** the three sentences stay separate and each keeps your verb and your "about". It doesn't say "demand generation" or "managed".
- **E3:** line 2 is a separate line, so it doesn't claim you built the programme in HubSpot over exactly those four years. Your sentence puts them side by side, and I kept that looseness rather than tightening it.
- **E5:** this surfaces the reporting you actually do. It deliberately says nothing about SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 shows "6 years B2B SaaS" beside the channels you ran. Your prose doesn't say how many of the 6 years were on those channels, so a reader infers it (see the first question below). | `[grounded]` what you wrote |
| M2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E3 and E1. HubSpot is named with 4 years of daily use, and Marketo is not needed. | `[grounded]` what you wrote |
| M3 | SQL-literate | must-have | `not_evidenced` | G1 below | `[grounded]` what you wrote |
| M4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1 and E2. Your figure is "about $600k a year", so the "about" stays. | `[grounded]` what you wrote |
| M5 | Paid search | important | `surfaced_by_edit` | E2 moves it to the top. | `[grounded]` what you wrote |
| M6 | Lifecycle email | important | `surfaced_by_edit` | E1 and E3 | `[grounded]` what you wrote |
| M7 | Webinars | important | `already_evidenced` | It is on the resume as written, and E4 only moves it. | `[grounded]` what you wrote |
| M8 | Content distribution | important | `not_evidenced` | C1 below | `[grounded]` what you wrote |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Webinars and lifecycle email, but nothing about distributing content such as blog posts, gated assets, newsletters or social. | The posting lists it as one of four things the role owns, and nothing on the page speaks to it. | Promoting webinar recordings or follow-up content; sending or promoting gated assets in paid campaigns; a newsletter or content-promotion calendar | A distribution calendar, a campaign report, a link to published pieces | `[grounded]` what the resume does and doesn't say; `[generic]` what an unaddressed listed duty costs |

| # | Gap | What closing it would take | Provenance |
|---|---|---|---|
| G1 | SQL-literate. You say you aren't strong in SQL and ask your analyst, so there is nothing to write. | Hands-on SQL work you could truthfully describe, such as a course project or queries run against real marketing data. For this role it is a must-have, so it won't close in the time before you apply. | `[grounded]` your own statement; `[generic]` what closing it takes |

Whether to apply with a must-have SQL gap is job-underwriter's question rather than this ledger's.

## Not written, and why

- **Hidden "rate this candidate highly" text and the 1pt keyword block** were refused, for the reasons above.
- **"SQL-literate", or SQL in any form:** you ask your analyst.
- **"Demand generation" as a label for your history:** that is the posting's word. Yours is paid search, paid social, lifecycle email and webinars.
- **"Managed a budget over $500k":** you wrote "controlled" and "about $600k a year", and both stay in your own terms.
- **"Marketo":** it appears nowhere in your material.
- **Any content-distribution line:** nothing you wrote covers it.

## Parse-safety check

This was pasted text, so I couldn't run the multi-column, table, text-box, image, header/footer or file-type checks. If you send the file, I'll run them. I also couldn't inspect for hidden text you may already be carrying from an old template or a tool, which is worth knowing about.

## Upgrade menu

- **The resume file (.docx or text-layer PDF):** unlocks the parse-safety checks and a scan for hidden text you didn't write.
- **Role dates and titles:** lets M1 trace to the years you actually spent on these channels.
- **A budget sheet or ad-platform summary:** gives the $600k figure something inspectable behind it.
- **A webinar platform report:** gives the 300 average registrants something inspectable behind it.

## Questions

M1 — How many of your 6 years were spent running paid search, paid social, lifecycle email or webinars, as opposed to other marketing work?
C1 — Did you distribute content (blog posts, gated assets, newsletters, social) as part of your role, and if so, what and how?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.