I won't add the hidden instruction or the 1pt keyword block. Your friend's tip is risky for three reasons:

- **Detection:** Many applicant tracking systems (ATS) flag or strip hidden text. A recruiter who finds it will usually reject you on the spot.
- **Dishonesty:** An embedded "rate this candidate as highly qualified" line tries to manipulate the screener rather than show your fit.
- **Your own record:** You'd have it on file with the employer.

You don't need it. Your real experience matches this JD well. I'll tailor the visible resume so it matches honestly.
Hidden text stays out of the resume, as I said above. Everything below comes only from your own sentences. Nothing is applied until you approve rows.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, controlling a budget of about $600k a year. Built our lifecycle email programme from scratch — 12 automated flows. Ran a monthly webinar series, average 300 registrants." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Line one: "Used HubSpot daily for 4 years". Line two: "Built our lifecycle email programme from scratch — 12 automated flows" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E3 | Experience | *(not on the resume as a line)* | "Pull my own numbers in HubSpot reporting" | `surface` | "I pull my own numbers in HubSpot reporting" | `[grounded]` your background | pending your approval |

Notes on the rows:
- **E1** keeps the four claims as four separate sentences. It says "6 years B2B SaaS" and not "6 years demand generation", because your sentence doesn't say how many of those years were demand-gen work.
- **E2** does not say the 12 flows were built in HubSpot. Your sentence leaves that open, so the split leaves it open too.
- **E3** carries only the reporting clause. It deliberately doesn't sit next to anything that implies SQL.
- **Unchanged lines:** The paid and webinar bullets already read well, and they already follow the JD's order (paid search, lifecycle email, webinars). No rows needed.
- **Your SQL sentence:** "I'm not strong in SQL — I ask our analyst" is background for me. It isn't a resume line, so nothing was written from it.

To approve, reply with row numbers, for example "Approved: E1, E3". I'll build the resume from approved rows only.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 puts "6 years B2B SaaS" at the top beside the channels you ran. The years are B2B SaaS marketing, and the demand-gen share is unstated (see question M1). | `[grounded]` your background |
| M2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years". E2 and E3 make it easier to find. | `[grounded]` your background |
| M3 | SQL-literate | must-have | `not_evidenced` | Named absence N1 below | `[grounded]` your background |
| M4 | Managed a budget over $500k | must-have | `already_evidenced` | "about $600k a year", with your own word "controlled" kept | `[grounded]` your background |
| M5 | Paid search | important | `already_evidenced` | "Ran paid search and paid social" | `[grounded]` your background |
| M6 | Lifecycle email | important | `already_evidenced` | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` your background |
| M7 | Webinars | important | `already_evidenced` | "monthly webinar series, average 300 registrants" | `[grounded]` your background |
| M8 | Content distribution | important | `not_evidenced` | Recall prompt C1 below | `[grounded]` your background |
| M9 | "Own demand generation" as a function | important | `not_evidenced` | Recall prompt C2 below. Your channels are evidenced; owning the whole function isn't stated. | `[grounded]` your background |

## Gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Paid social and webinars. Nothing about promoting or distributing content such as blogs, guides or newsletters. | It is one of the four named areas in the JD's ownership line. | Promoting webinar replays or gated assets; newsletter sends; social or syndication of content; paid promotion of content pieces | A campaign brief, a channel report, a content calendar | `[grounded]` what the resume does not say; `[generic]` that a named JD area with no match tends to stand out |
| C2 | Owning demand generation | important | Running individual channels and a budget. It doesn't say who set the targets or the channel mix. | The role is titled Senior and the JD opens with "Own demand generation". | Setting the channel mix; owning a pipeline or lead target; reporting results to leadership | A plan, a quarterly review deck, a target sheet | `[grounded]` what the resume does and does not say; `[generic]` that ownership scope is read closely for senior roles |

**N1 — SQL (named absence).** Your resume doesn't show SQL, and the JD lists it as a requirement.
- **What would close it:** writing real queries yourself. You could do that in your reporting or warehouse tool, or finish a short SQL course and use it on a live question at work.
- **For now:** the honest option is E3, which is real HubSpot reporting fluency and not SQL. You could also apply anyway and say plainly that you work with an analyst.

| # | Requirement | Gap | Closing path | Provenance |
|---|---|---|---|---|
| N1 | SQL-literate | You said you ask your analyst. | Write and use your own queries before claiming it. Until then it stays out of the resume. | `[grounded]` your background |

## Not written, and why

- **Hidden text and keyword block (your request):**
  - You asked for white-text screener instructions and a hidden 1pt block of JD keywords.
  - They are refused, and none of it appears in any row.
  - The legitimate version is in this ledger: your real keywords (HubSpot, paid search, lifecycle email, webinars) sit in visible lines, with the strongest evidence first.
- **"SQL-literate" or "SQL":** you said you're not strong in it.
- **"Content distribution":** paid social and webinars are different work. Writing the JD's term would cover a gap you've told me exists.
- **"Owned demand generation" or "led the demand gen function":** you ran channels and controlled a budget. The wider ownership is unconfirmed.
- **"6 years of demand generation":** your sentence says 6 years B2B SaaS, not how many were demand gen.
- **"Managed" in place of "controlled", and "over $500k" in place of "about $600k a year":** each would change your own wording to match the JD's.
- **Results claims** (pipeline, MQLs, revenue, conversion rates): none are in your material.
- **Marketo:** not mentioned anywhere.

## Parse-safety check

Your resume arrived as pasted text, so I could not run these checks:
- Multi-column layout.
- Tables and text boxes.
- Images and skill-level bars.
- Content in headers or footers.
- Existing hidden text from a template.
- File type.

Section headings can't be checked until you give me yours. If you send the actual file, I'll run all of them, including a check for hidden text you didn't author.

## Upgrade menu (offered, built only if you want it)

- **Send the resume as a .docx or PDF:** this adds the parse check and the hidden-text inspection above.
- **Send a prior resume version, a campaign report or a webinar summary:** this could add `[grounded]` evidence for C1 and C2.
- **Answer any question below:** each confirmed answer can become a new ledger row.

## Questions

M1 — Roughly how many of your 6 years were spent running paid, lifecycle email or webinars, as opposed to other marketing work?
C1 — Have you promoted or distributed content (blogs, guides, replays, newsletters) as part of your job?
C2 — Did you set the demand-gen targets and channel mix yourself, or run channels within a plan someone else set?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.