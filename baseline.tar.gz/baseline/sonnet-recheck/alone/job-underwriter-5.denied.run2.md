I'll read the reference files the skill points to before building the assessment.
**Yes, it's worth applying to: `conditional_go`.** R1, R2, R3, R4, R6 and R7 are every `must_have` row, and all land `direct`. The pay is positioned in RR3. Apply once R10, R11 and RR1 clear, because your location, your pay floor and the live posting haven't been checked.

**Fit ledger.**

- `hard_gate`: unclear: R10 (Remote (US) or our Denver office), R11 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R1, R2, R3, R4, R6, R7
- `important`: adjacent: R5 (a dbt-modelled warehouse in BigQuery) · unclear: R8 (ingestion from our app and CRM), R9 (the data contracts our analysts depend on)

R5 is a bridge with its limit named (Snowflake, not BigQuery), and R8 and R9 wait on your answers.

**Opportunity ledger.** Pay and funding read well and team and scope detail is thin. The stated range is set against the supplied market band in RR3, and the Series C is a positive signal on the company's own account (RR6). The hiring manager, team and equity are unknown (RR2, RR4), scope and on-call are unspecified (RR5, RR7), and the posting and employer have not been independently verified (RR1).

- **Hard gates:** none failed; unconfirmed: R10 (Remote (US) or our Denver office), R11 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R10: you are US-based or can work from Denver; (2) R11: the range clears your minimum base; (3) RR1: the posting is confirmed live and the employer checks out before you invest in a tailored application.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company page as you copied it at 09:10; not independently verified (RR1) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD as you copied it at 09:12 |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; equity terms not stated | `[grounded]` JD |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silent |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years; typical scope is one domain's pipelines, no direct reports. This is a role-family band, not Pellucid's offer | `[generic]` Datawright 2026 Data Engineering Pay Report (US, n=2,310), supplied by your recruiter |
| Level read | The posting's 5+ years sits at the low end of the report's 5–8 year "senior" band, and your 6 years falls inside it. A Series C company fits the report's B–D sample | `[inferred]` JD and your stated years against the report's figures |
| Scope read | Ingestion, warehouse modelling and contracts together may be wider than the report's "one domain's pipelines". No direct reports are mentioned | `[inferred]` JD scope against the report's typical scope |
| Unknowns | Hiring manager and reporting line; team size; equity terms; on-call; new role or backfill; how the company defines "data contracts" in practice | `[grounded]` JD and your message are silent on each |
| Contradictions | None between the JD and the about page as copied. The live posting was not re-checked (see Evidence status) | `[grounded]` both pastes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. That clears the floor. Medium because this is prose intake and no CV has been seen | `[grounded]` your message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is specific on use. Depth ("strong") is what a technical screen will probe, and nothing inspectable has been seen | `[grounded]` your message | none |
| R3 | dbt | must_have | direct | medium | none | "Built our dbt project on Snowflake — about 180 models." Confirmed and specific. Which parts were yours versus the team's isn't stated, so be ready to say it plainly | `[grounded]` your message | a sanitized lineage graph or the dbt docs model list would raise this to high |
| R4 | A cloud warehouse | must_have | direct | medium | none | The requirement list says "a cloud warehouse", and Snowflake is one. BigQuery is named in the role description, so it has its own row (R5) | `[grounded]` JD wording and your Snowflake statement | none |
| R5 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Carries over: dbt modelling and SQL on a cloud warehouse. Limit: you have never used BigQuery, so there is no firsthand experience of its table design or cost model. Medium because the adjacency rests on your Snowflake statement | `[grounded]` your statement of no BigQuery; `[generic]` that warehouses differ in dialect and cost model | state "Snowflake, not BigQuery" up front (see P1) |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | "Airflow for orchestration" matches the named tool | `[grounded]` your message | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | "I set up our Great Expectations test suite." Confirmed and specific, with no inspectable artifact yet | `[grounded]` your message | a sanitized expectation list or suite config would raise this to high |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | You describe Airflow pipelines but not which sources you ingested. A thread exists, but nothing is confirmed | `[grounded]` your message is silent on sources | see G1 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | A test suite is adjacent to contracts, which are agreed guarantees between producers and consumers. Whether you set any is unstated | `[grounded]` your message is silent; `[generic]` that tests and contracts are different practices | see G2 |
| R10 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting states the terms and you haven't said where you are based. No candidate statement exists to grade | `[grounded]` JD; no constraint stated by you | see G4 |
| R11 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so whether the range meets it is unknown | `[grounded]` JD; no constraint stated by you | see G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8, important) | discovery | Airflow pipelines are confirmed, but the source systems are not | The role is named for these two sources | Pulling product event data or an app database into the warehouse; syncing a CRM such as Salesforce or HubSpot; handling API limits or schema drift | A sanitized DAG, an ingestion config, or a source inventory | `[grounded]` your message silent on sources; `[inferred]` that this is the closest gap to a direct match |
| G2 | Data contracts (R9, important) | discovery | The Great Expectations suite is confirmed, but not any agreement with data consumers | It is named as a deliverable the analysts depend on | Agreeing schema, freshness or ownership terms with the analysts or product teams; contract-style checks on a source feed | A contract doc, a README, a schema-change process, or suite configs showing producer-side checks | `[grounded]` your message silent; `[generic]` that "data contracts" is applied inconsistently across employers |
| G3 | BigQuery (R5, important) | transferability | Strong dbt and Snowflake; no BigQuery | Likely to be raised in a technical screen | A personal or sandbox BigQuery project; migrating or porting a model between warehouses | A short written note or small dbt project run on BigQuery | `[grounded]` your statement; `[generic]` that screens probe stack-specific gaps |
| G4 | Location (R10, hard_gate) | hard_gate | Terms stated by the JD, nothing stated by you | A mismatch would end the application | Not an experience question | Your own confirmation | `[grounded]` JD and your message |
| G5 | Pay floor (R11, hard_gate) | hard_gate | Range stated, floor not given | A mismatch would end the application | Not an experience question | Your own confirmation | `[grounded]` JD and your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not independently verified | unknown | — | "Accepting applications" (your note on the posting) | All employer facts come from the company's own pages as you copied them, so nothing outside the company corroborates them | `[grounded]` search and fetch were refused this session (see Evidence status) | Can you confirm this role is open, and which team it sits in? | unresolved |
| RR2 | Hiring manager, reporting line and team size absent | unknown | — | "The posting names no hiring manager" | The reporting line and the team's size and shape are unknown | `[grounded]` your note; the JD is silent | Who would I report to, and how many data engineers and analysts are on the team? | unresolved |
| RR3 | Stated range against the supplied market band | positive_signal | — | "$148,000–$166,000 plus equity" | The low end is $3,000 below the report median of $151,000, the midpoint of $157,000 sits inside the interquartile range, and the top is $2,500 above its $163,500 upper bound. Pay is not a mismatch at this seniority | `[grounded]` JD range and report figures; `[inferred]` comparison, assuming the posted figure is base | Where in the range would someone with my background land? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Value could be material or negligible; no grant size, vesting or strike is given | `[grounded]` JD silent on terms | What is the equity grant size, vesting schedule and strike price for this level? | unresolved |
| RR5 | Broad mandate with no stated outcomes | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting: ingestion ... a dbt-modelled warehouse ... and the data contracts" | One role may own ingestion, modelling and contracts with no stated definition of success | `[inferred]` JD scope against the report's one-domain norm; the JD gives no first-year outcomes | What would success look like at 12 months, and which of ingestion, modelling and contracts does this role own? | unresolved |
| RR6 | Recent funding | positive_signal | — | "Series C ($52M, February 2026)" | Headcount is plausibly funded. The figure comes from the company's own page and is unverified | `[grounded]` about page as copied; funding not independently checked | Is this role new headcount from the round, or a backfill? | noted |
| RR7 | Operational ownership of "run" unspecified | unknown | — | "Build and run the pipelines" | "Run" may include on-call or incident duty | `[inferred]` from the verb "run" | Is there an on-call rotation for pipelines, and how are incidents handled? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | If your CV doesn't already lead with them, bring forward, in your own words, the dbt project on Snowflake (about 180 models), Airflow orchestration, and the Great Expectations suite you set up. No CV has been seen, so there is no wording to compare against | see R3, R6, R7 | `[grounded]` your message | resume_edits_pending_approval |
| P1 | State "Snowflake, not BigQuery" in the application itself, and let the dbt and SQL work carry the bridge. Don't present warehouse experience beyond Snowflake | see R5 | `[grounded]` your statement | pending your approval |
| Q1 | Ask RR2, RR4, RR5 and RR7 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Open the careers page yourself and confirm it still shows "Accepting applications" before tailoring anything | see RR1 | `[grounded]` your note from 09:12 | pending your approval |

Every row above, including the positioning advice in E1 and P1, is proposed. Nothing is final until you approve it.

## Evidence status

Verified: none yet. Your background is prose intake, which is CV-equivalent and capped at `medium`. No memory leads were used.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring K-12 Denver Series C" and fetched pellucidlearning.com/careers/senior-data-engineer; both calls were refused for lack of permission. It would have moved role reality's contradictions row and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you supplied fixes the market calibration row and the pay comparison (RR3) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you'd like this saved for later, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your CV or a profile link → E1 becomes concrete wording, and any presentation gaps in R1–R4, R6 and R7 get found.
- A sanitized dbt lineage graph or model list, or the Great Expectations expectation list or suite config → R3 and R7 toward `high`.
- Answers on location and pay floor → R10 and R11 resolve to `direct` or `hard_gate_fail`.
- A sanitized DAG, ingestion config or contract document → G1 and G2 resolve, and R8 and R9 move.
- Search access → target 1 reruns and RR1 can close. With it, a deeper pass on funding, leadership churn and employee reports (up to 5 more searches and 2 more fetches) is available on your word.

## Questions

G4 — Are you based in the US, or willing to work from Denver?

G5 — Does the $148,000–$166,000 range clear your minimum base?

G2 — Have you set down, with the people who consumed your data, what a table or feed guaranteed, such as schema, freshness or ownership? What did you own in that?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.