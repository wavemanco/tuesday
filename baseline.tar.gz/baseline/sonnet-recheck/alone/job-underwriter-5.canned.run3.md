I'll read the reference files the workflow requires before building the assessment.
## Decision snapshot

**Yes, Ines, this is worth applying to, as long as R1 and R2 check out on your side. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery as the warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R3, R4, R5, R6 and R7 are the `must_have` rows and all sit at `direct`. The open items are R8, R9 and R10, plus the two gates R1 and R2.

**Opportunity ledger.** The posting is live, consistent with the company's own pages, and states its stack and pay (RR3, RR6). It leaves the team and scope, the equity and the first-year outcomes unspecified (RR1, RR2, RR5), and the funding and headcount figures rest on the company's own pages (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is met: you can work from a US location or the Denver office, with US work authorization; (2) R2 clears your pay floor; (3) RR1 and RR5 are answered concretely in the interview loop; (4) R8 is framed as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched via search; first-party only |
| Posting status | Live, "Accepting applications", text identical to what you pasted | `[grounded]` careers page fetched |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting, covering ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Requirements bar | 5+ years data engineering, SQL and Python, dbt and a cloud warehouse, Airflow or similar, data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity (no grant details) | `[grounded]` JD |
| Location | Remote (US) or Denver office | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | Reads as ownership of reporting pipelines in one platform, with no reports mentioned. Whether it is a solo function or an existing team is not stated (RR1) | `[inferred]` from the mandate wording against the JD's silence on team |
| Market calibration | A 5+ year bar sits inside the 5–8 years "Senior" typically means at Series B–D companies. Scope here matches the typical single-domain, no-direct-reports remit. The posted range runs from $3,000 below the $151,000 median to $2,500 above the $163,500 upper quartile. Basis: your recruiter's Datawright 2026 report (US, n=2,310). This is a band, not this employer's offer | `[generic]` role-family norms from the report; `[grounded]` the posted figures |
| Unknowns | Hiring manager, team size, equity terms, success metrics | `[grounded]` posting names no manager and is silent on the rest |
| Contradictions | None between your paste, the careers page and the About page | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | The JD's term is clear, but your location and US work authorization were not given, so whether you meet it is not established. Confidence is `none` because there is no constraint statement to grade yet | `[grounded]` JD term; candidate constraints absent | Gate question in the closing block |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor was not given, so I can't say whether it clears. Equity terms are unstated (RR2) | `[grounded]` JD figure; floor absent | Gate question in the closing block |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years of data engineering at a B2B payroll company. That is above the bar, but it is self-report with nothing inspectable yet | `[grounded]` your intake statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You stated daily use of both. "Strong" will be probed by exercise, so expect a technical screen | `[grounded]` your intake statement; `[generic]` that technical screens usually test this | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Snowflake is the cloud warehouse. The BigQuery difference is carried in R8 | `[grounded]` your intake statement | Offer: a dbt docs site or sanitized lineage screenshot would raise it to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You stated Airflow orchestration. Your scope of ownership (DAGs you wrote versus ran) is not specified | `[grounded]` your intake statement | Offer: a sanitized DAG listing would raise it |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is a specific ownership claim. Suite size and what it caught are unstated | `[grounded]` your intake statement | Offer: Great Expectations data docs or a sanitized suite listing would raise it |
| R8 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Your Snowflake and dbt work carries over directly. The limit: you have not used BigQuery, and its partitioning, clustering and cost model differ from Snowflake's. The JD's requirement line says "a cloud warehouse", so BigQuery is named in the mandate, not the requirements | `[grounded]` your statement and the JD wording; `[generic]` that warehouse-specific tuning differs | See G3 |
| R9 | Ingestion from our app and CRM | important | unclear | none | discovery | Your intake doesn't say what source systems your pipelines ingested from. I won't infer that from "six years of data engineering" | `[grounded]` intake silent | See G1 |
| R10 | Data contracts our analysts depend on | important | unclear | none | discovery | Great Expectations testing (R7) is adjacent, but it is not the same as agreed contracts with downstream consumers. Whether you had any is not stated | `[grounded]` intake silent on contracts | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | The payroll-company work is established, but not which source systems fed your pipelines | The mandate leads with ingestion from the app and CRM, so a match here sharpens the positioning | Pulling product or event data from an application database or API; syncing a CRM such as Salesforce or HubSpot; payroll-system feeds you landed in the warehouse | A sanitized pipeline diagram, a DAG listing, or an ingestion-source inventory | `[grounded]` intake silent; `[inferred]` that ingestion is central, from the JD's mandate order |
| G2 | Data contracts (R10, important) | discovery | Testing is established (R7), but not agreements with consumers | The JD names contracts as the thing analysts depend on, so this is where an interviewer is likely to probe | Schema or freshness guarantees agreed with analysts; SLAs on a model; breaking-change notice or versioning rules; Great Expectations checks tied to a consumer's needs | A contract doc, a README for a model, or an SLA note | `[grounded]` intake silent; `[generic]` that contracts are probed as an ownership topic |
| G3 | BigQuery (R8, important) | transferability | Adjacent evidence: Snowflake and dbt at scale. Limit: no BigQuery use | It's named in the mandate, and the likeliest objection is "can she be productive here quickly" | A personal BigQuery sandbox project running dbt models on a public dataset | A small public repo with dbt models on BigQuery | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and scope unspecified | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be one domain on an existing team or a one-person data function. The report's typical scope is one domain with no reports | `[inferred]` from the JD's silence on team; `[generic]` for the typical scope | Is this role joining an existing data team, who would I report to, and which domain's pipelines would I own? | unresolved |
| RR2 | Equity unspecified | unknown | — | "plus equity" | Equity could be material or nominal, and the posting doesn't say | `[grounded]` JD gives no terms | What is the equity grant for this level: instrument, size, vesting and strike price? | unresolved |
| RR3 | Pay against market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range sits at or above the report's median and reaches past its upper quartile for Series B–D, so there is no seniority-pay mismatch | `[grounded]` JD range and the Datawright 2026 figures; `[generic]` that this is a band, not an offer | Where in the $148,000–$166,000 range would an offer for my experience land? | noted |
| RR4 | Funding and headcount rest on the company's own pages | unknown | — | "Series C ($52M, February 2026)" | The figures come only from Pellucid's own About page, and I have not checked anything independent. That is not a sign of a problem | `[grounded]` first-party page only; `[generic]` that self-reported figures stay unconfirmed until checked | How has the data team's headcount changed since the February funding round? | unresolved |
| RR5 | First-year outcomes unstated | unknown | — | "the data contracts our analysts depend on" | The posting lists duties but not what success looks like at 12 months | `[grounded]` JD names no outcomes | What would a successful first year in this role have delivered? | unresolved |
| RR6 | Concrete stack and salary stated | positive_signal | — | "a dbt-modelled warehouse in BigQuery" | The posting names its tools and pay up front, which reads as a defined role | `[grounded]` JD | What is on the roadmap for the BigQuery warehouse in the first six months? | noted |

## Application plan

Everything in this plan, the table and the positioning advice in it, is pending your approval. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle R1 and R2 for yourself before spending effort on the application | see R1, R2 | `[grounded]` map rows | pending your approval |
| E1 | Lead with your dbt project on Snowflake (about 180 models), the Great Expectations suite you set up, and your Airflow orchestration, in that order, since they map to the JD's dbt, data quality and orchestration lines. Share your CV and I'll propose bullet edits traced to your own words | see R5, R6, R7 | `[grounded]` your intake statements | pending your approval; `resume_edits_pending_approval` |
| E2 | Name the BigQuery gap plainly: "my warehouse work is on Snowflake; I have not used BigQuery" | see R8 | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery sandbox project as a work sample | see R8, G3 | `[inferred]` bridge | pending your approval |
| Q1 | Ask RR1, RR2, RR4 and RR5's questions verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. There are no unverified leads from earlier context.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Moved: the organization, posting status and contradictions rows in role reality, and RR4 |
| 2. Role-family sweep | skipped | The Datawright report you supplied already fixes the market calibration line and RR3, so a search could change nothing |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

If you'd like, I can write this up as a `tuesday-dossier.md` to keep or carry into later work.

## Upgrade menu

- Your pay floor, location and work authorization → R1 and R2 resolve, and the hard-gates line closes.
- Your CV file → presentation gaps checked, and edit proposals traced to your own words.
- A sanitized dbt docs site, DAG listing or Great Expectations data docs → R5, R6 and R7 can rise to `high`.
- Answers to G1 and G2 → R9 and R10 resolve, and the positioning sharpens.
- A hiring manager's name → target 3 runs, and the scope read and positioning get more specific.
- A deeper research pass on Pellucid Learning (funding and leadership changes, hiring patterns, public employee and candidate reports, recent news; up to 5 more searches and 2 more fetches) → RR4 moves from the company's own claims to something independent. Say the word and it runs.

R1 — Are you based in the US, or willing to work from the Denver office, and authorized to work for a US employer without sponsorship?

R2 — Does $148,000–$166,000 plus equity clear your pay floor?

G1, G2 — What source systems did your pipelines ingest from, and did you have any formal agreement with the analysts who consumed them, such as schema guarantees, SLAs or freshness checks?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.