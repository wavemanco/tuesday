I've read the posting and run three searches (company, pay band, hiring manager). Before I write the assessment, I'm checking the wording rules for any CV lines I propose.
## Decision snapshot

**Yes, worth applying to, on conditions. R6 (owning a forecast) and R8 (billing data) are the real stretches, and R1 and R2 are not yet confirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay)
- `must_have`: direct: R3, R4, R5a · adjacent: R6 (owning a forecast), R7 (finance on billing or revenue data) · unclear: R5b (spreadsheet modelling)
- `important`: direct: R9 · absent: R8 (own billing data)

R6 and R8 are the two things you told me you haven't done, and R7 turns on an answer I don't have yet.

**Opportunity ledger.** The employer exists as described (RR1) and the pay is stated, near the market median (RR2). The open points are how the role sits beside a Head of Revenue Operations (RR3), a four-part scope with no stated team (RR4), no stated success measures (RR5) and an unknown CRM and billing stack (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (£61,500–£67,000 pay); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm Bristol with two office days and the pay range work for you (R1, R2).
  2. The reporting-line answer in RR3 shows the forecast really sits with this role.
  3. R6 is framed as adjacent and R8 as new to you, never as experience you have.
- **What would change this:** if R1 or R2 fails for you, the status becomes `no_go` on that gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about, fetched |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, hybrid, two office days; £61,500–£67,000 plus share options | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, named by the recruiter per you. Her public profile reads Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` your message; `[grounded]` profile page fetched |
| Scope read | Four areas in one post (CRM data, billing data, reporting, forecast) with no team or reports stated, under a manager whose title is Head of Revenue Operations | `[inferred]` from the JD's silence on team and the profile title |
| First 90 days and first year | Not stated | `[grounded]` JD silent |
| Market calibration | UK B2B software revenue operations lead: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posted range sits inside that range, close to the median. The band is UK-wide, not Bristol-specific, and is not Quillfield's offer. Scope norms for the title were not found | `[generic]` Ledgerline 2026 pay guide (search result); `[grounded]` JD figure |
| Unknowns | Which CRM and billing system they run; team size; who owns the forecast today; share option terms; your location and pay floor | `[grounded]` JD silence; your message |
| Contradictions | None between the JD and the company page on city. Quillfield's own careers page for this role did not come up, so I have seen the listing on the job board only | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days | hard_gate | unclear | none | hard_gate | You gave no location or office-day constraint, so there is no statement of yours to grade | `[grounded]` JD; intake silent | Q1 |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | You gave no pay floor. The range sits inside the market band in role reality, but the floor decides whether the gate is met | `[grounded]` JD; `[generic]` band | Q1 |
| R3 | 4+ years in revenue operations, sales operations or similar analytics at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team, on your own account. Limit: the employer is a B2B payments company, and whether that reads as B2B software is the reader's call | `[grounded]` your intake, self-reported | none; the CV line (E1) says what the company is |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. The JD accepts either CRM; which one Quillfield runs is unknown (RR6) | `[grounded]` your intake | A credential ID or link would raise it to high |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly shows regular use. "Strong" is not evidenced beyond that, so I take the lower reading | `[grounded]` your intake | A sanitized query would raise it to high |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily is use, not modelling. No model you built has been described | `[grounded]` your intake | G5; a model you built, if one exists |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director and rebuilt the pipeline dashboards. Limit: you said finance owned the company forecast, so ownership is not shown | `[grounded]` your intake | G2 |
| R7 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | The renewal dashboards touch revenue data, but nothing says finance was involved. You have not worked on billing data, but the JD says "billing or revenue" | `[grounded]` your intake and the JD wording | G3 |
| R8 | Own billing data (JD: "own our CRM and billing data") | important | absent | none | capability | You confirmed you have never worked on billing data, and no adjacent work has been described | `[grounded]` your statement | G4 |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is unknown (R7) | `[grounded]` your intake | A sanitized dashboard screenshot would raise it to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Office days and pay fit (R1, R2, hard_gate) | hard_gate | No constraints given from you | An unmet gate ends the case whatever else fits | none; a yes or no settles it | none needed | `[grounded]` intake silence |
| G2 | Owning a forecast (R6, must_have) | transferability | A pipeline review and dashboards, but finance owned the forecast | R6 is a `must_have` at `adjacent`. The posting names the CFO forecast in its mandate | Producing the UK team's forecast or commit number that someone else rolled up; a forecast-versus-actual review; a quarterly number you defended | A sanitized forecast submission or forecast-versus-actual extract | `[grounded]` intake; `[inferred]` that this is the likeliest objection, from the JD's mandate line |
| G3 | Finance on revenue data (R7, must_have) | discovery | Renewal dashboards, no finance link stated | R7 sits at `adjacent` with `low` confidence; an answer could move it either way | Renewal figures agreed with finance; a quarter-end reconciliation of renewals or bookings; finance requesting your pipeline numbers | A sanitized dashboard or reconciliation sheet | `[grounded]` intake silence |
| G4 | Billing data (R8, important) | capability | No billing data experience, confirmed by you | The JD says you would own it. No wording closes that | none stated | Closure path: say so plainly and show a learning plan; work sample W1 below | `[grounded]` your statement |
| G5 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel use, no model described | R5b is a `must_have` at `unclear` | A renewal-value model, scenario sheet or quota model | A sanitized workbook | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer exists as described | positive_signal | — | "Quillfield, the invoicing software company" | The company is real and matches the posting on city and product | `[grounded]` company page fetched | How large is the revenue operations team today, and how is it structured? | noted |
| RR2 | Pay stated, in market range | positive_signal | — | "£61,500–£67,000 plus share options" | The range shows no seniority-pay mismatch against the guide's band. The option value is unstated | `[grounded]` JD figure; `[generic]` band | What are the option terms: vesting and typical grant at this level? | unresolved |
| RR3 | Role beside a Head of Revenue Operations | unknown | — | "run the quarterly revenue forecast with the CFO" | A Lead with forecast ownership may overlap with or report into the Head's remit | `[inferred]` from the profile title against the JD's ownership language | Where does this role sit relative to the Head of Revenue Operations, and who owns the forecast submission today? | unresolved |
| RR4 | Four-part scope, no team stated | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… run the quarterly revenue forecast" | Several specialisms may be bundled into one title with no analyst support | `[inferred]` from the four areas against the JD's silence on reports | Does the role have direct reports or analyst support, and which area is heaviest in the first six months? | unresolved |
| RR5 | No success measures stated | unknown | — | JD silent | The first-year outcomes are not defined in the posting | `[grounded]` JD silence | What does success look like at 90 days and at one year? | unresolved |
| RR6 | CRM and billing stack unknown | unknown | — | "HubSpot or Salesforce administration" | They may run HubSpot, where your Salesforce certification does not transfer directly. The billing system is unnamed | `[inferred]` from the JD's either-or wording | Which CRM and which billing system do you run today? | unresolved |

## Application plan

Every row is proposed and nothing is applied. CV rows are marked `resume_edits_pending_approval` and the rest are `pending your approval`. Each CV line was checked clause by clause against your own sentences, and the forecast and billing claims are left out on purpose.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Ran revenue operations for the UK team for the last 2 of 5 years in sales operations at a B2B payments company; Salesforce admin certified." | R3, R4 | `[grounded]` your intake | resume_edits_pending_approval |
| E2 | CV line: "Rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director." | R6, R9 | `[grounded]` your intake | resume_edits_pending_approval |
| P1 | Lead with the dashboard rebuild and the monthly review, since the JD names pipeline and renewal reporting. Say in your own words that finance owned the forecast and that billing data is new to you | R6, R8, R9 | `[grounded]` JD and your statements | pending your approval |
| Q1 | Ask the verification questions of RR3, RR4, RR5 and RR6 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the two gates (R1, R2) with the recruiter before investing in the application | Cheapest way to rule the role out | `[grounded]` R1, R2 | pending your approval |
| W1 | Optional work sample: a one-page note on how you would check renewal figures against billing data, written as a plan and not as past experience | G4 | `[grounded]` G4 | pending your approval |

## Evidence status

Verified: none yet. No unverified leads from memory. No rejected inferences.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol careers"; fetched "About Quillfield" (quillfield.co.uk/about). It confirmed the company exists as described, so no failed-attribution entry. Quillfield's own careers page for this role did not come up |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example). It moved the market calibration and RR2. It returned no scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; fetched "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). It moved the scope read, RR3 and P1 |

I can also write this up as `tuesday-dossier.md` if you want a file to keep or reuse. Say so and I'll build it.

## Upgrade menu

- Your Salesforce credential ID or link raises R4 to `high`.
- Sanitized dashboard screenshots raise R9, and support R3.
- A sanitized SQL query raises R5a to `high`.
- A forecast or forecast-versus-actual extract, or a sanitized workbook, settles R6 and R5b.
- A sanitized reconciliation sheet or dashboard shows whether R7 holds.
- Your pay floor, location and office-day limits close R1 and R2 and may change the status.
- A deeper research pass on Quillfield (funding follow-up, leadership changes, public staff reports, recent news; up to 5 more searches and 2 more fetches) runs if you say the word.

**Questions**

Q1 — G1 (R1, R2): Is a Bristol office two days a week workable for you, and does £61,500–£67,000 sit at or above your pay floor?

Q2 — G2 (R6): In your UK revenue operations role, did you produce any forecast or commit number that finance or the sales director rolled into a larger forecast? If so, what was yours to decide and what was someone else's?

Q3 — G3 (R7): When you rebuilt the renewal dashboards, did you work with anyone in finance on the numbers? Who, and were the figures agreed or reconciled with finance's own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.