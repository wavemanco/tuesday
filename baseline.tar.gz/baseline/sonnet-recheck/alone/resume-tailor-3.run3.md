I've tailored your CV for the Quartzline role. Nothing is applied yet; every row below waits on your approval.

- **What I built from:** your message, treated as self-report, plus the dossier's `role_profile`, `evidence_map`, `resume_edits_pending_approval` and `rejected_inferences`. I haven't seen your actual CV layout, so each "Current line" is your own sentence from this conversation rather than the bullet as it sits on the page.
- **The dossier:** it names this same role, so I used all of it. Its `conditional_go` is the underwriter's call, and I acted on none of it. Its adjacent/medium ratings carry over unchanged into the coverage map.
- **The edits:** all of them are reorders or surfacings of sentences you already wrote. None adds a claim. E1 comes from the dossier and went through the same audit as the rest.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (placement not seen) | "Wrote the internal integration playbook the whole team uses." as its own line | `surface` | "Wrote the internal integration playbook the whole team uses."; dossier E1: "surface the integration playbook authorship into its own line" | `[grounded]` your CV, dossier | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged — moved to the first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged — moved directly after the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "Comfortable in Postman, SQL, OpenAPI specs." (placement not seen) | "Comfortable in Postman, SQL, OpenAPI specs." as its own line, wording unchanged | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead at an enterprise software vendor, 7 years. Led 30+ client integrations of our REST APIs end to end. Wrote the internal integration playbook the whole team uses." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses." | `[grounded]` your CV | pending your approval |

- **E3:** the line stays exactly as you wrote it. "Collecting client feedback" has not become "drove the roadmap", and "clients" has not become "partners".
- **E4:** "Comfortable in" is kept. Dropping it would turn a tool you're comfortable in into a skill you've demonstrated.
- **E5:** it stays three separate sentences. "Never held a PM title" means no sentence in it says or implies PM.
- **Title:** your job title is unchanged. No row retitles it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | The dossier rates this adjacent (transferability, medium): integration leadership is adjacent, but roadmap ownership and prioritisation authority are not evidenced. E1, E2 and E3 show the adjacent work. Closing path in C1. | `[grounded]` dossier evidence_map R1; your "Never held a PM title." |
| 2 | Shipped API or platform products | must-have | `not_evidenced` | The dossier rates this adjacent (medium). E2 shows leading integrations of your vendor's REST APIs, which is not shipping an API product. Closing path in C2. | `[grounded]` dossier evidence_map R2 |
| 3 | Technical fluency | important | `surfaced_by_edit` | E4 and E2 | `[grounded]` your CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 show client-facing work only. Nothing in your material covers internal stakeholders or engineering squads. | `[grounded]` your CV |
| 5 | Write specs and drive delivery with two engineering squads (a JD responsibility) | important | `not_evidenced` | E4 shows you're comfortable in OpenAPI specs, not that you wrote specs or drove delivery. Closing path in C3. | `[grounded]` your CV |
| 6 | Define adoption metrics (a JD responsibility) | important | `not_evidenced` | Named absence, see below. | `[grounded]` your CV |

**Named absence, adoption metrics:** your material mentions no measure you defined or tracked. Closing it would take a real measure from your integration work that you can show, such as a go-live tracker or time-to-live figures. Without one, it stays a gap you should be ready to name in an interview.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM (roadmap ownership, prioritisation) | must-have | You ran roadmap-input sessions collecting client feedback for product. It does not say what happened to the feedback or who decided. | This is the one requirement the posting makes a must-have, and the dossier already flags prioritisation authority as unevidenced. | Being in the room when product ranked items; making a written recommendation product acted on; carrying a client request through to a release | Session notes, a recommendation doc, a release note naming the item | `[grounded]` what your line says and omits; `[generic]` what must-haves cost on applications of this kind |
| C2 | Shipped API or platform products | must-have | You led integrations of your vendor's REST APIs. It does not say you shipped anything that clients or partners consumed. | The dossier rates this adjacent, so this is the next-closest gap to the PM years. | A connector, sample code, an SDK, a spec or doc set you produced that went out to more than one client | A repo, a published doc page, release notes | `[grounded]` your line; `[generic]` what an adjacent rating costs |
| C3 | Specs, delivery with engineers, and measures | important | You are comfortable in OpenAPI specs. No authored spec, engineering working relationship or measure is stated. | The role has you working with two engineering squads and defining adoption metrics. | A spec or ticket you wrote that engineering built from; a measure you tracked that product or engineering used | The spec itself, a dashboard, a tracker | `[grounded]` your line; `[generic]` role-family pattern |

## Not written, and why

- **From the dossier's rejected inferences**
  - "built an internal request-triage tool — memory lead, candidate could not confirm ownership." It stays out and is not re-derived under other wording.
  - "has been the customer of a partner API platform — candidate worked vendor-side." You stood on the vendor side, so I wrote no "partner's-eye view" line.
- **"Product management experience" or "3+ years as a PM":** you never held the title, and the JD makes this a must-have. The adjacent work is in E1 to E3, and the gap is in the coverage map.
- **"Owned the roadmap" or "drove roadmap priorities":** you ran sessions that collected feedback for product. Ownership and prioritisation authority are not in your material.
- **"Shipped an API product" or "API platform experience":** you led integrations of your vendor's REST APIs. That is a different kind of work from shipping an API product.
- **"Partnered with integration partners" or "ran partner discovery":** your word is "client". The JD's word "partner" would change who sat across from you.
- **"Wrote API specs":** your line says "Comfortable in … OpenAPI specs", which is a tool you're comfortable in, not authorship.
- **"Worked with or led engineering squads" and "defined adoption metrics":** nothing in your material supports either.

## Parse-safety check

Your CV arrived as pasted prose, not a file, so I could not run any of these checks:

- multi-column layout
- tables and text boxes
- images and skill bars
- headers and footers
- section headings
- file type
- hidden text carried over from a template

If you send the actual file I can run them.

## Upgrade menu

These are offers, built only if you say yes:

- **Your actual CV file.** It would replace my "Current line" stand-ins with your real bullets and let the parse check run.
- **The playbook's table of contents, or notes from one roadmap-input session.** Either would give C1 something inspectable.
- **An OpenAPI spec or integration doc you wrote.** It would give C2 and C3 an artifact.

## Questions

C1 — After a roadmap-input session, what did you personally do with the feedback, and did you have any say in what product prioritised?
C2 — Did you produce anything out of your integration work that shipped to clients beyond a single engagement, such as a connector, sample, spec or doc set?
C3 — Have you written a spec, or tracked a measure of how integrations went, that engineering or product used?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.