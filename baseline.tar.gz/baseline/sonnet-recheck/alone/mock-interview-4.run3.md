I'll read the skill's reference files before building the pack.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-4-denied-58b2bf80/878d5043-e0dd-409a-9eae-4226d0f9700d/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It has 22 questions across seven interviewer styles, built for a 45-minute hiring-manager conversation.

- **Most important prep:** question A1, the objection your dossier named: "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" The guidance has four steps:
  1. Concede the gap plainly.
  2. Make the adjacent case using only your confirmed evidence.
  3. Name the limit on the roadmap-input sessions before the interviewer finds it.
  4. Give a ramp plan.
  It also covers three follow-ups and keeps to the dossier's "adjacent, never PM experience" condition.
- **Gaps the dossier didn't flag:** it doesn't list R2 (shipped API or platform products, a must-have) or R3 (API docs and schemas) as weak areas, but your evidence only touches both. The pack treats them as likely probes (A3, D2), with slots for you to answer from what actually happened.
- **No Quartzline research:** the three web searches I tried were refused, so the pack has no company values, interview process or strategy. That means no company-strategy questions. The persona weights rest on the hiring-manager round type and your dossier.
- **Dropped sections:** the pack leaves out an interviewer read (no name was given), a prep schedule (no prep time was stated), and a values sheet (no values round is documented).

I didn't need to ask you anything to build it.

Say the word and I'll play the Skeptic on A1, the highest-ROI question.
I can also save an updated `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

- **Round:** one 45-minute conversation with the hiring manager (name not given), Thursday.
- **Built on:** your message (round type) and `tuesday-dossier.md` v1.1 from job-underwriter (decision: conditional_go).
- **Assumption this pack stands on:** persona weights come from the hiring-manager prior and the dossier. No Quartzline research is in it: the searches were refused (see Sources), so there are no company-strategy questions.
- **Highest-ROI prep in this pack: A1.** The underwriter named that objection from evidence you confirmed, so A1 is used as they wrote it and gets the deepest rehearsal.

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Banks are letter-by-persona. Letters skip F so question IDs never collide with fit-snapshot rows (F1 to F9).
- **Type key.** VAL: past behavior against the company's published values. EXP: whether your experience claims survive scrutiny. JD: whether you can do the listed job, gaps included. CO: company and strategy knowledge. CASE: a live problem from the role. No published Quartzline values were read, so no question is tagged VAL, and none is tagged CO.
- **Guidance is scaffolding, not a script.** Everything said about your past rests on a sentence quoted beside it. An **answer slot** is an instruction for the interview: answer it from what actually happened, and if the practice it names did not happen or was not yours, say so plainly. Either branch is a good answer.
- **The dossier's two conditions run through the whole pack.** Position the bridge as adjacent, never as PM experience; and verify the squad-authority question in the room (reverse question 1).
- **All answer language in this pack is proposed, pending your approval.** Change any wording that is not how you would say it.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. Evidence cells hold your confirmed sentences only: `dossier handoff V1`, `V2` and `V3` are the three `verified_candidate_evidence` entries in order, quoted without the dossier's confidence notes (V1 is high and inspectable, V3 is medium).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff V3 | low | [grounded] | transferability | The underwriter's framing is binding: this is a transferability gap, positioned as adjacent and never as PM experience. Words are the two quotes at their own scope, said after the plain acknowledgment, which has its source in `prohibited_claims`: "I haven't held a product manager title." Limit, as the pack's observation: your material shows integration leadership and input sessions, not the title; V3 is medium, with limited inspectable proof, so volunteer that before it is extracted |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area ("Owning a roadmap and prioritization authority (R1 sub-claim)") and `prohibited_claims` lists "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Then a ramp plan said as a plan, never as a past: what you would find out and read in the first weeks. No bridge here; the underwriter found nothing to build one on |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff V1 | low | [grounded] | transferability | The dossier does not grade R2 in `uncertain_or_weak_areas`, so this row is the pack's own call. The quote is integrations of the vendor's APIs, which is not a statement about shipping a product, and the words stay at the quote's scope. Answer slot: the requirement's own line makes a probe on what you shipped likely. If you shipped any API or platform product, or part of one, say which and what your part was; if you did not, or the APIs were the vendor's and not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff V1; "Wrote the internal integration playbook her team uses" — dossier handoff V2 | low | [grounded] | discovery | The dossier does not grade R3 either. The quotes touch REST APIs and a playbook, and do not show whether API docs or schemas were part of that work. Answer slot: the requirement names API docs and schemas, so expect a probe on them. If you read, wrote or reviewed either in these integrations, say which and what for; if you did not, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff V3 | medium | [grounded] | transferability | The quotes carry clients and a channel to product; they do not carry engineering or sales. Describe the work in the quotes' own terms and do not borrow the requirement's phrase for it. Answer slot: if you worked with engineering or sales inside these integrations, say who and about what; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The `low` is the dossier's grade; its strategy for this area is `clarify`, and no confirmed sentence speaks to the requirement itself. Answer slot: expect a probe on agile delivery in the requirement's own wording. If you have worked that way, say how, in your own words; if you have not, say so plainly. Either way, add what you would want to confirm about how Quartzline's squads define it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff V3 | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so the words are the quote, nothing added: "I ran quarterly roadmap-input sessions that fed client evidence to product." The dossier marks V3 medium: confirmed, little inspectable proof, expect a probe. Answer slot: if you kept notes, an agenda or a deck from the sessions, say you can share them; if you have nothing to show, say you can describe the sessions but have nothing to hand over |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff V1 | low | [grounded] | transferability | The quote carries client integrations with requirements inside them, not specs for squads. `prohibited_claims` lists "Having set prioritization for an engineering squad". Answer slot: the line makes a probe on what you have written likely. If you wrote requirements that an engineering team built from, say what they were; if you did not, say so plainly and stay with leading integrations from scoping to go-live |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Silence, not a stated absence. Answer slot: if you tracked anything about how clients used or adopted the APIs, say what and how; if you did not, say so plainly and say what you would ask about first, which is how adoption is measured today and the current baseline |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the title and roadmap gap | High: the hiring-manager prior puts Skeptic first, and the dossier's named objection is a Skeptic question | Rehearse A1 until it is boring: concede first, adjacent case at its own scope, limit named before asked, ramp plan |
| Case/Strategist (bank B) | Live problems built from the role's own responsibilities: a blocked partner, competing asks, adoption, a spec | High: the hiring-manager prior; the responsibilities are decision-shaped | Clarify, objective, options, who decides, metrics, risks, thinking aloud |
| Data-Driven Prober (bank C) | Defend the 30+, the playbook, the sessions | Medium: the dossier flags V3 as a probe, V1 carries a figure, and 45 minutes allows two levels of follow-up | Know what you can and cannot say about how the count was made; say plainly when you do not know |
| Conversational (bank D) | The journey question first; casual questions on agile and API docs | Medium: a 45-minute conversation opens this way, and casual questions are still scored | A 90-second arc; treat every casual question as scored |
| Values/Behavioral (bank E) | A stakeholder-alignment scenario from R4 | Low: your message names one conversation with the hiring manager, and no values round is documented | Selection scaffolds with the honest branch; no invented story |
| Pressure (bank G) | A time-boxed A1; "how much of that was actually you" | Low as a style, but A1 follow-ups can arrive this way | Hold through two follow-ups, concede specifically, never fold on the quoted core |
| Peer Evaluator (bank H) | The seam with the two squad leads | Low: the interviewer is the manager, so the seam arrives as a role scenario | Propose seam principles; do not pretend to know Quartzline's seam |

## Question banks

Ordered by weight. Provenance quotes are exactly the sentences in the fit snapshot's evidence cells.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | Four beats, in order. (1) Concede first, plainly: "I haven't held a product manager title and I haven't owned a roadmap." (2) The adjacent case at its own scope, in your words: you led 30+ client integrations end to end, scoping through go-live, and you ran quarterly roadmap-input sessions that fed client evidence to product. Say adjacent, not equivalent. (3) Name the limit before they extract it: the sessions fed evidence to product, and V3 has little inspectable proof. Answer slot: if you have an agenda or notes from them, say you can share them; if you have nothing to show, say you can describe them but have nothing to hand over. (4) The ramp, as a plan: in the first weeks you would ask which decisions are yours and which belong to the squad leads, read the current roadmap and the reasons behind it, and find out how adoption is measured today. Follow-up 1: "Integration work is delivery, not product — what did you decide?" Return to the quote. Answer slot: which parts of scoping and requirements were yours to decide and how you decided, in your own words; if they were set for you, say so plainly. Follow-up 2: "A PM with three years has owned outcomes. What are you missing?" Concede specifically: the title and the roadmap, and nothing further than the dossier-sourced list. Follow-up 3: "So you're asking us to train you." Hold: "On roadmap ownership and prioritization, yes, I would be learning, and this is how I would do it" and return to beat 4. Never answer by saying you were effectively already doing the job | The underwriter named this objection from evidence you confirmed (F1 and F2), so it is used as written; every negative in it has a dossier source. JD because it scores R1; the Skeptic register is the delivery. Deepest means the most follow-up levels and a limit named before it is asked, never more affirmative content than the quotes carry |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] `uncertain_or_weak_areas`: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name the roadmap and prioritization authority as the answer: it is the area the underwriter marked `acknowledge_gap`, and the honest answer is the plain one, "I haven't owned a product roadmap". Then the ramp plan in two sentences: who you would sit with first and what you would read. Do not pair the answer with a bridge. Pick one weakness and stay on it; a list invites the interviewer to rank them | F2 is the largest gap and this stem asks for it directly. JD because it asks you to rank the listed job's demands against yourself |
| A3 | "The role asks for shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start with the quote at its own scope: you led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live. Answer slot: if you shipped any API or platform product, or part of one, say which and what your part was; if you did not, or the APIs were the vendor's and not yours, say so plainly and stay with the integrations. Do not describe the integrations as products you shipped | F3 is a must-have the dossier does not grade as weak, so it is the likeliest surprise. The premise is the requirement's, and the slot's second branch allows that it is false |
| A4 | "How do I know you won't slow the squads down while you learn the job?" | JD | [grounded] | No claim about your past is needed. Give a plan: in the first weeks, agree with each squad lead which decisions wait for you and which do not, so nothing queues behind your learning. Ask rather than assume where the line sits, because the dossier lists decision authority against the two squad leads as unverified. End on one thing you would ask the manager now | The risk of a learner on a two-squad platform is the manager's real worry, and the dossier carries the authority question as unresolved. JD because it tests the delivery responsibility |
| A5 | "Why move from integration work into product, and why here?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The reason is yours, and nothing in your material says it, so the pack supplies none. Structure it in three sentences: where you are (the quote, at its own scope), what you want to do next that you cannot do from there, and what about this role's responsibilities draws you. If a specific moment drove the move, tell it; if it was gradual, say so | Motivation consistency is what the Skeptic scores once the gap is conceded. JD because it tests whether the move fits the listed job |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says one endpoint's design is blocking their go-live, and the squad lead says it isn't worth changing. Where do you start?" | CASE | [generic] | Think aloud. Clarify first: what exactly is blocked, how many other partners hit it, what the workaround costs. Objective: restore the partner's go-live without a change that costs more than it saves. Options: a docs fix, a workaround, a change. Then who decides: ask, do not assume authority, and bring partner evidence rather than opinion. Close with how you would know it worked. Say "I would", never "I did" | The responsibilities put a PM between partners and squads, which is this scenario. CASE because it asks for structure, and `[generic]` because it is a pattern for the problem and claims nothing about you |
| B2 | "Next quarter, partners, sales and the two squads each want something different. How do you decide what goes on the roadmap?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | State your criteria aloud before applying them: goal first (the adoption outcome), then evidence from partners, then cost to the squads, then what you will say no to and how you tell people. Ask who holds the final call. You may link V3 once, at its own scope: the sessions fed client evidence to product, which is input, not the decision. Do not describe the decision as yours | Prioritization is the heart of F2's gap, so the manager will test your reasoning where your record is thin. CASE because it is a live decision |
| B3 | "How would you define and track adoption for a partner API? What do you want to know first?" | CASE | [generic] | Clarify: how adoption is measured today and the current baseline, which is exactly what the dossier lists as unknown. Then segment partners by where they are (signed, integrating, live, active), pick one or two measures and name each one's weakest assumption before they do. Answer slot for your past: if you tracked anything about how clients used or adopted the APIs, say what and how; if you did not, say so plainly and say what you would measure first | The responsibility "Define and track adoption metrics" has no evidence behind it (F9), so a structured answer is the only available strength. CASE with the weakest-assumption move built in |
| B4 | "How would you run discovery with integration partners so that it feeds both squads?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure: who you would talk to and why, what you would ask, how evidence gets written down, how it reaches each squad. You may link V3 at its own scope: the quarterly sessions fed client evidence to product. Volunteer the limit: little inspectable proof, so expect a probe. Answer slot: if you gathered the client evidence yourself, say how; if it came from elsewhere, say so plainly and stay with running the sessions | F7 is your closest evidence against a discovery responsibility. CASE because it asks for a design, and V3 gives the one place to ground it |
| B5 | "Draft the first paragraph of a spec for the endpoint change we just discussed. What goes in it?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what you would put in, in order: the problem and who has it, what success looks like, what is in and out of scope, open questions, and who reviews. Answer slot: if you wrote requirements that an engineering team built from, say what they were; if you did not, say so plainly and stay with the requirements work inside the integrations you led | F8 asks for specs and the quote carries requirements only inside client integrations. CASE because it is a live artifact request |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations. How did you count them?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The figure is high-confidence and the dossier records an inspectable artifact, the integration playbook, so you can offer it. Answer slots, each in your own words: how the count was made; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how a figure was counted, say so plainly. Do not explain a counting method you have not used | A headline figure is a magnet target (F1, F3). EXP because it tests attribution |
| C2 | "Tell me about the integration playbook you wrote. What's in it, and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats the quote states: you wrote it, it is internal, your team uses it. Describe the contents from the document itself, in your own words. If you know whether it changed how integrations ran, say; if you do not know, say so | The playbook is the inspectable artifact, so the manager is likely to ask about it (F4). EXP because it tests what is actually yours |
| C3 | "Tell me about the quarterly roadmap-input sessions you ran." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: quarterly, roadmap-input sessions, client evidence going to product. Say the limit first: the sessions fed evidence to product and you haven't owned a roadmap (`prohibited_claims`: "Having owned a product roadmap"). Answer slot: the discovery line makes a probe on how the sessions worked likely. If you gathered the evidence yourself, say how; if it came from elsewhere, say so plainly; if you do not know what product did with it, say that | The dossier marks this claim medium and says to expect a probe (F7). EXP because it checks a claim with thin proof |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get to integration leadership, and why this role now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats the quotes carry: you led the integrations; you wrote the playbook your team uses; you ran the roadmap-input sessions. The early career and the reason for this move are yours; the pack has no sentence for either, so tell them as they happened. End on the adjacent framing, not on a claim to product experience | The opener is scored. EXP because it checks whether the story hangs together (F1) |
| D2 | "How do you work with API docs and schemas day to day?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the requirement names API docs and schemas, so this casual question is scored. If you read, wrote or reviewed them, say which and what for; if you did not, say so plainly and say what you would look at in the first week. The quote supports saying you led integrations of REST APIs; it does not say what you did with docs | F4 is thin and a casual register is where it gets probed. JD because it scores R3 |
| D3 | "What's your experience with agile delivery?" | JD | [grounded] | Answer slot: the requirement's own wording is the probe. If you have worked that way, say how, in your own words; if you have not, say so plainly. Add what you would want to confirm about how Quartzline's two squads define it, which is true either way | F6 is a `clarify` area: the evidence may exist and was never established. JD because it scores R5 |

### Bank E: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to get engineering, sales and a customer to one decision." | JD | [generic] | Selection scaffold: pick an instance where all three had a stake. It needs a named disagreement, the part you played, and a decision everyone could live with. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The requirement lists those three groups (F5), and the material does not carry a sentence that fits |
| E2 | "Tell me about a time you had to tell a client or a colleague something they didn't want to hear." | EXP | [generic] | Selection scaffold: pick a time the hard truth actually landed and the relationship survived, with a named stake. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard behavioral stem. EXP because no published values were read, so it scores behavior, not value alignment |

### Bank G: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Thirty of them. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Pause, restate. Hold the quote through two follow-ups: you led them. Answer slot: which parts were yours alone and which you did with your team, in your own words; if some parts were others', say so plainly. Concede that specifically, not generally, and do not fold on "led" | Attribution is what this question probes (F1). EXP because it tests what was actually yours |
| G2 | "Sixty seconds: it's a bet to hire someone who has never owned a roadmap. Why isn't it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having owned a product roadmap" | A time-boxed A1. Concede in one line that it is a bet and that you haven't owned a roadmap, say the quoted adjacent work in one line, and give the ramp plan in one line. Do not claim the risk is zero; claim you would lower it | The same objection delivered under time pressure. JD because it scores R1; hold-then-concede is the type bar |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where is the seam between the PM and the two squad leads, and what happens when you disagree?" | CASE | [grounded] | Do not pretend to know Quartzline's seam; the dossier lists decision authority against the squad leads as unverified. Propose principles: each decision gets a named owner up front, disagreements are settled with partner evidence, and cost of change outranks preference. Then ask where it sits today | Collegial packaging of the F2 and F8 gaps. CASE because it is a live design of a working relationship |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Principle first: "we" for the work, "I" for what you did. If an instance comes to mind, tell it; the quote supports saying you wrote the playbook your team uses, and nothing beyond that. If none does, say so plainly and describe how you would handle it | Credit-sharing probes test attribution honesty collegially (F4). EXP because it checks how you describe shared work |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, A5, G2 |
| R2 "Shipped API or platform products" | A3, C1 |
| R3 "Technical fluency: API docs, schemas" | D2, C2 |
| R4 "Stakeholder management across engineering, sales, customers" | E1, E2, H1, H2 |
| R5 "Agile delivery experience" | D3 |
| Responsibility: own the roadmap | A1, A2, B2 |
| Responsibility: run discovery with integration partners | B4, C3 |
| Responsibility: write specs and drive delivery with two squads | A4, B1, B5, H1 |
| Responsibility: define and track adoption metrics | B3 |

## Reverse questions

No interviewer profile was given, so none is tied to their path, and the interviewer is not a peer, so there is no reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | From the dossier: the JD asserts decision authority and nothing evidences it. It reads as diligence, and it settles the condition the underwriter left open |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | From the dossier: adoption metrics are a named responsibility with no stated baseline. You need it to judge whether the goal is reachable |
| 3 | "What would you want me to have learned by day 30, and what by day 90?" | It turns the manager's doubts about a first PM seat into criteria you can meet |
| 4 | "Given that my background is integration work rather than a PM seat, what would you want to see early to know it was working?" | It invites the manager to name the objection themselves, on terms you have rehearsed in A1 |
| 5 | "How does partner feedback reach the roadmap today, and where does it get lost?" | It shows discovery interest and tells you whether input of the kind in V3 has a home here |
| 6 | "Can you describe a recent disagreement between the PM and a squad lead, and how it was resolved?" | It tests the authority question from a second angle, with a concrete example rather than a policy |

## Prohibited claims

Claims this pack will not coach. The first three come from the dossier's `prohibited_claims`; the rest are the stretched wording of sentences you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims`: "Having held a product manager title or role" | The plain acknowledgment that item supports: "I haven't held a product manager title." Then V1 and V3 at their own scope, as adjacent work |
| Having owned a product roadmap | Dossier `prohibited_claims`: "Having owned a product roadmap", and the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | "I haven't owned a product roadmap", then a ramp plan as a plan. V3 stays "feeding client evidence to product" and is never a roadmap |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims`: "Having set prioritization for an engineering squad" | "I haven't set prioritization for an engineering squad", only if asked, then the ramp plan |
| Shipped an API or platform product | Inflated form of F3 | V1 at its own scope. The limit is the pack's observation: the material says integrations of the vendor's APIs, not a shipped product. A3's slot stays inside the integrations |
| Managed stakeholders across engineering, sales and customers | Inflated form of F5 | V1 and V3 at their own scope. The material carries clients and a channel to product; B5 and E1 keep engineering and sales as slots |
| Wrote specs for engineering squads | Inflated form of F8 | V1 at its own scope, with requirements inside client integrations. B5's slot asks only what requirements you wrote |

## Sources

- **Provided:** your message (round type and length), and `tuesday-dossier.md` v1.1 from job-underwriter, dated 2026-08-14 (envelope major version 1, which this skill reads). Sections consumed: `role_profile` (requirements stand as the JD's lines; responsibilities used the same way), `handoff_to_mock_interview` (verified evidence, weak areas with their allowed strategies, the named objection, risks, employer questions, prohibited claims), and `decision` (context only). The dossier carried no `evidence_map`, `evidence_state` or `risk_register`, so fit-snapshot grading comes from the handoff's own confidence and gap types, and rows the handoff does not grade (F3, F4, F5, F8, F9) are this pack's call.
- **Searches sent, all refused (the host did not grant search permission):** "Quartzline company values"; "Quartzline interview process product manager"; "Quartzline partner API platform strategy news". No fetches. Nothing in this pack about Quartzline's values, loop or strategy comes from research.
- **Loop:** your message establishes it: one 45-minute conversation with the hiring manager. No values-style round is documented, so none is assumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions if a values round were documented |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have checked the loop and the persona weights against Quartzline's documented rounds |
| 3. `Quartzline strategy` / recent news | unavailable | The search was refused. It would have fed a grounding brief and CO questions |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or a pasted Quartzline values page and strategy brief → a grounding brief, CO questions, and the values sheet if a values round turns out to be part of the loop. A deeper pass is also available once: up to 6 further searches and 2 further fetches, several more minutes, adding a strategy brief and role-family loop reports
- The interviewer's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their path
- The recruiter's prep note (focus areas, any pre-declared exercise) → coverage of what the round will actually test
- The original posting text → requirement wording checked against the dossier's `role_profile`, and the responsibilities quoted as the JD's own lines
- An agenda, notes or deck from the roadmap-input sessions → F1, F5 and F7 evidence moves from medium toward high, and C3 and B4 get a quoted artifact to work from
- Your answers to the slots in F3, F4, F5, F6, F7, F8 and F9 → those rows become quoted evidence and their guidance cells get real beats
- How much prep time you have → a prioritized schedule for the days before the interview
