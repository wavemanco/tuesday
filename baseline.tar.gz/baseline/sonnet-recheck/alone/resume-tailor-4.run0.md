Short version: a keyword-matching rejection is possible but unlikely to be the main cause. The coverage map shows a bigger problem, which is that most of this JD's stack isn't on your resume. I've kept every edit to what you've told me, and nothing is applied yet.

I'm working from your description, not the PDF. The "current line" quotes below are your own sentences. I assumed your Kubernetes proof-of-concept sentence is on the resume. If it isn't, E2 and E3 add it rather than moving it.

## What the evidence says about ATS rejection

| Claim | What the source says | Provenance |
|---|---|---|
| Content-based auto-rejection is rare in the one sample available | "AI/content auto-rejection configured: 8% of recruiters." and "We only saw 2 of 25 using it." (cite C25) | `[grounded]` vendor interviews with 25 recruiters; the vendor sells a résumé builder and calls its findings themes, not representative statistics |
| What rejects without a person is usually a form question, not the resume | "When automated filters are used, they’re almost always knockout questions" (cite C26), which are yes/no checks on things like work authorization, license and location | `[grounded]` same source; nothing I write changes these |
| Keywords may affect ordering rather than rejection | "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27) | `[grounded]` same source; that keywords drive such scores is my inference |

I can't tell from this whether your rejections were automated at all. Truthful keywords placed where your evidence supports them can help you get found. Adding ones you can't back up would only move the rejection to the interview.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — moved to the first bullet under your current role)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a Kubernetes proof-of-concept for two months — never went to production." as its own bullet directly under E1; swap in the actual year for "last year" if you want a date | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Docker, Kubernetes (two-month proof-of-concept, not in production), Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |

- **E2 and E3 keep the "never went to production" qualifier.** Dropping it would make the Kubernetes line a bigger claim than the one you wrote.
- **No rows to cut or compress.** I haven't seen the rest of your resume text. Paste it and I'll look for lines to cut.

## Coverage map

The JD gives no tiers. I read the title and the closing sentence ("own platform reliability and developer experience") as must-haves, and took the core platform tools alongside them. Tell me if you read it differently.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | Kubernetes | must-have | `surfaced_by_edit` | E2, E3. Proof-of-concept only, so it won't read as production Kubernetes. | `[grounded]` your PoC sentence |
| M2 | AWS EKS | must-have | `not_evidenced` | AWS is on your resume; EKS isn't, and I don't know if your PoC ran on it. See C1. | `[grounded]` your skills line |
| M3 | Terraform | must-have | `not_evidenced` | Ansible is config management, a different kind of work. See C2. | `[grounded]` your skills line |
| M4 | CI/CD (Jenkins side) | must-have | `surfaced_by_edit` | E1 | `[grounded]` your pipeline sentence |
| M5 | Platform reliability and developer experience ownership | must-have | `not_evidenced` | Nothing you've said covers reliability ownership. See C3. | `[grounded]` absence from your material |
| M6 | GitLab CI | important | `not_evidenced` | Named absence N1 | `[grounded]` your skills line has Jenkins only |
| M7 | SRE practices | important | `not_evidenced` | See C3. | `[grounded]` absence from your material |
| M8 | Prometheus, Grafana, observability | important | `not_evidenced` | CloudWatch is already on your resume as a different tool; I wrote no row for it. | `[grounded]` your skills line |
| M9 | ArgoCD, GitOps | important | `not_evidenced` | Named absence N2 | `[grounded]` absence from your material |
| M10 | Helm | important | `not_evidenced` | C1 may close it. | `[grounded]` absence from your material |
| M11 | Python | important | `already_evidenced` | "Bash and Python scripting" is already on your resume. | `[grounded]` your skills line |
| M12 | AWS | important | `already_evidenced` | "AWS (EC2, S3, RDS, IAM)" is already on your resume. | `[grounded]` your skills line |
| M13 | Istio, service mesh | preferred | `not_evidenced` | Named absence N3 | `[grounded]` absence from your material |
| M14 | Vault | preferred | `not_evidenced` | Named absence N4 | `[grounded]` absence from your material |
| M15 | Go | preferred | `not_evidenced` | Named absence N5 | `[grounded]` absence from your material |

## Gap handling

**Recall prompts (pending your approval).** Each implies one question, asked once in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes, EKS, Helm | must-have | A two-month Kubernetes proof-of-concept that never reached production. It doesn't say where it ran or what it used. | Kubernetes and EKS lead the JD, and "proof-of-concept" with no detail reads thin. | The cluster was EKS; you used Helm charts; you deployed a real service or an internal tool onto it | The PoC write-up or architecture notes, a repo, manifests or charts | `[grounded]` what the resume does and does not say; `[generic]` how such postings usually weigh platform tools |
| C2 | Terraform | must-have | Ansible for config management and AWS services, with no infrastructure-as-code tool named. | It is a must-have and nothing on the page speaks to it. | Terraform or CloudFormation in a side project, a lab, or one-off work at your job; provisioning AWS resources from code | A repo or template files | `[grounded]` what the resume does and does not say; `[generic]` how such postings usually weigh IaC |
| C3 | Reliability ownership, SRE practices | must-have | CloudWatch for monitoring and about 30 Jenkins jobs maintained, which is operational work but not stated as reliability ownership. | The JD's closing sentence is about owning reliability. | CloudWatch alarms you set up; on-call rotations; incident response or postmortems; deploy rollbacks you handled | An alert config, a postmortem doc, a dashboard screenshot | `[grounded]` what the resume does and does not say; `[generic]` what this costs on applications of this kind |

**Named absences.**

| # | Gap | What closing it would take | Provenance |
|---|---|---|---|
| N1 | GitLab CI | Real use in a job or project. A realistic closing path is porting one Jenkins job to a `.gitlab-ci.yml` in a public project. List it only after you've done it. | `[generic]` |
| N2 | ArgoCD, GitOps | Running ArgoCD against a cluster, for example your PoC cluster or a local one. List it only after you've done it. | `[generic]` |
| N3 | Istio, service mesh | Real mesh work on a cluster. This is a preferred item, so it is probably not worth closing for this application. | `[generic]` |
| N4 | Vault | Standing up and using Vault. Preferred item; same judgment as N3. | `[generic]` |
| N5 | Go | Writing real Go. Preferred item, and a longer road than the others. | `[generic]` |

## Not written, and why (pending your approval)

- **"Platform Engineer" as your title.** You are a DevOps Engineer, and renaming the title upgrades the role.
- **"Production Kubernetes" or "EKS experience".** Your proof-of-concept never went to production, and you haven't said it ran on EKS.
- **"Infrastructure as code" or "Terraform".** Ansible for config management is a different kind of work, and I won't use the JD's word for it.
- **"Observability" or "Prometheus/Grafana".** You wrote "CloudWatch for monitoring". "Observability" is the posting's word, and your resume has the tool, not the practice.
- **"Owned platform reliability", "SRE practices" or "developer experience".** Nothing you've said shows you owned reliability or built for developers, and I don't know who used your pipeline.
- **"GitOps", "ArgoCD", "Helm", "Istio", "Vault", "Go", "GitLab".** None appear in your material.
- **A keyword block listing the JD's tools.** Listing tools you don't have is a claim, and an interviewer will ask about each one.

## Parse-safety check

I haven't seen the file, so most of this is unchecked. A copy-paste test is below.

| Check | Finding | Provenance |
|---|---|---|
| Multi-column layout | Risk: you said it's two columns. Parsers read linearly, so text can interleave and dates can detach from roles. | `[grounded]` your description; `[generic]` how extraction fails |
| Icons for skills | Risk: any skill shown only as an icon is absent to a parser. I can't tell whether the names are also written as text. | `[grounded]` your description; `[generic]` how extraction fails |
| Contact details in the header | Unverified: if they sit in a true page header or footer, some parsers discard them. I can't tell which this is. | `[generic]` |
| Section headings, file type, hidden text | Not checked: I haven't seen the file. | `[generic]` |

To test it yourself, select all the text in the PDF, paste it into a plain-text editor, and see whether the order, dates and contact details survive. Send me the result or the file and I'll report on it.

Whether this role is worth applying to, given the gaps above, is job-underwriter's question. Run it before spending more time on this one.

## Upgrade menu

- **Your resume as a text-layer PDF or `.docx`, or the pasted text.** This lets me run the real parse check and look for cuts.
- **The Kubernetes proof-of-concept write-up, architecture notes or a repo.** Inspectable evidence would let me write E2 and E3 more specifically.
- **A sanitized Jenkinsfile or pipeline screenshot.** This would back up E1.
- **A CloudWatch alert config, runbook or postmortem.** Any of these could close C3.

## Questions

C1 — Where did the Kubernetes proof-of-concept run (EKS or something else), did it use Helm or any monitoring, and what did you deploy on it?
C2 — Have you written any Terraform, CloudFormation or similar anywhere, including side projects?
C3 — Have you been on call, set up alerts or dashboards, or run an incident or postmortem?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.