I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, apply, once the posting checks out and you've confirmed R1. Status: `conditional_go`.** Your evidence is `direct` on R2, R3, R4, R5 and R6. Pet insurance (R9) and whole-product ownership (R7) are the two bridges to frame honestly.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (Own pricing analytics for the product)
- `preferred`: direct: R8 · adjacent: R9 (Pet-insurance domain knowledge)

R7 and R9 carry named limits, and R1 waits on one confirmation.

**Opportunity ledger.** The mandate is concrete (RR5), but the employer is not established (RR1), the salary is not stated (RR2), people-management scope is silent (RR3), and book size and test method are unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify (RR1); (2) R1 is confirmed; (3) R7 and R9 are framed as adjacent, never as whole-product or pet-insurance expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product. Its existence has not been checked | `[grounded]` JD as pasted |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Her public footprint was not researched | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| First-year outcomes | None stated in the JD | `[grounded]` JD silence |
| People management | The JD asks for none and names no reports. Your lack of it is not a requirement gap | `[grounded]` JD silence; `[grounded]` your statement |
| Scope read | An individual-contributor mandate: modelling, testing and advising, with no reports named. Your 5 years against "4+" sits inside the range | `[inferred]` from the JD's responsibilities and its silence on reports |
| Market calibration | Not calibrated and no figure given. The role-family sweep did not run. The title and "4+ years" suggest an experienced individual-contributor level, a pattern rather than a claim about Brindlemoor | `[generic]` title and years pattern |
| Unknowns | Salary; employer existence; team size; pet-book volume; how price tests are run; whether models are built in-house | `[grounded]` absent from the pasted JD |
| Contradictions | None inside the pasted JD. It was not compared with a careers page | `[grounded]` JD read; comparison not run |

## Evidence map

Your background was typed into the chat, so it counts as self-report. `medium` is the ceiling until you share an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You stated no location or right-to-work. A UK employer suggests you are UK-based, but that is not a confirmation | `[inferred]` from your UK motor insurer employer | Ask Q-R1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years in pricing analytics, the last 2 as senior analyst. Confirmed and specific, but no CV or dates inspected | `[grounded]` your intake message | Share your CV to firm up dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Frequency is confirmed, but "strong" rests on examples I haven't seen. Expect a probe | `[grounded]` your intake message | Name one concrete pipeline, model or monitoring script |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. Limit: one motor book | `[grounded]` your intake message | A sanitized model document or relativities report would raise this to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which matches "underwriting". No actuarial audience is stated, and the JD says "or" | `[grounded]` your intake message | A sanitized review deck would raise this to `high` |
| R6 | Design and read price tests, recommend to underwriting and product | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" does not say whether you designed them. A product audience is not stated | `[grounded]` your intake message; the design and product gaps are `[grounded]` silence | Ask G1 |
| R7 | Own pricing analytics for the whole product | important | adjacent | medium | transferability | You owned one segment's GLM (young drivers), not stated to be a whole product's analytics. Limit: scope of ownership | `[grounded]` your intake message; `[inferred]` that the role's scope is wider | See G4 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake message | none |
| R9 | Pet-insurance domain knowledge (not required in the JD) | preferred | adjacent | low | transferability | You have never worked on pet insurance. The bridge is personal-lines motor rating, and the transfer itself is untested. Pet rating likely has different factors and claims drivers | `[inferred]` from a role built on a pet product against a JD that asks only for insurance experience; `[generic]` that rating factors differ by line | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Test design ownership and audience (R6, must_have) | discovery | 14 tests "ran with the underwriting team". Nothing on who set cells, sample size or success measure, or whether product saw the results | R6 is a must-have row. Whether you designed or only executed decides how you present it | Choosing test cells and duration; setting the success measure; reading lift against loss ratio or retention; presenting a result to product as well as underwriting | A sanitized test read-out, a test-design note, a results deck | `[grounded]` intake silence; `[generic]` that this role family probes design versus execution |
| G2 | Pet-insurance bridge (R9, preferred) | transferability | Adjacent: motor GLM build and maintenance. Limit: no pet factors, claims behaviour or vet-cost trends exercised | A bridge with its limit stated reads weaker and interviews stronger | Any non-motor personal-lines work; small-volume frequency or severity modelling; renewal pricing | A one-page work sample on how your motor model structure would carry to pet, with its limits (see W1) | `[inferred]` bridge derived from your motor GLM work |
| G3 | UK location and right to work (R1, hard_gate) | hard_gate | Nothing stated | A gate the inputs do not settle stays open and caps the decision | none | none | `[grounded]` intake silence |
| G4 | Whole-product ownership (R7, important) | transferability | Segment ownership of one model, scope of "owned" unclear | The role says "own pricing analytics", so ownership breadth is the likely probe | Owning several models; documenting and monitoring them; others relying on your outputs | A model inventory, monitoring dashboard screenshots | `[inferred]` the likely probe from the JD's "own" wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small for a public footprint, or the posting may be stale or aggregated. Research did not run, so this is unverified, not failed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | *(no pay line in the pasted text)* | The figure may be withheld by the poster or trimmed from the paste | `[inferred]` from the pasted text's silence | What salary range is budgeted for this role? | unresolved |
| RR3 | People-management scope unstated | unknown | — | "Senior Pricing Analyst" | A senior title could carry mentoring or reports, though the JD lists none | `[inferred]` from the title against the JD's silence | Does this role have direct reports or a mentoring remit, now or planned? | unresolved |
| RR4 | Book size and test method unknown | unknown | — | "design and read price tests" | A small book could limit how fast tests reach a clear result | `[generic]` that new-product books are often small | How large is the pet book, and how are price tests run? | unresolved |
| RR5 | Concrete mandate with named audiences | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The mandate is defined and tied to named audiences | `[grounded]` JD | What would a good first six months look like? | noted |

## Application plan

Every row below is proposed, `pending your approval`. That covers the advice in the Why column as well as any wording. I have not seen your CV, so no CV text is proposed yet.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Brindlemoor's own careers page, or with the recruiter, before drafting | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your own claims on R4, R5 and R6, naming the caveat: confirmed, no document inspected | These are the rows where you are `direct` | `[grounded]` the map | pending your approval |
| A3 | State plainly that you have not worked on pet insurance, and present motor GLM rating as the adjacent bridge. Don't claim pet or whole-product expertise | See R9 and R7 | `[grounded]` your statement | pending your approval |
| A4 | If asked, say you have not managed anyone. The JD names no reports | See RR3 | `[grounded]` your statement | pending your approval |
| A5 | Ask the verification questions of RR2, RR3 and RR4 verbatim at screening | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| W1 | Optional: a one-page note on how your motor model structure would carry to pet, with its limits stated | See G2 | `[inferred]` from G2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Brindlemoor pet insurance insurtech careers" was refused for lack of permission. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "Senior Pricing Analyst pet insurance UK remote salary" was refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have moved role reality's scope read and which story the plan leads with |

Dossier: I can save this as `tuesday-dossier.md` if you'd like it.

## Upgrade menu

- **Your CV or a prior resume:** claims move from intake self-report to CV-checked, buried evidence surfaces, and I can propose wording.
- **Inspectable pricing artifacts:** a sanitized model document or relativities report lifts R4. A sanitized quarterly review deck lifts R5. A sanitized test read-out lifts R6.
- **An answer to G1:** closes R6's gap.
- **The salary range, from the recruiter or posting:** closes RR2 and lets me check it against any floor you give.
- **Search permission, or the careers-page text pasted in:** runs targets 1 to 3, covering employer verification (RR1), a market band, and the hiring manager's public professional footprint.
- **A deeper research pass on Brindlemoor** (funding, leadership churn, public candidate reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs once search is allowed.

**Questions**

- R1: Are you UK-based, with the right to work in the UK without sponsorship?
- G1: In the 14 price tests, which parts did you personally own: designing them (cells, sample size, success measure), analysing them, or presenting the read-out? Who received the recommendations?
- C1: Is there a salary floor, set hours or days, travel limit, or any other fixed term that would rule this role out?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.