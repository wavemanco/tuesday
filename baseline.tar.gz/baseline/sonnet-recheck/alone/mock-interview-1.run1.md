I'm writing the pack now. Both research searches were refused, so it rests on your material and your research note.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-1-denied-e39f7cb7/7e1009f5-e278-401a-934b-bd450c9d50aa/scratchpad/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

I built it for one 60-minute peer conversation with Dan. The only material was your JD highlights, your notes on Priya and your research note, since there was no full JD text or CV. My two searches (Northwind's values, Dan's public footprint) were refused, so nothing in the pack comes from the web. The sources section lists both as refused.

It has 22 questions across seven personas, weighted toward Peer Evaluator and Data-Driven Prober. Each question has a type, provenance, answer guidance and rationale. It also has a fit snapshot, a read of Dan, a requirement-coverage table, seven reverse questions, a prohibited-claims list and the sources.

The highest-ROI prep is D1. It covers Priya's stated lack of sales-ops and quota-setting experience, which is Dan's own territory. After that, rehearse B1 and B2 on the ~$400M ARR figure.

Say the word and I'll play Dan as the Skeptic on D1, with follow-ups that react to what Priya says.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD text and Priya's CV lines? The six JD rows would quote the real JD, and the rows that now rest on your summary would quote her CV.
2. Can you allow web search so I can retry the Dan and values lookups? Dan's footprint would sharpen the interviewer read and R1 and R2, and values would firm up G1 and G2. I can also run a deeper pass, up to 6 more searches and 2 more fetches, which takes several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

| Field | Detail |
|---|---|
| Candidate | Priya |
| Role | Senior GTM Strategy Lead, Emerging Products, Northwind Data |
| Interviewer | Dan Kovac, Director of Sales Strategy at Northwind Data |
| Relationship | Peer: "both reporting to the same VP" (your message) |
| Round | One 60-minute conversation with Dan (your message) |
| Built from | JD highlights and notes about Priya, both as you wrote them in your message, plus your research note; no full JD text and no CV lines were supplied |

## How to use this pack

- Personas say how a question is asked. Types say what is being scored. Every question carries both.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- An "answer slot" is an instruction for the live interview, not a question for you now. Answer it with either branch, from your own experience: say how it went, or say plainly it was not yours or never existed.
- Question IDs are letters by persona (A to G) so a drill can call them: "run D1".

| Type tag | Meaning | What it is really testing |
|---|---|---|
| VAL | Behavioral or values alignment | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether the claims survive scrutiny; who did what |
| JD | Role or JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at the company's altitude |
| CASE | Hypothetical or live problem | Structure and reasoning on a problem from the actual role |

## Fit snapshot

Candidate evidence is quoted exactly from your notes, and requirements from the JD highlights as you wrote them (not the full JD). Provenance is the label alone on every row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market, with nothing inspected behind it, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-product-lines line makes a probe on what go-to-market work you have owned likely. If any part was yours to own, say which part and how you decided, in your own words; if there was none, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The sentence says proposed and credited with; it does not show how the opportunity was found or sized, and the words stay at that scope: "I proposed a store-surface change that was credited with roughly a $400M ARR uplift." Answer slot, the figure: say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; if you do not know how it was counted, say so plainly. Answer slot, the lifecycle: the JD's land/adopt/expand/renew line makes a probe on how you find whitespace across those stages likely; if you have looked at any stage in your work, say which and what you did; if you have not, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in the tools, but a stated skill with nothing inspected behind it, so expect a probe on what you actually built. Lead with it in the quote's own terms: "I'm skilled in SQL and Tableau." Question B3 rehearses the walkthrough |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The sentence says a model built and used in negotiations; it does not show a partner motion designed, and the words stay at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the "required" line makes a probe on partner-motion design likely. If any decision about how partners were worked with, beyond the model itself, was yours, say which and how you decided; if there was no such decision, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The sentence reaches the requirement in role terms, with nothing inspected behind it. Lead with it as written: "I set annual volume targets with cross-org consensus." The word is targets throughout, never quotas |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The sentence says use, not building or launching, and the words stay there: "I use AI tools daily." Answer slot: expect a probe on which tools and for what; say which and what for, in your own words, and if the use is mostly for your own productivity, say so plainly |
| F7 | Familiarity with sales ops and quota setting (a gap you flagged; not a JD highlight) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and F5's targets are not relabelled as quotas |

## Reading the interviewer

Public footprint only. The two searches for Dan were refused, so everything below is what your message says his profile says; nothing beyond it is established.

| Signal (quoted) | Source | Provenance | Practical implication | Mirror opportunity |
|---|---|---|---|---|
| "relentlessly data-driven" | Dan's profile self-description, your message | [grounded] | Every figure you give is likely to be followed two levels down: B1, B2, B4, F1. Name the assumption you would defend least before he asks | Shared vocabulary: say what you can and cannot say about how a number was counted. Candidate side, F3: "skilled in SQL/Tableau" |
| "career spine is pricing and monetization roles" | Your message | [grounded] | Cases will likely land in pricing, packaging and unit economics: C1 to C3. Revenue language is his native register | Shared vocabulary, not a shared jump, because the quote shows no pricing work. Candidate side, F4: "built a partner-level revenue model used in carrier negotiations" |
| "with one early-stage-startup chapter" | Your message | [grounded] | One chapter in a pricing spine moves no persona weight. It is best used as a reverse question: R2 | None offered: no fit-snapshot row's evidence carries a candidate side of a startup jump |
| "both reporting to the same VP" | Your message | [grounded] | He is weighing what hiring you costs and adds to his own work. Reciprocity beats self-presentation: A1, A4, R3 | None needed |

## Persona table

Weights are a shown judgment: relationship prior, then interviewer signals, then the loop. Recalibrate if you know something this pack does not.

| Persona | Bank | Qs | How it shows up with Dan | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|---|---|
| Peer Evaluator | A | 5 | Seam-splitting between Sales Strategy and emerging-product GTM; what you need from him; credit across teams | High. The peer relationship prior makes this and the Prober dominant; he is weighing impact on his own work | Reciprocity framing; offer seam principles, not a map you have not seen; keep credit claims to named parts | [generic] prior, [grounded] relationship |
| Data-Driven Prober | B | 5 | CV numbers pushed to inputs and assumptions; a request to walk an analysis end to end | High. His self-description as "relentlessly data-driven" moves this up from the peer prior, and F2 is a headline number | Know what you can and cannot say about how each number was counted; say "I don't know how it was counted" plainly when true | [grounded] signal, [generic] method |
| Case / Strategist | C | 3 | Live problems on pricing, packaging, bundling and capacity for emerging lines | Medium. A pricing and monetization spine tilts cases toward his native ground; your research note supplies the live material (priorities, bundling) | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | [grounded] signal and note, [generic] method |
| Skeptic | D | 3 | The sales-ops and quota gap, the required partner-motion line, and the consumer-to-enterprise move | Medium to high on D1. F7 is a stated gap in the territory Dan works in, and F4 is a required line the evidence only partly reaches | Rehearse D1 until it is boring: plain acknowledgment, the quote at its own scope, a ramp plan | [inferred] from F4 and F7 |
| Conversational | E | 2 | An opening "walk me through the journey" and a casual "what are you playing with in AI" | Medium. Openers are near-certain in a 60-minute conversation, and "AI experience a plus" makes the casual AI question scored | A 90-second arc; treat the casual AI question as scored | [generic] |
| Pressure / Stress | F | 2 | "How much of that was actually you?" and a 60-second why-you | Low to medium. Peers rarely run stress formats, but the attribution question arrives in collegial packaging from the Prober too | Pause, restate, hold the quoted position through two follow-ups, concede specifically | [generic] |
| Values / Behavioral | G | 2 | Open "tell me about a time" prompts | Low. Your account of the round is one conversation with a peer, so no values-style round is detected and no published values are in hand | Selection scaffolds with an honest branch | [generic] |

Highest-ROI prep in this pack: D1. It will be asked in some form, it sits on the one gap Priya has stated, and Dan's work is that exact territory. B1 and B2 are the next most worth the time.

## Question banks

### Bank A: Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between Sales Strategy and GTM for emerging products, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Do not pretend to know the seam; say you would want to learn how it works today. Then propose principles: one place where each decision gets made, shared definitions for the numbers each side reports, and escalation to the shared VP only after both sides have put their evidence on one page. One past beat, at its own scope: "I set annual volume targets with cross-org consensus." Answer slot: the JD's cross-functional line makes a probe on a disagreement within that work likely; if there was one, say what it was and what part of it was yours; if there was none, or it was not yours to resolve, say so plainly and stay with the consensus | F5 is the evidence for the cross-functional line, and a peer is the person who tests it. JD because it scores the stated requirement; Peer Evaluator because it arrives as a seam question |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the principle first: name each part and its owner, and say what was yours before anyone asks. Then the quote at its own scope: "I proposed a store-surface change that was credited with roughly a $400M ARR uplift." Answer slot: if others carried parts of getting it from proposal to result, name the parts and who held them; if you do not know who carried what, or it was not shared work, say so plainly and stay with the proposal | F2 is where a credit question has most to bite on. EXP because it tests attribution honesty; the credit-sharing stem is the Peer Evaluator's |
| A3 | "Sales Strategy has set a number for one of your new product lines and you think it's too aggressive. What do we do?" | CASE | [generic] | Structure it aloud: first ask how the number was built and what each side can see; agree what evidence would move each of you; split decision rights from input rights; take it to the shared VP only with both views on one page. Concede that you would want to see his method before judging the number. The question needs no claim about your past, so the guidance makes none | Targets are the live seam for a Sales Strategy peer and a GTM lead. CASE because it asks for reasoning on a problem from the role; `[generic]` because it is a pattern, not a fact about this employer |
| A4 | "What would you need from my team in your first ninety days, and what could you give us?" | JD | [grounded] "skilled in SQL/Tableau" | Asks first, as requests to learn rather than to receive: how Sales Strategy defines land, adopt, expand and renew today, what data you can query, and where pricing and packaging constraints sit. Gives second: "I'm skilled in SQL and Tableau," offered as joint analysis on the questions he already owns. Name one thing you would not touch until you understood it | Reciprocity is what a peer is pricing. F3 is the only quote that supports an offer; the JD's land/adopt/expand/renew wording is the vocabulary to borrow for the asks |
| A5 | "Enterprise expansion is a stated priority, and so is the Compass launch. Sellers have finite attention. Where does that trade-off live between your plan and my team's?" | CO | [grounded] your research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Use the stated priorities as the frame, not a view of Northwind's internals. Name the tension as a question of capacity: what share of seller time exists, what core expansion needs, what a new line needs to prove itself. Say what data you would pull first and who holds it. Concede you do not know current capacity or attach figures. The guidance makes no claim about your past | The user's note supplies the priorities, so this is the strategy-grounded CO question for the peer bank. CO because it tests altitude; the seam framing is why it sits here and not in bank C |

### Bank B: Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly $400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open with the quote at its own scope: you proposed the change, and the uplift was credited to it. Then the four defend-the-number slots, each in your own words. Answer slot: how it was counted; what it is sensitive to; the assumption behind it you would defend least, named before he asks; which part was yours. If you do not know how it was counted, say "I don't know how it was counted" and say who would. Never reconstruct a method you cannot repeat under a second question | F2's headline figure is the first thing a self-described data-driven peer reaches for. EXP because it tests whether the claim survives scrutiny; the weakest-assumption move is the type's own bar |
| B2 | "Credited by whom, and how did they know it was the change?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The honest answer lives in the word credited. Answer slot: if you know who credited it and how they separated the change from everything else, say so in your own words; if you do not know how the crediting was done, say so plainly. Hold: "I proposed it, and the credit was given to it" is the position; do not move it to "I drove it" under a second follow-up | The second level down on F2, asked because the first answer used the word credited. Kept separate from B1 so each can be drilled alone. EXP because it scores attribution |
| B3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to answer." | JD | [grounded] "skilled in SQL/Tableau" | Say the skill as quoted. Then choose the instance: one where you wrote the queries or built the view yourself, and a decision depended on it. Walk question, data, method, result, and the part of the result you would trust least. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it. Offer to go end to end | The JD's "independent analysis" line is the one piece of this role Dan can test directly. F3 is stated skill with no artifact behind it; the open prompt lets Priya choose the instance |
| B4 | "For a brand-new product line, which metrics would you use across land, adopt, expand and renew, and which would you distrust in the first two quarters?" | JD | [generic] | Structure by stage: for each, one leading and one lagging metric, with its denominator stated. Then the launch caveat: small samples, early cohorts, and metrics that move for reasons unrelated to the product. Name the one you would trust least and why. The guidance makes no claim about your past | The JD's lifecycle line, tested the way a data-driven peer would test it. JD with CASE delivery: it scores the requirement through a live design problem |
| B5 | "Tell me about the revenue model you built for the carrier negotiations. What was it for, and where would you expect it to be wrong?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats the quote states: you built it, it was partner-level, it was used in the negotiations. Tell them in your own words. Answer slot: the assumption in it you would defend least, named before he asks; if you do not know where it would be wrong, say so plainly. Stay with the model; do not widen it into the negotiations or the partner relationship | F4 is the pricing-adjacent evidence closest to Dan's native language, so it will be pulled. EXP because it tests what was actually built |

### Bank C: Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor is bundling. Design the GTM for a new line like Compass. What do you need to know first?" | CO | [grounded] your research note: "bundling by a much larger platform vendor" and "an AI copilot launch ('Compass')" | Clarify before structuring: who the buyer is, what is already in the customer's contract, what the bundled alternative actually includes. Then objective, segments, packaging choices to test (standalone, add-on, within an enterprise agreement), the value metric, and the risks. Challenge one premise respectfully, for example that the bundle is a like-for-like substitute. Concede what you cannot know without Northwind's data. The guidance makes no claim about your past | The research note names the main competitive threat and the launch; pricing and packaging is Dan's native ground. CO because it needs company altitude; CASE in delivery |
| C2 | "Profitability is a stated priority and you own two new lines. How do you decide where the investment goes, and what do you not fund?" | CASE | [grounded] your research note: "reaching profitability"; JD highlights: "own GTM strategy for two new product lines" | Say the criteria before the choice: size of the whitespace, time to evidence, cost to serve, dependence on core sellers. Propose a stage-gate with kill criteria agreed in advance. Say which number you would want first and its denominator. Concede that the answer depends on data you have not seen. The guidance makes no claim about your past | Two lines plus a profitability priority forces trade-offs, which is where a Sales Strategy peer will test judgment. Case because there is no right answer, only structure |
| C3 | "Adoption on a new line is strong but expansion revenue is flat. Diagnose it." | CASE | [generic] | Clarify definitions first: what counts as adopted and as expanded, over what window. Segment by customer size and cohort. Hypotheses to test, each with the cut that would confirm or kill it: packaging that caps expansion, a value metric that does not track usage, the wrong buyer, an expansion trigger that needs a seller who is not engaged. State what would change your mind. The guidance makes no claim about your past | The metric-dropped stem applied to the JD's land/adopt/expand/renew vocabulary. CASE because it scores clarify, structure and reasoning |

### Bank D: Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales ops or quota setting in your background. How do you earn credibility with a sales strategy team?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | The deepest rehearsal in the pack. Level 1, say the plain acknowledgment and stop: "I don't have classic sales-ops or quota-setting experience." Level 2, what your material does carry, at its own scope: "I set annual volume targets with cross-org consensus," and the model quote. Do not call the targets quotas. Level 3, a ramp plan as a plan: ask Dan to walk you through how Northwind builds its numbers, and say what you would read first. Follow-up one, "that's a different thing": concede it plainly; you are not claiming equivalence. Follow-up two, "what would you get wrong first?": name the one thing you expect to be slowest at, in your own words. Follow-up three, "would you rather we taught you or would you work it out?": answer with what you would ask of his team. Answer slot: if asked how the targets were set, say what you know; if you do not know the method, say so plainly | F7 is the one stated gap and Dan owns the territory it sits in. JD because it scores a competency the role touches; Skeptic because it is aimed at the gap. Named the highest-ROI prep in this pack |
| D2 | "Partner-motion design experience is required. What part of a partner motion have you designed yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any decision about how partners were worked with, beyond the model, was yours, say which and how you decided, in your own words; if there was no such decision, or it was not yours, say so plainly. The honest branch is a limit, not a confession. Hold through two follow-ups by returning to the model, never by adding to it. Then a ramp plan, said as a plan | F4 is where the "required" line presses hardest and the evidence only partly reaches. JD because it scores the stated requirement; the Skeptic stem "tell me what you have done of X" is the delivery |
| D3 | "What do you expect to be different about enterprise data infrastructure compared with what you've done, and where will you be slowest?" | JD | [generic] | A forward question; answer with hypotheses and tests, not claims about enterprise work you have not described. Name two differences you would check in your first weeks and how you would check them, and one place you expect to be slowest. Anchor on what the quote carries, "then 9 at a large consumer-tech company in product strategy & ops", at its own scope. If asked directly what business-customer exposure you have, answer only from what you did, and if there was none, say so plainly | F1's quote names the consumer setting and the role is enterprise; the Skeptic will test that jump. JD because the role's priorities include enterprise expansion; `[generic]` because the answer is a plan, not a fact about this employer |

### Bank E: Conversational / Rapport Builder (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quote states: two years of strategy consulting, then nine years in product strategy and ops at a large consumer-tech company. Then the turn to this role. Answer slot, the motivation: say in your own words why this role and why now; the pack does not supply it. End on a sentence that invites his view, not a recap | An opener is near-certain and scored for economy. F1 carries the career beats. EXP because it tests that the history is told at its own scope |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at scope: "I use AI tools daily." Answer slot: which tools and what for, in your own words; if the use is mostly for your own productivity, say so plainly. Do not describe building or launching AI products. A good close is a question back about how Compass is being measured | The JD lists AI as a plus, so the casual question is scored. F6 is the only quote available |

### Bank F: Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR number: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold: "I proposed the change, and the uplift was credited to it." Hold through two follow-ups by returning to that sentence. Concede specifically: what you do not claim, and what you do not know about how the credit was assigned. Answer slot: which part of getting it from proposal to result was yours, if any beyond the proposal; if none, say so plainly | The Pressure stem aimed at F2, the headline figure. EXP because it scores attribution under pressure; the hold-then-concede structure is the type's bar |
| F2 | "Sixty seconds: why you over someone who has carried a number?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau"; "uses AI tools daily" | Lead with the acknowledgment so the gap is not the thing he finds: "I don't have classic sales-ops or quota-setting experience." Then, each at its own scope: the model, the consensus targets, SQL/Tableau, daily AI use. Do not rank yourself above the other candidate; say what you bring and name one risk in your own words | A time-boxed why-you is the standard pressure format. JD because it scores the whole fit; it draws on F3 to F7 |

### Bank G: Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. Use "we" for context and "I" for what you did. Your notes show no such story, and the pack does not supply one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem for a values probe. VAL because it scores behavior; `[generic]` because no published values are in hand and no values-style round is detected |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: a named customer-facing stake, a metric that pointed the other way, what you chose, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not invent the metric or the outcome | Customer-first framing is useful with a sales-side peer. VAL for the same reason as G1 |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, A5, A3, E1 |
| "identify whitespace across land/adopt/expand/renew" | B4, C3, B1 |
| "run independent analysis in SQL and Tableau" | B3, B4, A4 |
| "partner-motion design experience required" | D2, B5 |
| "strong cross-functional influence" | A1, A2, A4 |
| "AI experience a plus" | E2, C1 |
| Sales ops and quota setting (gap you flagged) | D1, F2 |
| Published company values | — none, and why: no published values in hand and no values-style round detected; G1 and G2 are `[generic]` |

Type coverage: VAL G1, G2; EXP A2, B1, B2, B5, E1, F1; JD A1, A4, B3, B4, D1, D2, D3, E2, F2; CO A5, C1; CASE A3, C2, C3. Total 22 questions.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You've spent your career in pricing and monetization before this seat. What would you want my GTM work to fix or avoid in how new lines get priced?" | Tied to his own path; it speaks his native language and turns the Q&A into a peer conversation | [grounded] "career spine is pricing and monetization roles" |
| R2 | "You had an early-stage chapter before this. What do you still use from it here, and what did you have to unlearn?" | Tied to his path; invites a story, not a pitch | [grounded] "with one early-stage-startup chapter" |
| R3 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you are thinking about his load | [generic] |
| R4 | "Where do Sales Strategy and emerging-product GTM tend to collide today, and how has the VP set up resolving it?" | Asks about the seam directly, which a peer will have a view on | [generic] |
| R5 | "When a larger vendor bundles, where would the first signal show up in your data, and who owns reading it?" | Pairs the stated competitive threat with a data-driven interviewer's instincts | [grounded] your research note: "bundling by a much larger platform vendor" |
| R6 | "How are you thinking about measuring Compass in its first two quarters, leading indicators or revenue?" | Shows you read the launch as a measurement problem, in his register | [grounded] your research note: "an AI copilot launch ('Compass')" |
| R7 | "Which number on your dashboard do you trust least?" | A data-driven interviewer usually has a ready answer, and it shows what you would be inheriting | [generic] |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative you stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| Called the annual volume targets quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: your material says targets and consensus, not quotas. D1's slot stays inside the targets |
| Designed or ran a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says a model used in negotiations. D2's slot asks only what was yours beyond the model |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. B1 and F1's slots ask only the four defend-the-number questions |
| Has owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The limit is the pack's observation |
| Has built or launched AI products or features | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily" |

## Sources

Provided documents: your message (the JD highlights, the notes about Priya, the description of Dan's profile) and your research note on Northwind's priorities and competitive threat. No dossier was supplied.

Searches sent:

| Query | Outcome |
|---|---|
| Northwind Data company values | refused |
| Dan Kovac Northwind Data Director of Sales Strategy | refused |

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Search was refused. It would have moved G1 and G2 from `[generic]` to published-value questions; no values cheat sheet is built either way, because no values-style round is detected |
| 2. Northwind Data interview process, GTM strategy | skipped | Your words fix the loop (one 60-minute peer conversation), so persona weights and the bank structure would not change |
| 3. Northwind Data strategy and recent news | skipped | Your research note already supplies the priorities and the competitive frame that feed A5, C1 and C2 |
| 4. Dan Kovac Northwind Data | unavailable | Search was refused. It would have moved the interviewer read and R1 and R2; nothing beyond your description of his profile is established |
| 5. Representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the fit snapshot rows and the JD-tagged questions; the full JD text is in the upgrade menu |

## Upgrade menu

- The full JD text → the six JD highlight rows quote the JD itself, any requirement the highlights leave out gets its own row and question, and the coverage table is checked against the real list
- Priya's CV lines, verbatim → every row now resting on your notes quotes her CV instead; any claim there that is more specific than your summary raises a row's confidence or sharpens its bridge
- Priya's answers to the slots in F1, F2, F4 and F6, in her own words (what go-to-market work was hers, how the ~$400M was counted, what part of the partner work was hers, which AI tools and for what) → those four rows move from slots to quoted evidence, and B1, B2, D2 and E2 become story-mapped
- An inspectable artifact for the analysis row, such as a sanitized Tableau workbook or SQL sample, or a description of one analysis she ran → F3 moves from medium toward high, and B3 gets a real walkthrough
- Dan's talks, posts or interviews, if search is allowed → a fuller interviewer read and sharper reverse questions
- Northwind's published values and interview page, if search is allowed → G1 and G2 become published-value questions, and a values cheat sheet is added if a values-style round is documented
- Anything the recruiter said about this conversation, such as a case, a deliverable or focus areas (usually one email) → a build section for any graded deliverable, and persona weights checked against it
- How much prep time Priya has → a prioritized schedule: the few things done well, in order
- Deep research, up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Northwind's current segmentation language, numbers and recent moves, and a sharper bundling case for C1
- A tuesday-dossier.md from an earlier evaluation of this role, if one exists → verified evidence and the allowed strategies for the weak areas, in place of the inferred ones
