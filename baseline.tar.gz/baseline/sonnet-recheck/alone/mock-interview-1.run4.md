I'll read the skill's reference files before writing anything.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-1-denied-7c13ccd4/a4aa70cc-81d9-41b0-be8a-d0ea207ce4d4/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

It has 21 questions, weighted for a peer round with Dan:

| Persona | Questions |
|---|---|
| Peer Evaluator | 5 |
| Data-Driven Prober | 4 |
| Skeptic | 3 |
| Case/Strategist | 3 |
| Conversational | 2 |
| Pressure | 2 |
| Values | 2 |

- **Research:** both web searches (Northwind's values and Dan's public footprint) were refused, so none ran. The pack rests only on your message, and the interviewer read uses your description of Dan's profile. The Sources section accounts for each search.
- **Highest-ROI prep:** C1, the "no classic sales-ops or quota-setting" objection. It lands on ground Dan owns, and the pack gives it the most follow-up levels and the exact concession wording. The second priority is B1, defending the ~$400M ARR figure.
- **Quotas:** the pack never treats Priya's "annual volume targets" as quotas. The prohibited-claims section also keeps her from claiming she owned the ARR uplift, designed a partner motion, or has AI expertise beyond daily tool use.
- **Left out:** there is no values cheat sheet, because no values-style round is detected. There is no prep triage, because I don't know her prep time.

Say the word and I'll play Dan as the Skeptic on C1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. He is Priya's peer: both would report to the same VP.
- **Round:** one 60-minute conversation with Dan.
- **Built from:** the material in your message only. Both research searches were refused, so there is no web research behind this pack (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Every question carries both, so Priya can rehearse the delivery as well as the content.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the behavior asked about |
| EXP | Work-experience deep-dive: does a claim survive scrutiny, and what was actually hers |
| JD | Role and JD-driven: can she do the listed job, gaps included |
| CO | Company and strategy knowledge: can she think at Northwind's altitude |
| CASE | Hypothetical or live problem: structure and reasoning on a problem from the role |

- Guidance is scaffolding, not a script. Say it in your own words.
- Every claim about Priya's past in this pack rests on a sentence quoted from your message. Where the material is silent, the guidance is an **answer slot**: an instruction for the interview that she answers truthfully either way. A slot's second branch always allows that the practice never existed or was not hers.
- Question IDs run A, B, C, D, E, G, H by persona. The letter F is skipped so a question ID never collides with a fit-snapshot row (F1 to F7).

## Fit snapshot

The JD requirements are the JD highlights you gave me, not the full posting. Evidence quotes are your sentences about Priya, unchanged.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market ownership, and the words stay at that scope: nine years in product strategy and ops at a large consumer-tech company, after two years of strategy consulting. Answer slot: the JD's own-GTM line makes a probe on whether any of that strategy work was go-to-market likely. If any was, say what it covered and what part was yours, in your own words; if none was, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | transferability | The words at the quote's scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." The material shows a proposal on a consumer store surface, not a search for whitespace across a customer lifecycle. Answer slot: the JD names land, adopt, expand and renew, so expect a probe on whether your analysis there was organized by stage. If it was, say how, in your own words; if it was not, say so plainly and stay with the proposal. The figure itself raises the defend-the-number slots rehearsed in B1 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | discovery | The quote states a skill and shows nothing built with it, so the words stay there: "I'm skilled in SQL and Tableau." Answer slot: expect a request for a specific analysis. If you wrote the queries or built the views, say which and what question they answered; if others did that part, or your use was lighter, say so plainly and stay with the skill |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | The words at the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." The material shows the model, not the design of a partner motion. Answer slot: because the JD marks this as required, expect a probe on which part of how the negotiations were approached was yours to design. If any was, say which and what you decided; if none was, or nothing was designed, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: you set annual volume targets with cross-org consensus. Keep "cross-org" and "targets"; do not swap in the JD's "cross-functional" or call the targets quotas. How the consensus was reached is not in the material, so expect that follow-up; A2 rehearses it |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [inferred] | discovery | Derived from the quote plus the JD's plus-skill line. The quote says use, with no tools or purposes named, so it is a lead and not a story. Answer slot: if you use AI tools daily, name them and what you use them for, in your own words; if use is lighter or narrower than daily, say so plainly |
| F7 | Not a JD line: the sales-operations ground that Dan's function (Director of Sales Strategy) stands on — your message | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and your message states it. Words: "I don't have classic sales-ops or quota-setting experience." Then a ramp plan said as a plan and never as a past. Nothing is added to make the gap feel smaller, and F5's targets are not relabeled as quotas |

No JD highlight you gave me is a hard gate (a term such as location, authorization or travel). The full JD text could change that; see the upgrade menu.

## Reading the interviewer

Source: your description of Dan's profile, not independently checked. He describes himself as "relentlessly data-driven"; his career spine is pricing and monetization roles with one early-stage-startup chapter; he is now Director of Sales Strategy.

| Signal from the profile | What it means for this hour | Where it is rehearsed |
|---|---|---|
| Self-described "relentlessly data-driven" | Expect every number to be pushed to its assumptions, collegially. Know what you can and cannot say about how each figure was counted | B1, B2, B4 |
| Pricing and monetization spine | His native language is pricing, packaging and unit economics. Cases land best when they have a packaging or economics angle | D2, D3 |
| He runs the sales-strategy ground | The stated gap in F7 sits on territory he owns personally. Candor reads better than a bluff he can test in one follow-up | C1, G1 |
| One early-stage-startup chapter | He may test whether a lean, build-it-yourself setting suits you. Nothing in your material is startup experience, so no question assumes it; answer from the nearest thing your material carries, or say how you would work without big-company infrastructure | C3 |

Mirror opportunity: shared domain vocabulary, not a shared jump. His pricing and monetization spine pairs with F4's evidence, "built a partner-level revenue model used in carrier negotiations". No career jump is offered as shared, because neither his profile as described nor any evidence cell establishes a parallel move.

## Persona table

The round is a single 60-minute conversation with a peer, so the loop is fixed by your words and no archetype fallback applies. Weights start from the peer relationship prior (Peer Evaluator and Data-Driven Prober dominant) and move on Dan's signals above.

| Persona | Questions | Likelihood and reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator (A) | 5 | High. Peer prior puts it first; two people under one VP means the seam is a live topic | Seam-splitting, "what would you need from me", credit across teams, collegial returns of other objections | Reciprocity: say what you bring his team as well as what you need. Offer seam principles, not a pretended map. Disagreement answers that show spine and tact |
| Data-Driven Prober (B) | 4 | High. Peer prior, plus "relentlessly data-driven", plus a ~$400M figure in the background | Walks the CV line by line, asks how a number was counted, goes two follow-ups deep | Know what you can and cannot say about each figure; name the weakest assumption before he does; say plainly when you do not know |
| Skeptic (C) | 3 | Medium. Not a peer-prior persona; raised because F7 and F4 are gaps on ground Dan owns | Quiet, persistent probing of the missing sales-ops ground and the partner-motion line | Rehearse C1 until it is boring: acknowledge, hold what the quotes carry, concede specifically, give a ramp plan |
| Case / Strategist (D) | 3 | Medium. His pricing and monetization spine tilts toward pricing, packaging and unit-economics cases, and your research note supplies live material | A live problem from Northwind's priorities or the bundling threat | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational (E) | 2 | Medium-low. Peers open with the biography and ask casually about JD plus-skills | The journey question and an AI question in a friendly register | Pre-script the 90-second arc; treat the casual AI question as scored |
| Pressure (G) | 2 | Low. No signal of a stress style; this appears as devil's-advocate moments inside other banks | Time-boxed "why you" and "how much was actually you" | Pause, restate, anchor in what you stated, hold through two follow-ups, concede specifically |
| Values / Behavioral (H) | 2 | Low. One conversation with a peer, and no values-style round is detected: your words fix the loop and name none | A behavioral stem inside the conversation | Selection scaffolds with an honest branch; no published values were available to map |

Total: 21 questions (5, 4, 3, 3, 2, 2, 2).

## Question banks

### Requirement coverage

| Requirement | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C3, D1, D2, D3, E1, G1 |
| "identify whitespace across land/adopt/expand/renew" | D3, D2 |
| "run independent analysis in SQL and Tableau" | B3, B4 |
| "partner-motion design experience required" | C2, B2 |
| "strong cross-functional influence" | A1, A2, A4, A5 |
| "AI experience a plus" | E2 |
| Stated gap (F7), not a JD line | C1, G1 |

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side on these two lines. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles instead of pretending to know the seam: who decides what, which numbers both teams treat as the shared source, and what happens when you read them differently (both readings, side by side, to the shared VP). Ask him where the seam hurts today before proposing anything, then fit your emphasis to his answer. This answer makes no claim about your past | The JD's cross-functional line (F5) plus the peer relationship make this near-certain. JD because it scores the stated requirement; `[generic]` because it is a pattern for the problem, not a fact about Northwind |
| A2 | "You set annual volume targets with other orgs on board. How did you get to consensus?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5 with only the beats the quote states: annual volume targets, set by you, with consensus across orgs. Say it in the quote's terms, then stop and let him ask. Answer slot: expect a probe on how the consensus was reached. If you know, say what you did and what the other orgs did, in your own words; if the consensus formed mostly elsewhere, or was routine, say so plainly and return to the targets and the consensus | F5 is the evidence for the JD's influence line, and a peer prices how you work with other teams. EXP because it tests what was actually hers |
| A3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | This is an open prompt, so choose the instance. The proposal can be your story only if it fits: the quote's beats are that you proposed the change and the uplift was credited to it. Answer slot: who else shaped the change or its result, in your own words; if the result was mostly others' work, or you do not know who assigned the credit, say so plainly and stay with the proposal. If no instance comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would split credit | A peer asks credit-sharing questions to see whether the hire adds to or lightens his load. F2 is the only row with a credit-shaped claim; EXP because the scoring is attribution honesty |
| A4 | "We size the whitespace for one of the lines differently, and my number is higher. How do we settle it?" | CASE | [generic] | Structure aloud: what each number counts (definition, scope, time frame); put both on the same data; find the assumption that moves the gap; agree which decision hinges on it; if still apart, take both readings with ranges to the VP. Data first suits a self-described data-driven peer. No claim about your past | Tests disagreement style with an equal, on his preferred ground. CASE because it is a live problem; `[generic]` because it presupposes nothing about Northwind or you |
| A5 | "What would you need from my team in your first 30 days, and what would you bring us?" | JD | [grounded] "skilled in SQL/Tableau" | Two halves. Need: the access and definitions you would want first, chosen from what is true for you. Bring: what you are skilled in, in the quote's words, and an offer to work through his team's open questions with him, framed as a plan and not a past. Nothing more about your history belongs in this answer | The reciprocity probe: a peer is pricing what you cost and contribute. F3 is the only evidence that fits as an offer; JD because it scores the cross-functional requirement |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what you proposed in the quote's terms: you proposed the change and the uplift was credited to it. Then four answer slots, each in your own words and each honest either way. How the figure was counted, and by whom if you know. What it is most sensitive to. The assumption behind it you would defend least, named before he does. Which part was yours and which was others'. If you do not know how it was counted, say so plainly; that beats a method you cannot repeat under a second question | The headline number in front of a self-described data-driven interviewer: this is the defend-the-number question. EXP because it tests whether the claim survives, from F2 |
| B2 | "Which assumption in your partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what it was in the quote's terms: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: name the assumption you would defend least, in your own words, before he asks twice; if you cannot name one, or the inputs were not yours, say so plainly and return to the model. Do not describe the model's structure or how negotiators used it beyond the quote | F4 is a modelling claim, and a prober goes after the assumptions. EXP because it tests what she knows about her own work |
| B3 | "Tell me about an analysis you ran in SQL or Tableau. What was the question, and what did the answer change?" | JD | [grounded] "skilled in SQL/Tableau" | The quote carries a skill and no story, so choose one: an analysis where you wrote the query or built the view yourself, for a question someone needed answered, that touched a decision. Expect the data-definition follow-up: where the data came from and what it left out. If no such analysis comes to mind, say so plainly, then say what you are skilled in, in the quote's words, and how you would start a whitespace question here | The JD lists independent SQL and Tableau analysis (F3), and Dan can test it directly. JD because it scores the stated requirement; the open prompt takes its theme from the JD line |
| B4 | "A new product line has no sales history. How would you set its first-year volume target?" | CASE | [grounded] "set annual volume targets with cross-org consensus" | Structure: what the target is for and who it binds; what comparables exist (adjacent products, similar launches, partner capacity); a range with the weakest assumption said aloud; a review trigger; who has to agree. One sentence may point to the quote, "I set annual volume targets with cross-org consensus", but the quote does not say whether history existed, so do not call it the same problem | Targets and unit economics are in his territory, and the question joins the data-driven signal to F5. CASE because it is a live problem; the quote is only an optional anchor |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background doesn't include classic sales-ops or quota-setting, and this role works right next to my team. How do you close that?" | JD | [grounded] "No classic sales-ops or quota-setting experience" "set annual volume targets with cross-org consensus" "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI rehearsal in the pack.** Beat 1, acknowledge, flat and first: "I don't have classic sales-ops or quota-setting experience." Beat 2, hold only what the quotes carry: you set annual volume targets with cross-org consensus, and you built a partner-level revenue model used in carrier negotiations. Beat 3, a ramp plan in the future tense, with the people and first questions your own: whom in his team you would sit with first. Follow-up 1, "targets aren't quotas": concede the label ("I'm not claiming they're the same thing"), then the slot: say what the targets covered and what part of setting them was yours; if they were a different kind of thing from his work, say so plainly. Follow-up 2, "what would you get wrong first?": name one real learning item of your choosing, specifically; do not fold on the two sentences you are holding. Follow-up 3, "why not hire someone who has done it?": agree that is a real option, return to the same two sentences, and name where his team fills your gap. The limit, named before it is asked for: the material shows targets and a model, not quota work. Hold by returning to those sentences, never by adding to them | F7 is the biggest gap in the pack, on ground Dan owns, so this objection arrives in some form. JD because it scores the role's working-alongside-sales demands, Pressure in delivery; given the most follow-up levels and the exact concession wording because it is the most predictable question |
| C2 | "Partner-motion design is a required part of this role. What part of a partner motion have you shaped yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you shaped any part of how those negotiations were approached, say which part and what you decided, in your own words; if none was yours, or nothing was designed, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it. The limit is the pack's observation: your material says the model, not the motion | The JD marks this requirement as required, and F4 is the nearest evidence. JD because it scores a stated requirement; the question's premise is the JD's, and the guidance does not adopt it |
| C3 | "You've spent nine years at a large consumer-tech company. Why a B2B data-infrastructure SaaS, and why now?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The quote supplies the career fact and no motive, so the reason has to be yours. Selection scaffold: pick your true reason, tie it to something you can point to (the role's mandate to own GTM strategy for two new lines, or Northwind's priorities from your research note), and name what you give up. Avoid reasons that are only about leaving. If your honest reason does not fit the role cleanly, say so plainly and say what in the role does pull you | The standard why-here-why-now probe from a skeptic, sharpened for a move from consumer to B2B and an emerging-products role (F1). JD because it scores motivation fit with the role |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our priorities are enterprise expansion, the Compass launch and getting to profitability. Where do you think these two lines fit among them?" | CO | [inferred] | Name the three priorities to show grounding, then take a position instead of reciting them. Two thesis options; adopt only one you believe. One: profitability limits how much new-line sales capacity can be absorbed, so lead with the line that can be sold into existing enterprise accounts; concession: you do not have Northwind's unit economics. Two: bundling by a much larger platform vendor makes expansion inside existing accounts a more defensible first move than a net-new push; concession: you do not know how exposed Northwind's accounts are. Anti-pick: say what you would not do first, and why. Ask whether Compass is one of the two lines instead of assuming it. No claim about your past | Derived from the three priorities and the bundling threat in your research note. Any prepared candidate can recite the note, so the pack coaches one consensus item and then a thesis with a concession and an anti-pick. CO because it scores strategy fluency |
| D2 | "The main threat we face is bundling by a much larger platform vendor. How does that shape the go-to-market for a new product like Compass?" | CASE | [inferred] | Clarify first: what is being bundled, which accounts are exposed, whether the buyer is the same, and whether Compass is one of the two lines. Objective, then segments (installed base against new, by land, adopt, expand, renew), then approach with a packaging and price angle (standalone against attached; what a bundler's free offer does to willingness to pay), then metrics (win rate where the bundler is present, attach in existing accounts, price realization), then risks. Challenge one premise politely: is bundling mainly a price threat or a distribution threat? No claim about your past | Built from the threat and the product name in your research note, in Dan's pricing and packaging language. CASE because it is a live problem; CO is the second tag because it uses Northwind's own frame |
| D3 | "We have two new lines and finite sales capacity. Where do you look first for whitespace across land, adopt, expand and renew?" | CASE | [grounded] | Clarify the objective against the priorities (enterprise expansion, profitability). Define a metric per stage. Segment the base. Give a hypothesis per stage. Say which SQL cuts you would run first, as a plan and not a past. Rank by size, ease and margin, and name the weakest assumption aloud. No claim about your past | The question is the JD's whitespace line (F2) turned into a live problem, with the priorities from your research note as constraints. CASE because it scores structure; the JD's land/adopt/expand/renew wording is the reason it is certain to be tested |

### E. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc in beats the quote states: two years of strategy consulting at a top firm; then nine years in product strategy and ops at a large consumer-tech company; then why this role, in your own words (C3). Add at most one highlight at its own scope, from "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus" or "proposed a store-surface change credited with a ~$400M ARR uplift". Pick the one you can answer two follow-ups on | The casual opener is scored. F1 is the career spine; EXP because every clause is a lead he can pull |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] | F6 is a thin, low-confidence line, so the pack does not script it. Answer slot: if you use AI tools daily, name them and what you use them for, in your own words, with an example of something it changed in your work only if you have one; if use is lighter or narrower than daily, say so plainly. Do not describe building AI products or models; the material says use. Then ask what Compass is trying to do, since you would rather learn it from him | The JD lists AI experience as a plus, and casual questions on plus-skills are scored. Derived from the quote plus the JD line; JD because it scores a stated requirement |

### G. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has run sales strategy for years?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "No classic sales-ops or quota-setting experience" | Pause and restate the question. Three beats at the quotes' scope: nine years in product strategy and ops; a partner-level revenue model used in carrier negotiations; annual volume targets set with cross-org consensus. Hold through two follow-ups. When he says it is not sales strategy, concede plainly: "I don't have classic sales-ops or quota-setting experience." Then return to the same three beats. Never fold on them, and never add to them | The time-boxed comparison a pressure interviewer uses, aimed at F7. JD because it scores fit against the role; the delivery is the test |
| G2 | "That ~$400M result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and the uplift was credited to it." That sentence is the position. Answer slot: which part of what happened after the proposal was yours, in your own words; if the rest was others' work, or you do not know how the credit was assigned, say so plainly. Concede specifically, naming what you do not know about the figure, and do not fold on the proposal itself | B1 asks how the figure was counted; this asks the attribution under pressure. F2 is the evidence, EXP because it tests attribution honesty |

### H. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | None of your quoted sentences carries this story, so pick one. It needs a named stake, a moment you did not soften, and what the relationship looked like afterward; choose a story where the truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would handle it | A standard behavioral stem. VAL, `[generic]` and low weight, because no values-style round is detected and no published Northwind values were available to map |
| H2 | "When did you put a customer or a partner outcome ahead of an internal number?" | VAL | [generic] | Selection scaffold: pick a time the outcome for an outside party and an internal number pulled apart, with the decision you made and its cost to you. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or say how you would decide | Same reasoning as H1: a stem a peer may use, kept at low weight and labeled generic |

## Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization roles with an early-stage chapter. What did that chapter change about how you plan sales strategy for products that have no history yet?" | Ties to his own path (as described), and emerging products are the topic of this role. It turns an interrogation into a peer conversation |
| R2 | "For the two new lines, where does your team's remit end and this role's begin, and what is the escalation when we read the numbers differently?" | Shows you are thinking about the seam as a working problem, not as turf |
| R3 | "What is one thing a new person on my side could do in the first month that would genuinely help your team?" | The reciprocity question for a peer: it signals you are pricing your contribution to his work |
| R4 | "Which definitions or datasets do you most wish both our teams shared?" | For a self-described data-driven peer, shared definitions are the practical concern |
| R5 | "How is the bundling pressure showing up in the deals your team sees, and what do you wish GTM had a better answer to?" | Uses your research note's competitive frame and invites his view instead of asserting yours |
| R6 | "What would make the VP say in six months that this hire changed outcomes for these two lines?" | Surfaces the shared boss's yardstick, which you both answer to |

## Prohibited claims

Built from the fit snapshot before the banks were written. Nothing in the pack coaches these, and no slot, hold or bridge asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having sales-ops or quota-setting experience | Negative your message states, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Treating the annual volume targets as quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus." The limit is the pack's observation: the material says targets, not quotas |
| Having strong cross-functional influence as an established fact | Inflated form of F5 against the JD line | The same quote at its own scope; A2's slot asks only how the consensus was reached |
| Owning, driving or delivering the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The material says proposed and credited, not delivered. B1 and G2 ask only how it was counted, its sensitivity, the weakest assumption and which part was hers |
| Leading or conducting the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: a model used in the negotiations |
| Having designed a partner motion | Inflated form of F4 against the JD's required line | The same quote; C2's slot asks only whether any part of how the negotiations were approached was hers |
| Owning GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops, after strategy consulting |
| Building or shipping AI products, or having AI or ML expertise | Inflated form of F6 | F6's quote at its own scope: it says use |
| Having run independent end-to-end analysis in SQL and Tableau | Inflated form of F3 against the JD line | F3's quote at its own scope: skilled in SQL and Tableau. B3's slot asks what she has used the tools for |

## Sources

Provided documents: your message, containing the role and JD highlights, the candidate summary, the description of Dan's profile, and your research note on Northwind's priorities and the bundling threat. No `tuesday-dossier.md` was present.

Searches sent (both refused; the permission was not granted, so nothing came back):

- "Northwind Data company values" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Both calls were refused. It would have named published values for H1 and H2; they stay `[generic]`. Section 10 stays out regardless, because no values-style round is detected |
| 2. `Northwind Data interview process, strategy and sales roles` | skipped | Your words fix the loop: one 60-minute conversation with a peer. Persona weights follow from it |
| 3. `Northwind Data strategy` and recent news | skipped | Your research note already supplies the three priorities and the bundling threat that feed D1 and D2 |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. The interviewer read rests on your description of his profile only; talks or writing could have added questions and a reverse question |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you gave fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- Search permission, then "go deeper" → a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) would add Dan's talks and writing, a strategy brief on Northwind for D1 and D2, and loop reports. The two refused searches above would also run: published values for H1 and H2, and Dan's public footprint for the interviewer read and R1
- The full JD text → the six JD rows quote the posting itself instead of your highlights, mid-list requirements get their own questions, and any gate term (location, travel, authorization) is surfaced
- Priya's CV, or her own answers to the slots in F1, F2, F3, F4, F6 and F7's ramp plan → those rows move from `discovery` and `transferability` toward `presentation` or `none`, and the guidance gets real beats instead of slots
- A written account of how the ~$400M ARR was counted, such as the impact readout or the sign-off that credited the uplift → F2 moves from `medium` toward `high`, and B1 and G2 get an exact, sourced answer
- The recruiter's prep email → coverage of any pre-declared case or deliverable, and whether Dan's hour is conversation only
- The time Priya has to prepare → a prioritized schedule sized to it
- A `tuesday-dossier.md` from an earlier evidence-recovery pass, if one exists → verified evidence and absolute prohibited claims would replace the ones built locally from your message
