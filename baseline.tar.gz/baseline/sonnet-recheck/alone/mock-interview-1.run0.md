I'll read the reference files the skill requires before writing anything.
Web searches were refused here, so every company fact in the pack comes from your research note. I'm writing the pack now.
Brackets appear only as provenance labels. Now I'll send the file.
Priya's prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-1-denied-97896810/4e1863fe-86fe-4d9b-95a0-045285ef9ca6/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. I built it for one 60-minute peer conversation with Dan, using only your message. The web searches I tried (company values, interview process, Dan's footprint) were refused. So the pack has no fresh research, and the Sources section says which targets were unavailable.

The pack has 22 questions, weighted to a peer who calls himself data-driven:
- **Data-Driven Prober:** 5 questions.
- **Peer Evaluator:** 5 questions.
- **Case/Strategist:** 4 questions.
- **Skeptic:** 3 questions.
- **Conversational:** 3 questions.
- **Pressure:** 2 questions.

Each question has a type tag, answer guidance, and a rationale. The pack also has the fit snapshot, the interviewer read, a persona table with the weighting reasoning, six reverse questions, and a list of claims it won't coach.

The most important prep is D1, the "no sales-ops or quota-setting background" question. It's the one gap you flagged and it sits in Dan's own territory. Second is A1, the ~$400M ARR figure, since Dan will likely walk it back to its inputs.

I left out the values cheat sheet because no values round was described. I also left out the prep schedule, deliverable and delivery-coaching sections because you gave no prep time, deliverable or assessment.

Say the word and I'll play Dan on D1, with follow-ups that react to what Priya says, then give feedback against that question's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD? It would let me check the coverage table against its mid-list items, which your highlights may omit.
Did the recruiter name any focus areas or pre-work for the conversation? A graded deliverable would add its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data. He is Priya's peer: both would report to the same VP.
- **Round:** one 60-minute conversation with Dan. No other rounds were described, so this is a single-session pack.
- **Built on:** your message (JD highlights, Priya's background, Dan's profile as you relayed it, your research note on Northwind's priorities). Web searches were refused in this session, so nothing here comes from fresh research. See Sources.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type tag | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No VAL questions appear: no values-style round was described, and no published values could be retrieved |
| EXP | Whether a claim survives scrutiny, and what was actually yours |
| JD | The stated responsibilities and qualifications, gaps included |
| CO | Knowledge of the company's strategy and competition |
| CASE | Structure and reasoning on a live problem from the role |

- **Answer slots** are instructions for the interview, not questions for this conversation. Each lets you answer truthfully either way: say how it went, or say plainly that the practice was not yours or never existed.
- **Highest-ROI prep:** D1 (the sales-ops and quota-setting gap). It is the one gap you flagged, it sits in the territory Dan works in every day, and it will arrive in some form. Rehearse it until it is boring. Second: A1 (the ~$400M figure), because Dan describes himself as data-driven.

## Fit snapshot

Evidence is quoted exactly from your message. Requirements come from the JD highlights you gave, not the full JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy & ops, not go-to-market for a product line, with nothing inspected behind it. The words stay at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's own-the-strategy line makes a probe on how a product reached its customers likely. If any of your product strategy & ops work dealt with that, say what and which part was yours, in your own words; if none did, say so plainly and stay with product strategy & ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The quote shows a proposal credited with an uplift. It does not show which of land, adopt, expand or renew the change sat in, or how the opportunity was found. The words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD names four stages, so expect a probe on which one this sat in. If it sat in one or more, say which and how the opportunity was spotted, in your own words; if it mapped to none, or you do not know how it was spotted, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap on paper, but a stated skill with nothing inspected behind it, so expect a show-me probe from a self-described data-driven peer. Lead in the quote's terms: "I'm skilled in SQL/Tableau." A2 rehearses the probe |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a motion. The words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's partner requirement makes a probe on how far the model reached likely. If it shaped anything beyond the negotiations it was used in, say what and which part was yours, in your own words; if it did not, or others shaped it, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a notes-level line, so expect a probe on how consensus formed. Lead with it in the quote's terms: "I set annual volume targets with cross-org consensus." Say targets, as your material does, never quotas. A4 and B2 rehearse the probes |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: "I use AI tools daily." It says use, not building, and the bridge adds nothing to that |
| F7 | Sales-ops and quota-setting fluency expected next to a sales-strategy peer (role-family expectation, no JD line) | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [generic] | capability | A gap wording cannot close, and it was stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to that work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Public footprint only, and here only what your message relayed. I could not check any of it (searches were refused).

| Signal | Source | What it implies for the prep | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Dan's profile, as you relayed it | Every number gets walked back to its inputs. Name the weakest assumption before he does (A1, A4, G1) | [inferred] |
| Career spine in pricing and monetization roles | Dan's profile, as you relayed it | Pricing, packaging and bundling are his native language, so expect cases tilted that way (C1, C3). Your material shows no pricing or packaging work, so ask in his terms and claim nothing | [inferred] |
| One early-stage-startup chapter | Dan's profile, as you relayed it | Expect questions about operating without a playbook (C2, C3). Your material carries no startup or 0-to-1 story, so none is offered | [inferred] |
| Peer, same VP | Your message | He is pricing what you cost and add to his work. Reciprocity and seam principles matter (B1, B3, reverse questions) | [inferred] |
| Mirror opportunity: shared vocabulary of revenue and monetization | Dan's pricing and monetization spine, beside F4's "built a partner-level revenue model used in carrier negotiations" | Use his word, revenue, when describing that model. No shared career jump is established, so none is offered | [inferred] |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (A, 5 questions) | Reads the notes line by line, asks for inputs and assumptions, goes two levels deep | High. The peer prior includes it, and his "relentlessly data-driven" self-description pushes it up | Know what you can and cannot say about how each number was counted, and say plainly when you do not know. Offer to walk through an analysis end to end (A1, A2, A4) |
| Peer Evaluator (B, 5 questions) | Seam-splitting, "what would you need from me", credit-sharing, disagreement style | High. He is a peer, so he is pricing what you add to his work | Reciprocity framing. Propose seam principles rather than pretend to know the seam (B1, B3) |
| Case/Strategist (C, 4 questions) | Live problems from the role, tilted to pricing, packaging and bundling | Medium. Not the peer prior, but his pricing spine and the bundling threat in your research note pull cases in | Clarify, objective, segmentation, approach, metrics, risks. Think aloud, challenge one premise respectfully (C1 to C4) |
| Skeptic (D, 3 questions) | Quiet, persistent probing of the background mismatch and the motivation | Medium. The stated gap (F7) and the consumer-to-B2B move invite it in collegial packaging | Rehearse D1 until it is boring. Bridges only from quoted sentences, plus a plan |
| Conversational (E, 3 questions) | Journey question, "what are you playing with in AI", "why us" | Medium. Any 60-minute conversation opens this way, and these questions are still scored | A 90-second arc (E1). Treat casual JD-plus questions as scored (E2) |
| Pressure (G, 2 questions) | Time-boxed attribution and "why you" challenges | Low. No relationship prior or interviewer signal points to it, but attribution probes can turn sharp inside a prober's follow-ups | Pause, restate, hold the position through two follow-ups, concede specifically (G1, G2) |

Values/Behavioral is omitted: no values-style round was described and no published values could be retrieved.

## Question banks

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C2, C3, D2, D3 |
| identify whitespace across land/adopt/expand/renew | A3, C2, C4 |
| run independent analysis in SQL and Tableau | A2, B3, C4 |
| partner-motion design experience required | A5, B4, D2 |
| strong cross-functional influence | A4, B2, B5 |
| AI experience a plus | E2, C2 |
| Sales-ops and quota-setting fluency (F7, not a JD line) | D1, G2 |

### A. Data-Driven Prober (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open on the sentence at its own scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Keep "proposed" and "credited with"; do not say drove, delivered or owned. Then three answer slots, each in your own words: how the figure was counted; what it is most sensitive to; the assumption behind it you would defend least, named before he asks. If you do not know how it was counted, say so plainly. Answer slot: if any part beyond the proposal was yours, say which; if none was, say so and stay with the proposal. Rehearse each answer through a second follow-up | F2 holds the only dollar figure in the material, and the interviewer self-describes as data-driven, so this probe is close to certain. EXP because it tests whether the claim survives and what was actually yours |
| A2 | "Take me through an analysis in SQL or Tableau that you ran yourself, start to finish." | EXP | [grounded] "skilled in SQL/Tableau" | Say "I'm skilled in SQL/Tableau," then choose one analysis you ran end to end. Selection criteria: it answered a question someone needed answered, you can say what data it used, and you can say what you would do differently. Offer to walk it through from raw data to decision. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach one | F3 is a stated skill with nothing inspected, and the JD says independent analysis. EXP because the probe checks the skill by asking for the instance, which is how a data-driven peer verifies it |
| A3 | "How would you go about finding whitespace across land, adopt, expand and renew for a product line with no sales history yet?" | JD | [grounded] | Makes no claim about your past. Clarify first: how Northwind defines each stage and what data exists today. State the objective, then give one hypothesis and one metric per stage, and name the metric you would trust least and why. Say what your first query would look like and what you would do if the data is not there. Close by asking how his team sees these stages today | F2's requirement as a live method question. JD because it scores the stated responsibility; the delivery is case-like because a data-driven peer asks for method |
| A4 | "Tell me about setting those annual volume targets." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say it at its own scope: "I set annual volume targets with cross-org consensus." Use the word targets, never quotas. Answer slot: the JD's cross-functional line makes a probe on how consensus formed likely. If the orgs disagreed, say about what and what moved them, in your own words; if agreement came without disagreement, or the work was not yours alone, say so plainly and stay with the targets | F5 supports the cross-functional requirement, and a peer from sales strategy will hear "targets" and compare them to quotas. EXP because it tests what was actually yours; the JD content is why it is likely |
| A5 | "Tell me about the revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states, told in your own words: the model, built at partner level, used in carrier negotiations. Answer slot: the JD's partner requirement makes a probe on how far the model reached likely. If it shaped anything beyond the negotiations, say what and which part was yours; if it did not, or others shaped it, say so plainly and stay with the model. If you can, say what you would defend least about it | F4 is the nearest evidence to the partner requirement. EXP because it opens on the candidate's own claim; the JD gives the follow-up its edge |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where do you think the seam is between sales strategy and this role, and what happens when we disagree?" | JD | [grounded] | Makes no claim about your past. You cannot know today's boundary, so ask how it works now. Then offer principles: shared definitions of the lifecycle stages and metrics before any dispute; disagreements settled on data both sides accept; neither side surprised by the other's numbers; the shared VP as a last step with both views written down, not the first. Close with what you would bring to his team | The relationship comes from your message. JD because it tests how the role fits beside his, and peers ask it to price their own load |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | Two quoted sentences could carry this; choose the one you can tell truthfully. Beats each states: targets set with consensus across orgs; a change proposed and credited with an uplift. Answer slot: if credit was shared and you remember how it was divided, say how and which part was yours; if credit never came up, or the work was not yours alone, say so plainly and stay with the sentence | F5 and F2 both involve work spanning groups. EXP because it tests attribution honesty, and a peer asks it collegially |
| B3 | "What would you need from me in your first week?" | JD | [grounded] "skilled in SQL/Tableau" | Three specific asks tied to the role: access to the data behind these product lines; how your team currently defines the lifecycle stages; who owns the existing partner relationships. Then reciprocity: "I'm skilled in SQL/Tableau, so I would come back with analysis, not just requests." Keep it a plan | Reciprocity is what a peer is scoring. F3 supplies the one thing you can offer his team at its own scope |
| B4 | "Partners matter a lot here. Where is your own experience closest to a partner motion?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." The material shows the model, not a motion; say so as your own observation of its limit. Answer slot: if any part of how partners were structured or handled was yours, say which and how you decided; if none was, say so plainly and stay with the model. The honest branch is a limit, not a confession. Hold through two follow-ups by returning to the model, never by adding to it | F4 is the JD's "required" line and the thinnest direct match, so it comes back in collegial packaging. JD because it scores a stated requirement |
| B5 | "Tell me about a time you changed a senior stakeholder's mind with data." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Selection criteria: a named stake, your position, the evidence you brought, what changed and what happened to the relationship. Your material does not show such a moment. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is setting annual volume targets with cross-org consensus, or how you would handle it | Persona stem on disagreement with equals, themed by the JD's influence line (F5). EXP because it asks for an instance; the scaffold exists because no quote carries one |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a capability that overlaps one of our new products. How do you think about positioning, and what do you want to know first?" | CASE | [grounded] | Makes no claim about your past. Clarify first: which customers overlap, where Northwind wins unbundled, and what a bundle does to willingness to pay. Structure it as objective, segments, approach, metrics, risks. Ask in his pricing terms rather than claiming pricing experience. Challenge one premise respectfully, for example whether the bundled capability is a true substitute | Bundling by a much larger platform vendor is the competitive threat in your research note, and pricing and packaging are his native area. CASE because it is a live problem; CO is the second tag |
| C2 | "Compass is launching as an AI copilot. If you were sketching its land, adopt, expand and renew plan, what would you need to know first?" | CASE | [grounded] | Makes no claim about your past. Clarify: is Compass sold standalone, bundled into existing contracts, or priced by use? Who is the first buyer? Then one hypothesis and one metric per stage, and name the assumption in your own plan you trust least. Curiosity about the product is part of the answer. If you use AI tools daily, that is a fact about you, not a qualification for this launch | Compass is a stated priority in your research note, and it fuses the JD's lifecycle and AI lines. CASE because it is a plan sketch; CO is the second tag |
| C3 | "Profitability and enterprise expansion are both priorities. How does that change how you would sequence investment across two new product lines?" | CO | [grounded] | Makes no claim about your past. State the tension first, then your hypothesis early. Ask what the profitability target is. Propose gating investment on leading indicators, and name the risk of under-investing in expansion. Say what you would want from his team's data | Two of the three priorities in your research note pull in opposite directions, and this role owns two new lines. CO because it tests altitude on current strategy; CASE is the second tag |
| C4 | "Expansion revenue on a product line drops twenty percent quarter on quarter. Diagnose it." | CASE | [generic] | Makes no claim about your past. Clarify the definition and the period, then segment before you theorize: by customer size, cohort, product, region, motion. Name the first cuts you would run and what each result would change. State what you would not conclude yet | Persona stem for a data-driven interviewer, and a natural place for him to check the SQL/Tableau line (F3). CASE because it is a live diagnosis |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background is product strategy and ops on the consumer side, and classic sales-ops and quota-setting aren't in it. Where would that show up as a gap in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep.** Level 1, name the limit before it is pressed: "I haven't had classic sales-ops or quota-setting experience." Say it once, plainly, no apology. Then the nearest thing your material carries at its own scope: "I set annual volume targets with cross-org consensus." Targets, not quotas. Level 2, "How would you ramp?": a plan, never a past. Say what you would learn first and from whom, for example how quotas and capacity are set at Northwind today and who does it. Level 3, "What if your consumer instincts don't transfer?": hold the sentence you can back, "I built a partner-level revenue model used in carrier negotiations," and concede specifically: some instincts will not transfer, and you would test them against Northwind's data before relying on them. Do not fold on the core claim to restore harmony, and do not claim to understand his motion better than he does | F7 is the one gap stated in your notes and sits in his daily territory. JD because it scores fit against the role; the Skeptic delivery is why it gets the most follow-up levels in the pack |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Pick the line where your material is adjacent rather than direct, and say it honestly. Candidates from the material: the partner requirement (F4, where the quote is a model) or owning go-to-market for new product lines (F1, where the quote is product strategy & ops). Name the line, say what you did carry using the quoted sentence at its own scope, and give a ramp as a plan. Answer slot: if your experience is closer to the line than the quotes show, say so in your own words and choose a different weakest part; if you would honestly be weakest elsewhere, say that | Persona stem. Choosing a real weakness with a ramp reads as calibrated candor. JD because it asks you to rank the stated requirements |
| D3 | "You have spent nine years at one large consumer-tech company. What makes you think you can do this at a B2B data-infrastructure company with no playbook?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Concede the shift is real, in one sentence. Then what carries, at the sentence's scope: nine years in product strategy & ops at a large consumer-tech company, after two years of strategy consulting. Answer slot on motivation: say in your own words why B2B data infrastructure and why now. The pack has no material on this, so work it out before the interview; if you cannot yet, say what you are still weighing, plainly | Consumer-to-B2B plus a startup-flavoured peer is a predictable probe. JD because it tests fit with the role's context; the motivation part is why the Skeptic frame fits |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy & ops. Answer slot: close on why this role and why now, in your own words. End by pointing at the JD's lifecycle language so the arc lands on his question | Almost every conversation opens here and it is scored. EXP because it is the CV told aloud |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say "I use AI tools daily." Answer slot: say which tools, in your own words, and one real way you use them; if the use is routine rather than a project, say so plainly. Do not suggest AI product experience your material does not carry. Ask what Compass does that a general copilot does not | Persona stem for the JD's AI plus (F6), asked casually and still scored. JD because it checks a stated plus |
| E3 | "What do you know about Northwind, and why us?" | CO | [grounded] | Makes no claim about your past. Use the three priorities from your research note: enterprise expansion, the Compass launch, profitability. Add the bundling threat. Give one thesis you would defend rather than reciting, for example that bundling raises the weight of adopt, expand and renew, and say what would change your mind. Refresh the note before the interview; it could not be re-checked here. Then your own why, in your own words | Differentiate from a source any prepared candidate has: bring the consensus item, then one divergence. CO because it tests homework depth and altitude |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, then hold: "I proposed the change; it was credited with a ~$400M ARR uplift." Concede specifically: what you do not know about how the crediting was done, and that others carried the change after the proposal if that is true. Answer slot: if any part beyond the proposal was yours, say which; if none, say so plainly. Follow-up 1, "So who decided?": answer only what you know. Follow-up 2, "Would it have happened without you?": do not claim a counterfactual you cannot support | Persona stem. F2's figure is the likeliest target of an attribution challenge, and hold-then-concede is the type's bar |
| G2 | "Sixty seconds: why you over a candidate who has run sales strategy?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau"; "set annual volume targets with cross-org consensus" | Concede first, briefly: "I haven't had classic sales-ops or quota-setting experience." Then what you bring, each at its own scope: "I built a partner-level revenue model used in carrier negotiations," "I'm skilled in SQL/Tableau," "I set annual volume targets with cross-org consensus." Close on how you would ramp. Do not claim to be better; state the fit and let him weigh it | Persona stem adapted to the gap in F7. JD because it scores fit against the role, in a time-boxed pressure format |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your career has been in pricing and monetization, with an early-stage chapter. How did that chapter change how you think about launching something with no pricing history?" | Tied to his path from your message; it turns an interrogation into a peer conversation and speaks directly to the two new lines |
| 2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it shows you think about his load |
| 3 | "Where do the two new product lines sit relative to Compass and the enterprise-expansion priority?" | Uses the priorities from your research note and tests whether you understand the role's real scope |
| 4 | "How does bundling pressure from the larger platform vendor show up in what your team sees today?" | Connects the competitive threat to his daily view and invites a real answer |
| 5 | "What data can I query on day one for these lines, and what is missing?" | A data-driven peer will respect a question about the data foundation, and it signals independent analysis |
| 6 | "How will success in this role be judged at six and twelve months, given profitability is a priority?" | Shows you read the profitability priority as a constraint on the role, not a slogan |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Set quotas | Inflated form of F5 | F5's quote at its own scope: annual volume targets with cross-org consensus. The limit is the pack's observation: the material says targets, not quotas |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. A1 and G1 slots stay inside the proposal |
| Designed or owned a partner motion | Inflated form of F4 | F4's quote at its own scope: a revenue model used in carrier negotiations. B4's slot stays inside the model |
| Owned go-to-market for product lines | Inflated form of F1 | F1's quote at its own scope: product strategy & ops. D2's slot stays inside that work |
| Built or shipped AI products, or has experience like Compass | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily |

## Sources

Provided documents: your message (JD highlights, Priya's background, Dan's profile as relayed, research note on Northwind's priorities and competitive threat). No dossier was supplied.

Searches sent, all refused, nothing returned:

- "Northwind Data company values" — refused
- "Northwind Data interview process strategy sales strategy" — refused
- "Dan Kovac Northwind Data Director of Sales Strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have fed a values cheat sheet; none is built because no values-style round was described |
| 2. Northwind Data interview process, sales strategy | unavailable | Would have tested the loop structure; your message establishes one 60-minute session with Dan, so persona weights rest on that and on the peer prior |
| 3. Northwind strategy and recent news | skipped | Your research note already supplies the three priorities and the bundling threat, which fix C1 to C3 and E3 |
| 4. Dan Kovac, Northwind Data | unavailable | Would have checked his profile and surfaced public talks; the interviewer read rests on your relay alone |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you gave fix the fit snapshot rows and JD-tagged questions |

## Upgrade menu

- The full JD text → the fit snapshot quotes the JD itself instead of your highlights, and mid-list requirements (a named tool or method) that the highlights omit would get questions
- The recruiter's prep email on focus areas or pre-declared deliverables → coverage of any graded deliverable, which would get its own build section
- Priya's own words on the answer slots (an analysis she ran end to end, how the ~$400M figure was counted, which part of the partner work was hers) → rows F1 to F6 can move from medium and bridges become story-mapped instead of slots
- Any pricing, packaging or bundling work in her background, as a sentence of hers → C1 would get a story instead of a method
- The internal write-up or readout that credited the ~$400M ARR uplift, and the revenue model itself → F2 and F4 can move from medium to high
- Search permission → a rerun of values, loop structure, and Dan's public footprint, plus a deeper pass (up to 6 further searches and 2 further fetches, several more minutes) for a strategy brief and recent Northwind context
- A `tuesday-dossier.md`, if one exists → verified evidence and prohibited claims arrive from a prior assessment instead of being built here
