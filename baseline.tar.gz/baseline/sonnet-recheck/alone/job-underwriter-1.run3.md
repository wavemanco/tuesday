I've read the underwriting method and am now running the research it calls for: one search to check Harborlight Health exists and the posting is live, and one for market norms for this role.
The two web searches were refused, so nothing about Harborlight Health is verified. I've marked those rows below and based the assessment only on the JD and your background.

## Decision snapshot

**Yes, apply. R1, R2, R3, R4 and R6 are `direct` and R5 is the one to firm up. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (Metrics layer definition and maintenance)
- `important` — adjacent: R7a (Turning analysis into roadmap decisions with PMs) · unclear: R7b (Partnering with clinicians), R8 (Mentoring two junior analysts)
- `preferred` — adjacent: R9b (HIPAA, protected health data) · absent: R9a (Healthcare data experience)

R5 (`low`) is the only `must_have` row below `direct`.

**Opportunity ledger.** The posting is concrete about responsibilities (RR4). Compensation is withheld (RR2), who owns the data modeling under the metrics layer is unstated (RR3), and the employer is unverified because research was refused (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) you can evidence owning metric definitions — R5, G1; (3) pay and level fit your floor — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C; care-navigation app | `[grounded]` JD header, not independently verified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentor two junior analysts | `[grounded]` JD |
| Stated hard terms | None. Location, pay, authorization and schedule are all absent from the posting | `[grounded]` JD silence |
| First-90-day or first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | Senior individual contributor with light mentoring. No direct reports are stated, and the metrics layer is the anchor responsibility | `[inferred]` from "mentor two junior analysts" and the responsibility order |
| Market calibration | Not done. The role-family search was refused, so I won't offer a pay band | `[generic]` none available |
| Unknowns | Pay, level, location, who owns the data pipelines under the metrics layer, how success is measured | `[grounded]` JD silence |
| Contradictions | None within the JD. JD against the careers page was not checked | `[grounded]` JD only |

## Evidence map

Your background was typed into the chat, so it counts as self-report. That caps confidence at `medium` until you point me to something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a meal-kit company. Confirmed and specific; no artifact inspected | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You state daily SQL on Snowflake. The level "expert" rests on your word; no query sample inspected | `[grounded]` your background | Optional: a sanitized query or model would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The posting does not define "at scale", so the limit is that your figures are your own | `[grounded]` your background; `[generic]` that "at scale" is usually read as test volume and rigor | Optional: a sanitized experiment readout would raise it to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background | Optional: dashboard screenshots |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" and the monthly metrics memo suggest metric definitions, but you did not say you defined or owned shared metrics. Low because the claim is indirect | `[grounded]` your background says "governed", not "defined"; `[inferred]` ownership is plausible | See G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | presentation | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. The evidence is strong; the issue is making sure it leads the resume | `[grounded]` your background | Resume edit E1, pending approval |
| R7a | Turn analysis into roadmap decisions with PMs | important | adjacent | medium | discovery | You present to the VP Product monthly and ran a pricing test with a retention outcome, but you did not say a roadmap decision followed from your analysis | `[grounded]` your background; no stated roadmap outcome | See G3 |
| R7b | Partner with clinicians | important | unclear | low | discovery | No clinical or domain-expert partnership is mentioned. Low because I have only a lead, not a claim | `[grounded]` background silence | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background is silent on mentoring. None, not low, because nothing points to it yet | `[grounded]` background silence | See G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You said you have never worked in healthcare | `[grounded]` your statement | Closure path noted in G5; minor risk because the JD calls it a plus |
| R9b | HIPAA, protected health data | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. Limit: that is consumer privacy law, not health data, and you have not worked under HIPAA | `[grounded]` your background; `[generic]` that the regimes differ in scope and obligations | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards and an exec memo, but no statement that you defined or owned shared metrics | R5 is the one `must_have` row below `direct`, and the posting leads with it | Writing the definition of a core metric (active subscriber, churn, retention) others reuse; LookML measures or a semantic model; settling a definition dispute between teams | A metric dictionary, sanitized LookML, or a KPI definitions doc | `[grounded]` background wording; `[generic]` that this responsibility is usually first among duties |
| G2 | Mentoring (R8, important) | discovery | Silent | The posting says two junior analysts report in or sit alongside the role | Onboarding an analyst, reviewing their SQL or dashboards, coaching an intern, running office hours | Nothing needed; a one-line description is enough | `[grounded]` JD; `[grounded]` background silence |
| G3 | Roadmap influence and domain-expert partnership (R7a, R7b) | discovery | Strong stakeholder presenting, no stated decision it changed, no domain-expert partner | The posting names PMs and clinicians as the main partners | A product or pricing choice that changed after your analysis; working with a nutritionist, ops, or culinary lead on a test | A memo or readout excerpt | `[grounded]` background and JD |
| G4 | HIPAA-adjacent data handling (R9b, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | The adjacent work is real, and the limit is the regulatory regime | Bridge: you handled regulated personal data and built consent logic. Limit: no health data, no HIPAA. Strengthener: a short learning artifact on HIPAA basics | Consent-state model diagram, sanitized | `[grounded]` background; `[generic]` that regimes differ |
| G5 | Healthcare domain (R9a, preferred) | capability | None, by your own account | Preferred only, so a minor risk rather than a blocker | Closure path: a short healthcare-analytics course or public-dataset project, or simply naming it as a gap | n/a | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | low | "digital-health scale-up, ~400 people, Series C" | The employer may be real and simply unchecked: my search was refused, so this is an absence of checking, not a negative finding. Severity stays low for that reason | `[generic]` pattern for companies of this size, not a claim about this one | Could you share the link to this role on your careers site, and tell me who the hiring manager is? | unresolved |
| RR2 | Compensation and level withheld | unknown | — | (no figure in the posting) | The posting gives no pay, level or location. The title says senior, but the band cannot be checked | `[grounded]` JD silence | What is the salary range and level for this role, and is it remote or based in an office? | unresolved |
| RR3 | Ownership of the data layer under the metrics layer | unknown | — | "define and maintain the metrics layer" | The role may own definitions without owning the pipelines and modeling beneath them, or may own both | `[inferred]` from the JD naming a metrics layer without naming an analytics-engineering team | Who builds and maintains the data models under the metrics layer, and what does this role control? | unresolved |
| RR4 | Concrete, well-specified responsibilities | positive_signal | — | "design and analyze A/B tests, build self-serve dashboards in Looker … mentor two junior analysts" | The mandate is specific and a team exists | `[grounded]` JD | What would success look like at six months? | noted |

## Application plan

Every row is a proposal. Nothing below is final, and my approval ask covers all of it, including the advice in A1 and Q1.

| # | Action | Proposed wording or step | Why | Provenance | Status |
|---|---|---|---|---|---|
| E1 | Resume edit (`resume_edits_pending_approval`): lead with your exec communication | "Write the monthly metrics memo the exec team reads; present to the VP Product monthly" | See R6 | `[grounded]` your own sentences | pending your approval |
| E2 | Resume edit (`resume_edits_pending_approval`): experimentation | "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | See R3 | `[grounded]` your own sentence | pending your approval |
| E3 | Resume edit (`resume_edits_pending_approval`): Looker | "Built the company's Looker instance from scratch — 40+ governed dashboards" | See R4 | `[grounded]` your own sentence | pending your approval |
| E4 | Cover-note line for the healthcare gap | "I haven't worked in healthcare; the nearest work I've done is handling GDPR/CCPA consumer PII and building our warehouse's consent-state model." No claim of HIPAA experience | See R9a, R9b | `[grounded]` your own sentences | pending your approval |
| Q1 | Ask RR1 to RR4's questions in the loop | Use them verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the posting is live on the company's own careers page before investing effort | Check before applying | See RR1 | `[grounded]` RR1 | pending your approval |

I'm holding off on any "metrics layer" bullet until G1 is answered, because your words so far say "governed dashboards", not "defined metrics".

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched for Harborlight Health's careers page for the Senior Product Analyst role, and the search was refused. It would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | I searched for salary and scope norms for senior product analysts in digital health, and the search was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. A name would feed the scope read and the plan's positioning |

## Dossier offer

If you want a saved copy, I can write all of this to `tuesday-dossier.md`.

## Upgrade menu

- Search permission granted → targets 1 and 2 run (up to 5 searches and 2 fetches), which closes RR1 and fills the market calibration row. A deeper company pass would add up to 5 more searches and 2 more fetches.
- A link to the live posting or the recruiter's email domain → RR1 closes without a search.
- A metric dictionary or sanitized LookML → R5 and G1 move from `low` to `medium` or `high`.
- A one-line mentoring example → R8 resolves.
- A sanitized experiment readout → R3 to `high`.
- The salary range and location → RR2 closes, and I can check them against your constraints.
- The hiring manager's name → the scope read and which story to lead with.

## Questions

**G1** — When you built the Looker instance, did you also define and own the shared metric definitions (what counts as an active subscriber, churn, retention), and who decided when teams disagreed?

**G2** — Have you mentored, onboarded, or reviewed the work of more junior analysts, formally or informally? What did you do, for whom, and for how long?

**C1** — Do you have non-negotiables on location or remote, pay floor, or work authorization? The posting states none, so I can't check them yet.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.