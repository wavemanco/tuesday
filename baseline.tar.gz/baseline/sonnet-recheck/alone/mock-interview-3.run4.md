I'll read the reference files the skill requires before building the pack.
Web search was refused, so I'm building the pack from your message alone. Nothing in it will be a Stripe-specific fact.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-3-denied-e44f9159/59d9629b-ba89-4aa9-a3c2-c266e2a450d0/scratchpad/stripe_product-operations-manager_interview_pack.md`.

I built it from your message alone, since I don't have your CV, the job description, an interviewer, or your recruiter's guidance. Web search was refused, so the pack has no Stripe facts: no values, interview structure or strategy. Those rows are marked as generic and the Sources section lists the refused searches.

It has 21 questions across seven interviewer styles, with live problem-solving and the skeptic's questions weighted highest. Those weights are a guess, because "final round" doesn't tell me who you're meeting or how many sessions there are. It also has a worksheet for your own evidence, a coverage table, six questions to ask them, and an upgrade menu of what to add.

The most important rehearsal is B1: "Tell me about a time you worked across teams on something that shipped. How much of it was actually you?" That is the likeliest probe for this kind of role, but it comes from the role in general, not from your background.

- **Practice:** Say the word and I'll play the interviewer on B1, or on any persona and question you choose.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word version:** I can convert the pack to a Word document if you'd like.

Three answers would restructure the pack:
- Who are you meeting in this round? The relationship reweights every question set.
- Is it one conversation or several sessions? If several, I can build a mini-pack per session.
- Can you paste the job description and your CV or key bullets? I can proceed without them, but they would turn the generic rows into answers built on your real experience.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. Structure and number of sessions not stated.
**Interviewer(s):** not named. **Relationship:** not stated.
**Built on:** your message only. No JD, no CV, no interviewer, no recruiter guidance, and no web research (the searches were refused, see Sources). Every row below is labeled `[generic]` for that reason. Persona weights are blended, not read from Stripe's actual process.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script. Because the pack holds none of your own sentences, it makes no claim about your past: wherever a question asks about your experience, the guidance tells you how to pick and structure a real instance, and ends with what to say if none comes to mind.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot (worksheet variant)

No CV and no JD were given, so this is a self-assessment worksheet. The requirements are role-family patterns written as plain prose, not quotes from any posting. Fill the evidence column in your own words before the interview; until you do, every row is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or changes across product, engineering and customer-facing teams. Role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a named launch or change, who was involved, and what you personally did versus coordinated. Selection scaffold: pick an instance where you can separate your actions from the team's; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define, track and interpret product or launch metrics. Role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a measure you can explain end to end: how it was counted, what it misses, what part was yours. Selection scaffold: pick the number you would most want to be asked about; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Build or improve a recurring process or operating cadence. Role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a process that existed because of you, with a way you know it helped. Selection scaffold: pick a process you changed or introduced and how you checked it; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence senior stakeholders without formal authority. Role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a moment you held a view against someone senior, with a named stake and an intact relationship afterwards. Selection scaffold: pick such a moment; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structure ambiguous problems and make a recommendation. Role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a problem that arrived without a brief and the reasoning you used. Selection scaffold: pick one where you can state the options you weighed; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Bring customer or user feedback into product decisions. Role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a decision that changed because of customer input, and your part in it. Selection scaffold: pick one; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No gate row (work authorization, location, schedule, a credential) appears, because no posting was supplied to name one. If the role has any, they are yours to confirm with the recruiter; no wording solves a gate.

## Persona table

The loop is not established: "final round" does not say how many sessions there are or who runs them, and no loop source was readable. The weights fall back to the Generic archetype (flat), tilted by the role family. Correct them if you know more.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: launches, diagnoses, prioritization | Highest. Product operations work is mostly problems of this shape (role-family pattern), and a final round usually has a decision-maker scoring reasoning. This is a weight, not a Stripe fact | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of "why this function, why you, how much was yours" | High. With no CV to tailor against, the most predictable probe is attribution and motivation | Rehearse the attribution question until it is boring; hold, then concede specifically |
| D. Peer Evaluator | Seam-splitting with adjacent teams; "what would you need from me" | Medium-high. The role sits between teams, so a peer or cross-functional interviewer is plausible | Reciprocity framing; propose seam principles, not a made-up seam |
| E. Data-Driven Prober | Asks how a number was counted and what it assumes | Medium. Metrics are central to the role family | Say plainly what you do and do not know about how a figure was counted; name the weakest assumption first |
| C. Values/Behavioral | Scenario probes against published values | Medium-low. No values page was read and no values round is documented in my material, so this bank uses persona stems only | Pick stories where the hard truth actually landed; "we" for context, "I" for contribution |
| F. Pressure | Time-boxed challenges, "why you" | Medium-low. Typical of senior rounds but not established here | Pause, restate, hold through two follow-ups |
| G. Conversational | Friendly openers that are still scored | Medium-low. Almost certain to appear as an opener, so it is cheap to prepare | A 90-second arc; treat casual questions as scored |

## Question banks

Every row is `[generic]`: none rests on a sentence of yours, so no guidance cell claims anything about your history. **B1 is the pack's highest-ROI rehearsal.** It is inferred from the role family, not derived from your CV, so treat it as the likeliest probe in general, not a diagnosis of your weak spot.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A feature is due to launch in two weeks, and engineering, support and the sales team each say they are not ready. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: what "not ready" means to each team, what is fixed, who decides. State an objective, split the problem by team and by risk, propose an approach with a decision point, name how you would know it is on track, and name the main risk. Challenge one premise aloud, such as whether the date is fixed. The question needs no claim about your past | Live problem from the role family (F1, F5). CASE because it scores structure, not recall |
| A2 | "A metric the product team watches dropped 20% week over week. Diagnose it." | CASE | [generic] | Clarify the metric's definition and any recent change in how it is counted before hypothesizing. Then segment (by user group, time, channel), separate real change from measurement change, and say what you would check first and why. Close with what decision the diagnosis would feed | Persona stem for the Case/Strategist (F2, F5). CASE because the structure is scored over the answer |
| A3 | "Three teams each want your help this quarter and you can support two. How do you decide?" | CASE | [generic] | Name the criteria before applying them (impact, urgency, cost of waiting, strategic fit), say who you would consult, and say how you would tell the third team. Show you would write the decision down | Prioritization is the commonest live problem for this function (F3, F4). CASE with a JD flavor |
| A4 | "Design the process by which a product decision reaches everyone who needs to act on it. Where would it break first?" | CASE | [generic] | Start with who needs to know what and by when, sketch a light process, then name the failure points yourself (unclear owner, late notice, drift between teams) and one check that would catch each. Keep it small enough to be adopted | Tests process design (F3) and whether you see failure modes before the interviewer does. CASE, JD content |
| A5 | "Where do you think the product organization here should focus its operational effort, and how would you find out?" | CO | [generic] | Be honest that this pack could not read Stripe's current strategy. Bring your own current reading from Stripe's public materials, state it as your view, and say what you would verify in the first weeks. A confident wrong claim about the company costs more than a labeled hypothesis | The only company-altitude question in the pack, and generic because research was refused (see Sources). CO because it scores homework depth |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you worked across teams on something that shipped. How much of it was actually you?" | EXP | [generic] | Selection scaffold: pick an instance where you can separate what you did, what you decided and what others did. Use "I" for your contribution and "we" for context. Hold your account through two follow-ups; when you concede, concede a specific thing, not the whole account. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Highest-ROI prep (F1). The stem is a standard attribution probe and it arrives in some form in nearly every loop. EXP because it checks what was actually yours |
| B2 | "What is product operations, as opposed to product management or program management, and why is it the job you want?" | JD | [generic] | Define the function in your own words, give the line you draw between it and its neighbors, and give reasons you can say are true. The guidance cannot supply your reasons | Motivation consistency, the Skeptic's core test. JD because it scores understanding of the role |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name a real weakness from your own honest self-assessment, then a concrete ramp plan stated as a plan, not a past. Do not pick a fake weakness | Standard Skeptic stem (F1 to F6). JD because it scores honest self-assessment against the role |
| B4 | "Why this role, why Stripe, why now?" | CO | [generic] | Three short reasons, each one you can defend. The Stripe-specific reason has to come from your own research; this pack could not supply it | Motivation consistency. CO because the company-specific reason is scored |

### C. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a message that was hard to hear, and a relationship intact afterwards. Say what you said and how it landed, not how it should have. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem for this interviewer (F4). VAL because it scores behavior, not virtue |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two actually pulled apart and you can say what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem (F6). VAL; Stripe's own published values were not read, so this does not map to them |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles (who owns the decision, who owns the follow-through, how a disagreement is escalated) instead of pretending to know this team's seam. Ask what their actual seam looks like | Persona stem (F4). JD because it scores how the role meets its neighbors |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick an instance where credit could have been contested and say what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem (F1). EXP because it checks your account of shared work |
| D3 | "What would you need from me in your first month, and what can you give my team?" | JD | [generic] | Reciprocity first: what you would bring that lightens their load, then what you need, kept short. Do not describe a past contribution here | Partnership fit (F4). JD |

### E. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you reported and walk me through how that number was counted." | EXP | [generic] | Selection scaffold: pick a figure you can answer four things about, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem (F2). EXP; this is also the defend-the-number rehearsal, since no CV figure was available to attach one to |
| E2 | "How would you tell whether a launch process is working? Name the measures and what each would miss." | CASE | [generic] | Pick two or three measures, say what each does not capture, and say what you would do when they disagree. Admit what you could not measure | Tests metric design (F2, F3). CASE |
| E3 | "A dashboard shows adoption of a new feature rising while support tickets rise too. What's your read?" | CASE | [generic] | Offer competing explanations, say what data would separate them, and say what you would not conclude yet. Do not pick a story before you have asked | Tests reasoning under ambiguity (F2, F5, F6). CASE |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | Pause, restate, give one reason that is true of you and that you can back with an example from your own experience. Do not compare yourself to people you do not know | Persona stem, a composure test. EXP because it scores your account of yourself |
| F2 | "Tell me about a time you held a position under pressure from someone senior." | EXP | [generic] | Selection scaffold: pick a case with a named stake, a moment you did not fold, and an intact relationship at the end. Hold through two follow-ups, then concede one specific thing. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Hold-then-concede rehearsal (F4). EXP |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you started, what drew you to product operations, why now. Built only from facts you would say anyway; write it out and time it | The casual opener that is still scored. EXP because it is your account of your own path |
| G2 | "What are you actually following about Stripe these days?" | CO | [generic] | Say one thing you have really read, what you made of it, and one question it raised. If you have read little, say what you have and ask a real question; do not recite headlines | Casual register, scored for genuine interest. CO |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-team launches | A1, B1, D2 |
| F2 Metrics | A2, E1, E2, E3 |
| F3 Process and cadence | A3, A4, E2 |
| F4 Influence without authority | A3, C1, D1, D3, F2 |
| F5 Ambiguity | A1, A2, E3 |
| F6 Customer input | C2, E3 |
| Headline CV metrics | none, and why: no CV was supplied, so E1 stands in |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you decide what product operations takes on versus what product management or program owners handle?" | Shows you thought about the seam before arriving |
| R2 | "What does a strong first 90 days look like, and what would tell you it went badly?" | Makes the success bar explicit and shows you plan to be measured |
| R3 | "Which recurring decision or launch process on this team do you most wish worked better?" | Invites them to hand you the real problem |
| R4 | "How does the team find out whether a process it introduced actually helped?" | Signals you care about evidence, not activity |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question; useful whichever relationship this turns out to be |
| R6 | "What has changed about the team's priorities in the last six months?" | Asks for current context instead of assuming it |

No reverse question is tied to an interviewer's own path, because none was named.

## Prohibited claims

None are listed. The material holds no sentence of yours to stretch and no negative you stated, so there is no inflated form to name. This is a different finding from a pack that checked your CV: nothing here was checked against one. Once you supply your own sentences, this section will list the wordings the pack will not coach.

## Sources

Provided documents: your message (company, role, round).

Research tier: L1 — searches 4 of 6, fetches 0 of 2. Every search was refused, so nothing from the web is used anywhere in this pack. Stripe's values, loop structure and strategy are deliberately absent rather than filled from memory.

Searches sent:

- `Stripe operating principles values` — refused
- `Stripe interview process product operations manager` — refused
- `Stripe strategy 2026 annual letter stablecoins agentic commerce` — refused
- `Stripe Product Operations Manager job description responsibilities qualifications` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have fixed the values cheat sheet (omitted) and given the VAL bank real value names |
| 2. `Stripe interview process product operations` | unavailable | Would have fixed the loop and persona weights; they rest on the Generic archetype instead |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded A5, B4 and G2; they are generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so no query could be formed |
| 5. representative `Product Operations Manager` JD | unavailable | Would have turned the fit snapshot's requirements into `[inferred]` quoted rows |

## Upgrade menu

- Search permission, or a pasted Stripe values page → a values cheat sheet with Stripe's own value names, and VAL questions mapped to them
- Search permission, or a pasted interview-process page → persona weights read from Stripe's documented loop instead of the Generic archetype
- The job description text → the fit snapshot's six generic rows become quoted, grounded rows, and every requirement gets a JD-tagged question
- Your CV or a few bullets → worksheet rows become story-mapped answers, and E1 and B1 become rehearsals of your actual claims
- The interviewer's name → an interviewer read and a reverse question tied to their path
- The recruiter's prep email (focus areas, any pre-declared deliverable) → coverage for those areas, plus a build section for any assignment
- If your final is several sessions, the schedule → per-session mini-packs with their own persona weights
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once, needs search permission → a current strategy brief for the CO and CASE banks
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and an evidence-derived top objection in place of the inferred one
