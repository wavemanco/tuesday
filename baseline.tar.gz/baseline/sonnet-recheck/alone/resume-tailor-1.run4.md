Your message gave me the CV as prose, so I treated it as self-report. Each "Current line" and "Traces to" cell below quotes your message word for word. I haven't seen the file's real wording or layout.

The JD maps well onto what you've told me. Your strongest evidence (40k requests/minute, p99 from 380ms to 95ms, six incidents as incident commander) is already specific, so most edits are reorders and splits, not rewrites. Three requirements aren't supported by what you wrote. They are named below instead of written around.

## Edit ledger — resume_edits_pending_approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline at a payments company." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline"; "Currently at a payments company." | `[grounded]` your message | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged — moved to first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Line 1: "On-call rotation every fourth week for two years." Line 2: "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | *(unchanged — moved after the incident bullets)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust; gRPC, Kafka, Postgres, Terraform, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "Kafka, Postgres, Terraform, gRPC, Datadog" | `[grounded]` your message | pending your approval |

How the rows were built:
- **E1** keeps your four sentences separate. Nothing is added except "at a payments company", which comes from your own sentence.
- **E4** splits one sentence doing two jobs, so incident command can be read as its own point. Your sentence doesn't say the six incidents fell inside the two on-call years, so the split doesn't either.
- **E5** stays as you wrote it ("onboarding", "pair with them"). The JD says "mentor mid-level engineers", and I didn't borrow that wording (see the prohibited list).
- **E6** puts Go in the skills line because your Go work is stated in a sentence of its own. The other tools stay as listed. A listed tool is not evidence of ownership.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 5+ years backend | must-have | `already_evidenced` | "7 years" is stated plainly. E1 repeats it in the summary. | `[grounded]` "Senior Software Engineer, 7 years." |
| M2 | Production Go | must-have | `surfaced_by_edit` | E1, E2 and E6 put Go next to the services you own. Your CV doesn't say which language the 40k requests/minute service is written in, so the proposed lines don't claim it. | `[grounded]` "Go and Rust daily for 4 years" |
| M3 | Distributed systems at scale | must-have | `not_evidenced` | See C1. Your volume figure shows scale, but nothing you wrote describes how the system is distributed. Kafka appears only in a tools list. | `[grounded]` what the CV says and omits |
| M4 | Drive down p99 latency | must-have | `already_evidenced` | E3 moves it up to the second bullet. | `[grounded]` "Cut p99 on the balance-read path from 380ms to 95ms" |
| M5 | Own on-call for your services | must-have | `already_evidenced` | E4 line 1. | `[grounded]` "On-call rotation every fourth week for two years" |
| M6 | Strong incident response | must-have | `surfaced_by_edit` | E4 line 2 gives incident command its own line. | `[grounded]` "I've run six incidents as incident commander" |
| M7 | Mentoring mid-level engineers | important | `surfaced_by_edit` | E5 moves the onboarding pairing up. Your CV doesn't say what level the new hires are, so the line doesn't say "mid-level". | `[grounded]` "I pair with them for their first month" |
| M8 | Design and ship Go services | must-have | `not_evidenced` | See C3. You say "own"; nothing says you designed or shipped them. | `[grounded]` "I own three services" |
| M9 | Partner with product on roadmap sequencing | important | `not_evidenced` | See C2. Nothing in the CV touches product or roadmap work. | `[grounded]` what the CV omits |

## Gaps: what could close them

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A service at about 40k requests/minute at peak, and Kafka in the tools list. It doesn't describe the system's shape or what you decided in it. | `[generic]` Postings that list this as a requirement usually probe it in interviews, so a bare tools-list entry leaves it open. | Owning Kafka consumers or producers; partitioning or ordering decisions; making a write idempotent; handling a downstream outage or replay | A design doc, an architecture diagram you drew, or a postmortem touching these | `[grounded]` what the CV says and omits; `[generic]` how this is usually probed |
| C2 | Partner with product on roadmap sequencing | important | Nothing about product, planning or prioritization. | `[generic]` The JD names this as part of the job, and a senior role at a 180-person company usually includes it. | Pushing back on or re-sequencing a deadline; scoping a migration around feature work; being consulted on a launch date | A planning doc, a roadmap thread, or a launch note | `[grounded]` what the CV omits; `[generic]` what such roles usually include |
| C3 | Design and ship Go services | important | You own three services, but the CV doesn't say whether you designed them or took them over. The same goes for who designed the cache rework. | `[generic]` "Owns" and "designed" are different claims, and interviewers tend to ask which one is yours. | Writing the design doc for a service or the cache rework; choosing the cache approach; leading a launch or migration | A design doc or ADR, or a launch or rollout note | `[grounded]` "I own three services"; `[generic]` how interviewers read the difference |

## Not written, and why

- **"Mentored mid-level engineers"**: you onboard new hires and pair with them. The JD's "mentor" is its word, and your CV doesn't state their level.
- **"Designed and shipped Go services"**: you wrote "own". Ownership of a service is a different claim from having designed it.
- **"Distributed systems at scale" or "built distributed systems"**: Kafka is a listed tool and 40k requests/minute is a volume. Neither describes a distributed system.
- **"High-request-volume services" (plural)**: one of your three services handles about 40k requests/minute.
- **"Reduced latency across the platform" or "across services"**: the 380ms to 95ms cut is on one path, the balance-read path.
- **"Go for 7 years"**: your sentence says 4 years of Go and Rust, with Python before that.
- **"Led incident response" or "led on-call"**: you run incidents as incident commander and sit on a rotation. Those are the two claims you made.
- **"Partnered with product on roadmap"**: there's no product work anywhere in what you gave me.

## Parse-safety check

Your CV arrived as pasted text, so I couldn't run any of these checks: multi-column layout, tables and text boxes, images or skill bars, contact details in headers or footers, non-standard section headings, and file type. Send the actual file (`.docx` or a text-layer PDF) and I'll run them. I'll also flag any hidden text a template or earlier tool may have left in it.

## Upgrade menu (offers; I'll build any of these only if you ask)

- **Send the CV file itself.** This would let me quote your real lines and run the parse check above.
- **Send a postmortem for one of the six incidents.** It could turn E4 line 2 into a more specific, checkable line.
- **Send a design doc or Datadog graph for the cache rework.** It would back the E3 numbers and may help with C3.

## Questions

C1 — In your ledger pipeline, what runs across multiple instances or partitions, and were you the one making the calls on ordering, retries or failure handling?
C2 — Have you worked with product to decide what got built or when, even once, for example re-sequencing work around a deadline?
C3 — For the three services you own, did you design any of them, or did you take them over? Who designed the cache rework?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.