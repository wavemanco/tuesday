I'll read the reference files first.
Dara, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-canned-93f81713/66f890f0-ca63-40d4-81e2-e20711da0390/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop: one shared fit snapshot, then a mini-pack for each round with its own persona weights, questions and reverse questions. The recruiter's email fixed the loop, and you pasted the values and strategy points, so I ran no web searches. No interviewer names exist yet, so there is no interviewer read. I also took 21 October as still ahead: your note dates today as 12 October, but my clock reads 5 November. If the rounds have passed, tell me and I'll rework it.

- **Highest-ROI prep:** D1, the round 2 question "the role covers the contact centre, and you've never worked in one." It is the one gap you stated against the JD, and your future manager will ask it. The pack gives you a four-step hold-then-concede ladder for it.
- **Weak spots from your own words:** I treated "formal complaints log" as unproven for the JD's "regulated complaints", and "monthly complaints spreadsheet" as unproven for "volumes and resolution times" and Excel. Those rows carry answer slots, so you say what was true for you or say plainly it wasn't.
- **Stated limits:** The contact centre and presenting above regional level are listed as limits you stated, with plain-acknowledgment wording and a plan to learn, never a past claim.
- **Stories to bring:** Round 3 has one question per value (F1–F4). Your material carries no complete story for any of them, so those are selection scaffolds that end with an honest branch. One real complaint story per value would turn them into mapped answers.

Say the word and I'll play the Skeptic on D1, or run a different question or persona.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Has the recruiter said whether the round 3 case arrives in advance or is cold on the day? If something is sent beforehand, I'll add a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Loop:** three rounds on 21 October 2026, built as a loop-mode pack (shared fit snapshot, then one mini-pack per round)

| Round | Who | Length | What the recruiter's email says |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | No stated format |
| 2 | Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation; the panel "is also the values round" and scores against the four values |

Interviewers beyond their roles are not yet assigned, so there is no interviewer read. Persona weights rest on the round types and the email's own words.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Every sentence about your past comes from your own message, quoted, or is an answer slot: an instruction to say, in your own words, what was true for you, with an honest branch if it was not.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values, not generic virtue |
| EXP | Whether your background claims survive scrutiny; what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you have done your homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: D1**, the contact-centre question in round 2. It is the one gap your own message states against a line the JD puts in the first sentence of the role, and your future manager is the person asking it.

## The fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages of a complaint likely. If any stage beyond the log was yours, say which and what you did, in your own words; if the log was the extent of it, or the rest was not yours, say so plainly and stay with the log |
| F2 | "the contact centre" (from "Own the member complaints process end to end across branches and the contact centre") — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built it and who uses it; it does not say what it counted. The words stay at: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it counted either, say which and how it was counted, in your own words, and the assumption behind it you would defend least; if it counted neither, or someone else set the columns, say so plainly and stay with the spreadsheet |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Derivation: the JD's Excel line read against a sentence that names no tool. Answer slot: if you built it in Excel, say so and say what it did, in your own terms; if it was another tool, or someone else built parts of it, say so plainly and stay with the spreadsheet you built |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The sentence carries six years in retail banking; the JD's phrase is customer operations. Say it as a spoken form of your own sentence, "six years in retail banking, the last three as a branch supervisor", and let the interviewers make the match. Do not re-label the role |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Derivation: the JD's word "regulated" read against your word "formal". Your sentence does not say whether rules or timescales set outside the branch applied to the log. Answer slot: if they did, say what they were and what part you handled; if it was a formal internal log only, or you do not know what governed it, say so plainly and stay with the log |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | The limit is yours and stated: "I've never presented to anyone above regional level." Then how you would prepare for a first senior audience, said as a plan and never as a past. Nothing added about presenting you have not described |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors and coaching, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's supervisors line makes a probe on coaching above teller level likely. If you have coached a supervisor, or anyone senior to you, on an escalation, say who and what you did; if you have not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with any digital or app team, even once, say on what and what was yours; if you have not, say so plainly and say what you would ask them first |

No requirement in the JD is a gate: the experience-length line is graded as experience, not as a term you meet or do not.

## Grounding brief (the strategy points you were sent)

Your account of the June 2026 strategy brief. The brief's own text was not read; only these four points are used.

| # | Item, as you reported it | Provenance | Where it is used |
|---|---|---|---|
| S1 | "move 40% of member service to digital channels by 2028" | [grounded] | A4, E1, E2 |
| S2 | "consolidate eight branches into five hubs over 2027" | [grounded] | A4, G3, R3 reverse questions |
| S3 | "launch a small-business lending product in Q1 2027" | [grounded] | A4 only; nothing in the three rounds points at it |
| S4 | "the main competitive pressure is app-only banks" | [grounded] | A4, E2 |

# ROUND 1: The recruiter (30 minutes)

## Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | A friendly walk through your background and why Ashgrove | High. Recruiter-screen prior is conversational plus light Skeptic; the email gives no format beyond "30 minutes with me" | A 90-second arc (A1); treat every casual question as scored |
| Skeptic (light) | Knockout checks against the JD's lines | Medium. The same prior; F2, F5, F6 and F4 are the rows a recruiter can check against the JD | Say the limit in your first sentence, then one sentence of plan; the full rehearsal is D1 |
| All others | Not expected | Low. Nothing in the email points to them | None needed |

## Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with the beats the quotes state: six years in retail banking; the last three as a branch supervisor; then the complaints work, the log and the monthly spreadsheet you built for your regional manager. Tell them in your own words and stop. Answer slot: your material does not say what the first three years held, or why you want this move. Say both in your own words; if you do not have a crisp reason for the move, say so plainly rather than borrowing one | The opener is casual but scored; F5 is the evidence it rests on. EXP because it tests the shape of the background claims |
| A2 | "What made you apply to Ashgrove?" | CO | [grounded] | Pick one thing that is true for you: one of the four values by its name, or one line of the strategy points (S1 to S4), and say why in your words. One reason said plainly beats four. The pack does not know your reason, and a reason borrowed from the values page that is not yours fails the first follow-up | Motivation is the most predictable recruiter question. CO because it is scored on company-specific homework, not only on motive |
| A3 | "Tell me about the complaints work you've done." | EXP | [grounded] "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | Three beats at their own scope: you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly spreadsheet your regional manager uses. Answer slot: the JD's end-to-end line (F1) makes a probe on what happened to a complaint beyond the log likely. If any stage beyond the log was yours, say which; if the log was the extent of it, say so plainly and stay with the log | This is the headline of the background and the first place the JD's "end to end" gets tested (F1, F8, F3) |
| A4 | "What do you know about where Ashgrove is heading?" | CO | [inferred] Derivation: the brief's digital and hub items as you reported them (S1, S2), read against complaints handling | Name two of the four points in plain words, for example the 40% digital target and the eight-to-five hub change. Then say what one could mean for complaints, as your own hypothesis ("I'd expect…"), never as inside knowledge: a complaint that starts in an app rather than at a counter, or a member whose branch has merged into a hub. Say you are working from the brief you were sent | The recruiter sent you the brief, so this question tests that it was read. CO because it scores strategy fluency; the implications are this pack's derivation |
| A5 | "What salary range are you looking for, and what's your notice period?" | JD | [generic] | Decide your range and your date before the call and say them plainly. The pack holds nothing on this role's pay, and the JD gives none, so it supplies no figure | Logistics are the standard knockout in a recruiter screen. JD because it screens against the posting's terms |

## Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. How do you feel about that?" | JD | [grounded] "Never worked in a contact centre" | Say it first: "I've never worked in a contact centre." Then one sentence of plan, said as a plan: what you would want to learn first and from whom. Pick only what you would really do. Stop there; the full rehearsal is D1 | F2 is the gap your own material states against the JD. The light version of the manager's D1 |
| B2 | "The JD asks for four-plus years in financial-services customer operations. How does your experience map?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it in the quote's terms: "six years in retail banking, the last three as a branch supervisor." Let them judge the match; do not re-label the role. Answer slot: if asked what the supervisor role covered beyond complaints, describe it in your own words; the pack does not know | F5 is the evidence. JD because it scores a stated requirement a recruiter can check |
| B3 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [inferred] "I handled the branch's formal complaints log" | Start with the sentence at its scope: "I handled the branch's formal complaints log." Answer slot: if rules or timescales set outside the branch applied to the log, say what they were and what part you handled; if it was a formal internal log only, or you do not know what governed it, say so plainly and stay with the log. Use the word "regulated" about your own work only if the first branch is true for you | F6 is the least certain requirement row and "regulated" is the JD's own word |
| B4 | "The role reports monthly on complaint volumes and resolution times and wants Excel confidence. Where does your spreadsheet work stand against that?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | The sentence at its scope first: you built the monthly complaints spreadsheet your regional manager uses. Then both slots: if it counted volumes or time to resolve, say which and how it was counted, and the assumption you would defend least; if it was built in Excel, say so. If it counted neither, was another tool, or was partly built by someone else, say so plainly and stay with what you built | F3 and F4 together: the JD's reporting and Excel lines are the two a recruiter can screen in one question |

## Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Is the case in the panel round given in advance or on the day, and is there anything I should bring?" | It asks for a process fact only the recruiter holds, and shows you are treating the 20-minute case as a graded segment |
| R1.2 | "Can you tell me the roles of the people I will meet in rounds two and three, and who from complaints or the contact centre is among them?" | It is a request the recruiter can answer in one line, and it fills the gap the email states |
| R1.3 | "What does the hiring team most need the first person in this role to fix?" | It turns the screen into a conversation about the problem the role exists for, and gives you material for the round-2 reverse questions |

# ROUND 2: Head of Member Services, your future manager (45 minutes)

## Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions | High. The recruiter's email says "mostly behavioural" | Pick stories from your quotes where one carries the setting; where none does, use the selection criteria and the honest branch |
| Skeptic | The gaps, from the person who would manage you | High. The hiring-manager prior is Case plus Skeptic; this person is buying capability and de-risking F2, F7, F8 | Rehearse D1 until it is boring: hold the position the quotes carry, concede specifically |
| Case / Strategist | Strategy and reporting problems | Medium. The prior would put it first, but the email says behavioural, so it is pulled down to the strategy questions only | Clarify, then structure, in the company's own vocabulary |

## Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unwelcome message to someone more senior than you." | VAL | [generic] | Selection criteria: a named stake, the moment you said it, and what happened to the relationship afterwards. Choose one where the message actually landed; if the ending was mixed, say so plainly. "We" for context, "I" for what you said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem for this persona, and it sits next to F7: the role reports to leaders you have not presented to. VAL because it scores behaviour, not a requirement |
| C2 | "Tell me about a time you coached someone through a difficult escalation." | EXP | [grounded] "trained new tellers on our escalation script" | The story has the beats the sentence states: you trained new tellers, and the training was on the escalation script. Answer slot: the JD's supervisors line (F8) makes a probe on the step up likely. If the training included working a hard case through with someone, say what the case was and what you said, in your own words; if it was the script only, say so plainly and stay there | The JD's coaching line is the raising source, and F8 is the evidence. EXP because it tests what was actually yours |

## Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role covers the contact centre, and you've never worked in one. How would you lead there?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | **Highest-ROI prep in the pack.** Hold-then-concede in four levels. Opening, about 20 seconds: "I've never worked in a contact centre." Then the position you hold, which is only what the quotes carry: you handled the branch's formal complaints log and trained new tellers on the escalation script, and you will not claim more than that. Follow-up 1, "So that part is new to you?": "Yes," plainly, then one sentence of plan. Follow-up 2, "What would you do in your first month there?": a plan in your own words; pick only what you would really do, for example listening to the centre's work before changing anything, asking the people there where a complaint that starts in a branch gets stuck, and asking what they need from branches. Follow-up 3, "Why would the centre's team follow someone from a branch?": concede that you would not expect them to on day one, and hold on what you would do to earn it. Name your limit before you are asked: how the centre is organised, what it measures and what its callers raise are things you would learn, not things you know | F2 is the largest stated gap and the manager is the person asking. JD because it scores a stated requirement; the deepest rehearsal here because it will be asked in some form |
| D2 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | The beat the quote states: you handled the branch's formal complaints log. Answer slot: the JD's end-to-end and regulated lines (F1, F6) make probes on what happened to a complaint beyond the log, and on what rules or timescales applied, likely. If any step or rule was yours to work to, say which and how, in your own words; if the log was where your part began and ended, or you do not know what governed it, say so plainly and stay with the log | F1 and F6 are the two rows a manager probes to find the edge of what was yours. EXP because it is a depth check on a CV line |
| D3 | "The role means presenting to senior leaders. Where do you stand on that today?" | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Plain acknowledgment first: "I've never presented to anyone above regional level." Then a plan, said as a plan: what you would do before a first senior audience; pick only what you would really do, for example asking what decision they need from the report, keeping it to what a leader can read in a minute, and asking a colleague to challenge a draft. The nearest thing your material carries is a report you built: "I built the monthly complaints spreadsheet our regional manager uses." Do not stretch it into presenting | F7 is stated, and the manager scores the JD's confidence line |

## Bank E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How would you work with digital teams on self-service journeys?" | JD | [grounded] | Answer slot first: if you have worked with any digital or app team, say on what and what was yours; if you have not, say so plainly. Then a way of working: offer to start from the complaints, which ones begin in a digital step and what members said in their own words, and ask the digital team what they already know. Say it as an offer, not as something you have done | F9 is silent and the JD names the requirement, so it is raised in some form. JD because it scores a stated requirement; no claim about your past is made |
| E2 | "The strategy aims to move 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Clarify first: what counts as member service in the 40%, and whether complaints are inside it. Then structure: objective (a member never has to explain a complaint twice), segments (by channel and by kind of complaint), approach, measures (volumes and resolution times by channel, the JD's two), risks (a member who cannot resolve something online and has to start again). Challenge one premise respectfully: whether complaints should default to digital. Say you are working from the brief you were sent | S1 plus S4 are the brief's pressure. CO because it scores strategy fluency; the reasoning is a method, not a claim about Ashgrove |
| E3 | "How would you set up the monthly complaints report for senior leaders? What do you need to know first?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Clarify before structuring: who reads it and what decision it serves; what counts as a complaint; when the clock for resolution time starts and stops. Then structure: volumes, resolution times, the one or two things that need a decision, on one page, in plain words. Name the assumption in your own definition of resolution time that you would defend least. Your own experience, at its scope: you built a monthly one for your regional manager. Answer slot: if you chose what it counted, say so; if someone else set the columns, or you do not know how it was counted, say so plainly | F3 is the evidence, and the JD's reporting line is the raising source. CASE because it is a live design problem; includes the metric weakest-assumption move |

## Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Where do complaints go wrong today between a branch and the contact centre?" | It goes straight at the remit's two halves and lets you listen, which is the first move in D1 |
| R2.2 | "Of the monthly report's measures, volumes and resolution times, which do senior leaders ask about first?" | It ties to the JD's own two measures and signals that reporting is for a decision |
| R2.3 | "As 40% of service moves online, how do you want the digital team and the complaints process to work together?" | It uses the brief you were sent and the JD's digital line |
| R2.4 | "What would you want me to have learned about the contact centre by the end of my first month?" | It turns the stated gap into a manager-defined ramp, honestly |
| R2.5 | "What does a strong first coaching conversation with a branch supervisor look like to you?" | It surfaces the standard behind the JD's coaching line before you are held to it |

# ROUND 3: Panel of two branch managers, including the values round (60 minutes)

## Persona weights

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | High. The email says the panel is the values round | Map a story to each value where a quote carries one; use the selection criteria and the honest branch where none does |
| Case / Strategist | The 20-minute complaint-escalation case | High. Twenty of the sixty minutes are stated | Say your structure aloud, clarify before answering, use the values' own words |
| Peer Evaluator | Seam and credit questions with two branch managers | Medium. The email does not say how the panel relates to the role; the JD's "across branches" makes a seam probe plausible, which is an inference | Seam principles, not a pretended seam; reciprocity |
| All others | Not expected | Low. Nothing in the email points to them | None needed |

## Bank F: Values / Behavioral (one per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Members First, Always: we decide from the member's side of the counter. Tell me about a time you did." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection criteria: one complaint, or one decision about one, where deciding for the member cost something, such as time, an argument or pushing on a rule. Name the complaint and the decision first, then the member's side, the cost and the result. The quote carries the log, which is where to look, not a story in itself. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first published value; the log is the setting a story would come from |
| F2 | "Plain Words: if a member needs it explained twice, we wrote it wrong. Tell me about a time you made something complicated clear." | VAL | [grounded] "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses." | Two candidate stories at their own scope: training new tellers on the escalation script, or the monthly spreadsheet you built. Choose the one where you can name what was unclear and to whom. Answer slot: if anything about the script's wording, your explanation of it, or the spreadsheet changed because someone found it unclear, say what and how you found out; if nothing did, say so plainly and stay with what you did | Published value two. F8 and F3 are the two sentences that could carry it |
| F3 | "Neighbours, Not Numbers: every branch is part of its town. Tell me about a time you weighed a number against what a branch needed." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection criteria: the setting is your own branch, where you were the supervisor. Name the number, name what the branch needed, and say which won and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Published value three; the panel are branch managers and the strategy consolidates branches, so the value is likely to be tested live |
| F4 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. Tell me about a problem you kept hold of." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection criteria: a problem you found, not only one handed to you. If it passed to anyone else at any point, say when and what you did to keep hold of it; if it never left your hands, say so. The quote carries the log only, so the story must be one named case. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Published value four, and the one closest to the complaints log |

## Bank G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained about the same fee at a branch twice, and the supervisor closed it both times. The member has now rung the contact centre and says they will take it outside the credit union. You have just been told. What do you do, in what order?" | CASE | [generic] | Say your structure aloud first. Clarify, briefly: what the member has been told and by whom, whether it is logged as a formal complaint, what the member is asking for, how long it has been open. Objective: the member's outcome and a fair process. Then: take hold of it today and name who holds it until the member has been told otherwise; speak to the member in plain words, from their side; talk to the supervisor about the two closings as a coaching conversation; record what you find; follow up. Challenge one premise: "closed" is not "resolved". Measures: reopened complaints and time to resolution. Say you would check Ashgrove's own rules rather than guess them | The 20-minute case, as a pattern; the scenario is invented for rehearsal, so nothing here is a claim about Ashgrove. CASE because it is a live problem; it lets you use the four values in your own words |
| G2 | "A branch supervisor keeps escalating complaints late. How would you coach them?" | JD | [grounded] "trained new tellers on our escalation script" | Find out what is happening before coaching: ask the supervisor to walk you through their last case. Agree what "on time" means, and ask Ashgrove's own standard rather than assume it. Coach in plain words, leave the branch's complaints with the supervisor, and agree a follow-up date. Your own experience, at its scope: you trained new tellers on the escalation script. Answer slot: if you have coached a supervisor, or anyone senior to you, say who and what you did; if you have not, say so plainly and stay with the tellers | The JD's coaching line, delivered as a case (F8). JD primary, CASE delivery |
| G3 | "Eight branches are becoming five hubs over 2027. How should complaints handling change so nothing falls between an old branch and a new hub?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify: which complaints are open at each move, who holds them, what members are told. Then structure: every open complaint has a named owner through the move (Own the Fix); members hear it in plain words (Plain Words); each branch's town is part of the picture (Neighbours, Not Numbers). Measures: open complaints by branch, resolution times, members who have to get back in touch. Risks: complaints that sit in the gap. Say you are working from the brief and that the branch managers on the panel know their own branches better than you | S2 is the strategy item closest to a panel of branch managers. CASE because it asks for a design; it also tests the vocabulary of the four values |

## Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where does the line sit between what a branch manager owns on a complaint and what you would own, and what happens when we disagree?" | JD | [generic] | Say you do not yet know where Ashgrove draws the line, then offer principles: a complaint has one named holder at any time; the branch manager keeps the relationship and decisions in their branch; the lead keeps the process, the reporting and the coaching; a disagreement is settled from the member's side first, and who decides is agreed in advance. Ask how it works today | The JD's "across branches" is the raising source. JD because it scores whether you can do the cross-branch part of the role |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | "We" for context, "I" for contribution; the quote's own attribution is "I built". Answer slot: if anyone else built or checked parts of it, say who and what; if nobody did, say so plainly. Name one thing you would credit others for in a shared piece of work | The stock peer stem; F3 is the sentence it can draw on |
| H3 | "What would you need from the branch managers in your first three months?" | JD | [generic] | Reciprocity first: what you would give, such as listening to each branch's view of its complaints and reporting back in plain words. Then what you would ask: a named contact at each branch, time with the supervisors, and honest feedback on the process | The standard collegial version of the "what would you need from me" probe |

## Values / principles cheat sheet (round 3)

The four values are Ashgrove's published names, from the text you pasted from its values page on 12 October 2026.

| Value | Working meaning (paraphrased) | Your story, or the scaffold | Rows and questions |
|---|---|---|---|
| Members First, Always | Decisions are made from the member's side | Scaffold, ending in the honest branch; setting: "I handled the branch's formal complaints log" (F1) | F1, G1 |
| Plain Words | If a member has to ask twice, the writing failed | "trained new tellers on our escalation script" (F8) or "I built the monthly complaints spreadsheet our regional manager uses." (F3), with the answer slot in F2 | F2, E3, D3 |
| Neighbours, Not Numbers | Each branch belongs to its own town | Scaffold, ending in the honest branch; setting: "6 years in retail banking, the last 3 as a branch supervisor." (F5) | F3, G3 |
| Own the Fix | Whoever finds the problem stays with it until it is solved | Scaffold, ending in the honest branch; setting: "I handled the branch's formal complaints log" (F1) | F4, G1, G3 |

## Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What would a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question; it shifts the panel from judging to advising |
| R3.2 | "When a complaint from your branch goes badly, what do you wish had happened earlier?" | It invites their experience and is the Own the Fix value in question form |
| R3.3 | "As eight branches become five hubs, what do you most want complaints handling to protect?" | It uses the brief you were sent and the Neighbours, Not Numbers value; it asks them, not tells them |
| R3.4 | "How does a complaint reach you today, and what would you change about that?" | It asks for the practical seam, which is what H1 is probing |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches" | A3, D2, G1, H1, H3 |
| "the contact centre" | B1, D1 |
| "report monthly on complaint volumes and resolution times" | B4, E3 |
| "coach branch supervisors on escalations" | C2, G2 |
| "work with digital teams on self-service journeys" | E1, E2 |
| "4+ years in financial-services customer operations" | B2, A1 |
| "experience handling regulated complaints" | B3, D2 |
| "confident presenting to senior leaders" | D3 |
| "comfortable with Excel reporting" | B4 |

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log, not a process across branches. The slots in A3 and D2 stay inside the log |
| Has handled regulated complaints | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says a formal log, not what governed it |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: your material says what you built, not what it counted |
| Is proficient in Excel | Inflated form of F4 | F4's quote at its own scope: your material says a spreadsheet, not the tool |
| Has coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: your material says new tellers and a script |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD you pasted; the four values as you copied them from ashgrovecu.org/about/values on 12 October 2026 (the URL is the source of text you pasted, so it was not fetched); the recruiter's email about the process; your account of the June 2026 strategy brief, four points only; your background in your message. No dossier was present. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the four value names and meanings for section 10 and bank F |
| 2. Ashgrove interview process, complaints or member-service role | skipped | The recruiter's email names three sessions, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The four brief points you supplied fix the CO and CASE questions (A4, E2, G3); the brief's full text is not in hand |
| 4. Interviewer names at Ashgrove | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Answers to the answer slots in F1, F3, F4, F6, F8 and F9, stated outside a drill → those rows are rewritten on your own words, and the discovery rows (F3, F4, F6, F9) become presentation or none, or stay honest limits
- Your CV as a document, and for the complaints work the artifacts this field keeps: a log extract with member details removed, the spreadsheet's column headings, the escalation script → medium bands on F1, F3, F4, F6 and F8 can rise to high
- One real complaint story for each of the four values, in your own words → the selection scaffolds in F1 to F4 become story maps
- The interviewers' names, once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's career path
- The recruiter's answer on whether the case materials arrive in advance → a build section for the case, if materials are sent
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → the full strategy brief, role-family loop reports, and recent organisation context; the grounding brief would grow past four points
- A tuesday-dossier.md from a job-underwriter run → the highest-ROI objection derived from evidence rather than inferred, and strategy limits per weak area
