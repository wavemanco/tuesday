I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, apply. You're a credible fit on the core of this role, and R5, R6a and R6b are the must-have rows still to firm up. The employer isn't verified yet (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R7 · adjacent: R5 (Define and maintain the metrics layer), R6a (Partner with product managers on roadmap decisions) · unclear: R6b (Partner with clinicians)
- `important` — unclear: R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 and R6b are where the first two closing questions point.

**Opportunity ledger.** The posting is concrete on duties and team (RR6). The employer is unconfirmed (RR1), pay and work arrangement are unstated (RR2), and three terms are open: support under the metrics layer (RR3), decision rights with clinicians (RR4) and the success definition (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) pay and work arrangement are acceptable to you, see RR2; (3) your answers to G1 and G2 hold up for R5, R6a and R6b; (4) R9 is framed as adjacent privacy-regime work, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C. Not checked against any source beyond the pasted posting | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app. Duties: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority signal | Senior title, 5+ years of product analytics, and a named team of two juniors | `[grounded]` JD |
| Scope read | Five duties sit in one role: analytics engineering (metrics layer), experimentation, BI, stakeholder partnership and people mentoring. Whether the metrics layer already exists, and who builds under it, isn't stated | `[inferred]` from the duty list against the JD's silence on data-engineering support |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not established. The role-family sweep didn't run, so no pay band is offered | `[grounded]` Evidence status, target 2 |
| Unknowns | Pay, location or remote arrangement, contract type, who owns roadmap decisions, clinician time available | `[grounded]` absent from the pasted JD |
| Contradictions | None visible inside the JD. It hasn't been compared with a careers page | `[grounded]` JD; comparison didn't run |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years of product analytics | must_have | direct | medium | none | Six years of product analytics at a consumer-subscription company, in your words. It's self-report with no inspectable artifact yet, so `medium`. Years of experience are graded on fit, not treated as a gate | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" is specific. "Expert" is the JD's grade, not a word you used, so the level rests on daily use. Senior analyst screens often include a live SQL exercise | `[grounded]` intake; `[generic]` screening pattern | Optional: a sanitized complex query or data-model sample would raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year at a company of about 2M subscribers, including the pricing test behind an 11% retention lift. Carry the 11% as you worded it, as a lift the test was behind. Test populations and risk limits in a care app may differ from consumer subscription | `[grounded]` intake; `[generic]` population difference | Offer: a sanitized readout of the pricing test (design, sample, result) would raise to `high` |
| R4 | Looker or similar BI tool; self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. "Self-serve" use by others isn't in your intake, only "governed", so don't carry self-serve into a claim until confirmed | `[grounded]` intake | Offer: a dashboard screenshot or usage figures; say whether business users built their own |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards and the exec metrics memo sit next to metric definitions. You haven't said you defined or maintained a shared metrics layer (semantic layer, LookML models, metric dictionary), so the claim isn't made yet and the band is the lower one | `[inferred]` adjacency from governed dashboards and the memo | G1 |
| R6a | Partner with product managers to turn analysis into roadmap decisions | must_have | adjacent | medium | discovery | You present monthly to the VP Product and write the exec memo, which is real contact with product leadership. You haven't said which roadmap decision your analysis changed, or whether you worked with PMs day to day | `[grounded]` intake, and its silence on a changed decision | G2 |
| R6b | Partner with clinicians | must_have | unclear | none | discovery | Nothing in your background mentions clinical or other domain-expert partners. That is unknown, not absent, until you've been asked | `[grounded]` intake silence | G2 |
| R7 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. An executive readership is the closest match to the JD's non-technical audience | `[grounded]` intake; `[inferred]` readership match | Offer: a sanitized memo would raise to `high` |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your intake is silent on mentoring or managing anyone | `[grounded]` intake silence | G3, held for a later turn |
| R9 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for your warehouse, which is regulated personal-data work. The limit is that no health data and no HIPAA obligations appear in your background, and the two regimes differ in what they cover | `[grounded]` intake; `[generic]` regime difference | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | discovery | Governed dashboards and a metrics memo. Nothing says you owned shared metric definitions | It's the first duty the JD names. A confirmed answer moves R5 toward `direct` and tests whether this job is the one you've been doing | Owning a metric dictionary or semantic layer others queried; LookML models and explores; agreeing one definition of retention, churn or conversion across teams; retiring conflicting metrics | A sanitized LookML snippet, a metric-definitions doc, a glossary screenshot | `[grounded]` intake silence; `[inferred]` that an answer moves R5 |
| G2 | Roadmap decisions and domain-expert partners (R6a and R6b, must_have) | discovery | VP Product contact is stated. A changed decision and any domain-expert partnership are not | Two must-have rows at `adjacent` and `unclear` hang on it. The JD names clinicians as partners | A test result that changed a launch, pricing or onboarding choice; working alongside operations, nutrition, culinary, customer-support or other subject experts to interpret data; a PM asking you to scope a question | A memo excerpt, a roadmap-review slide, a decision-log entry | `[grounded]` intake silence; `[generic]` that roles like this expect domain-expert partnership |
| G3 | Mentoring (R8, important) | discovery | No mention of mentoring or managing | The JD gives it as a named duty (two juniors) | Onboarding a new analyst; reviewing others' SQL or dashboards; running an analytics office hour or training | Nothing needed beyond a short answer | `[grounded]` intake silence |
| G4 | HIPAA bridge (R9, preferred) | transferability | Adjacent: consent-state model and GDPR/CCPA PII handling. Limit: no PHI, no HIPAA. Strengthener: a completed HIPAA basics course, if one is genuinely done, or a short design note on the consent model | A stated plus, not a requirement, so it can't make or break the application | — | A one-page sanitized design note on the consent-state model | `[grounded]` intake; `[generic]` that regimes differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and work arrangement not stated | unknown | — | (none: the posting as pasted has no pay or location terms) | The posting may withhold them, or the paste may have dropped them | `[inferred]` from the posting text as provided | What is the salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Metrics-layer support unstated | unknown | — | "define and maintain the metrics layer" | The role may own metric definitions with no data-engineering partner, or sit on a layer that exists already | `[inferred]` from the JD listing it beside four other duties and naming no engineering partner | What exists under the metrics layer today, and who builds and maintains the data models beneath it? | unresolved |
| RR4 | Decision rights and clinician access unstated | unknown | — | "partner with product managers and clinicians to turn analysis into roadmap decisions" | Partnership is named, but who makes the roadmap call and how much clinician time analytics gets are not | `[inferred]` from the JD's silence on both | How do analysis findings reach roadmap decisions today, and how much clinician time does the analytics team get? | unresolved |
| RR5 | No success definition for a broad mandate | unknown | — | "Own product analytics for our care-navigation app" | Ownership is stated with no first-90-day or first-year outcomes | `[grounded]` JD silent | What would success look like at six and twelve months? | unresolved |
| RR6 | Concrete scope and team | positive_signal | — | "mentor two junior analysts" | A named team size and five named duties suggest a defined role | `[grounded]` JD names both | Who are the two analysts, and how long have they been on the team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume bullet: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." Place it at the top | R3. Every clause is your own sentence | `[grounded]` intake | pending your approval |
| E2 | Resume bullet: "Built the company's Looker instance from scratch: 40+ governed dashboards." | R4. Your own sentence, with no "self-serve" added | `[grounded]` intake | pending your approval |
| E3 | Resume bullet: "Write the monthly metrics memo the exec team reads; present to the VP Product monthly." | R7 and R6a. Your own sentence | `[grounded]` intake | pending your approval |
| E4 | Resume line: "Handled GDPR/CCPA consumer PII; built the consent-state model for our warehouse." State plainly that you haven't worked with health data | R9. Adjacent, so it isn't presented as HIPAA experience | `[grounded]` intake | pending your approval |
| V1 | Verify the employer and the live posting on the company's own careers site before spending application effort | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the questions in RR2 to RR5 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Pick one past test to walk through end to end: hypothesis, sample, guardrails, result, decision | Senior experimentation roles are commonly probed on a candidate's own tests | `[generic]` role-family pattern | pending your approval |

Rows E1 to E4 are `resume_edits_pending_approval`, and the other rows are proposals too. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Harborlight Health care navigation app company careers" and "Harborlight Health Senior Product Analyst job" were both refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "senior product analyst digital health salary range 2026" was refused. It would have moved the market calibration row and the pay check in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you'd like a copy to keep.

## Upgrade menu

- **Search permission** → the organization row, RR1 and the market calibration row get filled from sources. After that, a deeper company pass would run up to 5 more searches and 2 more fetches, only if you say the word.
- **Your actual CV** → I can find buried evidence and presentation gaps. Right now I'm working from your summary.
- **Pay floor, location and other non-negotiables** → hard-gate rows appear and the hard-gates line stops reading "checks unknown".
- **A sanitized pricing-test readout** → R3 to `high`.
- **A dashboard screenshot or usage figures** → R4 to `high`, and it confirms whether business users built their own dashboards.
- **A sanitized monthly memo** → R7 to `high`.
- **Answers to G1, G2 and G3** → R5, R6a, R6b and R8 move.
- **The hiring manager's name** → target 3 can run.

G1 — Did you define or own shared metric definitions that other teams queried, such as LookML models, a metric dictionary or an agreed definition of retention or churn? What was yours, what was the team's, and what changed because of it?
G2 — Name one time your analysis changed a product or roadmap decision. Who did you work with: PMs day to day, and any domain experts outside product and analytics, such as operations, nutrition, culinary or support? What changed?
Constraints — Do you have non-negotiables I should check this role against: a pay floor, location or remote requirement, work authorization, schedule?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.