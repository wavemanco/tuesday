All six searches were refused, so I'm building the pack from your message and the recruiter's email alone. I'm writing it now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-5-denied-f2e308b2/3621cf8a-0915-43bf-8f98-90bf60f80808/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it for a second-round panel, with Deepa as your future manager and Ross as the commercial pusher. The searches I tried were all refused, so nothing in it comes from outside your message. I also don't have the job description or the text of the market report. It includes a build section for your 15-minute POV and a four-hour prep schedule. The pack names two objections as the prep to do first. They are "you haven't sold into rail" and "you've never carried a direct quota". Both come from your own words.

Say the word and I'll play Ross for the B1 and B2 objections, with follow-ups, then give feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, or its link? If you can, the requirement rows in the fit snapshot switch from the recruiter's words and generic role-family prose to the posting's actual lines.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second round, panel of two: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute POV from you, then Q&A in which Ross will push on commercials. Panel, timing and format are from the recruiter's email as you quoted it. Session mode.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: past behavior against published values |
| EXP | Work-experience deep-dive: do the claims survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: can you think at their altitude |
| CASE | A live problem from the role, solved aloud |

No VAL questions appear: nothing in your material or the recruiter's email names a values round in this session. Labels: `[grounded]` traces to your message or the recruiter's email, `[inferred]` is a derivation from a representative source, `[generic]` is a role-family pattern with no claim about Kelverton or you.

## Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV and speak it aloud against a timer, no slides, at least three full runs | Section: Graded deliverable; A1, A3, A4 |
| 2 | 60 min | Rehearse the highest-ROI objection aloud until it is boring: hold, concede, hold | B1, B2, D1 |
| 3 | 45 min | Write your own answers to the defend-the-number slots on the £4M figure; note what you do not know | C1, C2, C3, D2 |
| 4 | 30 min | Rehearse the commercial-terms answer and pick three reverse questions | C4, A5, Reverse questions |
| 5 | 15 min | The 90-second journey arc | E1 |

Everything else is insurance.

The highest-ROI prep in this pack is B1, with B2 beside it: you have said you have never sold into rail and never carried a direct quota, and a panel with a Commercial Director on it is likely to ask about both in some form.

## Fit snapshot

No job description was supplied. Requirements are the recruiter's own words, quoted, where she gave any; the rest are role-family requirements written as plain prose and labeled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says the ISV channel at a payments company, not operator partnerships, with nothing inspected behind it. The words stay at that scope: "My last four years were at a payments company, running the ISV channel." Answer slot: expect a probe on how that channel work maps to operator partnerships. If you see a carry-over, say which and why, in your own words; if you see none, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, with nothing inspected behind it. The words stay there: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on how that work shapes your view of what an operator needs from a partner. If it did, say how in your own words; if it did not, or it does not carry to train operators, say so plainly and ask the panel what operators tell them |
| F3 | "Ross will push on commercials." — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says influenced revenue, and "roughly", with nothing inspected behind it. The words stay there: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Answer slot: the figure raises four probes. Say how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly |
| F4 | Direct commercial accountability for a revenue target (role-family requirement, no source) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would take on direct accountability, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Prior selling or partnering into rail operators (role-family requirement, no source) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then a plan for learning it, said as a plan. F2 is the nearest thing your material carries and stays at its own scope |
| F6 | Grow and run a partner programme from a small base (role-family requirement, no source) | "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap on the requirement, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the count in the quote's own terms: you took it from 6 partners to 40. The sentence does not say who set the programme up or what it looked like at the start, so which part was yours is the C3 slot. Expect the panel to ask whether growth in partner count is what an operator-facing role needs |

## Graded deliverable: the 15-minute POV

Declared by the recruiter's email: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." Close requested: "Please land on what it means for the operators themselves."

### Grounded facts to build on

| Fact | Source | Row |
|---|---|---|
| 15 minutes, no slides, talk them through it | "First 15 minutes we'd like you to present a short POV" — recruiter's email | F1 |
| Close on the operators | "Please land on what it means for the operators themselves." — recruiter's email | F2 |
| The audience is your future manager and a Commercial Director who will push on commercials | "The panel is Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)." — recruiter's email | F3 |
| Your channel work, at its own scope | "9 years in partnerships, last 4 at a payments company running the ISV channel" | F1 |
| Your operator-side work, at its own scope | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | F2 |
| The limits you have stated | "never carried a direct quota, only influenced revenue"; "Never sold into rail specifically" | F4, F5 |

### Three theses to choose between (pick two, not three)

| # | Thesis, a position to test | Why it is defensible | Mandatory concession | Draws on | Provenance |
|---|---|---|---|---|---|
| T1 | Choose operator partnerships by the operator outcome each one moves, and say how you would know in 18 months | It answers the recruiter's requested close directly and gives Ross something he can test | You do not yet know which outcomes Kelverton's operators prize; the first job is to find out from them, and you should say so in the first minute | F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | [generic] |
| T2 | Prove, then scale: a few partnerships first, with commercial terms and exit conditions agreed up front, then widen | It speaks to Ross's lens before he has to ask, and it sequences the 18 months | It trades breadth for pace. You have not carried a direct quota, so frame the terms as principles to agree with Ross's team, not terms you would set alone. F6's sentence is about growth in count, from 6 to 40, so say plainly how your view of depth versus count applies here | F4: "never carried a direct quota, only influenced revenue"; F6: "took it from 6 partners to 40, roughly £4M of influenced revenue" | [generic] |
| T3 | Give operators a standing voice in partnership and roadmap decisions, with a named channel for what they tell you | It puts the operator at the centre of the 18 months rather than at the end | You cannot promise roadmap influence you do not control; say what you would commit to alone and what you would take to the product team | F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | [generic] |

### Differentiation from the consensus answer

You have read the strategy team's report, and the panel wrote or circulated it, so reciting its shortlist scores as homework. Bring one item from it, named plainly as theirs, to show grounding. Then give one thesis of your own that departs from it, with your reason. I have not seen the report, so I cannot say which item that should be; the upgrade menu says what pasting it unlocks.

The anti-pick: say one thing you would decline in 18 months. A candidate proposal for you to test against your own view: partnerships that add a partner but move no operator outcome. Replace it with yours if you disagree.

### A 15-minute shape (rehearse it aloud against a timer)

| Minutes | Beat |
|---|---|
| 0 to 1 | Frame: what you will cover, and one sentence on what you do not yet know. Say the limit before they do |
| 1 to 4 | Grounding: the one item from the report, as theirs |
| 4 to 10 | Your two theses, each with its concession, and the anti-pick |
| 10 to 14 | Close on the operators: what changes for an operator by month 6, 12 and 18, in operator terms, and how you would know |
| 14 to 15 | What you would want to learn first, handed back to the panel as an invitation |

## Persona table

Weights follow the relationship priors for a panel: the top two personas of each member's relationship, blended. Deepa is your future manager, which points to Case/Strategist and Skeptic. Ross is a Commercial Director whom the recruiter says will push on commercials, which my judgment reads as Data-Driven Prober with Pressure behind it; that reading is mine, not the recruiter's, and you should recalibrate it if you know something I do not. No loop source establishes more than this one session, so no round-type tilt is applied beyond it.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | The POV itself, then live problems on operator partnerships | High: the recruiter announced the POV, and Deepa is the manager who will judge your thinking | Clarify before structuring, think aloud, use their words (operator, partnership), challenge one premise respectfully |
| Skeptic (B) | Quiet, persistent probing of the rail and quota gaps | High: your own message states both gaps, and a future manager is buying capability and derisking it | Rehearse B1 until it is boring; concede plainly what your sentences say you have not done; plan, never a past |
| Data-Driven Prober (C) | Ross, line by line on the £4M and commercial terms | High: the recruiter's email names commercials as Ross's push | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the weakest assumption first |
| Pressure (D) | Time-boxed challenges: "sixty seconds, why you" | Medium: a Commercial Director who pushes may interrupt; the pattern is likely at moments, not as a whole style | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational (E) | Opening biography and casual "what are you thinking about" | Low: the opener may be warm, but the recruiter's brief makes this a structured panel | Pre-script the 90-second arc; treat casual questions about operator partnerships as scored |

Depth follows weight: Strategist 5, Skeptic 5, Prober 4, Pressure 3, Conversational 2.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] | This is the 15-minute opener; build it from the deliverable section above, not from this cell. Say aloud what you would find out first, two theses each with its concession, the one thing you would decline, and the close on operators. The cell makes no claim about your past | The recruiter's email announces it, so it is certain; F1 is where it presses hardest. CASE because it is a live problem delivered without slides |
| A2 | "What would you need to know about our operators before committing to a plan?" | CASE | [generic] | Clarify before structuring: ask which operator partnerships exist today and what each is for, who owns the commercial terms, and what operators say is not working. Ask rather than assume, and say which you would test first. It names no fact about Kelverton or your past | Clarify-first is what a Case/Strategist scores. `[generic]` because no company research landed; the upgrade menu says what would change that |
| A3 | "What does your plan mean for the operators themselves?" | CO | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The recruiter asked you to land here, so give it its own three minutes. Start with what the operator does differently or gets, in operator terms, then how you would know. The one claim about your past stays at its scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on how that work shapes what you think operators need. If it did, say how in your own words; if it did not, or it does not carry to train operators, say so plainly and ask what operators tell the panel | F2 is the evidence for the operator-side requirement and is the likeliest place to be probed. CO because it tests whether you can think from the customer's side at the company's altitude |
| A4 | "You have capacity for three partnership initiatives in the 18 months. Which do you pick, and which do you turn down?" | CASE | [generic] | State your criteria first, then pick, then name one you would decline and what declining it costs. The anti-pick has to be yours. It makes no claim about your past | The report's shortlist is the consensus answer; judgment shows in what you refuse. CASE because it is a live prioritisation, and `[generic]` because it presupposes nothing about you or Kelverton |
| A5 | "An operator partner tells you our roadmap doesn't match what they need. What do you do in the first week?" | CASE | [generic] | Find out what they need and what is fixed, who must be in the room, and what you can commit to alone versus what goes to the product team. Do not promise roadmap changes. Say how you would report back to the partner. It makes no claim about your past | The seam between a partnership and the product is where an operator-facing role bites, and Deepa will score your judgment there. CASE because it is a live problem set in the role |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. Why should we trust you with our operator partnerships?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The highest-ROI rehearsal in this pack. Concede first, plainly: "I've never sold into rail specifically." Then hold only what the quotes carry: "My last four years were at a payments company, running the ISV channel; before that, five years in transport consulting, in bus and light rail network planning." Follow-up one, "that's bus and light rail": concede the scope, "my planning work was bus and light rail." Follow-up two, "running a channel isn't selling": "I've never carried a direct quota, only influenced revenue." Then your plan for learning rail, said as a plan; name your own first steps, since the pack gives none. Answer slot: if any of your consulting or channel work touched train operators, say what in your own words; if none did, say so plainly and stay with what you have said. Hold by returning to the sentences, never by adding to them | F4 and F5 are the gaps your own message states, so this objection arrives in some form. JD because it scores the stated fit; the pressure is Skeptic delivery |
| B2 | "You've never carried a direct quota. How would you handle commercial accountability here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say it plainly: "I've never carried a direct quota, only influenced revenue." Then the figure at its scope: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Answer slot: expect the four probes the figure raises. Say how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly. Then how you would take on direct accountability, as a plan, and ask the panel what the role's commercial accountability is | F4 is the gap and F3 is the figure that sits beside it; Ross's push makes this likely. JD because commercial ownership is part of the role the recruiter described |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Choose from what your own sentence states: say one of the two plainly in one sentence, then how you would close it, as a plan. Avoid a weakness that is a strength in disguise. If neither is the one you would name, say what is and why, in your own words | F4 and F5 give the candid answer, and a rehearsed one converts the question into credibility. JD because it scores honest self-assessment against the role |
| B4 | "Why leave payments partnerships for a rail-tech vendor, and why now?" | CO | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | A scaffold, because your material gives no reason: say what pulls you to this role, what in your sentences connects to it at their own scope, and why now. The reasons must be yours; the pack has none to give. If the honest answer is mixed, say so plainly. Do not claim a long-held interest in rail unless it is true | The Skeptic stem "why leave, why here, why now" is near-certain from a future manager. CO because "why here" tests whether you understand the company |
| B5 | "What from running the ISV channel would you carry to train operators, and what would you leave behind?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Two short lists, yours. Answer slot: say what carries and what does not, in your own words; if you believe nothing carries, say so plainly and say what you would test first. Expect a follow-up on whether growth in partner count is the right goal for operators | F1 and F6 are the evidence, and the question probes the transfer between them. JD because it scores whether the candidate can do this listed job with a different channel behind them |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say how it was counted, in your own words. If you do not know how part of it was counted, say so plainly. State the figure as the sentence has it, "roughly £4M of influenced revenue"; do not name a method that was not yours | F3 is the headline metric and a magnet target for a Commercial Director. EXP because it tests whether the claim survives scrutiny |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: name the assumption you would defend least before they do, in your own words. If you do not know of one, say plainly that you do not know how it was counted, and say what you would check | The weakest-assumption move converts a gotcha into credibility. F3 is the source, and EXP because it tests the candidate's knowledge of their own number |
| C3 | "You took the channel from 6 partners to 40. What was yours in that, and what wasn't?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which part was yours and which was others', in your own words; "we" for context, "I" for contribution. If parts were done by others, say so plainly and return to the count the sentence states | F6 and F3 carry the count, and Ross will test the attribution. EXP because it asks exactly what was the candidate's |
| C4 | "How would you approach commercial terms with an operator partner?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Ask what model applies and who owns the terms, then name principles you would test: what the operator gets, what Kelverton gets, and how each side can leave. Say you would agree terms with Ross's team rather than set them alone. If pushed on owning terms: "I've never carried a direct quota, only influenced revenue." | Ross's push is announced and F4 is where it lands. JD because it scores the commercial side of the role the recruiter described |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause and restate. Concede first: "I've never sold into rail specifically." Then hold only the two sentences: my last four years running the ISV channel, and five years in bus and light rail network planning. Do not claim to be better; say what you bring, stop, and let them draw the inference. Hold through two follow-ups by returning to those sentences | F5 is the gap and F1 and F2 are all your material carries beside it. JD because it scores fit against the role; the time box is Pressure delivery |
| D2 | "That £4M — how much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold the sentence's own term, "influenced revenue", and neither shrink it to "contributed" nor grow it to "delivered". Answer slot: say which part was yours, in your own words; if you do not know, or it was shared, say so plainly and return to the figure as influenced revenue | F3 is the figure, and the pressure stem is the attribution probe. EXP because it tests precise attribution |
| D3 | "You say you know the operator world from the other side. Which side was that?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer from the sentence: bus and light rail network planning. Answer slot: say which side of the table you stood on and who you worked with, in your own words; if you did not work directly with operators, say so plainly | "From the other side" is the loosest phrase in your own sentences, and an expansion collapses on one follow-up; F2 is the source. EXP because it tests which side of the transaction you were on |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through the journey: consulting, partnerships, and here." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with the beats your sentences carry: five years in transport consulting, in bus and light rail network planning; nine years in partnerships; the last four running the ISV channel at a payments company. Answer slot: why you moved from consulting into partnerships and why this role now, in your own words; the pack has no reasons to supply. End on operators | F1 and F2 are the arc, and a pre-scripted arc stops casual questions from being unscored. EXP because it checks that the story is consistent |
| E2 | "What are you actually thinking about in operator partnerships these days?" | CO | [grounded] "which I've read" | Casual but scored. Bring one item from the report as theirs, then one view of yours that departs from it, with your reason. Answer slot: which item you would push back on, in your own words; the pack has not seen the report | The report is the panel's own material, so recitation scores as homework and a reasoned departure scores as judgment. CO because it tests how current you sound |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1: the 18-month POV on operator partnerships | A1, A2, A4, A5, B5, E2 |
| F2: land on what it means for operators | A3, D3, E1 |
| F3: commercials, and the £4M figure | B2, C1, C2, C3, C4, D2 |
| F4: direct commercial accountability | B1, B2, B3, C4 |
| F5: selling or partnering into rail | B1, B3, D1 |
| F6: growing a partner programme | B5, C3, E1 |

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's path.

| # | Ask | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which kinds do you count, and which one is working best today?" | It shows you are defining the unit before planning on it, and the answer lets you recalibrate your POV |
| R2 | "What would an operator say is the main reason to partner with Kelverton rather than simply buy the software?" | It goes straight to the operator's side, which the recruiter asked you to land on |
| R3 | "What does success look like at six and eighteen months for this role, in commercial terms, and is any of it a direct target?" | Ross pushes on commercials, so asking first shows you take accountability seriously, and the answer tells you whether F4 is a live gap |
| R4 | "When a partner commitment and the product roadmap conflict, who decides, and how does it get resolved?" | It names the seam that an operator-facing role works across and shows you think about it before day one |
| R5 | "Ross, where does partnerships end and commercial begin in how you work today?" | It asks the Commercial Director about the seam with his function, which turns a probe into a working conversation |
| R6 | "Is there anything in my background you would want me to address further before we finish?" | It invites any remaining objection, so you can answer it rather than leave it unspoken |

## Prohibited claims

What this pack will not coach, because it is the stretched form of a sentence you wrote or a thing you have said you have not done.

| Not coached | Basis | Honest form |
|---|---|---|
| Has carried a direct quota or owned a revenue target | Negative you stated, F4 | The plain acknowledgment: "I've never carried a direct quota, only influenced revenue." No slot |
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment: "I've never sold into rail specifically." No slot |
| Delivered, closed or owned £4M of revenue | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced revenue, not revenue closed or owned. D2's slot asks only which part was yours |
| Built the partner programme, or set it up from scratch | Inflated form of F6 | F6's quote at its own scope: "took it from 6 partners to 40". Your material says the count, not what you designed. C3's slot asks only which part was yours |
| Worked with, or advised, train operating companies | Inflated form of F2 | F2's quote at its own scope: "bus and light rail network planning". Your material says bus and light rail, not train operators. A3's and D3's slots stay inside that |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report she attached was not available to me; I have only your statement that you have read it. No `tuesday-dossier.md` was present.

Searches sent, every one refused:

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail strategy train operating companies scheduling software news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager Kelverton Rail job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have moved a values cheat sheet and VAL questions; none is built, and your message names no values round |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have moved persona weights from a documented loop; the recruiter's email already establishes this one session, so weights follow it |
| 3. Kelverton Rail strategy, recent news | unavailable | Would have moved the grounding brief and the CO bank from `[generic]` to `[grounded]`; the report you read is the stand-in, and I do not have its text |
| 4. Interviewer names, Deepa and Ross | unavailable | Would have moved an interviewer read and a reverse question tied to a career path; both are absent |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved the fit snapshot's requirements from the recruiter's words and role-family prose to quoted JD lines |

## Upgrade menu

- The market report's text, pasted → the grounding brief and the POV's consensus item built on its real content, and the CO questions (A3, E2) move from `[generic]` to `[grounded]`
- The job description's text, or its link → F4, F5 and F6 become quoted `[grounded]` requirements, and the coverage table is checked against the JD's own list
- Your own answers to the answer slots, typed in your message (how the £4M was counted, which part was yours, which side you stood on) → F2, F3 and F6 regenerate and the slots become story maps from your words
- The artifact behind the £4M, such as a partner-attributed revenue report → F3 can move from `medium` to `high`
- Search permission, or the interviewers' full names and any public talks → an interviewer read and a reverse question tied to a career path, which were refused here
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission → a company strategy brief for the CO and CASE banks
- A `tuesday-dossier.md` from job-underwriter → verified evidence and prohibited claims supplied rather than inferred from your message
