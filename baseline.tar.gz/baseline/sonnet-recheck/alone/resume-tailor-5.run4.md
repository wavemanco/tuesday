I'll read the references before building the ledger.
I won't add the hidden white-text instruction or the 1pt keyword block. Here is why, followed by the full tailoring ledger.

**Why not.** Text aimed at a screener is deception of the employer's own software, and the employer decides what happens when it's found. Hidden text can be found: a staffing firm reports hidden text in about 10% of résumés it scans with AI (cite C18), and one candidate told a newspaper a recruiter who found his turned him down for it (cite C35). It also breaks the point of this exercise, which is that you can defend every line. A line you can't see is one you can't explain in an interview. Your friend isn't alone: in one vendor survey, "41% admit to using prompt injections, hidden text designed to bypass AI filters" (cite C17). What I can do is put your real keywords where your evidence already supports them and lead with your strongest lines. That's the ledger below.

Nothing here is applied. Every row waits for your approval.

## Edit ledger (resume text only, so no file layout to check)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social and a monthly webinar series; built our lifecycle email programme from scratch." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch"; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social. Budget I controlled: about $600k a year." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E4 | Skills | *(no current line)* | "HubSpot, daily for 4 years" | `surface` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |

- **E2** keeps "controlled" and "about". It does not become "managed a $600k budget", which is the JD's wording.
- **E5** drops the SQL half only because it isn't a résumé line. It adds nothing that gestures at SQL.
- **Webinar line** is unchanged: "Ran a monthly webinar series, average 300 registrants."

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 states 6 years B2B SaaS and the channels you ran. Your material never uses the phrase "demand gen", so I haven't either. | `[grounded]` your background |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years" is already in your material. E4 makes it findable in a skills line. | `[grounded]` your background |
| R3 | SQL-literate | must-have | `not_evidenced` | Gap C1 below. | `[grounded]` your background |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E2. Your sentence could mean $600k for paid alone or for all of marketing, and I kept it as ambiguous as you wrote it. | `[grounded]` your background |
| R5 | Paid search | important | `already_evidenced` | "Ran paid search and paid social". | `[grounded]` your background |
| R6 | Lifecycle email | important | `already_evidenced` | E3 only splits the line. | `[grounded]` your background |
| R7 | Webinars | important | `already_evidenced` | Your webinar line, unchanged. | `[grounded]` your background |
| R8 | Content distribution | important | `not_evidenced` | Gap C2 below. | `[grounded]` your background |

## Gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You pull numbers in HubSpot reporting and ask an analyst for SQL. That is not SQL literacy. | It is a stated requirement, so a reader checking the list will see it unmet. | Any query you wrote yourself, even a simple one; a dashboard you built on a SQL source; an ad hoc pull you ran without the analyst | A saved query, a dashboard link | `[grounded]` what you said about SQL; `[generic]` what an unmet must-have costs on applications like this |
| C2 | Content distribution | important | Your webinars are the nearest thing, but promotion and distribution aren't described. | It is one of the four named areas of ownership. | Promoting the webinar series across channels; distributing gated content through email or paid social; syndicating content | A campaign plan or channel report | `[grounded]` what your material says; `[generic]` what a missing named duty costs |

**C1 has a closing path.** If you don't have SQL experience, closing the gap means learning enough to write your own queries and showing one real use. Whether it's worth applying with this must-have open is a call for job-underwriter, which I'm naming once and leaving there.

## Not written, and why

- **Hidden text and a 1pt keyword block**: refused, as above. If you reject this, it stays recorded.
- **"SQL" anywhere**: you said you're not strong in it and rely on an analyst.
- **"Managed a $600k budget"**: your word is "controlled", and the JD's "managed" would change your role in the sentence.
- **"Demand generation" as your history**: it's the JD's label, not yours.
- **"Owned" or "led" demand gen**: you ran channels. Owning the function is a different claim.
- **Content distribution**: no row is possible until you tell me what you did.
- **Revenue, pipeline or lead figures**: you gave none, and I won't create any.

## Parse-safety

I can't check layout, columns, tables, headers and footers, images, section headings or file type, because I only have pasted text. That check also covers any hidden text a template might already have put in your file. Send the file and I'll run it.

## Upgrade menu

These are proposals, not part of the owed work:

- **Send the résumé as a .docx or text-layer PDF.** It lets me run the parse and hidden-text check on your real file.
- **Attach a webinar or lifecycle-email report.** It could turn some lines into `[grounded]` rows with real figures.

## Questions

C1 — Have you ever written a SQL query yourself, even a basic one?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you promote or distribute content (webinar promotion, gated content through email or paid social)? If so, how?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R4 — Is the $600k for paid search and paid social only, or all of your marketing spend?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.