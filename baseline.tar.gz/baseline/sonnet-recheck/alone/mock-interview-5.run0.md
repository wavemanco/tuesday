Search access was refused, so I'm building the pack from your message alone. I'm saving it now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-5-denied-a2f89b47/92908ecf-d9b7-46f9-913f-9844bbea0f23/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It's built from your message only. I couldn't read the market report, and all six web searches were refused. The POV section therefore has slots where the report's content goes. The pack has 20 questions, a four-hour schedule split across the weekend, and a build for the 15-minute POV. Its highest-ROI prep is B1, the "never carried a quota, never sold into rail" question.

Say the word and I'll play Ross on B1 and its follow-ups, or run the full panel on your POV.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste the market report's text, and the JD if you have it, into this chat? The pack stands without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60 minutes, panel of two. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your spoken POV, then Q&A, and per the recruiter Ross will push on commercials.
**Built from:** your message only. The market report was not readable here and the web searches were refused, so the POV section holds slots where the report's content goes. See Sources.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny and attribution probing |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Guidance is scaffolding, not a script. Wherever a cell says "answer slot", the pack does not know the answer and will not invent one: say it in your own words, or say plainly that it was not yours or did not exist. Labels: `[grounded]` traces to what you or the recruiter wrote, `[inferred]` is derived, `[generic]` is a role-family pattern with no claim about you or Kelverton. Wording proposed for you to say is pending your approval.

Not in this pack, because their inputs were absent: a grounding brief, an interviewer read, a values sheet and delivery coaching. The upgrade menu says what would add each.

## 2. Prep triage (four hours, over the weekend)

| Block | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Fill the POV slots from the report, then say the POV aloud and record it. Trim to 12 to 13 minutes. | Section 4 |
| 2 | 50 min | Say B1 and its follow-ups aloud three times. This is the highest-ROI prep in the pack. | B1 |
| 3 | 45 min | Write down, in your own words, how the roughly £4M and the 6 to 40 were counted. Whatever you cannot answer is the finding. Then run D1 and D2 against a 60-second timer. | A1 to A3, D1, D2 |
| 4 | 40 min | Second timed POV run, then C1 to C4 aloud. | Section 4, C1 to C4 |
| 5 | 30 min | Reverse questions and the F1 journey arc. Stop. | Section 9, F1 |

Saturday: blocks 1 and 2 (125 min). Sunday: blocks 3 to 5 (115 min). Everything else is insurance: B2 to B4, E1, E2 and F2 get one read-through if time remains.

## 3. Fit snapshot

You gave no JD or CV, so the requirements are the recruiter's own words as you quoted them, plus role-family requirements written as plain prose and labeled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel in payments, not operator partnerships, and the words stay at that scope: "I took the ISV channel from 6 partners to 40." Answer slot: the recruiter's words ask where you would take operator partnerships, so expect a probe on what from the channel carries over. If some part did, say which in your own words; if none did, say so plainly and stay with what the channel was |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies, and the words stay there: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect "which operators, and what did you see of their needs". If the projects put you in front of operator staff, say who and what they needed, in your own words; if they did not, or the work was for others, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue, with nothing inspected behind it, so the words stay: "The channel went from 6 partners to 40, with roughly £4M of influenced revenue." Answer slot: the figure raises four probes. Say how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours; if you do not know how it was counted, say so plainly |
| F4 | Carrying a direct revenue target — role-family requirement, no source supplied | "never carried a direct quota, only influenced revenue" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota; my number was influenced revenue." Then how you would approach being held to a number, said as a plan and never as a past. Never a claim to quota work |
| F5 | Selling into rail operators — role-family requirement, no source supplied | "Never sold into rail specifically" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past |
| F6 | Building and growing a partner portfolio — role-family requirement, no source supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [generic] | none | No gap in the words, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms, 6 partners to 40, because a count beats an adjective |
| F7 | "no slides needed, just talk us through it" — recruiter's email, as you quoted it | none given | none | [grounded] | discovery | Your material does not show whether you have talked a leadership group through a view like this. Answer slot: if you have, say what it was in your own words; if not, say so plainly. Section 4 supplies the structure either way |

Proposed bridge wording above is pending your approval.

Requirement coverage:

| Requirement | Covered by |
|---|---|
| Where you'd take operator partnerships over 18 months | Section 4, C1 to C4, F2 |
| What it means for the operators themselves | Section 4 close, C1, C2 |
| Ross will push on commercials | A1 to A5, B1, D1 to D3, E1, E2 |
| Carrying a direct revenue target (F4) | A4, B1, B2, D1, D2 |
| Selling into rail (F5) | B1, B2, D1 |
| Building a partner portfolio (F6) | A3, B4 |
| Spoken delivery, no slides (F7) | Section 4 timing table |

## 4. Build: the 15-minute POV

### Facts to build on

| Fact | Where it comes from | How to use it |
|---|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | Recruiter's email, as you quoted it | The brief. Your thesis answers this sentence |
| "Please land on what it means for the operators themselves" | Recruiter's email, as you quoted it | The required close. The last two minutes are about operators, not about Kelverton's pipeline |
| "UK rail-tech, ~600 staff, they sell scheduling software to train operating companies" | Your message | Your only description of Kelverton. Whether operators are customers, co-development partners or something else is not in your material |
| F6: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Fit snapshot F6 | Your one quantified track record. Use it at its own scope |
| F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Fit snapshot F2 | Your operator-side material. If you use "the other side", expect "which operators", and stay with bus and light rail |
| F5: "Never sold into rail specifically" | Fit snapshot F5 | Say it yourself, early |

### Shape of the 15 minutes

| Minutes | Beat | Note |
|---|---|---|
| 0 to 1 | State how you are reading "operator partnerships" in one sentence | Your material does not define the term. A wrong reading would cost you the whole POV, and a ten-second check costs nothing. Your own reading goes here, in your own words |
| 1 to 3 | Where you are coming from | Opening line below |
| 3 to 5 | One point from the report you agree with | The report is their strategy team's document, circulated internally, so treat it as shared ground. Bring one consensus item to show you read it. Do not recite the list |
| 5 to 11 | Your thesis, the 18-month sequence, one divergence from the report, one anti-pick | Theses below |
| 11 to 13 | Commercials, before Ross asks | Commercial landing below |
| 13 to 15 | What it means for the operators | The close below. Aim to finish at 13 to leave room |

### Opening line (proposed, pending your approval)

"I should say where I'm coming from. I haven't sold into rail specifically. I've spent nine years in partnerships, the last four running the ISV channel at a payments company, and five years before that in transport consulting, in bus and light rail network planning."

Every clause traces to the quotes in F2, F5 and F6. Stop there and let them draw the inference.

### Three defensible theses

Pick one as the spine. Each carries a mandatory concession, said aloud.

| Thesis | One line | Mandatory concession | What must be true, your slot |
|---|---|---|---|
| T1: Define each partnership by what the operator gets | Sequence the 18 months around outcomes an operator would name, and measure partnerships on those | Outcome-led partnerships take longer to evidence than activity counts. Ross will ask what you would be accountable for, and you have not carried a direct quota (F4) | Name two or three operator outcomes, from the report or from your planning work (F2), in your own words |
| T2: Depth before breadth | Make fewer operator relationships work properly before widening | Your own record is breadth, 6 partners to 40 (F6), so say this is a different call and say what would make you wrong. It also shows revenue later | Say, from the report, why depth fits the operator set. Use this only if the report's list is breadth-led |
| T3: Earn the right first | The first six months are listening plus one proven joint outcome, then scale | It is a slow answer for a commercial director, and it leans on you not having sold into rail (F5) | Name the one joint outcome you would aim for, in your own words |

Recommendation: T1 as the spine, with T3 as its first-six-months sequence. Use T2 as your divergence only if the report is breadth-led. Decision rule: if the report's list is by partner type or topic, your divergence is T1's operator-outcome framing. If the report is depth-first, your divergence is breadth, argued from F6.

### Differentiation and the anti-pick

- Bring one consensus item from the report to show grounding, then one thesis-driven divergence, with your reason in operator terms.
- Anti-pick, your slot: name one item in the report you would deliberately not do in 18 months, and why. The reason is the part that scores.
- Do not coach the panel on what their own report got wrong. "Here is what I would sharpen" lands where "here is what's stale" does not.

### Commercial landing (before Ross asks)

Three sentences, all yours to fill:
1. How you would want to be measured. This is your slot, and A4 shows the structure.
2. What you would refuse to promise at month six, and why (B1, follow-up 3).
3. "I haven't carried a direct quota; my number was influenced revenue." This is sourced from F4. Say it plainly, once.

### The close: what it means for the operators (pending your approval)

Three sentences, each in an operator's terms:
1. Which person at an operator notices the change first.
2. What is different for them by month 18, in terms they would use.
3. What they would no longer have to do, or what it would cost them.

Ground each in the report or in your planning work (F2), in your own words. Do not claim to know how an operator runs beyond what F2's quote carries.

Rehearsal method: say the whole POV aloud twice, record it, time it, and cut anything that exists to sound impressive.

## 5. Persona table

| Persona | How it shows up here | Likelihood and the reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (Ross) | Commercial questions on the £4M and the partner count | High. The recruiter's own words are "Ross will push on commercials", and the only figures in your material are in F3 and F6. Depth: 5 | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know (A1 to A3) |
| Skeptic (Deepa and Ross) | Probing the rail and quota gaps | High. You have stated both gaps yourself (F4, F5), so they will find them quickly. Depth: 4 | Rehearse B1 until it is boring: concede in your own words, restate the record at its own scope, add nothing |
| Case/Strategist (Deepa) | Live problems on operator partnerships after the POV | High. Panel with a future manager; a 15-minute strategy POV invites case follow-ups. Depth: 4 | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise (C1 to C4) |
| Pressure (Ross) | Time-boxed, interrupting, "how much was actually you" | Medium. The relationship prior for a senior commercial seat, and the recruiter's warning. Depth: 3 | Pause, restate, hold through two follow-ups, concede specifically (D1 to D3) |
| Peer Evaluator (Ross, on the seam) | Where partnerships ends and direct commercial work begins | Low. Ross is not a peer, but his function sits next to where partner influence meets direct sales. Depth: 2 | Reciprocity framing: what you bring his team, and seam principles rather than a claim to know the seam (E1, E2) |
| Conversational (Deepa) | Opening or closing chat, "walk me through the journey" | Low. Fifteen of 60 minutes are the POV, but casual questions are still scored. Depth: 2 | A 90-second arc built from your quotes (F1) |
| Values/Behavioral | Dropped | No loop source documents a values round and no published values are in hand | Not applicable |

Loop basis: the recruiter's email establishes one session with a named two-person panel, so the weights above rest on it, not on an archetype.

## 6. Question banks

Proposed guidance wording is pending your approval.

### A. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You say roughly £4M of influenced revenue. How was that counted?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Defend the number in your own words; this pack supplies no method. Answer slot: say how the figure was counted, what it is most sensitive to, and the assumption behind it you would defend least; if you do not know how it was counted, say so plainly. Keep the quote's own words, "roughly" and "influenced" | F3 holds your only revenue figure and the recruiter flagged Ross's commercial push. EXP because it tests whether the figure survives, with JD overlap |
| A2 | "Which part of that was you, and which part belonged to other people?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Attribution honesty. Answer slot: say what was yours and who else touched the result, in your own words; if you cannot separate your part, say so plainly. The scope you can hold is the quote's, running the channel | Attribution probes follow any figure (F3). EXP because it tests what was actually yours |
| A3 | "You took the channel from 6 partners to 40. What counted as a partner, and how many of the 40 produced revenue?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say in your own words how a partner was counted and how many of the 40 were active; if you do not have the split, say so plainly and stay with the 6 to 40 | F6 is a headline metric and every headline metric gets a defend-the-number question. EXP because it tests the count |
| A4 | "If we set you a number for operator partnerships, what would you want it measured on?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Open with the sourced acknowledgment: "I haven't carried a direct quota." Then the structure: what you would want counted, what you would want kept out, and what you would need to know first about how partner-involved deals are credited today. Think aloud; it claims nothing about your past | Ross's commercial push (F3, F4) arrives as a design question. JD because it tests the commercial side of the role |
| A5 | "How would you decide whether an operator partnership is worth the effort?" | CASE | [generic] | Clarify first: what data exists on cost and return today. Then objective, what return means for an operator, a stopping rule for when you would walk away. Think aloud. No claim about your past | A commercial case any panel can ask. CASE; `[generic]` because it is a pattern, not a fact about Kelverton |

### B. Skeptic (Deepa and Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a quota and you haven't sold into rail. Why should we trust you with operator partnerships?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **The highest-ROI prep in this pack.** First answer, 60 to 90 seconds. Concede first, in your own words: "I haven't sold into rail specifically, and I haven't carried a direct quota; my number was influenced revenue." Then the record at its own scope: nine years in partnerships; the last four running the ISV channel, 6 partners to 40, roughly £4M of influenced revenue; five years in transport consulting, in bus and light rail network planning. Stop and let them draw the inference. **Follow-up 1** (Deepa): "Consulting isn't operating. What do you know about running a train operator?" Hold at the planning work and concede it was not operating. Answer slot: if the projects put you in front of operator staff, say who and what they needed; if they did not, or the work was for others, say so plainly and stay with the planning work. **Follow-up 2** (Ross): "A partner will ask for price and terms in month two. Have you negotiated them?" Answer slot: if you negotiated commercial terms with partners, say which and how you decided; if it was someone else's, or you did not, say so plainly and return to the channel you ran. **Follow-up 3**: "What would you refuse to promise us in your first six months?" Name one thing you cannot yet know, and why. Hold the record through two follow-ups by returning to it, never by adding to it | This objection arrives in some form because both gaps are ones you stated (F4, F5), and F2 and F6 are what you have against them. JD because it scores the stated fit; the follow-ups add EXP and CASE load |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Pick from the gaps you have already named, not an invented weakness. Answer slot: say which you would pick and why, in your own words. Then one concrete first step, said as a plan, not a past | A Skeptic stem built on F4 and F5. JD because it tests honest self-assessment against the role |
| B3 | "Your recent years were in payments. Why rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: the reason is yours and this pack does not have it. It should be true, specific to operators or to Kelverton, consistent with your opening line, and not run payments down. If you cannot name a reason yet, say so plainly and say what you want to find out | Motivation consistency is the Skeptic's core score (F1). EXP because the answer must survive cross-examination of the career story |
| B4 | "Your channel was ISVs. How much of that carries over to operators?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: name one thing that carries over and one that does not, from your own experience; if you cannot separate them yet, say so plainly and say what you would ask Deepa | F1 is the transfer question in its sharpest form. EXP because it tests what the channel work actually was |

### C. Case/Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thanks. Your first 90 days: what do you do?" | CASE | [generic] | Clarify what is already in place, then objective, segmentation, approach, metrics, risks. Tie it to your POV's sequence. Challenge one premise respectfully. No claim about your past | A POV invites its implementation. CASE; `[generic]` because it is a pattern |
| C2 | "Which operators do you start with, and which do you leave alone?" | CASE | [generic] | Ask what is known about operator readiness and existing relationships. Name your selection criteria, then the leave-alone group and the reason. Think aloud | Tests the anti-pick under live conditions (F1). CASE; `[generic]` |
| C3 | "What would you say no to in the next 18 months?" | CASE | [generic] | The anti-pick from section 4. Answer slot: name one item from the report and the reason in operator terms; concede what it costs and what would change your mind | Differentiation question for a role whose job includes choosing. CASE with CO load; `[generic]` because I have not seen the report |
| C4 | "What did you make of the market report?" | CO | [inferred] | Agree with something first, then give one addition or sharpening, never a correction. Answer slot: both come from your own reading; this pack has not seen the report | Derived from the report's circulation and your note that you read it, not from its content. CO because it tests homework depth |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, rather than someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause, restate, then three beats inside 60 seconds. The concession: "I haven't sold into rail specifically." The record: nine years in partnerships, the last four running the ISV channel, 6 partners to 40. The consulting: five years, bus and light rail network planning. Add no claim about what that makes you. Hold through two follow-ups | The Pressure stem aimed at F5. JD because it scores the stated fit; the hold-then-concede structure is the point |
| D2 | "Influenced isn't closed. Why should I count it?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold: "It's influenced revenue and I'm not calling it more." Concede specifically: "I haven't carried a direct quota." Answer slot: say how influence was determined and what part was yours; if you do not know, say so plainly. Never restate it as closed or delivered | The interrupting version of A1 and A2, aimed at F3 and F4. EXP because it tests the figure under pressure |
| D3 | "Suppose our sales team already covers every operator. What does a partnerships manager add?" | CASE | [generic] | State your position, hold it through two follow-ups, and concede specifically. Structure: ask what direct coverage includes, give the conditions under which a partnership adds something the direct team cannot, and name the conditions where it does not. No claim about your past | The seam and the role's value, put as a hypothetical. CASE with Pressure delivery; `[generic]` |

### E. Peer Evaluator (Ross, on the seam)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between your partnerships work and my commercial team, and what happens when we disagree?" | CASE | [generic] | Reciprocity first: what you would bring his team. Then propose principles, not a claim to know the seam: who owns the operator relationship, how credit is recorded, how disagreements escalate. No claim about your past | The seam is where F3's influenced-revenue problem becomes live. CASE; `[generic]` |
| E2 | "Tell me about a time credit for a result was shared across teams." | EXP | [grounded] "roughly £4M of influenced revenue" | Pick a time credit was shared. Name your share and the others', in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the roughly £4M of influenced revenue at its own scope, or how you would handle it | The Peer stem; F3's number is inherently shared credit. EXP because it tests attribution style |

### F. Conversational (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc with the beats the quotes state: five years in transport consulting, in bus and light rail network planning; nine years in partnerships; the last four at a payments company running the ISV channel, 6 to 40. Answer slot: the nine years include five before the payments company, and your material does not say what those were. Say what they were and what led to the payments company, in your own words | F6 and F2 are the arc's two anchors. EXP because it is the CV in spoken form |
| F2 | "What drew you to Kelverton?" | CO | [generic] | Answer slot: the reason is yours. A good one has a part about the work, a part about the company, and a part about now. The only description of Kelverton in your material is that it sells scheduling software to train operating companies; anything more comes from the report or your own reading | A rapport question that is still scored. CO; `[generic]` because the research that would ground it was refused |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you define a successful operator partnership today, and what does it look like from the operator's side?" (Deepa) | It echoes the brief's own close and shows an operator-first lens |
| R2 | "How are partner-influenced deals counted and credited between partnerships and your commercial team today?" (Ross) | It puts the influenced-versus-direct issue on the table in his language, before he does |
| R3 | "What would you want to be true at month six for you to call this hire a good one?" | It turns the commercial push into a shared yardstick |
| R4 | "Where did the market report generate the most debate internally?" | It shows you read it and invites the inside view |
| R5 | "What's the hardest thing about working with operators that I wouldn't see from the outside?" | It is an honest question from someone who has not sold into rail (F5), and it asks for what research cannot give |
| R6 | "Which of the report's recommendations are already decided, and which are open?" | It tells you what to hold and what to challenge in follow-up |

No interviewer profile was available, so none of these is tied to an interviewer's own path.

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't sold into rail specifically." No slot |
| Has carried a revenue target or quota | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; my number was influenced revenue." No slot |
| Generated, closed or delivered £4M of revenue | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says influenced revenue, not revenue closed |
| Built the channel alone, or from scratch | Inflated form of F6 | F6's quote at its own scope. The pack's observation: your material says what the channel did, not who else was involved or how partners were won |
| Has worked with train operating companies or knows how they operate | Inflated form of F2 | F2's quote at its own scope. The pack's observation: your material says bus and light rail network planning, not train operating companies |

## 9. Sources

Provided documents: your message (your background, the recruiter's email as you quoted it, your description of Kelverton). The market report you describe was not readable in this conversation, so nothing from it is used. No dossier was present.

Web searches, none of which returned anything:
- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships manager" — refused
- "Kelverton Rail strategy scheduling software train operating companies news" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Ross Commercial Director Kelverton Rail" — refused
- "Senior Partnerships Manager job description rail technology software UK" — refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values sheet, but none is in the pack either way, since no values round is documented |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Would have documented the round format. The recruiter's email already fixes the session, so persona weights stand |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have fed the grounding brief (dropped) and made C3, C4 and F2 `[grounded]` instead of `[generic]` or `[inferred]` |
| 4. Interviewer names (`Deepa`, `Ross`) | unavailable | Would have produced the interviewer read (dropped) and a reverse question tied to their paths |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Would have let F4 to F6 quote a requirement instead of using plain prose |

## 10. Upgrade menu

- The market report's text, pasted here → the grounding brief returns, section 4's slots become concrete picks, and C3, C4 and F2 move from `[generic]` or `[inferred]` to `[grounded]`
- Your CV → the fit snapshot draws on sentences beyond your summary, and F1's slot about the five partnership years before the payments company can be answered from it
- The artifact behind the £4M, such as the partner-sourced pipeline export or attribution report → F3 and F6 move from `medium` toward `high`
- Your answers to the slots in A1 to A3 and B1 → F2, F3 and F6 regenerate on your stated words
- The JD text → F4 to F6 requirements become quoted `[grounded]` rows, and JD-tagged questions are rechecked against it
- Both interviewers' surnames or public profile links → an interviewer read, persona weights tuned per person, and a reverse question tied to each path
- One email to the recruiter asking what "operator partnerships" covers and whether the 15 minutes is a hard stop → it settles section 4's opening beat
- Search access, if you grant it → the five L1 targets rerun; a deeper pass would add up to 6 further searches and 2 further fetches, several more minutes, offered once and run only if you ask
- A `tuesday-dossier.md`, if you already have one → verified evidence and constraints per weak area, never a prerequisite
