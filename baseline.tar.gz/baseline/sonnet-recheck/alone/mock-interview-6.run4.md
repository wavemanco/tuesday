I'll read the reference files the skill points to before building the pack.
Your prep pack for all three rounds is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-6-denied-9ca5d78a/f223cb5d-9838-4ef0-9322-6c3b03bf449f/scratchpad/larkfield-systems_engineering-manager_interview_pack.md`.

I built it in loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights, questions and reverse questions. I used your role description as the JD and your four background sentences as the only evidence. The pack also covers requirement coverage, the claims it won't coach, and a prep triage sized to the two weeks.

**Research didn't run.** All three web searches (values, interview process, strategy) were refused in this session, so nothing in the pack comes from the web. The Monday values cheat sheet is omitted, and the company-level questions (I1 and the case bank) are labeled `[generic]`.

The most important prep is A1 and A2. Your own message names "never owned a hardware-adjacent roadmap" and "never managed managers", and the Director will press there first. The same gaps come back on Thursday and Monday. The reliability-quarter story and the 60% figure also recur in all three rounds, so one honest, rehearsed version of each is worth the time.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD or your CV, or tell me to proceed without? Either would turn the thin rows into quoted ones.
Did the recruiter say anything else about the rounds, such as panel names, a prepared exercise, whether the 11 engineers include leads, or published values for the VP round?
If you grant web search, do you want me to run the company research and a deeper pass of up to 6 more searches and 2 more fetches, taking several more minutes? It would unlock the values cheat sheet and make the company-level questions specific.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Engineering Manager — Larkfield Systems: three-round interview pack (loop mode)

**Candidate:** Yusuf
**Role:** Engineering Manager at Larkfield Systems (industrial IoT, about 600 people), from your description: "Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap."

| Round | When | Who and relationship | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

No interviewer names were given, so there is no interviewer read. The three rounds, who runs each and how long each lasts come from your own words, so the loop is established and no archetype fallback is used.

## How to use this pack

- **Personas describe how a question arrives; types describe what is scored.** Each round has its own persona weights, with the reasoning shown so you can recalibrate if you know something the pack does not.
- **Type key.** VAL: whether your past behavior shows values and leadership, not generic virtue. EXP: whether the claims about your background survive scrutiny. JD: whether you can do the listed job, gaps included. CO: whether you can think at the company's altitude. CASE: structure and reasoning on a live problem from the role.
- **Guidance is scaffolding, not a script.** Every sentence about your past in the guidance is one you wrote, quoted next to the claim. Where the pack could not ground a beat, it leaves an answer slot instead: an instruction for the interview with an honest second branch, never a fact supplied for you.
- IDs run A to I across the whole loop. A to C are Tuesday, D to F are Thursday, G to I are Monday.

## Prep triage

Two weeks, three rounds. In order:

1. Before Tuesday: say A1 and A2 aloud until they are boring. This is the highest-ROI prep in the pack: the two negatives in your own message are where a hiring manager will press, and the same gaps return on Thursday and Monday in other packaging.
2. Before Tuesday: A4 and E1, the reliability-quarter story and the 60% figure. They reappear on Thursday (E1, F1) and Monday (H2), so one honest, rehearsed version serves three rounds.
3. Before Thursday: E2 (the 40 interviews), D4 and D1, and say B1 aloud once.
4. Before Monday: G1, G2, H1 and H2, then the reverse questions for each round.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The requirements are quoted from the role description you gave me; I have no fuller JD. Your background is the four sentences in your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team of 6, not two squads, and nothing about device-management work, so the words stay at that scope: for three of your nine years you have been a team lead of 6. Answer slot: the role asks for two squads on device-management services; if you have led across more than one team, or worked on anything of that kind, say what and what your part was, in your own words; if not, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description (delivery) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries a reliability quarter pushed through against roadmap pressure, and a 60% on-call drop after it. It does not say whether you owned delivery dates or commitments. Answer slot: the role asks you to own delivery; if you owned delivery commitments for your team, say what they were, in your own words; if delivery was owned elsewhere, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe on the number. Lead with the loop in the sentence's own terms: you run it, for backend roles. The figure is where a prober goes: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours (E2) |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description (growth) | none given | none | [grounded] | discovery | Your material is silent on growing engineers, which is not the same as having none. Answer slot: the role asks you to own growth; if you have helped anyone grow, say how, in your own words; if not, say so plainly and say what you would do first as a plan |
| F5 | "partner with hardware and product on roadmap" — role description (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The sentence touches roadmap pressure without showing who applied it or how it was settled; the pack's derivation is that this is your nearest evidence on the product side. Answer slot: if the pressure came from product and you worked it through with them, say what you did and what was yours; if it came from elsewhere, or there was no negotiation, say so plainly and stay with the quarter |
| F6 | "partner with hardware and product on roadmap" — role description (hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so: "never owned a hardware-adjacent roadmap". Then how you would learn it, said as a plan and never as a past. The pack's observation: the sentence denies owning such a roadmap and is silent on working alongside hardware teams, so A1 asks only about the second |

The role description does not say that managing managers is part of this job, so it is not a row. Your stated negative on it is handled in the prohibited list and in A2, G4 and the Round 1 reverse questions.

## Round 1 — Tuesday, Director of Engineering (your would-be boss), 45 min

**Persona weights, with reasoning**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (4 questions) | Quiet probing of the two gaps in your own message | High. The hiring-manager prior is Case plus Skeptic, because they are buying capability and derisking gaps, and F6 and your managers sentence are stated gaps | Rehearse A1 until boring; acknowledge plainly, then give a plan (A1, A2) |
| Case/Strategist (3 questions) | Live problems on their roadmap: plan two squads, resolve a hardware-versus-product clash | Medium-high. Same hiring-manager prior; the role description gives the problem surface | Clarify, then objective, options, risks; think aloud (B1 to B3) |
| Conversational (2 questions) | Opens with the journey; feels unscored | Medium. A judgment from the format: a 45-minute first conversation with a future boss usually opens this way | A 90-second arc built only from your quoted sentences (C1, C2) |
| Data-Driven Prober | Pulling on the 60% and the 40 | Low here, high on Thursday. A Director may still ask once | Prepare E1 and E2 now; they cover it |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Pause, then give the gap your sentence states: "never owned a hardware-adjacent roadmap", in your own words, once, without padding. Then a plan, said as a plan: who in hardware and product you would sit with first and what you would ask them. The limit, named before it is asked: the sentence denies owning such a roadmap and is silent on working alongside hardware teams. Answer slot: the role asks you to partner with hardware; if you have worked alongside hardware teams in any way, say what and what your part was; if you have not, or it was not yours, say so plainly and stay with the acknowledgment. Hold through two follow-ups by returning to the acknowledgment and the plan, never by adding to them. Concession wording you can use: "That is a real gap and I would rather name it than talk around it." | F6 is where the role's hardware partnership presses hardest and the one gap you stated outright, so this question arrives in some form; JD because it scores the stated requirement, with Skeptic delivery |
| A2 | "You've led a team of 6. This role is two squads and 11 engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Say the scope your sentence carries, in your words: three years as a team lead of 6. Then give what you expect to change as a view, introduced with "I would expect", not as something you have done. Answer slot: the role asks for two squads and 11 engineers; if you have led across more than one team in any form, say how and what part was yours; if not, say so plainly and stay with the team of 6. If pressed on managers, the plain acknowledgment is the sentence you wrote: "I've never managed managers". The role description does not say whether managing managers is part of the job, so ask (Round 1 reverse question 2) | F1 is the scale step the role asks for and F6's companion sentence carries the managers limit; JD because it scores the stated scope |
| A3 | "Why management, and why here, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Build a 60-second answer in three parts, each in your own words: what you do now ("currently at a payments company"), why management rather than staying on the technical path, why this domain. The pack names no reasons for you; none are in your material. Answer slot: the reasons are yours alone; if one is thin, say what you would want to learn rather than dressing it up. Test each reason by asking what else would also satisfy it | Motivation consistency is the Skeptic's standard probe and F1 is the jump being explained; JD because it scores fit to the stated role |
| A4 | "Tell me about a time you had to hold a priority against pressure on the roadmap." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the sentence, and only its beats: a reliability quarter, roadmap pressure, and a 60% drop in your team's on-call burden after it. Tell them in your own words. Answer slot: the role asks you to partner with product; expect a probe on who the pressure came from and how it was settled. If product pushed back and you worked it out, say what you did and what part was yours; if the pressure came from elsewhere, or there was no negotiation, say so plainly and stay with the quarter | F5 and F2 are the only evidence on roadmap trade-offs; EXP because it tests what was actually yours, with the theme from the role description's product partnership |
| B1 | "Two squads share a platform. One has a customer incident, the other has a hardware-dependent release due. Where do the engineers go?" | CASE | [generic] | Clarify first: how severe is the incident, how firm is the hardware date, what is blocked on what. State the objective, lay out two or three options with what each costs, say how you would decide and who you would tell, then name the risk you are accepting. Challenge one premise respectfully, for example whether it is really either-or. The question needs no claim about your past, so the guidance makes none | A live problem from the role description's two squads and hardware partnership (F1, F6); CASE because it scores structure, `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "You inherit two squads. What do you do in your first 30 days?" | CASE | [generic] | A plan, not a past: listen before changing anything, meet each engineer one to one, read what exists on delivery and on-call, find where the squads touch hardware and product, and name what you would deliberately leave alone for now. Say what you would want to be true after 30 days. Nothing here claims experience | The role description's delivery, hiring and growth for 11 engineers (F2 to F4) gives the surface; CASE because it asks for a plan; `[generic]` because it presupposes nothing about you |
| B3 | "Product wants a date. Hardware says theirs may slip. What do you tell product?" | CASE | [generic] | Separate what is known from what is estimated, give a range with what it depends on and when you will know more, say what you would ask hardware for, and say what you would trade if the date is fixed. Hold the range even under pressure to give a single date. No claim about your past is needed | F5 and F6 together: the seam the role sits on; CASE because it is a decision under uncertainty |
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc made only of those sentences: nine years in engineering, three as a team lead of 6, now at a payments company. Add the two points you can stand behind as the sentences state them: you run the hiring loop for backend roles, and the on-call drop after the reliability quarter. End on why this role, in your own words (A3). Do not add titles, dates or team names you did not give | A biography question is scored even when it feels casual; EXP because it tests the CV-level claims, and F1 to F3 are the sentences it draws on |
| C2 | "What are you playing with in IoT or device management these days?" | JD | [generic] | Selection scaffold: pick the nearest thing you have actually touched that resembles long-lived remote clients, versioned rollouts or fleet-level state. If nothing comes to mind, say so plainly, then say what you would learn first and why. Never describe a project you have not done | The role description names device-management services, which makes a casual question about it a scored one (F1); JD because it scores domain fit |

**Reverse questions, Round 1**

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make the first six months a clear success for the two squads?" | It asks for the Director's own scoring sheet and gives you something concrete to prepare against |
| 2 | "Of the 11 engineers, does anyone already act as a lead, and is managing managers part of this role now or later?" | It settles how much weight your stated gap actually carries, and the role description does not say |
| 3 | "Where do the squads work well with hardware and product today, and where is there friction?" | It moves the hardware gap from a confession to a working question and tells you which seam to learn first |
| 4 | "How would you like to hear about a problem in my squads: early and rough, or later and settled?" | A boss's working style, asked in a way that shows you are already thinking about reporting up |
| 5 | "What do you expect to be the hardest part of this role for whoever takes it?" | It invites the objection you most need to hear, and lets you respond to it on the day |

## Round 2 — the Thursday after, panel of two staff engineers and a product manager, 60 min

No names were given, so personas are assigned by role, not person.

**Persona weights, with reasoning**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (4 questions) | Seam-splitting, "what would you need from me", disagreement and credit probes | High. The panel blends the top two personas of each member's relationship: the staff engineers sit beside the role (Peer plus Prober) and the product manager is cross-functional | Offer seam principles rather than pretending to know the seam; reciprocity framing (D1 to D4) |
| Data-Driven Prober (3 questions) | The 60% and the 40 taken apart, plus domain depth from the staff engineers | Medium-high. Two figures in your material are the kind a prober pulls on, and staff engineers are the likeliest to test depth | Know what you can and cannot say about how each number was counted, and say plainly when you do not know (E1 to E3) |
| Values/Behavioral (2 questions) | A product manager's collaboration and disagreement stories | Medium. The cross-functional prior is Values plus Conversational; the role asks you to partner with product | Story-map from the quoted sentence; say plainly where the story ends (F1, F2) |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where is the seam between engineering and product on the roadmap, and what happens when we disagree?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Offer seam principles instead of pretending to know where the seam is here: who owns the what and the why, who owns the how and the when, and what is escalated and to whom. For disagreement, say how you would work it: put the trade-off in the open, bring the cost of each option, agree who decides before you start. You may mention the reliability quarter exactly as the sentence states it. Answer slot: if product was party to that disagreement and you settled it with them, say how; if not, say so plainly and stay with the principles | F5 is the only evidence on roadmap disagreement, and a product manager on the panel will go there; CASE because it asks for a method, with Peer delivery |
| D2 | "A staff engineer on your squad pushes back hard on a call you have made. What do you do?" | CASE | [generic] | A method, not a past: ask what they would do instead and why, separate the decision from the disagreement, say what would change your mind, then decide and explain the reason either way. Say when you would hold the call and when you would reverse it. No claim about your past is needed | The panel's two staff engineers are the people you would manage around; F2 is the delivery-ownership requirement this tests; CASE, `[generic]` |
| D3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Principles first: credit goes to named people and named contributions, and you separate what your team did from what others did. Use the sentence at its own scope: "my team's on-call burden", and that you pushed the quarter through. Answer slot: if anyone outside your team contributed to the quarter, say who and what; if no one did, say so plainly and stay with what the sentence says | A peer-style probe that returns the reliability story in collegial packaging (F2); VAL because it scores how you treat colleagues |
| D4 | "You would be hiring into these squads. How do you run a loop so the staff engineers trust the result?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the sentence in its own terms: you run the hiring loop for backend roles. Answer slot: the role asks you to own hiring; if some part of how the loop works was yours to set, say which and how you decided, in your own words; if you ran a loop that was set by others, say so plainly and describe how you run it. Then say what you would want the staff engineers to be doing in it, as a plan | F3 is the evidence for the hiring requirement; JD because it scores a stated responsibility, with a staff engineer's trust as the angle |
| E1 | "That 60% — walk me through how it was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say what the sentence says and no more: on-call burden dropped 60% after the quarter. Then the four defend-the-number moves, each in your own words: what the figure measured and against what comparison, what it is most sensitive to, which assumption behind it you would defend least, and which part of it was yours. Answer slot: if you know how it was counted, say it; if you do not know how it was counted, say so plainly and say who would. The limit: the sentence says "after", not "because", so expect "what else changed in that period", and answer with what you know | A headline figure is a prober's magnet (F2); EXP because it scores attribution, and the weakest-assumption move turns a gotcha into credibility |
| E2 | "About 40 interviews last year. How many were yours, and how was that counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say the sentence as written, then resolve any ambiguity downward: whichever reading claims less. Answer slot: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words; if you do not know how it was counted, say so plainly. Do not turn the number into a statement about how well the loop works | F3's figure is the second number on the panel's table; EXP because it scores how the number was counted and what was yours |
| E3 | "What do you know about running device-management services at scale?" | JD | [generic] | Selection scaffold: pick the nearest system you have run that had long-lived remote clients, versioned rollouts or fleet-level state, and say what is the same and what is not. If none comes to mind, say so plainly, then say how you would get up to speed and who you would ask first. Never claim a depth you do not have in front of two staff engineers | Staff engineers test domain depth, and the role description names device-management services (F1); JD, `[generic]` because the pack has no company research on their stack |
| F1 | "Tell me about a time you and a product partner disagreed about priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the sentence, its beats only: a reliability quarter, roadmap pressure, the on-call drop after. Answer slot: the role asks you to partner with product; if the pressure came from a product partner, say how the disagreement went and what part was yours, in your own words; if it did not, or nothing was negotiated, say so plainly and give the nearest thing your material carries or how you would handle it | The product manager's likeliest behavioral probe, and F5 is the only evidence on it; VAL because it scores how you behave with a partner |
| F2 | "What does a good working relationship between an engineering manager and a product manager look like to you?" | VAL | [generic] | A view, not a past: shared goals stated up front, trade-offs made visible, no surprises in either direction, a way to disagree that does not go through escalation first. Say what you would want from them and what you would offer. Nothing here is a claim about your history | The product manager is a panel member and the role description names product partnership (F5); VAL, `[generic]` because it asks for a view |

**Reverse questions, Round 2**

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want a new engineering manager to take off your plate, and what would you want them to leave alone?" | Reciprocity: it asks what the panel needs from you, before telling them what you want |
| 2 | "What could a new manager do in the first month that would genuinely help the squads?" | A direct, peer-level reciprocity question with a concrete answer to take into month one |
| 3 | "How are roadmap trade-offs between product, hardware and engineering settled today, and where does it hurt?" | The product manager's answer maps the seam you said you do not know yet |
| 4 | "What does on-call look like for these squads right now?" | It connects to the reliability work in your material without claiming anything about this team |
| 5 | "When a technical decision is contested, how do you decide whether it is the staff engineers' call or the manager's?" | It shows you are already thinking about the boundary between you and the people you would manage around |

## Round 3 — the following Monday, VP Engineering, 30 min, "values and leadership philosophy"

The recruiter's description is the only source for the round, and it documents a values-style round. Larkfield's published values were not in hand, so there is no values cheat sheet. Themes come from the recruiter's words and the persona stems.

**Persona weights, with reasoning**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (5 questions) | "Tell me about a time…" probes about leadership and what you stand for | High. The recruiter described the round as values and leadership philosophy | Map a story where one of your sentences carries one; where none does, a scaffold with an honest branch (G1 to G5) |
| Pressure (3 questions) | Time-boxed, devil's advocate: why you over someone who has done it | Medium-high. The executive prior is Case plus Pressure, 30 minutes is short, and your two stated negatives are what a pressure interviewer reaches for | Hold a position through two follow-ups, concede specifically, never fold on the core (H1 to H3) |
| Case/Strategist (2 questions) | Altitude: what the org should optimize for | Low-medium. The executive prior says strategy-heavy, but the recruiter's framing tilts it toward values; company questions stay `[generic]` without research | Say your hypothesis early and ask one clarifying question (I1, I2) |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What is your leadership philosophy?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name two or three principles in your own words; the pack names none for you. Tie each to something you can say at the scope of your own sentences: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Answer slot: what principle each of those decisions reflects is yours to state; if a principle came after the fact rather than before it, say so plainly. Stay under 90 seconds and let the VP draw the inference | The recruiter's own description makes this the likeliest opener (F2, F3); VAL because it scores what you stand for |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The sentence carries a reliability quarter and roadmap pressure; it does not say leadership was the audience. Answer slot: if you told someone senior something unwelcome in that quarter, say what you said, how it landed and what part was yours; if the pressure did not come from leadership, or no such conversation happened, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard values-round stem on the VP's stated theme; F2 is the nearest evidence and does not reach it, so the guidance stays inside the sentence |
| G3 | "Tell me about a hiring decision you were unsure about." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Selection scaffold: pick one decision with a named stake, what you weighed, what you did and what you would do differently. It must be one you can talk about for 90 seconds without adding detail. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: that you run the hiring loop for backend roles, or how you would handle it | The role description names hiring (F3), and leadership philosophy rounds often use a people decision; VAL, with the theme from the role description |
| G4 | "What kind of manager do you want to be, and what is your plan for the part you have not done yet, managing managers?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Say the plain acknowledgment first: "I've never managed managers." Then your view of the manager you want to be, in your own words, and a plan said as a plan: what you would learn first and from whom. Do not claim a version of management you have not done. Hold through two follow-ups by returning to the acknowledgment and the plan | The one stated gap a leadership round will reach; the pack's observation is that the role description does not say managing managers is part of the job, so see also Round 1 reverse question 2 (F1) |
| G5 | "How do you think about growing the engineers on your team?" | JD | [generic] | A view: what you would want to understand about each person, how you would find out what they want, and what you would do when your view of their next step and theirs differ. Answer slot: the role asks you to own growth; if you have helped anyone grow, say how and what was yours, in your own words; if not, say so plainly and say what you would do first | The role description names growth for 11 engineers and your material is silent on it (F4); JD, `[generic]` because the pack has no quoted sentence for it |
| H1 | "You have 60 seconds. Why you, rather than someone who has managed managers or owned a hardware roadmap?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Hold-then-concede. Hold only what your sentences carry: nine years in engineering, three as a team lead of 6, and you run the hiring loop for backend roles. Concede specifically and without softening: "I've never managed managers and never owned a hardware-adjacent roadmap." Do not claim to be better than that candidate; say what you would bring and what you would learn. Hold through two follow-ups; do not fold on what you stated, do not add to it | Pressure's stem aimed at exactly where your material is thin (F1, F6); the rationale for VAL is that the VP's frame is values, so the pressure is on your honesty |
| H2 | "That result, the 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold what the sentence says: "I pushed a reliability quarter through", and your team's on-call burden dropped 60% after it. Then be exact about the rest: which part was yours, which others', what else changed in that period. Answer slot: if you know how much of the drop the quarter explains, say so in your own words; if you do not know, say so plainly. Hold through two follow-ups; the strongest hold here is the plainest one | The attribution probe is a Pressure staple and F2 is the figure it targets; EXP because it scores precision about what was yours |
| H3 | "Would you push reliability over the roadmap again here if a hardware launch were at stake?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A decision method: what the launch depends on, what the reliability risk is, what you would trade, who needs to hear it and when. Hold your principle and concede the conditions: it depends on the facts. You may mention the earlier quarter at the sentence's own scope. Answer slot: if what you weighed that time is something you remember, say it; if not, say so plainly. Nothing here promises an answer you would give | A hypothetical built on F2 and the role's hardware side (F6); CASE because it asks for reasoning under pressure |
| I1 | "If we are a device-management business, what should engineering here optimize for in the next year?" | CO | [generic] | Say your hypothesis early and ask one clarifying question. Reason from what the role description gives: delivery, hiring, growth, a roadmap shared with hardware and product. Make no claim about Larkfield's strategy; the pack has none. The honest cost of declining research is that this stays generic | The executive prior includes strategy altitude; CO because it scores thinking at company level, `[generic]` because no company research ran |
| I2 | "What would need to be true in 90 days for me to say hiring you was right?" | CASE | [generic] | A short list, in your own words, of outcomes you could be held to, framed as what you would aim for, not what you have done. Say how you would know and how you would tell the VP early if it was not going to happen | A close-out stem for a 30-minute round, tied to the role description's delivery, hiring and growth (F2 to F4); CASE because it asks for a plan with measures |

**Reverse questions, Round 3**

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does good leadership look like here when reliability and the roadmap collide?" | It connects to the one story in your material and asks the VP's philosophy rather than reciting yours |
| 2 | "What do you look for in someone moving from team lead to engineering manager?" | It asks directly about the jump you are making, which turns your hardest motivation probe into a conversation |
| 3 | "How do you develop first-time managers here?" | It shows you are planning for the part you have not done, and it tests whether the org invests in it |
| 4 | "Where do you want engineering to be in two years, and what depends on the managers?" | Altitude: it lets you hear the strategy from the person who owns it |
| 5 | "What is one thing a new manager here should be honest with you about in the first 90 days?" | It signals candor, which is the theme your own answers have carried |

## Requirement coverage across the loop

| Requirement (source) | Questions |
|---|---|
| Lead two squads building device-management services (F1) | A2, A3, B1, B2, C2, E3, H1 |
| Own delivery (F2) | A4, B1, B3, D2, G1, G2, H3, I2 |
| Hiring (F3) | C1, D4, E2, G1, G3 |
| Growth (F4) | G5, B2, I2 |
| Partner with product on roadmap (F5) | A4, B3, D1, D3, F1, F2 |
| Partner with hardware on roadmap (F6) | A1, B1, B3, H1, H3 |
| Headline figure: the 60% (F2) | E1, H2 |
| Headline figure: the 40 interviews (F3) | E2 |
| Managing managers: not in the role description, a stated negative of yours | A2, G4, H1 |
| Values and leadership philosophy: the recruiter's description of Round 3 | G1 to G5, H1 to H3 |

## Prohibited claims (shared across all three rounds)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message. The plain acknowledgment is "I've never managed managers". No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated | The same sentence, "never owned a hardware-adjacent roadmap". A1's slot asks only about working alongside hardware teams, which is a different claim |
| Has led two squads or 11 engineers | Inflated form of F1 | "9 years engineering, 3 as a team lead of 6, currently at a payments company" at its own scope. The limit is the pack's observation: your material says a team of 6, not two squads or 11 engineers. A2's slot stays inside the team of 6 |
| That the reliability quarter alone produced the 60% drop | Inflated form of F2 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" at its own scope; the pack's observation is that it says after, and E1 and H2's slots ask only what you know about how it was counted and what was yours |
| Designed the hiring loop, or ran all 40 interviews yourself | Inflated form of F3 | "I run our hiring loop for backend roles — about 40 interviews last year" at its own scope. The pack's observation: the sentence says you run it, not that you designed it, and does not say whose the 40 were; D4 and E2's slots stay inside that |

## Sources

**Provided documents:** your message (the role description, the three rounds and who runs each, the recruiter's description of Round 3, and the four sentences about your background). No tuesday-dossier.md was present.

**Searches sent (all three were refused, so nothing came back):**
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The call was refused. It would have produced a Monday values cheat sheet with the official value names; without it there is none |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The call was refused. It would have checked the loop and each round's format against your account; persona weights rest on your own words and the relationship priors |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The call was refused. It would have grounded I1 and the Round 1 CASE bank in current priorities; both stay `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot rows and the JD-tagged questions; a fuller JD would add rows (see the upgrade menu) |

## Upgrade menu

- The full JD text → mid-list requirements and any named tools or methodologies become `[grounded]` rows with their own questions, and F1 to F6 may gain or lose rows
- Your CV → evidence on F1 to F4 can become fuller quoted sentences, and rows now `low` or `none` may rise
- The artifact behind the reliability quarter, such as the on-call dashboard export or the quarter's review write-up → F2 and F5 can move from `medium` and `low` towards `high`, and E1's slot can be answered from the record
- Your answers to the slots in F1, F2, F4 and F5 → those rows regenerate with your words quoted, and the A, D, F and G banks update
- The recruiter's prep email → panel names, whether Round 2 or 3 includes a prepared exercise, whether the 11 engineers include leads, and whether Larkfield has published values; each reweights a bank or adds a section
- Interviewer names → a public-footprint read of each, persona weights tuned to their path, and a reverse question tied to each person's own career
- Web search access for company research → Larkfield's published values for a Monday cheat sheet, the loop checked against your account, and I1 and the case bank made `[grounded]`
- A tuesday-dossier.md from job-underwriter → verified evidence with confidence bands, a sourced prohibited-claims list and an evidence-derived top objection in place of the one this pack inferred
