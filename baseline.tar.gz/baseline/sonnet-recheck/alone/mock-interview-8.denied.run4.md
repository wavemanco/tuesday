I'm fixing two sentences in the pack that claimed more than I know about the panel, then checking the file for stray brackets.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-denied-a635aeb2/e3730e56-0eb2-47f0-a4f8-3854e4d3255a/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it for three rounds still ahead of you, with separate question banks and persona weights for each round. The recruiter's email names all three rounds, so I ran no searches. Your pasted values and the strategy brief points covered the rest.

I couldn't check the pack against the Ashgrove documents beyond what you pasted. The strategy brief itself wasn't pasted, only the four items you listed.

Every claim about your past in the pack rests on one of your four background sentences. Where those sentences go quiet (digital-team work, which rules governed your complaints log, what your spreadsheet counted), the pack gives you a two-way answer slot to fill in your own words rather than inventing a story.

Your two stated gaps are in there honestly: you've never worked in a contact centre, and you've never presented above regional level. The pack's single most valuable rehearsal is question D1, "This role covers the contact centre, and you've never worked in one. Why should I believe you can own it?"

Say the word and I'll play the Head of Member Services as a Skeptic on D1, with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Your note dates itself 12 October with the rounds on 21 October, but my clock reads 5 November. Are the rounds still ahead of you, or have some already happened? If some have, I'll rebuild the pack as a debrief and a plan for what's left.

Does the 20-minute escalation case come with any pre-read or brief, or is it live on the day? A pre-read would earn its own build section.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 21 October, named in the recruiter's email.

| Round | Who | Length | Relationship | What the recruiter said |
|---|---|---|---|---|
| 1 | The recruiter | 30 min | Recruiter screen | none beyond the length |
| 2 | Head of Member Services | 45 min | Your future manager | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Panel, stakeholders for the role | Includes a 20-minute case on a complaint escalation; "the values round — they score against the four values" |

Interviewers beyond their roles have not been assigned, so there is no interviewer read. This pack stays in session terms for each round and rests its persona weights on the recruiter's email.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

Question IDs are lettered by persona and carry across rounds. They skip F so they never collide with the fit-snapshot rows F1 to F9.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values |
| EXP | Whether a claim about your past survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, reasoned aloud |

Answer slots are instructions for the interview, not questions for you now. Each has two branches, and either is a good answer if it is true.

## Fit snapshot

Your four background sentences are the only evidence in this pack, and every quote below is one of them. Where the material is silent, the row holds an answer slot rather than words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log and a script you trained tellers on, with nothing inspected behind it. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what your part was once a complaint had been logged. If you stayed with it beyond the log, say how far and what you did, in your own words; if the log was where your part stopped, or there was no later step you saw, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet that you built and your regional manager uses; it does not show what the spreadsheet counted. Answer slot: expect a probe on what it counted and how. If you know, say, in your own words; if you do not know how something was counted, or it was not counted, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says spreadsheet, not which tool. Answer slot: if it was in Excel, say so and say what you did in it, in your own words; if it was another tool, say which, plainly, and stay with what you built |
| F5 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | At its own scope your sentence says new tellers and an escalation script, and the script is "our" script, which the sentence does not make yours. Words: "trained new tellers on our escalation script." Answer slot: expect a probe on whether anyone more senior than a new teller had it from you. If you coached anyone beyond new tellers, say who and how, in your own words; if not, say so plainly and stay with the new tellers |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log; it does not show which rules governed it. Answer slot: expect a probe on which rules governed the log. If you know them, name them in your own words and say what they required of you; if the log was kept to internal practice, or you were not the one working to the rules, say so plainly and stay with the log you handled |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the years, but a line with nothing inspected behind it, so expect a probe on what the supervisor years held. Lead with it in its own terms: 6 years in retail banking, the last 3 as a branch supervisor |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for your first senior presentation, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital-team work. Answer slot: expect a probe on it, since the strategy brief puts 40% of member service on digital channels by 2028. If you worked with a digital team on anything members used themselves, say what and what part was yours; if you did not, say so plainly and stay with the log you handled and the script you trained tellers on |

## Grounding brief

Ashgrove's current priorities, in the words of the 2026 strategy brief as you relayed it, so you sound current.

| Item | What it says | Provenance | How it shows up in the loop |
|---|---|---|---|
| Scale and form | Member-owned, about 900 staff — JD | [grounded] | Use "members", not "customers", in every answer |
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | A2, E1, and the digital-teams line in the JD (A3) |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | [grounded] | H3 and every question from the branch managers in round 3 |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | A new product brings complaints with it; usable in E2 |
| Competitive frame | Main competitive pressure is app-only banks | [grounded] | Why self-service has to work; usable in E1 |

## Round 1 — the recruiter, 30 minutes

### Persona weights

| Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational | high | Friendly, unstructured: the journey, what you know of Ashgrove | The relationship prior for a recruiter screen is Conversational plus a light Skeptic; nothing in the email shifts it | A pre-scripted 90-second arc for A1; treat every casual question as scored |
| Skeptic, light | medium | Knockout checks: the newest part of the job, the years, why now | Same prior; F2 and F8 are gaps you stated, so a check on them is likely | Rehearse B1 until it is boring |

### Question bank

**A — Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. How did you get to this role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc whose beats are only what the quotes state: 6 years in retail banking, the last 3 as a branch supervisor; the branch's formal complaints log you handled; training new tellers on the escalation script; the monthly complaints spreadsheet you built that your regional manager uses. Say each at that scope. Answer slot: why this role and why now, in your own words, since nothing in the material supplies it | Casual openers are scored, and this arc is what every later answer hangs on. F7, F1 and F3 are the rows it touches; EXP because it tests the sequence on your own record |
| A2 | "What do you know about Ashgrove, and why a member-owned credit union?" | CO | [grounded] | Use the grounding brief in its own words: 40% of member service digital by 2028, eight branches into five hubs over 2027, small-business lending in Q1 2027, app-only banks as the main pressure. Pick one and say, as your view and not as a fact about Ashgrove, what it means for how members get help or complain. Answer slot: why a member-owned credit union, in your own words | The recruiter sent the brief, so it is fair game even in a screen. CO because it tests homework depth rather than your record |
| A3 | "The role works with digital teams on self-service journeys. Where have you come across that kind of work?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | No quoted sentence carries digital-team work, so this is a selection scaffold: pick a moment where you saw how members handled something themselves rather than at the counter. It needs a named situation, what you saw, and what changed afterwards. If no such time comes to mind, say so plainly, then say what your material does carry — "trained new tellers on our escalation script" or "built the monthly complaints spreadsheet" — and how you would start working with a digital team | F9 is a silent row against a JD line the strategy brief reinforces. JD because it scores a stated responsibility |
| A4 | "The role asks for 4+ years in financial-services customer operations. Does your background cover that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer in the quote's own terms and stop: 6 years in retail banking, the last 3 as a branch supervisor. Answer slot: expect a follow-up on what the supervisor years held. Answer from what you did, in your own words; if some part was not yours, or there was no such part, say so plainly and return to the 6 years | F7 is the cleanest row and the one a screen checks first. JD because it is a stated requirement |

**B — Skeptic, light**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would be newest to you on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the contact centre first, plainly, in the quote's words: "Never worked in a contact centre." Then a plan, in the future tense: who you would sit with and what you would read before changing anything. Raise the second gap only if asked: "I've never presented to anyone above regional level." Do not offer either as a strength | F2 and F8 are the gaps you stated, and a recruiter screens for them early. JD because it tests honest self-assessment against the listed job |
| B2 | "The role owns the complaints process across branches and the contact centre. How does your experience map to that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the sentence at its scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. The limit is this pack's observation: your material says the branch's log, not a process across branches, and not the contact centre. Answer slot: expect a probe on what your part was once a complaint had been logged. If you stayed with it beyond the log, say how far and what you did, in your own words; if the log was where your part stopped, or there was no later step you saw, say so plainly and stay with the log | F1 is the evidence for the role's headline line and the likeliest place to be pressed. JD because it scores the stated scope |
| B3 | "Tell me about the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Premised on your sentence: tell it at its beats — you handled it, it was the branch's, it was a formal log. Answer slot: expect a probe on which rules governed the log. If you know them, name them in your own words and say what they required of you; if the log was kept to internal practice, or you were not the one working to the rules, say so plainly and stay with the log you handled | F6 is the row where the JD asks for something your sentence does not show. EXP because it tests what was actually yours |
| B4 | "What's behind looking for a move now?" | JD | [generic] | The reason is yours and the pack has none to supply. Structure it as what this role adds that your current one does not, taken only from the JD's own lines, then one sentence on Ashgrove. Answer slot: the reason itself, in your own words | Motivation consistency is the usual recruiter check. JD because it tests fit with a step up from supervisor; generic because it makes no claim about your past |

### Reverse questions — round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Could I have the names of the panel for the third round?" | Practical, and it lets your prep be tailored to named people |
| 2 | "What does the 20-minute case in the panel round look at — escalation judgement, communication, or process?" | Shows you are already preparing for the case |
| 3 | "How does the panel score the four values — is it a story for each, or a conversation?" | Signals you know the panel is the values round, from the recruiter's own email |
| 4 | "Which of the 2026 strategy priorities does this role touch first?" | Shows you read the brief the recruiter sent |
| 5 | "Where does the complaints work sit today between the branches and the contact centre?" | Shows you read the JD's scope and are asking about the part you have not worked in |

## Round 2 — the Head of Member Services, 45 minutes

### Persona weights

| Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | high | "Tell me about a time" questions | The recruiter's email says "mostly behavioural", which lifts this above the hiring-manager prior of Case plus Skeptic | "We" for context, "I" for contribution; stories at the scope of your quotes |
| Skeptic | high | The gaps pressed in a manager's register | A future manager is derisking, and F2 and F8 are stated gaps | Hold-then-concede on D1 and D2 |
| Case/Strategist | medium | Live problems on the role | Hiring-manager prior, but the email assigns the case to the panel round | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Prober | low | Line-by-line questions on the spreadsheet | One CV-style line carries the reporting claim; D3 may be pushed two levels deep | Say plainly what you know and do not know about how it was counted |
| Pressure | low | Interruptions on D1 and D2 | The email signals no stress format; the gaps may be pressed hard anyway | Pause, restate, hold through two follow-ups |

### Question bank

**C — Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | A selection scaffold with the spreadsheet as the nearest anchor: pick a time the figures were uncomfortable for someone senior. It needs a named figure, who heard it, what you said, and what happened. If no such time comes to mind, say so plainly, then say what the spreadsheet was and who used it, or how you would deliver that message | The role reports monthly to leaders, so this is the likely behavioural probe. F3 is the nearest row, and it holds no story of this kind; VAL because it scores behaviour, not the spreadsheet |
| C2 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the quote's beats only: new tellers, the escalation script, you trained them. Answer slot: the JD asks about supervisors, so expect a probe on whether anyone more senior than a new teller had it from you. If you coached anyone beyond new tellers, say who and how, in your own words; if not, say so plainly and stay with the new tellers | F5 is the evidence for the role's coaching line. JD because it scores that line; the behavioural frame is the manager's |
| C3 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a complaint you stayed with. It needs a named complaint with no identifying member details, what you did to keep hold of it, and how it ended. If none comes to mind, say so plainly, then say what you did with the log, in your own words, or how you would keep hold of one. Expect this value again in round 3, so keep the same facts both times | This is Ashgrove's fourth value, "Own the Fix", asked in a manager's register. F1 is the nearest row and carries no such story; VAL because it scores a published value |

**D — Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role covers the contact centre, and you've never worked in one. Why should I believe you can own it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The deepest rehearsal in this pack. Level one: the plain acknowledgment, "Never worked in a contact centre," said before they get there, then what you did at its own scope: "handled the branch's formal complaints log and trained new tellers on our escalation script." Level two, "so how would you learn it": a plan in the future tense; structure only — who you would sit with first, what you would read before changing anything, and what you would leave alone until you had. Level three, "so you can't own it": hold, do not claim equivalence, and concede one thing specifically. Answer slot: the one thing about the contact centre you would most need to learn first, in your own words | F2 is a capability gap set against the JD's scope line, so this question will arrive in some form: it is the highest-ROI prep in the pack. A rehearsed, non-defensive answer here changes the interview. JD because it scores a stated requirement |
| D2 | "You'd report to senior leaders every month. What's your experience of presenting to them?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then the nearest thing at its scope: a monthly complaints spreadsheet you built and your regional manager uses — a report, not a presentation, and say it as that. Then a plan for your first senior presentation: what you would lead with and who you would rehearse with, in your own words. If pressed on confidence, concede you have not done it at that level and say what you would do to be ready | F8 is the second stated capability gap; the JD names senior leaders. JD because it scores that requirement |
| D3 | "What would be in the monthly complaints report you'd give me?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the sentence: a monthly complaints spreadsheet, built by you, used by your regional manager. Answer slot: expect a probe on what it counted and how. If you know, say, in your own words, and name the weakest assumption in how something was counted before they do; if you do not know how something was counted, or it was not counted, say so plainly. Then, as a plan, what you would want this report to show. Answer slot: which tool it was built in; if Excel, say so; if not, say which | F3 and F4 are the reporting rows. JD because it scores the reporting line; the prober probes follow from it |

**E — Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. Where do complaints fit in that?" | CO | [grounded] | Clarify first: which journeys move first, and what counts toward the 40%. Then objective, segmentation by complaint type, approach, metrics (volumes and resolution times are the JD's own reporting lines), risks. Challenge one premise respectfully: whether a complaint is a self-service journey or the route to a person, with app-only banks as the competitive frame. Use "Plain Words" as your test: if a member needs it explained twice, it was written wrong | The brief's 40% target meets this role's digital-teams line, so a strategy question from the manager is likely. CO because it tests thinking at the company's altitude |
| E2 | "Sketch your first ninety days owning complaints here. What do you need to know first?" | CASE | [grounded] | Clarify before structuring: what the process looks like in branches and in the contact centre, who has it today, what is reported. Then the plan: listen before changing anything, say aloud that the contact centre is the part you have not worked in, and name who you would pair with. Close on "Own the Fix": who holds a problem until it is solved. Mention the Q1 2027 lending launch as a new source of complaints to prepare for | A manager's natural case on their own role. CASE because it scores structure and sequencing, and it presupposes nothing about your past |

### Reverse questions — round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "How are complaint volumes and resolution times reported today, and what would you want changed?" | Shows you think in the JD's own reporting terms |
| 2 | "Given I haven't worked in a contact centre, who in your team would you pair me with in my first month?" | Turns a stated gap, in your own words, into a plan with a name on it |
| 3 | "Where do you expect the move to 40% digital to land hardest on complaints?" | Shows strategy fluency and asks for the manager's view |
| 4 | "Which senior leaders would I report to, and how often?" | Directly addresses the presenting gap without apologising for it |
| 5 | "What would success look like at six months, and what would worry you?" | Invites the manager's honest risk list |

## Round 3 — panel of two branch managers, 60 minutes

Twenty minutes of this round is the escalation case. The panel scores against the four values.

### Persona weights

| Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | high | One story per value, scored | The recruiter's email says this is the values round, scored against the four values | Map a story to each value where your quotes carry one; use the scaffold where they do not |
| Case/Strategist | high | The 20-minute escalation case | The email names the case and its length | Clarify before structuring; use the company's values as vocabulary |
| Peer Evaluator | medium | Seams between the role and the branches | Both panellists are branch managers; no names are known, so there is no split per member | Offer seam principles; reciprocity; credit-sharing at the right scope |
| Skeptic | low | The gaps returning in collegial packaging | The email gives no sign of a gap-focused panel | Same plain acknowledgments as D1 and D2 |

### Question bank

**G — Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A selection scaffold: pick a decision where the member's side and the branch's side differed. It needs a named decision, what it cost you or the branch, and how it ended. If no such time comes to mind, say so plainly, then say what you did with the log, in your own words, or how you would decide | Tests "Members First, Always", the first published value. F1 carries no such story; VAL because it scores the value, not the log |
| G2 | "Tell me about a time something you'd written or explained needed explaining twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the quote's beats only: new tellers, the escalation script, you trained them. Answer slot: the value's own test is whether anything had to be explained twice, so expect a probe on whether the script or your training did. If some wording needed fixing, say what and what part was yours; if nothing did, or the script was not yours to change, say so plainly and stay with training tellers on it | Tests "Plain Words". F5 is the nearest row, and "our" in your sentence does not make the script yours; VAL because it scores the value |
| G3 | "Tell me about a time what the numbers said and what a branch's town needed pulled in different directions." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I built the monthly complaints spreadsheet our regional manager uses." | A selection scaffold: pick a time a figure and a local need disagreed. It needs a named figure, what the local need was, and what you did. If no such time comes to mind, say so plainly, then say you were a branch supervisor for the last 3 years and built the monthly complaints spreadsheet your regional manager uses, or say how you would weigh the two | Tests "Neighbours, Not Numbers", asked by branch managers. F3 and F7 are the nearest rows and hold no such story; VAL because it scores the value |
| G4 | "How do you keep hold of a problem when it crosses someone else's patch?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A how-answer, not a past claim: who holds it from the moment it is found, how you tell the other party, how you keep checking until it is closed, and how you tell the member in plain words. If a real case comes to mind, use it in your own words; if none does, say so and keep to how you would hold it, with the log you handled as your nearest fact | Tests "Own the Fix". F1 is the nearest row; VAL because it scores the value. Expect the same value from the round 2 manager, so keep the facts identical |

**H — Case/Strategist (the escalation case)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's formal complaint has been passed back and forth between a branch and the contact centre, and each says it belongs to the other. What do you do?" | CASE | [grounded] | Clarify first: where the complaint is now, who last spoke to the member and what they were told, and what time limits apply. Then objective: the member hears one plain explanation from one person. Own the Fix: whoever has it keeps hold of it until it is solved, starting now. Last, the process fix, so it does not recur. Spend about 3 minutes clarifying and say your structure aloud | The recruiter named a 20-minute escalation case and this is its likeliest shape. CASE because it scores structure on a live problem and presupposes nothing about your past |
| H2 | "A supervisor at one of our branches keeps escalating things that could have been settled at the counter. How do you coach them?" | CASE | [generic] | Clarify first: is it a pattern or an isolated case, what do they say is stopping them, and does the script help or hinder. Then coach rather than correct: listen first, agree what good looks like, and follow up. Challenge one premise: whether the escalations are the supervisor's habit or a gap in the process | Tests the JD's coaching line in the form a branch manager will have lived. CASE because it is a live problem; generic because it is a pattern for the problem, not a fact about Ashgrove |
| H3 | "Eight branches are consolidating into five hubs over 2027, and complaints from a branch that is being folded in are rising. What do you do?" | CO | [grounded] | Clarify first: what is driving the complaints, which members are affected, and what has been said to them. Objective: members stay members. Approach: listen before changing anything, take it with the branch manager, put the plain explanation in members' hands. Metrics: volumes and resolution times by branch. Risks: tell the branch whole numbers without telling its town. Use "Neighbours, Not Numbers" as your frame | The brief's consolidation is the strategy item closest to branch managers. CO because it tests thinking at Ashgrove's altitude |

**J — Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Our branches and your role sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles rather than pretending to know the seam: the branch manager owns the branch's members and staff, you own the process and the report, and neither surprises the other. For a disagreement, say what you would do first (listen to their reasons) and when you would escalate. Add what you bring them, not only what you need | A branch manager is pricing what this hire costs and gives them. CASE because it is a live collaboration scenario; generic because it makes no claim about your past |
| J2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | "We" for context and "I" for contribution, using only what your sentences say: you built the spreadsheet, you handled the log, you trained new tellers on the script. Answer slot: if others contributed to the spreadsheet or the log, say so plainly and say what part was yours; if the script was someone else's, say that too | A peer-register credit probe returns the attribution question. F3 and F5 are the rows; EXP because it scores what was actually yours |
| J3 | "The reporting you'd produce will make some branches look worse than others. How do you present that to us?" | CASE | [grounded] | Clarify first: what is being compared and why, and what each manager can see. Present the comparison with the local context beside it and the branch manager first, before it goes up. Use "Neighbours, Not Numbers" as your frame. Offer a way for a manager to challenge a figure before it goes to leaders | Tests whether the reporting line costs the peer goodwill. CASE because it is a role scenario; grounded in the values page |

### Values / principles cheat sheet

Ashgrove's four published values, in the names the page gives them, mapped to a story where one of your quoted sentences carries it and to a scaffold where none does.

| Value (official name) | Working meaning | Your mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." No sentence carries a member-side decision, so use G1's scaffold, including its honest branch | G1 |
| Plain Words | If a member needs it explained twice, the writing was wrong | F5: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Its beats are the new tellers, the script and your training of them; whether anything needed rewording is G2's answer slot | G2 |
| Neighbours, Not Numbers | Every branch is part of its town | F3: "I built the monthly complaints spreadsheet our regional manager uses." The sentence carries the numbers but no town story, so use G3's scaffold, including its honest branch | G3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Its only beat is handling the log; a complaint you kept hold of is G4's and C3's scaffold | G4, C3 |

### Reverse questions — round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | Reciprocity: asks what you can give them rather than what you need |
| 2 | "When a complaint escalates from your branch, what do you wish happened differently?" | Invites the branch managers' own experience of the process you would own |
| 3 | "How do you see the move from eight branches to five hubs changing complaints in your area?" | Ties the brief to their branch, and shows you read it |
| 4 | "Which of the four values is hardest to live in your branch day to day?" | Treats the values as real rather than recited |
| 5 | "How would you want to hear how your branch's complaints compare with the others?" | Shows you have thought about the reporting seam before they raise it |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B2, D1, H1, J1 |
| "report monthly on complaint volumes and resolution times" | D3, J3 |
| "coach branch supervisors on escalations" | C2, H2 |
| "work with digital teams on self-service journeys" | A3, E1 |
| "4+ years in financial-services customer operations" | A4 |
| "experience handling regulated complaints" | B3 |
| "confident presenting to senior leaders" | D2, C1 |
| "comfortable with Excel reporting" | D3 |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Built from the fit snapshot before any bank was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not a process across branches |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: new tellers and an escalation script that is "our" script. The limit is the pack's observation: your material says new tellers, not supervisors |
| Reported monthly on complaint volumes and resolution times to leaders | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says a spreadsheet your regional manager uses, not what it counted |
| Handled regulated complaints under named rules | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says a formal complaints log, not which rules governed it |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "Never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; Ashgrove's four values as pasted, copied from ashgrovecu.org/about/values on 12 October 2026; the recruiter's email on the process; the 2026 strategy brief, as the four items you relayed (the brief itself was not pasted); your background, in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | Could not have moved the cheat sheet: the four values are pasted in full |
| 2. `Ashgrove interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email names all three rounds, who runs them, and what each holds |
| 3. `Ashgrove strategy` / recent news | skipped | Could not have moved CO and CASE questions: the four brief items you relayed supply current priorities |
| 4. `{interviewer name} Ashgrove` | n/a | No names were given, only roles; the interviewer read is absent and the upgrade menu says what a name would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your CV text → the four sentences here become full evidence; rows F3, F4, F5, F6 and F9 hold answer slots a CV line might close
- Your answers to the answer slots on F1, F3, F5, F6 and F9 → each becomes a quoted line, and the stories in A3, C2, D3 and J2 become story-mapped
- A copy of the monthly complaints spreadsheet or its report, with member details removed and only if your employer allows → F3 and F4 could move from medium to high, which a complaints report is the inspectable artifact for
- The panel's names, or the Head of Member Services' name → an interviewer read, persona weights per panellist, and a reverse question tied to their own path
- The recruiter's word on whether the 20-minute case arrives with a pre-read or brief, and what it covers → a build section for the case if it is a declared deliverable, and tighter H1 to H3
- Time available to prep → a prioritised schedule sized to it
- A deeper research pass — up to 6 more searches and 2 more fetches, several more minutes → Ashgrove's recent news and leadership context beyond the brief, and any reports on how this loop runs
- A tuesday-dossier.md from earlier work → verified evidence and a named toughest objection to rehearse, in place of the ones inferred here
