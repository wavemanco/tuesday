I'll read the reference files the skill points to before building the pack.
The pack is written and saved; this message presents it.

Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-denied-10177346/7ffa001f-d03e-473f-9076-89e74fe5c0e8/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions across six interviewer styles, a fit snapshot built only from your own sentences, a list of claims it won't coach, and a coverage table mapping every JD line to questions.

- **Assumption:** I built it for a hiring-manager round, since your note didn't say how Tobias relates to the role.
- **Research:** All four web searches were refused by this host, so the pack has no Saltmarsh values, strategy or interviewer facts. The company-knowledge question (D3) is a prompt to play their games, not a pre-written answer.
- **Highest-ROI prep:** B1 is "You haven't worked on a game with in-app purchases. How would you handle that in this role?" It is the biggest gap you named, so rehearse it first.

I can run a live drill as Tobias on B1, or on any question ID you pick.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter say anything about what Friday will cover, such as a task or presentation? The answer reweights the persona banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. The relationship is not stated in your message; this pack assumes a hiring-manager round, and the persona weights follow from that assumption. Web research could not run (see Sources), so company values, loop and strategy facts are absent rather than guessed.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Bank IDs are letter-by-persona (A to E, then G, so none collides with the fit-snapshot row IDs F1 to F10). Answer slots are instructions for the interview, not questions for you to reply to here.

## Prep triage (about a day of prep)

1. B1, aloud, three times. It is the highest-ROI prep in this pack.
2. E1 and B3: say the two plain acknowledgments until they are boring.
3. C1: decide in advance what you do and do not know about how the retention numbers were counted.
4. D1: the 90-second arc, timed.
5. D3: thirty minutes in each of the two titles, taking notes as a player.
6. A1 and A2: one aloud run each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, with nothing inspected behind it, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." The JD's live-events and two-titles wording sits wider than that sentence, and the pack does not close the distance. Answer slot: if your calendar ever had to share dates or people with another title or with time-limited events, say how, in your own words; if it did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which of these teams you worked with. Answer slot: the JD names four teams, so a probe on each is likely. If you coordinated with any of them on an update, say which and what you did, in your own words; if the calendar did not involve some of them, or the coordination was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." It does not say who set the review or defined the KPIs. Answer slot: expect probes on how the numbers were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours; answer each in your own words, and where you do not know how something was counted, say so plainly. If a review followed any content drop and was yours, say what it held; if there was none, or it was not yours, say so plainly and stay with the numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: "I wrote the release checklist our QA team still uses." Your material says wrote, and that QA still uses it; it does not say managed, so the verb stays where you put it. Expect a probe on it, since a CV line with nothing inspected behind it invites one |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years are stated; your material does not say whether the main title was a live-service game. Answer slot: if the title was live-service, say what that meant for how you worked, in your own words; if you would not call it that, say so plainly and stay with the four years and the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: weekly cadence, your studio's main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote already reaches the requirement: a named monthly presentation to a named audience. Expect a defend-the-number probe; C1 rehearses it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist is the one written piece your material names, and the pack infers from it only that you have a written artifact a team still uses. Answer slot: if there is other writing you would point to, name it; if the checklist is your best example, say that plainly |
| F9 | In-app-purchase experience on a mobile title — role-family pattern, not named in the JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | Leading a team — role-family pattern, not named in the JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." Then how you would work with the teams the role coordinates, said as a plan and never as a past |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic), then move on what the fit snapshot shows.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems: plan a month of events, diagnose a retention drop, trade off two updates | Highest, 5 questions. The hiring-manager prior puts it first, and the JD's plan-and-run line (F1) is a live-problem requirement | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps: in-app purchases, two titles, team leadership, events versus content drops | High, 4 questions. Second under the hiring-manager prior, raised because F9 and F10 are gaps you stated yourself | Rehearse B1 until it is boring; say the limit first; bridge only from what your quotes carry, then a plan |
| Data-Driven Prober | Reads your retention-numbers line closely and asks how it was counted | Mid, 3 questions. The JD makes KPIs part of the job (F3, F7) and you have a presented-numbers line to probe | Know what you can and cannot say about how the numbers were counted; say plainly where you do not know |
| Conversational / Rapport | A friendly opener, a chatty question about the games | Mid, 3 questions. Any 60-minute conversation opens in this register, and casual questions are still scored | A timed 90-second arc; treat the casual game question as scored |
| Pressure | Time-boxed challenge: why you, how much was really you | Low, 2 questions. Nothing in the inputs signals a stress style, so it is kept as insurance | Pause, restate, anchor in your own sentences, hold through two follow-ups before conceding anything real |
| Peer Evaluator | Seam-splitting between producer and the disciplines, credit across teams | Low, 2 questions. Tobias's title points to a manager rather than a peer, but F2's coordination line invites collegial packaging of the same probes | Propose seam principles rather than claiming to know the seam; reciprocity framing |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan a month of live events for one of our mobile titles. What do you need to know first?" | CASE | [generic] | Clarify out loud first: the title's goals for the month, what has already run, team capacity, QA and release windows. Then objective, player segments, the shape of the month, how you would measure it, what could slip. Challenge one premise respectfully, for example whether a month is the right planning unit. The question needs no claim about your past, so the guidance makes none | The core of the JD's plan-and-run line (F1) as a live problem. CASE because it scores structure; generic because it is a pattern, not a fact about Saltmarsh |
| A2 | "Retention on a live event is well below what the team expected. Diagnose it." | CASE | [generic] | Clarify what is below, against which baseline, for which cohorts. Segment: new versus returning players, platform, region. Check what shipped and when. Separate event design from technical or release causes. State a hypothesis and what would disprove it, and what you would tell the team. No claim about your past | F3 and F7's requirements asked as a diagnosis. CASE because it scores reasoning from a metric; generic because no Saltmarsh numbers are known |
| A3 | "We want an event to move revenue as well as engagement. How would you approach it?" | CASE | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then structure: ask how the title earns today and which revenue measures the studio reads, who owns pricing, how revenue and retention are weighed against each other; say how you would check an event's effect on both afterward, and what you would learn first. A plan, never a past | F9 is the gap you stated, and the question puts it inside a live problem. CASE because it scores how you reason without the experience; the question's premise is the interviewer's and the guidance does not adopt it |
| A4 | "Two updates need QA in the same week and there is capacity for one. What do you do?" | CASE | [generic] | Clarify which dates are fixed and why, and what each update risks if shipped lighter. Lay out options: reorder, trim scope, add cover, move a date. Say who decides, what you tell the other teams and when, and what you record. No claim about your past | The release-checklist-with-QA requirement (F4) as a decision under constraint. CASE; generic because it is a pattern for the problem |
| A5 | "Design wants a bigger event than engineering says fits the window. Where do you land?" | CASE | [generic] | Ask what each side is optimizing and what is flexible. Give a recommendation with its reason and what would change your mind, and name whom you would bring in to decide. Do not claim the decision is yours to make; propose who owns it | F2's coordination requirement as a live trade-off. CASE because it scores a position held with reasons; generic because it asserts nothing about your past |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases.", "I ran the weekly content-drop calendar for our main title for the last two years.", "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Say the limit first, before it is pressed: "I haven't worked on a game with in-app purchases." Then a plan, never a past: what you would ask for in the first weeks (how events earn today, who owns pricing, which revenue measures the studio reads, how past events did on them) and whom you would sit with. Follow-up one, how fast: concede you cannot promise a date, and say what you would propose to have learned by the end of the first month. Follow-up two, what matters most for revenue in an event: say plainly you do not yet know this studio's answer, and say what you would ask. Hold by returning to what your quotes carry — "I ran the weekly content-drop calendar for our main title for the last two years." and "I presented the monthly retention numbers to the studio head." — and add nothing to them | F9 is the largest gap you stated, so this objection arrives in some form. JD because it scores fit to the role; deepest rehearsal because it is aimed where the material is thinnest |
| B2 | "You ran the content calendar for your studio's main title. We run two. How do you see that step?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote, in its own terms: "I ran the weekly content-drop calendar for our main title for the last two years." Concede specifically that two titles is wider than that sentence. Then the plan: on day one you would ask where the two titles share people, dates and QA time, and how you would keep one view of both calendars. Hold through two follow-ups by returning to the calendar you ran, never by adding to it | F1's two-titles wording against its quote at its own scope. JD because it scores the stated requirement; the Skeptic delivery presses the scope |
| B3 | "You haven't led a team. The role coordinates design, art, engineering and community on each update. How do you see that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases.", "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." Then a plan: how you would learn each discipline's needs and constraints in the first weeks and what you would ask each for. Answer slot: the JD's coordination line makes a probe on your work with each of the four likely. If you worked with any of them on an update, say which and what you did, in your own words; if you did not, or it was not yours, say so plainly and return to the calendar you ran | F10 and F2 together. JD because it scores the stated coordination requirement; Skeptic because it presses the stated gap |
| B4 | "Your calendar was a weekly content-drop calendar. What changes when you run live events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Concede that you would want to understand where events differ from drops, rather than assuming. Then the questions you would ask: how events are scheduled against drops, what an event needs that a drop does not, who signs off, how an event is judged afterward. No claim about how events work at Saltmarsh | F1's live-events wording against a content-drop quote. JD because it scores the stated requirement; Skeptic because it presses a terminology gap |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beat the quote states: you presented the monthly retention numbers to the studio head. Answer slot: expect follow-ups on how the numbers were counted, what they are sensitive to, the assumption behind them you would defend least, and which part was yours. Answer each in your own words; where you do not know how something was counted, say so plainly and say what you would check | F7 and F3 are where the prober presses. EXP because it tests attribution and whether you know your own assumptions |
| C2 | "Which retention measure would you look at first after an event, and why?" | JD | [generic] | Choose one measure and say, in your own words, what it tells you, what it cannot tell you, what you would compare it to, and the assumption you would defend least. If you have used it, say so; if you have not, say which you would start with and why. No claim about your past is supplied here | F7's requirement as a judgment call. JD because it scores the stated metrics requirement; generic because it is a pattern |
| C3 | "After an event ends, what goes into the review and who sees it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: the JD's post-event review line makes this likely. If you wrote up what a content drop did, say what the write-up held and who read it, in your own words; if no review was part of your work, or it was not yours, say so plainly and return to the numbers you presented. Then say what a review would hold in your plan | F3 is where ownership of the review presses hardest. JD because it scores the stated requirement |

### D. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through your journey so far, and what draws you to live operations." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses.", "Presented the monthly retention numbers to the studio head." | A 90-second arc, one beat per quote: four years as an associate producer at a puzzle-game studio; for the last two years you ran the weekly content-drop calendar for the main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. Answer slot: why live operations and why this role now, in your own words; if the pull is something other than the work itself, say that plainly | The opener in a 60-minute conversation, F5 and F6 in story form. EXP because it tests whether the CV's claims are told consistently |
| D2 | "Tell me about something you wrote that a team actually used." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote the release checklist, and the QA team still uses it. Answer slot: the JD's checklist-with-QA line makes a probe on how releases ran through it likely. If you saw releases go through it, say how, in your own words; if you did not, say so plainly and stay with what you wrote and that QA still uses it | F8 and F4. An open prompt whose theme comes from the JD's written-communication line; EXP because it tests what was actually yours |
| D3 | "What have you noticed playing our games?" | CO | [generic] | This cannot be written for you; the research that would have supplied it could not run. Spend thirty minutes in each title before Friday and note, as a player, how events and updates show up, one thing you would keep and one thing you would ask about. Say it as an observation from play, never as knowledge of internal numbers. If you could not play them, say so plainly and say what you would look at first | A casual question about a hot JD topic (F1's two titles), still scored. CO because it tests homework; generic because no strategy research succeeded |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire an associate producer who has not led a team or worked on a game with in-app purchases?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio.", "Never led a team, and never worked on a game with in-app purchases.", "I ran the weekly content-drop calendar for our main title for the last two years.", "Wrote the release checklist our QA team still uses.", "Presented the monthly retention numbers to the studio head." | Pause and restate the question. First: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then hold what your quotes carry, in their own terms: the weekly content-drop calendar for the main title, the release checklist QA still uses, the monthly retention numbers you presented. Hold through two follow-ups by returning to those sentences; when pressed, concede the specific thing you would have to learn rather than fold on what you did | F9 and F10 together under time pressure. JD because it scores fit; Pressure delivery because it tests composure |
| E2 | "You say you ran that calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause. Start from the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours and which belonged to others, in your own words; if it was yours throughout, say that plainly; if some of it was set by someone else, say so plainly and say what you did with it. Hold through two follow-ups by returning to the quote | F1 and F6 are where the claim sits. EXP because it is the attribution probe |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than claiming to know the seam: the producer keeps the schedule and the trade-offs visible, each discipline keeps its own craft calls, and a disagreement goes early to whoever owns the outcome. Frame it as reciprocity: say what you would want to bring their team, as a proposal. No claim about your past | F2's coordination requirement from the side of a neighbouring team. CASE because it is a live seam problem; generic because it asserts nothing about your past |
| G2 | "How do you handle credit when an update spans design, art, engineering and community?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | A selection scaffold: pick a time work spanned several teams where credit could have blurred; it needs the teams named, what you did about credit, and the relationships intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — "I ran the weekly content-drop calendar for our main title for the last two years." — or how you would handle it | F2's four teams as a credit probe. VAL-style because it scores behavior, though no company values were available to it |

### Requirement coverage

| Requirement (source) | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" — JD | A1, B2, B4 |
| "coordinate design, art, engineering and community teams on each update" — JD | A5, B3, G1, G2 |
| "own the post-event review and the KPIs it reports" — JD | A2, C2, C3 |
| "manage the release checklist with QA" — JD | A4, D2 |
| "3+ years producing live-service games or apps" — JD | D1, E1 |
| "experience running a content calendar" — JD | A1, B4, E2 |
| "comfortable with player-retention metrics" — JD | A2, C1, C2 |
| "clear written communication" — JD | C3, D2 |
| In-app-purchase experience (not in the JD; stated by you) | A3, B1, E1 |
| Leading a team (not in the JD; stated by you) | B3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first ninety days look like in this role across the two titles?" | Scopes the two-title load from the person who owns it and shows you are planning the ramp |
| 2 | "How are revenue and retention goals weighed when you plan an event, and who owns each?" | Moves straight to the in-app-purchase gap on your terms, as a learner asking the right question |
| 3 | "What does the post-event review look like today, and who reads it?" | The JD makes the review and its KPIs part of the job; the question shows you think about what the review is for |
| 4 | "How does the release checklist work between live ops and QA today, and what would you change first?" | Shows you treat a checklist as a living tool and invites the interviewer's own priorities |
| 5 | "Which of design, art, engineering and community is hardest to line up on an update, and why?" | Asks for the real friction in the coordination the role is built around |
| 6 | "What would make you say, six months in, that this hire worked?" | Gets the interviewer's own success measure in the room before the close |

No question is tied to Tobias's own career path: no interviewer information beyond his name and title was available, so these are role-generic.

## Prohibited claims

Not coached in any cell of this pack, built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says a content-drop calendar for the main title |
| Owned the post-event review and defined its KPIs | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." The material says presented, not owned or defined |
| Managed the release checklist with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." The material says wrote, not managed |
| Has three or more years producing live-service games | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer at a puzzle-game studio, and the calendar. The material does not say live-service |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |

## Sources

Provided documents: the job description text and the background you wrote in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search sent was refused by the host, so nothing from the web is used anywhere in this pack.

| Query | Outcome |
|---|---|
| Saltmarsh Games values | refused |
| Saltmarsh Games interview process live operations producer | refused |
| Saltmarsh Games mobile studio news strategy | refused |
| Tobias Wrenfield Saltmarsh Games | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call refused. Would have supplied official value names for a cheat sheet; none is built, and no values-style round is detected, since your message names none |
| 2. Saltmarsh Games interview process, live ops | unavailable | Every call refused. Would have confirmed loop structure; your own words establish one 60-minute session with Tobias, so persona weights rest on that and the hiring-manager assumption |
| 3. Saltmarsh Games strategy and recent news | unavailable | Every call refused. Would have grounded a CO question in current strategy; D3 is generic as a result |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Every call refused. Would have supplied a public-footprint interviewer read and a tailored reverse question; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access on this host → targets 1 to 4 can run, turning the generic CO question and role-generic reverse questions into grounded ones; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once on request
- Tobias's public profile, talks or writing, pasted or linked → an interviewer read, persona weights adjusted to what he has published, and a reverse question tied to his own path
- The recruiter's note on Friday's format, any task or presentation, and who else you will meet → coverage of any graded deliverable and a check on the hiring-manager assumption
- Your answers to the answer slots on F1, F2, F3, F5 and F8 → those rows move from discovery or transferability to quoted evidence, and the guidance cells for B1 to B4, C1, C3 and D2 get regenerated from it
- The release checklist itself, or a retention report with figures removed → confidence on F4, F3 and F7 can rise from medium
- The names or store links of the two Saltmarsh titles → D3 and A1 can be tuned to what is actually live
- A job-underwriter dossier, if you have one → verified evidence and sourced prohibited claims in place of the locally built list; never required
