I'll start by reading the reference files the skill points to and checking for any provided documents.
I couldn't save the pack as a file because the write permission wasn't granted, so it's below in full. Web search was also not permitted. The pack has no research behind it and no JD or CV, so it is a structure to rehearse against, and every cell is labeled to show that.

# Interview prep pack: Product Operations Manager, Stripe

Round: final round, per your message. Interviewer and relationship: not given.

## How to use this pack

- Personas are how a question arrives (who is asking, in what style). Types are what the question is scoring. Each question carries one type tag.
- Guidance is scaffolding, not a script. Nothing here says what you did. Where an answer needs your history, the guidance gives selection criteria and an honest fallback, and you supply the story in your own words.
- Bank letters skip F, because F1 to F5 are fit-snapshot rows.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you understand the company's strategy and altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot (worksheet variant)

You gave no CV and no JD, so every evidence cell reads none given. The requirements are role-family patterns written as plain prose, not quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run the planning and review rhythm that keeps several product teams aligned (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a named recurring forum, who attended, and a decision it produced. Selection scaffold: pick the cadence you know best, name its participants and one decision that came out of it; if no such cadence comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F2 | Coordinate cross-functional product launches (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a specific launch, the functions involved and your part in it. Selection scaffold: pick one launch, name the functions and the piece that was yours; if no such launch comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would run one |
| F3 | Define, track and report product health metrics (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, what you would defend least. Selection scaffold: pick one figure and be ready for all three; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would measure first |
| F4 | Find and fix process friction in how product teams work (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is one friction point, the change made and how you knew it helped. Selection scaffold: pick one, and separate what you proposed from what you ran; if no such change comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would diagnose one |
| F5 | Influence partners without formal authority and communicate clearly to leaders (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a partner team and how it ended. Selection scaffold: pick one where the relationship survived, name the stake and your move; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona weights

"The final round" alone doesn't say how many sessions it holds or who runs them, so no loop source establishes this loop. The weights rest on the generic fallback pattern, not on Stripe's documented process. A final round can be a hiring manager, skip-level, cross-functional partner, peer, or several of these, so the weights blend those priors.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Case / Strategist | Live problems from the role: a slipping launch, a metric drop, a process to design | Highest. Hiring-manager and skip-level priors both lead with it, and it needs no CV to rehearse | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of motivation and weak areas | High. Hiring-manager prior; the most predictable objection lands here, though this pack can't name yours without your CV | Rehearse the single most predictable objection until it is boring; name the limit before it is extracted, then give a concrete ramp plan |
| Values / Behavioral | Scenario probes: an unpopular truth, a disagreement, a customer-first call | Medium. Cross-functional prior; no source shows a values-style round, so none is assumed and themes come from standard persona stems | Choose stories where the hard truth landed and the relationship held; where none comes to mind, say so plainly |
| Peer Evaluator | Seam-splitting with product management, credit-sharing | Medium. Peer prior, and the role sits between teams; matters only if a peer is in your loop | Reciprocity framing; propose seam principles instead of pretending to know the seam |
| Data-Driven Prober | Goes two levels deep on any figure or analysis | Medium. Analytics-adjacent role family; heavier if the interviewer is a data lead, which is unknown | Know how any number was counted; say plainly when you don't know; name the weakest assumption first |
| Conversational | Friendly openers, biography questions | Lower-medium. Likely as a warm-up in any session, and still scored | A 90-second arc scripted from your own material |
| Pressure | Interruptions, time-boxes, "how much was actually you" | Lower. Skip-level prior only | Pause, restate, hold a position through two follow-ups before conceding anything real |

## Question banks

Every row is `[generic]`. Questions that touch your history are open prompts, so they presuppose nothing, and each guidance cell ends in an honest branch. CASE rows ask about no past.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is slipping, and three teams each say another team is the blocker. What do you do in your first week?" | CASE | [generic] | Clarify first: what is the fixed constraint on the date, who owns the decision, what each team has actually said. Separate facts from attributions, get the three teams to agree one dependency list, set a single owner and cadence. Name the metric that shows recovery and one risk in your own plan. Challenge one premise, such as whether the date should move | A live problem a hiring manager can set without your CV. F2 and F5 are the rows. CASE because it scores structure, not experience |
| A2 | "An adoption metric for a recently launched feature dropped 20% week over week. Diagnose it." | CASE | [generic] | Clarify the definition and window. Split by segment, channel and platform; check instrumentation and seasonality before behavior; then form hypotheses and tests. Say what you'd do first with an hour and what you would not yet conclude | A persona-stem diagnostic probing F3 without presupposing a metric you owned. CASE because the reasoning is scored |
| A3 | "Sketch the launch process for a release that touches several teams. What do you need to know first?" | CASE | [generic] | Ask about scale, risk tier, the teams involved and what goes wrong today. Propose stages with one named owner each, a go or no-go checkpoint and a post-launch review; say which parts stay light for low-risk releases | Tests F2 and F4 at design altitude. CASE because it asks you to build a process |
| A4 | "Everyone's request to your team is urgent. How do you decide what to take on first?" | CASE | [generic] | Offer principles: impact on a stated goal, cost of delay, who else could solve it, what you'd decline and how you'd say so. Make the trade-off visible to the people you decline | Prioritization is the daily test of the role. F4 and F5 are the rows. CASE because it is a decision under constraint |
| A5 | "How would you design the review cadence so product leaders get the signal without a meeting overload?" | CASE | [generic] | Start from the decisions the cadence must serve, then who needs what detail, what goes async, and how you'd know it works or should be cut. Concede one trade-off in your design | F1 is the row. CASE because it asks for design reasoning |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why product operations, and why now?" | JD | [generic] | Selection criteria: one true reason for the move, one for the timing, one about the work rather than the title; about 60 seconds, consistent with how you describe your last role. If a clean reason doesn't come to mind, say so plainly, then give the nearest honest one | The motivation probe skeptics open with. JD because it tests fit for the role family |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack, inferred without your CV.** Name one real area as a limit, not a confession; say what you'd do about it in 30 days. Hold through "why isn't that disqualifying?" and "what if no one can teach you that here?" by returning to the ramp plan; concede one specific thing you don't yet know. Never pick a fake weakness | Some form of this arrives in nearly every loop, aimed at the thin spot of your own material, which this pack can't see yet. F1 to F5 are the candidate areas. JD because it scores the job, gaps included |
| B3 | "Tell me about a skill this role needs that you had to pick up quickly." | EXP | [generic] | Selection criteria: a named skill, a stake or deadline, what you did to learn it, how you knew you had. Say what was yours and what you were taught. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would learn a new one | Tests how credibly you close a gap. EXP because it asks for an instance |
| B4 | "What would make this the wrong job for you a year from now?" | VAL | [generic] | Name one or two honest conditions tied to the work, not perks, and say how you'd raise them early. Avoid anything that reads as demands | A retention and honesty probe. VAL because it reveals what you weigh |

### C. Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you didn't soften it, an intact relationship afterwards; "we" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem; touches F5. VAL because it scores behavior |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real trade-off with a cost to the internal number, a decision you can describe, how it was received. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh it | Persona stem. Stripe's published values weren't retrieved, so this theme is a stand-in. VAL because it scores a priority choice |
| C3 | "Tell me about a time you disagreed with a decision that was already made." | VAL | [generic] | Selection criteria: what you said and to whom, what you did once the decision stood, and whether you can state the other side's case fairly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests disagreement style, central to F5. VAL because it scores behavior under conflict |

### D. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, such as product management owning the what and why and you owning how it gets run and measured, with the exact line agreed per team. Disagreement path: agree the facts first, escalate the decision, not the person. Say you'd confirm the seam with them rather than assume it | F5 and F1 are the rows. CASE because it designs the relationship |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle first, such as naming contributors specifically and early. If a real instance comes to mind, tell it with "we" for context and "I" for your part; if none does, say so plainly and stay with the principle | Collegial form of an attribution probe. VAL because it scores values with equals |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Lead with reciprocity: one thing you'd offer their team, then one or two honest needs such as context or access. Offer only what you could deliver | The reciprocity move peers weight heavily. JD because it prices what the hire adds |

### E. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a metric you relied on to make a product decision. How was it counted?" | EXP | [generic] | Selection criteria: one figure you can explain on how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours. If you don't know how part of it was counted, say so plainly. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or what you would measure first | The defend-the-number slot, opened without presupposing a figure. F3 is the row. EXP because it tests attribution |
| E2 | "Tell me about an analysis you did yourself, end to end. What was the question and what changed?" | EXP | [generic] | Selection criteria: the question, the data, one limit of it, the decision that followed; offer to walk through it step by step. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | Probers want analysis you can walk through. F3 is the row. EXP because it checks what was yours |
| E3 | "How would you tell whether a process change you introduced actually worked?" | CASE | [generic] | State the outcome you wanted before the change, a baseline, a comparison, a leading and a lagging measure, and how you'd watch for side effects. Name the weakest assumption in your own plan | Exercises F3 and F4 with no past needed. CASE because it scores reasoning |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Script a 90-second arc from your own material: where you started, the one or two moves that mattered, why this role is next. End on the role. Each beat should survive a follow-up | The biography opener, scored even when casual. EXP because everything said becomes material for probes |
| G2 | "What have you been getting curious about lately in how product teams work?" | JD | [generic] | Pick one real thing, say why it interests you and one concrete place you've looked at it. If nothing comes to mind, say so plainly, then name the nearest area you'd explore and how | Casual questions on role topics are still scored. JD because it probes engagement with the field |

### H. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, answer in terms of what the role needs and one thing you'd bring, as an offer and not a comparison. Hold through two follow-ups, then concede specifically what an internal candidate knows that you don't | Tests composure; content must come from your own material. JD because it scores fit |
| H2 | "Think of the work you are proudest of. How much of it was actually you?" | EXP | [generic] | Say plainly what you did and what others did, in your own words. Hold your account through two rounds of pushback, then concede any part you can't vouch for. Don't widen your role to defend it | The attribution probe in pressure form. EXP because it tests honesty about credit |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Planning and review rhythm | A5, D1 |
| F2 Cross-functional launches | A1, A3, B2 |
| F3 Product health metrics | A2, E1, E2, E3 |
| F4 Process friction | A3, A4, B3, E3 |
| F5 Influence without authority | A1, A4, C1, C3, D1, D2, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first six months look like in this role, and how would you know?" | Shows outcome thinking and gives you the criteria you'll be judged on |
| R2 | "Where does product operations end and product management begin here, and where is that line still moving?" | Shows you understand the seam and want to respect it |
| R3 | "What is the most common friction between product teams that this role is meant to reduce?" | Surfaces the real problem so you can tie later answers to it |
| R4 | "How is the work of this function measured, and by whom?" | Signals metric literacy and tells you whether the role is valued for output or influence |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question; strongest if the interviewer is a peer |
| R6 | "What is one thing about this role you'd like candidates to ask about and few do?" | An open slot that rewards a prepared candidate |

## Prohibited claims

This pack coaches no claim about your past, because you gave it no CV, no JD and no statement about your history. It lists no inflated form and no stated negative, and nothing in the banks says what you did, owned or decided. When you add material, this section is rebuilt from it.

## Sources

Provided documents: your message ("I have a final-round interview at Stripe for a Product Operations Manager role"). No JD, CV, dossier or interviewer information was provided.

Searches sent, all refused (search permission not granted); nothing returned and nothing used:

- Stripe operating principles and values: refused
- Stripe interview process, Product Operations Manager, final round: refused
- Stripe strategy and recent news: refused
- Stripe Product Operations Manager job description: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have fed a values cheat sheet (dropped) and given official value names; VAL questions use persona stems instead |
| 2. Interview process | unavailable | Would have fixed the loop structure and persona weights; they rest on the generic fallback |
| 3. Strategy and recent news | unavailable | Would have grounded CO and CASE questions in Stripe's current priorities; this pack has no CO-tagged question |
| 4. Interviewer name | n/a | No name given, so no query could be formed; no interviewer read |
| 5. Representative role JD | unavailable | Would have supplied requirement text for the fit snapshot; rows are role-family prose instead |

## Upgrade menu

- Your JD text → F1 to F5 become quoted `[grounded]` requirements, JD-tagged questions get real raising sources and answer slots, and any gate such as location, schedule or work authorization is surfaced
- Your CV → the evidence cells hold your own sentences, story-mapped guidance replaces the selection scaffolds, defend-the-number questions are written for your actual figures, and the prohibited list gets entries
- Who you're meeting and the format (manager, peer, skip-level, cross-functional, panel) → personas and banks are reweighted; if your final is several sessions, the schedule unlocks a mini-pack per session
- The interviewer's name → a reading of their public professional footprint and a reverse question tied to their own path
- The recruiter's prep notes, including any pre-declared presentation or take-home → a build section for each graded deliverable
- Allowing web search → Stripe's published values by name, the documented loop, and a current strategy brief for CO and CASE questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can add interviewer talks and loop reports
- How much prep time you have → a prioritized schedule of the few things worth doing first
- A `tuesday-dossier.md` from an earlier role evaluation, if you have one → verified evidence and a named top objection in place of the inferred ones

Say the word and I'll play the Skeptic on B2, the question this pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it once file writing is allowed.

Who is the final-round interviewer, in what format, and did the recruiter mention a focus area or a presentation, and can you paste the JD and your CV, or tell me to go without them? Either answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.