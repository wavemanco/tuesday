Quick status: the prep pack is written. I'm fixing one line that claimed something you haven't told me, then I'll send the summary.
Dara, your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-8-canned-6934039c/f006685d-c738-468d-b9e2-5ffd7f50d81d/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop, with its own persona weights and question bank for each round. Each round has its own reverse questions. There are 29 questions in total. All four published values are mapped for the panel round.

- **Dates:** your message puts the rounds on 21 October and the values copy on 12 October, but my clock reads 5 November. I assumed the rounds are still ahead. If any have passed, tell me which and I'll drop them.
- **Research:** I ran no searches. Your JD, values text, recruiter email and strategy summary already covered what a search would have fed. I only had your four-line summary of the strategy brief, not the brief itself.
- **Biggest risk:** R2-B1 is the question the pack names as your highest-ROI prep. It asks how you'd own the process across every branch and the contact centre when your record is one branch's complaints log. It will likely come up in all three rounds, so rehearse it first.
- **Your own words:** the guidance quotes your sentences exactly and invents no experience. Where the JD asks for something your message doesn't cover, such as digital teams or coaching supervisors, the pack gives answer slots. Each slot has two honest branches. Your two stated gaps, no contact-centre experience and no presenting above regional level, get one-line plain concessions.

Say the word and I'll play the Head of Member Services on R2-B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Mode: loop (three scheduled rounds, all on 21 October 2026, per the recruiter's email). Interviewer names are not yet assigned; only their roles are known.

| Round | Length | Who | What the recruiter said it is |
|---|---|---|---|
| R1 | 30 minutes | The recruiter | A conversation |
| R2 | 45 minutes | Head of Member Services, who would be your manager | "mostly behavioural" |
| R3 | 60 minutes | Panel of two branch managers | Includes a 20-minute case on a complaint escalation; the panel is also the values round, scored against the four values |

## How to use this pack

- Personas describe how a question is asked; types describe what is being scored. Question IDs read round, persona letter, number: R2-B1 is round 2, Skeptic, question 1. Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, P Data-Driven Prober, S Pressure.
- Types: VAL (behaviour against published values), EXP (does the record hold up), JD (the stated role), CO (company and strategy knowledge), CASE (a live problem).
- Guidance is scaffolding for your own words, not a script. An answer slot is an instruction for the interview: it names something a likely follow-up will probe and gives you two honest branches. Either branch is a good answer; the one you cannot give is a branch that is not true.
- Provenance labels: `[grounded]` traces to a document you gave me; `[inferred]` is my derivation from one, with the derivation named; `[generic]` is a pattern with no claim about Ashgrove or about you.
- **Highest-ROI prep: R2-B1.** The objection most likely to be put to you, in some form in all three rounds, is that you have handled one branch's complaints log while the role owns the process across every branch and the contact centre. R1-B1, R2-S1 and R3-B1 are its relatives. Rehearse R2-B1 until the concession is boring to say.

## The fit snapshot (shared across rounds)

No requirement in the JD is a hard gate: the 4+ years line is a length-of-experience requirement, which is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message, "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says the branch's log and the tellers' script, not a process across branches. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which parts of a complaint you carried yourself likely. If your part went beyond the log itself, say which parts, in your own words; if the log was the extent of it, or the rest was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal log; it does not show what the complaints in it involved or which steps were yours, and the pack assumes nothing about which outside rules apply to Ashgrove. Words stay at: "I handled the branch's formal complaints log." Answer slot: expect a probe on which steps of a formal complaint you carried yourself. Say which, in your own words; if the log was a record others acted on, or there was no such step, say so plainly and stay with the log |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Strongest row in your material, and nothing has been inspected behind it, so expect a probe. Lead in the quote's own terms: you built it, it is monthly, your regional manager uses it. Answer slot: the JD names volumes and resolution times. If the spreadsheet counted those, say how each was counted and which assumption behind it you would defend least; if it counted other things, say what, and say so plainly |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors. Words at that scope: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether you have coached supervisors likely. If you have, say on what and how it went; if you have not, say so plainly and stay with the tellers |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have given input on an app, website or other self-service tool, say what and what came of it; if you have not, say so plainly, then say what you would want from a digital team in your first month, as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. Lead with it in your own terms: six years in retail banking, the last three as a branch supervisor. Let them place it against their requirement; do not rename it in the JD's words |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. Your material does not say what you have presented at regional level, so nothing about that is claimed here |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says spreadsheet; the JD says Excel, and the pack does not swap one for the other. Answer slot: if it was built in Excel, say so and what you built in it; if it was another tool, name it plainly |

## Grounding brief (from the 2026 strategy brief)

Your four-point relay of the brief the recruiter sent, published June 2026. I have not read the brief itself.

| # | Item | What it says or implies | Provenance | Where it surfaces |
|---|---|---|---|---|
| G1 | Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | R1-A2, R2-D1, R3-D3 |
| G2 | Hub consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] | R3-D2, R3-C3 |
| G3 | New product | "launch a small-business lending product in Q1 2027" | [grounded] | R2 reverse questions |
| G4 | Competition | "the main competitive pressure is app-only banks" | [grounded] | R3-D3 |
| G5 | Reading: the JD's digital-teams line sits where G1 meets complaints, because self-service journeys that fail are a likely source of new complaints | Derived from the JD line "work with digital teams on self-service journeys" and G1; offer it as your view, never as a fact about Ashgrove | [inferred] | R2-D1, R2-P2 |
| G6 | Reading: a new lending product (G3) brings a new kind of member and a new kind of complaint | Derived from G3; a question to ask, not a claim | [inferred] | R2 reverse questions |

## Persona table (weights per round)

The loop is established by the recruiter's email, so no archetype fallback applies. Weights start from the relationship priors, then move on what the email says. Recalibrate if you know something I do not.

| Round | Persona | Weight | How it shows up, and why this weight | Counter-strategy |
|---|---|---|---|---|
| R1 | A Conversational | high | Recruiter screens are friendly and still scored; the prior is Conversational plus a light Skeptic. Expect the biography, motivation and a knockout check on the contact centre. Decide your pay and notice answers beforehand, as `[generic]` logistics | A 90-second biography arc; treat the casual questions about the spreadsheet as scored |
| R1 | B Skeptic | medium | The knockout checks are the gaps in F2, F3 and F8 asked politely | Concede the stated negatives in one plain sentence, then move on |
| R2 | B Skeptic | high | The manager is buying capability and de-risking gaps (hiring-manager prior). The role's width against your one-branch record makes R2-B1 the likeliest line of the day | Hold-then-concede on R2-B1; limit named before it is asked for |
| R2 | C Values/Behavioral | high | The recruiter called this round "mostly behavioural", which moves weight from the usual Case tilt to behavioural stories | Story map where a quoted sentence carries one; selection scaffold with the honest branch where none does |
| R2 | P Prober | medium | The manager would own the monthly reporting you are being hired to produce, and your spreadsheet is the one thing in your material that invites detail | Know what each column counted; name the assumption you would defend least |
| R2 | D Case/Strategist | low | One strategy question on digital is likely; a full case is not signalled for this round | Clarify, structure, one challenged premise |
| R2 | S Pressure | low | A time-boxed version of the contact-centre objection | Pause, restate, concede specifically, do not fold on the log and the training |
| R3 | C Values/Behavioral | high | The recruiter said the panel is the values round and scores against the four values, so all four need a rehearsed answer | One story or scaffold per value, in your own words |
| R3 | D Case/Strategist | high | A 20-minute case on a complaint escalation is announced | Clarify, objective, structure, ownership, follow-through, say your framework aloud |
| R3 | E Peer Evaluator | medium | Branch managers would work alongside the role, and the role coaches their supervisors on escalations (JD); expect seam and disagreement questions. My reading, from the JD and the recruiter's description | Reciprocity framing; propose seam principles rather than pretend to know today's seam |
| R3 | B Skeptic | low | The gaps return in a collegial register | Same concessions as R1 and R2, shorter |

## Round 1 bank: the recruiter (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your background and what brings you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | Four beats in your own words, in this order: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on our escalation script; you built the monthly complaints spreadsheet your regional manager uses. Stop and let them ask for depth. On why this role: your material does not say what draws you, so decide that before the call and anchor it in what Ashgrove has published rather than the title. Answer slot: if a particular moment changed what you wanted to do next, say it; if none did, say so plainly and give the plain reason | The biography is scored in every screen. F7 supplies the years and F1, F4 and F5 the beats; EXP because it tests whether the story matches the record |
| R1-A2 | "What do you know about Ashgrove, and what made you look at us?" | CO | [grounded] | Three things in plain words: Ashgrove is member-owned; the four values by name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix); and one move from the brief, such as "move 40% of member service to digital channels by 2028". Then one thought of your own about what that means for complaints, offered as your view. Do not recite all four brief points. Why you looked: your material is silent, so give your real reason in one sentence; if the honest reason is simply that the role fits, say that | The rapport register hides a homework check; G1 and the values text are the raised sources. CO because it tests current knowledge |
| R1-A3 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it in the quote's own terms: you built it, it is monthly, your regional manager uses it. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted those, say how each was counted and which assumption you would defend least; if it counted other things, say what. Answer slot: if it was built in Excel, say so; if it was another tool, name it plainly | F4 and F9 are the evidence for the reporting and Excel lines and the likeliest early probe. EXP because it tests what you built |
| R1-A4 | "In your own words, what does a complaint handled well look like?" | VAL | [grounded] | A view, not a story, in three beats that echo the published values without reciting them: the decision is made from the member's side of the counter; the member should not need the answer explained twice; and one person keeps hold of the problem until it is solved. Optional: if a case from the log shows one of these, use it in one line; if none comes to mind, say so plainly and keep it as a view | The published values raise this casual question in the first round. VAL because it checks the values, ahead of the panel |
| R1-B1 | "The role covers the contact centre, and you haven't worked in one. How do you see that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Concede first, in one sentence: "I haven't worked in a contact centre." Then what you do carry, at its own scope: "I handled the branch's formal complaints log." Then a plan, the actions you would really take in your first weeks. Answer slot: if you have dealt with contact-centre colleagues or members' calls from the branch side, say how; if you have not, say so plainly and stay with your plan | The knockout version of the pack's likeliest objection. F2 is the stated negative and F1 the adjacent evidence |
| R1-B2 | "The JD asks for experience handling regulated complaints. Where does yours come from?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold at the quote's scope: "I handled the branch's formal complaints log." Answer slot: expect a follow-up on which steps of a complaint were yours. Say which, in your own words; if the log was a record others acted on, or there was no such step, say so plainly and stay with the log. Do not name a regulator, a rule or a deadline unless you have worked with it yourself | The requirement is a headline line and F3 is the thin row under it. JD because it scores the stated requirement |
| R1-B3 | "The role presents to senior leaders. How comfortable are you with that?" | JD | [grounded] "I've never presented to anyone above regional level" | Concede in one sentence: "I haven't presented to anyone above regional level." Then your preparation, as a plan in your own words. Answer slot: if you have presented at regional level, say to whom and about what; if the spreadsheet was sent rather than presented, say so plainly. Do not claim a comfort you cannot back with an example | F8 is the stated negative; this is its polite first appearance |
| R1-B4 | "Why move from supervising a branch to this role, and why now?" | JD | [generic] "the last 3 as a branch supervisor" | Selection criteria, because your material does not say: one sentence on what you want more of, one on what this role offers using the JD's own lines, one on why now. No criticism of your current employer. If there is no sharp why-now, say so plainly and give the pull towards the role instead | The standard motivation-consistency probe from the recruiter-screen prior. F7 is the background it tests |

## Round 2 bank: Head of Member Services (45 minutes, your would-be manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "You handled your branch's formal complaints log. This role owns the process across every branch and the contact centre. What makes you think you can do that?" | JD | [grounded] "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "Never worked in a contact centre" | The highest-ROI rehearsal, built as a ladder. Level 1, hold: "I handled the branch's formal complaints log, and I trained new tellers on our escalation script." Then name the limit before they do: "That is one branch, and I haven't worked in a contact centre." Level 2, "what did you actually decide?": answer slot, say which parts of a complaint were yours; if they were not yours, say so plainly and return to the log. Level 3, "what would you do in month one?": a plan, using only actions you would really take, such as listening to how complaints reach the contact centre, reading closed complaints from more than one branch, asking each branch supervisor how escalations run today. Level 4, "and if the contact centre won't take coaching from a branch person?": concede specifically, "that is a real risk, so I would learn their process before suggesting changes." Answer slot: if your complaints work ever reached another branch or the contact centre, say how; if it did not, say so plainly. Never fold on the log and the training; never claim cross-branch work | F1 and F2 are the pack's biggest gap, aimed at the exact width the JD asks for. JD because it scores the stated requirement; deepest rehearsal because it will be asked |
| R2-B2 | "Tell me about a complaint that didn't end well." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt, so a selection scaffold: choose a case from the log that ended badly or took longer than it should. It needs what happened, which part was yours, and what you would do differently; no blaming a named colleague. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, the log you handled, or say how you would handle one | The Own the Fix value raises this, and a behavioural manager asks it to see candour. F1 is the nearest evidence |
| R2-B3 | "Walk me through the escalation script you trained new tellers on." | EXP | [grounded] "trained new tellers on our escalation script" | Say it at its scope: you trained new tellers on the escalation script your branch used. Answer slot: if you wrote or changed the script, say what; if it was set by others, or there was no written script beyond the one you name, say so plainly. Answer slot: the JD asks for coaching supervisors, so expect a follow-up on how you taught it and what happened when a teller struggled. Say what happened if something did; if nothing did, say so plainly | The script is the evidence for the coaching line (F5) and the likeliest place to be probed. EXP because it tests what was actually yours |
| R2-C1 | "Tell me about a time you had to give someone senior a message they didn't want to hear." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt, so a scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the monthly spreadsheet your regional manager uses, at that scope, or say how you would handle it. Answer slot: if the spreadsheet ever showed your regional manager something unwelcome, say what happened; if it did not, say so plainly | The JD's senior-leaders line raises it, and the behavioural round is where it is scored. F8 is the gap beneath |
| R2-C2 | "Tell me about a time you coached someone through something difficult." | VAL | [grounded] "trained new tellers on our escalation script" | Story map: the quoted sentence gives you the audience (new tellers) and the subject (the escalation script). Answer slot: the JD's coaching line makes a probe on one particular person likely. If a moment stands out where someone found it hard, say what it was and what you did; if none does, say so plainly and stay with the training | JD coaching line; F5 carries the story at its own scope |
| R2-C3 | "Tell me about a time you worked with a team outside your branch to change something for members." | JD | [grounded] | Open prompt, so a scaffold: pick an instance that names the other team, what you wanted to change, and what actually changed. If no such time comes to mind, say so plainly, then say what you would want from a digital team in your first month, as a plan | The JD's digital-teams line raises it; F6 is silent, so this is a discovery question |
| R2-P1 | "Take me through the monthly spreadsheet. What is in it, where does the data come from, and who reads it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Walk it in the order asked, in your own words. Answer slot: what each column counted and where the data came from; if you do not know how something was counted, say so plainly. Answer slot: the assumption behind it you would defend least, said before they ask. Answer slot: which part was yours; if others fed or changed it, say so | A probe two levels deep on the strongest row. EXP, with the defend-the-number slots because the manager will own the output |
| R2-P2 | "A complaint is raised at a branch, moves to the contact centre and comes back. How would you measure its resolution time?" | CASE | [generic] | A live problem; it asks about no past. Clarify first: what starts the clock (first contact in any channel?) and what stops it. Then structure: one clock per complaint, not per team; who owns each handover; what the monthly report shows (volumes by channel and branch, aged open cases). Challenge one premise respectfully, such as whether member elapsed time is the right measure. Choose measures simple enough to explain once | F4 names the measures; CASE because it tests structure rather than history |
| R2-D1 | "The brief moves 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Clarify first: does the 40% include complaints, or only routine service? Then structure: where complaints will arise as journeys move to the app; what the role needs from digital teams (complaint data on failed journeys); how branches and the contact centre hand over; what to measure by channel. Name G1 in the brief's own words. Answer slot: if you have worked with a digital team, say on what; if you have not, say so plainly and say what you would ask them first | G1 is the raising source. CO because it tests thinking at the company's altitude |
| R2-S1 | "Sixty seconds: why you, rather than someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | Pause and restate. Hold: what your record is, in its own words (the log, the script training), and no claim to be better. Concede: "I haven't worked in a contact centre, and here is how I would learn it." Do not fold the core to restore harmony | A time-boxed version of R2-B1. F2 and F1 are the limits and the evidence |

## Round 3 bank: the panel of two branch managers (60 minutes, with a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Tell me about a time you decided from the member's side of the counter when it was harder for the branch." | VAL | [grounded] | Value: Members First, Always. Open prompt, so a scaffold: pick a time with a named member, the harder option, and what you gave up; it needs your reasoning, not the policy. If no such time comes to mind, say so plainly, then say how you would decide | The values text raises it, and the recruiter said the panel scores each value. No quote carries this story |
| R3-C2 | "Tell me about a time something you wrote or explained had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | Value: Plain Words. Open prompt, so a scaffold: pick a letter, a script, a training session or a report; it needs what confused people, what you changed, and how you knew it worked. Answer slot: if the script or the spreadsheet ever needed explaining twice, say what changed; if they did not, say so plainly. If no such time comes to mind, say so plainly | Plain Words is the value most likely to be tested through your own artefacts. F4 and F5 are the nearest evidence |
| R3-C3 | "Tell me about a time you let a local or human consideration outweigh a number." | VAL | [grounded] | Value: Neighbours, Not Numbers. Open prompt, so a scaffold: pick a time that names the place or person, the number you set aside, and what it cost. If no such time comes to mind, say so plainly, then say how you would weigh it. Keep to members and towns; do not speak about the panel's own branches or roles | The values text raises it. G2 makes it the value closest to the panel's own work, so keep it about members |
| R3-C4 | "Tell me about a time you kept hold of a problem until it was solved, when it would have been easy to pass it on." | VAL | [grounded] "I handled the branch's formal complaints log" | Value: Own the Fix. Story map: the quoted sentence gives you the log. Answer slot: if you stayed with a particular complaint through to its end, say what you did and what part was yours; if the log meant recording complaints that others resolved, say so plainly and stay with the log | The values text raises it and F1 is the nearest evidence. VAL because it tests the value by behaviour |
| R3-D1 | "Here is a case. A member has had a disputed-charge complaint with a branch for three weeks. They have rung the contact centre twice and say nobody will tell them who owns it. The branch supervisor says it belongs to the contact centre. What do you do?" | CASE | [generic] | Practice scenario, not a prediction of theirs. Minutes 0 to 3, clarify (what has the member been told, what are the member's circumstances, what does the formal process require of us, which I will check rather than assume). Minutes 3 to 6, objective and your framework said aloud. Minutes 6 to 14, today then this month: one named owner the member hears from today, with the whole story handed over once; fix the case; find where the handover broke. Minutes 14 to 20, follow-through and coaching: the supervisor and the contact centre both hear it in plain words, what the monthly report would show, what you would change. Challenge one premise, such as whether it matters who owns it. Own the Fix and Plain Words are your language | The recruiter announced a complaint-escalation case; this exercises the same muscles. CASE because it tests structure and the values at once |
| R3-D2 | "The brief consolidates eight branches into five hubs over 2027. What happens to complaints at a branch that is closing?" | CO | [grounded] | Speak about members, not about the panel's roles. Clarify the timeline first. Then structure: open complaints at the point of change; one owner across the move; plain notice to the member; reporting by branch for the transition year so trends are not lost. Use the brief's words, "consolidate eight branches into five hubs over 2027" | G2 is the raising source; branch managers live this one, which is why the framing is about members |
| R3-D3 | "App-only banks are our main competitive pressure. Where do branches and a person on the phone still win?" | CO | [grounded] | A view, structured: where a person helps (a complaint, a decision a member does not understand), where the app helps (status, speed), and how each hands the member over. Nothing about your past is claimed. Offer one idea and invite their view | G4 and G1 raise it. CO because it tests company-level thinking |
| R3-E1 | "Your coaching will reach my supervisors. One tells you your approach slows the counter at peak. What do you say?" | CASE | [generic] "trained new tellers on our escalation script" | Reciprocity first: ask what the supervisor is seeing, then agree what matters to both of you. Propose a principle rather than pretend to know their counter: coach in the quiet periods, keep it short. Answer slot: if you have had a similar exchange when you trained the tellers, say what happened; if not, say so plainly | Coaching supervisors is the JD line behind F5, and a branch manager will price what it costs their floor |
| R3-E2 | "Where is the line between what a branch owns on a complaint and what you would own?" | JD | [generic] | Say you would first learn how it works today. Then principles, not a map: the member hears one name; the branch fixes what is local; you own the process, the standard and the reporting; escalation reasons are visible to both. Invite their view on where it already works | A seam question from the peer prior. JD because it tests the stated role |
| R3-E3 | "Your monthly numbers show complaints rising at one branch, and I run it. What do you say to me?" | CASE | [generic] | Privately first, before it appears in a report; facts in plain words; ask what they are seeing. Hold your measure but concede the context. Answer slot: if you have shown a colleague unwelcome numbers from your spreadsheet, say what happened; if not, say so plainly | Tests tact and spine together in the reporting duty (F4) and the senior-audience line |
| R3-B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Choose one and say it plainly: either "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Then your plan for it, in your own words. Do not claim a weakness is secretly a strength | The Skeptic's stem. F2 and F8 are the stated negatives |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre | R1-B1, R2-B1, R2-S1, R3-C4, R3-D1, R3-E2 |
| Regulated complaints | R1-B2, R3-D1 |
| Monthly reporting on volumes and resolution times | R1-A3, R2-P1, R2-P2, R3-E3 |
| Coach branch supervisors on escalations | R2-B3, R2-C2, R3-E1 |
| Work with digital teams on self-service journeys | R2-C3, R2-D1, R3-D3 |
| 4+ years in financial-services customer operations | R1-A1 |
| Confident presenting to senior leaders | R1-B3, R2-C1, R3-B1 |
| Comfortable with Excel reporting | R1-A3, R2-P1 |

## Values cheat sheet (for R3, the values round)

The names are as published on the values page you copied on 12 October 2026. The mapped story is a quote from the fit snapshot where one carries a story, and a scaffold where none does.

| Value | Working meaning | Your mapped story | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, F1 and F5 do not carry this: pick a time with a named member, the harder option and what you gave up; if none comes to mind, say so plainly, then say how you would decide | R3-C1, R1-A4 |
| Plain Words | If a member needs it explained twice, it was written wrong | F5: "trained new tellers on our escalation script"; F4: "I built the monthly complaints spreadsheet our regional manager uses". Neither says anything needed explaining twice, so this is a scaffold with a slot | R3-C2 |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold, nothing in your material carries it: pick a time with a place or person and a number you set aside; if none, say so plainly | R3-C3, R3-D2 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log", with a slot on whether you stayed with a complaint to the end | R3-C4, R2-B2 |

## Reverse questions

Round 1, the recruiter.

| # | Question | Why it lands |
|---|---|---|
| R1-Q1 | "Does the panel receive anything in advance, and does the case come with material?" | It shows you are preparing for the case, and the answer decides whether a deliverable build is needed |
| R1-Q2 | "Are the four values and the case scored separately by the panel?" | It tells you how to split your 60 minutes |
| R1-Q3 | "Is the role new, or a replacement, and where does it sit between the branches and the contact centre?" | It targets the ownership width behind R2-B1 |
| R1-Q4 | "Who in the contact centre would I work with most closely?" | It shows you have clocked the gap and want to close it |
| R1-Q5 | "What would a good first 90 days look like from the team's side?" | It turns the screen into a conversation about the job |

Round 2, the Head of Member Services.

| # | Question | Why it lands |
|---|---|---|
| R2-Q1 | "Where does the complaints process work well today, and where do members feel it most?" | It asks for the real picture rather than the brochure |
| R2-Q2 | "Who reads the monthly complaints numbers today, and what decisions come from them?" | It links to your reporting evidence and the senior-leaders line |
| R2-Q3 | "Which self-service journeys do you expect digital teams to tackle first, and what do you want complaints data to tell them?" | It uses G1 and the JD's digital line together |
| R2-Q4 | "How would you want me to learn the contact centre side in my first month?" | It converts the gap into a shared plan with your future manager |
| R2-Q5 | "What does the small-business lending launch in Q1 2027 mean for complaints?" | It shows strategic reading; G3 is the raising source, and the question does not assert an answer |

Round 3, the branch managers.

| # | Question | Why it lands |
|---|---|---|
| R3-Q1 | "What do your supervisors find hardest about escalations today?" | Reciprocity: it starts from their problem, not your remit |
| R3-Q2 | "What could I do in my first month that would make your supervisors' week easier?" | It frames the hire as reducing their load |
| R3-Q3 | "As branches move to hubs, how do you want open complaints to be handled for your members?" | It tests Neighbours, Not Numbers; ask it about members, not about anyone's role |
| R3-Q4 | "When a complaint trend points at one branch, how would you want to hear about it from me?" | It shows the tact in R3-E3 before they ask |
| R3-Q5 | "Which of the four values is hardest to hold at your branch on a busy day?" | It invites their stories and fills the values round with their words |

## Prohibited claims

Built before the banks. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log and the tellers' script, not a process across branches |
| Has contact-centre experience | Negative you stated, F2: "Never worked in a contact centre" — your message | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Handled regulated complaints | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says a formal log, not what its complaints involved |
| Reported complaint volumes and resolution times | Inflated form of F4 | F4's quote at its own scope. The slot asks only what the spreadsheet counted |
| Coached supervisors on escalations | Inflated form of F5 | F5's quote at its own scope: new tellers and a script |
| Has presented to senior leaders | Negative you stated, F8: "I've never presented to anyone above regional level" — your message | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the four values as copied from ashgrovecu.org/about/values on 12 October 2026 (pasted text, so the page itself was not fetched); the recruiter's email on the process; your four-point relay of the 2026 strategy brief published in June 2026 (the brief itself was not read); your background message.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the cheat sheet and every VAL question |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the rounds, their lengths, who runs them and what each holds |
| 3. Ashgrove strategy and recent news | skipped | Your relay of the June 2026 brief supplies the priorities that feed the CO questions |
| 4. Interviewer public footprint | n/a | No name was given, only roles, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your CV as written, in place of the message: F1 to F9 would be quoted from it, and an anonymised view of the monthly report layout or the escalation script would raise F4, F5 and F9 from medium
- Your answers to the slots, outside a drill: F1, F3, F4, F5, F6 and F9 would each regenerate with your own words in the evidence column
- The interviewers' names, once assigned: the persona weights would be read from their public footprint, and one reverse question would be tied to each person's path
- The recruiter's answer on whether the case comes with material in advance: it would add a build section for that deliverable
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): it would add interviewer footprints, role-family loop reports, recent organisation context and which complaint rules Ashgrove works under, none of which your material states
- The strategy brief's full text, in place of the four-line relay: the grounding brief would quote it directly
- A tuesday-dossier.md from an earlier evaluation of this role, if you have one: it would add verified evidence and a pre-identified objection; it is not needed for any of this
