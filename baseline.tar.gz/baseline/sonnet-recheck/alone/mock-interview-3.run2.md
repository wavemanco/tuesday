I'll read the skill's reference files first.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-3-denied-834a7862/25c6fc74-ba05-452f-9c87-37e2f90e9816/scratchpad/stripe_product-operations-manager_interview_pack.md`. It has 19 questions across seven interviewer styles, a fit worksheet, reverse questions and an upgrade menu.

I built it for a final round with an unknown interviewer and format, and without your JD or CV.

All four of my web searches were refused for lack of permission. So nothing in the pack is a Stripe-specific fact: no Stripe values by name, no interview structure, no strategy. Every question is a generic Product Operations Manager one. If you grant search permission, I can rerun the research and add those.

With no CV, the guidance tells you how to pick a story rather than supplying one. The pack names B1, "Which part of this role would you be weakest at on day one?", as your highest-ROI prep.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in the final round, and in what format (manager, peer, skip-level, cross-functional, a panel), including any focus areas or deliverable the recruiter named? Whatever you say reweights the banks.
Could you paste the job description and your CV? They turn the generic rows into your real evidence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer: not given. Relationship: not given. JD: not supplied. CV: not supplied. Research: every search was refused, so nothing in this pack is a Stripe-specific fact. The pack is a role-family pack that is complete and rehearsable, and it sharpens as inputs arrive (see the upgrade menu).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one of five type tags:

| Tag | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company and think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

The guidance is scaffolding, not a script. No CV was provided, so no guidance cell claims anything about your past: where a question asks about your experience, the cell tells you how to choose a story and what an honest answer looks like if none comes to mind. Question IDs run A to E, then G and H. The letter F is left out because F1 to F6 are fit-snapshot rows.

The highest-ROI prep in this pack is B1 ("Which part of this role would you be weakest at on day one?"). It is the objection most likely to arrive in some form whatever your background, and a rehearsed, non-defensive answer changes the interview. With a CV, I would replace it with the objection your actual background invites.

## Fit snapshot

This is the worksheet variant, because no CV or background was given. The requirements are role-family patterns written without a source, so they are plain prose and labeled generic. They are not quotes from Stripe's posting. Fill the evidence column yourself in your own words before the interview; the rows tell you what strong evidence would look like.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or programs across product, engineering and go-to-market teams — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a specific launch or program, who was in it, and what part was yours. Selection scaffold: pick one with a named stake and a moment where teams disagreed; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing or running an operating cadence: planning, reviews, recurring rituals — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is one recurring process, why it existed, and how you knew it worked. Selection scaffold: pick a process you set up or changed, and be exact about whether you set it up, changed it or only ran it; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Defining and reading product-health metrics — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is one metric, how it was counted, and one decision it changed. Selection scaffold: pick a number you can explain end to end, including its weakest assumption; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing without authority and giving clear updates to senior stakeholders — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a moment you changed a senior person's mind or delivered news they did not want. Selection scaffold: pick one where the truth actually landed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizing and making trade-offs under ambiguity — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is a decision with competing options and what you gave up. Selection scaffold: pick a trade-off where both options had a real cost; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Improving process or tooling, including automation — role-family pattern, no source | none given | none | [generic] | discovery | Strong evidence is one change to how work gets done and what it replaced. Selection scaffold: pick a change you can describe without inflating its reach; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No row is a gate, because no posting was supplied to show whether the role carries one (location, work authorization, schedule). If it does, the JD will show it.

## Persona weights

No round format or interviewer was given, and no loop source establishes the loop, so this pack falls back to the generic archetype (screen, hiring manager, panel) with flat weights. Final rounds can be several sessions with different people; this pack does not assert Stripe's structure. If yours is several sessions, send the schedule and I will build a mini-pack per session.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live problem from the role: plan this, diagnose that | Equal top weight. The relationship priors put this persona first for a hiring manager and for a skip-level, and the relationship is unknown | Clarify, then objective, segments, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| Skeptic | Quiet, persistent probing of gaps and motivation | Equal top weight. Hiring managers are priced as skeptical in the priors, and a final round is where a gap gets tested | Rehearse B1 until it is boring. Bridge only from adjacent work you can state. Name a concrete ramp plan |
| Values/Behavioral | Scenario probes, often from someone outside the function | Equal top weight. The priors give a cross-functional interviewer this persona, and a final round often includes one. Stripe's published values are not in hand, so the bank uses persona stems only | Choose stories where the hard truth landed. Use we for context and I for your own contribution |
| Peer Evaluator | Seam-splitting between adjacent teams, credit, collaboration | Equal top weight. Product operations sits between teams by nature, so a peer is a plausible interviewer | Reciprocity framing. Propose seam principles instead of pretending to know the seam |
| Conversational | Friendly, unstructured, still scored | Equal top weight. The biography question is near-certain in any round | A scripted 90-second arc. Never answer the reverse-question slot with "I think you've covered everything" |
| Data-Driven Prober | Reads the CV line by line and asks how each number was counted | Lower. With no CV, this bank is thin until one arrives. Per the priors, it leads for peers and technical specialists | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Pressure | Interrupts, time-boxes, tests composure | Lower. The priors put it first only for skip-level and technical rounds | Pause, restate, anchor on what you actually did. Hold through two follow-ups before conceding anything real |

## Question banks

Every row is generic because there is no CV and no JD to quote. A cell that speaks about your past can only be an answer you give in your own words.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Three teams disagree about whether a launch is ready, and the date is two weeks out. Walk me through what you do first." | CASE | [generic] | Clarify first: what does ready mean, who decides, what does slipping cost. State the objective. Lay out two or three options and the trade-off between them. Say who needs to hear what, and what you would write down. This question needs no claim about your past, so the cell makes none | Covers F1 and F5 as a live decision rather than a story. CASE because it scores structure under disagreement |
| A2 | "A product-health metric dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Clarify the definition and how it is measured before anything else. Rule out a data or instrumentation problem first, then list hypotheses by segment and by recent change. Say which you would test first and what result would change your mind | Covers F3. CASE because the structure matters more than the answer |
| A3 | "A product org of several teams has no shared planning process. Sketch the plan, and tell me what you need to know first." | CASE | [generic] | Ask what exists already, what is broken, and who feels it. Propose principles for the rhythm before any ritual. Name how you would tell whether it was working after a quarter. Do not claim to know this org's seams | Covers F2 and F6. Uses the Case persona's own stem. CASE because it scores clarifying before structuring |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The deepest rehearsal in this pack. Choose from your own honest read of F1 to F6: the row where your own material is thinnest. Say it in one sentence without apologizing. Say what you would do in the first weeks to close it. Follow-up one will ask you to defend the choice, and follow-up two will push on whether it is a dealbreaker: hold your answer through both by returning to what you can actually state, and concede specifically what you do not yet know. If no weakness comes to mind, say so plainly, then name the area where you would ask the most questions in week one | The single most predictable objection for any candidate, and the one that decides whether the rest of the interview feels safe. JD because it scores honest self-assessment against the listed job. It becomes the objection your CV actually invites once one is provided |
| B2 | "Why this role, why Stripe, and why now?" | CO | [generic] | Say what drew you in your own words, tied to something you have read, used or watched about the company. Keep it to what you can source. If you cannot name a specific thing, say so plainly and say what you would want to learn in the first month. Never state a fact about the company that you have not checked | The motivation probe every skeptic runs. CO because it tests homework depth. Stripe-specific facts were not researched here, so the content has to be yours |
| B3 | "What would make you decide, six months in, that this role was not right for you?" | JD | [generic] | Name honest conditions from what you want from work, for example the kind of problems and the kind of autonomy. Keep them specific enough to be believable and not so strong that they read as a bad fit. This is about your preferences, so it needs no claim about your past | Tests motivation consistency and self-knowledge. JD because it scores whether you understand the job's hard parts |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact afterward. Use I for your contribution and we for context. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F4 with the Values persona's own stem. VAL because it scores behavior, not a stated principle |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the metric would have looked better the other way, and say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5. VAL because it separates a real trade-off from a slogan |
| C3 | "Leadership has made a decision you disagree with. What do you do?" | VAL | [generic] | A live problem, so it needs no claim about your past. Structure it: what you would check about their reasoning first, how and to whom you would raise the disagreement, and the point at which you commit and carry it out. Say where your line is | Covers F4 and F5 as a decision. VAL because it scores disagreement style |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam instead of claiming to know it: who decides, who is consulted, and how a disagreement escalates. Say what you would bring to their team, not only what you would need. Do not describe this company's structure | Covers F1 and F4. JD because it scores partnership fit with the role as listed |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Describe how you would handle it as a practice, in your own words: how you name contributions and where you say who did what. If you have a real example, say what part was yours; if not, say so plainly and describe how you would handle it | Covers F1. VAL because it scores credit-sharing behavior |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | A reciprocity answer in two halves: what you would want to learn from them, and one useful thing you could offer early, stated as an intent and not a claim about your past | Covers F1 and F2. The peer persona's own reciprocity probe. JD because it scores whether the hire reduces or adds to their load |

### E. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc of three beats, each a sentence you can say truthfully about your own path, with the last beat explaining why this role is next. Do not widen any beat past what you did. If a beat cannot be said plainly, drop it | Near-certain in any round, and scored even though it feels casual. EXP because it tests whether your story holds together |
| E2 | "What do you like most about operations work, and least?" | JD | [generic] | Pick one real thing for each. The least-liked must not contradict the role: choose something you manage and not something the role is mostly made of. This is about your preferences, so it needs no claim about your past | A casual question scored for self-knowledge and interest in the work. JD because it tests fit with the listed job's nature |
| E3 | "What questions do you have for me?" | CO | [generic] | Never answer that you think everything has been covered. Use the reverse questions below and pick three to ask depending on who is in the room | The slot rapport-style interviewers weight as a signal of preparation. CO because it shows how closely you thought about the company |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Choose one number from your CV and walk me through how it was counted." | EXP | [generic] | Pick a number you can explain end to end. In your own words, cover how it was counted, what it is sensitive to, and which part was yours. If you do not know how it was counted, say so plainly and say what you would check. Do not explain a method you cannot repeat under a second question | Covers F3. EXP because every figure on a CV is a target for a prober. Thin until a CV supplies the real numbers |
| G2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the assumption you would defend least before they do, in your own words, and say what changes if it is wrong. If you do not know where the weak point is, say so plainly. Do not supply an assumption you did not make | The standing follow-up. EXP because naming your own weak point turns a gotcha into credibility |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give two or three things you can truthfully say about what you would bring, each a sentence from your own material. Do not make claims about the other candidates. Hold your position through a follow-up before conceding anything | Tests composure under a time box. JD because it scores the case for your fit to the listed job |
| H2 | "That result — how much of it was actually you?" | EXP | [generic] | Hold, then concede specifically. State your share in the exact terms you used the first time. If it was shared, say so plainly and say what part was yours. Never fold on the core claim just to relieve the tension, and never widen it | The standard attribution probe. EXP because it scores precise honesty, which is why it is rehearsed |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-functional launches or programs | A1, D1, D2, D3 |
| F2 Operating cadence | A3, D3 |
| F3 Product-health metrics | A2, G1 |
| F4 Influence and senior updates | C1, C3, D1 |
| F5 Prioritization under ambiguity | A1, C2, C3 |
| F6 Process and tooling improvement | A3 only, and no question of its own: it is a role-family guess with no source, so a JD should say whether it deserves one |

## Reverse questions

Role-generic because no interviewer was named. The first five work with any interviewer; the sixth is for a peer.

| Question | Why it lands |
|---|---|
| "What would a strong first ninety days look like, and how would you know?" | The answer tells you how success is judged and by whom, and it shows you are already thinking about delivery |
| "Where does product operations end and product management begin here, and where does that line get contested?" | Shows you understand the seam is where the job is hard, and the answer tells you where you would have to push |
| "What would you change about how product work gets done here if you could?" | Invites candor about the gap this role exists to fill |
| "How is this role measured, and who decides?" | Surfaces the real scoring sheet, and signals you want to be accountable |
| "What do people who struggle in this role usually struggle with?" | Tells you what the true hard parts are and invites a frank answer from the interviewer |
| "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer. It turns the conversation toward their needs |

## Prohibited claims

Built locally. With no CV, there is no sentence of yours to inflate, so these entries come from the situation and not from your material.

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your own past that is not in your own words | No CV or background was provided, so nothing was available to quote | Every cell above is a selection scaffold or a live problem. You supply the story, and the story is only what you did |
| Stripe's values by name, its interview structure, and its current strategy | Research was refused, and memory is not a source for facts that drift | Say only what you have read yourself. If asked about the company's principles and you cannot name them, say so plainly and say what you have read |
| A comparison with other candidates | Nothing in any input supports one | H1 holds to what you can say about your own material |

## Sources

Provided documents: none. The only input was the request: Stripe, Product Operations Manager, final round.

Searches sent, all refused for lack of permission:

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description responsibilities qualifications" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have given the official principles by name and the values cheat sheet. Without it, section 10 is dropped and the Values bank uses persona stems only |
| 2. Stripe interview process, product operations | unavailable | Would have named the rounds and set the persona weights from a documented loop. Without it, weights are flat on the generic archetype |
| 3. Stripe strategy and recent news | unavailable | Would have grounded at least one CO or CASE question in current strategy. Without it, B2 is the only CO question and it is generic |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the generic rows F1 to F6 into inferred rows quoting a real posting, and shown any gates. Without it, the rows are plain role-family prose |

## Upgrade menu

- The job description text → F1 to F6 become quoted, grounded requirements, a JD-tagged question is added for each mid-list item, and any gate (location, work authorization, schedule) appears as its own row
- Your CV or a few sentences about your work → the evidence column fills with your own words, guidance becomes story-mapped instead of scaffolded, G1 and G2 are rewritten around your real numbers, and B1 is replaced with the objection your background actually invites
- Who you are meeting and the format (manager, peer, skip-level, cross-functional, panel) → persona weights move off flat and the banks are reordered and resized
- The interviewer's name → an interviewer read from their public professional footprint and a reverse question tied to their path
- The recruiter's prep email → coverage of any focus area or deliverable the recruiter named, usually one email to the recruiter
- If your final round is several sessions, the schedule → a mini-pack per session with its own weights
- Search permission, then a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) → Stripe's published values by name with a mapped cheat sheet, the documented loop, current strategy for CO and CASE questions, and a grounding brief
- A prior tuesday-dossier.md → verified evidence, per-gap strategy and prohibited claims arrive already graded, so the objection to rehearse comes from evidence instead of inference
