I'll read the reference files the skill points to before writing the pack.
Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-7-canned-505b6ca9/f2d1cbbc-0657-4e59-8e3e-6df72e4ef53f/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md. It has 19 questions, a fit snapshot, a values sheet, six reverse questions and a "what I won't coach" list.

I built it assuming Tobias is the hiring manager and that your session is the one Saltmarsh's interviewing page calls the Outage Hour. That is a 60-minute session that opens with a tabletop on a simulated outage during a live event and then moves to a values conversation. I also assumed about a day of prep.

- **Tabletop first:** Case questions A1 to A5 carry the most weight. Time A1 and A2 out loud.
- **Highest-ROI rehearsal:** C1, "you haven't led a team, and this role coordinates four disciplines on every update". The pack gives you the plain acknowledgment, what you can honestly hold on, and one specific concession.
- **Two things to settle before Friday:** the slots in F1 to F4, where your material is silent on whether your content drops were events, which teams you coordinated, and who chose the retention numbers. Answer from memory; "that wasn't mine" or "there was no such step" are fine answers.
- **Read the full Project Larkspur post:** I only saw a search snippet of it, and of Tobias's GDC talk. Both are behind A3, R1 and R3.

Say the word and I'll play Tobias on C1, or run the tabletop starting at A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager this role reports to, and did the recruiter mention any focus areas for the Outage Hour? Your answer would reweight the banks.
Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) on Larkspur and Tobias's talk?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute session on Friday. Saltmarsh's interviewing page describes its loop as a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home (Sources S2). This pack assumes Tobias is that hiring manager and that you are preparing for that session. Neither point is confirmed by the recruiter.
**Prep time assumed:** about one day. If you have more or less, section 3 is the part to resize.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one persona letter (A to F) and one type tag.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values / behavioral | Whether your past behavior shows Saltmarsh's published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | The stated responsibilities and requirements, gaps included |
| CO | Company and strategy knowledge | Whether you know where Saltmarsh is going and can think at that level |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

The guidance is scaffolding for a spoken answer, not a script. Where a cell says "answer slot", it is an instruction for the interview: the pack does not know the answer, and either honest branch is a good answer. Say what is true, in your own words.

## 2. Prep triage

About one day, in this order:

1. **Say A1 and A2 out loud against a timer.** The tabletop opens the session and is the block you cannot improvise structure for. Practise clarify, objective, plan, communicate, log.
2. **Rehearse C1 until it is boring.** It is the highest-ROI prep in this pack. Say the plain acknowledgment, hold your ground on the calendar and the checklist, concede the specific thing, and finish on the plan.
3. **Settle your answers to the F1, F2, F3 and F4 slots.** Each is a question you can answer in thirty seconds from your own memory. They decide how much of the pack's guidance can become story-mapped.
4. **Pick one value for B-bank and E2.** Prepare B3 fully. For the other two values, know your honest branch.
5. **Read the Project Larkspur announcement in full** (Sources S3). The pack saw only a search snippet of it. Then pick two reverse questions from section 11.

Everything else is insurance.

## 3. Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is your own words from your message. F8 and F9 are not JD requirements: they are limits you stated, kept here because the Skeptic bank will go to them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title; the JD says a live-events calendar across two. The words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on whether any drops were timed events and on running more than one calendar. If any were events, say which, in your own words; if they were content drops, say so plainly. If you ran more than one calendar, say so; if it was the main title's calendar only, say that and stay with it |
| F2 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The quotes give four years as an associate producer and two years on the calendar. They do not show how long the main title was live or what the earlier years covered. Answer slot: expect a probe on the 3+ years. Say in your own words what the title was and what your role was across the four years; if some of those years were not work on a live game, say so plainly and stay with the two years on the calendar |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not say which teams your weekly drops involved. Answer slot: if any drop needed design, art, engineering or community, say which and what you did with each, in your own words; if you worked with fewer of them, or the coordination was someone else's, say so plainly and describe the part you did |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented the numbers; the JD says own the review and the KPIs it reports. The words stay at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on who chose those numbers and whether a review followed events or drops. If you chose them, say how you decided; if they were set for you, say so plainly. If a review followed a drop, say what it covered; if there was none, say that |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: you wrote the release checklist, and your QA team still uses it. It says wrote, not that you ran it release by release, and the pack adds nothing to it. Expect a probe on what the checklist covers, which A4 and B3 rehearse |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but a one-line statement with nothing inspected behind it, so expect a probe on how the numbers were counted (D1). Lead with what you did in the quote's own terms: you presented the monthly retention numbers to the studio head |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist is writing, but the quote does not show how it read to anyone beyond QA still using it. Answer slot: if you wrote other material that players, teammates or leadership read, say what, in your own words; if the checklist is the main writing you have done at work, say so plainly |
| F8 | Leading people — not in the JD, which asks for coordination; raised by your message | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A limit you stated, and the words are yours: "I haven't led a team." After it, a plan and not a past: how you would earn agreement from each discipline in your first weeks. Nothing is added to make the limit feel smaller |
| F9 | Experience of in-app purchases — not in the JD; raised by your message | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A limit you stated, and the words are yours: "I haven't worked on a game with in-app purchases." After it, a plan: what you would ask first about how purchases appear in an event's results. Nothing is added to make the limit feel smaller |

## 4. Reading the interviewer

Public professional footprint only. Both facts come from one search snippet each; the talk itself was not fetched.

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | S4 (talk listing) | [grounded] | He has run release gates from the QA side. Expect interest in how your checklist works, and precision about what you did versus what a team did |
| Gave a GDC 2026 talk, "Patch Notes Are a Promise", whose argument is that a live team is judged by how often its patch notes describe what actually shipped | S4 (talk listing) | [grounded] | He may probe the gap between what you announced and what shipped. The same idea appears in Saltmarsh's published value "Ship the Patch Not the Promise" (S1). Describe outcomes at their real scope |
| Mirror opportunity: shared vocabulary of QA and release checklists | F5 | [grounded] | You can say, in the quote's words: "I wrote the release checklist our QA team still uses." Say it as a fact and let him ask what is on it |

## 5. Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a simulated outage during a live event | Highest. The interviewing page names the tabletop as one of the two parts of the session (S2). 5 questions | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise respectfully |
| B. Values / Behavioral | The values conversation that follows the tabletop | High. The same page names a values conversation, and the values page publishes three (S1, S2). 4 questions | Map a story to each value where your quoted sentences carry one; use the selection scaffold and its honest branch where they do not |
| C. Skeptic | A hiring manager weighing your limits against the JD | Medium. A hiring-manager session is where gaps get weighed, and you named two of them. 3 questions | Rehearse C1 until it is boring. Say the limit plainly, hold on what you did, concede specifically |
| D. Data-Driven Prober | Probing the retention numbers and the calendar | Lower. Nothing found describes Tobias as metrics-led; his published argument is about accuracy of statements. 3 questions because the JD asks for KPIs | Say how a number was counted if you know, and say plainly when you do not |
| E. Conversational | The opening ("walk me through the journey") and "why Saltmarsh" | Lower. Every session has an opener, but the page describes a structured format. 2 questions | A 90-second arc built from your own sentences |
| F. Pressure | Time-boxed tabletop injects, "how much was actually you" | Lower. The page does not say the tabletop is adversarial; a live-incident format can still be time-boxed. 2 questions | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator | Not banked | A single hiring-manager session; no peer round is documented in S2 | None needed for this session |

## 6. Question banks

Questions are the interviewer's lines. Where a question presupposes something about your past, the Provenance cell holds the sentence of yours that allows it, or the guidance holds an answer slot.

### A. Case / Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's day two of a weekend event. Reward claims are failing for some players and the community channel is filling with complaints. You have the first fifteen minutes. What do you do?" | CASE | [generic] | Clarify before you act: how many players, which platforms, since when, whether the event is still running, whether engineering has a cause. Then say the objective in one line: stop the harm to players and keep the record straight. Then sequence: who owns the technical fix, what you own (the clock, the coordination, the first player message), what you decide and when (pause, extend, compensate). Say your assumptions aloud and ask who can pause the event. Close with what you would capture for the post-event review | The tabletop is the first half of the documented session (S2), so this is the question most worth timing. CASE because it scores structure under a live problem; `[generic]` because the actual scenario is the pack's example of the format, not Saltmarsh's |
| A2 | "Draft the first message to players about that outage. You have two minutes." | CASE | [generic] | Short and plain: what players are seeing, who is affected, what is known and what is not, what players can do now, and when the next update will come. State only what is built or confirmed; promise no fix time you cannot back. That is also the company's published value, "we announce what is built, not what is hoped" (S1) | Tests the JD's written-communication line (F7) inside the tabletop. CASE because it is a live task; the value gives it a standard |
| A3 | "From January 2027 both titles share one events calendar. Two events want the same weekend, one per title, and design says both are locked. How do you decide, and who do you talk to first?" | CASE | [inferred] | Clarify what locked means (assets, economy, comms). Objective: players' experience across both titles. Segment: do the player bases overlap, what each event costs to move, what QA and engineering can support in the same window. Options: stagger, combine, move one with notice. Decide on players first, then dependencies. Talk first to the owners of each event, then QA and community. Name the risk of an event announced and then moved | The strategy question. Derived from the Project Larkspur announcement seen as a search snippet (S3), hence `[inferred]`; the JD's "two of our mobile titles" (F1) points the same way. CASE with a CO flavour |
| A4 | "A hotfix is needed mid-event and QA says the release checklist isn't complete. The event ends in six hours. Ship or hold?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure first: which items are missing and what risk each carries, what failure would cost players, the options (ship with a named risk and a rollback, hold and extend the event, ship in part), who signs off, and what you tell players either way. Open with the quote if you want a hook: "I wrote the release checklist our QA team still uses." Answer slot: the values page says every release leaves the checklist better than it found it (S1), so expect a probe on a hotfix path. If your checklist has one, say how it handles a hotfix, in your own words; if it has none, or you never applied it to a hotfix, say so plainly and describe how you would decide here | The JD's "manage the release checklist with QA" (F5) as a live decision. CASE because the format is a tabletop; the slot exists because the quote says wrote, not ran |
| A5 | "Last weekend's event ran and retention for the players who joined through it is below what we expected. How do you diagnose it?" | CASE | [generic] | Clarify the metric (which cohort, which day, compared to what baseline). Segment: new versus returning, platform, entry point. Hypotheses: event design, technical issues during the event, comms, overlap with other content. Say what data you would pull and what you would not conclude before you had it. Name the assumption in your own read that you would defend least, before he does | Covers the JD's retention and post-event review lines (F4, F6) as a diagnosis rather than a past. CASE; `[generic]` because it names no Saltmarsh metric |

### B. Values / Behavioral (the second half)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players wanted different things." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold, for the value "Players Before Plans" (S1). Pick an instance with a named schedule commitment, a player-side signal that pointed the other way, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the weekly calendar you ran, or how you would handle it | The first published value. The quote does not carry a conflict, so this is a scaffold. VAL because it scores one specific published value |
| B2 | "Tell me about a time you pushed back on announcing something before it was finished." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold, for "Ship the Patch Not the Promise" (S1). Pick an instance with a named announcement, someone who wanted it out early, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the checklist you wrote, or how you would handle it | Second value, and the one closest to Tobias's talk (section 4). The quote is offered only as the nearest thing; it shows no pushback |
| B3 | "What does it mean to you to leave the checklist better than you found it? Tell me about a time you did." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F5 with only the beats the quote states: you wrote the checklist, and your QA team still uses it. Answer slot: the values page raises this one (S1). If the checklist changed after a release or a miss, say what changed and why, in your own words; if it has not changed, or you did not revise it, say so plainly and stay with the fact that it is still in use | Third value and the best-supported story in your material. VAL, with an EXP edge on what you did |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold. It needs a named stake, a message the listener did not want, and what happened to the relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the monthly retention numbers to the studio head, or how you would handle it. Do not suggest the numbers were bad unless they were | A standard values-round question. Your material shows no such moment, so the pack supplies none. VAL |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't led a team. This role coordinates design, art, engineering and community on every update. Where will that show first?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | **Highest-ROI prep in this pack.** Hold, then concede. Open with the plain acknowledgment: "I haven't led a team." Hold on what your material carries: the weekly calendar you ran and the checklist your QA team still uses. First follow-up, likely "what did you coordinate": that is the F3 answer slot. If a drop needed design, art, engineering or community, say which and what you did with each; if you worked with fewer, say so plainly and stay with the calendar and the checklist. Second follow-up, likely "so where will it show": concede one specific thing, that coordinating all four disciplines on every update is what your material does not show, then give the plan: in the first weeks, meet each discipline's lead, learn how each prefers to receive an update, and ask what each needs from the calendar | F8 and F3 meet here: a limit you stated against the JD's coordination line. It is the objection most likely to arrive in some form, so it gets the most follow-up levels. JD because it scores a stated requirement |
| C2 | "You haven't worked on a game with in-app purchases. If our events touch purchases, how would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment first: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: ask what the events are measured on, learn how purchases appear in an event's results, and ask who to learn it from. Do not claim anything about monetization from the retention work. If you want to ask Tobias whether events touch purchases at Saltmarsh, reverse question R6 does it | F9 is a stated limit. The JD is silent on purchases, so the question carries a conditional ("if our events touch purchases") and the pack does not assume they do. JD |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Name one real weakness. The ones your material supports are leading people (F8), purchases (F9), and the F3 coordination slot. Say it plainly, say what you would do in the first weeks about it, and stop. Do not choose a strength dressed as a weakness | Persona stem for the Skeptic. JD because it scores honest self-assessment against the stated requirements |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The quote gives no figure, so the pack supplies no method. Answer slot, in four parts, each in your own words: how the numbers were counted, what they were most sensitive to, the assumption behind them you would defend least, and which part was yours versus someone else's. If you do not know how they were counted, say so plainly. Return to the quote: you presented them | F6 is the retention evidence and a one-line statement with nothing inspected, so a prober goes straight here. EXP because it tests attribution and understanding of your own numbers |
| D2 | "Tell me about a post-event review you ran. What was in it and what changed afterwards?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: the JD asks you to own the post-event review. If a review followed a drop or event, say what it covered and what you did, in your own words; if there was no such review, or it was not yours, say so plainly and return to the monthly retention presentation in the quote's words. Then, as a plan, say how you would build one: what was planned versus what happened, what players did, what you would change, and which KPIs were agreed before the event | F4 is the evidence and holds a gap. JD because the requirement is the premise; the second branch lets the premise be false |
| D3 | "On the calendar you ran, how did you decide what went into a given week?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: expect this probe on F1. If you decided or shaped what went into a week, say how, in your own words; if the contents were set by others, or there was no decision step you owned, say so plainly and describe how you ran the calendar. Do not name a process you did not use | F1 is the calendar evidence. The JD asks you to plan as well as run, and the quote says run. JD with an EXP edge |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only these four sentences: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for the main title for the last two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. Answer slot: why live operations and why Saltmarsh. Give your own reason; if you do not have one reason, say what is true | The opener is scored. F2 is the years-of-experience line it will set up |
| E2 | "What drew you to Saltmarsh?" | CO | [grounded] | Pick the one published value, or the Outage Hour format, that you genuinely connect with, say why in your words, and stop. Do not recite all three. If you mention Project Larkspur, read the announcement first (Sources S3); the pack saw a snippet only | Homework signal. CO because it scores company knowledge; label alone because the guidance makes no claim about your past |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, rather than someone who has led a live-ops team?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause, restate the question. Hold on two sentences: you ran the weekly content-drop calendar for the main title for the last two years, and you wrote the release checklist your QA team still uses. Do not say what they prove. Concede one specific thing: you haven't led a team. Hold through two follow-ups by returning to the same two sentences | Persona stem. The comparator is hypothetical, so nothing here asserts a rival exists. JD because it scores fit against the stated role |
| F2 | "That calendar: how much of running it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Keep the quote's scope: "I ran the weekly content-drop calendar." Answer slot: say which parts were yours and who else shaped it, in your own words; if someone else set priorities, say so plainly and stay with the part you ran. Concede nothing that is true and nothing that is not | F1 is the claim being tested. EXP because it tests attribution |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, D3, E1, F2 |
| "coordinate design, art, engineering and community teams on each update" | A1, A2, C1, C3 |
| "own the post-event review and the KPIs it reports" | A5, D1, D2 |
| "manage the release checklist with QA" | A4, B3 |
| "3+ years producing live-service games or apps" | D3, E1 |
| "comfortable with player-retention metrics" | A5, D1 |
| "clear written communication" | A2 |

## 7. Values cheat sheet

The three values are named as Saltmarsh publishes them (S1). The session's second half is a values conversation (S2).

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None of your sentences carries a conflict (F1). Selection scaffold: pick a time with a named commitment, a player signal pointing the other way, and your decision. If none comes to mind, say so plainly, then give the nearest thing, the weekly calendar you ran: "I ran the weekly content-drop calendar for our main title for the last two years." (B1) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None of your sentences carries it (F5). Selection scaffold: pick a time you held back an announcement. If none comes to mind, say so plainly, then give the nearest thing, the checklist: "Wrote the release checklist our QA team still uses." (B2) |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F5: "Wrote the release checklist our QA team still uses." Beats are the quote's only: you wrote it, and QA still uses it. Whether it changed since is the B3 answer slot |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How does your team check that after an event, and what does the review do with a mismatch?" | Ties to Tobias's own published argument (S4) and to the post-event review the JD names. Shows you researched him, not just the company |
| R2 | "You moved into live operations from QA. What did that teach you about the release checklist that you'd want a producer to carry?" | Ties to his own path (S4). Invites him to teach, and brings the checklist you wrote into conversation on his ground |
| R3 | "The Larkspur announcement describes one shared calendar and a single live-ops group from January. What would this role own in that structure, and does it still cover two titles?" | Shows you read the announcement (S3) and asks the question the JD's "two of our mobile titles" cannot answer |
| R4 | "What does a post-event review look like here today, and which KPIs get reported upward?" | Maps to the JD's "own the post-event review and the KPIs it reports" and gets you the real baseline |
| R5 | "Which of the three values is hardest to hold during a live event, and when did it last cost you something?" | Gets a real story from him and shows you take the values as working rules |
| R6 | "Does this role have direct reports, and do the events touch in-app purchases?" | One honest question that settles both limits (F8, F9) so you can plan the first weeks |

## 9. Prohibited claims

What this pack will not coach, with the basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F8 | The plain acknowledgment: "I haven't led a team." Then a plan, never a past |
| Worked on a game with in-app purchases, or owned a revenue figure | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: a weekly content-drop calendar for your main title. The pack's observation: your material says content drops for one title. The A- and D-bank slots stay inside the calendar you ran |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope: you presented the monthly retention numbers to the studio head. D2's slot asks only what a review covered, if there was one |
| Managed the release checklist with QA release by release | Inflated form of F5 | F5's quote at its own scope: you wrote the checklist, and QA still uses it. A4 and B3 slots ask only about the checklist's contents and changes |
| Four years producing a live-service game | Inflated form of F2 | F2's quotes at their own scope: four years as an associate producer at a puzzle-game studio, two years on the weekly calendar. The F2 slot asks what the title was and what the earlier years covered |

## 10. Sources

**Provided:** the JD and your background, in your message.

**Searches and fetches sent:**

| # | Call | Returned |
|---|---|---|
| S1 | search "Saltmarsh Games values"; fetch of the returned page | https://saltmarshgames.com/values. Fetched in full: three values, Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener |
| S2 | search "Saltmarsh Games interview process live operations producer"; fetch of the returned page | https://saltmarshgames.com/careers/interviewing. Fetched in full: recruiter call, then the Outage Hour, a 60-minute interview with the hiring manager (tabletop on a simulated outage during a live event, then a values conversation), no take-home |
| S3 | search "Saltmarsh Games strategy news mobile" | https://saltmarshgames.com/news/project-larkspur, search snippet only, not fetched: August 2026 announcement of a season-pass model for Tidepool Tactics and Lantern Row, one shared events calendar from January 2027, and a single live-ops group in place of per-title event teams |
| S4 | search "Tobias Wrenfield Saltmarsh Games" | https://talks.gdconf.example/2026/patch-notes-are-a-promise, search snippet only, not fetched: GDC 2026 talk by Tobias Wrenfield, Head of Live Operations, previously a QA lead at a console studio |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet (section 7) and the B-bank, by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Session structure: tabletop then values; persona weights in section 5; no graded deliverable, so no build section |
| 3. `Saltmarsh Games strategy` | yes | A3 and R3, from a snippet only; the full post would sharpen both |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Section 4, R1 and R2, from a snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 11. Upgrade menu

- The recruiter's note on the Outage Hour (focus areas, scenario type, whether Tobias is the interviewer) → confirms the persona weights and the tabletop's likely scenario type
- A deeper research pass (the full Project Larkspur post and Tobias's talk) → a grounding brief section, a grounded A3, and sharper R1 and R3
- Your answers to the slots in F1, F2, F3, F4 and F7, typed here → those rows become quoted evidence and the matching guidance becomes story-mapped instead of a slot
- The release checklist itself, or a content-calendar export or retention report excerpt (the artifacts this field keeps) → can raise F1 and F5 from medium to high
- A tuesday-dossier.md from an earlier engagement → verified evidence, a sourced prohibited-claims list, and strategy per weak area; never required
- A working-style assessment, if you have one → a delivery-coaching section
