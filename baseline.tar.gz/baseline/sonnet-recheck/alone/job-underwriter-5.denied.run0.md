I'll read the reference files the skill requires before building the assessment.
**Yes, it's worth applying.** R3, R4, R5, R6 and R7 (every `must_have` row) land `direct`. R8, the BigQuery gap, is a bridge, not a hole. R1 and R2, the location and pay gates, are unconfirmed because I don't have your location or pay floor. **Status: `conditional_go`.**

## Decision snapshot

**Fit ledger**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery) · unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 is a credible bridge with its limit named. R9 and R10 are open questions, not shortfalls.

**Opportunity ledger.** The pay is the strongest signal (RR3). The open points are an unnamed team and manager (RR1), employer facts I couldn't check (RR2), equity terms (RR4), what "run" means for on-call (RR5), and no stated first-year outcomes (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm the location and pay terms work (R1, R2).
  2. The BigQuery bridge is framed as adjacent, never as BigQuery experience (R8).
  3. The team, manager and employer facts check out in conversation (RR1, RR2).

Stage assumed: evaluating.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; I could not check it independently |
| Posting status | "Accepting applications" at 09:12 today | `[grounded]` your report; not verified by me |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Terms | Remote (US) or Denver; $148,000–$166,000 plus equity | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Scope read | One domain's pipelines, no direct reports mentioned, which matches the typical scope in your pay report | `[inferred]` from the JD's silence on reports; `[generic]` for the typical scope |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500, "Senior" typically 5–8 years (Datawright 2026, US, n=2,310). The posting's low end is $3,000 under the median and its top is $2,500 over the 75th percentile. Your 6 years sits inside the usual seniority range, and a Series C company sits inside the cohort | `[generic]` band from the report you provided; `[grounded]` JD figure, your 6 years and the company's stage |
| Unknowns | Hiring manager, team size, equity terms, on-call expectations, success measures, your location and floor | `[grounded]` posting and your message are silent on each |
| Contradictions | None between the JD and the about text as pasted; neither was checked against the live site | `[grounded]` the two pasted texts |

## Evidence map

Your background was typed into the chat. It counts as self-report, so `medium` is the ceiling until an artifact is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US. Confidence is `none` because no constraint of yours was stated | `[grounded]` JD; your constraints not given | Gate question below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given. Whether the range clears it is unknowable yet. Against the market, see Role reality | `[grounded]` JD; floor not given | Gate question below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Confirmed and specific, but nothing inspectable yet. This is a years requirement, so it is not a gate | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Depth of use isn't described and nothing inspectable was offered | `[grounded]` your message | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built a dbt project of about 180 models on Snowflake, which is a cloud warehouse. BigQuery specifically is R8 | `[grounded]` your message | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. What you owned versus used isn't stated, so expect a probe on that | `[grounded]` your message | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite, which is a specific and first-person claim. No artifact yet | `[grounded]` your message | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The bridge is your dbt-on-Snowflake work. The limit is that you have never used BigQuery. The JD lists "a cloud warehouse" as the requirement and names BigQuery only in the mandate | `[grounded]` your message and the JD wording; `[generic]` that warehouses differ in syntax and cost behaviour even when the dbt layer carries over | Bridge case in G3 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | You describe orchestration but not which sources you ingested. App-event and CRM sources aren't mentioned | `[grounded]` silence in your message | G1 question |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite sits nearby. Nothing you said covers agreements with data producers or analysts on schemas or guarantees | `[grounded]` silence in your message | G2 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R9, important) | discovery | Pipelines and orchestration are established. Source systems aren't | The mandate opens with this, so it decides whether R9 becomes `direct` | Event or product-database extracts, a Salesforce or HubSpot sync, a Fivetran or Airbyte setup you configured or replaced, a custom API loader | A DAG listing or an architecture sketch | `[grounded]` your message is silent on sources |
| G2 | Data contracts (R10, important) | discovery | A test suite is established. An agreement with producers or consumers isn't | The JD names "data contracts our analysts depend on" as a deliverable | A schema or freshness guarantee you agreed with analysts or app engineers, alerting on breaches, a documented model owner or SLA, dbt contracts or tests that gated a release | Great Expectations Data Docs, a dbt YAML excerpt, or a written spec | `[grounded]` your message is silent on contracts |
| G3 | BigQuery (R8, important) | transferability | Snowflake and dbt carry over. BigQuery use doesn't exist | An interviewer will likely test the warehouse named in the mandate | A BigQuery side project or sandbox, even small | A small public dbt-on-BigQuery repo | `[grounded]` your statement; `[generic]` that this role family tests the named warehouse |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and manager unnamed | unknown | — | "The posting names no hiring manager" (your note) | Scope and reporting line can't be judged from the posting | `[grounded]` your note on the posting | Who would I report to, and how many engineers and analysts are on the data team today? | unresolved |
| RR2 | Employer facts unchecked by research | unknown | — | "264 employees. Series C ($52M, February 2026)." | The facts are as pasted, but my live check was refused, so nothing is independently confirmed | `[grounded]` pasted text; check not run | Can you confirm the team this role sits in and that the role is open on your careers site? | unresolved |
| RR3 | Pay at or above the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The posted range matches or exceeds the median for the cohort | `[grounded]` JD; `[generic]` band | What is the leveling for this role, and where in the range do offers usually land? | noted |
| RR4 | Equity unspecified | unknown | — | "plus equity" | Amount, vesting and valuation aren't given | `[grounded]` JD | What equity grant range, vesting schedule and latest valuation apply at this level? | unresolved |
| RR5 | "Run" may imply on-call | unknown | — | "Build and run the pipelines" | Operational ownership may include after-hours response | `[inferred]` from the JD's verb | Is there an on-call rotation, and how many people share it? | unresolved |
| RR6 | No first-year outcomes | unknown | — | JD silent on outcomes | Success measures are undefined for the role | `[grounded]` JD silence | What should this role have delivered in its first year? | unresolved |

## Application plan

Every row is proposed and none is final.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put "Built the dbt project on Snowflake, about 180 models" and "Set up the Great Expectations test suite" in the top third of the CV. I have not seen your CV, so this is proposed wording only | R5, R7 | `[grounded]` your message | pending your approval |
| E2 | State the warehouse plainly: dbt on Snowflake, no BigQuery. Do not list BigQuery as a skill | R8 | `[grounded]` your message | pending your approval |
| W1 | A small public dbt-on-BigQuery project, if you want a work sample | R8, G3 | `[inferred]` from the limit in R8 | pending your approval |
| Q1 | Ask RR1, RR4 and RR5 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both calls were refused: a fetch of pellucidlearning.com/careers/senior-data-engineer and a search for "Pellucid Learning online tutoring K-12 Denver Series C". It would have confirmed the posting is live, the entity exists as described, and the JD matches. Until then it rests on RR2 and Role reality's posting-status row |
| 2. Role-family sweep | skipped | Your pay report is in hand and already fixes the market calibration and the pay-versus-market check |
| 3. Hiring manager's footprint | n/a | The posting names no one, so there is no query to form |

I can offer `tuesday-dossier.md` at the natural end of this, if you'd like a file to keep.

## Upgrade menu

- **Your CV** (or a link to it), with Great Expectations Data Docs, a dbt docs lineage page, or an Airflow DAG listing, sanitized: R3–R7 can reach `high`, and E1 can be drafted against real wording.
- **Your location, work authorization and pay floor:** R1 and R2 resolve, and the decision becomes `go` or `no_go`.
- **Answers to G1 and G2:** R9 and R10 move off `unclear`.
- **Web access for target 1:** the live-posting and company check runs, and RR2 closes.
- **The hiring manager's name, if you find one:** the scope read and positioning get a reader to aim at.
- **A deeper research pass** (funding and leadership news, public employee reports; up to 5 more searches and 2 more fetches), if you say the word.

## Questions

1. **R1, R2:** Are you US-based and authorized to work there (remote, or Denver), and does a base of $148,000–$166,000 clear your floor?
2. **G1 (R9):** Which source systems did your pipelines ingest from, and was any of it a product database, event stream or CRM? What did you own?
3. **G2 (R10):** Have you agreed a schema, freshness or quality guarantee with the people consuming your data? What happened when it was breached?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.