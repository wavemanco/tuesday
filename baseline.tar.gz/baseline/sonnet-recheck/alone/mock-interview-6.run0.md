I'll read the reference files first.
I've saved a three-round prep pack. The searches I tried were refused, so it has no Larkfield research behind it.

I built it as loop mode: one shared fit snapshot, then a mini-pack for each round with its own persona weights, 8 questions and reverse questions. The tradeoff is that the personas follow your account of the rounds, not a published Larkfield process.

- **Your biggest objection:** you said you've never managed managers or owned a hardware-adjacent roadmap. Question A1 (Tuesday) rehearses it in depth. Monday's C4 is the same objection in 60 seconds, so A1 is the first thing to prepare.
- **Your two numbers:** the 60% on-call drop (A6, A7) and the "about 40 interviews" (B4) each get a defend-the-number question. Your sentence says the drop came *after* you pushed the reliability quarter, not *because* of it. The pack keeps that wording.
- **The research gap:** there is no values cheat sheet for Monday, because I couldn't fetch Larkfield's values. Company-knowledge question C7 is generic.
- **Guidance cells:** they only use your own sentences. Where your material is silent, such as engineer growth, device-management work, or whether product applied the roadmap pressure, the guidance is a slot for you to fill in your own words. "Nothing like that happened" is always an allowed answer.

Everything is in `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-m18-sonnet-alone-rooms-mock-interview-6-denied-fd9235bf/34839fce-24d5-43ae-977e-fe5d5a81f948/scratchpad/larkfield-systems_engineering-manager_interview_pack.md`

Say the word and I'll play the Director on A1 with live follow-ups, since the pack names it as the highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter give any focus areas or a prep task (a case, a presentation) for Tuesday or Thursday? Anything they said would reshape those rounds.
Can you paste the full job description and your CV? Both would replace the three role lines and the four sentences I'm quoting now.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

No interviewer names were given, so there is no interviewer read. The loop above is the one you described; no company-published loop source was available (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Every question carries one or more type tags:

- VAL: whether past behavior shows the values the company publishes, not generic virtue
- EXP: whether a claim about your experience survives scrutiny, including what was actually you
- JD: the stated responsibilities, including the gaps
- CO: company and strategy knowledge
- CASE: a live problem from the role, scored on structure

Guidance is scaffolding for a spoken answer, not a script. Any line marked Answer slot is an instruction for the interview: say what is true in your own words, and the second branch is always allowed. Provenance labels: `[grounded]` traces to what you wrote or to the role description you gave; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern that asserts nothing about you or Larkfield.

## Prep triage

Three rounds in about two weeks. Do these in order; everything else is insurance.

1. Before Tuesday: A1 (the objection you will certainly meet, and the one Monday's C4 repeats in 60 seconds), then A6 and A7 (the reliability quarter and the 60%), then the A8 arc.
2. Before Thursday: B3 (hardware dependency, with the concession first), B4 (the "about 40 interviews" figure), B6 and B8 (the product-disagreement and growth stories, both of which have answer slots to fill).
3. Before Monday: C1 and C2 (philosophy and unpopular truth, which lean on stories the earlier rounds will already have heard), C5 (how much was you), C4 (A1 at 60 seconds). The round is 30 minutes, so expect to reach about five questions.
4. Across all three rounds: tell the reliability-quarter story in the same words each time, resting only on the sentence in F3.

Everything else in the banks is insurance.

## Shared fit snapshot

Requirements are quoted from the role description you gave. Evidence is your own words, from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says a team of 6, not two squads, with nothing inspected behind it. The words stay at that scope: "I was a team lead of 6 for three years." The role description does not say whether each squad has its own lead; that is a question for the recruiter or the Director. Plain acknowledgment, sourced from your own sentence: "I've never managed managers." Answer slot: the two-squad line makes a probe on how you would split attention across them likely. If any of your lead work reached beyond the team of 6, say what and which part was yours; if none did, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | Your sentence already reaches hiring in role-relevant terms, but it is a single line with nothing inspected behind it, so expect a probe on it. Lead with the loop in the sentence's own terms: you run it, for backend roles. The figure is "about 40 interviews", and defending it is a separate task (B4) |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Pushing a reliability quarter through is adjacent to owning delivery, not the same thing, and the sentence says the drop came after the push, not because of it. Use it at that scope. Answer slot: if you traded commitments to make room for the quarter, say which and who agreed; if nothing was traded, or it was not your call, say so plainly and stay with what you pushed |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description (the growth part) | none given | none | [grounded] | discovery | Your material does not show an example of helping an engineer grow, and it does not say there was none. Answer slot: if there is one, say what you did and what changed, in your own words; if there is not, say so plainly and say what you would do first with 11 engineers |
| F5 | "partner with hardware and product on roadmap" — role description (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The sentence touches roadmap pressure without saying who applied it or whether product was involved. This pack derives the link; it is not yours to assert. Answer slot: if the pressure came from product and you worked through it with them, say how; if it came from elsewhere, or there was no product partner in it, say so plainly |
| F6 | "partner with hardware and product on roadmap" — role description (the hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words for you: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Your sentence is about owning a roadmap; your material is silent on partnering with hardware teams, so no claim is made either way |
| F7 | "building device-management services" — role description | none given | none | [grounded] | discovery | Your material does not show work on device-management services, and does not say there was none. Answer slot: if you have built or run anything of that kind, say what and your part in it; if not, say so plainly and say how you would get up to speed |

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the gaps: scope jump, hardware, why leave payments | High. The hiring-manager prior is to derisk gaps, and F1 and F6 are gaps you have named yourself | Rehearse A1 until it is boring: concede in your own words first, hold on the quoted ground, add a plan |
| Case/Strategist | Live problems from their actual roadmap: slipping releases, a new team | High. The same prior says expect live problems on the roadmap this person owns | Clarify, then structure, then answer; say the limit once and early (A4); think aloud |
| Data-Driven Prober | Goes two levels deep on the 60% and the roadmap-pressure story | Medium. F3 contains a headline figure, and a Director reading closely will ask for it | Know what you can and cannot say about how the 60% was counted; say plainly when you do not know (A6, A7) |
| Conversational | The opening "walk me through the journey" | Medium-low as a block, but near-certain as the opening ask; it is scored | Pre-script the 90-second arc (A8) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't managed managers and you haven't owned a hardware-adjacent roadmap. Why should I bet on you for two squads in industrial IoT?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year." | The highest-ROI rehearsal in the pack. Pause, then concede first in your own words: "I've never managed managers, and I've never owned a hardware-adjacent roadmap." Then hold only on what your sentences carry: "3 as a team lead of 6" and "I run our hiring loop for backend roles". Then a plan, not a past: who you would sit with first and what you would read in the opening weeks, named by you. Follow-up one: "Name something you would get wrong in month one." Answer with a real limit drawn from the two you conceded; add no new inventory. Follow-up two: "Why not lead one squad first." Make the case for this role in your own words and do not widen the team of 6. Answer slot: if you have had working contact with hardware or firmware teams, say what and your part; if you have not, say so plainly and return to the team of 6. Limit named before it is asked for: do not describe the team of 6 as a wider remit. Hold through both follow-ups by returning to the quoted ground, never by adding to it | F1 and F6 are where the role presses hardest and where you have stated the absence yourself, so this objection arrives in some form. JD because it scores the stated lead and partner requirements; the deepest rehearsal because it also returns in Round 3 as C4 |
| A2 | "The two squads are 11 engineers between them. You've led a team of 6. What changes at that size?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the ground first: the team you led was 6. Then answer as a plan: what you expect to change in how you spend your time across two squads, and what you would stop doing yourself, named by you. Ask the Director whether each squad has a lead today, since it changes the answer. Answer slot: the two-squad line makes a probe on whether any of your lead work reached beyond the team of 6 likely. If any did, say what and your part in it; if none did, say so plainly and stay with the team of 6 | F1 is the scope jump the hiring manager is pricing. JD because the 11 is the role description's number; the quote is only the team of 6 |
| A3 | "Why leave a payments company for industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your material does not say why, so the words are yours. Answer slot: say what draws you to device-management services and what draws you to managing, naming the role-description lines you actually responded to. If the pull is more the step to managing than the domain, say that plainly. Keep it to about 60 seconds and make no claims about the domain you have not worked in | F7 shows the domain is new to your material, so the motivation probe is likely. JD because it tests commitment to the stated role |
| A4 | "Hardware tells us a device release is slipping a month. Product wants the same launch date, and your squads' services depend on that release. What do you need to know first, and what do you do?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Clarify first: what is fixed and what can move, what in each squad depends on the release, what can ship independently. Then objective, options, a decision with an owner, who is told and when, and the risks. Challenge one premise politely. Say the limit once, early, as a plain acknowledgment: "I've never owned a hardware-adjacent roadmap, so I'd start by asking..." and then ask. The scenario asks about no past | A live problem built from the role description's partner-with-hardware line, which is the Case persona's native ground for a hiring manager. CASE with JD content; F6 is why the early concession is rehearsed |
| A5 | "You start with 11 engineers across two squads. What do you do in your first 30 days?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure it as a plan: who you listen to first, how you would see the state of delivery, what you would look at in hiring (you already run a hiring loop for backend roles), how you would meet your hardware and product counterparts, and what you would deliberately not change yet. Name the order yourself and say why | Tests whether you reason at the altitude of the role. CASE because it is a live plan; F2 is the only row that gives you a starting point in it |
| A6 | "Walk me through the reliability quarter. You pushed it through against roadmap pressure. How did that go?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Tell the beats your sentence states, in your own words: a reliability quarter, you pushed it through, against roadmap pressure, and afterwards the team's on-call burden dropped 60%. Keep "after I pushed", not "because". Answer slot: the delivery and product-partnership lines make probes on who applied the pressure and how it resolved likely. If you traded commitments to make room, say which and who agreed; if nothing was traded, or it was not your call, say so plainly and stay with what you pushed | F3 and F5 are the only delivery and roadmap evidence you have, so a careful reader goes here next. EXP because it tests what was actually yours |
| A7 | "On the 60%: how was that counted, and which assumption would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Four slots, each in your own words and none filled in for you. What "on-call burden" measured in that figure; if you do not know how it was counted, say so plainly. What the figure is sensitive to. The assumption behind it you would defend least, named before the interviewer does. Which part was yours: the sentence says you pushed the quarter; say who else contributed, or say nothing else was involved. Hold the "after" wording | The headline number on your side, and the one a prober tests. EXP because it scores attribution and honesty about the figure; F3 holds the sentence |
| A8 | "Walk me through the journey: from nine years in engineering to wanting to manage two squads." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc built on the sentence's beats: nine years in engineering, three as a team lead of 6, currently at a payments company, then why this role. Answer slot: what made you want the step into managing; if it was gradual rather than one moment, say that. End on the role | The opener is near-certain and scored for economy. EXP because it tests whether the career story matches F1 |

### Reverse questions for Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Do the two squads have their own leads today, or would I be the direct manager of all 11 engineers?" | It resolves what the role description leaves open and shows you are thinking about the jump in scope |
| R1.2 | "What would success look like at 90 days and at 12 months in this role?" | Gives you the scoring sheet this person will actually use |
| R1.3 | "Where do hardware and product roadmap conflicts get resolved today, and who is in that room?" | Shows you understand the seam without claiming to know it |
| R1.4 | "How does reliability and on-call work get weighed against roadmap commitments here, and who decides?" | Opens the topic you have the most to say about, as a question rather than a claim |
| R1.5 | "What is the biggest delivery risk across the two squads right now?" | Moves the conversation to the real problem you would own |
| R1.6 | "What would you want to see from me in the first month to feel this was the right hire?" | Invites the Director to state the bar; the answer is your next rehearsal |

## Round 2: Thursday, panel of two staff engineers and a product manager, 60 min

### Persona weights

The panel's names are not known, so the personas are assigned by role. Staff engineers get Peer Evaluator and Prober; the product manager gets Values/Behavioral, from the cross-functional prior, plus the Peer seam.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between a staff engineer and the EM, "what would you need from us", disagreement style | High. Two of three panelists are staff engineers who would work next to you, and the panel prior blends each member's top personas | Reciprocity: say what you bring them, not only what you need; propose seam principles rather than pretending to know the seam (B1, B2, B3) |
| Data-Driven Prober | Goes into the hiring loop and the "about 40" figure | Medium. Staff engineers are plausible interviewers in a loop, and F2 holds a figure | Know what the number counted; say plainly when you do not know (B4, B5) |
| Values/Behavioral | Scenario probes on product disagreement and growing engineers | Medium. The product manager is outside engineering, and the role description names product partnership and growth | Choose a story only where your sentence carries it; otherwise use the scaffold and its honest branch (B6, B8) |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between a staff engineer and the engineering manager on technical direction, and what happens when we disagree?" | JD | [generic] | Propose principles, not facts about Larkfield: who decides what and why, how a disagreement escalates and what is written down, and what you ask of staff engineers in return. Then ask the panel where the seam sits today. The question needs no claim about your past, so the guidance makes none | The Peer persona's native question. JD because it scores the partnership the role needs; `[generic]` because it is a pattern, not a fact about this team |
| B2 | "Tell me about a time you disagreed with a more senior engineer about technical direction." | VAL | [generic] | Selection scaffold: pick a case with a named disagreement, your actual position, what the other person's position was, and how it ended, including a point where you were wrong if there was one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Staff engineers test disagreement style with an equal. VAL because it scores behavior with peers; the theme comes from the Peer persona's stem |
| B3 | "Our device-management services depend on hardware release cycles. You've never owned a hardware-adjacent roadmap, so how would you plan around that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Concede first, in your own words: "I've never owned a hardware-adjacent roadmap." Then the plan: which dependencies you would map first, and ask the staff engineers in the room which one hurts most today. Hold through two follow-ups by returning to the plan and the ask, never by claiming exposure. Answer slot: if you have had any working contact with hardware or firmware teams, say what; if you have not, say so plainly | F6 is the stated absence, and staff engineers are the people who feel the dependency daily. JD because it scores the hardware-partnership line |
| B4 | "You run the hiring loop for backend roles and you said about 40 interviews last year. How was that counted, and what was your part?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the sentence at its scope: you run the loop for backend roles, and the figure is "about 40 interviews". Four slots, each in your own words: what an interview was in that count; what the number is sensitive to; the assumption you would defend least; which parts were yours. If you do not know the exact count, say so plainly. Do not turn interviews into hires or the loop into headcount decisions unless you can say it as it happened | F2 holds the figure; staff engineers are plausible members of a hiring loop and will test it. EXP because it scores attribution |
| B5 | "How would you adapt the hiring loop you run to a device-management squad?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the loop you run, in the sentence's terms, then answer as a design: what you would keep, what you would ask these staff engineers to decide because you do not know it, and why. Answer slot: if you have hired for any role outside backend, say which and what you changed; if not, say so plainly and describe the backend loop you run | The role description names hiring; this turns your loop into a question for the people who would sit in it. JD with a CASE delivery |
| B6 | "Tell me about a time you and a product partner wanted different things from the same quarter." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Choose an instance. Your sentence may fit, but it does not say who applied the roadmap pressure. Answer slot: if the pressure came from product and you worked through it with them, say how, what you said, and how it ended; if it came from elsewhere, or it is not a story of that kind, say so plainly and pick another or say none comes to mind and describe how you would handle it | The role description names partnership with product, and the product manager is the panelist who scores it. F5 is why the slot is needed |
| B7 | "Product wants three things this quarter, and the two squads can credibly deliver two. Walk us through what you do." | CASE | [generic] | Clarify first: the value and dependencies of each, and who decides. Then options such as descoping or sequencing, a decision, what you say to product and to the engineers, and the risk you are accepting. Say aloud where you would want the staff engineers' estimate. The scenario asks about no past | A live problem from the roadmap-partnership line, set for the product manager. CASE because it scores structure |
| B8 | "Tell me about a time you helped an engineer grow into something bigger." | VAL | [generic] | Selection scaffold: pick an engineer whose change you can describe, with the starting point, what you specifically did, what changed, and where you were wrong. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach growth for 11 engineers | The role description names growth for 11 engineers, and F4 shows nothing yet in your material. VAL because it scores behavior toward people |

### Reverse questions for Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | To the staff engineers: "What is one thing a new engineering manager could do in their first month that would genuinely help your squad?" | The reciprocity question; it turns the panel from evaluators into advisors |
| R2.2 | "Where do hardware dependencies hurt the squads most today?" | Shows you are mapping the dependency, and your own B3 plan depends on the answer |
| R2.3 | To the product manager: "How does the roadmap get set between product, hardware and engineering, and where do disagreements surface?" | Names the seam and invites the product manager's view of it |
| R2.4 | "What do staff engineers here expect from a manager that they would not expect from a tech lead?" | Shows you are asking about the boundary rather than assuming it |
| R2.5 | "What would make you say, a year from now, that the manager was good for this squad?" | Gets each panelist's bar into the open |
| R2.6 | "What has changed in how the squads are organised in the last year?" | Surfaces context that shapes the Round 3 conversation |

## Round 3: Monday, VP Engineering, 30 min, "values and leadership philosophy"

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on philosophy, unpopular truths, how you treat people | High. The recruiter's description is the loop source; it is the only thing said about this round | Map a story only where your sentence carries one, and use the scaffold and its honest branch where none does (C1, C2, C3) |
| Pressure | Time-boxed answers, "how much was actually you", the A1 objection in 60 seconds | Medium. The skip-level and executive prior pairs strategy with composure, and 30 minutes forces compression | Pause, restate, hold the quoted ground through two follow-ups, concede specifically (C4, C5, C8) |
| Case/Strategist | One live problem, one company question | Medium-low. The executive prior includes it, but the recruiter's description points elsewhere | Structure aloud; for company knowledge, say plainly what you know (C6, C7) |

### Question bank

If time is short, rehearse C1, C2, C4 and C5 first.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." "I run our hiring loop for backend roles — about 40 interviews last year." | Name two principles yourself, ones you actually act on. For each, one specific instance from your own experience and where it costs something. The two sentences your material carries are the reliability quarter and the hiring loop; a principle with neither behind it is a statement, not an answer, and you can drop it. Answer slot: if a principle has an instance, say what you did; if it has none, say so plainly and leave it out | The recruiter's description makes this the likeliest opener. VAL because it scores whether stated principles are backed by behavior |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Your sentence says you pushed the quarter through against roadmap pressure; it does not say whom you told what or how it landed. Answer slot: if this is the story, say who, what you said, and what happened, in your own words; if leadership was not involved, or it did not land, say so plainly and either pick another instance or say none comes to mind and describe what you would do. Choose a story in which the hard truth actually landed, and say where it did not | A stem for the Values persona. F3 holds the only candidate sentence, so the slot is needed |
| C3 | "How do you approach hiring and growing engineers, and what do you do when someone isn't working out?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Hiring: start from the loop you run, in the sentence's terms. Growth: your answer to B8. Someone not working out: your material shows no instance of this. Answer slot: if you have had someone not working out, say what you did; if not, say so plainly and describe how you would approach it | The role description names hiring and growth, and the VP scores how you treat people. F2 and F4 supply the starting points |
| C4 | "Sixty seconds: why you, for a role that spans two squads, when you haven't managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A1 compressed. One line of concession in your own words: "I've never managed managers." One line on the ground you hold: "3 as a team lead of 6". One line on why this role. Then stop and let the silence sit | The Pressure persona's stem for the same objection, which is why A1 is the first thing to rehearse |
| C5 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause and restate. Hold on the sentence: you pushed the quarter through. Concede specifically: the drop came after the push, and whether the quarter alone accounts for it is not in your sentence. Answer slot: say who else contributed and how much of the drop you can attribute to the quarter; if you do not know, say so plainly. Never fold on the core claim to restore harmony | The Pressure persona's other stem. EXP because it scores precise attribution |
| C6 | "A device-management service has an outage while devices are in the field. What do you do in the first hour, and what do you change afterward?" | CASE | [generic] | Structure aloud: stabilize first, who is told and when, what you need to know before touching anything, then cause, then what changes. The scenario asks about no past | The VP's altitude question for a role that builds these services. `[generic]` because it is a pattern, not a fact about Larkfield |
| C7 | "What do you know about Larkfield, and where do you think device management goes here?" | CO | [generic] | This pack could not research Larkfield, so it supplies no company facts and you should not borrow any. Before Monday, read the company's own pages and note what you actually learned. Then say plainly what you know and what you would want to find out. Do not bluff a strategy | The recruiter's description does not rule it out, and a values conversation often moves here. CO because it scores homework; `[generic]` because no research was available |
| C8 | "Suppose an internal lead could step into this role. Why you over them?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" "I run our hiring loop for backend roles — about 40 interviews last year." "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold and concede. Do not disparage a person you have not met. Say what you bring in your sentences' terms: "3 as a team lead of 6" and "I run our hiring loop for backend roles". Concede what you have not done: "I've never managed managers, and I've never owned a hardware-adjacent roadmap." Then say what you would do about both | The Pressure persona's third stem; it tests composure on the same two gaps from another side |

### Reverse questions for Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does your leadership philosophy look like in practice here: a recent decision that tested it?" | Turns the values conversation into a two-way exchange |
| R3.2 | "What would you want the first six months of this role to show you?" | Gets the VP's bar into the open |
| R3.3 | "Where do you see device-management services in two years, and what would that ask of engineering leadership?" | Fits the altitude of a VP and shows you think about the company's direction |
| R3.4 | "How are the people leading the two squads expected to develop?" | Probes the layer below you, which your material has not covered |
| R3.5 | "Where is the tension between hardware and software timelines sharpest right now, from your seat?" | A strategy-level version of your Round 1 and 2 questions |

## Requirement coverage

| Requirement (role description) | Covered by |
|---|---|
| "Lead two squads" | A1, A2, A5, C4, C8 |
| "building device-management services" | A3, A4, B1, B3, C6 |
| "own delivery" | A4, A6, A7, B7, C5 |
| "hiring" | A5, B4, B5, C1, C3 |
| "growth for 11 engineers" | B8, C3 |
| "partner with hardware" | A1, A4, B3, C6 |
| "partner with product on roadmap" | A6, B6, B7 |
| "11 engineers" | A2, A5 |
| "industrial IoT" | A1, C7 — thin, and none beyond that: no company or domain research was available |

## Prohibited claims

What this pack will not coach. Each has a basis, and the honest form is what you may say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or ran a multi-team organization | A negative you stated, F1 | Your plain acknowledgment: "I've never managed managers." No answer slot asks you to claim otherwise |
| Owned a hardware-adjacent roadmap, or has partnered with hardware teams | A negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." Then a plan, never a past |
| Led two squads, or managed 11 engineers | Inflated form of F1 | "3 as a team lead of 6" at its own scope. Your material says a team of 6, not two squads |
| The reliability quarter caused the 60% drop, or that you owned delivery | Inflated form of F3 | "The on-call burden dropped 60% after I pushed a reliability quarter through." The limit is this pack's observation: your sentence says after, not because |
| Hired about 40 people, or made hiring or headcount decisions | Inflated form of F2 | "I run our hiring loop for backend roles", with "about 40 interviews" as given. Your sentence says interviews, not hires |

## Sources

Provided: your message — the role description, the three rounds and who runs each, and your account of yourself. The description of Monday's round as "values and leadership philosophy" is the recruiter's, as you relayed it. No dossier was present.

Searches sent, none returned anything:

- `Larkfield Systems industrial IoT values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems industrial IoT device management strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have supplied the published value names for a values cheat sheet for Round 3, which is therefore absent |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The search was refused. Persona weights rest on your account of the loop and on relationship priors, not on a company-published process |
| 3. `Larkfield Systems strategy` and recent news | unavailable | The search was refused. It would have grounded C7 and any CO question; C7 is `[generic]` for that reason |
| 4. `interviewer name Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the fit snapshot rows and the JD-tagged questions. A fuller JD is an upgrade-menu line |

## Upgrade menu

- Full job description text → the three quoted lines become the full requirement list; mid-list items turn into JD-tagged questions and more rows move from `[inferred]` to `[grounded]`
- Your CV → the evidence column can quote more than your message; F4, F5 and F7 could move off `none given` or `low`
- Your answers to the answer slots (A2, A6, A7, B4, B8, C3) → each answer becomes quoted evidence, and the rows that draw on it regenerate
- The recruiter's guidance on Tuesday and Thursday (format, any case or presentation, focus areas) → a corrected loop and, if a deliverable was declared, a build section for it. One email to the recruiter usually does it
- Whether each squad has its own lead → closes the open question in F1 and reweights A1, A2 and C4
- The three interviewers' names, or their public profiles → an interviewer read per round, per-member personas for the panel, and reverse questions tied to their own paths
- Larkfield's published values page, pasted → a values cheat sheet for Round 3, with a story or a selection scaffold per value
- Search permission for this session, or a pasted strategy brief → grounded CO questions in place of C7, and a deeper pass is available (up to 6 more searches and 2 more fetches, several more minutes)
- A `tuesday-dossier.md` from a prior underwriting session → evidence-graded objections and a dossier-sourced prohibited list in place of the one built here
