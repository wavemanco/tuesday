I'll read the reference files the skill names before building the assessment.
**Not yet. Your fit is strong, but R1 (where you'd work) is unsettled: the JD says fully remote and Brindlemoor's own careers page says Leeds office four days a week. Status: `hold_pending_answers`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important` — adjacent: R10 (Pet insurance domain knowledge) · unclear: R8 (Recommendations for product)
- `preferred` — direct: R9

R1 is the row that can change the decision. R4 (`medium`) and R6 (`medium`) are the closest matches to the JD's own words.

**Opportunity ledger.** The role is sound on mandate and reporting line (RR5), but the work-pattern terms contradict each other (RR1). Pay is withheld (RR2), the employer is thinly attributable (RR3), and authority and team size are unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the answer to G1, whether the Leeds-four-days pattern works for you, and a written confirmation from Brindlemoor of which pattern is real (RR1). If you can work from Leeds, or the role is remote, the status moves to `conditional_go`, with R5b and RR3 as the remaining conditions. If you can't work from Leeds and the role isn't remote, it moves to `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Stage and size are not established | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga. The JD and the careers page agree | `[grounded]` JD; careers page |
| Work pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both quoted; the conflict is unresolved (R1, RR1) |
| People management | The JD asks for none, so your lack of it is not a requirement gap | `[grounded]` JD requirements list |
| Scope read | A single-product, hands-on analytics post with presentation duties. The title and the 4+ years fit together | `[inferred]` from the JD's responsibilities against its requirements |
| Market calibration | The Pricewell 2026 UK survey of senior pricing analysts at insurers and insurtechs (n=612) shows median base £58,400 and an interquartile range of £52,100 to £64,900. The posting withholds pay, so this is the expected band and not Brindlemoor's offer (RR2) | `[generic]` role-family sweep, one salary search; `[grounded]` JD, for the withheld pay |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. She was previously head of pricing analytics at Calloway Re for six years | `[grounded]` public professional profile, search result only |
| Unknowns | Pay, team size, authority over price changes, first-year outcomes | `[grounded]` JD silence |
| Contradictions | Work pattern, as above | `[grounded]` JD against careers page |

## Evidence map

Your background was typed into the chat. It counts as CV-equivalent self-report, so `medium` is the ceiling until you confirm specifics or share an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a location or remote requirement, so confidence in your constraint is `none`. Fit is `unclear` because the JD and the careers page give different terms | `[grounded]` JD and careers page quoted; no candidate statement | G1 question; written confirmation from Brindlemoor |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You have 5 years of pricing analytics at a UK motor insurer, 2 of them as senior analyst. This is self-reported, with no document yet | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Depth isn't described, and there's no artifact yet | `[grounded]` your stated background | offer: a sanitized query or notebook excerpt would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. It's specific, but nothing inspectable has been shared | `[grounded]` your stated background | offer: a sanitized model-spec or documentation page would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | The same claim as R4, covering the build side | `[grounded]` your stated background | none |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring, but you haven't said so. Ambiguity resolves downward, so this is `low`. Pricing leaders often probe this closely, and this hiring manager has spoken publicly on it | `[grounded]` your wording; `[generic]` that monitoring is commonly probed; `[grounded]` the talk title | G2 question |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. "Ran" is your word, and the designing and reading split isn't stated | `[grounded]` your stated background | confirm your ownership of design versus reading when you answer G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Actuarial audiences aren't mentioned | `[grounded]` your stated background | none |
| R8 | Recommendations for product, not only underwriting | important | unclear | none | discovery | Nothing you've said touches a product or proposition owner. The JD names product as an audience | `[grounded]` JD quote; your background is silent | G3 question |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your stated background | none |
| R10 | Pet insurance domain knowledge (implied: you'd own the pet product's pricing) | important | adjacent | medium | transferability | Frequency-and-severity GLM work on a personal-lines book carries over. The limit is that none of it touched pet rating factors or vet-cost trends. The JD doesn't make pet experience a requirement | `[inferred]` from the JD's product named against your motor experience; `[generic]` that rating factors differ by line | G4 bridge case |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Work pattern (R1, hard_gate) | hard_gate | The JD and careers page contradict each other. Your own location and remote needs are unstated | Everything else is moot if this fails. It is the only row that can force `no_go` | n/a — this is a term you meet or don't | The recruiter's written confirmation, or a screenshot of the live posting | `[grounded]` the contradiction; `[inferred]` that it decides the status |
| G2 | Monitoring rating models (R5b, must_have) | discovery | You maintained the model, but "monitoring" isn't established | A must-have, and it is the topic of the hiring manager's published talk | Tracking actual-versus-expected by segment after a rate change; drift or segment-stability checks on the model; alerts or a dashboard the team used; a post-implementation review | A sanitized monitoring dashboard screenshot, an A/E report template, or a review note | `[grounded]` the gap; `[inferred]` that the talk topic makes this probable ground |
| G3 | Recommendations for product (R8, important) | discovery | Only underwriting is evidenced | The JD lists product as a recipient of results | A price-test result taken to a proposition or product owner; a pricing paper that changed a product feature or tier; a pricing-review item routed to a product team | A pricing-review deck excerpt or a recommendation note | `[grounded]` the gap; `[generic]` that such roles interact with product |
| G4 | Pet domain (R10, important) | transferability | Motor GLM and price-test experience | Probably the most likely objection | Adjacent: young-driver risk segmentation is a niche-segment problem. Limit: no pet factors such as breed or vet-cost inflation. Strengthener: a short note on how you'd structure a pet frequency/severity model, shown as a work sample if you choose | A one-page approach note | `[inferred]` bridge from your motor work; `[generic]` that pet-specific factors exist |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work pattern contradicts across sources (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The posting copy may be out of date, or the careers page may be authoritative. Severity is held at `medium` because your constraint is unknown, and it rises if remote matters to you | `[inferred]` from the two quoted statements | Is this role fully remote, or based in Leeds four days a week, and which is the contract term? | unresolved |
| RR2 | Pay withheld | unknown | — | JD states no compensation | The figure may sit anywhere against the Pricewell band in role reality | `[inferred]` from the JD's silence, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | A search on the company name returned nothing. Only its own careers page was found, so stage and size are unverified. It may simply be small, and `high` is withheld on that basis | `[generic]` pattern for companies of this size, not a claim about this one | Can you share the company's registered details, and who would I interview with? | unresolved |
| RR4 | Authority and success measures not stated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend without deciding, and the JD gives no first-year outcomes | `[inferred]` from the JD's verb "recommend" against its silence on decision rights | Who decides price changes, how big is the pricing team, and what does success look like at 12 months? | unresolved |
| RR5 | Named senior owner and a defined remit | positive_signal | — | "reports to the Director of Pricing" | A named Director-level manager with a public record on rating-model monitoring suggests the work is recognised internally | `[grounded]` careers page and public profile | Which of your team's decisions does this role feed into most often? | noted |

## Application plan

All of these are proposals only and nothing here is final until you approve it.

**Resume edits** — `resume_edits_pending_approval`. Every clause traces to your own sentences.

| # | Proposed line | Source | Status |
|---|---|---|---|
| E1 | "Built and maintained the GLM rating model for the young-driver book at a UK motor insurer; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting." | Your own background sentences | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle the work-pattern contradiction with the recruiter before spending application effort | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | If you apply, lead with the GLM model and the 14 price tests, and say plainly that your background is motor rather than pet. Don't describe the work as "leading" anything beyond what you've told me | see R4, R6, R10 | `[grounded]` the rows | pending your approval |
| A3 | After G2, consider a one-page monitoring example as a work sample, since the hiring manager's published topic is monitoring | see R5b | `[inferred]` from her talk title | pending your approval |
| Q1 | Ask the verification questions in RR1 through RR4 verbatim in the first conversation | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved role reality's work-pattern and contradictions rows, R1 and RR1, and the employer entry RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved the hiring manager row, R5b and A3 |

## Dossier offer

If you'd like a `tuesday-dossier.md` of this assessment to carry forward, say so and I'll emit it.

## Upgrade menu

- Your location, remote needs and pay floor → R1 becomes a firm met or failed row, with your own hard constraints added as gate rows.
- A sanitized model-spec page or a SQL/Python excerpt → R3, R4 and R5a move toward `high`.
- A monitoring artifact (an A/E report or dashboard screenshot) → R5b resolves.
- A product-facing recommendation note → R8 resolves.
- Written confirmation of the work pattern and the budgeted pay → RR1 and RR2 close.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) → would strengthen RR3. Say the word and it runs.

## Questions

G1 — Can you work from a Leeds office four days a week, and does a fully remote arrangement matter to you? If you have a pay floor or other limits, include them.
G2 — After the young-driver GLM went live, what did you personally do to monitor it, who saw the results, and did a monitoring finding ever lead to a model or rate change?
G3 — Have you taken a price-test result or pricing recommendation to a product or proposition owner, rather than to underwriting? What was it and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.