This PR carries:
- items 4 and 5: the routing diagnostic and the user-link fixture;
- step 2 of the Tuesday plan: bringing the three skills into line with Anthropic's skill guidance;
- the research-row fix (closed) and the watch-out rounds (closed);
- the owner-decides version of the two-iteration rule;
- Tuesday, the skill that routes each request to one module: three measured rounds, the owner's decision to ship it with one open case, and the shipped skill, builds, plugin and install docs;
- the quality check through Tuesday on three models, the harness preparation for the one-round fix the owner chose, its approved plan and bar, and its Step 1 (the harness and the one text change).

Do not merge until reviewed.

**Branch note:** this session can only push to `claude/skill-job-underwriter-95xjz8`, which was restarted from `main` after PR #10 merged.

## Item 4: the routing attachment diagnostic

The harness:
- `evals/run_routing.py --cases FILE` runs an alternative case set.
- `evals/routing_variants.py` generates the two variant sets, and CI holds the committed variants equal to its output.

Two harness bugs were found and fixed on the way:
- **Every case shared one project folder.** Five cases attach a `jd.txt`, so most cases saw another case's posting, including in the old "22% before, 22% after" measurement. Each case now runs in its own folder.
- **Spanning cases were judged against a hard-coded pair.** Case 21's correct resume-tailor fires were scored as misses. Each spanning case now lists the skills it spans as `siblings`, both scorers read them, and CI requires them.

**Result** (39a0bd8, 5 runs per case, Haiku / Sonnet / Opus 5.5, decision rule fixed before the run):

| Reached a skill | Haiku | Sonnet | Opus |
|---|---|---|---|
| A: attached files, as written | 87% | 100% | 100% |
| B: A with the documents also pasted in | 93% | 100% | 100% |
| C: self-contained, details moved into a file | 13% | 98% | 100% |
| D: self-contained, as written | 29% | 60% | 62% |
| Wrong skill fired | 0 | 0 | 0 |

- **The hypothesis is falsified on all three models.** Attached-file prompts are not the weak spot.
- **Short prose requests are, especially on Haiku.**
- **Caveat found later:** every measured session had inherited the parent session's synced skills, including a second `mock-interview`. Child sessions now start clean (`evals/child_env.py`), and the Tuesday rounds re-measured every case clean.

## Item 5: a fixture for a link the user gives

job-underwriter eval 6 gives the posting as a link, served through `research.user_pages` with a canary only that page carries. The read was counted as `user links read 1` in 9 of 9 runs, and the posting's content reached the response in 9 of 9.

## Compliance with Anthropic's skill guidance (Tuesday plan, step 2)

- Tables of contents on every reference file over 100 lines; descriptions in the third person.
- SKILL.md bodies under 5k estimated tokens (job-underwriter 6,394 → 4,917; mock-interview 5,173 → 4,577; resume-tailor 3,592 → 3,084), rationale moved to `references/rationale.md`.
- job-underwriter's 557-line dossier template split into focused files, each linked directly from SKILL.md.
- A "Before sending" checklist in each SKILL.md. CI holds all of it, each check with must-fail and must-pass tests.

## Measured on three models

Graded pass rate, new text vs the text before all three changes (39a0bd8), graders pinned to Sonnet:

| Skill | Haiku | Sonnet | Opus |
|---|---|---|---|
| job-underwriter | 60.4% vs 49.5% | 91.1% vs 91.7% | 88.5% vs 87.0% |
| mock-interview | 82.6% vs 74.3% | 93.6% vs 89.9% | 95.0% vs 87.6% |
| resume-tailor | 83.1% vs 78.0% | 85.6% vs 80.5% | 87.3% vs 82.2% |

- **Research rows name their pages — closed at iteration 1:** 12/12 Sonnet, 11/11 Opus, Haiku 12/15 pooled with the re-run the owner asked for (bar 80%).
- **Watch-out — closed at round 3.** The owner chose another round after the second iteration; `watch_out` now holds the whole line, label included. The exact line ended 66/66 Haiku, 33/33 Sonnet and 33/33 Opus runs.
- **New open issue (iteration 0):** Haiku writes more than one sentence after the fit ledger (12 of 24 runs). The new text restores the ledger that exposes this existing rule; not a regression.

## The two-iteration rule now has the owner decide

After two iterations, work stops and the issue goes to the owner with its rate, what was tried, and what each option costs: a watch-out, another round with its own bar, or leave it open. The decision is recorded in the ledger. Decisions so far: four — three "another round", one "left open" (Opus case 10, with Tuesday shipped), none a watch-out.

## Tuesday, round 1 (dd72b88)

A prototype of Tuesday at `evals/arms/frontdoor/` routes to the three modules, which are installed hidden (`disable-model-invocation: true`) so only Tuesday competes for routing, and a module's own slash command still works. Measured against today's three skills on all 21 routing cases plus 20 explicit-command runs, on all three models, bar fixed before the run.
- Routing gained on Haiku (53% → 93% right module) and held on Sonnet and Opus; no wrong-module picks, no off-topic fires.
- **Failed:** a message started with `/mock-interview` or `/job-underwriter` also fired Tuesday (1, 9 and 2 of 20 runs), and Haiku reached a hidden module twice. Owner's decision: another round.

## Tuesday, round 2 (d88efe8)

**Change:** a skill started by its own slash command keeps the turn (`interaction-grammar.md` §6, pointed to from each SKILL.md), and the harness reads every Tuesday run to the end of its turn.

| Bar (fixed before the run) | Haiku | Sonnet | Opus |
|---|---|---|---|
| Explicit command stays on its module, 20/20 | 20/20 | 20/20 | 20/20 |
| Tuesday fires after a command (reported) | 0 | 0 | 0 |
| Off-topic fires, 0/30 | 0 | 0 | 0 |
| Wrong-module picks, ≤2/60 | 0 | 0 | 0 |
| Hidden module reached, 0 | **3 — fail** | 0 | 0 |
| Right module, single-module cases (today's skills → Tuesday) | 62% → 83% | 98% → 100% | 100% → 98% |
| No module starved | met | **missed** (measurement) | **missed** (measurement) |
| Spanning ≥ today's skills | **9 vs 10 — missed** | 15 vs 11 | 10 vs 10 |

- **The explicit-command fix worked on every model.**
- **Haiku's misses are one behaviour.** All three hidden reaches came after `find .` listed the working folder, where the harness installs the skills, as a project install in `.claude/skills/` would. Two only listed a hidden folder and then did the right job through Tuesday. One read resume-tailor's SKILL.md directly and returned a rewritten resume instead of the approve-first edit ledger. The spanning miss is that same case-21 run. Text in Tuesday ("never read from them, even when a listing shows them") did not stop it.
- **Sonnet's and Opus's starvation misses are measurement faults:**
  - I started the Tuesday arm without its documented `--timeout 900`. Six case-5 runs that had already routed right were cut off at 240 s and set aside.
  - One Opus run read the right playbook by `cd` + `cat`, a form the reader's documented rule did not count. The rule was changed after the results (fad32e9). Under it Opus meets every item of the bar; Sonnet and Haiku do not change.
- **Process notes:**
  - A container restart killed Sonnet's and Opus's explicit arms before they wrote results. They were re-run on the same commit after Haiku's score was known; the killed runs' transcripts, replayed, were all focused.
  - Child sessions shared the parent's session ID (fixed).

**Harness fixes since the measurement** (they re-score nothing above except as stated):
- dddfdd0: a run read to the end of its turn gets 900 s by default; child sessions drop `CLAUDE_CODE_REMOTE_SESSION_ID`.
- fad32e9: a playbook read by `cd` into Tuesday's folder and a relative path, in one call, is a route.

**Owner's decision:** another round, shipping Tuesday only where its files sit outside the user's working folder (the plugin and a personal install); project installs and cloud sessions keep today's three skills.

## Tuesday, round 3 (b2f424b)

**Change (harness only):** `run_routing.py --layout {project,personal,plugin}`. The personal layout gives each run its own config folder outside the case folder; the plugin layout loads a per-case plugin with `--plugin-dir`. Outside the project layout a run may read its own skills folder: headless runs otherwise refused every read of a skill's files. Each run also records, reported only: path contact with Tuesday's files, naming the skills folder, refused tool calls, time and tokens.

| Bar (fixed before the build) | Haiku | Sonnet | Opus |
|---|---|---|---|
| Explicit command stays on its module, 20/20 (both layouts) | 20/20, 20/20 | 20/20, 20/20 | 20/20, 20/20 |
| Hidden module reached, 0 | 0 | 0 | 0 |
| Off-topic fires 0/30; wrong picks ≤2/60; set aside ≤10% | met | met | met |
| Right module, single-module (today's skills → plugin / personal) | 47% → 75% / 73% | 100% → 100% | 100% → 100% |
| No module starved | met | met | met |
| Spanning ≥ today's skills | 9 → 10 / 10 of 15 | 10 → 15 / 14 of 15 | **12 → 10 / 10 of 15 — missed** |

- **The layout removed round 2's failure:** no run reached a hidden module, Tuesday's files by path, or the skills folder, on any model.
- **The one miss is case 10 on Opus:** a short "prep or cancel?" question with no posting given. Opus answered it directly in all 20 Tuesday runs across three rounds, and in 13 of 15 runs with today's skills; this round's 2 fires with today's skills are the only ones in three rounds (Fisher p ≈ 0.1), both layouts are compared with those same 5 runs, and the spanning rule had no margin.
- **Not gated:** Haiku case 3 went 3/5 → 0/5 in both layouts.
- **How it ran:** the account's weekly usage limit killed 470 runs on Oct 31; with the owner's agreement they were re-run on Nov 5 on the same commit and merged with the runs that had finished (CLI 2.1.318 for the re-runs, 2.1.316 before; disclosed in the README ledger). Every number was re-derived independently and the merge audited.

**Owner's decision:** ship Tuesday, and leave Opus case 10 open (recorded in the README's Tuesday backlog).

## Shipping Tuesday (27b4339)

- `skills/tuesday/`: the skill round 3 measured, byte for byte, with its 27 generated references. CI's `MEASURED_FRONTDOOR` holds the measured hashes, including every file the Claude Code builds ship, so a change to shipped text fails until it is measured or the constant is updated on purpose.
- `ci/sync.py`: one tool for every generated copy (convention mirrors and Tuesday's references), checked in CI.
- Builds: `dist/tuesday.skill` (claude.ai), `dist/claude-code/` (personal install), `dist/plugin/tuesday/` with `.claude-plugin/marketplace.json` (`tuesday@wavemanco-tuesday`, version 0.1.0).
- README Install rewritten per surface: the plugin or a personal install for Tuesday; the three modules for projects and cloud sessions; claude.ai untested. "Front door" was a working name and is gone from every README; three places Claude reads it remain until the next measured change (backlog).
- `run_fixtures.py --via frontdoor`: the quality check through Tuesday, run below.
- Built, then reviewed four ways (measured equality, CI and packaging, install routes with live runs, docs): 30 findings, all fixed.

## Quality through Tuesday (27b4339 and 2d7dbfc)

Each module run through Tuesday against the module alone: every fixture and mode (23), 5 runs each, both ways, graders pinned to Sonnet. The bar was fixed before each step: graded pass rate no more than 5 points below alone, and no automatic check failing in 3 or more extra runs.

| Graded pass rate, alone → Tuesday | Sonnet | Haiku | Opus |
|---|---|---|---|
| job-underwriter | 91.1 → 92.4% | 63.7 → 74.2% | 91.4 → 92.0% |
| mock-interview | 92.4 → 89.4% | 77.6 → 78.1% | 90.4 → 88.6% |
| resume-tailor | 88.8 → 88.0% | 83.7 → 84.6% | 90.2 → 87.1% |

- **Graded quality is within the bar on every model.** Nothing was set aside.
- **The check count missed on every step** (failing runs, Tuesday vs alone):
  - Sonnet: mock-interview quotes, 17 vs 8 runs once the check was fixed.
  - Haiku: six job-underwriter checks, mostly because Tuesday's runs wrote the fit ledger more often; the watch-out line, 6 vs 1.
  - Opus: four job-underwriter checks at exactly +3; mock-interview's quotes, 15 vs 8; one honestly labelled news search on fixture 8, 6 vs 2.
- **Owner's decisions:** accept and record each step, same rule on all three for consistency, then make every fix in one round.
- **A verified summary of every miss, gap and failure** across the three models and the routing rounds went to the owner. The README records what the bar did not read, including a ledger claim that turned out wrong (job-underwriter's research skip).

## Harness preparation for the fix round (be7afe1)

No skill text changed and no saved grade was regraded (the owner chose not to regrade). `MEASURED_FRONTDOOR` still passes.

- **Grader prompt:** the response sits between two named lines (version 3). Version 2 let graders read the harness record as the response's closing text.
- **Same install in both arms:** `--layout plugin` installs a module alone exactly as Tuesday is installed. The quality check's arms also differed in install, read rule and room name.
- **Recorded per run:** refused tool calls by tool, and whether a save was refused.
- **Fixture dates relative to the run:** mock-interview eval 8's interviews are always about nine days ahead, its brief about four months old. At their anchor the fixtures give exactly the saved runs' text.
- **Fixture 5:** its candidate text holds the candidate's own sentences.
- **Re-cut quotes** are labelled `joined` or `unquoted`, verdict unchanged.
- **New `traces` check** on resume-tailor's Traces to cells, no stricter than `edit-ledger.md`.
- **`evals/compare_arms.py`:**
  - rates over the runs where each check applied;
  - check families counted once;
  - exact Fisher p-values on runs;
  - like-for-like grading flagged;
  - nudges, refusals and cost.
- **Reviewed three ways** (harness, checks, scorer): 17 findings, 14 fixed with tests. The rest are proposals for the round's spec or already documented.
- **Re-scored on the saved runs:**
  - mock-interview's quote failures are mostly re-cut quotes. Runs with any other quote failure, Tuesday vs alone: 6 vs 3 of 50 on Sonnet, 22 vs 21 on Haiku, 1 vs 1 on Opus.
  - The traces check fails 2 of 150 runs.

## The fixed harness, smoked on Sonnet and Opus (c16136e)

52 runs on be7afe1 (CLI 2.1.319), graders pinned to Sonnet under the fenced prompt, readings fixed before the run (nothing gated). mock-interview eval 8 in three arms, 6 runs each: old project install, module alone in a plugin, Tuesday. resume-tailor eval 3 and job-underwriter eval 5 in the last two. Each reading was re-derived by one agent and challenged by another.

- **The harness works:** every run fired unprompted and recorded its install, date and refusals. All 104 grade files are prompt version 3.
- **The fence works:** 0 of 95 failing verdicts read the harness record as the response's text.
- **The quality check's refused saves were the install, not Tuesday.** Saves refused on eval 8 (Sonnet, Opus):

  | Arm | Sonnet | Opus |
  |---|---|---|
  | old project install | 1/6 | 1/6 |
  | module alone in a plugin | 6/6 | 5/6 |
  | Tuesday | 6/6 | 6/6 |

  No arm may write inside its room. With the old install the model saved to its scratchpad; in a plugin it aimed the first save at the empty room. 4 of 24 plugin-installed runs then delivered the pack only in chat.
- **Dates relative to the run work:** 0 of 36 runs read the interviews as past (the quality check: 39 of 40).
- **Cost:** $70, 3 points of the weekly usage.

## The fix round's plan and bar (6d02293, approved in 9c86e24)

`docs/fix-round-plan.md` (short) and `docs/fix-round-plan-detail.md` (full, the bar the round is held to). The owner approved both on 10 November, before any measured run, so the bar is fixed.

- **The round:** Thursday 12 to Monday 16 November, 1,220 graded quality runs (alone against Tuesday, same install) and 870 routing runs, about 52 points of the weekly meter.
- **The bar:** per module and model, Tuesday no more than 5 points below alone on graded rate, no check or truthfulness rise of 10 points (p below 0.01 / 0.05), at most 10% set aside; routing as round 3, with two items recalibrated and a bound on hidden-module reaches. With nothing wrong, it flags something about one round in four or five; a flag goes to the owner, not to a re-run.
- **The owner's five decisions** are at the end of the short version.

## The fix round, Step 1 (c6cf110 and b8702ac)

No model calls were spent here.

- **c6cf110, the harness:** runs may save inside their own room in both arms; a re-cut quote passes and is reported; a quick check of pasted material passes (at most two calls, each naming what it checks), while a search for the unnamed hiring manager still fails; job-underwriter's fixture 5 no longer says when its pages were copied; the scorer prints every measure the bar reads; `run_fixtures --stems` regrades listed runs. Every gate passes here.
- **b8702ac, the one text change:** the old working name goes from the three places Claude reads it; Tuesday gets its routing-table row and the install-one-way line; both modules' research rules allow the quick check; the one sentence after job-underwriter's fit ledger is written as a list. The CI edits that only pass with it are in the same commit.
- **CI is red on b8702ac in one place**, the guard that marks shipped text as not yet measured. That is expected, and the branch is not merged while it is. The record commit after a passed round sets the measured hashes and moves the plugin to 0.2.0; it was dry-run on a scratch copy and passes every gate.
- **Run folders:** the quality runs use neutral folders (`part-1` to `part-3`) instead of the module's name, so no path the model sees names its module, as in the quality check through Tuesday, which supplies the baselines.

## Gate

At c6cf110 (the harness commit):
- `ci/sync.py --check` and `ci/package.py`: current.
- `ci/check_skills.py`: 264 assertions pass.
- `ci/test_checks.py`: 360 mutations detected, 109 must-pass cases accepted.
- `evals/test_harness.py`, `evals/routing_variants.py --check`: pass.

At b8702ac (head): the same, except `ci/check_skills.py` fails in the measured-text guard alone, so `ci/test_checks.py` declines to run. With the record commit applied on a scratch copy: 265 assertions, 369 mutations, 113 must-pass cases, all pass.

## Still open

- The fix round: plan approved (9c86e24), Step 1 built (c6cf110, b8702ac). The measured runs start when the weekly meter resets on Thursday 12 November at 06:00 UTC; the report is due Monday 16 November. The quality check's saved runs are not regraded (owner's choice): the round re-runs both arms with the matched install.
- Owner's decisions for that round (2326566, 679e5b6): a re-cut quote is not a defect, and no question is added about it (mock-interview's watch-out already asks the user to check); one labelled search checking that the user's material is still current is not a defect; runs may save inside their room, in both arms; Tuesday's description stays until a fourth module is planned.
- Agreed, outside the fix round: one folder per application for a candidate's job-search files, named by Claude as a default, measured on its own.
- Decided (dedb16e): job-underwriter's quick check of a posting and company the user pasted counts as the same proactive check; fixtures model what users typically send.
- The marketplace install needs the branch merged (the repo is private: users need access and a stored git credential).
- More than one sentence after the fit ledger (iteration 0): the quality check shows it on every model, in both arms.
- The plugin on claude.ai (hidden modules, `/tuesday:<module>`) needs a test in the owner's account.
- The repository's PR-creation setting still needs an admin to switch it in Settings.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_015ptydWtHPYTwrwMYpgde4U
