**Decision: no_go as posted.** Two hard gates fail on the posting's own terms, and wording can't close either one.

**Decision snapshot**
- **Hard gates (failed):** (1) **Location:** on-site in Austin 5 days a week, "no exceptions," against your remote-only, Portland-based requirement. (2) **Compensation:** $70–85k base against your $150k floor, which is 47–57% of your floor. `[grounded]`
- **Fit:** Strong on years (9 vs. 8+ required), scope (paid, lifecycle, experimentation, SQL/GA4/Braze), team leadership (3–7 people), and budget ownership ($8M to $40M ARR). `[grounded]`
- **Opportunity ledger:** Red-flag language in the posting (see risk register). The employer is unverified.
- **Confidence:** Hard-gate findings are high confidence because they come straight from the posting. Employer legitimacy is unverified.

**Role reality**
- Head of Growth owning all revenue channels (paid, SEO, lifecycle, brand, PR, partnerships, sales ops), team of one to start, reporting to the CEO with a dotted line to the board. `[grounded]`
- Stated scope is very broad for a base of $70–85k. Taken together with "team of one" and "we don't need a bench," the role reads as a single person covering a whole function. `[inferred]`
- "Must thrive on ambiguity; success metrics will evolve" means no defined success measures. `[grounded]`
- I did not run research, so I can't say whether this pay level is normal for the title or stage. `[generic]` pattern only.

**Evidence map** (requirements from the posting)

| # | Requirement | Priority | Fit | Confidence | Gap |
|---|---|---|---|---|---|
| 1 | 8+ years growth leadership | Must-have | Met | High (your stated history) | None |
| 2 | Own revenue growth end to end | Must-have | Met | High | None |
| 3 | Paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | Must-have | Partly met: paid, lifecycle, and experimentation are strong; SEO, PR, partnerships, brand, and sales ops are not evidenced in your summary | Medium | Presentation or capability; needs your CV detail |
| 4 | Team of one, comfortable without a team | Preferred | Your experience is building teams of 3–7, so this is a step down in scope | Medium | Transferability question for you |
| 5 | Thrives on ambiguity | Preferred | Not evidenced in your summary | Low | Needs an example |
| 6 | Compensation $70–85k base | Hard gate | Fails your $150k floor | High | Terms-level; not closable by wording |
| 7 | On-site Austin, 5 days/week | Hard gate | Fails your remote-only constraint | High | Terms-level; not closable by wording |

**Risk register**

| Class | Item | Severity |
|---|---|---|
| Compensation mismatch | Base is $65k–$80k below your floor. Equity is unquantified, and equity doesn't close a base-salary gap. `[grounded]` | High |
| Location mismatch | "No exceptions" on-site policy. `[grounded]` | High |
| Red-flag language | "Evenings and weekends when it matters is just who we are" signals expected overwork. `[grounded]` | Medium |
| Red-flag language | "Players who don't need a bench" plus a single-person function covering all revenue channels. `[inferred]` | Medium |
| Unverified employer | I have not confirmed Novaline exists as described (stage, size, and profitability are company claims). `[grounded]` as claims only | Medium, pending verification |

**Application plan:** Don't apply as posted. If the employer later confirms remote work and base pay at or above $150k, re-underwrite. Equity alone doesn't meet the floor, so I wouldn't count it toward that.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0: research not run, so the employer is unverified |
| 2. Role-family sweep (scope and pay norms) | skipped | L0: research not run |
| 3. Hiring manager's public footprint | n/a | No hiring manager named |

**Dossier offer:** At the end of this engagement, I can save this analysis as `tuesday-dossier.md` for later use.

**Upgrade menu** (what each input would add)
- **Live posting or careers-page link:** Confirms the terms, the pay, and whether the posting is current and consistent. This would resolve the unverified-employer item.
- **Research at L1 (up to 5 searches and 2 fetches):** Checks that Novaline exists as described, and gives a role-family pay and scope comparison labeled `[generic]`.
- **Your CV detail on SEO, PR, partnerships, and sales ops:** Would move requirement 3 from partly met to met or to a named gap.

**Questions**
1. Did this come from a recruiter, and did they quote the $70–85k and the on-site requirement, or was it only in the posting?
2. Can you share the live posting link or the company's careers page so I can check whether the terms still stand?
3. Are there any remote or hybrid Head of Growth roles you're tracking where the base clears $150k? If so, I can run the same underwriting on one.

Response modes: answer each question in your own words, or say "skip" to leave it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.