**Decision: conditional_go.** Apply, but confirm two things first: that the employer and posting are real and live, and what the pay is. Renata's fit on the posted requirements is strong. The open questions are about the opportunity, not her.

**Fit ledger** (scored separately from the opportunity)
- Meets all four must-haves: 4+ years pricing analytics, strong SQL and Python, GLM experience, presenting to underwriting leads. All are CV-stated and unverified.
- Meets the insurance "plus" through UK motor pricing.
- Partial: pet-insurance domain. Transferable skills, no direct experience.
- Unknown: people management. The JD is silent on it, and Renata has never managed anyone.

**Hard gates:** None stated in the posting. Fully remote UK fits Renata as stated. Her right to work in the UK is assumed from her UK employment, not verified.

**Opportunity ledger**
- Unknown: pay is not stated, so no band has been checked.
- Unknown: employer not verified. At this research tier I could not confirm Brindlemoor exists as described. This is a standing entry in the risk register.
- Positive signal: the JD gives clear ownership, covering rating models, price tests and recommendations to underwriting and product. That is a realistic senior scope.

**Role reality** (from the JD only; no research run)
- Title: Senior Pricing Analyst, pet-insurance product, Brindlemoor (insurtech), fully remote UK. Hiring manager: Odile Varga, Director of Pricing.
- Stated first-year outcomes: own the rating models and test program, and turn results into recommendations.
- Not stated: team size, whether the models are in-house or vendor-built, the product's age and loss history, pay, and reporting line.
- Market calibration: not run. `[generic]` only, and not calibrated.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | 4+ yrs pricing or actuarial analytics | met | medium | none | 5 yrs UK motor pricing analytics, last 2 as senior analyst (CV) |
| 2 | must | Strong SQL and Python | met | medium | none | Daily SQL and Python use (CV) |
| 3 | must | GLM experience | met | medium | none | Built and maintained a GLM rating model for the young-driver book (CV) |
| 4 | must | Presenting to underwriting or actuarial leads | met | medium | none | Presents quarterly pricing review to head of underwriting (CV) |
| 5 | preferred | Insurance experience | met | medium | none | UK motor insurance (CV) |
| 6 | implied | Pet-insurance product knowledge | partial | low | transferability | No pet experience. GLM method carries over; pet risk drivers and claims patterns do not yet |
| 7 | implied | Design and read price tests | met | medium | none | Ran 14 price tests with underwriting last year (CV) |
| 8 | implied | People leadership | unknown | low | discovery | JD silent; Renata has never managed anyone |

**Gap recovery queue**
- Row 6, pet domain: closes with evidence that she has learned pet risk drivers, such as a self-study project, a pet-related analysis, or adjacent health or livestock modelling. Without it, present the gap as transferable, not absent.
- Row 8, people leadership: closes once the reporting line is known. If the role has no direct reports, the gap is moot.

**Opportunity risk register**

| Class | Severity | Item |
|---|---|---|
| Unknown | medium | Pay not stated. Withholding pay is worth a question. |
| Unknown | high | Employer not verified at this research tier. Resolve with the live posting link or the company careers page. |
| Risk signal `[inferred]` | low | A GLM role on a newer pet product may have thin loss data. Unverified; depends on product age, which the JD does not give. |
| Positive signal | — | Clear ownership and decision remit in the JD. |

**Application plan**
- Lead with the GLM build-and-maintain record and the 14 price tests. These are the closest matches to the JD's core.
- Address the pet gap directly rather than hiding it: say her motor GLM and test experience is the transferable part, and that she is learning pet risk drivers.
- Do not claim pet experience, people management, or any figure she has not confirmed.
- Proposed CV or cover-letter wording is `resume_edits_pending_approval`. Nothing gets written or sent until Renata approves it.

**Evidence status**

Research tier: L0 — no searches; user links read 0

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Not run in this pass. Needs research consent. |
| 2. Role-family sweep (scope, title, pay) | skipped | Not run in this pass. Needs research consent. |
| 3. Hiring manager's public footprint | skipped | Not run in this pass. Needs research consent. |

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file for reuse later.

**Upgrade menu**
- Live posting link or careers page URL: verifies the employer (row for the unverified employer).
- L1 research, up to 5 searches and 2 fetches: checks the employer, a role-family pay band, and Odile Varga's public professional profile for positioning.
- Any pet-related work or learning: raises the pet-domain row from partial.
- Pay floor: lets the pay band be checked against her minimum.

**Questions**
1. Does this role have direct reports, or is it an individual-contributor role? This resolves the people-leadership row (row 8).
2. What is your pay floor? I'll compare it with the band once the posting or research provides one.
3. Shall I run L1 research on Brindlemoor, up to 5 searches and 2 fetches, to verify the employer and the pay band?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.