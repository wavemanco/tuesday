**Decision snapshot — apply, conditionally. Status: `conditional_go`.**

Your core technical match is strong. The real gaps are pet-insurance domain knowledge and two things the posting doesn't say. Web research was blocked, so the employer is still unverified.

**Fit ledger** (one line per priority tier, grouped by fit)
- `hard_gate`: unclear: right-to-work and UK location (you're UK-based by your history, but it isn't stated); unclear: pay (not stated)
- `must_have`: direct: 4+ years pricing analytics (R1), SQL and Python (R2), GLM experience (R3), presenting to underwriting leads (R5); direct: designing and reading price tests (R4, from the JD's own duties)
- `important`: adjacent: monitoring rating models in production (R6), bridged by your GLM maintenance work; absent: pet-insurance product knowledge (R7, implied by "for our pet-insurance product")
- `preferred`: direct: insurance experience (R8, motor); unclear: line management (not in the JD, and you've never managed anyone)

**Opportunity ledger.** The JD is specific: named hiring manager, concrete duties, a clear remit. Pay is withheld. The employer could not be checked, and the posting doesn't say whether the role owns a team.

**Role reality**
- Scope: owns pricing analytics for one product, a pet-insurance book, with outputs to underwriting and product. `[grounded]` from the JD.
- Market calibration: not available. Research was blocked, so there is no `[generic]` comparison for title, scope or pay.
- Contradictions: none found in the JD itself. "Senior" plus "own" suggests ownership, but the JD doesn't say whether that includes people.

**Evidence map** (confidence is from your statements alone; no artifacts were provided)

| # | Requirement | Priority | Fit | Gap | Confidence | Basis |
|---|---|---|---|---|---|---|
| R1 | 4+ yrs pricing/actuarial analytics | must_have | direct | none | medium | 5 yrs, last 2 senior `[grounded]` from your input |
| R2 | Strong SQL and Python | must_have | direct | none | medium | daily use, stated |
| R3 | GLM experience | must_have | direct | none | medium-high | built and maintained a GLM rating model, stated. Motor, not pet. |
| R4 | Design and read price tests | must_have | direct | none | medium | 14 tests last year, stated |
| R5 | Presenting to underwriting/actuarial leads | must_have | direct | none | medium | quarterly review to head of underwriting. Actuarial leads not mentioned. |
| R6 | Monitoring rating models | important | adjacent | transferability | medium | maintaining the GLM; no mention of monitoring cadence or drift checks |
| R7 | Pet-insurance product knowledge | important | absent | transferability | low | no pet experience; motor work does not exercise pet-specific drivers (vet-cost inflation, species/breed, wellness add-ons, cover-level structure) |
| R8 | Insurance experience | preferred | direct | none | medium | UK motor |
| R9 | Line management | not in JD | unclear | unknown | n/a | never managed; JD silent |

**Gap recovery queue** (no questions here; the question for each row is in the closing block)
- **G1: Pet-domain knowledge (R7), transferability.** *Adjacent evidence:* rating, GLM structure and price-test design carry over. *Limit:* pet-specific drivers and claim behaviour were not exercised. *Strengthener:* any pet-related reading, data or pricing work you can show. `[inferred]` that this is the gap an interviewer will probe first.
- **G2: Monitoring rating models (R6), transferability.** Your GLM maintenance is a real bridge. The limit is that you haven't shown what production monitoring looked like. Strengthener: a description of the monitoring you ran on the young-driver model.
- **G3: Line management (R9), unknown.** It determines whether "senior" means leading people or leading analysis. Only the employer can settle it.

**Opportunity risk register**
- **Employer unverified** (standing entry). Research was refused, so Brindlemoor's existence, stage and posting could not be checked. This keeps the decision at `conditional_go`, not `go`.
- **Pay withheld** (`[grounded]`). No band is stated, so there's no comparison to your floor. Unknown until the employer shares a range.
- **Right-to-work and location** (hard gate, unclear). "Fully remote (UK)" is stated, but your right to work isn't. Confirm before applying.
- **Possible people scope** (unknown). If this role line-manages, it's a step up from your experience.

**Application plan** (no CV language is proposed here; nothing is for sending yet)
1. Apply. The core match is strong, and the gaps are domain and scope, not capability.
2. Lead with the GLM ownership, price-test record and underwriting presentations. These map directly to R1 to R5.
3. Name the pet gap yourself, in one line, and say what you bring across. Interviewers will find it anyway.
4. Verify the employer and the pay before you invest in a full application.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page (Brindlemoor) | unavailable | web search was refused (permission not granted); would have checked the employer exists and the posting is live |
| 2 | Role-family sweep (pet-insurance pricing analyst scope and pay) | unavailable | web search refused; would have given a `[generic]` market and pay calibration |
| 3 | Hiring manager's public footprint (Odile Varga) | unavailable | web search refused; would have informed positioning for the interview |

**Upgrade menu**
- A link to the live posting, or the recruiter's email domain: unlocks the employer check. Moves the decision toward `go` if it confirms the company.
- The pay band: unlocks the compensation check.
- Your right to work in the UK: closes the hard-gate question.
- Any pet-related pricing or reading you've done: raises R7 from low confidence.
- Whether the role line-manages: resolves R9.
- Approving web search in your permissions: lets me rerun the three blocked checks. A deeper pass (L2: up to 5 more searches and 2 more fetches on funding, leadership and public candidate reports) is available, but only if you want it.

Dossier offer: I can write this up as a `tuesday-dossier.md` file so the assessment carries into later sessions.

**Questions**

1. Does the role line-manage anyone, or is "own" about analysis and decisions? (Affects R9.)
2. Can you paste the live posting link or the recruiter's email domain so I can verify Brindlemoor? If you approve web search, I'll check it myself.
3. Do you know the pay band, and are you UK-based with the right to work? (Affects the hard-gate and compensation checks.)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.