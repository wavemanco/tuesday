**Worth applying to, on conditions. Status: `conditional_go`.** Your background fits the operational half of this role well. The forecast and billing-data requirements are where the gaps are, and the posting itself needs one check before you invest effort.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days a week)
- `must_have` — direct: R2a, R3, R4a · adjacent: R2b (B2B software company), R4b (spreadsheet modelling), R5 (owning a forecast) · absent: R6 (billing and revenue data with finance)
- `important` — direct: R7 (pipeline and renewal reporting)

R2b (`medium`) — payments, not software; R4b (`low`) — modelling not yet evidenced; R5 (`low`) — pipeline review is adjacent, forecast never owned; R6 (`none`) — no billing work.

**Opportunity ledger.** Sound on substance: scope is defined and pay is disclosed in band (RR4). Two things are unresolved: whether the posting is confirmed on Quillfield's own careers page (RR1), and what "owning the forecast" actually means here (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is confirmed on Quillfield's own careers page (RR1); (2) the forecast scope is concrete: what you'd own versus the CFO and finance (RR2); (3) you can work the Bristol hybrid pattern (R1).

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 employees; Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options (options unquantified) | `[grounded]` posting |
| Market calibration | Ledgerline 2026 UK survey (n=438): median £64,200, interquartile range £57,800–£70,400. The posted range sits inside that band, near the median | `[generic]` one survey, 2026; not this employer's offer |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, per her public profile; previously sales operations manager at Corvane Payments for four years | `[grounded]` LinkedIn snippet, not fetched in full |
| Scope read | Covers CRM, billing and forecasting in one role, which is a broad remit for a lead | `[inferred]` from the posting's responsibility list |
| Unknowns | Whether the role reports to Tamsin; who currently owns the forecast methodology; what billing data access the role has; contract type; share option value | — |
| Contradictions | Posting says "Requirements: experience working with finance on billing or revenue data" and "own billing data", which is a requirement and a responsibility in one list. Recruiter's named hiring manager matches the public profile | `[grounded]` posting, profile |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | No candidate statement on location. Unresolved, not failed | `[grounded]` posting; no candidate claim | Ask Q1 |
| R2a | 4+ years in revenue ops, sales ops or analytics | must_have | direct | medium | none | Five years in sales ops, the last two running UK revenue ops. Self-reported at intake | `[grounded]` intake, CV-equivalent | none |
| R2b | …at a B2B software company | must_have | adjacent | medium | transferability | Worked at a B2B payments company. Payments is not software; the sales-ops work carries over | `[inferred]` from the employer type you described | Name the limit in any application |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; no HubSpot | `[grounded]` intake | Attach the certificate, which would raise to `high` |
| R4a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` intake | none |
| R4b | Spreadsheet modelling | must_have | adjacent | low | transferability | Excel daily, but no modelling work described | `[inferred]` from daily Excel use | Ask Q2 |
| R5 | Owning a revenue forecast | must_have | adjacent | low | transferability | Runs the monthly pipeline review with the sales director. Never owned the company forecast; finance did | `[grounded]` intake; `[inferred]` that the review is forecast-adjacent | Ask Q2 |
| R6 | Working with finance on billing or revenue data | must_have | absent | none | discovery | Never worked on billing data. Finance-side revenue work is not described | `[grounded]` intake | Ask Q3 |
| R7 | Pipeline and renewal reporting | important | direct | medium | none | Rebuilt pipeline and renewal dashboards | `[grounded]` intake | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5, must_have) | transferability | You run the monthly pipeline review and never owned the forecast | Decides whether the forecast line is a real gap or only a scope question | Any pipeline-to-forecast handoff you made to the sales director; any number you committed to | An anonymised pipeline review slide or forecast-vs-actual note | `[inferred]` bridge from the pipeline review |
| G2 | Billing and revenue data with finance (R6, must_have) | discovery | No billing work; revenue work is pipeline and renewals | This is the one must-have with no bridge yet | Renewal bookings reconciled against invoices; any finance-facing revenue report | A renewal report or a reconciliation example, sanitised | `[grounded]` intake |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own careers page | risk_signal | medium | "revenue operations lead" on tallyboard.example | The posting may be on an aggregator only, stale, or a different title on the company site. The employer exists, so this is not a failed-attribution entry | `[inferred]` from a careers search that returned no result | Is this role live on Quillfield's careers page, and is it the same post as this listing? | unresolved |
| RR2 | Forecast scope unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | You may own the model, or the CFO may own it with you supporting. Both are possible | `[inferred]` from the posting's wording | Which parts of the forecast does this role own, and which stay with the CFO? | unresolved |
| RR3 | Billing data ownership and access | unknown | — | "own our CRM and billing data" | Ownership may mean the data sits with finance and this role gets read access only | `[inferred]` from the posting's wording | Does the billing data sit with finance systems, and what write and sign-off rights come with the role? | unresolved |
| RR4 | Pay disclosed and in band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is transparent and sits in the middle of the market band | `[generic]` survey band; `[grounded]` posting | What is the share option grant, and how is it valued? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the role on Quillfield's careers page before writing anything | see RR1 | `[inferred]` from the careers search | pending your approval |
| P2 | Attach the Salesforce certificate to the application | see R3 | `[grounded]` intake | pending your approval |
| P3 | Draft pipeline and renewal dashboard bullets for the CV, reframed as revenue reporting. No forecast claim | see R7, R5 | `[grounded]` intake | pending your approval; reframing audit required before use |
| P4 | Prepare one honest forecast bridge: pipeline review to forecast, with the limit stated (you never owned the forecast) | see R5 | `[inferred]` | pending your approval |
| P5 | Ask the recruiter who the role reports to and what the forecast and billing scope is | see RR2, RR3 | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Everything above is intake prose, which counts as leads until you confirm it in a specific answer.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" (returned quillfield.co.uk/about) and "Quillfield careers revenue operations lead Bristol" (no results). Fetched quillfield.co.uk/about. Moved the employer check: the company exists as described; the role is not confirmed on its own careers page (RR1) |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software" (returned the Ledgerline 2026 pay guide, snippet only). Moved the market calibration line, labelled `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" (returned a LinkedIn profile, snippet only). Moved role reality's hiring-manager row; no contact details used |

**Upgrade menu**

- Your Salesforce certificate attached → R3 to `high`.
- An anonymised pipeline review or forecast-vs-actual note → R5 to `medium` or higher, and RR2 narrows.
- A renewal reconciliation or billing-facing example → R6 moves from `none`.
- The live careers-page link → RR1 clears.
- Your location and any non-negotiables (contract type, pay floor) → R1 resolves and the snapshot's constraints check runs.
- A deeper pass on Quillfield (funding, leadership changes, employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

Could I write this up as a `tuesday-dossier.md` file so the mock-interview skill can pick it up later? Say the word.

1. **R1:** Can you work hybrid from Bristol, two office days a week? Do you have any non-negotiables on contract type or pay floor?
2. **R5:** In your monthly pipeline review, do you produce a number that becomes the sales forecast? What did it get right or wrong last time?
3. **R6:** Have you ever reconciled renewal or pipeline bookings against invoices or billing records, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.