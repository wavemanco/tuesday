**Decision snapshot: conditional_go.** Pivoting to product management is not a waste of time, but this specific posting is a long shot on its literal must-have. Apply only if you can truthfully answer the first two questions below in the affirmative.

- **Fit ledger, by priority.**
  - *Must-have, strong:* stakeholder management across engineering, sales and customers.
  - *Must-have, partial:* shipped API or platform products; strong technical fluency (CV-only claim); roadmap-facing discovery; launch coordination with sales and support.
  - *Must-have, gap:* 3+ years of product management experience. You have no PM title, and this is the requirement a recruiter screens on first.
  - *Unevidenced:* adoption-metric definition and tracking; agile delivery.
- **Hard gates:** None identified. The material does not state location, pay, authorization or schedule, so those are unknown and flagged rather than cleared.
- **Opportunity ledger:** Nothing in the posting is a red flag on its face. The employer is unverified because no research has run (see Evidence status).

**Role reality** `[grounded]` from the JD: a platform PM owning the roadmap for a partner-facing API product, with two engineering squads, partner discovery, and metrics. This is a product-owner role, not an implementation role. Your strongest parallels sit next to it, not inside it.

**Market calibration** `[generic]`: integration and API PM roles often accept candidates from implementation or solutions backgrounds, but usually only when the candidate also shows product ownership: decisions, a backlog, or shipped changes. The literal "3+ years PM" line is commonly used as a screen. I have not checked this against current postings.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | What closes it |
|---|---|---|---|---|---|---|
| 1 | 3+ yrs PM experience | must-have | gap | low | transferability | Any period where you owned priorities or a backlog, even informally |
| 2 | Shipped API or platform products | must-have | partial | medium | presentation | Name a change you shipped in an API or the integration layer, and what you decided |
| 3 | Technical fluency: API docs, schemas | must-have | partial | medium `[grounded]` CV-only | presentation | Example of a schema or contract decision you drove or reviewed |
| 4 | Stakeholder management: eng, sales, customers | must-have | strong | medium-high `[grounded]` CV-only | none | Already well supported by coordinating vendor engineers, client engineers and PMs |
| 5 | Partner discovery | must-have | partial | medium | discovery | Your roadmap-input sessions: what changed in product as a result |
| 6 | Specs and delivery with eng squads | must-have | partial | medium | transferability | Requirements documents that engineering built against |
| 7 | Adoption metrics definition and tracking | must-have | unknown | low | discovery | Any adoption or go-live metric you tracked (you used SQL) |
| 8 | Launch coordination with sales and support | must-have | strong | medium-high | none | 30+ go-lives you ran end to end |
| 9 | Agile delivery | must-have | unknown | low | discovery | Sprint or backlog work in your past roles |

**Gap recovery queue:** Rows 1, 2, 5 and 7 are closed by the answers the questions below ask for. Row 3 is closed by one concrete example.

**Memory lead (unverified):** Earlier context suggests you built an internal request-triage tool that support agents adopted. I have not treated this as evidence. If it's true, it is the single strongest answer to row 1 and row 2, because it shows ownership of a product decision. Please confirm the details.

**Opportunity risk register**

| Class | Severity | Entry |
|---|---|---|
| mismatch | high | The must-have "3+ years PM" is not met by title. It may be met by substance if you can show product ownership. |
| failed-attribution | medium | Quartzline is not verified as described (stage, size, live posting). No research has been run. |
| scope | low | Two squads plus partner discovery is a real platform-PM load. Not a red flag, but it means the role wants someone already comfortable owning a backlog. |

**Application plan, as far as evidence allows**

- Do not apply on the strength of the title alone. Lead with the implementation work only if you can frame it as product input.
- Position your history as "integration and adoption product input from the field." Do not call it product management.
- If the answers to the first two questions are no, target roles with wording like "solutions-to-product," "integrations PM," "technical account or partner PM," or "implementation product" before this one.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Research not yet consented; offered in the upgrade menu |
| 2. Role-family sweep | skipped | Same |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file you can carry into a mock-interview session, if you'd like.

**Upgrade menu**

- **L1 research (default, up to 5 searches and 2 fetches):** verify that Quartzline exists as described and that the posting is live; check PM title and pay norms for this seniority.
- **The posting link:** this lets me check the JD against the live listing.
- **PM-adjacent artifacts:** the triage tool's scope and adoption numbers; the outcomes of your roadmap-input sessions; any metrics you tracked.

**Questions**

1. (Row 1 and row 2) Did you ever own a backlog, make a prioritization call, or ship a change to a product because of your work, including internal tools? If so, what was it and what happened?
2. (Row 9) Did you work in sprints or with a backlog at any point? What did you own in them?
3. (Row 5) Name one roadmap-input outcome that actually shipped, and what changed for clients as a result.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.