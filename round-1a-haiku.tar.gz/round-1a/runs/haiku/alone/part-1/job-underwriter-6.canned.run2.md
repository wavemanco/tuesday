**Decision snapshot: `hold_pending_answers`.** Apply if your answers on forecasting and billing come out as partial matches. Your core skills fit this role well. Two stated must-haves are the gaps, and the posting's own source and pay/location terms are still unchecked.

**Hard gates:** Location (Bristol, two days a week in the office) and pay (£61,500–£67,000) are unknown against your constraints. Neither is confirmed or failed yet.

**Research tier: L0 — no searches.** I read the posting you linked. I did not check Quillfield, the hiring manager, or market pay.

### Fit ledger (per requirement)

| # | Priority | Fit | Requirement | Basis |
|---|---|---|---|---|
| 1 | Must | Strong | 4+ years in RevOps / sales ops at a B2B software company | Your background: 5 years in sales ops at a B2B payments company, 2 running UK RevOps. Payments is B2B; the software/payments distinction is minor. `[grounded]` from your message |
| 2 | Must | Strong | HubSpot or Salesforce administration | Salesforce admin certified; rebuilt pipeline and renewal dashboards `[grounded]` |
| 3 | Must | Strong | Strong SQL and spreadsheet modelling | SQL weekly, Excel daily `[grounded]`. "Modelling" is not established yet; ask what the Excel work involved |
| 4 | Must | Partial | Experience owning a forecast | You run the monthly pipeline review with the sales director but have never owned the company forecast (finance did it). This is a real gap, though pipeline review is adjacent `[grounded]` |
| 5 | Must | Gap or partial | Experience working with finance on billing or revenue data | You have never worked on billing data. Renewal and pipeline data is revenue-adjacent, but finance collaboration is unestablished `[grounded]` |

Rows 1–3 are strong. Rows 4–5 carry the decision. The posting makes both must-haves: "experience owning a forecast" and "experience working with finance on billing or revenue data."

### Role reality

- **Scope:** The posting says you will "own our CRM and billing data," build pipeline and renewal reporting for sales and finance, and "run the quarterly revenue forecast with the CFO." This is more finance-facing than your current role. `[grounded]` from the posting.
- **Pay:** £61,500–£67,000 plus share options. Whether that fits your floor is unknown. I have not checked the market band; I can't calibrate it from memory. `[generic]` only once researched.
- **Location:** Bristol, hybrid, two days a week in the office. Your location and commute tolerance are unknown.
- **Contradiction to note:** Requirement 4 asks for experience owning a forecast, while the scope says the role runs the forecast with the CFO. Ask what "owning" means here: sole owner, or the operational lead for a finance-led process.
- **Source:** The link is on a third-party job board (tallyboard.example). I could not verify that Quillfield posted it. Confirm via Quillfield's own careers page or the recruiter's email domain before you invest time.

### Evidence map

| # | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|
| 1 | Must | Strong | High (your stated history) | None | Your message |
| 2 | Must | Strong | High (certification) | None | Your message |
| 3 | Must | Strong | Medium (SQL/Excel frequency stated, not shown) | Modelling depth unknown | Your message |
| 4 | Must | Partial | Medium | Forecast ownership | Pipeline review; no forecast ownership |
| 5 | Must | Gap | Medium | Billing data; finance collaboration | No billing work stated |

### Opportunity risk register

| Class | Severity | Item |
|---|---|---|
| Source | High | Posting on a third-party board; Quillfield not verified. Would change `go` to `conditional_go` until verified |
| Scope | Medium | Role is finance-facing (CFO forecast, billing data) while your experience is sales-side |
| Pay | Unknown | £61.5k–£67k vs your floor, not yet known |
| Location | Unknown | Bristol two-day hybrid, not yet known |
| Hiring manager | Unknown | Tamsin Achebe not researched |

### Application plan (as far as evidence allows)

- **Lead with:** Salesforce administration, pipeline and renewal dashboards, the SQL and Excel work, and two years running UK RevOps.
- **Do not claim** forecast ownership or billing experience unless you actually did them. Describe what you did with accuracy: for example, "ran the monthly pipeline review with the sales director," or "fed pipeline data into the forecast," if that is true.
- Any CV or outreach wording is a proposal for your approval before use.

### Evidence status

| Target | Status | Reason |
|---|---|---|
| L1-1: Quillfield site and careers page | skipped | L0 in effect; not run |
| L1-2: Role-family sweep (scope, title, pay) | skipped | L0 in effect; not run |
| L1-3: Hiring manager's public footprint | skipped | L0 in effect; not run |

User links read: 1 (the posting).

**Dossier offer:** I can save this as a `tuesday-dossier.md` file for the mock-interview skill to use later, if you want to go ahead.

**Upgrade menu:**
- **L1 research (up to 5 searches, 2 fetches):** checks Quillfield's existence and careers page, the market pay band for this role, and Tamsin Achebe's public professional background. This would resolve the source risk and the pay calibration.
- **Your floor and location:** tells us whether the pay and Bristol hybrid terms are gates or just noise.
- **Forecast or billing examples:** any artifact showing forecast inputs you built, or billing or finance reconciliation work, would raise rows 4 and 5.

**Questions:**
1. For the forecast: did you feed inputs into it (pipeline commit, stage-weighting, review of finance's numbers with the sales director)? How much of the process did you touch?
2. For billing and finance: have you done any work with finance on invoices, billing data, or reconciling bookings to billing, even at a reconciliation level?
3. Are Bristol two days a week and £61.5k–£67k both within your range?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.