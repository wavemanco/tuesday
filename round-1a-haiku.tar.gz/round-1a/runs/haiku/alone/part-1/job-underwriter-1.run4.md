**Decision: `conditional_go`.** Yes, apply. On the requirements you listed, your CV meets every one, and healthcare is a plus rather than a requirement. The decision is conditional only because I could not verify the employer.

**Decision snapshot**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R7
- `important`: adjacent: R5 (metrics layer), R6 (PM and clinician partnership) · unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R9 (HIPAA and healthcare data)

R3 is your strongest evidence, and the 11% result is what interviewers will probe. R5 is a bridge from governed Looker work, with the owned metric-definition process not yet shown. R8 has no mentoring evidence on the CV. R9 is a bridge from consumer PII work, with no PHI experience.

**Opportunity ledger.** Specific responsibilities, but thinly specified: the employer is unverified (RR1), the scope bundles several jobs into one role (RR2), and PHI access, clinical experiment context and pay are all unstated (RR3, RR5, RR4). One entry runs the other way: the analytics function appears to exist already (RR6).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** (1) the employer and live posting verify (RR1); (2) you have a credible answer on mentoring (R8); (3) PHI access and data-engineering support are confirmed (RR2, RR3).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not verified externally |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silent |
| Scope read | One senior analytics lead carrying metrics, experiments, BI and mentoring for one product | `[inferred]` from the responsibility list |
| Market calibration | Not established: the role-family search was refused, so there is no pay or scope band | — |
| Compensation, location, contract | Not stated | `[grounded]` JD silent |
| Unknowns | Employer verification, PHI access model, data-engineering support, clinical experiment constraints, pay, location | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company; CV-only, and employment dates would verify it | `[grounded]` your CV | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is a level to show, not just claim; a redacted query would show it | `[grounded]` your CV | optional: redacted query sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran a 30+ tests/year program. The 11% pricing result is the probe: be ready to give baseline, duration, primary metric, guardrails, and whether it held | `[grounded]` your CV | prepare methodology detail |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance from scratch; 40+ governed dashboards | `[grounded]` your CV | optional: dashboard screenshot |
| R5 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed models and a warehouse consent model show metric-definition work. No evidence yet of a cross-team metric dictionary or definition sign-off. Limit: that process is unshown | `[inferred]` | G1 |
| R6 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | medium | transferability | Monthly presentations to the VP Product and an exec memo show partnering. No clinician-facing work | `[grounded]` your CV; `[inferred]` transfer | none beyond G1 |
| R7 | Strong written communication for non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads | `[grounded]` your CV | optional: redacted memo sample |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing on the CV about mentoring or managing analysts | `[grounded]` CV silence | G2 |
| R9 | Healthcare data and HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and a consent-state model. No PHI, HIPAA, or clinical data | `[grounded]` your CV; `[generic]` that HIPAA adds PHI-specific obligations | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, important) | transferability | Governed Looker work and a consent-state model; no cross-team metric dictionary shown | The JD names the metrics layer as a core job; this is the bridge most likely to be probed | Agreeing one definition of an active subscriber across finance and product; resolving conflicting numbers; writing metric specs behind the monthly memo | A metric dictionary page, a redacted model excerpt, or a metric spec | `[inferred]` bridge; `[generic]` that this is a likely probe |
| G2 | Mentoring two analysts (R8, important) | discovery | No mentoring, managing, or onboarding on the CV | Named in the role; the one must-do-people item with no evidence | Onboarding someone onto Looker or the warehouse; reviewing a colleague's SQL or test analysis; running a team analysis review | An onboarding guide or review checklist | `[grounded]` CV silence |
| G3 | HIPAA and PHI handling (R9, preferred) | transferability | Consumer PII under GDPR/CCPA; a consent-state model; no PHI | Preferred, so a minor risk, but it governs how self-serve access can work | Access controls on sensitive data; minimum-necessary analysis; retention rules; any regulated-data project | A data-access or privacy design note | `[grounded]` your CV; `[generic]` on PHI obligations |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The search was refused, so the employer is unverified. This is not a finding about the company; small companies can have thin footprints | `[generic]` pattern; the gap itself is `[grounded]` | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Bundled scope in one role | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards…, and mentor two junior analysts" | Engineering or platform support may be missing from the description, leaving analysis to carry pipeline work | `[inferred]` from the responsibility list against no mention of data engineering | Who owns the warehouse pipelines and the experimentation platform, and how much of the metric work is engineering versus analysis? | unresolved |
| RR3 | PHI access model and self-serve scope unstated | unknown | — | "build self-serve dashboards in Looker" | Self-serve access to clinical data may be restricted, shaping the dashboard work | `[generic]` that healthcare data is usually access-gated | How is PHI separated from the analytics warehouse, and which roles can query it? | unresolved |
| RR4 | Pay, location, and contract not stated | unknown | — | JD silent on all three | Pay may be below your floor, or simply not published | `[grounded]` JD silence | What is the base range, and where is the role based? | unresolved |
| RR5 | Experiment context in a clinical product | unknown | — | "design and analyze A/B tests" | Health outcomes often lag and samples can be smaller than in consumer subscriptions, changing design choices | `[generic]` pattern; not a claim about this employer | Which experiments ran last year, and which metrics gate a decision: clinical, engagement, or revenue? | unresolved |
| RR6 | Responsibilities are specific and name existing assets | positive_signal | — | "build self-serve dashboards in Looker"; "define and maintain the metrics layer" | Suggests an analytics function already exists rather than being built from scratch | `[inferred]` from the existing-tense language | What does the analytics team look like today, and what would this role change first? | noted |

**Application plan** (every row proposed; nothing is finalized without your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the 30+ test program; prepare the 11% test's methodology (baseline, duration, primary metric, guardrails, whether it held) | R3 is your strongest evidence and the most likely probe | `[grounded]` your CV | pending your approval |
| P2 | Offer a redacted metrics memo as a work sample | Raises R7 to high | `[grounded]` R7 | pending your approval |
| P3 | Describe the consumer PII and consent-state work as what you handled, not as compliance you certified, and bridge it to R9 | Keeps the bridge honest | `[grounded]` your CV; reframing audit | pending your approval |
| P4 | Prepare a mentoring answer from real experience only. If you have none, say so and name how you would start | R8 is unevidenced; an invented story fails the first follow-up | `[grounded]` CV silence | pending your approval |
| P5 | Ask the RR-verification questions in the first interview | Turns the register into interview preparation | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Harborlight Health (company and careers page) were refused: search permission has not been granted in this session. Would have moved RR1 (whether the employer exists and the posting is live) |
| 2. Role-family sweep | unavailable | One search for senior product analyst pay and scope was refused. Would have moved the market calibration and the RR4 band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- A live posting link or the company's careers-page URL → RR1 closes; the employer cap on the decision lifts.
- Search permission granted → the employer and role-family checks run, with up to 2 more searches and 2 more fetches.
- A redacted query sample → R2 moves to high.
- A redacted metrics memo or dashboard screenshot → R7 and R4 move to high.
- The 11% test's readout (baseline, duration, primary metric, outcome) → R3 moves to high, and the probe is answered in advance.
- The base range and location → RR4 closes.
- The hiring manager's name → public-footprint research on how they likely evaluate analysts.

Would you like this saved as `tuesday-dossier.md`, so later interview prep can pick it up?

1. **G1 — Have you defined or signed off on a shared metric, such as an active subscriber, across teams? What did you own, and who had to agree?**
   Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G2 — Have you mentored, managed, or formally onboarded analysts? If so, what did that look like?**
   Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **C1 — What are your non-negotiables on location, base-pay floor, and contract type? These are the checks the snapshot cannot run yet.**
   Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.