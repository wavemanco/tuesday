**Yes, go for it, but only after two checks. Status: `conditional_go`.** On the core of the role you match the requirements on paper. The gaps are pet-specific, and I could not verify the company.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R8 (Pet-insurance product knowledge)
- `preferred`: direct: R9 (Insurance experience)

R2–R6 are all `direct` at `medium`, because they rest on your own statements and have no artifact behind them yet. R8 is the one real gap, and it is transferability, not capability.

**Opportunity ledger.** The role itself is clear and well scoped (RR4), but the employer is unverified (RR1), the salary is not stated (RR2), and it is unclear whether the role carries direct reports (RR5). A new pet product may have thin claims history to model on (RR3). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Brindlemoor and the live posting are confirmed (RR1); (2) the salary and contract basis are stated or confirmed with the recruiter (RR2); (3) you are not presenting pet-pricing experience you do not have. The motor-to-pet bridge is framed as adjacent, with its limit named.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your brief; company not verified this run |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` your brief |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior IC analytics role with clear outputs; no management requirement is stated | `[inferred]` from the JD's responsibilities against its silence on people |
| Market calibration | Not established. The salary and role-family searches did not run, so there is no band to compare against | — |
| Unknowns | Salary; contract type; whether the role has direct reports; size and data history of the pet book; whether the company exists as described | — |
| Contradictions | None visible between the JD and your brief | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD sets the gate. Your UK motor-insurer history suggests eligibility, but you have not stated your base or any constraint on remote working | `[grounded]` JD; `[inferred]` from employer history | Q2 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics, the last two senior. Your statement; no artifact yet | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, per your statement | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for a young-driver book. Motor, not pet, but the method is the same | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your statement | none |
| R8 | Pet-insurance product knowledge | important | adjacent | low | transferability | Motor pricing carries over: GLM method, price testing, underwriting presentation. It does not cover pet risk drivers (breed, age, vet-cost inflation, lifetime versus annual cover), which your work did not exercise | `[inferred]` bridge from R4 and R6; `[generic]` that pet risk drivers differ from motor | Q1 |
| R9 | Insurance experience | preferred | direct | medium | none | Motor insurance, per your statement | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-product knowledge (R8, important) | transferability | Motor pricing only. Nothing on pet risk drivers, lifetime cover, or vet-cost trends | This is the objection most likely to be raised, and it is the main reason the role is not a clean `go` | Any non-motor pricing or rating work; a claims-cost or severity study for a product with different drivers; a model you adapted for a new segment | A sanitized model summary, a price-test readout, or a segment analysis | `[inferred]` bridge derived from R4 and R6; `[generic]` that pet drivers differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Brindlemoor (insurtech)" | The company may be real and small, or the posting may be stale or aggregated. Search was unavailable, so this is a gap in the check, not evidence of a problem | `[inferred]` from the search failure in this run | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in JD) | The package may be below your expectation, or the company may simply not publish it | `[inferred]` from the JD's silence | What is the budgeted salary for this role? | unresolved |
| RR3 | Pet product may have thin data history | unknown | — | "our pet-insurance product" | A newer product may have little claims history to model from, which limits the rating work | `[generic]` pattern for newer insurtech products, not a finding about this company | How many policies and years of claims history sit behind the current pet pricing? | unresolved |
| RR4 | Clear scope and outputs | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | Role ownership is defined, and the work matches your background | `[grounded]` JD | Which pricing decisions does this role make itself, and which go to underwriting? | noted |
| RR5 | Direct reports unclear | unknown | — | (no management stated) | The role may be IC-only, in which case your lack of management experience is not a gap. If it has reports, it would matter | `[inferred]` from the JD's silence | Does this role line-manage anyone now or in the next year? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting and the company before investing effort | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter for the salary band, contract type, and whether the role has reports | see RR2, RR5, R1 | `[grounded]` RR2, RR5 | pending your approval |
| E1 | Keep the CV to what you have done: GLM, price tests, SQL and Python, underwriting presentations. Do not add pet experience | see R8 | `[grounded]` R4, R6, R8 | pending your approval |
| W1 | Prepare a one-page note on how motor pricing method maps to pet pricing, with the limits named (no pet risk data, no lifetime-cover work) | see R8, G1 | `[inferred]` bridge; `[generic]` on pet drivers | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your own statements and the JD.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was sent and refused (permission not granted), so nothing returned. Would have checked the company exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Search was sent and refused. Would have set the market calibration and the salary band (RR2) |
| 3. Hiring manager's public footprint | unavailable | Search was sent and refused. Name was given, so a query could form. Would have informed positioning for Odile Varga |

I did not retry the refused searches; the decision above is made on your brief and the JD alone.

## Dossier offer

If you want this kept as a file, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Search access granted → rerun the company and salary checks: resolves RR1 and RR2, and sets the market calibration.
- Live posting link or Brindlemoor careers page → RR1 closes, and R1 can be checked against it.
- Any non-motor or pet-related pricing artifact (sanitized) → R8 moves from `adjacent` toward `direct`.
- Your constraints (minimum salary, permanent or fixed-term, start date, base location) → the hard-gate checks run against them, and the snapshot's constraints flag clears.

## Questions

Q1 (R8, G1): Have you worked on any non-motor product, or any pricing that dealt with vet-cost trends, lifetime or renewal cover, or species-level risk? If so, what did you own and what happened?

Q2 (R1, constraints): What are your non-negotiables for this search: minimum salary, permanent versus fixed-term, start date, and whether your base is in the UK?

Q3 (RR1): Can you send the link to the posting or the recruiter's email domain, so I can check Brindlemoor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.