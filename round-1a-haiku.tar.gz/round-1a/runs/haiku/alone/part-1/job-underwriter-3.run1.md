**No — R1 and R2, both hard gates, fail · `no_go`.** Your sense that something is off is right. Two of your hard constraints fail on the posting's own stated terms, and the role is also built on a scope that doesn't fit one hire.

## Decision snapshot

- `hard_gate` — hard_gate_fail: R1 (on-site Austin office, five days a week), R2 (base pay $70–85k)
- `must_have` — direct: R3, R4, R5, R6
- `important` — direct: R9 (SQL, GA4, Braze) · unclear: R7 (SEO/content, brand), R8 (PR, partnerships, sales ops)

R1 — "no exceptions" in the posting; R2 — the top of the range is $65k under your floor; R7 and R8 — not in your CV, so open, not disqualifying.

**Opportunity ledger.** Against the role on its own terms: RR1 (seven disciplines under one hire), RR2 (always-on expectation), RR3 (pay likely low for this scope, not yet checked), RR4 (success metrics undefined), RR5 (equity unquantified), RR6 (employer not verified).

- **Hard gates:** failed: R1 (on-site Austin office, five days a week), R2 (base pay $70–85k)
- **Severe red flags:** none found
- **What would change this:** no factual path exists here. The posting says on-site is "no exceptions" and prints the pay range. It would change only if Novaline offered remote work in Portland or a base of $150k or more, and even then RR1 and RR2 would remain. Revising your floor or your remote requirement is your decision, not something the posting can resolve.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` JD claim, not verified |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Authority and resources | "Team of one to start"; no budget stated; reports to CEO, dotted line to board | `[grounded]` JD |
| Scope read | Seven specialist disciplines under one hire with no team is a bundled role | `[inferred]` from the JD's list against "team of one" |
| Working pattern | "Evenings and weekends when it matters is just who we are"; on-site five days | `[grounded]` JD |
| Market calibration | Not run. The $70–85k figure is compared only against your floor | — |
| Unknowns | Budget, equity terms, success metrics, which disciplines get staffed later | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, 5 days/week | hard_gate | hard_gate_fail | high | hard_gate | Your remote-only, Portland, no-relocation constraint is your own confirmed statement; the posting rules it out | `[grounded]` JD quote, your statement | none; only changed terms or a changed constraint resolve it |
| R2 | Base $70–85k vs your $150k floor | hard_gate | hard_gate_fail | high | hard_gate | Top of range is $65k under your floor | `[grounded]` JD figure, your statement | none; same as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years; growth lead, then Head of Growth | `[grounded]` CV, no artifact | none |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid at two B2C subscription companies | `[grounded]` CV | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze named | `[grounded]` CV | none |
| R6 | End-to-end revenue ownership | must_have | direct | medium | none | $8M→$40M ARR over three years with a budget you controlled | `[grounded]` CV | none |
| R7 | SEO/content, brand | important | unclear | low | discovery | Not in CV | `[grounded]` CV silence | none (does not change status) |
| R8 | PR, partnerships, sales ops | important | unclear | low | discovery | Not in CV | `[grounded]` CV silence | none (does not change status) |
| R9 | SQL, GA4, Braze | important | direct | medium | none | Named in CV | `[grounded]` CV | none |

## Gap recovery queue

- **G1** — R7 and R8 (discovery). The CV is silent on these. Closing them would not change the status, so no question is asked here.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled scope, one hire | risk_signal | medium | "all revenue growth end to end … sales ops"; "a team of one to start" | Coverage will be shallow in most of the seven disciplines | `[inferred]` from the JD's list against its team-of-one line | "Which of these seven does the first hire own in depth, and what budget and headcount come with the rest?" | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work is the norm | `[grounded]` quote; norm read `[inferred]` | "How much evening and weekend work did the last growth lead do, and what counts as 'when it matters'?" | unresolved |
| RR3 | Seniority-pay mismatch, unchecked | risk_signal | medium | "$70–85k base plus meaningful equity upside" | Pay may sit below the market for this scope | `[inferred]` from the range against title and scope; band not searched | "How was the base set for a head-level role with this scope, and what is the equity worth?" | unresolved |
| RR4 | Success metrics undefined | risk_signal | low | "success metrics will evolve as we learn" | Targets may be set after you start | `[grounded]` quote | "What three numbers define success at six and twelve months, and when are they fixed?" | unresolved |
| RR5 | Equity unquantified | unknown | — | "meaningful equity upside" | Equity value cannot be weighed | `[grounded]` quote | "What is the option pool, strike price, vesting schedule, and latest valuation?" | unresolved |
| RR6 | Employer not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A…)" | Employer existence and posting status are unchecked | `[grounded]` absence of research | "Can you point me to the role on your own careers page, and who would I interview with?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply as posted | R1 and R2 fail on the posting's own terms | `[grounded]` R1, R2 | your decision |

## Evidence status

Verified: your two constraints (R1, R2), confirmed in this conversation. Unverified: all CV claims (R3–R6, R9).

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | The two hard gates set the decision on the posting's own terms. Checking that the employer and posting are live would clear RR6; it would not change `no_go` |
| 2. Role-family sweep | skipped | Your floor already fixes the comparison. A market band would add a `[generic]` figure, not change the status |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Novaline's live posting link and the recruiter's email domain → clears RR6. Does not reopen the gates.
- Written remote eligibility or a base of $150k or more → R1 or R2 would move from failed to unclear, and the decision could move to hold.
- A search on Novaline (funding, recent growth-lead hires) and the pay band for head-level growth roles → sharpens RR1, RR3 and the market line. Up to 5 searches and 2 fetches; say the word and it runs.

I can also write this up as a `tuesday-dossier.md` file to keep the register for later, if you want it.

**Question (R1/R2, the only thing that could move the status):** Are your $150k floor and Portland-remote requirement firm, or is a specific alternative, such as a hybrid arrangement or a lower base with equity, a live option for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.