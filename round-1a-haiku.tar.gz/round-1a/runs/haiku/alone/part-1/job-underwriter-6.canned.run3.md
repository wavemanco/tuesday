**Yes, but on conditions. Status: `conditional_go`.** Apply, and go in ready to describe your pipeline and renewal work accurately. Don't claim the forecast or billing experience you don't have. Both are headline responsibilities, so they will come up.

**Fit ledger.**

- `hard_gate`: unclear: R8 (Bristol, hybrid, two days a week in office)
- `must_have`: direct: R2, R3 · adjacent: R1, R4 · unclear: R7 (working with finance on revenue data) · absent: R5 (owning a forecast), R6 (billing data)

R5 and R6 are absent and central to the job. R1 and R4 are real bridges with limits named in the map.

**Opportunity ledger.** The employer checks out, the pay sits in the middle of the market, and the scope is stated. Two parts of the role are unclear: whether the forecast is yours to own or to feed (RR1), and who owns the billing data day to day (RR2). The posting is not confirmed on the company's own careers page (RR3).

- **Hard gates:** none failed; unconfirmed: R8 (Bristol, hybrid, two days in office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the forecast and billing gaps are presented as adjacent exposure, never as ownership (R5, R6); (2) the posting is confirmed live on Quillfield's own careers page (RR3); (3) the Bristol hybrid pattern works for you (R8).

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, Bristol, founded 2018, about 96 staff, £11M Series A in April 2025 | `[grounded]` search snippet from quillfield.co.uk/about (page not fetched) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; the options' value is not stated | `[grounded]` posting |
| Market calibration | Ledgerline's 2026 UK pay guide for revenue operations leads in B2B software (n=438): median £64,200, interquartile range £57,800–£70,400. The posted range sits around the median | `[generic]` role-family sweep, this month |
| Unknowns | Forecast decision rights (RR1); billing data ownership (RR2); whether the role is hybrid in practice beyond the two days | — |
| Contradictions | The posting is on Tallyboard, and a search for the role on Quillfield's careers pages found nothing (RR3) | `[grounded]` search |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in revenue, sales operations or analytics at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales operations, the last two running RevOps for the UK team, at a B2B payments company. Quillfield describes itself as invoicing and payments software, so the match is close rather than exact | `[grounded]` CV; `[inferred]` on the match | Name the payments-software overlap in the application |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce-certified admin; rebuilt the pipeline and renewal dashboards | `[grounded]` CV | none |
| R3 | Strong SQL | must_have | direct | medium | none | SQL weekly. Stated, with no artifact to inspect | `[grounded]` CV | A sanitized query or dashboard would raise to high |
| R4 | Spreadsheet modelling | must_have | adjacent | low | transferability | Excel daily, but modelling depth is not described | `[grounded]` CV; `[inferred]` on the depth | Name a model you built |
| R5 | Owning a company revenue forecast | must_have | absent | high | capability | Finance owned the company forecast. You run the monthly pipeline review with the sales director, which is an input to a forecast, not the forecast | `[grounded]` CV, user-confirmed | G1 |
| R6 | Billing data | must_have | absent | high | capability | No billing-data work. The posting makes billing data central ("own our CRM and billing data") | `[grounded]` CV, user-confirmed; posting | G2 |
| R7 | Working with finance on revenue data | must_have | unclear | low | discovery | Renewal dashboards are revenue-adjacent, but finance collaboration is not described | `[grounded]` CV silence | Ask (Q2) |
| R8 | Bristol, hybrid, two days a week in office | hard_gate | unclear | low | hard_gate | Your location and constraints were not given | `[grounded]` posting | Ask (Q3) |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5) | capability | Pipeline review with the sales director; no forecast ownership | It is a named quarterly deliverable with the CFO | Any pipeline-to-forecast reconciliation, forecast accuracy check, or input you gave finance | A forecast-accuracy tracker, or a reconciliation you ran | `[inferred]` on the transfer; `[generic]` that this is the likeliest objection |
| G2 | Billing data (R6) | capability | Renewal and pipeline reporting; no billing data | It is named as owned data | Invoice or contract-value checks on renewals; any reconciliation with finance | An example query or report on renewal values | `[inferred]` on the transfer |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast decision rights unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build and maintain the model while the CFO signs it off, or it may own the numbers | `[inferred]` from the posting's wording against its silence on sign-off | Does this role own the forecast numbers, or prepare the model for the CFO's sign-off? | unresolved |
| RR2 | Billing data ownership unclear | unknown | — | "own our CRM and billing data" | Ownership may mean the reporting layer, with finance keeping the billing system | `[inferred]` from the posting against its silence on the billing system's owner | Who owns the billing system and its data day to day, and what would I change in the first 90 days? | unresolved |
| RR3 | Posting not found on Quillfield's own careers page | risk_signal | low | "Revenue Operations Lead, Quillfield" (on Tallyboard) | The posting may be a repost, a stale listing, or lag the company's own site | `[generic]` pattern for aggregator postings; `[grounded]` search returned no careers result | Can you point me to this role on your careers page, and who would I interview with? | unresolved |
| RR4 | Funding and size | positive_signal | — | "Series A (£11M) closed in April 2025" | The company is funded and growing, so the role is likely funded | `[grounded]` search snippet from the company's About page | What is the RevOps headcount plan for the next 12 months? | noted |
| RR5 | Pay in market | positive_signal | — | "£61,500–£67,000 plus share options" | The posted range sits around the market median | `[generic]` Ledgerline band against `[grounded]` posting | What is the share option grant and vesting? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the pipeline and renewal dashboards and the UK RevOps ownership; describe the monthly pipeline review as pipeline inspection, not forecast ownership | R2, R3, R5 | `[grounded]` CV; `[inferred]` on the framing | pending your approval |
| E2 | Frame payments-company sales operations as the bridge into B2B software, and name the overlap | R1 | `[grounded]` CV | pending your approval |
| A1 | Confirm on Quillfield's careers page that the role is live, and check the hybrid pattern and share options | RR3, R8, RR5 | `[grounded]` RR3 | pending your approval |
| A2 | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield and was previously in sales operations at Corvane Payments. That is public and a useful reader to write for. The public profile was seen only as a search snippet, not opened. Write for someone who knows the pipeline and renewal side | Positioning for the hiring manager | `[grounded]` search snippet of a public profile | pending your approval |

**Evidence status**

Verified: R2 (Salesforce certification), R5 and R6 (stated absences, user-confirmed). Unverified: R1, R3, R4, R7, R8. Rejected inferences: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" → quillfield.co.uk/about (snippet only; page not fetched): an invoicing and payments software company, founded 2018 in Bristol, about 96 staff, £11M Series A in April 2025. Searched "Quillfield Revenue Operations Lead careers" → no results, so the role is not confirmed on the company's own site (RR3) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software £60,000" → Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide): median £64,200, interquartile range £57,800–£70,400, n=438. Moved the market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → a public profile snippet (linkedin.example/in/tamsin-achebe), not opened: Head of Revenue Operations at Quillfield; previously four years as sales operations manager at Corvane Payments. Moved the positioning in A2 |

**Upgrade menu**

- A forecast-accuracy tracker, or a pipeline-to-forecast reconciliation you ran or checked → R5 and G1 move from absent toward adjacent.
- A billing or invoice-reconciliation example, even a sanitized one → R6 and G2 move.
- A sanitized SQL query or renewal dashboard → R3 rises to high.
- The careers-page link, or the recruiter's email domain → RR3 closes.
- A deeper pass on Quillfield (funding, leadership changes, reviews; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

1. (R5) Have you ever built, checked, or presented forecast numbers, even as an input to finance, such as a pipeline-to-forecast reconciliation or an accuracy review?
2. (R7) Have you worked with finance on invoice or revenue figures, even just to reconcile renewal values or pipeline against bookings?
3. (R8) What are your constraints on Bristol hybrid work (two days a week in the office) and on salary?

If you're ready to build the application, I can also write the CV edits (E1 and E2) for your approval.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.