## Decision snapshot

**Yes, apply. Status: `conditional_go`.** Your record covers five of the six listed requirements directly. The conditions are about the employer and the role's scope, not your fit.

**Fit ledger.**

- `hard_gate`: unconfirmed: R1 (fully remote, UK; your location and right to work aren't in what you gave me)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `preferred`: direct: R8 (insurance experience, listed as "a plus")

Confidence is `medium` on every row. All of it comes from your account, and none of it is inspectable yet.

**Opportunity ledger.** The posting is clear about the work and thin on everything around it: no salary, no team size, no contract type, and no stated reporting line (RR2, RR4). I haven't checked that the employer exists as described (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK; location and right to work not stated). Candidate non-negotiables not given, so checks against them are unknown.
- **Severe red flags:** none found in the text you pasted.
- **Conditions for go:** (1) confirm R1; (2) verify the employer and the live posting (RR3); (3) confirm whether the role line-manages anyone (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Scope read | An individual-scope senior analyst role on the posting's wording; whether it includes line management is not stated | `[inferred]` from the responsibilities list against the silence on reports |
| Market calibration | Senior pricing analyst roles at UK insurers commonly sit in the £60–80k range | `[generic]` pattern, not a claim about this employer; no search run |
| Unknowns | Salary; contract type; team size; reporting line; whether the rating engine is in-house or vendor-built; whether pricing decisions sit with the Director or with underwriting | — |
| Contradictions | None; only one source (the JD text you pasted) was checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK: location and right to work | hard_gate | unclear | none | discovery | Not in what you gave me; I have not assumed it | `[grounded]` JD states the location; your eligibility is absent | Confirm (see Q-none; upgrade menu) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst; the CV is the only source | `[grounded]` your account | Verify against the CV |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; no code sample in what you gave me | `[grounded]` your account | Optional: a sanitized query or script |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model: your strongest match. Motor, not pet | `[grounded]` your account | Lead with it |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your account | Lead with it |
| R6 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting; the JD names underwriting | `[grounded]` your account | Prepare one slide-level example |
| R7 | Build and monitor rating models | must_have | direct | medium | none | Maintained a rating model in production; "monitor" is covered by that work | `[grounded]` your account | None |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in UK motor insurance | `[grounded]` your account | None |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (no listed requirement; see RR1) | transferability | Motor only; nothing in pet | The role owns "our pet-insurance product"; a team may expect domain fluency | Any non-motor product, or any pricing driver with the same mechanics: frequency and severity, inflation, lifetime versus annual cover | A short note on the drivers you'd examine first in a pet book | `[inferred]` from the JD's product line against your history; `[generic]` on the domain drivers |
| G2 | Line management (not in JD; see RR2) | discovery | Never managed anyone | Matters only if the role line-manages | Leading a project or review with other analysts | Confirmation of the role's scope | `[grounded]` your account; `[inferred]` on the risk |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pet-insurance domain not in your record | risk_signal | medium | "our pet-insurance product" | A team may want domain experience on day one; motor pricing mechanics transfer, pet drivers would need learning | `[inferred]` JD against your history; `[generic]` on pet drivers | Is pet-domain experience expected from the start, or learned in role? | unresolved |
| RR2 | Line-management scope not stated | unknown | — | "own pricing analytics" | The role may be individual-scope, or may include a team you'd lead | `[inferred]` from the responsibilities against the silence on reports | Does this role line-manage anyone? | unresolved |
| RR3 | Employer not checked | unknown | — | "Brindlemoor (insurtech)" | Existence, stage and funding are unverified; checking was not run | `[grounded]` nothing beyond the JD text was checked | Link to the live posting, or the company's careers page | unresolved |
| RR4 | Salary and contract type withheld | unknown | — | (no figure stated) | Pay may sit below band, or the posting omits it | `[inferred]` from the missing figure | What is budgeted for the post, and is it permanent? | unresolved |
| RR5 | Clearly defined scope | positive_signal | — | "build and monitor rating models, design and read price tests" | The role is specified well enough to be a real owner's job | `[grounded]` JD | None needed | noted |

## Application plan

- **Lead with** GLM work (R4), price tests (R5) and the underwriting presentation (R6). Those three are where your record is strongest.
- **Don't claim** pet-insurance experience or any ownership you can't document. Frame pet as a learnable domain, supported by the pricing mechanics you already run.
- **Prepare** one sanitized example each of a GLM factor review and a price-test read-out. These are the inspectable evidence that moves R2–R6 from `medium` upward.
- **Before a formal application,** confirm RR2 and RR3 so you know the role's shape and that the employer is real.

*No externally visible text has been drafted. Any CV line or outreach wording would be proposed for your approval first.*

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Brindlemoor's official site and careers page | skipped | Research not consented; L0 run. Offered in the upgrade menu |
| 2 | Role-family sweep: pet and motor pricing scope and pay | skipped | As above |
| 3 | Hiring manager's public professional footprint (Odile Varga) | skipped | As above |

User links read: 0.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file whenever you want to keep it.

**Upgrade menu:**
- **Research (L1):** up to 5 searches and 2 page fetches to check that Brindlemoor exists, its stage and funding, and the hiring manager's public footprint. This would close RR3 and the market calibration.
- **Live posting link:** the employer's own page, or the recruiter's email domain.
- **Your CV document:** would move R2–R7 from `medium` toward `high` if it matches what you've told me.
- **Location and right to work:** would close R1.
- **Salary band:** would close RR4.

**Questions:**
1. **(RR2)** Does this role line-manage anyone, or is it individual-contributor?
2. **(RR1)** Have you worked on any non-motor product, or on a pricing driver that behaves like pet claims (vet-cost or medical inflation, lifetime versus annual cover)?
3. **(RR3)** Do you have a link to the live posting?

Answer any of these, or skip any. Skipping is fine.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.