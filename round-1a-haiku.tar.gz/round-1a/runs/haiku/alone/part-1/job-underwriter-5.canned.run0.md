**Decision: conditional_go.** Apply, but only after you confirm the posting is live and answer two gate questions below. Your fit is strong on the stated requirements. The posting's terms are reasonable. Nothing here is a no-go.

**Fit ledger**
- **Met as you stated it:** 5+ years data engineering; strong SQL and Python; dbt; a cloud warehouse (Snowflake); Airflow; data quality testing.
- **Partial:** BigQuery, which the JD names.
- **Unknown:** data contracts; ingestion from an app and a CRM.

**Hard gates:** Your location and pay floor were not in what you gave me, so both are unknown. Remote (US) or Denver will matter only if you're outside the US or need Denver specifically.

**Confidence:** Every fit row rests on your statement. Nothing is documented yet, so the band is "stated."

**Research tier:** L0, no searches. I haven't checked the company or posting online. Everything about the employer below comes from what you pasted.

**Role reality**
- **Scope** `[grounded]`: "Build and run pipelines" for reporting, with ingestion, a dbt warehouse in BigQuery, and data contracts. No hiring manager is named.
- **Market calibration** `[generic]`: Your seniority (6 years) sits in the typical "Senior" band (5–8 years). The posted $148k–$166k has a midpoint of $157k, above the $151k median and inside the $139k–$163.5k interquartile range. Equity is unpriced, so its value is unknown.
- **Company** `[grounded]`: Live K-12 tutoring in 31 states, founded 2016, 264 employees, $52M Series C (Feb 2026). These are the company's own claims, not verified.

**Evidence map**

| # | Priority | Fit | Requirement | Evidence | Gap | Confidence |
|---|---|---|---|---|---|---|
| 1 | Must | Met | 5+ years data engineering | 6 years, B2B payroll | None | stated |
| 2 | Must | Met | Strong SQL and Python | Daily use | None | stated |
| 3 | Must | Met | dbt | ~180-model dbt project | None | stated |
| 4 | Must | Partial | Cloud warehouse (BigQuery named) | Snowflake, no BigQuery | Transferability | stated |
| 5 | Must | Met | Airflow or similar | Airflow orchestration | None | stated |
| 6 | Must | Met | Data quality testing | Set up Great Expectations suite | None | stated |
| 7 | Responsibility | Unknown | Data contracts for analysts | Not in your background | Unknown | none |
| 8 | Responsibility | Unknown | Ingestion from app and CRM | Not in your background | Unknown | none |

Row 4 is a transferability gap, not a capability gap. Snowflake and BigQuery differ in partitioning and clustering, cost model, and SQL dialect (nested STRUCT/ARRAY and UNNEST). `[generic]`. Rows 7 and 8 are open questions, not gaps you've confirmed.

**Risk register**
- **Unverified employer** (medium): Nothing here is checked against the live web. Resolve with the live posting link, the company careers page, or the recruiter's email domain.
- **Equity unpriced** (low): The posting gives no amount or vesting terms.
- **No hiring manager named** (low): Reporting line and team unknown. Ask the recruiter.

**Application plan**
- Lead with the verifiable work: the 180-model dbt project, the Great Expectations suite, and the Airflow orchestration.
- Present Snowflake-to-BigQuery as a stated ramp, not as BigQuery experience. Don't claim BigQuery experience you don't have.
- Any résumé or outreach wording is `resume_edits_pending_approval`. Nothing goes out until you approve it.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 tier; no search run |
| 2. Role-family sweep | skipped | L0 tier; comp uses your Datawright report |
| 3. Hiring manager footprint | n/a | No name given |

Research tier: L0 — no searches

**Upgrade menu**
- A live posting link, or the recruiter's email domain, to verify the employer. Unlocks the employer row and the unverified-employer risk.
- Your location and pay floor. Unlocks both hard-gate rows.
- Equity amount and vesting terms. Unlocks the equity risk.
- A CV or portfolio line that shows ingestion or contracts work. Unlocks rows 7 and 8.
- An L1 research pass (up to 5 searches and 2 page fetches) on the company and the posting. Unlocks the employer check.

If you want, I can save this assessment as `tuesday-dossier.md` for later interview prep.

**Questions**
1. **[rows 7–8]** Have you designed or owned data contracts, or built ingestion from an app or CRM? Even partial work counts.
2. **[hard gates]** Where are you located, and what's your pay floor? Would remote-only work?
3. Can you send the live posting link or the recruiter's email domain so I can verify the employer? If you'd rather I run the L1 check myself, say so and I'll run it.

Reply with answers, or skip any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.