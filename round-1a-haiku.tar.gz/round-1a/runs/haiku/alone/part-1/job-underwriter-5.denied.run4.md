## Decision snapshot

Yes, probably worth applying, on conditions: `conditional_go`.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (US work authorization and location), R10 (base pay against your floor)
  - `must_have`: direct: R2 (5+ years data engineering), R3 (SQL and Python), R4 (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
  - `important`: adjacent: R5 (BigQuery warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts)

  R5 — a credible bridge from Snowflake and dbt, with the BigQuery limit named; R1 and R10 — the inputs don't settle either gate; R8 and R9 — neither appears in what you gave me.

- **Opportunity ledger.** Well specified on paper: the pay band and responsibilities are concrete (RR2). The employer and posting are unverified from here (RR1), no hiring manager or reporting line is named (RR3), and the BigQuery stack is a real difference from your background (RR4).
- **Hard gates:** none failed; unconfirmed: R1 (US work authorization and location), R10 (base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) US work authorization and location confirmed (R1); (2) the posting confirmed live on the employer's own careers site (RR1); (3) your base-pay floor sits at or below $148,000 (R10); (4) BigQuery framed as a transferable gap, never as experience (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted about text; not checked against the live site |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled warehouse on BigQuery, and data contracts analysts depend on | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain's pipelines spanning ingestion, warehouse and contracts: typical for a senior title, and not unusually broad | `[inferred]` from the JD's responsibility list against the title |
| Market calibration | Base median $151,000, interquartile range $139,000–$163,500 for senior data engineers at Series B–D companies; "senior" typically means 5–8 years; scope typically means one domain with no direct reports. The posted $148,000–$166,000 sits inside that interquartile range except for its upper end | `[generic]` the Datawright 2026 report, as your recruiter sent it; `[grounded]` the posted band |
| Unknowns | Hiring manager; reporting line; whether the BigQuery migration is done or planned; equity terms; your authorization and location fit; your pay floor | — |
| Contradictions | None visible between the JD and the about text, but neither was checked against the live site | `[grounded]` pasted text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US work authorization; remote US or Denver location | hard_gate | unclear | none | hard_gate | No constraint stated, so nothing settles the gate | `[grounded]` JD location line; candidate statement absent | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-report with no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; self-report | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake; the JD asks for "a cloud warehouse", which Snowflake meets | `[grounded]` your background | none |
| R5 | BigQuery-modelled warehouse (named in responsibilities) | important | adjacent | medium | transferability | dbt and SQL carry over; BigQuery specifics are not exercised. Limit: you have never used BigQuery | `[inferred]` transfer from Snowflake and dbt; `[grounded]` your statement | G2 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; CV-only claim | `[grounded]` your background | none |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in what you gave; Airflow use may cover it, unestablished | `[grounded]` absence | G1, Q2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in what you gave | `[grounded]` absence | G1, Q2 |
| R10 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor was not given; the posted band is grounded, the comparison is not made | `[grounded]` JD; floor not stated | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R8, R9, important) | discovery | Airflow and a 180-model dbt project are named; ingestion from an app or CRM and contracts are not | Two important rows; one answer can settle both | Pipelines pulling from a product database, Salesforce or HubSpot; schema or freshness contracts analysts relied on | A DAG diagram, a contract document, or a dbt exposures list | `[grounded]` absence; `[generic]` that CRM ingestion is common in edtech reporting |
| G2 | BigQuery (R5, important) | transferability | Snowflake and dbt; no BigQuery | Named in the role's stack; the limit is real | Any BigQuery work: a migration, cost tuning, a sandbox project | A sandbox project, or a short note comparing BigQuery with Snowflake | `[inferred]` bridge from the Snowflake and dbt work you described |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified from here | unknown | — | "Senior Data Engineer — Pellucid Learning" (pasted) | The role may be live and the company as described, and nothing here checked either | `[grounded]` the live-site check did not run; the text is pasted | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Base pay disclosed, inside the market interquartile range | positive_signal | — | "$148,000–$166,000 plus equity" | Disclosed pay near the market's middle; your floor is still unknown | `[generic]` band from the Datawright report; `[grounded]` posted band | Is the range base only, and how is equity sized? | noted |
| RR3 | No hiring manager or reporting line; scope unstated | unknown | — | "Posting names no hiring manager" | The role may own its pipelines end to end with no reports, the typical scope for the title, or it may not | `[generic]` typical scope from the Datawright profile; `[inferred]` from the JD's silence | Who would this role report to, and does it own its pipelines end to end? | unresolved |
| RR4 | BigQuery stack against a Snowflake background | risk_signal | low | "dbt-modelled warehouse in BigQuery" | The role may need a BigQuery ramp; severity is low because dbt and SQL transfer | `[inferred]` from the JD's stack line against your background | Is the warehouse on BigQuery already, migrating, or planned, and how much of the work is BigQuery-specific? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Name Snowflake and the dbt scale (about 180 models) explicitly in the CV; make no BigQuery claim | R4, R5 | `[grounded]` your background | pending your approval |
| E2 | Stand up a small dbt project on BigQuery before applying; if asked, describe it as learned, not production | R5 | `[inferred]` from G2 | your action |
| E3 | Confirm the posting on the employer's own careers site before investing in the application | RR1 | `[grounded]` RR1 | your action |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The careers-page fetch and a company search were both refused, so the posting's live status, the company facts and the employer's existence are not established here. Would have moved the organization row and RR1 |
| 2. Role-family sweep | skipped | The Datawright figures you pasted already fix the market calibration; no search sent |
| 3. Hiring manager's public footprint | n/a | No name is given in the posting |

Target 1 is `unavailable` because both calls were refused, not because the search was judged unnecessary. If you grant research permission, the same two targets run again within the same caps.

## Dossier offer

If you'd like, I can save this as `tuesday-dossier.md` so it carries into a later session; just say so.

## Upgrade menu

- Granting research permission runs the careers-page check, the posting-status check and the company-facts check, and closes RR1 if they confirm the role.
- A link to the live posting or the employer's careers page: RR1 closes by reading it.
- A sanitized dbt exposures list or a data-contract document: R9 moves toward `medium`.
- A BigQuery sandbox run, or a note comparing it with Snowflake: R5 moves from `adjacent` toward `direct`.
- The hiring manager's name: RR3's scope read sharpens, and the positioning can lead with the story that fits that reader.
- A deeper research pass on Pellucid (leadership changes, funding history, recent news; up to 5 more searches and 2 more fetches) — say the word, and only if research is permitted.

## Questions

**R1** — Can you work for a US employer without sponsorship, and does remote US or the Denver office fit where you live?

**R8, R9** — Have you owned ingestion from an app database or a CRM, or defined data contracts analysts relied on? Tell me the one you'd lead with: what it was, what you owned, and what broke.

**R10** — What is your base-pay floor, and is it firm?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.