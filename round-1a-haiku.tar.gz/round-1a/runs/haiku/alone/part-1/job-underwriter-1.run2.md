**Yes, apply, but verify the posting first.** On the core requirements your experience maps directly, and the open items are healthcare and clinician work. The decision is `conditional_go`. I could not run any web research because the search permission was declined, so the employer is unverified.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5, R6, R7
- `important`: unclear: R8, R9
- `preferred`: adjacent: R10

R1–R7 are your core match. R8 (clinicians), R9 (mentoring) and R10 (healthcare) are where the map is thin. R1–R7 are self-reported, so each carries `medium` confidence until there is an inspectable artifact.

**Opportunity ledger.** The employer is not established, and no pay is stated: RR1 (employer not established) and RR2 (no compensation stated) are open. RR3 (clinician involvement) is unclear. RR4 is a positive signal: the scope is explicit.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for `conditional_go`:** (1) RR1 verifies on Harborlight's own careers page; (2) R8 and R9 come back concrete in answers; (3) you tell me any location, authorization or pay constraints so I can check them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, as stated in the JD | `[grounded]` your paste |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | A full analytics-lead remit with people management added; coherent for a senior title | `[inferred]` from the JD's bullet list |
| Market calibration | Not run: the role-family search was declined | — |
| Compensation | Not stated in the JD | `[grounded]` JD |
| Unknowns | Employer's live status, pay, clinician involvement, mentoring scope, location and contract terms | — |
| Contradictions | None found in the material you gave | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | 6 years stated in your background; self-reported | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; no artifact yet | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests/year; pricing test with 11% retention lift as you stated it | `[grounded]` your background | Offer one readout as an artifact to raise to `high` |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Define and maintain the metrics layer | must_have | direct | medium | presentation | Governed dashboards imply metric definitions; you have not said you owned them | `[grounded]` your background; `[inferred]` from "governed" | Confirm you owned the canonical definitions, then lead with that |
| R6 | Partner with PMs; turn analysis into roadmap decisions | must_have | direct | medium | none | Monthly presentations to the VP Product | `[grounded]` your background | none |
| R7 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team | `[grounded]` your background | none |
| R8 | Partner with clinicians | important | unclear | low | discovery | No clinician work stated | `[grounded]` JD; CV silent | Question 1 below |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Mentoring not stated | `[grounded]` JD; CV silent | Question 2 below |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model; no PHI and no HIPAA | `[grounded]` your background; `[inferred]` that consent work transfers | Make the bridge and state its limit: consumer data, not PHI |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R8, important) | discovery | No clinician work stated | Clinician input is part of the mandate | Working with care-ops or support teams on a decision; clinical or ops review of a test | A readout or memo that a non-analyst partner shaped | `[grounded]` CV silence |
| G2 | Mentoring (R9, important) | discovery | No mentoring stated | Two junior analysts are part of the role | Onboarding or reviewing a junior's SQL or analysis; leading an analyst team | Team plan, or a review you ran | `[grounded]` CV silence |
| G3 | Healthcare bridge (R10, preferred) | transferability | Consent and PII work in a consumer warehouse | Preferred, not required | Consent-state model; privacy reviews of data access | A data-access policy you wrote | `[inferred]` bridge; limit is PHI and HIPAA |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The live posting may be stale or aggregated, or the employer may be small enough to have little footprint. The search was declined, so this says nothing about whether Harborlight is real | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (no pay in the JD) | Pay may be set after screening | `[inferred]` from the JD's silence | What is the base salary range for this role? | unresolved |
| RR3 | Clinician involvement unclear | unknown | — | "partner with ... clinicians to turn analysis into roadmap decisions" | Clinicians may have veto power over metrics or tests | `[inferred]` from the JD's wording | How much weight do clinicians have when a test result or metric is contested? | unresolved |
| RR4 | Scope explicit | positive_signal | — | "Own product analytics for our care-navigation app" | The remit is clear and includes mentoring | `[grounded]` JD | How many experiments does the team run each year, and who decides what ships? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting on Harborlight's careers page before applying | RR1 | `[grounded]` register | recommended |
| A2 | Lead the CV with the metrics-definition ownership, if confirmed | R5 | `[grounded]` R5 row | pending your approval |
| A3 | Frame healthcare as adjacent: consent and PII work, with PHI and HIPAA named as the limit | R10 | `[grounded]` R10 row | pending your approval |
| A4 | Ask the RR2 and RR3 questions in the first recruiter call | RR2, RR3 | `[grounded]` register | recommended |

Nothing in A2 or A3 adds a claim. Do not describe mentoring or clinician work as yours unless you confirm it.

## Evidence status

Verified: none yet. Everything in the map is self-reported.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Harborlight Health care navigation app Series C"; "Harborlight Health Senior Product Analyst careers") were declined. Would have confirmed the employer exists, its stage, and that the posting is live |
| 2. Role-family sweep | unavailable | One search ("senior product analyst salary experimentation Looker digital health") was declined. Would have set the market calibration and the pay check |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- The live posting link or the careers-page URL → resolves RR1 and lets the employer check run.
- Permission to run web search → a market calibration for this title and a pay band to compare against RR2.
- A pay range from the recruiter → RR2 closes.
- Any location, work-authorization or minimum-pay constraints → the hard-gate checks run; right now they are unknown.
- One inspectable artifact (an experiment readout or a metrics-definition doc, with confidential parts removed) → R3 or R5 to `high`.

If you want, I can write this up as a `tuesday-dossier.md` file for later.

1. R8: Have you worked directly with clinicians or care-ops teams? If so, what did you own in how their input shaped a decision?
2. R9: Have you formally mentored or managed junior analysts? If so, how many, and what did it involve?
3. Do you have any hard constraints I should check against this role: location, work authorization, minimum pay or schedule?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.