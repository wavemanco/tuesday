**Decision: no_go as posted.** Two hard gates fail, and neither can be fixed by wording. Your sense that something is off is well-founded.

**Decision snapshot**

- **Opportunity ledger:** The posted base of $70–85k [grounded] is $65–80k below your $150k floor. The role is on-site 5 days a week in Austin with "no exceptions" [grounded], which excludes remote-only.
- **Fit ledger (candidate side):** Strong on years, paid, lifecycle, experimentation, and SQL/GA4/Braze. Partial on SEO, PR, brand, partnerships, and sales ops. Your B2C subscription background transfers only partly to e-commerce enablement.
- **Hard gates:** 2 of 2 failed: compensation (`hard_gate`) and location/schedule (`hard_gate`).

**Role reality**

- **Scope:** Every revenue function, a team of one to start, with "evenings and weekends when it matters" [grounded]. That is wide and thin, and it conflicts with your track record of building and managing teams of 3–7.
- **Ambiguity:** "Success metrics will evolve as we learn" [grounded]. Undefined success metrics for a Head-of-level role are a risk in themselves.
- **Contradictions:** The title, board-facing reporting line, and 8+ years requirement sit against a pay band that reads like a far more junior role. The posting does not say whether the pay or the location is negotiable.
- **Market calibration:** Not established. I did not run research, so I have no sourced band for this title and seniority.

**Opportunity risk register**

| Risk | Class | Severity |
|---|---|---|
| Base pay $65–80k below your floor | mismatch | high |
| On-site 5 days, "no exceptions," vs. remote-only | mismatch | high |
| Unrealistic scope for one person, with stated evenings and weekends | red flag | high |
| Employer identity and "profitable since day one" unverified | unknown | medium |

**Application plan:** Don't apply as written. If you want to test whether the terms are real, send one question to the recruiter: is the base and the on-site requirement negotiable, in writing? A clear no closes it. A yes would reopen the decision, and I'd re-underwrite then.

**Evidence status:** Research tier: L0 — no searches. No research targets were run, so there are no evidence-status rows.

**Dossier offer:** I can write this up as `tuesday-dossier.md` when you want to keep the analysis.

**Upgrade menu**

- **L1 research** (up to 5 searches, 2 fetches): confirms Novaline exists as described, checks the live posting, and gives a sourced market band for this seniority and pay.
- **Link to the live posting or the recruiter's email domain:** lets me check whether the posting matches what was provided.
- **Your CV, if you want the fit ledger fully sourced:** would raise confidence on the partial rows.

**Questions**

1. Is the $70–85k base a figure the recruiter gave you, or one you read from the posting? Has anyone said the range is flexible?
2. Would you consider a remote arrangement or a hybrid one outside Austin, or is the location gate firm?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.