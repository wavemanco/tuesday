**Decision: conditional_go.** Apply, once you've confirmed the posting is live and the role doesn't involve managing people.

I could not run web research: the search permission was refused. So nothing below about Brindlemoor is verified, and market norms are general patterns, not facts about this employer.

**Role reality**
- Senior Pricing Analyst, owning pricing analytics for one pet-insurance product: rating models, price tests, and recommendations to underwriting and product. [grounded, JD]
- Scope reads as an individual-contributor analytics owner. The JD never mentions people management. [grounded] Whether that holds is an open question (see below).
- Insurtech, fully remote UK. [grounded, JD] Company size, stage and funding are unknown. [generic]
- Pet pricing differs from motor in ways that matter here: ongoing renewals, vet-cost inflation, and a smaller claims history for a newer product. [generic] Those are patterns to test against the company, not facts about it.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Basis |
|---|---|---|---|---|---|---|
| 1 | Must-have | 4+ years pricing or actuarial analytics | Meets | High | none | 5 years, last 2 senior [grounded, your background] |
| 2 | Must-have | Strong SQL and Python | Meets | Medium | none | Daily use, stated [grounded]; no artifact to check |
| 3 | Must-have | GLM experience | Meets | Medium | none | Built and maintained a young-driver GLM [grounded]; scale and validation not stated |
| 4 | Must-have | Presenting to underwriting or actuarial leads | Meets | Medium | none | Quarterly review to the head of underwriting [grounded] |
| 5 | Must-have | Designing and reading price tests | Meets | Medium | none | 14 tests last year [grounded]; outcomes not stated |
| 6 | Preferred | Insurance experience | Meets | High | none | UK motor insurer [grounded] |
| 7 | Implied | Pet-insurance product knowledge | Partial | Low | Domain | No pet experience [grounded, your statement]. Closeable by ramp-up, not by a hard gate |
| 8 | Implied | Owning a product's pricing end to end | Unknown | Low | Scope | Not stated whether this includes people management or product decisions |

Requirements 1–6 are supported by your background. Confidence is capped at medium for anything you haven't backed with an artifact. [inferred]

**Hard gates**
- Fully remote, UK: not failed. Your background implies UK, but location is not stated. Confirm it.
- No failed hard gates.

**Opportunity risk register**
- **Unverified employer** (severity: medium). I couldn't confirm Brindlemoor exists as described. This is why the verdict is conditional.
- **Possible management expectation** (severity: medium). "Own" plus "Senior" can mean a line-management role. You've never managed anyone, so this is the most important question to settle before applying.
- **Pet-domain ramp** (severity: low–medium). Expect questions on lifetime versus annual cover, breed and age rating factors, and vet-cost trends. [generic]

**Application plan**
- Lead with the motor GLM and price-test work, framed as transferable: segmenting risk and reading controlled tests. [inferred]
- Do not describe any of it as pet experience. Proposed wording (draft, not for use until you approve it): "Applied GLM segmentation and price testing in UK motor; applying the same method to pet risk."
- Proposed CV language is `resume_edits_pending_approval`. Nothing goes out until you approve it.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Search permission refused |
| 2. Role-family sweep | unavailable | Search permission refused |
| 3. Hiring manager's public footprint | unavailable | Search permission refused; name given, so declared |

---

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file, so you can return to it or use it for interview prep.

**Upgrade menu**
- **Live posting link or recruiter email domain.** Verifies the employer and confirms the hard gates.
- **Permission to search.** Lets me check the company, the market pay band, and Odile Varga's public background.
- **Outcomes from the 14 price tests** (lift, loss-ratio effect, or sample size). Turns the "medium" rows into "high".
- **Full job description.** Confirms or rules out the management expectation.

**Questions**
1. Does this role manage people, or is it individual analytics ownership? The posting doesn't say, and you've never managed anyone.
2. Can you share the live posting link, or the recruiter's email domain, so I can confirm Brindlemoor exists as described?
3. Which of the 14 price tests have a measurable outcome you can share? Even rough figures would strengthen the evidence rows.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.