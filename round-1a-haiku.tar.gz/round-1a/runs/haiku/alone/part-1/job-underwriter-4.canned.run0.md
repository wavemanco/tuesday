**Decision snapshot — hold_pending_answers.** Your fit is strong on the requirements, but the role has an unresolved location conflict, and the employer is thinly verifiable. Two answers would settle it.

**Fit ledger.**
- `hard_gate`: unclear: R8 (location: "fully remote UK" in the JD, "Leeds office four days a week" on the careers page)
- `must_have`: direct: R1, R2, R3, R5
- `important`: direct: R4
- `preferred`: direct: R6

**Opportunity ledger.** The role is well scoped and its craft matches your work. The risks are the location contradiction (RR1), a thin public footprint for the employer (RR2), and a withheld salary (RR3).

- **Hard gates:** none failed; unconfirmed: R8 (location, sources contradict); candidate pay floor and other constraints not given, so checks against them are unknown.
- **Severe red flags:** none found in the posting itself.
- **Conditions to move to go:** (1) the location is confirmed in writing, and you can work it; (2) the employer is verified beyond its own careers page.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` JD; careers page |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD; careers page |
| Working pattern | Conflict: "Fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | Senior IC analytics role. The JD names no line management, so I have not treated people management as a requirement. | `[inferred]` from the stated responsibilities |
| Market calibration | Not run. The role-family salary sweep was skipped, so there is no pay band. | — |
| Unknowns | Live location; salary; contract basis; whether the pet product has existing rating models you would inherit | — |
| Contradictions | Location (above) | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | high | none | Five years, the last two senior, matches the floor | `[grounded]` CV | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact yet | `[grounded]` CV | G2 |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; CV-only claim | `[grounded]` CV | G1 |
| R4 | Design and read price tests | important | direct | medium | none | Ran 14 tests with underwriting last year; the JD lists this as a responsibility, not a requirement | `[grounded]` CV and JD | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` CV | none |
| R6 | Insurance experience | preferred | direct | high | none | Five years at a UK motor insurer; the JD says "a plus" | `[grounded]` CV and JD | none |
| R8 | Location: fully remote UK vs Leeds four days a week | hard_gate | unclear | low | hard_gate | Two sources disagree; your location was not given | `[grounded]` JD and careers page | G3; Q1 |

**Gap recovery queue**
- **G1 (R3, GLM):** the gap is proof, not capability. Closes with anonymised model documentation or a worked example of the young-driver model's structure and monitoring.
- **G2 (R2, SQL/Python):** the claim is stated but unshown. Closes with a sanitised query or model script.
- **G3 (R8, location):** the contradiction is in the sources. Closes with the recruiter confirming the working pattern in writing, or the live posting showing one version.

**Opportunity risk register**
- **RR1: location contradiction.** Severity: high. The JD and careers page conflict, and your location is unknown. Treat this as the gate.
- **RR2: employer verification (standing entry).** Severity: medium. A broad search for "Brindlemoor insurtech pet insurance UK" returned nothing. The only attributable web presence is the careers page, which is live and matches the JD's role. Existence as described is partly verified. Resolves with the recruiter's email domain or a press or company-register check.
- **RR3: pay withheld.** Severity: medium. No salary is stated, and the market band was not checked. Resolves with your floor against the offer.
- **RR4: no pet-insurance background.** Severity: low-medium. The stated requirements do not name pet experience, so this is not a fit failure, but the team may expect product sense. Lead with transferable method, not claimed pet knowledge.
- **Positive signal:** the hiring manager has a relevant background. A public profile snippet (not fetched) describes Odile Varga as Director of Pricing, previously head of pricing analytics at Calloway Re for six years, and a 2025 Insurance Pricing Forum speaker on monitoring rating models in small books. `[grounded]` search snippet. This says nothing about the company itself.

**Application plan**
- Lead with the GLM build and maintenance, the 14 price tests run with underwriting, and the quarterly presentation to underwriting. These match R3, R4 and R5 directly.
- Present motor pricing as transferable: model monitoring and test design with underwriting. Do not claim pet-insurance knowledge.
- Hold the application until Q1 is answered. If the location is four days in Leeds and that doesn't work, this is a no.
- No CV edits or outreach text are proposed yet. Any wording would go to you for approval first.

**Evidence status**
Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | yes | Query "Brindlemoor careers pet insurance"; page brindlemoor.co.uk/careers/senior-pricing-analyst (fetched). Posting is live; Leeds four days a week. The broad company query found nothing else. |
| 2 | Role-family sweep (market scope and pay) | skipped | Not run in this pass. Would give a `[generic]` pay band. |
| 3 | Hiring manager's public footprint | yes | Query "Brindlemoor Senior Pricing Analyst Odile Varga"; search snippet only, page not fetched. |

**Dossier offer:** I can save this as a `tuesday-dossier.md` file with the full evidence map, so you can revisit it or hand it to interview prep.

**Upgrade menu**
- A deeper company check (funding, leadership, news; up to 5 more searches and 2 more fetches) would test RR2. Say yes if you want it.
- A salary sweep for this seniority and remit would give a pay band for RR3.
- An anonymised GLM document or SQL/Python sample would move R2 and R3 from medium to high.

**Questions**
1. **(R8)** Where are you based, and could you work from Leeds four days a week?
2. **(RR2)** Who contacted you about this role, and from which email domain?
3. **(RR3)** What is your pay floor, and are there other non-negotiables I should check against?

Reply to any of these, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.