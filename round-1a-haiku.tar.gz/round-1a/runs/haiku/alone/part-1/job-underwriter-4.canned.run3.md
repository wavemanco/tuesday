**Worth applying to, on conditions. Status: `conditional_go`.** Your fit is strong on the requirements the JD lists. The open issues are the employer, which I haven't verified, the pay, which isn't stated, and the pet-insurance domain, which you haven't worked in.

**Fit ledger.**
- `hard_gate`: unclear: R1 (fully remote UK; your location isn't in what you gave me)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6 · adjacent: R7 · absent: R9 (pet insurance)
- `preferred`: direct: R8

R9 is the only absent row, and it's the one that matters most for this specific role.

**Opportunity ledger.** Clearly scoped, with a named hiring manager. The employer is unverified, the salary is withheld, and it's unclear whether the role sets final rates or only recommends them. The posting's responsibilities are specific, which is a positive signal.

**Research tier: L0, no searches or fetches.** Everything about Brindlemoor, pet-insurance pricing and pay is unverified or labelled `[generic]`.

## Role reality

| # | Item | Provenance |
|---|---|---|
| U1 | Scope: rating models, price tests, recommendations to underwriting and product | [grounded] JD |
| U2 | Stated requirements: 4+ years, SQL/Python, GLM, presenting to underwriting or actuarial leads; insurance a plus | [grounded] JD |
| U3 | Not stated: pay, contract type, line management, whether final rate decisions sit with this role | [grounded] JD (absence) |
| U4 | Pet pricing differs from motor in ways a GLM transfers only partly: species and breed factors, vet-cost inflation, lifetime versus annual cover | [generic] |
| U5 | Market calibration: not run (L0) | — |
| C1 | Employer existence: not established; no L1 check | [inferred] from L0 |

## Evidence map

| # | Priority | Requirement | Fit | Gap | Confidence | Evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | hard_gate | Fully remote, UK | unclear | hard-gate | low | Your location not stated | [grounded] JD |
| R2 | must_have | 4+ years pricing or actuarial analytics | direct | none | medium | 5 years, last 2 as senior analyst (CV-only) | [grounded] your background |
| R3 | must_have | Strong SQL and Python | direct | none | medium | Daily use (CV-only) | [grounded] your background |
| R4 | must_have | GLM experience | direct | none | medium | Built and maintained the young-driver GLM (CV-only) | [grounded] your background |
| R5 | must_have | Presenting to underwriting or actuarial leads | direct | none | medium | Quarterly pricing review to head of underwriting | [grounded] your background |
| R6 | important | Design and read price tests | direct | none | medium | 14 tests last year with underwriting | [grounded] your background |
| R7 | important | Turn results into recommendations for underwriting and product | adjacent | presentation | medium | Recommendations to underwriting shown; product-side work not evidenced | [inferred] |
| R8 | preferred | Insurance experience | direct | none | high | UK motor insurer, 5 years | [grounded] your background |
| R9 | important | Pet-insurance pricing domain (implied by "our pet-insurance product") | absent | transferability | high | No pet work | [grounded] your background; [generic] for pet-pricing differences |

Confidence is `medium` for claims you've stated but I haven't seen evidence for. Each of R2–R6 rises to `high` with a document or work sample.

## Gap recovery queue

- **G1 (R9, pet insurance).** The GLM method and test design transfer. The domain doesn't: species and breed factors, vet-cost inflation, and lifetime versus annual cover are new to you. What would close it: an example of pet-related modelling, or a clear account of how you'd learn the domain fast. Until then, don't claim pet experience.
- **G2 (R7, product side).** Recommendations have reached underwriting, not product. Closing evidence: any example of a recommendation that changed a product decision.

## Opportunity risk register

| ID | Class | Severity | Status | Entry | Provenance |
|---|---|---|---|---|---|
| RR1 | risk_signal | medium | unresolved | **Employer not established.** No L1 check. Possible reasons, none ranked: a small or new firm with a thin web presence, a name collision, or a posting that's out of date. Decision rule: verify through the live posting or careers page before applying. | [inferred] |
| RR2 | unknown | medium | unresolved | **Pay and contract type not stated.** Band not calibrated (no L1 sweep). | [grounded] JD (absence) |
| RR3 | unknown | medium | unresolved | **Decision rights unclear.** The JD says "recommendations", not authority over rates. | [grounded] JD |
| RR4 | positive_signal | — | — | Scope is explicit, with a named hiring manager and specific responsibilities. | [grounded] JD |

## Decision

**`conditional_go`.** Your evidence ledger is strong on the must-haves. The opportunity ledger has an unverified employer and unknown pay. Pet insurance is a real domain gap that no question will close.

Conditions before you apply:
1. The employer is confirmed (RR1).
2. The pay range is known (RR2).
3. Your location meets the UK-remote gate (R1).

## Application plan (proposed, not drafted)

- **Lead with:** the young-driver GLM you built and maintained, the 14 price tests, and the quarterly review to underwriting leads. These map directly to R2–R6.
- **Frame motor as transferable:** the method (GLM, test design, presenting to underwriting) moves across. Name the pet-domain gap yourself before the interviewer does.
- **Don't claim:** pet experience, product-side impact, or any people-management work. The JD doesn't ask for management, so don't volunteer it.
- **Resume language:** proposed only. Nothing goes into a CV or outreach until you approve it.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page (L1) | skipped | L1 not run; needs your consent |
| 2 | Role-family sweep for pay and scope (L1) | skipped | L1 not run; needs your consent |
| 3 | Hiring manager public footprint (L1) | skipped | No L1 run; hiring manager name only, public footprint not searched |

## Upgrade menu

- **L1 research (up to 5 searches, 2 fetches):** verifies Brindlemoor exists and matches the posting, and gives a pay band for this seniority. Closes RR1 and RR2 and calibrates the market line.
- **L2 research (up to 5 more searches, 2 more fetches):** adds funding, leadership churn and recent news. Offered once; I won't repeat it.
- **A pet-related modelling example or work sample:** the artifact that would raise R9 from `absent`.
- **The live posting link:** lets me check RR1 directly.

If you'd like, I can save this as a `tuesday-dossier.md` to carry into prep.

**Questions** (answer any, or say "skip" and I won't re-ask):
1. *(RR1)* Can you paste the live posting link, or the recruiter's email domain?
2. *(RR2)* What's the pay range, and is the role permanent or contract?
3. *(R1)* Are you based in the UK?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.