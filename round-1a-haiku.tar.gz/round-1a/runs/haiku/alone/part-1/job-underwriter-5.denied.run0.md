**Worth applying to, on conditions. Status: `conditional_go`.** Your fit against the posting's stated requirements is strong. What's open is your location and pay floor, which you haven't given me, and whether this employer is verifiable from outside. Research didn't run this session, so that check is still open.

**Research tier:** L1 ran with both search and fetch calls refused, so the employer and market checks are unverified. Nothing below is verified externally.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery as the named platform); unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on)

R7 — a credible bridge, its limit named (BigQuery never used); R1 and R2 — gates unchecked, since your location and pay floor weren't given; R10 and R11 — named in the posting, not yet evidenced in your background.

**Opportunity ledger.** The role is clearly scoped and its posted pay sits inside the recruiter's cited band. The employer is unverified, and the hiring manager isn't named. No severe red flags in the material.

- **Hard gates:** none failed (no `direct` gate rows); unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location meets remote-US or Denver (R1); (2) your base floor sits at or under the posted range, or you accept it (R2); (3) the posting is confirmed live on the company's own careers page or through the recruiter's company domain (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company About page as you supplied it; not checked externally |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts | `[grounded]` JD |
| Scope read | Ownership of one domain (reporting) end to end, with no direct reports stated. Normal for a senior title at this stage | `[inferred]` from the JD's three named systems against the no-reports silence; `[generic]` for the pattern |
| Compensation | Posted $148,000–$166,000 plus equity; equity unquantified | `[grounded]` JD |
| Market calibration | Posted midpoint ($157,000) sits inside the $139,000–$163,500 IQR and above the $151,000 median | `[generic]` Datawright 2026 report from your recruiter (US, n=2,310, Series B–D senior DE); not a search |
| Hiring manager | Not named in the posting | `[grounded]` JD |
| Unknowns | Employer verification; hiring manager; your location; your pay floor; equity size; contract basis | — |
| Contradictions | None found between the JD and the company text you supplied | `[grounded]` both as you pasted them |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | No candidate location given; gate can't be read | `[grounded]` JD; no candidate statement | Q1 |
| R2 | Pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor not given; posted range is inside the band | `[grounded]` JD; `[generic]` band from report | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported in intake; no artifact | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; self-reported | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | About 180 models built on Snowflake; self-reported | `[grounded]` your background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; the BigQuery specific is R7 | `[grounded]` your background; `[inferred]` Snowflake meets the generic term | none |
| R7 | BigQuery warehouse (JD body) | important | adjacent | medium | transferability | dbt and SQL carry over; BigQuery-specific operation not exercised | `[inferred]` from the Snowflake dbt work; `[generic]` on what the platform change costs | G1 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow set up and run for orchestration; self-reported | `[grounded]` your background | none |
| R9 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up; self-reported | `[grounded]` your background | none |
| R10 | Ingestion from app and CRM (JD body) | important | unclear | low | discovery | Your background doesn't name app or CRM sources | `[grounded]` your background is silent on these | G2 |
| R11 | Data contracts analysts depend on (JD body) | important | unclear | low | discovery | Not named in your background; dbt tests could be adjacent | `[grounded]` silence; `[inferred]` dbt adjacency | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R7) | transferability | Snowflake dbt work, never on BigQuery. Limit: BigQuery's cost and partitioning model and GCP tooling not exercised | Named in the JD body, not the requirement list; a platform ramp is visible in interview | Any BigQuery exposure, even a sandbox or a migrated model | A sandbox dbt project, a BigQuery migration note | `[inferred]` from your background; `[generic]` on the platform gap |
| G2 | App and CRM ingestion (R10) | discovery | No ingestion sources named | Ingestion is the first responsibility in the posting | Pipelines from a product database, event streams, or a CRM API | An architecture diagram, a source inventory | `[grounded]` silence in your background |
| G3 | Data contracts (R11) | discovery | Data quality testing is evidenced; consumer-facing contracts aren't | Analysts depend on these; interviewers probe ownership | Schema agreements with consumers, breaking-change notice, versioning | A contract doc or a schema-change process | `[grounded]` silence; `[inferred]` dbt and GE adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team not named | unknown | — | (no name in posting) | The reporting line and team may be set after the posting | `[generic]` common in postings of this kind | Who is the hiring manager, and which team would this role sit in? | unresolved |
| RR2 | Employer not verified from outside | unknown | — | "Pellucid Learning runs live online tutoring…" | The company's own description may be accurate; research couldn't check it | `[grounded]` research refused this session | Which careers page or job board carries this posting? | unresolved |
| RR3 | Posted pay sits inside the band | positive_signal | — | "$148,000–$166,000" | The range is within the market band for this title | `[generic]` band from report | What base is budgeted at the top of the range? | noted |
| RR4 | Scope names specific systems and outputs | positive_signal | — | "Build and run the pipelines…" | Ownership is defined, not a bundle of roles | `[inferred]` from the JD's named systems | none needed | noted |

No request for payment, deposit, bank or ID details, or chat-only hiring appears in the material.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Name BigQuery honestly as the platform you haven't run; show Snowflake dbt depth | See R7; claiming BigQuery would be inflation | `[grounded]` R7 row | pending your approval |
| P1 | Before applying, ask the recruiter for the live posting link and the company's careers page | See RR2; this verifies the employer | `[generic]` standard verification step | pending your approval |
| P2 | Ask the recruiter for the hiring manager's name and team | See RR1 | `[grounded]` RR1 | pending your approval |
| P3 | Build a short BigQuery sandbox project, or a single dbt model on BigQuery, to turn G1 into a live example | Closes the limit with an artifact | `[inferred]` from G1 | pending your approval |

Every row is a proposal. None are drafted language yet.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetch of the careers page and two company searches were refused. Would have checked that the employer exists, that the posting is live, and the RR2 status |
| 2. Role-family sweep | unavailable | Salary and scope searches were refused. Would have replaced the recruiter's report with a second market source for the calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Your location and base floor → R1 and R2 close; the decision moves to `go` or `no_go`.
- The live posting link, or the recruiter's confirmation from the company's domain → RR2 closes; the employer condition clears.
- Permission to run the refused research calls → target 1 verifies the employer, and target 2 adds a second market source for the pay calibration.
- Any BigQuery touch, even a sandbox → R7 moves toward `direct`.
- A concrete example of app or CRM ingestion, or a data contract you've maintained → R10 and R11 move off `unclear`.

I can write this analysis to `tuesday-dossier.md` if you want a copy to keep.

**Questions**

R1 — Where are you based, and can you work fully remote in the US or from Denver?
R2 — What base salary is your floor, and does equity change how you'd weigh a base below it?
R10/R11 — Have you built ingestion from an operational app or a CRM, and have you owned data contracts with consumers (schema versions, breaking-change notice)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.