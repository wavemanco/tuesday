## Decision snapshot

**Worth applying, on conditions. Status: `conditional_go`.**

The core of the role matches your background closely. The two places it doesn't are both `must_have` requirements, and the posting names them outright. Applying costs little, so the question is whether you can answer those two gaps honestly in an interview.

**Fit ledger.**

- `must_have`: direct R1, R2, R3 · adjacent R4, R5
- `important`: direct R6, R7
- `hard_gate`: unclear R8, R9
- `preferred`: none listed

**Opportunity ledger.** Specific and mostly well described: the outcomes are explicit, and the salary is disclosed. The scope is broad for one lead: CRM data, billing data, pipeline and renewal reporting, and a quarterly forecast run with the CFO. Who else sits on the team is not stated, and neither is who owns billing day to day. The posting sits on a third-party board, and the employer is not yet verified.

- **Hard gates:** none failed; unconfirmed: R8 (Bristol hybrid, two days a week in the office), R9 (£61,500–£67,000 against your floor). Your constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found in the posting itself.
- **Conditions for go:**
  1. Verify Quillfield and the live posting through its own site or the recruiter's email domain (RR3).
  2. Confirm the location and salary floor (R8, R9).
  3. Present forecast and billing work as adjacent, never as owned (R4, R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, an invoicing software company, Bristol | `[grounded]` posting and your statement |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| First-year outcomes | None stated | — |
| Working pattern | Hybrid, two office days a week in Bristol | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | Three functions in one lead post (sales ops, billing data, finance forecasting) is broad | `[inferred]` from the mandate list |
| Market calibration | Not established. This run used no research, so I'm not giving a pay or scope band from memory | — |
| Unknowns | Team size; reporting line; who owns billing data today; whether the forecast is built in Excel or a planning tool; hiring manager (recruiter named Tamsin Achebe, nothing further checked) | — |
| Contradictions | None found in the posting | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | high | none | Five years in sales ops, the last two running UK RevOps. The one nuance is that your company is B2B payments, not software. Say that plainly | `[grounded]` your statement | State the payments context in the first line |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards | `[grounded]` your statement | Have the certification details ready |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily are stated. Modelling depth (scenarios, driver-based models) is not described, so expect a probe | `[grounded]` your statement | Prepare one example model you built |
| R4 | Experience owning a forecast; quarterly forecast with the CFO | must_have | adjacent | high | capability | You have never owned the company forecast; finance did. The monthly pipeline review with the sales director is forecast-adjacent, not forecast ownership | `[grounded]` your statement; `[inferred]` adjacency | See gap G1 |
| R5 | Experience working with finance on billing or revenue data | must_have | adjacent | medium | transferability | Pipeline and renewal data is revenue-related. You have never worked on billing data, and the finance collaboration is not described | `[grounded]` your statement; `[inferred]` adjacency | See gap G2 |
| R6 | Own CRM data | important | direct | high | none | Salesforce admin and dashboard rebuilds | `[grounded]` your statement | none |
| R7 | Build pipeline and renewal reporting for sales and finance | important | direct | high | none | Rebuilt both pipeline and renewal dashboards. The finance audience is not described, so that part is untested | `[grounded]` your statement | none |
| R8 | Bristol hybrid, two office days a week | hard_gate | unclear | high | hard_gate | Your location and commute tolerance were not stated | `[grounded]` posting; your constraint not given | Answer question Q1 |
| R9 | Pay of £61,500–£67,000 against your floor | hard_gate | unclear | high | hard_gate | The posted range is known; your floor was not given | `[grounded]` posting; your constraint not given | Answer question Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R4, must_have) | capability | Pipeline review is a monthly process with the sales director; no company forecast ownership | It is named twice in the posting: as a requirement and as a quarterly responsibility | Any time you supplied pipeline inputs, weighted the pipeline, or checked a forecast against outcomes | Your pipeline review's inputs, or a forecast comparison you made | `[grounded]` your statement; `[inferred]` adjacency |
| G2 | Billing and finance revenue data (R5, must_have) | transferability | Renewal and pipeline work with no billing data | Billing data ownership is listed as a core responsibility | Reconciling renewals or pipeline with invoices or billing exports, even informally | A reconciliation example, or a finance-facing report you produced | `[grounded]` your statement; `[inferred]` adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Broad scope for one lead | risk_signal | medium | "own our CRM and billing data"; "run the quarterly revenue forecast with the CFO" | The role may be the whole revenue-ops function in one post, with no team beneath it | `[inferred]` from the mandate list | Who else is on the revenue team, and what does this role own alone? | unresolved |
| RR2 | Billing data ownership unclear | unknown | — | "own our CRM and billing data" | Billing may sit with finance, with this role owning only the reporting | `[inferred]` from the mandate list | Which team owns the billing system and its data day to day? | unresolved |
| RR3 | Employer not verified | unknown | — | Posting on a third-party board (jobs.tallyboard.example) | Quillfield exists as described, but this is unconfirmed. It may be a repost or a mismatch | `[generic]` boards repost roles | Is the posting on Quillfield's own careers page, or can the recruiter confirm from a company email domain? | unresolved |
| RR4 | Salary disclosed | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is set and negotiable inside the range | `[grounded]` posting | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting and employer through Quillfield's careers page or the recruiter's company email domain | see RR3 | `[generic]` | proposed |
| A2 | Lead with the pipeline and renewal dashboard rebuild and the Salesforce admin certification | strongest direct evidence (R2, R6, R7) | `[grounded]` your statement | pending your approval |
| A3 | Describe the monthly pipeline review as pipeline inspection, not forecasting | avoids claiming forecast ownership you don't have (R4) | `[grounded]` your statement | pending your approval |
| A4 | Prepare one SQL or Excel model you built | answers the modelling probe (R3) | `[inferred]` | pending your approval |
| A5 | Ask the recruiter who owns billing data, who the CFO partner is, and how the forecast is built | resolves RR1 and RR2 before the loop | `[inferred]` | pending your approval |

No CV wording is drafted yet. Any CV or outreach text will be proposed first, and nothing goes out without your approval. Avoid writing "forecasting experience" or "billing data experience" unless a real example backs it.

## Evidence status

Verified: none yet. Every claim so far is your own statement, unverified.

Research tier: L0 — no searches; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would confirm the employer and the live posting (RR3). Research was offered but not run |
| 2. Role-family sweep | skipped | Would set market calibration for pay and scope. Not run |
| 3. Hiring manager's public footprint (Tamsin Achebe) | skipped | Would inform the scope read and which story to lead with. Not run |

## Upgrade menu

- Consent to L1 research: up to 5 searches and 2 page fetches covering Quillfield's existence and careers page, a role-family pay and scope sweep for Bristol, and Tamsin Achebe's public professional footprint. This would move RR3, the market calibration, and the scope read.
- Quillfield's own careers page link, or the recruiter's email domain → RR3 closes.
- Your location and salary floor → R8 and R9 resolve.
- A forecast or billing example, even partial or informal → R4 and R5 rise.
- Salesforce certification name and date → R2 becomes easier to cite.

Offer: I can write this up as a `tuesday-dossier.md` so it's saved with the verification questions and the application plan.

**Questions**

- **Q1 (R8, R9):** Can you work from Bristol two days a week, and does £61,500–£67,000 meet your floor?
- **Q2 (R4):** Have you ever built or checked a revenue forecast or bookings projection that finance or the CFO used, even as one input?
- **Q3 (R5):** Have you reconciled pipeline or renewal data against invoices or billing exports, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.