**Yes, it's worth applying, once three checks clear. Status: `conditional_go`.** Your must-have skills match the posting well. The real gaps are BigQuery, app/CRM ingestion and data contracts, and two things I can't check yet: your location and pay floor. Web research was refused in this session, so the employer is unverified.

- **Fit ledger**
  - `hard_gate` — unclear: R1 (remote US or Denver), R2 (base within $148,000–$166,000)
  - `must_have` — direct: R3 (5+ years), R4 (SQL and Python), R5a (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
  - `important` — adjacent: R5b (BigQuery); unclear: R8 (app and CRM ingestion), R9 (data contracts)
- **Fit reads:** R3, R4, R5a, R6 and R7 are the must-haves you already use, at `medium` until probed; R5b is Snowflake-to-BigQuery, a bridge with its limit named; R8 and R9 have no evidence yet.
- **Opportunity ledger:** RR1 is a positive signal: the stated range sits inside the reported band. RR2 (employer and posting not checked live), RR3 (equity terms unstated) and RR4 (no hiring manager named) are open.
- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (base range $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR2: the live posting confirmed on pellucidlearning.com's own careers page; (2) R1: your location fits remote-US or Denver; (3) R2: a base in the $148,000–$166,000 range meets your floor.
- **What would change this:** if R1 or R2 fails, the status becomes `no_go` on that gate alone. If the posting can't be confirmed live, it stays `conditional_go` until you verify it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` the About text you pasted; not checked live |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse on BigQuery, and analyst data contracts | `[grounded]` JD |
| Scope read | Ownership of the reporting pipelines end to end; no reports mentioned | `[inferred]` from the JD's listed responsibilities |
| Seniority | "Senior" with 5+ years, against the report's 5–8 years for the title | `[generic]` pay report as you relayed it |
| Market calibration | Stated range midpoint ~$157,000 against a ~$151,000 median and $139,000–$163,500 IQR. The top of the range ($166,000) sits slightly above the IQR | `[generic]` Datawright 2026 report, US, n=2,310, Series B–D, as you summarized it; not searched |
| Unknowns | Equity terms; team size; whether the role has peers or is the sole owner; hiring manager | — |
| Contradictions | None between the JD and About text as you pasted them. Live check unavailable | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location wasn't given | `[grounded]` JD | Q1 |
| R2 | Base within $148,000–$166,000 (your floor) | hard_gate | unclear | none | hard_gate | Your floor wasn't given; the range sits inside the reported band | `[grounded]` JD; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, no artifact, so probe-able | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5a | dbt and a cloud warehouse | must_have | direct | medium | none | 180-model dbt project on Snowflake | `[grounded]` your background | none |
| R5b | BigQuery warehouse (named in the JD description) | important | adjacent | medium | transferability | Snowflake and dbt carry over; no BigQuery experience. Limit: no BigQuery work claimed | `[grounded]` background; `[inferred]` the limit | G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration | `[grounded]` background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` background | none |
| R8 | Ingestion from app and CRM (JD description) | important | unclear | none | discovery | No ingestion work stated | `[grounded]` JD; CV silent | G2, Q3 |
| R9 | Data contracts analysts depend on (JD description) | important | unclear | none | discovery | Not stated; dbt tests may be adjacent | `[inferred]` | G2, Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5b) | transferability | Snowflake and dbt work; no BigQuery | The JD names BigQuery, so the bridge's limit will be probed | Any dbt model or pipeline you ran on another cloud warehouse; any BigQuery exposure, even a sandbox | A dbt repo, a sample model, or a cost or partition note | `[inferred]` bridge from the Snowflake work; `[generic]` that interviewers probe the named warehouse |
| G2 | App and CRM ingestion; data contracts (R8, R9) | discovery | Nothing stated | Both are in the job description's first sentence | Pipelines from a product database or a CRM; schema agreements with downstream analysts | A pipeline diagram, a contract or schema doc | `[grounded]` JD; `[inferred]` that the gap is real |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay inside the reported band | positive_signal | — | "$148,000–$166,000 plus equity" | The base is market-normal for a senior role at this stage | `[generic]` pay report; `[grounded]` JD | — | noted |
| RR2 | Employer and posting not checked live | unknown | — | "pellucidlearning.com/careers/senior-data-engineer" | The posting and the company facts are as you supplied them | `[grounded]` your materials; live check unavailable | Can you point me at this role on your careers page, and who would I be interviewing with? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Equity could be a material part of total pay | `[inferred]` from the posting's silence | What equity is offered, on what vesting schedule, and at what strike price? | unresolved |
| RR4 | No hiring manager named | unknown | — | (posting silent) | No reporting line is visible from the posting | `[inferred]` from the posting | Who would I report to, and who is the hiring manager? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting on the careers page before applying | RR2 | `[grounded]` RR2 | proposed |
| A2 | Lead with dbt, Airflow and Great Expectations | R3, R5a, R6, R7 | `[grounded]` background | proposed |
| A3 | Name BigQuery as the limit and the Snowflake-to-BigQuery bridge; don't claim BigQuery experience | R5b | `[grounded]` background; `[inferred]` the limit | proposed |
| A4 | Ask about ingestion and contracts in the first recruiter call | R8, R9, RR4 | `[generic]` pattern for this kind of role | proposed |

## Evidence status

Verified: none yet. Your background is CV-equivalent self-report until you confirm specifics.

Research tier: L1 — searches 2 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning tutoring Denver Series C funding" and "\"Pellucid Learning\" live online tutoring K-12"; fetched the careers posting and the About page. Every call was refused for lack of web permission, so the posting and company facts remain as you supplied them. Would have moved: the organization row and RR2 |
| 2. Role-family sweep | skipped | Your summary of the pay report fixes the calibration; no search was sent. Would have moved nothing new |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- **Live check of the posting and company** (if you grant web access): RR2 closes, and the organization row moves from your materials to verified.
- **Your location and pay floor:** R1 and R2 close, and the decision moves to `go` or `no_go`.
- **Equity terms:** RR3 closes, and total pay becomes calculable.
- **A hiring manager's name:** RR4 closes and shapes the scope read.
- **A BigQuery sample or a dbt repo:** R5b moves toward `direct`.
- **A deeper research pass** on Pellucid's funding and leadership (up to 5 searches and 2 fetches), if web access is granted.

If you want to keep this and carry it into prep, I can write it up as a `tuesday-dossier.md`.

Q1 (R1): Are you based in the US, and is remote-from-US or the Denver office workable for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (R2): Does a base salary between $148,000 and $166,000 meet your floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 (R8, R9): Have you built or owned ingestion from a product database or a CRM, or defined data contracts analysts relied on? If so, name the systems and what you owned.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.