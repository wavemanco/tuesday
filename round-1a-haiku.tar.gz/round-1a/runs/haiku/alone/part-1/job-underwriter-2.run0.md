**Worth applying to, on conditions. Status: `conditional_go`.** Pivoting isn't a waste of time. This posting is a stretch, though, mainly because of the 3+ years PM line, which you don't meet on its face. Apply only if you can back a product-ownership story with evidence, and only after the recruiter confirms whether the line is firm.

**Fit ledger.**

- `hard_gate`: none stated. You gave no constraints (location, work authorization, pay floor), so hard-gate checks are unknown.
- `must_have`: direct: R3, R4 · adjacent: R2 · absent: R1 · unclear: R5
- `important`: direct: R6 · adjacent: R7, R8, R10 · unclear: R9

**Opportunity ledger.** Scope is clear and the domain fits yours: a partner-facing API platform, two engineering squads, and sales and support coordination. The unknowns are whether the 3+ years line is a real screen, whether a senior PM sits above the role, and compensation, which the JD does not give. No red flags are visible in the text you provided.

- **Hard gates:** none failed; checks against your constraints are unknown until you give them.
- **Severe red flags:** none found.
- **Conditions for go:** (1) a concrete product-ownership story you can evidence, or a recruiter signal that the 3-year line is negotiable; (2) you describe your past work as discovery and spec-writing for integrations, never as product ownership.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your summary; not checked against the web |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs for two engineering squads; define adoption metrics; coordinate launches | `[grounded]` JD |
| Scope read | A platform PM over two squads at this size is a normal single-owner remit | `[inferred]` from squad count against stated duties |
| Market calibration | Platform PM postings at this stage often ask for 3+ years of PM experience | `[generic]` pattern, not a claim about this employer |
| Unknowns | Whether a senior PM or head of product sits above the role; compensation; location and contract terms | — |
| Contradictions | None in the material provided | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must_have | absent | high | transferability | You have no PM title or PM years. Your nearest equivalent is integration and implementation lead | `[grounded]` your statement | Q1 below |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You delivered 30+ client integrations of your company's REST APIs. You shipped integrations to clients, not a product you owned | `[grounded]` CV, candidate-stated | Work sample W1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI, and integration architecture on the CV | `[grounded]` CV, candidate-stated | Work sample W1 would raise to high |
| R4 | Stakeholder management across engineering, sales, customers | must_have | direct | medium | none | You coordinated your engineers, client engineers, and PMs across 30+ builds. Sales is not named on the CV | `[grounded]` CV | Confirm sales interaction (Q3) |
| R5 | Agile delivery experience | must_have | unclear | low | discovery | The CV is silent on sprints or ceremonies | `[grounded]` CV silence | Q2 below |
| R6 | Partner discovery | important | direct | medium | presentation | Scoping workshops, requirements documents, and quarterly client feedback sessions are discovery under another name | `[inferred]` from CV duties | Reframe as discovery (see audit note in the plan) |
| R7 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | You wrote requirements and integration architecture and coordinated engineers. You did not own a backlog | `[grounded]` CV | W1 |
| R8 | Own the roadmap | important | adjacent | medium | capability | You ran roadmap-input sessions. You did not own the roadmap | `[grounded]` CV | Q1 |
| R9 | Define and track adoption metrics | important | unclear | low | capability | No metric on the CV. SQL is a tool for this, not evidence of it | `[grounded]` CV silence | Q1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | presentation | You ran UAT and go-live for each client. Launch coordination with sales and support is not stated | `[grounded]` CV | Q3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM years (R1) | transferability | No PM title or years | This is the line most likely to get you screened out | Any feature, integration program, or tool you scoped, prioritized, or tracked to outcome | A sanitized spec, roadmap, or adoption figure | `[grounded]` CV; `[generic]` on how screening works |
| G2 | Adoption metrics (R9) | capability | Nothing on the CV | The JD makes this a responsibility. Without it, the product story is thin | Go-live counts, time-to-integrate, partner retention from your playbook | A metric you can state and source | `[inferred]` |
| G3 | Owned roadmap (R8) | capability | Ran input sessions only | Distinguishes a PM from a discovery lead | Any prioritization decision you made alone | A roadmap or priority list you authored | `[grounded]` CV |

The gap queue holds no questions. The questions are in the closing block, tagged by row.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | 3+ years PM as a must-have | risk_signal | high | "3+ years product management experience (must-have)" | The line may be an ATS or recruiter screen, not a hiring-manager preference | `[inferred]` from the must-have label; `[generic]` on screening practice | Is 3+ years a firm screen? | unresolved |
| RR2 | Senior PM above the role unknown | unknown | — | — | If a senior PM owns the roadmap, the role is narrower than the JD reads | `[inferred]` from the JD's ownership language | Who does this role report to, and who sets platform priorities? | unresolved |
| RR3 | Compensation absent | unknown | — | — | The band is unknown until stated | `[grounded]` JD omits pay | What is the budgeted range? | unresolved |
| RR4 | Clear, partner-facing scope | positive_signal | — | "Own the roadmap for our partner-facing API platform" | A defined, customer-facing platform suits integration experience | `[grounded]` JD | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter whether the 3+ years line is firm before you invest in the loop | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Frame your work as "ran discovery and requirements for 30+ partner integrations." Do not say "product manager experience" or "owned the roadmap." Check every verb: "led" should mean you led, not that you coordinated | R6, R8; reframing audit | `[grounded]` CV | pending your approval |
| A3 | Write one sanitized work sample: a spec or requirements document for a partner API feature | R2, R3, R7 | `[grounded]` CV | pending your approval |
| A4 | Build the product story from G1–G3 evidence only | G1–G3 | `[inferred]` | pending your approval |
| A5 | Target adjacent titles too: platform or integration PM, technical PM, or partner-facing product roles, where your stated experience is the ask | Fit is stronger there | `[generic]` pattern | pending your approval |

Every row is a proposal. Nothing goes outside this conversation without your approval.

**Evidence status**

Verified: none yet. Every claim above rests on your statement or the CV you gave me. The triage tool is an unverified prior-context lead. I have not counted it as evidence.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | I did not search because you asked about fit. Quartzline's existence and the live posting are unchecked |
| 2. Role-family sweep | skipped | Market calibration above is a pattern, not a measured band |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer.** If you want this kept as a `tuesday-dossier.md` for tracking or interview prep, say so and I'll produce it.

**Upgrade menu**

- **Live posting or Quartzline careers link:** confirms the role exists and whether the 3+ years line is repeated. Unlocks the employer-existence check.
- **Research at L1:** Quartzline's stage and product, and the typical PM remit and pay at this stage. Unlocks a measured market calibration and a salary comparison, which the JD does not give.
- **Work sample (sanitized spec or requirements doc):** raises R2, R3, and R7 from medium to high. This is the strongest single artifact you could add.
- **Adoption figure from your playbook or any tool:** unlocks R9 and G2.
- **Your constraints (location, work authorization, pay floor):** unlocks the hard-gate checks.

**Questions**

1. **(R1, R8, R9)** Have you ever been accountable for a product, tool, or feature's priorities or adoption, even internally? If so, what was the outcome?
2. **(R5)** Did your delivery work run in sprints or another agile cadence with engineering? Describe it in a sentence or two.
3. **(R4, R10)** Did you work directly with sales or support on launches? If so, what did that look like?

Reply with answers, say "skip" for any question, or ask me to run L1 research.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.