**Worth applying: `conditional_go`.** Your stated requirements match well, and the pay sits inside the market band. Two of your own constraints (location and pay floor) aren't in the material yet, and the employer's details come only from its own site.

**Decision snapshot**

**Fit ledger.**
- `hard_gate`: unclear: R1 (location: remote US or Denver), R2 (pay floor against $148k–$166k)
- `must_have`: direct: R3 (5+ years), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R10 (data contracts); unclear: R9 (ingestion from app and CRM); absent: R8 (BigQuery)

R8 is the one real capability gap, and the posting only names BigQuery in the role description. Its requirements line says "a cloud warehouse."

**Opportunity ledger.** Sound and live. Pay is market-normal, the scope is ambitious but describable, and the posting is consistent across sources. The employer rests on its own site only (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (location), R2 (pay floor). Candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm your location and pay floor against R1 and R2; (2) corroborate the company beyond its own site before investing in a loop (RR1); (3) present BigQuery as transferable from Snowflake, not as experience you have.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees | `[grounded]` company About page (the company's own site) |
| Posting | Live; "Accepting applications"; text matches your brief | `[grounded]` careers page, fetched |
| Mandate | Pipelines for tutoring-platform reporting: ingestion from app and CRM, a dbt warehouse in BigQuery, data contracts for analysts | `[grounded]` posting |
| Compensation | $148k–$166k base (midpoint $157k) plus equity, which is unquantified | `[grounded]` posting |
| Market calibration | Report median $151k, IQR $139k–$163.5k. The midpoint sits inside the IQR, slightly above the median | `[generic]` Datawright 2026 report (n=2,310), via search and your recruiter's copy |
| Scope read | Ownership of the platform's reporting pipelines across ingestion and contracts. The report's typical scope is one domain with no direct reports. This posting reads broader, and it names no reports | `[inferred]` posting against `[generic]` report scope |
| Hiring manager | Not named | `[grounded]` posting |
| Unknowns | Equity value; reporting line; whether "data contracts" means enforced schemas or documentation; BigQuery usage expected in year one | — |
| Contradictions | None between the posting and the About page | `[grounded]` both fetched or read |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: remote US or Denver | hard_gate | unclear | none | hard_gate | Your location is not in the material | `[grounded]` posting; no candidate claim | Ask location (Q1) |
| R2 | Pay at or above your floor | hard_gate | unclear | none | hard_gate | Your floor is not in the material. The posted range is the figure the check runs against | `[grounded]` posting; no candidate claim | Ask floor (Q2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported | `[grounded]` your brief | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, self-reported | `[grounded]` your brief | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so this meets the requirement as written | `[grounded]` your brief; `[inferred]` that "a cloud warehouse" is satisfied by Snowflake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, self-reported | `[grounded]` your brief | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. "Set up" is not "owned long-term," so I did not upgrade it | `[grounded]` your brief | none |
| R8 | BigQuery | important | absent | low | transferability | You have never used it. The posting names it in the role description, not the requirements | `[grounded]` your brief and posting | Walk through the Snowflake-to-BigQuery bridge (G1) |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | No claim in your brief | `[inferred]` from the posting's mandate | Ask (Q3) |
| R10 | Data contracts analysts depend on | important | adjacent | low | transferability | dbt tests and GE validation are close to contracts, but you have not described contracts with consumers | `[inferred]` adjacency from R5 and R7 | Ask (Q3) |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | No BigQuery use; Snowflake and dbt are direct | The posting names BigQuery as the warehouse, so it will come up | Your Snowflake modelling, partitioning and cost decisions, and how you'd map them to BigQuery's model | A short written note on your Snowflake-to-BigQuery mapping, or a dbt project you ran on another warehouse | `[inferred]` from your brief; `[generic]` that BigQuery's cost and partitioning model differs from Snowflake's |
| G2 | Ingestion and contracts (R9, R10) | discovery | Nothing about app or CRM ingestion, or consumer-facing contracts | These are two of the three named responsibilities | Any ingestion you owned from a product database or a SaaS source; any schema agreement with a downstream team | A sanitized pipeline diagram or a contract doc | `[inferred]` from the posting |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer footprint rests on its own site | unknown | — | "Series C ($52M, February 2026)" | The company may be as described; no independent confirmation was found | `[grounded]` one search for the Series C returned only the About page | Can your recruiter send a press or investor link, and confirm the email domain? | unresolved |
| RR2 | Posted pay sits in the market band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is market-normal, not a low-ball | `[grounded]` posting and report; `[inferred]` the comparison | Is equity a typical grant for this stage? | noted |
| RR3 | Scope broader than the typical senior remit | risk_signal | low | "ingestion from our app and CRM, … a dbt-modelled warehouse …, and the data contracts" | You could own more than one domain with no defined reporting line | `[inferred]` from the posting against `[generic]` report scope | Who would you report to, and which domains are yours alone? | unresolved |
| RR4 | BigQuery is named in the role but not required | risk_signal | low | "a dbt-modelled warehouse in BigQuery" | Interviewers may probe BigQuery directly even though the requirement is "a cloud warehouse" | `[grounded]` posting; `[inferred]` interview probe | Would BigQuery be learned on the job? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for location eligibility, the reporting line, and the equity terms before the loop | R1, R2, RR3 | `[grounded]` rows | pending your approval |
| A2 | Ask for an independent link on the Series C and the email domain | RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Positioning line for R8: "Six years on Snowflake and dbt; I haven't used BigQuery, and I expect dbt skills to transfer" | Keeps the gap honest and visible | `[inferred]` from R8 and G1 | pending your approval |
| P2 | Lead with the dbt build and the GE suite as the data-quality story for R5 and R7 | Strongest verified-by-description evidence | `[grounded]` R5, R7 | pending your approval |

**Evidence status**

Verified: none yet. Your brief is self-reported. Confirmation of R3 through R7 would come from an artifact or a probe answer.

Research tier: L1 — searches 5 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer job" (found the careers page) and "Pellucid Learning Series C funding 2026" (returned only the About page); also searched "Pellucid Learning live online tutoring K-12 Denver" (no results). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The posting is live and matches the brief. RR1 is filed because the company's claims rest on its own site. |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer base salary median Series B D companies 2026 pay report"; it returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report). Feeds the market calibration line and RR2. |
| 3. Hiring manager's public footprint | n/a | No name in the posting, so there was no query to form. |

**Upgrade menu**

- Your location and pay floor → R1 and R2 close, and the status can move to `go` or `no_go`.
- An independent link on the Series C (press, investor page) → RR1 closes.
- A sanitized Snowflake-to-BigQuery note, or any ingestion or contract example → R8, R9 and R10 move, and G1 and G2 close.
- The hiring manager's name → the scope read and the positioning can be tailored to that reader.
- A deeper research pass on Pellucid (funding history, leadership, employee reports, up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can also put this into a `tuesday-dossier.md` file for later use.

Questions (answer any or all in one reply; "skip" is a valid answer):

1. **R1:** Where are you based, and can you work remote in the US or from Denver?
2. **R2:** What is your base-pay floor, and does the $148k–$166k range clear it?
3. **R9, R10:** Have you owned ingestion from an app or CRM, or agreed a schema contract with a downstream team? If so, what did you ship?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.