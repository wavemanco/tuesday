**Short answer: yes on fit, not yet on the gates. Hold until two questions are answered and the employer is checked.** `hold_pending_answers`

Your requirement-level fit is strong. Two hard gates are unsettled, though: your location and work authorization, and your pay floor. Both could change the answer, so I'd settle them before investing in the loop.

## Decision snapshot

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Fit ledger**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Base pay against your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (Strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar), R8 (Data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R9 (Ingestion from the app and CRM), R10 (Data contracts analysts depend on)

R6 — adjacent, Snowflake work carries over, BigQuery's limit named; R9 and R10 — unclear, nothing in your background yet; R1 and R2 — gates not established, see the hard-gates line.

**Opportunity ledger.** RR4, RR5 and RR6 read positive: a stated pay range, concrete scope, and a stated Series C. RR2 and RR3 are unknowns (equity terms, no named manager). RR1 is the one that caps the decision: the employer is not verified from here.

**What would change this:** R1 and R2 answered (a no on either is a hard fail and moves this to `no_go`); RR1 cleared by the live posting on Pellucid's careers page; R9 and R10 shown by an artifact or a clear answer. If the gates clear and RR1 verifies, I'd expect `conditional_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; Denver; founded 2016; 264 employees; Series C, $52M, February 2026 | [grounded] your pasted company page; not independently checked |
| Mandate | Build and run pipelines for the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts | [grounded] JD |
| Scope read | Ownership of a reporting domain's pipelines, no reports named | [inferred] from "build and run" with no team stated |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" usually 5–8 years; one domain's pipelines, no direct reports. Your 6 years sit in the usual band | [generic] Datawright 2026 report from your recruiter (US, n=2,310) |
| Pay against market | Posted range $148,000–$166,000: its top sits above the report's IQR top ($163,500); its midpoint ($157,000) sits above the median | [grounded] JD range against [generic] band |
| Unknowns | Equity terms, hiring manager, location eligibility, whether BigQuery is needed on day one | — |
| Contradictions | Not checked: JD against the careers page (web search unavailable this run) | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office; your eligibility | hard_gate | unclear | none | hard_gate | Your location and work authorization were not given, so the gate is not established | [grounded] JD | Q1 |
| R2 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | No floor stated; the range sits above the report median | [grounded] JD; [generic] band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; intake prose, not yet probed | [grounded] your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported; no artifact seen | [grounded] your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models; stated, not inspected | [grounded] your background | Upgrade: sanitized dbt excerpt |
| R6 | BigQuery warehouse (in JD scope, not its Requirements list) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery-specific work not done; limit named | [inferred] adjacency from R5; [grounded] "Never used BigQuery" | Draft line A3 |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow used for orchestration; stated | [grounded] your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; stated | [grounded] your background | Upgrade: suite config excerpt |
| R9 | Ingestion from app and CRM (JD scope) | important | unclear | none | discovery | Background silent on app or CRM sources | [inferred] from JD scope sentence | Q3 |
| R10 | Data contracts analysts depend on (JD scope) | important | unclear | none | discovery | Background silent on contracts | [inferred] from JD scope sentence | Q3 |

Intake prose is CV-equivalent, so `medium` is the ceiling and nothing is verified yet.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | Snowflake dbt work; no BigQuery | A reviewer will probe BigQuery-specific cost and dialect choices | Snowflake cost or performance tuning; a BigQuery sandbox or course project | A dbt project run on BigQuery, even small | [inferred] bridge from R5; [generic] that BigQuery cost work is a common probe |
| G2 | App and CRM ingestion (R9) | discovery | Background silent | Core of the role's first scope | Any pipeline from a product database or a CRM into a warehouse | Pipeline diagram, DAG, or a sanitized config | [inferred] from JD scope |
| G3 | Data contracts (R10) | discovery | Background silent | Analysts depend on it, per the JD | Schema agreements, tests on published models, breaking-change handling | A contract doc or dbt schema tests | [inferred] from JD scope |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified this run | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The posting may be stale, or may not represent a live hiring employer; the company facts are only the pages you pasted | [generic] pattern for companies of this size, not a claim about this one | Is this role live on your own careers page, and who would the hiring manager be? | unresolved |
| RR2 | Equity offered with no terms | unknown | — | "plus equity" | Equity could be material to total pay and is unquantified | [inferred] from "plus equity" with no terms | What equity is offered for this role, and on what vesting schedule? | unresolved |
| RR3 | No hiring manager named | unknown | — | (posting names no hiring manager) | Reporting line and roadmap ownership unknown | [generic] pattern for postings without a named manager | Who would I report to, and who owns the reporting pipeline's roadmap? | unresolved |
| RR4 | Pay range stated | positive_signal | — | "$148,000–$166,000 plus equity" | Transparency; the range sits above the report median | [grounded] JD against [generic] band | Is this range the approved budget for the role? | noted |
| RR5 | Scope named concretely | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse … data contracts" | Scope is concrete and fits a pipeline-owner role | [grounded] JD | Which of these three would I own from day one? | noted |
| RR6 | Funding stated | positive_signal | — | "Series C ($52M, February 2026)" | Funded, though self-published and not independently checked | [grounded] company page as you pasted it | What does this round fund, and is this role in that plan? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open Pellucid's careers page; confirm the role is live and the recruiter's email domain matches | RR1 | [grounded] RR1 | your action |
| A2 | Settle location eligibility and your base floor with the recruiter before investing in the loop | R1, R2 | [grounded] gate rows | your action |
| A3 | BigQuery line, as written: "Built our dbt project on Snowflake, about 180 models. Have not used BigQuery." | R6 | [grounded] your own sentences; each clause traces to one of them | pending your approval |
| A4 | If you have one, pull a sanitized ingestion or data-contract example for the interview | R9, R10 | [inferred] from JD scope | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Pellucid Learning live online tutoring K-12 Denver"; "Pellucid Learning Senior Data Engineer careers") were refused for lack of web-search permission. Would have moved RR1 (employer exists, posting live) and the JD-against-careers contradiction check |
| 2. Role-family sweep | skipped | The Datawright 2026 report you supplied already fixes the band and scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you can grant web-search permission, I'll run target 1 next.

I can write this assessment up as `tuesday-dossier.md` to keep and reuse, if you want it.

## Upgrade menu

- Web-search permission granted → target 1 runs; RR1 clears or escalates.
- A sanitized dbt project excerpt or Great Expectations suite config → R5 and R8 move to `high`.
- A BigQuery example, even a sandbox project → R6 moves toward `direct`.
- An ingestion or data-contract artifact → R9 and R10 leave `unclear`.
- Location and floor answers → R1 and R2 close; the decision moves to `conditional_go` or `no_go`.
- A deeper pass on Pellucid's funding and leadership (up to 5 more searches and 2 more fetches): say the word once search is granted.

**Questions**

- **Q1 (R1):** Are you authorized to work in the US, and could you work remote in the US or from Denver?
- **Q2 (R2):** What is the lowest base salary you'd accept?
- **Q3 (R9, R10):** Have you built ingestion from an app database or a CRM, or defined a data contract analysts relied on? Name what you built and what it covered.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.