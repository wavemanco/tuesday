## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.** Five of the seven core requirements are direct matches for your background. The open items are your location and work authorization, which the posting's Remote (US)/Denver terms depend on and you haven't given me, plus the BigQuery gap and two scope items the posting names but doesn't list as requirements.

**Fit ledger.**
- `must_have`: direct: 5+ years, SQL and Python, dbt with a cloud warehouse, Airflow, data quality testing (R1–R5)
- `important`: direct: domain pipeline ownership (R7); adjacent: BigQuery (R8); unclear: data contracts, app and CRM ingestion (R9, R10)
- `hard_gate`: unclear: location and work authorization (R11); compensation floor, not given (R12)

**Opportunity ledger.** The company checks out: the about page and the live careers posting agree with what you pasted, and the pay band sits inside the role-family range. Two things are unknown: the equity figure is not stated, and the posting describes platform-wide scope that is wider than a typical senior role.

- **Hard gates:** none failed; unconfirmed: location and work authorization (R11), compensation floor (R12). Candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and authorization confirmed against "Remote (US) or Denver"; (2) you're comfortable with the scope in the data-contracts and ingestion parts; (3) BigQuery is framed as an adjacent gap you'll close, not as experience you have.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` about page, via search |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD and live careers page |
| Scope read | Wider than a single domain: three areas (ingestion, warehouse, contracts) against a norm of one domain's pipelines | `[inferred]` from the JD against the pay report's scope norm |
| Market calibration | Base median $151,000, IQR $139,000–$163,500 for Senior Data Engineers at Series B–D companies; "Senior" typically means 5–8 years | `[generic]` Datawright 2026 report (datawright.example). Note: this is the same report your recruiter sent, so it's one source, not corroboration |
| Compensation | $148,000–$166,000 base plus equity; the band sits inside the IQR, near the median | `[grounded]` JD for the posting figures; `[generic]` for the comparison |
| Unknowns | Equity amount; location and authorization requirements; whether the role owns ingestion and contracts or consumes them; hiring manager (not named) | — |
| Contradictions | None between the JD you pasted and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated; no artifact yet | `[grounded]` your intake | Verify via employment record |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no code sample yet | `[grounded]` your intake | Q-free: a repo or sample would raise to high |
| R3 | dbt and a cloud warehouse | must_have | direct | high | none | About 180 models on Snowflake, a cloud warehouse | `[grounded]` your intake | none |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, stated | `[grounded]` your intake | none |
| R5 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, stated | `[grounded]` your intake | none |
| R6 | Owning a domain's pipelines (the typical senior scope) | important | direct | medium | none | Built the dbt project; "built" is not yet "owned end to end" | `[inferred]` from "built" | Confirm ownership and on-call |
| R7 | BigQuery, the posting's warehouse | important | adjacent | medium | transferability | Snowflake transfers; BigQuery itself is unused by you | `[grounded]` JD names BigQuery; your intake says never used it | Gap queue G1 |
| R8 | Data contracts for analysts | important | unclear | low | discovery | Not in your background; the JD names it as a responsibility, not a requirement | `[grounded]` JD | Gap queue G2 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background | `[grounded]` JD | Gap queue G2 |
| R10 | Location and work authorization (Remote US or Denver) | hard_gate | unclear | — | hard_gate | You haven't stated these, so the check is unknown | `[grounded]` JD terms | Question 2 |
| R11 | Compensation floor against $148k–$166k | hard_gate | unclear | — | hard_gate | No floor given | `[grounded]` JD terms | Question 3 |

R7 and R8 are rows in the map, but the JD does not list them as requirements. I treat them as `important` because the responsibilities depend on them.

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7) | transferability | Snowflake and dbt transfer; no BigQuery work on record | The JD names BigQuery as the warehouse; the gap is a tooling question, not a missing capability | Any cloud-warehouse cost or performance tuning on Snowflake; any BigQuery exposure, even a side project | A short BigQuery project, or a stated ramp plan | `[inferred]` transferability from Snowflake work |
| G2 | Data contracts and app/CRM ingestion (R8, R9) | discovery | Not in your background, which I can't tell apart from undisclosed experience | Scope could be wider than the role you would own | Any schema-ownership, API ingestion, or CRM sync work | A description of one ingestion or contract you've built | `[grounded]` absence in intake |

The questions for these rows are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Platform-wide scope (ingestion, warehouse, contracts) | risk_signal | medium | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role may be a de facto platform lead, wider than the typical one-domain senior role | `[inferred]` JD scope against the pay report's scope norm | Does this role own ingestion and contracts, or consume them? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Equity value cannot be assessed; it may be a small share | `[grounded]` JD withholds the figure | What equity is offered, and on what terms? | unresolved |
| RR3 | Base pay inside the role-family range | positive_signal | — | "$148,000–$166,000" | Compensation sits near the median of the Series B–D band | `[grounded]` JD; `[generic]` band | — | noted |
| RR4 | Company verified and consistent | positive_signal | — | "Series C ($52M, February 2026)" | The employer exists as described and the posting is live | `[grounded]` about page and careers page | — | noted |
| RR5 | No hiring manager named | unknown | — | (none) | Minor; common in postings, not a signal on its own | `[generic]` | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for location and authorization requirements, the equity figure, and whether BigQuery experience is required or preferred | Resolves R10, R11, RR2 before you invest in the loop | `[grounded]` gaps above | pending your approval |
| P1 | Lead with the 180-model dbt project on Snowflake and the Great Expectations suite | These are your direct matches | `[grounded]` your intake | pending your approval |
| P2 | Describe BigQuery as an adjacent Snowflake background, not as warehouse experience | The reframing audit's "kind" and "relationship" drift risks apply here | `[grounded]` your intake; reframing audit | pending your approval |

Proposed language stays within your own sentences: "built a dbt project of about 180 models on Snowflake" is your claim. "Multi-cloud warehouse experience" would not be.

## Evidence status

Verified: none yet. Every row above rests on what you told me in intake; the company and pay facts rest on the sources in the research tier line.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Senior Data Engineer salary Series B D 2026 dbt Airflow BigQuery", which returned pellucidlearning.com/about. Fetched pellucidlearning.com/careers/senior-data-engineer: the posting is live and matches the JD text. Moved: entity check cleared; no contradictions |
| 2. Role-family sweep | yes | Same salary search returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report). Moved: market calibration `[generic]`; single source, which is the same one your recruiter sent |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- The recruiter's answer on location, authorization, and equity → R10, R11 and RR2 close; the decision likely moves to `go` or `no_go`.
- A short BigQuery project or ramp plan → G1 narrows; R7 moves toward direct.
- One described ingestion or contract project → R8 and R9 move from unclear to direct or adjacent.
- A code sample or repo for SQL and Python → R2 rises from medium to high.
- A hiring manager's name → I can check their public footprint, within the people-research limits, and shape the positioning.
- A deeper pass on Pellucid (funding, leadership, reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

Would you like a full dossier file for this, to carry into interview prep? It's optional and I'll only generate it if you say yes.

1. Have you defined data contracts, or built ingestion from an application or CRM? If so, which one, and what did you own?
2. Where are you based, and are you authorized to work in the US without sponsorship? (This settles the "Remote (US) or Denver" gate.)
3. What base pay is your floor? (This settles the compensation gate against $148k–$166k.)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.