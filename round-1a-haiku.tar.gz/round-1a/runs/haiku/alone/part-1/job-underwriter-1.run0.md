**Yes, apply, once the posting checks out on their own careers page. Status: `conditional_go`.** R1 through R5, the five must-haves, are all direct matches to your record. The gaps sit in the important and preferred rows, not the core.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (define and maintain the metrics layer), R7 (partner with PMs and clinicians on roadmap decisions); unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data experience, HIPAA)

**Opportunity ledger.** The role is clearly scoped but bundles five distinct jobs into one title (RR1). Who owns metric definitions today is unknown (RR2). No pay is stated (RR3). The employer is unverified because my searches were blocked (RR4). One entry runs the other way: mentoring two juniors suggests the team is being built (RR5).

- **Hard gates:** none stated in the JD; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed on the company's careers page or from the recruiter's domain (RR4); (2) your location, work-authorization and pay constraints are checked against the role; (3) RR1 and RR2 come back concrete in a screen: one analyst or a team, and who owns the metric definitions.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD text; not verified externally |
| Mandate | Product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnering, mentoring | `[grounded]` JD |
| Scope read | Broad for one analyst: five distinct outputs in one role | `[inferred]` from the JD's bundled responsibilities |
| Market calibration | Not run. The role-family pay sweep was blocked, so there is no band to compare against | — |
| Unknowns | Location or remote, pay, analyst team size, reporting line, whether Looker exists or is being rebuilt, how clinical the product's data is | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | high | none | Six years at one consumer-subscription company | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; no artifact yet | `[grounded]` your statement | sanitized query sample raises to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, you designed the program; the pricing test is the strongest single example | `[grounded]` your statement | test design doc raises to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch, 40+ governed dashboards | `[grounded]` your statement | dashboard screenshot raises to high |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly exec metrics memo; presents to the VP Product monthly | `[grounded]` your statement | sanitized memo raises to high |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | You built governed dashboards and metric definitions for exec reporting; the CV does not show owning canonical definitions across product areas | `[inferred]` from the dashboard work | metric dictionary sample (see G3) |
| R7 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | low | transferability | Exec and VP-level influence is shown; PM partnership is implied, not stated; no clinician work | `[inferred]` | see G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in your background mentions mentoring | `[grounded]` absence from your statement | see G1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | low | transferability | GDPR/CCPA consent-state model for consumer PII; no PHI, HIPAA or BAA work | `[inferred]` | see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R8, important) | discovery | No mentoring in what you've shared | An unclear important row that interviewers may probe | Onboarding a new hire, reviewing a colleague's SQL or test design, running an analytics training | A review note, onboarding plan, or training outline | `[grounded]` absence; `[generic]` that this is a probe point |
| G2 | Clinician and PM partnership (R7, important) | transferability | Strong exec and VP influence; no clinician-facing work | Adjacent, and the clinician piece is the real limit | A roadmap decision you drove with a non-PM, non-exec stakeholder | A decision memo or meeting summary | `[inferred]` |
| G3 | Metric definitions and healthcare data (R6, R9) | transferability | Governed dashboards and a consent model; no canonical metric layer or PHI work | Both are named in the JD's first and last lines | A metric definition you wrote and got adopted; a data-access or consent policy you authored | A metric dictionary entry, a consent-model diagram | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled responsibilities | risk_signal | medium | "Own product analytics … define and maintain the metrics layer … mentor two junior analysts" | The role may be one person doing a team's work | `[inferred]` from the bundling | How many analysts are on the team, and which of these sit with this role versus a data platform team? | unresolved |
| RR2 | Metric ownership unknown | unknown | — | "define and maintain the metrics layer" | An existing layer may already exist, so the role maintains rather than builds | `[inferred]` from the JD's wording | Is there an existing metrics layer, and who owns its definitions today? | unresolved |
| RR3 | Pay not stated | unknown | — | (no pay in the JD) | The band is unknown, so the seniority-compensation fit can't be judged | `[grounded]` JD omits pay; `[generic]` that such postings withhold it | What is the budgeted base range for this role? | unresolved |
| RR4 | Employer not verified | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Nothing shows it is fake. It is unverified only because the searches were blocked | `[grounded]` search refusal; `[generic]` on posting verification | Can you point me at this role on your careers page, and who would I interview with? | unresolved |
| RR5 | Investment in analysts | positive_signal | — | "mentor two junior analysts" | The team is being built, so the role may have support | `[inferred]` | What does success look like at six and twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program and the Looker build, the two strongest direct matches | R2–R4 are the core of the JD | `[grounded]` your background | pending your approval |
| P2 | Describe the consent work as GDPR/CCPA consumer-PII work. Don't call it healthcare or HIPAA experience | R9 is adjacent only | `[grounded]` + reframing audit | pending your approval |
| P3 | Check the 11% retention claim before interviews: relative or absolute, the test window, and whether it held afterward | Interviewers will probe the headline number | `[generic]` interview pattern | pending your approval |
| P4 | Confirm the posting on the careers page or recruiter's domain before spending application effort | RR4 | `[generic]` pattern | pending your approval |
| P5 | Prepare a sanitized metric dictionary sample and experiment design doc | Raises R2, R3, R6 to high | `[grounded]` the evidence map | pending your approval |

## Evidence status

Verified: none yet. Everything here is your stated background, not checked against an artifact.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were sent for the company (its identity, its careers page, its product) and every call was refused, so the permission was not granted. It would have verified the employer and the posting (RR4) |
| 2. Role-family sweep | unavailable | Same refusal. It would have set the pay band and scope norm for RR3 and the market calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Upgrade menu

- The live posting link or the recruiter's email domain → RR4 closes, which is a condition for go.
- Your location, work-authorization and pay constraints → the hard-gate checks run and the status may move to `go`.
- Enabling web search for this session → the company check and the pay band run (targets 1 and 2).
- A sanitized metric dictionary or experiment design doc → R2, R3 and R6 move to high.
- The hiring manager's name → the positioning for this reader can be tailored.

If you want this kept as a file, I can emit a `tuesday-dossier.md` with the full envelope.

1. **G1 (R8):** Have you managed, mentored or onboarded junior analysts? What did you own, and what happened?
2. **Constraints:** Do you have location, work-authorization or base-pay constraints for this role?
3. **RR4:** Can you paste the live posting link or the recruiter's email domain?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.