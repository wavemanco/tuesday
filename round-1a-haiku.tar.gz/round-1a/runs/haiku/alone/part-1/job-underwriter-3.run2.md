**Decision snapshot: `no_go` as posted.** Tomás would be a strong candidate for this role, but the posting fails both of his hard constraints, and those can't be solved with wording.

- **Fit (candidate ledger):** Strong on experience. The 8+ years, growth leadership, paid, lifecycle and experimentation ownership, managing teams of 3–7, and the $8M to $40M ARR scale-up all match the posting's requirements `[grounded]`, from the candidate's own account. Confidence is high on what's stated; nothing has been verified against documents.
- **Hard gates (failed):**
  - **Pay:** $70–85k base against a $150k floor. The top of the range is $65k below the floor, which is roughly 43% short `[grounded]`.
  - **Location and schedule:** On-site in Austin five days a week, "no exceptions," against a remote-only requirement `[grounded]`.
- **Opportunity ledger (separate from fit):** Weak. The scope is one person covering seven functions (paid, SEO, lifecycle, brand, PR, partnerships, sales ops) "to start." The posting also normalizes evenings and weekends. Pay that low for a Head of title with this scope is a pattern worth noticing `[generic]`, not a claim about Novaline specifically.

Research tier: L0, no searches. I have not checked whether Novaline exists as described, what the market pays for this role, or whether the posting is live. Those claims are therefore unverified, and the `no_go` rests on the posting's own terms, not on anything external.

**Why "something feels off":** The experience match is genuine, but the posting asks for a senior leader's scope at a junior-level salary, in a location you've ruled out. That mismatch is the signal, and it doesn't depend on any research.

**Risk register (short):**
- Hard-gate mismatch, pay: critical.
- Hard-gate mismatch, location and schedule: critical.
- Scope and role design (one person, seven functions, "team of one"): high. This is a real risk even if the pay and location issues disappeared.
- Working-hours norm ("evenings and weekends... just who we are"): medium.

**Application plan:** None recommended. If you still want to test it, one message to the recruiter asking whether remote is possible and what the base range is would settle both gates for little effort. Treat the answer as expected to be no.

I can save this assessment to `tuesday-dossier.md` if you want a file to come back to.

**Upgrade menu (what would change the picture):**
- **Live posting or Novaline's careers page:** confirms the role and pay range are current and not a stale or mis-keyed listing.
- **L1 research (up to 5 searches, 2 page fetches):** would check that the company exists as described, and give a sourced market band for this title and seniority, replacing the `[generic]` pattern above.

**Questions (up to 3):**
1. Is there a link to the live posting, or the Novaline careers page? If the listing is stale, the decision may change.
2. Would you like me to run the L1 research above before you decide?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.