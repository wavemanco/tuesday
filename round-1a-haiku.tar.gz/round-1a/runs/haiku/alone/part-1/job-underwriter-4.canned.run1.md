**Decision snapshot**

**Worth applying to, conditional on location. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (Working location: fully remote, or Leeds four days a week)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (GLM experience), R4 (SQL and Python), R5 (presenting to underwriting leads)
- `important`: direct: R6 (designing and reading price tests), R7 (building and monitoring rating models); absent: R8 (pet-insurance product knowledge, implied by the JD)
- `preferred`: direct: R9 (insurance experience, motor)

**Hard gates:** unconfirmed: R1 (working location). Your own location and constraints weren't given, so checks against them are unknown.

**Opportunity ledger.** Sound role with a few open items.
- **Location contradiction (RR1):** the JD you pasted says "Fully remote (UK)". The careers page says "Leeds office four days a week."
- **Salary withheld (RR2):** neither source states a salary.
- **Pet domain expectation (RR4):** the role owns a pet-insurance product and you have no pet experience.
- **Company attribution (RR3):** Brindlemoor is established only by its own careers page.
- **Positive (RR5):** the hiring manager's public profile shows directly relevant work.

**Conditions for go:** (1) working location confirmed as workable for you; (2) salary checked against the band before the loop.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product. Only its own careers page was found. | `[grounded]` careers page; independent corroboration not found |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing | `[grounded]` careers page |
| Working pattern | Contradiction: "Fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | Senior individual-contributor analytics role; no direct reports stated | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs (n=612): median £58,400, interquartile range £52,100–£64,900 | `[generic]` Pricewell 2026 survey, snippet only, not fetched |
| Unknowns | Working location; salary; whether pet-claims data is accessible; whether mentoring is expected | — |
| Contradictions | Location, as above | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working location (remote vs Leeds 4 days/week) | hard_gate | unclear | low | contradiction | Two sources disagree; your location is not known | `[grounded]` both sources | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two as senior analyst | `[grounded]` your statement | Send CV to verify |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. Motor, not pet; the technique transfers | `[grounded]` your statement | Lead with this |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Designing and reading price tests | important | direct | medium | none | 14 price tests last year with underwriting | `[grounded]` your statement | A one-page test summary would raise confidence |
| R7 | Building and monitoring rating models | important | direct | medium | none | Built and maintained the young-driver model | `[grounded]` your statement | Monitoring story to lead with |
| R8 | Pet-insurance product knowledge (implied) | important | absent | none | capability | No pet experience. The JD's product description makes it matter | `[grounded]` your statement; `[inferred]` that it matters from the JD | G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurer, five years | `[grounded]` your statement | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R8) | capability | No pet work; motor only | The JD names the pet product as the thing you would own | Motor claim frequency and severity modelling; any work with vet, animal or health cost data | A pet-adjacent data sample or a short note on how you would approach pet pricing | `[inferred]` transferability from motor work; `[generic]` that pet pricing has its own features |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradiction | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The JD you pasted may be out of date, or the policy changed | `[grounded]` both sources | Is the role fully remote or Leeds four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | No salary in either source | The figure may sit below the band, or may simply be unpublished | `[inferred]` from the missing figure, against the `[generic]` band | What base salary is budgeted? | unresolved |
| RR3 | Employer established by one page only | unknown | — | Search for "Brindlemoor insurtech pet insurance" returned nothing; the careers page was the only result | A small or early-stage company with little web presence | `[grounded]` search results | Can you share the live posting link or the recruiter's email domain? | unresolved |
| RR4 | Pet-specific pricing expected | risk_signal | medium | "Own pricing analytics for our pet-insurance product" | Interviews may probe pet-specific pricing, such as breed, lifetime vs annual cover, and vet cost inflation | `[inferred]` from the JD | What pet-specific pricing questions could you answer? | unresolved |
| RR5 | Hiring manager's public footprint is relevant | positive_signal | — | Public profile: Odile Varga, Director of Pricing; 2025 Insurance Pricing Forum talk "Small Books, Loud Errors" on monitoring rating models; previously head of pricing analytics at Calloway Re for six years | Your model-monitoring work is the closest match to this reader's interests | `[grounded]` public profile snippet | — | noted |

**Application plan** (all proposed; none sent)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working location with the recruiter before investing in the process | RR1, R1 | `[grounded]` | proposed, pending your approval |
| A2 | Lead with the young-driver GLM monitoring and the price-test results, framed as motor work that transfers | R3, R6, R7 | `[grounded]` | proposed, pending your approval |
| A3 | Do not claim pet experience. Prepare a short, honest answer on how you would approach pet pricing | R8, RR4 | `[grounded]` | proposed, pending your approval |
| A4 | Ask for the salary range before the first interview | RR2 | `[grounded]` | proposed, pending your approval |

**Evidence status**

Verified: none yet. Everything about your experience is your own statement, not yet checked against a CV or work sample.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance jobs"; fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved the location contradiction (R1, RR1) and the single-source attribution (RR3) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary GLM", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. Moved the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance", which returned a public profile (linkedin.example/in/odile-varga). Moved the positioning in RR5 and A2 |

**Dossier offer:** I can write this up as `tuesday-dossier.md`, and a later mock-interview session can use it for interview prep.

**Upgrade menu**
- The live posting link or the recruiter's email domain would resolve RR3 and confirm the location (RR1).
- A salary range would close RR2 against the band.
- A CV or any work sample would move R2 to R9 from self-reported to verified.
- Any pet-related work, or a pet-pricing sample, would move R8.
- Deeper company diligence is available once: funding, leadership changes, hiring patterns, and public candidate reports. It would run up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions**

1. (R1, RR1) Where are you based, and could you work from Leeds four days a week, or is fully remote essential?
2. (RR2) What is the lowest base salary you would accept for this role?
3. (R8, RR4) Have you done any pricing or analysis work on pets, animal health or vet-cost data, even outside a job?

Answer any of these, or say skip and I'll continue on what's here.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.