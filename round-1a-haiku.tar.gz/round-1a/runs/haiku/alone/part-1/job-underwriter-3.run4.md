**Decision: no-go on this posting as written.** Two hard gates fail on the posting's own terms, and wording can't close either one.

**Decision snapshot**
- **Hard gates:** 2 failing, pay and location (below).
- **Fit:** strong on the core requirements you described. That rests on your account, not on documents.
- **Confidence:** moderate. It's based on your self-description only.

**Hard gates (failing)**
1. **Pay.** The posting offers $70–85k base against your $150k floor. Your floor is 1.76× the top of the range and 2.14× the bottom. `[grounded]`: the posting's figures, with the comparison as arithmetic. Equity is described as "meaningful upside," which doesn't meet a base-salary floor.
2. **Location.** The role requires on-site in Austin five days a week, "no exceptions." You are remote-only in Portland. The posting rules out the exception you need.

Both are stated terms. The only route to a yes is the employer changing both, and the posting says it won't.

**Opportunity signals (not gates)**
- One person covering paid, SEO/content, lifecycle, brand, PR, partnerships and sales ops, with "no bench" framing and 8+ years required. `[grounded]`
- Evenings and weekends as the default, and success metrics that "will evolve." `[grounded]`
- "Profitable since day one" and the Series A label are the company's own claims. I haven't verified them.

**Candidate fit (self-described)**
- **Strong:** paid acquisition, lifecycle, experimentation, managing teams of 3–7, scaling $8M→$40M ARR, SQL/GA4/Braze.
- **Not in your description:** SEO/content, brand, PR, partnerships, sales ops. These are gaps to close, but they don't decide anything while the two gates fail.

**Research:** Research tier: L0, no searches.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Novaline's official site and careers page | skipped | Not yet consented |
| 2 | Role-family pay and scope sweep | skipped | Not yet consented |
| 3 | Hiring manager's public footprint | n/a | No name given |

I haven't confirmed that Novaline exists as described, and I haven't checked market pay for this title.

**Dossier offer:** I can save this underwriting as `tuesday-dossier.md` so it carries into mock-interview prep if you pursue another role.

**Upgrade menu**
- A live posting link, or the recruiter's email domain, would let me confirm the company exists and the posting is current.
- A remote-eligible version of the role with base in your range would change both gate verdicts, and I'd re-underwrite it.
- Consent to the L1 research above: up to 5 searches and 2 page fetches to check the company and the market pay.

**Questions**
1. Did anyone at Novaline say anything about remote work or pay that isn't in the posting?
2. Should I run the L1 research? Reply "research" to run it, or "skip" to stop here.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.