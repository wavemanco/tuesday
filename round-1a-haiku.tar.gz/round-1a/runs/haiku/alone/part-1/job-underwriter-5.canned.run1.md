**Decision snapshot: `conditional_go`.** Apply, once the posting and the employer are confirmed live. Your fit is strong on the stated requirements. The main gap is BigQuery, and the two other gaps are things your background may cover but the CV doesn't say.

**Hard gates:** Location (remote US or Denver) and authorization are unknown. Your pay floor is unknown against the posted band. Both are `hard_gate` rows in the map below.

**Research tier: L0, no searches; user links read 0.** Everything from outside the two pasted sources is `[generic]`.

## Role reality

- **Title and scope:** Senior Data Engineer, owning pipelines for tutoring-platform reporting, with ingestion, a dbt warehouse, and data contracts. Ownership of one domain without direct reports is the typical scope for this title `[generic]`.
- **Compensation:** The posted band is $148,000–$166,000 `[grounded]`, plus equity that can't be valued from the posting. The midpoint of $157,000 sits above the report's median of $151,000 and inside its IQR of $139,000–$163,500 `[generic]`. The posted pay is at or above market.
- **Company:** 264 employees, Series C of $52M in February 2026, founded 2016 `[grounded]`, from the company's own about page. Nothing has been checked independently.
- **Sector:** K-12 tutoring depends on school budgets `[generic]`. Ask about contract concentration and renewals.
- **Unknowns:** No hiring manager named, no team size, on-call expectations not stated, and "build and run" may include operations.

## Evidence map

| # | Priority | Fit | Confidence | Gap | Requirement |
|---|---|---|---|---|---|
| 1 | Must | Met | High (6 years, self-reported) | none | 5+ years data engineering |
| 2 | Must | Met | High (daily use) | none | Strong SQL and Python |
| 3 | Must | Met | High (~180 models) | none | dbt on a cloud warehouse (Snowflake) |
| 4 | Must | Met | High | none | Airflow orchestration |
| 5 | Must | Met | Medium (set up the suite) | none | Data quality testing (Great Expectations) |
| 6 | Must | Partial | Medium | capability | BigQuery is the named warehouse; no experience yet |
| 7 | Implied | Unknown | Low | discovery | Ingestion from an app and a CRM; not in the CV |
| 8 | Implied | Unknown | Low | discovery | Data contracts with analysts; not in the CV |
| 9 | Hard gate | Unknown | None | hard-gate | Location (remote US or Denver) and work authorization |
| 10 | Hard gate | Unknown | None | hard-gate | Pay floor against $148k–$166k |

## Opportunity risk register

| Risk | Class | Severity | Note |
|---|---|---|---|
| Employer not verified | Failed attribution | Medium | Confirm the live posting and the careers page. This is why the decision is conditional. |
| BigQuery ramp | Capability | Medium | Snowflake transfers well; BigQuery specifics (partitioning, slots, cost model, IAM) need learning. |
| Pay floor and location unknown | Hard gate | Unresolved | Decides whether the role is viable at all. |
| K-12 funding exposure | Sector `[generic]` | Low to medium | Check how the company funds itself. |
| Scope ambiguity | Posting | Low | Clarify the ingestion and contracts ownership and whether on-call applies. |

## Application plan

- Lead with 6 years of dbt, Airflow and data-quality work on a warehouse at scale, and name Snowflake as the warehouse.
- Describe BigQuery as the next platform to learn. Don't list it as experience.
- Claim ingestion and data contracts only if you confirm them. Proposed CV language is `resume_edits_pending_approval` until you approve it.

## Gap recovery queue

- **Row 6 (BigQuery):** Closes with a BigQuery project or certification, or a short ramp example. This is a capability gap, so it is closable.
- **Row 7 (ingestion):** Closes with a CV line naming the app and CRM sources you ingested.
- **Row 8 (contracts):** Closes with a schema-agreement or contract example from your payroll work.
- **Rows 9 and 10:** Close only with your answers.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| L1 1: company site and careers page | skipped | L0 run; no searches consented |
| L1 2: role-family sweep | skipped | L0 run; no searches consented |
| L1 3: hiring manager footprint | n/a | No name given |

## Upgrade menu

- **Research at L1** (up to 5 searches and 2 page fetches): confirms the employer and the live posting, which would clear the conditional. It also checks the market band with sources.
- **Deeper diligence at L2**, optional: funding, leadership changes, and candidate reports. Up to 5 more searches and 2 more fetches.
- **Your CV, with any ingestion and contracts detail** raises rows 7 and 8.

## Questions

1. Are you authorized to work in the US, and does remote-US or Denver work for you? (Row 9)
2. Did your ingestion work cover app and CRM sources, and did you own data contracts with downstream analysts? (Rows 7 and 8)
3. What's your pay floor, and is $148,000 below it? (Row 10)

Answer in prose, or skip any question. A skip counts as an answer.

I can also build a dossier file (`tuesday-dossier.md`) for this role if you want to keep the analysis.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.