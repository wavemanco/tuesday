**Yes, apply, but only after the employer checks out and you have pay and location. Status: `conditional_go`.** On the analyst core you are a strong fit. The gaps are healthcare data (preferred), mentoring two junior analysts, and clinician partnership.

Research note: the three web searches were refused because search permission has not been granted in this session, so the employer and market are unverified. I did not retry them.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (metrics layer)
- `important` — direct: R7a (partner with product managers) · unclear: R7b (partner with clinicians), R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R5 — metric definitions implied by your governed dashboards, not stated (`medium`); R7b — no clinician work in the material (`low`); R8 — no mentoring in the material (`none`); R9 — consent and PII work, not PHI (`medium`).

**Opportunity ledger.** The role is clearly scoped, with named responsibilities, but it withholds pay and location and its employer is unverified (RR1, RR2, RR3). The breadth of one senior seat (RR4) is an inference, and the specific responsibilities are a positive signal (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) the employer verifies as a live posting (RR1); (2) pay and location are stated and workable (RR2, RR3); (3) you describe healthcare, mentoring and clinician work only as you have actually done it (R7b, R8, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` your JD text; unverified (RR1) |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` JD |
| Scope | Metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | Broad for one senior individual-contributor seat: metrics owner, experimentation lead, BI builder and mentor at once | `[inferred]` from the responsibility list |
| Working pattern | Not stated | — |
| Compensation | Not stated | — |
| Market calibration | Not run; the role-family search was refused | — |
| Unknowns | Pay, location and remote terms; employer existence; what "clinicians" means in practice | — |
| Contradictions | None found within the JD text; nothing was checked against an external source | — |

## Evidence map

Confidence tops out at `medium` on a first pass, because your background is self-report and nothing has been inspected yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated | `[grounded]` your background | Expect a probe |
| R2 | 5+ years product analytics | must_have | direct | medium | none | Six years at one company | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test with an 11% retention lift, stated | `[grounded]` your background | Offer a redacted experiment readout |
| R4 | Looker and self-serve dashboards | must_have | direct | medium | presentation | Built the Looker instance and 40+ governed dashboards; self-serve use is not stated | `[grounded]` your background | Say whether the dashboards were self-serve |
| R5 | Define and maintain a metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and the monthly metrics memo imply metric definitions, but ownership of a metrics layer is not stated | `[inferred]` from dashboards and memo | Question in closing block |
| R6 | Strong written communication to non-technical readers | must_have | direct | medium | none | Writes the monthly metrics memo that the exec team reads | `[grounded]` your background | none |
| R7a | Partner with product managers | important | direct | medium | none | Presents monthly to the VP Product | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | unclear | low | discovery | No clinician stakeholders in the material | `[grounded]` material silence | Question in closing block |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring in the material | `[grounded]` material silence | Question in closing block |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR and CCPA and a consent-state model; no PHI or HIPAA work. Limit: no covered-entity or BAA exposure | `[grounded]` your background; `[inferred]` adjacency | Question in closing block |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G-R5 | Metrics layer (R5) | transferability | Governed dashboards and the metrics memo, with no stated ownership of metric definitions | A metric definitions doc or governance example you owned | `[inferred]` from dashboards and memo |
| G-R7b | Clinician partnership (R7b) | discovery | Nothing in the material | Any work with clinical, care or ops-domain experts | `[grounded]` material silence |
| G-R8 | Mentoring (R8) | discovery | Nothing in the material | Onboarding, code review or intern work you did | `[grounded]` material silence |
| G-R9 | HIPAA or regulated health data (R9) | transferability | Consent and PII work; no PHI | Any health, benefits or BAA-governed data work | `[grounded]` your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The employer may be too new or small to have a footprint, or the posting may be stale. The search was refused, so this is unverified, not disproven | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | Not stated | The pay may sit below the role-family band, or may simply be unpublished | `[grounded]` JD silence | What is the base salary range for this role? | unresolved |
| RR3 | Location and work pattern not stated | unknown | — | Not stated | Could be remote, hybrid or on-site | `[grounded]` JD silence | Where is this role based, and what is the in-office expectation? | unresolved |
| RR4 | Broad scope for one senior seat | risk_signal | low | "metrics layer, A/B tests, self-serve Looker, clinicians, mentor two junior analysts" | The seat may be asked to cover four jobs at once | `[inferred]` from the responsibility list | How is this role's time split across metrics, experiments, dashboards and mentoring? | unresolved |
| RR5 | Specific, named responsibilities | positive_signal | — | "Own product analytics for our care-navigation app" | The scope is defined enough to test in interview | `[grounded]` JD | Which parts of the metrics layer already exist, and who owns its definitions? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's own careers page before investing effort | see RR1 | `[grounded]` RR1 | proposed |
| A2 | Ask the recruiter for pay range, location and start date | see RR2, RR3 | `[grounded]` RR2, RR3 | proposed |
| A3 | Answer the RR questions in the first interview | The register doubles as interview preparation | `[grounded]` register | proposed |

No CV or outreach language is proposed in this pass, so no approval is needed yet.

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation company" and "Harborlight Health careers Senior Product Analyst"; both refused, so the employer is not established in this run. Would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "senior product analyst salary digital health product analytics"; refused. Would have set the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- The live posting link, or the careers-page listing → RR1 can clear and the employer can be checked.
- Search permission granted → the role-family pay and scope calibration, and the employer's footprint.
- Pay range, location and start date → RR2 and RR3 close, and the hard-gate checks run against your constraints.
- A redacted experiment readout or memo → R3 and R6 move toward `high`.
- Any mentoring or review artifact, such as an onboarding doc or review notes → R8 can be raised.
- A deeper research pass on Harborlight (funding, leadership, past postings; up to 5 more searches and 2 more fetches) → available once permission is granted.

If you want to keep this analysis, I can write it up as `tuesday-dossier.md`.

## Questions

R8 — Have you mentored, onboarded or formally reviewed the work of junior analysts, even informally, such as interns or code review? What did you own, and how did it go?

R9 — Have you worked with health, benefits or other regulated personal data (HIPAA, a BAA, or similar controls)? If so, what did your role cover?

RR1 — Can you paste the live posting link, or tell me the recruiter's email domain, so I can check the employer?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.