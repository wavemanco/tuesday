**Yes, apply, but as a conditional go: your analytics core matches the JD closely, and the condition is that the posting and the employer check out.** I could not verify either: web search was not permitted in this session, so every claim about Harborlight Health below comes from the JD you pasted.

- **Status: `conditional_go`.** Apply once the posting is confirmed live and the employer is confirmed to exist as described (RR1).
- **Fit ledger.**
  - `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R7, R8
  - `important`: unclear: R6
  - `preferred`: adjacent: R9
  
  R7 (define and maintain a metrics layer): governed dashboards, not metric definitions. R8 (clinicians): PM partnership carries over; clinician work not exercised. R6 (mentoring): not stated anywhere. R9 (healthcare data): consent and PII work, not HIPAA.
- **Opportunity ledger.** The employer is unestablished (RR1), and the JD states no compensation (RR2). RR3 flags that the clinician-partnership scope is undefined. RR4 is positive: the deliverables are concrete.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a confirmed live posting and employer moves the status to `go`. A mentoring or clinician-work answer moves R6 or R8. A pay range is still needed before you weigh the offer.

Your experience is `medium` confidence throughout: the claims are yours and specific, but nothing inspectable has been shared yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header, unverified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentor two junior analysts | `[grounded]` JD |
| Scope read | Broad but coherent for a senior analytics lead; the clinician partnership is the least defined part | `[inferred]` from the responsibility list |
| Market calibration | Not run: no band available at this tier | — |
| Unknowns | Pay, employer existence, contract basis, clinician decision rights | — |
| Contradictions | None visible in the pasted JD; no second source to compare | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; self-report, no artifact | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily Snowflake use stated | `[grounded]` your intake | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and the pricing test stated; design docs not yet seen | `[grounded]` your intake | A sanitized test design or readout would raise to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance and 40+ governed dashboards, as stated | `[grounded]` your intake | A sanitized dashboard screenshot would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and monthly VP Product readout stated | `[grounded]` your intake | A redacted memo excerpt would raise to high |
| R6 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` absence in intake | G1 |
| R7 | Define and maintain a metrics layer | must_have | adjacent | medium | transferability | Governance work carries over; metric definitions not stated | `[inferred]` from the governed-dashboard work | G2 |
| R8 | Partner with PMs and clinicians | must_have | adjacent | medium | transferability | PM partnership direct; clinician work not stated | `[grounded]` intake, `[inferred]` adjacency | G3 |
| R9 | Healthcare data (HIPAA) | preferred | adjacent | medium | transferability | Consent-state and PII work; no HIPAA or clinical data | `[grounded]` intake, `[inferred]` adjacency | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R6, important) | discovery | No mention of people development | Affects the mandate and the decision only if it is central | Onboarding or reviewing a junior's work; running a team's analysis standards; coaching on test design | Onboarding doc, review notes (redacted) | `[inferred]` that mentoring is a stated responsibility |
| G2 | Metrics layer (R7, must_have) | transferability | Governed dashboards and governance work | Metrics definition is a must-have | Owning canonical metric definitions; resolving disputed metrics across teams | A metric definition doc or glossary excerpt | `[inferred]` |
| G3 | Clinician partnership (R8, must_have) | transferability | PM partnership stated | The clinician side is the one not exercised | Working with a care, ops or clinical team on a analysis or product decision | A brief or readout shared with non-analytics stakeholders | `[inferred]` bridge; `[generic]` that clinician work is the likeliest objection |
| G4 | Healthcare data (R9, preferred) | transferability | Consent and PII work | Preferred, so a minor objection | Any regulated or sensitive data work; access controls | A consent-model summary (redacted) | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size; not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (none in the pasted JD) | The posting may withhold pay, or the paste may have omitted it | `[inferred]` from the JD text as pasted | What is the base salary range for this role? | unresolved |
| RR3 | Clinician partnership scope undefined | unknown | — | "partner with PMs and clinicians" | Clinicians may have consultative input rather than decision rights | `[inferred]` from the responsibility wording | How often would this role work directly with clinicians, and which decisions would they shape? | unresolved |
| RR4 | Deliverables concrete | positive_signal | — | "design and analyze A/B tests … build self-serve dashboards" | Scope is defined and measurable | `[grounded]` JD | Which of these deliverables does the team need done in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the live posting and the employer's careers page before investing in an application | see RR1 | `[generic]` pattern | pending your approval |
| P2 | Prepare one sanitized test design or readout to show R3 | see R3 | `[grounded]` your intake | pending your approval |
| P3 | Frame R7, R8 and R9 as bridges, stating each limit (no clinical data, no HIPAA, no clinician work) | keeps the adjacency honest in interviews | `[grounded]` the rows' limits | pending your approval |

## Evidence status

Verified: none yet. Your intake claims are self-report and stay unverified until you confirm specifics.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches for Harborlight Health were refused (web search not permitted). Would have confirmed the entity, stage and size, and whether the posting is live (RR1) |
| 2. Role-family sweep | unavailable | The salary and scope searches were refused. Would have set the `[generic]` market band for this title and seniority (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A live posting link or the careers-page URL → RR1 closes, and the status can move to `go`.
- Permission to run web search → the employer check and the pay band run (up to 5 searches and 2 fetches).
- A sanitized test design or readout → R3 moves to `high`.
- A redacted memo excerpt → R5 moves to `high`.
- Deeper company diligence (funding, leadership, reports; up to 5 more searches and 2 more fetches) → needs the same permission; say the word once it is granted.
- The hiring manager's name → the scope read and the positioning for that reader.

If you want this kept as a file to take into the application, I can write it up as `tuesday-dossier.md`.

1. Have you mentored or managed junior analysts? What did you own: hiring, reviews, or their analysis?
2. Have you worked directly with clinicians or a care team on analysis? What decisions did that work shape?
3. Can you paste the live posting link, or the careers-page URL and the recruiter's email domain?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.