**Status: `conditional_go`.** On what you've given me, your must-haves match the posting well. The BigQuery gap is real but learnable. Two things stand between you and a plain go: the employer hasn't been checked (my web lookups were refused permission), and your location is unknown.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office location). Candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Confirm Pellucid exists and the posting is live, through the company's own careers page or the recruiter's link (RR1). (2) Confirm your location fits R1. (3) Confirm the ingestion and data-contract scope (R8, R9) in the first conversation.

**Fit ledger** (from the evidence map)

- `hard_gate`: unclear: R1 (Remote (US) or Denver office location)
- `must_have`: direct: R2 (5+ years data engineering), R3 (strong SQL and Python), R4 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R5 (dbt-modelled warehouse in BigQuery); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R4 — dbt on Snowflake, a direct match for the stack; R5 — the BigQuery limit, named; R8 and R9 — not in your background, so unconfirmed.

**Opportunity ledger.** RR1 is the cap: the employer is unverified. RR2 and RR3 are open terms (equity, hiring manager). RR4 is a positive: the salary is stated.

---

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states; founded 2016 in Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` company About page as you provided it; not checked online |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stated pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500. The posted range's midpoint ($157,000) sits in the upper half of that IQR. | `[generic]` Datawright 2026 pay report, US, n=2,310, as you provided it |
| Seniority and scope | "Senior" usually means 5–8 years; typical scope is one domain's pipelines with no direct reports. Your 6 years sits inside that. | `[generic]` same report |
| Scope read | One domain (reporting), no management named | `[inferred]` from the JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Hiring manager (not named); equity terms; who owns the data contracts; ingestion scope | — |
| Contradictions | None between the JD and the About page you gave me. The posting itself was not checked. | `[grounded]` |

I've assumed you're evaluating, not yet applying.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in what you gave me | `[grounded]` JD terms | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company. Self-report, no artifact yet. A length-of-experience requirement, so not a gate. | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, as you stated it. No artifact yet. | `[grounded]` your statement | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. | `[grounded]` your statement | none |
| R5 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Your dbt work carries over; you've never used BigQuery. The limit is named. | `[inferred]` adjacency from your Snowflake work | G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration | `[grounded]` your statement | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up a Great Expectations test suite | `[grounded]` your statement | A5 |
| R8 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background | `[inferred]` from the JD's responsibilities | Q2 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your background | `[inferred]` from the JD's responsibilities | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5) | transferability | Snowflake dbt work; no BigQuery | It's named in the JD's first responsibility | dbt model design, warehouse structure, or cost and partitioning choices on any warehouse | A BigQuery project, a sample model, or a dbt repo | `[grounded]` your statement; `[inferred]` that this is the likeliest objection |
| G2 | Ingestion and data contracts (R8, R9) | discovery | Not in your background | These are the first two responsibilities the JD lists | Pipelines pulling from an operational database or API; agreed schemas that downstream users relied on | A pipeline diagram, a schema agreement, or a DAG | `[inferred]` from the JD's responsibilities |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not yet verified | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Research didn't run, so nothing outside the pages you gave me confirms Pellucid exists as described. The posting may be stale or not a live hire. | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | The equity may be material or may be token; the posting doesn't say | `[inferred]` from the JD's silence | "What's the equity grant: its size, vesting schedule, and the basis for its value?" | unresolved |
| RR3 | Hiring manager not named | unknown | — | (no name in the posting) | Reporting line and first-year scope are unclear | `[inferred]` from the posting's silence | "Who would I report to, and who owns these pipelines today?" | unresolved |
| RR4 | Salary stated | positive_signal | — | "$148,000–$166,000" | The range sits around the role-family median, so it's a credible figure | `[grounded]` JD; band `[generic]` | "Is this range final, and where in it does an offer usually land?" | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting and the employer before spending effort: open the role on the company's careers site, or ask the recruiter for the link | RR1 | `[grounded]` the register | proposed |
| A2 | CV line: "Built our dbt project on Snowflake — about 180 models." | R4, R5 | `[grounded]` your sentence; the line adds nothing you didn't write | `resume_edits_pending_approval` |
| A3 | Interview framing for the BigQuery gap: "My dbt work was on Snowflake. I haven't used BigQuery." | R5 | `[grounded]` your statement; limit stated | pending your approval |
| A4 | CV line: "Set up our Great Expectations test suite." | R7 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| A5 | Ask RR2 and RR3 verbatim in the first conversation with the hiring team | Register doubles as interview prep | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Your background is self-report, so every claim stays at the intake ceiling of `medium`.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search and one fetch were sent; both were refused permission, so nothing was checked. Would have moved RR1 and the posting's live status. |
| 2. Role-family sweep | skipped | The Datawright report you provided already fixes the market band and the scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given |

Dossier offer: If you want this kept as a file for the application, I can produce `tuesday-dossier.md`.

## Upgrade menu

- Permission for web search and page fetch → runs target 1; a confirmed live posting closes RR1, and the decision could move to `go`.
- The live posting link, or the recruiter's email domain → the same check, without a search.
- Your location and work-authorization status → R1 moves to `direct`.
- A BigQuery project or sample model → R5 moves toward `direct`.
- A description of an ingestion pipeline or a data contract you owned → R8 and R9 move.
- Your pay floor and any other non-negotiables → the hard-gate checks run.
- The hiring manager's name → target 3 runs, and the scope read tightens.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **R1:** Where are you based, and does working remote in the US, or from the Denver office, work for you?
2. **R8, R9:** Have you built ingestion from an app or CRM, or owned data contracts that analysts relied on? What did you own, and what happened?
3. **Candidate constraints:** What's your pay floor, and are there other non-negotiables (contract type, start date)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.