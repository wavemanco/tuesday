**Decision: conditional go.** Apply selectively. You're not wasting your time, but the must-have is a real gap and you should go in knowing that.

Research tier: L0, no searches. Quartzline, its posting, and market pay are unverified.

## Decision snapshot

- **Strong fit [grounded]:** technical fluency (OpenAPI, Postman, SQL, integration architecture), stakeholder coordination across engineers, clients, and PMs, and discovery-style requirements work.
- **Partial fit [grounded]:** shipped platform product, launch coordination, roadmap influence.
- **Gaps:** 3+ years of PM experience (must-have), adoption metrics, and agile delivery, which your resume doesn't show.
- **Hard gates:** none stated in the JD, none failed. Location, pay, and authorization are unknown to me.
- **Opportunity:** Series B, about 150 people, a platform role with two engineering squads. The scope sounds plausible. The employer itself is unverified.

## Evidence map

| Requirement | Priority | Fit | Confidence | Gap type | Evidence |
|---|---|---|---|---|---|
| 3+ years PM | Must-have | Gap | High | Transferability | No PM title or PM years on the resume |
| Shipped API/platform products | Must-have | Partial | Medium | Presentation | You shipped 30+ client integrations of your vendor's REST APIs. You didn't own the product. |
| API and schema fluency | Must-have | Strong | High | None | OpenAPI, Postman, SQL, integration architecture |
| Stakeholders across eng, sales, customers | Must-have | Strong | High | None | Coordinated engineers, client engineers, and PMs. Sales isn't mentioned. |
| Partner discovery | Core | Strong | Medium–high | None | Scoping workshops; quarterly roadmap-input sessions |
| Specs and driving delivery | Core | Partial | Medium | Presentation | Requirements docs; coordinated engineers but didn't own a backlog |
| Adoption metrics | Core | Gap | Low | Capability | Nothing listed |
| Launch coordination with sales and support | Core | Partial | Medium | Presentation | UAT and go-live; support isn't mentioned |
| Agile delivery | Preferred | Unknown | Low | Presentation | Not on the resume |

Most of the "presentation" gaps may be real experience you didn't write down. Check before you conclude you lack them.

## Assessment

Your must-have gap is the 3+ years of PM. That's a requirement you can't wording your way past. Expect it to be a screening filter [generic]. The adjacency is still strong: solutions engineers moving into technical or platform PM is a common path [generic]. Your discovery, requirements, and roadmap-input work is the closest thing to product ownership you have. Be careful how you describe it. "Coordinated" and "led integrations end to end" are accurate. "Owned the product" would not be.

Series B platform roles often mean the PM is building the function, not inheriting one. Ask whether the two squads would report to you or only take your priorities.

## Application plan

1. Confirm the posting is live on Quartzline's own careers page before you spend time on it.
2. Write 3–5 owner-level decisions from your integrations work. For example: something you scoped out, a roadmap input that changed what product built, or a playbook change that changed how teams worked. Include only what's true, and include outcomes if you have them.
3. In the cover letter, name the PM gap yourself and give the closest evidence. Don't hide it.
4. Spread applications across adjacent titles too: technical PM, integrations PM, solutions PM, and internal-tools PM. Those are often easier entry points.

## Upgrade menu

- A posting link or Quartzline's careers page would verify the employer.
- L1 research would check the posting and typical pay for this title and seniority.
- Your three answers below would move the shipped-product and adoption rows, the two that matter most.

## Questions

1. Name one decision you made or materially shaped about what got built. What happened after?
2. Did you track any numbers, even informally: go-live time, partner adoption, playbook usage, support volume?
3. Your prior-conversation notes mention an internal request-triage tool that support agents adopted. I can't confirm that from here. Did you build it, what did it do, and what adoption did you see?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.