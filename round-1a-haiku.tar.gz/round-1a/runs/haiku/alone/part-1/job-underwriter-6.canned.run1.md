**Decision snapshot**

Yes, apply, on conditions. This is `conditional_go`.

**Fit ledger**
- `must_have`: direct: R2 (sector is adjacent, see map), R3, R4 · adjacent: R2 sector, R6 · absent: R5
- `hard_gate`: unconfirmed: R1 (Bristol, two days a week in the office)

R5 (owning the company forecast) is the one that matters most. You have never owned one, and the JD says the role runs the quarterly forecast with the CFO.

**Opportunity ledger.** The company is real and the pay is in market. The posting itself isn't visible on Quillfield's own site (RR1), and it's unclear how much of the forecast is actually this role's (RR2).

- **Hard gates:** unconfirmed: R1 (Bristol hybrid, two days a week in the office).
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is confirmed on Quillfield's own site or by the recruiter (RR1). (2) The forecast scope is clarified: you'd own it, co-own it with finance, or only feed pipeline into it (RR2). (3) Billing-data work is realistic in interviews (R6). (4) The Bristol hybrid pattern works for you (R1).

Why `conditional_go` and not `go`: your years, tools and SQL meet the bar, but two of six must-haves are gaps you'd have to argue past. Why not `no_go`: nothing is a hard-gate failure, and both gaps can be scoped down in the first conversation.

---

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 staff; £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Scope | Owns CRM and billing data; builds pipeline and renewal reporting; runs the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options | `[grounded]` JD |
| Market calibration | Median base for a UK B2B software RevOps lead is £64,200; interquartile range £57,800–£70,400. The posted band sits in the middle | `[generic]` Ledgerline 2026 pay guide (n=438) |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield. Previously sales operations manager at a payments company for four years. Your background is close to hers | `[grounded]` search snippet only; profile not opened |
| Unknowns | Whether this role reports to her or sits beside her; how much of the forecast is owned here; billing-data access | — |
| Contradictions | None between the JD and the company's site. The role itself isn't on the company site (see risk register) | `[grounded]` careers page returned nothing |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in office | hard_gate | unclear | — | discovery | Location and commute not stated in your background | `[grounded]` JD; your background silent | Q1 below |
| R2 | 4+ years RevOps / sales ops / analytics at a B2B software company | must_have | adjacent | high | transferability | Five years in sales ops, two running RevOps. Years meet the bar; the sector is payments, not software. A payments firm is a credible neighbour, not the same thing | `[grounded]` your background; `[inferred]` on sector fit | Name the payments sector plainly |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards. Certification not yet checked | `[grounded]` your statement | Confirm cert is current |
| R4 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. "Modelling" implies financial models, which you have not stated | `[grounded]` your statement | Ask whether modelling means forecast models (see R5) |
| R5 | Experience owning a forecast | must_have | absent | high | capability | Finance owned the company forecast at your previous firm. The monthly pipeline review is a forecast input, not the forecast | `[grounded]` your statement | Q2 below |
| R6 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | You've built renewal and pipeline dashboards (revenue data), but not billing data, and not with finance | `[grounded]` your statement | Q3 below |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R5) | capability | No ownership; a pipeline-review bridge exists | The JD names forecasting with the CFO as a core duty | Learn whether the role owns it, co-owns it or feeds it; then describe the pipeline-to-forecast link honestly | `[grounded]` JD and your background |
| G2 | Billing data (R6) | discovery | No billing work; revenue dashboards only | The JD says "own our billing data" | Find out whether you ever reconciled payments to invoices or billing records at your payments firm | `[grounded]` JD |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not visible on the employer's own site | risk_signal | medium | Posting hosted on tallyboard.example; quillfield.co.uk/careers returned no page | The role may be on a different careers path, or the listing may be stale or aggregated. Most small companies are simply small; this is not a fraud signal | `[generic]` pattern for aggregator listings; `[grounded]` fetch result | Can you point me at the role on quillfield.co.uk, and who would I interview with? | unresolved |
| RR2 | Forecast scope unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may share the forecast with finance, owning only the pipeline input | `[inferred]` from the JD's wording against its silence on who signs the number | Does this role own the forecast, co-own it with finance, or feed pipeline into it? | unresolved |
| RR3 | Hiring manager's reporting line unknown | unknown | — | Recruiter named Tamsin Achebe as hiring manager | Her Head of RevOps title suggests this role may sit under her or beside her, which changes the scope question | `[inferred]` from a search snippet | Who will I report to, and which parts of the revenue stack will I own alone? | unresolved |
| RR4 | Posted pay sits in market | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is unlikely to be the blocker | `[generic]` band against `[grounded]` posted figure | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the Salesforce certification and the pipeline and renewal dashboards | Strongest verified-looking evidence for R3 | `[grounded]` your background | pending your approval |
| P2 | Describe the pipeline review's role in forecasting exactly as it was: an input, not ownership | Avoids the R5 claim that a probe would break | `[grounded]` R5 | pending your approval |
| P3 | Ask the recruiter for the forecast scope and the reporting line before applying | Settles RR2 and RR3 cheaply | `[grounded]` RR2, RR3 | pending your approval |
| P4 | Check the posting exists on quillfield.co.uk before investing in an application | Settles RR1 | `[grounded]` RR1 | pending your approval |

**Evidence status**

Verified: none yet. Your background is stated in this conversation, not documented.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" and "Quillfield careers Revenue Operations Lead Bristol" (no results); fetched quillfield.co.uk/about (company confirmed) and quillfield.co.uk/careers (no page). Moved RR1 and the employer-existence check |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK Bristol B2B software", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide. Moved the market calibration |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; the LinkedIn result appeared as a search snippet only and was not opened. Moved RR3 and the positioning in P2 |

**Dossier offer.** Want me to write this up as `tuesday-dossier.md` for later use?

**Upgrade menu**
- The live posting on quillfield.co.uk, or the recruiter's reply on where it's listed → RR1 closes; the decision can move to `go`.
- The forecast scope from the recruiter → R5 and RR2 close. If the role only feeds pipeline, the forecast gap shrinks to adjacent.
- A sanitized reconciliation example or billing-related artifact from your payments firm → R6 rises from adjacent to direct.
- A deeper pass on Quillfield (funding and leadership changes, past hiring, reviews; up to 5 more searches and 2 more fetches) → say the word and it runs. It's offered once.

**Questions**
1. (R1) Can you work two days a week in the Bristol office?
2. (R5) Has your pipeline review ever fed a number into a forecast, or been signed off by finance?
3. (R6) At the payments company, did you reconcile payments against invoices or billing records with finance?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.