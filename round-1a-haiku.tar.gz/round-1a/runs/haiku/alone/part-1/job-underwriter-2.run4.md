**Decision snapshot**

- **Decision: conditional_go.** Apply, but treat it as a stretch. The must-have is the weak point.
- **Candidate fit:** strong on technical fluency and stakeholder work. A real gap on "3+ years PM experience."
- **Opportunity:** plausible scope, but unverified. No live posting link and no company research (L0).
- **Hard gates:** none stated in the JD. Compensation, location, and schedule are unknown for Nadia, so those checks are open.

**Are you wasting your time?** No. Your evidence is PM-adjacent and real. But this role is the hardest version of the pivot, because its must-have asks for a record of owning product decisions, and your CV doesn't show one yet. Wording won't close that gap. Proof will.

**Evidence map** (provenance: [grounded] from your CV and the JD unless noted)

| # | Priority | Requirement | Fit | Gap type | Confidence | Evidence |
|---|---|---|---|---|---|---|
| 1 | must-have | 3+ yrs PM experience | gap | transferability | high | No PM title; no owned roadmap or prioritization decisions on the CV |
| 2 | must-have | Shipped API or platform products | partial | transferability | medium | 30+ REST integrations end to end; you didn't own a shipped product |
| 3 | must-have | Technical fluency | strong | none | high | Postman, SQL, OpenAPI, integration architecture |
| 4 | must-have | Stakeholder management (eng, sales, customers) | strong | none | high | Coordinated your engineers, client engineers, and PMs |
| 5 | must-have | Agile delivery | unknown | capability | low | Not stated on the CV |
| 6 | core | Own the roadmap | partial | transferability | medium | Ran roadmap-input sessions; didn't own prioritization |
| 7 | core | Discovery with integration partners | strong (adjacent) | none | high | Scoping workshops and requirements work |
| 8 | core | Specs and delivery with eng squads | strong (adjacent) | none | high | Requirements documents; coordinated engineers |
| 9 | core | Define and track adoption metrics | gap | capability | low | No adoption metrics on the CV; go-live is an outcome, not adoption |
| 10 | core | Launch coordination with sales and support | partial | none | medium | Go-live and UAT; support coordination not stated |

**Gap recovery queue**

- **Row 1:** Closes only with a PM-shaped ownership record, either a PM title or documented prioritization decisions with outcomes.
- **Row 2:** Closes with a shipped product where you owned the spec and the release decisions.
- **Row 9:** Closes with one adoption metric you defined and tracked, such as integration time-to-live or playbook usage.
- **Row 5:** Closes with a statement of your delivery method and an example of it.

**Opportunity risk register**

- **Unverified employer (standing entry, high):** Without a live posting or the company's careers page, the company facts are unconfirmed. That is why this is conditional_go and not go.
- **Scope above evidence (medium):** Owning the roadmap for a partner-facing platform is a step up from your record. [generic] Series B platform PM roles usually expect a shipped-product record.
- **Compensation and location unknown (medium):** Not stated in the JD, and not known for you.

**Application plan**

1. **Reframe honestly.** "Ran roadmap-input sessions" is accurate. "Owned the roadmap" isn't, unless you did. Don't call the playbook a product unless it was run as one.
2. **Build proof in 4–6 weeks.** Run one discovery with partners in your current role. Write one spec and track one adoption metric for the integration playbook or onboarding. Ask for backlog ownership of integration tooling.
3. **Consider bridge roles first.** Examples: an internal PM transfer on partner or integrations products, a developer-platform PM role, or a technical PM or product-ops role on an API team. [generic] Each builds the must-have record faster than a direct Platform PM role.
4. **Unconfirmed lead.** The request-triage tool from prior context isn't evidence yet. If it's real and support agents adopted it, it's your best PM-shaped story, since it shows you owned requirements and adoption. Verify before you use it.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0: no research consented |
| 2. Role-family sweep | skipped | L0: no research consented |
| 3. Hiring manager footprint | n/a | No name given |

Dossier offer: I can write this up as a `tuesday-dossier.md` file for handoff to interview prep, if you want it.

Upgrade menu, in order of impact:
- The live Quartzline posting link (resolves the unverified-employer entry).
- Your compensation floor and location constraints (closes the hard-gate checks).
- Details of the triage tool: what it did, who used it, and any adoption numbers (could move row 2 and row 9).
- Any agile methodology you've used (closes row 5).

Questions:
1. Row 1 / row 6: Have you ever owned a prioritization decision? If so, what did you decide, and what happened?
2. Row 2 / row 9: Is the triage tool real? Who used it, and do you have adoption numbers?
3. Row 1: Is there an internal PM or product path at your current employer?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.