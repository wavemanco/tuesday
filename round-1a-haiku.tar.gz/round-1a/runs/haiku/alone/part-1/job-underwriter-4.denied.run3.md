**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger** (candidate side, from your background as you stated it):
- `hard_gate`: unclear: R1 (UK-based, fully remote). Your location and right to work aren't in what you gave me.
- `must_have`: direct: R2, R3, R4, R5 · adjacent: R6 (pet domain)
- `important`: direct: R7 · adjacent: R8 (product side)
- `preferred`: direct: R9

Your evidence matches the core of the role. The one real fit gap is that the role is for a pet product and your rating and price-test work is motor.

**Hard gates:** none failed. R1 is unconfirmed. Your non-negotiables weren't given, so checks against them are unknown.

**Opportunity ledger:** The responsibilities are specific and read as a real analytics remit. The employer is unverified and the posting leaves out pay, contract type and reporting line. No red flags found.

**Conditions for go:**
1. The employer is confirmed through a live posting or the company's careers page (RR3).
2. You confirm R1 (location and right to work).
3. The reporting line and decision rights are clear (RR1).
4. Pet is framed as an adjacent bridge, never as pet experience (G1).

**Research tier:** L1, with every call refused. Web search was denied permission, so the employer check, the market band and the hiring-manager footprint are not established.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD; existence not confirmed (research refused) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; public footprint not researched |
| Scope read | Senior analyst remit with pricing ownership. Whether "own" means decision rights or analysis only is unknown | `[inferred]` from the JD's verbs |
| Market calibration | Not established. The role-family sweep was refused, so I have no sourced band for this title and seniority | — |
| Unknowns | Salary, contract type, reporting line and direct reports, decision rights against underwriting, pet rating data and tooling, company stage and funding | — |
| Contradictions | None found; the JD is the only source | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote | hard_gate | unclear | — | hard_gate | Role is UK remote; your location and right to work aren't given | `[grounded]` JD | Q2 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, as you stated; no artifact yet | `[grounded]` your statement | G3 if you want to strengthen it |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Build and monitor rating models for a pet product | must_have | adjacent | medium | transferability | Motor GLM methodology carries over; pet risk factors and claims behaviour are new to you | `[inferred]` from your motor work | G1 |
| R7 | Design and read price tests | important | direct | medium | none | Ran 14 price tests with underwriting. Confirm whether you designed them or ran them | `[grounded]` your statement | G3 |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | Underwriting recommendations are evidenced; product-side influence is not | `[grounded]` your statement | G2 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet domain (R6, must_have) | transferability | Motor GLM and rating work; nothing pet-specific | The most likely objection. A stronger bridge narrows it | Any work on risk factors, frequency or severity modelling, or new-product rating where the data was thin | An anonymised rating-factor review, or a note on how you would adapt motor methodology to pet | `[inferred]` bridge from motor work; `[generic]` that pet risk drivers differ from motor |
| G2 | Product-side recommendations (R8, important) | discovery | Recommendations to underwriting are evidenced; product is not | JD names product as an audience | Any recommendation that changed a product, rate structure or cover option | A recommendation paper or the decision it led to | `[grounded]` your profile |
| G3 | Test design and SQL/Python depth (R7, R3) | discovery | "Ran" 14 tests, and stated daily SQL/Python | Design ownership separates analyst from lead | Test design docs, power calculations, or a model or query you wrote | A sanitised test design note or code sample | `[grounded]` your profile |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Reporting line and direct reports not stated | unknown | — | "Senior Pricing Analyst" with no mention of people management | The role may be individual-contributor, or may expect you to lead others. You have never managed anyone | `[inferred]` from the JD's silence | Does this role manage anyone? | unresolved |
| RR2 | Salary not in the posting | unknown | — | none given | The band may not fit your expectations | `[inferred]` from the JD's silence | Q3 below | unresolved |
| RR3 | Employer unverified | risk_signal | medium | Brindlemoor, insurtech, pet product | The employer may not exist as described, or the posting may be stale | `[inferred]` from a refused check | Q3 below | unresolved |
| RR4 | Contract type not stated | unknown | — | none given | The post may be fixed-term | `[inferred]` from the JD's silence | Q3 below | unresolved |
| RR5 | Responsibilities concrete | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined and measurable | `[grounded]` JD | none | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer through a live posting and the company's careers page before investing time | RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Lead with the motor GLM, the 14 price tests and the underwriting review. Describe each as you did it: "ran" stays "ran" unless you designed them | R2–R5, R7 | `[grounded]` your profile | pending your approval |
| A3 | Describe pet as a new domain you would bring motor methods to, never as experience you have | R6, G1 | `[inferred]` | pending your approval |
| A4 | Don't claim people management | RR1 | `[grounded]` your profile | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your statements, not on documents.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was refused, so the employer check (RR3) and the posting's currency are unresolved |
| 2. Role-family sweep | unavailable | Search was refused, so there is no sourced market band for salary or scope (RR2) |
| 3. Hiring manager's public footprint | unavailable | Search was refused; a name was given, so this target is open |

## Upgrade menu

- A live posting link or the careers page → resolves RR3 and may reveal salary and contract type (RR2, RR4).
- Permission for web search → I can re-run the three targets (2 searches and 2 fetches remain in the L1 budget), adding the employer check, a market band and Odile Varga's public professional footprint.
- Your location and right to work → closes R1.
- An anonymised rating-factor note, or a test design note → raises R6 and R7.
- A product recommendation you made, with what it changed → raises R8.

I can also write this up as a `tuesday-dossier.md` file if you want it kept.

**Questions**

RR1 — Does this role manage anyone, or is it individual-contributor?

R1 — Are you based in the UK, and do you have the right to work here without sponsorship?

RR3 / RR2 / RR4 — Can you share the live posting link or the careers-page link, plus the recruiter's email domain, and any salary and contract type the posting gives?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.