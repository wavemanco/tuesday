**Probably worth applying to, but hold until two gates are checked.** Status: `hold_pending_answers`. Your must-haves line up well. The open questions are your location/work authorization and your pay floor. If either fails, this becomes a `no_go`.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver location), R2 (base pay against your floor)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar orchestration), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse, never used); unclear: R9 (data contracts analysts depend on), R10 (ingestion from app and CRM)

R8 — Snowflake-family dbt work carries over, with the BigQuery limit named; R9 and R10 — nothing in your background yet, R9 is asked below.

**Opportunity ledger.** Positive: RR1 the employer is established, RR2 the stated pay sits inside the market band. Open: RR3 equity is unstated, RR4 no hiring manager is named. RR5 is a low-severity scope risk.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** if G1 and G2 clear, the status moves to `conditional_go`, with the conditions being RR3 and RR4 answered in the first interview and R8 framed as adjacent. If location or pay fails, it becomes `no_go` with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring in 31 states; founded 2016, Denver; 264 employees; Series C $52M, February 2026 | `[grounded]` about page (surfaced in search); careers page fetched |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse on BigQuery, and data contracts for analysts | `[grounded]` JD |
| Seniority | "Senior" at 5+ years | `[grounded]` JD |
| Pay | $148,000–$166,000 base, plus equity | `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500. Typical scope is one domain's pipelines, usually without direct reports. The stated range sits around the median, with its top above the IQR's | `[generic]` Datawright 2026 report you pasted; not a claim about this employer |
| Scope read | Three areas named (ingestion, warehouse, contracts), wider than the one-domain norm | `[inferred]` from the JD set against the `[generic]` norm |
| Unknowns | Equity terms, reporting line, team size, your location and authorization, your pay floor | — |
| Contradictions | None between the JD and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material, so the gate is not settled | `[grounded]` JD | G1 |
| R2 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor is not in the material | `[grounded]` JD | G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated; no artifact yet, so the claim carries a probe caveat | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, stated; no artifact | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models, stated | `[grounded]` your background; `[inferred]` that Snowflake meets "a cloud warehouse" | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite; "set up" does not yet say who ran it in production | `[grounded]` your background | none |
| R8 | BigQuery warehouse (in the responsibilities, not the requirements list) | important | adjacent | medium | transferability | Snowflake-family dbt work carries over; BigQuery never used, which is the limit | `[inferred]` adjacency from R5 | G3 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in your background mentions contracts | `[grounded]` JD; CV silence | G4 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` JD; CV silence | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Location and work authorization (R1, hard_gate) | hard_gate | Location not in the material | Confirmation that you meet the location term | `[grounded]` JD |
| G2 | Pay floor (R2, hard_gate) | hard_gate | Floor not given | Confirmation that $148,000 base clears your floor | `[grounded]` JD |
| G3 | BigQuery (R8, transferability) | transferability | Snowflake dbt work, BigQuery never used | A small BigQuery project you can link or describe; the limit still gets named | `[inferred]` adjacency from R5 |
| G4 | Data contracts (R9, discovery) | discovery | No contract work in the background | Whether you have defined or owned contracts with consumers | `[grounded]` CV silence |
| G5 | App and CRM ingestion (R10, discovery) | discovery | No ingestion work named | Any ingestion you built from an application or CRM source | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer established | positive_signal | — | "Series C ($52M, February 2026)" | The entity exists and the posting is live | `[grounded]` careers page fetched; about page in search | What would the first six months of this role look like? | noted |
| RR2 | Stated pay inside the market band | positive_signal | — | "$148,000–$166,000" | The range sits near the median-to-upper part of the pasted band | `[generic]` pasted band; `[grounded]` JD figure | Where in the $148,000–$166,000 range would this level start? | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Equity value is unknown | `[grounded]` JD | What is the equity grant, its vesting schedule and strike price? | unresolved |
| RR4 | No hiring manager or team named | unknown | — | (the posting names none) | Reporting line and team size are unknown | `[grounded]` JD | Who would I report to, and how many engineers are on the data team? | unresolved |
| RR5 | Scope spans ingestion, warehouse and contracts | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse … data contracts" | One engineer may be carrying three areas that usually split | `[generic]` pattern for this span; the pay report's one-domain norm | Which of ingestion, the warehouse and the contracts would I own alone, and which would I share? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm location and work authorization for the remote-US or Denver term | Gate R1 | `[grounded]` JD | pending your approval |
| A2 | Confirm your pay floor against $148,000 base | Gate R2 | `[grounded]` JD | pending your approval |
| P1 | Lead with the 180-model dbt project and the Great Expectations suite | The strongest proof for R5 and R7 | `[grounded]` your background | pending your approval (positioning) |
| P2 | Describe BigQuery as not used yet; do not list it as experience | Keeps R8 honest | `[grounded]` your statement | pending your approval (positioning) |
| Q1 | Ask RR3, RR4 and RR5 verbatim on the first recruiter call | The register doubles as interview prep | `[grounded]` register | pending your approval |

No resume wording is drafted here. Any CV text will come as a separate proposal for your approval.

## Evidence status

Verified: none yet. Your background is CV-equivalent until you confirm specifics, so every row above is at `medium` or below.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "\"Pellucid Learning\" Series C funding" (returned the about page). Fetched pellucidlearning.com/careers/senior-data-engineer, whose text matches the JD. Moved: employer established (RR1); no contradictions |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you pasted already fixes the market band in role reality |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Dossier offer: I can write this up as a `tuesday-dossier.md` you can keep and reuse for prep.

**Upgrade menu**

- Your location and authorization (G1) → R1 resolves, and the status moves toward `conditional_go` or `no_go`.
- Your pay floor (G2) → R2 resolves.
- The equity terms from the recruiter → RR3 closes.
- The team and reporting line → RR4 and RR5 narrow.
- A linked BigQuery project or sandbox dbt work → R8 moves toward `direct`.
- A deeper pass on Pellucid (funding, leadership changes, recent news, public employee and candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Are you based in the US, and can you work remotely in the US or from Denver without sponsorship?

G2 — Is a $148,000 base above your floor? If not, what is your floor?

G4 — Have you defined, owned or maintained data contracts with analysts or other consumers? Describe one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.