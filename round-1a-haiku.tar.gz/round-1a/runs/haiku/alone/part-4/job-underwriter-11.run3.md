**Decisions:** Apply to Duinvaart. Skip Kroonhaven for now.

- **Duinvaart Cold Chain, Operations Analyst: `conditional_go`.** Your core fit is strong. Two hard gates are open (Rotterdam office three days a week, and right to work in the Netherlands), and I could not verify that the employer exists as described.
- **Kroonhaven Foods, Supply Planner: `no_go` for this role.** Three must-haves are absent from your background: planning experience, SAP IBP or a similar system, and fluent Dutch. This is a different job from the one you've done, not a rewording problem.

**Hard gates:**
- Duinvaart: location/schedule (Rotterdam, three days a week) and authorization are unknown for you. Neither is stated in your background.
- Kroonhaven: on-site Utrecht is unknown for you. Fluent Dutch is not a statutory gate, but the role runs a weekly S&OP meeting, and you've said your Dutch is conversational.

**Research tier: L1, searches 0 of 5, fetches 0 of 2.** The three searches I sent (company checks for both employers and one role-family pattern search) were refused by the host because web search permission was not granted. All three count against the budget as refused.

## Role reality

**Duinvaart (Operations Analyst, Rotterdam).** Stated responsibilities [grounded]: track on-time delivery and temperature compliance across a refrigerated fleet, build weekly Power BI dashboards, work with depot managers on route changes. Must-haves: 2+ years in logistics or operations analysis, strong SQL, Power BI or Tableau. Preferred: Dutch. The posting states no salary. Scope is operational analytics with a stakeholder component. Temperature compliance may carry regulatory accountability for cold-chain goods [inferred from the role's subject matter, not from the posting].

**Kroonhaven (Supply Planner, Utrecht).** Stated responsibilities [grounded]: own the 13-week supply plan for chilled ready meals, balance production capacity against forecast, run the weekly S&OP meeting. Must-haves: 3+ years of supply or demand planning in FMCG, advanced Excel, SAP IBP or similar, fluent Dutch. The posting states no salary. This is a planning-ownership role with a cross-functional meeting, not an analyst role. The 3-year requirement is the specific gap.

Market calibration: unavailable. No role-family pattern was retrieved, so none is stated here.

## Evidence map

**Duinvaart**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | must_have | 2+ yrs logistics/ops analysis | direct | medium | none | 4 yrs as ops analyst at a parcel carrier [grounded: your statement] |
| R2 | must_have | Strong SQL | direct | medium | none | Daily use [grounded] |
| R3 | must_have | Power BI or Tableau | direct | medium | none | Daily Power BI use [grounded] |
| R4 | must_have | Track on-time delivery | direct | medium | none | Built and owned the on-time dashboard depot managers use [grounded] |
| R5 | must_have | Track temperature compliance, refrigerated fleet | adjacent | low | transferability | No cold-chain or temperature data experience stated |
| R6 | must_have | Weekly dashboards; work with depot managers on route changes | direct | medium | none | Ran the weekly route-performance review [grounded] |
| R7 | preferred | Dutch | partial | low | capability | Conversational [grounded] |
| R8 | hard_gate | Rotterdam office, three days a week | unknown | n/a | location/schedule | Not stated for you |
| R9 | hard_gate | Right to work in the Netherlands | unknown | n/a | authorization | Not stated |

Confidence is "medium" for CV-only claims, because no artifact has been seen. That is the ceiling until something verifiable is provided.

**Kroonhaven**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | must_have | 3+ yrs supply/demand planning, FMCG | gap | n/a | capability | No planning experience [grounded: your statement] |
| R2 | must_have | Own a 13-week supply plan; balance capacity vs forecast | adjacent | low | transferability | Forecast-based operational analysis, not plan ownership |
| R3 | must_have | Advanced Excel | unknown | n/a | discovery | Not in your background |
| R4 | must_have | SAP IBP or similar planning system | gap | n/a | capability | None stated |
| R5 | must_have | Fluent Dutch | gap | n/a | capability | Conversational only [grounded] |
| R6 | must_have | Run the weekly S&OP meeting | adjacent | low | transferability | Ran the weekly route-performance review [grounded] |
| R7 | hard_gate | On-site in Utrecht | unknown | n/a | location | Not stated for you |

## Gap recovery queue

- **Duinvaart R5 (temperature compliance).** To close: any temperature, cold-chain, or regulated-goods data work. If none exists, state the gap and your learning plan.
- **Duinvaart R7 (Dutch).** To close: a language certificate or a working-language example. Otherwise, state it honestly.
- **Kroonhaven R1, R4, R5.** To close: none in the near term. These are the three rows that decide the verdict.
- **Kroonhaven R3 (Excel).** To close: a sample of your advanced Excel work, such as a forecast model or capacity calculation.

## Opportunity risk register

**Duinvaart**

| Class | Severity | Entry |
|---|---|---|
| Unverified employer | medium | Employer existence and posting status could not be checked (research refused). This is a standing entry and keeps the decision at conditional. |
| Mismatch: pay | medium | No salary stated. Compensation cannot be compared with your floor. |
| Scope | low | Temperature compliance may carry regulatory accountability [inferred]. |

**Kroonhaven**

| Class | Severity | Entry |
|---|---|---|
| Mismatch: experience | high | Requires 3+ years of planning; you have none. |
| Mismatch: language | high | Fluent Dutch is required for a role that runs a meeting. Conversational is not enough. |
| Mismatch: tooling | medium | SAP IBP or a similar system is required, with no stated exposure. |
| Unverified employer | medium | Same as Duinvaart. |

## Application plan

**Duinvaart: apply.**
- Lead with the on-time delivery dashboard and the route-performance review. Both match the role's core work directly.
- Say plainly that cold-chain temperature work is new to you, and give a concrete plan for learning it. Do not imply experience you lack.
- State your Dutch as conversational, with a timeline if you have one.
- Resume edits: none drafted. Any wording will be proposed for your approval before it goes anywhere.

**Kroonhaven: do not apply now.** If you want to pursue planning-adjacent work, look at demand or supply analyst roles or S&OP analyst roles. I have not checked any of them, so their requirements are [generic] at best.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page (both employers) | unavailable | Web search permission not granted |
| 2 | Role-family sweep (market scope, title, pay) | unavailable | Web search permission not granted |
| 3 | Hiring manager's public footprint | n/a | No name given |

## Dossier offer

If you want, I can save this analysis as `tuesday-dossier.md` so it carries into your next session.

## Upgrade menu

- **Permission to web-search** → verifies both employers exist and their postings are live, and adds salary bands and planning-role norms. Runs within the L1 budget.
- **Live posting links** → confirms the requirement text against the official listing.
- **Your advanced Excel level and any forecast or capacity work** → moves Kroonhaven R3 and possibly R2.
- **Right-to-work status** → closes Duinvaart R9.
- **Your minimum salary** → lets the compensation mismatch be assessed in both postings.

## Questions

1. **Duinvaart (R8, R9):** Can you work in Rotterdam three days a week, and do you have the right to work in the Netherlands without sponsorship?
2. **Kroonhaven R3 and Duinvaart R5:** How advanced is your Excel (pivot tables, lookups, forecast models), and have you worked with any temperature or cold-chain data?
3. **Both postings:** What is your minimum acceptable salary? Neither posting states pay.

Answer any or all. "Skip" is a fine answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.