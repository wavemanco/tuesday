**Decision snapshot**

- **Decision: `conditional_go`.** Apply, once the employer and live posting are confirmed. You meet every essential requirement as stated. The gaps are caseload ownership, leg-ulcer and continence depth, and Doppler, which is only desirable.
- **Fit ledger:** Meets, Partial, Gap, Unknown, by priority, in the Evidence map below.
- **Hard gates:** all met as stated. NMC registration (active), full UK driving licence (category B), and location (you live in Halifax, the role is Halifax). Your NMC registration and licence are for you to check.
- **Confidence:** every fit call rests on your CV, so it is a lead, not verified evidence.

Research tier: L0 — no searches

**Role reality** (from the advert only)

- Community Staff Nurse, Band 5, Calderbrook Community Health CIC, Halifax. District nursing for housebound adults in their homes.
- Stated scope: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all recorded electronically.
- You would hold a small caseload, supported by a senior community nurse. Pool cars and mileage are provided.
- Pay: £31,050–£37,800 plus mileage `[grounded]`. I have not compared this to any band, because that needs research.
- Contradictions: none in the text. The employer is unverified (see risk register).

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap |
|---|---|---|---|---|---|
| 1 | Current NMC registration, Adult | Essential, hard gate | Meets | CV claim | None |
| 2 | Full UK driving licence | Essential, hard gate | Meets | CV claim | None |
| 3 | At least 1 year post-registration | Essential | Meets (5 years) | CV claim | None |
| 4 | Home visits and working in patients' homes | Implied by role | Meets, transferable | CV claim | None |
| 5 | Wound care, pressure and surgical wounds | Must | Partial | CV claim | Leg-ulcer specifically not stated; transferable |
| 6 | Catheter care | Must | Meets | CV claim | Continence care not stated; discovery |
| 7 | Insulin administration | Must | Meets | CV claim | None |
| 8 | Clear, timely written records | Essential | Unknown | None | Not evidenced; discovery |
| 9 | Electronic patient record | Stated | Unknown | None | Not stated; discovery |
| 10 | Own caseload, supported by senior nurse | Must | Gap | Candidate-stated | Never held a caseload; capability |
| 11 | End-of-life visits | Must | Unknown | None | Not stated; discovery |
| 12 | Care planning | Must | Unknown | None | Not stated; discovery |
| 13 | Doppler assessment for leg ulcers | Desirable | Gap | Candidate-stated | Not held; capability, may be trainable (not established) |

**Gap recovery queue** (no questions here; the questions are below)

- Row 10, caseload: closed by evidence of planning and running your own visit lists, or by the employer's onboarding plan.
- Rows 5 and 13, leg ulcers and Doppler: closed by any leg-ulcer dressing experience, or by a funded training route.
- Rows 8, 9, 11, 12: closed by evidence on the ward or in discharge work.

**Opportunity risk register**

| Class | Severity | Entry |
|---|---|---|
| Failed attribution (unverified employer) | Medium, standing | I cannot confirm that Calderbrook Community Health CIC exists as described. This is why the decision is conditional. Resolve with the live posting link or the employer's careers page. |
| Caseload-first role | Medium | No prior caseload. Ask about onboarding and supervision before you accept. |
| Unestablished pay comparison | Low | The stated range is not compared to any band. Confirm the pay framework with the employer. |
| Desirable skill gap | Low | Doppler is not held. Ask whether the employer funds training. |

Positive signals `[grounded]`: senior nurse support, pool cars, mileage, and a role that matches your home-visit work.

**Application plan** (`resume_edits_pending_approval`; nothing is sent without your approval)

- Lead with 18 months of home visits in the first week after discharge, plus wound, catheter and insulin work.
- Do not claim caseload, Doppler or end-of-life experience unless you have it. "Visited patients at home" is accurate; "managed a caseload" is not, until it is true.
- Consider contacting Rhiannon Mabbott for the informal chat the advert offers. You can ask about caseload onboarding, Doppler and continence training directly.

**Evidence status** (one row per declared target)

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 selected; research not consented |
| 2. Role-family sweep (scope, title, pay) | skipped | L0 selected; research not consented |
| 3. Hiring manager public footprint | n/a | No hiring manager named; contact given is a team lead, not researched |

Your NI number is not needed for this assessment, so I have not used it.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file for later use with mock-interview prep.

**Upgrade menu:**
- Research at L1 would check the employer exists, that the posting is live, and the pay band against role-family norms.
- A link to the live posting would resolve the employer question faster than research.
- A line from your ward or discharge manager on your documentation would raise row 8.

**Questions**

1. In your discharge-to-assess work, did you plan your own visit lists and document them, or were visits assigned to you? (Row 10.)
2. Have you dressed leg ulcers, done continence assessments, or taken part in end-of-life visits, even on the ward? (Rows 5, 6, 11.)
3. Shall I run the L1 check on the employer and pay band? Reply with answers, "skip" to pass on a question, or "check it" to run the research.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.