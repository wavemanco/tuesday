**Worth applying to, with conditions. Status: `conditional_go`.** Your registration, driving licence, post-registration years, wound care, catheter care and insulin administration all match the essential criteria on your CV. The real gaps are owning a caseload, which you haven't done, and Doppler, which is desirable. The employer checks out as a real organisation, but I could not find the vacancy on its careers page, so the posting itself is unverified.

**Fit ledger.**

- `hard_gate`: direct: R1 (NMC registration), R2 (full UK driving licence)
- `must_have`: direct: R4 (one year post-registration), R5 (wound care), R7 (catheter care), R8 (insulin administration) · adjacent: R9 (care planning) · unclear: R12 (clear, timely written records)
- `important`: adjacent: R10 (own caseload) · unclear: R11 (end-of-life visits), R13 (electronic patient record) · direct: R3 (lives in Halifax)
- `desirable`: absent: R14 (Doppler assessment)

Hard gates: none failed (R1 `direct`, R2 `direct`). Unconfirmed: none.

**Opportunity ledger.** The employer is real and consistent with the advert (RR3). The posted pay sits inside the role-family range, though its floor is below the middle of that range (RR4). Two things are unknown: whether the post is live as advertised (RR1) and how caseloads are supervised (RR2).

- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm the advert is live and matches the description; (2) confirm how caseloads and the senior nurse's support work in practice; (3) describe your discharge-to-assess visits accurately as home visits, not as district nursing or caseload work.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff; four locality hubs | `[grounded]` company About page, fetched |
| Mandate | Caseload-holding district nursing for housebound adults in their homes: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic record | `[grounded]` advert |
| Working pattern | Pool cars provided; mileage paid. Caseload supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage. The survey's middle half for Band 5 community staff nurses is £32,400–£36,600 and its median is £34,300, so the advertised range is broadly in line, with a lower floor | `[generic]` Wardround 2026 survey (n=1,240); `[grounded]` advert |
| Team | Rhiannon Mabbott leads the Halifax district nursing team, after 11 years as a district nurse; she has publicly spoken on leg-ulcer clinics and Doppler training for staff new to community work | `[grounded]` public speaker page |
| Unknowns | Whether the post is live; caseload size and supervision; whether Doppler training is provided; EPR system | — |
| Contradictions | None found between the advert and the company's public description. The careers page could not be located, so the advert is unchecked against it | — |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | high | none | CV states active registration, revalidation due March 2028 | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | high | none | CV states full licence, category B | `[grounded]` CV | none |
| R3 | Based in Halifax | important | direct | high | none | CV states you live in Halifax | `[grounded]` CV | none |
| R4 | One year or more post-registration experience | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` CV | none |
| R5 | Wound care (pressure, surgical, leg ulcers) | must_have | direct | high | presentation | Pressure and surgical wounds evidenced; leg ulcers not stated, so that part is adjacent | `[grounded]` CV | Name leg-ulcer exposure if you have it (Q3 in the closing block) |
| R6 | Leg-ulcer care specifically | important | adjacent | medium | capability | Wound care transfers; no leg-ulcer work on the CV | `[inferred]` from R5 | Upgrade menu |
| R7 | Catheter and continence care | must_have | direct | medium | presentation | Catheter care is stated; continence is not | `[grounded]` CV for catheters | Confirm continence experience (Q3) |
| R8 | Insulin administration | must_have | direct | high | none | Stated on CV | `[grounded]` CV | none |
| R9 | Care planning | must_have | adjacent | medium | transferability | Discharge-to-assess work involved assessing patients at home in the first week; formal care planning is not stated | `[inferred]` from the discharge role | Q2 |
| R10 | Holding your own caseload | important | adjacent | medium | transferability | Home visits without a caseload of your own; supervised by a senior | `[grounded]` CV for visits; `[inferred]` for the gap | Q2 |
| R11 | End-of-life visits | important | unclear | low | discovery | CV silent; you may have done them on the ward | `[grounded]` CV silence | Q3 |
| R12 | Clear, timely written records | must_have | unclear | low | discovery | CV silent | `[grounded]` CV silence | Q3 |
| R13 | Electronic patient record | important | unclear | low | discovery | CV silent | `[grounded]` CV silence | Q3 |
| R14 | Doppler assessment for leg ulcers (desirable) | desirable | absent | none | capability | No evidence; the employer's public emphasis suggests it matters to them | `[grounded]` CV silence; `[grounded]` speaker page for the emphasis | Upgrade menu |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R10) | transferability | Home visits within a seconded team; no caseload of your own | Likely interview probe for a post built around a caseload | Any patient list or discharge follow-up you managed alone | Caseload examples; a sanitised care-plan note | `[grounded]` CV; `[inferred]` on the probe |
| G2 | Doppler (R14) | capability | None on CV | Desirable, but the employer's public emphasis points at it | Any vascular or leg assessment training | A course certificate, or a stated willingness to train | `[grounded]` speaker page |
| G3 | Records, EPR, end-of-life (R11–R13) | discovery | CV silent | Essential-sounding for the role | Ward documentation, EPR use, end-of-life care | Anonymised record samples (approval needed) | `[grounded]` CV silence |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Advert not found on the company's careers page | unknown | — | "Current vacancies are listed on our careers page" | The posting may be closed or the company may use a different platform | `[grounded]` About page; careers page not located in search | Can you send the live advert link or the recruiter's email domain? | unresolved |
| RR2 | Caseload size and supervision not stated | unknown | — | "a small caseload… supported by a senior community nurse" | Support may be informal; the caseload could be larger than "small" in practice | `[inferred]` from the advert's wording | What is the typical caseload size and how is it supervised? | unresolved |
| RR3 | Company exists as described | positive_signal | — | "410 staff working from four locality hubs" | The employer is stable enough to hire for this post | `[grounded]` About page | — | noted |
| RR4 | Posted pay is within the survey's range, with a lower floor | risk_signal | low | "£31,050–£37,800" | The offer may start near the floor | `[generic]` survey; `[grounded]` advert | — | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Rephrase your discharge-to-assess role as "home visits to patients in their first week after discharge, within a seconded team" | Keeps the home-visit experience without claiming caseload or district nursing | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Name wound, catheter and insulin work with specific examples in your cover letter | Covers the essential criteria | `[grounded]` CV | pending your approval |
| A1 | Confirm the advert is live via the recruiter or the careers page before applying | Resolves RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask about Doppler training in the interview | Resolves R14 | `[grounded]` R14 | pending your approval |

The reframing check holds: I have not described your discharge work as community caseload or district nursing, and I have not claimed leg-ulcer or Doppler experience you don't have.

**Evidence status.** Verified: R1, R2, R4, R5, R8 (sources: your CV). Unverified: everything else. Rejected: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read none

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and fetched calderbrookhealth.example/about: adult community nursing under an NHS contract, founded 2015, 410 staff. Searched the careers page: not found, so the advert is unchecked against it (RR1) |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary"; returned the Wardround 2026 UK Community Nursing Pay Guide (median £34,300, middle half £32,400–£36,600). Moved the pay calibration (RR4) |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; returned communitynursingforum.example/speakers/rhiannon-mabbott. Moved the team read and the Doppler emphasis (R14) |

**Upgrade menu.**
- The live advert or the recruiter's email domain → RR1 closes.
- Caseload examples or any patient-list experience → G1 and R10 move.
- A Doppler or vascular assessment course → R14 moves from absent.
- Any leg-ulcer experience → R6 moves to direct.
- A deeper research pass on Calderbrook (leadership changes, past recruitment, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` file.

1. Have you ever had a patient list of your own, even informally, such as discharge follow-ups you managed alone? How were your visits planned and recorded? (G1, R10)
2. Have you done any leg-ulcer work, continence care, end-of-life visits, or worked on an electronic patient record? (R5–R7, R11–R13)
3. Can you send the live advert link or the recruiter's email, so I can confirm the posting is current? (RR1)

Reply with answers, or say "skip" for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.