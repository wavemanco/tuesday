**Yes, apply. Status: `go`.** On the fit side, you meet all four essentials. The opportunity side has no red flags, and the pay is in the usual range. The one thing to check before you apply is that the posting is still live on Calderbrook's careers page.

**Fit ledger.**
- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R6a · adjacent: R4, R5, R7, R8
- `important`: adjacent: R6b · unclear: R9
- `preferred`: absent: R10

R5 — your home visits in discharge-to-assess are the closest thing to a caseload, but you have never owned one. R10 — Doppler, which you have never done.

**Hard gates:** none failed (R1 `direct`, R2 `direct`); location matches (Halifax); pay floor not given, so the pay check is unknown.

**Severe red flags:** none found.

**Opportunity ledger.** Clean. The role has a named supervisor, a clear caseload model, a posted pay range and pool cars (RR2, RR3). The unknowns are the posting's live status (RR1) and whether Doppler is trained in-role (RR4).

**What would change this:** if the live posting can't be found, or if Calderbrook's pay sits below your floor, it becomes `conditional_go` or `hold`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Calderbrook Community Health CIC: adult community nursing under an NHS contract, across Calderdale, 410 staff, four hubs | `[grounded]` calderbrookhealth.example/about |
| Role | District nursing for housebound adults; small own caseload, senior community nurse support | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` JD |
| Market calibration | Median basic pay for a Band 5 community staff nurse in England is £34,300 (IQR £32,400–£36,600); 61% of respondents were paid mileage, 24% had a pool or lease car | `[generic]` Wardround 2026 pay guide (n=1,240), search snippet only |
| Unknowns | Whether the posting is live; whether Doppler is trained in-role; EPR system used | — |
| Contradictions | None found between the JD and the About page | — |

The posted range sits within the market band. Its bottom is below the interquartile range and its top is above it. The provided pool car is worth noting, since about a quarter of comparable roles offer one.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult | hard_gate | direct | high | none | `[grounded]` user-stated; check on the NMC register yourself |
| R2 | Full UK driving licence | hard_gate | direct | high | none | `[grounded]` user-stated, category B |
| R3 | At least one year post-registration | must_have | direct | high | none | `[grounded]` five years, acute medical ward |
| R4 | Clear, timely written records (on an EPR) | must_have | adjacent | medium | discovery | `[grounded]` acute and discharge-to-assess documentation; no EPR named |
| R5 | Own caseload, with support | important | adjacent | medium | transferability | `[grounded]` home visits, first week after discharge; no caseload held |
| R6a | Wound care | must_have | direct | high | none | `[grounded]` pressure ulcers, surgical wounds |
| R6b | Leg-ulcer care | important | adjacent | medium | transferability | `[inferred]` from R6a; leg ulcers not stated |
| R7 | Catheter and continence care | must_have | adjacent | medium | discovery | `[grounded]` catheter care; continence not stated |
| R8 | Insulin administration and care planning | must_have | adjacent | medium | transferability | `[grounded]` insulin; community care planning not stated |
| R9 | End-of-life visits | important | unclear | low | discovery | `[grounded]` silence in your CV |
| R10 | Doppler assessment (desirable) | preferred | absent | none | capability | `[grounded]` you have not done it |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it |
|---|---|---|---|---|
| G1 | Own caseload (R5) | transferability | Visits in discharge-to-assess were autonomous but time-limited, with no ongoing caseload | Evidence that you planned and followed up care yourself |
| G2 | End-of-life and continence (R7, R9) | discovery | Not in your CV | Any such visits or patients |
| G3 | EPR records (R4) | discovery | Documentation described, but not the system | Which EPR, and what you charted in it |
| G4 | Doppler (R10) | capability | No evidence | A training course or in-role teaching (see RR4); this is a closure path, not a blocker, since the post marks it desirable |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting live not confirmed | unknown | — | "Current vacancies are listed on our careers page" | The advert may have closed or been filled | `[inferred]` from the About page's pointer to a careers page I did not check | Is this post still open, and who would I be interviewing with? | unresolved |
| RR2 | Pay within market band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | — | `[grounded]` JD, `[generic]` band | — | noted |
| RR3 | Clear supervision and caseload model | positive_signal | — | "supported by a senior community nurse" | Scope and support are defined | `[grounded]` JD | — | noted |
| RR4 | Doppler training | unknown | — | "Desirable: Doppler assessment" | Calderbrook may train it in-role; a forum talk by the team lead covered Doppler training for staff new to community work | `[inferred]` from the search snippet of the speaker's 2025 talk | Do you train staff in Doppler assessment after they join, and what sign-off is needed? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the discharge-to-assess home visits, and describe the wound, catheter and insulin work in community terms | Closest evidence to the role | `[grounded]` your CV | pending your approval |
| E2 | Say plainly that you have not held a caseload and have not done Doppler; name your plan for both | Honest framing; the interview will probe it | `[grounded]` R5, R10 | pending your approval |
| A1 | Use the informal chat with Rhiannon Mabbott to ask the three questions below | The team lead's public focus is Doppler and community leg-ulcer work | `[grounded]` search snippet | pending your approval |

Rhiannon Mabbott's public profile (a community nursing forum speaker page) is the only footprint I looked at. I did not look for anything else about her.

## Evidence status

Verified: R1, R2, R3 claims (user-stated, not checked against the NMC register or licence). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community nursing"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). Confirms the employer exists as described. The careers page was not fetched, so the posting's live status is still unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary NHS 2026 Agenda for Change", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Read from the search snippet only, not fetched. Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned her community nursing forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved RR4 and A1 |

## Upgrade menu

- A link to Calderbrook's careers page or the live posting → resolves RR1.
- A sanitised example of a discharge plan you wrote → R4 to `high`.
- Any Doppler training record, or your EPR experience → R10 and R4.
- Your pay floor → the pay check moves from unknown to met or failed.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can save this assessment as `tuesday-dossier.md` at the end of our work.

Three questions, tagged to the gap rows:

G1 — On discharge-to-assess, did you decide each visit's priorities and follow up the plan yourself? Give me one case.
G2 — Have you done any end-of-life or continence visits at home, or been the nurse for a patient at end of life?
G3 — Which electronic records system have you used, and what did you chart in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.