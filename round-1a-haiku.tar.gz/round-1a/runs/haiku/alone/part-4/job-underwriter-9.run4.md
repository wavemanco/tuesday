## Decision snapshot

**Decision: `conditional_go`.** Accept only after you have confirmed the offer through a channel you found yourself, not through the email's links or contact details. Share the bank, PPS and passport details only through the portal, once that check is done.

**Fit ledger (candidate side):** strong on the core requirements, with one real gap (pension changes) and one unverified detail (Irish PAYE/PRSI/USC depth).

**Hard gates:** none known to fail. Hybrid location (Limerick, two days a week), pay floor and notice period are **unknown**, because you haven't told me your constraints. Please confirm them before you accept.

**Confidence:** medium overall. The fit side rests on your own account. The employer side rests on your in-person interviews and the offer email, and I have not checked the company online.

## Research tier

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Marrowgate official site and careers page | skipped | Research not yet consented; L0 in use |
| 2 | Role-family sweep (Irish payroll, €38–42k) | skipped | Research not yet consented; L0 in use |
| 3 | Hiring manager's public footprint (Declan Garvagh) | skipped | Research not yet consented; L0 in use |

## Role reality

- **Role:** Payroll Administrator, permanent, reporting to Declan Garvagh, Finance Manager. Hybrid with two days a week in the Limerick office. Salary €38,000–€42,000; the offer is €40,000 `[grounded]`.
- **Scope:** monthly payroll for 240 staff; starters, leavers and pension changes; monthly payroll-to-ledger reconciliation; staff payroll queries `[grounded]`.
- **Market calibration:** the offer sits at the midpoint of the posted band `[grounded]`. I have no market data for Limerick housing associations, so I can't say whether the band is normal `[generic]`.
- **Unknowns:** the posting doesn't say whether the 240 staff are paid monthly or on another cycle, nor whether pension changes are administered in-house or by a provider. Both would change the scope.

## Is the onboarding request normal?

Yes, the three requests are standard for an Irish employer once you have accepted. They are not a red flag in themselves. The risk is the channel and the timing.

- **Bank details for salary:** normal `[grounded]`. Employers need them to pay you.
- **PPS number:** normal `[generic]`. Employers use it for PAYE and PRSI returns to Revenue. You'd know this from your payroll work.
- **Passport for right-to-work:** normal `[generic]`. Employers must make sure you can work in the State, and checking an original passport and keeping a copy is common practice. Ask what they keep, why, and for how long. The Data Protection Commission governs this.
- **Original passport on day one:** consistent with normal practice `[generic]`.

**Your instinct is right for unsolicited requests, not for a real offer after interviews.** The concern is verifying the sender before you hand over sensitive data.

## Evidence map (requirement by requirement)

| # | Requirement | Priority | Fit | Confidence | Gap | Basis |
|---|---|---|---|---|---|---|
| 1 | 2+ years running payroll | must-have | met | high | none | 3 years, hotel group, fortnightly, 90 staff `[grounded]` |
| 2 | Working knowledge of Irish PAYE, PRSI, USC | must-have | likely met | medium | presentation | Payroll Technician cert; Irish depth not described |
| 3 | Strong Excel | must-have | met | medium | none | daily pivots, XLOOKUP; self-reported |
| 4 | Payroll qualification or working towards | must-have | met | high | none | Payroll Technician certificate, 2024 |
| 5 | Starters and leavers | stated scope | met | high | none | prior role |
| 6 | Monthly payroll-to-ledger reconciliation | stated scope | met | high | none | prior role |
| 7 | Monthly run for 240 staff | stated scope | partly met | medium | transferability | you ran 90 staff, fortnightly |
| 8 | Pension changes | stated scope | not met | low | discovery | you have never done these; your manager did |
| 9 | Staff payroll queries | stated scope | likely met | medium | presentation | not stated in your background |

## Gap recovery queue

- **Row 8, pension changes (discovery):** this is the main gap. Find out what you observed of your manager's pension work (contribution changes, opt-outs, provider submissions) and whether you have touched any of it. That exposure closes part of the gap.
- **Row 2, Irish PAYE/PRSI/USC:** if you have filed Revenue returns, run statutory deductions in Ireland, or worked with RPN/ROS, say so. That would move this from medium to high confidence.
- **Row 7, scale and cycle:** the move from 90 fortnightly to 240 monthly is a transferability gap. Reconciliation and error-checking experience carries over; ask about the cycle and provider set-up.

## Opportunity risk register

| Risk | Class | Severity | Note |
|---|---|---|---|
| Employer not independently verified | verification | medium | Your in-person interviews reduce this; a check via the company's own site and phone number closes it |
| Sensitive-data request via email link | channel | medium | Use the portal only after confirming the company's own domain |
| Pension gap in a stated responsibility | capability | medium | Can be closed by discovery questions or a short handover |
| Pay position | mismatch | low | €40k sits at the midpoint of the posted band `[grounded]` |
| Hybrid commute and notice period | unknown | unknown | Not stated by you yet; hard-gate status unknown |

## Application plan

1. **Before accepting (within five working days):** call Marrowgate on a number from their official website, not from the email. Ask Declan Garvagh's office or the People Team to confirm the offer and the onboarding process. Check that any portal address matches the company's domain.
2. **Accept by reply** if the confirmation checks out. Accepting doesn't require sending any sensitive data.
3. **Before uploading anything:** ask what data they retain, why, for how long, and who can see it. Only then use the portal.
4. **Pension gap:** prepare a short, honest account of what you observed and what you'd want shown in your first month.

## Evidence status and offers

**Dossier offer:** I can save this as `tuesday-dossier.md` for later use if you'd like.

**Upgrade menu:**
- **L1 research (consent needed):** checks Marrowgate's careers page and website, a role-family pay sweep for Irish payroll, and Declan Garvagh's public professional footprint. This would confirm the employer exists as described and firm up the pay calibration.
- **Your constraints (pay floor, commute, notice period):** lets me complete the hard-gate check.
- **Pension detail from your previous job:** raises row 8 from low confidence.

**Questions:**
1. What's the lowest salary you'd accept, and can you commute to Limerick two days a week?
2. Have you filed Revenue returns or run Irish statutory deductions yourself, and what do you know about how pension changes were processed in your last role?
3. Do you want me to run the research check (L1) on Marrowgate? It would use up to 5 searches and 2 page fetches.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.