**Decision: no_go. Don't send anything to this recruiter.** The posting may be real, but the messages match a well-known fake-job scam, and that's enough to stop.

**Decision snapshot**
- **Opportunity:** no_go. Three requests are red flags: an upfront €349 "equipment" fee, a cheque to lodge and partly forward, and IBAN, PPS number and passport photo before any real interview.
- **Candidate fit:** strong on the listed requirements (below). That doesn't change the decision.
- **Hard gates:** none of the role's own terms block you. The payment and identity requests are the blockers.
- **Research tier:** L0, no searches. The verdict rests on the messages you pasted, not on the company's existence.

**Role reality**
- Remote Order Processing Coordinator, Velloway Logistics. 15–30 h/week, up to €26/h plus commission per order. [grounded, from the posting]
- Pay arithmetic: 15–30 h × 52 weeks × €26 ≈ €20,300–€40,600 before commission. Reaching your €30,000 floor takes about 22–23 paid hours a week. [grounded, arithmetic]
- Hiring runs entirely on Telegram, with no calls or video, and the "interview" was a chat. [grounded]
- Contact address velloway.hr@postmail.example is a generic mail domain, not a company domain. I could not verify that the company exists. [inferred, L0]

**Evidence map (requirements against your background)**

| Requirement | Evidence | Fit |
|---|---|---|
| Customer service and order handling | 3 years as a parcel-courier agent, ~60 Zendesk tickets/day [grounded, your statement] | Strong |
| Spreadsheets | Keeps the team's weekly Excel tracker [grounded] | Strong |
| Training others | Trained two new starters [grounded] | Strong |
| Attention to detail | Implied by tracker work [inferred] | Moderate |
| Written English | Not stated [unknown] | Unknown |
| Quiet workspace | Not stated [unknown] | Unknown |

**Gap recovery queue:** none that matters for this role. The open question is the employer's legitimacy, and no candidate-side gap closes that.

**Risk register**

| Class | Severity | Evidence |
|---|---|---|
| Pay-to-work: €349 "refunded with first wages" | Severe | Posting messages [grounded]; standard scam pattern [generic] |
| Fake-cheque overpayment: lodge €2,850, keep €350, forward the rest | Severe | Cheques can be credited and then returned unpaid, leaving you owing the bank the amount you sent on. This is also the money-mule pattern. [generic] |
| Identity harvesting: IBAN, PPS number, passport photo before any interview | Severe | Enough for identity fraud. [grounded + generic] |
| Telegram-only, chat "interview", no calls or video | High | [grounded] |
| Unverified employer, generic mail domain | High | [inferred, L0] |

**Application plan**
1. Stop replying. Don't send your IBAN, PPS number, passport photo or any money. Don't lodge a cheque if one arrives, and take it to your bank instead.
2. Screenshot the chat and save the posting and its URL before you close anything.
3. Report the listing to the jobs site, report the Telegram account, and report to the Gardaí.
4. **If you've already sent details:** contact your bank now, change your email and banking passwords, watch your statements, and tell the Gardaí. If your PPS number went out, tell the Department of Social Protection too.
5. If you want Velloway's real vacancies, find them through its own website and apply there. Don't use Telegram.

Don't paste your IBAN into any chat again, including this one.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| L1-1: company site and careers page | skipped | Research not requested. The verdict doesn't depend on it. |
| L1-2: role-family sweep (scope, title, pay) | skipped | Same |
| L1-3: hiring manager's public footprint | n/a | No name was given |

I can write this up as a `tuesday-dossier.md` file if you want to keep it.

**What would change the picture:** a link to the live posting, Velloway's own careers page, or the original jobs-site listing. Even if the company turns out to be real, a legitimate employer doesn't ask for an advance payment or identity documents before hiring.

**Questions**
1. Have you sent anything yet, even the passport photo or PPS number? That decides which of the steps above apply.
2. Do you want me to run a light check on Velloway Logistics (up to 5 searches and 2 page fetches)?
3. Do you want a short reply to the recruiter declining, or would you rather not reply at all? I'd draft it for your approval before anything is sent.

Answer in prose, or say "skip" to any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.