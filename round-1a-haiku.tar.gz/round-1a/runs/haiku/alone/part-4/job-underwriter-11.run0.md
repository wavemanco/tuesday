## Decision snapshot

**Duinvaart Operations Analyst: `conditional_go`.** Apply, once you've checked the Rotterdam commute. Your core toolkit matches the job: SQL, Power BI, on-time delivery reporting and the route-performance review. The open items are the temperature-compliance side and whether you can do three office days a week in Rotterdam.

- **Fit ledger.**
  - `hard_gate`: unclear: D9 (Hybrid, three days a week in Rotterdam office)
  - `must_have`: direct: D1, D2, D3; adjacent: D4 (on-time tracking across a refrigerated fleet); unclear: D5 (temperature compliance)
  - `important`: direct: D6; adjacent: D7 (route changes)
  - `preferred`: adjacent: D8 (Dutch a plus)
- **Hard gates:** none failed; unconfirmed: D9 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Opportunity ledger.** Clean and specific: the deliverables are named (D-RR3). Pay is withheld (D-RR1), and it's unclear whether the role decides routes or advises on them (D-RR2).
- **Severe red flags:** none found.
- **Conditions for go:** (1) D9 is workable for you; (2) D5 holds up, meaning you have temperature or cold-chain data experience or a credible plan to learn it; (3) D-RR2 resolves to a role you can stand behind.

**Kroonhaven Supply Planner: `no_go`, as posted.** Two must-haves are absent: three years of planning and owning the 13-week plan. You've never worked in planning, and that can't be closed quickly. The posting itself looks legitimate.

- **Fit ledger.**
  - `hard_gate`: unclear: K7 (On-site in Utrecht)
  - `must_have`: absent: K1 (3+ years FMCG supply or demand planning), K2 (own 13-week plan, balance capacity against forecast); unclear: K5 (SAP IBP or a similar planning system); adjacent: K6 (fluent Dutch)
  - `important`: adjacent: K3 (weekly S&OP meeting); unclear: K4 (advanced Excel)
- **Hard gates:** none failed; unconfirmed: K7 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Opportunity ledger.** Well scoped, with a named owner (K-RR1). Team size and reporting line are unknown (K-RR2).
- **Severe red flags:** none found.
- **What would change this:** planning experience you haven't mentioned, even part-time supply, demand or production planning, would move this to `hold_pending_answers`. From what you've told me, I don't expect that.

## Role reality

| Element | Duinvaart | Kroonhaven | Provenance |
|---|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` posting |
| Mandate | On-time delivery and temperature compliance; weekly Power BI dashboards; route changes with depot managers | Own the 13-week supply plan; balance capacity against forecast; run weekly S&OP | `[grounded]` posting |
| First-year outcomes | Not stated | Not stated | `[grounded]` absence |
| Working pattern | Hybrid, three office days in Rotterdam | On-site in Utrecht | `[grounded]` posting |
| Scope read | Normal analyst scope | Full planning-owner scope, senior to your background | `[inferred]` from the listed responsibilities |
| Unknowns | Pay; route-change authority; team size | Pay; team; reporting line; planning system in use | — |
| Contradictions | None in the posting | None in the posting | `[grounded]` |
| Employer and market checks | Not run (research unavailable) | Not run (research unavailable) | — |

## Evidence map

Your background is self-reported, so confidence tops out at `medium` until something inspectable exists.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier, self-reported, not inspected | `[grounded]` your background | Keep employer and title ready for references |
| D2 | Strong SQL | must_have | direct | medium | none | Daily SQL use, self-reported; "strong" is unmeasured | `[grounded]` your background | Prepare one sanitized query as a work sample |
| D3 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use, self-reported | `[grounded]` your background | Same work sample as D2 |
| D4 | Track on-time delivery across a refrigerated fleet | must_have | adjacent | medium | transferability | On-time tracking carries over; your experience is parcels, not refrigerated trucks, and cold chain is not exercised | `[inferred]` bridge from your parcel on-time dashboard | Present as adjacent, with the limit named |
| D5 | Track temperature compliance | must_have | unclear | none | discovery | Nothing in your background covers temperature data | `[grounded]` absence | Question Q2 |
| D6 | Weekly dashboards in Power BI | important | direct | medium | discovery | You use the on-time dashboard daily; you haven't said whether you built it | `[grounded]` your background | Question Q3 |
| D7 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review; not stated whether you proposed or made route changes | `[inferred]` | Confirm route authority (D-RR2) |
| D8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent; you haven't worked in Dutch | `[grounded]` your statement | Say exactly that |
| D9 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your residence and commute aren't in your inputs; working in Amsterdam is not evidence of where you live | `[grounded]` absence | Question Q1 |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | 3+ years FMCG supply or demand planning | must_have | absent | none | capability | You've said you never worked in planning; operations analysis isn't planning; no FMCG work stated | `[grounded]` your statement | Closure path below |
| K2 | Own the 13-week plan; balance capacity against forecast | must_have | absent | none | capability | No capacity or forecast ownership in your background | `[grounded]` your statement | Same as K1 |
| K3 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review; it was a performance review, not supply and demand decisions | `[inferred]` | State the limit in any interview |
| K4 | Advanced Excel | important | unclear | low | discovery | Excel isn't in your inputs | `[grounded]` absence | Check your Excel level if you keep this option open |
| K5 | SAP IBP or a similar planning system | must_have | unclear | none | discovery | No planning system named; Power BI is reporting, not planning | `[grounded]` absence | Closed by K1 |
| K6 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent; the S&OP meeting's language is not stated | `[grounded]` your statement; `[inferred]` on meeting language | Say exactly that |
| K7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same as D9 | `[grounded]` absence | Question Q1 applies |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G-D5 | Temperature compliance (D5) | discovery | No temperature or cold-chain data in your background | A dashboard, report or exception log you've worked with, or a concrete learning plan | `[grounded]` silence |
| G-D6 | Dashboard ownership (D4, D6) | discovery | "Including the dashboard depot managers use" doesn't say you built it | Whether you built, maintained or only used it, with a sanitized example | `[grounded]` your wording |
| G-D7 | Route authority (D7) | transferability | Ran the review; decision rights unknown | Who approves a route change, and whether you have proposed one | `[inferred]` |
| G-D9 | Rotterdam commute (D9) | hard_gate | Location not in inputs | Whether three office days a week is workable | `[grounded]` absence |
| G-K1 | Planning experience (K1, K2, K5) | capability | You've never worked in planning | Closure path: planning-adjacent roles (see application plan) | `[grounded]` your statement |
| G-K6 | Dutch (K6) | transferability | Conversational only | Dutch working-level evidence, if any | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| D-RR1 | Pay not stated | unknown | — | (no salary in posting) | The role may be priced below your expectations, or pay is negotiated late | `[generic]` pattern in job postings; no band checked | What is the salary range for this role? | unresolved |
| D-RR2 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | The role may advise on routes while depot managers decide | `[inferred]` from the phrase | Who decides a route change: this role, the depot manager, or head office? | unresolved |
| D-RR3 | Concrete deliverables named | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards" | Scope is defined and measurable | `[grounded]` posting | What does a good on-time figure look like for this fleet, and who reviews it? | noted |
| K-RR1 | Named plan owner | positive_signal | — | "Own the 13-week supply plan" | Authority over the plan is stated | `[grounded]` posting | Who else plans this range, and who signs off the plan? | noted |
| K-RR2 | Team and reporting line unknown | unknown | — | not stated | The planner may work alone with production | `[inferred]` from silence | Who would I report to, and how many planners are on the team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| D-A1 | Reorder your CV so the on-time dashboard and the route-performance review lead the bullets, using only your own words | D6, D7 presentation | `[grounded]` your statements | resume_edits_pending_approval |
| D-A2 | Name the temperature gap yourself, in one cover-letter sentence: what you've done and what you'd learn | D5 | `[generic]` interviewers tend to probe gaps they hear about second-hand | pending your approval |
| D-A3 | Ask the recruiter for the salary range before investing in the full process | D-RR1 | `[generic]` | pending your approval |
| D-A4 | Prepare one sanitized query or dashboard screenshot, only if you built or maintained it | D2, D3, D6 | `[grounded]` | pending your approval |
| K-A1 | Don't apply to this posting as written. Target demand-planner or S&OP-analyst roles, which often ask for less planning ownership | K1, K2 closure path | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your own statements, which are leads for verification rather than proof.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Duinvaart Cold Chain and Kroonhaven Foods were refused (permission not granted). No existence or live-posting check. Would have moved: the employer-not-established check, which could cap the Duinvaart decision at `conditional_go` |
| 2. Role-family sweep | unavailable | The salary-band search was refused. No market calibration. Would have moved: a pay comparison for both roles, neither of which states pay |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- **Research retry (L1):** I can rerun the employer and pay-band checks, up to 5 searches and 2 page fetches. Nothing has been checked yet, so the employers are unverified.
- **Recruiter's salary range:** closes D-RR1 and lets the pay be compared with the band.
- **A sanitized query or dashboard you built:** raises D2, D3 and D6 to `high`.
- **Any planning experience, even part-time:** could move Kroonhaven to `hold_pending_answers`. I don't expect it, given what you've told me.

You can save this as a `tuesday-dossier.md` file to keep and reuse.

## Questions

Q1 (D9, K7): Can you work three days a week in the Rotterdam office, and where would you commute from? Utrecht is the same question for Kroonhaven, but that role is already `no_go`.

Q2 (D5): Have you tracked temperature or cold-chain compliance data, with thresholds or exception reports? If not, what have you done to learn those metrics?

Q3 (D4, D6): Did you build the on-time delivery dashboard, maintain it, or only use it? Your note says you use it; it doesn't say you built it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.