**Verdict: no-go. This is a scam, and you should not send anything.**

**Why it's a scam**

- **You're asked for sensitive identity data before any real hiring step.** IBAN, PPS number and passport photo are what someone needs to commit identity fraud or open accounts in your name. Real payroll collects these only after a signed contract, through the employer's HR system.
- **You're asked to pay for equipment.** A legitimate employer supplies its own equipment or gives a documented allowance. It never has you pay an "equipment partner" by bank transfer, with a promised refund.
- **The cheque plan is the classic overpayment fraud.** They send you a cheque for €2,850, you deposit it, keep €350, and forward the rest to them. Banks often show the funds as available within a day or two, but the cheque can take weeks to bounce. When it does, the money you sent is gone and the bank can hold you liable. Using your account to move money for someone else can also make you a money mule, which is a criminal matter.
- **Telegram-only hiring, no calls or video, and "passed screening" within minutes** are standard patterns for these operations.
- **The posting is built to attract you.** "No experience needed," "earn up to €26 an hour plus commission," and "set your own hours" are bait. Your background is a near-perfect match for the job description, which is exactly what makes it convincing. It says nothing about whether the job is real.

I didn't run research on Velloway Logistics. The red flags above are enough to decide, and checking a company's website wouldn't outweigh them. Even if a real company with this name exists, the process you've been shown is not how legitimate employers hire.

**What to do now**

1. **Don't send your IBAN, PPS number, or passport photo**, and don't pay anything or deposit any cheque. If you already sent the IBAN, watch your account closely and tell your bank what happened. Ask them about fraud monitoring.
2. **Don't reply to @VellowayHiring or email velloway.hr@postmail.example** beyond maybe blocking them. Engaging only gives them more to work with.
3. **Report it.** In Ireland, that means the Gardaí (you can report online or at a station) and the Garda National Cyber Crime Bureau. You can also report the Telegram account to Telegram, and report the listing to the jobs site.
4. **If you sent anything sensitive,** consider requesting a new bank account number from your bank, and contact the Department of Social Protection or Revenue about your PPS number if you're worried it's been misused.

**Your job search**

Your experience is real and transferable: three years of Zendesk-based customer service at a courier, training new starters, and a team tracker in Excel. Those skills suit customer operations and logistics coordinator roles at established employers. Look for roles on company career pages or established job boards, and apply directly. A real employer will have a named hiring manager, a company domain, a video or phone interview, and a written contract before any payroll details are requested.

If you'd like, I can help you tailor a CV around your Zendesk and tracker experience, or draft a short list of search terms and target employers.