**Decision snapshot: no_go.** Do not send anything, pay anything, or deposit the cheque. This is almost certainly a fraud, and the posting is not a close call.

- **Ledger 1, opportunity:** Critical. The process matches known job-scam patterns: an upfront payment for equipment, a cheque to deposit with money to return, and personal documents requested before any interview.
- **Ledger 2, candidate fit:** Strong on the role's functional requirements (see below). This does not change the decision.
- **Hard gates:** Pay floor (€30,000) is **not met on the posting's own terms**. The rate is "up to €26/hr" for 15–30 hours a week, which gives €20,280 to €40,560 a year before commission. Reaching €30,000 needs about 22 hours a week at the top rate.
- **Research tier: L0, provided documents only, no searches.** Nothing here needed outside checks to reach the decision.

---

**Role reality**
- Title and scope: remote order processing, 15–30 hours a week, training provided. Nothing about the duties is unusual.
- Organization: "Velloway Logistics," with no verifiable company details in the material you gave me. Contact is through a Telegram handle and an email address on a generic mail host, `postmail.example`, not a company domain. `[grounded]`
- Compensation: "up to €26/hr plus commission," with commission unspecified. The posting withholds the commission terms, which is itself a question worth asking. `[grounded]`
- Market calibration: not run at L0. Compensation is a mismatch with your floor on the stated figures alone. `[grounded]`

**Evidence map**

| # | Priority | Fit | Requirement | Gap | Confidence |
|---|---|---|---|---|---|
| 1 | hard_gate | gap | Pay ≥ €30,000/yr | Base pay "up to" €26/hr; needs ~22 hrs/wk at top rate, commission unknown | high (arithmetic from posting) |
| 2 | must-have | strong | Attention to detail, spreadsheets | 3 years keeping a weekly Excel tracker | medium (CV-only, unverified) |
| 3 | must-have | strong | Ticket and order processing | ~60 Zendesk tickets/day for 3 years | medium (CV-only, unverified) |
| 4 | must-have | strong | Good written English | Customer-facing written work implied by the role; not tested | low (not evidenced) |
| 5 | must-have | unknown | Quiet place to work | Not stated | unknown |

**Opportunity risk register**

| Class | Severity | Finding |
|---|---|---|
| Advance fee | critical | €349 "equipment" payment to a third party, "refunded with first wages." Refunds of this kind are not paid. |
| Fake cheque | critical | You'd lodge €2,850, keep €350, and send €2,500 onward. Cheques can bounce after funds appear to clear, and the shortfall would be yours to repay. |
| Identity harvest | critical | IBAN, PPS number and passport photo requested before any interview. |
| Process | high | "Passed screening" and "passed interview" with no real interview, and the whole process on Telegram. |
| Contact | high | Email on a generic mail host, not a company domain. |
| Pay mismatch | medium | "Up to" rate, unstated commission, and a floor that depends on hours. |
| Attribution | high | Employer existence not verified (L0). Standing entry until the company's own site or registration confirms it. |

**Application plan**
1. Stop all contact with @VellowayHiring. Do not send your IBAN, PPS number, or passport photo, even though you have the IBAN ready.
2. Do not pay the €349, and do not deposit or lodge the cheque, even if it arrives looking genuine.
3. Report the job listing to the jobs site and the Telegram account to Telegram.
4. If you have already shared any of those details, contact your bank now, report the matter to the Gardaí (including the Garda National Cyber Crime Bureau), and tell the Department of Social Protection about the PPS disclosure.
5. Keep applying for roles where your Zendesk and Excel experience can be checked: a real interview, a company email address, and a clear contract before any payment or account setup.

**Gap recovery queue**
- **G1 (employer):** Closed by the company's own careers page or a registration record for the company in the country it operates in. Given the decision, this gap won't change the outcome.
- **G2 (commission):** The posting doesn't state commission terms. Closed only by a written contract, which a legitimate employer provides before payment or account setup.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | skipped | Research not yet consented; offered below |
| 2 | Role-family sweep (scope, title, pay) | skipped | Same |
| 3 | Hiring manager's public footprint | n/a | No named hiring manager; the only contact is a Telegram handle |

Research tier: L0 — no searches

**Dossier offer:** If you want, I can save this assessment as a `tuesday-dossier.md` file to keep with your records.

**Upgrade menu**
- L1 research: checks the company's existence, its careers page and pay norms for this role (up to 5 searches and 2 page fetches).
- A link to the original jobs-site listing, which would show how the posting was published.

**Questions**
1. (G1) Do you want me to run L1 research to check whether Velloway Logistics exists as described? Reply "research" or "skip."
2. (G1) Does the jobs-site listing link to a company website or careers page?
3. (G2) Is €30,000 a must-have on base pay alone, and how many hours a week would you accept?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.