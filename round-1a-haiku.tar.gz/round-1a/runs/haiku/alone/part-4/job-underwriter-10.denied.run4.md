**Decision: conditional_go.** The role fits your experience well. The main gap is that you have never been the only designer. Before you put time into interviews, confirm Fernquay exists and that Ronan's message is a reply to an application you actually sent. I could not verify either from here.

**Research tier:** L1 requested, but web search was not granted permission, so no research ran. Every search or fetch I could send is counted: searches 2 of 5, fetches 0 of 2. Every claim about the company, the market and Ronan below is therefore unverified. Anything derived from general patterns is marked `[generic]`, and anything from your CV or the posting is `[grounded]`.

**Hard gates:** none failed.
- Location and hybrid pattern (Galway, two office days): fits, since you moved back to Galway. `[grounded]`
- Pay: the posted €52,000–€60,000 is `[grounded]` from the posting. Your floor is not stated, so this gate is unknown.
- Equity: 0.5–1% is stated in the posting. Its value depends on stage and funding, which are unknown. `[generic]`

**Role reality**
- Scope: first designer at a six-person company, owning the booking flow end to end, running research calls with school owners, and shipping with two engineers. `[grounded]`
- Market calibration: a first designer at a small seed-stage company is a sole-owner role, and the salary band sits in a typical range for that for mid-level designers in Ireland. `[generic]` I have not checked this against current data.
- Posting quality: salary and equity are stated, which is good. Stage, funding, customers and the CTO's full name are not stated. The role reports into the co-founder, so the co-founder is also your main reviewer.

**Evidence map (requirement → fit → confidence)**

| # | Requirement | Fit | Confidence | Gap |
|---|---|---|---|---|
| 1 | 3+ years product design | Met: 4 years | High, from your CV | none |
| 2 | Strong Figma | Met: daily use | Medium, self-reported | none |
| 3 | Has run own user research | Partly: monthly usability sessions with customers | Medium | transferability: sessions were with travel customers, not B2B operators, and you did not own recruiting or sales-led interviews |
| 4 | Works directly with engineers | Met: four-engineer squad | Medium | none |
| 5 | Own the booking flow end to end | Partly: checkout redesign is a large part of the flow | Medium | scope: you owned checkout, not the whole flow |
| 6 | First/only designer, sets up design practice | Not evidenced | Low | capability gap: no record of working alone or building design process |
| 7 | B2B operator software (school owners) | Not evidenced | Low | domain transferability: consumer travel to small-business operators |

**Risk register**
- *Unverified employer* (`severity: high` until resolved): I could not confirm Fernquay exists as described.
- *Channel mismatch* (`medium`): a WhatsApp message asking you to do a call and "shout here" is an unusual first step. Many small Irish companies do use it, but it is not proof.
- *Compensation* (`low`): the posted band is stated; I cannot say whether it is competitive without a verified market source.
- *Single-manager concentration* (`low`): the role depends heavily on one co-founder.

**Application plan (evidence-limited)**
1. Before the call, confirm where you applied and find the live posting, the company's own domain, and the sender domain of the calendar invite. Match all three.
2. On the call, lead with the checkout redesign and the monthly usability sessions. Say plainly that you have not been the only designer, and ask how they would support you in that.
3. Ask Ronan and Saoirse what the first six months look like and how they run research with school owners.

**Evidence status (research tier)**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | search permission not granted |
| 2. Role-family sweep (market for this title and band) | unavailable | search permission not granted |
| 3. Hiring manager's public professional footprint | unavailable | search permission not granted; name given is Ronan Kehoe |

**Dossier offer:** if it's useful, I can save this as `tuesday-dossier.md` so the analysis carries into interview prep.

**Upgrade menu (what would close the gaps)**
- Live posting link, or the company's careers page: confirms the role is current. Unlocks the employer-existence check.
- Company domain and the calendar invite's sender domain: confirms the invite came from Fernquay.
- Public footprint for Ronan Kehoe (professional profile only): clarifies his background and how he works. Unlocks the positioning line.
- The checkout case study as you sent it: lets the evidence map upgrade from Medium to High on rows 3 and 5.
- Your salary floor: resolves the pay gate.

**Questions (1 of 3 allowed in this message)**
1. Where did you apply (website, email, job board), and does Ronan's WhatsApp reply to that application?
2. Please share the posting URL and the domain the calendar invite came from. Share only the domain, not the full address.
3. Has anyone asked you for money, a bank detail, or an ID document so far? If yes, stop and don't send it.

Response modes: answer each question, or reply "skip" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.