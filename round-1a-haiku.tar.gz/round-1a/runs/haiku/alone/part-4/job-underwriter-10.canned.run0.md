**Decision: conditional go.** Worth applying for and taking the call. Confirm the invite is really from Fernquay first.

**Is the company real?** Mostly yes, on what I could check. The company's own pages describe the same business and role:
- The about page says Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools. It has six people in Galway and was founded in 2023 by Ronan Kehoe and Saoirse Doyle. [grounded]
- The careers page lists this Product Designer role with the same salary, hybrid pattern and "apply with one real project" request. [grounded]
- Ronan's public LinkedIn profile lists him as co-founder and CEO, previously product lead at a Galway travel-software company for five years. [grounded]

The company is small, so a thin web presence is normal and not a warning sign by itself. The about page names Saoirse as co-founder, while the WhatsApp calls her CTO. Those are compatible, but confirm her title on the call.

**The WhatsApp message.** A co-founder messaging a candidate on WhatsApp is informal, not a scam signal on its own, and common in small Irish startups. The markers to watch for are requests for payment, bank or ID details before an offer, a paid "test" arranged off-platform, or no real interview. This message is a 45-minute video call with the co-founder and CTO, which is a normal step.

**Fit against the posting**
- 3+ years of product design: met (4 years). [grounded]
- Strong Figma: met, used daily. [grounded]
- Has run user research: met, with monthly customer usability sessions. The customers were consumer travel users, not school owners, so this transfers partly. [inferred]
- Works directly with engineers: met, from a squad of four engineers. [grounded]
- Owns the booking flow alone as first designer: the main gap. You have never been the only designer. This is a capability and experience gap, not a hard gate, and your checkout redesign is the strongest evidence to close it. [inferred]
- Sea-kayak and surf-school domain: no direct experience. It is a new vertical with similar booking mechanics. [inferred]

**Opportunity concerns**
- Equity of 0.5–1% comes with no stated vesting, strike price or cap-table information. Ask about these before relying on it.
- I did not check €52–60k or the equity range against the market, so I can't say whether they are fair. [generic, uncalibrated]
- A first-designer role at a six-person company means little design peer support. The posting's candour about being informal and messy is a positive signal about how they work.

**Before the call (about five minutes)**
- Check that the calendar invite came from a Fernquay address and that it matches the careers contact.
- Reply to confirm the time by email to jobs@fernquay.example, not only on WhatsApp.
- Don't send ID, bank details or money before a written offer.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries: "Fernquay booking software Galway sea kayak surf schools", "Fernquay Galway careers Product Designer". Pages: fernquay.example/about, fernquay.example/careers/product-designer |
| 2 | Role-family sweep (pay, title, scope) | skipped | Not run. This is the calibration for the salary and equity. |
| 3 | Hiring manager's public footprint | yes | Query: "Ronan Kehoe Fernquay co-founder". LinkedIn snippet only; profile not fetched. |

**Upgrade menu**
- The role-family sweep would replace the uncalibrated salary and equity with a checked market comparison.
- The calendar invite's sender address and video-link domain would confirm the call is genuine.
- Your checkout case study would let me map the "owns it end to end" evidence more precisely.
- Deeper diligence (funding, leadership changes, candidate reports) is available once, up to 5 more searches and 2 more fetches.
- I can save this assessment as `tuesday-dossier.md` if you want to keep it.

**Questions**
1. Can you paste the calendar invite's sender address and video-link domain?
2. Should I run the role-family sweep for pay and equity, and the deeper diligence, or is what's here enough?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.