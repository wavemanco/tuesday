**Decision snapshot: conditional_go.** The role fits Maeve's stated experience well. The open items are verifying the employer on the live web and pinning down the pay and equity terms, not her ability to do the job.

- **Fit ledger:** Strong on 3+ years, daily Figma, working in a squad with engineers, and Galway location for the hybrid days. Partial on user research (monthly usability sessions, but not school-owner research) and on booking-flow ownership (checkout redesign, not end-to-end). Gaps on sole-designer work and on sea-kayak/surf or small B2B domain knowledge.
- **Hard gates:** None failed. Location and hybrid schedule are met. Pay (€52–60k) is stated but has no floor to check against, so it is unknown. Equity has no stated value.
- **Confidence:** Medium overall. The company's public footprint matched the posting, but I could not check the live web (see below).

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Fetched the about page; search returned the careers page. Both match the posting and each other. |
| 2 | Role-family sweep (market pay and scope) | unavailable | Not sent in this pass. It would move the market calibration line and the pay comparison. |
| 3 | Hiring manager's public footprint | yes | Search returned Ronan Kehoe's profile (snippet only; page not fetched). |

**Role reality**
- **Company:** Fernquay, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway-based, founded 2023 by Ronan Kehoe and Saoirse Doyle, customer-funded. [grounded, from the about page]
- **Role:** First designer. Owns the booking flow, runs school-owner research, ships with two engineers. [grounded, from the posting]
- **Ronan's background:** Listed as co-founder and CEO, previously product lead at a Galway travel-software company for five years. [grounded, from a search snippet]
- **Saoirse:** Named as co-founder on the about page. Her CTO title comes from the WhatsApp message only. Check it.
- **Market calibration:** Not run. I have no sourced market band for this seniority in Galway, so I have not judged the €52–60k range against the market. [generic]
- **Contradictions:** None between the posting and the careers page. The posting asks for "one real project" and the careers page asks for one real project sent to a jobs@ address. Both match.

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | strong | medium | none | 3+ years product design | 4 years at a Dublin travel-booking company |
| 2 | must | strong | medium | none | Strong Figma | Daily use, stated; no file reviewed |
| 3 | must | partial | medium | discovery | Owns user research | Monthly usability sessions with customers; no school-owner interviews |
| 4 | must | strong | medium | none | Works directly with engineers | Four-engineer squad |
| 5 | must | partial | low | capability | Owns booking flow end to end | Redesigned checkout only; end-to-end ownership not shown |
| 6 | preferred | gap | — | transferability | Sole or first designer | Never been the only designer |
| 7 | preferred | gap | — | discovery | Sea-kayak, surf or outdoor-operator domain | None stated; travel booking is adjacent, not the same |
| 8 | hard gate | strong | high | none | Galway hybrid, two days a week | Moved back to Galway last year |
| 9 | hard gate | unknown | — | hard-gate | Pay floor | Not provided, so unknown |

**Opportunity ledger**
- **Positive signals:** Real-looking company with a consistent public record; founders with relevant backgrounds; the posting values a real project over a polished deck, which suits Maeve's experience; the founders have already reviewed her checkout case study.
- **Risks:**
  - Sole-designer role with no design peers. (Severity: high for her, given that she has never done it.)
  - Equity of 0.5–1% at a six-person company has no stated value. Treat it as unvalued until she sees the cap table and vesting terms. (Severity: medium.)
  - Pay floor not known. (Severity: medium until she sets one.)
  - Employer not verified on the live web (see below). (Severity: medium.)
- **Red flags on process:** The WhatsApp message is plausible for a small startup, but two things need checking. First, the invite should come from a fernquay company address, not a personal one. Second, she should not share ID, bank details or payment information in any chat.

**Failed attribution — standing entry:** The search results and pages came back on fernquay.example and linkedin.example. The .example domain is a reserved placeholder that does not resolve on the public internet. I therefore cannot confirm from these results that the company exists as described on the live web. The results agree with each other, but that is not verification. Check the company's real domain yourself. Pages that would resolve it: the live careers page, the recruiter or co-founder email domain, and Ronan's and Saoirse's public profiles.

**Application plan**
- **Before the call:** Check the invite's sender domain and the meeting link. Look up Saoirse Doyle's public profile to confirm the CTO role. Set a pay floor and ask what the equity terms are.
- **Lead with:** The checkout case study they already liked. Describe what you did: "redesigned checkout and ran monthly usability sessions." Do not say you owned the booking flow end to end. That is not supported by the evidence.
- **Prepare for:** "You'd be the only designer." Answer honestly: you have worked in a squad, not alone. Explain how you would get design feedback and what you would do about it.
- **Positioning:** Proposed only, pending your approval. Any CV wording, outreach text or work sample goes to you first.

**Upgrade menu**
- Your salary floor and equity expectations. These would turn the pay line from unknown into a checked hard gate.
- The real company domain or live posting link. This would close the failed-attribution entry.
- A market pay sweep for product designers in Galway. This would fill the market calibration line.
- A deeper diligence pass (funding, hiring patterns, public employee and candidate reports). Up to 5 more searches and 2 more fetches. Offered once, runs only on your consent.

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` so it carries into interview prep.

**Questions**
1. What is your salary floor, and what equity would make the role worth it to you? (Responds to: the pay hard-gate row.)
2. Did you give Ronan your WhatsApp number in your application, or did he find it another way? (Responds to: the process red-flag row.)
3. Did the calendar invite come from a fernquay company address? If you paste its sender domain here, I can compare it with the company domain. (Responds to: the failed-attribution entry.)

Response modes: answer any or all of these in one message, or skip any. Mock-interview can rehearse the 45-minute call if you want to prepare for it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.