**Don't go ahead. This is almost certainly a scam, and nothing you've been sent is a real job offer.** Don't send your IBAN, PPS number or passport photo, and don't pay the €349.

**Why it's a scam**

- **The cheque plan is the core of the fraud.** They send you a €2,850 cheque, you lodge it and transfer €2,500 onward to "their partner." Banks usually make cheque funds available within a few days, before the cheque clears. When it bounces weeks later, the money you sent is gone and the bank can recover it from your account, often with charges. You would be out the full amount. This kind of arrangement is also how people get used as money mules, which can carry legal consequences.
- **Paying for your own equipment** is a clear sign of fraud. Legitimate employers don't ask new hires to pay them or their "partners" for a laptop.
- **You "passed the interview" without an interview.** You passed a "screening" and then an "interview" in Telegram chat, with no call, no video and no company contact. Each step was designed to get you to the next request.
- **They wanted your IBAN, PPS and passport before any real hiring step.** Those details are enough to open accounts or take out loans in your name.
- The posting has the other usual markers: vague duties, pay that looks high for no experience, flexible hours, and a Telegram-only process.

**What to do now**

1. **Don't send anything else.** Don't reply to the cheque or to the partner's details, and don't deposit anything.
2. **If you've already sent your IBAN, PPS or passport**, contact your bank today and ask them to flag the account. Then report it to your local Garda station, and consider a PPS-related alert with the Department of Social Protection.
3. **Block and report @VellowayHiring** in Telegram.
4. **Don't pay anyone** who asks for money to "start" a job.

**Your background is strong**

Three years of Zendesk ticket work, training new starters and keeping a team tracker in Excel are good evidence for customer operations, support or back-office roles. Those are common in Ireland, and you can find them through the companies' own careers pages, Indeed, LinkedIn and Irish recruitment sites. Apply only where you can find the employer's own site and a posting you can open independently.

If you like, paste the job descriptions you're considering and I'll check each one against your experience and your €30k floor, or help you draft a CV that uses only what you've actually done. I haven't searched the web to verify Velloway Logistics. You don't need to, though: the red flags above are enough to decline.