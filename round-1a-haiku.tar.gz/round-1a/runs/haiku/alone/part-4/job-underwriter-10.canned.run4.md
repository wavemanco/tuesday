**Yes, take the call, and it's a real company.** Ronan's message is ordinary recruiting, not a scam pattern. `conditional_go`

**Fit ledger.**

- `hard_gate`: direct: R8 · unclear: R9 (Salary €52,000–€60,000 plus equity)
- `must_have`: direct: R1, R2, R3, R6 · adjacent: R4 (own the booking flow end to end)
- `important`: adjacent: R5 (Research with school owners) · absent: R7 (Being the only designer)

R4 is a credible bridge, its limit named: checkout is one stage of a booking flow, not the whole flow. R7 is the post's main stated condition and the one you disclosed you have no evidence for.

**Opportunity ledger.** Sound and verified: the employer, product and posting match the company's own site, and the pay sits inside the market band. Three unknowns are open: decision rights (RR1), scope breadth (RR2) and equity terms (RR3).

- **Hard gates:** none failed (R8 `direct`); unconfirmed: R9 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R9: €52,000 base clears your floor, or the equity closes the gap; (2) RR1: design authority and any design peer verify concrete on the call; (3) R4 is framed honestly, as the checkout stage you redesigned.

**Legitimacy.** I can establish the firm from here. Fernquay's own about page says it makes Kelproster booking software for sea-kayak, surf and sailing schools, has six people in Galway, was founded in 2023 and is customer-funded. Its careers page carries the same role, pay, hybrid pattern and first-designer framing as the posting. Ronan's public profile (search snippet, not opened) lists them as co-founder and CEO, previously five years as product lead at a Galway travel-software company. The WhatsApp message asks for no money, deposit or bank details, and it uses chat only to schedule a call that is confirmed by an emailed invite. None of that is a signal.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023; funded by its customers | `[grounded]` fernquay.example/about |
| Role | Product Designer, the company's first design hire; own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting and careers page |
| Working pattern | Hybrid: two days a week in Galway, the rest remote | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting and careers page |
| Market calibration | Tillerby 2026 Ireland report, product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The posting range sits inside that band, around the median. This is a band, not this employer's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report (tillerby.example), n=520 |
| Scope read | Designer, researcher and front-end contributor in one post, for a six-person company | `[inferred]` from the three duties named together |
| Unknowns | Who makes final design calls; equity form and vesting; whether "ship" means production code; Saoirse Doyle's role (the about page lists her as co-founder, the message calls her CTO, and both can be true) | — |
| Contradictions | None between the posting, the careers page and the about page | `[grounded]` three pages compared |

The co-founder's previous company is a Galway travel-software firm, not your Dublin one. Nothing in the posting or message suggests a connection between them.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, as you stated | `[grounded]` your statement | Share the case study (upgrade menu) |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use, as you stated | `[grounded]` your statement | none |
| R3 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers; the recruiter's praise of the checkout case study shows they have seen it, not what it contains | `[grounded]` your statement; WhatsApp message | Inspect the case study |
| R4 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of the flow, not the whole flow | `[inferred]` gap from your stated scope | Gap queue G2 |
| R5 | Research with school owners (small-business customers) | important | adjacent | medium | transferability | Customer research is direct; the audience differs from consumer travel customers | `[inferred]` from the audience difference | Gap queue G4 |
| R6 | Works directly with engineers | must_have | direct | medium | none | A squad of four engineers, as you stated | `[grounded]` your statement | none |
| R7 | Being the first and only designer | important | absent | medium | capability | You have never been the only designer anywhere; no evidence of design decisions made without a design peer | `[grounded]` your statement | Gap queue G1 |
| R8 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year | `[grounded]` your statement | none |
| R9 | Pay €52,000–€60,000 (your floor not given) | hard_gate | unclear | low | hard_gate | No floor stated, so the check against it is unknown | `[grounded]` posting; floor not given | Gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Being the only designer (R7, important) | capability | No solo design role on record | It's the posting's main stated condition | Freelance or side-project design you decided alone; any time you worked without a design lead to review you | A short example of a decision taken without a design peer, and how you got critique | `[grounded]` your statement; `[generic]` that this is the likeliest concern |
| G2 | Booking flow end to end (R4, must_have) | transferability | You redesigned checkout inside a flow owned by others | The posting names end-to-end ownership | Any work on search, listing or confirmation steps, or a flow you specified from start to finish | The checkout case study, marked for where the flow started and ended for you | `[inferred]` bridge from your checkout work |
| G3 | Pay (R9, hard_gate) | hard_gate | Floor not stated | Determines whether the hard-gate check passes | None needed; this is your number | Your floor, and whether equity should count toward it | `[grounded]` posting; floor not given |
| G4 | Research with small businesses (R5, important) | transferability | Consumer travel customers only | The job's research is with school owners | Any interviews or tests with small-business or service-business users | A sanitised note from one such session | `[inferred]` from the audience difference |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Final design decision authority not stated | unknown | — | "You would be our first designer" | Final design calls may sit with the co-founder, with no design peer to review your work | `[inferred]` from the solo framing against silence on decision rights | "Who makes the final design calls on the booking flow, and would I have anyone in the company to review my work with?" | unresolved |
| RR2 | Breadth of duties for one designer | risk_signal | medium | "own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | One role may combine design, research and front-end work | `[inferred]` from three duties in one post | "Which of those three is the main job, and do you expect design to produce production code?" | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The value depends on instrument, vesting and dilution | `[generic]` pattern for early-stage equity grants | "Is the equity options or shares, what is the vesting schedule, and what is the strike price?" | unresolved |
| RR4 | Pay disclosed and in market | positive_signal | — | "€52,000–€60,000" | The range sits inside the 2026 Ireland 3–5 year band, around the median | `[generic]` Tillerby 2026, n=520 | "Is €52,000–€60,000 the budget for this hire, or is there room within it?" | noted |

The standing entry "employer not established" is cleared: the employer resolves to its own domain, so it is not recorded.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reply to Ronan and accept a time for the 45-minute call with Ronan and Saoirse | The call is the next step in the process | `[grounded]` WhatsApp message | pending your approval |
| A2 | Prepare a checkout walkthrough that separates what you led from what the team did | Covers R4 and R3 | `[grounded]` R3, R4 rows | pending your approval |
| A3 | Ask RR1–RR3 on the call, verbatim from the register | The register doubles as call preparation | `[grounded]` register | pending your approval |
| E1 | Describe your work as "I redesigned the checkout stage of a booking flow", not "I owned the booking flow" | The stronger claim is not one you have evidence for | `[grounded]` R4 row | pending your approval |
| A4 | Decide your pay floor before the call | Needed to close R9 | `[inferred]` from the hard-gate row | your own decision |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer job Galway"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) and "About Fernquay" (fernquay.example/about). Role reality: the employer exists as described, and the posting matches its careers page |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 3 years experience 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a LinkedIn profile snippet (linkedin.example/in/ronan-kehoe); not opened, so this rests on the snippet. Role reality's scope read: co-founder and CEO, previously five years as product lead at a Galway travel-software company |

## Upgrade menu

- **The checkout case study**, or a description of which parts you led → R3 and R4 move toward `high`, and the E1 wording gets firmer.
- **Your pay floor** → R9 closes, and the hard-gate line in the snapshot becomes a finished check.
- **The equity terms, in writing** → RR3 closes.
- **A deeper pass on Fernquay** (funding, hiring history, public staff or candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can write this whole assessment to a `tuesday-dossier.md` file you can keep and take into the call.

**Questions**

1. What is your pay floor, and does €52,000 base clear it? (R9)
2. Have you ever made design decisions alone, with no design peer to review them, even on a side project or freelance piece? If not, how would you get critique? (R7, G1)
3. Can you share the checkout case study, or tell me which parts of it you led alone and which the team did? (R3, R4, G2)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.