I'll read the reference files the skill needs before building the assessment.
The skill's rules are clear enough to build from. Next I'll run the L1 research: the official-site check for each employer, plus a role-family sweep for each role. Both searches run in parallel.
Search was refused by the host, so the research checks didn't run and both assessments rest on your message and the two postings. Each posting gets its own assessment.

## 1. Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Decision snapshot. Worth your time: yes, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (Rotterdam office, three days a week)
- `must_have`: direct: R2, R3, R4, R5a, R6 · adjacent: R5b (temperature compliance)
- `important`: adjacent: R7 (route changes with depot managers)
- `preferred`: adjacent: R8 (Dutch)

R5b is a bridge with its limit named. R1 is open until you tell me your commute limit.

**Opportunity ledger.** The scope is concrete and names its tools and deliverables (RR4). Pay isn't stated, the employer and live posting are unverified here (RR1, RR2), and it's unclear whether route changes are yours to make or the depot managers' (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Rotterdam office, three days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting confirmed on Duinvaart's own careers site (RR2); (2) three days a week in Rotterdam workable for you (R1); (3) pay you can accept, which the posting doesn't give (RR1)

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; runs a refrigerated fleet | `[grounded]` posting; entity not verified (search refused) |
| Mandate | Track on-time delivery and temperature compliance; build weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| First-year outcomes | None stated | `[grounded]` absence in posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | One analyst owning KPIs and dashboards for a fleet, with route decisions passing through depot managers | `[inferred]` from the three listed duties |
| Market calibration | Not run (search refused). No band given; I won't supply one from memory | — |
| Unknowns | Pay, team size, fleet size, who decides route changes | — |
| Contradictions | None in the text you gave me | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Rotterdam office, 3 days/week | hard_gate | unclear | low | discovery | Your constraint isn't given, so nothing to test | `[grounded]` posting | Q1 |
| R2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier; self-reported | `[grounded]` your message | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use for four years; self-reported | `[grounded]` your message | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use; Tableau not claimed | `[grounded]` your message | none |
| R5a | Track on-time delivery across the fleet | must_have | direct | medium | none | You tracked on-time delivery for depot managers | `[grounded]` your message | none |
| R5b | Track temperature compliance | must_have | adjacent | low | transferability | Monitoring against targets is the bridge; no temperature or cold-chain data stated | `[inferred]` bridge from R5a | G1 |
| R6 | Weekly dashboards in Power BI | must_have | direct | medium | none | You worked on the on-time dashboard depot managers use | `[grounded]` your message | none |
| R7 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review; whether you proposed or approved changes isn't stated | `[grounded]` your message | G2 |
| R8 | Dutch | preferred | adjacent | medium | capability | Conversational; posting says "a plus" | `[grounded]` your message | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R5b, must_have) | transferability | No temperature or cold-chain data experience stated | A must-have sits at adjacent | Any threshold or SLA monitoring, even outside food or cold chain | A KPI definition or report excerpt, anonymized | `[inferred]` |
| G2 | Route changes (R7, important) | transferability | Your review informed route decisions; your ownership of them isn't clear | Depot managers will expect a partner, not only a reporter | A route change you proposed and saw implemented | One-line example | `[inferred]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | "Hybrid, three days a week" (no pay given) | Pay may sit below what you need, or simply go unpublished | `[inferred]` from the posting's silence on pay | What is the salary range for this role? | unresolved |
| RR2 | Employer and live posting unverified | unknown | — | Posting text only | The posting may be stale or aggregated, or the role may not be on the employer's own site | `[inferred]`: search refused, so nothing checked | Is this role posted on Duinvaart's own careers site, and who would I interview with? | unresolved |
| RR3 | Route-change authority unclear | unknown | — | "work with depot managers on route changes" | You may propose changes, or only report on them | `[inferred]` from the duty's wording against its silence on decision rights | Which route changes does this role decide itself, and which go to depot managers? | unresolved |
| RR4 | Concrete scope with named tools and deliverables | positive_signal | — | "Track on-time delivery and temperature compliance… build weekly dashboards in Power BI" | The role's scope is defined, which makes the interview easier to prepare for | `[grounded]` posting | Who uses the weekly dashboards, and what decision does each one feed? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Duinvaart's own careers site and apply there | RR2 | `[generic]` pattern: aggregator reposts can be stale | your action |
| A2 | Resume line: "Worked daily in SQL and Power BI on the on-time delivery dashboard depot managers use." | R3, R4, R5a | your message | `resume_edits_pending_approval` |
| A3 | Resume line: "Ran the weekly route-performance review." | R7 | your message | `resume_edits_pending_approval` |
| A4 | In the interview: "I haven't worked with temperature data yet. How is temperature compliance measured here?" | R5b, RR3 | `[inferred]` | pending your approval |

---

## 2. Supply Planner, Kroonhaven Foods (Utrecht)

**Decision snapshot. Worth your time now: no. Status: `no_go`.**

The role needs three years of FMCG planning and a planning system you haven't used. A few weeks of effort won't close that, so this is a poor use of application time now.

**Fit ledger.**
- `hard_gate`: unclear: R1 (on-site in Utrecht)
- `must_have`: adjacent: R5 (fluent Dutch) · unclear: R3 (advanced Excel) · absent: R2 (3+ years FMCG planning), R4 (SAP IBP or similar)
- `important`: adjacent: R7 (weekly S&OP) · absent: R6 (13-week plan, capacity against forecast)

R2 and R4 are absent with no planning years or planning-system use. R7 is a bridge, not the S&OP itself.

**Opportunity ledger.** Ownership is explicit: the 13-week plan, capacity, and the S&OP meeting (RR3). Pay isn't stated and the employer is unverified (RR1, RR2).

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** for `no_go`, the posting would have to accept route and performance-review work in place of planning years. Its text doesn't.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready meals | `[grounded]` posting; entity not verified (search refused) |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP | `[grounded]` posting |
| First-year outcomes | None stated | `[grounded]` absence in posting |
| Working pattern | On-site, Utrecht | `[grounded]` posting |
| Scope read | A senior ownership role, not an entry-level planning seat | `[inferred]` from "own" and the experience requirement |
| Market calibration | Not run (search refused). No band given | — |
| Unknowns | Pay, team, reporting line | — |
| Contradictions | None in the text you gave me | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | low | discovery | Your constraint isn't given | `[grounded]` posting | Q1 |
| R2 | 3+ years FMCG supply or demand planning | must_have | absent | high | capability | No planning years stated; your route and delivery work is adjacent at best | `[grounded]` your message | none |
| R3 | Advanced Excel | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` absence | check your own level before applying |
| R4 | SAP IBP or similar planning system | must_have | absent | high | capability | No planning-system use stated | `[grounded]` your message | none |
| R5 | Fluent Dutch | must_have | adjacent | medium | capability | Conversational, not fluent | `[grounded]` your message | none |
| R6 | 13-week plan; balance capacity against forecast | important | absent | medium | capability | Production capacity and forecasting are not in your background | `[grounded]` your message | none |
| R7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran the weekly route-performance review; S&OP is cross-functional planning | `[inferred]` bridge from your review | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Planning years (R2, must_have) | capability | No planning years | Three years is a stated threshold | None found after looking at the background you gave | None closes this in a few weeks | `[grounded]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (no pay in posting) | Pay may be below your need, or unpublished | `[inferred]` from the posting's silence | What is the salary range for this role? | unresolved |
| RR2 | Employer and live posting unverified | unknown | — | Posting text only | Stale or aggregated posting, or not on the employer's own site | `[inferred]`: search refused | Is this role posted on Kroonhaven's own careers site? | unresolved |
| RR3 | Explicit ownership of the 13-week plan and S&OP | positive_signal | — | "Own the 13-week supply plan" | The scope is clearly defined | `[grounded]` posting | How is the S&OP meeting run, and who attends? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Skip this role for now; spend application time on roles where your evidence is direct | R2, R4, R6 | `[inferred]` from the map | your decision |
| A2 | Look at demand-analyst or S&OP-coordinator roles at smaller FMCG firms | R7 | `[generic]` role-family pattern, not checked | pending your approval |
| A3 | Honestly rate your advanced Excel before applying anywhere that asks for it | R3 | your background is silent on it | your action |

---

## Evidence status

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Duinvaart: official site and careers page | unavailable | Search refused by the host; no results |
| 2. Duinvaart: role-family sweep | unavailable | Search refused by the host; no results |
| 3. Duinvaart: hiring manager | n/a | No name given |
| 1. Kroonhaven: official site and careers page | unavailable | Search refused by the host; no results |
| 2. Kroonhaven: role-family sweep | unavailable | Search refused by the host; no results |
| 3. Kroonhaven: hiring manager | n/a | No name given |

Verified: none yet.

If you want this written up as a `tuesday-dossier.md` file for later sessions, I can do that.

## Upgrade menu

- **Web search access:** if you grant it, I can check each employer against its own site and run a salary band for each role. That closes RR2 for both postings and the market band for both.
- **Live posting links:** the employer's own careers page verifies RR2 for both postings.
- **Your pay floor:** closes RR1 for Duinvaart against your number.
- **Your commute limit or on-site days you can do:** closes R1 for both postings.
- **An anonymized KPI definition or report excerpt from your job:** raises R2 and R5a confidence from medium toward high, and gives G1 something concrete for Duinvaart.
- **A hiring manager's name, if you have one:** tells the Duinvaart application which story to lead with.

## Questions

1. **(R1, both postings)** Where are you based, and how many days a week can you be on site? Rotterdam and Utrecht are different commutes.
2. **(RR1, both postings)** Do you have the right to work in the Netherlands without sponsorship, and what is your pay floor?
3. **(RR2, both postings)** Do you have the link to each live posting?

Answer any mix of these, or skip any; a skipped question stays unasked.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.