## Decision snapshot

| Role | Decision | Fit (candidate) | Opportunity |
|---|---|---|---|
| Operations Analyst, Duinvaart (Rotterdam) | **conditional_go** | Strong on the core job; one domain gap (cold chain) | Scope is clear. Employer unverified, salary not stated, commute unknown |
| Supply Planner, Kroonhaven (Utrecht) | **no_go** for now | Three stated requirements unmet (planning years, planning system, fluent Dutch) | Clear scope, but it's an ownership role that needs the experience you don't have |

Hard gates: no hard-gate failure on either role. Two items need your confirmation: the Rotterdam hybrid schedule (Job 1) and the Utrecht on-site location (Job 2).

Research tier: L0, no searches run. Everything below rests on your two postings and your background. Labels: `[grounded]` = from your text or the postings; `[generic]` = general market pattern, not verified for these employers.

## Operations Analyst, Duinvaart: requirement map

| Requirement | Evidence | Fit | Confidence | Gap type |
|---|---|---|---|---|
| 2+ yrs logistics/ops analysis | 4 yrs as ops analyst at a parcel carrier `[grounded]` | Meets | High | None |
| Strong SQL | Daily use `[grounded]` | Meets | Medium (CV claim, not yet shown) | None |
| Power BI or Tableau | Daily Power BI `[grounded]` | Meets | Medium | None |
| On-time delivery tracking | Built and used the OTD dashboard depot managers rely on `[grounded]` | Strong match | Medium | None |
| Weekly dashboards | Ran recurring reporting `[grounded]` | Meets | Medium | None |
| Depot managers, route changes | Ran the weekly route-performance review `[grounded]` | Strong match | Medium | None |
| Temperature compliance, refrigerated fleet | Nothing in your background | Not evidenced | n/a | Transferability: the monitoring skill transfers, the cold-chain rules don't yet |
| Dutch (a plus) | Conversational `[grounded]` | Partial | n/a | Capability, not required |
| Hybrid, 3 days/week in Rotterdam | Your commute tolerance isn't known | To confirm | n/a | Hard gate (location/schedule), to confirm |

**Why conditional, not go:** the fit is good, but the employer hasn't been checked and the posting has no salary. Neither is a fit problem. Both are cheap to resolve.

**Application plan**
- Lead with the OTD dashboard and the route-performance review. Those map directly to the job.
- Name the cold-chain gap yourself and frame it as a learning area, with a specific example of how you'd pick up temperature-compliance reporting. Don't imply experience you don't have.
- Ask in the interview what temperature excursions count as a compliance breach and who owns the response. That shows you understand the domain.
- Put the Dutch level on the CV as it is ("conversational"). Don't round it up.
- Before applying: confirm the posting is live on Duinvaart's own careers page, and check the commute is workable.

## Supply Planner, Kroonhaven: requirement map

| Requirement | Evidence | Fit | Confidence | Gap type |
|---|---|---|---|---|
| 3+ yrs FMCG supply/demand planning | None. You've never worked in planning `[grounded]` | Not met | n/a | Capability and transferability. Adjacent work exists (route forecasting, demand-facing reporting), but it isn't planning |
| Advanced Excel | Not mentioned in your background | Unknown | n/a | Discovery. You may have it and not listed it |
| SAP IBP or similar planning system | None | Not met | n/a | Capability |
| Fluent Dutch | Conversational `[grounded]` | Not met | n/a | Capability. Likely matters a lot in a weekly S&OP meeting |
| Run a weekly S&OP meeting | You ran a weekly route-performance review `[grounded]` | Partial | Medium | Presentation: the meeting skill transfers, the content doesn't |
| On-site, Utrecht | Commute not known | To confirm | n/a | Hard gate (location), to confirm |

**Why no-go for now:** three stated requirements are unmet at once, and the role owns a 13-week plan and production capacity from day one. Applying would be a stretch on every front. Experience length is not a legal gate, but in practice this employer will screen on it.

**What would change this:** if you have forecasting, inventory, capacity or Excel modelling work that isn't in your CV, the Excel row moves and the decision should be re-checked.

**Better targets `[generic]`:** demand planner, supply chain analyst, or S&OP analyst roles, usually junior or mid-level. Your Power BI and SQL carry these, and they don't require the full planning record yet. Check that the posting doesn't also require a planning system or fluent Dutch.

## Evidence status

Your background and both postings are the only sources. No employer checks were run. Both companies' existence, size and current hiring are unverified.

## Upgrade menu

- **Company check (L1), up to 5 searches and 2 page fetches:** confirms both employers exist as described, that the postings are live, and gives a role-family salary range for each. This would settle Duinvaart's conditional.
- **Your CV bullets with numbers:** on-time % change, time saved, depots covered. These would firm up the medium-confidence rows in Job 1.
- **Any planning-adjacent work you haven't listed:** could move Job 2 from no-go to hold.

Would you like a dossier file (`tuesday-dossier.md`) with this assessment saved for later use with mock-interview prep?

## Questions

1. Can you do Rotterdam three days a week, and is Utrecht on-site workable from where you live? (Hard-gate check for both roles.)
2. Have you done any forecasting, inventory, capacity or Excel modelling at the carrier that isn't in your CV?
3. Can you share two or three quantified outcomes from the OTD dashboard or the route review?

Answer each in a line, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.