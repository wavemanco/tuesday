**Decision: no-go. Don't send your IBAN, PPS number, or passport photo, don't pay the €349, and don't lodge the cheque.**

This is a fake-job and fake-cheque scam. It's a strong match on every point I'd check, and it doesn't need a company search to decide.

**Decision snapshot**
- **Opportunity:** no-go. The process is the problem, not the role.
- **Candidate fit:** your background matches the posted duties well (Zendesk volume, training new starters, Excel tracking). That's a separate ledger and doesn't change the decision.
- **Hard-gate failures:** none of the posted terms is a hard gate in itself, but the pay falls below your €30k floor unless you work close to 30 hours a week (see below).
- **Research tier:** L0, provided text only. I ran no searches, so I haven't confirmed whether Velloway Logistics exists.

**Red flags in the posting and messages** ([grounded], from your text)

| Signal | Why it matters |
|---|---|
| Asked for IBAN, PPS and passport photo before any interview | Legitimate employers collect these after an offer, through their HR system. This is how identity theft starts. |
| Pay €349 "for equipment" to a third party, refunded "with first wages" | Real employers supply their own equipment. Paying to start a job is the classic pattern. |
| Cheque for €2,850, keep €350, send the rest to the "equipment partner" | This is a fake-cheque scam. The cheque bounces after you've sent real money, and the bank can hold you liable. |
| Whole process on Telegram, no calls or video | Lets them avoid any check on who they are. |
| "No experience needed" and "up to €26/hour plus commission" | Vague, unverifiable pay that makes the offer sound better than it is. |
| Contact is an email address on a generic mail domain | No company domain to check against. |

**Pay check** ([inferred], arithmetic on the posted figures)
At €26/hour, 15 hours a week is about €20,300 a year gross, and 30 hours is about €40,600. Commission is unstated and "up to" is a ceiling. So this only meets your €30k floor if you work roughly 23+ hours a week, and it's before tax.

**What to do now**
1. Don't send anything. If you've already sent your PPS number or passport photo, contact your bank and report it to the Gardaí. Consider asking the Department of Social Protection about protecting your PPS.
2. Report the Telegram account and the posting to the jobs site.
3. If you want to check the company, search the Companies Registration Office (cro.ie) and the company's own website. Compare the email domain against the official one. If the company doesn't exist or the domains don't match, that confirms the scam.

**Next step:** Do you want me to look for real remote customer operations or support roles that match your Zendesk and Excel background, paid at or above €30k and posted directly by employers? I'd start with sites that list employer postings directly, then check each company with the CRO before you apply.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.