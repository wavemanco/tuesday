**Job 1, Duinvaart Cold Chain (Rotterdam): worth applying, conditionally.** `conditional_go`.
**Job 2, Kroonhaven Foods (Utrecht): not worth it now.** `no_go`. This is my reading. It isn't a hard-gate failure, and you decide.

**Research tier: L1, searches 4 of 5, fetches 0 of 2.** The four searches were refused because web search permission wasn't granted, and they count against the budget. Nothing below about either employer or any pay level comes from research.

---

## Job 1: Operations Analyst, Duinvaart Cold Chain

**Decision snapshot: `conditional_go`.** Your SQL, Power BI, on-time delivery and depot-route work match the posting. Temperature compliance and the Rotterdam schedule are open. The employer is also unverified, because the searches didn't run.

**Fit ledger.**
- `hard_gate` — unclear: R1 (hybrid, three days a week in Rotterdam office)
- `must_have` — direct: R2, R3, R4
- `important` — direct: R5, R7 · unclear: R6 (temperature compliance tracking)
- `preferred` — adjacent: R8 (Dutch a plus)

R1 is a condition, not a skill gap. R6 is the gap that matters for this role. R8 is the one adjacency, with its limit stated.

- **Hard gates:** none failed; unconfirmed: R1 (hybrid, three days a week in Rotterdam office)
- **Severe red flags:** none found.
- **What would change this:** a conditional go depends on three things: the three-day Rotterdam schedule works for you (R1), the posting is live on Duinvaart's own site (RR2), and you can speak to temperature or condition monitoring, even indirectly (R6). If the schedule is fixed and you can't do it, this becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam; refrigerated fleet | `[grounded]` your posting text |
| Scope | On-time delivery and temperature compliance across the fleet, weekly Power BI dashboards, route changes with depot managers | `[grounded]` posting |
| Scope read | Recognisably your current job with a refrigeration overlay. The temperature piece is the new part | `[inferred]` from your background against the responsibilities |
| Market calibration | Not run. Searches were refused, so no pay band | — |
| Unknowns | Salary, schedule flexibility, whether temperature data is in your hands or the depot's | — |
| Contradictions | None in the posting | `[grounded]` posting |

## Evidence map (Job 1)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't stated whether this works. Your Amsterdam base makes it a live question, not a settled one | `[grounded]` posting; no candidate statement |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. Self-reported | `[grounded]` your background |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL use. No artifact yet | `[grounded]` your background |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use. No artifact yet | `[grounded]` your background |
| R5 | Weekly dashboards; on-time delivery tracking | important | direct | medium | presentation | You describe the on-time dashboard depot managers use. Your ownership of it isn't stated, so say whether you built or maintained it | `[grounded]` your background |
| R6 | Temperature compliance; refrigerated fleet | important | unclear | low | discovery | Nothing in your background touches temperature. On-time tracking transfers, condition monitoring may not | `[grounded]` absence; `[inferred]` on transfer |
| R7 | Route changes with depot managers | important | direct | medium | none | Your weekly route-performance review ran with depot managers | `[grounded]` your background |
| R8 | Dutch (a plus) | preferred | adjacent | high | transferability | Conversational, not fluent. The limit is stated, not argued away | `[grounded]` your own statement |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6) | discovery | Your background covers on-time delivery, not condition or temperature monitoring | This is the one requirement that could hold the decision | Customer SLAs on sensitive goods; any exception reporting on product condition; anything with a temperature or humidity log | A report, SLA excerpt, or dashboard view that shows the monitoring | `[grounded]` CV silence; `[inferred]` that it moves the decision |

## Opportunity risk register (Job 1)

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | (no pay figure in posting) | The salary may sit below what this scope usually pays, or the employer may not publish pay | `[inferred]` from posting silence | What is the pay band for this role? | unresolved |
| RR2 | Employer and posting not verified | unknown | — | (posting only; no company page checked) | The posting may be stale or not from the company itself | `[generic]` pattern for unverified postings, not a claim about this employer | Can you point me to this role on Duinvaart's own careers page? | unresolved |
| RR3 | Concrete, measurable scope | positive_signal | — | "Track on-time delivery and temperature compliance across our refrigerated fleet" | Success is measurable, which makes the role easier to evaluate | `[grounded]` posting | How is temperature data collected, and who reviews the weekly dashboard? | noted |

## Application plan (Job 1)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the on-time delivery dashboard and route-performance review, in your existing words | R5, R7 | `[grounded]` your background | resume_edits_pending_approval |
| A2 | Describe Dutch as "conversational", never "fluent" | R8 | `[grounded]` your statement | resume_edits_pending_approval |
| A3 | Claim nothing about temperature work until G1 is answered | R6 | `[grounded]` gap | pending your approval |
| A4 | Apply once the posting is confirmed on the employer's own site | RR2 | `[generic]` pattern | pending your approval |

---

## Job 2: Supply Planner, Kroonhaven Foods

**Decision snapshot: `no_go` for now.** Two must-have requirements have no direct or adjacent evidence in your background: the planning years (R2) and the planning system (R3). Closing either would take far longer than an application cycle.

**Fit ledger.**
- `hard_gate` — unclear: R1 (on-site in Utrecht)
- `must_have` — adjacent: R5 (fluent Dutch) · unclear: R4 (advanced Excel) · absent: R2 (3+ years of supply or demand planning in FMCG), R3 (SAP IBP or a similar planning system)
- `important` — adjacent: R7 (weekly S&OP meeting) · absent: R6 (13-week supply plan, capacity against forecast)

The S&OP cadence transfers (R7); the planning itself doesn't (R2, R6).

- **Hard gates:** none failed; unconfirmed: R1 (on-site in Utrecht)
- **Severe red flags:** none found.
- **What would change this:** a planning background you haven't mentioned, such as forecasting, inventory or capacity work in Excel or a planning tool (R2, R3, R4).

## Role reality (Job 2)

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` posting |
| Scope | 13-week supply plan, capacity against forecast, weekly S&OP | `[grounded]` posting |
| Scope read | A mid-level planning role. The posting asks for the planning tenure a new planner would not have | `[inferred]` from the requirements |
| Market calibration | Not run | — |
| Unknowns | Salary; whether they would consider a candidate without planning years | — |
| Contradictions | None | `[grounded]` posting |

## Evidence map (Job 2)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement of your position on this | `[grounded]` posting |
| R2 | 3+ years supply or demand planning in FMCG | must_have | absent | medium | capability | You've never worked in planning. This isn't a gate, so the years are graded like any other requirement | `[grounded]` your statement |
| R3 | SAP IBP or similar planning system | must_have | absent | medium | capability | No use of a planning system in your background | `[grounded]` your background |
| R4 | Advanced Excel | must_have | unclear | low | discovery | Not stated in your background | `[grounded]` absence |
| R5 | Fluent Dutch | must_have | adjacent | high | transferability | Conversational, not fluent | `[grounded]` your statement |
| R6 | 13-week plan; capacity against forecast | important | absent | medium | capability | No planning work | `[grounded]` your background |
| R7 | Weekly S&OP meeting | important | adjacent | medium | transferability | Your weekly route-performance review is a recurring cross-functional cadence. It carries no forecasting or capacity decisions | `[grounded]` your background; `[inferred]` on transfer |

## Gap recovery queue (Job 2)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G2 | Planning years and system (R2, R3) | capability | No planning work or planning system in your background | Two must-haves with no closure inside an application cycle | A planning course or a short project could show interest, not years | None that closes this | `[inferred]` closure timing from the requirement's years |

## Opportunity risk register (Job 2)

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR4 | Pay not stated | unknown | — | (no pay figure in posting) | Pay may be set below market, or simply not published | `[inferred]` from posting silence | What is the pay band for this role? | unresolved |
| RR5 | Clear scope and named system | positive_signal | — | "Own the 13-week supply plan for our chilled ready-meals range" | The role is well defined | `[grounded]` posting | Which planning system is in use, and what does the S&OP meeting decide? | noted |

## Application plan (Job 2)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| B1 | Don't apply now | R2, R3 | `[inferred]` from the map | pending your decision |
| B2 | If you want an adjacent route, look at demand or S&OP-analyst roles, where your analytics and review work carries over; the planning years still apply | R7 | `[inferred]` from the map | pending your approval |

---

## Evidence status

Verified: your background (R2, R3, R4, R5, R7, R8). These claims rest on your own statements. Nothing has been inspected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht ready meals" were refused. They would have checked that each employer exists and that each posting is live (RR2, RR-level for Job 2) |
| 2. Role-family sweep | unavailable | Searches "operations analyst refrigerated logistics Netherlands salary Rotterdam" and "supply planner FMCG S&OP salary Utrecht" were refused. They would have set the pay bands for RR1 and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

If you want this saved as a `tuesday-dossier.md` to come back to, say so and I'll write it.

## Upgrade menu

- **Web search access:** This would check both employers exist and set pay bands for RR1 and RR4. Only one search remains under the default budget, so a deeper pass would need your go-ahead.
- **A dashboard artifact:** An anonymised screenshot, or a written description, of the on-time dashboard would move R5 from `medium` to `high`.
- **A temperature example:** Any SLA, report or exception log touching condition or temperature would resolve G1 and R6.
- **A planning example:** Any forecasting, inventory or capacity work in Excel or a planning tool would move R2–R4 for Job 2.

## Questions

1. **R6 (Job 1):** Did any of your work touch temperature, cold-chain, or product-condition monitoring, even through a customer's sensitive-goods requirements? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **R1 (Job 1):** Can you work three days a week in the Rotterdam office from Amsterdam, and is there any other schedule constraint I should know about? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **R4 (Job 2):** Have you done any forecasting, inventory or capacity work in Excel or a planning tool, even inside another role? And how would you rate your Excel? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.