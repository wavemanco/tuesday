**Yes, it's worth the call, and as far as I can check it's a real company: `conditional_go`.** Fernquay's own site and careers page confirm the role, and nothing it has asked of you so far is a scam pattern. The open questions are your pay floor, whether you'd have real decision rights as the only designer, and whether the checkout work matches "own the booking flow end to end".

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay within €52,000–€60,000); candidate constraints not given, so checks against your pay floor are unknown.
- **Fit ledger:**
  - `hard_gate`: direct R1 · unclear R2
  - `must_have`: direct R3, R4, R5, R6 · adjacent R7
  - `important`: adjacent R8, R9
  - R7, your checkout ownership is a real bridge with its limit named; R8 (`low`), no sole-designer evidence yet, and the squad work is the nearest bridge.
- **Opportunity ledger:** the employer is verifiable (RR3); the open items are decision rights (RR1), the WhatsApp channel (RR2, low), and the equity terms (RR4).
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor is at or below €52,000 (R2); (2) on the call, they confirm which decisions are yours (RR1); (3) you present R7 as checkout ownership inside a squad, not end-to-end ownership.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak, surf and sailing schools; founded 2023 by Ronan Kehoe and Saoirse Doyle | `[grounded]` fernquay.example/about, fetched |
| Posting | Live on the company's careers page; salary, hybrid pattern and first-designer scope match your JD | `[grounded]` fernquay.example/careers/product-designer, fetched; no contradiction with the JD |
| Market calibration | Irish product designers with 3–5 years: median €57,000, interquartile range €51,500–€62,000. The posted €52,000–€60,000 sits inside that range, below the median | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520) |
| Scope read | First designer, reporting to a co-founder; the role is close to the founders | `[inferred]` from the posting's "first design hire" and "work most closely with" |
| Unknowns | Equity value at 0.5–1% of a six-person company, your decision rights, who reviews your work | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | high | none | `[grounded]` your stated move back to Galway |
| R2 | Pay within €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your floor was not given |
| R3 | 3+ years product design | must_have | direct | medium | none | `[grounded]` your background; no artifact yet |
| R4 | Strong Figma | must_have | direct | medium | none | `[grounded]` daily use |
| R5 | Has run own user research | must_have | direct | medium | none | `[grounded]` monthly customer usability sessions |
| R6 | Works directly with engineers | must_have | direct | medium | none | `[grounded]` four-engineer squad |
| R7 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | `[grounded]` checkout redesign; limit: one flow inside a squad, not end-to-end |
| R8 | First designer, no design team | important | adjacent | low | transferability | `[inferred]` squad work as the bridge; you have never been the only designer |
| R9 | Research calls with school owners | important | adjacent | medium | transferability | `[grounded]` customer research; limit: consumer travel customers, not small operators |

**Gap recovery queue**

- **G1 (R7, transferability):** the checkout redesign carries over; the limit is that you never owned discovery through operator-side setup. Strengthener: a short write-up of that checkout project, which they already liked.
- **G2 (R8, transferability):** the squad carried design decisions with peers; the limit is that you have never been the only designer. Strengthener: how you set up research or design practice in that squad.

**Opportunity risk register**

| # | Signal | Class | Severity | Source | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights unclear for a sole designer | unknown | — | "our first design hire" | You may own the flow without final say on scope | `[inferred]` from the posting's silence on decision rights | Which booking-flow decisions are mine to make, and which go to Ronan or Saoirse? | unresolved |
| RR2 | Recruiting by WhatsApp message | risk_signal | low | "Just shout here if the time does not suit" | Informal founder communication at a small company | `[generic]` pattern for small companies | Could you confirm the calendar invite came from the company email domain? | unresolved |
| RR3 | Employer verifiable | positive_signal | — | fernquay.example | The company exists and is hiring | `[grounded]` careers and about pages, fetched | — | noted |
| RR4 | Equity value unstated | unknown | — | "0.5–1% equity" | Equity may be worth little or a lot; no cap table is public | `[generic]` early-stage pattern | What are the vesting schedule, the share count and the current valuation? | unresolved |

On the WhatsApp message: nothing in the thread asks you for money, bank details, ID or a deposit. The next step is a video call with the two founders, so this isn't a scam pattern. The only thing to check is that the invite comes from fernquay.example.

**Application plan** (all proposals, pending your approval)

- Confirm the invite is from fernquay.example before the call.
- Prepare a sole-designer answer for G2 from what you did in the squad.
- Ask RR1 and RR4 on the call.

**Evidence status**

Verified: none yet. Your background is still self-report.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay Product Designer job Galway careers"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Employer established; posting live and consistent with the JD |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience"; returned Tillerby 2026 Ireland Design Salary Report. Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder"; returned a LinkedIn profile snippet (not fetched): co-founder and CEO, previously product lead at a Galway travel-software company for five years. Moved the scope read |

**Upgrade menu**

- Your pay floor → R2 closes and the gate line clears.
- Your Figma portfolio or the checkout case study as an artifact → R3–R5 move toward `high`, and R7 gets its evidence.
- A walkthrough of Kelproster, their product → R7 and G2 get something concrete to compare against.
- A deeper research pass on Fernquay (funding, leadership changes, past hires, public reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want this kept as a `tuesday-dossier.md`, say so.

Q1 (R2): What's the lowest base you'd accept?
Q2 (R8): Have you ever been the only designer on anything, even a side project or freelance job?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.