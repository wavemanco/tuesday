## Decision snapshot

**Decision: `conditional_go`.** Apply to the role, and treat the call as the place to verify the employer. Don't share anything beyond your existing application until the company checks out.

- **Fit ledger:** Strong on the stated requirements (experience, Figma, research, working with engineers). The gaps are about ownership and context: you've never been the only designer, and your research was with consumers, not business owners.
- **Hard gates:** Location and schedule pass if you can be in the Galway office two days a week, which you can. Salary floor is **unknown** because you haven't given me one.
- **Opportunity:** Unverified. Nothing in the posting or the outreach can be confirmed from outside the conversation, so the employer's existence is an open question.

**Research tier: L1, but no research was run.** Web search was not granted in this session, so every outside claim below is `[generic]` or `[inferred]`.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | `unavailable` | Web search permission was denied in this session |
| 2 | Role-family sweep (scope, title, pay for this seniority) | `unavailable` | Same |
| 3 | Ronan Kehoe's public professional footprint | `unavailable` | Same |

## Role reality

- **Role:** Product Designer, first design hire at a six-person company. Owns the booking flow end to end, runs research with school owners, works directly with two engineers.
- **Scope read:** Solo design ownership. Nobody to review your work, and the research audience is a different one from what you know.
- **Market calibration `[generic]`:** Not verified in this session. Dublin and Galway product designer pay for 3+ years is plausibly in the €50–65k range, so €52–60k looks ordinary rather than low. Equity of 0.5–1% at a six-person company is in a normal range for an early hire. Both are unverified.
- **Unstated:** The posting gives no stage, funding, or revenue, and no information on the CTO's background. Both are worth asking about.

## Evidence map

| Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|
| 3+ years product design | Met | High | None | 4 years, stated |
| Strong Figma | Met | Medium | Portfolio unseen | Daily use, stated |
| Has run own user research | Met | Medium | Consumer, not B2B | Monthly usability sessions, stated |
| Works directly with engineers | Met | High | None | Four-engineer squad, stated |
| Owns a flow end to end | Partial | Medium | Presentation/capability | Checkout redesign, but not evidence of owning the whole flow |
| Research with school owners | Partial | Low | Transferability | Travel-booking customers differ from small operators |
| First or only designer | Gap | n/a | Capability | Never worked solo; no peer to review |

## Opportunity risk register

- **Employer not confirmed** (standing entry, severity high). Cannot confirm the company exists as described from here. Resolve by: the live posting link, their own careers page, and the recruiter's email domain.
- **Outreach channel** (medium). A co-founder contacting you on WhatsApp after applying is unusual but not unheard of at very small Irish startups. It is not proof of anything either way. The check is whether the calendar invite comes from a company email domain and names Ronan and Saoirse.
- **Equity terms** (low). Ask for the vesting schedule and the company's cap table or share class before treating 0.5–1% as real value.

## Application plan

1. **Before the call:** Check that the company exists with a second source. Confirm the invite comes from their domain. Find Saoirse's name and role on a company or LinkedIn page.
2. **On the call:** Ask about funding, runway, how many paying schools they have, and what the design brief is for the first six months.
3. **Positioning:** Lead with the checkout redesign and the monthly sessions. Say plainly that the booking-flow ownership is new, and that you have worked on a team of four engineers, not alone.
4. **Pay:** Settle your floor before the offer stage.

## Gap recovery queue

- **G1, end-to-end ownership:** The checkout work is real evidence, but it is a fragment of a flow. Closes with a project where you owned the whole flow, or a clear account of what you decided alone.
- **G2, B2B research:** Closes with any work with business customers, or a plan for how you'd reach school owners.
- **G3, solo working:** Closes with a time you worked without design peers, or a clear plan for doing so.

## Questions

1. Where did you send your application, and did the checkout case study go to a company address or through a job board?
2. Is there a project where you owned a flow end to end, even partly, or research with business customers?
3. What is your salary floor?

**Upgrade menu:** The live posting link, their careers page, the recruiter's email domain, your portfolio, and the checkout case study you sent. Each one would move the employer check, the Figma claim, or the end-to-end gap.

I can also write the dossier file for this if you want to keep it for later.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.