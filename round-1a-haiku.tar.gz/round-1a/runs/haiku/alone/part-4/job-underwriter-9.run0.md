**Decision snapshot**

- **Decision: `conditional_go`.** Pending verification that the offer is genuinely from Marrowgate and that the onboarding process is genuine. Don't send bank, PPS or passport details until that's done.
- **Fit (candidate side):** strong on the stated must-haves. Gaps are pension changes and scale (240 staff versus 90). Irish PAYE/PRSI/USC is probably covered by the Payroll Technician certificate, but that isn't confirmed.
- **Hard gates:** pay meets the band (€40,000 is inside €38,000–€42,000). Location is unknown: two office days in Limerick need a commute. Notice period and start date are unknown.
- **Research tier: L0** (no searches run, no consent given yet).

**Your direct question: is this normal?**

Partly. [generic] Employers do need bank details (for salary payment) and PPS number (for Revenue/PAYE registration) after an offer. That part is ordinary. Asking for a passport scan through a portal before your first day is less standard. In Ireland, a general right-to-work check mostly matters for non-EEA nationals, and the usual practice is to see original ID in person, not collect a copy up front. Data protection guidance also says an employer should only collect what it needs, when it needs it.

Your two in-person interviews at their office make a scam less likely. The risk sits in the remote step: the offer email and the portal link that follows it.

**Before you accept or send anything:**

1. Check the sender's domain. The address you gave me, `people@marrowgate.example`, is not a normal company domain. Compare it against the domain on Marrowgate's own website. I can't verify it from here.
2. Find a phone number for Marrowgate on their website or through a directory, not from the offer email, and ask HR to confirm the offer and the onboarding link.
3. Check the portal URL. It should be on the company's own domain and use HTTPS. Don't enter details on a page reached only through a link in an email.
4. Don't send a passport scan by email. If they need ID for right-to-work, ask whether they will just check the original in person on day one.
5. Ask what they retain, for how long, and who can see it.

Accepting within the five working days is fine once steps 1–2 are done. Accepting is not the same as handing over the sensitive details.

**Evidence map** (requirement by requirement)

| # | Requirement | Fit | Confidence | Gap |
|---|---|---|---|---|
| 1 | 2+ years running payroll | Meets | high (stated) | none |
| 2 | Working knowledge of PAYE, PRSI, USC | Probably meets | medium (certificate, syllabus unconfirmed) | verify the certificate covers Irish payroll |
| 3 | Strong Excel | Meets | high (stated: pivots, XLOOKUP) | none |
| 4 | Payroll qualification or working towards one | Meets | high (certificate, 2024) | none |
| 5 | Starters, leavers, monthly payroll-to-ledger reconciliation | Meets | high (stated) | none |
| 6 | Pension changes (in responsibilities) | Gap | high (stated) | capability: never done it, manager handled it |
| 7 | Scale: 240 staff | Partial | high | scale: 90 to 240, a step up |
| 8 | Hybrid, Limerick two days a week | Unknown | none | hard gate, depends on where you live |

**Gap recovery queue** (no questions here; they are at the end)

- **Pension changes:** capability gap. Closes with a worked example of pension change handling, or a training plan.
- **Scale (240 vs 90):** scale gap. Closes with evidence of handling volume, such as batch processing or the peak-period process you ran.
- **PAYE/PRSI/USC:** verify. Closes by confirming the certificate's syllabus covers Irish payroll.

**Opportunity risk register**

| Class | Severity | Risk | What resolves it |
|---|---|---|---|
| Failed attribution | High | Employer existence and offer sender unverified | Live posting link, company careers page, the sender's domain, an independently found phone number |
| Process | High | Passport scan requested via portal before the first day | Confirm the portal's domain and what the passport check actually requires |
| Location | Medium | Two office days in Limerick, commute unknown | Confirm where you live |
| Terms | Low | Notice period and start date unstated | Your notice period; agree the start date with them |

**Application plan**

Lead with the 3 years of fortnightly payroll for 90 staff and the reconciliation record. Address pension changes directly, as a learning area, rather than leaving them for the interviewer to find. This is positioning, not approved CV language; nothing goes out without your approval.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | skipped | L1 research not yet consented |
| 2. Role-family sweep (market scope and pay) | skipped | L1 research not yet consented |
| 3. Hiring manager's public footprint | skipped | L1 research not yet consented |

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file if you want to keep it or reuse it later.

**Upgrade menu**

- Live posting link, or the careers page URL: enables the company check (L1, target 1).
- Consent to L1 research: up to 5 searches and 2 page fetches to check the company and the role's pay range. Labelled `[generic]` where it applies to the role family.
- Your commute, or where you live: resolves the location gate.
- The certificate's syllabus, or a list of topics: confirms PAYE/PRSI/USC.

**Questions**

1. Can you check the offer's sending domain against Marrowgate's website, and tell me whether the onboarding link is on that same domain? (Response modes: answer here, or reply "skip".)
2. Where do you live relative to Limerick, and can you commute for two office days a week?
3. What is your notice period?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.