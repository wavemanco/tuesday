**Decision: conditional_go.** Take the 45-minute call once the employer checks out. The role fits you reasonably well. What's unverified is whether Fernquay is a real hiring company and whether the posting is live. Web search was denied in this session, so I could not check the company, the role, or market pay.

**Decision snapshot**
- Must-haves, fit ledger: 3+ years (direct, high; 4 years stated). Strong Figma (direct, medium; daily use stated, no portfolio seen). Own user research (direct, medium; monthly usability sessions stated). Works with engineers (direct, high; squad of four). Owns the booking flow end to end (adjacent, medium; you redesigned checkout, not booking). Sole designer (capability gap, medium; you've never been the only designer).
- Hard gates: location, hybrid in Galway, meets (stated). Pay €52–60k against your floor: unknown, you haven't given one. Schedule, equity terms: unknown.
- Hard gates line: compensation floor not provided, so that gate is unknown.
- Opportunity: employer not established from attributable sources. Standing entry, medium, unresolved. This caps the decision at conditional_go.
- No requests for money, deposits, or bank/ID details appear in the posting or the WhatsApp message, so no scam verdict applies. The call is set up by a calendar invite, not run wholly by chat.

**Role reality**
- First designer at a six-person company, with two engineers, a CTO (Saoirse), and co-founder Ronan Kehoe as your closest collaborator.
- Scope is broad: "own the booking flow end to end" plus customer research, which is a lot for one designer. `[inferred]` from the posting's wording.
- The posting is specific and realistic about its size and informality. That's a positive signal, not a red flag.
- Pay is stated, so the posting's figure is `[grounded]` from the JD. I can't calibrate it against market pay without search, so no band is given.
- The 0.5–1% equity at this stage is illiquid. Its value depends on terms such as vesting, option type, and dilution. `[generic]`

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence (stated by you) |
|---|---|---|---|---|---|---|
| 1 | 3+ years product design | must-have | direct | high | none | 4 years at a Dublin travel-booking company |
| 2 | Strong Figma | must-have | direct | medium | portfolio unseen | Daily use |
| 3 | Own user research | must-have | direct | medium | no case study shared | Monthly usability sessions with customers |
| 4 | Works directly with engineers | must-have | direct | high | none | Squad of four engineers |
| 5 | Owns booking flow end to end | must-have | adjacent | medium | booking not checkout | Redesigned checkout flow |
| 6 | Sole or first designer | implied | capability gap | medium | never solo | None |

**Gap recovery queue**
- Row 5: show that you can own a flow from research to ship, even though it was checkout, not booking. The checkout case study is the best proof.
- Row 6: name how you'd work without a design peer, such as your review habits, how you'd get critique, and what you'd ship first.
- Row 2: Figma proof, such as a file or screenshot from the checkout work, if your old employer's rules allow it.

**Opportunity risk register**
- Employer not established (medium, unresolved). Verification question for the employer: "Can you point me to this role on Fernquay's own careers page, and confirm the invite came from your company address?" Clears when the posting appears on their own site, and the invite and Ronan's email use the company domain.
- Responsibility without design support (medium, unresolved). Verification question: "Who makes product decisions on the booking flow, and what does design review and sign-off look like?"
- Positive: a clear, honest posting that asks for a real project over a polished deck. Scope is realistic for a first designer.

**Application plan**
1. Verify the employer before investing in prep: the live posting on their site, and the invite's domain.
2. Before the call, decide which checkout work you can show, and check your old NDA first. Don't share anything you're not cleared for.
3. Lead with checkout redesign, customer usability sessions, and squad work. Describe these as you did them. Don't say you "owned" the booking flow or "led" design.
4. Answer the sole-designer gap directly: how you'd get critique, what you'd ship first, and how you'd push back on scope.
5. Don't accept or discuss equity terms until you've seen the option paperwork.

**Evidence status**

Research tier: L0 — no searches (search permission denied by the host; the three L1 targets could not run)

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search denied |
| 2. Role-family sweep (scope, title, pay) | unavailable | Web search denied |
| 3. Hiring manager's public footprint | unavailable | Name given, search denied |

**Dossier offer:** I can save this assessment as `tuesday-dossier.md`, which keeps the evidence map and risk register for later.

**Upgrade menu**
- The live posting URL or Fernquay's careers page: resolves the employer check.
- Your checkout case study or portfolio: raises the Figma and research rows to high.
- Your pay floor: runs the hard-gate check.
- Search permission turned on: company footprint and a market pay band for €52–60k.

**Questions**
1. Row 5 / gate: What's your compensation floor, and would €52,000 be a problem?
2. Employer check: Can you send the careers page URL or the posting link, and the domain the calendar invite came from?
3. Row 3: Which parts of the checkout work can you show publicly, given any NDA?

Answer in text, paste the posting link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.