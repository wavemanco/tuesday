## Decision: conditional go, pending one verification step

**Fit:** Strong on the core of the role. Your 3 years of fortnightly payroll for 90 staff, starters and leavers, and the monthly payroll-to-ledger reconciliation match the job's main duties. Pension changes are your real gap, and it is learnable. Irish PAYE/PRSI/USC is unconfirmed from your background.

**Opportunity:** The offer is a normal shape for an employer. The main issue is the channel, not the request. Verify the employer and the portal before you send any sensitive data.

## Your question: are bank, PPS and passport requests normal?

**Yes, the data itself is normal.** A real employer needs each of these [generic]:
- **Bank details** to pay your salary.
- **PPS number** to register you with Revenue for PAYE. An employer cannot run payroll without it.
- **Right-to-work evidence.** Employers must check this. The usual method is to see the original document, and many employers also keep a copy. Your "bring the original passport on day one" line is the standard form.

**What makes this one worth checking:**
- The offer asks for all three through a link, before any written contract is mentioned.
- The sender address is a generic `people@` mailbox. Your interviews were in person, which is strong evidence the company is real. It does not prove that this email came from them.
- Nothing in the offer says what you are not asked for. A real offer usually says nothing about fees, equipment purchases, or card details, and this one doesn't. That is a good sign, not proof.

**Before you send anything:**
1. **Verify the sender.** Find Marrowgate's phone number and careers page yourself, not from the email. Check that the `people@` domain matches the domain on their website.
2. **Verify the portal.** Type the portal address you confirmed through step 1 into your browser. Don't click the link in the email. Check that it is on their own domain and uses HTTPS.
3. **Ask for the written contract first.** Irish law requires a written statement of terms [generic]. Ask for it before you give any sensitive data.
4. **Share PPS and passport only after you have a signed contract.** Bank details go into the portal only after steps 1 to 3.
5. **Reply within the five working days.** You have time to do all of this. A real employer will accept a short delay for verification.

**Stop and reconsider if** anyone asks for payment, equipment money, card details, or a password, or pressures you to skip verification.

## Evidence map: role requirements against your background

| # | Requirement | Priority | Fit | Gap | Evidence |
|---|---|---|---|---|---|
| 1 | 2+ years running payroll | Must [grounded] | Strong | None | 3 years, fortnightly, 90 staff [grounded] |
| 2 | Working knowledge of Irish PAYE, PRSI, USC | Must [grounded] | Unconfirmed | Confirm | Your background doesn't name the jurisdiction. The Payroll Technician certificate likely covers it. |
| 3 | Strong Excel | Must [grounded] | Strong | None | Daily use, pivot tables, XLOOKUP [grounded] |
| 4 | Payroll qualification, or working towards one | Must [grounded] | Met | None | Payroll Technician certificate, 2024 [grounded] |
| 5 | Starters, leavers, monthly payroll-to-ledger reconciliation | Core duty [grounded] | Strong | Monthly vs fortnightly | You've done starters, leavers and reconciliation. The role is monthly, which is a small shift. [inferred] |
| 6 | Answer staff payroll queries | Stated duty [grounded] | Not evidenced | Confirm | Not in your background. |
| 7 | Pension changes | Stated duty [grounded] | Gap | Capability, learnable | You have never done this; your manager handled it. [grounded] |
| 8 | Hybrid, two days a week in Limerick | Schedule and location [grounded] | Unknown | Confirm | Your location and commute are not stated. |
| 9 | Salary €38,000–€42,000 | Pay [grounded] | Offer is €40,000, inside the band | Your floor is unstated | The band is what the ad says [grounded]. Whether €40k meets your floor is for you to check. |

## Opportunity risks

- **Unverified sender and portal.** Severity: medium. Standing until you complete steps 1 and 2 above. This is the constraint on the decision.
- **Sensitive data requested before a contract.** Severity: medium. Resolved by the contract-first step.
- **No written terms mentioned.** Severity: low to medium. Ask for them.
- **Pension changes are new to you.** Severity: low. Ask what training they provide, and check whether your manager or a colleague can onboard you on it.

## Application plan (accept path)

1. Verify the sender and the portal (steps 1 and 2 above).
2. Ask for the written contract and terms.
3. Confirm the start date, the hybrid arrangement, and whether pension training is included.
4. Once the contract is signed, submit PPS, bank details and the right-to-work scan through the verified portal.
5. Accept in writing within the five working days.

**Research tier: L0, no searches.** I haven't searched for Marrowgate, so I can't confirm the company exists as described. Confirming that is step 1 above, and I can run it if you want.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | skipped | L0 tier, no search consent |
| 2 | Role-family sweep (pay and scope for this seniority) | skipped | L0 tier, no search consent |
| 3 | Hiring manager's public footprint | skipped | No consent; hiring manager name given, footprint not checked |

## What would sharpen this

- **Live posting link or the site where you saw the ad.** Confirms the offer matches the advertised role.
- **Marrowgate's switchboard number from their own website.** Lets you verify the employer directly.
- **Confirmation of Irish payroll in your current role.** Moves requirement 2 from unconfirmed to strong.
- **Your salary floor and commute limit.** Resolves the hard-gate rows.
- **Any experience answering staff queries.** Moves requirement 6 from not evidenced.
- **The written contract, once it arrives.** Lets me check the terms against the offer.

If you want, I can save this assessment as a `tuesday-dossier.md` file to carry into interview prep.

1. Did your current payroll run on Irish PAYE, PRSI and USC?
2. What is your salary floor, and can you commute to Limerick two days a week?
3. Shall I run a light employer check, meaning up to 5 searches and 2 page fetches on Marrowgate's own site, careers page and role pay? It would help confirm the company exists as described.

Answer any, all or none; say "skip" to drop one.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.