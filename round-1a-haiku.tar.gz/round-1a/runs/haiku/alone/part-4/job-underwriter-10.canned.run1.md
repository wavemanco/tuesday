**Decision:** Worth taking the call, but the company is only partly verified. **`conditional_go`**: the work fits you well, and the open points are about the employer and pay, not your ability to do the job.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R9 (€52,000–€60,000 against your pay floor, which you haven't given me); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Fit ledger** (from the evidence map below)
- `hard_gate`: `direct` R1 (Galway hybrid); `unclear` R9 (pay against your floor)
- `must_have`: `direct` R2 (3+ years), R3 (Figma), R4a (usability sessions), R5 (working with engineers); `adjacent` R4b (school-owner research calls)
- `important`: `adjacent` R6 (booking flow end to end), R8 (outdoor-school booking domain); `absent` R7 (only designer on the team)

R7 is the real gap: you've never been the only designer. R4b is the second: your research was with travel customers, not school owners.

**Opportunity ledger:** The company page matches the posting: Galway, six people, booking software for sea-kayak and surf schools, founded 2023 by Ronan Kehoe and Saoirse Doyle. The posting itself is not on any careers page I could find, and I haven't checked the company register (RR1). Salary and equity are unbenchmarked (RR2). The scope for one designer across a booking flow is not clear (RR3).

**Research tier: L1 — searches 4 of 5, fetches 1 of 2**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Found fernquay.example/about, which matches the posting. No careers page or posting found. |
| 2 | Role-family pay and scope sweep | skipped | Not run in this pass. |
| 3 | Hiring manager's public footprint | yes | Ronan Kehoe's LinkedIn lists him as co-founder and CEO, previously product lead at a Galway travel-software company for five years. No public profile found for Saoirse Doyle. |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | high | — | You moved back to Galway last year. |
| R2 | 3+ years product design | must_have | direct | medium | — | Four years at a Dublin travel-booking company. Self-reported. |
| R3 | Strong Figma | must_have | direct | medium | — | Daily use. Self-reported. |
| R4a | Own user research | must_have | direct | medium | — | Monthly usability sessions with customers. |
| R4b | Run research calls with school owners | must_have | adjacent | low | discovery | Your sessions were with travel customers, not school owners. |
| R5 | Works directly with engineers | must_have | direct | medium | — | Four years in a squad with four engineers. |
| R6 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned checkout, which is one part of a booking flow. |
| R7 | First and only designer | important | absent | — | capability | Never worked as the only designer. |
| R8 | Outdoor or booking-SMB domain | important | adjacent | low | discovery | Travel booking, not school booking. |
| R9 | €52,000–€60,000 pay, 0.5–1% equity | hard_gate | unclear | — | — | Your floor isn't known to me. |

**Opportunity risk register**

- **RR1, employer not established (`severity: low`, status reduced).** [grounded] The company page exists and matches the posting. [generic] A small company with no careers page is common. Question for the employer: "Can you point me to the live posting on your careers page, and which legal entity would employ me?"
- **RR2, pay and equity unbenchmarked (`severity: medium`, status unresolved).** I didn't run the market check, so I can't say whether €52,000–€60,000 with 0.5–1% equity is normal for this seniority in Galway. Question: "How were the salary and equity ranges set, and what are the vesting terms?"
- **RR3, scope against authority (`severity: medium`, status unresolved).** [inferred] "First designer, own the booking flow end to end" with two engineers and no design peers, which means you'd probably make calls without a second opinion. Question: "Which decisions on the booking flow would I make without sign-off, and who has final say on product?"
- **Positive signals.** The posting states the pay, the hybrid terms and the co-founder you'd work with. The company page is specific about what it makes, where, and who founded it.

**Is it legit?** I can't establish that from here. The company page is consistent with the posting, but I found no careers page and didn't check the company register. Nothing you've described asks you for money, bank details, ID, or hiring entirely over chat, so no scam entry applies. The invite still needs checking.

**Verification steps, in order**
1. Check the invite's sender address. It should be on the company's own domain, not a personal email. If it isn't, ask Ronan to send the posting link from the careers page before the call.
2. Look up Fernquay on the Companies Registration Office's public register (cro.ie) and check the registration date and directors. I haven't done this.
3. Confirm Saoirse's role. Her name is on the company page as co-founder, but Ronan's message calls her CTO. Both can be true, so check how the company describes her.
4. Don't send money, bank details, PPS number or ID until you have a written offer that names the role and pay.

**Application plan:** Reply on WhatsApp, confirm the time, and ask for the posting link and the invite's sender. For the call, lead with the checkout redesign and the usability sessions, and say plainly that you've never been the only designer, then explain how you'd handle that. Don't describe the checkout work as owning the booking flow. For rehearsing the call itself, the mock-interview skill is the right tool.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file if you want to keep it.

**Upgrade menu:**
- The posting link or careers page raises RR1 from partly to fully verified.
- Your pay floor closes R9.
- A market check on pay and scope for this title in Galway (up to 5 searches and 2 fetches) closes RR2.
- Deeper diligence on funding, leadership changes and public candidate reports (up to 5 more searches and 2 more fetches) would test RR1 and RR3. I'd run it only if you want it.

**Questions:**
1. What's the lowest salary you'd accept, and what equity would you expect? This closes R9.
2. Would you like me to run the market check on pay and scope now?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.