**Yes, worth applying, on one condition: confirm the post is live first.** `conditional_go`

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · adjacent: R5, R10 · unclear: R4
- `important`: direct: R7 · adjacent: R6, R8 · unclear: R9, R12
- `preferred`: absent: R11

R3 (`medium`) is stated on your CV, not yet checked. R10 is the nearest bridge: your discharge-to-assess visits, but never a caseload of your own. R5 covers wound care, but leg ulcers aren't on your CV.

**Opportunity ledger.** The role is clearly scoped, with the caseload, the clinical duties, the supervising nurse and the record system all named. Three things are open: whether the post is live on the employer's own careers page (RR1), what mileage pays (RR2), and how much support a new caseload holder gets (RR3). One entry runs the other way: the duties and support are described concretely (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`).
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed on Calderbrook's own careers page or by the contact (RR1); (2) the caseload support is described as concrete (RR3); (3) Doppler and your lack of a caseload are presented as they are, never claimed (R10, R11).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing under an NHS contract across Calderdale, founded 2015, about 410 staff in four locality hubs | `[grounded]` search snippet of the employer's own About page |
| Mandate | A small personal caseload of housebound adults, supported by a senior community nurse | `[grounded]` advert |
| Duties | Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, all on the EPR | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Community staff nurse, Band 5: median basic pay £34,300, interquartile range £32,400–£36,600 (n=1,240, one 2026 pay survey). The advert's range sits around that median. 61% of respondents were paid mileage | `[generic]` 2026 pay-guide search snippet; not this employer's offer |
| Unknowns | Mileage rate; caseload size; supervision in the first months; whether leg-ulcer work is a daily duty | — |
| Contradictions | None found. The careers page fetch returned no page, so the posting is not confirmed live there | `[grounded]` fetch attempt |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | PIN and active status stated; not checked on the register | `[grounded]` CV, self-reported | You check the PIN on the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated | `[grounded]` CV, self-reported | Your check |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | Your CV is silent on records | `[grounded]` CV silence | Show a short anonymised note (Q2) |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure and surgical wounds are direct; leg ulcers are not stated | `[inferred]` from the wound types on your CV | Q3 |
| R6 | Catheter and continence care | important | adjacent | medium | transferability | Catheter care direct; continence not stated | `[inferred]` | Q3 |
| R7 | Insulin administration | important | direct | medium | none | Stated on CV | `[grounded]` CV | none |
| R8 | Care planning | important | adjacent | low | transferability | Discharge assessment implies planning; not stated | `[inferred]` | none |
| R9 | End-of-life visits | important | unclear | low | discovery | Not on your CV | `[grounded]` CV silence | Q1 |
| R10 | Own caseload | must_have | adjacent | low | capability | Discharge-to-assess visits, but team-based, not your own list | `[inferred]` | Q1 |
| R11 | Doppler assessment (desirable) | preferred | absent | none | capability | Not on CV | `[grounded]` CV | Closure path: a short course or supervised practice |
| R12 | Electronic patient record | important | unclear | low | discovery | Not stated | `[grounded]` CV silence | Ask at interview |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R10) | transferability | Team-based home visits in the first week after discharge | The advert names this as the role's core | Any period where you planned your own visits or follow-up | A one-paragraph description of your discharge visit workflow | `[inferred]` |
| G2 | Doppler (R11) | capability | Not on CV | Desirable only, so a minor gap | Vascular or leg-ulcer assessments, even without Doppler | A training record or supervised practice plan | `[grounded]` CV |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's careers page | risk_signal | medium | "For an informal chat about the role, contact Rhiannon Mabbott" | The advert may be stale, or the employer's careers page may list it under another title | `[generic]` pattern for recruiting pages | "Is this post live on your careers page, and what is the reference?" | unresolved |
| RR2 | Mileage terms unstated | unknown | — | "plus mileage" | Mileage may be below what the pool car would save | `[inferred]` from the advert's silence on rate | "What is the mileage rate, and how are travel times counted?" | unresolved |
| RR3 | Support for a new caseload holder not described | unknown | — | "supported by a senior community nurse" | Support may be in name only | `[inferred]` from the advert's silence on supervision hours | "What caseload size and supervision would I have in the first three months?" | unresolved |
| RR4 | Clear duties and tools named | positive_signal | — | "all recorded on our electronic patient record" | The role is scoped and measurable | `[grounded]` advert | "Who sets caseload size?" | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your PIN on the NMC register before applying | Confirms R1 | `[grounded]` CV | your check |
| A2 | Ask Rhiannon Mabbott RR1–RR3 by email or phone, through the contact in the advert | Verifies the post and the support | `[grounded]` register | pending your approval |
| A3 | Describe your discharge visits as home-based nursing with patient follow-up, not as caseload management | Keeps R10 honest | `[inferred]` | pending your approval |
| A4 | Don't claim leg-ulcer or Doppler experience until you have it | Truthfulness | `[generic]` | noted |

**Evidence status**

Verified: none yet. Your CV claims (R1–R3, R7) stand as self-reported until checked.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and read the About page snippet at calderbrookhealth.example/about; fetched calderbrookhealth.example/careers, which returned no page. Organization row: the employer exists as described. RR1 raised |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing Halifax salary £31,050 £37,800", which returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration row |
| 3. Hiring manager's public footprint | skipped | The contact is named in the advert, but I did not search for her; this needs your go-ahead under the people-research guardrail |

**Upgrade menu**

- A live link to the posting or the employer's careers page: RR1 closes.
- An answer to the caseload and support questions: RR3 and G1 move.
- Your discharge visit workflow in a paragraph: R10 moves to `medium`.
- A training record or a supervised Doppler plan: R11 and G2 close.
- A go-ahead to look up the contact's public professional footprint: the positioning in A3 can be checked against her role.
- A deeper research pass on Calderbrook (inspection reports, recent news, staff reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

If you want a dossier file of this assessment, say so and I'll write `tuesday-dossier.md`.

**Questions** (reply in your own words, or say skip for any):

1. (G1, R10) In your discharge-to-assess role, did you plan and follow up your own visits, or did the team allocate them?
2. (R4) Can you share one anonymised care note, with nothing identifying the patient, that shows how you write up a visit?
3. (R5, R6) Have you dealt with leg ulcers, compression or continence assessment in any role?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.