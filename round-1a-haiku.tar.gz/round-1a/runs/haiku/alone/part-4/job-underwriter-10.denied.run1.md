**Take the call, after a quick check on the company. Status: `conditional_go`.** I can't establish Fernquay from here, because web search was refused this session. Nothing you've shared asks for money, bank details or a chat-only hiring process, so I see no scam pattern in what you pasted. Your fit is strong on the core requirements. The open questions are the employer's existence and what it's like to be the only designer.

**Fit ledger.**

- `hard_gate` — direct: R9 · unclear: R10 (Salary €52,000–€60,000)
- `must_have` — direct: R1, R2, R3, R4 · adjacent: R5 (Own the booking flow end to end)
- `important` — direct: R8 (A real messy project, not a deck) · adjacent: R6 (Research calls with school owners), R7 (First designer, working alone)

R5 — one checkout redesign, not the whole flow; R6 — usability sessions with your customers, not school owners; R7 — squad work, never the only designer; R10 — your pay floor is not given.

**Opportunity ledger.** The posting is specific and transparent: named people, a stated salary, office days and a real-project preference (RR5). The employer is not established from attributable sources (RR1), the team is one designer with no design peers (RR2), and the equity and pay band are unchecked (RR3, RR4).

- **Hard gates:** none failed (R9 `direct`); unconfirmed: R10 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: Fernquay is registered and its own careers page lists this role. (2) RR2 is answered on the call: who reviews design work and what tooling and budget exist. (3) R10 and RR3 are answered before any offer: your floor against the salary, and the equity class and vesting.
- **What would change this:** a failed RR1 check, with no registered company and no listing on the company's own site, moves this to `hold_pending_answers`. A request for money, a deposit or bank details before an offer would make it `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting. Existence not established (RR1) |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Scope read | Wide for one person: flow ownership, research and shipping, with no design peer | `[inferred]` from the posting's "first designer" and its team size |
| Market calibration | Not run. Search was unavailable, so no salary band is claimed | — |
| Unknowns | Equity class, vesting and strike price; whether the salary meets your floor; who reviews design work | — |
| Contradictions | None found between the posting and the WhatsApp message | `[grounded]` both as you pasted them |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a travel-booking company, as you stated it; no artifact here | `[grounded]` your statement | none |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use, as you stated it | `[grounded]` your statement | none |
| R3 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers, as you stated it | `[grounded]` your statement | none |
| R4 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your statement | none |
| R5 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of a booking flow. Limit: not discovery through shipping across the whole flow | `[inferred]` from the checkout work you described | G1 |
| R6 | Research calls with school owners | important | adjacent | medium | transferability | Customer usability sessions carry over. Limit: your customers were travellers, not owners of small businesses | `[inferred]` from the sessions you described | G3 |
| R7 | First designer, working alone | important | adjacent | low | transferability | You have never been the only designer. Squad work and self-run research are the nearest evidence. Limit: no solo shipping, no design direction without peers | `[grounded]` your statement; the gap is `[inferred]` | G2 |
| R8 | A real messy project over a polished deck | important | direct | medium | presentation | The checkout case study is the nearest artifact. Surface the process, not the polish | `[grounded]` the recruiter's remark about the case study | G4 |
| R9 | Hybrid, two days in Galway | hard_gate | direct | medium | none | You moved back to Galway | `[grounded]` your statement | none |
| R10 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your pay floor is not given, so the check is unknown | `[grounded]` the posting's figure; no floor given | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow end to end (R5, must_have) | transferability | Checkout redesign, one stage | Flow ownership is the core of the job | Any stage of a booking or purchase flow you specified, tested and saw through to release | The checkout case study with the decisions you owned | `[inferred]` from your checkout work |
| G2 | Working alone (R7, important) | transferability | Squad work only | The posting says you would be the first designer | Freelance, a side project, a volunteer job: anything you designed and shipped with no other designer | One project you drove alone, with its decisions | `[grounded]` your statement |
| G3 | Research with owners of small businesses (R6, important) | transferability | Customer sessions with travellers | The job includes research calls with school owners | Interviews with small-business customers, or any B2B-style research | Your interview guide or a session summary | `[inferred]` |
| G4 | Messy real project (R8, important) | presentation | A polished case study that the recruiter liked | The posting asks for process over polish | Where research changed the design, and what failed | The case study, with its dead ends | `[grounded]` the recruiter's remark |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software" | The company may be new or very small with little public footprint, the posting may be stale, or it may not be a real hiring employer. Search was unavailable, so this is not a finding that the company failed a check | `[generic]` pattern for companies of this size, not a claim about this one | Can you give me Fernquay's registered company name and the link to this role on your careers page? | unresolved |
| RR2 | Solo role with no design peers | risk_signal | medium | "You would be our first designer" | Design direction, review and tooling may fall to one person | `[inferred]` from "first designer" against the two-engineer team | Who reviews design decisions day to day, and what tooling and budget does design have? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The equity class, vesting and strike price may matter more than the percentage | `[inferred]` from the posting, which gives no terms | What class of shares is this, with what vesting schedule and strike price? | unresolved |
| RR4 | Pay band not calibrated | unknown | — | "Salary €52,000–€60,000" | The band may sit inside or outside the market for this seniority. This session did not check | `[generic]` no market check run | How was this band set, and does it change with the level of hire? | unresolved |
| RR5 | Specific, transparent posting | positive_signal | — | "we would rather see one messy real project than a polished deck" | Scope and pay are stated, which lowers the chance of a bait listing | `[grounded]` the posting | What would you need to see from me in the first 90 days to call the hire a success? | noted |

The WhatsApp message is not a warning sign under the rules I work from. It only schedules a video call, and the invite came by email. Check that the invite comes from Fernquay's own domain.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the company yourself: search the Companies Registration Office register for the name, find its own site, and confirm the invite's sender domain. Check that Ronan Kehoe and Saoirse appear on the company's site or a public profile | RR1 | `[grounded]` RR1 | Yours to do. Nothing is sent |
| A2 | Lead the call with the checkout case study as the messy real project: what research changed, what failed, what you'd still fix | R8, G4 | `[grounded]` R8 | Pending your approval |
| A3 | Ask RR2, RR3 and RR4 verbatim on the call. Rehearsing the call itself belongs to the mock-interview skill | RR2, RR3, RR4 | `[grounded]` the register | Proposed |
| A4 | Name the solo limit before they ask: "I've never been the only designer. Here is how I'd work alone with two engineers, and what I'd want from you on review." | R7, RR2 | `[grounded]` your statements | Pending your approval |

## Evidence status

Verified: none yet. Your background is what you stated in this conversation, the checkout case study is unseen, and the employer is unchecked.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Fernquay booking software Galway sea kayak surf schools" was refused by the tool permission, so no company page was checked. It would have moved RR1 |
| 2. Role-family sweep | unavailable | No search was sent, because search permission was refused. It would have set RR4 against the market. No band is claimed here |
| 3. Hiring manager's public footprint | unavailable | The search "Ronan Kehoe Fernquay co-founder" was refused. It would have moved the scope read and the positioning in A4 |

## Upgrade menu

- Enabling web search, or pasting the live posting or the careers page, runs targets 1 to 3 and can resolve RR1. Pasting the page counts as its check.
- The checkout case study, as a link or pasted text, moves R1 to R3, R5 and R8 from `medium` toward `high`, and shows whether the messy-project read holds.
- Any project you designed alone, even a small one, moves R7 from `low`.
- Your pay floor resolves R10.
- A deeper pass on funding, leadership changes and recent news (up to 5 more searches and 2 more fetches) is available if search is enabled. Say the word and it runs.

If you want, I can write this assessment into a `tuesday-dossier.md` file to carry into your call prep.

G2 (R7) — Have you ever designed or shipped something with no other designer around, such as freelance work, a side project or volunteering? What did you decide alone, and how did it turn out?

Q2 (R10) — What's the lowest salary you would accept, and is there any other term you would not take?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.