**Decision snapshot**

- **Opportunity: conditional_go.** The job itself reads well. Pay (€40,000 in a €38,000–€42,000 band) and location (Limerick, two days in office) fit your stated constraints. The one thing to settle before anything else is whether Marrowgate is who the offer says it is.
- **Candidate fit: strong on paper.** Your gaps are narrow: pension changes, and scale and cycle (240 staff monthly versus your 90 fortnightly).
- **Hard gates:** none failed on what's stated. Salary floor and schedule constraints weren't given, so those are unknown and marked as such below.
- **Direct answer:** No, it isn't normal to send a bank details, PPS and passport bundle through an emailed portal link before you've verified the employer and have a signed contract. Don't use the link yet.

**Role reality**

- Scope: monthly payroll for 240 staff, starters, leavers, pension changes, monthly payroll-to-GL reconciliation, staff queries. `[grounded]` from the posting.
- Reporting line to Declan Garvagh, Finance Manager, is named in the offer. `[grounded]`, not yet verified.
- Market calibration: a mid-level payroll administrator at this scope sits in a typical range. `[generic]`, not a claim about this employer.
- Compensation: €40,000 is inside the posted band. The band is `[grounded]` from the posting. Whether it is market-normal for this employer is `[generic]`.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Source |
|---|---|---|---|---|---|---|
| 1 | 2+ years running payroll | Must | Met | high (self-reported, referee-checkable) | none | CV |
| 2 | Working knowledge of PAYE, PRSI, USC | Must | Likely met | medium | presentation: not detailed; Irish jurisdiction of hotel group not stated | CV |
| 3 | Strong Excel | Must | Met | medium-high | none | CV (pivot tables, XLOOKUP) |
| 4 | Payroll qualification | Must | Met | high (certificate) | none | Payroll Technician cert, 2024 |
| 5 | Starters and leavers | Must | Met | high | none | CV |
| 6 | Monthly payroll-to-GL reconciliation | Must | Met | high | none | CV |
| 7 | Monthly run for 240 staff | Must | Partial | medium | transferability: fortnightly, 90 staff | CV |
| 8 | Pension changes | Must | Not evidenced | low | capability: not done personally | CV (your own account) |
| 9 | Answering staff payroll queries | Must | Not evidenced | low | discovery: not stated, may already be covered | — |

**Gap recovery queue**

- **Row 8 (pension changes), capability.** Closes with evidence of exposure: observed processes, knowledge of the scheme or provider, or a short ramp-up plan.
- **Row 7 (scale and cycle), transferability.** Closes by describing how you handled fortnightly cut-offs and the reconciliation cadence at 90 staff.
- **Row 9 (staff queries), discovery.** Closes if you handled payroll queries in the hotel role.

**Opportunity risk register**

| Class | Severity | Entry |
|---|---|---|
| Failed attribution (standing) | High | I can't confirm Marrowgate exists as described from the email alone. `people@marrowgate.example` can't be checked from here. Resolve by finding the company's own website yourself and matching the address and role. |
| Red flag: data collection | High | Bank details, PPS number and passport scan requested in one portal link, after an offer, with a five-day acceptance window. This is the classic pattern for identity-theft and payment-redirection scams. Legitimate employers do collect these, but through a verified channel and usually after contract signing. |
| Red flag: duplicated ID check | Medium | The offer asks for a passport scan now and the original on day one. Right-to-work checks are normally done against originals in person, so a pre-start scan needs a clear reason. `[generic]` |
| Gap: terms | Medium | No written contract, probation, pension scheme or notice terms were mentioned. |
| Positive signal | — | You had two in-person interviews at their office. Check that the address is the company's real one. |

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company website and careers page | skipped | not consented; L0 |
| 2. Role-family sweep | skipped | not consented; L0 |
| 3. Hiring manager's public footprint | skipped | no consent; not requested |

**What to do before you reply to the offer**

1. Don't click the portal link or upload anything.
2. Find Marrowgate's website yourself, not through the email. Check that the role is listed there and that Declan Garvagh is Finance Manager.
3. Call the main number from that website and confirm the offer and the People Team contact.
4. Ask for the written contract and terms first. Ask why a passport scan is needed before start, and how the PPS and bank details will be collected when the contract is signed.
5. If they push you to use the portal before you've verified them, treat that as a reason to stop.

Your instinct is right, though the issue is the channel and the timing, not whether a real employer will ever need these details.

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file to carry into interview prep, if you want one.

**Upgrade menu**

- The company's website address and the role's live posting link: unlocks the employer check in step 2 above.
- The full sender address and any phone number on the offer email: lets us compare it against the company's own contact details.
- Your pension exposure (observed, knew the provider, or none): closes gap row 8.
- Whether the hotel group ran Irish payroll and whether you can do two office days a week in Limerick: closes the jurisdiction and location unknowns.

**Questions**

1. What is the company's own website address, and can you see this role listed on it? If you'd like me to check it, I can run a light research pass (up to 5 searches and 2 page fetches) on the company and posting. Say yes or skip.
2. What exposure have you had to pension processes? Did you observe them, know the scheme or provider, or have none?
3. Can you commit to two office days a week in Limerick, and is there a salary below which you wouldn't accept?

Reply to any question, say "skip" to pass, or ask for the research pass.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.