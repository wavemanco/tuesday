**Yes, take the call, but treat it as conditional: `conditional_go`.** Fit is credible. Legitimacy is unverified, not negative. Nothing in the posting or the WhatsApp message asks for money, bank details or a chat-only hiring process. But I could not confirm that Fernquay exists as described, because web search was refused in this session.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay and equity against your floor); candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **Fit ledger:**
  - `hard_gate` — direct: R1 · unclear: R2 (pay and equity against your floor)
  - `must_have` — direct: R3, R4, R7, R8 · adjacent: R5 (own the booking flow end to end), R6 (research with school owners) · unclear: R9 (operate as first designer)

  R3, R4, R7 and R8 cover core design and working with engineers; R5 and R6 are transferable but not shown; R9 is the open question.
- **Opportunity ledger.** RR4 reads positive (pay and location are stated plainly). RR1 and RR5 are the employer check, RR3 is unstated equity, and RR2 is the design-support question.
- **What would change this:** conditions for go are (1) RR1 and RR5 clear on Fernquay's own site and the invite's sender domain; (2) R2 checked against your pay floor; (3) RR2 answered in a way you can work with. If the company can't be found on its own domain, or the invite doesn't come from it, I'd move to `hold_pending_answers`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | [grounded] posting |
| Team | Two engineers, CTO Saoirse, co-founder Ronan Kehoe; you would be the first designer | [grounded] posting, WhatsApp message |
| Process | Video call, 45 minutes, with Ronan and Saoirse; invite by email | [grounded] WhatsApp message |
| Scope read | Owning a whole booking flow as the sole designer is a broad remit for one role | [inferred] from "own the booking flow end to end" against "first designer" |
| Working pattern | Hybrid: two days a week in the Galway office, the rest remote | [grounded] posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity, with no vesting or share terms stated | [grounded] posting |
| Market calibration | Not run. No search ran, so no band for this title, seniority or equity is available | — |
| Unknowns | Whether the company exists as described; your pay floor; equity terms; who sets design priorities; funding and runway | — |
| Contradictions | None visible within the posting or the message | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two office days in Galway | hard_gate | direct | high | none | You moved back to Galway last year | [grounded] your statement | none |
| R2 | Pay and equity against your floor | hard_gate | unclear | none | hard_gate | Posted pay is stated; your floor was not given, so the fit can't be called | [grounded] posting | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer; stated, no artifact yet | [grounded] your statement | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, stated; no shared file yet | [grounded] your statement | a shareable Figma file would raise this |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of a booking flow; end-to-end ownership isn't shown | [inferred] from your checkout work against the requirement | G1 |
| R6 | Research calls with school owners | must_have | adjacent | medium | transferability | Your usability sessions were with travel-booking customers; the method transfers, the segment doesn't | [inferred] from your research work against the requirement | G3 |
| R7 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers | [grounded] your statement | none |
| R8 | Works directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers | [grounded] your statement | none |
| R9 | Operates as the first designer, with no design peers | must_have | unclear | low | capability | You have never been the only designer; no evidence either way | [grounded] your statement | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a flow beyond checkout (R5) | transferability | Checkout redesign only | R5 sits at `adjacent`; a second stage of the flow would narrow the objection | Any booking or onboarding step you scoped and shipped, even partly | A short write-up, or the checkout case study if you can share it | [inferred] from the CV against the requirement |
| G2 | Working without design peers (R9) | capability | Always had a design team around you | This is the main question about the role itself | Decisions you made alone with engineers in the squad; how critique happened day to day | A short note on how design decisions were reviewed in your squad | [grounded] your statement |
| G3 | School owners as users (R6) | transferability | Customer research, different segment | Owner-operators have different constraints from travel customers | Interviews with small-business customers | Notes from any research with small operators | [inferred] |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | Research was refused, so this is unverified, not shown missing. The company may be too new or small to have a footprint, the posting may be stale, or it may not be a live hiring employer. | [generic] pattern for companies this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | No design peers or critique | risk_signal | medium | "You would be our first designer." | You may be judged on design output with no design lead to review it. | [generic] pattern for first-designer hires | How do design decisions get reviewed, and who would I critique with day to day? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The equity's worth depends on share count and terms the posting doesn't show. | [generic] early-stage equity pattern | What share class, vesting schedule and strike price apply, and how many shares are issued in total? | unresolved |
| RR4 | Pay and location stated plainly | positive_signal | — | "Salary €52,000–€60,000 … two days a week at our Galway office" | Clear terms, which suits a Galway-based candidate. | [grounded] posting | Who owns the booking flow roadmap? | noted |
| RR5 | Contact channel for the interview | unknown | — | "I have emailed you a calendar invite with the video link." | Chat for scheduling a video call, with the invite by email, is ordinary for a small team. The invite's sender domain is not yet checked. | [inferred] from the message as received | Could you confirm the invite came from the company's own email domain? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the invite's sender domain against the company's own site before replying | RR1, RR5 | [generic] check you can run yourself | for you |
| P2 | Reply on WhatsApp only to confirm a time; keep the invite and call on email and video | RR5 | [inferred] from the message | pending your approval |
| P3 | Ask whether the checkout case study can be shown; if it's confidential, prepare a version without client data | R5, G1 | [generic] norm for former-employer work | pending your approval |
| P4 | Bring the RR2 and RR3 questions to the call, verbatim | The register doubles as interview prep | [grounded] register | proposed |
| P5 | Prepare a one-minute account of owning a flow beyond checkout | G1 | [grounded] gap queue | proposed |

**Evidence status.** Verified: none yet. Your background is your own statement, so it stays a lead until backed by an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay Galway booking software sea kayak surf schools"; refused, so no result. Would have moved RR1: whether the company exists as described and the posting is live. |
| 2. Role-family sweep | unavailable | Not sent; search is not permitted in this session. Would have moved the market band for R2 and RR3 (pay and equity calibration). |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused, so no result. Would have moved the check that Ronan's co-founder role matches the posting. |

Dossier offer: I can write this assessment to `tuesday-dossier.md` if you want to keep it for later.

## Upgrade menu

- **Allowing web search** → RR1, RR3 and R2's market band close. I would run up to 3 more searches and 2 page fetches.
- **The live posting link or Fernquay's careers page URL** → RR1 closes in a single fetch. A link you give me is not counted against the budget.
- **Your pay floor** → R2 closes.
- **The equity terms** (share class, vesting, share count) → RR3 closes.
- **A piece of work showing the flow beyond checkout** → R5 moves toward `direct`.

**Questions**

1. What is your pay floor, and is anything beyond the Galway hybrid pattern a non-negotiable for you? (R2)
2. May I run the company and market checks now? If you allow web search, I'll run up to 3 more searches and 2 page fetches. (RR1, RR3)
3. Can the checkout case study be shown outside your former employer, or is it confidential? (R5)

Answer in text, paste a link, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.