**Decision snapshot: conditional_go, pending employer verification. Don't send bank details, PPS or passport yet.**

- **Fit (candidate side):** strong on the stated requirements. Three years of payroll for 90 staff, PPS/PAYE-style payroll experience, monthly payroll-to-ledger reconciliation, daily Excel, and a Payroll Technician certificate (2024). Gaps are pension changes (never done them herself), the scale jump from 90 to 240 staff, and the monthly cycle (she ran fortnightly). `[grounded]` from your account; not yet tested.
- **Hard gates:** none stated that you'd fail. Pay (€40,000) is inside the advertised €38k–€42k band. Hybrid is two days in Limerick, as advertised. Your right to work is unknown to me, so that check is still open.
- **Opportunity:** the role itself looks normal. The problem is the sequence of the offer and what has not been verified.

**The data request: partly normal, but the order is wrong**

- Bank details, PPS and right-to-work checks are normal parts of onboarding. `[generic]`
- They normally come after a written contract is signed, not before. You're being asked to hand over identity and bank data before you've seen terms, salary in writing, or a contract. That's the part to push back on.
- A passport scan is more than payroll needs. Right-to-work checks normally mean viewing the original document in person. Asking for it on day one, as they also do, is consistent with that. Asking for a scan up front through a portal is the step to question. `[generic]`
- Your family's "never hand those over" rule is right for unverified parties and wrong as an absolute. Give the data once the employer is confirmed and the contract is in hand, and only through a channel you've checked.

**The red flag in the offer itself**

The sender address is `people@marrowgate.example`. `.example` is a reserved domain that no real organisation can hold. If you changed the domain when you pasted this, ignore that. If the email really came from that address, treat the whole offer as suspicious and don't click the portal link.

**Research status**

I tried to search for Marrowgate Housing and the permission was refused, so nothing about the employer has been verified online.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; the one search was refused.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Search permission refused |
| 2 | Role-family sweep (market pay and scope) | skipped | Not run after the refusal |
| 3 | Hiring manager's public footprint (Declan Garvagh) | skipped | Not run after the refusal |

**Before you reply to the offer**

1. Find Marrowgate Housing yourself: its official website, the Approved Housing Bodies Regulatory Authority register (if it is an approved housing body), and the Companies Registration Office. Use contact details from those sites, not from the email.
2. Confirm Declan Garvagh and the People Team exist there.
3. Reply to accept only in principle, and ask for a written contract (salary, start date, pension, hours, probation) before any personal data.
4. When data is requested, use only the employer's verified portal and send bank details from the same portal. Never by plain email.
5. Walk away if they ask you to pay anything, rush you within the five-day window, or won't talk on a number you've verified.

**Fit gaps to close before you accept**

- Pension changes: say so honestly and ask what their pension scheme involves. It's a capability gap you can close with a few weeks of study or a quick practice exercise.
- Scale and monthly cycle: a real but manageable step up. Ask how many payroll runs they do and who checks them.

**Upgrade menu**

- A live link to the job advert, or the careers page, would let me check the posting matches the offer.
- The AHBRA or CRO entry for Marrowgate, if you can paste it.
- A real sender domain from their website, if the offer's address was only anonymised.
- Your right-to-work status, so the hard-gate row can be closed.

**Questions**

1. What is the real sender domain on their offer email, and is the job advert still live somewhere I can read?
2. Have they sent a written contract yet, or only this letter?
3. Did you apply directly, or through a recruiter?

A dossier file of this assessment can be produced for mock-interview prep, if you want it later.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.