## Decision: apply, but confirm the employer first

**Decision: `conditional_go`.** On your stated evidence you meet every essential requirement that can be checked from a CV. The real gaps are owning a caseload and community-specific skills, and neither is a hard gate. The condition is that the employer and posting are verified before you spend time on the application.

- **Hard gates:** NMC registration, full UK licence, Halifax location and one year's post-registration experience are all met on what you've stated `[grounded]`. Your pay floor is unknown, so the £31,050–£37,800 band is not yet checked against it.
- **Essential requirements:** met for registration, licence and post-registration experience. Written records are unevidenced, and caseload ownership is a gap.
- **Desirable:** Doppler is a gap. It is trainable and does not block the application.
- **Confidence:** medium. Everything rests on your CV and the posting, with no outside checks yet.

I haven't used or repeated your National Insurance number. It isn't needed for this assessment.

**Research tier: L0, no searches.** I didn't search for the employer, so it stays unverified. That is the main reason for the condition.

## Evidence map

| # | Requirement | Priority | Evidence you've given | Fit | Gap type |
|---|---|---|---|---|---|
| 1 | NMC registration, Adult | Essential | Active, revalidation March 2028 | Met | None (check on the NMC register) |
| 2 | Full UK driving licence | Essential | Category B | Met | None |
| 3 | 1+ year post-registration | Essential | Five years as staff nurse | Met | None |
| 4 | Clear, timely written records | Essential | Not mentioned | Unevidenced | Presentation |
| 5 | Wound and leg-ulcer care | Core | Pressure ulcers and surgical wounds; no leg ulcers | Partly met | Transferability |
| 6 | Catheter and continence care | Core | Catheter stated; continence not stated | Partly met | Presentation |
| 7 | Insulin administration | Core | Stated | Met | None |
| 8 | End-of-life visits | Core | Not stated; home visits may cover it | Unevidenced | Discovery |
| 9 | Care planning | Core | Implied by discharge-to-assess `[inferred]` | Partly met | Discovery |
| 10 | Own small caseload | Core | Never held one | Gap | Capability |
| 11 | Electronic patient record | Core | Not stated | Unknown | Discovery |
| 12 | Doppler assessment | Desirable | None | Gap | Capability (trainable) |

**Strongest point:** the 18 months of home visits in the first week after discharge. That is the closest thing to community work on your CV, and it should lead.

## Opportunity risks

- **Employer unverified (standing entry):** I can't confirm Calderbrook Community Health CIC exists as described. A live posting link would settle it.
- **Band 5 for a five-year nurse:** this may be a fast-start role with a quick ceiling `[generic]`. Ask about progression.
- **Lone working with a senior nurse as backup:** the role says the caseload is held independently. Ask about safeguarding, on-call and out-of-hours cover.
- **Terms unstated:** mileage rates, pension and whether NHS terms apply. A CIC may not use NHS pay scales `[generic]`.

## Application plan

- **Lead with:** home visits after discharge, then wound, catheter and insulin care. Present these as what you've done, not as community experience you don't have.
- **Be explicit about the gaps:** say you haven't held a caseload and haven't done Doppler, and say what you'd do about each. Don't imply either is covered.
- **Resume edits (pending your approval):** I can draft the summary and a line on home-visit work. Nothing gets written into a CV or sent until you approve it.
- **Informal chat with Rhiannon Mabbott:** useful for caseload size, support, Doppler training and the pay question. Ask about these before applying.

---

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file you can reuse for other roles or interview prep, if you'd like.

**Upgrade menu:**
- **Live posting link or Calderbrook's careers page:** verifies the employer, which would move this from `conditional_go` to `go`.
- **Research at L1 (up to 5 searches, 2 page fetches):** checks the employer and the Band 5 market for Halifax `[generic]`.
- **Any example of written or electronic records:** an anonymised audit or EPR experience would move row 4 up.
- **Any community leg-ulcer or continence experience:** would move rows 5 and 6 up.
- **A Doppler training plan:** would turn row 12 into a plan rather than a gap.

**Questions:**
1. **(Row 4)** Have you written or audited care records on an electronic system, or in any way that a manager could check?
2. **(Rows 6 and 8)** Did your discharge-to-assess work include end-of-life visits or continence assessments?
3. **(Pay)** What is your minimum salary, and would you accept Band 5 pay for a caseload role?

Answer, skip or say "not sure" to each.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.