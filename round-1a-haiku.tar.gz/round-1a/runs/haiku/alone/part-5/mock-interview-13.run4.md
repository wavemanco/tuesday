Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/haiku/alone/part-5/rooms/case-13-denied-dbf680cc/quillmoor_operations-coordinator_interview_pack.md`. It's built on the advert, Hannah's message and your background as you wrote them. I didn't run any web research, because the call's topics are logistics and your material already answers them.

# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

Recruiter: Hannah Lowther (Talent Partner). 30-minute phone call, Thursday 2pm, on the mobile number on your application.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what's being scored: **JD** (the listed job), **EXP** (your experience), **CASE** (a live problem), **VAL** (values), **CO** (company knowledge).
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Prep time wasn't stated, so this is ordered by what the call will check.

1. Know your notice period as a number. A2 is the one logistics answer your material doesn't give.
2. Say £42,000 plainly. It sits inside the advertised £38,000–£44,000 (A1).
3. Two days at Avonmouth is fine; three is the most you want (A3).
4. The reason for moving is the Bristol closure and the Reading offer, nothing more (A4).
5. Be exact about SAP and production planning (B2, B3).

Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Closed. Your own account, so expect a check on dates. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Delivery scheduling is adjacent work, not production planning, and nothing you wrote reaches QA. Answer slot: if you worked with planning, the warehouse or QA in any way, say what it was; if not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | presentation | Your sentence already reaches this: "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Closed. "About a third" is a figure, so expect it to be probed (B1). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material doesn't show dispatch reporting. Answer slot: if you reported on dispatch or delivery timing, say what and how often; if not, say so plainly and say how you'd start. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | A spreadsheet rebuild touches Excel without showing your level. Answer slot: say what you built and what you were comfortable doing; if unsure how to rate yourself, say so. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | No SAP, and it's a plus, not a requirement. Your in-house system is adjacent work. Words: "I've never used SAP. We ran our own in-house stock system." |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your own constraint, met at two days. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your target sits inside the band. |

No row is a hard gate that's unmet. Location and pay are met on your own stated terms.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I coordinated production schedules" | Inflated form of F2 | "I schedule deliveries for our three depots." |
| "I have ERP experience" or "I know SAP" | Negative you stated (F7) | "I've never used SAP. We ran our own in-house stock system." |
| "Advanced Excel" | Inflated form of F6 | "I rebuilt our stock-count spreadsheet." |
| "I cut discrepancies by a third" | Inflated form of F4; your sentence says they fell, not who caused it alone | "Discrepancies fell by about a third over a year." |
| Any willingness to relocate to Reading | Negative you stated | "The only offer is relocating to Reading, which I don't want." |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Conversational / logistics | Top (4 questions) | A recruiter screen is logistics in a friendly register. Pay, notice, location and reason for leaving are scored. |
| Skeptic | Light (3 questions) | Motivation consistency and CV gaps are the usual screen probes. |

## Question banks

### Persona A: Conversational / logistics

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say £42,000 plainly, in your own words. It sits inside the advertised band, and you can say so. | Pay is a knockout check against the band. F9. |
| A2 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Logistics slot: give your actual notice period in weeks, as your contract states it. Your material gives no figure, so check it before Thursday. | Notice sets the earliest start date. You fill it. |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Two days at Avonmouth is fine. State three as the ceiling and stop there. | F8. Your own constraint. |
| A4 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the closure and the Reading offer in those terms. No criticism of the company. End on what you're looking for. | Reason for leaving is a logistics slot and the motivation probe. |
| A5 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." | A 90-second arc: the role, the three depots, the chasing, then the stock-count fix. | F1, F3, F4. Opening biography is scored too. |

### Persona B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You mention a stock-count improvement. How did you measure it?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say how discrepancies were counted, what the figure is sensitive to, the assumption you'd defend least, and which part was yours. If you don't know how it was counted, say so. | F4 is a figure, so it gets the defend-the-number slots. |
| B2 | "The advert asks for SAP or similar. What's your ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **Highest-ROI prep.** Hold it plainly: "I've never used SAP. We ran our own in-house stock system." Then say what that system did, in your own words. Hold through two follow-ups by returning to the system, never by adding to it. | F7. The likeliest probe, and it's a plus, not a requirement. |
| B3 | "The role coordinates production planning and QA. Where have you worked with either?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: say what you scheduled and for whom. If you had contact with planning or QA, say what it was; if none, say so and say how you'd learn the production side. | F2. The honest answer is the limit. |

## Coverage

| JD requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A5 |
| Coordinate production schedules across planning, warehouse and QA | B3 |
| Track supplier deliveries and chase late orders | A5 |
| Keep stock records accurate | B1 |
| Weekly on-time dispatch reporting | none, and why: this screen doesn't ask it, and F5 is a discovery gap. R2 raises it. |
| Confident with Excel | none, and why: a probe is possible, so answer from F6 if asked. |
| ERP (SAP or similar), a plus | B2 |
| Hybrid, two days at Avonmouth | A3 |
| Pay band £38,000–£44,000 | A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for this role?" | Shows you think in outcomes. |
| R2 | "How is on-time dispatch reported today, and who reads the weekly report?" | Shows you read the reporting line, and surfaces F5. |
| R3 | "Is the in-house stock system being replaced, and where does this role sit in that?" | Shows you know the SAP question is live, and raises your gap on your own terms. |
| R4 | "Which two days do people usually come into Avonmouth?" | Tests the hybrid pattern concretely. |
| R5 | "Who would I coordinate with most day to day across planning, the warehouse and QA?" | Shows you're thinking about the team you'd join. |
| R6 | "What are the next steps, and when is a decision expected?" | A clear close. Ask it even if Hannah covers it. |

## Sources

- Provided: the advert, Hannah's message, your background message.
- Research tier: L0, provided documents only. No search was run. Hannah set the topics, and the material decides every answer on the call.

| Target | Status | What it moved, or would have |
|---|---|---|
| Quillmoor values | skipped | Nothing: no values round is detected. |
| Quillmoor interview process | skipped | Nothing: Hannah has set the topics. |
| Quillmoor strategy or news | skipped | Nothing: not needed for a logistics screen. |
| Hannah Lowther | n/a | A recruiter; no profile sought. |
| Representative JD | skipped | Nothing: your advert fixes the fit snapshot. |

## Upgrade menu

- Your notice period as a figure → fills A2 in your own words, so you walk in with the number.
- Research at L1 (a search on Quillmoor's values and process) → a short company line for the call. It moves nothing in the logistics answers.
- Later interview rounds, if you have them → persona weights and questions for each.

---

Two offers, neither pushed:
- I can play Hannah for a drill: the conversational recruiter on A4, or the skeptic on B2, which is the one to rehearse most.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for future sessions. I can also convert the pack to Word if you'd like.

I kept the pack shorter than the usual session size, since you asked for tight and the call is 30 minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

Recruiter: Hannah Lowther (Talent Partner). Format: 30-minute phone call, Thursday 2pm, on the mobile number on your application.
Built on: the advert, Hannah's message, and your own background as you wrote it. No interviewer profile and no research run (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **JD** (the listed job), **EXP** (your experience), **CASE** (a live problem), **VAL** (values), **CO** (company knowledge).
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Prep time was not stated, so this is ordered by what the call will check.

1. Know your notice period as a number. A2 is the only logistics answer your material does not give.
2. Say £42,000 plainly. It sits inside the advertised £38,000 to £44,000 (A1).
3. Two days at Avonmouth is fine; three is the most you want (A3).
4. The reason for moving is the Bristol closure and the Reading offer, nothing more (A4).
5. Be exact about SAP and production planning (B2, B3).

Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Closed. Your own account, so expect a check on dates. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Delivery scheduling is adjacent work, not production planning, and nothing you wrote reaches QA. Answer slot: if you worked with planning, the warehouse or QA in any way, say what it was; if you did not, say so plainly. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | presentation | Your sentence already reaches this in other terms: "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Closed. "About a third" is a figure, so expect it to be probed (B1). |
| F5 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you reported on dispatch or delivery timing, say what and how often; if not, say so plainly and say how you would start. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | A spreadsheet rebuild touches Excel without showing your level. Answer slot: say what you built in it and what you were comfortable doing; if you are unsure how to rate yourself, say that. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | No SAP, and it is a plus rather than a requirement. Your in-house system is adjacent work. Words: "I've never used SAP. We ran our own in-house stock system." Keep the system's scope to what you describe. |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Your own constraint, met at two days. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your target sits inside the advertised band. |

Gap type routing: F2, F7 are transferability (adjacent work does not reach the requirement); F3 is presentation (your quote already reaches it); F5, F6 are discovery (the material is silent or touches without showing). No row is a hard gate unmet. Location and pay are met on your own stated terms.

## Prohibited claims

Not coached, and why each is out.

| Not coached | Basis | Honest form |
|---|---|---|
| "I coordinated production schedules" | Inflated form of F2. Your material says deliveries, not production. | "I schedule deliveries for our three depots." |
| "I have ERP experience" or "I know SAP" | Negative you stated (F7). | "I've never used SAP. We ran our own in-house stock system." |
| "Advanced Excel" | Inflated form of F6. Your material shows a rebuilt spreadsheet, not a skill level. | "I rebuilt our stock-count spreadsheet." |
| "I cut discrepancies by a third" | Inflated form of F4. Your sentence says they fell over a year, not who caused it alone. | "Discrepancies fell by about a third over a year." |
| Any willingness to relocate to Reading | Negative you stated. | "The only offer is relocating to Reading, which I don't want." |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Conversational / logistics | Top (4 questions) | A recruiter screen is logistics in a friendly register. Pay, notice, location and reason for leaving are scored, not chatted through. |
| Skeptic | Light (3 questions) | Motivation consistency and the gaps in your CV are the usual screen probes. |

No interviewer profile exists, so there is no interviewer read. Round type is a recruiter screen, so the weights follow the relationship prior in the persona model.

## Question banks

### Persona A: Conversational / logistics

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say £42,000 plainly, in your own words. It sits inside the advertised band, and you can say so. | Pay is a knockout check against the band. F9. |
| A2 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Logistics slot: give your actual notice period in weeks, as your contract states it. Your material does not give a figure, so check it before Thursday. | Notice sets the earliest start date. Not in your material, so you fill it. |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Two days at Avonmouth is fine. State three as the ceiling and stop there. | F8. Your own constraint, so no slot. |
| A4 | "What's prompting a move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the closure and the Reading offer in those terms. No criticism of the company. End on what you are looking for. | Reason for leaving is a logistics slot and the motivation probe. |
| A5 | "So, walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip." | A 90-second arc: the role, the three depots, the chasing, then the stock-count fix. Use your own words. | F1, F3, F4. Opening biography is scored too. |

### Persona B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You mention a stock-count improvement. How did you measure it?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say how discrepancies were counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. | F4 is a figure, so it gets the defend-the-number slots. |
| B2 | "The advert asks for SAP or similar. What's your ERP experience?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Highest-ROI prep. Hold it plainly: "I've never used SAP. We ran our own in-house stock system." Then say what that system did, in your own words. Hold through two follow-ups by returning to the system, never by adding to it. | F7. The requirement most likely to be probed, and it is a plus, not a requirement. |
| B3 | "The role coordinates production planning and QA. Where have you worked with either?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: say what you scheduled and for whom. If you had contact with planning or QA, say what it was; if none, say so plainly and say how you would learn the production side. | F2. Transferability, and the honest answer is the limit. |

## Coverage

| JD requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A5 |
| Coordinate production schedules across planning, warehouse and QA | B3 |
| Track supplier deliveries and chase late orders | A5 |
| Keep stock records accurate | B1 |
| Weekly on-time dispatch reporting | none, and why: this screen does not ask it, and F5 is a discovery gap. Reverse question R2 raises it. |
| Confident with Excel | none, and why: a probe is possible, so answer from F6 if asked. |
| ERP (SAP or similar), a plus | B2 |
| Hybrid, two days at Avonmouth | A3 |
| Pay band £38,000 to £44,000 | A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for this role?" | Shows you think in outcomes, not just the job description. |
| R2 | "How is on-time dispatch reported today, and who reads the weekly report?" | Shows you read the reporting line in the advert, and surfaces F5. |
| R3 | "Is the in-house stock system being replaced, and where does this role sit in that?" | Shows you know the SAP question is live, and raises your gap on your own terms. |
| R4 | "Which two days do people usually come into Avonmouth?" | Tests the hybrid pattern concretely. |
| R5 | "Who would I coordinate with most day to day across planning, the warehouse and QA?" | Shows you are thinking about the team you would join. |
| R6 | "What are the next steps, and what is the timing for a decision?" | Gives you a clear close, and you can ask it even if Hannah covers it. |

## Sources

- Provided documents: the advert, Hannah's message, and your background message.
- Research tier: L0, provided documents only. No search was run. The screen's topics come from Hannah's message, and the provided material decides every answer on the call, so a search could not change this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| Quillmoor values | skipped | Nothing: no values round is detected, and the screen is logistics. |
| Quillmoor interview process | skipped | Nothing: Hannah has set the topics in her message. |
| Quillmoor strategy or news | skipped | Nothing: not needed for a logistics screen. |
| Hannah Lowther | n/a | A recruiter with no profile sought; the interviewer read is absent. |
| Representative Operations Coordinator advert | skipped | Nothing: the advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Your notice period as a figure → fills A2's slot in your own words, so you walk in with the number.
- Research at L1 (a search on Quillmoor's values and process) → a short company line for the call. It moves nothing in the logistics answers.
- The team's later interview rounds, if you have them → persona weights and bank questions for each round.
