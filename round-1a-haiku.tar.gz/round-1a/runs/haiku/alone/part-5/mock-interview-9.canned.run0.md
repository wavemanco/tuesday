Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/haiku/alone/part-5/rooms/case-9-canned-8aa70a02/halvering_fourth-grade-teacher_interview_pack.md`.

Your résumé includes your Social Security number. I left it out and didn't use it. Interviewers don't need it at this stage, so take it off the résumé before you send that to the district. The license number is also left out of the pack.

I built the pack from the invite, your résumé, and your message. I didn't run any company research, so there are no school values or recent-news sections. The panel is blended: the principal carries the Skeptic and Case personas, and the two team members carry the Peer Evaluator and Prober. Your highest-return prep is the question "You've never taught fourth grade. What makes you think you can teach it?" (A1). Your two stated gaps are the first things a principal would check.

Would you like me to play the principal on A1? I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions.

Do you have the posting's full text? If you paste it, I'll rebuild the fit snapshot from its exact wording. If not, I'll keep the pack as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Panel interview:** Thursday, 45 minutes. Principal Dolores Vantongeren and two fourth-grade team members (not named in the invite).
**Employer:** Orrinsford Community School District, Human Resources.
**Built from:** the invite, your résumé, and your message about the gaps. No company research ran (see Sources).
**Changelog:** first version.

---

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = does the candidate meet the posted job's requirements, gaps included. **EXP** = what the candidate actually did, tested by attribution. **VAL** = how past behaviour shows teamwork and judgment. **CASE** = a live problem from the role, scored on reasoning. **CO** = company knowledge (not used here, because no company research ran).
- Guidance is scaffolding, not a script. Rehearse in your own words. Each guidance cell is written to be spoken in 90 to 120 seconds.
- Provenance is shown in its own column. `[grounded]` means traceable to your résumé, your message, or the invite. `[generic]` means a role-family pattern with no claim about you or this school.

---

## 2. Fit snapshot

The invite gives one hard requirement (the license). The position title and the panel's makeup set the rest. The posting's full text was not supplied, so the requirements below are quoted only from the invite.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite, gate) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Gate met by your stated status. Nothing to rehearse beyond having the license details ready, including the June 30, 2029 expiry. |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [grounded] | transferability | Your material shows third grade, for six years, not fourth. "For six years I taught third grade at a public elementary school in Joliet." Answer slot: the panel will probe what carries over from third grade to fourth. Name which practices carry over. If you cannot yet name any, say so and say what you would learn first. |
| F3 | "Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | The gap you stated, in your words: "I haven't taught fourth grade." Then how you would close it, as a plan and never as past experience. |
| F4 | "two members of our fourth-grade team" (invite) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | presentation | The quote already reaches working with a grade-level team, in other terms: "In 2024 I led our grade level's move to a new reading curriculum." The bridge adds no practice and no outcome. |
| F5 | Shared planning and decisions on a grade team (role-family pattern, not quoted from the invite) [generic] | "I've never been a team lead" (your message) | none | [grounded] | capability | The gap you stated: "I haven't been a team lead." Then how you would contribute to team decisions, as a plan. |
| F6 | Reading instruction (role-family pattern) [generic] | "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | presentation | Reworded only: "For the last two years I've run the after-school reading club." |
| F7 | Family communication (role-family pattern) [generic] | "I write a weekly email to families." (your CV) | medium | [grounded] | presentation | Reworded only: "Each week I write an email to families." |

**Reading the table.** F2 and F3 both sit on the same posted title. F2 is what your material shows. F3 is what you told me you have not done. Both belong in your answer. F5 is a gap you stated, so it is acknowledged plainly rather than bridged.

---

## 3. Prohibited claims

These are claims this pack will not coach, because the material does not support them. None of them should appear in your answers.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade," or any fourth-grade experience | You stated the absence (F3). | "I haven't taught fourth grade." |
| "I have been a team lead," or "I led the grade team" | You stated the absence (F5). The quote in F4 is about a move, not a team. | "I haven't been a team lead." And, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." |
| "I ran the school's reading program" | An inflated form of F6. The quote is an after-school club, not a school program. | "I've run the after-school reading club for the last two years." |

**Limit noted in analysis (not words for you):** your material says you led a move to a curriculum and ran a club. It does not show the school's program, your results, or the team's decisions.

---

## 4. Persona table

| Persona | How it shows up in this panel | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| The Skeptic (weight 5) | The principal asks about the two gaps you stated: never taught fourth grade, never a team lead. "Why you?" | **High.** A grade placement's first check is whether the candidate has taught that grade. The two stated gaps are the ones a principal will name. | Say the plain acknowledgment first. Then the nearest quoted base. Then a ramp plan. Hold once, then concede one specific thing. |
| The Case / Strategist (weight 4) | The principal gives a live grade-level problem: reading gaps, a parent, a unit going wrong. | **High.** The principal is the hiring authority and will test how you would act, not only what you did. | Clarify before you act. Assess, group, talk with the team, bring in the family. Name the order and the reason. |
| The Peer Evaluator (weight 4) | The team members ask about the seam between their grade and yours, disagreement, and credit for shared work. | **High.** Two peers on the team will judge whether you add to their load. The invite names their team. | Propose seam principles, not facts about their grade. Offer reciprocity: what you need, and what you would bring. |
| The Data-Driven Prober (weight 3) | A team member asks what changed for students, how it was measured, and what the club's figures are. | **Medium.** Your material names two reading items with no figures, so a probe is likely but not certain. | Say what you counted, and how. If you counted nothing, say so plainly. Name the assumption you would defend least. |
| The Conversational / Rapport Builder (weight 2) | An opener such as "walk us through your path." | **Likely at the start.** Panels often open casually, and the answer is still scored. | Keep a 90-second arc ready: Joliet, third grade, the reading move, the club, the family email, and why fourth grade. |

**Weights, shown.** The panel is blended from relationship priors: the principal carries the Skeptic and the Case persona, and the two team members carry the Peer Evaluator and the Prober. The team members are not named, so per-member assignment is not possible. If they are named later, the weights can be recomputed.

---

## 5. Question banks

### Bank A: The Skeptic (weight 5), principal

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What makes you think you can teach it?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | **The highest-return prep in this pack.** Open with the plain acknowledgment: "I haven't taught fourth grade." Then your base, in your words: "For six years I taught third grade at a public elementary school in Joliet." Then name what carries over, what you would learn first, and how you would check early whether you are on track. Hold through two follow-ups by returning to the third-grade base and the plan. Concede one specific thing (a named content area you have not taught), never a general one. | F3 is the gap the principal will name first, because grade placement is the first check. The question's premise is one you stated, so it is asked as written. JD, because it scores the posted position. |
| A2 | "What in fourth grade will be hardest for you on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Name one or two parts of fourth-grade work you expect to be newest to you, in your own words, and what you would do about each in the first two weeks. Make no claim about this school's fourth-grade content. | F2 is a transferability gap. This is the Skeptic's standard self-assessment, and the answer should show judgment about the gap. |
| A3 | "You've never been a team lead. Why would we give you a say in grade-level decisions?" | JD | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Plain acknowledgment: "I haven't been a team lead." Then the nearest thing your material carries, at its own scope: "In 2024 I led our grade level's move to a new reading curriculum." Say who was involved in that move and what your part was. Answer slot: if you set the move's steps, say which; if the steps came from someone else, or the choice was not yours, say so plainly and describe your part. Then say how you would contribute to a grade-level decision. | F5 is a stated gap. F4 is the nearest quote, and the bridge stays inside the move, not the team. |
| A4 | "Tell me about a time you disagreed with a colleague about what is best for students. What happened?" | VAL | [generic] | An open prompt. Choose a disagreement you can describe cleanly: what was at stake, what you did, and how it ended. Answer slot: if no such time comes to mind, say so plainly, then say how you would raise a disagreement on a grade team, with the evidence in front of you. | The principal's values probe. Your material contains no disagreement, so the guidance supplies only the method. |
| A5 | "Sixty seconds: why this role, why now, and why you over someone who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've run the after-school reading club for the last two years" (your CV) | Three beats: your base (quoted), your reading work (quoted), then your real reason for wanting fourth grade, in your own words. Answer slot: your material gives no reason for the move, so name the one you actually have. For the second half, say plainly: "I haven't taught fourth grade, and here is what I would bring instead." Do not disparage other candidates. | A three-part motivation probe in one question. The reason for the move is yours and is not in the material, so it is an answer slot. |

### Bank B: The Peer Evaluator (weight 4), team members

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between your grade and ours, and what happens when we disagree about a lesson or an assessment?" | VAL | [grounded] "two members of our fourth-grade team" (invite) | Propose seam principles, not facts about their grade: shared planning dates, a common assessment calendar, and a rule for who decides when two plans conflict. For disagreement, state the principle first: raise it with the evidence in front of you, then decide together. Answer slot: if you have disagreed with colleagues about a lesson or assessment, describe it with a named stake and how it ended; if not, say so plainly and say how you would raise it. | The Peer Evaluator's core probe. The seam is theirs to name, so the guidance proposes principles and claims no knowledge of their grade. |
| B2 | "What would you need from us in your first month?" | JD | [generic] | Ask for specific things: the team's planning calendar, the shared materials, the assessment schedule, a standing time to talk. Then say what you would bring to their team. | Reciprocity, which the Peer Evaluator weights heavily. "What do you need" is a cost question for them to price. |
| B3 | "How do you handle credit when a reading change involves several teachers?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say who else was involved in the move, in your words, and what was yours. Do not shrink "led" and do not describe other people's roles you did not see. Answer slot: if others set parts of the change, name them and the parts; if you made the calls yourself, say that. | A credit probe on F4. The answer should say who did what, and nothing more. |
| B4 | "Describe what happens in the reading club, in your own words." | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Describe the club's activities in your own words, as you would to a colleague. Answer slot: if you chose who joins, say how; if you did not, say so plainly. | F6 is the club. Peers ask about the practice behind a line on a CV, and the answer must be yours. |

### Bank C: The Case / Strategist (weight 4), principal

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two students in your class are reading well below level six weeks into a unit. Walk me through your first moves." | CASE | [generic] | Clarify before you act: what the assessment actually shows, how much intervention time exists, and what the team already does for these students. Then assess more finely, group, talk with the team, and bring in the family. Name each move and why it comes in that order. Do not describe any school's program as fact. | A live problem from the role. It makes no claim about your past, so it needs no quote. |
| C2 | "A parent emails you upset that their child has not moved up a reading level. What do you say?" | CASE | [grounded] "I write a weekly email to families." (your CV) | Structure it: acknowledge the concern, say what you would check first, say what you would tell the parent and when, and say what you would put in your next family email. Your weekly email is a channel you already run, so say how you would use it here. | Parent communication is a likely principal probe, and the quote gives you a channel you have actually used. |
| C3 | "What would you check in fourth-grade reading in your first semester before you changed anything?" | CASE | [generic] | Name what you would look at first: the existing assessments and what they measure, where gaps cluster, and what the team already tracks. Then say what would make you change something and whom you would check with first. | A diagnose-before-changing question. It rewards sequence over a confident answer. |
| C4 | "What would a colleague say about how you work with a team?" | VAL | [generic] | Say how you would want a colleague to describe you, then name one behaviour behind it from your own work. Answer slot: if you cannot name a real example that fits, say so, and say which behaviour you want to be known for. | The principal's read on team fit, which the Skeptic bank cannot test. |

### Bank D: The Data-Driven Prober (weight 3), team members

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led a reading curriculum move. What changed for students, and how did you measure it?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what changed in classroom practice, in your words. On measurement, the answer is a slot: if you tracked any measure, name it, what it counted, and how; if you did not track one, say so plainly and name the measure you would use. Name the assumption you would defend least about any result you give. | The Prober tests the move's effect. Your material gives no measure, so the guidance cannot supply one. |
| D2 | "How would you tell whether the reading club is helping the children who attend?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (your CV) | Say what you would count and what you would be cautious about reading into it. Answer slot: if you counted anything during the two years, say what and how; if you did not, say so plainly. | A denominator probe on the club. The question asks for a method and presupposes no result. |
| D3 | "If you have figures for the club or the reading change, which would you give us, and how were they counted?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years." (your CV) | Give only figures you actually have. For each, say how it was counted and what it is sensitive to. If you have none, say so plainly and say what you would start counting. No figure is supplied here. | The defend-the-number slot. No figure is in your material, so the answer is an honest branch, never a number. |

### Bank E: The Conversational / Rapport Builder (weight 2), opener

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path to fourth grade." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I write a weekly email to families." (your CV) | A 90-second arc: Joliet and third grade, the reading move, the club, the weekly family email, and one honest sentence on why fourth grade, including "I haven't taught fourth grade yet." Keep it under 90 seconds. | Panels often open this way. The casual register is still scored. |
| E2 | "What's something you've been excited about teaching lately?" | VAL | [generic] | Name one topic or activity and say why it works for children. Keep it to one. | A rapport opener. The answer is scored for communication economy and real interest. |

**Coverage across the banks.** Banks A to E hold 18 questions. Depth follows persona weight: 5 for the Skeptic, 4 for the Case and the Peer Evaluator, 3 for the Prober, and 2 for the Conversational.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with an elementary endorsement (invite, F1) | — none, and why: the material states it as met. Having the license details ready is the whole preparation. |
| Fourth Grade Teacher position (invite, F2, F3) | A1, A2, A5 |
| Work with the fourth-grade team (invite, F4) | B1, B2, B3 |
| Shared planning and decisions on a grade team (F5, [generic]) | A3, A4, B1 |
| Reading instruction (F6, [generic]) | B4, C1, D2, D3, E1 |
| Family communication (F7, [generic]) | C2, E1 |

**Highest-return prep:** A1. This objection is the most likely to be asked in some form, and a rehearsed, non-defensive answer changes how the rest of the panel reads you.

---

## 6. Reverse questions

Each question is one you can ask at the end. The panel is internal, so these are chosen for the principal and the team.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a new fourth-grade teacher's first month look like here?" | It is concrete, and it answers the ramp concern from A1 and A2 before anyone raises it. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for the team members. It signals you are asking how to add, not only what you will receive. |
| R3 | "How does the grade team plan units together, and where does the reading curriculum fit in that?" | It tests the day-to-day, and the answer shows you where the seams are. |
| R4 | "Principal Vantongeren, what would success look like for this role at the end of the first year?" | It asks the principal for criteria, so you can measure yourself against what she actually expects. |
| R5 | "What did the fourth-grade team decide last year that a new teammate should know about?" | It shows interest in the team's practice, and it invites the team to talk about what they value. |
| R6 | "What do you most want the next fourth-grade teacher to bring to the team?" | It asks for the team's need directly, which is the skill the Peer Evaluator scores. |

---

## 7. Sources

**Provided documents:**
- The interview invite (Human Resources, Orrinsford Community School District).
- Your résumé (your CV).
- Your message about the two gaps (fourth-grade teaching and team leadership).

**Searches and fetches this turn:** none. Company research was not run.

**Dossier:** none present, so none consumed.

**Research tier: L0** (provided documents only). The research consent item gave way to the posting question, which is the one that shapes the fit snapshot most.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering Elementary School values | unavailable | Values cheat sheet, which is dropped here because no values are in hand. |
| 2. Orrinsford Community School District interview process for fourth-grade teacher | unavailable | Panel format, and whether a demonstration or written task is expected. |
| 3. Halvering or Orrinsford recent news and priorities | unavailable | Grounding brief, and a current CO bank. |
| 4. Dolores Vantongeren, public professional profile | unavailable | Interviewer read and a tailored reverse question. |
| 5. Representative fourth-grade teacher posting | unavailable | JD-tagged questions beyond the invite's own words. |

---

## 8. Upgrade menu

- **The posting's full text** → the requirements in section 2 become quoted `[grounded]` rows, and the coverage table checks against the posting's own list.
- **Your go-ahead for light research on the school and district** (values, interview process, recent news) → a values cheat sheet, a grounding brief, and current company questions.
- **Dolores Vantongeren's public professional profile** → persona weights read from her footprint, and a reverse question tied to her path.
- **Any written task or demonstration the district announces** → a build section for each one.
- **Your prep time before Thursday** → a prioritized schedule sized to that time.
- **A `tuesday-dossier.md`** → verified evidence for F2, F3 and F5, and limits on what this pack must not claim.
