I'd check this before preparing for it. The message has several common job-scam signs:

- **Unsolicited contact** from an unknown number, claiming they "found your profile online."
- **No company named**, only "a remote position with flexible hours."
- **The whole process on WhatsApp**, including the contract, with no calls or video. Real employers almost always speak to candidates by phone or video at some point.
- **Urgency**: an interview "tomorrow at 11am" for a role you haven't confirmed.

Scammers use this pattern to collect ID documents and bank details, to ask for payment for "equipment" or "training," or to recruit people to move money. Some legitimate recruiters do use WhatsApp, so this isn't proof, but it's enough reason to verify first.

**Before you reply to Jess or share anything:**

1. **Check your applications.** Look at the job boards or LinkedIn accounts you applied through. If this role isn't there, be suspicious.
2. **Ask for specifics** and don't accept vague answers: the company name, the exact job title, the job posting URL, and the agency's registered name and website.
3. **Verify independently.** Find the company's careers page yourself (don't use a link from Jess) and confirm the role is listed. Check that the agency exists on its official website and on LinkedIn.
4. **Ask for a video or phone call.** A real recruiter will usually agree. Scammers tend to refuse or keep delaying.
5. **Never send** your passport, ID, National Insurance or Social Security number, bank details, or photos of documents. Don't pay for anything, and don't accept or forward money or packages.

If you want to reply now, you could send something like:

> "Thanks, Jess. Before I confirm tomorrow, could you send the company name, the job posting link, and your agency's details? I'd also like a short video or phone call before we go further."

**Once you've confirmed the role is real,** I can run the mock-interview prep. To build it I'll need:

- The job description from the official posting
- Your CV
- The company name, if you have it, so I can cover its values and likely interview questions

I can also run a practice session where I play the interviewer, which is useful for a video or phone round. If it turns out to be a scam, send me the details anyway and I'll help you spot the warning signs.