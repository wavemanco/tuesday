Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN IE00 ..." and to "reply with a photo of your passport and your bank details before the interview", and it says "you deposit the cheque and send the balance on to the vendor". Requests like these, a fee or equipment payment, a cheque deposit, and passport or bank details before any offer, are a known scam pattern, and the fee request and the cheque are very likely a scam. Hold all three until you have checked the invite with the employer through contact details you find on its own website or careers page, not any in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-5-rooms-case-12-denied-95ef6dc1/e06ef38a-4565-4cf7-82b7-faf53094302e/scratchpad/brennock_remote-administrative-assistant_interview_pack.md. It's built for a 30-minute video call with the office manager, using your ad summary and background note.

# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

**How to use:** Personas describe how a question is asked. Types describe what is scored (JD, EXP, CASE). Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" | "I ran the appointment book for four physios" - your message | medium | [grounded] | transferability | Bridge: "I ran the appointment book for four physios." Answer slot: if you handled changes or clashes in that book, say how; if not, say so. |
| F2 | "booking travel" | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say how; if not, say how you would learn the booking tools. |
| F3 | "preparing documents in Word" | "I'm good with Word" - your message | medium | [grounded] | none | If asked for an example, name one document you prepared; if none, say so. |
| F4 | "preparing documents in Excel" | "I'm okay with Excel" - your message | low | [inferred] | discovery | Answer slot: name the Excel tasks you have done; if only basic, say so and how you'd close the gap. |
| F5 | "processing supplier invoices" | "I chased unpaid invoices" - your message | low | [inferred] | transferability | Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices, say which steps; if you only chased, say what you'd learn first. |
| F6 | remote working (job title) | none given | none | [grounded] | discovery | Answer slot: if you've worked remotely or with online tools, say which; if not, say how you'd keep a remote day organised. |

**Prohibited claims (not to be coached):** "Managed the company's calendars" (F1 stretched; your material says the appointment book for four physios); "Expert in Excel" (F4 stretched); "Processed supplier invoices" (F5 stretched).

## Persona weights

- **Skeptic (high):** probes your gaps against the four listed tasks. Counter: quote-led bridges, honest answer slots.
- **Case/Strategist (medium):** short live problems. Counter: clarify first, then sequence.
- **Conversational (high):** a 30-minute call often opens with rapport. Counter: a 90-second arc.

## Question banks

**Skeptic**
- **A1** "Which of these four tasks would you be weakest at on day one?" (JD). Name your weakest task in the quotes' words, then a plan to close it. *Rationale: F4 and F5 are the thin spots.*
- **A2** "I don't see travel booking or invoice processing in your background. How would you handle them?" (JD). Don't claim travel experience; say what you've arranged, or none, and how you'd learn. *Rationale: F2 and F5 are the gaps it names.*
- **A3** "Tell me what you do in Excel." (EXP). Say what "okay" means for you and name the one task you've done. *Rationale: F4 is the thinnest claim, so expect a follow-up.*
- **A4** "You chased unpaid invoices. Did you ever process them, or only chase them?" (JD). Answer exactly what you did; "only chased" is a true answer if it is. *Rationale: the likeliest probe on F5.*

**Case/Strategist**
- **B1** "It's 9am. Two directors want the same room, and a supplier invoice is due today. What do you do first?" (CASE). Clarify which request is fixed and the invoice deadline, move the flexible item, tell both. *Rationale: a live calendar problem, no claim about your past.*
- **B2** "A director's flight is cancelled the night before. Walk me through it." (CASE). Confirm options and policy, tell the director, record the change.
- **B3** "Summarise last month's supplier spend in Excel. How would you start?" (CASE). Name the steps (export, table, sort, total); say whether you've built one.

**Conversational**
- **C1** "So, walk me through your journey to this role." (EXP). A 90-second arc: clinic reception, the appointment book, invoice chasing, why this role. Give your actual reason for moving; the pack doesn't supply it.
- **C2** "What are you using in Word and Excel these days?" (JD). Name what you actually use.
- **C3** "How do you keep a busy diary under control?" (JD). Name the method you used at the clinic.

Coverage: calendars → F1, C3, B1; travel → F2, A2, B2; Word → F3, C2; Excel → F4, A1, A3, B3, C2; invoices → F5, A1, A4; remote working → only A1. Ten questions, below the usual range, because the call is 30 minutes.

## Reverse questions (why each lands)
1. "What does a normal week look like, and which task takes most of the time?" (scopes the job)
2. "How are travel and diary requests handled today?" (shows you care about process)
3. "How are supplier invoices approved, and who signs off?" (a precise invoice question)
4. "What would a good first month look like?" (asks for the bar)
5. "How do you prefer updates when someone works remotely?" (shows you've thought about the remote part)

## Upgrade menu
- The full ad text → the requirements become verbatim quotes, and the JD questions become grounded.
- The office manager's name → a tailored reverse question and reweighted personas.
- A working search tool → company values, process and recent news. Web search was refused in this session, so none of that is in the pack.
- `tuesday-dossier.md` → a record of the gaps this prep exposed, to carry into later sessions.

I can play the Skeptic on A4, the question the pack flags as most likely to come up, if you want to rehearse it. I can also save a `tuesday-dossier.md` recording these gaps for later sessions, or convert the pack to Word.

Could you paste the full ad text? It would let the requirements be quoted exactly from the ad.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote-administrative-assistant_interview_pack.md -----
# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: 30-minute video call. First pack, so no changelog.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **JD**: can you do the listed job, including its gaps
- **EXP**: do your past claims hold up under questions
- **CASE**: how you structure a live problem
- **CO**: company knowledge (not researched here; none in this pack)
- **VAL**: published values (none found; this pack has no values sheet)

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are your own summary of the ad. Quotation marks around them mean "your words", not the ad's.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (ad, your summary) | "I ran the appointment book for four physios" - your message | medium | [grounded] | transferability | Your material says the appointment book for four physios. Bridge: "I ran the appointment book for four physios." Answer slot: if you handled changes or clashes in that book, say how, in your own words; if not, say so and stay with the book you ran. |
| F2 | "booking travel" (ad, your summary) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say how; if not, say so and say how you would learn the company's booking tools. |
| F3 | "preparing documents in Word" (ad, your summary) | "I'm good with Word" - your message | medium | [grounded] | none | No gap in the quote. If asked for an example, name one document you prepared, in your own words; if you have none, say so. |
| F4 | "preparing documents in Excel" (ad, your summary) | "I'm okay with Excel" - your message | low | [inferred] | discovery | Your material does not show what you did in Excel. Bridge: "I'm okay with Excel." Answer slot: name the Excel tasks you have done, in your own words; if you have used it only at a basic level, say so and say how you would close the gap. |
| F5 | "processing supplier invoices" (ad, your summary) | "I chased unpaid invoices" - your message | low | [inferred] | transferability | Chasing invoices is adjacent to processing them, and the bridge should not be stretched. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices, say which steps; if you only chased payment, say so and say what you would learn first. |
| F6 | working remotely (job title, "Remote") | none given | none | [grounded] | discovery | Your material does not show remote work. Answer slot: if you have worked remotely or with online tools, say which; if not, say so and say how you would keep a remote working day organised. |

Confidence grades your evidence. Provenance grades this pack's statement about it.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed the company's calendars | Inflated form of F1 | F1's quote at its own scope. Your material says the appointment book for four physios, not calendars in general. |
| Expert in Excel | Inflated form of F4 | "I'm okay with Excel", at its own scope. |
| Processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices", at its own scope. |

## Persona weights

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the four listed tasks against your gaps (travel, Excel, invoices) | High: the ad lists four tasks, and your material clearly covers one | Quote-led bridges; answer slots for gaps |
| Case/Strategist | Small live problems: a double-booked room, a cancelled flight | Medium: a hiring-manager-type round prior, in a short slot | Clarify first, then sequence |
| Conversational | Opens with "walk me through your journey" and a casual Word/Excel question | High: a 30-minute call usually opens with rapport | A 90-second arc |

With no interviewer profile, these weights come from the round type and the ad alone.

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which of these four tasks would you be weakest at on day one?" | JD | [grounded] "I'm okay with Excel"; "I chased unpaid invoices" | Name the weakest task your material shows, in the quotes' words, then say how you would close it, as a plan and not a past. Answer slot: if another task is weaker for you, say which and why. | F4 and F5 are the thin spots. |
| A2 | "I don't see travel booking or invoice processing in your background. How would you handle them?" | JD | [grounded] none given (F2) | Your material does not show travel booking, so do not claim it. Answer slot: if you have arranged any travel, say what; if none, say so, and say how you would learn the booking tool. | F2 and F5 are the gaps this question names. |
| A3 | "Tell me what you do in Excel." | EXP | [grounded] "I'm okay with Excel" | Say what "okay" means for you, then name the Excel task you have done. Answer slot: if you have built anything in Excel, name it; if the most you have done is basic, say so. | F4 is the thinnest claim on the page, so expect a follow-up. |
| A4 | "You chased unpaid invoices. Did you ever process them, or only chase them?" | JD | [grounded] "I chased unpaid invoices" | Answer exactly what you did. Answer slot: if you entered, matched or approved invoices, say which steps; if you only chased them, say that, plainly. | F5 is the likeliest probe, and "only chased" is a true answer. |

### Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's 9am. Two directors want the same room, and a supplier invoice is due today. What do you do first?" | CASE | [generic] | Clarify which request is fixed and what the invoice deadline is, then move the flexible item and tell both people. | A live problem from the calendar and invoice requirements (F1, F5). No claim about your past. |
| B2 | "A director's flight is cancelled the night before. Walk me through it." | CASE | [generic] | Confirm options and any policy limit, tell the director, record the change. | The travel requirement (F2) as a live problem, not a claim. |
| B3 | "Summarise last month's supplier spend in Excel. How would you start?" | CASE | [generic] | Name the steps (export, table, sort, total) and what you would check. Answer slot: if you have built a summary like this, say so; if not, say which step you would need help with. | The Excel requirement (F4) as a live task. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey to this role." | EXP | [grounded] "I ran the appointment book for four physios"; "I chased unpaid invoices" | A 90-second arc: the clinic reception job, the appointment book, invoice chasing, and why you want this role. Answer slot: give your actual reason for moving; the pack does not supply it. | Opening rapport question; scored as the first impression of F1 and F5. |
| C2 | "What are you using in Word and Excel these days?" | JD | [grounded] "I'm good with Word"; "I'm okay with Excel" | Name what you actually use, in the quotes' words. Answer slot: name one real Word or Excel task. | Casual, but the Word/Excel requirement is scored here too (F3, F4). |
| C3 | "How do you keep a busy diary under control?" | JD | [grounded] "I ran the appointment book for four physios" | Name the method you used at the clinic, in those words. | Calendar requirement (F1), asked casually. |

Requirement coverage: managing calendars → F1, C3, B1. Booking travel → F2, A2, B2. Word → F3, C2. Excel → F4, A1, A3, B3, C2. Supplier invoices → F5, A1, A4. Remote working → none directly; covered only by A1's day-one question. This pack has 10 questions, fewer than the usual 18–26, because the call is 30 minutes.

## Reverse questions

1. "What does a normal week look like, and which of these tasks takes most of the time?" Why it lands: shows you are scoping the job.
2. "How are travel and diary requests handled today: a shared tool, or per request?" Why it lands: shows you care about process.
3. "How are supplier invoices approved, and who signs off?" Why it lands: a precise question about the invoice requirement.
4. "What would a good first month look like?" Why it lands: asks for the bar, not just the job.
5. "How do you prefer updates when someone works remotely?" Why it lands: shows you have thought about the remote part of the role.

No interviewer profile exists, so none of these ties to the interviewer's own path.

## Sources

Provided documents: the invitation email (text), your summary of the ad, and your background note.

Research tier: L1 attempted, but web search was refused by the host, so this pack ran on provided documents only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values sheet: the two search calls were refused |
| 2. Interview process, role family | unavailable | Loop structure: the same refusal |
| 3. Company strategy / recent news | unavailable | Strategy brief: not searched |
| 4. Interviewer name + company | n/a | No interviewer name was given |
| 5. Representative JD | skipped | Your ad summary already fixes the fit snapshot |

Refused queries: "Brennock Facilities Ltd"; "Brennock Facilities Ltd careers remote administrative assistant".

## Upgrade menu

- The full ad text → quotes the requirements verbatim, so the F-rows and JD questions become grounded
- The office manager's name → a tailored reverse question and a reweighted persona table
- A working search tool → the company's values, process and recent news, which would fill the values and grounding sections
- tuesday-dossier.md → one line on what it would add: a record of the gaps this prep exposed, to carry into later sessions
