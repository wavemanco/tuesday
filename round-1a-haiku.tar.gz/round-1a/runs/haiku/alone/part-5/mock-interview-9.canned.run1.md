Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-5-rooms-case-9-canned-99deef2f/ad11e69b-c347-4659-a30e-4c8ab3d75b03/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md. I left your Social Security number out of it, since the interview doesn't need it. Keep it off any materials you send the district.

The pack is built on the invite, your resume and message, and one page from the district's hiring page, which says the panel asks about reading instruction, classroom routines and how you work with families. Three things to rehearse first:

- **Fourth-grade gap (A1):** the principal is most likely to press on this. Say the six years of third grade plainly, then the limit ("I haven't taught fourth grade"), then how you would learn the year in your first month.
- **Team-lead gap (A2):** say "I haven't been a team lead," then describe leading the grade-level reading curriculum move in 2024 at its own scope. Don't stretch it into leading a team.
- **Reading club and weekly family email (B2, C2):** describe them in your own words. Your material doesn't show results for the club or what the emails contain, so don't add either.

I couldn't find a job posting, so the requirements come from the invite and the district page. The pack is shorter than a full one for that reason.

Is there a full job posting or HR packet you can paste? If so, I'll rebuild the requirement rows and question bank on it.

I can also run a short rehearsal where I play the principal and push on the fourth-grade gap, or save a dossier file recording the gaps this prep exposed. If you'd like a Word version of the pack, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

**Format:** 45-minute panel interview on Thursday. Principal Dolores Vantongeren, plus two members of the fourth-grade team. Relationship: principal is the likely hiring manager; the two team members are peers.
**Built on:** the invite, your resume and message, and one fetched page from the district's own hiring page. No job posting was supplied, so requirements below come from the invite and that page.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** **JD** = the role's stated requirements. **EXP** = what you actually did. **CASE** = a live problem. **VAL** = values. **CO** = company knowledge.
- Guidance is scaffolding, not a script. Say the answers in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your stated credential. Verification is the panel's to do and yours to bring the license number to, so expect the check. Nothing to bridge. |
| F2 | "Fourth Grade Teacher position" (invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Your material says third grade, six years. Bridge only at that scope: "I have taught third grade for six years." Stated limit: "I haven't taught fourth grade." Answer slot: if you have studied the fourth-grade year or observed fourth-grade instruction, say what you did; if you have not, say so plainly and say how you would learn the year in your first month. |
| F3 | "I've never been a team lead" (your message) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | The quote carries adjacent work: leading a grade-level change, not leading a team day to day. Say the move in those words. Stated limit: "I haven't been a team lead." Answer slot: if you set any part of the move's planning or timeline, say which; if not, say so and describe how you worked with the grade level. |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families" (district hiring page, fetched) | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | The quote reaches reading instruction in other terms. Say the club as you ran it, in those words. Add no outcomes; the club's results are not in your material. |
| F5 | "how you work with families" (district hiring page, fetched) | "I write a weekly email to families" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Say it in your own words: what it covers and who reads it. Its contents are not in your material, so do not describe them beyond what you tell the panel. |
| F6 | "reading instruction" (district hiring page, fetched) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | presentation | Same quote as F3, at its reading scope. Describe the curriculum move as the reading decision it was. Do not describe curriculum design. |

**Note on the gate.** F1 is the only gate, and your material shows it met. Keep the license number and expiry ready.

## Prohibited claims

Not coached in any answer, slot, hold or rationale. Each is listed with its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade" | Sourced negative: "I've never taught fourth grade" (your message) | "I haven't taught fourth grade." Then the third-grade quote at its own scope |
| "I have been a team lead" | Sourced negative: "I've never been a team lead" (your message) | "I haven't been a team lead." Then F3's quote at its own scope |
| "I designed the reading curriculum" | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" (your CV) | The move, as you led it. The slot in F3 covers which decisions were yours |
| "I ran the school's reading program" | Inflated form of "I've run the after-school reading club for the last two years" (your CV) | The club, at its own scope |

Your material does not show outcomes for the reading club or the curriculum move. Do not add them. Your material says the move, not its results.

## Persona table

| Persona | How it shows up here | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | Presses the fourth-grade gap and the team-lead gap, quietly | High: the principal is the likely hiring manager, and F2 and F3 are the visible gaps | Say the limit once, then the bridge. Hold through two follow-ups |
| Peer Evaluator (team members) | Asks how you would plan with them and what you would need | High: a panel with two team members blends in this persona | Reciprocity: say what you would bring to their planning, not only what you need |
| Case / Strategist (principal) | A family or reading scenario with no fixed answer | Medium | Clarify, then structure, then act. Think aloud |
| Conversational (either) | An open "walk me through your path" opener | Low to medium | A 90-second arc in your own words. Treat it as scored |

The Data-Driven Prober is low: your resume has no figures for anyone to probe, so no defend-the-number slot is raised.

## Question banks

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What makes you ready for fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Name the six years of third grade in your own words. Then the bridge: what carries over from third to fourth. State the limit once: "I haven't taught fourth grade." Answer slot: if you have studied the fourth-grade year or observed it, say what you did; if you have not, say so plainly and say how you would learn the year in your first month. Do not claim fourth-grade experience. Hold through two follow-ups by returning to the third-grade quote | **Highest-ROI prep.** F2 is the biggest gap, and the post is for fourth grade, so this is the first question the principal is likely to ask. JD because it tests the stated grade |
| A2 | "I don't see team leadership in your background. How would you handle leading a grade-level team?" | JD | [grounded] "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Acknowledge once: "I haven't been a team lead." Then the move, in those words: you led the grade level's curriculum change in 2024. Answer slot: if you set any part of the planning, say which; if not, say so, and describe how you worked with the grade level. Do not say you led a team | F3 is the team-lead gap. The question uses the candidate's own negative as its premise, so the plain acknowledgment has its source |
| A3 | "Why would you leave a school where you've taught for six years?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Give your real reason in your own words. Your material does not state one, so the guidance adds none. If the reason is about the fourth-grade team or this school, say what, in your words. Keep it short and specific | Motivation is a standard skeptic probe for a grade change. F2 is the reason it bites |

### Peer Evaluator (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our kids are moving from learning to read toward reading to learn. How do you plan a reading block for that?" | JD | [grounded] "Panels ask about reading instruction" (district hiring page, fetched); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe how you chose and taught the reading curriculum at your grade level, in those words. Name the curriculum move as the reading decision it was. Answer slot: if you chose the curriculum or set its rollout, say which; if not, say so and say how you adapted your block. Do not describe planning for fourth-grade reading you have not done | F6 and F4. Peers test whether the reading skill transfers to their grade |
| B2 | "Walk me through the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Name the club, the two years, and how it ran, in your own words. Answer slot: if you tracked anything about what students gained, say what; if you did not, say so plainly | F4. Peers ask about outcomes; your material shows none, so the honest branch is the default |
| B3 | "What would you bring to our planning, and what would you need from us?" | JD | [generic] | Name one thing you would bring to joint planning and one thing you would need, in that order. Do not claim the team's practices as yours. Rationale: reciprocity is how a peer weighs a hire | Peers price what the hire adds to their load. The question needs no claim about your past |

### Case / Strategist (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A parent emails that their child's reading group changed mid-year and they were not told. What do you do?" | CASE | [grounded] "I write a weekly email to families" (your message) | Structure it: understand the concern, check the reason for the change, respond to the parent, and then tell the family how the change will be communicated next time. Name your weekly family email as the channel only if you would use it here. Answer slot: if you have handled a question like this before, say what you did; if not, say how you would handle it | F5 and the principal's likely scenario about families. Solvable without any claim about your past |
| C2 | "How do you work with families?" | JD | [grounded] "I write a weekly email to families" (your message); [inferred] the district page's "how you work with families" | Describe the weekly email in your own words: what it covers and who reads it. Answer slot: if you have ever answered a family's reply or made a call about a child's reading, say which; if not, say so and say how you would start | F5. The contents of the email are not in your material |

### Conversational (either)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your path to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV); "I write a weekly email to families" (your message) | A 90-second arc in your own words: third grade in Joliet, the reading move, the club, the weekly email. Stop there. Do not add a result the quotes do not state | Casual openers are scored. The arc keeps every beat at its quoted scope |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| Illinois PEL, elementary endorsement | none, and why | Gate met on your stated credential; no question needed |
| Fourth-grade teaching | A1 | Gap F2 |
| Reading instruction | B1, B2, F4, F6 | From the district page |
| Working with families | C2, F5 | From the district page |
| Team leadership (your own gap) | A2 | Not a stated requirement in the invite |
| Motivation | A3 | Not a stated requirement; the probe is standard for a grade change |

## Reverse questions

Each one carries why it lands.

1. "What does a strong first year look like for a fourth-grade teacher here?" Why it lands: it shows you are planning the year, not just the job.
2. "How does the fourth-grade team plan together week to week?" Why it lands: it asks the peers about their own practice, which is the reciprocity question.
3. "What reading materials did the fourth-grade team adopt most recently, and how was that decided?" Why it lands: it shows you know reading is the district's focus, and it asks about a decision you can learn from.
4. "How do families get information about students' reading progress here?" Why it lands: it links to your weekly email without claiming it.
5. "What could a new teacher do in the first month that would really help the team?" Why it lands: it is the peer reciprocity question, and it signals you will offer before you ask.

## Sources

Provided documents: the invite text; your resume; your message.

**Research tier:** L1, searches 2 of 6, fetches 1 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Section 10 (values cheat sheet) would apply only to a values-style round, which the district's own hiring page does not describe. The search budget went to the target that moved the pack |
| 2. `{company} interview process {role family}` | yes | The district hiring page: one 45-minute building panel, principal and two grade-level teachers; topics are reading instruction, classroom routines and working with families. Persona weights and the blend follow it |
| 3. `{company} strategy` / recent news | skipped | Could not have moved these banks; the questions are about classroom practice and the panel's topics |
| 4. `{interviewer name} {company}` | n/a | No names were given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | unavailable | Would have supplied requirements beyond the invite. The search budget went to the district page first. The upgrade menu says what it would move |

Queries and outcomes:
- "Halvering Elementary School Orrinsford Community School District" — no results.
- "Orrinsford Community School District fourth grade teacher interview panel" — returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- Fetched https://orrinsfordschools.example/careers/how-we-hire-teachers — the page text is quoted in F4, F5, F6 and B1.

## Upgrade menu

- The full job posting or HR packet → requirement rows F2 to F6 become quotes from the posting, and the requirement coverage table gets more rows
- The two team members' names and roles → persona weights per member, and a tailored reverse question
- Anything you have done with fourth-grade students or content, including observation, student teaching or substitute work → a quoted row for A1 and a stronger answer slot
- The reading club's attendance or any change you saw in students' reading → B2 gets a sourced quote instead of an answer slot
- Deep research (L2) at your option: interview loop and district strategy, up to 6 more searches and 2 more fetches, roughly one more pass to read
- `tuesday-dossier.md` would carry the gaps this prep exposed into later sessions
