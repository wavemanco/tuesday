I can't build the prep pack yet. The skill needs the company name and the role title, and this message gives neither. I also need to flag something first.

**This has several hallmarks of a recruitment scam, so please verify before you invest time or share anything:**

- Contact out of the blue from an unknown number, saying they "found your profile"
- No employer named, and a vague "remote position with flexible hours"
- An interview the next day
- The whole process over WhatsApp, with no calls or video, all the way through to the contract

A genuine recruiter can normally name the employer and will agree to a video call. Whatever happens, don't send ID, bank or tax details before an offer, and never pay a fee, buy equipment, or deposit a cheque. Scams like this often ask for one of these.

**Ways to check before 11am:**

1. Ask "Jess" for the company name, the job title, the job reference, and the agency's name and registration.
2. Find the job on the company's own careers page, typed in from a search, not via a link they send. Also check the company's main phone number from its official website.
3. Ask for a video call. Be cautious if they refuse.
4. If you can't confirm the role, you can decline or simply not reply. Check whether you actually applied for it: look for the confirmation email or the job board's application history.

If you can verify it, tell me:

1. **The company and the role title** (required to build the pack).
2. **The job description**, if you have it. If not, I can build the pack from a representative description for that title and label it as inferred.
3. **Your CV or a short background summary**, so the answers reflect your real experience.

Once I have the company and role, I'll build the pack. If it turns out to be a scam, I'll help you report it instead.