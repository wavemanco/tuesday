Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-5-rooms-case-9-canned-c26a1f2f/d3c79a2b-7591-4232-840d-02372f1a105b/scratchpad/Halvering_Elementary_fourth-grade-teacher_interview_pack.md`, and the full pack is below.

I built it on these assumptions: a panel with the principal (hiring-manager prior) and two fourth-grade peers, no posting text, and no web research yet. I also left the Social Security number out of everything, including the pack. Take it off your résumé before you send it anywhere.

# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Organization:** Orrinsford Community School District
**Interviewers:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (not named)
**Format:** 45-minute panel, Thursday
**Round type and relationship:** panel. The principal is a hiring-manager relationship; the two team members are peers.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores:

- **VAL**: values fit. None detected for this role, so no VAL questions.
- **EXP**: what you actually did.
- **JD**: the requirements in the invite.
- **CO**: company knowledge. None, because no research has run yet.
- **CASE**: a live problem from the job.

Guidance is scaffolding, not a script. Say it in your own words, and say only the parts that are yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your CV. Say it in one line: you hold the PEL with the elementary endorsement, grades 1–6, active through June 30, 2029. Have the license record with you in case the panel asks to see it. |
| F2 | "Fourth Grade Teacher position" (invite); [generic] classroom teaching at fourth-grade level | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Words: "I've taught third grade for six years." Then, plainly: "I haven't taught fourth grade." Any claim about how third-grade work carries over is an answer slot in A2, not a bridge. |
| F3 | [generic] leading a grade-level team (role pattern; not stated in the invite) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." The closure path is a plan for the future, never a past claim. |
| F4 | [generic] reading instruction and curriculum work (role pattern) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Your material shows the move and the club. It does not show what either changed for students. Any result you name has to be one you hold. |
| F5 | [generic] communication with families (role pattern) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Say it as it stands: you write a weekly email to families. |
| F6 | [generic] collaborative work on a grade-level team (role pattern) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | low | [grounded] | discovery | Your material does not show whether you worked through the team on that move. Answer slot: if you can say how you worked with colleagues on it, say what you did in your own words. If you did not work through the team, say so and say how you would approach shared planning. |

## Prohibited claims

These are not coached in any answer, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Your own negative, "I've never taught fourth grade" (your message) | "I've taught third grade for six years. I haven't taught fourth grade." |
| Has led a team, or led the fourth-grade team | Your own negative, "I've never been a team lead" (your message). Also an inflated form of "I led our grade level's move to a new reading curriculum in 2024" (your CV) | "I led our grade level's move to a new reading curriculum in 2024. I haven't been a team lead." |
| The reading curriculum raised students' reading results | Inflated form of F4. No result appears in any of your sentences. | The move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Limit, in the pack's analysis: your material says the move, not any result. |
| Any figure for the club's size or the move's results | No figure appears in your material. | Give a figure only if you hold it. If you do not, say you do not have it. |

## Persona table

The panel has no per-member names, so personas are blended. The principal gets the hiring-manager priors (Skeptic and Case); the two team members get the peer priors (Peer Evaluator and Prober).

| Persona | Weight | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | 5 | The principal is the hiring-manager prior. The two gaps in the fit snapshot, no fourth-grade teaching and no team lead, are what this persona will test. | Rehearse A3 until it is plain. Name the gap first, then hold your third-grade record. |
| Peer Evaluator | 4 | Two peers on the fourth-grade team. They will test whether you fit a shared team. | Answer from practice, and say what you would need from colleagues. |
| Data-Driven Prober | 3 | Peers on a team that teaches reading will likely ask about the 2024 curriculum move, the only reading work your CV describes. | Say what you tracked. If you tracked nothing, say that. Name what you would track next. |
| Case / Strategist | 3 | The principal is likely to set a live classroom problem. | Clarify first, then structure. Make no claim about a past student. |
| Pressure / Stress | 2 | Not a relationship prior for this panel. Included because a 45-minute panel can turn sharp. | Pause, restate, hold one position through two follow-ups, then concede the specific gap. |
| Conversational / Rapport | 2 | A panel usually opens with small talk. Casual questions are still scored. | Keep a 90-second arc ready. |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Do you hold a valid Illinois Professional Educator License with an elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | "Yes." Then one line in these words: the PEL, the elementary endorsement, grades 1–6, active through June 30, 2029. | The invite's gate, met on your CV (F1). One line is enough. |
| A2 | "You've taught third grade for six years. What would carry over to fourth grade, and what wouldn't?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Say the six years in third grade. Then name the carry-over only as far as you can. Answer slot: name one fourth-grade expectation your third-grade work already prepares students for, if you know one. If you do not, say so and say how you would learn the fourth-grade expectations before the first day. Never describe fourth-grade teaching you have not done. | F2 is the transferability gap. The question concerns the position, which the invite raises, and presupposes no fourth-grade work you did. |
| A3 | "You haven't taught fourth grade and you haven't been a team lead. Why should we pick you over someone who has?" | JD | [grounded] "I've never taught fourth grade" (your message); "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | **Highest-ROI prep in this pack.** Name the two gaps yourself, in these words: "I haven't taught fourth grade. I haven't been a team lead." Then your case from what you have: six years in third grade, and the 2024 move at its own scope. Hold through two follow-ups by returning to the third-grade years and the move. If pushed on what you would do, answer with a plan in the future tense. Concede specifically: the team-lead part is a real gap, and say what you would do first. Answer slot: name one thing you would do in your first month to learn fourth-grade content and team work, if you have a plan. If you do not, say so. | F2 and F3 are the gaps this question targets. The second follow-up is where a held position without backing breaks, so the hold stays inside what you have said. |
| A4 | "What draws you to this fourth-grade position?" | JD | [generic] | Give your own reason in your own words. The material gives none, so there is no sentence to build on. Pick a true reason from your experience, say it plainly, and say how fourth grade fits it. If you are not yet sure, say that. | Motivation consistency for the Skeptic. Generic because the material is silent on your reasons. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On a grade-level team, tell me about a time you disagreed with a colleague over how to teach something. What did you do?" | EXP | [generic] | Choose one real disagreement: what you and the colleague wanted, what you did, and how it ended. If none comes to mind, say so plainly, then describe how you would handle a disagreement with a grade-level colleague. Do not borrow the 2024 move as the disagreement unless it was one. | F6 is a discovery gap. The open prompt's theme is the peer persona's seam, not a fact about you. |
| B2 | "You write a weekly email to families. How do you decide what goes in it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Say what goes in it and how you choose, in your own words. Give one example of a week's content if you have one. Do not describe how families responded unless you know. | F5. Peers probe communication scope, so the guidance stays with what you do. |
| B3 | "Tell me about the after-school reading club you've run." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe what the club does and how you have run it for two years, in your own words. If a detail comes up, such as size or what children read, give what you know and say what you do not. | F4. Peers will probe for impact. The guidance supplies no figure. |
| B4 | "What would you bring to shared planning on a grade-level team, and what would you need from colleagues?" | JD | [generic] | Name what you bring from your reading and family work, in your own words. Then name what you would need from colleagues. Do not claim shared-planning experience, since the material shows none. | The peer-side team-fit question. Generic because the material says nothing about shared planning. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 2024 reading curriculum move. How did you decide it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what the move involved, in your own words and at the scope the sentence gives. Answer slot: if you tracked anything to judge the move, name what you tracked and who else saw it. If you tracked nothing, say so plainly and say what you would track next time. Do not name a result. | F4. The question presupposes an evaluation your material does not show, so the guidance is a slot whose second branch allows that none happened. |
| C2 | "Which reading measures do teachers at this level typically use, and which have you used?" | JD | [generic] | Name the measures you have used and what each told you. If you have not used one, say so and say how you would learn it. | The fourth-grade reading question. Generic on the measures; your own use is the only claim. |
| C3 | "Of the 2024 move, which decisions were yours, and which were the team's?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Split it honestly: name the decisions you made, and those the team or the school made. Use "I led" only for what you led. Answer slot: if you set any part of the move's steps, say which. If the decisions were not yours, say so plainly and describe the part you ran. | The attribution probe. The sentence's scope limits what you can claim. |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A student in your class is reading well below grade level three weeks into the year. What's your first move?" | CASE | [generic] | Clarify first: what you know about the student's reading, what you would check, and who you would contact, such as the family or a specialist. Then structure: the next two weeks, what you would try, and how you would know it worked. Make no claim about a past student. | A live classroom problem. It asks about no past, so the guidance makes no claim about you. |
| D2 | "A family disagrees with a grade-level decision you're part of. What do you do?" | CASE | [generic] | Clarify the decision and the family's concern. Meet with the family, bring the team's view before your own, and follow up. Keep the grade-level decision standing unless the team changes it. | Family communication under a shared decision. Generic. |
| D3 | "The team wants to change how it sends family updates. How would you approach that?" | CASE | [generic] | Clarify what is changing and why. Check what families currently receive. Propose a trial and agree with the team what it would review. Say what you would not change without the team. | A live team problem. Generic. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Six years in third grade is six years of one grade. Why do you think you're ready to switch?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Pause and restate the question. Hold: the six years are real, and third-grade work is what you can point to. Hold through two follow-ups on what you did, not on what you will become. Concede plainly when pushed: you have not taught fourth grade, and say what you would do to close that. Do not fold on the six years. | Hold-then-concede. The held position is the six years, which your CV carries. |
| E2 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Sixty seconds, three beats: the six years in third grade, the 2024 move at its scope, and what you would do first to learn fourth grade. Say it once, without filler. Do not present the other candidate's experience as a weakness. | A timed pressure question. Each beat is a quoted sentence or a plan. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc: how you started teaching, the six years in third grade, the reading work since, and why fourth grade now. Use only the quoted sentences, at their scope. | A casual opener that is still scored. |
| G2 | "What do you enjoy most about teaching?" | EXP | [generic] | Give one true answer in one concrete sentence drawn from your own practice. Do not make it a slogan. | Rapport, scored for communication economy. Generic. |

Session total: 18 questions across six personas.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | A1 |
| Fourth Grade Teacher position (invite) | A2, A3, A4 |
| Leading a grade-level team ([generic]) | A3, B1 |
| Collaborative work on a grade-level team ([generic]) | B1, B4 |
| Family communication ([generic]) | B2, D2, D3 |
| Reading instruction ([generic]) | B3, C1, C2, C3 |
| Classroom problems ([generic]) | D1 |

## Reverse questions

1. **"What does the fourth-grade team already do well that a new teacher should learn first?"** Lands because it asks about the team's practice, not the job description.
2. **"How does the team organize family communication? Is there a shared pattern?"** Lands because family communication is part of your record, so the answer shows whether your experience fits the team.
3. **"What would a new team member do in the first month that would most help the team?"** Reciprocity for the peers. It shows you are asking what you can bring.
4. **"Where is the team's reading approach under review right now?"** Lands because you have led one curriculum move. It asks where the team is going, not where it has been.
5. **"What does a successful first year look like for this role?"** Lands with the principal. It asks for the standard the panel will score against.

## Sources

- **Provided documents:** the invite (quoted in the fit snapshot), your résumé, and your message.
- **Searches and fetches this turn:** none.

**Research tier: L0.** No searches or fetches have run, and research consent is still open.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering values | unavailable | Values cheat sheet. Not included: no values round is detected, and no research has run. |
| 2. Orrinsford / Halvering interview process | unavailable | Loop structure and persona weights, currently blended. |
| 3. Recent district strategy or news | unavailable | CO questions. None in the pack. |
| 4. Dolores Vantongeren public footprint | unavailable | Interviewer read and a tailored reverse question. |
| 5. Representative fourth-grade posting | unavailable | JD-tagged questions and requirement rows beyond the invite's two. |

## Upgrade menu

- The posting text → turns the invite-based rows into grounded requirement rows, and tests A2 against the posting's own words.
- The two team members' names → per-member persona weights.
- Any focus areas, demo lesson or sample task from HR → a graded-deliverable section.
- Research consent (about six searches) → the district's values and interview process, for a values cheat sheet and sharper persona weights.
- The principal's public footprint, if research runs → an interviewer read and a reverse question tied to her career path.
- Your license record (the PEL copy or the state lookup) → F1 becomes checkable, so you can state it as verified.
- A `tuesday-dossier.md`, if you have one → verified evidence and allowed strategies for the gap rows.

---

**Drill offer:** I can play the Skeptic on A3, the question the pack names as the highest-return prep, and give feedback afterward.
**Dossier offer:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

1. Did HR share focus areas, a demo lesson, or a sample task for Thursday?
2. Can you paste the posting text? If not, I'll keep working from the invite.
3. Should I run web research on Halvering and Orrinsford (about six searches) to add the district's values and interview process? Yes or no.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Organization:** Orrinsford Community School District
**Interviewers:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (not named)
**Format:** 45-minute panel, Thursday
**Round type and relationship:** panel. The principal is a hiring-manager relationship; the two team members are peers.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores:

- **VAL**: values fit. None detected for this role, so no VAL questions.
- **EXP**: what you actually did.
- **JD**: the requirements in the invite.
- **CO**: company knowledge. None, because no research has run yet.
- **CASE**: a live problem from the job.

Guidance is scaffolding, not a script. Say it in your own words, and say only the parts that are yours.

## Fit snapshot

Requirements come from the invite, quoted. Evidence is quoted from your CV or your message. Where the material is silent, the row says so.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Met on your CV. Say it in one line: you hold the PEL with the elementary endorsement, grades 1–6, active through June 30, 2029. Your material is your own statement, so have the license record with you in case the panel asks to see it. |
| F2 | "Fourth Grade Teacher position" (invite); [generic] classroom teaching at fourth-grade level | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Words: "I've taught third grade for six years." Then, plainly: "I haven't taught fourth grade." Any claim about how third-grade work carries over is an answer slot in A2, not a bridge. |
| F3 | [generic] leading a grade-level team (role pattern; not stated in the invite) | "I've never been a team lead" (your message) | none | [grounded] | capability | Words: "I haven't been a team lead." The closure path is a plan for the future, never a past claim. |
| F4 | [generic] reading instruction and curriculum work (role pattern) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Your material shows the move and the club. It does not show what either changed for students. The pack has no result to give you, and any result you name has to be one you hold. |
| F5 | [generic] communication with families (role pattern) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Say it as it stands: you write a weekly email to families. |
| F6 | [generic] collaborative work on a grade-level team (role pattern) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | low | [grounded] | discovery | Your material does not show whether you worked through the team on that move. Answer slot: if you can say how you worked with colleagues on it, say what you did in your own words. If you did not work through the team, say so and say how you would approach shared planning. |

Gap type is one token per row. Confidence is what your evidence supports. Provenance is how this pack labels its own statement about you.

## Prohibited claims

These are not coached in any answer, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Your own negative, "I've never taught fourth grade" (your message) | "I've taught third grade for six years. I haven't taught fourth grade." |
| Has led a team, or led the fourth-grade team | Your own negative, "I've never been a team lead" (your message). Also an inflated form of "I led our grade level's move to a new reading curriculum in 2024" (your CV) | "I led our grade level's move to a new reading curriculum in 2024. I haven't been a team lead." |
| The reading curriculum raised students' reading results | Inflated form of F4. No result appears in any of your sentences. | The move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Limit, in the pack's analysis: your material says the move, not any result. |
| Any figure for the club's size or the move's results | No figure appears in your material. | Give a figure only if you hold it. If you do not, say you do not have it. |

## Persona table

The panel has no per-member names, so personas are blended. Weights follow the relationship priors: the principal as hiring manager (Skeptic and Case), the two team members as peers (Peer Evaluator and Prober).

| Persona | Weight | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | 5 | The principal is the hiring-manager prior. The two gaps in the fit snapshot, no fourth-grade teaching and no team lead, are the material this persona will test. | Rehearse A3 until it is plain. Name the gap first, then hold your third-grade record. |
| Peer Evaluator | 4 | Two peers on the fourth-grade team. They will test whether you fit a shared team. | Answer from practice, and say what you would need from colleagues. |
| Data-Driven Prober | 3 | Peers on a team that teaches reading will ask about the 2024 curriculum move, which is the only reading result your CV names. | Say what you tracked. If you tracked nothing, say that. Name what you would track next. |
| Case / Strategist | 3 | The principal is likely to set a live classroom problem. | Clarify first, then structure. Make no claim about a past student. |
| Pressure / Stress | 2 | Not a relationship prior for this panel. Included because a 45-minute panel can turn sharp. | Pause, restate, hold one position through two follow-ups, then concede the specific gap. |
| Conversational / Rapport | 2 | A panel usually opens with small talk. Casual questions are still scored. | Keep a 90-second arc ready. |

Depth follows weight: the top persona gets the most questions. Every persona gets at least two questions, so no style meets you for the first time live.

## Question banks

Provenance comes before guidance. The sentences a claim rests on are quoted exactly from the fit snapshot.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Do you hold a valid Illinois Professional Educator License with an elementary endorsement?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | "Yes." Then one line in these words: the PEL, the elementary endorsement, grades 1–6, active through June 30, 2029. | The invite's gate, met on your CV (F1). One line is enough. |
| A2 | "You've taught third grade for six years. What would carry over to fourth grade, and what wouldn't?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Say the six years in third grade. Then name the carry-over only as far as you can. Answer slot: name one fourth-grade expectation your third-grade work already prepares students for, if you know one. If you do not, say so and say how you would learn the fourth-grade expectations before the first day. Never describe fourth-grade teaching you have not done. | F2 is the transferability gap. The question is about the position, which the invite raises, and presupposes nothing about fourth-grade work you did. |
| A3 | "You haven't taught fourth grade and you haven't been a team lead. Why should we pick you over someone who has?" | JD | [grounded] "I've never taught fourth grade" (your message); "I've never been a team lead" (your message); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | **Highest-ROI prep in this pack.** Name the two gaps yourself, in these words: "I haven't taught fourth grade. I haven't been a team lead." Then your case from what you have: six years in third grade, and the 2024 move at its own scope. Hold through two follow-ups by returning to the third-grade years and the move. If pushed on what you would do, answer with a plan in the future tense. Concede specifically: the team-lead part is a real gap, and say what you would do first. Answer slot: name one thing you would do in your first month to learn fourth-grade content and team work, if you have a plan. If you do not, say so. | F2 and F3 are the gaps this question targets. The second follow-up is where a held position without backing breaks, so the hold stays inside what you have said. |
| A4 | "What draws you to this fourth-grade position?" | JD | [generic] | Give your own reason in your own words. The material gives none, so there is no sentence to build on. Pick a true reason from your experience, say it plainly, and say how fourth grade fits it. If you are not yet sure, say that. | Motivation consistency for the Skeptic. Generic because the material is silent on your reasons. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On a grade-level team, tell me about a time you disagreed with a colleague over how to teach something. What did you do?" | EXP | [generic] | Choose one real disagreement: what you and the colleague wanted, what you did, and how it ended. If none comes to mind, say so plainly, then describe how you would handle a disagreement with a grade-level colleague. Do not borrow the 2024 move as the disagreement unless it was one. | F6 is a discovery gap. The open prompt's theme is the peer persona's seam, not a fact about you. |
| B2 | "You write a weekly email to families. How do you decide what goes in it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Say what goes in it and how you choose, in your own words. Give one example of a week's content if you have one. Do not describe how families responded unless you know. | F5. Peers probe communication scope, so the guidance stays with what you do. |
| B3 | "Tell me about the after-school reading club you've run." | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe what the club does and how you have run it for two years, in your own words. If a detail comes up, such as size or what children read, give what you know and say what you do not. | F4. Peers will probe for impact. The guidance supplies no figure. |
| B4 | "What would you bring to shared planning on a grade-level team, and what would you need from colleagues?" | JD | [generic] | Name what you bring from your reading and family work, in your own words. Then name what you would need from colleagues. Do not claim shared-planning experience, since the material shows none. | The peer-side team-fit question. Generic because the material says nothing about shared planning. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the 2024 reading curriculum move. How did you decide it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Say what the move involved, in your own words and at the scope the sentence gives. Answer slot: if you tracked anything to judge the move, name what you tracked and who else saw it. If you tracked nothing, say so plainly and say what you would track next time. Do not name a result. | F4. The question presupposes an evaluation your material does not show, so the guidance is a slot whose second branch allows that none happened. |
| C2 | "Which reading measures do teachers at this level typically use, and which have you used?" | JD | [generic] | Name the measures you have used and what each told you. If you have not used one, say so and say how you would learn it. | The fourth-grade reading question. Generic on the measures, with your own use as the only claim. |
| C3 | "Of the 2024 move, which decisions were yours, and which were the team's?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Split it honestly: name the decisions you made, and those the team or the school made. Use "I led" only for what you led. Answer slot: if you set any part of the move's steps, say which. If the decisions were not yours, say so plainly and describe the part you ran. | The attribution probe. The sentence's scope limits what you can claim. |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A student in your class is reading well below grade level three weeks into the year. What's your first move?" | CASE | [generic] | Clarify first: what you know about the student's reading, what you would check, and who you would contact, such as the family or a specialist. Then structure: the next two weeks, what you would try, and how you would know it worked. Make no claim about a past student. | A live classroom problem. It asks about no past, so the guidance makes no claim about you. |
| D2 | "A family disagrees with a grade-level decision you're part of. What do you do?" | CASE | [generic] | Clarify the decision and the family's concern. Meet with the family, bring the team's view before your own, and follow up. Keep the grade-level decision standing unless the team changes it. | Family communication under a shared decision. Generic. |
| D3 | "The team wants to change how it sends family updates. How would you approach that?" | CASE | [generic] | Clarify what is changing and why. Check what families currently receive. Propose a trial and agree with the team what it would review. Say what you would not change without the team. | A live team problem. Generic. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Six years in third grade is six years of one grade. Why do you think you're ready to switch?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Pause and restate the question. Hold: the six years are real, and third-grade work is what you can point to. Hold through two follow-ups on what you did, not on what you will become. Concede plainly when pushed: you have not taught fourth grade, and say what you would do to close that. Do not fold on the six years. | Hold-then-concede. The held position is the six years, which your CV carries. |
| E2 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Sixty seconds, three beats: the six years in third grade, the 2024 move at its scope, and what you would do first to learn fourth grade. Say it once, without filler. Do not present the other candidate's experience as a weakness. | A timed pressure question. Each beat is a quoted sentence or a plan. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc: how you started teaching, the six years in third grade, the reading work since, and why fourth grade now. Use only the quoted sentences, at their scope. | A casual opener that is still scored. |
| G2 | "What do you enjoy most about teaching?" | EXP | [generic] | Give one true answer in one concrete sentence drawn from your own practice. Do not make it a slogan. | Rapport, scored for communication economy. Generic. |

Session total: 18 questions across six personas.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | A1 |
| Fourth Grade Teacher position (invite) | A2, A3, A4 |
| Leading a grade-level team ([generic]) | A3, B1 |
| Collaborative work on a grade-level team ([generic]) | B1, B4 |
| Family communication ([generic]) | B2, D2, D3 |
| Reading instruction ([generic]) | B3, C1, C2, C3 |
| Classroom problems ([generic]) | D1 |

## Reverse questions

Each has a reason it lands. The panel includes peers, so a reciprocity question is included.

1. **"What does the fourth-grade team already do well that a new teacher should learn first?"** Lands because it asks about the team's practice, not the job description.
2. **"How does the team organize family communication? Is there a shared pattern?"** Lands because family communication is part of your record, so the answer will tell you whether your experience fits the team.
3. **"What would a new team member do in the first month that would most help the team?"** Reciprocity for the peers. It shows you are asking what you can bring.
4. **"Where is the team's reading approach under review right now?"** Lands because you have led one curriculum move. It asks where the team is going, not where it has been.
5. **"What does a successful first year look like for this role?"** Lands with the principal. It asks for the scoring standard directly.

Reverse questions tied to the interviewer's own career path are not included, because no profile was researched (see Upgrade menu).

## Sources

- **Provided documents:** the invite (quoted in the fit snapshot), your résumé, and your message.
- **Searches and fetches this turn:** none.

**Research tier: L0** (no searches or fetches run; research consent is still open).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering values | unavailable | Values cheat sheet, section 10. Not included: no values round is detected, and no research has run. |
| 2. Orrinsford / Halvering interview process | unavailable | Loop structure and persona weights, which are currently blended. |
| 3. Recent district strategy or news | unavailable | CO questions. None in the pack. |
| 4. Dolores Vantongeren public footprint | unavailable | Interviewer read and a tailored reverse question. |
| 5. Representative fourth-grade posting | unavailable | JD-tagged questions and requirement rows beyond the invite's two. |

## Upgrade menu

- The posting text → converts the invite-based rows into grounded requirement rows, and tests A2 against the posting's own words.
- The two team members' names → per-member persona weights.
- Any focus areas, demo lesson or sample task from HR → a graded-deliverable section.
- Research consent, which runs about six searches → the district's values and interview process, for a values cheat sheet and better persona weights.
- The principal's public footprint, if research runs → an interviewer read and a reverse question tied to her path.
- Your license record (the PEL copy or the state lookup) → F1 becomes checkable, so you can state it as verified.
- A `tuesday-dossier.md`, if you have one → verified evidence and allowed strategies for the gap rows.
