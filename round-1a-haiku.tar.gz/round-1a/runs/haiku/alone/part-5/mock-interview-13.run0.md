Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-5-rooms-case-13-denied-c24cf5f8/e17ee7c3-2ea0-433c-becf-5278c7320cb3/scratchpad/quillmoor_operations_coordinator_interview_pack.md and sent to you. It covers the fit against the advert, 18 questions across four styles of interviewer, the pay, hybrid and reason-for-leaving answers, and questions for Hannah.

I built it from your message alone and did no company research, so the "why Quillmoor" answer is generic for now.

The most important prep is B1: your background is building-supplies wholesale, and the advert asks for production scheduling across planning, the warehouse and QA. Your honest answer is the depot scheduling you already do, plus a plain statement of whatever you haven't done. Don't stretch it into production work.

Other points:
- **SAP:** say "I haven't used SAP" once, then describe how you'd learn it as a plan.
- **The one-third figure:** be ready to say how the discrepancy count was done, and whose part of it was yours.
- **Dispatch reporting and Excel level:** your message doesn't show either. If you have examples, tell me and I'll add them.

Two one-line offers, neither pushed:
- I can run a short drill where I play Hannah and push on the pay and hybrid answers.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Before Thursday, I need one thing: what's your notice period? The pack has no figure for it, so it's the one gap in the notice answer.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics — Operations Coordinator — recruiter screen prep

Recruiter: Hannah Lowther, Talent Partner. Thursday 2pm, 30-minute phone call to your mobile.
Round type: recruiter screen (logistics, motivation, then team and next steps).

## How to use this pack

- **Personas** = how a question is asked. **Types** = what is being scored: VAL (values), EXP (your experience), JD (the advert's requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Aim for 90 to 120 seconds per answer, in your own words.
- Provenance: **[grounded]** = your own sentence, quoted. **[inferred]** = my derivation from it. **[generic]** = no source from you; a pattern only.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (JD) | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots, not production schedules or QA. Words: "I schedule deliveries for our three depots." Answer slot: the JD's planning, warehouse and QA line makes a probe on production timing likely. If you had a say in production or QA timing, say which and how you decided; if not, say so plainly and stay with the depot schedule. |
| F2 | "track supplier deliveries and chase late orders" (JD) | "chase suppliers when orders slip" — your message | medium | [grounded] | presentation | Reword only this: "I chase suppliers when orders slip." No practice added. |
| F3 | "keep stock records accurate" (JD) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | presentation | Words: "I rebuilt our stock-count spreadsheet, and discrepancies fell by about a third over a year." The figure raises the defend-the-number slots in C1. Do not claim sole credit. |
| F4 | "report weekly on on-time dispatch" (JD) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you reported dispatch performance, say how often, what you counted and who saw it; if you did not, say so plainly and say how you would start. |
| F5 | "confident with Excel" (JD) | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The spreadsheet shows Excel use but not your level. Answer slot: name the functions you used, if you can; if you cannot, say so and describe what the spreadsheet did. |
| F6 | "ERP (SAP or similar) a plus" (JD) | "Never used SAP" — your message | none | [grounded] | capability | Words: "I haven't used SAP." Then how you would learn it, said as a plan, never as a past. Your own stock system is "our in-house stock system", in your words. |
| F7 | "2+ years in operations or logistics coordination" (JD) | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | [grounded] | none | No gap. Words: "4 years as a logistics coordinator." |
| F8 | "two days a week at our Avonmouth site in Bristol" (JD) | "two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | No gap. Words as given: two days works; no more than three. |

## Prohibited claims

These are not to be said, even under pressure. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules across planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The material says delivery scheduling across three depots. Slot stays inside the depots. |
| Managed supplier relationships or performance | Inflated form of F2 | "I chase suppliers when orders slip." |
| Cut discrepancies by a third through my changes | Inflated form of F3 (drops "over a year" and turns a fall into your doing) | "discrepancies fell by about a third over a year" at its own scope; C1's slot asks how it was counted and whose part it was. |
| Have used SAP or other ERP systems | Negative you stated (F6) | "I haven't used SAP." No slot. |

## Personas and weights

Recruiter screen prior: conversational, with a light skeptic. Weights shown so you can recalibrate.

| Persona | How it shows up in this call | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Conversational / rapport | Pay, notice, hybrid and reason for leaving asked casually | High. A recruiter screen is mostly logistics, and casual questions are still scored | One 90-second background arc; each logistics answer in one or two sentences | 5 (A) |
| Skeptic | "Why this, why you, why now"; the production and SAP gaps | High. F1 and F6 are the gaps a screen checks | Rehearse B1 until it is plain; concede the gap in one sentence | 5 (B) |
| Data-Driven Prober | The one-third figure; what the dispatch report measured | Medium. A CV figure invites a probe, though screens rarely go deep | Say how it was counted if you know; name the weakest assumption; say when you do not know | 4 (C) |
| Pressure | Pay and the hybrid limit pushed back on | Medium-low. Pay is the likeliest pressure point | Hold the figure through two follow-ups; concede only what is true | 4 (D) |

## Question banks

Session totals: 18 questions. A is top weight with B, since a recruiter screen is mostly logistics and knockouts.

### A — Conversational (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background, and how you got into logistics." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Four years as a logistics coordinator at a building-supplies wholesaler. You schedule deliveries for three depots and chase suppliers when orders slip. You rebuilt the stock-count spreadsheet. Describe what you did, not what it proves. | F7, F2, F3: the opener is a scored first impression. |
| A2 | "What's drawing you to Quillmoor?" | CO | [generic] | Answer from the advert's own words: which part of production, warehouse and QA coordination you want to do. Do not claim knowledge of the company you have not got. | Motivation check. No company research was run, so this stays generic. |
| A3 | "Two days a week at Avonmouth, how does that fit with living in north Bristol?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot: two days a week at Avonmouth works; no more than three. | F8: the hybrid knockout, answered in your terms. |
| A4 | "What's your notice period?" | JD | [generic] | Give your actual notice period in one line. | Logistics slot. Your figure is not in the material, so this is the one question in the message below. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want" | Say the closure plainly in one sentence, say that relocating to Reading does not suit you, then move to what you want. Do not criticise the employer. | Reason-for-leaving logistics slot. The closure is a fact; no need to dress it up. |

### B — Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is building-supplies wholesale. What makes you think you can coordinate production at a diagnostics manufacturer?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "Coordinate production schedules between planning, the warehouse and QA" (JD) | **Highest-ROI prep in this pack.** Lead with the part that carries: scheduling deliveries across three depots and chasing suppliers when orders slip, in your words. Answer slot: if you had a say in production or QA timing, say which and how; if not, say so plainly and return to the depot schedule. Hold through two follow-ups by returning to the depots; concede the production part plainly rather than stretch it. | F1 is the requirement the JD states most directly, so expect this objection in some form. JD because it scores the stated requirement. |
| B2 | "You've never used SAP. How long would it take you to learn it?" | JD | [grounded] "Never used SAP" | "I haven't used SAP." Then how you would learn it, as a plan, not a past. Do not name a timescale you have not tested. | F6, a stated capability gap. Say it once, then move on. |
| B3 | "The advert asks for a weekly on-time dispatch report. Have you produced one?" | JD | [grounded] "report weekly on on-time dispatch" (JD) | Answer slot: if you reported dispatch performance, say how often, what you counted and who saw it; if you did not, say so plainly and say how you would start. | F4, discovery. The answer slot ends the question. |
| B4 | "How would you rate your Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: name the functions you used, if you can. If you cannot, say so and describe what the spreadsheet did. | F5, discovery. The spreadsheet is the only Excel evidence you gave. |
| B5 | "Why this role, rather than another logistics coordinator job in Bristol?" | EXP | [grounded] "our Bristol office is closing next year, and the only offer is relocating to Reading, which I don't want" | Say which part of the advert you want to do: production, warehouse and QA coordination, or weekly dispatch reporting. Do not speak against your current employer. | F8 and the motivation check. Tests whether the reason is consistent across the call. |

### C — Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "discrepancies fell by about a third over a year" | Defend-the-number slot. Say how you counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. | The headline figure. A figure raises only defend-the-number slots. |
| C2 | "What did the count cover, every line or some stock?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: say what the count covered. If you do not know, say so. | Denominator probe on the same figure. |
| C3 | "Walk me through a delivery schedule across your three depots." | JD | [grounded] "I schedule deliveries for our three depots" | Describe the steps in your own words. Stay with the depot schedule. If any step touched production or QA timing, say which. | F1, a method probe. |
| C4 | "How do you decide an order has slipped?" | JD | [grounded] "chase suppliers when orders slip" | Name the trigger you used. If you had no set trigger and chased by judgement, say so. | F2, presentation. Covers "chase late orders". |

### D — Pressure (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You want £42,000 and the range goes to £44,000. Why not start at the bottom?" | JD | [grounded] "I'm hoping for £42,000." | State £42,000 once. Hold through two follow-ups. If you want the band first, you can ask what it is. Concede only that you are open to talking about the detail. | Pay logistics. Your figure fills its slot; no defend-the-number slot. |
| D2 | "Two days minimum, honestly, can you do it fully?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" | Say two days works and no more than three. Hold. | F8 under pressure. |
| D3 | "Why should we believe a delivery coordinator can run production schedules?" | JD | [grounded] "I schedule deliveries for our three depots" | Hold the scope: deliveries across three depots. Concede that production scheduling is not yours yet. Say what you would do to close that gap, as a plan. | F1 under pressure: hold, then concede. |
| D4 | "Sixty seconds: why should we hire you over someone with SAP?" | JD | [grounded] "Never used SAP" | Hold on the coordination record. Concede SAP plainly: "I haven't used SAP." | F6 under pressure. Do not argue the point. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F7 |
| Coordinate production schedules between planning, warehouse and QA | B1, C3 |
| Track supplier deliveries and chase late orders | A1, C4 |
| Keep stock records accurate | C1, C2 |
| Weekly on-time dispatch reporting | B3 |
| Confident with Excel | B4 |
| ERP (SAP or similar) a plus | B2, D4 |
| £38,000 to £44,000 | D1 |
| Hybrid, two days a week at Avonmouth | A3, D2 |

## Reverse questions

1. "What does the first ninety days look like for someone in this role?" Why it lands: shows you are planning the job, not just applying.
2. "When production, warehouse and QA priorities conflict, who decides?" Why it lands: names the seam the advert describes.
3. "Which part of the weekly dispatch report is hardest to hit right now?" Why it lands: specific, and it shows where the pressure sits.
4. "What stock and order systems does the team use day to day?" Why it lands: tests the SAP gap directly and shows you want to learn the system.
5. "What are the next steps after this call, and who would I meet?" Why it lands: a standard close that moves the process on.

## Sources

- Provided: your message, including the advert text and your background.
- Research tier: L0. No searches were run; the screen's logistics do not depend on company research.
- Targets: 1. company values, unavailable (L0); 2. interview process, unavailable (L0); 3. strategy and recent news, unavailable (L0); 4. Hannah Lowther's public footprint, unavailable (L0), and the interviewer read is absent; 5. representative JD, skipped (the advert was supplied).

## Upgrade menu

- Your notice period → A4 gets your figure, which is then quoted into the fit snapshot.
- Company research (L1) → values and recent news for the "why Quillmoor" answer (A2), currently generic.
- Hannah's prep email, if she sends one → shows whether the call covers anything beyond logistics.
- Dispatch reporting or your Excel detail → upgrades B3 and B4 from discovery to grounded.
