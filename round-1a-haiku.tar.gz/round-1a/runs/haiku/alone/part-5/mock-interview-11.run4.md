I'd hold off on the interview. This message has several hallmarks of a job scam, and I'd verify it before you prepare or reply in detail.

**Red flags:**
- **Unsolicited contact** from an unknown number, saying they "found your profile online." Ask yourself which application this came from. Recruiters normally name the company and role.
- **Everything over WhatsApp, with no calls or video.** Legitimate recruiters use email and phone, and usually a company email address.
- **Fast-track pressure:** an interview tomorrow for a remote job with "flexible hours."
- **Scams like this often continue** by asking for your ID, bank details, or National Insurance/Social Security number "for payroll" before any real offer. Some ask you to pay for equipment or training, or to receive and forward money. Those are the serious warning signs.

**How to check before anything else:**
1. Ask Jess for the job posting link, the client company's name, and a reply from a company email address (not Gmail, WhatsApp, or similar).
2. Look up the recruitment agency and the client company independently. Use their official website or a phone number you find yourself, not the one Jess gave you.
3. Check whether the role appears on that company's own careers page.
4. Search the company name with "scam" or "reviews."
5. Don't send ID, bank details, or any payment to anyone before a verified written offer.

**A reply you could send Jess:**
> "Thanks for getting in touch. Before I confirm a time, could you send me the job posting link, the name of the company hiring, and a contact email from the company's domain? I'd also prefer a short phone or video call. I'll confirm once I've checked."

If Jess is legitimate, they'll be able to answer this easily. If they push back, avoid calls, or ask for personal details, treat that as a no.

If the role does check out, I can help you prepare. Send me the job description (or the company name and role title), your CV, and the interview format, and I'll run the mock-interview prep: likely questions, answer guidance for your background, gaps to address, and a practice session where I play the interviewer. I can also start on general interview prep now if that's more useful.