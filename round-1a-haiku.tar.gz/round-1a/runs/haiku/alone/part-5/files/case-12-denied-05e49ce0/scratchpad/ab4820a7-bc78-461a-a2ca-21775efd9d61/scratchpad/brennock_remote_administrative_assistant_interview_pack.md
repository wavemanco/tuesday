# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: 30-minute video call. Built on your message and the job-ad summary you gave. No research was run, so no company values or strategy are included.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **JD** (the listed duties), **EXP** (your past work), **CASE** (a live problem from the job). Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", it is an instruction for the interview: answer it with what is true for you, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material shows an appointment book for four physios, not calendars for a team. Bridge at its own scope: "I ran the appointment book for four physios." Answer slot: if you set the booking rules or resolved clashes, say which and how; if not, say so and say what you did when two bookings collided. |
| F2 | "booking travel" — your message | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and with which tool; if not, say so plainly and say how you would learn the booking tools. |
| F3 | "preparing documents in Word and Excel" — your message | "good with Word, okay with Excel" — your message | medium | [grounded] | presentation | Your own words, reworded only as they stand: "I'm good with Word, okay with Excel." No slot: do not add documents or spreadsheets you did not name. |
| F4 | "processing supplier invoices" — your message | "chased unpaid invoices" — your message | low | [inferred] | transferability | Chasing unpaid invoices is collecting payment, not processing supplier invoices. Bridge at its own scope: "I chased unpaid invoices." Answer slot: if you entered, checked or approved supplier invoices, say how; if not, say so. |

## Prohibited claims

Claims this pack will not coach, because the material does not carry them.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1 | "I ran the appointment book for four physios." Your material says the appointment book, not calendars. |
| Processed supplier invoices | Inflated form of F4 | "I chased unpaid invoices." Your material says chasing, not processing. |
| Expert in Excel | Inflated form of F3 | "Okay with Excel." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: travel, invoices, why a clinic-to-office move | High. An office manager hiring for admin is checking the two duties you have not shown (F2, F4). | Rehearse the gap question until it is plain. Lead with what you did, then name the gap and how you would close it. |
| Case / Strategist | A live problem from the job: an invoice with no purchase order, a double-booked room | Medium. Admin roles often test judgment on a real task. | Clarify first, then state your steps out loud. |
| Data-Driven Prober | Asks for counts and how you tracked things | Medium. Your CV has no figures, so any number you give will be probed. | Give a figure only if it is real. Otherwise say you do not have one and say what you would count. |
| Conversational | "Walk me through your journey" | Medium. A short, friendly opener that is still scored. | Have a 90-second arc ready, built only from your own sentences. |
| Pressure | A challenge on the gaps, with a time limit | Low for a 30-minute call, but possible. | Hold your true position through two follow-ups. Concede only what is true. |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me from a reception desk to an admin role. Why should I think you'll manage?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Lead with that sentence. Then name the two parts of the job you have most to learn (travel booking, invoice processing) and how you would learn them. | F1 and F4 are where a skeptic will press. |
| A2 | "Which parts of this job have you not done yet, and how would you cover them?" | JD | [grounded] "ran the appointment book for four physios" | This is the highest-ROI rehearsal in the pack. Name the parts you have not done, in your words. Use the nearest real work you did (the appointment book) to show how you would learn. Answer slot: if you have booked travel or entered invoices before, say which and how; if not, say so plainly. Hold through two follow-ups by returning to the appointment book, not by adding to it. | F2 and F4 are the gaps a skeptic will find. The question names the requirements, not a past you lack. |
| A3 | "Why leave a clinic for a remote admin role?" | EXP | [generic] | Give your actual reason, in your own words, and what you want from this job. No figure or event is needed. | Motivation is always probed, and your material gives no reason yet. |
| A4 | "You'd be working remotely. How do you keep calendars and documents on track when nobody is in the room?" | JD | [generic] | Describe a plan: which tools, how you check in, how you hand over in writing. This is a plan, not a past. | "Remote" is in the job title. A plan answers it without claiming experience. |
| A5 | "Word is your strength. What would you do with an Excel task that is beyond you?" | JD | [grounded] "good with Word, okay with Excel" | Say "okay with Excel" as you said it. Then describe how you would handle a task beyond you: ask, learn the function, check the result. Answer slot: if you have built a spreadsheet for work, name what it did; if not, say so. | F3 is the weakest-supported skill; honesty about Excel is the strength here. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A supplier invoice arrives with no purchase order and is due Friday. What do you do?" | CASE | [generic] | Clarify first: is a PO required, who approves, what is the due date for. Then the steps: check with the approver, ask the supplier for the PO, escalate if unresolved. | Processing invoices is in the job; this tests judgment. |
| B2 | "Two people want the same meeting room and the same flight on the same day. How do you decide?" | CASE | [generic] | Ask who has priority and who decides. Confirm before rebooking anything. Record the decision in writing. | Calendars and travel are both in the job. |
| B3 | "A director needs to be in Dublin and Lisbon in one week. How would you book it?" | CASE | [generic] | Ask about budget, travel policy and date flexibility. List what you would confirm before booking. | Travel booking is a gap (F2), so the answer is structure, not history. |
| B4 | "What would you do in your first week to learn how invoices get approved here?" | JD | [generic] | Ask for the approval chain, follow one invoice through it, and write it down. | Shows how you would close the F4 gap. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Roughly how much did the appointment book carry in a typical week?" | EXP | [grounded] "ran the appointment book for four physios" | If you have a real figure, give it and say how you knew. If you do not, say so and say what you would have counted. Answer slot: if you give a figure, expect a follow-up on how it was counted; say what you did, in your words, and which part was yours. | Your CV has no figures; a prober will ask for one. |
| C2 | "How many unpaid invoices did you chase, and how many did you recover?" | EXP | [grounded] "chased unpaid invoices" | If you have a count, give it and say how you tracked it. If not, say you did not count them and say how you would track them now. Answer slot: the figure, if given, raises only these: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. | F4's evidence is a verb, not a number. Do not invent one. |
| C3 | "Walk me through how you'd check a supplier statement against three invoices." | CASE | [generic] | Name the steps: match purchase orders, match amounts, query differences in writing. Answer slot: if you have reconciled a statement before, say how; if not, say so and describe the steps you would take. | Invoices are in the job; this tests method. |
| C4 | "What can you do in Excel today without help?" | JD | [grounded] "okay with Excel" | Name the functions you have used, in your words. Say which you would look up. Answer slot: if you have used a function for work, name it; if not, say so and say how you would check your work. | F3 is "okay", so the answer is specific and modest. |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc: the clinic, the appointment book, the invoices, why this role. Use only those sentences. | Casual openers are still scored. |
| D2 | "What's the part of this job you're looking forward to most?" | JD | [generic] | Name one duty from the job and why it appeals, in your words. | Shows interest, not history. |
| D3 | "Any questions for me?" | — | [generic] | See the reverse questions below. Never answer with "no". | Rapport interviewers weight this heavily. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I pick you over someone who has booked travel?" | JD | [grounded] "ran the appointment book for four physios" | Hold: name what you did (the appointment book, the invoices) and how you would learn the rest. Concede only what is true: if travel booking has not been part of your work, say so plainly. Hold through two follow-ups. | F2 is the position under challenge. |
| E2 | "That's a lot of 'okay' on Excel. How much of this job depends on it?" | JD | [grounded] "okay with Excel" | Hold "okay with Excel" as you said it. Concede specifically: say you would want to build up Excel quickly, and how. Do not claim more. | F3 is held, not inflated. |

**Coverage.** Managing calendars: A1, A4, B2, F1. Booking travel: A2, B3, E1, F2. Word and Excel: A5, C4, E2, F3. Processing supplier invoices: B1, B4, C2, C3, F4. Remote: A4, D2. No requirement is left without a question.

## Reverse questions

Each asks the office manager something, and why it lands.

1. "What does a typical week look like for the office manager, and where does admin sit in it?" Why it lands: shows you are planning the work, not only the job title.
2. "Who approves supplier invoices, and what is the usual turnaround?" Why it lands: a process question that shows you think about invoices.
3. "How is travel booked today: a tool, a person, or a policy?" Why it lands: shows you have noticed the gap and want to close it.
4. "What would make someone in this role successful after the first 90 days?" Why it lands: a standard question that signals you want to be measured.
5. "How do you usually hand work over when someone is remote?" Why it lands: shows you have thought about remote working.

No interviewer profile was given, so no reverse question is tied to the interviewer's own career path.

## Upgrade menu

- The full job ad text → the requirements above are your summary; with the ad, they become quoted from the ad itself.
- The office manager's name → persona weights from their public footprint, and a reverse question tied to their path.
- Any travel booking or invoice work you have done, even informal → upgrades F2, F4 and the slots in A2, C2 and C3.
- Permission to run research on the company → confirms it from its own site and public sources before you engage.
- A `tuesday-dossier.md` → would record the gaps this prep exposed, for later sessions.
