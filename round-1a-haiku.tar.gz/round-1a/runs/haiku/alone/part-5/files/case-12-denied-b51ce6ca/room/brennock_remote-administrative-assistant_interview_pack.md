# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager (name not given).
**Interviewer treated as:** hiring manager, so Case/Strategist and Skeptic weigh most.
**Research tier:** L0, provided material only. No web search was run for this pack.

## How to use this pack

Personas are how a question arrives. Types are what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", the honest answer is either what you actually did, in your own words, or a plain statement that it was not yours or you have not done it.

| Type | Meaning |
|---|---|
| **VAL** | Behavioural or values alignment (not tagged this round) |
| **EXP** | Your own past experience, and whether it holds up under questions |
| **JD** | The role's listed duties and requirements |
| **CO** | Company knowledge (not tagged: no research run) |
| **CASE** | A live problem from the job, answered as it happens |

## Prep priorities

1. **B2** is the highest-return prep in this pack. The ad asks for supplier invoice processing, and your material shows invoice chasing. Expect a probe on the gap.
2. **A1 to A4** are the most likely questions in a task-focused call. Practise them aloud.
3. Everything else is insurance.

## Fit snapshot

Requirements come from your summary of the ad, not the full text, so they are marked `[grounded]` only for the words you supplied. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your summary of the ad) | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | The material says the appointment book for four physios, not calendars across several people. Bridge: "I ran the appointment book for four physios." Answer slot: if you managed diaries for people other than the physios, or settled clashes between them, say how, in your own words; if you did not, say so plainly and describe how you would handle a clash. |
| F2 | "booking travel" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel, say for whom and with which tool, in your own words; if you have not, say so plainly and say how you would learn the booking tools in your first week. |
| F3 | "preparing documents in Word" (your summary of the ad) | "good with Word" — your message | medium | [grounded] | none | No gap, but a self-rating with nothing inspected behind it, so expect a probe. Lead with the sentence as you said it. |
| F4 | "preparing documents in … Excel" (your summary of the ad) | "okay with Excel" — your message | low | [grounded] | discovery | Your material gives a level, not a task. Answer slot: name one Excel task you have done and what it produced, if any; if none, say so plainly and say which function you would learn first. |
| F5 | "processing supplier invoices" (your summary of the ad) | "chased unpaid invoices" — your message | low | [grounded] | transferability | Chasing unpaid invoices is collections, not processing, so the bridge should not stretch. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or approved supplier invoices, say what you did; if chasing was your only invoice work, say so plainly. |

## Prohibited list

These claims are not coached, because the material does not support them. Each is the stretched form of a sentence you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive calendars and settled clashes across teams | Inflated form of F1 | "I ran the appointment book for four physios." Your material says the appointment book, not calendars across teams. |
| Processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices." Chasing is not processing. |
| Advanced Excel | Inflated form of F4 | "okay with Excel", at its own scope. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live office problems: a clash, a trip to book, a mismatched invoice | High. A hiring-manager round for an admin role tests task handling first. Weight: 5 questions. | Clarify before answering. Say what you would check first, then what you would do. |
| Skeptic | Background mismatch, the invoice gap, the day-one weakness | High. Receptionist to admin is the obvious question. Weight: 4 questions. | Hold your bridge from your own sentences. Say plainly what you have not done. |
| Conversational | Friendly opener, casual Excel question | Medium. Short calls often start casually, and casual questions are still scored. Weight: 3 questions. | Have a 90-second version of your journey ready. |
| Data-Driven Prober | Counts and amounts from your CV lines | Medium. Your CV lines contain numbers you have not given yet. Weight: 3 questions. | Say the figure as you know it, and say how you would count it if you are unsure. |
| Pressure | A 60-second challenge against someone with more experience | Low to medium. Short calls use a pressure beat occasionally. Weight: 3 questions. | Pause, restate, hold the bridge through two follow-ups, then concede the specific gap. |

Peer persona is omitted: the interviewer is the office manager, not a peer.

## Question banks

### Case/Strategist (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two directors have booked the same meeting room for Thursday at ten. What do you do?" | CASE | [generic] | Clarify who booked first and who needs it most. Check with both, then confirm with the one who gives way. Record the change. No claim about your past. | A live calendar problem from the ad's calendar duty. Generic because it is a pattern, not a fact about this office. |
| A2 | "A director needs to be in Cork and Dublin on the same day next week. Walk me through booking it." | CASE | [generic] | Clarify times, budget and preferences. Check the travel policy. Compare two options, then confirm with the traveller before booking. | The ad's travel duty as a live problem. Generic; no claim about your past. |
| A3 | "Monday, a supplier's invoice shows different bank details from the ones on file. What do you do?" | CASE | [generic] | Do not pay. Confirm the change through the supplier's known contact, not the number or email on the new invoice. Tell the approver and note it. | The ad's invoice duty, with the most common payment-fraud check. Generic. |
| A4 | "Show me how you would turn a list of supplier payments into a monthly summary in Word and Excel." | JD | [grounded] "preparing documents in … Excel" — your summary of the ad | Name the steps: the source list, the key field, the totals, the check. Then say honestly which of these you have used. Answer slot: if you have built a summary like this, say so; if not, say so plainly. | The ad's Word and Excel duty stated as a task. The question asks for method, not a claimed history. |
| A5 | "Tell me how you'd keep a director's diary clear for a week without missing a meeting." | JD | [grounded] "managing calendars" — your summary of the ad | Name the steps: confirm the week's priorities, check conflicts, hold buffers, confirm each day. Answer slot: if you have done this for anyone, say how; if not, say so and describe the steps. | The ad's calendar duty as a scheduling problem. The premise comes from the ad, not from your CV. |

### Skeptic (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is a physio clinic front desk. Why would an admin role at a facilities firm suit you?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Name the part of the clinic work you would carry over, using the appointment book sentence. Then give your reason for wanting this role, in your own words. Answer slot: the reason is yours to state, not supplied here. | The skeptic's first probe on background fit. |
| B2 | "The ad asks for supplier invoice processing. You've chased unpaid invoices. How much of processing them have you done?" | JD | [grounded] "chased unpaid invoices" — your message | Hold: "I chased unpaid invoices." Answer slot: if you entered, matched or approved supplier invoices, say what you did; if chasing was your only invoice work, say that plainly and say how you would learn the payables steps. Hold through two follow-ups by returning to the chasing, not by adding to it. | F5 is where the ad's invoice duty presses hardest. Highest-return prep in the pack. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | none (open prompt) | Name the duty you have least evidence for: travel booking, from F2. Answer slot: if you have booked travel, say how; if not, say so plainly and say how you would learn the tools in your first week. | An open prompt that lets you choose the weak area. Keeps you from being surprised by F2. |
| B4 | "Why move from a clinic to this role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | Give your reason in your own words. Answer slot: the reason is yours to state, not supplied here. Do not criticise the clinic. | A motivation probe. The reason is not in your material, so the slot is the honest form. |

### Conversational (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey to here." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" — your message | A 90-second arc: the clinic, the appointment book, the invoice chasing, what you want next. Use the sentences as you said them. | A casual opener that is still scored. |
| C2 | "What are you playing with in Excel these days?" | JD | [grounded] "okay with Excel" — your message | Use your own words for your level. Name one function you have used only if you have. Answer slot: if you have no current Excel work, say so and name the function you would learn first. | The ad's Excel duty asked casually. |
| C3 | "Tell me about yourself in two minutes." | EXP | [grounded] "good with Word", "ran the appointment book for four physios", "chased unpaid invoices" — your message | Order: the clinic, the appointment book, the invoice work, Word, and your reason for applying. Keep each to one sentence as you said it. | A standard opener that the interviewer will use to pick the next probe. |

### Data-Driven Prober (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. How many bookings did it hold in a week, and how did you handle clashes?" | EXP | [grounded] "ran the appointment book for four physios" — your message | Give the number if you know it, and say how it was counted. Answer slot: if you do not know the figure, say so; for clashes, say how you settled them, in your own words, or that you did not settle them yourself. | F1's scope. The clash question is the ad's calendar duty, raised as a probe. |
| D2 | "You chased unpaid invoices. How much was outstanding at the worst point, and how much came back?" | EXP | [grounded] "chased unpaid invoices" — your message | Give any figure as you remember it. Say the weakest assumption behind it: how you tracked it. Answer slot: if you have no figures, say so and say what you would record first. | F5's scope. The figure is an answer slot, not a supplied number. |
| D3 | "What does 'okay with Excel' mean in practice for you?" | EXP | [grounded] "okay with Excel" — your message | Use your own sentence for your level. Name a function only if you have used it. Answer slot: if you cannot name one, say so plainly. | F4's scope, asked as a probe. |

### Pressure (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we pick you over someone who already processes invoices every day?" | JD | [grounded] "chased unpaid invoices" — your message | Pause, then restate. Hold: "I chased unpaid invoices for two years." Concede the specific step you have not done, if that is true, and say how you would learn it. | The pressure version of B2. Hold, then concede the step, not the whole role. |
| E2 | "What would you be least comfortable doing in Excel?" | JD | [grounded] "okay with Excel" — your message | Hold your level in your own words. Concede the specific function you have not used, if that is true, and say how fast you would learn it. | A pressure version of D3. Concede a named function, not your general level. |
| E3 | "Sixty seconds: why you over someone with office admin experience?" | JD | [grounded] "ran the appointment book for four physios" — your message | Pause and restate. Hold on the appointment book and the invoice work. Do not claim office admin experience you have not stated. | A pressure question about the comparison. Keep to your own sentences. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| managing calendars | A1, A5, D1 |
| booking travel | A2, B3 |
| preparing documents in Word and Excel | A4, C2, C3, D3, E2 |
| processing supplier invoices | A3, B2, D2, E1 |

## Reverse questions

Ask these at the end of the call.

1. "What does a typical week look like for whoever holds this role, and which part takes longest?" Why it lands: shows you are thinking about the real workload.
2. "How do you verify a supplier's bank details before paying?" Why it lands: shows you understand payment fraud, and gives you a real process check.
3. "Who approves supplier invoices here, and roughly how many come in a month?" Why it lands: shows you understand the payables control and the volume.
4. "Which travel booking tools do you use, and who signs off trips?" Why it lands: tests your travel duty concretely.
5. "What would a good first 90 days look like?" Why it lands: asks for the success measure in the interviewer's own words.

## Sources

- Provided material: your message, including the invite text, your summary of the ad and your background.
- Research tier: L0. No web search or page fetch was run. Ask if you want the company checked through its public footprint.

| Target | Status | What it would have moved |
|---|---|---|
| 1. `Brennock Facilities values` | unavailable | Values cheat sheet, not in this pack (no values round detected) |
| 2. `Brennock Facilities interview process` | unavailable | Loop structure; persona weights are based on the round you described |
| 3. `Brennock Facilities strategy` / recent news | unavailable | Company knowledge questions, none in this pack |
| 4. `{interviewer name} Brennock Facilities` | n/a | No interviewer name was given |
| 5. Representative `Remote Administrative Assistant` JD | skipped | Your summary of the ad already fixes the fit snapshot and the JD questions |

## Upgrade menu

- The full text of the ad → rows F1 to F5 move from your summary to the ad's exact words, and A4 and A5 get their exact duties.
- Your Excel work, in more detail → rows F4 and D3 can be answered with a task rather than a level.
- The office manager's name → an interviewer read and a tailored reverse question.
- Research on the company → a company knowledge bank and an updated values check.
