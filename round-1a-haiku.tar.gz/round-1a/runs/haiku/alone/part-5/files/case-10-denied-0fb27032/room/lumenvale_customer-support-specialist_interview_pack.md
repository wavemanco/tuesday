# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

- **Role:** Customer Support Specialist, remote
- **Company:** Lumenvale Software
- **Interviewer:** the support team lead (name not given). Relationship: hiring-side team lead.
- **Format:** text chat on Telegram. The interview is written, so written clarity is tested live, not only described.
- **Candidate:** Imani

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key:
  - **VAL**: values alignment. Not used here, because no values were supplied.
  - **EXP**: what you actually did in your past role.
  - **JD**: the job's stated requirements.
  - **CO**: company knowledge. Not used here, because no research was run.
  - **CASE**: a live problem from the role.
- Guidance is scaffolding, not a script. Speak it in your own words.
- **Answer slot:** an instruction for the interview where your material does not show something. You answer from your own experience, or say plainly that it was not yours or never happened. It is not a question for this conversation.

## Fit snapshot

Requirements are quoted from the ad as you relayed it in your message. The full ad text was not supplied, so the quotes are your wording of it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as relayed) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap. Say the role and the years in those words. Keep your title as it is; do not rename it "customer support." |
| F2 | "Zendesk or a similar ticketing tool" (job ad, as relayed) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Freshdesk is the similar tool the ad allows. Say it in your words: "I use Freshdesk every day." Do not say Zendesk unless you have used it. |
| F3 | "clear written communication" (job ad, as relayed) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume shows you write often. It does not show the writing is clear. Answer slot: if someone checked, edited or praised your written replies, say who and what they changed; if no one did, say so plainly and show your writing in this chat. |
| F4 | "confidence handling escalations" (job ad, as relayed) | none given | none | [grounded] | discovery | Your material is silent on escalations. Answer slot: if you handled an escalation, say what you did and what happened, in your own words; if you did not, say so plainly and say how you would handle one. |
| F5 | Experience in a software company's support team ([generic], not in the ad) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked for a software company." Then bridge only with what F1 and F2 carry. Do not claim product knowledge you do not have. |
| F6 | Onboarding and training others on a process ([generic], not in the ad) | "trained four new starters on our refunds process last year" (your message) | high | [grounded] | none | Strength, not a gap. Say what you did in those words. |
| F7 | High-volume handling ([generic], not in the ad) | "answering around 60 calls and emails a day" (your message) | medium | [grounded] | none | Strength. The figure is approximate ("around"), so say it as approximate. How it was counted is question C1. |

Gap types are chosen from the evidence cells, as the routing rule requires. F4 and F5 are the two rows most likely to be probed.

## Prohibited list

Claims this pack will not coach. Each one has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Software company experience | Negative you stated (F5) | "I haven't worked for a software company." No answer slot. |
| Zendesk experience | Inflated form of F2. Your material shows Freshdesk only. | "I use Freshdesk every day." |
| Wrote or designed the refunds process | Inflated form of F6 | "trained four new starters on our refunds process last year," at its own scope |
| Quality results for the 60 a day | Inflated form of F7. Your material says volume, not quality. | "around 60 calls and emails a day," at its own scope |

## Persona table

| Persona | How it shows up in this chat | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the software gap and the Zendesk line. Asks why you would move. | High, top weight (5 questions). A hiring-side team lead's prior is Case plus Skeptic, and F5 is the gap your own message states. | Say the plain acknowledgment first. Bridge only from quotes. Offer a ramp plan as a plan, not a past. |
| Case / Strategist | Live refund and queue problems in the chat. | High (4 questions). The same prior, and the ad's escalations line raises it. | Clarify first, then structure, then write. Keep the reply short. |
| Data-driven prober | Asks how the 60 a day was counted. | Medium (3 questions). F7 is your headline figure. | Say what the figure counts, and name the assumption you would defend least. |
| Pressure | Challenges escalations, and whether you actually trained or changed the process. | Medium (3 questions). F4 and F6 are where a challenge lands. | Pause, restate, hold through two follow-ups, then concede the real limit. |
| Conversational | Casual opener and an open question in the chat. | Medium (3 questions). Casual questions are still scored. | Pre-script a 90-second background from your quotes. |

## Question banks

### Skeptic (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. Why would you be good at supporting our product?" | JD, EXP | [grounded] "I've never worked for a software company" (your message); "I use Freshdesk every day" (your message); "3 years as a customer service advisor at an energy supplier" (your message) | Say the plain part first: "I haven't worked for a software company." Then bridge with your quotes: the three years, and "I use Freshdesk every day." Name one transfer, the daily Freshdesk use. Do not claim product knowledge. Say how you would learn the product, as a plan. | **Highest-ROI prep in this pack.** F5 is a gap your message states, so this objection will come in some form. The bridge stays at F1 and F2's scope. |
| A2 | "The ad asks for Zendesk or a similar ticketing tool. What have you used?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say it in those words: Freshdesk, every day. Answer slot: if you have used Zendesk, say when and for what. If you have not, say so plainly and say how you would learn its basics first. | F2 is a presentation gap: the quote reaches the requirement in another tool's terms. The question scores the ad's own tool line. |
| A3 | "Tell me about a time an issue was beyond what you could resolve, and how you escalated it." | JD, EXP | [generic] | Open prompt. Pick a case where the issue went beyond what you could settle alone. Say what you checked before escalating, who it went to, and what happened, in your own words. Your material does not show an escalation. If none comes to mind, say so plainly, then describe how you would handle one, or the nearest case your three years contain. | F4 is silent on escalations. The theme comes from the ad's escalations line, so the honest branch is required. |
| A4 | "Why would you move from an energy supplier to a software company's support team?" | JD | [grounded] "I've never worked for a software company" (your message) | Give your reason in your own words, and keep to what is true for you. Answer slot: if your reason is specific to this role, say it. If not, say plainly what you want from a support role and what you would need to learn. | Motivation probe. F5 is why it lands; a reason that names the software gap is more credible than a generic one. |
| A5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" (your message) | Name the product knowledge first. Answer slot: if you have already done part of the role, say which part. If not, name what you do not know yet and how you would learn it in the first week. | Calibrated candor scores better than bluffing. The honest answer is the F5 acknowledgment. |

### Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer emails that their refund hasn't arrived after two weeks. Write your first reply to them here in this chat." | CASE, JD | [generic] | Write it in the chat. Acknowledge the wait, say what you will check, give one next step with a timeframe you can keep, and avoid jargon. Keep it under 120 words. Do not promise an amount or a date you cannot confirm. | Live written clarity under the chat format (F3). The scenario is generic, so it claims nothing about your past. |
| B2 | "A customer asks for a feature the product doesn't have. How do you reply, and what happens next?" | CASE | [generic] | Say what you can confirm, and do not promise a timeline. Log the request and say where it goes. If you are unsure whether it is a bug, say you would check before answering. | Tests judgment at the edge of what support can promise. Links to F4. |
| B3 | "Your queue has 40 open tickets and two are marked urgent. What order do you work them in, and what do you tell the customers waiting?" | CASE | [generic] | Clarify what "urgent" means first, then set the order, then say what each queue hears. Name the escalation step for an urgent case you cannot resolve. | Structure over a right answer. It asks for reasoning, not a past. |
| B4 | "How would you know a support reply is clear enough before you send it?" | CASE, JD | [generic] | Name one check you would run: reread for any question the customer must answer, cut the steps, read it as the customer would. Answer slot: if someone has checked or edited your written replies, say who and what they changed. If no one has, say so plainly. | F3 is the written-communication gap. This is where it gets tested. |

### Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted, and which part was yours?" | EXP, defend-the-number | [grounded] "answering around 60 calls and emails a day" (your message) | Say what the 60 counts, in your words. Name the assumption you would defend least. Answer slot: if you know how it was counted, say how. If you do not, say plainly that you do not know how it was counted. Say which part was your own work. | F7 is your headline figure. Defend-the-number slots apply, and the pack supplies no counting method. |
| C2 | "What would you measure to know a support reply was good?" | JD, CASE | [generic] | Name one measure, say what it misses, and say how you would check it. | A metrics stance. Generic, so no claim about your past. |
| C3 | "You trained four new starters on the refunds process. What did you use to check they had learned it?" | EXP | [grounded] "trained four new starters on our refunds process last year" (your message) | Say what the training was, in those words. Answer slot: if you checked their learning, say how. If you did not, say so plainly and say what you would check next time. | F6 is a strength. The check is an answer slot because your material does not show one. |

### Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pick you over someone with software support experience?" | JD, Pressure | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I've never worked for a software company" (your message) | Pause and restate the question. Hold your position through two follow-ups: the three years and the daily Freshdesk use are what you have. Concede the real gap in one line: no software company experience, which you would close by learning the product. Do not fold on the three years. | Hold-then-concede. The position held is one your quotes carry. |
| D2 | "How much of that refunds process was yours, and how much was already there when you trained people on it?" | EXP, Pressure | [grounded] "trained four new starters on our refunds process last year" (your message) | Say what you did: trained four starters, in those words. Say which parts were already there, in your words. Answer slot: if you changed any part of the process, say what and why. If you did not, say so plainly. | Tests attribution. Your hold is the training, and the concession is that the process was already there. |
| D3 | "You handled 60 a day. Volume isn't quality. What do you say to that?" | Pressure, EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Agree that volume and quality differ, in your words. Hold that the volume is a real measure of the work you did. Name any quality check that existed. Answer slot: if a quality check existed, say what it was. If not, say so plainly. | The hold is volume, not quality. Concede without folding on the number. |

### Conversational (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your background." | EXP, JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I use Freshdesk every day" (your message); "trained four new starters on our refunds process last year" (your message) | Pre-script a 90-second arc from those three quotes, in your words: role and years, daily Freshdesk use, the training. Then state the software gap plainly. | A casual opener that is still scored against the ad's years and tool lines. |
| E2 | "What are you most curious about in our support work?" | JD | [generic] | Name one thing from the ad or this chat. Do not invent a product fact. Ask one question back. | A casual question about the role, scored for engagement. |
| E3 | "How do you keep a reply friendly when a customer is rude?" | JD | [generic] | Name one habit: stay on the facts, answer the question first, then hold the line. Answer slot: if you have a real example, say it. If not, name the habit. | Written tone, the ad's clear-communication line (F3). |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support | E1 |
| Zendesk or a similar ticketing tool | A2 |
| Clear written communication | B4, E3 |
| Confidence handling escalations | A3, B2 |
| Software company gap (not in the ad) | A1, A4, A5, D1 |

## Reverse questions

Ask at least one, or two, at the end. Each one has a reason it lands.

1. "What does an escalation look like here, and who decides it?" Why it lands: it tests the escalation path the ad names.
2. "Which support tools does the team use day to day?" Why it lands: it confirms whether Freshdesk fits, or what you would learn.
3. "What would a strong first ninety days look like for someone new to software support?" Why it lands: it turns the F5 gap into a joint plan.
4. "How is reply quality reviewed, and how often?" Why it lands: it signals you think about quality, not only volume.
5. "Is there a written style guide for customer replies?" Why it lands: it shows you care about the written side the chat is testing.

No interviewer profile was supplied, so none of these is tied to the interviewer's own path.

## Sources

- **Provided documents:** the Telegram invite from the talent team, as quoted in your message, and the job ad's requirements as you relayed them. Your background is from your message. No CV was supplied.
- **Research tier: L0.** No search was run. Research depth was not chosen in this message, so the pack is built on provided material only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Would have moved a values cheat sheet. No values section is included. |
| 2. Lumenvale interview process | unavailable | Would have moved the loop structure. Persona weights are from round-type priors. |
| 3. Lumenvale strategy / recent news | unavailable | Would have moved CO questions. None are included. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative JD for the title | unavailable | Would have verified the ad's wording and the fit snapshot's requirement quotes. |

## Upgrade menu

- The full job ad text → the four requirement quotes become the ad's own sentences, not your summary.
- Your CV → fit snapshot evidence comes from your CV as well as your message, and more bank questions can be premised on it.
- The team lead's name → a tailored reverse question and persona weights from their public footprint.
- Research at L1 (up to 6 searches, 2 page fetches) → Lumenvale's public values and any published interview process. Upgrade to L2 for strategy and recent news, on request.
- The recruiter's process notes → coverage of any stated test or assignment.
- `tuesday-dossier.md` → carries this pack's gaps into later sessions (one line, below).
