# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** 30-minute recruiter screen by phone, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Her agenda (from her message):** salary expectations, notice period, hybrid pattern, reason for moving; then she describes the team and next steps.
**Research:** none run. This pack uses only your message, your background as you described it, and the advert.

## How to use this

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- The guidance below is scaffolding, not a script. Say it in your own words.
- Target: each answer speakable in 60–90 seconds.

## Prep triage

In order, before Thursday:

1. **Get your notice period figure** (A4). It is the one thing you have not given me, and she will ask.
2. **Practise the salary line** (A3) and the reason-for-moving line (A2) until they sound natural.
3. **Practise the hybrid line** (A5) and the SAP line (A7).
4. Everything else is insurance.

## Fit snapshot

Requirements are quoted from the advert. Evidence is quoted from your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | [grounded] | none | Clear match. Give the years and the role, nothing more. |
| F2 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message | high | [grounded] | none | Clear match. Your daily version: you schedule deliveries for three depots and chase suppliers when orders slip. |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year" — your message | high | [grounded] | none | Strong match. Keep "about a third" and "over a year" exactly; do not round them up. |
| F4 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | medium | [inferred] | discovery | The rebuild shows Excel use, but not your level. Expect "How would you rate yourself?" Answer slot: name two or three features you used in the count sheet, in your own words. |
| F5 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | low | [grounded] | transferability | A plus, not a requirement. Words: "I haven't used SAP. My stock work has been on our in-house stock system." Keep it as a fact; do not add a claim to learn it quickly as if it were a past. |
| F6 | "coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | low | [grounded] | transferability | Your material shows delivery scheduling across depots, not production planning or QA. Answer slot: if you have worked with production planning or QA sign-off, say what and when. If not, say what you did coordinate and how it maps. |
| F7 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Answer slot: if you have reported delivery performance before, say how often and to whom. If not, say how you would build a weekly on-time view. |

## Prohibited claims

These will not be coached, because the material does not support them:

- **Any SAP or ERP experience.** You have said you have not used it.
- **Production planning, QA, or diagnostics / regulated-manufacturing experience.** Not in your material.
- **Sole credit for the discrepancy drop**, or a figure rounder than "about a third". The material says the rebuild was yours; it does not say you alone drove the change over the year.
- **A notice period figure** until you give it to me.
- **A current salary figure**, unless you tell me what it is.

## Question bank: recruiter screen

Persona: the recruiter (Hannah). Weight: high. She has set the agenda, so expect the questions in this order.

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background." | Background | "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | 60-second arc: the employer type, the three depots, the chasing, then the stock spreadsheet. End on the spreadsheet. | Opener. Sets up the match to F1–F3. |
| A2 | "What's prompting the move?" | Motivation | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | State the closure as a fact. Say the relocation does not suit you. Then what you want: a Bristol operations role that uses delivery and stock coordination. Do not criticise the employer. | She named this topic. Keep it forward-looking. |
| A3 | "What are your salary expectations?" | Pay | "I'm hoping for £42,000." | "I'm looking for around £42,000, depending on the full package and the scope of the role." Do not name a floor. | She named this topic. The advert range is £38,000–£44,000. |
| A4 | "What's your notice period?" | Logistics | none given | "My notice period is [your figure]." **I need this figure from you.** | She named this topic. It is the gap in the material. |
| A5 | "How would the hybrid pattern work for you?" | Logistics | "Two days at Avonmouth is fine, but I wouldn't want more than three." | Two days works for you. Say three is your ceiling. Ask which days the team usually uses. | She named this topic. Your stated limit is three; the advert says two. |
| A6 | "Tell me about the stock-count work." | Evidence | "I rebuilt our stock-count spreadsheet; discrepancies fell by about a third over a year." | What you rebuilt, over what period, with "about a third" kept exactly. If asked what others did, answer from what you know. | Tests the accuracy claim. Expect a probe on how much was yours. |
| A7 | "Have you used SAP?" | Gap | "Never used SAP — we run our own in-house stock system." | "I haven't used SAP. My stock work has been on our in-house stock system." | The advert's plus. Honest and short. |
| A8 | "Have you worked with production planning or QA?" | Gap | "I schedule deliveries for our three depots." | Answer slot: say what you have done that is closest, and whether you have worked alongside either team. Do not claim production or QA work. | The advert's first requirement. Expect this probe. |
| A9 | "How would you rate your Excel?" | Gap | "I rebuilt our stock-count spreadsheet." | Answer slot: name two or three features you used, in your own words. | The advert's core tool. |

## Reverse questions

Ask two or three of these. Each one shows you have read the advert.

1. **What does the weekly on-time dispatch report look like, and who reads it?** *Why it lands:* shows you have read the reporting duty.
2. **Where do the stock discrepancies usually come from at the moment?** *Why it lands:* shows you care about the accuracy requirement.
3. **When production schedules clash between planning, the warehouse and QA, how is it usually resolved?** *Why it lands:* tests how the role works in practice.
4. **Which suppliers tend to slip most, and what is the usual lead time problem?** *Why it lands:* shows you understand the chasing part of the job.
5. **Is the hybrid pattern fixed days at Avonmouth, or flexible?** *Why it lands:* checks your two-day line against reality.
6. **What are the next steps after this call?** *Why it lands:* she has said she will cover this, but it is a safe close.

## Sources

- Your message (the recruiter's booking note and the advert text as you pasted them).
- Your background, as you described it.
- No search or page fetch was run.

## Upgrade menu

- Your notice period figure → a complete A4 answer. (Needed before Thursday.)
- Your current salary, if she asks → a prepared answer.
- The team's name or manager → a tailored reverse question.
- A representative job description for the title → a check on the advert's wording.
- A deeper research pass on Quillmoor → a grounding brief on their recent news and production sites.
