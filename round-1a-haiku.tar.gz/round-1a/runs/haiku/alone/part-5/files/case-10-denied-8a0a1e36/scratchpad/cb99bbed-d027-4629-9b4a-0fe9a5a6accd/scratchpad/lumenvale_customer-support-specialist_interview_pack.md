# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Candidate:** Imani
**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Round:** Text-chat interview on Telegram with the support team lead
**Interviewer:** Support team lead (name not given). Relationship assumed to be hiring manager; see upgrade menu.
**Changelog:** First version.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **EXP** (your experience), **JD** (the role's requirements), **CASE** (a live problem), **VAL** (values), **CO** (company knowledge).
- Guidance is scaffolding, not a script. Each cell is written to be spoken in 90–120 seconds, or typed in a short chat reply.
- **This is a written interview.** Your replies are scored on clarity and tone as well as content. Keep answers short and structured, and reply in full sentences, not fragments.
- Anything in quotation marks is from your message, not from the job ad. The ad's full text was not provided, so the requirements below are your summary of it.

---

## 2. Fit snapshot

Requirements are from your summary of the ad. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (your summary of the ad) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | high | [grounded] | none | No gap. Say it in your own words: "I have three years as a customer service advisor." The volume figure is yours to explain if asked. |
| F2 | Experience with Zendesk or a similar ticketing tool (your summary of the ad) | "I use Freshdesk every day" — your message | high | [grounded] | presentation | Your quote already reaches the requirement, since Freshdesk is a similar ticketing tool. Say it plainly: "I use Freshdesk every day." |
| F3 | Clear written communication (your summary of the ad) | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written work, but the material does not show how clear your writing was. Answer slot: if any of those emails were checked for quality or thanked for clarity, say what that was; if none were, say so, and show how you would write a reply to a customer. This chat is itself written evidence, so keep your replies clean. |
| F4 | Confidence handling escalations (your summary of the ad) | none given | none | [grounded] | discovery | The material does not show escalation work. Answer slot: if you handled escalations, say what happened and what you did, in your own words. If you did not, say so plainly, then describe how you would handle one. |
| F5 | Experience at a software company (implied by the company, not in the ad) | "I've never worked for a software company." — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't worked for a software company." Then say how you would learn the product, as a plan and never as past experience. |

**Gap types, briefly:** F2 is `presentation` (your quote already reaches the requirement). F1 is `none`. F3 and F4 are `discovery` (the evidence may exist and the material does not show it). F5 is `capability` (you stated the absence).

---

## 3. Prohibited claims

These are the claims this pack will not coach, because the material does not support them. Each one is an inflated version of something you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or set up the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | Your quote at its own scope: you trained four new starters on it. The limit is this pack's observation, not words for you: your material says you trained others on the process, not that you designed or owned it. |
| Set up, configured or administered Freshdesk | Inflated form of "I use Freshdesk every day" | Your quote at its own scope: you use it every day. |
| Software support experience | Inflated form of "3 years as a customer service advisor at an energy supplier" | Your quote at its own scope. You work in energy, not software. |
| Handled escalations | Silence in the material, not a quote (F4) | Not listed. It is an answer slot, and you answer it from your own experience. |
| "I've never supported a software product" | Goes beyond your stated negative, "I've never worked for a software company." | Plain acknowledgment only: "I haven't worked for a software company." |

---

## 4. Persona table

Your interviewer is a support team lead, so the relationship prior is hiring manager: Case/Strategist and Skeptic dominate. The interview is text-only, which lowers the weight on delivery-based pressure. Interviewer-signal adjustments do not apply because there is no interviewer profile.

| Persona | How it shows up in this chat | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Questions the software gap and the escalation gap directly | High, weight 5 | Hiring managers derisk gaps. Your F5 and F4 are the obvious gaps. | Rehearse the software objection until it is boring. Use bridges only from your quoted sentences, plus a concrete plan for learning the product. |
| Case/Strategist | A live support scenario you answer in writing | High, weight 3 | Team leads test how you triage. A written case shows structure and clarity at once. | Clarify, then structure, then answer. Keep it short. |
| Data-Driven Prober | Asks how your volume figure was counted | Medium, weight 2 | Your 60-a-day figure is a headline number, so expect a probe. | Say what you know about how it was counted, and say plainly what you do not know. |
| Pressure | Challenges your fit in one short message | Medium, weight 2 | A chat can still press on one point. | Hold your position through two follow-ups, then concede only what is true. |
| Conversational | Opens with a casual "walk me through your journey" | Medium, weight 2 | Casual openers are still scored. | Prepare a 90-second arc. Treat it as scored. |

---

## 5. Question banks

Ordered by persona weight. Depth follows weight.

### A. Skeptic (weight 5)

**Highest-ROI prep in this pack:** A1. The software gap is the most predictable objection, and it will be asked in some form. The hold is only what you stated.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company. What would make you effective with our product from week one?" | JD | [grounded] "I've never worked for a software company." | Start with the plain acknowledgment: "I haven't worked for a software company." Then the part your experience supports: three years of answering customers under real volume, in your own words. Then a plan, stated as a plan: how you would learn the product in your first two weeks. Hold through two follow-ups by returning to the plan. Concede specifically: "I don't yet know your product's edge cases; I would learn them from live tickets." Never claim software experience. | F5 is the gap. The question is the objection the ad will raise. JD because it scores the software requirement. |
| A2 | "Your experience is in energy. Why does that transfer to our customers?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Name what transfers and no more: answering customers in volume, under time pressure, and keeping them informed. Do not claim the energy domain is the same as software. Answer slot: if you have dealt with a technical product question, say how; if not, say so and describe how you would learn. | F1 and F5 together. Asked as a fit test. |
| A3 | "I don't see escalation work in your background. How would you handle an escalation here?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you handled escalations, say what happened and what you did, in your own words. If you did not, say so plainly, then describe a clear process: acknowledge, check the facts, decide what you can, hand on what you cannot, and tell the customer when they will hear back. The refunds training is a related point, but do not present it as escalation experience. | F4. The interviewer's line is a Skeptic stem, presupposing only what your material does not show. |

### B. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes: their refund was approved two weeks ago and it still hasn't reached their account. They're angry. Reply to them in under 100 words, then tell me your next step." | CASE | [grounded] "I trained four new starters on our refunds process last year" | Clarify first in your head: which refund, which payment method, what the record shows. Reply: apologise once, state what you are checking, give a realistic timeframe, and say how they will hear from you. Next step: check the refund record and payment status, then escalate if it is stuck beyond the normal window. The refunds training is a real point to mention, in your own words. | Live written case for the JD's written-communication and escalation requirements (F3, F4). CASE because it is a live problem. The reply length is a deliberate constraint. |
| B2 | "You have 40 open tickets and an outage report arrives. What order do you work in?" | CASE | [generic] | Clarify the outage's scope and severity first. Then route: outage and urgent customers first, then tickets with deadlines, then the rest. Say what you would tell the team lead. No claim about your past needed. | Live problem from the role's triage work. [generic] because it is a pattern, not a fact about you. |

### C. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day" | A 90-second arc: where you started, what your three years in energy have been like, the daily tool, and why support work suits you now. Keep the volume and the tool in your quoted words. Do not add roles or results. | F1 and F2. Casual, but scored. |
| C2 | "What does a normal day in Freshdesk look like for you?" | JD | [grounded] "I use Freshdesk every day" | Describe what you actually do in it, in your own words: the queue, the replies, the notes, the handoffs. Answer slot: name any feature you have used beyond the queue; if you have not, say so. | F2. Shows the tool is real experience, not a line on a CV. |

### D. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your figure is around 60 calls and emails a day. How was that counted, and what share were calls versus emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say how you know the figure. If you do not know how it was counted, say so plainly. Name the assumption you would defend least, and which part of the volume was yours to handle. Answer slot: if the split was tracked, say what the split was; if it was not, say so. | F1. The figure is the headline, so the probe is likely. Defend-the-number slot. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Freshdesk and Zendesk do the same job. Why would you pick up ours quickly?" | JD | [grounded] "I use Freshdesk every day" | Hold: the basic work is similar, and you would learn their setup in the first weeks. Hold through two follow-ups by returning to what you do daily. Concede specifically: "Their setup will differ, and I would expect to learn it." Do not claim you have used Zendesk. | F2. Hold-then-concede. |
| E2 | "Why are you applying here, when you have not worked in software?" | EXP | none | Answer slot: the material says nothing about your motivation, so give your own reason in your own words. Do not invent one. Then connect it to the work, with the plain acknowledgment as the first sentence if needed. | F5. Motivation is the Skeptic's favourite follow-up, and no quote carries it. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | F1: C1, D1 |
| Zendesk or similar ticketing tool | F2: C2, E1 |
| Clear written communication | F3: B1 (live written reply) |
| Confidence handling escalations | F4: A3, B1 |
| Software company experience (implied) | F5: A1, A2, E2 |

---

## 6. Reverse questions

Ask these at the end. Each one shows you have thought about the job.

1. **"What does a typical escalation look like here, and who makes the final call?"** Why it lands: it tests the escalation process the ad asks you to handle, and shows you are thinking about the hard part.
2. **"What does the first two weeks look like for someone new to the product?"** Why it lands: it turns your F5 gap into a concrete onboarding question, and shows you plan to learn.
3. **"How do you judge a good reply here: response time, resolution, or customer satisfaction?"** Why it lands: it shows you want to be measured on the right things.
4. **"Which ticketing tool does the team run on day to day?"** Why it lands: it checks the Zendesk-or-similar requirement directly.
5. **"Once an offer is made, how and from which address does it come?"** Why it lands: a company that runs a legitimate process answers this easily. It is also your check on the Telegram concern below.

---

## 7. Sources

- **Provided documents:** your message (the invite, the job-ad summary and your background). No CV, no full job ad and no interviewer profile was provided.
- **Searches and fetches:** one web search was attempted for "Lumenvale Software careers Customer Support Specialist". It was **refused** (permission not granted), so no company research ran.

**Research tier:** L1 (requested by default), searches 0 of 6, fetches 0 of 2. No result was obtained.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Values cheat sheet (section 10) not produced. The search was refused. |
| 2. `Lumenvale Software interview process customer support` | unavailable | Loop structure: persona weights rely on the relationship prior, not a confirmed loop. The search was refused. |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Company context in the grounding brief. The search was refused. |
| 4. `{interviewer name} Lumenvale Software` | n/a | No name was given, so there was no query to form. |
| 5. Representative Customer Support Specialist JD | unavailable | Would have given the requirements as quoted text. The search was refused. |

---

## 8. Upgrade menu

- The full ad text → the five requirements in section 2 become quoted `[grounded]` rows, and F3 and F4 get sourced wording.
- The interviewer's name and public role → a tailored reverse question, and persona weights read from their public footprint.
- Confirming the round is with the hiring manager, not a peer → reweights the personas (Skeptic and Case stay on top; a peer would move Peer Evaluator up).
- Allowing a web search → company values, product and support-model context, which would sharpen B2 and the reverse questions.
- A `tuesday-dossier.md` from job-underwriter → records verified evidence and the software gap as a rehearsal priority, without reprocessing this pack.
