# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Format: 30-minute video call. First pack, so no changelog.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **JD**: can you do the listed job, including its gaps
- **EXP**: do your past claims hold up under questions
- **CASE**: how you structure a live problem
- **CO**: company knowledge (not researched here; none in this pack)
- **VAL**: published values (none found; this pack has no values sheet)

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are your own summary of the ad. Quotation marks around them mean "your words", not the ad's.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (ad, your summary) | "I ran the appointment book for four physios" - your message | medium | [grounded] | transferability | Your material says the appointment book for four physios. Bridge: "I ran the appointment book for four physios." Answer slot: if you handled changes or clashes in that book, say how, in your own words; if not, say so and stay with the book you ran. |
| F2 | "booking travel" (ad, your summary) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say how; if not, say so and say how you would learn the company's booking tools. |
| F3 | "preparing documents in Word" (ad, your summary) | "I'm good with Word" - your message | medium | [grounded] | none | No gap in the quote. If asked for an example, name one document you prepared, in your own words; if you have none, say so. |
| F4 | "preparing documents in Excel" (ad, your summary) | "I'm okay with Excel" - your message | low | [inferred] | discovery | Your material does not show what you did in Excel. Bridge: "I'm okay with Excel." Answer slot: name the Excel tasks you have done, in your own words; if you have used it only at a basic level, say so and say how you would close the gap. |
| F5 | "processing supplier invoices" (ad, your summary) | "I chased unpaid invoices" - your message | low | [inferred] | transferability | Chasing invoices is adjacent to processing them, and the bridge should not be stretched. Bridge: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices, say which steps; if you only chased payment, say so and say what you would learn first. |
| F6 | working remotely (job title, "Remote") | none given | none | [grounded] | discovery | Your material does not show remote work. Answer slot: if you have worked remotely or with online tools, say which; if not, say so and say how you would keep a remote working day organised. |

Confidence grades your evidence. Provenance grades this pack's statement about it.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed the company's calendars | Inflated form of F1 | F1's quote at its own scope. Your material says the appointment book for four physios, not calendars in general. |
| Expert in Excel | Inflated form of F4 | "I'm okay with Excel", at its own scope. |
| Processed supplier invoices | Inflated form of F5 | "I chased unpaid invoices", at its own scope. |

## Persona weights

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the four listed tasks against your gaps (travel, Excel, invoices) | High: the ad lists four tasks, and your material clearly covers one | Quote-led bridges; answer slots for gaps |
| Case/Strategist | Small live problems: a double-booked room, a cancelled flight | Medium: a hiring-manager-type round prior, in a short slot | Clarify first, then sequence |
| Conversational | Opens with "walk me through your journey" and a casual Word/Excel question | High: a 30-minute call usually opens with rapport | A 90-second arc |

With no interviewer profile, these weights come from the round type and the ad alone.

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which of these four tasks would you be weakest at on day one?" | JD | [grounded] "I'm okay with Excel"; "I chased unpaid invoices" | Name the weakest task your material shows, in the quotes' words, then say how you would close it, as a plan and not a past. Answer slot: if another task is weaker for you, say which and why. | F4 and F5 are the thin spots. |
| A2 | "I don't see travel booking or invoice processing in your background. How would you handle them?" | JD | [grounded] none given (F2) | Your material does not show travel booking, so do not claim it. Answer slot: if you have arranged any travel, say what; if none, say so, and say how you would learn the booking tool. | F2 and F5 are the gaps this question names. |
| A3 | "Tell me what you do in Excel." | EXP | [grounded] "I'm okay with Excel" | Say what "okay" means for you, then name the Excel task you have done. Answer slot: if you have built anything in Excel, name it; if the most you have done is basic, say so. | F4 is the thinnest claim on the page, so expect a follow-up. |
| A4 | "You chased unpaid invoices. Did you ever process them, or only chase them?" | JD | [grounded] "I chased unpaid invoices" | Answer exactly what you did. Answer slot: if you entered, matched or approved invoices, say which steps; if you only chased them, say that, plainly. | F5 is the likeliest probe, and "only chased" is a true answer. |

### Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's 9am. Two directors want the same room, and a supplier invoice is due today. What do you do first?" | CASE | [generic] | Clarify which request is fixed and what the invoice deadline is, then move the flexible item and tell both people. | A live problem from the calendar and invoice requirements (F1, F5). No claim about your past. |
| B2 | "A director's flight is cancelled the night before. Walk me through it." | CASE | [generic] | Confirm options and any policy limit, tell the director, record the change. | The travel requirement (F2) as a live problem, not a claim. |
| B3 | "Summarise last month's supplier spend in Excel. How would you start?" | CASE | [generic] | Name the steps (export, table, sort, total) and what you would check. Answer slot: if you have built a summary like this, say so; if not, say which step you would need help with. | The Excel requirement (F4) as a live task. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey to this role." | EXP | [grounded] "I ran the appointment book for four physios"; "I chased unpaid invoices" | A 90-second arc: the clinic reception job, the appointment book, invoice chasing, and why you want this role. Answer slot: give your actual reason for moving; the pack does not supply it. | Opening rapport question; scored as the first impression of F1 and F5. |
| C2 | "What are you using in Word and Excel these days?" | JD | [grounded] "I'm good with Word"; "I'm okay with Excel" | Name what you actually use, in the quotes' words. Answer slot: name one real Word or Excel task. | Casual, but the Word/Excel requirement is scored here too (F3, F4). |
| C3 | "How do you keep a busy diary under control?" | JD | [grounded] "I ran the appointment book for four physios" | Name the method you used at the clinic, in those words. | Calendar requirement (F1), asked casually. |

Requirement coverage: managing calendars → F1, C3, B1. Booking travel → F2, A2, B2. Word → F3, C2. Excel → F4, A1, A3, B3, C2. Supplier invoices → F5, A1, A4. Remote working → none directly; covered only by A1's day-one question. This pack has 10 questions, fewer than the usual 18–26, because the call is 30 minutes.

## Reverse questions

1. "What does a normal week look like, and which of these tasks takes most of the time?" Why it lands: shows you are scoping the job.
2. "How are travel and diary requests handled today: a shared tool, or per request?" Why it lands: shows you care about process.
3. "How are supplier invoices approved, and who signs off?" Why it lands: a precise question about the invoice requirement.
4. "What would a good first month look like?" Why it lands: asks for the bar, not just the job.
5. "How do you prefer updates when someone works remotely?" Why it lands: shows you have thought about the remote part of the role.

No interviewer profile exists, so none of these ties to the interviewer's own path.

## Sources

Provided documents: the invitation email (text), your summary of the ad, and your background note.

Research tier: L1 attempted, but web search was refused by the host, so this pack ran on provided documents only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values sheet: the two search calls were refused |
| 2. Interview process, role family | unavailable | Loop structure: the same refusal |
| 3. Company strategy / recent news | unavailable | Strategy brief: not searched |
| 4. Interviewer name + company | n/a | No interviewer name was given |
| 5. Representative JD | skipped | Your ad summary already fixes the fit snapshot |

Refused queries: "Brennock Facilities Ltd"; "Brennock Facilities Ltd careers remote administrative assistant".

## Upgrade menu

- The full ad text → quotes the requirements verbatim, so the F-rows and JD questions become grounded
- The office manager's name → a tailored reverse question and a reweighted persona table
- A working search tool → the company's values, process and recent news, which would fill the values and grounding sections
- tuesday-dossier.md → one line on what it would add: a record of the gaps this prep exposed, to carry into later sessions
