# Interview prep: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Panel, Thursday, November 19, 2026, 45 minutes: Principal Dolores Vantongeren and two fourth-grade team members. Relationship assumed: the principal is the hiring authority; the team members are peers. This is a first build, so there is no changelog.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioral and values alignment
- **EXP**: work-experience deep-dive; whether what you did is what you say you did
- **JD**: role-driven; whether you can do the job, gaps included
- **CO**: company knowledge (not covered in this pass; see Sources)
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Each answer should fit in about 90 to 120 seconds. With 45 minutes and a panel of three, expect roughly six to eight of these questions, not all of them.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | Presses the gaps: fourth grade and team lead | Weight 5. The principal is the hiring authority, and the title is fourth grade. Your two stated gaps are the most likely probes | Rehearse the gap sentence until it is plain. Hold the position, then concede a specific thing |
| Peer Evaluator (team members) | Asks what you would bring to their planning and what you would need from them; seam and credit questions | Weight 4. Two peers on the panel weight this bank heavily | Reciprocity: say what you bring and what you need |
| Case / Strategist (principal) | A live problem from the role | Weight 3. The principal's second register, from the role-relationship prior | Clarify, then structure, out loud |
| Conversational (panel opener) | A biography opener and a closing "anything else?" | Weight 2. Casual questions are still scored | A 90-second arc. Choose one true point to close on |

Panel rule: each member's two top personas are blended, so the principal carries Skeptic and Case, and the team members carry Peer and Conversational.

Requirement coverage:

| Requirement | Covered by | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | A1 (JD); F1 | Met on your resume. Confirm the active date before Thursday |
| Fourth-grade teacher (invite title) | A1, B4 | F2 gap. Highest-ROI prep |
| Team lead (your stated gap; not in invite) | A3 | F4 gap |
| Other posted requirements | none, and why: no posting text was supplied | Paste the posting and this table fills in |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Say it in the quote's terms: your license is active through June 30, 2029 |
| F2 | [generic] Fourth-grade classroom teaching (role title, invite) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | high | [grounded] | capability | Words: "I haven't taught fourth grade." Then the six years, third grade, in the CV's terms. No further claim. Answer slot lives in A1 |
| F3 | [generic] Working within a grade-level team | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | Your material says the move was the grade level's, not the district's selection. Words: "For our grade level I led the move to a new reading curriculum in 2024." Wider step is an answer slot in A2 |
| F4 | [generic] Leading a team | "I've never been a team lead" (your message) | high | [grounded] | capability | Words: "I haven't been a team lead." Then F3 at its own scope. Never claim the role |
| F5 | [generic] Reading instruction | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | Words: "For two years I've run the after-school reading club." The quote already reaches reading instruction. Measures are not in the quote; see A4 |
| F6 | [generic] Family communication | "I write a weekly email to families" (your CV) | medium | [grounded] | presentation | Words: "I write a weekly email to families." What it covers is not in the quote; see A5 |

## Prohibited list

Claims this pack will not coach, and why. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Stated negative, F2 | "I haven't taught fourth grade." No slot |
| Has been a team lead | Stated negative, F4 | "I haven't been a team lead." No slot |
| Chose the school's reading curriculum | Inflated form of F3 | F3's quote at its own scope. Your material says the grade level's move, not the choice of curriculum. A2's slot stays inside the move |
| Measured or proved reading growth in the club | Inflated form of F5 | F5's quote at its own scope. Your material says you ran the club, not how its students' reading was measured. A4's slot asks only what you track |

## Question banks

### A. Principal: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role is fourth grade, and your experience is third. What would your first month look like?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've never taught fourth grade" | Open with the six years, in those words. Then the gap at its own size: "I haven't taught fourth grade." Then a plan in future tense: what you would read, review and ask first. Answer slot: if you have already looked at fourth-grade materials or standards, say which and what you saw; if not, say so plainly and say how you would start. Do not describe fourth-grade work you have not done | F2 is the gap in the title itself, and the principal scores it first. **Highest-ROI prep in this pack.** JD because it tests the role's grade level |
| A2 | "Tell me about the reading curriculum move. What did you decide yourself?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell the move in the sentence's own terms: you led the grade level's move in 2024. Answer slot: if you chose which curriculum, say why and how you decided; if the choice was the district's or the team's, say so and describe what you did lead. Use "we" for the team and "I" for your part | F3 is your strongest evidence and the likeliest place for a "who decided" probe. The quote keeps its scope: "led the move", not "chose the curriculum" |
| A3 | "You've never been a team lead. Why should we trust you to coordinate this team?" | JD | [grounded] "I've never been a team lead"; [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold: "I haven't been a team lead." Then the true point, at its own scope: the 2024 move. Hold through two follow-ups by returning to what you led and what you did not. Concede one specific thing in your own words: a coordination skill you have not yet shown as a lead. Do not claim the team role | Pressure from a stated negative. Hold, then concede specifically. Never fold on the claim that you have not led a team |
| A4 | "What do you measure in the reading club, and how would you know if it were helping?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Say what the club does, in those words. Answer slot: if you track anything, say what and how you record it; if you track nothing, say so plainly and say what you would track first. Never describe results you do not have | F5 states the club, not its measures. The material is silent on outcomes, so the answer is a slot, not a claim |
| A5 | "Tell us how you communicate with families. What do you put in the weekly email?" | JD | [grounded] "I write a weekly email to families" | Describe what the email covers, in your words. Answer slot: if a family's reply changed what you sent, say what changed; if none did, say so plainly and say how you would find out what families need | F6 is a stated practice. The probe is what it covers, which the quote does not state |

### B. Team members: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you bring to our planning, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity. Name one thing from the 2024 move you can share and one thing you would need from the team, in your words. Do not promise a planning method you have not used | Peers price what a hire costs their work. This asks for both sides |
| B2 | "Tell us about a time you disagreed with a colleague on how to teach something. How did it end?" | VAL | [generic] | Pick one real disagreement: what you and the colleague saw differently, and how it resolved. If none comes to mind, say so plainly, then say how you would handle one. The point is the seam, not a win | An open prompt from the peer register. The guidance makes no claim about your past |
| B3 | "When a team plan works, who gets the credit?" | VAL | [generic] | Say "we" for the team and "I" for what you did. Scope any credit to a sentence you stated, such as the 2024 move | Credit-sharing probe; peers test turf awareness |
| B4 | "You'd be teaching fourth grade beside us. What would you need to learn from us first?" | JD | [grounded] "I've never taught fourth grade" | Say plainly that you have not taught fourth grade. Then ask concrete questions: the unit sequence, the assessments, how the team plans. Do not describe the team's practice as known | Peer collaboration test on the gap. The question invites you to ask, not assert |

### C. Principal: Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student in your fourth-grade class is reading well below grade level by October. What do you do in the first week?" | CASE | [generic] | Clarify first: what data you have and what you would check. Then assess, plan with the team, and bring in the family. Structure out loud before answering. Scaffold only; do not cite a method you have not used | A live problem from the role. The case scores structure, not a single right answer |
| C2 | "A grade-level team has to change its reading curriculum mid-year. How would you approach it?" | CASE | [generic] | Clarify the constraints and who decides. Then the steps, the team's role, and how you would tell families. If you draw on the 2024 move, use only the steps you were part of | The case echoes your 2024 move without assuming it. Use that example only where your quote carries it |

### D. Panel opener: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell us about yourself and why this school." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've run the after-school reading club for the last two years" | About 90 seconds: six years in third grade, the 2024 reading move, the reading club, the weekly family email. For why this school, answer slot: say the reason in your own words; the material does not give one | Casual openers are scored as first impressions. The arc uses only quoted sentences |
| D2 | "What's something you'd want us to know that we haven't asked?" | VAL | [generic] | Choose one thing from the quotes you are sure of and say it plainly. Do not add a story you have not rehearsed | Closing opener. You choose the instance |

Count: 13 questions. That is below the 18 the rubric targets, because no posting text was supplied to generate JD questions. The upgrade menu says what would add them.

## Reverse questions

Each has a "why it lands." One is reciprocity, because the panel includes peers.

1. "What does the fourth-grade team's planning look like from week to week?" Why it lands: it shows you are planning to join the team, not only to teach.
2. "What would a new teacher on this team do in the first month that would genuinely help?" Why it lands: reciprocity. It asks the peers what they need, which is what B1 asks you to offer.
3. "What has the school prioritized for reading this year?" Why it lands: it ties your reading-club and curriculum experience to the school's current direction.
4. "How does the principal support a team that is working through a curriculum change?" Why it lands: it tests the team-lead gap from the other side, and shows you think about support, not only performance.
5. "What would success look like at the end of the first semester?" Why it lands: it turns the fourth-grade gap into a shared, measurable goal.
6. "How does family communication currently work across the fourth-grade team?" Why it lands: it shows you already think about F6 as a team practice, and gives you the team's actual pattern to build on.

## Sources

- Provided documents: the interview invite (pasted); your resume summary (pasted); your message, which includes the two gap statements.
- No search or fetch was run in this pass.

**Research tier: L0**, searches 0 of 0, fetches 0 of 0 (provided documents only).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering Elementary or Orrinsford values | unavailable | Values section (would apply only if a values round is detected). Not run in this pass |
| 2. Orrinsford interview process for teacher roles | unavailable | Loop structure and persona weights. Not run in this pass |
| 3. Orrinsford current reading or strategy news | unavailable | Would change A4 and reverse question 3. Not run in this pass |
| 4. Principal or team member public footprint | n/a | No names were given beyond the principal's name, and school staff profiles are often thin; without a search query the interviewer read is absent |
| 5. Representative Fourth Grade Teacher posting | unavailable | Would give JD questions beyond the invite's single requirement. Not run in this pass |

## Upgrade menu

- The posting text → the coverage table's uncovered rows get JD questions, and the [generic] rows become [grounded] where the posting quotes them.
- L1 research (the district's values, its interview process, a representative posting) → a values section and loop structure, if the process shows one.
- The principal's and team members' names → persona weights per member. Public professional footprint only.
- The panel's question list or a recruiter email → coverage of anything it names.
- Your prep time before Thursday → a prioritized schedule.
- A tuesday-dossier.md would add verified evidence and a strategy constraint for each weak area.
