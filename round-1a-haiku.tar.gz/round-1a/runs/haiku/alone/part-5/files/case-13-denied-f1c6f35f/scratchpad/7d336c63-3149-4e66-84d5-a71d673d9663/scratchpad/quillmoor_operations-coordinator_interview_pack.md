# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30 minutes by phone, Thursday 19 November at 2pm, with Hannah Lowther (Talent Partner). She will ring the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, the hybrid pattern, what's prompting the move, then the team and next steps.
**Changelog:** first version.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is scored: JD (the role's own terms), EXP (your past and your claims), CASE (a live problem), VAL (values), CO (company knowledge).
- Guidance is scaffolding, not a script. Answer slots are instructions for the interview, in your own words. Where your material is silent, the pack says so rather than filling the gap.
- **Before Thursday, in this order:** (1) know your notice period, (2) settle your salary line, (3) rehearse B3. B3 is the question most likely to test the two gaps the advert names, SAP and production scheduling. It is the highest-return prep here.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | high | [grounded] | none | No gap. Say it as written: four years as a logistics coordinator. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | high | [grounded] | presentation | Your sentence already reaches the supplier and late-order work in other terms. Keep to what you wrote: you schedule deliveries for three depots and chase suppliers when orders slip. Add no figures. |
| F3 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | medium | [grounded] | presentation | The quote shows a spreadsheet you rebuilt. The advert asks for a level of confidence, which your message does not state, so do not claim one. Answer slot: if particular Excel features were part of that rebuild, name them in your own words; if you would rate yourself differently, say so. |
| F4 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | none | [grounded] | capability | Words: "I've never used SAP. We run our own in-house stock system." Then how you would learn an ERP, said as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F5 | "coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [inferred] | transferability | Your quote is delivery scheduling across depots. It does not reach production planning or QA, so the bridge stays at delivery scheduling. Answer slot: if you have worked to a production plan or with a quality team, say how; if you have not, say so plainly and say how you would learn the production side. |
| F6 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you produced a regular report on deliveries or dispatch, say what it measured; if you did not, say so plainly and say what you would track first. |
| F7 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | presentation | Bridge in the quote's own terms: discrepancies fell by about a third over a year. The figure raises the defend-the-number slot in C1. |
| F8 | "two days a week at our Avonmouth site in Bristol" (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | high | [grounded] | none | Say it as your message does: two days is fine; three is your limit. |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | A figure you gave for the job's terms. It fills logistics slot B1 and raises no defend slot. |
| F10 | "your notice period" (Hannah's message) | none given | none | [grounded] | discovery | Your material does not state a notice period. Logistics slot: give your actual notice period as your contract states it. The pack supplies no figure. |
| F11 | "what's prompting a move" (Hannah's message) | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | high | [grounded] | none | Say it as written: the Bristol office closes next year, the only offer is relocating to Reading, and you don't want that. |

**Reading the snapshot:** F4 and F5 are the gaps the advert presses on. F3 and F7 are the strongest evidence you have, and F7's figure is the one a prober will test. F10 is the only logistics item with no figure from you yet.

## Prohibited list

These claims are not coached anywhere in this pack. Each one stretches a sentence you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Built the in-house stock system | Inflated form of F3 and F7 | F3's quote at its own scope. Your material says a spreadsheet you rebuilt, not the stock system the company runs. |
| Cut discrepancies by a third | Inflated form of F7 | F7's quote: discrepancies fell by about a third over a year. Your material does not say what caused the fall or whose work it was. |
| Managed supplier relationships | Inflated form of F2 | F2's quote: you chase suppliers when orders slip. |
| Experience with production planning or QA | Inflated form of F5 | F5's quote, at delivery-scheduling scope. |
| Advanced Excel | Inflated form of F3 | "I rebuilt our stock-count spreadsheet." No level is stated. |
| Some SAP experience | Negative you stated, F4 | Plain acknowledgment: "I've never used SAP." No slot. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Conversational / Rapport | Friendly walk-through, "what drew you to us" | High. A recruiter screen's default register is conversational, and the casual questions are still scored. | A 90-second arc from your quotes; treat casual questions about the advert's terms as scored | 4 questions |
| Skeptic (light) | Knockout checks on pay, notice and SAP | High. Hannah's agenda names pay and notice, and F4 and F5 are visible in the snapshot. | Hold the honest gap; bridge only from sentences you wrote | 3 questions |
| Data-Driven Prober (light) | "How was that a third counted?" | Low to medium. Recruiters rarely probe, but the figure is on your message and is the easiest one to test. | Say what you know and what you don't | 2 questions |
| Pressure | "Why you over someone who has used SAP?" | Low to medium. A screen can test whether you hold a position. | Pause, hold, then concede one specific point | 2 questions |

**Session total: 11 questions.** Below the 18 to 26 a full loop would carry, because a 30-minute screen cannot rehearse more. The coverage line below shows what each requirement touches.

## Question banks

### A. Conversational / Rapport (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message); "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Ninety seconds in four beats, each from your own quotes: the four years as a logistics coordinator; scheduling deliveries for three depots; chasing suppliers when orders slip; rebuilding the stock-count spreadsheet. End on "about a third over a year" and stop. | F1, F2 and F7 are the spine of your story, and this opening is the one a screen is most likely to ask. EXP because it tests what you did. |
| A2 | "What do you know about Quillmoor, and what's drawing you to this role?" | JD | [grounded] "diagnostic-test manufacturer, about 400 staff" (the advert); "coordinate production schedules between planning, the warehouse and QA" (the advert) | Name two things from the advert in its own words: the sector and size, and the planning, warehouse and QA coordination. Answer slot: your reason for applying, in your own words. Your material does not say what draws you to Quillmoor. If it is the content of the role, say which part. If it is the Avonmouth site or the pay, say that. | Motivation is scored, and the advert is your only source, so the answer should come from it. JD because the question scores the role. |
| A3 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | Say the fact as written: the Bristol office closes next year, the only offer is relocating to Reading, and you don't want that. Then say what you are looking for: a role you can do from Bristol. Do not add reasons behind the closure or any account of how the decision was made; you have not stated them. | F11 is your stated reason, and its scope ends at the closure and the relocation offer. Hannah asked directly, so this is the most likely probe. |
| A4 | "How do you feel about the hybrid pattern, two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Two days is fine from north Bristol; three is your limit. Nothing more. | F8. The pattern is a filter term she will check, so the answer should match your note exactly. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." (your message); "£38,000–£44,000" (the advert) | Logistics slot: state your figure in your own words. Your note says £42,000. Or name the alternative: ask first what the band is. Justify the figure only with history you have stated; you have given none. | F9. A figure you gave raises no defend slot. Pay is the first topic on her list. |
| B2 | "What's your notice period?" | JD | [grounded] "your notice period" (Hannah's message). No notice figure given. | Instruction: give your actual notice period as your contract states it. If you are not sure of the figure, say you will check and confirm it. Do not guess. | F10. Her topic, with no figure from you yet, so the slot stays open. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "ERP experience (SAP or similar) a plus" (the advert); "coordinate production schedules between planning, the warehouse and QA" (the advert); "Never used SAP — we run our own in-house stock system." (your message) | **Highest-return prep in this pack.** Hold: "I've never used SAP. We run our own in-house stock system." Then the plan: how you would learn an ERP, and what the stock-count work gives you to start from. Hold through two follow-ups by returning to the stock system and your plan. Never claim SAP or production-side work. If the probe is production planning or QA, the answer slot: if you have worked to a production plan or with QA, say how; if not, say so plainly and say how you would learn it. Concede the specific gap once, then return to the plan. | F4 and F5 are the two gaps the advert names most, and this is the objection a screen is most likely to contain. The gap is not hidden in the pack, so it gets the deepest rehearsal. |

### C. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was that third counted, and which part of it was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Defend-the-number. Say how the discrepancies were counted, in your words. Name the assumption you would defend least. If you do not know how the count was made, say so. Then say which part was yours: the rebuild. Do not reconstruct a method. Answer slot: if you tracked the figure yourself, say how; if you did not, say so. | F7 is the headline figure, and figures are what probers test. Attribution is the point: what was yours and how you know it. |
| C2 | "Walk me through what that spreadsheet does." | EXP | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Describe it in your own words: what it records and what it is used for. Answer slot: if you used particular Excel features in the rebuild, name them; if you did not, describe what you did with the spreadsheet. | F3 is medium confidence because no level is stated. This tests the Excel claim without asserting one. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we consider you over someone who has used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message); "I schedule deliveries for our three depots" (your message) | Hold: you have not used SAP, and what you do bring is the delivery scheduling and the stock count, in those words. Hold through two follow-ups; concede the SAP gap once, specifically; do not fold on the claim that the stock work is relevant. | The sharpest version of the knockout, and a pressure question because it tests composure under a direct comparison. |
| D2 | "If we offered you £38,000, what would you do?" | JD | [grounded] "I'm hoping for £42,000." (your message); "£38,000–£44,000" (the advert) | Logistics slot, choice between named options: say what you would need before deciding, such as the reason for the figure or the full package, or say the figure is below your range. Do not commit to a number on the call. | Tests whether you hold your figure under a lower offer. The band is the advert's; your range is yours to state. |

### Coverage line

| Requirement (advert) | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1 |
| Track supplier deliveries and chase late orders | A1, D1 |
| Keep stock records accurate | C1 |
| Coordinate production schedules between planning, warehouse and QA | B3, A2 |
| Weekly on-time dispatch reporting | B3 (answer slot, F6); no question of its own, because the screen will not reach reporting detail |
| Confident with Excel | C2 |
| ERP (SAP or similar) a plus | B3, D1 |
| Hybrid, two days at Avonmouth | A4 |
| £38,000 to £44,000 | B1, D2 |
| Notice period and reason for moving (Hannah's topics) | B2, A3 |

## Reverse questions

1. **"What does a typical week look like, and where does the role sit between planning, the warehouse and QA?"** Why it lands: it shows you read the advert's three-way coordination and asks for the real shape of it.
2. **"How much of the day-to-day runs in SAP, and what training would someone from a non-SAP stock system get?"** Why it lands: it asks about the gap you named, and the answer tells you how large it is.
3. **"What is the weekly on-time dispatch report used for, and who reads it?"** Why it lands: it links the reporting line in the advert to a decision.
4. **"Is the two-day pattern set by the team, or flexible within the week?"** Why it lands: it covers the hybrid term in one question and shows you read the policy.
5. **"If this goes well, who would I meet next, and what would they want to see?"** Why it lands: she is covering next steps, so you ask first and listen for the stage names.

## Sources

- **Provided documents:** your message (your background and terms), Hannah Lowther's LinkedIn message, and the advert.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. No search or fetch was run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | skipped | No values cheat sheet. No values-style round is detected, and Hannah's message names none. |
| 2. Interview process | skipped | Her message gives the call's structure: five topics in 30 minutes. A loop structure would matter only for later rounds. |
| 3. Strategy / recent news | skipped | Judged not worth a search for a screen. The advert and her message fix the questions. A strategy brief would sharpen A2. |
| 4. Hannah Lowther public footprint | skipped | A recruiter's public footprint would not change any answer here. No interviewer read is included. |
| 5. Representative JD | skipped | The advert was supplied. |

## Upgrade menu

- Your notice period → B2 stops being a slot and becomes a line you can say.
- Your Excel level, or which functions you used → C2 and F3 can move from medium to high confidence.
- The hiring manager's name, if you know it → personalised reverse questions and a reweighted persona table for the later rounds.
- A research pass at the L1 tier (about six searches) → Quillmoor's current values, recent news and the process beyond this call. Worth it if there is a second round.
- Hannah's prep email, if she sends one → coverage of any focus areas she names.
- A `tuesday-dossier.md` → verified evidence and any limits added to the fit snapshot, graded by a second pass.
