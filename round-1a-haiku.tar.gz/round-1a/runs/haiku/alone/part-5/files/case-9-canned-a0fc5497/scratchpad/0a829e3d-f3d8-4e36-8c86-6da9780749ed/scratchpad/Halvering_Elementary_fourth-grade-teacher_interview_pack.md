# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Organisation:** Orrinsford Community School District
**Format:** 45-minute panel interview, Thursday
**Panel:** Principal Dolores Vantongeren (hiring authority) and two fourth-grade team members (names not given)
**Built on:** the invite and your resume. No job description, no research (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: **EXP** (your experience, tested for accuracy), **JD** (the listed job, including its gaps), **CASE** (a live problem), **VAL** (values), **CO** (company knowledge).
- Guidance is scaffolding, not a script. Say it in your own words and stop where the guidance stops.
- Answer slots (*Answer slot:*) are instructions for the interview. They are not questions to me.

## Fit snapshot

The requirement column quotes the invite. Only the invite's license line is a stated requirement; the rest is inferred from the role title and panel makeup and marked as such.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029." — your CV | medium | [grounded] | none | No gap. Confirm the status on your ISBE record before Thursday, since the invite makes it a condition. |
| F2 | "Fourth Grade Teacher" (invite, role title) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [grounded] | transferability | The quote carries third grade, not fourth. Words: "I taught third grade for six years." Answer slot: name one thing about third grade that carries into fourth, and one thing you would check on arrival that you have not seen yet. |
| F3 | "Fourth Grade Teacher" (invite, role title) | "I've never taught fourth grade" — your CV | high | [grounded] | capability | A stated absence, so it can be said plainly. Words: "I haven't taught fourth grade." Then how you would learn it, as a plan. Never a past claim. |
| F4 | Leading curriculum decisions with grade-level colleagues (role-family, not in the invite) | "I led our grade level's move to a new reading curriculum in 2024." — your CV | medium | [generic] | none | No gap against the requirement. Keep the quote's scope: you led the move. It does not say you chose the curriculum or led a team. |
| F5 | Working as a member of a grade-level team (implied by a panel of fourth-grade team members) | "I've never been a team lead." — your CV | high | [inferred] | capability | A stated absence. Words: "I've never been a team lead." Then your account of working with colleagues on shared decisions, using the F4 quote. |
| F6 | Reading instruction (role-family, not in the invite) | "I've run the after-school reading club for the last two years." — your CV | medium | [generic] | none | No gap. The club is extracurricular; say so when you describe it. |
| F7 | Communicating with families (role-family, not in the invite) | "I write a weekly email to families." — your CV | medium | [generic] | none | No gap. Describe what the email covers in your own words. |

## Persona weights

| Persona | Who | Weight | Why |
|---|---|---|---|
| Skeptic | Principal | 4 | Hiring authority; the two gaps (F3, F5) are the obvious staffing risk, so expect them to be tested. |
| Peer Evaluator | Team members | 4 | Fourth-grade colleagues price what a new hire adds to their load and how they would decide things together. |
| Case / Strategist | Principal | 3 | Principal will want to see how you would plan for a grade you have not taught. |
| Data-Driven Prober | Team members | 3 | Your CV lines (club, email) invite "how did you know" questions. |
| Conversational | Opener | 2 | Opening biography question is casual but scored. |
| Pressure | Any member | 2 | Timed panel: a short challenge to the fourth-grade gap is likely. |

Weights come from relationship priors (hiring manager and peer), not from interviewer profiles, since none were supplied.

## Prohibited claims

Each entry is a wording this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have taught fourth grade" / "I know the fourth-grade standards" | Inflated form of F2 | "I taught third grade for six years." and, as a stated absence, "I haven't taught fourth grade." |
| "I was a team lead" / "I led the grade-level team" | Inflated form of F4 and F5 | "I led our grade level's move to a new reading curriculum in 2024." and "I've never been a team lead." |
| "I chose the new reading curriculum" | Inflated form of F4 ("led the move") | The F4 quote at its own scope. Your material says you led the move, not that you selected the curriculum. |
| "Families responded to my weekly email" / "my readers improved" | Outcome not in your material | "I write a weekly email to families." Describe what you do; leave outcomes to what you can show. |

## Question banks

### Principal (Skeptic, Case / Strategist), weight 4 and 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've taught third grade. What would you need to learn before you could teach fourth grade well?" | JD, EXP | [grounded] "I haven't taught fourth grade." (F3); [grounded] "I taught third grade for six years." (F2) | **Highest-ROI prep in this pack.** Start with the plain acknowledgment: "I haven't taught fourth grade." Then the bridge: "I taught third grade for six years." Name what you would learn first and how: which fourth-grade standards the team uses, what students arrive knowing, and the team's current units. *Answer slot:* name one thing from third grade that carries into fourth. Hold through two follow-ups by returning to the plan. Concede plainly: "I'd be learning the content as I go, with the team." | F3 is the largest gap and the most likely objection from a principal staffing a grade. Deepest rehearsal because it will come up in some form. |
| B2 | "The team works closely together on shared decisions. Have you led a team?" | JD | [grounded] "I've never been a team lead." (F5); [grounded] "I led our grade level's move to a new reading curriculum in 2024." (F4) | Say the plain acknowledgment: "I've never been a team lead." Then bridge with F4 at its own scope: "I led our grade level's move to a new reading curriculum in 2024." *Answer slot:* describe the part of the move that was yours to decide, in your own words; if you were not the one deciding, say so and describe how you worked with colleagues. Do not stretch F4 into team leadership. | F5 is a stated gap the panel is likely to test directly. Answer with the limit stated first. |
| B3 | "Our fourth graders are moving to a new unit sequence next fall. How would you plan the first six weeks with the team?" | CASE | [generic] | Clarify first: what the team already has, what is assessed, and where students stand now. Then structure: meet the team, check incoming skill levels, agree on sequence and assessments. Name one risk and what you would do about it. This question makes no claim about your past. | Live problem from the role; tests whether you can plan a grade you have not taught without pretending to know it. |
| B4 | "Your reading group is struggling with comprehension, but the grade's common assessment looks fine. What do you do?" | CASE | [generic] | Diagnose before changing anything: check whether the assessment measures what the group is struggling with, then look at a few student responses. Say what you would take to the team. | Tests reading judgment and collaboration with the team. |

### Team members (Peer Evaluator, Data-Driven Prober), weight 4 and 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the move to the new reading curriculum went in your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (F4) | Story-mapped on F4: the move and the year, in those words. *Answer slot:* if anyone on the grade level disagreed, describe how it was handled; if no one did, say so plainly. Stay with what you led. | F4 is your nearest evidence for working with grade-level colleagues; peers will ask how the decision was made. |
| A2 | "Where do you expect us to disagree with you, and how would you raise it?" | CASE | [generic] | Name one kind of disagreement you would expect (pacing, assessments, texts) and the first thing you would do: ask what evidence the team is working from. | Peer seam question; tests how you handle disagreement with equals. No claim about your past. |
| A3 | "On a grade-level team, when have you contributed to a decision you did not lead?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024." (F4); [grounded] "I've never been a team lead." (F5) | Open prompt. Pick a shared decision you contributed to. *Selection criteria:* a decision made with colleagues, your input on it, and an outcome you can describe. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reading curriculum move. | Peers want to know how you work when you are not in charge; this is where F5 is tested from the other side. |
| A4 | "How did you know the reading club was working? What did you measure?" | EXP | [grounded] "I've run the after-school reading club for the last two years." (F6) | Say what you observed and what you tracked, in your own words. *Answer slot:* if you tracked something, name it and how you counted it; if you tracked nothing, say so plainly and say what you would track. Never describe a measure you did not use. | Data-Driven Prober: a club is easy to describe and hard to defend without measures. |
| A5 | "Your weekly family email: how do you know families read it, and what changed because of it?" | EXP | [grounded] "I write a weekly email to families." (F7) | Describe what the email covers and how you send it. *Answer slot:* if you saw any response, say what; if not, say so plainly. Do not claim an effect you did not observe. | Peer probe on the one communication CV line; tests whether you can separate activity from outcome. |

### Opener and pressure, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk us through your six years in Joliet." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." (F2) | 90-second arc: where you taught and at what grade, then one story from the reading curriculum move (F4) and one from the reading club (F6). End on what you want to do next with fourth grade. | Casual opener that is still scored; the arc avoids drifting into unbounded biography. |
| D1 | "Sixty seconds: why should we hire you over someone who has taught fourth grade?" | JD | [grounded] "I haven't taught fourth grade." (F3); [grounded] "I taught third grade for six years." (F2) | Hold the position: the reading curriculum move (F4) and six years of classroom teaching (F2) are what you bring. Concede the gap in one sentence: "I haven't taught fourth grade." Do not fold on the core claim. | Time-boxed challenge to F3; tests composure, not content. |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | F1; no question | Gate shown met by your CV. Confirm the status before Thursday. |
| Fourth-grade teaching (role title) | B1, D1, F2, F3 | Largest gap; deepest rehearsal on B1. |
| Working on a grade-level team (panel makeup) | B2, A1, A3 | Largest second gap (F5). |
| Reading instruction (role-family) | A4, C1 | Extracurricular only; say so. |
| Family communication (role-family) | A5 | Activity, not outcome. |

## Reverse questions

Each one has a reason it lands with this panel.

1. "What would you expect a new fourth-grade teacher to have finished in the first month?" *Why it lands:* it turns B1's gap into a planning conversation and shows you are already thinking about the grade.
2. "How does the fourth-grade team decide on shared units and assessments?" *Why it lands:* the team members are on the panel, so this asks them about their own decision-making.
3. "What has the fourth-grade team changed in the last year, and what is still open?" *Why it lands:* shows you want the current picture, not a brochure.
4. "What does a strong first year look like in this role, from your side, Principal Vantongeren?" *Why it lands:* asks the hiring authority directly for the success measure, which the answer to B1 can then address.
5. "Which reading supports are in place for fourth graders, and where do they need the most help?" *Why it lands:* connects to A4 and C1 and invites a conversation about reading, where you have real material.
6. Reciprocity, for the team members: "What would you need from a new colleague in the first term?" *Why it lands:* turns the peer seam into a question about what you bring to their load.

## Prohibited claims, applied

The list above binds every guidance cell in this pack. If a rehearsed answer starts to drift toward "I taught fourth grade" or "I led the team," return to the quote in the fit snapshot.

## Sources

- **Provided documents:** the invite from Human Resources, Orrinsford Community School District; your resume.
- **Research tier: L0.** No search or fetch was run. Step 1 would have offered the default tier, but no job description was supplied, so the research question gave way to the upgrade menu.
- **Target accounting:**
  - Official school or district values: skipped (L0).
  - Loop structure for the role: skipped (L0).
  - Recent strategy or district news: skipped (L0).
  - Principal's public footprint (Dolores Vantongeren): skipped (L0). Not searched; a public-footprint check is an upgrade-menu item.
  - Representative job description: skipped (L0), since the JD was not supplied.

## Upgrade menu

- The full job description → turns F4 and F5 into `[grounded]` rows, and adds a JD-tagged question for each stated requirement.
- A demo lesson or written task announced for Thursday → a build section for the deliverable.
- Principal Dolores Vantongeren's public footprint (L1) → a tailored reverse question and persona weights read from public material.
- The HR contact's note on focus areas or the panel format → covers any stated focus, including whether the panel will score specific competencies.
- Research on the district's published values (L1) → a values cheat sheet if the panel runs a values-style round.
- A `tuesday-dossier.md` from a prior session → would record the gaps F3 and F5 for later sessions.
