# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Status:** Conditional. Hold until the invite is verified (see the warning in your message). Research tier: L0, provided material only. No company research was run, so nothing here about Brennock's values, loop or strategy is verified.

**Format:** 30-minute video call with the office manager (from the invite).

## 1. Fit snapshot

Sources: the job ad as you summarised it, and your background as you stated it. Confidence: [grounded] = your own words; [inferred] = a bridge I built from them.

| Requirement (ad) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Managing calendars | "where I ran the appointment book for four physios" | [grounded] | Transferable | "I managed a shared calendar for four clinicians, so I'm used to competing priorities and double-booking risk." |
| Booking travel | none stated | n/a | Unevidenced | "I haven't booked travel for a team. What I do have is planning around fixed times and rebooking when plans change, which I can show you." |
| Word and Excel documents | "good with Word, okay with Excel" | [grounded] | Partial on Excel | "I'm strong in Word. In Excel I'm comfortable with the core tasks and I'd tell you where I'd need to upskill." |
| Supplier invoices | "chased unpaid invoices" | [grounded] | Direction differs | "I've chased unpaid invoices, so I know how payments and records fit together. I haven't processed supplier invoices, so I'd learn your process first." |

## 2. Prohibited claims (built locally, binds every answer below)

- Do not claim you have booked business travel for others.
- Do not claim advanced Excel skills. Stick to "okay".
- Do not claim you have processed supplier invoices for payment. You chased customer payments; say so.

## 3. Interviewer read

No interviewer profile was provided, so this section is generic. A 30-minute call with an office manager usually focuses on day-to-day practicality: can you handle the admin load, do you ask questions, can you work with little supervision.

## 4. Persona weights (round-type priors)

- **Office manager, practical:** high weight. Expect scenario and "how would you" questions.
- **Skeptic:** medium weight. Expect probing on travel and invoices, the two gaps.
- **Pressure:** low to medium. A short call means a few hard questions, not a grilling.

## 5. Question banks

Question types: Behavioural, Scenario, Skeptic, Reverse.

### Bank A: Practical (office manager)

| ID | Question | Type | Guidance (90 to 120 sec) | Provenance |
|---|---|---|---|---|
| A1 | Tell me about your admin experience. | Behavioural | Lead with the appointment book for four physios. Name the scale, what you tracked, and one time you fixed a double-booking. | Provenance: your words. "where I ran the appointment book for four physios" |
| A2 | How would you handle two managers asking for the same meeting slot? | Scenario | Name the priority rule you'd ask about first, then check both calendars and propose options. Do not claim a tool you haven't used. | Provenance: generic scenario, not from your CV. |
| A3 | How comfortable are you with Excel? | Skeptic | "Okay" is accurate. Name the tasks you can do and the one you'd need to learn. | Provenance: your words. "okay with Excel" |

### Bank B: Skeptic (the two real gaps)

| ID | Question | Type | Guidance | Provenance |
|---|---|---|---|---|
| B1 | Have you booked business travel before? | Skeptic | Answer honestly: not for a team. Bridge to planning fixed-time bookings and rebooking. Do not imply experience you lack. | Provenance: your gap, quoted in the fit snapshot. |
| B2 | You've not processed supplier invoices. How would you learn? | Skeptic | Say you chased unpaid invoices and know how payment records fit together. Name how you'd learn their approval and filing process. | Provenance: your words. "chased unpaid invoices" |

### Bank C: Reverse questions (ask them)

- What does a typical week look like in this role, and what share is travel and invoices? (Why: exposes real scope.)
- How is the role supported when the office manager is away? (Why: shows how much independence is expected.)
- Who approves supplier invoices, and what system is used? (Why: checks whether the invoice work is real.)

## 6. Values cheat sheet

Skipped. No company values were researched or provided.

## 7. Upgrade menu

- **Company's own careers page or job board listing:** confirms the role exists and gives the real duties. Unlocks checked, [grounded] requirement rows.
- **Full job ad text:** replaces my summary, so the fit snapshot can quote it directly.
- **Interviewer name (if given in the invite):** personalises the interviewer read and reverse questions.
- **Recruiter guidance:** whether they want a short task or a specific skill demonstrated.
- **`tuesday-dossier.md`:** would add verified evidence and prohibited-claim constraints from a dossier.
