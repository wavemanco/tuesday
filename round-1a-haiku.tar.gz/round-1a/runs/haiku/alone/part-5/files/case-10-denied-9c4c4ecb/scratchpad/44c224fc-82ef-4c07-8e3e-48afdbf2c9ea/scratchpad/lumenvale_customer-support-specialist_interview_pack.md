# Interview prep pack: Customer Support Specialist, Lumenvale Software

Round: text-chat interview on Telegram with the support team lead (interviewer name not yet known). Arranged by Marcus Hale, talent team. Relationship read as hiring-manager type: the team lead is buying support capability and checking gaps.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = a job-ad requirement; **EXP** = what your past work actually shows; **CASE** = a live problem from the role; **CO** = company knowledge (not covered here, see Sources); **VAL** = company values (not covered here).
- Guidance is scaffolding, not a script. Written chat means you can pause and draft, so practise typing your answers out, then cutting them to what you did.

## Fit snapshot

Your message is the only evidence source. Each "Evidence" cell holds only words you wrote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as summarised in the request) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | Lead with the years and the role in your own words. Expect a probe on whether energy-supplier advice counts as support. |
| F2 | "experience with Zendesk or similar ticketing tool" (job ad) | "I use Freshdesk every day" (your message) | high | [grounded] | transferability | Freshdesk is a similar ticketing tool, and the ad allows "similar". Zendesk is not in your material. Answer slot: if you have used Zendesk, say where and how; if not, say so and name which Freshdesk work maps across. |
| F3 | "clear written communication" (job ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume shows you write a lot, not how clearly. Answer slot: name one email you sent that had to be clear, and what the customer needed from it. Today's chat is also a written sample. |
| F4 | "confidence handling escalations" (job ad) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | Training on refunds is adjacent to escalations, not the same thing. Answer slot: if any refund or complaint went beyond your own authority, say what you did with it; if none did, say so and say how you would decide. |
| F5 | Company background (not a job-ad requirement) | "I've never worked for a software company." (your message) | none | [grounded] | capability | A gap you have stated. Words: "I haven't worked for a software company." Then how you would learn their product, as a plan, not as past experience. |

Gap types above follow the routing rule in the skill: a row is `transferability` where your evidence is adjacent, `discovery` where your material is silent, and `capability` where you have stated the gap.

## Persona weights

| Persona | Weight | Why this weight | How it shows up in text chat |
|---|---|---|---|
| A. Skeptic | 5 (top) | Hiring-manager prior. Freshdesk vs Zendesk and no software background are the two gaps the team lead will test. | Short, pointed follow-ups: "and what would you do on day one?" |
| B. Case / Strategist | 4 | Support leads score live reasoning on escalations and refunds. | A scenario typed out, then they watch how you clarify first. |
| C. Pressure | 3 | Composure under challenge, even in text. | A blunt one-line challenge to a claim you just made. |
| D. Conversational | 3 | Casual openers still score communication economy. | "So, walk me through how you got here." |
| E. Data-Driven Prober | 3 | You quote a daily volume and Freshdesk use; both invite a "how do you know" check. | "How was that 60 a day counted?" |

No interviewer profile was supplied, so weights are relationship priors only.

## Question banks

Provenance: each row lists the label first, then the candidate's own sentences the guidance rests on.

### A. Skeptic (weight 5)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Your background is customer service advisor, and this is a customer support role. Why is that the same work? | JD, EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Name the role, the channels (calls and emails) and the daily volume, as you stated them. Let the team lead judge the equivalence. Do not claim support-desk experience you did not state. (~90s) | F1. The JD's "2+ years" line is the first thing a skeptic checks. |
| A2 | The role asks for Zendesk or a similar tool, and you use Freshdesk. Walk me through how you would be productive in Zendesk on day one. | JD | [grounded] "I use Freshdesk every day" | Answer slot: if you have used Zendesk, say where and how, in your own words. If you have not, say that Freshdesk is the tool you use every day, then name the ticket work that carries across (ticket triage, replies, status updates). Then the plan: what you would check first in Zendesk. Do not describe Zendesk features you have not used. | F2. **Highest-ROI prep in this pack.** The team lead will almost certainly ask about the tool gap in some form. Rehearse the plain statement and the learning plan until they sound natural. |
| A3 | You have never worked for a software company. Why should we believe this will translate? | JD, EXP | [grounded] "I've never worked for a software company." | Say it first: "I haven't worked for a software company." Then one thing that carried over, from your own material: the daily volume of customer contact. Hold that point through two follow-ups. Concede only what is true: you would learn the product. | F5. This is the most likely cross-examination of the background. Hold, then concede specifically. |
| A4 | Show me clear writing. Tell me about one customer email you sent that had to be clear. | JD, CASE | [grounded] "answering around 60 calls and emails a day" | Pick one email from your daily work. Say what the customer needed to understand and what you wrote to make that clear. Answer slot: if no single email comes to mind, say so, and say what you do to keep emails clear. | F3. The chat itself is a written sample; keep this answer short. |
| A5 | You trained four new starters on refunds. How did you know they had got it? | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you checked their understanding (a test, a shadow shift, a review), say how. If you did not formally check, say so and say what you did instead. | F4. Training is the nearest thing to team-lead-style judgment in your material. Do not inflate it into escalation handling. |

### B. Case / Strategist (weight 4)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | A customer says their refund was approved last week and has not arrived, and they are threatening to leave. Type your first reply and say what you would check first. | CASE | [generic] | Clarify before answering: the order or refund reference, the approval date, the payment method. Then say what you can promise and what you would escalate. Keep the reply short and specific. | F4. Escalation judgment under a live problem. The refund is a plausible case, not your history. |
| B2 | The same bug appears in three tickets this week. What do you do with that? | CASE | [generic] | Name the pattern, the number of contacts, and who you would tell (a senior or the product owner). Say what you would tell the customer now and what you would not promise. | JD escalation line. Scored on judgment, not on a past event. |
| B3 | Our team's tool is Zendesk. Which parts of the work would you learn first? | JD | [grounded] "I use Freshdesk every day" | Name the daily ticket work you know from Freshdesk, then the parts you would learn first in Zendesk. A plan, not a claim. | F2. Turns the tool gap into a learning plan. |
| B4 | Give me your escalation criteria in 60 seconds. When does a ticket go up? | JD | [generic] | State three or four criteria in your own words (repeat contact, money at risk, a customer who cannot wait, a fault you cannot fix). Say who you escalate to. Do not claim a policy you have not seen here. | JD escalation line. Scored on clarity, which is also what the chat tests. |

### C. Pressure (weight 3)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Sixty contacts a day sounds like volume, not quality. How much of that work was actually you? | EXP | [grounded] "answering around 60 calls and emails a day" | Hold: the volume was your work. Concede only what is true: if quality was measured, say what it was; if it was not, say so. | Premised on the volume you stated. Keep the answer to what you counted. |
| C2 | The role depends on confident escalation handling. What escalation have you handled, and what did you do? | JD, EXP | [grounded] "I trained four new starters on our refunds process last year" | Open prompt. Your material does not show an escalation you handled. Answer slot: if one comes to mind, tell it in your own words. If none does, say so plainly, then give the nearest thing you have: the refunds process you taught, and how you would handle a refund escalation. | F4. The honest branch is the answer. Do not invent an escalation. |
| C3 | How much of that refunds process was yours to design, and how much was already set? | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you shaped any of the process, say which part and how. If it was set by the company, say so and say what you added in training. | Premised on the process you taught. Keeps the credit honest. |

### D. Conversational (weight 3)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | So, walk me through how you got into customer support. | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | 90-second arc: energy supplier, the daily volume, Freshdesk, training four starters, and why this role. For the last part, give your own honest reason. | Casual openers are scored. Rehearse the arc so it runs in under two minutes typed. |
| D2 | What do you actually do in Freshdesk day to day? | EXP | [grounded] "I use Freshdesk every day" | Name the actions you do: replies, status changes, notes, handoffs. Do not list features you have not used. | F2. A concrete answer here also helps A2 and B3. |
| D3 | How do you keep on top of a busy inbox? | EXP | [grounded] "answering around 60 calls and emails a day" | Name the one or two habits you use, in your own words. Keep it to what you do. | Communication economy, and a bridge into the escalation questions. |

### E. Data-Driven Prober (weight 3)

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| E1 | You said around 60 calls and emails a day. How was that counted, and what is it sensitive to? | EXP | [grounded] "answering around 60 calls and emails a day" | Defend-the-number slot. Say how you know the figure, in your own words. Answer slot: if you did not count it, say that it is your estimate. Name the assumption you would defend least before they do. | F3. The figure is an estimate in your message, so do not present it as a measured total. |
| E2 | Which tools did you use to count your daily volume? | EXP | [grounded] "I use Freshdesk every day" | Answer slot: if Freshdesk reports gave you the count, say which report. If you counted by hand or estimated, say that. | Defend the number, from the tool side. |
| E3 | Which numbers from Freshdesk would you put in front of a manager, and why? | JD | [grounded] "I use Freshdesk every day" | Name only numbers you have looked at. If you have not looked at any reports, say so and name the one you would start with. | F2. Shows whether you read the tool or only typed in it. |

## Requirement coverage

| Job-ad requirement | Covered by |
|---|---|
| 2+ years in customer support | A1 |
| Zendesk or a similar ticketing tool | A2, B3, E3 |
| Clear written communication | A4, D3 (and today's chat) |
| Confidence handling escalations | B1, B2, B4, C2 |
| Software-company background (not in the ad, but the biggest objection) | A3 |

## Reverse questions

Ask two or three. Each one shows you have thought about the role.

1. **What does a strong first 90 days look like for someone new to your ticketing tool?** Why it lands: it shows you are already planning to learn Zendesk.
2. **Which escalations come up most often, and who decides when one goes up?** Why it lands: it shows you know escalations are the core of the job.
3. **How is written quality reviewed on the team?** Why it lands: it tests the written-communication requirement directly.
4. **What is the team's biggest support challenge right now?** Why it lands: it invites a peer-style conversation rather than a list of questions.
5. **Since this chat is also where offers and onboarding happen, how do I confirm your official contact details and how an offer is sent?** Why it lands: it checks the process, and a team that is legitimate can answer it easily.

## Prohibited claims

Things this pack will not coach you to say, and why. Each one has a basis and an honest form.

| Claim to avoid | Basis | Honest form |
|---|---|---|
| "I have experience with Zendesk." | Inflated form of "I use Freshdesk every day". Zendesk is not in your material. | "I use Freshdesk every day." |
| "I've handled escalations." | Inflated form of "I trained four new starters on our refunds process". Your material shows training, not escalation handling. | "I trained four new starters on our refunds process last year." |
| "I have software or SaaS support experience." | Contradicted by your own sentence. | "I haven't worked for a software company." |
| "I counted 60 contacts a day." | Inflated form of "answering around 60 calls and emails a day". Your figure is an estimate. | "I handle around 60 calls and emails a day." |

## Sources

- **Provided:** your Telegram invite from Marcus Hale (talent team); your message describing the job ad (as a summary, not full text) and your background.
- **Research tier: L0.** No search or fetch was run for this pack. Lumenvale's company values, product, support stack and recent news are not covered. Your message includes the warning in the invite (see chat).
- **Target accounting:** no declared targets run (L0).

## Upgrade menu

- **Full job-ad text** → turns the job-ad rows (F1 to F4) from summary into [grounded] quotes, and lets the requirement coverage table be checked line by line.
- **Your CV, as text** → gives more quotes to build from, and checks "customer service advisor" and "Freshdesk" against the document.
- **Lumenvale's public careers page or product pages (L1 research)** → adds company vocabulary and support-stack detail, and lets a company-knowledge question be added.
- **The team lead's name and the format the chat will take (length, time limit)** → lets the interviewer read and a tailored reverse question be added.
- **Saving a `tuesday-dossier.md`** → carries the gaps above into later sessions.
