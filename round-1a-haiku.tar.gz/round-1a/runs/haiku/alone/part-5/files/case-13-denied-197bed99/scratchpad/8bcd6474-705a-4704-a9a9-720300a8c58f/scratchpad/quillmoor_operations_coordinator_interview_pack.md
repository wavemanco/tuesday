# Quillmoor Diagnostics: Operations Coordinator, recruiter screen

**Role:** Operations Coordinator, Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff), Avonmouth, Bristol, hybrid.
**Interviewer:** Hannah Lowther, Talent Partner (recruiter).
**Format:** 30-minute phone call, Thursday 2pm, to the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, the hybrid pattern, reason for moving; then the team and next steps.

## 2. How to use this pack and the type key

Personas describe how a question is asked. Types describe what is being scored.

- **JD**: the listed job: pay, notice, location, and whether you can do the work.
- **EXP**: what you actually did, and why you are moving.
- **VAL**: values or behaviour (not in this screen).
- **CO**: company knowledge (not in this screen; no research ran).
- **CASE**: a live problem (not in this screen).

Guidance is scaffolding for a spoken answer, not a script. Use your own words.

## 4. Fit snapshot

Requirements come from the advert you supplied, quoted. Evidence comes only from your message, since no CV was supplied. Anything here is limited to what you have told me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | low | [inferred] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling or working with planning or QA. Answer slot: if you have worked on production timing with planning, the warehouse or QA, say what that was in your own words. If not, say so plainly and say how you would learn the production side. |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots and chase suppliers when orders slip." (your message) | medium | [grounded] | none | The quote already reaches this requirement. Expect a probe on how you tracked deliveries and how often orders slipped. |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | The quote reaches this requirement. Expect a probe on how the discrepancy figure was counted (C1). |
| F4 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show any dispatch or delivery reporting. Answer slot: if you have reported on delivery timing regularly, say what it measured and how often. If you have not, say so plainly. |
| F5 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a check on the dates. |
| F6 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | One rebuilt spreadsheet does not show your level across Excel. Answer slot: say what you use Excel for and how confident you are, in your own words. |
| F7 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP" and "we run our own in-house stock system" (your message) | none | [grounded] | capability | Words: "I haven't used SAP. We ran our own in-house stock system." Then how you would learn an ERP, said as a plan and never as a past. |
| F8 | "Hybrid: two days a week at our Avonmouth site" (advert; gate) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Gate shown met by your own constraint. Say it at its stated scope: two days is fine, three is the limit. |
| F9 | "£38,000–£44,000" (advert; gate) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Gate shown met by your own figure. |

Gate note: pay and hybrid are gates. Your own statements meet both, so neither is surfaced as a hard gate. Notice period is not in the advert and is covered as a logistics slot (A2).

## 5. Graded deliverables

Not applicable: no deliverable was announced.

## 6. Grounding brief

Not applicable: no company research ran (see Sources).

## 7. Reading the interviewer

Not applicable: no public profile was researched. Hannah Lowther is named, and a search was sent but refused (see Sources).

## 8. Persona table

This is a 30-minute recruiter screen. The relationship prior is conversational with a light skeptic, and the pack weights it that way.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly, logistics first: pay, notice, location, reason for moving | High. Her stated agenda is these four items, in a friendly register | Give each logistics answer in your own words, at its exact scope. Treat casual questions about the role as scored |
| Skeptic | Probes the gaps: production scheduling, SAP, "why this one" | Medium. Recruiters screen for knockouts and motivation consistency | Rehearse the highest-ROI objection (B1) until it is plain. Name the gap before she does |
| Data-driven prober | Asks how a figure was counted, or what you use Excel for | Low to medium. A recruiter may ask one follow-up on the CV figure | Say how it was counted, in your own words, or say you do not know |
| Pressure | Interrupts, pushes on pay or fit | Low. Included as composure rehearsal | Hold a position for two follow-ups, then concede only what is true |

Note on bank size: the 18 to 26 question total is for a full loop. A 30-minute screen gets a shorter bank. Each persona is still covered.

## 9. Question banks

### Conversational (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations for this role?" | JD | [grounded] "I'm hoping for £42,000" (your message); the advert's "£38,000–£44,000" | Give your figure: £42,000. You may add that you have seen the advertised range. Say it once, plainly. | Pay is a gate, and your figure fills this logistics slot. It raises no defend-the-number slot. |
| A2 | "Could you tell me your notice period?" | JD | [grounded] "your notice period" (Hannah's message) | Give your actual notice period in your own words. The material does not state it, so the pack has no figure for you. | Notice is a logistics slot. The answer is yours, and this pack will not supply it. |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Say that two days at Avonmouth is fine, and that three is the most you would accept. Say you live in north Bristol. Do not add commute times you have not given. | Location is a gate, and your stated constraint fills it at its own scope. |
| A4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say the Bristol office is closing next year and the only offer is relocation to Reading, which you do not want. Stop there. Add a reason for the next role only if it is one you actually hold. | The reason for moving is a logistics slot. Keep it to the closure you stated. Do not add a dissatisfaction you have not given. |
| A5 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" and "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message) | Story-mapped on F2. Four years as a logistics coordinator at a building-supplies wholesaler. You schedule deliveries for three depots and chase suppliers when orders slip. Keep it to about 90 seconds. | The biography question is the first scored moment. It draws only on your own sentences. |

### Skeptic (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production between planning, the warehouse and QA. Your background is delivery scheduling. What would you need to learn?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" (your message); the advert's "Coordinate production schedules between planning, the warehouse and QA" | Highest-ROI prep in this pack. Say what you do now: you schedule deliveries across three depots and chase suppliers when orders slip. Then answer the gap. Answer slot: if you have worked on production timing with planning, the warehouse or QA, say what it was. If not, say so plainly and say what you would learn first. Hold through two follow-ups by returning to delivery scheduling. | F1 is the gap the advert most directly raises. A recruiter will probably test it. The premise is the advert's, and the answer may be that you have not done it. |
| B2 | "The advert says SAP or similar is a plus. What's your experience?" | JD | [grounded] "Never used SAP" and "we run our own in-house stock system" (your message) | Plain acknowledgment: "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, said as a plan. | F7 is a stated gap. Say it once and move on. |
| B3 | "Why Quillmoor, specifically?" | EXP | none given. The advert is the only source for the role | Answer slot: give your own reason for Quillmoor in your own words. If the main reason is the closure of the Bristol office, say that. Do not invent interest in the company, its products or its values. | The material has no reason for Quillmoor. Silence is an answer slot, not a claim. |

### Data-driven prober (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Answer slot, in your own words: how the discrepancies were counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so. Do not say you cut discrepancies by a third. Your sentence says they fell over a year after the rebuild. | F3 is the figure a prober would test. The honest answer is the one you can repeat. |
| C2 | "What do you report on regularly, and how do you use Excel for it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: say what you report on and how often, and what you use Excel for, in your own words. If you report on delivery timing, say what it measured. If you do not, say so. Say how confident you are with Excel and why. | F4 and F6 are the requirements this question tests. A single spreadsheet does not show your level. |

### Pressure (weight: low, 1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We have candidates with SAP and manufacturing experience. Why should we move you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Hold: four years as a logistics coordinator, scheduling deliveries and chasing suppliers. Hold through two follow-ups. Then concede plainly: you have not used SAP and have no manufacturing experience, and say what you would learn first. | Hold-then-concede. Do not claim manufacturing or SAP to hold the position. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1 |
| Track supplier deliveries and chase late orders | A5, B1 |
| Keep stock records accurate | C1 |
| Weekly on-time dispatch reporting | C2 |
| 2+ years in operations or logistics coordination | A5 |
| Confident with Excel | C2 |
| ERP (SAP or similar), a plus | B2 |
| Pay (£38,000–£44,000) | A1 |
| Hybrid, two days a week at Avonmouth | A3 |

## 10. Values / principles cheat sheet

Not applicable: no values-style round was detected, and no published values were supplied.

## 11. Reverse questions

Each one has a reason it lands.

1. "What does a normal week look like for this role between planning, the warehouse and QA?" Why it lands: it shows you understand the advert's core and invites her to describe the work.
2. "How does the team chase late supplier orders today?" Why it lands: it links the advert's wording to the team's actual process.
3. "Which two days would be in the office at Avonmouth, and does the team mostly work on the same days?" Why it lands: it turns the hybrid question into a practical one about your team.
4. "What does the team's ERP look like today, and is it SAP?" Why it lands: it asks about the system you do not know, without claiming experience with it.
5. "What are the next steps after this call, and when would I meet the team?" Why it lands: she said she would cover them, so it confirms the timeline.

## 12. Delivery coaching

Not applicable: no working-style assessment was provided.

## 13. Prohibited claims

Built locally from the fit snapshot. No dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| "I planned production schedules" or "I owned the delivery schedule" | Inflated form of F1. Your material says you schedule deliveries for three depots. | The quote at its own scope: "I schedule deliveries for our three depots." Limit as the pack's observation: the material shows delivery scheduling, not production planning. |
| "I cut discrepancies by a third" | Inflated form of F3. Your sentence says discrepancies fell over a year after you rebuilt the spreadsheet. | The quote at its own scope. Do not claim sole cause. |
| "I've used SAP" or "I have ERP experience" | Negative you stated in F7. | "I haven't used SAP. We ran our own in-house stock system." |
| "I have QA or manufacturing experience" | Silence in your material, not a stated fact. | Not listed as a claim. It is an answer slot under B1, and D1 holds the honest concession. |

## 14. Sources

- **Provided documents:** Hannah Lowther's LinkedIn message (quoted in your request); the advert; your background notes.
- **Research tier:** L1 was the default. Two searches were sent (queries: "Quillmoor Diagnostics values"; "Quillmoor Diagnostics Avonmouth recruitment interview process"). Both were refused because the search permission was not granted, so no research ran.
- **Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Would have fed a values section. No values round is detected, so it would likely move nothing for a screen. Search refused. |
| 2. Quillmoor interview process, Operations role | unavailable | Would have set persona weights and confirmed the screen's structure. Search refused. |
| 3. Quillmoor strategy / recent news | unavailable | Would have fed a grounding brief. Not sent, because the host refused search. |
| 4. Hannah Lowther, Quillmoor | unavailable | Would have shown her public role. Not sent, because the host refused search. |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your actual notice period, said in your own words → nothing changes in the pack; you state it live on the call (A2).
- Your CV → the fit snapshot's quotes can come from it, which may upgrade F1, F4 and F6 from [inferred] or discovery.
- Search permission for this session → the values, interview-process and strategy research lines, and the reverse questions can be made specific to Quillmoor.
- Your Excel level, in your own words → C2 and F6 get an exact answer.
