Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account," to "reply with a photo of your passport and your bank details before the interview," and says successful candidates get a cheque that you "deposit ... and send the balance on to the vendor." Requests like these, before any offer, are a known scam pattern. This invite is very likely a scam. Don't pay anything, don't send your passport or bank details, and don't deposit that cheque. Check the job through a phone number or address from the employer's own website or careers page, not the address in this email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-5-rooms-case-12-denied-fb97699b/880c2972-5c40-4903-881c-7bf74b98433d/scratchpad/Brennock_Remote-Administrative-Assistant_interview_pack.md`. It's built on the duties and background you gave me, since I don't have the full job ad or your CV.

The pack's highest-return prep is B1, the question "What makes you ready for supplier invoices?" Rehearse it aloud at least three times. Your Excel answer (A4 and C1) is next, since "okay" is your honest level and the pack keeps it that way.

Say the word and I'll play the Skeptic on B1 so you can rehearse it live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full job ad text? The duty quotes in the pack are paraphrased from your message, and the full text would let me quote them exactly.
Do you know the office manager's name? That would let me tailor the reverse questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_Remote-Administrative-Assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Candidate:** Aoife
**Round:** 30-minute video call with the office manager (interviewer's name not given)
**Built on:** the job duties as you described them, and your background as you described it. No full job ad, no CV, no research (L0: provided material only).

## How to use this pack

- **Personas** = how the question is asked. **Types** = what is being scored.
- Type key: **Fit** (does your experience map to the duties), **Evidence** (can you back a claim with a specific example), **Honesty** (do you describe your real level accurately), **Process** (how you work day to day), **Reverse** (questions you ask them).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Fit snapshot

Requirements are the duties from your description of the ad (the full ad text was not provided, so these are not quoted from it).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Managing calendars (your message) | "ran the appointment book for four physios" — your message | high | [grounded] | transferability | Your material is a clinic appointment book for four people, not executive calendars. Say that plainly and bridge on the scheduling skill. Answer slot: how many bookings a day you handled, and one clash you resolved |
| F2 | Booking travel (your message) | none given | none | [grounded] | discovery | Nothing in your material covers travel booking. Answer slot: have you ever booked travel for anyone? If yes, say how. If not, say so, and say how you would learn the process (airline sites, company travel policy) |
| F3 | Preparing documents in Word (your message) | "good with Word" — your message | medium | [grounded] | none | Self-described, with no example behind it. Expect a probe. Have one concrete document ready that you formatted or produced |
| F4 | Preparing documents in Excel (your message) | "okay with Excel" — your message | low | [grounded] | capability | Your own word is "okay", and the pack keeps it. Words: "I'm okay with Excel." Then name the specific functions you have used (SUM, filters, simple tables), and do not claim more |
| F5 | Processing supplier invoices (your message) | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Chasing invoices is not the same as processing and logging them. Words: "I chased unpaid invoices." Answer slot: how you tracked what was owed, and whether you ever entered or matched invoices |
| F6 | Two years in a client-facing admin role (your message) | "two years as a receptionist at a physiotherapy clinic" — your message | high | [grounded] | none | Strong, and it answers the "why admin" and "reliability" questions. Lead with it |

## Prohibited claims

Built locally from the fit snapshot. The pack will not coach you to say any of these:

- **Excel beyond "okay".** No "advanced", "proficient" or "power user" unless you can show it in the call. Basis: your own word is "okay".
- **Travel booking or invoice processing experience** that you do not have. Basis: F2 is empty, and F5 is chasing, not processing.
- **Executive or corporate calendar management**, or any facilities or corporate-admin background. Basis: F1 is a clinic appointment book.
- **Any scale or outcome you did not personally produce**, such as "I improved collections by X%" if you cannot state the number.

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Practical process-tester (office manager) | Concrete scenarios: "walk me through how you'd book a flight for a director" | High. A 30-minute office-manager call is usually about day-to-day workload | Answer with the steps you would take, and name what you'd check first |
| Skeptic | "Why should I trust you with supplier invoices after a receptionist role?" | Medium. Their likely doubt is fit, based on F1 and F5 | Acknowledge the gap in one sentence, then give your closest real example |
| Pressure | Follow-ups that push you past your evidence, such as "How advanced is your Excel?" | Medium | Hold your real level. "Okay, and here's what I actually do in it" is a complete answer |

## Question banks

### Persona A: Practical process-tester

| ID | Type | Question | Guidance (provenance first) | Rationale |
|---|---|---|---|---|
| A1 | Fit | "Tell me about how you've managed someone's schedule." | [grounded] "ran the appointment book for four physios" — your message. Describe the book, the four calendars, how you handled double bookings | Calendar management is the first duty in the ad, and F1 is your closest match |
| A2 | Fit | "How would you book travel for a senior colleague?" | [generic] No travel experience in your material. Say what you'd check first: their preferences, the policy, the budget. Then say how you'd learn the booking tools | F2 is empty, so the answer is a plan, not a past |
| A3 | Evidence | "Show me how you'd build a simple document in Word." | [grounded] "good with Word" — your message. Name one document you have produced and the steps you used | F3 is self-described, so back it with one example |
| A4 | Honesty | "How would you rate your Excel?" | [grounded] "okay with Excel" — your message. Say "okay", then name two functions you have used | F4 is low confidence, and the honest answer is the strongest one |
| A5 | Process | "How do you handle invoices that are overdue?" | [grounded] "chased unpaid invoices" — your message. Describe how you chased them: who you contacted, how often, how you tracked it | F5 is your closest invoice evidence |

### Persona B: Skeptic (highest-ROI prep)

| ID | Type | Question | Guidance (provenance first) | Rationale |
|---|---|---|---|---|
| B1 | Honesty | "You've been a receptionist. What makes you ready for supplier invoices?" | [grounded] "chased unpaid invoices" — your message. Acknowledge the difference in one sentence, then give the closest real example. Do not argue the case for a bigger background | This is the most likely objection to your candidacy, so it gets the deepest rehearsal. Rehearse it aloud at least three times |
| B2 | Evidence | "How much of the appointment book was you, and how much was the system?" | [grounded] "ran the appointment book for four physios" — your message. Say what you set up and decided yourself | A test of how much you claim. Only say what you did |

### Persona C: Pressure

| ID | Type | Question | Guidance (provenance first) | Rationale |
|---|---|---|---|---|
| C1 | Honesty | "So you can handle Excel for our finance reports, right?" | [grounded] "okay with Excel" — your message. Answer: "I'm okay with Excel, and here's what I've used it for" | The pressure is to agree. Hold your real level |

## Reverse questions

Each one has a reason it lands.

1. "What does a typical week look like for whoever is in this role?" Shows you are thinking about workload, not just the title.
2. "Which calendar, booking and invoicing tools does the team use?" Shows you are preparing for the tools.
3. "How are supplier invoices approved before they're paid?" Shows you understand that invoice work sits inside a process.
4. "What would a strong first month look like?" Gives you their standard for success.
5. "How is the remote setup supported, such as equipment and onboarding?" Lets you check the employer's process, and they should expect this question.

## Prep priorities

With no prep time given, here is the default order:

1. B1 (your most likely objection), then rehearse it aloud.
2. A4 and C1 (your Excel answer), so you can say your real level without flinching.
3. A2 (travel plan), since F2 has no evidence behind it.
4. Everything else is insurance.

## Sources

- Provided material only: your message (the invite, the duties and your background). No search or fetch was run (L0). Everything is labeled as above.

## Upgrade menu

- The full job ad text → the duty quotes in the fit snapshot become `[grounded]` instead of paraphrased, and the travel and invoice rows get exact wording
- Your CV → F1 to F6 get the exact sentences you wrote, with fewer words in your own summary
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Research on the employer (L1) → a check on whether the company and role details are real, and what their published values are. An offer for a deeper pass (L2) is available on request, with its cost stated
- `tuesday-dossier.md` from job-underwriter → verified evidence and a risk register carried into this pack. This is an optional add, not a requirement
