Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-1-denied-6010f2bb/523bbe02-07d2-43b7-b228-31845a05b102/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`. I built it for a peer round, as you described. Web search was refused in this session, so the company values, interview structure and Dan's public footprint are not in it. The pack relies on your notes and research note.

# Priya: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Interviewer: Dan Kovac, Director of Sales Strategy. Relationship: peer, same VP. Round: one 60-minute conversation. Research tier L1, with search refused (see Sources).

## 1. How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Types: **VAL** behavioral/values · **EXP** experience deep-dive · **JD** role-driven · **CO** company and strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Each one should be speakable in 90–120 seconds.
- An **answer slot** is an instruction for the interview, not a question for you to answer here. Answer from your own experience; the honest branch is always allowed.

## 2. Fit snapshot

Every quote below is verbatim from your message (JD highlights, your background notes, your research note).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "partner-motion design experience required" (your message, JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | hard_gate | Your material does not establish partner-motion design. This row asks nothing; the gate question is in this message. |
| F2 | "own GTM strategy for two new product lines" (your message, JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | low | [inferred] | transferability | Bridge: "I proposed a store-surface change, credited with a ~$400M ARR uplift." Answer slot: say which decisions for that change were yours to make, and how you decided. If none were, say so and stay with the proposal. |
| F3 | "identify whitespace across land/adopt/expand/renew" (your message, JD highlights) | "set annual volume targets with cross-org consensus" (your message) | low | [inferred] | transferability | Target-setting with consensus is adjacent; your material shows no whitespace work. Answer slot: if you identified a segment or motion with room to grow, say which and how. If you did not, say so and say how you would start looking. |
| F4 | "run independent analysis in SQL and Tableau" (your message, JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | Bridge rewords only the quote: "I work in SQL and Tableau." No analysis is named; the bank asks for the instance. |
| F5 | "strong cross-functional influence" (your message, JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | Bridge rewords only the quote: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" (your message, JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Tool use is adjacent to building AI, and your material does not reach past it. Answer slot: if you have built or shipped something with AI beyond using tools, say what and your part. If not, say so and say how you use the tools daily. |

Your message says you have no classic sales-ops or quota-setting experience. That is your note, not a statement from you, so no line asks you to acknowledge it. It is covered in section 3 and in D2.

## 3. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Designed a partner motion | Inflated form of F1's quote | F1's quote at its own scope. Pack observation: your material says a revenue model used in negotiations, not a partner motion. |
| Negotiated with carriers | Inflated form of F1's quote | F1's quote at its own scope. Your material says the model was used in negotiations, not who negotiated. |
| Drove the ~$400M uplift | Inflated form of F2's quote | F2's quote at its own scope: proposed, and credited with the uplift. Pack observation: your material says proposed and credited, not drove. |
| Owned GTM for launches | Inflated form of F2, against the JD line | F2's quote at its own scope. Pack observation: your material says the proposal, not launch ownership. |
| Set quotas or ran sales ops | Widening of F5's quote; your message says no classic sales-ops or quota-setting experience | F5's quote at its own scope. The words for you are an answer slot (D2). Pack observation: target-setting is not quota-setting. |
| Built AI products | Inflated form of F6's quote | F6's quote at its own scope. Pack observation: your material says tools used daily. |

## 4. Reading the interviewer

Career pattern, from your description: pricing and monetization as the spine, one early-stage startup chapter, now Director of Sales Strategy. Self-described as "relentlessly data-driven". Same VP as the role.

Implications:

1. Every number you give will be taken back to its assumptions. Expect denominators.
2. Case questions will lean toward pricing and packaging. That is their native language.
3. The startup chapter means builder stories land. Expect a scrappiness probe on big-company pace.
4. As a peer, expect seam questions and "what would you need from me".

Mirror opportunities: none established. The startup chapter is the only possible shared path, and your notes do not put you on one. Do not invent one.

Public footprint: not searched. This read is from your description and is unverified.

## 5. Persona table

| Persona | Weight | Why this weight | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 | Peer prior, and the self-described "relentlessly data-driven" pushes it up | Asks for the denominator, the input, the assumption behind each number | Name the weakest assumption before they do; offer to walk through an analysis end to end |
| Peer Evaluator | 4 | Peer, same VP: they price what you add to their load | Seam questions, "what would you need from me", credit | Reciprocity first; propose seam principles, not a made-up seam |
| Case / Strategist | 3 | GTM role; the research note gives live strategy; pricing spine tilts cases to pricing | Live problems on the two lines, the bundling threat, profitability | Clarify, then structure: objective, segments, approach, metrics, risks |
| Skeptic | 3 | The gate F1 and the quota gap are the most predictable objections | "Which part would you be weakest at on day one?" | Rehearse the gate until it is plain; answer it honestly |
| Pressure | 2 | Peer round, so low stress prior, but cheap to cover | Interrupts on the $400M figure; sixty-second "why you" | Pause, restate, hold through two follow-ups, concede only what you can name |
| Conversational | 2 | Casual openers are still scored | "Walk me through the journey"; AI asked casually | Pre-scripted 90-second arc; treat casual AI as scored |
| Values / Behavioral | 2 | No published values in hand; cross-functional touch | Customer-versus-metric and unpopular-truth stories | Selection scaffold ending in the honest branch |

Total: 21 questions, within the 18–26 range.

## 6. Grounding brief (your research note)

- Stated priorities: enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- Main competitive threat: "bundling by a much larger platform vendor".
- Currency: taken from your note, not re-checked. Use the vocabulary; do not assert a date.

## 7. Question banks

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the partner-level revenue model: what it counted, and which assumption you'd defend least." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Two beats from the quote: you built the model, and it was used in carrier negotiations. Answer slots: what it counted, and its weakest assumption, in your own words. If you do not know, say so plainly. | Premised only on the quoted model. The Prober's top stem |
| A2 | "Your store-surface change is credited with about $400M of ARR. How was that counted, and which assumption behind it would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number, four slots: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. Each in your own words. If you do not know how it was counted, say "I don't know how it was counted," then say what you proposed. | Headline metric on your story. The figure raises the four slots and nothing else |
| A3 | "Sketch how you'd size whitespace across land, adopt, expand and renew. What's wrong with your first cut?" | JD | [generic] | Structure before numbers: define each stage, the grain of the data, and the first check on a first cut. Name one assumption you would test first. No claim about your past | A live problem from the whitespace line; presupposes nothing about you. Carries the SQL/Tableau requirement |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt: pick one analysis you ran yourself that went into a decision. Say what you ran and what you would check before presenting it. If none comes to mind, say so plainly, then say how you would approach the first one | F4 is the evidence. The question asks for the instance, so the guidance does not supply one |
| A5 | "Which of your numbers would you least want me to take at face value?" | EXP | [grounded] "credited with a ~$400M ARR uplift" | Name the weakest assumption before they do, in your own words. If the figure is the one you would name, say what you assume about it. If none is in your head, say so | Prober stem. Forces the weakest-assumption move on the number most likely to be probed |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on partner motions and expansion. Where's the seam, and what happens when we disagree?" | JD | [grounded] "partner-motion design experience required" | Propose seam principles, not a pretended seam: who decides what, who owns the partner, how you resolve a clash. Answer slot: if you have disagreed with an equal over a launch, say what and how it resolved. If not, say so and say how you would handle one. Do not claim partner-motion design here (F1 is a gate) | Peer stem. The gate sits under this seam, so the guidance keeps it unbridged |
| B2 | "How do you handle credit when GTM work spans two teams?" | VAL | [generic] | A stance, not a record: say what you would credit the other team with, and how you would say it when a launch goes well | Peer stem on credit. Generic because the answer is a principle |
| B3 | "What would you need from my team to make the second product line work?" | JD | [grounded] "strong cross-functional influence"; "set annual volume targets with cross-org consensus" | Reciprocity first: what you bring their team, then what you need. Use your one quote in your own words: you set annual volume targets with cross-org consensus. Do not name a practice you have not stated | Peer's load question. Reciprocity is what a peer weights |
| B4 | "Two new product lines, one sales org. Where does GTM strategy stop and the forecast start?" | JD | [grounded] "own GTM strategy for two new product lines" | Name where you would draw the line and why, as a principle. Answer slot: if you have drawn a line like this before, say where. If not, say so and propose one | Seam between strategy and forecast is the peer's ground; the quote states your scope |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching and enterprise expansion is a priority. Where would you put GTM effort first, and what would you need to know?" | CO | [grounded] research note: "enterprise expansion" and "an AI copilot launch ('Compass')" | Clarify, objective, segmentation, approach, metrics, risks. Use the company's words: enterprise expansion, Compass. No claim about your past | Strategy question from the provided note. The differentiator the note makes possible |
| C2 | "A much larger platform vendor starts bundling a competing product into their suite. What do you do with pricing and packaging for our new line over the next two quarters?" | CASE | [grounded] research note: "bundling by a much larger platform vendor" | Clarify the threat first. Segment the exposed accounts. Set out two or three pricing and packaging options and what each gives up. Give metrics and risks. Speak the trade-offs; this is their register. No past claim | Named threat from the note, tilted to pricing per the interviewer read |
| C3 | "Reaching profitability is a priority. How does that change which of your two lines gets investment?" | CO | [grounded] research note: "reaching profitability" | State the trade-off, name the metric you would watch first, and say what would make you change the call. No past claim | Profitability priority from the note. A strategy-altitude question |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The JD requires partner-motion design experience. Which part of that would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" | Highest-ROI prep in this pack. Gate, not bridge: the revenue model is not a bridge here. Answer slot: if you have designed a partner term, programme or motion yourself, say what and your part. If not, say so plainly, then say how you would learn the first thing in 30 days. Hold through two follow-ups by returning to what you have said. Concede only a limit you can name yourself | The most predictable objection. The requirement is the JD's own words |
| D2 | "Quota is the core of sales strategy. How would you set quotas for a new product line, and where have you set anything sales-facing?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Quote the one sentence and nothing wider. Answer slot: if you have set anything sales-facing, say what and your part. If you have not set quotas, say so plainly and say how you would approach it first. Never call target-setting quota-setting | The quota probe will come. The quote is target-setting, so the honest answer keeps that scope |
| D3 | "Whitespace is cheap to find. What have you shipped that changed a decision?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped from the quote: you proposed it, and it is credited with an uplift. Answer slot: name the decision it changed, if it changed one. If you did not decide it, say so and say what you proposed | F2's transferability row. The skeptic will test whether the proposal was a decision |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | Pre-scripted arc from the two quotes: strategy consulting, then product strategy and ops. Add your partner-level sentence and volume-target sentence in your own words. Pause before answering. Hold through two follow-ups. Concede only a limit you can name yourself | Pressure stem. The sixty seconds tests composure, and a prepared arc makes that possible |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: you proposed it, and the uplift is credited to the change. Concede precisely what you cannot say about the share. On the second follow-up, hold the same line. Do not move to "I drove it" | Pressure's challenge to an inflated share. Hold-then-concede |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: consulting, then consumer tech, product strategy and ops, and where the partner work sits. Speak only those beats | Casual opener, still scored on economy |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what you do with them, in your own words. Do not stretch "uses" to "built" | "AI experience a plus", asked casually and scored |

### V. Values / Behavioral (2)

No published values were retrieved, so there is no mapped story. Both use the selection scaffold.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Open prompt: pick a time. A decision where the customer outcome and an internal number pointed different ways, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing you have done | Persona stem; no mapped value in hand |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Same scaffold: a time you held a view that was unwelcome upward, what you said, and how it landed. If none, say so, then give the nearest thing | Persona stem; scored on whether the truth actually landed |

## 8. Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | B4, C1 |
| identify whitespace across land/adopt/expand/renew | A3, C1 |
| run independent analysis in SQL and Tableau | A4, A3 |
| partner-motion design experience required | D1, B1 |
| strong cross-functional influence | B3, V2 |
| AI experience a plus | G2 |

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career is built on pricing and monetization, and now sits in sales strategy. Which pricing question did you wish the sales side could answer sooner?" | Ties to their own path, and turns a probe into a peer conversation |
| R2 | "What did the early-stage startup chapter teach you about GTM that you still use at Northwind?" | Asks about a chapter from their own description, which reads as research on them, not on the role |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer |
| R4 | "Where does the partner motion sit between your team and the emerging products group today?" | A seam question that shows you have thought about the gate |
| R5 | "Which of the two new product lines has the clearest open pricing question right now?" | Invites them into their native register |
| R6 | "How is Compass changing what the sales org needs from new lines?" | Current priority from your note; invites specifics |

## 10. Sources

- Provided documents: JD highlights, your background notes, the interviewer description and your research note, all in your message.
- Search calls: three WebSearch calls were refused (permission not granted in this session):
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused
  - "Northwind Data company values": refused
  - "Northwind Data interview process Senior GTM Strategy Lead": refused

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet: would have mapped published values to stories. Not produced |
| 2. Northwind interview process | unavailable | Loop structure: would have set persona weights from named rounds. Weights here use relationship priors |
| 3. Northwind strategy / recent news | skipped | Your research note fixes current priorities and the threat |
| 4. Dan Kovac + Northwind | unavailable | Interviewer public footprint: would have moved the interviewer read and reverse questions R1 and R2 |
| 5. Representative JD | skipped | Your JD highlights fixed the requirement list |

## 11. Upgrade menu

- Your answer to the partner-motion question below → upgrades F1 and the gate in D1 and B1
- Full JD text → quotes the rest of the requirement list, and checks the coverage table against all of it
- Your CV lines, verbatim → upgrades F2, F3, and the stories in A1, A4, E2
- Dan's public talks or posts, or permission to search → checks the interviewer read and R1 and R2
- The company's values page, pasted → a values cheat sheet, and V1 and V2 get mapped stories
- Recruiter focus areas or a pre-declared deliverable → graded-deliverable sections
- Deep research (L2), offered once: four more targets, at most six more searches and two more fetches; needs search permission
- Prep time available → a prep triage section

---

Want a live rehearsal? I can play the Skeptic on D1, the highest-ROI prep in the pack, or the Prober on A2, the $400M figure. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Two things would sharpen the pack:

1. The JD requires partner-motion design. Have you designed a partner motion yourself? In your own words, what did you design, and what was your part?
2. Can you paste the full JD text and any CV lines word for word? Right now the evidence is your summary, not her wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Priya: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Interviewer: Dan Kovac, Director of Sales Strategy. Relationship: peer, same VP. Round: one 60-minute conversation. Research tier L1, with search refused (see Sources). First build, so no changelog.

## 1. How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Types: **VAL** behavioral/values · **EXP** experience deep-dive · **JD** role-driven · **CO** company and strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Each one should be speakable in 90–120 seconds.
- An **answer slot** is an instruction for the interview, not a question for you to answer here. Answer from your own experience; the honest branch is always allowed.

## 2. Fit snapshot

Every quote below is verbatim from your message (JD highlights, your background notes, your research note).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "partner-motion design experience required" (your message, JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | hard_gate | Your material does not establish partner-motion design. This row asks nothing; the gate question is in the message that carries this pack. |
| F2 | "own GTM strategy for two new product lines" (your message, JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | low | [inferred] | transferability | Bridge: "I proposed a store-surface change, credited with a ~$400M ARR uplift." Answer slot: say which decisions for that change were yours to make, and how you decided. If none were, say so and stay with the proposal. |
| F3 | "identify whitespace across land/adopt/expand/renew" (your message, JD highlights) | "set annual volume targets with cross-org consensus" (your message) | low | [inferred] | transferability | Target-setting with consensus is adjacent; your material shows no whitespace work. Answer slot: if you identified a segment or motion with room to grow, say which and how. If you did not, say so and say how you would start looking. |
| F4 | "run independent analysis in SQL and Tableau" (your message, JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | Bridge rewords only the quote: "I work in SQL and Tableau." No analysis is named; the bank asks for the instance. |
| F5 | "strong cross-functional influence" (your message, JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | Bridge rewords only the quote: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" (your message, JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Tool use is adjacent to building AI, and your material does not reach past it. Answer slot: if you have built or shipped something with AI beyond using tools, say what and your part. If not, say so and say how you use the tools daily. |

Your material does not show anything about sales-ops or quota work. Your message says you have no classic sales-ops or quota-setting experience. That is your note, not a statement from you, so no line below asks you to acknowledge it. It is covered in section 3 and in D2.

## 3. Prohibited claims

Built locally from the fit snapshot. The pack will not coach any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Designed a partner motion | Inflated form of F1's quote | F1's quote at its own scope. Pack observation: your material says a revenue model used in negotiations, not a partner motion. |
| Negotiated with carriers | Inflated form of F1's quote | F1's quote at its own scope. Your material says the model was used in negotiations, not who negotiated. |
| Drove the ~$400M uplift | Inflated form of F2's quote | F2's quote at its own scope: proposed, and credited with the uplift. Pack observation: your material says proposed and credited, not drove. |
| Owned GTM for launches | Inflated form of F2, against the JD line | F2's quote at its own scope. Pack observation: your material says the proposal, not launch ownership. |
| Set quotas or ran sales ops | Widening of F5's quote; your message says no classic sales-ops or quota-setting experience | F5's quote at its own scope. The words for you are an answer slot (D2). Pack observation: target-setting is not quota-setting. |
| Built AI products | Inflated form of F6's quote | F6's quote at its own scope. Pack observation: your material says tools used daily. |

## 4. Reading the interviewer

Career pattern, from your description: pricing and monetization as the spine, one early-stage startup chapter, now Director of Sales Strategy. Self-described as "relentlessly data-driven". Same VP as the role.

Implications:

1. Every number you give will be taken back to its assumptions. Expect denominators.
2. Case questions will lean toward pricing and packaging. That is their native language.
3. The startup chapter means builder stories land. Expect a scrappiness probe on big-company pace.
4. As a peer, expect seam questions and "what would you need from me".

Mirror opportunities: none established. The startup chapter is the only candidate shared path, and your notes do not put you on one. Do not invent one.

Public footprint: not searched (refused). This read is from your description and is unverified. Anything uncertain is dropped, not hedged.

## 5. Persona table

| Persona | Weight | Why this weight | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 | Peer prior, and the self-described "relentlessly data-driven" pushes it up | Asks for the denominator, the input, the assumption behind each number | Name the weakest assumption before they do; offer to walk through an analysis end to end |
| Peer Evaluator | 4 | Peer, same VP: they price what you add to their load | Seam questions, "what would you need from me", credit | Reciprocity first; propose seam principles, not a made-up seam |
| Case / Strategist | 3 | GTM role; the research note gives live strategy; pricing spine tilts cases to pricing | Live problems on the two lines, the bundling threat, profitability | Clarify, then structure: objective, segments, approach, metrics, risks |
| Skeptic | 3 | The gate F1 and the quota gap are the most predictable objections | "Which part would you be weakest at on day one?" | Rehearse the gate until it is plain; answer it honestly |
| Pressure | 2 | Peer round, so low stress prior, but it is cheap to cover | Interrupts on the $400M figure; sixty-second "why you" | Pause, restate, hold through two follow-ups, concede only what you can name |
| Conversational | 2 | Casual openers are still scored | "Walk me through the journey"; AI asked casually | Pre-scripted 90-second arc; treat casual AI as scored |
| Values / Behavioral | 2 | No published values in hand; cross-functional touch | Customer-versus-metric and unpopular-truth stories | Selection scaffold ending in the honest branch |

Total: 21 questions, within the 18–26 range.

## 6. Grounding brief (your research note)

- Stated priorities: enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- Main competitive threat: "bundling by a much larger platform vendor".
- Currency: taken from your note, not re-checked. Use the vocabulary; do not assert a date.

## 7. Question banks

Weights set the depth: 5, 4, 3, 3, 2, 2, 2.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the partner-level revenue model: what it counted, and which assumption you'd defend least." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Two beats from the quote: you built the model, and it was used in carrier negotiations. Answer slots: what it counted, and its weakest assumption, in your own words. If you do not know, say so plainly. | Premised only on the quoted model. The Prober's top stem |
| A2 | "Your store-surface change is credited with about $400M of ARR. How was that counted, and which assumption behind it would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number, four slots: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. Each in your own words. If you do not know how it was counted, say "I don't know how it was counted," then say what you proposed. | Headline metric on your story. The figure raises the four slots and nothing else |
| A3 | "Sketch how you'd size whitespace across land, adopt, expand and renew. What's wrong with your first cut?" | JD | [generic] | Structure before numbers: define each stage, the grain of the data, and the first check on a first cut. Name one assumption you would test first. No claim about your past | A live problem from the whitespace line; presupposes nothing about you. Carries the SQL/Tableau requirement |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt: pick one analysis you ran yourself that went into a decision. Say what you ran and what you would check before presenting it. If none comes to mind, say so plainly, then say how you would approach the first one | F4 is the evidence. The question asks for the instance, so the guidance does not supply one |
| A5 | "Which of your numbers would you least want me to take at face value?" | EXP | [grounded] "credited with a ~$400M ARR uplift" | Name the weakest assumption before they do, in your own words. If the figure is the one you would name, say what you assume about it. If none is in your head, say so | Prober stem. Forces the weakest-assumption move on the number most likely to be probed |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on partner motions and expansion. Where's the seam, and what happens when we disagree?" | JD | [grounded] "partner-motion design experience required" | Propose seam principles, not a pretended seam: who decides what, who owns the partner, how you resolve a clash. Answer slot: if you have disagreed with an equal over a launch, say what and how it resolved. If not, say so and say how you would handle one. Do not claim partner-motion design here (F1 is a gate) | Peer stem. The gate sits under this seam, so the guidance keeps it unbridged |
| B2 | "How do you handle credit when GTM work spans two teams?" | VAL | [generic] | A stance, not a record: say what you would credit the other team with, and how you would say it when a launch goes well | Peer stem on credit. Generic because the answer is a principle |
| B3 | "What would you need from my team to make the second product line work?" | JD | [grounded] "strong cross-functional influence"; "set annual volume targets with cross-org consensus" | Reciprocity first: what you bring their team, then what you need. Use your one quote in your own words: you set annual volume targets with cross-org consensus. Do not name a practice you have not stated | Peer's load question. Reciprocity is what a peer weights |
| B4 | "Two new product lines, one sales org. Where does GTM strategy stop and the forecast start?" | JD | [grounded] "own GTM strategy for two new product lines" | Name where you would draw the line and why, as a principle. Answer slot: if you have drawn a line like this before, say where. If not, say so and propose one | Seam between strategy and forecast is the peer's ground; the quote states your scope |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching and enterprise expansion is a priority. Where would you put GTM effort first, and what would you need to know?" | CO | [grounded] research note: "enterprise expansion" and "an AI copilot launch ('Compass')" | Clarify, objective, segmentation, approach, metrics, risks. Use the company's words: enterprise expansion, Compass. No claim about your past | Strategy question from the provided note. The differentiator the note makes possible |
| C2 | "A much larger platform vendor starts bundling a competing product into their suite. What do you do with pricing and packaging for our new line over the next two quarters?" | CASE | [grounded] research note: "bundling by a much larger platform vendor" | Clarify the threat first. Segment the exposed accounts. Set out two or three pricing and packaging options and what each gives up. Give metrics and risks. Speak the trade-offs; this is their register. No past claim | Named threat from the note, tilted to pricing per the interviewer read |
| C3 | "Reaching profitability is a priority. How does that change which of your two lines gets investment?" | CO | [grounded] research note: "reaching profitability" | State the trade-off, name the metric you would watch first, and say what would make you change the call. No past claim | Profitability priority from the note. A strategy-altitude question |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The JD requires partner-motion design experience. Which part of that would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" | Highest-ROI prep in this pack. Gate, not bridge: the revenue model is not a bridge here. Answer slot: if you have designed a partner term, programme or motion yourself, say what and your part. If not, say so plainly, then say how you would learn the first thing in 30 days. Hold through two follow-ups by returning to what you have said. Concede only a limit you can name yourself | The most predictable objection. The requirement is the JD's own words |
| D2 | "Quota is the core of sales strategy. How would you set quotas for a new product line, and where have you set anything sales-facing?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Quote the one sentence and nothing wider. Answer slot: if you have set anything sales-facing, say what and your part. If you have not set quotas, say so plainly and say how you would approach it first. Never call target-setting quota-setting | The quota probe will come. The quote is target-setting, so the honest answer keeps that scope |
| D3 | "Whitespace is cheap to find. What have you shipped that changed a decision?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped from the quote: you proposed it, and it is credited with an uplift. Answer slot: name the decision it changed, if it changed one. If you did not decide it, say so and say what you proposed | F2's transferability row. The skeptic will test whether the proposal was a decision |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | Pre-scripted arc from the two quotes: strategy consulting, then product strategy and ops. Add your partner-level sentence and volume-target sentence in your own words. Pause before answering. Hold through two follow-ups. Concede only a limit you can name yourself | Pressure stem. The sixty seconds tests composure, and a prepared arc makes that possible |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: you proposed it, and the uplift is credited to the change. Concede precisely what you cannot say about the share. On the second follow-up, hold the same line. Do not move to "I drove it" | Pressure's challenge to an inflated share. Hold-then-concede |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: consulting, then consumer tech, product strategy and ops, and where the partner work sits. Speak only those beats | Casual opener, still scored on economy |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what you do with them, in your own words. Do not stretch "uses" to "built" | "AI experience a plus", asked casually and scored |

### V. Values / Behavioral (2)

No published values were retrieved, so there is no mapped story. Both use the selection scaffold.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Open prompt: pick a time. A decision where the customer outcome and an internal number pointed different ways, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing you have done | Persona stem; no mapped value in hand |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Same scaffold: a time you held a view that was unwelcome upward, what you said, and how it landed. If none, say so, then give the nearest thing | Persona stem; scored on whether the truth actually landed |

## 8. Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | B4, C1 |
| identify whitespace across land/adopt/expand/renew | A3, C1 |
| run independent analysis in SQL and Tableau | A4, A3 |
| partner-motion design experience required | D1, B1 |
| strong cross-functional influence | B3, V2 |
| AI experience a plus | G2 |

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career is built on pricing and monetization, and now sits in sales strategy. Which pricing question did you wish the sales side could answer sooner?" | Ties to their own path, and turns a probe into a peer conversation |
| R2 | "What did the early-stage startup chapter teach you about GTM that you still use at Northwind?" | Asks about a chapter from their own description, which reads as research on them, not on the role |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer |
| R4 | "Where does the partner motion sit between your team and the emerging products group today?" | A seam question that shows you have thought about the gate |
| R5 | "Which of the two new product lines has the clearest open pricing question right now?" | Invites them into their native register |
| R6 | "How is Compass changing what the sales org needs from new lines?" | Current priority from your note; invites specifics |

## 10. Sources

- Provided documents: JD highlights, your background notes, the interviewer description and your research note, all in your message.
- Search calls: three WebSearch calls were refused (permission not granted in this session):
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused
  - "Northwind Data company values": refused
  - "Northwind Data interview process Senior GTM Strategy Lead": refused

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet: would have mapped published values to stories. Not produced |
| 2. Northwind interview process | unavailable | Loop structure: would have set persona weights from named rounds. Weights here use relationship priors |
| 3. Northwind strategy / recent news | skipped | Your research note fixes current priorities and the threat |
| 4. Dan Kovac + Northwind | unavailable | Interviewer public footprint: would have moved the interviewer read and reverse questions R1 and R2 |
| 5. Representative JD | skipped | Your JD highlights fixed the requirement list |

## 11. Upgrade menu

- Your answer to the partner-motion question in the message → upgrades F1 and the gate in D1 and B1
- Full JD text → quotes the rest of the requirement list, and checks the coverage table against all of it
- Your CV lines, verbatim → upgrades F2, F3, and the stories in A1, A4, E2
- Dan's public talks or posts, or permission to search → checks the interviewer read and R1 and R2
- The company's values page, pasted → a values cheat sheet, and V1 and V2 get mapped stories
- Recruiter focus areas or a pre-declared deliverable → graded-deliverable sections
- Deep research (L2), offered once: four more targets, at most six more searches and two more fetches; needs search permission
- Prep time available → a prep triage section
