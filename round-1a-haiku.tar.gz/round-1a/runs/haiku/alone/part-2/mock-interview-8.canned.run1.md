Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-8-canned-59652a35/c611213a-af98-4f21-87b5-b8f073a86bfb/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it for all three rounds you named, with 24 questions. The highest-value prep is B1: "Complaints here run through the contact centre as well as the branches. You've never worked in one. What would you do first?" Your manager will probably press on this, so practise saying the gap plainly and then giving a plan, without bridging to experience you haven't described.

Say the word and I'll play the Head of Member Services on B1, and push back until you hold your position or concede the right part.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Rounds (26 November):**
1. Recruiter, 30 minutes (logistics and first screen)
2. Head of Member Services, 45 minutes, mostly behavioural. This is your future manager.
3. Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel also scores the four published values.

Panel members are not yet named, so the panel is weighted by its relationship prior, not by individual profiles. First version of this pack.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values alignment. **EXP** your own work, examined closely. **JD** the listed job. **CO** company and strategy knowledge. **CASE** a live problem.
- Guidance is scaffolding, not a script. Each answer should be speakable in 90 to 120 seconds.
- In the Provenance column, the sentences in quotation marks are your own words, from your message. Anchor your answers on them. Anything not in quotes is generic or a derivation from the job description, and makes no claim about your past.

## The fit snapshot

Requirements are quoted from the job description you pasted. Evidence is quoted from your message, the only source about your experience. No requirement here is a gate under the evidence conventions (none is a legal or credential term), so no row is `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material says a branch's formal complaints log, not an end-to-end process across branches and a contact centre. Say the log in those words. Answer slot: if any step of the process was yours to set, say which and how you decided; if none was, say so plainly. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | discovery | Your material says "formal" and does not say whether the complaints were regulated. Answer slot: if some were, say which and what made them so; if the log was formal but not under rules you can name, say that, and say what "formal" meant in your branch. |
| F3 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your six years are in retail banking, and the years are real. Reword only the quote: "I have six years in retail banking, the last three as a branch supervisor." Do not add a contact-centre or operations claim the quote lacks. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none given beyond the stated negative | [grounded] | capability | A gap you stated, so the words can be yours: "I've never worked in a contact centre." Then a plan for closing it, said as a plan and never as past experience. |
| F5 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none given beyond the stated negative | [grounded] | capability | A gap you stated: "I've never presented to anyone above regional level." Then how you would learn to present to senior leaders, said as a plan. Do not claim comfort or confidence you have not shown. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Your material says a spreadsheet and does not name the tool. Answer slot: if it was Excel, say what you built in it; if it was something else, say what it was and how you would build your Excel skills for this role. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Your material shows a monthly complaints spreadsheet and does not show whether it carried volumes or resolution times. Answer slot: say which measures it carried, in your own words; if it carried neither, say so, and say what you would measure first. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script." (your message) | low | [inferred] | transferability | Derived from your training of tellers, and training tellers is not coaching supervisors. Say the nearest thing plainly: you trained tellers on the escalation script. The step to coaching supervisors is a plan, not a past. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Answer slot: if you have worked on a self-service journey, or on the complaints side of one, say what it was and what part was yours; if you have not, say so plainly and say what you would look at first. |

Reading the snapshot: F1, F2, F6 and F7 each rest on one sentence, the same one in two cases, so a probe on any of them returns to the same quote. F4 and F5 are the only gaps you stated yourself. F3 is the strongest thing your material shows.

## Prohibited list

These are claims this pack will not coach, because the material does not support them, or the wording would stretch your sentences. Each lists its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1. Your sentence covers a branch's log and tellers' training. | "I handled the branch's formal complaints log." The limit is this pack's observation: the material shows the branch, not a process across branches and a contact centre. |
| Handled regulated complaints | Inflated form of F2. "Formal" is not "regulated". | "I handled the branch's formal complaints log." |
| Coached branch supervisors on escalations | Inflated form of F8. Your sentence covers tellers. | "I trained new tellers on our escalation script." |
| Built and reported monthly volumes and resolution times | Inflated form of F7. Your sentence says you built the spreadsheet. | "I built the monthly complaints spreadsheet our regional manager uses." Which measures it carried is an answer slot, not a claim. |
| Worked in a contact centre | Negative you stated (F4). | "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F5). | "I've never presented to anyone above regional level." |

## Grounding brief: the company, from what you were sent

Source: the strategy brief as your recruiter summarised it to you in July 2026. You did not paste the full brief, so check every number against the original before you quote it in the room.

- **Digital shift:** move 40% of member service to digital channels by 2028.
- **Branch consolidation:** eight branches become five hubs over 2027.
- **Small-business lending:** a new product launches in Q1 2027.
- **Competitive pressure:** app-only banks.

Vocabulary to use: "member service", "digital channels", "hubs", "self-service". Use the company's own phrasing back at them. If a framing in the brief looks out of date, do not correct it in the interview.

## Persona weights

Weights come from relationship priors, adjusted for the loop. No interviewer profiles are available, so no interviewer-signal adjustments apply.

| Round | Relationship | Dominant personas (weight) | Why |
|---|---|---|---|
| 1. Recruiter | Recruiter screen | Conversational (4), light Skeptic (2) | Logistics and motivation consistency in a friendly register. The risk is treating it as unscored. |
| 2. Head of Member Services | Hiring manager, mostly behavioural | Skeptic (5), Values/Behavioural (4), Case (2) | The manager is buying capability and checking the gaps you already stated. Mostly behavioural, per the recruiter. |
| 3. Panel of two branch managers | Peer-adjacent, values-scored, with a case | Peer Evaluator (4), Case/Strategist (4), Values/Behavioural (4), Data-Driven Prober (3) | Branch managers judge what the hire costs their branches. The recruiter says the panel scores four values, and runs a 20-minute case. |

Counter-strategies by persona:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "You've never worked in a contact centre. What would you do?" | Highest. Two gaps you stated are visible in the JD. | Acknowledge the gap in your own words first. Then give a plan. Do not bridge from adjacent work the material does not show. |
| Values/Behavioural | Scenario probes against the four values. | High. The recruiter says the panel scores values. | Map each value to one of your own sentences where one exists. Where none does, pick a real case and be honest about the ending. |
| Case/Strategist | A live escalation, or a branch consolidation problem. | High for the panel's 20-minute case. | Clarify, then structure, then answer. Name the metric you would watch. Challenge one premise. |
| Data-Driven Prober | "How was that counted?" | Medium to high on the spreadsheet, which is your one quantitative line. | Say what you know and what you do not. Name the assumption you would defend least before they do. |
| Peer Evaluator | "Where's the seam between us?" | Medium. Branch managers will think about turf. | Offer principles for the seam, not claims about it. Show reciprocity: what you bring to their branches. |

## Question banks

Question IDs are letter-by-round. Each question is tagged with a type. Depth follows weight: round 3 has the most questions because it carries the case and the values score.

### Round 1: Recruiter (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Ninety-second arc: the six years, the last three as a branch supervisor, the formal complaints log, training tellers on the escalation script, and the monthly spreadsheet. Use only those beats, in your own words. | F3 is your opening arc. A casual question is still scored. |
| A2 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask what the band is first. Do not give a figure you have not chosen. | Pay is a recruiter-screen logistics check. Your answer is yours alone. |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. | Notice is a recruiter-screen logistics check. |
| A4 | "Where can you work, and how often?" | JD | [generic] | Logistics slot: say where you can work and how often, in your own words. Check any office pattern against the posting. | Location is a recruiter-screen logistics check. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give your own reason in one sentence. Choose what is true, not what sounds best. | Reason for leaving is a recruiter-screen check, and the answer should match your CV. |

### Round 2: Head of Member Services (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Complaints here run through the contact centre as well as the branches. You've never worked in one. What would you do first?" | JD, CASE | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI prep in this pack.** Start with the plain acknowledgment: "I've never worked in a contact centre." Then give a 30-day plan: which contact-centre people you would sit with, which complaint records you would read, and what you would ask. Hold the plan through two follow-ups, then concede any part you cannot yet do. Answer slot: if you have run a queue, call-handling or the contact side of a complaint, say what it was and what part was yours; if not, say so plainly. | F4 is the gap most likely to be raised, and the question names the JD's contact-centre requirement. Rehearsing the acknowledgment and the plan keeps you from bridging into experience you have not stated. |
| B2 | "Which of the complaints you handled were regulated, and what made them so?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if some complaints were regulated, name them and say what made them so. If the log was formal but nothing in it was regulated in the sense the JD means, say so plainly and say what "formal" meant in your branch. | F2. The question presupposes regulated complaints. Your material does not show them, so the second branch has to be open. |
| B3 | "Walk me through how you ran the formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the quote states: you handled the log, in the branch, as a formal log. Then answer slot: which steps were yours to set, and how you decided. If none were, say so and describe how the log worked. Hold through two follow-ups by returning to the log. | F1 is the strongest evidence for the four-year requirement, and the likeliest place to be probed on how much was yours. |
| B4 | "Why this role, and why now?" | EXP | [generic] | Scaffold: say what the role offers that your branch work did not. Name the gap as the thing you would be learning, and say why you want to learn it. | "Why leave, why here, why now" is the Skeptic's standard motivation probe. |
| B5 | "A branch supervisor brings you an escalation you would have handled differently. What do you do?" | JD, CASE | [grounded] "trained new tellers on our escalation script." | Structure it: what you would ask the supervisor first, what you would decide on this case today, how you would coach, and what you would record. Say that training tellers on the script is the nearest thing in your material, and that it was tellers, not supervisors. Do not claim you coached supervisors. | F8, the JD's coaching requirement. The guidance names only the quote's scope. |
| B6 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: pick a time you told a manager something unwelcome about a process. Needs a named stake, what you said, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the spreadsheet your regional manager uses. | The Values/Behavioural stem for "confident presenting to senior leaders". The quote is the only place your material touches a senior audience. |
| B7 | "What is the most senior audience you have presented complaints figures to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Answer slot: if you have presented at regional level, say what and how you prepared; if you have not presented complaints figures to anyone, say so. | F5, presenting to senior leaders. The question's presupposition is open, and the answer is the one you stated. |

### Round 3: Panel (C values, D case and strategy, E probing and peers)

**Values (C).** The panel scores the four values. Each question has a mapped sentence where one exists, and a selection scaffold where none does.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided a complaint from the member's side of the counter." (Members First) | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Scaffold: pick one complaint from the log. Say what the member asked for, what you decided, and why it was the member's side. If none turned on the member's side, say so and give the nearest case. | Members First is scored on decisions. Your log is the only place in your material where a complaint was decided. |
| C2 | "Tell me about a time you explained something so the member only needed it once." (Plain Words) | VAL | [grounded] "trained new tellers on our escalation script." | Scaffold: if you trained tellers to explain the script in plain words, say what you changed and how you checked it landed. If you taught the script as written, say that. | Plain Words is scored on what you changed. The quote shows training, not rewriting. |
| C3 | "How have you treated a complaint as something happening in a particular town?" (Neighbours, Not Numbers) | VAL | [generic] | Scaffold: if a complaint you handled turned on the branch's place in its town, say how. If you have only seen the figures, say so and say what you would look at in the town first. | Your material has no sentence on this value, so the answer is a selection scaffold with an honest branch. |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." (Own the Fix) | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: if the spreadsheet came from a problem you found and kept hold of, say what the problem was, in your words, and where it ended. If it came from a request, say so. The value is about who kept hold of the fix. | Own the Fix is the value the spreadsheet is nearest to. The guidance does not claim the spreadsheet solved anything. |

**Case and strategy (D).** D1 is the 20-minute case.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A member's complaint has been escalated three times, across a branch and the contact centre. Today they say they'll move their account to an app-only bank. What do you do in the first 48 hours?" | CASE, JD | [generic] | Clarify first: what did each escalation promise, and what does the member need now. Then objective, segmentation of the member's need against the process, approach, measures, and risks. Think aloud, and challenge one premise respectfully. | The case is a live problem from the JD's escalation work, with the brief's competitive pressure. It asks about no past of yours. |
| D2 | "Eight branches become five hubs during 2027. What do you need to know before you change how complaints are handled?" | CASE, CO | [grounded] the brief, as summarised: "consolidate eight branches into five hubs over 2027" | Clarify: complaint volumes by branch, which complaints are branch-specific, how escalation paths would change, and what members would lose in a hub. Name the data you would ask for first. | Hub consolidation is the brief's main operational change, and the panel are branch managers who will live with it. |
| D3 | "Digital should carry 40% of member service by 2028. Which complaints should stay with a person?" | CO, JD | [grounded] "move 40% of member service to digital channels by 2028" and the JD's "work with digital teams on self-service journeys" | Name categories of complaint, and why a person is needed for each: vulnerability, disputes over money, and anything that needs a decision. Say what self-service cannot resolve. Make no claim about your own digital work. | The JD's digital line and the brief's 40% target meet here. F9 has no evidence, so the answer stays with reasoning. |
| D4 | "Small-business lending launches in Q1 2027. What complaints would you expect in the first ninety days?" | CO | [grounded] the brief, as summarised: "launch a small-business lending product in Q1 2027" | Name the likely categories and say why. Say which data you would need first and how you would set up tracking before launch. | A forward-looking CO question. It tests whether you can think at the company's altitude without making claims about the product. |

**Probing and peers (E).**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How did the monthly spreadsheet count a complaint as resolved, if it did?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if it counted resolutions, say how, in your own words. If it did not count resolution, or you did not set the definition, say so plainly. | F7 and F6, and the JD's resolution-time requirement. A Data-Driven Prober will ask this, so the honest branch needs to be ready. |
| E2 | "Which assumption behind the monthly figures would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the weakest assumption in your own words before they do. If you cannot name one, say so. Do not supply an assumption the spreadsheet did not contain. | The Prober's standard metric move. It converts a gotcha into a credibility gain, and the guidance refuses to supply a method you did not give. |
| E3 | "The contact centre and the branches both touch a complaint. Where is the seam, and what happens when you disagree with a branch manager about the outcome?" | VAL | [generic] | Name the seam as principles, not facts you cannot know. For disagreement, pick a real case if you have one, and say how you kept the relationship. If you have none, say so and say how you would approach it. | The Peer Evaluator's collegial version of the Skeptic's probe. The question raises the JD's contact-centre line. |
| E4 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say which parts you built and which came from your manager's brief, in your own words. Hold the part you built through two follow-ups. Concede any part you did not build, rather than folding on the part you did. | The attribution probe. Hold-then-concede is the structure: the position you hold is the one your sentence carries. |

### Requirement-coverage line

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, D1, E3 |
| Report monthly on complaint volumes and resolution times | E1, E2, D2 |
| Coach branch supervisors on escalations | B5 |
| Work with digital teams on self-service journeys | D3 |
| 4+ years in financial-services customer operations | A1, B3 |
| Experience handling regulated complaints | B2 |
| Confident presenting to senior leaders | B6, B7 |
| Comfortable with Excel reporting | E1, E4 |

Values: Members First C1, Plain Words C2, Neighbours, Not Numbers C3, Own the Fix C4.

## Values cheat sheet

Values come from the company's published page, as pasted on 17 November 2026. The panel scores against these four.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | C1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Selection scaffold; honest branch if no complaint turned on the member's side. |
| Plain Words | If a member needs it explained twice, the wording was wrong | C2: "trained new tellers on our escalation script." Selection scaffold; say what you changed, or say you taught it as written. |
| Neighbours, Not Numbers | Every branch is part of its town | C3: no sentence in your material. Selection scaffold; honest branch: if you have only seen the figures, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | C4: "I built the monthly complaints spreadsheet our regional manager uses." Selection scaffold; say where it ended. |

## Reverse questions

Six questions, each with why it lands. No interviewer profile exists, so none is tied to a career path. Reciprocity is included for the panel, because the panel is peer-adjacent.

1. **To the Head of Member Services:** "How will complaint handling change as the eight branches become five hubs during 2027?" Why it lands: it shows you read the strategy brief and want to plan for the real change.
2. **To the Head of Member Services:** "What does a good monthly complaints report look like to you, and what is missing from the one you have?" Why it lands: it turns your spreadsheet line into a conversation about what the manager needs.
3. **To the Head of Member Services:** "Where does the digital team's self-service plan meet complaints today, and who owns a complaint that starts in the app?" Why it lands: it names the JD's digital line and surfaces the seam.
4. **To the panel (reciprocity):** "What could a new Member Experience Lead do in their first month that would genuinely help your branches?" Why it lands: it is a peer question, and it signals you are thinking about what you bring, not only what you need.
5. **To the recruiter:** "Which of the four values do candidates most often find hardest to show evidence for?" Why it lands: it tells you where to prepare, and it shows you take the values scoring seriously.
6. **To the panel:** "How will the small-business lending launch change what counts as a complaint?" Why it lands: it shows you have read the Q1 2027 launch and are thinking about the complaints it will bring.

## Sources

**Provided documents (read in full):**
- The job description, pasted in your message.
- The four company values, pasted in your message and copied from ashgrovecu.org/about/values on 17 November 2026.
- Your recruiter's email about the three rounds, the panel's values scoring, and the 20-minute case.
- The strategy brief, as summarised to you by the recruiter in July 2026. The full brief was not pasted. Its numbers and wording are the summary's.
- Your background, from your message.

**Searches and fetches:** none run. The provided documents covered every target, so no research was needed.

**Research tier:** L1. Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | The values were pasted, so the cheat sheet is built from them. |
| 2. `Ashgrove interview process, Member Experience Lead` | skipped | The recruiter's email sets the three rounds, so the persona weights follow it. |
| 3. `Ashgrove strategy` / recent news | skipped | The strategy brief summary supplies the current priorities and recent moves. |
| 4. `{interviewer name} Ashgrove` | n/a | No interviewer names have been given, so there is no query to form. |
| 5. Representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Full strategy brief** (not the summary) → checks the numbers in D2, D3 and D4 against the source, and lets the grounding brief quote it.
- **Interviewer names** for Round 2 and the panel → their public professional footprint, which gives tailored persona weights and a reverse question tied to their own career path. A deep-research pass (L2) could add the company's recent talks and the loop reports for this role family: six more searches and two more fetches, which I would run only if you ask.
- **Names of the two panel branch managers** → per-member persona weights for round 3 in place of the blended ones.
- **The complaints log's rules** (which regulator or internal policy it followed) → moves F2 from discovery to a stated answer, and lets B2 carry your words.
- **Which measures the spreadsheet carried, and the tool it was in** → moves F6 and F7 from discovery, and settles E1 and E2.
- **Any contact-centre or queue work, even adjacent** → changes B1 from a plain acknowledgment and a plan to a story you can tell.
- **Any digital or self-service work** → moves F9 from no evidence, and turns D3 into a story rather than reasoning.
- **Your prep time** → a prioritised schedule, so you can spend the evening on the few things that matter most.
- **A `tuesday-dossier.md`** from an earlier job-underwriter run, if you have one → verified evidence and prohibited claims that bind every cell, in place of the local list.
