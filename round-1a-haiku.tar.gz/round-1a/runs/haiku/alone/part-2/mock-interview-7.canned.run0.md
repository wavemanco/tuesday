Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/haiku/alone/part-2/rooms/case-7-canned-5d7d53d9/saltmarsh_live-operations-producer_interview_pack.md`. I read the company's own pages, so the interview format and values are sourced, not guessed.

**What the research changed:**
- **The 60 minutes is one session.** Saltmarsh's careers page calls it the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. So most of the prep is live problem-solving, not your CV.
- **The values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.** Your checklist is the strongest bridge to the last two.
- **Your interviewer previously led QA at a console studio.** A GDC 2026 talk of his, "Patch Notes Are a Promise", argues a live team is judged by whether its patch notes match what shipped. I saw this only in a search snippet, so I did not open the page.
- **Project Larkspur** (September 2026) moves two titles onto one shared events calendar and retires per-title event teams. The JD's "two of our mobile titles" may be Tidepool Tactics and Lantern Row, but that is my inference from the timing. Please confirm before you rely on it.

**Where to spend your time:**
1. **The two-title gap (B2).** This is the question most likely to come up in some form. Hold to what you actually ran: one title's content-drop calendar for two years. Then give a concrete plan for two titles, and say plainly if you have not planned across more than one.
2. **The Outage Hour (A1, A2).** Clarify first, stop the bleeding before debugging, communicate to players, and name the review. Practise saying this out loud.
3. **The gaps you named.** "I haven't led a team" and "I haven't worked on a game with in-app purchases" are plain sentences. Say them early and calmly, then move to how you would close the gap. Do not stretch "coordinated" into "led" or "presented" into "owned".
4. **Post-event review and KPIs.** Your material has nothing on this. Prepare one honest answer about what you would put in the first review.

**Offers, neither pushed:**
- **Live drill:** I can play the Skeptic on B2 and push back on your answer, then give feedback against that question's own guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Want a deeper research pass (up to six more searches and two more fetches, several extra minutes) on Saltmarsh's strategy and the interviewer's talks? Say so and I'll run it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager. Round: a single 60-minute interview, which the company's careers page calls the Outage Hour (a live-incident tabletop, then a values conversation).
**Candidate:** Femi (they/them).
**Built on:** the job description you pasted, your background notes, and L1 research (Sources).

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** **VAL** behavioral/values; **EXP** your own experience; **JD** the listed job; **CO** company and strategy; **CASE** live problem.
- Guidance is scaffolding, not a script. Each cell is written to be spoken in 90 to 120 seconds, and the candidate's own words are the only ones it may use about the past.
- Answer slots (written as instructions) are for the interview. They ask nothing of you here.

---

## Fit snapshot

Requirements are the JD's own words. Evidence is quoted exactly from your message or CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material describes a content-drop calendar for one title, not live events across two. Bridge: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned events or calendars for more than one title, say what they were; if not, say so and describe how you would divide one calendar across two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you coordinated other disciplines on a content update, name which and what you did, in your own words; if you did not, say so and describe how you would set that up for the first update. |
| F3 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement. Caveat: no artifact has been inspected, so expect a probe on what the checklist covers and how it is kept current. Bridge: "I wrote the release checklist our QA team still uses." |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is written work that others depend on; the material does not show the writing style. Bridge reworded from the quote only: "I wrote the release checklist; QA still uses it." Add no practice or figure. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote shows presenting the numbers, not computing them. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you computed those numbers yourself, say which part; if you presented numbers someone else produced, say so. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [grounded] | discovery | The years are stated; the live-service model is not. This is a length of experience, not a gate, so it is graded like any other row. Answer slot: describe how the puzzle game's content was delivered after launch, in your own words; if it was not live-service, say so. |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Caveat: expect a probe on the calendar's planning horizon and who set it. |
| F8 | "Never led a team" (your message), not quoted in the JD; the JD's "coordinate ... teams" is the nearest line | "Never led a team" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't led a team." Then how you would coordinate across teams without authority, said as a plan and never as a past. |
| F9 | Not in the JD. You named it as a gap: "in-app purchases" (your message) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn that model, said as a plan. |

**Gates:** the JD text contains no gate (no location, schedule, licence or legal term). If the posting has one, add it and it will be surfaced as a `hard_gate` row.

---

## Prohibited claims

Built locally from the fit snapshot. These wordings are not to be used in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Inflated form of "coordinate ... teams" (F2), and it contradicts your stated "Never led a team" (F8) | Plain acknowledgment: "I haven't led a team." Your coordination experience, if any, at its own scope |
| Ran post-event reviews or owned KPIs | Inflated form of F5 and F1; the JD requirement is not in your quotes | F5's quote at its own scope. The limit is this pack's observation: your material shows presenting retention numbers, not owning a review |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope: one title, a content-drop calendar, two years |
| Live-service experience | Inflated form of F6 | The years at their own scope. Whether the game was live-service is an answer slot, not a claim |
| Monetisation or in-app-purchase experience | Negative you stated (F9) | "I haven't worked on a game with in-app purchases." No slot |

---

## Interviewer read

- **Career pattern (public footprint):** previously a QA lead at a console studio, now Head of Live Operations. The source is a GDC 2026 talk page, "Patch Notes Are a Promise". The search snippet was the only text read; the page itself was not opened.
- **Stated view:** a live team is judged by how often its patch notes describe what actually shipped. This is the same idea as Saltmarsh's published value "Ship the Patch Not the Promise".
- **Practical implications:**
  1. Anything you say about a past release has to match what shipped. Rehearse precision about what was delivered, not about what was planned.
  2. QA's world is the interviewer's home ground. The checklist you wrote (F3) is the strongest vocabulary bridge you have. Use it.
  3. The Outage Hour is this interviewer's format. Expect the tabletop to test sequence and communication, not the answer.
- **Shared jump:** none offered. Their QA-to-live-ops move has no counterpart in your evidence, so it is not presented as a shared path.
- **Mirror opportunities:** "release checklist", "ship what is built", "players first" (the calendar and the players).

---

## Persona table

Relationship prior: hiring manager. The loop source names one 60-minute session that is a live tabletop followed by a values conversation, so the loop establishes a case plus a values component, and the archetype fallback is not used.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live incident on a live event, then sequencing | Highest. The Outage Hour is named by the company's own page | Clarify, then impact, then first action, then communication, then the review |
| Skeptic | The gaps: leadership, monetisation, two titles | High. Hiring managers buy capability and derisk gaps | Hold the stated facts; plain acknowledgment; ramp plan |
| Values / Behavioral | The three published values, scored by a values conversation | High. The loop source documents a values conversation | Map stories to values only where a quote carries one; scaffolds otherwise |
| Data-Driven Prober | Retention numbers: how counted, which assumption | Medium. You presented retention figures | Name the weakest assumption before it is asked |
| Pressure | Time-boxed challenge on leadership or on "how much was you" | Low to medium | Hold through two follow-ups, then concede exactly what you did not do |
| Conversational | Opening arc and casual questions about live work | Low to medium | 90-second arc from quotes only |

Question depth: Case 5 (A1 to A5, two of them values prompts), Skeptic 4 (B1 to B4), Values 2 (C1, C2), Prober 3 (D1 to D3), Pressure 2 (E1, E2), Conversational 2 (G1, G2). Total 18, within the 18 to 26 range.

---

## Question banks

### Case / Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A simulated outage: during a live event, a reward bug grants currency for forty minutes. Walk me through the first fifteen minutes." | CASE | [generic] | Clarify what is broken and who is affected. State the first action (stop the grant before you debug it). Name the communication to players and the decision owner. End by saying what goes into the review. No claim about your past | The Outage Hour is the company's own format; this is the live problem it names. [generic] because it is a pattern for the problem, not a fact about this company |
| A2 | "Week two retention drops fifteen percent after a content drop. What do you check first?" | CASE | [generic] | Separate the drop from the measurement: definitions, cohort, the drop's own timing. Then segment. Name the metric you would defend least | This is a retention-metric problem from the JD's own retention line. No claim about your past |
| A3 | "Project Larkspur puts both titles on one shared events calendar. What breaks first?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar" (company news, Sept 2026) | Name the coordination risk first: release conflicts and shared content. Then the checklist, which is the one artifact you have run. Answer slot: your material shows one title's calendar; if you have planned across more than one title, say so; if not, say how you would start | Strategy-grounded differentiator. The mapping of the JD's two titles to Tidepool Tactics and Lantern Row is an inference from the announcement's timing, and should be confirmed before you rely on it |
| A4 | "Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open prompt. Pick a time a planned drop conflicted with what players were telling you. Name the stake, what you did, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the calendar you ran for two years, and how you handled a drop that needed to move | The value is Players Before Plans; the quote is the only context you have. No claim is made that the story exists |
| A5 | "Ship the Patch Not the Promise. Tell me about something you announced before it was built." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. The checklist is your strongest artifact. If the checklist was the gate between built and announced, say what it checked. If not, say what was the gate. Do not claim the checklist did a job you did not see it do | Maps the value to the checklist quote. The interviewer's own talk theme is the same, so precision matters |

### Skeptic (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't led a team. How would you coordinate four disciplines on an update with no authority over them?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then the plan: who you would bring in first, what you would agree on, and what would make a discipline say no. Answer slot: if you have coordinated across disciplines without authority, say how, in your own words | The JD's coordination line plus the stated gap. F8 |
| B2 | "Your experience is one title's content drops. What is your plan for two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Quote the calendar at its scope. Limit, observed by the pack: your material shows one title. Plan: the shared calendar, the checklist per title, and who owns conflicts. Answer slot: if you planned across more than one title, say so; if not, say how you would start | The JD names two titles; this is the F1 gap. Deepest rehearsal, with the hold being the scope of the quote |
| B3 | "Which post-event reviews have you owned, and what KPIs did they report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Open prompt about the JD's post-event review line. Hold to what you presented; if you did not own a review, say so. Do not describe a review you did not run | The JD's ownership line. F5 limits what the candidate can claim; F1 says the candidate ran a calendar, not a review |
| B4 | "You've never worked on a game with in-app purchases. How would you learn that model?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan: which metrics you would read first, which team you would ask, and what you would watch in the first month. Never a claim to monetisation work | The candidate's stated gap; it is a capability gap. F9 |

### Values / Behavioral (weight: 4 questions)

Covered by A4 and A5 above, plus:

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Leave the Build Greener. Tell me about a release that left the checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: if you changed the checklist after a release, say what changed and why. If the checklist QA uses is the version you wrote and nothing changed, say so | The third value, mapped to the checklist quote. No story is supplied |
| C2 | "Tell me about a time you delivered an unpopular truth to a team you did not manage." | VAL | [generic] | Open prompt. Pick a time you disagreed with a discipline's plan. Name the stake and the outcome. If no such time comes to mind, say so plainly and say how you would handle it | Tests influence without authority, which the JD's coordination line needs. [generic] |

### Data-Driven Prober (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that retention figure was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you computed the figure, say how, in your own words; if you presented figures someone else produced, say whose and what you checked. Name the weakest assumption you know of | F5 is the only retention evidence; the prober will test whether it was yours |
| D2 | "Which KPI from a live event would you defend least?" | JD | [generic] | Name one KPI and its weakest assumption. If you have a KPI you tracked, use it; if not, say which KPI you would pick and why it is fragile | Post-event KPIs are the JD's ownership line. No claim about your past |
| D3 | "How did you know a content drop worked? What did you measure?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you measured a drop, name the metric; if you did not, say so and say what you would measure first | F1 and F7 show calendar work, not outcome measurement |

### Pressure (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "Never led a team" and "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the position you can back: two years of running a calendar and a checklist QA still uses. Hold through two follow-ups. Concede specifically: "I haven't led a team." Never fold the calendar record | Pressure answers hold then concede. The hold is the quote's scope, not more |
| E2 | "That retention presentation. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold what you presented. Concede exactly what you did not compute, in your own words | Tests attribution under pressure. F5 |

### Conversational (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | A 90-second arc using only these three sentences, in your own words. Stop at the checklist and invite the next question | Casual questions are scored. The arc uses no claim the quotes do not carry |
| G2 | "What part of live work do you most want to be judged on?" | VAL | [generic] | One sentence, tied to one value: "Players Before Plans" or "Ship the Patch Not the Promise". Then one example you can defend | An open casual question; the answer is scored on focus |

---

## Values / principles cheat sheet

Condition met: the loop source documents a values conversation; the values are fetched from the company's page.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F1 context: "I ran the weekly content-drop calendar for our main title for the last two years." No story is carried. Scaffold: a time a planned drop conflicted with what players needed; if none comes to mind, say so plainly and give the nearest thing your material carries (A4) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F3: "Wrote the release checklist our QA team still uses." No story is carried. Scaffold: what the checklist checked before anything was announced; if it did not, say what did (A5) |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F3 again. No story is carried. Answer slot: whether the checklist changed after a release, and why (C1) |

---

## Reverse questions

Each one lands for a reason.

1. "Your GDC talk argues that patch notes should describe what actually shipped. How do you check that before a live event?" Why it lands: it uses a published talk and invites the interviewer to speak from their own view.
2. "You came up through QA before live operations. What did QA catch that live ops would have missed?" Why it lands: it ties to the interviewer's own path, which is the peer conversation the profile allows.
3. "With Larkspur putting both titles on one shared calendar, who owns a conflict between them?" Why it lands: it shows you read the news, and it surfaces the decision rights the role depends on.
4. "What would a strong first 90 days look like in this role, and what would day-90 success measure?" Why it lands: it signals you plan to be measured.
5. "How is the Outage Hour scored, and what does a strong answer sound like?" Why it lands: it tells the interviewer you know the format and want the bar, not the script.
6. "What does a post-event review look like today, and who reads it?" Why it lands: it names the JD's ownership line as a question about current practice.

---

## Sources

- **Provided documents:** the JD text; the candidate's background notes.
- **Research tier:** L1 (searches 4 of 6, fetches 2 of 2).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name. Query: "Saltmarsh Games values". Result: saltmarshgames.com/values, fetched |
| 2. Saltmarsh Games interview process, live operations | yes | Loop structure: recruiter call, then the Outage Hour, a 60-minute hiring-manager interview with a live-incident tabletop and a values conversation. Query: "Saltmarsh Games interview process Live Operations Producer". Result: saltmarshgames.com/careers/interviewing, fetched |
| 3. Saltmarsh Games strategy / recent news | yes | CO question A3. Query: "Saltmarsh Games mobile studio strategy news". Result: saltmarshgames.com/news/project-larkspur (search snippet; not fetched) |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read; a GDC 2026 talk page (search snippet; not fetched). Query: "Tobias Wrenfield Saltmarsh Games Head of Live Operations" |
| 5. Representative Live Operations Producer JD | skipped | The JD was supplied, so this target is skipped |

Sources not opened: the Larkspur announcement and the GDC talk page. Their claims come from search snippets only and are labelled as such above.

---

## Upgrade menu

- A CV or any artifact from the puzzle-game calendar → turns F1, F3 and F5 from quotes you gave into inspectable evidence
- The last post-event review you ran, or any KPI you set for an event → would upgrade F2 and B3 from answer slots to grounded answers
- Confirmation that the two titles are Tidepool Tactics and Lantern Row → makes A3 grounded rather than inferred
- The recruiter's note on whether the 60-minute interview is the only round → confirms the loop, so the persona weights are not an archetype fallback
- Any location, schedule or licence term in the posting → adds a gate row, which is surfaced prominently
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. Adds a strategy brief, the interviewer's talks, and role-family loop reports
- Your puzzle game's post-launch content history → lets F6's live-service answer be grounded
