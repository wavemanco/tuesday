Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-1-denied-b943cb17/58d1ea37-0d8c-4adf-81bf-e5b18168101a/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md. I built it for a 60-minute peer round with Dan, as you described.

Two things to know before you read it:

- **Research didn't run.** Both web searches were refused for lack of permission, so everything outside the pack's own sources comes from your notes. Dan's public footprint is unverified, so his interviewer read is based only on your description.
- **The biggest risk is the quota gap.** Priya's sales-side target-setting is the most likely objection, and the pack names it as highest-ROI prep (C1). Your note records that she has no quota-setting experience, but she hasn't said so herself. Confirm that with her before she rehearses any sentence about it.

The pack has 19 questions across six personas, weighted toward the Data-Driven Prober because of Dan's self-described style. Every answer is tied to a quote from your notes, and the file's upgrade menu lists what would firm it up.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer (same VP). Round: one 60-minute conversation.
**Built from:** the coach's notes (JD highlights, Priya's background, Dan's description, Northwind priorities). No provided JD text, no CV text, no dossier.
**Research:** none. Both searches were refused (permission not granted), so every outside claim here is the coach's notes, not a public source.
**Regeneration:** none. First version.
**Sections omitted by their conditions:** prep triage (no prep time given), values cheat sheet (peer round, no values round, no company values in hand), graded deliverables (none declared), delivery coaching (no assessment provided).

---

## 1. How to use

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. An **answer slot** is an instruction for the interview ("if X, say so"). It asks Priya for nothing in this conversation.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values | Past behavior that shows a published value (none published here, so rarely used) |
| EXP | Work-experience deep-dive | Whether her claims survive scrutiny, and what she actually did |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy | Whether she thinks at Northwind's altitude (research refused, so this is generic) |
| CASE | Live problem | Structure and reasoning on a problem from the role, with no claim about her past |

---

## 2. Fit snapshot

Requirements come from the coach's JD highlights, not the full posting. Every quote is verbatim from the coach's notes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "own GTM strategy for two new product lines" (JD highlights, coach's notes) | "built a partner-level revenue model used in carrier negotiations" (coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | low | [grounded] | transferability | The material shows product strategy and a revenue model, not GTM ownership of a launch. Words at scope: "I built a partner-level revenue model used in carrier negotiations, and I proposed a store-surface change." Answer slot: if you owned any go-to-market decision for a product line, say which and how you decided; if you did not, say so plainly and say what your first launch plan would start with. |
| R2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, coach's notes) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | low | [grounded] | transferability | The revenue model is adjacent work. The material does not show that it covered land, adopt, expand or renew. Words at scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if the model covered lifecycle stages, say which and how you found the gaps; if it did not, say so and describe how you would find whitespace across all four. |
| R3 | "run independent analysis in SQL and Tableau" (JD highlights, coach's notes) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | presentation | The skill is stated and reaches the requirement in other terms. Reworded from the quote only: "I'm skilled in SQL and Tableau." Confidence caveat: no inspectable artifact is in the material, so expect a probe. |
| R4 | "partner-motion design experience required" (JD highlights, coach's notes) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | low | [grounded] | transferability | Partner-facing economics is adjacent. The material does not show how a partner works with the company day to day. Words at scope: the revenue model. Answer slot: if you designed how a partner works with a company, not just what it earns, say what you designed; if the model covered economics only, say so plainly and describe what the negotiation used it for. "Required" is an experience term, not a gate, so this row is graded on fit. |
| R5 | "strong cross-functional influence" (JD highlights, coach's notes) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: agreement across orgs. Confidence caveat: limited inspectable proof, so expect a probe on who agreed and how. No bridge needed beyond the quote's own words. |
| R6 | "AI experience a plus" (JD highlights, coach's notes) | "uses AI tools daily" (coach's notes) | medium | [grounded] | presentation | The quote reaches the requirement as use, not building. Reworded from the quote only: "I use AI tools daily." |
| R7 | Sales-side target and quota setting for a field motion (role-family pattern, not in the highlights, so plain prose) | "set annual volume targets with cross-org consensus" (coach's notes); "No classic sales-ops or quota-setting experience" (coach's notes) | low | [grounded] | discovery | The coach's note records the absence, but Priya has not stated it herself, so no words for it are coached. Confirm it with her before any sentence is written. Answer slot: if you set or carried a quota, say how; if you did not, say so plainly and name the nearest thing your material carries, the volume target set with cross-org consensus. |

**Gate check:** the highlights state no gate (location, work authorization, pay, licence). If the full posting states one, it becomes a `hard_gate` row. See the upgrade menu.

---

## 3. Prohibited claims

Built locally from the fit snapshot. No dossier was provided. These are the claims Priya could reach for under pressure, and no guidance cell below asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the go-to-market for two new product lines | Inflated form of R1 | R1's quote at its own scope. Pack observation, not words for her: the material says product strategy and a revenue model, not GTM ownership. |
| Designed partner motions end to end | Inflated form of R4 | R4's quote at its own scope. Pack observation: the material says a revenue model, not a partner motion. |
| Led the store-surface change behind the ~$400M | Inflated form of "proposed ... credited with" | The two verbs at their own scope. "Proposed" is not "led", and "credited with" is not "delivered". |
| Set quotas for a sales team | Inflated form of R7 | The volume-target quote at its own scope. Pack observation: the material says volume targets, not quotas. |
| Built the ~$400M figure from scratch | Practice the material never states | No slot names a counting method. Slot A1 asks how it was counted, in her words, and its second branch allows that she did not count it. |
| Ran independent analysis in SQL and Tableau | Inflated form of R3 | "skilled in SQL/Tableau" |
| Ships AI products | Inflated form of R6 | "uses AI tools daily" |

---

## 4. Interviewer read

From the coach's description only. The public-footprint search was refused, so none of this is verified.

- **Self-described:** "relentlessly data-driven." Implication: every number she gives will be probed to its assumptions. Lifts the Prober's weight (A1, A2, A5).
- **Career spine:** pricing and monetization, with one early-stage-startup chapter. Implication: pricing, packaging and unit-economics framing is his native language (A3, D2). The startup chapter makes scrappiness probes more likely (F2).
- **Relationship:** peer, same VP. He is pricing what the hire costs his own work and whether the hire adds or removes load (B1 to B4).
- **Mirror opportunities:** none offered. The coach's notes give no shared professional path that Priya's own sentences carry.

---

## 5. Persona weights

Relationship prior for a peer: Peer Evaluator and Data-Driven Prober. Interviewer signals then lift the Prober. The loop is a single peer round, so nothing further adjusts the weights.

| Persona | Weight | Reasoning |
|---|---|---|
| Data-Driven Prober | 5 (top) | Self-described data-driven, plus the $400M figure and the SQL/Tableau claim, which are where that register lands. |
| Peer Evaluator | 4 | Relationship prior for a peer. The round is partly about what the hire does to his team. |
| Skeptic | 3 | Rows R1, R2, R4 and R7 are the objection material. |
| Case / Strategist | 3 | Pricing spine tilts the case toward pricing and unit economics. Whitespace across the lifecycle is a live-problem topic. |
| Conversational / Rapport | 2 | Casual openers are still scored. The reverse-question slot carries weight. |
| Pressure / Stress | 2 | One peer round, so low. The $400M claim is the one held position, so it is kept. |
| Values / Behavioral | 0 | No values-style round detected, and no company values are in hand. Section dropped. |

Total: 19 questions. Within the 18 to 26 range.

---

## 6. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks how each figure was counted, and what it is sensitive to | Very high. Dan describes himself this way and the $400M figure is the obvious target. | Know how the figure was counted, or say plainly that you do not. Name the weakest assumption before he does. |
| Peer Evaluator | Seam questions, credit, what the hire needs from his team | High. Peer rounds weight this, and the JD's cross-functional line is the hook. | Offer seam principles, not a made-up map. Say what your work gives his team, not only what you need. |
| Skeptic | Probes gaps: no quota experience, partner motion, day-one weakness | High for the quota objection (R7). Most predictable objection in the pack. | Hold the nearest adjacent quote. Concede the gap exactly. Give a ramp plan. |
| Case / Strategist | Live whitespace sizing, bundling threat, Compass launch | Medium. Pricing and unit-economics framing suits his background. | Clarify before structuring. Name the anti-pick. Use the company's own vocabulary as you have it in the notes. |
| Conversational | "Walk me through the journey", "what are you playing with in AI" | Medium. Casual, but scored. | Pre-scripted 90-second arc. Treat the AI question as scored. |
| Pressure | "How much of that was actually you?" | Low-medium. One held position is the $400M claim. | Hold through two follow-ups. Concede attribution precisely. Never move "proposed" to "led". |

---

## 7. Question banks

Provenance comes before the guidance. Every candidate sentence the guidance rests on is quoted in the Provenance cell.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Speak the words of the quote: the change was proposed, and the uplift is credited to it. Say how the figure was counted, in your own words. Answer slot: if you did not count it, say so plainly and name the part that was yours. | The headline figure is the first thing a data-driven peer tests. EXP because it asks what she actually did. R-row: R1. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Name the weakest assumption before he does, in your own words, and what the figure is sensitive to. Answer slot: if you know which assumption you would defend least, name it; if you do not know how the figure was counted, say that plainly and say what you would check first. Hold by returning to the quote's scope. | Prober's favourite follow-up. Converts a gotcha into a credibility gain if answered plainly. |
| A3 | "Walk me through the partner revenue model: what went into it, and how was it used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Story-mapped from the quote's three beats: built, partner-level, used in carrier negotiations. Lead with what it was used for. Answer slot: if you chose the inputs, say which and why; if others set them, say whose and what you took from them. Do not state an outcome of the negotiation unless you were there. | Pricing is his native language, and this is the most likely pricing-literate probe. The question presupposes only that the model existed and was used, which the quote carries. |
| A4 | "Suppose a whitespace estimate for a new product line is off by a third after one quarter. What do you check first?" | JD, CASE | [generic] | Name the denominator, the segment definitions across land, adopt, expand and renew, and how you would validate against actual conversions. Say what would change the plan. No claim about your past. | Covers the whitespace requirement (R2) as a probe on assumptions. The case is a live problem, so it makes no claim about her. |
| A5 | "Tell me about an analysis you ran independently in SQL or Tableau. What did it inform?" | JD, EXP | [grounded] "skilled in SQL/Tableau" (coach's notes) | Story-mapped from the quote: skilled in SQL and Tableau. If you have a named analysis, name it and what it fed. Answer slot: if you ran it end to end, say so; if you only worked inside someone else's analysis, say so plainly and describe your part. | Open prompt on the independent-analysis requirement (R3). "Skilled" is the quote's word, so the guidance does not upgrade it. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between yours and mine, and what would you need from me?" | JD | [generic] | Propose seam principles, not a map: which decisions cross teams, who owns pricing and targets, and when you would bring him in. Say what your work gives his team, not only what you need. | Peer stem tied to the cross-functional requirement (R5). Guidance makes no claim about her past. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say what "credited with" means in the quote: you proposed it, and the credit went to the work. Name the other people in the work, if any, and what each did. Answer slot: if credit was shared with named people, name them; if you were not the one who proposed it, say so plainly. | A peer's credit-share worry, drawn from the same sentence as A1 but aimed at collaboration. |
| B3 | "Tell me about a time you designed how a partner works with a company, not just what the partner earns." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Story-mapped from the quote's beats. Answer slot: if the way a partner works day to day was yours to design, say what you designed; if the model covered only economics and the motion was someone else's, say that plainly and describe what the model did in the negotiation. | Open prompt on the required partner-motion design (R4). The quote is the only partner-facing sentence, and it reaches economics, so the second branch matters. |
| B4 | "Tell me about an annual volume target you set, and how you got agreement across orgs." | JD, EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Story-mapped from the quote: the target, and the cross-org consensus it reached. Say who held the decision. Answer slot: if you set the target, say how agreement was reached and who agreed; if others reached consensus and you brought the analysis, say that. | Tests the cross-functional requirement (R5) and begins R7, the sales-side gap, without supplying quota practice. |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Field teams carry quota. What is your experience carrying one?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | **Highest-ROI prep in this pack.** Hold the quote's scope: the target was set with cross-org consensus. Concede the gap specifically, not in general. Name the nearest adjacent thing and say what you would learn first about quota design. Hold through two follow-ups; never fold to "I would be great at it." Answer slot: if you have carried or set a quota, say how; if you have not, say so plainly, then give the nearest thing your material carries. | This is the most predictable objection, because the coach's note records no quota-setting (R7) and the sales-side requirement is implied by the land/adopt/expand/renew scope. The rehearsal is a limit named before it is asked for, not a stronger claim. |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Name one requirement plainly. Partner-motion design (R4) and sales-side targets (R7) are the two the material leaves open. Give a ramp: what you would read, who you would sit with, what you would test in the first 30 days. | Skeptic stem. The answer is a ramp plan, and the guidance adds no past. Covers the launch-ownership requirement (R1) as well. |
| C3 | "Show me the first thing you would build for this role, in SQL or Tableau." | CASE | [generic] | Name the grain, the source tables you would need, the first cut you would check, and what would make you drop it. Do not describe a dashboard you have built. | Tests the independent-analysis requirement (R3) as a live problem. Presupposes nothing about her work. |

### D. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Here is a live problem. A partner channel is growing fast on product line one, and direct sales say it is cannibalizing their deals. How would you size the whitespace before you decide?" | CASE | [generic] | Clarify first: time horizon, and what counts as cannibalized. Then objective, segmentation across land, adopt, expand and renew, approach, metrics, and risks. Challenge one premise respectfully. | Covers launch ownership (R1), whitespace (R2) and partner motion (R4). Scores structure. Presupposes nothing about Priya. |
| D2 | "A much larger platform vendor starts bundling a comparable capability into its suite. What does that do to product line one's plan?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (coach's notes) | Structure: what the bundle changes for the buyer, what you would protect, the price or packaging move you would consider, and the one you would refuse. Name the anti-pick. Use pricing and packaging language, which fits his background. | The threat comes from the coach's research note. Without search, the question stays generic enough not to depend on a public source. Pricing angle per the interviewer read. |
| D3 | "Compass launches as an AI copilot. What does its go-to-market need that a data product's does not?" | CO | [grounded] "an AI copilot launch ('Compass')" (coach's notes) | Structure: the buyer, the proof, the pricing unit, and the enterprise-expansion path the launch has to feed. Say what you would want to know about Compass before you hold a view. | Current priority from the coach's notes, and the AI requirement (R6) in strategic form. The question presupposes a difference, which is the interviewer's line; the guidance claims nothing. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 90-second arc. Use the two stages in the quote's own words. Then name the carrier model, the store-surface proposal and the volume targets, each as the coach's notes state them. Add no title or scope. | Casual opener, scored for economy. The arc keeps the sentence's scope. |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools, and what you use them for, in your own words. Answer slot: if you have built anything with AI, say what it was; if your use is tools, say that. | Casual version of the AI-plus requirement (R6). |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you for this role?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes); "set annual volume targets with cross-org consensus" (coach's notes) | Sixty seconds. Use the revenue model and the cross-org target setting, then say what you would do first on the two product lines. Do not compress into a claim about what you would run. | Time-boxed fit question. The two product lines are the pivot. |
| F2 | "That result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | **Hold, then concede.** Hold: you proposed it, and the uplift is credited to that proposal. Follow-up two: concede exactly what the credit covers, and no more. Never move "proposed" to "led". Answer slot: if your share was the proposal and not the build, say that. | The one held position in the pack. The $400M is the figure a pressure stem targets. |

---

## 8. Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Own GTM strategy for two new product lines (R1) | D1, C2, F1, D3 |
| Identify whitespace across land/adopt/expand/renew (R2) | A4, D1 |
| Run independent analysis in SQL and Tableau (R3) | A5, C3 |
| Partner-motion design experience required (R4) | B3, D1, C2 |
| Strong cross-functional influence (R5) | B1, B2, B4 |
| AI experience a plus (R6) | E2, D3 |
| Sales-side target and quota setting (R7, role-family, not in highlights) | B4, C1 |

No requirement is uncovered.

---

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Your career has a startup chapter and a long run in pricing and monetization. Which of those shaped how you would judge a new product line's price?" | Ties to his own path without asserting a sequence, and turns an interrogation into a peer conversation. |
| RQ2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. Signals she is thinking about his load, not only her own. |
| RQ3 | "Where does the seam between pricing and sales strategy sit today, and which decisions cross it?" | Opens the seam conversation B1 rehearses, and shows she knows the two functions touch. |
| RQ4 | "For the two new product lines, what number would you watch at twelve months to know whether whitespace was real?" | Shows she thinks in measures, which fits a data-driven peer. |
| RQ5 | "How did the Compass decision change the way Sales Strategy plans targets?" | Ties to the current priority in the coach's notes, and asks how the enterprise-expansion work reaches the field. |

---

## 10. Sources

**Provided documents:** the coach's notes, covering the JD highlights, Priya's background, Dan's description and Northwind's three priorities and competitive threat. No JD text, CV text, dossier or assessment.

**Searches and fetches attempted:**

| Query or fetch | Result |
|---|---|
| "Dan Kovac Director of Sales Strategy Northwind Data" | refused (permission not granted) |
| "Northwind Data Compass AI copilot enterprise expansion profitability" | refused (permission not granted) |

**Research tier: L1, attempted, not completed. Searches 0 of 6 (2 refused), fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Would have fed a values cheat sheet, which the peer round does not call for. No call was sent because the host refused search. |
| 2. Northwind interview process, role family | unavailable | Would have set loop structure. Persona weights rest on the relationship prior and the interviewer description. |
| 3. Northwind strategy and recent news | unavailable | Call sent (query 2), refused. Would have checked the coach's priorities and the bundling threat against public sources. |
| 4. Dan Kovac public footprint | unavailable | Call sent (query 1), refused. Would have verified the interviewer read, may have moved weights, and would have tuned RQ1. |
| 5. Representative JD for the title | unavailable | Only JD highlights were supplied, not the full posting. No fetch was sent. |

---

## 11. Upgrade menu

- **Full JD text** → turns the highlight rows into verbatim quotes, and surfaces any gate (location, work authorization, pay) the posting states.
- **Priya's CV text** → moves the Provenance quotes from the coach's notes to her own sentences. Every row currently rests on the notes.
- **Priya's own words on quota and sales-side target setting** → converts R7 from a coach-recorded absence into a sourced one, and makes C1's hold concrete.
- **Permission for web search, or Dan's public talks or posts pasted in** → verifies the interviewer read, which is currently unverified, and may reweight personas and retune RQ1.
- **Confirmation of which $400M counting words Priya will use** → lets A1 and A2 cite her own sentences instead of leaving the counting method as a slot.
- **Prep time before the 60 minutes** → restores the prep triage section.
- **Any stated focus areas from the recruiter** → adjusts persona weights and the coverage table.
