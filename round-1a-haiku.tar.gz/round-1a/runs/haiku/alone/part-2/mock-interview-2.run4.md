Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-2-denied-bffbfc57/37a4c2cc-e367-45ff-8c9e-086a9190d0e1/scratchpad/atlas-freight_operations-manager_interview_pack.md`, and I've sent it to you as a file. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack uses only your message and the JD text, with nothing from Atlas Freight's own materials.

The three things to rehearse most:

- **Team size (B2).** The JD says 12 supervisors across four sites. You have 3 supervisors. Lead with that in your own words and don't add to it. This is the question most likely to come up in some form.
- **Power BI (B3).** Answer it directly: you've never used it. Then give Excel and a plan to learn Power BI, framed as a plan.
- **The 40% mis-pick figure (A1, D2).** Be ready to say how it was counted, which assumption you'd defend least, and which part was yours. If the pick-path redesign was a team's, say which part you led.

Two other things in the pack. The "5+ years of leadership" line is the one I'd check your own answer on first: the pack has no count of your leadership years, so that number has to come from you (B1). And the pack has no values section and no interviewer read, because neither a values-style round nor an interviewer was identified.

Would you like a live drill? I can play the Skeptic on B2, the question the pack names as the highest-value prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions, and convert the pack to Word if you'd like it that way.

Who are you meeting: your future manager, a peer, a recruiter, or a panel? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager (4 terminal sites, team of 12 supervisors). Company: Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Round: not known; built as a hiring-manager round.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. The guidance is scaffolding for a spoken answer, not a script. Rehearse the shape, and say only what you actually did.

- **JD**: a requirement from the job description, asked directly.
- **EXP**: a question about something on your CV or in your message, testing what you actually did.
- **CASE**: a live problem from the role, scored on structure and reasoning.
- **VAL**: values or behaviour. None detected for this loop, so none in this pack.
- **CO**: company and strategy knowledge. No company research ran, so none in this pack.

## Fit snapshot

Requirements are quoted from your message (the JD text you gave). Evidence is quoted from your message. The gap-and-bridge column holds only words you have said, or answer slots. Where the pack notes what your material does not show, that is its own observation, not words for you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD, your message) | "7 years in warehouse and distribution ops" (your message), "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material describes operations at one site, and the words stay there: "I have seven years in warehouse and distribution operations, and I ran the site's peak-season surge plan two years running." Answer slot: if you have run daily operations at more than one site, say how many and what you were accountable for; if you have not, say so plainly and say how you would take on four sites. |
| F2 | "lead a team of 12 supervisors" (JD, your message) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows 3 supervisors, not 12. Words: "I am currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three supervisors, say how many and over what; if you have not, say so and describe how you would build a team of twelve, as a plan. |
| F3 | "5+ years operations leadership required" (JD, your message) | "7 years in warehouse and distribution ops" (your message), "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | presentation | Your material reaches operations and a current leadership role in other terms, so the bridge rewords only those quotes: "I have seven years in warehouse and distribution operations, and I am currently a senior shift manager." Your material does not show how many of those years were in a leadership role. Answer slot: give that number and the role in your own words; if it is under five, say so plainly and point to the seven years as the nearest thing your material carries. This is a length-of-experience requirement, not a gate, so it is graded on fit like the rest. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD, your message) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | That quote is accuracy, not on-time performance or cost. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost-per-shipment, say what you counted and how; if you did not, say so plainly and name the one measure you would put first. |
| F5 | "build reporting in Excel/Power BI" (JD, your message), Excel half | "solid Excel" (your message) | medium | [grounded] | presentation | The quote reaches Excel in other terms, not reporting. Words: "I am solid in Excel." Answer slot: name any reporting you have built in Excel, in your own words; if you have not built reports, say so. |
| F6 | "build reporting in Excel/Power BI" (JD, your message), Power BI half | "never used Power BI" (your message) | none | [grounded] | capability | A capability you stated you lack. Words: "I have never used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD, your message) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Words: "I am Green Belt certified." A certificate in hand is the inspectable proof that would raise this row to high. |

Gate check: none of the requirements is a term (authorization, licence, location, schedule, pay, travel, credential) that your material leaves unsettled. Terminal location and schedule are not stated in the JD text you gave, so they are not graded here.

## Prohibited claims

The pack will not coach these, and it will not use them in any answer slot, hold, bridge or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across 4 sites | Inflated form of F1 | F1's quote at its own scope. Your material describes one site, and the pack's observation is that it does not show more. |
| Led a team of 12 supervisors | Inflated form of F2 | "I am currently a senior shift manager over 3 supervisors." |
| Owned on-time performance and cost-per-shipment | Inflated form of F4 | F4's quote at its own scope: the mis-pick rate and the pick-path redesign. |
| Built reporting in Power BI, or knows Power BI | Negative you stated, F6 | "I have never used Power BI." Plain acknowledgment, sourced to your message. |

## Question banks

Personas are weighted for a hiring-manager round, since no round or interviewer was named. Each bank is ordered by weight.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: years of leadership, the 12-supervisor team, Power BI, "why this role" | 5, the top weight. A hiring manager is usually buying capability and checking the stated gaps. F1, F2, F3 and F6 are the gaps the material shows. | Rehearse the single most predictable objection until it is calm. Bridge only from quotes you actually have; where there is none, state the limit plainly. |
| Case / Strategist | Live problems on the role's real terms: on-time drop, cost rise, a new team, peak | 4. A hiring manager often sets a live problem to test reasoning. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Data-Driven Prober | Asks how your headline numbers were counted | 3. Your 40% mis-pick figure is the one headline number in your material. | Say how it was counted if you know. If not, say so, and name the assumption you would defend least. |
| Pressure / Stress | Time-boxed challenges: why you, how much was you | 3. No pressure signal is known, so this sits mid-weight. | Pause, restate, hold a position through two follow-ups, then concede the specific thing. |
| Conversational / Rapport | Opens with "walk me through" or a casual Excel question | 2. A screen or an opener may come first, and casual questions are still scored. | A 90-second arc from your own sentences. Name only the Excel work you have actually done. |
| Peer Evaluator | Seam questions, credit-sharing | 0, not weighted. No peer round is named. If the round is a peer, these banks change. | Reciprocity framing, if it arrives. |

No values-style round is detected for this loop, and no interviewer is named, so there is no values cheat sheet and no interviewer read. Reverse questions are built role-generic.

### Skeptic bank (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role asks for five-plus years of operations leadership. How many of your years have been leadership?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message), "currently a senior shift manager over 3 supervisors" (your message) | Give the number and the role in your own words. Your quotes carry seven years of operations and a current senior shift manager role; they do not carry a count of leadership years, so the number is yours to give. Answer slot: if your leadership years are under five, say so plainly, then point to the seven years and the current role as the nearest thing your material carries. | F3 is the requirement the JD states as a minimum, and a Skeptic will ask for the number first. JD because it scores the stated requirement. |
| B2 | "This role leads 12 supervisors across four sites. Where does your experience sit against that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | The highest-ROI rehearsal in this pack. Open with the quote in those words: "I am currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three supervisors, or been accountable across more than one site, say how many and what you were accountable for; if you have not, say so plainly and describe how you would build a team of twelve across four sites, as a plan. Hold through two follow-ups by returning to three supervisors, never by adding to the number. | F2 and F1 carry the scale gap, and this is where the JD presses hardest. JD because it scores the team requirement. |
| B3 | "Our reporting runs in Power BI. Have you used it?" | JD | [grounded] "never used Power BI" (your message) | Answer the yes-or-no first: "I have never used Power BI." Then "I am solid in Excel," and the plan to learn Power BI, said as a plan. Claim no dashboard in either tool that you have not built. | F6 is a stated capability gap, and this yes-or-no will be asked directly. JD because it scores the Excel/Power BI requirement. |
| B4 | "What's the part of this job you'd be weakest at on day one?" | Skeptic stem | [grounded] "never used Power BI" (your message) | Name Power BI first, in the quote's words. For the scale gap, give the F1 answer slot: if you have run more than one site, say so; if not, say that the multi-site part is where you would be weakest, and how you would learn it in your first month. | Persona stem. The answer draws on F6 and F1, and it names gaps rather than hiding them. |
| B5 | "Why this role, and why now?" | Skeptic stem | [generic] | The material holds none of your reasons, so the pack has no story to map and makes no claim about them. Answer slot: give your actual reasons, in your own words, and tie each to something you have done; if the honest reason is the role itself, say that. Keep it under 90 seconds. | Motivation consistency is the Skeptic's standard probe. [generic] because it is a pattern for the question, not a fact about you or this employer. |

### Case / Strategist bank (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time rate at one of your sites drops eight points in a month. What do you do in the first week?" | CASE | [generic] | Structure it. Clarify what changed: volume, carrier, labour, one lane or shift. Set the objective. Segment by site, shift and lane. State two or three hypotheses. Name the metrics you would watch. Speak it in 90 seconds. Make no claim about any site you have run. | A live problem from the JD's on-time line (F4's requirement), asked as a decision. [generic] because it is a pattern, not a fact about this employer. |
| C2 | "Cost per shipment has risen across the network this year. Where do you look?" | CASE | [generic] | Split cost into its parts: labour, linehaul, dwell, rework. Cut by site. Separate volume effects from rate effects. Name the one measure you would defend first. Make no claim about past cost work. | The JD's cost-per-shipment line (F4). Live problem, so it presupposes nothing about you. |
| C3 | "You inherit 12 supervisors across four sites, and two of them are struggling. What do you do in your first 30 days?" | CASE | [generic] | Structure it: listen first, one-to-ones with all twelve, the standards they are held to, the causes behind the two struggling supervisors, and a review cadence for the whole team. Make no claim about having led twelve. | The JD's team line (F2). A plan, not a past. |
| C4 | "Peak starts in six weeks and volume is forecast 30% above last year. Walk me through your surge plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Use your two years of surge planning as the basis, in those words. The forecast and the six weeks are the interviewer's hypothetical, so build the plan forward from them. Answer slot: if any part of a surge plan was yours to set, say which and how you decided; if you did not set it, say so plainly and describe how you would plan this one. | Peak planning is your clearest operational story, and the JD's operations line presses it. CASE because the forecast is the interviewer's. |
| C5 | "Sketch the weekly on-time and cost-per-shipment report you'd put in front of four site leaders. Where does it start, Excel or Power BI?" | CASE | [generic] JD line "build reporting in Excel/Power BI" (your message) | Structure it around three decisions: which measures, which cut by site and shift, which review rhythm. Say it starts in Excel because you are solid there, and that Power BI is the next step you would learn, as a plan. Claim no report you have built. | The JD's reporting line (F5, F6) and its on-time and cost line (F4), together. |

### Data-Driven Prober bank (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number in your own words: the period you would use as the baseline, what was counted, and the assumption you would defend least. Answer slot: if you can say how the rate was counted, say it; if not, say so plainly and name what you would check. Then which part was yours: if the redesign was a team's, say which part you led; if you did it alone, say that. The pack supplies no baseline, method or attribution model. | The headline figure is the likeliest magnet for a prober (F4). EXP because it tests attribution. |
| A2 | "Have you owned an on-time rate or a cost-per-shipment figure? What were they?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you tracked on-time performance or cost-per-shipment, say what you counted and how. If you did not, say so plainly, then name the closest measure you did track, the mis-pick rate. Never describe an on-time or cost figure you did not track. | The JD's on-time and cost line (F4). The question asks rather than presumes, so the honest branch is the direct answer. |
| A3 | "What did you collect or count to show the green belt project worked?" | EXP | [grounded] "green belt certified" (your message) | Answer slot: if you applied the belt to a project, name it and what you measured. If you hold the belt without a project, say so plainly and name the tool you would apply first. Never name a project you did not run. | The Lean/Six Sigma line (F7). The question presupposes a project, so the second branch must allow that there was none. |

### Pressure bank (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run four sites?" | Pressure | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause, then restate the question. Hold: the 40% is the strongest result you have, in your own words. Concede specifically: if you have not run four sites, say so. Hold through two follow-ups; concede only the scale. | F1 and F2. The "someone who has run four sites" is the interviewer's comparison, not your history. |
| D2 | "That 40% — how much of it was actually you?" | Pressure | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the redesign, in the quote's terms. Concede specifically: name any part done with others, and any part you did not do alone. Hold-then-concede: hold what you did, concede the rest by name. | Attribution probe on F4. The pack holds nothing it cannot back. |
| D3 | "You've said you've never used Power BI. Why would we bet on you to build our reporting?" | Pressure | [grounded] "never used Power BI" (your message) | Hold on the reporting you would specify, not the tool: the measures and the review rhythm are the part you can speak to. Concede: you would not build Power BI on day one. Hold through two follow-ups before conceding. | F6 is the stated gap. The hold stays inside what your material carries. |

### Conversational bank (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through how you got into operations." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running", "green belt certified" (your message) | A 90-second arc in your own order, using your sentences: the seven years, the senior shift manager role, the pick-path redesign, the surge plan two years running, the belt. Add nothing between them. Answer slot: if there was a turning point between them, name it and what you did; if there was not, do not invent one. | A casual opener is still scored, and this is the first question most interviewers ask. |
| E2 | "What are you actually using in Excel these days?" | Conversational | [grounded] "solid Excel" (your message) | Name the Excel work you have actually done, in concrete terms. Do not list functions you have not used, because the follow-up will test them. Answer slot: if you have not built reports in Excel, say so. | F5. A casual question about a JD topic is scored. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | B2, B4, C1 |
| Drive on-time performance and cost-per-shipment down | A2, C1, C2 |
| Lead a team of 12 supervisors | B2, C3 |
| Build reporting in Excel/Power BI | B3, C5, E2 |
| 5+ years operations leadership required | B1, D1 |
| Lean/Six Sigma a plus | A3 |

The headline figure (40% mis-pick) gets its defend-the-number questions at A1 and D2.

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's career path, and no peer reciprocity question is included.

1. **"What would success look like in the first six months for whoever takes this role?"** Why it lands: it shows you are planning against their target, not just asking about the job.
2. **"How do the four sites share practice today, and where does that break down?"** Why it lands: it maps straight onto the 12-supervisor team, and it asks about a real problem.
3. **"Is on-time and cost-per-shipment reporting built in Excel today, or in a tool the team already runs?"** Why it lands: it tells you the real Power BI gap, and it reads as curiosity, not defensiveness.
4. **"Is there a Lean or Six Sigma programme running, and who runs it?"** Why it lands: it treats the JD's last line as a live question, and it shows you read the posting.
5. **"What has been hardest for the last person in this role?"** Why it lands: it invites candour, and it lets you answer with a plan.

## Prep triage

Skipped: no prep time was given.

## Sources

- **Provided documents:** your message only, which contains the JD lines and your background. No uploaded files.
- **Searches sent:**
  - `Atlas Freight regional logistics company values`: refused. Web search permission was not granted in this session.
  - `Atlas Freight operations manager interview process`: refused, for the same reason.
- **Not established:** nothing about Atlas Freight's values, loop, strategy or leadership came from research. Nothing in this pack is drawn from memory of the company.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet. Refused, so no values source. No values-style round is detected in any case, so the section is dropped. |
| 2. `Atlas Freight interview process operations` | unavailable | Loop structure and persona weights. Refused, so persona weights use the generic prior. |
| 3. `Atlas Freight strategy` / recent news | unavailable | The CO bank. No call was sent because search was refused, so the pack has no CO questions. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative `Operations Manager` JD | skipped | The JD text you gave fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Who you are meeting (your future manager, a peer, a recruiter or a panel) → reweights every bank. This is the one question in the message that presents this pack.
- The recruiter's email or the invite's description of the rounds → the loop structure, and persona weights per round. If the first round is a recruiter screen, pay, notice and location become logistics slots.
- Atlas Freight's values page, pasted → the values cheat sheet, if a values-style round turns up.
- A deeper research pass, if web search is allowed → up to six more searches and two fetches covering the company's values, interview process and strategy. This is one offer, and it takes several minutes.
- The interviewer's name → an interviewer read and a tailored reverse question, from their public professional footprint only.
- A Green Belt certificate, or a record of the project you used it on → raises F7 to high and makes A3 concrete.
- The number of years you have held a leadership role, and the method behind the 40% figure → turns the answer slots in F3, B1 and A1 into stated claims, in your own words.
- Any Power BI use, even a course project → rewrites F6 and B3 to match what you have actually done.
- `tuesday-dossier.md` from an earlier session, if you have one → sharpens the pack with verified evidence and the objections already found.
