Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-6-denied-e3277544/1aa0e09c-c500-4457-aa51-6267037ac9bb/scratchpad/larkfield_engineering-manager_interview_pack.md`. It covers all three rounds: a shared fit snapshot, a prohibited-claims list, per-round question banks and reverse questions, a persona table, a requirement-coverage table, and a prep order across the window.

Two things shaped it. Company research didn't run: all three web searches were refused in this session, so the pack says nothing about Larkfield's values, strategy or interview process. Also, the questions are built from your message and the role description you gave, not a full job posting. Every claim about your experience is one of your own sentences, quoted in the pack.

The most important prep is R1-A4, "You've never managed managers. How would you lead two squads with their own leads?" It's the most likely objection, and round 3 comes back to it as R3-C6. Rehearse the plain "I haven't managed managers," then your team-of-six story, then a plan for working with leads. Don't add leadership experience you didn't have.

Would you like me to play the Skeptic on R1-A4 in a live drill? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would make the pack sharper:
1. Do you have the full job description text? It would replace the summary I built from, and firm up the requirement quotes.
2. Do you know the Director's name, and the panel members' names? With them I can tailor each round's questions to the people in the room.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: loop prep pack (Yusuf)

**Loop mode:** three rounds. Round 1 (Tuesday): hiring manager, Director of Engineering, 45 min. Round 2 (Thursday): panel, two staff engineers and a product manager, 60 min. Round 3 (the following Monday): VP Engineering, 30 min.
**Research:** not run. All three company searches were refused in this session (see Sources). The pack is built from your message and the role description you gave. Nothing about Larkfield's values, strategy or interview process is asserted.

## How to use + type key

- **Personas** = how a question is asked. **Types** = what it scores.
- **VAL** Behavioral / values alignment. **EXP** Work-experience deep-dive. **JD** Role / JD-driven. **CO** Company and strategy knowledge (none in this pack, see Sources). **CASE** Hypothetical / live problem.
- Guidance is scaffolding, not a script. Each guidance cell is written to be said aloud in 90–120 seconds, and every claim about your past is one of your own quoted sentences.
- Question IDs are per round: R1-A1, R2-B1, R3-C1.

## Fit snapshot (shared across all rounds)

Requirements come from your role description (quoted as you gave it). Evidence comes from your message (quoted as you wrote it).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" — your role description | "I run our hiring loop for backend roles" — your message; "about 40 interviews last year" — your message | medium | [grounded] | transferability | The hiring you have run is for backend roles, and the quotes say nothing about a wider team. Say it in those words: "I run our hiring loop for backend roles, about 40 interviews last year." Answer slot: if the loop changed for a non-backend role, say what changed; if it did not, say so and say what you would do first. |
| F2 | "Lead two squads building device-management services" — your role description | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | The quote is one team of six, not two squads. Use the quote's scope: "I've led a team of six for three years." Answer slot: if you have coordinated more than one team at a time, say how; if not, say so. |
| F3 | Managing leads under the two squads — [inferred] from your scope note, not in the role text | "I've never managed managers" — your message | none | [grounded] | capability | This is a negative you stated. Words: "I haven't managed managers." Then the plan for working with leads, given as a plan and never as a past. Do not add any leadership experience to make the gap feel smaller. |
| F4 | "partner with hardware and product on roadmap" — your role description | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries roadmap pressure, not hardware. Answer slot: if that quarter had a hardware dependency, say how it was handled; if it did not, say so. |
| F5 | Owning a hardware-adjacent roadmap — [inferred] from your scope note | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A negative you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then the closest quote (F4), at its own scope. |
| F6 | "own delivery" — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | medium | [grounded] | none | The figure is specific and has no inspectable proof behind it, so expect a probe. Lead with the quote in its own terms. |

Gate rows: none. Neither your message nor the role description states a location, eligibility, schedule or pay term. If the posting carries one, send it (see upgrade menu).

Rules the table follows: quotes are only your own sentences or the role text; gap types follow the quote, not the writer's sense of the row; the qualifier lives in the last column; a gap is worded only from a negative you stated, and an answer slot otherwise.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and no guidance cell in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or led leads | Negative you stated (F3) | "I haven't managed managers." No slot on this claim. |
| Owned a hardware roadmap | Negative you stated (F5) | "I haven't owned a hardware-adjacent roadmap." |
| Led two squads, or 11 engineers | Inflated form of F2 and F1 | The quote at its own scope: a team of six, and the hiring loop for backend roles. |
| Cut on-call by 60% by yourself | Inflated form of F6 | The quote: "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The limit is in the pack's analysis: your material does not show how much of the drop was yours. |
| Built the hiring loop | Inflated form of F1 | "I run our hiring loop for backend roles." |

## Persona weights by round

| Round | Relationship | Persona | Weight | Reasoning |
|---|---|---|---|---|
| 1 (Tuesday, Director of Engineering) | Hiring manager | Case/Strategist | top, 4 questions | They are buying the capability to run two squads and will test it on a live problem (hiring manager prior). |
| 1 | Hiring manager | Skeptic | 3 questions | They will derisk the gaps in F2, F3 and F5 directly. |
| 1 | Hiring manager | Conversational | 1 question | Opening biography; casual, but still scored. |
| 2 (Thursday, panel) | Two staff engineers, one PM | Data-Driven Prober | top, 3 questions | Staff engineers check the numbers on F6 and the scope claims on F2. |
| 2 | Staff engineers | Pressure | 2 questions | Technical depth under follow-up. |
| 2 | Product manager | Peer Evaluator | 3 questions | Seam and disagreement with a peer. |
| 3 (Monday, VP Engineering) | Skip-level, values round | Values/Behavioral | top, 4 questions | Your recruiter described this round as "values and leadership philosophy," so a values-style round is documented by a loop source. |
| 3 | Skip-level | Case/Strategist (altitude) | 2 questions | Strategic altitude, without research on Larkfield's strategy. |
| 3 | Skip-level | Pressure | 2 questions | Composure on the manager-of-managers gap. |

No interviewer profiles were given, so there is no interviewer read and no per-person tuning. Round 2 is a panel, so the persona blend follows each member's relationship. Delivery is tuned per round, not per pack.

## Prep order across the window

The order follows the rounds, not a time budget, since you did not give prep time. Rehearse A4 (round 1) first. It is the single most likely objection in this pack, and round 3 returns to it as C6.
1. Before Tuesday: R1-A4 and R1-A5 aloud, twice each. Then R1-A1 and R1-A2.
2. Between Tuesday and Thursday: R2-B1 and R2-B2 (defend the 60% figure). Then the panel's seam question, R2-B5.
3. Between Thursday and Monday: R3-C1 and R3-C6. Rehearse the honest branch for each one.
Everything else is insurance.

## Round 1 — Hiring manager (Director of Engineering), 45 min

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Sketch how you'd take over two device-management squads in your first 90 days — what do you need to know first?" | CASE | [grounded] "Lead two squads building device-management services" — your role description | Clarify before structuring: current delivery state, roadmap commitments, and which hardware dependencies the two squads have. Then the approach and the metrics you would check first. Claim nothing about your past. | A live problem from the role text; no claim about your experience is made. |
| R1-A2 | "A squad's device rollout slips six weeks because the hardware team's firmware is late. What do you do this week?" | CASE | [grounded] "partner with hardware and product on roadmap" — your role description | Name who owns the dependency, what gets re-sequenced, what you tell product, and which decision you need from the Director. Keep it to the first week. | The role text raises the partnership; the scenario is a pattern for it, not a fact about your team. |
| R1-A3 | "Where does the reliability quarter you pushed through carry over to a roadmap with hardware in it, and where does it not?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Story-mapped on F4: the quarter, the roadmap pressure, and pushing it through. Answer slot: if that quarter had a hardware dependency, say how it was handled; if not, say so and say where the carry-over stops. | F4 is the transferability gap on the partnership requirement; the honest answer is the limit. |
| R1-A4 | "You've never managed managers. How would you lead two squads with their own leads?" | JD | [grounded] "I've never managed managers" — your message; "Lead two squads building device-management services" — your role description | **Highest-ROI prep in this pack.** Open with the plain acknowledgment: "I haven't managed managers." Then the nearest thing you have: "I've led a team of six for three years." Then a plan for working with leads, given as a plan. Hold through two follow-ups by returning to the team of six and the plan; concede explicitly that you have not done it. Never add leadership experience you did not have. | This question will come in some form: the squads' structure is the scope jump the role implies, and F3 is the gap it aims at. A non-defensive answer changes the interview. |
| R1-A5 | "Eleven engineers is almost twice the team you've led. What part of that would you be least sure of?" | JD | [grounded] "3 as a team lead of 6" — your message; "own delivery, hiring and growth for 11 engineers" — your role description | Name the weakest assumption before they do: the hiring pace, or whether the team's delivery holds as it grows. Give the team of six at its own scope. | F2 and F1 are the scope gap; this asks for the assumption you would defend least. |
| R1-A6 | "You've never owned a hardware-adjacent roadmap. Why should we believe you'd partner on one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" — your message | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the closest quote (F4) and a ramp plan stated as a plan. Do not claim hardware knowledge. | F5 is a stated gap; the honest answer is the acknowledgment and a plan. |
| R1-A7 | "So — tell me how you got from engineer to team lead." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | A 90-second arc built only from that sentence: nine years, three as team lead, the team of six, and where you are now. | Opener; casual register, still scored. |
| R1-A8 | "How do you run your hiring loop, and what would change for hardware-adjacent roles?" | JD | [grounded] "I run our hiring loop for backend roles" — your message; "about 40 interviews last year" — your message | Say what you run and the scale (about 40 interviews last year). Answer slot: what you would change for a non-backend role, as a plan. | F1, the hiring part of the scope. |

Coverage for round 1 is in the requirement-coverage table below.

### Reverse questions (round 1)

1. "What does success look like for these two squads at the six-month mark?" — It forces the priorities into the open.
2. "Where does the hardware roadmap get decided today, and who has the final say when product and hardware disagree?" — It shows you are thinking about the seam.
3. "What is the current on-call and delivery picture across the two squads?" — It asks for the baseline your 60% figure would be measured against.
4. "Which roles are open, and which is hardest to fill?" — It turns the hiring requirement into a planning conversation.
5. "What has made this role hard to fill so far?" — It asks what the Director has already learned.

No interviewer profile exists, so none of these ties to the Director's own career path. See the upgrade menu.

## Round 2 — Panel (two staff engineers, one product manager), 60 min

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "Walk me through how the on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | Defend-the-number slots, in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you counted it, say how; if you did not, say so and say which figure you do know. | F6 is the headline figure, and probers test it first. Rehearse saying "I don't know how it was counted" as an honest branch. |
| R2-B2 | "Which part of that reliability quarter was your decision, and which was your team's?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Say what you decided, in the quote's scope: you pushed it through. Answer slot: if the scope was set by others, say so; if you set it, say what you decided and why. | Attribution probe; the quote is the only act the material states. |
| R2-B3 | "What's the hardest technical decision in a device-management service, and how would you test your squads' answer?" | CASE | [generic] | Structure: device state, offline behavior, rollout safety, rollback. Say what you would test first. | Live problem from the role's domain; no claim about your past. |
| R2-B4 | "Devices run offline and on flaky networks. How would you make a rollout safe?" | CASE | [grounded] "Lead two squads building device-management services" — your role description | Name the risk, a staged rollout, and the rollback. Keep it to the first three steps. | The role text raises the domain; the answer is a pattern. |
| R2-B5 | "Our teams sit side by side — where's the seam with product, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" — your role description | Seam principles, not a claimed seam. Disagreement: the only quoted case is the reliability quarter (F4). Answer slot: if the pressure came from product, say what they wanted and how it landed; if it came from elsewhere, say so. | A peer probe; the reciprocity framing is in the reverse questions. |
| R2-B6 | "You've led six people. Why won't that scale to eleven?" | JD | [grounded] "3 as a team lead of 6" — your message; "own delivery, hiring and growth for 11 engineers" — your role description | Hold: the team of six at its own scope, then the plan for the next step. Hold through two follow-ups; concede the limit explicitly. | Pressure version of R1-A5, aimed at the staff engineers' scope doubt. |
| R2-B7 | "What's been the most useful thing you learned in payments that carries over?" | EXP | [grounded] "currently at a payments company" — your message | Name one lesson, and say how it applies to device fleets. Keep it to a single example. | Conversational opener; the answer is a choice, not a claim. |
| R2-B8 | "How do you hire a backend engineer here versus a firmware-adjacent one?" | JD | [grounded] "I run our hiring loop for backend roles" — your message | Describe the backend loop as the quote states it. Answer slot: what you would change for a firmware-adjacent role, as a plan. | Staff engineers will ask whether your loop covers their domain. |

### Reverse questions (round 2)

1. "What's the hardest technical decision your squads faced last year?" — It asks for the real engineering problem, not the brochure.
2. "How do staff engineers and the product manager settle a disagreement on sequencing?" — It shows you are thinking about the seam as the panel lives it.
3. "What could a new person do in their first month that would genuinely help your teams?" — Reciprocity question for a peer panel. It turns the conversation toward what you bring.
4. "How much of the roadmap is set by hardware timelines?" — It tests your understanding of the dependency.
5. "What does on-call look like across the device fleet today?" — It connects to the figure you will be asked about.

## Round 3 — VP Engineering, 30 min (values and leadership philosophy)

Your recruiter described this round as "values and leadership philosophy." That is a loop source naming a values-style round, so values questions are guaranteed here. The company's published values were not found (see Sources), so there is no values cheat sheet, and the VAL questions rest on the recruiter's words and on your material.

### Question banks

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Story-mapped on F4: the quarter, the roadmap pressure, and pushing it through. Beats are the quote's own clauses. Answer slot: if no such truth was delivered to leadership, say so plainly, then give the nearest thing your material carries: the quarter. | The recruiter's theme is leadership philosophy; the quote is the only story your material carries. |
| R3-C2 | "What's your leadership philosophy, in one minute?" | VAL | [grounded] "I run our hiring loop for backend roles" — your message; "3 as a team lead of 6" — your message | Build the minute from what you have done: a team of six, and the hiring loop for backend roles. Say what you believe, grounded in those two facts. | Open prompt on the recruiter's theme. The answer must not reach past the quotes. |
| R3-C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a metric and a customer's needs diverged. If none comes to mind, say so plainly, then give the nearest thing you did. Do not invent a customer story. | Persona stem for the values theme. No customer story is in your material. |
| R3-C4 | "How do you develop engineers so they can take on more?" | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" — your role description | Answer slot: if you have grown someone into a larger role, say how; if not, say so and say what you would do. Do not name a promotion you did not give. | The role text raises growth; your material does not show a growth outcome. |
| R3-C5 | "Where would you take this organization's device-management work in two years?" | CASE | [generic] | Altitude first: the trade-off between fleet scale and hardware commitments. Name what you would decide now and what you would defer. | Strategy altitude without research on Larkfield's strategy; generic by design. |
| R3-C6 | "Sixty seconds: why should we give this to someone who has never managed managers?" | JD | [grounded] "I've never managed managers" — your message | Hold: "I haven't managed managers." Then the team of six, and the plan for leads. Hold through two follow-ups; concede the specific limit. Never a claim to manager-of-managers work. | Pressure version of R1-A4 at the highest level; the VP will test the same gap. |
| R3-C7 | "What did you get wrong last year, and what did you change?" | VAL | [generic] | Selection scaffold: pick a real mistake you made in the last year. If none comes to mind, say so plainly, then give the nearest thing you did. | Open prompt; it tests honesty about your own errors. |
| R3-C8 | "What would you need from me in your first 90 days?" | VAL | [generic] | Name two or three concrete needs, such as decision rights on the roadmap and access to hardware leadership. Keep it to what you would actually ask for. | Reciprocity for a VP round; the answer shows you think about the seam from the top. |

### Reverse questions (round 3)

1. "What does this organization get wrong about leadership that you'd want the next manager to fix?" — It asks for the VP's own diagnosis.
2. "How do you decide between a roadmap commitment and a reliability investment?" — It ties to R3-C1 and to the 60% figure.
3. "What separates a manager here who grows people from one who doesn't?" — It is a values question asked back.
4. "What would make you say in six months that this hire was a mistake?" — It exposes the success criteria directly.
5. "How do you want this group to work with hardware leadership?" — It asks about the partnership requirement at the top of the org.

## Persona table

| Persona | Round | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 1 | Live problem on the two squads' roadmap | High: the hiring manager is buying capability (hiring-manager prior) | Clarify, structure, metrics; say the framework before using it |
| Skeptic | 1 | Probes the scope jump and the hardware gap | High: F2, F3 and F5 are the gaps most worth derisking | Rehearse R1-A4 and R1-A6 until the acknowledgment is plain |
| Data-Driven Prober | 2 | Asks how the 60% figure was counted | High: F6 is the headline figure the staff engineers will check | Defend-the-number slots; say when you do not know how it was counted |
| Pressure | 2 and 3 | Holds the scope jump against you | Medium to high: the scope jump is the question's pull | Hold, then concede the specific limit |
| Peer Evaluator | 2 | Seam with product; credit for the quarter | Medium: product is the peer on the roadmap | Seam principles; disagreement story with both spine and tact |
| Values/Behavioral | 3 | Values questions tied to your stories | High: the recruiter named the round | Map the quote; give an honest branch where none exists |
| Case/Strategist (altitude) | 3 | Two-year direction | Medium: no company strategy was researched | Trade-offs; generic by design |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "Lead two squads building device-management services" | R1-A1, R1-A4, R2-B4, R3-C5 |
| "own delivery, hiring and growth for 11 engineers" | R1-A5, R1-A8, R2-B6, R2-B8, R3-C4, R3-C8 |
| "partner with hardware and product on roadmap" | R1-A2, R1-A3, R1-A6, R2-B5, R3-C1 |
| Managing leads (your scope note) | R1-A4, R3-C6 |
| Stated negatives: manager-of-managers, hardware roadmap | R1-A4, R1-A6, R3-C6 |
| Growth of engineers | R3-C4 — the role text raises it; no quoted growth outcome in your material |

No requirement is left uncovered.

## Sources

**Provided documents:** your message (your background, the three rounds, the recruiter's words "values and leadership philosophy"); your role description (Larkfield Systems, Engineering Manager). No dossier was present. No full JD text was supplied.

**Searches and fetches sent:**

| Query | Result |
|---|---|
| "Larkfield Systems values industrial IoT" | refused (search permission was not granted in this session) |
| "Larkfield Systems interview process engineering manager" | refused |
| "Larkfield Systems device management strategy news" | refused |

No fetches were sent.

**Research tier:** L1 — searches 0 of 6 returned results, fetches 0 of 2 used.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet not built; the VP round's values questions rest on the recruiter's words and your material only |
| 2. Larkfield interview process, engineering manager | unavailable | Loop comes from your message and the recruiter's description, which is enough to establish the three rounds; persona weights follow them |
| 3. Larkfield strategy and recent news | unavailable | The CO bank is absent; the strategy questions (R3-C5) are generic |
| 4. Interviewer name and Larkfield | n/a | No interviewer names were given, so no query could be formed |
| 5. Representative engineering manager JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full job description text → six [grounded] rows gain their exact requirement quotes, and the coverage table gains the rest of the posting.
- The Director's name and the panel members' names → an interviewer read, persona weights per person, and a reverse question tied to their career path.
- Larkfield's published values page, pasted → a values cheat sheet for round 3, and VAL questions mapped to specific values.
- Larkfield's strategy note or recent news, pasted → CO questions and a grounding brief. A deeper research pass is also available, several more minutes and up to six more searches and two more fetches, if research permission is granted.
- Any stated location, schedule, work-authorization or pay term from the posting → a gate row, which the pack would surface without bridging.
- Your recruiter's note on each round's format, and any pre-declared deliverable → coverage for it, plus a graded-deliverable section.
- Your prep time before Tuesday → a prioritized triage schedule sized to it.
