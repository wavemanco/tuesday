# Interview prep: Product Manager, Platform APIs at Quartzline

Interviewer: hiring manager, name not given. Round: 45-minute conversation with the hiring manager, Thursday.
Built on: your underwriting dossier (`tuesday-dossier.md`, generated 2026-08-14, decision `conditional_go`). That is about three months before today, so check the open unknowns below against what you now know.

## How to use + type key

Personas are how a question is asked. Types are what it scores.

- **JD**: can you do the listed job, including its gaps
- **EXP**: do your past claims survive scrutiny, and what did you actually do
- **CASE**: structure and reasoning on a live problem from the role
- **VAL**: values alignment (none in this pack: no values-style round is detected)
- **CO**: company and strategy knowledge (none in this pack: live research was refused)

Guidance is scaffolding, not a script. Say the plain acknowledgments in your own words.

## Fit snapshot

Requirements are the dossier's `role_profile` lines. Evidence is quoted from the dossier's `verified_candidate_evidence` (E1 to E3). No requirement here is a term gate, so there are no `hard_gate` rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (R1, dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | low | [inferred] | transferability | Bridge, limit named: "I haven't held the product manager title or owned a roadmap. What I've done is lead client integrations of the vendor's REST APIs, from scoping through go-live." Your material shows integration leadership, not product management; the pack's limit is that observation, not a claim you make. |
| F2 | "Owning a roadmap and prioritization authority" (R1 sub-claim, dossier uncertain_or_weak_areas) | none given | none | [grounded] | capability | Plain acknowledgment from the dossier's acknowledge_gap area: "I haven't owned a product roadmap." Then a ramp plan, said as a plan you would follow and never as a past. No bridge: the underwriter found no evidence, so do not build one live. |
| F3 | "Shipped API or platform products" (R2, dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | transferability | The quote shows you leading integrations of someone else's APIs as the client, not shipping an API product. The dossier does not grade R2; this row is the pack's observation. Say what you led, from the quote, and say it was the client side. |
| F4 | "Technical fluency: API docs, schemas" (R3, dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | presentation | Reword only this quote: "I led the integrations of the vendor's REST APIs, through architecture, from scoping to go-live." Adds no practice, figure or tool. |
| F5 | "Stakeholder management across engineering, sales, customers" (R4, dossier role_profile) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | medium | [grounded] | discovery | Confirmed, with limited inspectable proof, so expect a probe. Answer slot: if engineering or sales were in those sessions, say who and how you handled them; if they were not, say so and say who the sessions were with. |
| F6 | "Agile delivery experience" (R5, preferred, dossier role_profile) | none given | low | [grounded] | discovery | Dossier clarify area. Nothing in your evidence speaks to agile delivery, so the answer is a slot, not a bridge (see A4). |

## Prohibited list

From the dossier's `prohibited_claims`, plus one inflated form this pack built locally.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims; F1 | "I haven't held the product manager title or role." Plain acknowledgment sourced by the prohibited_claims field. |
| Having owned a product roadmap | Dossier prohibited_claims; F2 | "I haven't owned a product roadmap." Plain acknowledgment sourced by the prohibited_claims field. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." The nearest true thing is E3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product" — input, not setting. |
| Having shipped a partner-facing API platform | Local: R2 widened from E1 | E1 at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation: the material shows client integrations, not a platform you shipped. No first-person negative. |

## Persona table

Weights come from the hiring-manager prior (Case/Strategist and Skeptic). There are no interviewer signals, so no adjustments. No loop source establishes the loop, so the flat archetype fallback applies, and these weights rest on that pattern, not on Quartzline's documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Presses the PM-title gap and the roadmap ownership gap | High. Hiring-manager prior, plus the dossier's named objection. Weight 5. | Rehearse A1 until it is boring; bridge from E1 with the limit named; plan the ramp. |
| Case/Strategist | Live roadmap and adoption problems | High. Hiring-manager prior. Weight 4. | Clarify first, then objective, approach, metrics, risks. |
| Data-Driven Prober | Probes the 30+ count, adoption metrics, roadmap-input outcomes | Medium-high. Adoption is a named responsibility with no baseline, and E1 and E3 carry headline claims. Weight 4. | Say how you counted; name your weakest assumption; say plainly when you do not know. |
| Pressure | Pushes on the objection and on how much was yours | Medium. Not the prior, but the objection invites it. Weight 3. | Pause, restate, hold through two follow-ups, then concede the specific uncertainty. |
| Conversational | Opens with the journey and casual questions on API docs | Low-medium. Weight 2. Casual questions are still scored. | A 90-second arc from E1 to E3; say the gap yourself. |

## Question banks

The highest-ROI rehearsal is **A1**. The dossier named this objection, so the pack uses its wording.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook". Plain acknowledgment sourced by the dossier's prohibited_claims and acknowledge_gap fields. | Lead with the plain acknowledgment: "I haven't held the product manager title or owned a roadmap." Then the bridge with its limit: "What I've done is lead client integrations of the vendor's REST APIs, from scoping through go-live, and write the internal integration playbook." Then the ramp, said as a plan: what you would do in your first months to learn roadmap and prioritization work. Do not argue that integration work equals PM experience. Hold through two follow-ups by returning to the integrations; concede the roadmap gap, never the bridge. | The underwriter named this as the likeliest objection, so it gets the deepest rehearsal. It rests on F1 and F2. The question is worded as the dossier wrote it because every negative in it has a source. |
| A2 | "Which roadmap decisions would you make alone on this platform, and which would sit with the two squad leads?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (JD line from dossier role_profile) | Say you have not held decision rights over a roadmap, so you would want to see how decisions are split before saying which you would own. Ask for the decision-rights map. Do not claim any decision as yours. | The squad-authority question is the dossier's top unknown, and the answer is the one to test in the drill. Rests on F2. |
| A3 | "The role asks for three-plus years of product management. Where does your experience sit against that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Same bridge as A1, shorter. Answer slot: give the years of integration work you can state, in your own words. Say plainly that none of it was product management. | The short form of A1 for a sharper opening. Rests on F1. |
| A4 | "What does agile delivery look like for you inside a product team?" | JD | [grounded] "Agile delivery experience" (R5, dossier role_profile) | No quote speaks to agile delivery, so this is a clarify slot. Answer slot: if you ran sprints or a delivery cadence with a product team, say how; if you did not work that way, say so and say what you would want to confirm about how this team defines agile delivery. | The dossier's clarify area for R5. Rests on F6. |
| A5 | "Of the 30+ integrations, how many did you lead end-to-end, and what was actually yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the number: say how you counted them, name the assumption behind the count you would defend least, and say which parts were yours. Answer slot: if you did not keep a count, say so. | A headline figure is a magnet for probers. Rests on F3. |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd get the first partner-facing API change through two squads — what do you need to know first?" | CASE | [generic] | Clarify first: the partner's need, who owns each squad's change, and the adoption baseline. Then objective, approach, metrics, risks. Make no claim about your past. | A live problem from the JD's two-squad responsibility. |
| B2 | "Partner API adoption dropped 20% last quarter. Diagnose it." | CASE | [generic] | First ask how adoption is counted and what the baseline is. Segment partners, then think aloud. | Adoption metrics are a named responsibility with no stated baseline. |
| B3 | "A partner asks for a change that would break an existing schema. What do you do?" | CASE | [generic] | Ask which consumers depend on the schema, then compare versioning options and name who decides. | Covers R3, technical fluency with schemas. |
| B4 | "A large integration partner is threatening to churn over a broken integration. Walk me through your first week." | CASE | [generic] | Map stakeholders across sales, engineering and the customer. Say what you would learn before acting. This is a plan, not a past. | Covers R4 with a live problem. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say how the count was made in your own words. Answer slot: if no count was kept, say so plainly. | Defend-the-number slot on F3's figure. |
| C2 | "Which adoption metric would you track for partner APIs, and what would it miss?" | JD | [generic] | Name one metric. Say you do not know the current baseline. Say what it would miss, such as integrations that are live but unused. | Adoption metrics have no stated baseline, so expect a probe. |
| C3 | "Which assumption behind the 30+ figure would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name the weakest assumption before the interviewer does. Answer slot: if you cannot name one, say so. | Weakest-assumption move for the same figure. |
| C4 | "Roadmap-input sessions — what came out of them, and did any of it reach a roadmap decision?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | This is confirmed, with limited inspectable proof, so volunteer that limit first. Answer slot: if something reached a decision, say which; if nothing did, say so. | The dossier expects a probe here (E3, medium). |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate. Hold the bridge: the integration work is adjacent, not the same. Concede the specific uncertainty: the roadmap ramp. Do not fold on the core claim. | Pressure version of A1: hold, then concede. |
| D2 | "That integration result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the word "led" as it stands. Say which parts were yours and which were the team's. Concede the team's share plainly. | Attribution under pressure on E1. |
| D3 | "If this goes wrong in six months, what does it cost us?" | JD | [generic] | Concede the specific uncertainty: the roadmap ramp and the decision rights you have not yet seen. Do not concede the integration record. | Hold-then-concede on the risk. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: integration leadership, the playbook, roadmap input. Then name the gap yourself, before it is asked. | The opener is scored. |
| E2 | "What are you actually working with in API docs and schemas these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name what you used from that quote, with nothing added. Answer slot: name the docs and schemas you worked with; if you did not work with schemas directly, say so. | Covers R3, the least-evidenced technical requirement. |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| R1 3+ years product management | A1, A3, D1 |
| R1 roadmap and prioritization authority | A2, D3 |
| R2 shipped API or platform products | A5, C1 |
| R3 technical fluency, API docs and schemas | B3, E2 |
| R4 stakeholder management | B4, C4 |
| R5 agile delivery | A4 |

Totals: 18 questions (A 5, B 4, C 4, D 3, E 2).

## Reverse questions

Each one's "why it lands" comes from a dossier risk or employer question.

1. "Which roadmap decisions does this PM make alone, and which belong to the two squad leads?" — tests the decision-authority unknown the JD names but does not evidence.
2. "How is partner API adoption measured today, and what is the current baseline?" — adoption is a named responsibility with no stated baseline.
3. "What would make the first six months in this role a clear success?" — shows you want to be judged on something specific.
4. "Where do partner requests and squad capacity conflict most often right now?" — tests the two-squad seam the role sits on.
5. "What did the last person in this role get right, and what would they have changed?" — shows whether the role was vacated over authority or scope.

## Sources

- Provided: `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). Consumed sections: `role_profile` (requirements R1 to R5, unknowns), `handoff_to_mock_interview` (verified evidence E1 to E3, uncertain areas, objections, risks, employer questions, prohibited claims), `decision` (context only). Absent from the dossier: `evidence_map`, `evidence_state`, `risk_register`. Unresolved risks came from `opportunity_risks_to_validate`.
- Search sent: "Quartzline platform APIs product manager" (standard). Refused: search permission was not granted. No fetches were sent.

Research tier: L1 — searches 0 of 6 (1 refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Refused. Would have moved the values cheat sheet, which the pack omits because no values-style round is detected. |
| 2. Quartzline interview process | unavailable | Refused. Would have moved the loop structure. Persona weights rest on the hiring-manager prior, not a documented loop. |
| 3. Quartzline strategy / recent news | unavailable | Refused. Would have moved CO questions. The pack has none. |
| 4. interviewer name | n/a | No name given, so there was no query to form. |
| 5. representative JD | skipped | The dossier's `role_profile` fixes the requirements. |

L2 deep research was not run and was not offered in a form that could run without search.

## Upgrade menu

- Anything learned since August about decision authority or the adoption baseline → updates F5, A2 and C2 from evidence; new facts become quoted material.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
- Permission for web search → the three refused targets (values, loop, strategy), so the loop weights and a CO bank rest on sources. The deeper pass would add up to 6 more searches and 2 fetches, several minutes.
- Inspecting the integration playbook → E2 moves from dossier-stated to inspected.
- A count of the 30+ integrations, in your words → C1 and C3 quote it instead of asking for it.
- The recruiter's note on the round's focus → reweights the persona table.
