# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer (both report to the same VP). Pronouns not stated, so this pack uses "they."
**Round:** one 60-minute conversation.
**Research tier:** L0, provided material only (no searches run; see Sources).

**Built on:** your JD highlights (not the full JD text), your candidate summary (no CV), your interviewer description, and your research note. Where a fact was not in those, the pack says so or leaves an answer slot.

## How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the beats in your own words.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior against published values. No values were in hand, so these run on scaffolds. |
| EXP | Work-experience deep-dive | Whether your stated experience survives scrutiny, and what you did yourself |
| JD | Role / JD-driven | The stated responsibilities and qualifications, including the gaps |
| CO | Company and strategy | Depth of homework on Northwind's priorities and competitive position |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

Each row sets a JD requirement against the evidence you gave, quoted exactly. Bridge language is what you may say about each gap.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | low | [grounded] | transferability | Say the nine years in product strategy and ops, at their own scope, and stop there. Anything past that is an answer slot: if you owned go-to-market for a product line, say what you owned and how you decided; if you did not, say so plainly and point to the closest thing your material carries, the revenue model in F3. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | low | [grounded] | discovery | Your material does not show lifecycle whitespace. The model touches revenue, not land, adopt, expand or renew. Answer slot: if any of your work surfaced revenue outside one of those four stages, say which stage and what you did; if none did, say so and say how you would look for whitespace first. |
| F3 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | This is adjacent. A partner-level model used in negotiation is not a partner motion designed for a product line. Say the model and the negotiations at their own scope. Answer slot: if you set any part of how partners were paid, enabled or chosen, say which part and how you decided; if the model stopped at the negotiation, say so and say how you would design a partner motion from it. |
| F4 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | low | [grounded] | presentation | The bridge rewords only the quote: "I work in SQL and Tableau." Expect a probe on independence. The answer is one analysis you ran yourself (see A4). |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms: targets agreed across orgs. Expect a probe on it. Lead with the targets and the consensus in those words. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [grounded] | transferability | Daily use is adjacent to AI experience, not building with it. Words: "I use AI tools every day." The material says use, not build, so do not describe anything you built or shipped. |
| F7 | Quota-setting and sales-org fluency. Not in the JD highlights; role-family prose, so [generic] for the requirement, and flagged because the role sits in sales strategy. | "set annual volume targets with cross-org consensus" (your message); "No classic sales-ops or quota-setting experience." (your message) | low | [grounded] | discovery | Your material records volume targets, not quota or sales-ops work. This row writes no words of its own: the live question and its honest branch are in D2. |

**Note on the evidence column.** Every quote is verbatim from the summary you sent, not from a CV or from Priya's own writing. Until Priya's own sentences are in hand, treat each quote as a lead to verify, and expect probes on the specifics.

## Grounding brief

Source: your research note. Not re-checked, since this run is L0.

- **Three stated priorities:** enterprise expansion; an AI copilot launch called "Compass"; reaching profitability.
- **Main competitive threat:** bundling by a much larger platform vendor.
- **Vocabulary to use:** "enterprise expansion," "Compass," "profitability," "bundling."
- **Not in hand:** the current segmentation language, headline numbers, leadership context, and recent moves beyond the note. Do not treat the note as current until it is checked.

## Reading the interviewer

Public footprint only, as you described it. No published talks or writing were checked.

- **Career pattern:** a pricing and monetization spine, with one early-stage-startup chapter.
- **Self-described style:** "relentlessly data-driven."

**Practical implications:**
1. Every metric will be probed to its assumptions. Name your weakest assumption before they do.
2. Pricing and packaging is their native language. Tie the revenue model to price, volume and margin.
3. The startup chapter means builder stories land, and expect a scrappiness probe from big-company experience.
4. A peer's questions come collegially. Reciprocity counts as much as the answer.

**Mirror opportunities:** shared vocabulary only. Pricing, monetization and partner economics overlap with F3 ("built a partner-level revenue model used in carrier negotiations"). No shared career jump is established, so none is offered as a mirror. Do not build on any shared background beyond the professional one.

## Persona table

Weights are relationship priors (peer), adjusted by the interviewer signals above. Depth follows weight: top 4 to 5 questions, mid 3, low 2.

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 (top) | Walks the ~$400M, the revenue model and the volume targets back to their inputs; asks for the SQL and Tableau work | High. Peer prior, and their self-described "relentlessly data-driven" lifts the Prober. Your headline numbers are the magnet. | Name the weakest assumption first. Say what was yours and what was not. |
| Peer Evaluator | 4 | Seam with sales strategy; "what would you need from me"; credit across teams | High. Peer prior, and the same VP means their sales-strategy work overlaps yours. | Reciprocity framing. Propose seam principles; do not claim to know their seams. |
| Case / Strategist | 4 | Pricing-tilted live problems on partner terms, margin and whitespace; a question on the stated priorities | Medium-high. Their pricing spine tilts cases toward price and unit economics, and the JD's whitespace and partner lines are live-problem material. Raised above mid because the research note makes a CO question likely. | Clarify, then objective, segmentation, approach, metrics, risks. Name the unit economics first. |
| Skeptic | 3 | The partner-motion and quota gaps; "why move" | Medium. F3 and F7 are the predictable objections. | Rehearse D2 until it is routine. Calibrated candor, not bluffing. |
| Conversational / Rapport | 2 | Opening "journey" question; a casual AI question | Medium. Peer rapport. Casual questions are still scored. | A 90-second arc; keep the AI answer short. |
| Pressure / Stress | 2 | "Sixty seconds" on why this role; "how much was you" on the revenue model | Low-medium. A peer seldom stress-tests, but a sharp one may. | Hold, then concede. |
| Values / Behavioral | 2 | Unpopular truths; customer against metric | Low. No values-style round detected and no published values in hand. Kept at 2 because cross-functional influence is a JD line. | Selection scaffolds ending in an honest branch. |

## Prohibited claims

These claims are not coached, anywhere in this pack. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: your material says product strategy and ops. |
| Designed the partner motion | Inflated form of F3 | The revenue-model quote at its own scope. The pack's observation: the material says a model used in negotiations, not a partner motion designed. |
| Set quotas or ran sales ops | Inflated form of "set annual volume targets with cross-org consensus" | That quote at its own scope. The pack's observation: volume targets, not quota. The coach's note of no sales-ops or quota experience is not a first-person negative for you to say; use your own words in D2's slot. |
| Built AI features | Inflated form of F6 | "uses AI tools daily" at its own scope. |
| Sole owner of the ~$400M uplift | Inflated form of the figure's attribution | "credited with a ~$400M ARR uplift" at its own scope. Which part was yours is the answer slot in A1 and B3. |

Not listed: how the ~$400M was counted. The material is silent, so A1 holds an answer slot instead.

## Question banks

Ordered by persona weight. Each row: the question, its primary type, the provenance (the label, then every sentence the guidance rests on), the answer guidance, and the rationale.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend the number in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Name that assumption before they do. Answer slot: if you can say how it was counted, do so and say which part of the change was yours; if you cannot reproduce the count, say so plainly and say what you can show. | The headline figure is the likeliest probe target. EXP because it tests attribution. The material gives no counting method, so none is supplied. |
| A2 | "Walk me through the inputs to the partner-level revenue model. Which one would you defend least?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the inputs in your own words, then the one you would defend least and why. Answer slot: say which inputs were yours to set and which came from elsewhere; if you did not set the inputs, say so plainly and describe what the model was used for. | Probers go to the model's inputs first. F3 is the nearest partner-motion evidence, so partner design gets tested here. JD because it scores the partner requirement; EXP is the delivery. |
| A3 | "How were the annual volume targets set, and where did the cross-org consensus come from?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Say the basis for the targets, which orgs were in the room, and how the consensus was reached, in your own words. Answer slot: if a figure was the basis, say how it was counted; if the targets had no model behind them, say so and say what did set them. | Targets are the closest thing in your material to quota (F7). F5 is the cross-functional requirement. The prober will ask for denominators. |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one analysis you did end to end. Name the question, the grain of the data, and the result it produced. Answer slot: if you cannot name one you ran yourself, say so plainly and give the nearest piece you did run. Do not describe a dashboard as an analysis you built if you did not build it. | The JD asks for independent analysis in SQL and Tableau. The quote names only the tools, so the example is the answer. The question is an open prompt; its theme comes from the JD line. |
| A5 | "Which AI tools do you use most, and what do you use them for?" | JD | [grounded] "uses AI tools daily" | Name the tools by category and what you use them for, in your own words. Answer slot: if you check the outputs, say how; if you do not, say so. Keep it under 60 seconds. | AI is a plus, so it is scored lightly, but a prober will push past the first answer. JD because it scores the plus-skill. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between emerging-products GTM and sales strategy, and what happens when we disagree?" | JD | [generic] persona stem; [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles, not knowledge of their seams: who sets price, who owns the partner list, how a disagreement is settled on evidence. Ask one question back about where the seam hurts most. Disagreement: pick a time you held a view on a number with a peer and stayed in the room. If none comes, say so, then give the consensus in A3. | The seam is where a peer tests whether the hire adds to or lightens their load. JD because it scores the cross-functional and partner requirements. |
| B2 | "What would you need from my team to make a new product line work?" | JD | [generic] persona stem; [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity first: name what you would bring to their team from the revenue model, as an offer, not as a past claim. Then one specific ask, such as the sales-side data you would need to test partner economics. | Personas name this as a peer probe. Reciprocity is the answer a peer scores. The reverse-question bank covers the candidate's own version. |
| B3 | "How do you handle credit when work spans teams? Take the ~$400M." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say who else was involved, in your own words, and then your part. Answer slot: if the credit was larger than your part, say so and say how it came to be set that way; if the change was yours to propose, say so and say what you did to share the credit. | Credit across teams is a peer probe, distinct from A1's method question. Same figure, different test: attribution across people, not counting. |
| B4 | "If we disagreed on whether a new product line sells through partners or direct, how would we settle it?" | JD | [generic] persona stem; [grounded] "partner-motion design experience required" | Propose a decision rule: the evidence both teams accept, who decides, and what would change your mind. Keep to principles. Do not claim a past channel decision. Answer slot: if you have settled a channel decision with a peer, say how; if not, say how you would test it first. | Partner-motion design is required; a peer disagreement is the probe. Principles only, so no history is presupposed. |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch a go-to-market for a partner-sold data product. What do you need to know first?" | CASE | [inferred] typical GTM-lead problem for a partner-sold product, not stated as this team's practice; [grounded] "own GTM strategy for two new product lines" | Clarify before structuring: who the partners are, what they earn, what they already sell, what the price unit is. Then objective, segmentation by lifecycle stage and partner type, approach, metrics, risks. Say the structure aloud. Make no claim about your past. | CASE because it scores live structure. Covers the GTM-ownership requirement and partner-motion design together. |
| C2 | "A partner wants a bigger margin share to carry one of the two new lines. What do you do?" | CASE | [inferred] typical partner-economics negotiation; [grounded] "main competitive threat is bundling by a much larger platform vendor" | Pricing first: what the margin buys (volume, retention, bundle position), the unit economics on both sides, what you would trade, and your decision rule. If the bundling threat applies, name it and how it changes the trade. | Their pricing spine makes this the native case. The bundling threat from your note is the competitive frame they will expect. |
| C3 | "Where is the whitespace across land, adopt, expand and renew for a new product line, and how would you size it?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" | Structure by lifecycle stage. Give one metric and one data source per stage. State the sizing approach; do not invent a number. Name the first cut you would run in SQL. | Covers the whitespace requirement. CASE because the sizing is live; the SQL link bridges to A4. |
| C4 | "Enterprise expansion, the Compass copilot and profitability are the stated priorities. Which should a new product line serve first?" | CO | [grounded] "three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Pick one, state the trade-off, and say what you would give up. Present it as your position, not as Northwind's internal sequencing. Include the bundling threat if it helps the argument. | CO at L0, from your note only. Not re-checked, so keep the claims to what the note says. CASE is the delivery. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" | Name the one area of this JD where your material is thinnest, in your own words. The pack's read is partner-motion design (F3), and that is the pack's analysis, not your words. Then a 30-day ramp: who you would learn from and what you would measure first. | The Skeptic's stem. Partner-motion design is the headline required item, so the gap lands there. |
| D2 | "How would you set a quota for one of the two new product lines, and what would you need from sales operations to defend it?" | CASE | [inferred] quota-setting for a new line is typical of a GTM-strategy role; not stated in the JD highlights | Structure before numbers: capacity, ramp, and what the number is for. Name what sales operations would need to supply, and what you do not know yet. Hold the structure through two follow-ups: "What if sales says it's unachievable?" and "What do you give up if you set it high?" Answer slot: if you have set a quota or capacity figure before, say how and whose it was; if you have not, say so plainly and say what you would ask sales operations first. Concede specifically; never fold the structure. | Highest-ROI prep in this pack. The material records volume targets and no quota or sales-ops work (F7). Dan's role is sales strategy, so this is where the objection lands. A live problem presupposes no past, so it can be asked directly. The deepest rehearsal: two follow-ups, the concession wording, and the limit named before it is asked. |
| D3 | "What draws you from a consumer-tech company to a B2B data-infrastructure company?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Say the draw in your own words, with one specific reason tied to this role. Answer slot: if the reason is not yet clear to you, say so and say what you are testing for. The pack does not supply a reason. | Motivation consistency is the classic Skeptic probe. EXP because it tests the career story. F1's transferability makes the move the question. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pre-scripted 90-second arc: consulting, then consumer-tech product strategy and ops, then the revenue model used in negotiations, then the volume targets. Each beat is a quoted sentence at its own scope. Stop before the ~$400M and let them ask. Hold the reason for the move for D3. | Casual register is still scored. This arc is the one prepared answer that does not recite the CV. |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Keep it to 30 seconds: the tools you use and one thing they do for your work, in your own words. Answer slot: if you have built anything with AI, say what; if not, say that you use it. | Casual version of A5. Relaxed in tone, still the plus-skill being scored. |

### P. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should this role be yours?" | JD | [grounded] "partner-motion design experience required"; "strong cross-functional influence" | Answer in 60 seconds from the fit you can show: the revenue model used in negotiations and the volume targets with cross-org consensus, in those words. Hold through one follow-up: "Why not someone with quota experience?" Hold by naming the fit, then concede the gap in one specific line. | Tests composure under a time box. Hold-then-concede: the held position is only what the quotes carry. |
| P2 | "That revenue model: how much of it was actually you?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold: say which part you built, in your own words, and name the inputs you did not set. Hold through two follow-ups by returning to the model's scope. Concede specifically what was shared. Never fold on "built." Answer slot: if the model was built with others, say so. | Attribution pressure on the strongest partner-motion evidence (F3). Hold, then concede. |

### V. Values / Behavioral (weight 2)

No published values were in hand, so these run on scaffolds. Dropping the values cheat sheet is deliberate.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; theme from [grounded] "strong cross-functional influence" (JD highlights) | Selection scaffold: pick a time you told senior people something they did not want to hear and the room still worked afterwards. It needs a stake, the truth you said, and what happened. If none comes to mind, say so plainly, then say how you would handle it. | Included at low weight because cross-functional influence is a JD line. No values were supplied, so there is no mapped story. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] persona stem | Selection scaffold: pick a time a customer outcome and a target pulled apart and you chose the customer. Say the metric, the customer, and the choice. If none comes to mind, say so plainly and say how you would weigh it. | Generic values probe. Expect it only if the round is framed as values-led. |

**Requirement coverage**

| Stated requirement | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" | C1, C4 |
| "identify whitespace across land/adopt/expand/renew" | C3 |
| "run independent analysis in SQL and Tableau" | A4 |
| "partner-motion design experience required" | A2, B4, C2, D1, P1 |
| "strong cross-functional influence" | A3, B1, V1, P1 |
| "AI experience a plus" | A5, E2 |
| Quota-setting and sales-org fluency (not in the JD highlights; F7) | D2 |

Every stated requirement has at least one question. None is uncovered.

**Session totals:** 22 questions (A 5, B 4, C 4, D 3, E 2, P 2, V 2). Within the 18 to 26 range.

## Reverse questions

Ask these in the time at the end. Do not give a generic answer to "any questions for me?"

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization, and spent time at an early-stage startup. Which of those habits do you bring to sales strategy?" | Ties to their own path. It turns the interview into a peer conversation and shows you read their profile. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the peer test. It signals you are thinking about their load, not only yours. |
| R3 | "Where does emerging products hand off to sales strategy today, and where does that handoff break?" | A seam question. Shows you think at the seam, not only at the org chart. |
| R4 | "How does Compass change what the two new product lines need from sales?" | Uses your research note. Invites their view on how the three priorities sequence. |
| R5 | "How is the bundling threat from the larger platform vendor showing up in pricing conversations?" | Pricing-native, and tied to the stated competitive threat. Do not name the vendor. |
| R6 | "Which of the three priorities gets the first call on go-to-market headcount?" | Forces a trade-off view, and shows you know the three priorities. |

**Guidance:** if asked "any questions for me?", ask R1 first, then R5.

## Sources

**Provided:** your message (role, JD highlights, candidate summary, interviewer description, the three priorities, the bundling threat); your research note, not re-checked.

**Searches and fetches sent:** none. Links you gave: none (`user links read 0`).

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | The values cheat sheet, which is dropped. V1 and V2 run on scaffolds. You chose L0. |
| 2. Northwind interview process, strategy role family | unavailable | Loop structure. The peer prior stands unchanged. You chose L0. |
| 3. Northwind strategy and recent news | skipped | Your research note already fixes the three priorities and the competitive threat. |
| 4. Dan Kovac, Northwind | unavailable | The interviewer read and R1, which rely on public footprint. A name was given, so a query could be formed. You chose L0. |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the requirement list and the JD-tagged questions. |

## Upgrade menu

- Full JD text → quotes in the fit snapshot become exact posting wording. If it names a location, work pattern or work authorization, that row becomes a hard_gate row.
- Priya's own written account, or a CV → her sentences replace your summary in the evidence column, and the banks quote her, not you.
- Dan's public profile and talks, run as L1 (6 searches, 2 page fetches) → persona weights from their published writing, and a tailored reverse question. L2 (further searches) adds loop and talk research.
- The recruiter's prep email → focus areas, and coverage of any pre-declared deliverable.
- Northwind's published values → a values cheat sheet, and V1 and V2 mapped to stories.
- Your research note re-checked at L1 → confirms the three priorities and the threat are current.
- Prep time available → a prioritized schedule for the time you have.
- `tuesday-dossier.md` → would add verified evidence and prohibited claims from an underwriter check.
