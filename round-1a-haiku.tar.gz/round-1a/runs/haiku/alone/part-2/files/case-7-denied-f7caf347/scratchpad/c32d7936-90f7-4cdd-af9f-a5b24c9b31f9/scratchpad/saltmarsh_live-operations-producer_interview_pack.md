# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed (see the upgrade menu).
**Format:** 60 minutes, Friday. Round type not stated.
**Candidate:** Femi.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = can you do the listed job, gaps included. **EXP** = do your past claims survive scrutiny. **CASE** = structure and reasoning on a live problem. **VAL** = does past behaviour show the values. **CO** = company and strategy knowledge (not yet researched, so none here).
- The guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements come from the JD you supplied. Evidence comes only from your own message. Nothing has been checked outside it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title's weekly drop calendar over two years. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title scope makes a probe likely. If you planned for more than one title, say which and how. If you planned for one, say so and describe how that calendar worked. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote already reaches this requirement. It is a line with nothing inspected behind it, so expect a probe on what the calendar contained. Lead with the quote's own terms. |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination across these teams. Answer slot: name the teams you coordinated with on a content update and how the handoffs worked. If you coordinated with none of them, say so and say how you would start. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Your material says you wrote the checklist and QA still uses it. It does not say you managed releases. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: if you ran release sign-offs with QA, say how. If you did not, say so plainly. |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting retention numbers is adjacent to owning KPIs. Your material shows no post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported or ran a post-event review, say what you did. If you did not, say so plainly. |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote already reaches this requirement in role terms. No figure is given, so no defend-the-number slot is raised yet. Expect a probe on how the numbers were counted (see C1). |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | The years are in your material. Your material does not say the puzzle game was live-service or that you produced it. Bridge: "I was an associate producer at a puzzle-game studio for four years." Answer slot: if the main title was live-operated, say what that meant in your own words. If your role was not production, say so. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist shows written work. It does not show clarity. Pack observation: your material shows no other written communication. Answer slot: name one written piece a team acted on, and what it changed. |
| F9 | Team leadership. Not in the JD text. Implied by F3's coordination line — [generic] | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated this absence. Words: "I haven't led a team." Then how you would coordinate without line management, given as a plan and never as a past. |
| F10 | In-app purchases. Not in the JD text. A gap you named — [generic] | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated this absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation side, given as a plan. Pack observation: the JD does not mention in-app purchases. |

## Prohibited claims

These claims will not be coached anywhere in this pack. Each is built from the fit snapshot above.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or led teams through updates | Negative you stated (F9) | "I haven't led a team." No answer slot. |
| Ran the live-events calendar for two titles | Inflated form of F1 | Your quote at its own scope: the weekly content-drop calendar for one main title. Pack observation: your material says one title and weekly drops, not events across two titles. |
| Owned the post-event review and its KPIs | Inflated form of F5 | "I presented the monthly retention numbers to the studio head." Pack observation: your material shows no post-event review. |
| Ran release sign-off with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Set the retention targets | Inflated form of F6 | "I presented the monthly retention numbers to the studio head." |
| Worked on a game with in-app purchases | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." No answer slot. |

## Persona table

Relationship prior: a hiring-manager round, which weights Case and Skeptic highest. This is an assumption. Your note did not say who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live plans and diagnoses from the calendar and retention work | High. The role is planning and running events, so live problems are the natural test. | Clarify, then structure, then name the risks. Think aloud. | 4 questions (A1 to A4) |
| Skeptic | Pushes on team leadership and the in-app purchase gap | High. Two gaps are stated in your own message (F9, F10). | Say the plain acknowledgment first. Then the nearest thing you carry. Hold through two follow-ups. | 3 questions (B1 to B3) |
| Data-Driven Prober | Asks how retention numbers were counted | Medium. Retention is a JD requirement, and the only metric work in your material is a presentation. | Say what you know about the counting, and say plainly what you don't. Name the weakest assumption. | 4 questions (C1 to C4) |
| Values / Behavioral | Open prompts about bad news and failed updates | Low to medium. No values round was detected, so the theme comes from persona stems. | Selection scaffold. Name a real moment, or say none comes to mind and give the nearest thing you carry. | 2 questions (D1 to D2) |
| Pressure / Stress | Sixty-second challenges to the leadership gap and to authorship | Medium. Your message names the gap plainly, and an interviewer may test it. | Pause. Hold the position you can back. Concede the specific part you have not done. | 2 questions (E1 to E2) |
| Conversational / Rapport | A casual walk-through opener, and a casual question about games | Low to medium. Scored anyway. | A 90-second arc from your quotes. Name a real game you play. | 2 questions (F1 to F2) |
| Peer Evaluator | Seam questions with QA, and credit-sharing | Low. Not a peer round, as far as is known. | State the seam principle, then any real example. | 2 questions (G1 to G2) |

## Question banks

Depth follows weight: the top persona gets 4 questions, mid weight gets 3, and low weight gets 2.

### Case / Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the live-events calendar for one of our titles for next quarter. What do you need to know first?" | CASE (JD) | [grounded] "Plan and run the live-events calendar for two of our mobile titles" — JD; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Clarify first: which title, its goals, the current cadence, the retention baseline, QA windows and team capacity. Then the cadence, the events in order, and the risks. Say aloud which question you would ask first. Your weekly drop cadence is a reference point, in your own terms: "I ran the weekly content-drop calendar for our main title for the last two years." | A live problem from the JD's calendar line. The interviewer is testing structure, not a recalled answer. |
| A2 | "A live event misses its retention target in week two. Diagnose it." | CASE (JD) | [grounded] "comfortable with player-retention metrics" — JD | Confirm the metric definition and the baseline. Split by cohort and by when players joined. Check what else changed that week. Name the two causes you would check first, and what would rule each one out. Do not invent a figure. | Raised by the JD's retention line. A live diagnosis scores structure and the weakest-assumption move. |
| A3 | "Design and art want this update this sprint, and QA wants another week. What do you do?" | CASE (JD) | [grounded] "coordinate design, art, engineering and community teams on each update" — JD | Name who decides, and what the risk is. Separate what QA must check from what the schedule wants. Propose an option that protects the checklist. Say what you would tell each team. No past claim is made here. | Raised by the JD's coordination line. Tests the decision, not a record. |
| A4 | "What is on the release checklist for a live update, and which step would you change first?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Walk through the checklist's stages in your own words. Name one step you would change and why. If you would change none yet, say so and say what you would check first. | Premised on the quote. Tests whether you know the artifact you wrote. |

### Skeptic (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message; plain acknowledgment: "I haven't led a team." | **Highest-ROI prep in this pack.** Say the plain acknowledgment first. Then the nearest thing you carry: the content-drop calendar and the QA checklist, each in its own terms. Concede the leadership gap specifically. Hold through two follow-ups by returning to the calendar and the checklist. Never add a team you led. Expected follow-up: "Who did you direct on a content update?" The answer is only what you did, or a plain no. Then give a ramp plan, as a plan. | This is the most predictable objection: a coordinating role with no team-leadership record. It gets the deepest rehearsal. |
| B2 | "I don't see anyone you've managed in this background. How would you coordinate four teams on an update without managing them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Open with "I haven't led a team." Answer slot: if you coordinated people on a content update without line authority, say how it worked, in your own words. If you did not, say so, and say how you would set up that coordination. Do not claim leadership from the calendar work. | The premise is your own stated negative, so the question may carry it. The coordination line is raised by the JD. |
| B3 | "Your background is a puzzle game. Have you worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Say: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation side, given as a plan: which data you would want first. | The JD does not raise in-app purchases. This probe is asked as a check on your own stated gap, and the pack records that. |

### Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP (JD) | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Say what the number measured, and who set the counting rule. If you did not set it, or do not know its exact rules, say so plainly. Then name the assumption behind it that you would defend least. Answer slot: if you set the counting method, say what it was and why. If you did not, say so and say who did. | Retention is a JD requirement, and this presentation is the only metric work in your material. No figure is given, so no figure-based defend slot is raised yet. |
| C2 | "What would you check before trusting a retention drop after a live update?" | JD | [generic] | Name the checks in your own order: the cohort definition, the timing overlap with other changes, the instrumentation, and sample size. Name the one you trust least, and why. | Tests method. It makes no claim about your past, so the guidance makes none. |
| C3 | "How would you know a post-event review changed anything?" | JD | [grounded] "own the post-event review and the KPIs it reports" — JD | Say what you would measure against what: the event's goal, a comparison window, and what you would do if a KPI moved and the cause was unclear. Answer slot: if you ran a post-event review, say what it measured and what changed. If you have not, say so and say what you would measure first. | F5's gap. The slot asks only what was measured, and never names a review you have not run. |
| C4 | "Tell me about a written update a team acted on. What did it change?" | JD | [grounded] "clear written communication" — JD | Pick one written piece. Say what it said, what the reader did, and what changed. If the checklist is the nearest example, use it in its own terms. If nothing comes to mind, say so plainly. | Covers the written-communication requirement, which had no question. F8's gap. |

### Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL (persona stem) | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Selection scaffold: pick a time you brought a number someone senior did not want to hear. It needs a named stake, what you said, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: presenting the monthly retention numbers, and what you did in that room, in your own words. | Persona stem. No company value was detected or fetched, so none is mapped. |
| D2 | "Tell me about a content update that did not go to plan. What did you do?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Pick one real update. Say what went wrong, what you did in the week after, and what you would change next time. If none of the two years' drops went wrong, say so, then describe how you ran a drop. | Theme from the JD's post-event review line. |

### Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | CO (delivery) | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Wrote the release checklist our QA team still uses." — your message; "Presented the monthly retention numbers to the studio head." — your message | A 90-second arc, in order: the studio and role, the calendar you ran, the checklist, the retention presentation. Then stop, and turn to the role. | A casual opener is still scored. The arc uses only what your quotes carry. |
| F2 | "What's a live game you've been playing lately, and what did its last update do well?" | CO | [generic] | Name one game you actually play, one update you noticed, and what it did for you as a player. Do not claim knowledge of its numbers. | Casual register, but genuine interest is scored. No past claim. |

### Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between a content calendar and QA's release work, and what happens when you disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | State a seam principle: who owns the release gate, and who owns the checklist's content. For a disagreement, tell one from your own work, if you have one. If not, say so and state the principle you would use. Answer slot: if you disagreed with QA, say what happened. If you did not, say so. | Peer seam. The checklist you wrote is the nearest real seam in your material. |
| G2 | "How do you handle credit when a drop depends on work from several teams?" | Peer stem | [generic] | State the principle first: name the people whose work landed. Then one example you can name from your material, or say you have none and give the principle. | Peer register. No past claim is made. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, C3 |
| Coordinate design, art, engineering and community teams on each update | A3, B2, G1 |
| Own the post-event review and the KPIs it reports | C3, D2 |
| Manage the release checklist with QA | A4, G1 |
| 3+ years producing live-service games or apps | B1 (through F7's answer slot) |
| Experience running a content calendar | A1, D2 |
| Comfortable with player-retention metrics | A2, C1, C2 |
| Clear written communication | C4 |

## Reverse questions for Tobias

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first 90 days look like, and which live event would you want me to have run by then?" | It turns the JD into a shared target, and it shows you plan toward outcomes. |
| R2 | "How is the calendar for the two titles set today, and who signs off each cadence?" | It shows you understand governance before you change anything. |
| R3 | "Where do design, art, engineering and community most often disagree on an update?" | It finds the real seam, and it invites his own view of the team. |
| R4 | "Who owns the release checklist with QA, and how often does it get revised?" | It tests the boundary of the JD's "manage" line. |
| R5 | "How does a post-event review feed into the next event's plan today?" | It shows you take the KPI loop seriously, and it shows you know where the review sits. |
| R6 | "Would this role come with direct reports, now or later?" | It asks the leadership question directly, which you need answered before you decide anything. |

No reverse question is tied to his career path, because no public profile was researched.

## Sources

**Provided documents:** the JD text, and your background message. No dossier was present.

**Searches sent:**

- `Saltmarsh Games values mobile game studio`: refused. Permission to use WebSearch was not granted.
- `Saltmarsh Games live operations producer interview`: refused. Permission to use WebSearch was not granted.
- `Tobias Wrenfield Head of Live Operations`: refused. Permission to use WebSearch was not granted.

Research tier: L1 requested, but no search or fetch ran. Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved the values cheat sheet (section 10). That section was dropped anyway, because no values round was detected. |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved the loop structure and the persona weights. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO questions and the grounding brief. No call was sent, and the inputs do not fix this target. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read and the reverse questions. |
| 5. representative `Live Operations Producer` JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

Dropped sections, with the reason for each: prep triage (prep time not given), graded deliverables (none declared), values cheat sheet (no values round detected, no values in hand), grounding brief (no research ran), reading the interviewer (no public profile), delivery coaching (no assessment provided).

## Upgrade menu

- Round type and Tobias's role in the loop → confirms or changes the persona weights, and the reverse questions can be tied to his path.
- Permission for WebSearch to be granted → the three refused searches can be rerun, which would ground the values section, the loop structure, the recent strategy and Tobias's public footprint. Deep research at L2 is also available, with six further searches and two further fetches, on request.
- Whether the two titles use in-app purchases, or the recruiter has mentioned monetisation → B3, F10 and the monetisation answer move from the gap column into the grounded column.
- Any post-event review you ran, or KPI you chose, in your own words → C3 and F5 move from answer slot to a story-mapped answer.
- Prep time before Friday → adds a prep-triage section with the few things to do first.
- The recruiter's notes on focus areas, or any exercise they mentioned → adds graded-deliverable sections.
- A `tuesday-dossier.md` → would add evidence already verified outside this conversation, and sharper objections.
