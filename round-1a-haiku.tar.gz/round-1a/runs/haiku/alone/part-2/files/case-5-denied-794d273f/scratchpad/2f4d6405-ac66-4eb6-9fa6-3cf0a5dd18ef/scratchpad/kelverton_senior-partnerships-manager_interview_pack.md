# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

Panel: Deepa (VP Partnerships, future manager) and Ross (Commercial Director). 60 minutes: 15-minute spoken POV, then Q&A with Ross pressing on commercials.
Version 1. Built from your message and the recruiter's email as you quoted it. No JD, no market report text and no research run.

## 1. How to use this pack

Personas are how a question is asked. Types are what it scores: **VAL** behavioural/values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem. Guidance is scaffolding, not a script. Rehearse aloud, in your own words.

## 2. Prep triage (about 4 hours)

1. **75 min: the POV.** Build the three theses in section 5, each with its concession. Speak it aloud twice, timed to about 13 minutes so there is slack.
2. **60 min: commercial pressure.** Drill B1 to B3 and C1 aloud. Defend the figure in your own words, including what was yours.
3. **45 min: the objection.** Drill D1 with hold-then-concede. This is the highest-return item in the pack.
4. **20 min: reverse questions.** Pick five from section 9.
5. Everything else is insurance.

## 3. Fit snapshot

Requirements come from the recruiter's email, quoted in your message. No JD was supplied, so no requirement is quoted from one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "running the ISV channel" (your message); "took it from 6 partners to 40" (your message) | medium | [grounded] | transferability | Your material shows a partner channel you ran and grew, not operator partnerships. Say what carries over: running and growing a partner base. Do not claim the operator model. Answer slot: if you set how partners were recruited or enabled, say how, in your own words; if you did not, say so and stay with the channel you ran. |
| F2 | "land on what it means for the operators themselves" (recruiter's email) | "bus and light rail network planning" (your message); "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material supports knowledge of operators' planning work. It does not show operators' commercial decisions or budgets. Use the planning side as your way in and do not extend it to procurement. Answer slot: if you saw how operators decided on planning spend, say what you saw; if not, say so. |
| F3 | "Ross will push on commercials" (recruiter's email) | "never carried a direct quota, only influenced revenue" (your message); "roughly £4M of influenced revenue" (your message) | high | [grounded] | capability | The gap is one you stated: "I haven't carried a direct quota." Your figure is influenced revenue; say so before anyone asks, and never restate it as sourced revenue. Answer slot: how the £4M was counted, and which part was yours. |
| F4 | Rail sales experience (not stated in the material; the recruiter's email names none) | "Never sold into rail specifically" (your message) | high | [grounded] | capability | The gap is one you stated: "I haven't sold into rail." Pair it with F2: "I know the planning side; I have not sold into rail." Then how you would learn the buyer side, said as a plan, never as a past. |

Gap types here follow the routing rule in the suite's evidence conventions: the evidence cell decides the type, not the writer's sense of the row.

## 4. Prohibited claims

Built here from the fit snapshot, since no dossier was supplied. Nothing in this pack asserts, softens or implies these.

- **PL1, sourced.** "never carried a direct quota" (your message). Honest form: "I haven't carried a direct quota." A plain acknowledgment with its source.
- **PL2, sourced.** "Never sold into rail specifically" (your message). Honest form: "I haven't sold into rail." A plain acknowledgment with its source.
- **PL3, inflated form.** "I generated £4M" or "I sourced £4M," stretched from "roughly £4M of influenced revenue" (your message). The pack's own observation: your material says influenced, not sourced or closed. Never a first-person negative.
- **PL4, inflated form.** "I designed the ISV programme," stretched from "running the ISV channel" (your message). The pack's own observation: your material says you ran and grew the channel.
- **PL5, inflated form.** "I know how operators make commercial decisions," stretched from "I know the operator world from the other side" and "bus and light rail network planning" (your message). The pack's own observation: your material is planning-side.

## 5. The graded deliverable: the 15-minute POV

**Brief** (recruiter's email, your message): "a short POV on where you'd take our operator partnerships over the next 18 months" and "land on what it means for the operators themselves." No slides. Graded.

**Facts to build on:** F1 and F2 above. Every claim about your past in the build rests on those quotes and nothing else.

**Three theses, each with its concession.** The industry claims inside the theses are [generic]: they come from general knowledge of the sector, not from research, and need checking before you state them as fact.

- **T1, the operator's planning cycle.** Partnerships should follow operators' timetable-change cycle, not the vendor's sales cycle. What it means for the operator: their planners get help before a change window, not after it. [generic] Concession: I have not yet tested how operators plan change windows against scheduling software; I would check that with operator planners before I wrote it into a plan.
- **T2, delivery through partners.** Some operators need a delivery partner to put the software to work, not only a licence, so the partner model should carry implementation. [generic] Provenance: F1. Concession: I have not run a delivery-partner model with an operator, and a payments channel sells to a different buyer. Name that before they do.
- **T3, outcome-linked terms.** Part of the price could follow an operator's measured outcome, such as timetable reliability. [generic] Concession: I have not priced an outcome-linked deal, and the commercial model needs Ross's view. Anti-pick: do not chase every operator at once; start with those with a live change window.

**Spoken shape, about 13 minutes:** two minutes on what operators need; four on T1; three on T2; two on T3; two on what it means for the operator, closing on the planner's first month. Guidance is 90 to 120 seconds per thesis; cut anything you cannot say aloud.

**Differentiation against the consensus answer.** Strategy teams commonly circulate a market report, and interviewers have it too. Reciting it scores as homework. I have not seen the report. Once you paste its shortlist, agree with one item, depart from one with reasons, and name the thesis it changes.

**Close (operator benefit, as the recruiter asked):** "what an operator's planner can do in their first month that they cannot do now."

## 6. Reading the panel

No public footprint was researched, so no interviewer read is run. Persona weights come from relationship priors: Deepa as hiring manager (Case/Strategist and Skeptic), Ross as the commercial lead (Data-Driven Prober and Pressure). Expect Deepa to test the POV's logic and Ross its numbers.

## 7. Persona table

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Deepa | Live operator problem after the POV | High: the panel's first scored hour is the POV, and a hiring manager buys judgment | Clarify, then structure, then answer; name one premise to test |
| Skeptic | Deepa | "Why should we hire you" on the gaps | High: F3 and F4 are the gaps most likely to be raised | Hold the position through two follow-ups; concede specifically |
| Data-Driven Prober | Ross | Line-by-line questions on the £4M | High: a headline figure with an unclear count invites a probe | Give the counting rule in your words; name the weakest assumption |
| Pressure | Ross | Time-boxed challenge on the quota gap | Medium to high: he has said he will push on commercials | Pause, restate, hold two follow-ups, concede only the uncertain part |
| Conversational | Either | Opening invitation to walk through your background | Medium: a panel usually opens this way | A 90-second arc from quoted sentences only |

Weights: Case/Strategist 5 questions; Skeptic 4; Data-Driven Prober 4; Pressure 3; Conversational 2. Total 18. Every plausible persona is touched, so nothing is met for the first time live.

## 8. Question banks

**Coverage:** the POV is covered by section 5. Commercials: B1 to B4, C1 to C3. Operator strategy: A1 to A5. Rail gap: D1, D3, D4. Operator-side knowledge: A2, E2. No JD requirement exists to check against; the recruiter's three demands are each covered.

**Most predictable objection, the highest-return prep: D1.** Deepest rehearsal: three follow-up levels.

### Case / Strategist (Deepa), weight 5

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | CASE | "Sketch your first 90 days on operator partnerships. What do you need to know before you propose anything?" | [generic] No candidate sentence rests here. | Clarify first: which operators, what their change windows look like, what they already run. Then objective, segments, approach, metrics, risks. Name one premise to test. Claim no prior operator deals. | A hiring manager's live problem. The question presupposes nothing about you. |
| A2 | CO | "Where should operator partnerships sit as the rail ownership and contracting picture changes?" | [generic] | Say what you would verify first, then name one scenario it changes. Do not state current policy as fact: no research has been run. | Strategy altitude. Left generic until research runs (upgrade menu). |
| A3 | CASE | "Which operator would you start with, and why?" | [generic] | Pick a segment by live change window, not by size. Say what would make you change the pick. | Forces a prioritised answer that matches T3's anti-pick. |
| A4 | CASE | "Which of your three theses dies first if operators say no?" | [grounded] "Ross will push on commercials" (recruiter's email, your message) with [generic] thesis content | Name the thesis with the largest concession: the one you have not tested with an operator. Keep the answer as a test, not a conclusion. | Tests whether the POV is a position or a list. |
| A5 | CASE | "How would you time a partnership push around an operator's cycle?" | [generic] | Tie timing to change windows and budget cycles, each named as something to verify. Name what you would not do in a change window. | Tests T1 under pressure. |

### Data-Driven Prober (Ross), weight 4

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | EXP | "Your number is roughly £4M of influenced revenue. How was it counted?" | [grounded] "roughly £4M of influenced revenue" (your message) | Give the counting rule in your own words. Name the assumption you would defend least. Say which part was yours. Answer slot: if you set the attribution rule, say so; if the company set it, say so. | The defend-the-number slot a headline figure raises. Do not explain a method you cannot repeat under a second question. |
| B2 | EXP | "Which of the 40 partners drove that number, and what share is yours?" | [grounded] "took it from 6 partners to 40" and "roughly £4M of influenced revenue" (your message) | Use the two figures as you stated them. Say how far the partner count and the revenue are linked. Do not claim revenue per partner. | An attribution probe on the same figure. |
| B3 | EXP | "When a partner influenced a deal, who closed it, and how did you know?" | [grounded] "only influenced revenue" (your message) | Separate influence from closed revenue. You did not carry a quota, so say who closed, and what you could see. Answer slot: if you tracked a stage, name it; if the sales team closed it, say so. | Probes the influence-versus-revenue gap. |
| B4 | CASE | "Operators pay partly on outcomes. How would you model a partner's unit economics?" | [generic] | Structure: volume, price, margin, partner share, cost to serve. Name each input you would need to verify. Concede that operator payment terms are untested. | Ross's commercial lens, and the T3 concession. |

### Pressure (Ross), weight 3

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | JD | "Sixty seconds: why would an operator give a partnerships budget to someone with no quota history?" | [grounded] "never carried a direct quota" (your message) | Pause. Restate: "I haven't carried a direct quota." Then the first-90-day plan from A1. Hold through two follow-ups. Concede only the budget-cycle uncertainty. | A time-boxed challenge to composure. Holding a position without defensiveness is what is scored. |
| C2 | CO | "Give me a commercial model for a partner-led deal with an operator, in three numbers." | [generic] | Name three numbers and label which you would verify. Do not invent market sizes or prices. | Commercial composure under a number demand. |
| C3 | JD | "What would you say no to in the first six months?" | [generic] | Name one class of deal you would decline, and why. Concede that the commercial line is Ross's to set. | Tests the anti-pick from T3. |

### Skeptic (Deepa), weight 4

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | JD | "You've never sold into rail and never carried a direct quota. Why should we hire you for this seat?" | [grounded] "Never sold into rail specifically" and "never carried a direct quota, only influenced revenue" (your message); [grounded] "took it from 6 partners to 40" (your message) | Hold, do not defend: "I haven't sold into rail and I haven't carried a direct quota. What I have done is take a channel from 6 partners to 40." Follow-up 1: "Why would operators trust a payments partnerships lead?" Answer with F2, the planning-side knowledge. Follow-up 2: "Who on the operator side would you need to convince first?" Concede specifically: "I don't yet know operator procurement; I would spend the first month on it." Never fold on the channel result. | The most predictable objection to this candidate, and the highest-return prep. Three follow-up levels. |
| D2 | EXP | "You ran a channel of 40 partners. What did you personally decide, and what was set for you?" | [grounded] "running the ISV channel" (your message) | Name the decisions you made, in your words. If some were set by others, say so. Answer slot: if you chose which partners got enablement, say how; if not, say so. | An ownership probe on the word "running." |
| D3 | JD | "Which part of this role would you be weakest at on day one?" | [grounded] "Never sold into rail specifically" (your message) | Name the buyer-side knowledge and the quota as your ramp. Give the ramp plan. Concede; do not defend. | A Skeptic stem that invites candour. |
| D4 | JD | "How would partner economics differ when the buyer is an operator?" | [generic] | Say what carries over (channel economics) and what does not (the buyer, the budget, the procurement). Concede that the second list is untested. | A skeptical peer's question in collegial form. |

### Conversational / Rapport (either), weight 2

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| E1 | EXP | "So, walk us through the journey." | [grounded] "9 years in partnerships" and "running the ISV channel" and "bus and light rail network planning" (your message) | A 90-second arc from those three quotes only. Do not go beyond them. End on the operator side, which is your bridge. | The opener. Casual register, still scored. |
| E2 | JD | "What are you most curious about in our operator base?" | [generic] | Ask one specific question back. Do not answer "I think you've covered everything." | A rapport question that doubles as a preparation signal. |

**Count:** 18 questions, within the 18 to 26 range. Values-style rounds were not detected, so no values cheat sheet is included.

## 9. Reverse questions

Each has a "why it lands" line. No interviewer footprint was researched, so none ties to a career path. Pick five.

1. **To Deepa:** "What would an operator say had changed for them in 18 months, in their own terms?" Why it lands: it puts the operator at the centre of the answer, which is the brief.
2. **To Ross:** "When an operator partnership goes well, which number moves first, and who signs off the price?" Why it lands: it shows you know the commercial model is open.
3. **To Deepa:** "What could a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question, which signals you are thinking about the team, not only the role.
4. **To Ross:** "Where has the commercial model been hardest to hold with operators?" Why it lands: it asks for the real problem, not the brochure answer.
5. **To Deepa:** "What would make you say in six months that this was the right hire?" Why it lands: it turns the last slot into a success criterion you can work to.

Prepare your own answer to "any questions for me?" from these. Do not let it be generic.

## 10. Sources

- **Provided:** your message, including the recruiter's email as you quoted it. The market report: you read it; I have not seen its text.
- **Research tier: L0.** No search or fetch was run. [generic] labels mark every outside claim that needs checking.
- **Target accounting:** strategy brief, interviewer footprint, loop structure, representative JD and recent organisation context: all skipped at L0.
- **Dossier:** none supplied. The pack is built from raw inputs.

## 11. Upgrade menu

- The JD text → F1 to F4 become quoted requirements, and the [generic] rows in section 8 can be checked against it.
- The market report's headline shortlist → section 5's differentiation can be finished, and T1 to T3 can be tested against a named item.
- Research at L1 (up to six searches and two page fetches) → A2, A3, C2 and T1 move from [generic] to checked claims about current rail policy and Kelverton's position.
- The public profiles of Deepa and Ross → an interviewer read, and reverse questions tied to their own careers.
- Confirmation from the recruiter of any other graded deliverable → a build section for each.
- Whether a rail sales track record is a stated requirement in the JD → if so, F4 is a gate row, and the pack will say what the material shows.
