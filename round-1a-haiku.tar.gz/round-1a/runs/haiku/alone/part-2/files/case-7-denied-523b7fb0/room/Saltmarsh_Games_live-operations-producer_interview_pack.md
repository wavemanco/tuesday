# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be **hiring manager**; not yet confirmed (see the Step 1 question in the message). First version, so no changelog.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral / values, **EXP** experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Each cell is written to be spoken in 90 to 120 seconds.
- Sections absent because their inputs are missing: prep triage (prep time unknown), values cheat sheet, grounding brief, reading the interviewer, delivery coaching. None is filled in from memory.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 3+ years producing live-service games or apps (JD) | "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | presentation | Your material gives four years as an associate producer at a puzzle-game studio, and a content-drop calendar. It does not say the title was live-service, so do not call it that. Words: "I was an associate producer at a puzzle-game studio for four years." Answer slot: if you can say in what sense the title was live-service, say how; if not, say it was a puzzle title with a weekly content cadence. |
| F2 | experience running a content calendar (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap; the quote reaches the requirement. A CV-level line with nothing inspected behind it, so expect a probe on what the calendar contained. |
| F3 | Plan and run the live-events calendar for two of our mobile titles (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | low | [inferred] | transferability | The quote is one title. Two titles is the step it does not reach, and the bridge does not stretch to it. Words: that sentence at its own scope. Answer slot: if any of that work touched a second title, say which and what you did; if none did, say so plainly and say how you would plan a calendar across two. |
| F4 | coordinate design, art, engineering and community teams on each update (JD) | none given | none | [grounded] | discovery | Your material does not show cross-team coordination for design, art, engineering or community. Answer slot: if you coordinated an update across any of those teams, say which and how; if none comes to mind, say so plainly and say how you would run that coordination for each update. |
| F5 | manage the release checklist with QA (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | transferability | The quote is writing the checklist and QA still using it. It does not say you managed the release process. Words: that sentence at its own scope. Answer slot: if you ran the checklist with QA for each release, say how; if you wrote it and handed it over, say that. |
| F6 | own the post-event review and the KPIs it reports (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting numbers is not owning the KPIs or the review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs went into the reports, say how you decided; if you presented numbers someone else defined, say that. |
| F7 | comfortable with player-retention metrics (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | No gap; the quote reaches the requirement. No figure is in this conversation, so there is no number to defend; expect a probe on how the count was made. |
| F8 | clear written communication (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Quote reaches the requirement in other terms: a written artifact a team still uses. Words: that sentence as written. Adds no practice. |
| F9 | Leading a team (not a JD line; raised in your message) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would learn to coordinate a team, said as a plan and never as a past. |
| F10 | Working on monetized mobile titles (not a JD line; raised in your message) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then what you would need to learn about in-app-purchase calendars, said as a plan. The JD does not name monetization, and the pack cannot check whether Saltmarsh's titles use it (see Sources). |

Pack observation, not words for you: the material shows a calendar for one title, a checklist, and retention numbers presented. It does not show two titles, team leadership, or cross-team coordination.

## Prohibited claims

The pack will not coach these, built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review and the KPIs | Inflated form of F6 | F6's quote at its own scope. Observation: your material says you presented the numbers, not who set the KPIs. |
| Ran calendars across two titles | Inflated form of F2 and F3 | "I ran the weekly content-drop calendar for our main title for the last two years." |
| Owned the release process with QA | Inflated form of F5 | "Wrote the release checklist our QA team still uses." |
| Led or managed a team | Stated negative, F9 | "I haven't led a team." |
| Worked on monetized (in-app purchase) games | Stated negative, F10 | "I haven't worked on a game with in-app purchases." |

## Persona weights

Hiring-manager prior: Case/Strategist and Skeptic lead. No interviewer signals exist, since no research ran, so there is no adjustment.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | Live problems on the calendar: slips, collisions, a metric drop | High. A hiring manager is buying capability for a calendar they already run, and the JD is a list of live problems. | Clarify before structuring. Name one premise to challenge. Use the JD's own words. |
| Skeptic (weight 4) | Cross-examines the gaps: team leadership, monetization, two titles | High. Three gaps are visible from your own message (F3, F9, F10) and a hiring manager will test the first one. | Rehearse B1 until it sounds plain. Bridge only from the quotes. |
| Data-Driven Prober (weight 3) | Asks how the retention numbers were counted | Medium. The JD names retention metrics, and your CV-level line has nothing inspected behind it. | Say how the count was made if you know. Say "I don't know" plainly where true. |
| Values/Behavioral (weight 2) | Open prompts such as "tell me about a time" | Low to medium. No values round is detected: no loop source established one, and the generic fallback reads no. Two questions cover it. | Selection scaffolds ending in the honest branch. |
| Pressure (weight 2) | Interrupts; time-boxes the answer | Low to medium. Composure test; the hold-then-concede structure applies. | Hold through two follow-ups, then concede the specific point. |
| Conversational (weight 2) | Opens with a casual question | Medium. Casual openers are scored, so the first answer matters. | A 90-second arc. |
| Peer Evaluator (not weighted) | Seam and credit questions | Not weighted, because the relationship is assumed to be hiring manager. Confirm in the Step 1 question. | None needed unless the relationship is different. |

## Question banks

Question IDs are letter-by-persona. Depth follows weight.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you'd plan the live-events calendar for two titles over the next quarter. What do you need to know first?" | CASE | [generic] | Clarify first: each title's current state, what is already committed, each team's capacity, the KPIs. Then the objective, the cadence, the dependencies for each update (design, art, engineering, community, QA), the metrics, and one risk. Think aloud, and challenge one premise you think is wrong. No claim about your past. | Raising source: the JD line "Plan and run the live-events calendar for two of our mobile titles." CASE because it is a live problem; it sits beside F3. |
| A2 | "Art is running a week late on an update that's already scheduled. Walk me through your next hour." | CASE | [generic] | Establish what the slip blocks. Decide what to shift, cut or protect. Tell design, engineering, community and QA the same facts in one message. Record the decision. Hold the date only if you can say why. | Raising source: the JD line "coordinate design, art, engineering and community teams on each update." Tests sequencing, the live version of F4. |
| A3 | "Two titles want a big update in the same fortnight, and QA has one slot. How do you decide?" | CASE | [generic] | Rank by player impact and KPI risk. Check QA's real capacity with QA before deciding. Propose one trade, not three. Say what you would drop and who you would tell first. | Raising sources: "two of our mobile titles" and "manage the release checklist with QA." Covers F3 and F5. |
| A4 | "What belongs in a post-event review, and who should sign it off?" | JD | [generic] | Goal against actual, the KPIs that moved and by how much, what caused the variance, what changes next time, and an owner for each action. Name the sign-off you think is right, and why. Say nothing about what you have done. | Raising source: "own the post-event review and the KPIs it reports." A pattern for the role, not your history, so no quote is needed. |
| A5 | "Retention dropped 15% in the week after a live event. Diagnose it." | CASE | [generic] | Clarify the metric and cohort definition, then whether the drop is real. Split by segment and platform. List what else changed that week, including the event. Pick the one hypothesis to test first, and say what would disprove it. | Metric-diagnosis stem from the Case persona. Raising source: "comfortable with player-retention metrics." |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't led a team. How would you coordinate design, art, engineering and community on each update without that experience?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases."; [grounded] "Wrote the release checklist our QA team still uses." | **Highest-ROI prep in this pack.** This is the objection most likely to come up, because the JD names four teams and your material names none. Hold: the only nearby line is the checklist sentence above. Answer slot: if you have coordinated across teams, say how; if not, say so plainly and then give the plan: how you would set up each update's dependencies and who decides. Hold through two follow-ups by returning to the plan. Concede that you have not led a team, and only that. Do not claim team coordination the quotes do not carry. | F4 is the coordination gap; F9 is the leadership gap it presses on. Given the most rehearsal because it is the likeliest objection and the one most tempted to be thickened. |
| B2 | "Your release checklist is what QA uses. How do you run it with QA, release to release?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say what you wrote and how QA uses it, in those words. Answer slot: if you ran the checklist with QA for each release, say how; if you wrote it and handed it over, say that plainly. Do not say you manage the release process unless you do, in your own words. | Premise is the quoted checklist. "How you run it" presumes a practice, so it is an answer slot with a false-premise branch. Covers F5. |
| B3 | "The JD makes the post-event review and its KPIs part of the job. What have you owned there?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, to whom, in those words. Answer slot: if you chose which KPIs went into the reports, say so and how you decided; if you presented numbers someone else defined, say that plainly. Hold: presenting was yours. Defining is yours only if you did it. | F6 is low confidence: the quote is presenting, not owning. The question's premise is the JD's line; the guidance does not adopt it. |
| B4 | "Why this role, and why now, given that leading a team is new to you?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Give your own reason for wanting this role. The pack has no reason on record for you, so it supplies none. Say you have not led a team, then what you would do to learn it, as a plan. Do not claim a leadership ambition your material does not carry. | Motivation probe built on your stated negative (F9, F10). Your reason for applying is not in the material; that is for you to state in the room. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say how the numbers were counted if you know. If you do not, say so plainly and say who did. Name the weakest assumption you know of, before they do. Answer slot: if you built or changed the count, say what you changed; if you took it as given, say that. Never describe a method you cannot repeat. | F7 is the retention row. No figure is in this conversation, so the defend-the-number slots apply to the count itself. |
| C2 | "Which assumption behind your retention figures would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name one assumption in your own words. If you cannot name one, say that. Do not invent a plausible-sounding assumption to seem rigorous. | Weakest-assumption slot. A probe at depth two: the second follow-up is where the made-up answer breaks. |
| C3 | "A content update ships on a Tuesday, and retention moves the same week. How do you separate the update's effect from everything else?" | JD | [generic] | Name a comparison group or holdout if one exists, a cohort window before and after, the other changes that week, and the result that would show the update did nothing. A method, not a claim about your history. | Raising source: "comfortable with player-retention metrics." Tests method; the answer carries no past claim. |

### D. Values/Behavioral (weight 2)

No values round is detected, so these are generic themes, not values under test.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to someone with more say than you." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time you told someone senior a thing they did not want to hear. It needs a named stake, the moment you held the point, and what happened after. If none comes to mind, say so plainly, then give the nearest thing your material carries: presenting the monthly retention numbers to the studio head, with how you handled it, in your own words. | Persona stem. The nearest line is F7's source sentence, used only as the honest fallback. |
| D2 | "Tell me about a time you put a player's experience ahead of a number someone was watching." | VAL | [generic] | Selection scaffold: pick a time a metric pointed one way and what players needed pointed the other. Name the stake and what you chose. If none comes to mind, say so plainly, and say how you would decide one now. | Persona stem. No quoted sentence carries a player-first decision, so this is a scaffold. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has led a team?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases."; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause, then restate the question. Three parts: what you do not have, the calendar you ran, what you would do to close the gap. Hold through two follow-ups by returning to the calendar. Concede specifically: you have not led a team. Do not argue that leadership doesn't matter. | Composure test on F9 and F2. Time-boxed; the hold is the calendar you ran, nothing larger. |
| E2 | "The retention numbers you presented: how much of them was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: presenting them was yours. Concede specifically: if you did not define the figures, say so, and say who did. Do not lift the ownership to sound stronger. | Attribution probe on F6 and F7. The premise, "presented," is quoted. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey, and how you'd describe the calendar to someone who's only shipped live-service games." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Ninety-second arc: the four years, the two on the calendar, the QA checklist, the retention presentations. Describe the cadence in your words. Say whether the puzzle title was live-service in the sense they mean; if it was not, say what it was. | Casual register, scored. Covers "3+ years producing live-service games or apps" and "experience running a content calendar" in one answer (F1, F2). |
| F2 | "What's a live calendar you've seen recently that you'd want to copy?" | JD | [generic] | Name one you have played or watched closely, what you would copy, and why. If you have not seen one closely, say so plainly. Do not name one you have not used. | Casual question on a JD topic, still scored. A pattern, with no source about this company. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A3 |
| Coordinate design, art, engineering and community teams on each update | A2, B1 |
| Own the post-event review and the KPIs it reports | A4, B3 |
| Manage the release checklist with QA | B2, A3 |
| 3+ years producing live-service games or apps | F1 |
| Experience running a content calendar | F1 |
| Comfortable with player-retention metrics | C1, C2, C3, A5 |
| Clear written communication | none, and why: this round is spoken. The written evidence is the checklist in B2, and writing is judged as you explain it. |

Off-JD gaps raised in your message: team leadership (B1, B4, E1) and monetization (B4, E1).

## Reverse questions

Each has a reason it lands. No interviewer profile was available, so none is tied to Tobias's own path.

1. **"What does a typical month on the live calendar look like across the two titles, and where does it run tightest?"** Lands because it shows you are thinking about the calendar as a system, not as a list of drops.
2. **"Who writes the post-event review today, and who owns the KPIs it reports?"** Lands because it tests the ownership boundary the JD sets, and their answer tells you what the job really is.
3. **"How does live ops work with design, art, engineering and community on an update: who decides what ships?"** Lands because it asks about the coordination the JD names without presuming you have done it.
4. **"Which of your two titles depends most on in-app purchases, and how does that change the calendar?"** Lands because it asks about the monetization gap directly, with curiosity rather than defence.
5. **"Does this role lead people, or coordinate them across teams?"** Lands because it settles the team-leadership question in the room, and the answer tells you how hard to lean on the plan in B1.

## Sources

**Provided documents:** the job description and your background, both in your message. No CV, dossier, values page, strategy brief or assessment was provided.

**Searches and fetches sent.** Each call was refused by the host; none returned a result. I did not retry.

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile game studio news" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section dropped. Nothing taken from memory. |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure. Persona weights are the hiring-manager prior, not a documented loop. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Grounding brief and CO questions. No CO question was written; the bank has none. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, persona adjustment, and a reverse question tied to their path. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Permission to search (or the four targets pasted directly: Saltmarsh's values page, its interview format, a recent strategy piece, Tobias's public profile) → the values cheat sheet, loop structure, a grounding brief, and a reverse question tied to Tobias's path.
- The recruiter's email on round format → confirms the hiring-manager round and adds any graded deliverable as its own build section.
- Whether Saltmarsh's titles use in-app purchases → sharpens F10 and the monetization probe in B4 and E1.
- A CV or résumé → gives F1 to F8 a second, inspectable source; F5 and F8 may upgrade to `high` if an artifact comes with them.
- Your prep time before Friday → a prioritized triage of the questions above.
