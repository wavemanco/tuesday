# Larkfield Systems: Engineering Manager interview prep pack (three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people)
**Candidate:** Yusuf
**Interviewers:** A, Director of Engineering, hiring manager, 45 min (Tuesday). B, panel of two staff engineers and a product manager, 60 min (Thursday). C, VP Engineering, values and leadership philosophy, 30 min (following Monday).
**Built in:** loop mode. Built from your message only. No posting, CV or research was available for this pack (see Sources).

---

## How to use

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Type | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the values the company publishes. None are in hand yet (see the upgrade menu). |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company knowledge | Not used. No research ran, so no company-strategy question is grounded. |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding for a spoken answer, not a script. An answer slot is an instruction for the interview: answer whichever branch is true for you. Round C has seven questions because it is 30 minutes long.

---

## Prep triage

Prep time is about two weeks across three rounds. In order:

1. **A1**, rehearsed aloud until the two plain acknowledgments come out without hedging. It is the most likely objection, and it returns in some form in all three rounds.
2. **A3 and B2**, the 60% figure and the reliability decision. Know what you can and cannot say about how each was counted and who decided what.
3. **A2 and B3**, the roadmap and hardware cases, done out loud, starting with clarifying questions.
4. **C1 to C3**, the values round. No published values are in this pack, so prepare two stories you can state in your own words.

Everything else is insurance.

---

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says one team of six, not two squads. Keep the bridge at that scope: "For three years I was a team lead of six." Answer slot: running two squads at once is the probe this role invites. If you have done anything like it, say how, in your own words. If not, say so and describe how you would split the work between the two. |
| F2 | "Own delivery, hiring and growth for 11 engineers" (role summary, your message), hiring part | "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | medium | [grounded] | presentation | Hiring is reached in other terms: backend roles, and interviews rather than hires. Say the scope as you said it: "I run our hiring loop for backend roles, about 40 interviews last year." The material gives no hire count. |
| F3 | "Own delivery ... for 11 engineers" (role summary, your message), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Delivery in your material is one team's reliability quarter. Keep the figure at its scope: "my team's on-call burden dropped 60%." Delivery across two squads is not shown. Answer slot: the 60% is where a probe lands. See A3. |
| F4 | "Own delivery, hiring and growth for 11 engineers" (role summary, your message), growth part | none given | none | [grounded] | discovery | The material shows no growth work. Answer slot: say what you have done to develop engineers on your team, in your own words. If you have not tracked it, say so and say how you would start. |
| F5 | Managing managers (not in the role summary; your own gap, raised in your message) | "I've never managed managers" (your message) | none | [grounded] | capability | Plain acknowledgment in your words: "I haven't managed managers." Then the plan, stated as a plan and never as a past: how you would learn to coach managers in the first ninety days. No claim to manager-of-manager work. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." The nearest adjacent work is in F3, at its own scope: pushing a reliability quarter through against roadmap pressure. Do not bridge from F3 to owning a hardware roadmap. |
| F7 | Location, on-site or travel (a gate; not stated in the role summary) | none given | none | [generic] | hard_gate | Your material does not establish this. It is not bridged here. The question for it is in the message that accompanies this pack. |

**Requirement coverage.** Each stated requirement, mapped to the questions that cover it.

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A2, B3, C4 |
| Own delivery for 11 engineers | A3, A4, B4, C6 |
| Hiring | A5, A6 |
| Growth | B5, C6 |
| Partner with hardware on roadmap | A1, B3, C7 |
| Partner with product on roadmap | A1, B1, B3 |
| Managing managers (your gap) | A1, C3 |
| Location, on-site or travel (gate) | None. The material does not state it, so no question is written here. It is in the message. |

---

## Persona table

Weights are the question counts per persona in each round's bank. The bank is capped by round length, so the top persona in each round gets the deepest follow-ups rather than the most questions.

| Persona | Round A (hiring manager) | Round B (panel) | Round C (VP) | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 2, top | 0 | 0 | Name the gap first. Bridge only from evidence you stated. Give a ramp plan. |
| Case / Strategist | 3, top | 1, mid | 2, mid | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Data-Driven Prober | 2, mid | 2, top | 0 | Say how each figure was counted, or that you don't know. Name the weakest assumption first. |
| Peer Evaluator | 0 | 3, top | 0 | Propose seam principles, not a claimed map. Offer reciprocity. |
| Pressure | 1, low | 0 | 2, top | Pause, restate. Hold through two follow-ups, then concede specifically. |
| Values / Behavioral | 0 | 0 | 3, top | Selection scaffolds with their honest branch. Say plainly when a story isn't there. |
| Conversational | 0 | 1, low | 0 | Pre-scripted 90-second arc from your own sentences. |

Why these weights. Hiring managers buy capability and derisk gaps, so Skeptic and Case lead Round A, and the two stated gaps (F5, F6) are the Skeptic's material. The panel is two staff engineers and a PM, which is peer and probe territory. The VP round is values-led because the recruiter named values and leadership philosophy, with pressure from a senior interviewer.

---

## Question banks

### Round A: hiring manager (Director of Engineering), 45 min

#### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where in this role would you be weakest on day one?" | JD | [grounded] "I've never managed managers" (your message); "never owned a hardware-adjacent roadmap" (your message); "pushed a reliability quarter through against roadmap pressure" (your message) | Name the two gaps first, in your words: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then the nearest thing you did, at its own scope: a reliability quarter pushed through against roadmap pressure, with your team's on-call burden down 60%. Then the plan: what you would learn from the hardware leads in your first thirty days, and what you would ask your manager to check at day thirty. Hold the acknowledgment through two follow-ups. Do not add to the bridge when pressed. | This is the highest-ROI prep in the pack. F5 and F6 are the two stated gaps, and this probe comes in some form in all three rounds. It gets the deepest rehearsal because it is the one most likely to be asked. The question is open, and the role summary's partner-with-hardware line supports it. |
| A8 | "Why this role, and why now?" | JD | [grounded] "currently at a payments company" (your message) | Give your own reason for moving, in your words. Your reason is not in the material, so the answer has to come from you. If it is the scope of the role, say that. Then name one part of the role you want to do, taken from the role summary. | Motivation consistency is the skeptic's standard check for a move into hardware-adjacent work. The material gives no reason, so the answer is an answer slot. |

#### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A2 | "Two squads, one device-management backlog, and a firmware rollout three weeks late. What do you do first?" | CASE | [generic] pattern for live problems in the role; raising source: "Lead two squads building device-management services" (role summary, your message) | Clarify first: what "late" means, who is waiting, and what the rollout risks are. State the objective. Segment the devices by fleet, firmware version and site. Approach: stop the rollout where risk is highest, and have one squad and the hardware team own the gate. Metrics: failed updates per cohort. Risks: a bad update on a live fleet. Challenge one premise respectfully: whether "three weeks late" is the right frame. | The case tests structure against the role's own work. It is generic because it is a pattern for the problem, not a fact about this employer. It asks nothing about your past. |
| A4 | "The role owns delivery for 11 engineers. How would you know in six months that delivery is healthy?" | JD | [grounded] "Own delivery, hiring and growth for 11 engineers" (role summary, your message); "I pushed a reliability quarter through against roadmap pressure" (your message) | Name two or three signals you would watch, and what you would do when one goes red. Use your reliability quarter only as a case of watching one signal, at its own scope: on-call burden. Answer slot: if you have watched a delivery signal at team scope, name it. If not, name the one you would pick first, and why. | This scores the delivery requirement. F3 is the only delivery evidence, and it is thin at the scope of two squads. |
| A5 | "Walk me through the hiring loop you run for backend roles." | JD | [grounded] "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | Describe the loop as you run it: the stages, what each stage tests, and your part in it, in your own words. Then the change you would make for device roles, as a plan. Answer slot: if you have hired for hardware or firmware roles, say what the loop looked like. If not, say so plainly, and describe how you would calibrate the loop for them. Say "run," not "designed," unless you did design it. | F2 is your strongest hiring evidence, and it stops at backend roles. The question checks whether the loop transfers. |

#### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A3 | "Walk me through how the 60% on-call reduction was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say what was counted, in your own words, and over what period. Answer slot: if you know how the figure was counted, say how. If you don't, say so plainly, and say what you would measure first. Name the assumption behind the figure you would defend least, before they ask. Then the part that was yours: the decision you made, and what the team did. Keep the 60% at "my team." | F3 is the figure a prober reads first. This question tests attribution: which part was your decision and which was the team's. |
| A6 | "Of the roughly 40 interviews you ran last year, what came of them?" | EXP | [grounded] "about 40 interviews last year" (your message) | Answer from what you know. Answer slot: if you know how many of those interviews became hires, say it in your own words. If you do not track it, say so and say what you would track. Do not estimate a conversion rate on the spot. | The likeliest probe after F2. The question presupposes only the interviews, and a hire count you cannot repeat is worse than none. |

#### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "Sixty seconds: why should we hire you over someone who has run hardware roadmaps?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message); "pushed a reliability quarter through against roadmap pressure" (your message) | Pause, then restate the question in your own words. Hold on what you ran: the team of six, the reliability quarter, the hiring loop, each at its own scope. Hold through two follow-ups by returning to what you ran, not to what you would promise. Then concede plainly: the hardware roadmap is the gap, and name your ramp plan. Do not run down the other candidate. | Low weight in this round. It tests composure more than content. The hold must rest on the scope the quotes carry, not on a claimed equivalence. |

### Round B: panel (two staff engineers, one product manager), 60 min

#### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [generic] persona stem; raising source: "partner with hardware and product on roadmap" (role summary, your message) | Propose the seam as principles, not as a map: who decides a roadmap item, how a hardware dependency is escalated, what happens when the squads disagree. Do not pretend to know their seam. Answer slot: if you disagreed with a peer team and it was yours to resolve, say how, in your words. If you have not had a disagreement of that kind, say so and describe how you would handle one. | Peers price the hire by what it adds to their load. Seam principles beat a claimed map. |
| B5 | "Give me one example of growing an engineer past their current level." | JD | [generic] open prompt; raising source: "Own delivery, hiring and growth for 11 engineers" (role summary, your message) | Selection scaffold: pick a time you helped an engineer take on something bigger, with a named change in what they did. If no such time comes to mind, say so plainly, then give the nearest thing you did. Answer slot: if you have grown an engineer, say what they did differently and how you know. If you have not tracked it, say so. | F4 is discovery. The material shows no growth work, so the honest answer is a selection, not a claim. |
| B7 | "What would you need from our staff engineers in your first quarter?" | JD | [generic] persona stem; raising source: "partner with hardware and product on roadmap" (role summary, your message) | Name two needs, framed as a plan: for example, architecture review, or access to the device data. Do not claim a history with the staff engineers. | Reciprocity. Peers judge whether the hire reduces or adds to their work, and a question about what you need from them signals that you know it. |

#### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B2 | "When roadmap pressure and the reliability work collided, how did you decide?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Hold your decision: say what you chose and why, in your words. Hold through two follow-ups. Concede specifically what you cannot prove: what the roadmap lost, if anything, and whether the figure would have moved without the quarter. Answer slot: if you negotiated with product, say what was traded. If you did not, say so, and describe how you would handle the same collision now. | This is the panel's version of the pressure question, and F3 is its only material. The structure is hold, then concede. The concession is specific, and it never folds the decision itself. |
| B4 | "What's the one delivery metric you would put on your own dashboard?" | JD | [grounded] "Own delivery, hiring and growth for 11 engineers" (role summary, your message) | Name one metric, and its weakest assumption, before they ask. Say which signal you would trust least. Answer slot: if you have run a delivery metric for a team, name it and how it was counted. If not, say which you would choose and why. Never name a baseline you do not have. | Turns the delivery requirement into a number the panel can test. The slot stays open because no metric appears in the material. F3 is one figure, not a dashboard. |

#### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "Our roadmap is set by hardware schedules we don't control. How would you decide what your squads build next quarter?" | CASE | [grounded] "partner with hardware and product on roadmap" (role summary, your message); "never owned a hardware-adjacent roadmap" (your message) | Clarify: whose schedule it is, what is fixed, and what product has committed. State the objective, then criteria for ranking work: reliability, hardware dependencies, product asks. Approach: make the trade-off visible to the PM and the hardware lead together. Answer slot: you have not owned a hardware-adjacent roadmap. Say so plainly, then say how you would learn the schedule constraints in the first month. | The PM's case tests partnering. The owned-roadmap gap (F6) is what the PM will test, and the slot keeps the acknowledgment separate from the learning plan. |

#### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "So, walk me through the journey." | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); "currently at a payments company" (your message) | A pre-scripted 90-second arc from those sentences: nine years in engineering, three of them as a team lead of six, now at a payments company, and what brings you to hardware-adjacent work. Add no titles or scope beyond those sentences. | Casual openers are scored. This one sets the frame for the panel, and the arc is built only from your own sentences. |

### Round C: VP Engineering, values and leadership philosophy, 30 min

#### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; raising source: "values and leadership philosophy" (your message, the recruiter's phrase); "I pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: pick a time you told someone senior something they did not want to hear, with a named stake, the moment you did not fold, and a relationship that was intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, with what you said to whom and what it cost. Answer slot: if the pressure came from a senior person and you pushed back, say so, in your words. If it came from elsewhere, say that. | Values rounds score the hard truth, and no published values are in hand, so no mapped story exists yet. The provenance rests on the recruiter's phrase, not on a specific value. |
| C2 | "What's your leadership philosophy in a sentence, and where have you acted on it?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message); "I run our hiring loop for backend roles" (your message) | Give one sentence in your own words. Then one decision that shows it, at its own scope. Answer slot: if your philosophy shows in no decision you can name, say so, and say what would test it. Do not adopt a sentence from a poster. | The recruiter named leadership philosophy. The material has no sentence you have stated as one, so the answer is yours to write. The decision is one quoted sentence. |
| C5 | "Tell me about a hire you got wrong, or a team decision that did not work." | VAL | [generic] persona stem; raising source: "values and leadership philosophy" (your message, the recruiter's phrase) | Selection scaffold: pick a decision that did not work, what you saw, and what you did about it. Answer slot: if you have no such decision, say so plainly, then say how you would recognise one early. Do not supply a failure you did not have. | Values rounds look for honest failure. None appears in the material, so this is a slot, not a story. |

#### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Sixty seconds: why should I back you to lead two squads when you haven't managed managers?" | JD | [grounded] "I've never managed managers" (your message); "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Pause, then restate. Hold on your team's reliability record and your hiring loop, at their own scope. Hold through two follow-ups. Concede plainly that managing managers is new, then give the 30-day plan. Never say you have managed managers. | The VP's version of gap F5. The hold rests on what you ran. The concession is specific. |
| C7 | "You've never owned a hardware-adjacent roadmap. Why would the hardware leads take you seriously on their schedule?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message); "partner with hardware and product on roadmap" (role summary, your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then how you would earn the hardware leads' trust in the first month: learn their constraints, and bring them reliability trade-offs early. Hold through two follow-ups. Do not bridge from software roadmaps. | A pressure probe on the partnering line. The presupposition is your own negative, and the acknowledgment handles it. |

#### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "How would you tell whether a device-management service deserves more investment than a product feature?" | CASE | [generic] pattern for investment trade-offs; raising source: "Lead two squads building device-management services" (role summary, your message) | Clarify what each option buys and who is asking. State the objective. Criteria: fleet risk, customer-visible reliability, cost of delay. Approach, metrics, risks. Challenge one premise respectfully. | The VP's altitude question. No company strategy is in the pack, because no research ran, so the question is generic. |
| C6 | "What would you do in your first ninety days?" | JD | [grounded] "Own delivery, hiring and growth for 11 engineers" (role summary, your message); "partner with hardware and product on roadmap" (role summary, your message) | A plan, by stage: days 1 to 30, learn the two squads and the hardware team's schedule; days 31 to 60, agree delivery signals with product; days 61 to 90, set the hiring and growth plan. Answer slot: none. This is a plan, not a claim about your past. | A plan-shaped question, so the answer is a plan and not a past. |

### Coverage check

Round C has seven questions, round A eight, round B seven. Round C is 30 minutes, so its bank is shorter than the 8 to 12 loop band.

---

## Reverse questions

Each has a reason it lands.

**Round A (Director of Engineering)**
- "Which of the two squads is in the harder shape today, and why?" Why it lands: it asks for the operating picture before you propose any fix.
- "What would a bad first year look like to you in this seat?" Why it lands: it shows you plan against accountability, not just tasks.
- "What would you need the hardware team to change in the next six months?" Why it lands: it turns the partnering requirement into a shared problem.

**Round B (panel)**
- "What could I do in my first month that would genuinely help your team?" Why it lands: it is the reciprocity question for peers, and it shows you price the hire by what it does for them.
- "Where do you and the product team disagree most often, and how does it get settled?" Why it lands: it tests the seam directly and gives you the answer you need for B1.

**Round C (VP Engineering)**
- "When a reliability request collides with a roadmap date, what do you expect a manager to bring you?" Why it lands: it links the philosophy question to the VP's own practice, and it follows on from C3.
- "What does 'values' mean in a close decision here, not on the wall?" Why it lands: it takes the recruiter's phrase and asks the VP to answer in practice.
- "What would a manager need to show by month six to be trusted with more?" Why it lands: it states the bar, and it treats growth as expected rather than as a favour.

---

## Prohibited list

What this pack will not coach, and why. Each entry names its basis, and the honest form is stated for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers | Negative you stated, in your message | "I haven't managed managers." No answer slot. |
| Owned a hardware-adjacent roadmap | Negative you stated, in your message (F6) | "I haven't owned a hardware-adjacent roadmap." No answer slot. |
| Led two squads | Inflated form of F1 ("3 as a team lead of 6") | F1 at its own scope. The pack's observation: the material says one team of six. |
| Hired 40 engineers | Inflated form of "about 40 interviews last year" (F2) | "About 40 interviews last year." Interviews are not hires. |
| Cut on-call burden 60% across the company | Inflated form of "My team's on-call burden dropped 60%" (F3) | The figure at your team's scope: "my team's on-call burden." |
| Set the reliability plan and the roadmap priorities | Incident or practice: your material says you pushed a reliability quarter through, and nothing about setting the plan or the priorities | The quote at its own scope. Where the role raises roadmap decisions (B1, B3), the slot asks how you decided, and the second branch allows that you did not set them. |

---

## Sources

**Provided.** Your message: the role summary, your background, the recruiter's phrase "values and leadership philosophy" as you reported it, and the round structure. No posting, CV or prior drafts.

**Searches and fetches.** One search was attempted: "Larkfield Systems industrial IoT company values engineering". It was refused, because permission to use web search was not granted in this session. No other calls were made.

**Research tier:** L1 requested. Searches 0 of 6 and fetches 0 of 2 were used, because the search was refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, section 10. Dropped. The search for it was refused. |
| 2. Interview process, engineering manager | unavailable | Loop structure. The round sequence here comes from your message, so persona weights are priors, not loop-verified. |
| 3. Strategy and recent news | unavailable | Company-knowledge (CO) questions. None written, so C4 is generic. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. Round A's interviewer read is absent. |
| 5. Representative engineering manager JD | unavailable | Would have turned the role-summary requirements into posting quotes. |

---

## Upgrade menu

- **The full posting text** → F1 to F6 move from your summary to the posting's own words. The JD questions get exact lines to rehearse against.
- **Your current CV** → any further claim you state about your past becomes quoted material here, and the rows that draw on it are regenerated.
- **Your measurement notes for the 60% figure** (how it was counted and over what period) → the defend-the-number answer slots in A3 and B2 can be answered from quotes instead of left open.
- **The hiring manager's name** → persona weights from their public footprint, and a tailored reverse question for Round A. Web search is unavailable in this session, so this needs a session where it runs.
- **Larkfield's published values page, or the values the recruiter named** → the values cheat sheet for Round C, and mapped stories for C1, C2 and C5.
- **Your answer on the location, on-site or travel gate** → resolves F7.
- **The recruiter's note on what each round tests, or any advance piece of work** → coverage for each round, and a build section for any declared deliverable.
- **A `tuesday-dossier.md`, if you have one** → verified evidence and an objection-specific strategy for F1 to F6.
