# Ashgrove Credit Union: Member Experience Lead, interview prep pack

Loop mode: three rounds on 26 November 2026. Shared fit snapshot and sources first, then one mini-pack per round, then the shared prohibited list and upgrade menu.

Interviewers: the recruiter (round 1), the Head of Member Services, who would be your manager (round 2), and a panel of two branch managers (round 3). No names given yet, so there is no interviewer read.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values alignment; **EXP** your own experience, tested for accuracy; **JD** the role's stated requirements; **CO** company and strategy knowledge; **CASE** a live problem.
- Guidance is scaffolding, not a script. Each one is speakable in about 90 to 120 seconds.
- Provenance labels: **[grounded]** traces to a document you gave me or a sentence you wrote; **[inferred]** is my derivation; **[generic]** is a role-family pattern with no claim about you or Ashgrove.
- Answer slots (lines that begin "Answer slot") are instructions for the interview. They ask for nothing here.

## Fit snapshot

Requirements are quoted from the JD you supplied. Your evidence is quoted from your message. Nothing in the evidence column is my summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Say the years and the role in your own words. The quote reaches the requirement, so there is nothing to add. Expect a probe on whether branch work counts as customer operations. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your material says formal complaints, not regulated ones. Say it as the quote does: "I handled the branch's formal complaints log." Do not add the word regulated. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your own words: "I've never presented to anyone above regional level." Then say how you would build the skill, as a plan and never as something you have done. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material says spreadsheet, not Excel. Say it as the quote does. Do not say Excel unless you used it, and do not claim formulas or charts you did not build. |
| F5 | "own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The adjacent work is one branch's formal log. Say that at its scope. End-to-end ownership across branches is not shown in your material, so name what would carry over and stop there. |
| F6 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your own words: "I've never worked in a contact centre." Then the first-month plan, as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches monthly reporting but says nothing about volumes or resolution times. Say it as the quote does. Do not say it tracked resolution times unless it did. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message), and "the last 3 as a branch supervisor" from F1 | medium | [grounded] | transferability | You trained tellers on the escalation script; coaching supervisors is a step your material does not show. Say the training at its own scope and name what would carry over. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you worked with any team on a digital or self-service process, say which and what you did; if you did not, say so plainly. |
| F10 | Work location and in-person days (not stated in the JD or the recruiter's email) | none given | none | [generic] | hard_gate | Your material does not establish this, and the pack asks nothing about it in the interview beyond the logistics slot in A5. The one question about whether it is met is in the message that delivers this pack. |

Points the snapshot's columns enforce:

- The **medium** bands on F1, F2, F4, F5, F7 and F8 are because your claims are specific and yours, but nothing has been inspected. Expect a probe on each.
- F3 and F6 are the two things you have said you have not done. The pack gives you back your own words for them and nothing more.
- The F9 and F10 rows are silence in your material, not a negative you stated. They get answer slots or a gate question, never a plain acknowledgment.

## Prohibited list

These are claims this pack will not coach, because the material does not carry them and a probe would expose them. Each entry names its basis and gives the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F5. Your material says one branch's formal log. | "I handled the branch's formal complaints log." |
| Coached branch supervisors on escalations | Inflated form of F8. Your material says tellers. | "trained new tellers on our escalation script" |
| Handled regulated complaints | Inflated form of F2. Your material says formal complaints. | "I handled the branch's formal complaints log." |
| Used Excel for reporting, or built the reporting function | Inflated form of F4. Your material says a spreadsheet. | "I built the monthly complaints spreadsheet our regional manager uses." |
| Worked in a contact centre | Your own stated negative, F6 | "I've never worked in a contact centre." |
| Presented to senior leaders | Your own stated negative, F3 | "I've never presented to anyone above regional level." |

The pack's own observation, not words for you: your material says the branch's log, not the end-to-end process; it says tellers, not supervisors; and it says a spreadsheet, not Excel. The pack says those limits as its analysis and never as a first-person statement.

## Sources

Provided documents:

- Your message: your background, the rounds you were told about, the four values and the July 2026 strategy points, all as you pasted them.
- The job description text you supplied.
- The recruiter's email about the three rounds, as you summarised it.
- The four values, as you copied them from ashgrovecu.org/about/values on 17 November 2026. I have not checked this copy against the live page.
- The July 2026 strategy brief, as you summarised it. I have not seen the document itself.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values are in hand as your copy, so no search. Values cheat sheet uses that copy. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds, their lengths and the values scoring, so no search. |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief, as you summarised it, already supplies the current priorities. Grounding brief uses that summary. |
| 4. Interviewer name and Ashgrove | n/a | No names given for the round 2 or round 3 interviewers, so there was no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Not searched: no interviewer profiles, no loop reports and no recent organisational news. Those would be the deep-research tier, offered in the upgrade menu.

## Grounding brief

Source: your summary of the July 2026 strategy brief. Use these words, and check them against the brief itself before the interview.

- **Member service moves to digital**: 40% of member service to digital channels by 2028 (F9's terrain).
- **Branch network**: eight branches consolidate into five hubs over 2027.
- **Lending**: a small-business lending product launches in Q1 2027.
- **Pressure**: app-only banks are the main competitive pressure.

Sensitive: the round 3 panel are branch managers, and the hub consolidation is a decision that touches their branches. Do not ask about which branches close, do not give a view on the decision, and do not correct the brief's framing in front of them. Keep any question about hubs on process: who owns a complaint while it moves.

## Round 1: recruiter screen, 30 minutes

**Persona weights.** Conversational / rapport builder, high (recruiter-screen prior; the risk is treating the call as unscored). Light Skeptic, medium (recruiter checks contact centre and presenting). Logistics, certain (pay, notice, location, reason for leaving are asked in every screen, and the coverage rule requires them). Depth: Conversational 2, Skeptic 2, logistics 4.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in a couple of minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message) | Say the six years and the last three as a branch supervisor. Then the complaints log and the teller training, in your own words, each at its own scope. Under 90 seconds. | F1, F5 and F8 are the beats. The opener is scored for economy and accuracy. |
| A2 | "What's drawing you to Ashgrove, and why now?" | VAL | [generic] | Answer from the work, the complaints process and the member side of the counter. Name one of the four values in your own words only if it is true for you. Do not recite the values page. | Motivation consistency, and the first place the values are heard. |
| A3 | "What base salary are you expecting?" | JD | [generic] | Logistics slot. Give your own number, or ask for the band for this role first. Do not give a figure you have not chosen. | Pay is a knockout check; the candidate's own figure is the only safe answer. |
| A4 | "What notice do you need to give?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words, not rounded up or down. | Notice is a knockout check. |
| A5 | "Where would you be based, and how many days a week in person?" | JD | [generic] | Logistics slot. Say where you can work and on which days, in your own words. If the role's pattern is not clear to you yet, ask the recruiter for it before you answer. | Location and schedule are gates the JD does not state (F10). |
| A6 | "What's making you look at a move now?" | EXP | [generic] | Logistics slot. One sentence on the real reason, positive about what you want next, not critical of your branch or the bank. Answer slot: if the reason involves the complaints work, say which part and what you wanted to change. | Reason for leaving is asked in every screen. |
| A7 | "This role covers the contact centre, and you've been in branches. What's your plan there?" | JD | [grounded] "Never worked in a contact centre" (your message); JD: "across branches and the contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then a first-month plan, as a plan. | F6 is the first gap the recruiter will check, and your own words are the honest answer. |
| A8 | "What does a regulated complaint mean to you in practice?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); JD: "experience handling regulated complaints" | Say the quote at its scope: "I handled the branch's formal complaints log." Answer slot: if a regulator's timescales or rules shaped how those complaints were handled, say which; if they did not, or you did not handle them under those rules, say so plainly. | F2. The premise is the JD's own word, so the slot can allow that the rules did not apply to your work. |

**Reverse questions (round 1)**

- "What would make this role a success in its first six months?" Why it lands: it asks for the scorecard, which tells you what the panel will be listening for.
- "How does the panel score the values: written criteria, or a shared rubric?" Why it lands: it shows you have read the loop design and want to know how you will be scored.

## Round 2: Head of Member Services, 45 minutes, mostly behavioural

**Persona weights.** Values / behavioural, high, weight 4. The recruiter describes this round as mostly behavioural, which moves it from the hiring-manager prior (case and skeptic) toward values. Skeptic, medium-high, weight 3: your manager is buying the capability and checking the gaps F3, F5 and F6. Pressure, low-medium, weight 2: short time-boxed follow-ups from a manager.

**Highest-ROI prep: B6.** The most predictable objection to you is presenting above regional level (F3), and it is the gap a manager is most likely to test. Rehearse the plain acknowledgment and the plan until they are boring.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a member's experience changed what you did." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick a time a member's side of a complaint changed a decision: a reversal, a call back, a re-check. Tell it in beats: the situation, what you saw from the member's side, what you did, what changed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal complaints log you handled, and what you did with a case in it. | Members First is scored. The open prompt has no event of its own, so the nearest quote is the fallback. |
| B2 | "Tell me about a complaint you stayed with until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Hold a case from first contact to close: what you held, what you did at each step, and where it went to someone else, if it did. Answer slot: if a case went past you, say where and to whom; if you kept it to close, say how. | Own the Fix is scored. The quote's scope limits the answer to the log. |
| B3 | "Tell me about a time someone needed an explanation twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if an explanation of the escalation script had to be repeated for someone, say what you changed in it. If you did not explain it twice to anyone, say so, and describe how you taught the script to new tellers. | Plain Words. The quote is training, not a repeated explanation, so the second branch must stay open. |
| B4 | "Tell me about a time a local detail changed how you handled a number." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If you can recall a branch's local situation changing how you read a figure, say it. If none comes to mind, say so plainly, then give the nearest thing your material carries: the monthly spreadsheet, and what it counts and does not count. | Neighbours, Not Numbers is scored. The nearest quote is a spreadsheet, so do not make it a local story. |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then your first-thirty-days plan: who you would ask, what you would listen to, as a plan. | F6 is the most predictable gap, and a manager will test whether you name it yourself. |
| B6 | "You haven't presented above regional level. How will you present to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Say it plainly: "I've never presented to anyone above regional level." Then how you would prepare: rehearse a monthly report with a reader you choose, and ask for feedback, as a plan and not a past. | F3. A plain acknowledgment with its source, then a plan. |
| B7 | "Your monthly spreadsheet: how was a figure on it counted, and which assumption would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Defend the number: say how the figure was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. Answer slot: if you built the count yourself, say how; if the counting rules were not yours, say so plainly. | F4 and F7. A prober's question asked by a manager. |
| B8 | "You've run a branch for three years and never worked in a contact centre. Why isn't this a step too far?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" and "Never worked in a contact centre" (your message) | Hold the position through two follow-ups: the years and the supervisor role are what you did. Concede the gap plainly: "I've never worked in a contact centre." Do not fold on the complaints work you actually did. | Pressure, hold-then-concede. The hold uses only your quoted sentences. |
| B9 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then answer from your quoted sentences: the complaints log, the escalation training, the monthly spreadsheet. Name the gap in one line and stop at sixty seconds. | Time-boxed pressure. The pack does not know whether an internal candidate exists, so the stem is generic. |

**Reverse questions (round 2)**

- "How do complaints that cross a branch and the contact centre get owned today?" Why it lands: it finds out where ownership is unclear, which is the job's central problem, and it shows you are thinking about the work, not the title.
- "Which parts of the 2027 hub plan is the complaints team being asked to design?" Why it lands: it keeps the hub question on process and off which branches close, which is the right altitude for a round with your manager.

## Round 3: panel of two branch managers, 60 minutes, including a 20-minute escalation case

**Persona weights.** Case / strategist, top, weight 4: the 20-minute escalation case is the longest single part of the loop. Values / behavioural, weight 3: the panel scores against the four values. Peer evaluator, weight 2: branch managers whose supervisors you would coach, so the seam between branch and contact centre matters to them. Data-driven prober, weight 2: the monthly report is the thing they can test. The panel's members are not named, so the blend is the top two of each member's relationship.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member's complaint has been to the branch twice and is near the regulator's deadline. The supervisor says it's resolved. Walk me through what you'd do." | CASE | [generic] (optional line: "trained new tellers on our escalation script," your message) | Clarify: what the member was told, what the record shows, the deadline. Objective: the member gets a clear answer in time. Approach: check the record, take the decision to whoever owns it, tell the member in plain words. Risks: the member hears nothing; the record is wrong. Think aloud. If you draw on escalation practice, you can say you trained new tellers on the escalation script, and nothing more about how it was used. | F5 and F8, and the 20-minute case. The case is generic; you bring the process, not an invented event. |
| C2 | "The supervisor pushes back: 'the member's wrong, close it.' Now what?" | CASE | [generic] | Hold the member's side while asking for the evidence. Name who makes the call and take it to them. Do not claim authority you do not have. | Coaching supervisors on escalations (JD). The follow-up tests the same hold under pressure. |
| C3 | "Forty per cent of member service is moving to digital by 2028. How do complaints keep reaching a person?" | CO | [grounded] "40% of member service to digital by 2028" (your summary of the July brief) | Channel design from the member's side: where a complaint starts in the app, how it routes to a person, what a member sees at each step. If asked for figures on complaint channels, you have none; say so and name the first figure you would want. Answer slot: if you worked with any digital team on a journey, say which; if you did not, say so plainly. | F9, the JD's self-service requirement, and the brief's headline strategy. |
| C4 | "Two branches' complaints move to one hub over 2027, and a case is open the week it moves. What happens?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the July brief) | Answer on process, not outcome: a named owner before, during and after the move; the member told in plain words; the branch contact kept until the case closes. Do not comment on which branches close or on the decision itself. If asked for your view of the consolidation, answer about the process and say what you would want explained to members. | Sensitive. The panel manages the branches affected. Keep the answer on how cases move. |
| C5 | "Tell me about an unpopular truth you took to someone above you." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If you took a hard figure upward, say what it showed and what you did next. If you did not, say so plainly, then give the nearest thing: the spreadsheet your regional manager uses, and how you would raise a number that looked bad. | Own the Fix, the hard-truth version. The quote does not say you raised anything, so the second branch must stay open. |
| C6 | "What does 'every branch is part of its town' mean to you when a branch changes shape?" | VAL | [generic] | Say what the branch's town gives a complaint: local knowledge, staff who know members. Name what you would keep when a branch changes. Do not make claims about Ashgrove's decisions. | Neighbours, Not Numbers, asked as a live question about a change the panel is living through. |
| C7 | "Show us how you'd explain a complaint outcome to a member in four sentences." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Say the four sentences aloud: what happened, what was decided, what the member can do next, when they will hear again. Test: the member should need it explained once. | Plain Words, as a live exercise. |
| C8 | "Where does branch complaint handling stop and the contact centre's begin?" | JD | [grounded] JD: "across branches and the contact centre" | Propose a seam principle, not a map: one owner per case, a written handoff, the branch keeps the member relationship. Say you would want to see their seam before you draw it. | Peer seam. The panel are the people whose work touches yours. |
| C9 | "When a fix spans two teams, how do you handle credit?" | VAL | [generic] | Credit the people who did the work by name. Say what you would put in writing. Do not claim a team's result as your own. | Peer credit-sharing. |
| C10 | "Walk me through the monthly report: what's on it, and how is each figure counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Defend the number: what is counted, what is excluded, which figure you would defend least, and which part was yours. Answer slot: if you set the counting rules, say so; if you did not, say so plainly. | F4 and F7, the defend-the-number slot. |
| C11 | "Does your monthly report track resolution time? If so, how is it counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If it tracks resolution time, say how it is counted and which assumption you would defend least. If it does not, say so plainly, and say the first measure you would add. | F7. The question does not presume the report tracks resolution time. |

**Reverse questions (round 3)**

- "Where does the escalation decision sit today: branch supervisor, branch manager or the contact centre?" Why it lands: it asks how ownership works in practice, which is the thing you would be coaching.
- "What could a new person do in their first month that would genuinely help your branch teams?" Why it lands: it is the peer reciprocity question, and it turns the panel into a conversation.
- "What would you want the complaints lead to fix first in your branches?" Why it lands: it lets the panel name a problem they own, and it keeps the hub plan out of the answer.

## Values cheat sheet (round 3, the values round)

The recruiter's email says the panel scores against the four values, so this section applies. Each row maps a value to a story from your quoted sentences, or to a selection scaffold with its honest branch where none carries one.

| Value | Working meaning (paraphrase) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a member-side decision. Scaffold: pick a time a member's side changed what you did. If none comes to mind, say so plainly, then give the nearest: the formal complaints log you handled (F5). |
| Plain Words | If a member needs it explained twice, the writing was wrong. | Your teaching of the escalation script (F8) is the nearest. Scaffold: pick a time an explanation had to be simplified. If none comes to mind, say so, then give how you taught the script to new tellers. |
| Neighbours, Not Numbers | Every branch is part of its town. | Nothing in your material shows a branch's town. Scaffold: pick a time a local fact changed how you read a number. If none comes to mind, say so plainly, then give the spreadsheet your regional manager uses and what it leaves out (F7). |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | The formal complaints log you handled (F5) is the nearest quote. Scaffold: pick a case you kept until it was solved. If you did not keep one to close, say so, and describe how you handled the log's open cases. |

Values are not slogans. A panel that scores against them wants a specific decision that shows the value, and a plain "I don't have one" is a better answer than a story you cannot tell in full.

## Coverage: JD requirements to questions

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A8, C1 |
| Confident presenting to senior leaders | B6 |
| Comfortable with Excel reporting | B7, C10 |
| Own the member complaints process end to end across branches and the contact centre | A7, B2, C8 |
| Report monthly on complaint volumes and resolution times | C10, C11 |
| Coach branch supervisors on escalations | C1, C2 |
| Work with digital teams on self-service journeys | C3 (F9, discovery; answer slot inside C3) |
| Work location and schedule (gate, not stated in the JD) | A5 (F10) |

## Upgrade menu

- The strategy brief itself, pasted or linked → the grounding brief and the CO questions (C3, C4) rest on the document rather than your summary.
- The names of the Head of Member Services and the two panel branch managers → an interviewer read, persona weights per member, and reverse questions tailored to their paths.
- A recruiter reply confirming whether the round 3 case is on paper or live, and whether any part of the loop is a written task → the case format and any build section the loop requires.
- The deep-research tier (L2): searches on the strategy brief, interviewer public talks, and recent loop reports for this role family, up to 6 searches and 2 fetches → the grounding brief and the interviewer read, with the cost stated before it runs.
- Your own account of a complaint you handled end to end, if you have one → upgrades F5 and the B2 and C1 rows from the log's scope to the case's scope, once you can say what you did.
