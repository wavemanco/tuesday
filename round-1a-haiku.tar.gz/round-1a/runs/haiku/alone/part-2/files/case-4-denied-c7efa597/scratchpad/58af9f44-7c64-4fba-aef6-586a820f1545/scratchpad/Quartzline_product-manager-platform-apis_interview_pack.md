# Quartzline, Product Manager, Platform APIs: Hiring-Manager Prep Pack

**Round:** 45-minute conversation with the hiring manager, Thursday. Interviewer name and relationship beyond "hiring manager" not given.
**Built from:** your underwriting dossier (`tuesday-dossier.md`, generated 2026-08-14). Web research did not run (see Sources).
**Changed since last version:** first version.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **JD** (the listed job), **EXP** (your past work, probed), **CASE** (a live problem from the role).
- Guidance is scaffolding, not a script. Speak in your own words. Where a line says *answer slot*, the answer is yours to give. Either honest branch is a good answer.
- Every claim about your past comes from a sentence quoted in the fit snapshot (E1 to E3 below). Nothing else is written as your experience.

## The fit snapshot

Evidence E1 to E3 are your verified entries from the dossier, quoted exactly. E1 is "Led 30+ end-to-end client integrations of the vendor's REST APIs", E2 is "Wrote the internal integration playbook", and E3 is "Ran quarterly roadmap-input sessions feeding client evidence to product". Confidence notes sit in the Confidence column, not in the quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1, must have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | low | [inferred] | transferability | Your material shows integration leadership, not product management, and no PM years are in it. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Anything beyond that is an answer slot. |
| F2 | "Owning a roadmap and prioritization authority" (dossier uncertain area, R1 sub-claim) | none given | none | [grounded] | capability | Your material does not contain roadmap ownership. Words (dossier acknowledge_gap area): "I haven't owned a product roadmap." Then a ramp plan, stated as a plan, never as a past. |
| F3 | "Agile delivery experience" (dossier R5, preferred) | none given | low | [inferred] | discovery | Nothing in the material speaks to agile delivery inside a product org. Answer slot: if you ran delivery in sprints or with a product team, say how; if not, say that and what you would want to confirm about how this team runs it. |
| F4 | "Shipped API or platform products" (dossier R2, must have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | low | [inferred] | discovery | The dossier does not grade R2, and E1 touches it without showing whether you shipped an API product. Answer slot: if you shipped an API or platform product yourself, say which and what was yours; if the work was integrations on top of someone else's API, say that. |
| F5 | "Technical fluency: API docs, schemas" (dossier R3, important) | "Wrote the internal integration playbook" — dossier E2 | high | [grounded] | presentation | The playbook is inspectable and speaks to API docs. Lead with it in the quote's terms, because a document you can name beats an adjective. Schema work is not in the material. Answer slot: if you worked with schemas directly, say which; if not, say what the playbook covered. |
| F6 | "Stakeholder management across engineering, sales, customers" (dossier R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | medium | [grounded] | discovery | Client work and the product feed are in the material; engineering and sales are not shown. Confidence is medium with limited inspectable proof, so expect a probe. Answer slot: which of engineering or sales you worked with and what came of it; if neither, say so and stay with the client and product side. |
| F7 | "Define and track adoption metrics" (dossier role profile responsibility) | none given | none | [grounded] | discovery | The material says nothing about adoption metrics, and the dossier records that no current baseline is stated. Answer slot: if you measured partner API adoption, say what you counted; if you didn't, say so and say what you would measure first. |

No requirement is a hard gate in the dossier (`hard_gates: []`), so no row is gated.

## Persona weights (hiring-manager round)

Relationship priors for a hiring manager put Case/Strategist and Skeptic on top. The dossier names the Skeptic's objection as the highest-ROI rehearsal. There is no interviewer profile, so no signal adjusts the weights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the PM gap and the roadmap gap directly | High. The hiring manager is buying a capability and derisking gaps, and the dossier's objection is this persona's | Acknowledge plainly, bridge only at quote scope, then a ramp plan | 5 questions |
| Case/Strategist | Live problems on the squads' roadmap and partner adoption | High. Hiring-manager prior, and the decision-rights and adoption unknowns are case material | Clarify decision rights and the baseline before structuring | 4 questions |
| Data-Driven Prober | Counts the 30+ integrations and asks what the playbook covered | Medium. Mid-weight prober on EXP claims; E1 and E2 are the places a prober goes | Name the count's method, its weakest assumption, and what was yours, in your own words | 4 questions |
| Pressure | Challenges the PM years and the roadmap claim | Medium. Composure test on the gap the dossier is most worried about | Hold on the integration record through two follow-ups, then concede the PM gap | 3 questions |
| Conversational | Opener and a casual "where are you with API docs" | Low-medium. Casual questions are still scored | 90-second arc from E1 to E3; no PM title | 2 questions |

## Question banks

Coverage follows the table at the end of this section.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "You've never held the PM title or owned a roadmap" as the dossier's named objection; negatives sourced: "Having held a product manager title or role" (dossier prohibited_claims); "Owning a roadmap and prioritization authority" (dossier acknowledge_gap) | **Highest-ROI prep in this pack.** Dossier named this objection. Open with the plain acknowledgment: "I haven't held a product manager title, and I haven't owned a product roadmap." Bridge at quote scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Then a ramp plan, stated as a plan: "In the first 90 days I'd learn the decision rights with the two squad leads and how adoption is measured, before I claimed any prioritization." Answer slot: say in your own words why the integration record fits this seat. Never claim PM work. | F1 and F2 are the rows this objection presses. Dossier named it, so this is its deepest rehearsal. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier acknowledge_gap area) | Name roadmap and prioritization authority plainly, as in A1, with the ramp plan. Then name agile delivery inside a product org as an area to clarify, not as a claim. | Skeptic stem. Reads the dossier's two weakest areas back to the interviewer in order of severity. |
| A3 | "Walk me through how you ran the partner integrations, end to end." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on E1. The beats are the sentence's own: scoping, requirements, architecture, UAT, go-live, in your words. Answer slot: the JD says "Write specs and drive delivery." If you wrote the specs for these integrations, say which; if someone else wrote them, say whose and what you did. | F4 is the nearest answer to "shipped API products," so this is where the R2 probe lands. The spec-writing slot is the JD's own responsibility. |
| A4 | "I don't see prioritization authority anywhere in your background — how would you handle that on this team?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier acknowledge_gap area) | Same plain acknowledgment as A1, then the ramp plan. A plan, not a past: decision rights, the squad leads, and the adoption baseline in the first weeks. | The interviewer's negative is theirs. Your answer needs a source, and the dossier gives one. |
| A5 | "Why move from integration leadership into product management, and why now?" | EXP | [generic] | Answer slot: give your own reason in your words. If you don't have a reason beyond the role, say so and say what you would need to learn. | Motivation consistency probe, the Skeptic's standard question. Nothing in the guidance is a claim about your history. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squad leads disagree on the next partner-API item. What do you do in your first 30 days?" | CASE | [generic] | Clarify decision rights first: who decides, and what the escalation path is. Then structure: partner impact, cost to each squad, adoption evidence. Name the decision owner before you propose an answer. | Decision authority is the dossier's top unknown. A live problem asks about no past, so it claims nothing about you. |
| B2 | "Partner API adoption dropped this quarter. Diagnose it." | CASE | [generic] | Clarify the metric definition and the current baseline before you segment. Then segment by partner tier, integration stage and API version. | Adoption is a stated responsibility with no baseline in the dossier. This is the case version of the F7 gap. |
| B3 | "A major partner asks for a breaking schema change. Sales wants it, engineering doesn't. What do you do?" | CASE | [generic] | Structure: the partners affected, a deprecation path, who decides, and a short decision memo that both sides can sign. | Stakeholder management (F6) at its hardest point. The interviewer's own words make the problem. |
| B4 | "Sketch how you'd find out what integration partners need from the platform next quarter." | CASE | [generic] | Discovery plan: which partners to sample, what signal you'd trust, and how you'd test a need before building for it. | Partner discovery is a listed responsibility, and the question tests method, not history. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted those 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say the count in the quote's own terms. Answer slot: how the count was kept, what it is sensitive to, the assumption you would defend least, and which of the integrations were yours. If no count was kept, say that. | The 30+ is a headline figure, so it gets the defend-the-number slot. The pack supplies no counting method. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name the weakest assumption before the interviewer does, in your own words. The pack does not name one for you. Answer slot if you don't know how it was counted: say so. | Same figure, second probe level. A prober follows up exactly like this. |
| C3 | "Show me the playbook. Which parts did you write, and how did you decide what went in?" | EXP | [grounded] "Wrote the internal integration playbook" | Describe the playbook's scope in the quote's terms. Answer slot: if you chose its contents, say how you decided; if its contents were set by others, say so. | F5 is the presentation gap. An inspectable artifact is where the prober goes next. |
| C4 | "What evidence did your roadmap-input sessions send to product, and what did product do with it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Describe the sessions' quarterly cadence and the client evidence they carried, in the quote's terms. Answer slot: if you know what product decided, say so; if you didn't see the outcome, say so. | F6 is medium confidence and expects a probe. Volunteer the limit before the prober extracts it. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; acknowledgment sourced by "Having held a product manager title or role" (dossier prohibited_claims) | Hold-then-concede. Hold on the integration record through two follow-ups: the client-facing delivery you led is the case you make. Then concede, explicitly: "I haven't held a product manager title, and I haven't owned a product roadmap." Do not fold on the integration record. | Pressure stem on the dossier's named objection. The hold is the quote, and the concession is the dossier's acknowledgment. |
| D2 | "That's 30+ integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: which of the scoping, requirements, architecture, UAT and go-live decisions were yours, in your own words. If some were the team's, say which. Hold to what you led. | Attribution pressure on the headline figure. |
| D3 | "You've never owned a roadmap. Why would a partner trust your priorities?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; acknowledgment sourced by "Having owned a product roadmap" (dossier prohibited_claims) | Hold on E3 at its own scope: you ran quarterly roadmap-input sessions. Concede: "I haven't owned a product roadmap or set priorities." Do not extend the hold to priorities. | Pressure on the roadmap gap, held on the one quote that touches partners. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; [grounded] "Wrote the internal integration playbook"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built from E1, E2 and E3 in whatever order is true for you. End with the adjacency: "That's the adjacent work. I haven't held a PM title." | Casual openers are still scored. Pre-scripting the arc stops it from freezing. |
| E2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook" | Answer slot: if you've worked on schemas directly, name the one you know best. If you haven't, say so, and name what you have written. | F5. The casual register still scores the JD's technical-fluency line. |

**Requirement coverage**

| Requirement | Question IDs | Note |
|---|---|---|
| R1, 3+ years PM | A1, A4, D1 | |
| R2, shipped API or platform products | A3 | F4's answer slot is inside A3. |
| R3, API docs and schemas | C3, E2 | |
| R4, stakeholder management | B3, C4 | |
| R5, agile delivery | none, and why: the dossier grades it a clarify area with low confidence, and no scored question would have anything to ask for. Covered by reverse question RQ4. | |
| Responsibility: define and track adoption metrics | B2 | F7 is the answer slot inside B2. |

## Reverse questions

Each one carries its own "why it lands." These come from the dossier's employer questions and validation risks.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: decision authority versus the squad leads is asserted in the JD and unevidenced; asking it reads as diligence and answers something you need to know before accepting.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the dossier records no baseline. The answer tells you whether the role's success metric exists yet.
3. **"What would a strong first 90 days look like, and how would you judge it?"** Why it lands: it turns the ramp plan from A1 into a conversation about their bar, so you can hear whether it matches.
4. **"How do the two squads plan together today, and where would the PM sit in that?"** Why it lands: it covers the agile-delivery clarify area (F3) without claiming any experience.
5. **"What's the hardest partner conflict on the platform this year, and how was it resolved?"** Why it lands: it shows you want the real operating picture, and the answer tests the stakeholder load the role carries (R4).

## Prohibited claims

These claims are not coached anywhere in this pack. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier prohibited_claims | Plain acknowledgment sourced to that field: "I haven't held a product manager title." |
| "Having owned a product roadmap" | Dossier prohibited_claims | Plain acknowledgment sourced to that field: "I haven't owned a product roadmap." |
| "Having set prioritization for an engineering squad" | Dossier prohibited_claims | Plain acknowledgment sourced to that field: "I haven't set prioritization for an engineering squad." |
| Ran the partner API roadmap | Inflated form of E3 | E3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is this pack's observation, not words for you: your material says roadmap-input sessions, not roadmap decisions. |
| Shipped an API platform | Inflated form of E1 | E1 at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is this pack's observation: your material says integrations of the vendor's APIs, not a shipped API product. |

## Sources

- **Provided:** the underwriting dossier, pasted into this conversation. Sections consumed: `role_profile` (the JD tier, including requirements R1 to R5, responsibilities and unknowns), `handoff_to_mock_interview` (verified evidence E1 to E3, the weak-area strategies, the named objection, the risks, the employer questions and `prohibited_claims`). `decision` (conditional_go) was read as context only.
- **Dossier age:** generated 2026-08-14, about three months before this prep. Check the posting against it. If the JD or the squad setup has changed, the fit snapshot needs regenerating.
- **Research tier:** L1, searches 0 of 6 run (2 attempted and refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet not built. The query was refused: "Quartzline company values product manager platform APIs interview process" |
| 2. Quartzline interview process, product manager role family | unavailable | Loop structure not established, so persona weights are the hiring-manager prior only. Same refused query as target 1 |
| 3. Quartzline strategy and recent news | unavailable | The current strategy and recent moves would have moved the case bank. The query was refused: "Quartzline partner API platform roadmap" |
| 4. Interviewer name and Quartzline | n/a | No interviewer name was given, so there was no query to form. The upgrade menu says what a name would unlock |
| 5. Representative product manager, platform APIs JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Granting web search permission → I'll rerun targets 1 and 2 (values and interview process), which unlocks the values cheat sheet and the loop structure. It also moves the persona weights if the loop is several rounds.
- The current posting text, if it has changed since 14 August → the fit snapshot and the JD-tagged banks regenerate against it.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their own career path.
- Your full CV → the `[inferred]` and `[grounded]` rows gain the sentences the dossier doesn't carry.
- Prep time before Thursday → a timed triage section, so the time goes to A1 and the Skeptic drill first.
- A deep research pass (L2) → a strategy brief, interviewer writing, and loop reports, at up to 6 more searches and 2 more fetches. Costs time; say the word if you want it.
