# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union. **Dates:** three rounds on 26 November 2026.
**Interviewers:** Round 2, Head of Member Services (your future manager, name not yet given). Round 3, a panel of two branch managers (names not yet given).
**Format:** loop mode. One shared fit snapshot and sources, then one mini-pack per round.
**Changelog:** first version.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Types:** VAL = values and behaviour, scored against the published values. EXP = your own experience, checked for attribution. JD = the job's stated requirements. CO = company and strategy knowledge. CASE = a live problem from the role.
- **Question IDs:** A = round 1, B = round 2, C = round 3.
- **Guidance is scaffolding, not a script.** Every claim about your past is one of your own quoted sentences, a plain acknowledgment of a gap you stated, or an answer slot you fill in your own words.

---

## Fit snapshot

Requirements come from the JD as you pasted it. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your material says six years in retail banking, three of them as a branch supervisor. Say it in those words: "Six years in retail banking, the last three as a branch supervisor." Expect a probe on whether branch years count as customer operations; answer at the quote's own scope. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch's log, not the whole process and not the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: the end-to-end line makes a probe on the stages after the log likely. If you took a complaint past the log, say which stages were yours and what you decided; if they were not yours to decide, say so plainly and describe how the log ran. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches monthly reporting but does not mention resolution times. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names resolution times, so expect that probe. If the spreadsheet recorded how long complaints took to close, say what it recorded; if it did not, say so and say what you would add first. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material shows training tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached anyone above teller level on an escalation, say who and what you did; if not, say so and say how you would coach supervisors. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work. Answer slot: if you have worked with a digital or product team on a customer journey, say what your part was; if you have not, say so and say how you would start. |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would learn to present to senior leaders, said as a plan, never as a past. Do not add presenting experience. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [grounded] | discovery | Your material says formal complaints, not regulated ones. The quote touches the requirement without showing whether it reaches it, so it is not asserted as your claim. Answer slot: if any formal complaint ran to a regulatory timescale or an outside review, say which rules applied and what you did; if none did, say so and describe how formal complaints ran. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms: it says spreadsheet, not Excel. Name Excel only if it was Excel. Expect a probe on what the spreadsheet does. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then the nearest thing your material carries, in its own terms: six years in retail banking. No contact-centre claim. |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote about it. F9 and F6 are gaps you stated, so the pack can give those words back.

---

## Grounding brief

Built from the July 2026 strategy brief as you relayed it. You did not paste the brief itself, so check the figures against the published document before you quote them.

- **Headline commitments:** 40% of member service moved to digital channels by 2028; eight branches consolidated into five hubs over 2027; a small-business lending product launched in Q1 2027.
- **Competitive pressure:** app-only banks.
- **Vocabulary to use:** member service, digital channels, hubs, app-only banks.
- **Stale framings:** none flagged in what you relayed.

---

## Persona table

Relationship priors set the starting weights. The panel blends the two top personas for each member, and the names are not known, so the blend is used.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter screen (30 min) | Conversational / Rapport (weight 5) | Friendly opener, logistics checks, motivation questions | High. Recruiter screens weight logistics and motivation in a friendly register. Scored even when it feels casual. | 90-second background arc; logistics answers in your own words |
| 1 | Skeptic, light (weight 3) | Knockout checks on the contact centre and on presenting | Medium. The screen will test the two gaps you stated early. | Plain acknowledgment, then the nearest thing your material carries |
| 2, Head of Member Services (45 min, mostly behavioural) | Skeptic (weight 4) | Probes the contact-centre gap, end-to-end ownership and presenting to senior leaders | High. Your future manager is buying capability and checking the gaps. | Hold-then-concede on B2, the highest-ROI rehearsal |
| 2 | Values / Behavioral (weight 4) | Scenario questions on members, ownership and escalation | High. The round is mostly behavioural. | Story-map where a quote carries a story; selection scaffold where none does |
| 3, panel of two branch managers (60 min, values-scored) | Values / Behavioral (weight 4) | Four published values, scored one at a time | High. The recruiter says the panel scores against all four values. | Values cheat sheet; honest branch where no story exists |
| 3 | Case / Strategist (weight 2) | 20-minute escalation case tied to the hub plan | High. The recruiter named the case. | Clarify first, then structure; think aloud |
| 3 | Pressure (weight 2) | Time-boxed challenges on the contact-centre gap and on attribution | Medium. Branch managers may time-box. | Pause, restate, hold through two follow-ups, then concede specifically |

---

## Prohibited claims

What this pack will not coach, and why. Each entry is built from the fit snapshot. Your material says the round, the log, the spreadsheet, the training. Anything wider is listed here.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F2 | "I handled the branch's formal complaints log." Limit, in this pack's analysis: your material shows one branch's log, not end-to-end ownership. |
| Handled regulated complaints | Inflated form of F7 | Formal complaints, at the quote's scope. F7's answer slot asks which rules applied. |
| Reported on resolution times | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." F3's answer slot asks what it recorded. |
| Coached branch supervisors | Inflated form of F4 | "I trained new tellers on our escalation script." |
| Six years of customer operations | Inflated form of F1 | "Six years in retail banking, the last three as a branch supervisor." |
| Excel expertise | Inflated form of F8 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Experience in a contact centre | Negative you stated, F9 | Plain acknowledgment: "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated, F6 | Plain acknowledgment: "I've never presented to anyone above regional level." |

---

## Question banks

Each bank is one round. Types are the five tags above.

### Round 1: recruiter screen (30 min)

**Conversational (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" | Ninety-second arc: the years, then the last three as a supervisor, then the complaints work in one clause: "I handled the branch's formal complaints log." Tell the rest in your own words. | F1 and F2 are the first facts the recruiter will check against the JD. |
| A2 | "What's the reason you're looking to move on?" | EXP | [generic] | Logistics slot: give your actual reason for leaving, in one or two sentences, in your own words. Give the true reason, not the one that sounds best. | Logistics and motivation check. No reason is in your material, so the reason is yours to give. |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give the notice period you actually owe. If you are unsure of its terms, check your contract before the call. | Knockout logistics check. The only safe answer is the true one. |
| A4 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask what band the role sits in before you name one. | Pay is a logistics term. The answer is yours to give, and it fills its slot without any figure from this pack. |
| A5 | "Where are you based, and which days could you work in an office?" | JD | [generic] | Logistics slot: give your actual location and the office days you can commit to. The JD does not state an office pattern; ask for it before you commit. | Location is a logistics term. The strategy's hub plan may shape the answer, so ask which hub the role sits in. |

**Skeptic (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A6 | "Walk me through the monthly complaints spreadsheet you built, and what it measures." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on that sentence: you built it, and your regional manager uses it. Say what it counts in your own words. Answer slot: the JD asks for resolution times, so a probe is likely. If the spreadsheet recorded how long complaints took to close, say what and how you read it; if it did not, say so and say what you would measure first. Name the tool only as you used it. | F3 and F8 are the reporting evidence. This is the JD's reporting question, and it tests what the spreadsheet actually did. |
| A7 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then the nearest thing your material carries, in its own terms: six years in retail banking. No further claim. | F9 is a gap you stated. The recruiter will check it early. |
| A8 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" "work with digital teams on self-service journeys" | Name the contact centre first, in the words you gave (F9). On digital self-service, say what you have and have not done, in your own words. Answer slot: if you worked with a digital team on a journey, say your part; if you did not, say so and say how you would start. | Skeptic stem. Both JD lines are the raising sources. F5 is where the material is silent, so the honest answer is a slot. |

Coverage in round 1: the JD's reporting requirement (A6), the monthly-resolution question (A6), notice and pay (A3, A4), contact centre (A7, A8), digital (A8).

### Round 2: Head of Member Services (45 min, mostly behavioural)

**Skeptic (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how a complaint that starts in the contact centre would reach a branch, and who would own it at each hand-off." | CASE | [generic] Stated gap: "Never worked in a contact centre" | Clarify first: which channel, what the member asked for, what the record shows. Structure the hand-offs and name the owner at each. Say plainly that you have not worked in a contact centre, then reason from the case. | A live problem from the JD's end-to-end line. It asks about no past, so it claims nothing about you. |
| B2 | "You've never worked in a contact centre, and this role owns complaints across one. What makes you the right person?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Hold: name the stated absence in your own words, then the strongest thing your material shows: "I handled the branch's formal complaints log." First follow-up, concede specifically: "I've never worked in a contact centre, and I won't claim one." Second follow-up, return to the log and do not add to it. Third follow-up, what you would do in month one: answer as a plan, not a past. Answer slot: if any complaint you handled reached a team outside your branch, say which and what you did; if none did, say so. | This is the objection the JD most predictably raises, and F9 is where the material is thinnest. Deepest rehearsal: three follow-up levels, exact concession wording. |
| B3 | "Tell me about a complaint you escalated, and what happened after it left your hands." | EXP | [grounded] "trained new tellers on our escalation script" "I handled the branch's formal complaints log" | Open prompt on the JD's escalation theme. Story-mapped on the script you trained tellers on: what the script asked, how you taught it. Answer slot: if an escalation went beyond the branch, say where and what you decided; if none did, say so and describe the nearest escalation the script governed. | Escalation is the coaching requirement (F4). The answer should stay at the scope of the training you gave. |
| B4 | "Tell me about a time you presented to senior leaders." | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then, if you presented at regional level, describe it in your own words. If you did not, say what you would do to prepare to present to this panel of leaders. | F6 is a gap you stated, and this is the JD's presenting requirement asked by someone senior. |

**Values / Behavioral (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "Tell me about a time you had to tell someone something they didn't want to hear." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a time you told someone an unwelcome thing and it changed what happened: the moment, what you said, the result. If none comes to mind, say so plainly, then give the nearest thing your material carries: the spreadsheet your regional manager uses, and what in it you had to say to them. Answer slot: if it showed something they did not want to hear, say what; if not, say so. | Tests Own the Fix in the candidate's own words. The material has no ending for this question, so the honest branch is written in. |
| B6 | "Tell me about a complaint you didn't let go of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on the log: the beat is the log you handled. Answer slot: if you kept one complaint from start to finish and can say how it closed, say that; if not, say so and describe how the log tracked open items. | Maps to Own the Fix. The rehearsal is the candidate's own follow-through, not a claim the material does not carry. |
| B7 | "When did you put a member's need ahead of a rule or a target?" | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: pick a time a member's need cut across a rule, a number or a script; name the rule, the member, and what you did. If none comes, say so, then the nearest thing: the script you trained tellers on. Say what it asked a teller to do, and whether it ever did not fit a member's case. | Maps to Members First, Always. The quote gives the script, not a story about putting a member first. |
| B8 | "Your branch is part of its town. How do you account for that when you measure complaints?" | VAL | [grounded] values line, as you pasted it: "every branch is part of its town" | Honest branch: your material shows counts and a branch log, not work on local context. If you have compared a complaint pattern with a branch's local situation, say what you saw; if not, say so and say how you would check. | Maps to Neighbours, Not Numbers. The material shows numbers, so do not claim town ties you have not described. |

Coverage in round 2: contact centre and end-to-end (B1, B2), escalation coaching (B3), presenting (B4), ownership (B6), members (B7), values (B5, B8).

### Round 3: panel of two branch managers (60 min, values-scored, 20-minute case)

**Values / Behavioral (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Members First: tell us about a decision you made from the member's side of the counter." | VAL | [grounded] values line, as you pasted it: "Members First, Always — we decide from the member's side of the counter." | Selection scaffold: pick a decision where the member's side changed the outcome: the decision, what the member needed, what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries: the branch's formal complaints log you handled (F2). Say what you kept hold of there, and what closed it if anything did. | No quote carries a story about this value, so the honest branch is written in. |
| C2 | "Plain Words: tell us about a time someone needed something explained twice." | VAL | [grounded] values line, as you pasted it: "Plain Words — if a member needs it explained twice, we wrote it wrong." | Scaffold: pick a time an explanation did not land the first time and you changed how it was given. Beats: what was unclear, what you changed, what happened. If none comes, say so, then the nearest: "I trained new tellers on our escalation script." Say whether you changed how the script was taught. | Scored on Plain Words. The training sentence is the nearest material, not a plain-words story. |
| C3 | "Neighbours, Not Numbers: what do you know about a branch's town that its complaints numbers would never show?" | VAL | [grounded] values line, as you pasted it: "Neighbours, Not Numbers — every branch is part of its town." | Honest branch: your material shows branch counts and a log, not work on a town. If you know something about a town from working in its branch, say what; if not, say so and say how you would find out. Do not claim local ties your material does not show. | The panel will test the value against your spreadsheet background. Expect the probe on numbers over neighbours. |
| C4 | "Own the Fix: tell us about a problem you found that was not yours, and what you did with it." | VAL | [grounded] values line, as you pasted it: "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Selection scaffold: pick a problem you found that was outside your job and held until it was solved: what you found, who else needed to act, when it closed. If none comes to mind, say so, then the nearest: the formal complaints log you handled (F2). Say what you kept hold of there, and what closed it. | Scored on Own the Fix. Honest branch written in, since the material has no ending for this. |

**Case (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member escalates a complaint about a fee, and the branch will merge into a hub next year. Talk us through the case." | CASE, JD | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you relayed it) | Live case, 20 minutes. Clarify first: what the fee was, what the member asked for, whether any regulatory timescale applies. Then objective, segmentation (member harm versus process failure), approach (who decides, what the member hears, when it closes), metrics (how you would count "resolved"), and risks (a regulatory deadline, the hub move, trust). Think aloud, and challenge one premise respectfully. Make no claim about your past. | Covers the JD's regulated-complaints requirement through the timescale check (F7), and grounds the case in the strategy you relayed. |
| C6 | "Your supervisors escalate everything to you. What do you do?" | CASE, JD | [grounded] "coach branch supervisors on escalations" (JD) | Structure: what you would ask first (which escalations, what the supervisors decided, what they were missing), what you would do this week, what you would coach, and how you would check it had changed. Answer slot: if you have coached a supervisor or teller on when to escalate, say what you did; if not, say so and say how you would start. | Covers the JD's coaching requirement as a live problem, not a past claim. |

**Pressure (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C7 | "Sixty seconds: why should we trust you to own complaints across a contact centre you have never worked in?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Hold: state what you have run, the formal complaints log, in those words. Concede specifically: "I've never worked in a contact centre, and I won't claim one." Hold through two follow-ups: return to the log, and describe how you would learn the queue, as a plan. Do not fold on the core claim. | Pressure stem. F9 is the stated gap, and F2 is the log. Hold-then-concede. |
| C8 | "The complaints you logged: how much of what happened to them was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Hold: say what you handled, the log, and whose decisions the outcomes were. Answer slot: if you decided an outcome on a logged complaint, say which and how; if you did not, say so and say whose decision it was. | Tests attribution under pressure. The honest answer is the one the material supports. |

Coverage in round 3: all four values (C1 to C4), the escalation case with the regulated-timescale check (C5), coaching supervisors (C6), the contact-centre gap under pressure (C7), attribution (C8).

---

## Values cheat sheet

The panel scores against the four values you pasted. The material carries a story for none of them, so each row gives a selection scaffold ending in its honest branch.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No story carried. Selection scaffold (C1). Nearest material, F2: "I handled the branch's formal complaints log" |
| Plain Words | If a member needs it explained twice, we wrote it wrong | No story carried. Scaffold (C2). Nearest material, F4: "trained new tellers on our escalation script" |
| Neighbours, Not Numbers | Every branch is part of its town | No story carried. Honest branch (C3). Your material shows numbers, so do not claim town ties |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No story carried. Scaffold (C4). Nearest material, F2: "I handled the branch's formal complaints log" |

---

## Reverse questions

No interviewer profile exists, so none is tied to an interviewer's own path. The panel are not your peers, so no reciprocity question is included.

| Round | Question | Why it lands |
|---|---|---|
| 1, recruiter | "What would a good first six months look like for whoever runs complaints across the branches?" | Shows you are thinking about the job, not only the offer. |
| 2, Head of Member Services | "Where do complaints usually stall between a branch and the contact centre today?" | Names the end-to-end gap and shows you read the JD closely. |
| 2 | "As digital channels take on more member service, which complaint types do you expect to move first?" | Links the question to the 40% digital target in the brief you relayed. |
| 2 | "What would you want finished by the end of the first quarter?" | Asks your future manager for the bar you will be measured against. |
| 3, panel | "When a branch moves into a hub, what happens to its open complaints?" | Puts a concrete consolidation risk from the 2027 plan on the table. |
| 3 | "What does a branch manager look for from a complaints lead when a case escalates?" | Asks the panel for their bar before they score you against it. |

---

## Sources

- **Provided documents (your message):** your background, the JD, the four values as you typed them, the strategy brief as you relayed it, and the recruiter's process email as you relayed it. No dossier was provided.
- **Research:** none run. The values, strategy, loop structure and JD were all in what you sent, so no search or fetch was needed.
- **Limit:** the values and strategy are your summaries. Check them against ashgrovecu.org and the published brief before you quote a number or a phrase.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet already fixed by the values you pasted; not checked against ashgrovecu.org |
| 2. Ashgrove interview process, member services | skipped | Loop structure fixed by the recruiter's email as you relayed it |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief as you relayed it fixes current priorities |
| 4. Interviewer name and Ashgrove | n/a | Interviewers beyond their roles are not yet assigned, so there is no query |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## Upgrade menu

- Round 2 and round 3 interviewer names → persona weights from their public footprint, and a tailored reverse question.
- A redacted copy of the monthly complaints spreadsheet, with names removed → F3 and F8 move from medium to high, with the artifact named in the bridge.
- Whether any formal complaint ran to a regulatory timescale or an outside review → F7 gets a grounded line, and the C5 answer changes.
- Whether your log recorded how long complaints took to close → F3's answer slot becomes a grounded line for A6 and C8.
- Any digital or product-team work, however small → F5 moves from none to a grounded line for A8 and B-round answers.
- Any presentation above regional level, even to a branch forum → F6 and B4 gain a grounded quote.
- Whether the panel case comes with a written brief or is spoken → changes the C5 structure.
- Deep research (L2): the strategy brief itself, interviewer public footprints, and loop reports for this role family. Up to six more searches and two fetches, a few minutes. Offered, not run; say yes to run it.
- A `tuesday-dossier.md` from a verification pass would ground F1 to F9 in checked evidence before you rehearse them.
