# Interview prep pack: Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three rounds, built as one loop: Round A (Tuesday, hiring manager, Director of Engineering, 45 min), Round B (Thursday, panel of two staff engineers and a product manager, 60 min), Round C (following Monday, VP Engineering, 30 min, "values and leadership philosophy"). Research: L1, and every search was refused, so no company values, loop or strategy is in this pack. Prep time: not stated.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your own experience, including how figures were counted
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge (none here, because strategy research did not run)
- **CASE**: a live problem from the role

Question IDs are A for Round A, B for Round B, C for Round C. Guidance is scaffolding, not a script. "Answer slot" means an instruction for the interview, not a question to me. Provenance labels: **[grounded]** means your own words or the role summary you sent; **[generic]** means a pattern with no claim about you or Larkfield.

## Fit snapshot

Requirements come from the role summary in your message, quoted. No full job description was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Words: "For three years I was a team lead of 6." Answer slot: if you have led more than one team, or anyone beyond six, say how; if not, say so plainly and stay with the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | The quote already carries delivery under pressure, in reliability terms. Words: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after it." Expect a probe on how the 60% was counted. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), growth component | none given | none | [grounded] | discovery | Your material does not show engineers grown in their careers. Answer slot: if you have grown engineers, say which and how you know; if not, say so plainly and give your plan. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary, your message), hiring component | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | The quote reaches hiring in role terms. Lead with it as written: "I run our hiring loop for backend roles." Expect a probe on how many of the 40 were yours. |
| F5 | "partner with hardware and product on roadmap" (role summary, your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | medium | [grounded] | capability | You stated the absence yourself. Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan and never as past work. |
| F6 | "Lead two squads building device-management services" (role summary, your message), device component | none given | none | [grounded] | discovery | Your material shows payments work and no device-facing services. Answer slot: if any service you ran had hardware, device or external-dependency constraints, say what; if none did, say so plainly and say how you would learn the device domain. |

Gate rows: none identified. Without the full job description, I cannot tell whether location, on-site or travel terms apply (see the question at the end).

Note for the pack's analysis: the role summary does not say whether the two squads have their own managers. That decides whether "never managed managers" is a gap for this role, which is why it is in the upgrade menu.

## Prohibited claims

Built locally from the fit snapshot. None of these may be asserted, implied or softened in any answer, rehearsal or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led 11 engineers" or "I've managed managers" | Inflated form of F1 and F3 | "For three years I was a team lead of 6," and the plain acknowledgment "I've never managed managers." The material shows a team of six, not two squads or eleven engineers. |
| "I cut on-call by 60%" as your own sole result | Inflated form of F2: the quote says the team's burden dropped after you pushed a quarter through | The quote at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through." |
| "I've owned a hardware-adjacent roadmap" | Inverse of F5: a negative you stated | "I've never owned a hardware-adjacent roadmap." |

## Persona table

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| A | Skeptic (4 questions) | Probes the two gaps you named, and whether you can scale from six | Top weight. A hiring manager buys capability and derisks gaps, and your stated gaps are the obvious ones to test | Name the gap first, then the nearest real evidence, then a plan labeled as a plan |
| A | Data-Driven Prober (2) | Asks how the 60% and the 40 interviews were counted | Mid weight. Your two figures are the ones a manager would check | Say how each figure was counted if you know; say so if you don't |
| A | Case / Strategist (2) | Live problems on device-management services and hiring | Mid weight. Hiring-manager rounds carry live problems on the actual roadmap | Clarify before structuring; state the device-domain questions you'd ask first |
| B | Data-Driven Prober (4) | Staff engineers test technical substance and the numbers | Top weight. Two of the three panelists are staff engineers, and the reliability quarter is the most probe-able claim in the material | Name the weakest assumption before they do; say what you did not measure |
| B | Peer Evaluator (2) | The product manager probes the seam with hardware and product | Low weight. The product manager is a peer for roadmap work | Propose seam principles rather than claiming to know the seam |
| B | Case / Strategist (2) | A device roadmap trade-off | Low weight but present, because the roadmap partnership is a stated requirement | Clarify, then structure the trade-off |
| B | Pressure (2) | Pushes on managing managers and on how much of the result was yours | Low weight, but the panel is where attribution gets tested | Hold through two follow-ups; concede the gap specifically |
| C | Values / Behavioral (4) | Scores whether your past shows leadership under pressure and a leadership philosophy | Top weight. The recruiter describes the round as "values and leadership philosophy," which is a values-style round | Selection scaffolds where your material has no story; use real stories only |
| C | Pressure (2) | Asks whether you would hold a leadership position under pushback | Low weight. A VP round is a composure check | Hold through two follow-ups; concede uncertainty without folding |
| C | Conversational (2) | "Walk me through the journey" and "what would you do in six months" | Low weight but scored, since casual questions still count | A 90-second arc built only from the facts you gave |

## Round A: hiring manager, Director of Engineering (Tuesday, 45 min)

Mini-pack with 8 questions: Skeptic 4, Prober 2, Case 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never managed managers and never owned a hardware-adjacent roadmap. What makes this the right next step for you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI prep in this pack. Say the gap first, in your words: "I've never managed managers," and "I've never owned a hardware-adjacent roadmap." Then the nearest thing you did do, in the quotes' terms: "For three years I was a team lead of 6," and "I pushed a reliability quarter through against roadmap pressure." Then a plan for each gap, labeled as a plan. Answer slot: if you have worked with someone who managed managers, say what that was; if not, say so plainly. Hold through two follow-ups by returning to the team of six; concede the two gaps specifically and never fold on the team-lead record. | F5 and F1 make this the most predictable objection: your own negatives match two role requirements. Deepest rehearsal here. JD because it scores stated requirements. |
| A2 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say what the 60% measured and over what period, in your own words. Name the assumption behind it you would defend least, before they ask. Answer slot: if you can say which part of the drop you can attribute to your push, say it; if you cannot separate your share from the team's, say that plainly. | F2 is the figure. Figures raise the defend-the-number slots. EXP because attribution is what this tests. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Answer in order of the gaps you named, and name the one you'd be slowest at first. Do not add a gap you did not name. | F5 and F3. A stock Skeptic stem that the candidate's own negatives answer directly. |
| A4 | "Of the roughly 40 interviews, how many were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Give the figure as you stated it. Answer slot: if you can say how many were yours and what you decided in them, say so and how you counted; if you cannot, say that plainly. | F4. The figure is the candidate's, so the share is an answer slot, not a supplied number. |
| A5 | "Two interviewers disagree on a backend hire. How do you settle it?" | CASE | [generic] | Structure it: the evidence each interviewer saw, a test that settles the disagreement, what you would ask each of them, and how the decision is recorded. If you have a real case, use it. No claim about your past in this answer. | F4 hiring is the strength. Generic because it is a pattern, not a fact about Larkfield. |
| A6 | "This role builds device-management services. What would you need to learn first?" | CASE | [grounded] "Lead two squads building device-management services" | Name what you'd learn first: how devices connect, how fleets are sized, how updates reach hardware. Frame them as questions you would ask, not as things you already know. No claim about your past. | F6 is discovery. The answer is a learning plan, not a knowledge claim. |
| A7 | "I don't see hardware work in your background. How would you handle hardware in this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then a plan: who in hardware you would meet first and what you would ask them. | F5 is a capability gap you stated, so the words are yours. Never claim hardware work the material does not show. |
| A8 | "Why should we believe a team lead of six can run eleven engineers across two squads?" | JD | [grounded] "For three years I was a team lead of 6" and "own delivery, hiring and growth for 11 engineers" | Hold: "For three years I was a team lead of 6." Concede: "I haven't led eleven." Then your plan to scale, labeled as a plan. Hold through two follow-ups; concede the scale gap specifically. | F1 is the scale gap, and the probe is aimed at it. The concession is the honest answer. |

Requirement coverage for Round A is in the coverage table below.

Reverse questions for Round A:

| Question | Why it lands |
|---|---|
| "What did the last person in this seat get wrong in the first ninety days?" | Shows you are planning for the transition, and invites a candid answer about what the role demands |
| "Does anyone on the two squads manage other managers today?" | Settles whether "never managed managers" is a gap here (A1) |
| "Where does the roadmap get decided between hardware and product, and who breaks ties?" | Shows you understand the partnership is the hard part |
| "What would you need to see from me in the first ninety days to call the hire a success?" | Turns the interview into a shared success definition |
| "What's the hardest hiring call the team has made recently?" | Opens the hiring conversation A5 prepares for |

## Round B: panel of two staff engineers and a product manager (Thursday, 60 min)

Mini-pack with 10 questions: Prober 4, Peer 2, Case 2, Pressure 2. The panel has no named members yet, so persona weights are a blend.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the assumption in your words before they ask. Answer slot: if you can name one, say it and why it matters; if you cannot, say that plainly. | F2 is the figure a staff engineer would test. This is the weakest-assumption move. |
| B2 | "Walk me through what that reliability quarter contained." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Choose the parts you did and say so in your words. Answer slot: if the quarter included changes to services, name them and say whose they were; if it was mostly other work, say that. | The quote does not say what changed, so the technical detail is a slot, not a claim. |
| B3 | "Which numbers told you the reliability quarter was working?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through." | Name any number you used and how it was counted. Answer slot: if you judged it another way, say that. | Staff engineers ask for the measurement, and the quote has only one measure. |
| B4 | "Your team of six: what does on-call look like per engineer now?" | EXP | [grounded] "My team's on-call burden dropped 60%" | Answer slot: if you have the per-engineer figure, give it and how it was counted; if not, say so plainly. | A figure not in the quote. The slot is the honest branch. |
| B5 | "Hardware and product disagree on a device-API roadmap. Where do you sit, and what would you need from me?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary) | Propose principles for the seam: who decides scope, what each side brings and takes. Do not pretend to know this seam. No claim about your past. | Peer seam question. The product manager's and staff engineers' seam is the requirement. |
| B6 | "How do you handle credit when delivery spans two squads?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Give the principle first. Then the result as "my team's" and the push as "I": "My team's on-call burden dropped 60% after I pushed a reliability quarter through." | Peer credit probe. Keeps the team result and your action separate. |
| B7 | "A device roadmap has two squads and a hardware dependency slipping. Sketch what you'd do first." | CASE | [generic] | Clarify what is slipping and who owns the dependency. Decide what to protect. Name the first conversation you would have. No claim about your past. | Live problem from the role. Generic because it is a pattern. |
| B8 | "Product wants next quarter's feature, and the reliability backlog is growing. How do you decide?" | CASE | [generic] | Structure the trade-off: the cost of delay, the on-call load, and what the roadmap owner needs to hear. Do not present your reliability quarter as the answer unless you describe what you actually did. | Connects to F2 without invoking it. |
| B9 | "Sixty seconds: why you over someone who has managed managers?" | JD | [grounded] "I've never managed managers" | Pause, restate the question, then: "I've never managed managers." Concede it. Then the one thing you can show: "For three years I was a team lead of 6." Hold through two follow-ups; never fold on the team-lead record. | Pressure stem. F1 is the record to hold and F5 the concession. |
| B10 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: the result is the team's, and the push was yours, both as the quote states them. Concede the part you cannot separate, specifically. Hold through two follow-ups. | Pressure version of the attribution probe. Hold-then-concede. |

Requirement coverage for Round B is in the coverage table below.

Reverse questions for Round B:

| Question | Why it lands |
|---|---|
| "What would someone new do in their first month that would genuinely help your team?" | Reciprocity framing for the peers on the panel |
| "Where is the device-management code most painful for the squads today?" | Shows you are already thinking about the domain |
| "How do you know when a reliability push is worth more than a roadmap feature?" | Turns the B8 trade-off into a conversation about how the team decides |
| "How does on-call work across the two squads today?" | Grounds the reliability question in their real setup |
| "What is one thing about the device roadmap you would want a new engineering manager to understand before the first planning cycle?" | Lets the panel show you what they actually worry about |

## Round C: VP Engineering, "values and leadership philosophy" (Monday, 30 min)

Mini-pack with 8 questions: Values 4, Pressure 2, Conversational 2. The recruiter's words "values and leadership philosophy" establish a values-style round, so VAL questions are present. No published company values are in hand, so there is no values cheat sheet. The VAL questions use selection scaffolds where your material has no story.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told senior leaders something they did not want to hear: the stake, the moment you did not fold, and the relationship afterward. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I pushed a reliability quarter through against roadmap pressure." | Persona stem. The nearest quote is honest because no story is in the material. |
| C2 | "What is your leadership philosophy, in a sentence or two?" | VAL | [grounded] "values and leadership philosophy" (recruiter's round description) | State your philosophy in your own words, then tie it to a decision you made. Answer slot: the decision must be one you made. If the reliability quarter is the decision you mean, say it in the quote's terms. | Recruiter's own words name the round. The philosophy is yours to state. |
| C3 | "When did a priority call cost your own team something?" | VAL | [generic] | Pick a call where your team paid for a decision. Answer slot: if the reliability quarter cost the team roadmap time, say so; if it cost something else, or nothing you can name, say that. | Generic because it is a pattern. The honest branch is named. |
| C4 | "Tell me about someone you grew who you did not hire." | VAL | [generic] | If you grew someone, name the arc and what you did. If you have not, say so plainly and give your plan for growing engineers across eleven people. | F3 is discovery. This question is the same gap in a values frame. |
| C5 | "Why haven't you managed managers, and why would you start now?" | JD | [grounded] "I've never managed managers" | Say it plainly: "I've never managed managers." Give the honest reason for the step, only what you can state. Hold that the team of six is your evidence; concede the uncertainty specifically. | Pressure version of the F5 gap. Hold-then-concede. |
| C6 | "Is the reliability quarter your best call, or just the one that went best?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Hold: the push was yours, the result was the team's, both as quoted. Concede in your own words what you would call luck or context. Hold through two follow-ups. | Pressure on the strongest quote. The concession must be specific. |
| C7 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Build a 90-second arc from those three facts only. Add nothing you have not said. | Casual opener that is still scored. The arc is built from the candidate's own sentence. |
| C8 | "What would you want to be doing here in your first six months?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary) | Give a plan, not a promise: the hardware plan from A7, plus one people step. | Reverse-style question that is scored. The plan is the answer. |

Requirement coverage for Round C is in the coverage table below.

Reverse questions for Round C:

| Question | Why it lands |
|---|---|
| "Which leadership behavior here do you most want to see more of?" | Opens the values conversation with their own priorities |
| "Where can I read the company's values in your own words, and which one is hardest to live by?" | Turns a gap in the pack into a question for the VP |
| "What would make you say a year from now that this was the wrong hire?" | Shows you are willing to be measured |
| "How do you want an engineering manager to bring problems to you?" | Signals leadership philosophy in practice |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A6, A8, B5 |
| Own delivery | A2, B1, B6, B10 |
| Hiring | A4, A5 |
| Growth for 11 engineers | A3, C4 (the material shows no grown engineers, so this stays a slot) |
| Partner with hardware and product on roadmap | A1, A7, B5, B7, C8 |

## Sources

Provided documents: your message, which holds the role summary, the three round details and your background. No full job description and no CV document were supplied.

Searches sent (L1 targets 1 to 3), all refused by the host:
- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems strategy news": refused

No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet (section 10). The search was refused, so the cheat sheet is absent |
| 2. Interview process | unavailable | Loop structure check. Your message already names all three rounds, so the loop is established, but the search would have checked case formats and whether a values round is documented |
| 3. Strategy and recent news | unavailable | Company-strategy bank (CO). Absent, so no CO questions appear |
| 4. Interviewer name | n/a | No interviewer name was given |
| 5. Representative role JD | unavailable | Representative requirements beyond the role summary. Not sent, because the host refused search for targets 1 to 3 |

Persona weights rest on round-type priors and on your stated round details. Loop structure comes from your own words, which establish the rounds and who runs each one.

## Upgrade menu

- Full job description, or your recruiter's prep email → the fit snapshot's requirements become verbatim [grounded] rows, and any on-site, location or travel terms become gate rows
- Search access granted, then a re-run → the values cheat sheet, a loop check, and strategy-grounded CO questions; targets 1 to 3 would run
- A pasted company values page → the values cheat sheet, and VAL questions mapped to the company's actual values
- Names for the Director, the panel members and the VP → an interviewer read, per-member persona weights, and tailored reverse questions
- Prep hours across the two weeks → a prep triage ordering the three rounds
- Whether the two squads have their own managers → settles whether "never managed managers" is a gap in Round A (A1)
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. Want it?
