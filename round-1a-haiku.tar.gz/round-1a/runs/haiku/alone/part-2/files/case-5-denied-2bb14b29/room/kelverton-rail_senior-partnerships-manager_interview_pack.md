# Kelverton Rail, Senior Partnerships Manager: second-round panel prep

Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken POV on operator partnerships over the next 18 months, landing on what it means for the operators themselves, then Q&A in which Ross pushes on commercials. First build of this pack; nothing to regenerate yet.

## How to use and type key

Personas are how a question is asked. Types are what is being scored:

- **VAL**: values alignment (not detected here, so no bank uses it)
- **EXP**: your own past, probed
- **JD**: the role's requirements (no JD yet, so these come from the recruiter's words)
- **CO**: company and strategy knowledge
- **CASE**: a live problem

Provenance labels: `[grounded]` means your own sentence, or the recruiter's words you pasted. `[inferred]` means my derivation about the role or the fit. `[generic]` means a pattern not drawn from your material or from Kelverton.

Guidance is scaffolding, not a script. Rehearse the shape and say it in your own words.

**What this pack is built on:** your message, including the recruiter's lines you quoted. No JD was supplied. The market report is not in my working directory, so I have not seen its content and the differentiation notes in section 5 are provisional.

## Prep triage (about 4 hours)

1. **POV build, section 5 (about 90 minutes).** Write the three theses and the concession under each. Then speak the 15-minute version aloud twice, timed. Land the operators close in the final two minutes, not the first.
2. **Commercial bank A1 to A6 (about 75 minutes).** Say the honest branches aloud against a timer. Start with A4, the highest-ROI item in this pack.
3. **Operator-side credibility, B2 and C2 (about 30 minutes).** Say the bridge in one breath, then the concession.
4. **Reverse questions and the opening arc, D1 and D2 (about 20 minutes).**

Everything else is insurance. Those four blocks total about 215 minutes, leaving slack for a second pass on A4.

## Reading the interviewers

Not built. The brief gives first names and titles only, and the research that would have read their public footprint was refused (see Sources). The persona weights below rest on role priors, and the upgrade menu says what their public profiles would change.

## The fit snapshot

Requirements are the recruiter's words; no JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" (recruiter's brief, your message) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material says you worked on the operator side as a consultant, planning bus and light rail networks. It does not show an operator's scheduling decision made on your recommendation. Answer slot: if any operator decision on a scheduling or planning change was yours to influence, say which and how; if none was, say so plainly and stay with what the consulting work showed you. |
| F2 | "Ross will push on commercials" (recruiter's brief, your message) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap you stated, so the words can be yours: "I've never carried a direct quota. What I ran was influenced revenue." Then the record in F4. No claim to quota experience. |
| F3 | rail sector sales experience (role-family prose, `[generic]`) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated: "I've never sold into rail specifically." Then the operator-side bridge in F1. Never a claim to rail sales. |
| F4 | building and growing a partner base (role-family prose, `[generic]`) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | none | No gap, but a headline figure with its counting method not in your material, so expect a probe on it. Lead with the quote's own terms: from 6 partners to 40. The method is the question A1 holds, not a claim this pack makes. |
| F5 | senior-level partnerships experience (role-family prose, `[generic]`) | "9 years in partnerships" (your message) | high | [grounded] | none | No gap. Use the quote's own words in the opener, D1. |

Rules behind the gap types, in brief: F2 and F3 are `capability` because you stated the absence. F1 is `transferability` because consulting is adjacent work that does not reach operator scheduling decisions. F4 and F5 are `none` because the quotes already reach the requirement in role-relevant terms.

## Prohibited claims

Not coached in any answer, slot, hold or rationale in this pack:

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a direct quota | Contradicted by your sentence (F2) | "I've never carried a direct quota." |
| Sold into rail | Negative you stated (F3) | "I've never sold into rail specifically." No slot. |
| Owned operator relationships | Inflated form of F4: the figure says partners, and the ISV channel, not operator contracts | The F4 quote at its own scope. The limit is this pack's observation: your material says partners and influenced revenue, not operator accounts. |
| Led operator scheduling decisions | Inflated form of F1: the sentence says you know the operator side from consulting | The F1 quote at its own scope, with the limit as the pack's observation, not a first-person negative. |
| Owned the £4M | Inflated form of F4: your figure is influenced revenue | "roughly £4M of influenced revenue," in those words. |

## Persona weights

Panel: blend the top personas of each member's relationship. Ross's role is not in the relationship table, so his weights are the nearest match (executive, plus the recruiter's note that he pushes on commercials). Deepa, your future manager, is a hiring-manager relationship.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Ross | Follows the headline figure to its counting method and assumptions | High. The recruiter named commercials, and F4 is the only figure in your material | Hold the figure and its assumption in your own words (A1 to A3) |
| Pressure | Ross | Pushes on quota and on influenced revenue as a commercial measure | High. F2 is the most visible gap in your material against the stated focus | Hold through two follow-ups, then concede specifically (A4, A5) |
| Case/Strategist | Deepa, and Ross on commercial trade-offs | Live problems on operator partnerships and the 18-month plan | High. The POV is a case by another name, and a hiring-manager relationship prompts live problems | Clarify, then structure, then the one premise to challenge (B1 to B6, A6) |
| Skeptic | Deepa | Motivation and fit: why you, and what you have not done | Medium. F3 is a stated gap; the panel will reach it | Concede the sales gap first, then the bridge (C1 to C3) |
| Conversational | Either | An open opener, and the reverse-question slot | Low-medium. A 60-minute panel opens with an arc; casual questions are still scored | Pre-scripted 90-second arc (D1); treat D2 as scored |

Depth follows weight: Ross's bank is the deepest (A1 to A6), Deepa's the next (B1 to B6, C1 to C3), the opener the least.

## Section 5: Graded deliverable, the 15-minute POV

The brief names the requested close: "Please land on what it means for the operators themselves." The grounded facts to build on are F1 and F4.

Build the POV around one thesis, one divergence, and one anti-pick. Each has its concession.

**Thesis 1: start from an operator's own planning problem** (`[generic]`). A timetable change or a disruption recovery is the moment an operator already wants help; the partnership should meet it there, and the partner shows how the problem gets solved. *Concession:* operator planning teams move slowly, and a problem-first pitch may wait for a change window. *Grounding:* F1, your sentence "bus and light rail network planning, so I know the operator world from the other side."

**Thesis 2: the ISV model transfers as method, not as motion** (`[generic]`). Partner recruitment and the enablement that carried your F4 figure teach how to build a partner base; buying in rail runs through operators' own integration and procurement teams, which a payments channel does not face. *Concession:* I haven't sold into rail (F3), so the rail motion is the part I would learn first. *Grounding:* F4, "took it from 6 partners to 40, roughly £4M of influenced revenue."

**Thesis 3: measure partnerships by operator outcome, not only influenced revenue** (`[generic]`). This is the divergence Ross is most likely to test. *Concession:* operator outcomes are hard to attribute to one partner, and operators may not share the data needed to prove it.

**Anti-pick:** do not start with the widest operator list. Say what you would not chase first, and what that costs in near-term pipeline. (`[generic]`)

**Differentiation against the report.** The report is the consensus answer that other candidates will recite. Bring one consensus item to show you read it, then Thesis 1 as the divergence. The specific divergences depend on the report's shortlist, which I have not seen (see the first upgrade-menu line).

**Close.** Describe one operator's day-to-day change in plain words, once, then stop. Do not restate the theses.

## Question banks

Ross first (weight highest), then Deepa, then the opener.

### Bank A: Ross, Prober and Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | State the figure in your own words, then the method. Answer slot: if you set the attribution rule, or knew it, say what it was and what it counted; if you did not set it, or do not know how it was counted, say so plainly and say what you could pull to check. Do not supply a method. | F4 is the figure the commercial pushback will land on. This is the defend-the-number question. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Name the weakest assumption before Ross does, in your own words. Answer slot: if you know one, name it and what it moves; if you do not, say you have not tested how sensitive the number is. | The weakest-assumption move turns a gotcha into a credibility gain. |
| A3 | "Which of the 40 partners best shows what took you from 6 to 40?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Name one partner and the move that brought it in, in your own words, and what it produced. Answer slot: if the move was yours, say what you did; if the partner came through someone else, say so and what you did with it. | Tests attribution: the "how much was actually you" probe, aimed at the growth record. |
| A4 | "You've never carried a direct quota. What would you commit to on a number here?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold the position that the influenced-revenue record is a number you can defend, through two follow-ups. Concede the real limit specifically: a direct quota is untested for you. Say how you would build a first-year number with the commercial team, and do not name a figure you have not been given. | Highest-ROI item in this pack. Ross will press commercials, and the quota gap is the most likely probe on it. Deepest rehearsal: the second follow-up is "what happens if the number is wrong." |
| A5 | "Influenced revenue is what a partner touched, not what it closed. Why should I take it as a partnership measure?" | EXP | [grounded] "only influenced revenue" (your message) | Hold: it is the measure you ran, and you can say what it does and does not tell you. Concede: it is not closed revenue, and say what you would add to it. | Pressure on the one metric your material carries. |
| A6 | "What would you cut from the operator partnership budget in year one, and what would you protect?" | CASE | [generic] | Structure it: what each line buys, what evidence would move you, and the one thing you would protect. Name what you would stop doing, not only what you would fund. | A live commercial problem on the recruiter's commercials line. It presupposes nothing about your past. |

### Bank B: Deepa, Case/Strategist and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk us through where you'd take operator partnerships over the next 18 months." | CASE | [grounded] "what it means for the operators themselves" (recruiter's brief, your message) | Deliver section 5 in 15 minutes: the operator's change in one sentence, the sequence, then the theses. | This is the graded POV. |
| B2 | "What would an operator's planning team have to change for your partnership to work?" | CASE | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Name the planning-cycle step your consulting work showed, in your own words, and what a partner would have to fit into it. Answer slot: if you did not sit inside an operator's planning team, say so plainly and say what you learned from the outside. | F1 is the operator-side credibility story. Highest-ROI operator item after A4. |
| B3 | "What would you need to learn about how an operator makes a scheduling decision in your first 30 days?" | JD | [generic] | Present it as a plan: who you would meet, what documents you would read, which decisions you would shadow. Never present the plan as a past. | Tests the F1 gap by asking for a plan. |
| B4 | "Name a partner type you would not pursue for operators, and why." | CASE | [generic] | Name one and concede its cost. This is the anti-pick, said aloud. | Scores the anti-pick in section 5. |
| B5 | "Where would you disagree with the consensus in the market report?" | CO | [generic] | After you paste the shortlist, rehearse one consensus item to show grounding, then one divergence with reasons. Until then, use Thesis 1. | Differentiates from the report rather than reciting it. |
| B6 | "How would you know in 12 months that operators are better off for the partnership?" | JD | [generic] | Name a measure tied to the operator, not to revenue, and concede that attribution is hard. | Connects the close to a measure Ross will also test. |

### Bank C: Deepa, Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message) | Name rail sales as the weakest area, in your own words, then the ramp plan from B3. Do not say you have sold into rail. | The Skeptic's opener, and the setup for C2. |
| C2 | "Why would a rail operator take a partnership pitch from someone who has never sold into rail?" | EXP | [grounded] "Never sold into rail specifically" and "bus and light rail network planning, so I know the operator world from the other side" (your message) | Concede the sales gap first. Then the bridge: the operator side from consulting, and what you know about how operators work. Hold it; do not claim you sold to operators. | The premise is the gap you stated; both quotes are yours. |
| C3 | "Why you over someone who has sold into rail for ten years?" | EXP | [grounded] "Never sold into rail specifically" (your message) | Hold: your case is the operator-side knowledge and the partner record; concede the sales record. Answer slot: if there is a specific reason to choose you, say it in your own words. | The stress version of the Skeptic question. |

### Bank D: Opener

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships"; "5 years in transport consulting"; "running the ISV channel" (your message) | A 90-second arc in this order: consulting on the operator side, then partnerships, then the ISV channel. Each beat is the quoted sentence, no more. | Scored as casually as a formal question. |
| D2 | "What drew you to partnerships in software sold to operators?" | JD | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Answer from the operator-side view that consulting gave you, and what it made you notice about partners. Keep it at that scope. | Operator fit, asked casually. |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "what it means for the operators themselves" (recruiter's brief) | B1, B2, B6, section 5 |
| 18-month operator partnerships (recruiter's brief) | B1, B3, section 5 |
| "Ross will push on commercials" (recruiter's brief) | A1 to A6 |
| Commercial pushback on quota and influenced revenue (your message) | A4, A5, B5 |
| JD requirements | None: no JD supplied. Add it and the table gains JD rows. |

## Reverse questions

1. "What does success look like for this role at six months?" *Why it lands:* it makes Deepa describe the bar, and your answer to it becomes the commitment you are measured against.
2. "Where do operators push back hardest on partner-led sales today?" *Why it lands:* it shows you think at the operator's level, not only the company's.
3. "How do you and Ross split a partnership number between influenced and direct revenue?" *Why it lands:* the commercial pushback is coming, and asking first changes the frame of it.
4. "What did your own first year leading partnerships teach you that you'd want the next hire to know?" *Why it lands:* with no public profile for Deepa, this is the safe version of a question about her path, and it turns the conversation into a peer one.
5. "What would make the first 90 days genuinely useful to your team?" *Why it lands:* it is the reciprocity question, and it tells the panel what you bring.
6. "What's the one thing about rail that someone new to it gets wrong in the first 90 days?" *Why it lands:* it shows you know you are new, and it is a question about the work, not about you.

## Sources

**Provided documents:** your message, including the recruiter's brief as you quoted it. No JD. No market report content (not in my working directory). No links read.

**Searches sent (both refused by the host):**
- "Kelverton Rail scheduling software train operators": refused
- "Kelverton Rail Senior Partnerships Manager": refused

**Research tier:** L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | skipped | Section 10 is dropped because no values-style round is in the brief, so the inputs fix that output. |
| 2. `Kelverton Rail interview process Senior Partnerships Manager` | unavailable | Both calls refused. Would have set the loop structure; the panel and its format are in the brief, so weights follow the brief. |
| 3. `Kelverton Rail strategy and recent news` | unavailable | Query refused. Would have moved B5 and the reverse questions. |
| 4. `Deepa VP Partnerships Kelverton Rail` and `Ross Commercial Director Kelverton Rail` | unavailable | No call sent: the host refused search permission on the first two calls, so no further calls were sent. Would have built the interviewer read and per-member persona weights. |
| 5. Representative JD for the role | unavailable | No call sent, for the same reason as target 4. Would have supplied requirement rows in place of the recruiter's words. |

## Upgrade menu

- Paste the JD → the recruiter's-words rows become JD-grounded rows, and JD-tagged questions are added.
- Paste the market report's shortlist or headline segments → B5 and the section 5 divergence are written against the report, rather than recited from it.
- Deepa's and Ross's public profiles, or any published talks → an interviewer read, per-member persona weights, and a reverse question tied to each person's own path.
- The recruiter's note on the POV format (can the panel interrupt, and is there a time cue) → the timing triage and the B1 delivery.
- Kelverton's published values, if they exist → a values cheat sheet, if the panel uses values framing.
