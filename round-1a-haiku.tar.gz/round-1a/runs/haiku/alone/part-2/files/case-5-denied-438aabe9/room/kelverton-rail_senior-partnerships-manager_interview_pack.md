# Interview prep pack: Senior Partnerships Manager, Kelverton Rail, second round

Round: panel, 60 minutes, Tuesday. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: spoken POV on operator partnerships over 18 months, no slides. Remaining 45 minutes: Q&A, with Ross pushing on commercials.

Built without a job description and without web research (see Sources). Requirements come from the recruiter's email as quoted in your message.

## How to use this pack and the type key

Personas are how a question is asked. Types are what it scores.

- **EXP**: what you actually did. Attribution and honesty.
- **JD**: can you do the listed job, including its gaps.
- **CASE**: a live problem, structured out loud.
- **CO**: company and strategy depth. Not covered here, because no research ran (see Sources).
- **VAL**: published values. Not built, because no values-style round was detected.

Guidance is scaffolding, not a script. Say it in your own words. Each guidance cell is written to be spoken in 90 to 120 seconds.

## Prep triage

Four hours in total. In order:

1. **About 90 minutes: build and speak the POV.** Write three bullets, then talk it through aloud three times against a 12-minute timer. Covered by the POV build section and A1 to A3.
2. **About 60 minutes: rehearse B1 and C1 to D1.** These are the three places you are most likely to be pressed. B1 is the highest-ROI prep in this pack. Rehearse its two follow-ups out loud.
3. **About 45 minutes: A4, A5, B2, C3.** The operator-knowledge and channel-model questions Deepa is most likely to ask.
4. **About 30 minutes: the commercial questions, C4, C5, D2, D3.** Prepare your 90-day ramp plan for a quota-less commercial role. This is the plan you will say, not a past you will claim.
5. **About 15 minutes: the reverse questions.** Pick three and say them aloud.

Everything else is insurance.

## Fit snapshot

No job description was supplied, so every row below is drawn from the recruiter's quoted words, your message, or is marked generic. There are no gate rows: nothing in the material establishes a location, office-days or right-to-work condition either way. The question at the end of this pack asks about that.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter's email, quoted in your message) | "so I know the operator world from the other side" (your message); "bus and light rail network planning" (your message) | medium | [grounded] | transferability | Your material shows operator-side knowledge from bus and light rail planning, not from rail-tech partnerships. Say it in those words: "I know the operator world from the other side, from bus and light rail network planning." Answer slot: if you saw a decision about a planning supplier or a partner made from inside an operator, say what and how; if you did not, say so plainly, and say how you would test the POV with an operator. |
| F2 | "land on what it means for the operators themselves" (recruiter's email, quoted in your message) | "so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | The quote already reaches operator-side thinking. Bridge only rewords it: "I know the operator world from the other side." Do not add an operator outcome you have seen, because the quote does not carry one. |
| F3 | "Ross will push on commercials" (recruiter's email, quoted in your message) | "never carried a direct quota, only influenced revenue" (your message); "roughly £4M of influenced revenue" (your message) | medium | [grounded] | capability | You stated the absence: "I haven't carried a direct quota." Say that first. The influenced-revenue figure stays at its own scope: "roughly £4M of influenced revenue." Closure is a plan, said as a plan: the 90-day ramp in C5 and D1. |
| F4 | Running a partner channel at scale (role-family requirement, no source quote) | "took it from 6 partners to 40" (your message); "running the ISV channel" (your message) | medium | [grounded] | none | The quote already reaches channel scale. Say the numbers in their own terms: "I took it from 6 partners to 40." Expect a probe on the 6 to 40 figure; see C2. |
| F5 | Senior partnerships tenure (role-family requirement, no source quote) | "9 years in partnerships" (your message) | medium | [grounded] | none | The quote already reaches seniority. Say the figure in those words. |

Rules these rows follow: the evidence column holds only your sentences, verbatim. Gap types come from the evidence cells, not from how the rows read. F3 is a capability gap because you stated the absence yourself, so the acknowledgment is yours to give.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| POV on operator partnerships over 18 months | POV build; A1, A2, A3 |
| What it means for operators themselves | POV build (the close); A3, A4 |
| Commercials (Ross) | C1, C2, C4, C5, D1, D2, D3 |
| Partner channel scale | A5, B1, C3, E1 |
| Rail sales experience | B1, A4 (the gap is stated, not bridged) |
| Anything else in a JD | None: no JD supplied. Upgrade menu. |

## Graded deliverable: the 15-minute POV

Pre-declared by the recruiter: a short spoken POV, 15 minutes, no slides. Close on what it means for the operators.

**Facts you can build on.** F1 and F2 (operator-side knowledge, quoted). F4 (channel scale, quoted). Nothing else about your past goes in the POV. Do not add an operator you have spoken to, a rail figure, or any outcome you have seen.

**Theses.** Three options. Each carries a concession. You pick one or two.

- **T1 [generic]: sell operator partnerships on recovered timetable performance, not on partner count.** Concession: I have not seen operator performance data. If operators buy mainly on price or on contract timing, this thesis changes.
- **T2 [generic]: the planner, not only the director, is the user to win.** Concession: this could be over-general for a company that serves several kinds of buyer. I would check it against your market report's buyer map before using it.
- **T3 [generic]: partners should carry delivery risk on outcome-linked terms, but only after a pilot proves the metric.** Concession: I do not yet know what risk-sharing ceiling a partner would accept.

**Differentiation.** The likely consensus answer is to expand the partner ecosystem. The divergence is a smaller number of deeper operator programmes. Say the consensus once, briefly, then depart from it and give your reason. Do not recite your market report back to its authors.

**Anti-pick [generic].** Do not make a bigger partner count the headline. Your most-quoted number, 6 to 40, is an argument for breadth, and operators are likely a small number of large buyers. Verify that against your report before you say it.

**Requested close.** "What it means for the operators themselves": on one operator's typical day, fewer disruption calls, a clearer recovery plan, and a named Kelverton contact. These are outcomes you are proposing, not outcomes you have seen. Say them as a proposal.

## Prohibited claims

Built locally from the fit snapshot. These are not to be coached, asserted, softened or implied in any answer, slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| "I sold into rail" or "I carried a quota" | Negative you stated (your message) | "I haven't sold into rail specifically, and I haven't carried a direct quota." Plain acknowledgment, no slot. |
| "I built the ISV channel" or "I owned the partner strategy" | Inflated form of "running the ISV channel" (your message) | "Running the ISV channel," at its own scope. Pack's observation, not your words: your material says running, not setting strategy. |
| "£4M of revenue I closed" | Inflated form of "roughly £4M of influenced revenue" (your message) | "Roughly £4M of influenced revenue." Pack's observation: your material says influenced, not closed. |
| "I know rail operations" or "I ran operator networks" | Inflated form of "bus and light rail network planning" (your message) | The quote at its own scope: bus and light rail network planning. |
| "We grew it from 6 to 40 on my own" | Inflated form of "took it from 6 partners to 40" (your message) | "I took it from 6 partners to 40." No "on my own", no team credit removed. |

## Persona weights

Panel: Deepa and Ross. Each member's top personas are blended below. No interviewer profile was researched, so these weights come from role and round priors.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Deepa | Live problems on the operator roadmap; the POV challenged | High. Hiring-manager priors: they are buying capability and checking the operator plan | Clarify, then structure, then state the one assumption you would test first |
| Skeptic | Deepa | "Why you? Why operators? Why now?" | High. Rail sales and quota gaps are visible in your message | Rehearse B1 until it is boring. Hold, then concede the real gap, then give the ramp plan |
| Data-Driven Prober | Ross | "How was the £4M counted?" "Which partners produced it?" | High. Commercial Director plus a stated influenced-revenue figure | Name the weakest assumption you know before he or she asks; say plainly when you do not know |
| Pressure | Ross | Interruptions; "why would we give you commercial ownership?" | Medium. Recruiter said Ross will push on commercials | Pause, restate, hold two follow-ups, concede specifically |
| Conversational | Panel opener | "Walk us through the journey" | Low. A casual opener is still scored | Ninety-second arc: operator side, partner side, the real reason for rail |
| Values / Behavioral | None | None | Not detected: no values-style round named | Not built |
| Peer Evaluator | None | None | Not applicable at this level | Not built |

## Question banks

Provenance is the candidate's own quoted sentences the guidance rests on. Each question's guidance is the cell the drill scores against.

### A. Deepa, Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Give me the 18-month plan for our operator partnerships. What would you do first?" | CASE | [generic] | Clarify first: which operators, which contract cycle, what they measure. Then the first 90 days: learn before committing budget. Name one thing you would not do yet. No past claim is made. | The POV's Q&A form. Generic because it is a pattern for the problem, not a fact about your history. |
| A2 | "Which of your three bets would you drop first if operators told us they were not priorities?" | CASE | [generic] | Name the bet you would test with a single operator, and the signal that would kill it. Say which one you would drop and why, in one sentence. | Tests whether the POV is a plan or a list. Generic because it does not presuppose your past. |
| A3 | "Which operator segment would you not bother with?" | CASE | [generic] | Name an anti-pick and the reason. Concede the cost: the segment you drop may be the one that funds the rest. | The anti-pick from the POV build. Tests judgment, not knowledge of rail. |
| A4 | "Your background is partner-side in payments and planning-side in transport. What do you know about how a rail operator actually buys?" | EXP | [grounded] "so I know the operator world from the other side" (your message); plain acknowledgment "Never sold into rail specifically" (your message) | Say what you saw from the operator side in bus and light rail planning, in those words: who made decisions and what they measured. Then say how you would learn rail procurement: operators, contract cycles, the people who sign. Answer slot: if you saw a purchasing decision from inside an operator, say where and what; if you did not, say so plainly. | F1 is the evidence for operator-side knowledge. Its limit is stated, not argued. |
| A5 | "How would you decide whether a partner should be a reseller, an integrator or a referral partner for us?" | JD | [grounded] "running the ISV channel" (your message) | A decision framework first: what the partner contributes to the deal, who owns the customer, how the margin moves. Then the channel you ran: "I was running the ISV channel." Answer slot: if the ISV channel used one of these models, say which and what its economics were; if it did not fit one, say what it was. | JD content with a CASE shape. The channel is the only experience this question can touch. |

### B. Deepa, Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never sold into rail and never carried a quota. Why should we believe you can own our operator partnerships?" | JD | Plain acknowledgment "Never sold into rail specifically" and "never carried a direct quota, only influenced revenue" (your message); "took it from 6 partners to 40" (your message) | **Highest-ROI prep in this pack.** Hold: "I haven't sold into rail, and I haven't carried a quota. What I have done is take a partner channel from 6 partners to 40, and I know the operator side from planning." Hold through two follow-ups by returning to the channel and the operator knowledge. Follow-up 1 will be "why would an operator take a call from you?" Answer with the operator-side knowledge in your own words. Follow-up 2 will be "name one deal you would have lost." Concede the real gap in one specific sentence and give the 90-day ramp in C5. Never claim a rail deal. | The most likely objection, aimed at your two stated absences. A rehearsed non-defensive answer is worth more than any new claim. |
| B2 | "Influenced revenue is not closed revenue. How much of the £4M did you close?" | EXP | "roughly £4M of influenced revenue" and "never carried a direct quota, only influenced revenue" (your message) | Say the scope: influenced, not closed. Do not claim a close you did not make. Answer slot: if you know how many of those influenced deals closed on your involvement, say the number; if you do not, say so plainly. | A probe on the same figure as C1, from the other side of the table. |
| B3 | "What is the one assumption in your POV you would be most worried is wrong?" | CASE | [generic] | Name one assumption in your own words, and what you would learn first to test it. | Shows you know where your plan is weak before they find it. |

### C. Ross, Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M influenced number was counted." | EXP | "roughly £4M of influenced revenue" (your message) | Weakest-assumption move: name, in your own words, the attribution assumption you would defend least. Answer slot: if you know the attribution rule (the touch, the registration, the time window), say it; if you do not know how it was counted, say so plainly and say what you would check. | The defend-the-number question. No attribution method is supplied by this pack. |
| C2 | "Of the 40 partners, how many produced the revenue?" | EXP | "took it from 6 partners to 40" (your message) | Answer slot: if you have the concentration, say it; if you do not, say you do not know the split and what you would check first. | A concentration probe on the channel figure. |
| C3 | "Which of your 40 partners would you use as the template for an operator, and why?" | JD | "took it from 6 partners to 40" (your message) | Be honest that partner breadth is not the operator lens. Name the one partner model you would carry, in your own words, and what would have to be different for an operator. | Tests whether you know your most-quoted number is the wrong lens. |
| C4 | "Show me the unit economics of one operator deal over three years." | CASE | [generic] | Outline the structure, not the numbers: contract value, implementation cost, support cost, partner share, renewal. Say which two you would ask for first. | Commercial structure without a claim about any deal. |
| C5 | "What partner margin would you need to stay interested in an operator deal?" | CASE | [generic] | Say the margin test in terms of your own pricing logic and what would make you walk away. Do not quote a figure you do not have. | A commercial floor question. Generic because it presupposes nothing about your past. |

### D. Ross, Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we give commercial ownership to someone who has never carried a quota?" | JD | "never carried a direct quota, only influenced revenue" (your message) | Pause before answering. Restate the question. Hold: "I haven't carried a quota. What I would bring is influence over the partner side, and a plan to take ownership of the commercial side in 90 days." Hold through two follow-ups. Concede specifically: the quota gap is real and the ramp is the answer. | Pressure on your stated absence. The hold is the rehearsal. |
| D2 | "Operators will say our price is too high and walk. What do you do in the room?" | CASE | [generic] | Hold the value case. Concede the part you do not know: their renewal criteria. Ask what they would need to see to stay. | A live negotiation problem. No past claim. |
| D3 | "You are going to say operators want outcomes. Who pays when the outcome misses?" | CASE | [generic] | Name who carries the risk and what ceiling you would test. Concede that you do not know the ceiling until a pilot runs. | Pressure on the outcome-based thesis T3. |

### E. Conversational (2, panel opener)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | JD | "9 years in partnerships" and "5 years in transport consulting" (your message) | Ninety seconds: the operator side from transport planning, then the partner side from nine years in partnerships, including the channel from 6 partners to 40. Give the real reason you want rail in your own words; the material does not show it, so say it yourself. | The casual opener is still scored. The arc is the same arc as the POV's opening. |
| E2 | "What would you want from us in the first 90 days?" | CASE | [generic] | Be specific: named access to operator contacts, a pricing authority, and a first operator to learn from. | A reciprocity question at the panel's own level. |

## Reverse questions

Each has a reason it lands. Pick three.

1. "What did the last operator decision turn on: price, a reliability measure, or a contract date?" Lands because it asks for the operator's own decision logic, which is the thing your POV is about.
2. "How is partner-sourced revenue credited against quota today?" Lands because it shows you care about attribution, which is exactly what Ross will probe.
3. "Which operator relationship would you most want a new partnerships lead to protect?" Lands because it asks for their priority, not a generic one.
4. "What did your last partnerships hire get wrong in the first six months?" Lands with Deepa, because it asks for the lesson behind the role rather than the job description.
5. "What would have to be true in 18 months for you to say this hire worked?" Lands because it lets you hear the measure they will judge you on.
6. "Where does the commercial plan not yet show what partnerships needs to deliver?" Lands with Ross, because it asks about the gap between their plan and this role.

## Sources

**Provided documents.** Your message: the recruiter's email as quoted, and your background. The market report your strategy team circulated was not in this conversation, so nothing in this pack draws on it. Paste its operator-side points and the pack's POV theses will be grounded in it instead of generic.

**Research tier.** Research tier: L1, searches 3 of 6, fetches 0 of 2. Three web searches were sent and each was refused: the search permission was not granted. No web research ran, so no result was used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Query "Kelverton Rail company values" refused. Would have moved a values cheat sheet, but no values-style round was detected, so none is built. |
| 2. Interview process, partnerships role | unavailable | Query "Kelverton Rail scheduling software train operating companies partnerships" refused. This was the nearest query to the interview-process target. Would have moved persona weights and the loop structure. |
| 3. Strategy and recent news | unavailable | Query "Kelverton Rail strategy news 2026" refused. Would have moved the CO questions and a grounding brief. |
| 4. Interviewer names, Deepa and Ross | unavailable | No search sent. The names and titles are in hand, so a query could be formed; the search permission was not granted. Would have moved the interviewer read and a tailored reverse question. |
| 5. Representative JD | unavailable | No search sent. Would have moved the JD-tagged questions and gave the fit snapshot its requirements. |

## Upgrade menu

- A job description → each requirement row moves from generic or quoted-from-email to grounded, and any gate (location, office days, right to work) gets its own row.
- The market report's operator-side points, pasted → POV theses grounded in your company's framing instead of generic; the differentiation paragraph is rebuilt from it.
- Public profile information for Deepa and Ross (roles and published talks only) → interviewer read, sharper persona weights, and a reverse question tied to their own career path.
- Permission to run web search → values, interview-process and strategy research (targets 1 to 3), with the accounting re-run.
- Deep research (offered once): six more searches and two more fetches for a strategy brief, interviewer talks, and loop reports. Costs the same time as the L1 run plus the strategy reading.
- The recruiter's email, if it says anything about written material or timing → confirms there is no graded deliverable beyond the spoken POV.
