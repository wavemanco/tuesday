# Interview prep pack: Product Operations Manager, Stripe

**Round:** Final round. Interviewer and relationship not yet known.
**Built on:** no job description, no CV, no interviewer name, no recruiter note. Persona weights are blended priors and every requirement is a generic product-operations requirement. Once you share those inputs, this pack is regenerated.

## 2. How to use this pack

- **Personas** describe how a question is asked (the register and the pressure). **Types** describe what the question scores.
- Type key:
  - **VAL**: behavioral / values alignment. Not used in this pack, because Stripe's published values could not be retrieved (see Sources).
  - **EXP**: work-experience deep-dive. Tests whether what you did survives scrutiny.
  - **JD**: role-driven. Tests whether you can do the listed job, gaps included.
  - **CO**: company and strategy knowledge. Tests homework.
  - **CASE**: live problem. Tests structure and reasoning.
- **Guidance is scaffolding, not a script.** Rehearse the structure and the honest branch. Do not memorize sentences.

## 4. Fit snapshot (worksheet variant)

No background is on file, so every evidence cell reads "none given". The requirements below are generic product-operations requirements, not quotes from a posting. Each row's bridge says what strong evidence looks like. Where no source raises a requirement, the bridge ends in a selection scaffold with its honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running a planning or decision cadence across several teams (role family) | none given | none | [generic] | discovery | Strong evidence is a named process you designed or changed, what it replaced, and what changed after. Selection scaffold: pick a time you changed how a group planned or made decisions. If you have not, say so and say what you would look at first. |
| F2 | Coordinating launches and rollouts across product, engineering and go-to-market (role family) | none given | none | [generic] | discovery | Strong evidence is a launch you coordinated end to end, with its readiness checks. Selection scaffold: pick a launch or rollout you were close to, and say what you personally checked. If none, say what a readiness check would cover. |
| F3 | Defining metrics and dashboards that people use to decide (role family) | none given | none | [generic] | discovery | Strong evidence is a metric you defined, its definition, and who used it to decide. Selection scaffold: pick a number you were responsible for, and say how it was counted. If none, say how you would define one. |
| F4 | Making prioritization trade-offs between competing stakeholders (role family) | none given | none | [generic] | discovery | Strong evidence is a trade-off you made, what you gave up, and who was unhappy. Selection scaffold: pick a decision where two teams wanted different things. Say what you decided and who decided it. |
| F5 | Written and verbal reporting to senior leaders (role family) | none given | none | [generic] | discovery | Strong evidence is an update or memo you wrote for leadership, and what it changed. Selection scaffold: pick one update and say what decision it informed. |
| F6 | Working knowledge of the company's products and business (role family) | none given | none | [generic] | discovery | Strong evidence is what you have read or used yourself. Say that, in your own words. If you have not used the products, say so and say how you would learn them in the first month. |

## 8. Persona table

Relationship is not known. The priors below are a blended final-round starting point (hiring manager plus peer), and the weights are an assumption. They move once the relationship is confirmed.

| Persona | How it shows up in this loop | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live product-ops problems: a slipped launch, a contested roadmap item, a metric that moved | High. A product-ops hire is being judged on how they structure ambiguous process problems. | Clarify, then structure, then name the metric and the risk. Think aloud. | 4 questions |
| Skeptic | Probes the gap between a generalist background and this role's scope | High. The most predictable objection for this role is scope and depth, so expect it. | Rehearse the single most predictable objection until it is plain. Name the gap and a concrete ramp plan. | 4 questions |
| Peer Evaluator | Seams with product, engineering and go-to-market; "what would you need from me" | Medium. Peers in a final round price what the hire costs their team. | Lead with what you bring to their team. Propose seam principles instead of pretending to know the seam. | 3 questions |
| Data-Driven Prober | Asks how a metric was defined, its denominator, and its weakest assumption | Medium. Product ops is metric-heavy, so the probe is likely. | Name the weakest assumption before they do. Say plainly what you do not know. | 3 questions |
| Pressure / Stress | Time-boxed, interrupting, challenges your motive | Low to medium. Mostly a composure check. | Pause, restate the question, hold a position through two follow-ups before conceding. | 2 questions |
| Conversational / Rapport | Friendly openers that are still scored | Medium. Casual openers are scored for communication and interest. | Keep a 90-second arc ready. Treat casual questions about the role as scored. | 2 questions |

## 9. Question banks

Provenance comes first in each row. Where a question makes no claim about your past, the provenance is the [generic] label alone.

### A. Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product launch slipped two weeks last quarter, and nobody knew until the day before. How would you find out why, and what would you change?" | CASE | [generic] | Clarify what counts as a slip and who needed to know. Map the handoffs from intake to plan to build to launch readiness. Find where the signal went missing. Propose one fix that is a cadence or an artifact, and one metric that would show whether it worked. | The core product-ops diagnostic. It makes no claim about your history. |
| A2 | "Engineering wants to ship a feature that sales says is urgent, and the roadmap has no room. Walk me through how you would decide." | CASE | [generic] | Ask who owns the decision. Set the criteria: revenue at stake, segments affected, cost of delay, and what gets displaced. Write the trade-off down, and say how you would tell both sides. | Tests trade-off reasoning under stakeholder pressure. |
| A3 | "How would you set up an operating cadence for a product area with eight teams and no shared planning process?" | JD | [generic] | Start with the decisions the cadence must support, then the minimum set of inputs, then the forum. Name what you would not standardize yet. | Scores the core F1 requirement as a design problem. |
| A4 | "If you joined and the first thing to fix was metrics people argue about in reviews, what would you do in your first 30 days?" | CASE | [generic] | Listen first. Inventory the definitions in use. Pick one metric to settle, get sign-off from its owners, and write the definition down. | Tests sequencing and humility on day one. |

### B. Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Product operations is mostly process work. What in your background shows you can do this at our scale, rather than run someone else's template?" | JD | [generic] | Highest-ROI rehearsal in this pack. Answer slot: name one process you designed or changed, what it replaced, and what happened after. If your experience is adjacent, say which part is adjacent and which part you have not done yet. | The most predictable objection to a generalist profile for this role. It is inferred from the role, not from evidence, so it is rehearsed until the honest answer is ready. |
| B2 | "Why product operations, and why are you looking to leave where you are?" | EXP | [generic] | Answer slot: give your motivation in your own words. Do not criticize your current employer. Name one thing about this role that pulls you, and say why. | The motivation-consistency probe every final round includes. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap. Then give a concrete ramp plan: which teams and metrics you would learn first, and by when. | Calibrated candor. Bluffing a gap is what the skeptic is listening for. |
| B4 | "Tell me about a process you proposed that failed. What happened?" | EXP | [generic] | Answer slot: if you have one, say what you proposed, why it failed, and what you changed afterwards. If you have none, say so and describe how you would learn from a failed process. | Tests honest self-assessment. A rehearsed success story will not survive this. |

### C. Peer Evaluator (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Product ops sits between product, engineering and go-to-market. Where is the seam with my team, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam (who decides what, how disagreements are escalated) rather than claiming to know their org. Say how you would settle a disagreement with an equal. | Peer probe of turf awareness. |
| C2 | "How do you handle credit when a process change spans three teams?" | EXP | [generic] | Name the teams and what each contributed. Use "we" for the group and "I" only for what you personally did. Answer slot: if you have a case, give it. If not, describe the rule you would use. | Peer probe on credit-sharing. |
| C3 | "What would you need from me in the first month?" | JD | [generic] | Give one specific need and one thing you would bring to their team. Reciprocity first. | Peers judge whether the hire adds to their load or reduces it. |

### D. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick one metric you would put on a product-ops dashboard. How would you define it, and what would it hide?" | CASE | [generic] | State the definition, its denominator, and the segment it could mislead. Name the weakest assumption before the prober does. | Tests whether you can see the limits of your own metric. |
| D2 | "How would you know a process change actually worked?" | JD | [generic] | Name a baseline, a comparison group or time window, and one guardrail metric that would show a harmful side effect. | Tests experimental thinking applied to process change. |
| D3 | "What is a number you would not trust in a product review, and why?" | EXP | [generic] | Name a real example of a metric with a known blind spot. If you cannot name one, say what you would check before trusting any number. | Tests honest judgment about metrics. Open prompt, so it presupposes nothing about your history. |

### E. Pressure / Stress (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over an internal candidate?" | JD | [generic] | Pause. Restate the question. Answer with what you would bring that an internal candidate might not. If you do not know the internal field, do not guess about it. | Tests composure and concise framing. |
| E2 | "That sounded like a template. What did you actually do yourself?" | EXP | [generic] | Hold your position. Restate the specific thing you did, in your own words. Concede only what is true, and only after two follow-ups. | Tests whether you fold or stand on what you actually did. |

### F. Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | Build a 90-second arc with a through-line, two or three stops, and one link to this role. Use only what you can verify. Do not embellish. | Casual openers are scored for economy and interest. |
| F2 | "What are you reading or following on product operations these days?" | CO | [generic] | Name only what you have actually read. If you have not read widely, say so, and name one thing you plan to read this week. | Tests homework, asked casually. |

## 11. Reverse questions

Each question has a "why it lands" line.

1. "What does a strong first 90 days look like in this role, and what would have to be true by day 90?" Why it lands: it shows you are planning for the job, and the answer tells you what they are measuring.
2. "When product and go-to-market disagree about a launch, where does the decision get made today?" Why it lands: it surfaces how decisions are actually made, which is the core of this role.
3. "Which process here do people complain about most, and what has already been tried?" Why it lands: it shows you expect real friction and want the history, not a clean story.
4. "How is success in this role measured, and who sets that measure?" Why it lands: it tests whether the role has an owner, which decides how much authority you will have.
5. "What would you need from someone in this role that you have not gotten yet?" Why it lands: it is a reciprocity question. It works well with a peer and is still useful with a hiring manager.

## 13. Prohibited claims

Built locally, because no background is on file. These are the claims a candidate reaches for under pressure in this role. None is coached as a statement. Each has an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ownership of a product-ops function or a company-wide process | Pressure claim for F1 and F4. No evidence on file. | Say what you did yourself, in your own words. Until you share your background, use the selection scaffold. |
| Any specific figure or percentage improvement | Pressure claim for F3. No evidence on file. | Describe how a number was counted, or say that you would define one. Figures come only from your own sentences. |
| Familiarity with Stripe's products, customers or internal processes | Generic. The pack has no source for it. | Say what you have read or used yourself. If the answer is nothing, say so and say how you would learn. |

## 14. Sources

- **Provided documents:** none. The pack used no job description, CV, interviewer profile, recruiter note or strategy brief.
- **Searches and fetches sent:** three web searches were sent, all refused by the host (permission not granted). No fetches were sent.
  - "Stripe company values operating principles": refused.
  - "Stripe interview process final round loop product operations": refused.
  - "Stripe strategy news 2026": refused.

**Research tier:** L1 (default), 0 of 6 searches completed (3 refused by the host), 0 of 2 fetches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have produced the values cheat sheet. Section dropped, since no published values are in hand. Queries refused. |
| 2. `Stripe interview process product operations` | unavailable | Would have set the loop structure and persona weights. Weights are priors only. Query refused. |
| 3. `Stripe strategy` / recent news | unavailable | Would have fed the company-strategy bank. No CO bank beyond F2. Query refused. |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative `Product Operations Manager` JD | unavailable | Would have grounded the fit snapshot requirements. Requirements are [generic]. Query not sent. |

Everything about Stripe itself in this pack is unverified. Do not repeat any company claim from this pack without checking it on Stripe's own site.

## Upgrade menu

- A job description, pasted → the six `[generic]` fit snapshot rows become grounded, quoted requirements, and the banks are rewritten against them.
- Your CV or a short background, pasted → the evidence cells are filled with your own sentences, the worksheet variant becomes a normal snapshot, and story-mapped answers replace the selection scaffolds.
- The round type and who you are meeting → persona weights are recomputed, and the reverse questions are tailored.
- The recruiter's note on focus areas or any take-home or presentation → coverage is matched to what the final will test, and a graded-deliverable section is added if one is named.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Research, once search is permitted in this session → the Stripe values cheat sheet, the loop structure and a current strategy brief become possible. This pack lacks all three.
- A `tuesday-dossier.md` file → would carry the gaps this prep exposes into later sessions.
