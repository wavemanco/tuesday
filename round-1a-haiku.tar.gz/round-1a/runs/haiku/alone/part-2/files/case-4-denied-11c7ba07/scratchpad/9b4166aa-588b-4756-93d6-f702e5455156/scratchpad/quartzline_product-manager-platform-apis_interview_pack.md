# Quartzline: Product Manager, Platform APIs

Hiring-manager conversation, 45 minutes, Thursday. Interviewer not named; relationship taken as hiring manager from your note.

Built from: `tuesday-dossier.md` (job-underwriter, version 1.1, dated 2026-08-14). No CV or full JD text was supplied. Web research was refused (permission not granted), so company values, loop structure and strategy are not established here.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** VAL = behavioral/values (none detected, see Sources); EXP = work-experience deep-dive; JD = role-driven; CO = company strategy (none, research refused); CASE = live problem.
- Guidance is scaffolding, not a script. Answer slots are instructions for the interview: answer from your own experience, or say plainly that the practice was not yours.
- Confidence and gap type come from the underwriter's dossier. Provenance quotes are your sentences from the dossier's verified evidence, or the dossier's own fields.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | low | [grounded] | transferability | Adjacent work only. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, covering scoping, requirements, architecture, UAT and go-live. I have not held a product manager title." The second sentence is a plain acknowledgment sourced to the dossier's prohibited_claims field. The material shows integration work, not the PM job. |
| F2 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence 1) | medium | [grounded] | transferability | The quote is on the consuming side: integrations of the vendor's APIs, not a platform you shipped. Say the integration sentence at its own scope and no wider. Answer slot: if any part of an API or platform release was yours to shape, say which and how; if none was, say so plainly and say what the integrations showed you about the platform. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence 2) | high | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I wrote the internal integration playbook my team uses." Do not add docs or schema detail the material does not state. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence 3) | medium | [grounded] | presentation | Reaches a client-to-product channel, not management of engineering or sales. Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." The dossier flags limited inspectable proof and expects a probe. |
| F5 | "Agile delivery experience" (dossier role_profile R5) | none given | low | [grounded] | discovery | Nothing in the material speaks to Agile delivery. Answer slot, using the requirement's own wording as the probe: if you have worked in Agile delivery, say where and what your part was; if you have not worked that way, say so plainly and say what you would confirm about how this team defines it. |
| F6 | Owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this as acknowledge_gap, and it is on its prohibited_claims list. Words: "I have not owned a product roadmap, and I have not set prioritization for an engineering squad." Then a ramp plan, stated as a plan and never as past experience. No bridge. |

**Gap types, briefly.** F1 and F2 are transferability: adjacent work that does not reach the requirement. F3 and F4 are presentation: the quote reaches the requirement in other terms. F5 is discovery: the evidence may exist and the material does not show it. F6 is capability: the dossier records the absence.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims item | "I have not held a product manager title." Plain acknowledgment, no slot. |
| Having owned a product roadmap | Dossier prohibited_claims item; uncertain_or_weak_areas acknowledge_gap | "I have not owned a product roadmap." Plain acknowledgment, no slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims item | "I have not set prioritization for an engineering squad." Plain acknowledgment, no slot. |
| Ran the roadmap (or owned the roadmap through quarterly sessions) | Inflated form of F4 | The F4 quote at its own scope. The pack's observation, not words for you: the material says roadmap-input sessions, not roadmap ownership. |
| Shipped the API platform | Inflated form of F2 | The F2 quote at its own scope. The pack's observation: the material shows integrations of the vendor's APIs, not a platform you shipped. |

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Cross-examines the title and roadmap gap; "why you, instead of someone with the job" | Highest. A hiring manager is buying capability and derisking gaps, and the dossier names the objection. | Rehearse the single predictable objection until it is calm. Bridge only from quoted work, name the limit, and give a ramp plan. |
| Case / Strategist | Live roadmap problems from the posting: partner discovery, adoption, two squads | Highest. The posting's responsibilities are live problems. | Clarify before structuring. Name the squad-authority question and the adoption baseline out loud. |
| Pressure | Time-boxed challenge on the 30+ figure and on "why you" | Medium. Depth verification is likely from a hiring manager. | Hold the quoted work through two follow-ups, then concede the title and roadmap cleanly. |
| Data-Driven Prober | Asks how the 30+ count was made, what the playbook covers | Medium. The headline figure and the playbook invite scrutiny. | Say what you can and cannot say about how each figure was counted. |
| Conversational | The opening "walk me through" and the casual "what are you playing with" | Low to medium. It is scored casually. | A 90-second arc, and treat casual JD questions as scored. |

Weights rest on relationship priors only. No loop source was found, so these are not this company's documented process.

## Question banks

### A. Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; plain acknowledgment sourced to the dossier prohibited_claims items "Having held a product manager title or role" and "Having owned a product roadmap" | **Highest-ROI prep in this pack.** Hold the integration work at its own scope through two follow-ups, which is the whole case. Concede once, cleanly: "I haven't held the title or owned a roadmap." Then the ramp, as a plan: what you would learn first about who decides which roadmap calls. Do not add anything to narrow the gap. | The underwriter named this objection, so the wording is theirs. It is aimed at F1 and F6, the thinnest part of the material, and it will come in some form. JD because it scores the title requirement. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities); plain acknowledgment sourced to the dossier prohibited_claims item "Having owned a product roadmap" | Concede roadmap ownership and squad prioritization in one plain sentence, as F6. Then name the nearest thing you have done: the client-side requirements work in F1. Do not claim the roadmap work. | F6 is the row this tests. The honest answer is a named gap and a ramp plan, not a rescue. |
| A3 | "Our posting asks for 3+ years of product management experience. How do you map to that?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say the integration work at its scope, then the title plainly: "I haven't held a product manager title." Hold the adjacency, and do not stretch it. | The requirement is R1, the must-have. The answer names the limit before it is asked for. |
| A4 | "Tell me about your experience with Agile delivery, if you have any." | JD | [grounded] "Agile delivery experience" (dossier role_profile R5) | Answer slot, the open prompt on the requirement's own wording. If you have worked in Agile delivery, say where and what your part was. If you have not worked that way, say so plainly, and say what you would confirm about how this team defines Agile delivery. | F5 is discovery: the dossier says clarify, so the question-shaped answer is the honest one. |
| A5 | "Pick the most platform-level API work you've been part of, if any. What was your part?" | JD | [grounded] "Shipped API or platform products" (dossier role_profile R2); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot. Name the integration work and say it is on the consuming side. If that is the closest you have, say so. If you have shipped a platform product, say which and what your part was. | R2 is a must-have, and the honest answer is a limit. The question carries its own "if any", so it does not presuppose a shipped product. |

### B. Case / Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you'd decide the roadmap for the partner API platform. What do you need to know first?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities) | Clarify before structuring. Ask who decides which roadmap calls (squad leads or you), what the current adoption baseline is, and which partners drive demand. Then objective, options, metrics, risks. Name the authority question aloud. | A live problem from the roadmap responsibility. The two unknowns, authority and baseline, make the clarify step the scored move. It presupposes nothing about you. |
| B2 | "Partner API adoption dropped 20% last quarter. Diagnose it." | CASE | [generic] | Clarify the metric definition and baseline first. Segment by partner size, integration stage and endpoint. State a hypothesis, then what would confirm or rule it out. Think aloud. | A generic diagnostic from the adoption responsibility. The 20% figure is invented for the exercise. |
| B3 | "Two engineering squads disagree on what ships next in the API release. How do you decide, and who decides?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Name the decision rights before answering. Say what you would bring to the squad leads, such as partner evidence and adoption data. Confirm where the call sits. Do not claim authority over squad priorities. | This is the squad-authority unknown, and the answer shows judgment without claiming authority. |
| B4 | "How would you run discovery with an integration partner who wants a feature that only one customer needs?" | CASE | [grounded] "Run discovery with integration partners" (dossier role_profile responsibilities); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify what the request is meant to solve. Separate the need from the proposed feature. Test with usage data if it exists. Say where you would escalate the trade-off. Your client-side requirements work is the nearest example; use only that, with its limit. | Tests the discovery responsibility, which is a likely live problem for this role. |
| B5 | "How would you define and track adoption for a partner API?" | CASE | [grounded] "Define and track adoption metrics" (dossier role_profile responsibilities) | Clarify what adoption means and what the current measure is. Define the adoption event, segment by partner, and name one leading and one lagging metric. Say what you would not measure. | The adoption baseline is an open unknown in the dossier. Reverse question R2 asks the same thing from the other side. |

### C. Pressure / Stress (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses" | Hold the integration work and the playbook, each at its own scope, through two follow-ups. Concede the title and the roadmap plainly. Do not fold on the integration case. | A pressure stem on the R1 gap: hold the quoted work, then concede the rest. |
| C2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, defend the number. Say how the 30+ was counted, what the count is sensitive to, the assumption you would defend least, and which of the stages were yours to set. If you do not know how it was counted, say so plainly. | The headline figure invites attribution probes. This is the pressure version of the defend-the-number slot. |
| C3 | "Walk me through those quarterly sessions: what went in, and where did it go?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what went in and where it went, in the quote's own terms. Answer slot: if you can name a change product made from it, say it; if you cannot trace one, say so plainly. Do not claim a result. | F4 is medium confidence and the dossier expects a probe. The question presupposes the sessions, which the quote carries, not an outcome. |

### D. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, defend the number. Say how the count was made in your own words. If it was a rough count, say so. Name the weakest assumption before they do. If you did not count them yourself, say so. | The counting question is the first one a prober asks of any headline number. |
| D2 | "What does the integration playbook cover?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Describe in your own words what you wrote. Do not add contents the material does not state. If they ask about API docs or schemas inside it and it does not cover them, say so. | F3 is presentation. The prober tests whether the claim has content behind it. |
| D3 | "Pick one of those integrations and walk me through it end to end. Which of the stages were yours to set?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot. Pick one integration and walk the stages the quote names. For the stages you set, say which and how you decided. If a stage was not yours to set, say so plainly and stay with what you ran. | The second branch allows that a stage was not yours. The question presupposes nothing the quote does not carry. |

### E. Conversational / Rapport (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order: the integration work, the playbook, the quarterly sessions. Then the gap in one sentence, then why this role. Never claim the title at any point. | An opening biography is scored casually, so the arc is rehearsed. |
| E2 | "What are you actually playing with in API docs and schemas these days?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier role_profile R3); [grounded] "Wrote the internal integration playbook her team uses" | Name what you have used, anchored on the playbook. Answer slot: if schemas were not part of that work, say so plainly. | R3 is an important requirement. A casual question about it is still scored. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| R1: 3+ years PM experience (must-have) | A1, A3, C1 |
| R1 sub-claim: roadmap ownership and prioritization | A1, A2, B1 |
| R2: Shipped API or platform products (must-have) | A5, D3 |
| R3: Technical fluency, API docs and schemas (important) | D2, E2 |
| R4: Stakeholder management (important) | B3, C3 |
| R5: Agile delivery experience (preferred) | A4 |
| Responsibility: roadmap for the partner platform | B1 |
| Responsibility: run discovery with partners | B4 |
| Responsibility: specs and delivery with two squads | B3 |
| Responsibility: define and track adoption metrics | B5 |
| Unknown: squad decision authority | B1, B3; reverse questions 1 and 5 |
| Unknown: current adoption baseline | B5; reverse question 2 |

Session total: 18 questions.

## Reverse questions

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it tests the decision-authority risk the posting names and no evidence shows.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the baseline is unknown, and the answer shows where the job starts.
3. **"What would make the first six months of this role a clear success?"** Why it lands: it surfaces the real scoring before you are hired.
4. **"What gap in the team led you to open this role?"** Why it lands: it tells you what the hiring manager is buying.
5. **"Which squad is this role closest to in its first quarter, and what do those leads expect from a PM?"** Why it lands: it shapes the squad-authority answer and shows you are thinking about delivery.

## Sources

- **Provided document:** `tuesday-dossier.md` (job-underwriter, version 1.1, generated 2026-08-14). Consumed sections: `handoff_to_mock_interview` (weak areas, objection, prohibited claims, risks and employer questions), `role_profile` (JD tier), and `verified_candidate_evidence` (CV tier). `decision` (conditional_go, no hard gates or red flags) was read as context only.
- **Dossier age:** dated 2026-08-14, about three months before today. Check that it still matches your evidence before you rely on its quotes.
- **Searches attempted:** three web searches, for Quartzline values, Quartzline's interview process, and Quartzline strategy or recent news. All three were refused by a permission prompt. They were not retried.

**Research tier: L1, searches 0 of 6 (3 refused), fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have moved the values cheat sheet. The section is dropped because no values round is detected. Query "Quartzline values operating principles" refused. |
| 2. Quartzline interview process | unavailable | Would have named the loop and so set persona weights. Weights are flat hiring-manager priors. Query "Quartzline interview process product manager platform APIs" refused. |
| 3. Quartzline strategy or recent news | unavailable | Would have produced CO questions. None are in the pack. Query "Quartzline strategy recent news" refused. |
| 4. Interviewer name | n/a | No name was given, so no query could be formed. |
| 5. Representative JD | skipped | The dossier's role_profile already fixes the requirements. |

**Loop and values:** no loop source was established, so the pack uses the generic archetype's fallback. The generic archetype does not detect a values round, so the values cheat sheet is dropped.

## Upgrade menu

- Quartzline's careers or values page, pasted → confirms the interview loop and any values round, which unlocks the values cheat sheet and loop-based persona weights.
- A recent strategy note or news pasted → CO and CASE questions tied to current strategy, which are missing now. Or a deeper research pass (L2: up to 6 more searches and 2 more fetches, several minutes), if you want it.
- Permission for web search → the three research targets above, in one pass.
- Your CV → the sentences behind the dossier's summaries, so the [grounded] rows rest on your own words.
- Full JD text → confirms the exact wording of R1 to R5 and adds mid-list items.
- The interviewer's name → an interviewer read and a reverse question tied to their career path.
- The recruiter's note on focus areas, or any take-home → a graded-deliverable section.
- An updated `tuesday-dossier.md`, since the one here is dated 2026-08-14.
