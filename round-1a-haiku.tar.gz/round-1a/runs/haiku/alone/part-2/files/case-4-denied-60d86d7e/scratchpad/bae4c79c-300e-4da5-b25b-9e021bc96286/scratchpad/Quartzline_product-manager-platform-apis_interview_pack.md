# Interview prep pack: Product Manager, Platform APIs at Quartzline

Interviewer: hiring manager (name not given). Round: 45-minute conversation, Thursday 2026-11-19. This is the first version of the pack; nothing has changed yet.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **EXP** work-experience deep-dive, **JD** role and JD-driven, **CASE** live problem, **CO** company knowledge, **VAL** values. This pack has no CO or VAL questions; see Sources.
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.
- Answer slots (marked "Answer slot") are instructions for the interview. Use whichever branch is true.

## Fit snapshot

Requirements come from your dossier's `role_profile`, quoted as the dossier gives them. Evidence is quoted from `verified_candidate_evidence` (V1 = first item, V2 = second, V3 = third) and is user-confirmed in the dossier.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row V3 | low | [grounded] | transferability | Your material shows integration leadership and roadmap input, not product-management time. Bridge at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs: scoping, requirements, architecture, UAT, go-live." Never add a PM title or years of PM work. Answer slot: if you held any decision over what the integrations shipped, say which and how you decided; if not, say so and stay with the integrations you led. |
| F2 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | low | [inferred] | transferability | Integrating a vendor's API from the client side is adjacent to shipping an API product, and the dossier does not show that you shipped one. Bridge at V1's scope only. Answer slot: if anything you built was integrated by an outside party, say what and your part in it; if nothing was, say so. Note: the dossier does not flag this requirement as weak, so this grade is this pack's derivation. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" — dossier row V2 | medium | [inferred] | transferability | The playbook is integration documentation, and that is the adjacent evidence. Schemas and API reference docs are not in the material. Bridge: "I wrote the internal integration playbook the team uses." Answer slot: if you wrote or reviewed API reference docs or schemas, say which; if not, say so and say how you would learn the schema tooling. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier row V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row V3 | high | [grounded] | presentation | The customer side is well evidenced (V1, V3). Engineering and sales are not in the material. Bridge only rewords V1 and V3; add no relationship or event. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Evidence may exist; your material does not show it. Answer slot: if your integration work ran in sprints or another agile cadence, say which and how; if it did not, say so and say what you would want to confirm about how this team defines agile delivery. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility; R1 sub-claim) | none given for roadmap ownership. Dossier prohibited_claims: "Having owned a product roadmap" | none | [grounded] | capability | The dossier records this as a capability gap. Plain acknowledgment, sourced to the dossier prohibited_claims item: "I haven't owned a product roadmap." Then a ramp plan, stated as a plan and never as a past. No bridge and no answer slot. |
| F7 | "Define and track adoption metrics" (dossier role_profile responsibility) | none given | none | [grounded] | discovery | Your material does not show any adoption measure. Answer slot: if you measured adoption of any integration, say what you counted and how; if you did not, say so and say what you would measure first. The dossier also records that no current baseline is stated. |
| F8 | "Run discovery with integration partners" (dossier role_profile responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | medium | [inferred] | transferability | Scoping and requirements with clients are adjacent to partner discovery. Clients are not partners in the discovery sense. Bridge at V1's scope only. |

Observations (this pack's analysis, not words for you): your material shows client-side integration work and roadmap input, not product-management time, roadmap ownership or prioritization authority. The dossier's own gap grades for F1, F5 and F6 are the underwriter's and are used as given.

## Prohibited claims

Claims this pack will not coach, with their basis and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced entry: dossier prohibited_claims, "Having held a product manager title or role" | Plain acknowledgment: "I haven't held the product manager title." Then V1 at its own scope. |
| Having owned a product roadmap | Sourced entry: dossier prohibited_claims, "Having owned a product roadmap" | Plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan, as a plan. |
| Having set prioritization for an engineering squad | Sourced entry: dossier prohibited_claims, "Having set prioritization for an engineering squad" | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Set prioritization for the integrations you led | Inflated form of F1 and V1 | V1 at its own scope: scoping, requirements, architecture, UAT, go-live. The limit is this pack's observation: the material shows scoping and requirements, not prioritization. |

## Persona table

Relationship prior: hiring manager, which the pack weights toward Case/Strategist and Skeptic. No loop source was read (see Sources), so the weights rest on the relationship prior, not on this company's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the R1 gap and the roadmap gap; "why you, why this role" | High: the hiring-manager prior, plus the dossier's named objection | Rehearse the single objection until it is boring. Concede the gap in one plain sentence, hold the bridge through two follow-ups, and ramp in plan form. | 5 |
| Case/Strategist | Live problems on the partner-API roadmap: adoption, partner requests, squad trade-offs | High: the hiring-manager prior, and the JD's responsibilities are a ready source for live problems | Clarify, then structure: objective, segments, metrics, risks. Ask for the baseline before proposing a target. | 4 |
| Data-Driven Prober | Asks how the 30+ count and any adoption figure were measured | Medium: V1 is high confidence but the count has no stated method; F7 has no measure | Give the count's method in your own words, or say there was none. Name the weakest assumption before the interviewer does. | 3 |
| Pressure / Stress | Time-boxed challenges to the integration-equals-product framing | Low-medium: a stress format on the same objection | Pause, restate the question, hold the scope, concede specifically. | 2 |
| Conversational / Rapport | Friendly opener: "walk me through the journey" | Low-medium: openers are scored too | A 90-second arc from V1, V2 and V3, with the role you want stated plainly. | 2 |
| Peer Evaluator | Squad seam: where the authority sits between you and the squad leads | Medium: the JD's two squads and the dossier's open authority question | Propose a seam principle before claiming any past disagreement. | 2 |

Depth follows weight: 5 / 4 / 3 / 2 / 2 / 2 questions. Total 18.

## Question banks

Interviewer read: dropped (no interviewer name given). Graded deliverables: none declared. Values cheat sheet: dropped (no values-style round detected, no loop source, no values page read).

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier likely_interviewer_objections; dossier prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap"; V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; V2 "Wrote the internal integration playbook her team uses" | The highest-ROI prep in this pack. The dossier named this objection. Beat 1, concede in one sentence: "I haven't held the product manager title, and I haven't owned a product roadmap." Beat 2, the closest evidence at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, covering scoping, requirements, architecture, UAT and go-live, and I wrote the integration playbook the team uses." Beat 3, the plan: "In the first months I'd settle decision rights with the squad leads before setting any priority." Hold beats 2 and 3 through two follow-ups. On a third, concede the specific gap: roadmap and prioritization authority. Never say you were the de facto PM. | Asked as the underwriter wrote it, because every negative in it has a dossier prohibited_claims source. F1 is the transferability gap, and F6 is the roadmap capability gap. Most follow-ups will come here. |
| A2 | "Which parts of this JD would you be weakest at on day one?" | JD | [grounded] dossier uncertain_or_weak_areas "Owning a roadmap and prioritization authority" (acknowledge_gap) and "Agile delivery inside a product org (R5)" (clarify) | Name the roadmap gap first, in the plain form F6 allows: "I haven't owned a product roadmap." Then the R5 area as an answer slot: if your integration work ran in sprints or another agile cadence, say which and how; if it did not, say so and say what you would want to confirm about how this team defines agile delivery. No bridge on the roadmap. | Names both weak areas from the dossier. Covers R5 and R1's roadmap sub-claim without inventing evidence. |
| A3 | "Which part of the integration work would carry over to roadmap ownership, and which would not?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Name what carries, at the quotes' own scope: the scoping and requirements work in V1, and the evidence you fed product in V3. Name what does not: prioritization authority, which you have not held. | A live analytic question that tests whether your bridge has a stated limit. It asks for no past claim beyond the quotes. |
| A4 | "Why this role, and why now?" | EXP | [generic] | Open prompt. Say what draws you to the partner API platform in your own words. If the pull is the product role itself, say so plainly. Do not reach for a motive your material does not carry. | Motivation is a Skeptic's core probe. The material carries no stated motive, so the guidance is a scaffold. |
| A5 | "If one squad lead thinks a partner priority is wrong and the other disagrees, which way do you lean, and why?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility) | State the decision principle first: who owns the trade-off, and what evidence settles it. Then the lean. Answer slot: if you have had a disagreement with an engineering lead, say how it ended; if you have not, give the principle alone. | The seam under R4 and the open decision-authority question. The guidance asserts no past disagreement. |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has stalled after onboarding. Where do you start?" | CASE | [grounded] "Define and track adoption metrics" (role_profile responsibility) | Clarify: which partners, which API, and what "adopted" means. Then a metric tree. Then ask for the current baseline before you propose a target. Invent no baseline. | Adoption is a named responsibility, and the dossier records no baseline. Generic because research did not run. |
| B2 | "A partner asks for an endpoint only they need. How do you decide?" | CASE | [grounded] "Run discovery with integration partners" (role_profile responsibility) | Discovery questions first: how many partners need it, what it costs the platform, what the partner would do without it. Then a decision rule: generalize, decline, or scope it. | Partner discovery is a JD responsibility. Generic. |
| B3 | "Two squads have conflicting capacity for next quarter. Walk me through your first week." | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility) | Plan, not past. Meet both leads, map the commitments, ask what is fixed. Say what you would not decide alone in week one. | A live problem from the JD's squad responsibility. It asks about the future and presupposes no past. |
| B4 | "How would you separate a partner that has integrated from one that is actively using the API?" | CASE | [grounded] "Define and track adoption metrics" (role_profile responsibility) | Define the two states first. Then name the signal for each, and the baseline you would need before you could set a target. | Tests the adoption definition, the weakest point the dossier flags. Generic. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted. What made one complete?" | EXP | [grounded] V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say how you counted, in your own words. If there was no counting rule, say so plainly. Weakest-assumption move: name, in your own words, the assumption behind the count you would defend least. The pack does not name it for you. | The defend-the-number slot a figure raises. V1 is high confidence and points to the integration playbook as proof. |
| C2 | "After go-live, what did you look at to tell whether a client was using the integration?" | JD | [grounded] V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Define and track adoption metrics" (role_profile responsibility) | Answer slot: if you looked at any usage signal after go-live, say which and what it showed. If you did not track it, say so and say what you would measure first. | F7. Adoption is a JD responsibility, and the material is silent on tracking. The question's premise is a raising source; the second branch allows it to be false. |
| C3 | "What partner API adoption metric would you pick, and what is the baseline?" | JD | [grounded] "Define and track adoption metrics" (role_profile responsibility); dossier risk "no current baseline is stated" | Name the metric type and the definition question you would settle first. Ask for the baseline. Do not invent one. | The dossier names the baseline as an unvalidated risk. This question doubles as a reverse question. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] V1 and V2 as quoted in A1; dossier prohibited_claims "Having held a product manager title or role" | Pause. Restate the question in one line. Then, in 60 seconds: concede the PM title, then V1 at its own scope. Hold through two follow-ups. Concede the roadmap gap plainly on a third. | The stress format of the A1 objection. It tests composure, not new content. |
| D2 | "That integration work is client services with a different title. How much of it was product work?" | JD | [grounded] V1 "Led 30+ end-to-end client integrations of the vendor's REST APIs"; V3 "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold the scope, not the label: "What I led was the integrations, end to end. Roadmap input was evidence I fed product from client work." Concede: "Setting priorities for an engineering squad I haven't done." | Composure under a reframing challenge. The concession is sourced to the dossier prohibited_claims item. |

### Rapport / Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] V1, V2 and V3 as quoted in the fit snapshot | A 90-second arc: the integrations (V1), the playbook (V2), roadmap input (V3), and the role you want. Do not call the work a PM role. | Casual openers are scored. The arc is built from the quotes only. |
| E2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] "Technical fluency: API docs, schemas" (role_profile R3) | Name only tools you have used recently. If schemas are new to you, say so and say how you would learn them. | F3. The material does not show schema work, so the honest answer is the slot. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1q | "Our two squad leads sit either side of this role. Where is the seam between you and them, and what happens when you disagree?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility) | State the seam principle: who decides scope, who decides sequencing. Answer slot: if you have had a disagreement with an engineering lead, say how it ended; if not, give the principle alone. | R4 and the open decision-authority question. |
| F2q | "How do you handle credit when work spans teams?" | EXP | [generic] | Name the work and the people who did it, not the org chart. Do not claim credit for a squad's work. | A credit probe. Generic. |

Question count: 18 (A1–A5, B1–B4, C1–C3, D1–D2, E1–E2, F1q–F2q).

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| R1 3+ years product management experience | A1, A2, D1, D2, E1 | |
| R2 Shipped API or platform products | A3, C1 | |
| R3 Technical fluency: API docs, schemas | E2 | Covered only by a conversational stem. No stronger question; a stated reason. |
| R4 Stakeholder management across engineering, sales, customers | F1q, B3, C2 | Sales is not covered by any question: no sales material. |
| R5 Agile delivery experience | A2 | |
| Own the roadmap (F6) | A1, A2, D2 | |
| Define and track adoption metrics (F7) | B1, B4, C2, C3 | |
| Run discovery with integration partners (F8) | B2 | |

## Reverse questions

Ask at least two of these. The first two come from your dossier.

| Question | Why it lands |
|---|---|
| "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" (dossier questions_for_employer) | The decision-authority question is the dossier's biggest unvalidated risk. The answer tells you whether the role is what the JD says. |
| "How is partner API adoption measured today, and what is the current baseline?" (dossier questions_for_employer) | The dossier names the baseline as unstated. If there is none, the job starts with building it, and you should know that before you accept. |
| "What did the last person in this seat leave unfinished?" | Shows you want the actual state of the work. Generic. |
| "When the two squads disagree, how does the trade-off get settled today?" | Tests the seam directly, in the hiring manager's own words. Generic. |
| "What would make the first 90 days a success from your seat?" | Shows what they expect, and lets you check it against the ramp plan. Generic. |

## Sources

- **Provided documents:** your `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14, about three months old). Consumed sections: `handoff_to_mock_interview` (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, prohibited_claims, questions_for_employer, opportunity_risks_to_validate) and `role_profile` (requirements R1–R5, responsibilities, unknowns). The `decision` section (conditional_go) is context only. The dossier has no evidence_map or evidence_state, so the pack's rejected-inference list is built from prohibited_claims alone.
- **Research tier:** L1 intended. Two searches were sent and the host refused both, so no research ran. Values, loop structure and strategy are not established by any source in this pack.
- **Searches sent:**
  - "Quartzline company values": refused.
  - "Quartzline product manager platform APIs interview process": refused.

Target accounting:

Research tier: L1 — searches 0 of 6 (2 sent, both refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet, section 10. Search refused; the section is dropped. |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure and persona weights. Search refused; weights rest on the hiring-manager prior. |
| 3. `Quartzline strategy` / recent news | unavailable | Grounding brief and CO questions. Not attempted after the refusal; CO questions are not in this pack. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the requirements and JD-tagged questions. |

## Upgrade menu

- The interviewer's name → a tailored reverse question and persona weights read from their public footprint.
- A pasted copy of Quartzline's values page → a values cheat sheet, with each value mapped to a story from your quotes.
- Research permission for this session → values, loop structure and strategy, up to 6 searches and 2 fetches. Deep research is the same kind of pass with 6 more searches and 2 more fetches, several minutes; it needs the same permission first.
- The recruiter's prep email → any pre-declared deliverable and any process details, such as whether this round is a single session.
- Your CV → adds a CV quote to V1, V2 and V3, so those rows carry two sources.
- Hours you have before Thursday → a prioritized prep schedule.
- Refresh the dossier: it is dated 2026-08-14. If the posting or the squad setup has changed since then, rerun the underwriting before Thursday.
