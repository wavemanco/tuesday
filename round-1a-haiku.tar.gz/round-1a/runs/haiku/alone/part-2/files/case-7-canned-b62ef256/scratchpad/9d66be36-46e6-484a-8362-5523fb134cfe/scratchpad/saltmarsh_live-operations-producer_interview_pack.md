# Live Operations Producer, Saltmarsh Games: interview prep for Femi

Interviewer: Tobias Wrenfield, Head of Live Operations (public talk: "Patch Notes Are a Promise", GDC 2026). Assumed relationship: hiring manager. Saltmarsh's careers page says the 60-minute loop is "a single 60-minute interview with the hiring manager", so the pack is built on that. If that is wrong, the persona weights change (see the upgrade menu).

## How to use this pack

Personas are how a question is asked. Types are what is being scored:

- **CASE**: a live problem from the role, scored on structure and reasoning
- **VAL**: values alignment, scored on past behaviour against Saltmarsh's published values
- **EXP**: your own experience, scored on whether it survives scrutiny
- **JD**: a stated requirement from the job description
- **CO**: company and strategy knowledge

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are quoted from the job description. Evidence is quoted from your own sentences. Quotes are the only things this pack says about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material names one calendar, for your main title, weekly. Two titles and live events are not in it, so the bridge stops at the calendar: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for live events across two titles. If you planned events, not only content drops, say which and how you chose their timing; if you did not, say so and describe how you would plan two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | discovery | Your material names QA and nothing else. Coordination across four teams on an update is not shown either way. Answer slot: if you coordinated design, art, engineering or community on an update, say which and how; if you did not, say so and describe how you would run one update across all four. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material says you presented the numbers. It does not say you chose them, built them, or ran a review. Answer slot: if you chose the numbers or ran a review, say which and what it reported; if you presented numbers someone else built, say so and say what you would own. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it. Running releases against it is not stated. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: if you ran a release against the checklist with QA, say how; if not, say so and describe how you would run one. |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap: the sentence reaches the requirement in its own terms. Expect a probe on how the calendar was fed. Keep the claim at the calendar you ran. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Bridge rewords only the quote: "I presented the monthly retention numbers to the studio head." No analysis is added. |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | discovery | The material shows a checklist you wrote, not a body of writing. Answer slot: if you can name a piece of writing that others acted on, name it; if the checklist is your strongest example, say that. |
| F8 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material gives four years as an associate producer on a puzzle game. It does not say live-service or app. Answer slot: if the puzzle game ran as a live-service title, say how; if not, say so and point to the weekly content drops as the nearest live work your material carries. |

Not in the JD, but it will come up: your message says "Never led a team" and "never worked on a game with in-app purchases." Plain acknowledgments, usable as stated: "I haven't led a team." and "I haven't worked on a game with in-app purchases."

## Prohibited claims

Not to be coached in any answer, hold or reverse question. Built here from the fit snapshot; no dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated: "Never led a team" | "I haven't led a team." |
| Ran live events across two mobile titles | Inflated form of F1: your material names one main title | "For the last two years I ran the weekly content-drop calendar for our main title." |
| Owned the KPIs or the post-event review | Inflated form of F3: your material says you presented the numbers | "I presented the monthly retention numbers to the studio head." |
| Ran a release with QA | Inflated form of F4: your material says you wrote the checklist | "I wrote the release checklist our QA team still uses." |
| Worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." |

## Interviewer read

Public footprint only: a GDC 2026 talk, "Patch Notes Are a Promise", and his earlier role as a QA lead at a console studio (both from search results; the talk page was not opened).

- **Implication 1:** his QA background means the release checklist will be probed. Keep F4 at the checklist you wrote.
- **Implication 2:** his talk argues that a live team is judged by how often its patch notes describe what shipped. That is the same test as Saltmarsh's value "Ship the Patch Not the Promise". Answer through what was checked before release, not through what was promised.
- **Mirror opportunity:** QA is the shared ground. He moved from QA to live operations. Your sentence "Wrote the release checklist our QA team still uses" is the only QA-adjacent material you have. Use it as the mirror, not as a claimed path.

## Persona table

Weights are the hiring-manager prior, adjusted by the Saltmarsh loop page and his public talk.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour: a live-incident tabletop on a simulated outage during a live event | High. The careers page names the tabletop as the first half of the 60 minutes | Clarify first, then structure, then decide. Think aloud. Name a tie-breaker |
| Values/Behavioral | The values conversation after the tabletop, on three published values | High. The page names a values conversation as the second half | Map each value to a story only where one of your quotes carries one; otherwise use the scaffold |
| Data-Driven Prober | Retention numbers and the post-event review, probed by someone with a QA background | Medium. The JD names KPIs, and his talk is about shipped-versus-promised | Name the weakest assumption before he does; say plainly when you did not build a number |
| Skeptic | Team leadership and purchases, the two gaps you named | Medium-high. Hiring-manager prior, and two real gaps in the material | Rehearse D1 until it is plain. Hold what you did, concede what you have not led |
| Pressure | Time-boxed tabletop | Medium-low. Not in the page, but a live-incident format runs to time | Pause, restate, answer in one clean sentence, then elaborate |
| Conversational | A warm opener and a journey question | Low. Still scored, so prepare the 90-second arc | Keep the arc to what your quotes say |

Peer persona: not included. This is a hiring-manager loop.

## Question banks

Question IDs are letter-by-persona. Depth follows weight: 5, 4, 3, 3, 2, 2.

### A. Case/Strategist (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say the cadence, the title and the two years, in your own words. Answer slot: the JD asks about live events across two titles, so expect a probe there. If you planned events as well as content drops, say which and how you chose their timing; if not, say so and describe how you would extend the calendar. | F1 and F5 are the evidence. EXP because it tests what you actually ran |
| A2 | "Two mobile titles, one events calendar. How would you plan a month across both?" | CO | [grounded] "one shared events calendar from February 2027" (Saltmarsh news, search snippet) | Clarify before you plan: what each title's goals are, what is already in flight, what the QA and release windows are. Structure the plan around the shared calendar. Name one tie-breaker when two titles collide. Say the structure aloud before you use it. Do not claim to know how Saltmarsh staffs it | The shared calendar is the company's current direction, so this is the strategy question. CO because it tests altitude, CASE because it is a live plan. The JD's "two of our mobile titles" is the raising source |
| A3 | "It is 40 minutes into a live event and a reward is granting twice. Walk me through the first ten minutes." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (Saltmarsh careers page) | Stop the bleed first: pause the event or cap the reward. Then say who you call, in what order: engineering on call, QA, community for player messages. Say what you record for the post-event review. Answer slot: if you have run a live incident, say what you did; if you have not, say so plainly and give the order you would work in. | This is the Outage Hour's format, so it is the most likely question. The question presupposes nothing about your past |
| A4 | "Engineering needs two more days for the fix, and the community team says players are already angry. What do you decide, and who do you tell first?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Decide on player harm first, and say so. Then say what you can announce as built, not as hoped. Then say who hears first, and why. Use the company's own value, Players Before Plans, only if you can say why it applies here | Tests coordination across four teams, which F2 leaves open. Generic: it is a live problem, not a claim about your past |
| A5 | "Walk me through the release checklist you wrote. Who uses it, and what happens when an item fails?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what you wrote, and who uses it now. Answer slot: the JD asks you to manage the checklist with QA. If you ran a release against it with QA, say how; if not, say so and describe how you would run one | F4 is the evidence for the manage requirement. The question asks how the checklist works, and the answer must not claim a failure you did not see |

### B. Values/Behavioral (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "when the calendar and the players disagree, the players win" (Saltmarsh values page); nearest candidate sentence: "I ran the weekly content-drop calendar for our main title for the last two years" | Pick a time you had to choose between the calendar and what players needed. Name the stake, what you chose, and how it landed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the calendar you ran, and how you decided what went in it, in your own words | The value is the company's own, and the calendar is your nearest material. Scaffold, because no quote carries a decision |
| B2 | "When have you told a team a date was not real?" | VAL | [grounded] "we announce what is built, not what is hoped" (Saltmarsh values page); nearest candidate sentence: "Wrote the release checklist our QA team still uses" | Pick a time you had to tell someone a date was not real. Name the stake, what you said, and what changed. If none comes to mind, say so plainly. Connect the checklist only if it did connect; if it did not, say so | This is the value "Ship the Patch Not the Promise", asked as an open prompt. The checklist is the nearest material, not the answer |
| B3 | "What have you left better than you found it?" | VAL | [grounded] "every release leaves the codebase and the checklist better than it found them" (Saltmarsh values page); candidate sentence: "Wrote the release checklist our QA team still uses" | Say what you wrote and that QA still uses it, in those words. Do not say it made releases better unless you know it did. Answer slot: if you know what the checklist replaced, say what it was; if you do not, say so | The value names the checklist. The guidance claims only that you wrote it and it is still used |
| B4 | "Tell me about a time you got work from people who did not report to you." | VAL | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); no candidate sentence carries a story | Pick a time you got work done across a team boundary. Name the stake, what you asked for, and how it ended. If none comes to mind, say so plainly and give the nearest thing your material carries. Do not describe leading anyone | This is the coordination requirement, which F2 leaves open. Scaffold, since no quote carries a story |

### C. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention number did you present most often, and where did it come from?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the number in your own words. Say who built it, and what you chose to show. Answer slot: if you chose the cut or built the number, say so; if someone else built it and you presented it, say so plainly | F6 is the evidence. The question asks where the number came from, which the quote does not answer. Keep the answer at presentation |
| C2 | "What does a post-event review look like for you, and what did you take to the studio head?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); candidate sentence: "Presented the monthly retention numbers to the studio head" | Describe what you have seen or done, in your own words. Answer slot: if you ran a post-event review, say what it reported; if you presented from one someone else ran, say so, and say what you would own. | F3 is the gap. The JD raises the post-event review, and your quote does not show you ran one |
| C3 | "A retention number dropped after a content drop. What is your first assumption about why, and which one would you defend least?" | JD | [generic]; candidate sentence: "Presented the monthly retention numbers to the studio head" | Name the weakest assumption before they do. Keep to what you can defend. Do not claim the analysis was yours unless it was | This is the metric question every prober asks. Generic reasoning, with the presentation quote kept in scope |

### D. Skeptic (weight: medium-high, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have not led a team, and this role coordinates four teams. Why should we believe you can?" | JD | [grounded] "Never led a team" (your message); JD: "coordinate design, art, engineering and community teams on each update" | Hold what you did, and concede what you have not. Say: "I haven't led a team." Hold: the cross-team work your material shows is the release checklist with QA: "I wrote the release checklist our QA team still uses." Hold that through a second follow-up. Concede plainly where it is thin, and name how you would learn to coordinate four teams | This is the highest-ROI prep. It is the most predictable objection, and it is aimed at your thinnest evidence. Deepest rehearsal: hold, then concede exactly, never more than the quote carries |
| D2 | "Your calendar was for one title. Two titles, one events calendar. What breaks first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; JD: "Plan and run the live-events calendar for two of our mobile titles" | Say the scope you ran: your main title, and nothing more. If you ran a calendar across more than one title, say so; if not, say which part you would check first | Scope is the gap. The quote names your main title and does not say you ran only one, so do not claim it either way |
| D3 | "You have not worked on a game with in-app purchases. Live events on mobile titles often involve purchases. What would you need to learn first?" | JD | [generic]; candidate sentence: "I haven't worked on a game with in-app purchases" (plain acknowledgment, from "never worked on a game with in-app purchases") | Say the plain acknowledgment first. Then say what you would learn first, in order: how purchases are tested during an event, and who owns the purchase flow. Do not claim familiarity with it | The purchase gap is real and this question will come. The plain acknowledgment is sourced to your own words |

### E. Pressure (weight: medium-low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has run two titles?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause. Restate the question. Answer in one clean sentence: the calendar you ran, for two years, on your main title. Then concede the scope you have not shown. Hold the calendar; concede the second title | Time-boxed challenge. Hold-then-concede: the position is the calendar, the concession is the second title |
| E2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: you wrote it, and QA still uses it. If QA or anyone else shaped it, say who and how. If you wrote it alone, say so. Answer slot: do not claim the checklist changed anything you cannot name | Attribution probe on the checklist. The answer has to be exact about who did what |

### F. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | A 90-second arc: four years as an associate producer on a puzzle game; the weekly calendar for your main title; presenting retention to the studio head. Do not add to it | Casual, and still scored. The arc uses only sentences you gave |
| F2 | "What are you playing right now, and what would you change about how a live game ships an event?" | JD | [generic] | Name one game you actually play, and one specific thing about how it ships events. Do not claim to know Saltmarsh's titles beyond the two named in the news | Casual register on a live-ops topic. Generic, because the answer is a view, not a claim about your past |

## Reverse questions

Ask at least five. Each has why it lands.

1. "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. What does your team check before a note goes out?" Why it lands: it is his own talk, and it ties to the checklist you wrote. [grounded] talk search snippet.
2. "Project Larkspur moves both titles to one shared events calendar from February 2027. What does the first milestone look like for the person running it?" Why it lands: it is the company's current direction, and it shows you read the news. [grounded] Saltmarsh news search snippet; I did not open the full page, so check it before Friday.
3. "What does the first thirty days look like for someone taking on the calendar for both titles?" Why it lands: it asks about the job, not your competence.
4. "Where does the live-ops group sit with design, art and engineering on an update?" Why it lands: it tests whether the coordination requirement is a shared process or a personal one.
5. "How do you know whether a post-event review changed the next event?" Why it lands: it asks about the KPI loop the JD asks you to own, and it lets him describe his standard.

## Values cheat sheet

The company's three published values, from its values page.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quote carries a decision of this kind. Scaffold: B1. If none comes to mind, say so, then give the calendar you ran |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote carries a decision of this kind. Scaffold: B2. If none comes to mind, say so, then give the checklist you wrote |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | Your quote carries that you wrote the checklist and QA still uses it. Nothing shows it improved anything. Scaffold: B3, and say what it replaced only if you know |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, A2, D2 (F1) |
| Coordinate design, art, engineering and community teams on each update | A4, B4 (F2) |
| Own the post-event review and the KPIs it reports | C2, C1 (F3) |
| Manage the release checklist with QA | A5, E2 (F4) |
| Experience running a content calendar | A1 (F5) |
| Comfortable with player-retention metrics | C1, C3 (F6) |
| Clear written communication | B3 (F7); no writing sample in the material |
| 3+ years producing live-service games or apps | F1 (F8); the live-service part is not shown |

Outage Hour, the company's format: A3 and A4.

## Sources

Provided documents: your message (background and JD text).

Searches and fetches this run (research tier L1):

- "Saltmarsh Games mobile studio values live operations": saltmarshgames.com/values, and a talk page
- "Saltmarsh Games interview process Live Operations Producer": saltmarshgames.com/careers/interviewing
- "Tobias Wrenfield Head of Live Operations": GDC 2026 talk page, talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; not opened)
- "Saltmarsh Games strategy 2026 news titles": saltmarshgames.com/news/project-larkspur (search snippet only; not opened)
- Fetch: saltmarshgames.com/careers/interviewing (returned one paragraph)
- Fetch: saltmarshgames.com/values (returned three values)

Research tier: L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and B1 to B3: three values by name |
| 2. Saltmarsh Games interview process, live operations | yes | The loop: recruiter call, then the Outage Hour, a 60-minute hiring-manager interview. Persona weights and A3 |
| 3. Saltmarsh Games strategy and recent news | yes | Larkspur: one shared events calendar from February 2027, and a single live-ops group. A2 and reverse question 2 |
| 4. Tobias Wrenfield, Head of Live Operations | yes | Talk and prior role, from snippets. Interviewer read and reverse question 1 |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's note on how the 60 minutes split between the tabletop and the values conversation → a time-boxed plan for each half
- Confirmation that Tobias is the hiring manager → the persona weights are checked, not assumed
- The calendar you ran, anonymised → F5 and A1 move from medium toward high confidence
- A writing sample you can share → F7 moves from discovery to supported
- A retention review you presented, anonymised → C1 and F6 get a specific artifact to rehearse
- Whether the puzzle game was mobile and ran live events → F1 and F8 gain a sentence you can say aloud
- Full research at L2 (the strategy brief, the full talk, the Larkspur page) → the CO bank and reverse questions get deeper
