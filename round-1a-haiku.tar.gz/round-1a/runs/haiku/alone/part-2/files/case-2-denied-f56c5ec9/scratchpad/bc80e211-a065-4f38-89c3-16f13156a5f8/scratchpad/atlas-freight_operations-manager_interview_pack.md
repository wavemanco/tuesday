# Operations Manager, Atlas Freight: interview prep pack

Interviewer: not named. Round: not stated. Built as a hiring-manager round (see assumption below). First build, so nothing to regenerate.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** EXP = your past work, checked for what was really yours. JD = the job's listed requirements. CASE = a live problem from the job, no past needed. CO = company knowledge (not covered: no research run). VAL = values (not covered: no values round detected).
- **Guidance is scaffolding, not a script.** Aim for 90 to 120 seconds spoken.
- **Answer slots** are instructions for the interview. They are not questions to me, and they tell you what to say if the premise is not yours.
- **Assumption:** you didn't say who you're meeting, so I built this for a hiring-manager round. The weights are therefore a prior, not a read on this interviewer. Without the round type, the pack is weaker than one built for the actual loop.

## Fit snapshot

Requirements are quoted from the JD you supplied. Your evidence is quoted from your message. "Your message" means the background you wrote for this request.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material says one site's warehouse and distribution work, not four terminals. Keep it at that scope: "I've spent seven years in warehouse and distribution operations." Answer slot: if you have run or directed daily work across more than one site, say which and how; if you have not, say so, and say how you would take on four. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more people through supervisors, say how many and how; if three is your span, say so and say how you would structure twelve. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows an accuracy metric moved by a process redesign, not on-time performance or cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment, say the figure and how it was counted; if you did not, say so and say how you would measure it first. |
| F4 | "Lean/Six Sigma a plus" (JD) | "Green Belt certified" (your message) | medium | [grounded] | none | The certificate reaches the requirement. Lead with it in your words. A certificate alone has nothing inspected behind it, so expect a question about a project you ran. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" and "never used Power BI" (your message) | low | [grounded] | capability | Excel is stated. Power BI is a stated absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. If you have built Excel reporting, it is not in your material yet; add it as a fact and this row upgrades. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish the leadership years. It gives total operations years and a current supervisory role, not how long you have led people. Surfaced here, not bridged. This cell asks nothing; Step 1 asks you the one question it needs. |

**Confidence grades your evidence. Provenance grades what this pack wrote about it.** F3 is medium because the metric is real, but it is a different metric from the JD's.

## Prohibited claims

These are the claims this pack will not coach. Each is a stretched form of something you said, or a negative you stated.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns terminal operations across four sites | Inflated form of F1 | "I've spent seven years in warehouse and distribution operations." Your material says one site, not four. |
| Leads a team of twelve supervisors | Inflated form of F2 | "I'm a senior shift manager over three supervisors." |
| Cut on-time performance or cost per shipment | Inflated form of F3 | "I cut the mis-pick rate 40% by redesigning the pick path." Your material says accuracy, not on-time or cost. |
| Five years of operations leadership | Inflated form of F6 | Your material shows seven years in operations and a current supervisory role. The leadership years are not established. |
| Has built Power BI reporting | Negative you stated, F5 | "I haven't used Power BI." No answer slot. |

## Persona weights

No round type and no interviewer profile, so these are relationship priors for a hiring manager, with no interviewer adjustment.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live floor and cost problems from the JD | High. A hiring manager is buying the ability to run daily terminal work, and the JD is all outcomes. | Clarify the metric, then segment, approach, check risks. Say the structure out loud. |
| Skeptic | "How will you do X?" on the span, the gate and Power BI | High. F2, F5 and F6 are the gaps a hiring manager sees on paper first. | Rehearse B1 until it is boring. Hold the three, then concede the scale plainly. |
| Data-Driven Prober | The 40% figure, and on-time performance | Medium-high. The 40% is your headline metric, and the JD is metric-heavy. | Defend the number. Name the assumption you would defend least. |
| Pressure | Composure on the span and on attribution | Medium. Depth 2, because it is a secondary persona here. | Pause, restate, hold through two follow-ups, then concede only the real uncertainty. |
| Conversational | A casual opener, and Excel and Power BI asked lightly | Low to medium. Casual questions are still scored. | A 90-second arc for the journey question. Treat any casual Power BI question as scored. |

## Question banks

Each row's Provenance carries the candidate sentences its guidance rests on. Guidance that makes no claim about your past carries its label alone.

### A. Case/Strategist (weight: 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "One of your four terminals has on-time performance eight points below the others for six weeks. What do you do in the first two weeks?" | CASE | [inferred] "drive on-time performance and cost-per-shipment down" (JD) | Clarify first: what counts as on time, and what the cut-off is. Then segment by shift, lane, carrier and volume. Then check labor and the dock. End with a 30-60-90 plan. This makes no claim about your past. | The JD's headline outcome, asked as a live problem. The label is [inferred] because the problem is derived from the JD's line. |
| A2 | "Cost per shipment is up 6% in a year with flat volume. Where do you look first?" | CASE | [inferred] "drive on-time performance and cost-per-shipment down" (JD) | Clarify what the cost includes. Split it into labor hours per shipment, overtime and temporary labor, and accessorial charges. Check whether peak carry-over is the cause. No claim about your past. | The second headline outcome. Cost questions are the ones most candidates from a single site are not ready for. |
| A3 | "How would you set up a weekly operations report across four terminals, and where would Power BI come in?" | JD | [grounded] "solid Excel" and "never used Power BI" (your message) | Describe the Excel structure first: the metric definitions, the data source and the refresh rhythm. Power BI comes later, and you say it as a plan: "I'd learn it on the same definitions." | The JD's reporting line. F5 is the honest version of the Power BI answer. |
| A4 | "What changes in the first week of a peak surge that you wouldn't check in a normal week?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | This is your strongest story. Name what the plan covered, in your own words. Answer slot: if you set the parts of the plan yourself, say which; if you ran a plan someone else built, say so and say what you ran. | Your material shows a plan you ran twice, which makes it the most concrete story you have. The question's premise is the quote's own. |

### B. Skeptic (weight: 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've managed three supervisors. This role leads twelve across four sites. What's the plan?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Say the three first: "I currently manage three supervisors, and that's the span I can show." Hold it through two follow-ups by returning to the three. Answer slot: if you have led through supervisors across shifts or sites, say how many and how; if three is your span, say so plainly. Then the plan, as a plan: site leads between you and the supervisors, built in stages. When pushed, concede the stretch: "Twelve is more than I've run, and I'd test it early." | F2 is where this objection lands, and it is the one the JD's span line makes certain. Deepest rehearsal, because a held, non-defensive answer changes the interview. |
| B2 | "How many years have you had people reporting to you in an operations role?" | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | Give the count in your own words, as the number of years you had staff reporting to you. Answer slot: if it is under five, give the honest total and say what your seven years of operations covered. Never round up. | F6 is a gate the material does not establish, so it gets asked directly. |
| B3 | "You've run a site. How would you own cost per shipment across four?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer slot: if you tracked cost per unit at your site, say the figure and how it was counted; if you did not, say so plainly and say how you would build the baseline first. | F3's cost half. Asked as a plan, not as a record you do not have. |
| B4 | "Your background shows no Power BI. What do you do with that in your first month?" | JD | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I haven't used Power BI." Then the plan: start with the metric definitions you already have in Excel, and learn the tool on them. No answer slot. | A sourced negative, so the plain acknowledgment is allowed. The interviewer will likely raise it. |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Name the span and the Power BI gap in your own words, then the ramp plan for each. Don't wait to be asked. | An open prompt. A Skeptic often opens with this, and the honest answer is the one that is most credible. |

### C. Data-Driven Prober (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the measure and the period in your own words. Then name the assumption you would defend least, before they do. Answer slot: if you did not track how it was counted, say so plainly. | The headline metric. It is the number a prober will test first, so the answer is precise attribution. |
| C2 | "What was your on-time performance, and how was it measured?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you tracked on-time performance, say the figure and how it was measured. If you did not, say so plainly and describe how you would measure it first. Hold to accuracy, and say that on-time is what you have not yet tracked. | F3's gap. The JD names on-time directly, and a prober will ask for the figure. |

### D. Pressure (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who's run twelve supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" and "ran the site's peak-season surge plan two years running" (your message) | Pause, then restate the question. Hold: you have the surge plan, run twice, and the three supervisors. Hold through two follow-ups. Concede only what is real: "I haven't run twelve, and I'd build to it." Do not fold on the surge plan. | Composure on the span. Hold-then-concede. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the part you designed. Concede the team's share plainly. Answer slot: if you designed the path alone, say so; if others shaped it, say which part was yours. Don't fold on the redesign. | Attribution under pressure. The honest answer is the one that holds. |

### E. Conversational (weight: 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | CO | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: warehouse floor, then supervising, then the redesign and the surge plan, in your own words. Stop at the supervising. | A casual opener is still scored on the same facts. |
| E2 | "What's the most useful thing you've built in Excel?" | EXP | [grounded] "solid Excel" (your message) | Answer slot: name what you built, if you built anything, in your own words. If your Excel was mostly use, not building, say so. | Casual, and it doubles as an Excel check. The answer upgrades F5 if you have something to name. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1, B5 |
| Drive on-time performance down | A1, C2 |
| Drive cost-per-shipment down | A2, B3 |
| Lead a team of 12 supervisors | B1, D1 |
| Build reporting in Excel/Power BI | A3, B4, E2 |
| 5+ years operations leadership | B2 |
| Lean/Six Sigma a plus | none, and why: the Green Belt is on your CV line, and a plus does not earn a bank of its own. |

## Reverse questions

Five, each with why it lands. No interviewer profile, so none ties to a career path.

1. "How is on-time performance measured across the four sites today, and which site is furthest behind?" Why it lands: it shows you will look at the data before you judge.
2. "How are the twelve supervisors split across sites and shifts?" Why it lands: it tests the span directly and tells you what the structure looks like.
3. "Which reports does the ops team build today in Excel, and is Power BI in use or planned?" Why it lands: it tells you how large the Power BI gap is.
4. "What did the last operations manager leave as the biggest unresolved problem?" Why it lands: it shows you are already thinking about the job, not the title.
5. "How does cost per shipment get reviewed with the finance side?" Why it lands: it finds out who owns the P&L view, which is the gap in B3.

## Sources

Provided documents: the JD text, and your background message. No web research was run.

**Research tier: L0** (provided documents only; you have not yet consented to research).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, section 10. No values round detected, so the section is dropped; no research was run. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. Persona weights are priors, not loop-based. |
| 3. Atlas Freight strategy / recent news | unavailable | Grounding brief. Would have supplied the current language for cost and on-time. |
| 4. Interviewer name + Atlas Freight | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Who is interviewing you and in what round → persona weights, the reverse questions, and the closing read are retuned to that round.
- Interviewer's name → a read of their public footprint, and a reverse question tied to their path.
- Permission to research Atlas Freight at L1 (values, interview process) → the values cheat sheet, and the process structure of the loop.
- A recruiter's note on focus areas or a take-home → coverage of any pre-declared deliverable.
- Your answers to the slots in B1, B2 and D1, in your own words → those rows upgrade from slots to quoted material.
- A `tuesday-dossier.md` from job-underwriter → verified evidence in place of the inferred rows, and a prohibited-claims guardrail checked by the underwriter.
- Prep time before the interview → a prioritized triage of these rows.
