# Stripe: Product Operations Manager, final round (generic pack)

**Round:** final round, Product Operations Manager, Stripe. Interviewer and relationship not yet given, so persona weights are flat (see Persona table).
**Built without:** your CV, the JD text, and web research (search was not permitted this session). Everything below is `[generic]` until those are in.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** your past work, **JD** the listed job, **CO** company and strategy knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds.
- Answer slots (marked "Answer slot") are instructions for the interview. Answer them from your own experience. If the experience isn't there, the honest branch is named in the slot.

## Fit snapshot (worksheet variant)

No CV and no JD, so every evidence cell is `none given`. Requirements are role-family prose, not quotes. The bridge column says what strong evidence looks like, then gives a scaffold.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run recurring operating reviews and cadences across product teams (role family) | none given | none | [generic] | discovery | Strong evidence: a recurring review you ran end to end, with its inputs and the decision it produced. Scaffold: pick a recurring meeting or process you owned; if you never owned one, say so plainly and name the nearest one you ran or joined |
| F2 | Build metrics and dashboards that leadership uses to make decisions (role family) | none given | none | [generic] | discovery | Strong evidence: a metric you chose, who used it, and what changed because of it. Scaffold: pick a metric or report you built; if you did not build one, say which you used and whether you changed any of it |
| F3 | Coordinate launches and rollouts across engineering, legal, and go-to-market (role family) | none given | none | [generic] | discovery | Strong evidence: a launch with named functions and your specific coordination role. Scaffold: pick a cross-functional launch; if you were not the coordinator, say whose role it was and what yours was |
| F4 | Prioritize and triage competing requests with unclear ownership (role family) | none given | none | [generic] | discovery | Strong evidence: a queue or intake you ran and the rule you used to rank it. Scaffold: pick a time the queue was full; if you had no rule, say so and describe how you would set one |
| F5 | Turn ambiguous problems into written process, playbooks, or decision records (role family) | none given | none | [generic] | discovery | Strong evidence: a document or decision record others used after you wrote it. Scaffold: pick a process you documented; if none exists, say so and name the form you would use |

## Prohibited list

Nothing to list yet. There are no candidate statements in hand, so there is no stretched wording to guard against. This list fills once your CV is in: the wording of each sentence you did say becomes its own entry, at its own scope.

## Persona table

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems on how a product-ops function would run | High | Final rounds commonly test judgment on live problems; no relationship given, so this is the flat default | Clarify, then structure, then metrics, then risks. Say the framework aloud once |
| Skeptic | "Where is the gap?" questions about the listed job | High | Generalist ops candidates are commonly probed on the domain the JD names | Name the gap plainly, then the ramp plan |
| Data-Driven Prober | Asks how a number was counted and what it assumes | Medium | Ops roles are judged on metrics; no CV yet to probe | Name the weakest assumption before the interviewer does |
| Pressure | Time-boxed challenge to why you | Medium | Final rounds often add a senior voice | Pause, restate, hold through two follow-ups |
| Values / Behavioral | STAR-shaped stories | Medium | No published values in hand, so the stories are generic | Pick a story with a hard truth in it; say so if none exists |
| Conversational | Casual opener and "what excites you" | Medium | Casual questions are still scored | Have a 90-second arc ready |

Depth: Case/Strategist 5, Skeptic 4, Prober 3, Pressure 2, Values 2, Conversational 2.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would approach your first 90 days in this role. What do you need to know first?" | CASE | [generic] | Clarify first: the team's current priorities, who the work serves, and what leadership measures. Then structure: listen, map the processes, pick one fix with a measure. Name a risk | Role-family case; the most common final-round opener for this function |
| A2 | "Launch-readiness reviews are slipping about a week each cycle. Diagnose it." | CASE | [generic] | Name the metric first ("slipping" against what?). Split by stage and by team. Challenge one premise: that the slip is in review, not in inputs | Live diagnosis, which the Case persona scores on structure |
| A3 | "A product team says its launch is urgent and wants to skip intake. What do you do?" | CASE | [generic] | Ask what is urgent and for whom. Offer a fast path that keeps the one check that matters. Name what you would record | Prioritization under pressure, a common live problem for this role |
| A4 | "Design a weekly operating review for 40 people across four product areas. What goes on the agenda?" | CASE | [generic] | Start from the decisions the review must make. Then the inputs for each, then the owner. Keep it to three items | Tests whether you design for decisions, not for updates |
| A5 | "How would you decide which of 30 requested process changes to do first?" | CASE | [generic] | Name the criteria before ranking: impact, effort, who is blocked. Show how you would test the top two | Prioritization judgment, the most common ops question |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Answer slot: name the area where your experience is thinnest, in your own words. If you have run that kind of work, say where. If you have not, say so plainly and name how you would learn it in the first month | The stock Skeptic opener; an honest, specific answer beats a vague one |
| B2 | "I don't see [domain the JD names] in your background. How would you handle it here?" | JD | [generic] | Highest-ROI prep in this pack. Answer slot: if you have done this work, say where and what you did. If not, say so plainly, then describe the first 30 days of learning and the person you would ask | The most predictable objection for a generalist candidate. It will come in some form. Rehearse until the plain answer is boring |
| B3 | "Why leave where you are, and why Stripe, and why now?" | EXP | [generic] | Answer slot: give your actual reason for leaving in your own words, then one specific reason for this role. Do not describe the company's strengths unless you have looked them up yourself | Motivation consistency; the reason for leaving is a logistics-style answer and should be yours |
| B4 | "Why should we hire you over someone who has done this exact job at a larger company?" | JD | [generic] | Name the one true difference you can defend. If there is no difference you can defend, say so and name what you would do to close the gap | Tests calibrated candor over bluffing |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you would measure whether a process change worked." | JD | [generic] | State the metric, the baseline you would need, and the assumption you would defend least. Answer slot: if you have measured one before, say how; if not, name the first measure you would set | Ops roles are judged on measurement |
| C2 | "Tell me about a number you have reported. How was it counted?" | EXP | [generic] | Answer slot: say how it was counted, in your own words. Name the weakest assumption behind it. Say which part was yours. If you do not know how it was counted, say so | Defend-the-number slot. Never explain a method you cannot repeat |
| C3 | "What assumption behind your best result would you defend least?" | EXP | [generic] | Name the assumption before they do. Answer slot: if you do not have a best result you can defend, say which result you can defend and why | Converts a gotcha into a credibility point |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question. Give one defensible reason and one honest concession. Hold through two follow-ups; concede only what is true | Time-boxed challenge; tests composure |
| D2 | "That result. How much of it was actually you?" | EXP | [generic] | Answer slot: state your part in your own words. Concede the shared part specifically. Never fold on the core claim just to end the pressure | Hold-then-concede structure |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time a senior person disagreed with you on a fact, you did not fold, and the relationship held. Say so plainly if none comes to mind, then give the nearest one, or how you would handle it | Open prompt. Values stems are generic until values are in hand |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: pick a time a customer outcome beat an internal number, and say what you gave up. If none, say so, then give the nearest one | Open prompt; scored behavioral conversation |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | Have a 90-second arc: where you started, the through-line, the work that matters for this role, and why now. Your specifics go in the slots above, not here | Casual opener, still scored |
| F2 | "What excites you most about this role?" | JD | [generic] | Name one part of the role in the job's own words, once you have the JD. Tie it to one real thing you have done, if one exists | Tests genuine interest and specificity |

### Requirement coverage

| Role-family requirement | Question IDs |
|---|---|
| Operating cadence and reviews | A4, A5, C1 |
| Launch coordination | A2, A3 |
| Metrics and dashboards | C1, C2, C3 |
| Prioritization of competing requests | A5, B4 |
| Ambiguity and written process | A1, F2 |
| Gaps in the listed domain | B1, B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does success look like for this role at six months?" | Shows you think in outcomes, and gives you the scoring rubric in their words |
| R2 | "Which process here causes product teams the most friction right now?" | Shows you think about the operating model, not only the role description |
| R3 | "When the queue is full, how do product and ops decide what gets done first?" | Surfaces the prioritization rule, which you can answer for in later rounds |
| R4 | "What is the team's biggest open question this quarter?" | Invites them into their own problem; a strong close |
| R5 | "What would make someone in this role a strong hire beyond the listed requirements?" | Gets the unwritten bar, which the JD doesn't carry |

If the interviewer is a peer, add one reciprocity question: "What could a new person do in their first month that would genuinely help your team?"

## Sources

- Provided documents: none beyond your message.
- Research tier: L1 (searches 0 of 6 permitted, fetches 0 of 2). Three searches were attempted and each was refused by the host (permission not granted).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10), omitted. Query refused: "Stripe company values principles" |
| 2. Stripe interview process, final round | unavailable | Loop structure and persona weights. Query refused: "Stripe interview process final round onsite" |
| 3. Stripe strategy and recent news | unavailable | Grounding brief and CO questions, omitted. No query sent after the host refused search |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given |
| 5. Representative JD for the title | unavailable | Fit snapshot requirements, currently `[generic]`. Query refused: "Stripe Product Operations Manager role responsibilities" |

## Upgrade menu

- Your CV → evidence cells in the fit snapshot, premised questions, and a prohibited list built from your own sentences
- The JD text → requirement rows move from `[generic]` to `[grounded]`, and the coverage table becomes JD-specific
- Round type and relationship (hiring manager, peer, panel) → persona weights recomputed from flat
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- Permission to search → Stripe values cheat sheet, loop structure, and current strategy questions
- The recruiter's prep email → any declared deliverable, and its coverage
- If the final is several sessions, send the schedule → a mini-pack for each session
