# Ashgrove Credit Union: Member Experience Lead interview prep pack

Role: Member Experience Lead. Company: Ashgrove Credit Union (member-owned, about 900 staff).
Round 1: recruiter, 30 min, 26 Nov. Round 2: Head of Member Services (your future manager), 45 min, mostly behavioural, 26 Nov. Round 3: panel of two branch managers, 60 min including a 20-minute complaint-escalation case, scored against the four values, 26 Nov.
Interviewers for rounds 2 and 3 are not yet named. Prepared 17 Nov 2026.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioural / values | Whether past behaviour shows Ashgrove's published values |
| EXP | Experience deep-dive | Whether your CV claims survive scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you know the July 2026 strategy and think at its level |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Say it in your own words, and stop where the guidance stops.

## Prep triage

You have nine days. Work in this order:

1. **B1, the highest-return prep in this pack.** The Head of Member Services is most likely to ask where you are weakest. Rehearse the hold-then-concede answer until it is plain, not defensive.
2. **C5, the 20-minute case.** Practise the time plan out loud, twice.
3. **A1 and the logistics answers (A3 to A6).** Know your own pay, notice, location and reason before the recruiter asks.
4. **Section 10, the values stories.** Find one real case for each value, or know your honest "not that one" answer.
5. **C8 to C10, the strategy questions.** Know the three strategy lines and what each means for complaints.

Everything else is insurance.

### Day by day to 26 November

- **Tue 17 Nov:** Write the three things your material says you did (complaints log, tellers' escalation training, monthly spreadsheet) and the two things it says you have not done (contact centre, presenting above regional level). Keep the wording exactly as in section 4.
- **Wed 18 Nov:** Say A1 aloud, under 90 seconds. Record it and listen for any beat you added.
- **Thu 19 Nov:** Answer A3 to A6 with your own figures and reasons. Write them down once; do not improvise them in the interview.
- **Fri 20 Nov:** Drill B1 with a friend playing the Head of Member Services. Hold through two follow-ups, then concede the two gaps in your own words and give the plan.
- **Sat 21 Nov:** Look at the monthly spreadsheet. Note what it counts and whether it includes resolution times. Prepare a one-page version with no member details in it.
- **Sun 22 Nov:** Rest. Read section 6 once.
- **Mon 23 Nov:** Run C5 in 20 minutes, timed, using the time plan. Then run B6 once.
- **Tue 24 Nov:** Fill the values table in section 10 with real cases, or confirm the honest branch for each value.
- **Wed 25 Nov:** Read the three strategy lines. Say your answers to C8 to C10 aloud. Pick four reverse questions from section 11.
- **Thu 26 Nov:** Interviews. Round 1 is logistics and motivation. Round 2 is mostly behavioural. Round 3 is values plus the case.

## The fit snapshot

Each row sets the JD requirement against your own sentences, quoted exactly. Everything this pack says about your past comes from these quotes and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on the years. "Customer operations" is the JD's phrase, not yours, so describe the role you held in your own words. Expect a probe on whether branch service counts. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your sentence is one branch's log, not the process end to end. Say it at its own scope: "I handled the branch's formal complaints log." Answer slot: if you ran any step beyond that log, say which, in your own words. If not, say so and stay with the log. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated, so the words are yours: "I've never worked in a contact centre." Then say how you would learn it, as a plan, never as a past. |
| F4 | "report monthly on complaint volumes" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Your sentence reaches the monthly report. Reword only that: "I built the monthly complaints spreadsheet our regional manager uses." Add no figure, measure or tool. |
| F5 | "resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence does not show whether resolution times were in the spreadsheet. Answer slot: if they were, say which and how they were counted. If not, say so and say what you would add first. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Tellers, not supervisors, and training, not coaching. Say it at its own scope: "I trained new tellers on our escalation script." Answer slot: if you helped a supervisor through an escalation, say what you did. If not, say so and say how you would coach one. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | No evidence either way. Answer slot: if you have worked with a digital team on a customer journey, say what you did. If you have not, say so and say what you would look at first. |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your sentence does not say the log was regulated. Answer slot: name the rules or timescales that governed the log, in your words. If none did, say so and describe how the log was kept. |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would learn it, as a plan. |
| F10 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Your sentence says spreadsheet, not Excel. Name the tool only if you used Excel. The spreadsheet itself is inspectable proof and would raise this row (section 15). |

No requirement above is a gate. Years, skills and "regulated" are graded on fit, not treated as legal bars.

## Graded deliverables

None were declared. The round 3 case is a live case, not a take-home, so it is covered in section 9 (C5).

## Grounding brief

Source: the 2026 strategy brief Ashgrove published in July 2026, as sent by the recruiter. Use these lines as the vocabulary; do not recite them as your own findings.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

The brief is four months old. Anything published since July is not in this pack (see the upgrade menu).

## Persona table

| Persona | How it shows up in this loop | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Conversational / rapport | Round 1 recruiter: friendly, asks for the walk-through and the logistics | High. Recruiter screens are logistics plus motivation, and the recruiter's email says it is a 30-minute conversation with them | Pre-set your 90-second walk-through. Treat casual questions about pay, notice and location as scored | A1 to A6 |
| Skeptic | Round 2 Head of Member Services: why this role, why now, where are you weakest | High. The relationship prior for a hiring manager is Skeptic plus Case. A future manager is also checking the JD's three gaps (F2, F3, F9) | Rehearse B1 until it is boring. Hold the branch experience you can stand behind, concede the two stated gaps, give a plan | B1, B2, B7; A7 (light) |
| Values / behavioural | Round 2 "mostly behavioural"; round 3 scores the four values | High. The recruiter names both | Map a story to each value where a quote carries one. Where none does, use the honest branch | B3, B4, B5; C1 to C4 |
| Case / strategist | Round 2 live problems; round 3 20-minute case and strategy questions | High in round 3, because the case is stated. Medium in round 2 | Clarify, then objective, segments, approach, metrics, risks. Use the company's own vocabulary | B6, B9; C5, C8 to C10 |
| Prober | Round 2 asks how the spreadsheet counts and which rules applied | Medium. Not in the recruiter's email, but a manager reading a CV line by line is likely | Say what the spreadsheet counted, and say when you do not know | B8, B10 |
| Peer evaluator | Round 3 branch managers ask about the seam between branches and the contact centre | Medium. Branch managers are likely peers, and the panel scores partnership | Propose seam principles, not a map. Show what you bring to their branches | C6 |

Weighting: round 2 is 45 minutes, so Skeptic and Values are weighted equally at three questions each. Round 3 is values-scored, so Values is four questions and Case is four. The totals are within the 18 to 26 range.

## Question banks

### Round 1: recruiter screen (persona: Conversational, with a light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, in the order your sentences give them: six years in retail banking, the last three as a branch supervisor; the complaints log you handled; the monthly spreadsheet your regional manager uses. Say them in your own words and stop. Do not add a beat your sentences do not carry. | Story-mapped on F1, F2 and F4. This is the strongest opening your material supports. The risk is stretching the middle beat, which is where a probe lands. |
| A2 | "Why Ashgrove, and why now?" | VAL | [generic] a view about the company, not a fact about you | Name one thing from the published values and one from the strategy brief that draws you. Say why in your own terms, under a minute. | Motivation is scored in round 1 and checked again in round 2. Generic because it asks for your view. |
| A3 | "What are your pay expectations for this role?" | JD | [generic] logistics slot | Give your own figure, or ask what band the role carries before you give one. This pack supplies no figure. | Pay is a knockout check. The only safe answer is your own number. |
| A4 | "What is your notice period?" | JD | [generic] logistics slot | Give your actual notice period in your own words. | Notice sets the earliest start the panel can offer. Only you hold this fact. |
| A5 | "Where can you work from, and how often would you need to be in an office?" | JD | [generic] logistics slot | Say the locations and days you can work. If you are unsure where the base is, ask before you answer. | Location matters more because hub consolidation is planned for 2027. Your answer is a fact only you hold. |
| A6 | "Why are you leaving your current role?" | EXP | [generic] logistics slot | Give your own reason in one or two sentences, true and forward-looking. This pack supplies none. | The recruiter's reason-for-leaving check. No reason was given, so none is written here. |
| A7 | "Contact centres run differently from branches. What's your experience of one?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then the plan, as a plan: what you would learn first and from whom. Say it once and move on. Do not reach for branch work as if it were contact-centre work. | F3. This is where the JD's end-to-end line is probed first, and a recruiter often checks it early. |

### Round 2: Head of Member Services (personas: Skeptic 3, Values 3, Case 2, Prober 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've handled a branch complaints log, you've never worked in a contact centre, and you haven't presented above regional level. This role reports to senior leaders every month. Where would you be weakest on day one?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "I've never presented to anyone above regional level." | **Highest-return rehearsal.** Hold, first follow-up: say what the branch log gave you, at its own scope, "I handled the branch's formal complaints log." Hold, second follow-up: do not fold on the core. Concede the two stated gaps exactly: "I've never worked in a contact centre," and "I've never presented to anyone above regional level." Then the plan, as a plan: learn how contact-centre complaints are logged, from the people who log them; ask to present the first monthly report alongside the Head of Member Services. Never claim contact-centre or senior-presenting experience to close the gap. | F2, F3 and F9 are the three gaps the headline JD lines hit. This objection will arrive in some form, and a rehearsed, non-defensive answer changes the interview. Deepest rehearsal in the pack. |
| B2 | "Why leave a supervisor role for this one, and why now?" | EXP | [generic] a question about your reason; [grounded] "I handled the branch's formal complaints log" for context | Give your own reason. Then say what in this role you want that the supervisor role does not give you, if that is true. Do not borrow the JD's phrase unless it is your reason. | Skeptic motivation probe. Your reason is the A6 slot. |
| B3 | "Tell me about a time you had to tell someone more senior than you something they didn't want to hear." | VAL | [generic] selection scaffold; [grounded] "I handled the branch's formal complaints log" as the nearest carried sentence | Pick a time you said something unwelcome to someone above you. Name what you said, their reaction, and what happened after. If none comes to mind, say so plainly, then give the nearest case from the log you handled. | Round 2 is mostly behavioural. Honest branch built in, because your material shows no such moment. |
| B4 | "Tell me about a complaint you stayed with until the cause was fixed, not just closed." | VAL | [generic] selection scaffold; [grounded] "I handled the branch's formal complaints log" | Pick a complaint where the cause, not only the member's outcome, was yours to follow. Say what changed and how you know. If the log recorded only closures, say so. Do not stretch the log into a root-cause record. | Maps to the Own the Fix value (section 10). The honest branch matters most here. |
| B5 | "Tell me about a time you helped someone through an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped: you trained new tellers on the escalation script. Say it at that scope, and say "trained", not "coached". If you helped a supervisor through a case, say that. If not, say so and say how you would coach a supervisor on escalations. | F6. The JD's coaching line is the question; your sentence is about tellers. Do not upgrade it. |
| B6 | "A supervisor escalates a case to you and you think they handled it wrongly. What do you do?" | CASE | [generic] rehearsal scenario | Structure: what you would check first (what the member was told, what the record says); who you would talk to; how you would give feedback that keeps the supervisor's trust; what you would write down. No claim about your past. | A live coaching problem from the JD's supervisor line. Generic because it is a pattern, not a fact about this employer. |
| B7 | "How would you report to senior leaders each month on complaint volumes and resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you would put in the report: volumes first, then resolution times, then what changed and what you would do about it. Answer slot: if your spreadsheet already showed resolution times, say what it counted. If not, say so and say what you would add first. | F4 and F5. Links directly to the senior-presenting gap in B1. |
| B8 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped: you built it, it is monthly, your regional manager uses it. Answer slot: which parts you designed and which you inherited, in your own words. If you did not design the layout, say so. If you give a figure from it, be ready to say how it was counted and which assumption you would defend least. Show structure, not member records. | Defend-the-number rehearsal for the spreadsheet, and the Excel requirement (F10). A prober's most likely first question. |
| B9 | "Our digital team wants to move complaints into self-service journeys. Where would you start?" | JD | [generic] rehearsal scenario | Structure: which complaint types can be self-served without harm, which need a person, and how you would measure whether members got an answer. Say which part you have seen in practice, if any. If none, say so and say how you would learn it from the digital team. | F7. The raising source is the JD's digital line. Generic because you have no evidence here. |
| B10 | "What rules governed the complaints you handled, and how did you keep to them?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: name the rules or timescales that applied to the log, in your words. If the log ran to no external rule you knew of, say so and describe how it was kept. Do not name a regime your sentence does not carry. | F8. The question presupposes regulated complaints, which the JD raises. The second branch lets that premise be false. |

### Round 3: panel of two branch managers (personas: Values 4, Case / Strategist 4, Peer 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a member's needs and the process pointed in different directions." | VAL | [generic] selection scaffold; [grounded] "I handled the branch's formal complaints log" as the nearest carried sentence | Pick a case where the member's side changed what you decided. Name what the process said and what the member needed. If none, say so, then give the nearest case from the log in your own words. | Members First, Always, scored by the panel. Honest branch built in. |
| C2 | "A member tells you they don't understand the letter we sent. What do you do?" | VAL | [generic] rehearsal scenario | Say the point back in the member's words. Rewrite the one sentence that confused them. Check they understand it before you close. Do not blame the member. | Plain Words, as a live scenario. No claim about your past. |
| C3 | "Tell me how being part of a town shaped a decision you made about a member." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" as the nearest carried sentence; [generic] selection scaffold | Pick a decision where the branch's place in its town mattered. If none, say so, then say how you would use local knowledge in a branch that is being consolidated. | Neighbours, Not Numbers. Your three years as a supervisor is the nearest carried sentence. |
| C4 | "Tell me about a pattern in complaints you spotted and what you did about it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the pattern only if the spreadsheet showed one. Say what you did with it and who you told. If the spreadsheet only counted, say that, then say what you would look for. | Own the Fix. The spreadsheet is the only sentence your material gives on reporting patterns. |
| C5 | "A member has complained three times about a fee on their account. Each time a branch reversed it, and it was charged again. The member now says they will take it to the ombudsman and wants a person to call them. You have twenty minutes. Walk us through how you would handle it." | CASE | [generic] rehearsal case, written for this pack and not an Ashgrove case; the four values in the guidance are the pasted values | See the time plan below. Structure: clarify, objective, segments, approach, metrics, risks. Use the four values as your lens: Members First, Plain Words in the call, Neighbours in the member's branch, Own the Fix as one named owner until solved. | The round 3 case. Scored for structure and values, not for a right answer. |
| C6 | "Our branches and the contact centre sit side by side. Where's the seam, and what happens when we disagree about who owns a complaint?" | JD | [generic] rehearsal question; the JD's "across branches and the contact centre" as the raising source | Propose principles, not a map: one owner per complaint until it is solved; one team speaks to the member; disagreements are settled by what the member needs. Do not claim to know their seam. Ask where they see it. | Peer Evaluator. Seam questions from peers are scored for partnership. |
| C8 | "Ashgrove plans to move 40% of member service to digital channels by 2028. Which complaints move with it, and which stay in the branch?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Segment complaints by type and by what the member needs. Say which can be resolved digitally without harm and which need a person, and why. No claim about Ashgrove's current complaint mix. | Strategy-linked, from the July 2026 brief. Generic judgment, not a fact about this employer. |
| C9 | "Eight branches are becoming five hubs over 2027. What happens to complaints from members whose branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Say what you would protect first: the member's contact, the case's owner, the record, and a letter in plain words. Tie it to Neighbours, Not Numbers. Do not assume Ashgrove's plans beyond the brief. | The consolidation is the strategy's most visible member effect, and it touches a value directly. |
| C10 | "App-only banks are the main competitive pressure. Why would a member with a complaint stay with us, and what would you do to earn it?" | CO | [grounded] "the main competitive pressure is app-only banks" (strategy brief) | Structure: what a member with a complaint wants (an answer, one owner, speed, a person when needed). Say where a good complaint process is a reason to stay. Name one thing you would measure. Do not claim to know how app-only banks handle complaints. | The competitive pressure is in the brief. Complaint handling is where a member-experience lead can answer it. |

**C5 time plan (20 minutes, rehearsal only)**

- 0 to 3 minutes: clarify. Ask what the fee was, what each branch recorded, and whether the member has already referred the case anywhere.
- 3 to 6 minutes: objective and segments. The objective is to resolve the member's case and stop the repeat charge. Segments: a fee-reversal error, a process error, or a staff error.
- 6 to 14 minutes: approach. Stop the repeat charge first. Name one owner. Call the member back in plain words, and say what you will do and when.
- 14 to 18 minutes: metrics and risks. Metrics: time to resolution, and repeat complaints on the same account. Risks: a referral to the ombudsman, and the branch's trust.
- 18 to 20 minutes: what you would do this week, and what you would change so it does not recur.

## Coverage: JD requirement to question IDs

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A7, B1, C6 |
| Report monthly on complaint volumes and resolution times | B7, B8, C4 |
| Coach branch supervisors on escalations | B5, B6 |
| Work with digital teams on self-service journeys | B9 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B10 |
| Confident presenting to senior leaders | B1, B7 |
| Comfortable with Excel reporting | B8 |

Every requirement has at least one question.

## Values and principles cheat sheet

Round 3 scores against the four values. Each row maps a value to a fit-snapshot row and a quoted sentence where one carries a story. Where none does, it gives a selection scaffold and the honest branch.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Scaffold: pick a decision where the member's side changed the outcome. Nearest carried sentence (F2): "I handled the branch's formal complaints log." If none, say so plainly. |
| Plain Words | If a member needs it explained twice, the letter was wrong | No quoted sentence carries a story. Scaffold: pick a letter or explanation you changed after a member did not understand it. Nearest carried sentence (F10): "I built the monthly complaints spreadsheet our regional manager uses." If none, say so plainly. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold: pick a complaint where the branch's place in its town mattered. Nearest carried sentence (F1): "6 years in retail banking, the last 3 as a branch supervisor." If none, say so plainly. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No quoted sentence carries a story. Scaffold: pick a complaint you kept until it was solved. Nearest carried sentence (F2): "I handled the branch's formal complaints log." If the log recorded only closures, say so. |

## Reverse questions

Ask at least four of these. The interviewers are not yet named, so none is tied to a path.

| Question | Why it lands |
|---|---|
| "What would make the first 90 days in this role clearly worth it to you?" (round 2) | Shows you plan around outcomes, not the title |
| "How do complaints that start in a branch and end in the contact centre get handed over today?" (round 2) | Names the seam in the JD and shows you have noticed the end-to-end problem |
| "How does the monthly complaints report reach senior leaders now, and what do they do with it?" (round 2) | Shows you are thinking about presenting, and tells you how the current report lands |
| "What could someone new in this role do in their first month that would genuinely help your branches?" (round 3, reciprocity) | Panel members are likely peers, and peers weigh this question heavily |
| "Which of the four values is hardest to keep to in a busy branch week, and what helps?" (round 3) | Puts the values in the panel's own experience, the people who score them |
| "How will the 2027 hub consolidation change which complaints reach this role?" (round 2 or 3) | Shows you have read the strategy brief, without claiming anything about it |

## Prohibited claims

These are the claims this pack will not coach, and the honest form of each. They are built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F2 | "I handled the branch's formal complaints log." The material says the log, not the process. |
| Designed the escalation script | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Built reporting that tracks resolution times | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." Whether it held resolution times is the F5 slot. |
| Coached branch supervisors on escalations | Inflated form of F6 | The tellers sentence, at its own scope. |
| Has worked in a contact centre | Negative you stated (F3) | "I've never worked in a contact centre." |
| Has presented to senior leaders | Negative you stated (F9) | "I've never presented to anyone above regional level." |

## Sources

Provided documents, all pasted into this conversation:

- The job description, as pasted.
- Ashgrove's values, copied from ashgrovecu.org/about/values on 17 Nov 2026.
- The 2026 strategy brief published in July 2026, as sent by the recruiter, pasted as its strategy lines.
- The recruiter's email on the three rounds.
- Your background, in your message.

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values were pasted from the site this morning, so they fix the cheat sheet in section 10 |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email fixes the three rounds and their lengths |
| 3. Ashgrove strategy and recent news | skipped | The pasted July 2026 brief fixes the strategy lines in section 6. News since July is not checked (upgrade menu) |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there is no query to form |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The names of the Head of Member Services and the two branch managers → persona weights from their public footprint, and reverse questions tied to their career paths. Public professional footprint only.
- The monthly complaints spreadsheet, shown without member details → rows F4, F5 and F10 can be rewritten from what it actually counts, and B8 gets a real walk-through. The spreadsheet is inspectable proof, so it can raise those rows' confidence.
- One complaint you took through to a fix, in your own words → section 10's Own the Fix and Members First rows, and answers to B4 and C1, move from scaffold to mapped story.
- Any pre-declared deliverable or case prompt from the recruiter, in advance of 26 Nov → a graded-deliverable section, if there is one.
- Deep research, offered once: up to six more searches and two more fetches, on the named interviewers' public footprint, role-family loop reports, and news since July 2026. It runs only if you say so. It would not change the case or the strategy questions, but it would update section 6.
- A tuesday-dossier.md file would carry the gaps this prep exposed (F2, F3, F9) into later sessions, with no change to this pack.
