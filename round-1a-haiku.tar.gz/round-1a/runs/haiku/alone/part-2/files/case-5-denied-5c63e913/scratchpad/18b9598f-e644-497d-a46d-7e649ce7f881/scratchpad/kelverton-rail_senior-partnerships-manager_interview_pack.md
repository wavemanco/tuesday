# Kelverton Rail: Senior Partnerships Manager, second-round panel

**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute POV on your plan for operator partnerships over 18 months, then Q&A, with Ross pushing on commercials.

*First version. Built from your message and the recruiter's email as quoted in it. No job description was supplied, and web research was refused (permission not granted), so no company values, loop structure or strategy are included.*

## How to use and type key

Personas describe how a question arrives. Types describe what it scores.

- **EXP**: what you actually did, and whether the claims survive scrutiny
- **JD**: whether you can do the stated job, gaps included
- **CASE**: a live problem, judged on structure and reasoning
- **CO**: company and strategy knowledge (none in this pack; research was refused)
- **VAL**: published values (none in this pack; no values page was supplied)

Guidance is scaffolding, not a script.

## Prep triage (about 4 hours)

1. **POV build, about 90 min.** Section 5. Pick one thesis, write its concession, say it aloud twice, and time it to 15 minutes.
2. **Commercials drill, about 60 min.** Ross's bank (B1 to B5). Answer each in 90 seconds. Rehearse B2 hardest.
3. **Deepa's bank (A1 to A4), about 45 min.** Rehearse A3 hardest: it is the likeliest hard question.
4. **Reverse questions and your opening, about 20 min.**

Everything else is insurance. Keep 15 minutes unallocated.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter email, quoted in your message) | "9 years in partnerships" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your partner work is with ISVs in payments, not train operators. Say the channel result at its own scope: "I took the ISV channel from 6 partners to 40, roughly £4M of influenced revenue." Answer slot: if any part of that partner growth was yours to set, such as how partners were chosen, say which and how you decided; if none of it was yours to set, say so and say what you did do. |
| F2 | "Please land on what it means for the operators themselves." (recruiter email, quoted in your message) | "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your operator view comes from five years of bus and light rail network planning. Say that as planning work: "I did bus and light rail network planning for five years." Do not describe it as running or selling to an operator. |
| F3 | "Ross will push on commercials." (recruiter email, quoted in your message) | "roughly £4M of influenced revenue" (your message) | low | [inferred] | presentation | Your number is influenced revenue, not revenue you closed. Say it that way. Answer slot: if you know how influence was counted, state the rule in your own words; if you don't, say you don't know how the figure was counted and what you would check. |
| F4 | Carrying a direct revenue quota (not in any supplied input; role-family prose) | "never carried a direct quota, only influenced revenue" (your message) | none for quota; the negative is yours | [grounded] | capability | Plain acknowledgment: "I haven't carried a direct quota." Then your number: influenced revenue, roughly £4M. Whether this role has a quota is unconfirmed; see question 2. |
| F5 | "they sell scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't sold into rail." Then the operator-side view from F2, at its own scope. |

## Prohibited claims

These claims will not be coached, in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Rail sales experience, or having sold to train operators | Sourced negative: "Never sold into rail specifically" (your message) | "I haven't sold into rail." |
| Carrying or hitting a revenue quota | Sourced negative: "never carried a direct quota" (your message) | "I haven't carried a direct quota. My number is influenced revenue." |
| Running operator partnerships | Inflated form of F2: your material shows network planning work, not operator partnerships | F2's quote at its own scope: "I did bus and light rail network planning for five years." |
| How the 6-to-40 growth was achieved (method, criteria, tactics) | Inflated form of F1: your material shows the result, not the method | F1's quote as the result. The method is an answer slot, not something to supply. |
| £4M as revenue you closed or own | Inflated form of F3: your material says influenced | "roughly £4M of influenced revenue" |

The pack's own observation, not words for you: your material shows results in payments partner growth and operator-side planning, and nothing on operator sales.

## Graded deliverable: the 15-minute POV

The recruiter specified a POV, no slides, with the close "what it means for the operators themselves". Build three theses. Pick one, or take the strongest parts of two.

**D1. Judge operator partnerships on operator outcomes, not partner volume.**
- Mandatory concession: operator procurement cycles may not let an 18-month plan show outcomes, so say which early signal you would use.
- Differentiation: a generic plan leads with partner count and pipeline. Lead with the operator's result (for example, disruption recovery, if you can say why that is the operator's metric). The Kelverton market report's shortlist is unread here; if you paste its shortlist, I can check this thesis against it.
- Operator close: "For the operator, the test is whether their planning team trusts the partner's changes."

**D2. Make the operator a co-owner of the integration, drawing on the planning view.**
- Grounding: F2's quote, "so I know the operator world from the other side". Say it as planning work.
- Mandatory concession: operators are stretched, and co-ownership asks for their time. Say what you would drop to make that affordable.
- Operator close: "For the operator, the planner keeps the decisions and the partner does the integration work."

**D3. Sequence partners by the operator decisions they affect, not by the pipeline.**
- Mandatory concession: "I haven't sold into rail, so I don't yet know which operators buy first." Say that plainly, then say how you would find out in the first 90 days.
- Differentiation: a sequencing plan built from operator decisions, not from deal size.
- Operator close: "For the operator, the partner arrives when the decision is theirs to make."

## Persona table

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa's live problem on the 18-month plan | High: a hiring manager buys capability and tests the roadmap; the POV already sets this up | Clarify, then structure, then metrics. Say the first measure out loud. |
| Skeptic | Deepa and Ross on the rail and quota gaps | High: the gaps are the obvious doubt | Plain acknowledgment, then the bridge at its own scope, then the plan to learn |
| Data-Driven Prober | Ross asking how influenced revenue was counted | High: the £4M figure is the number most likely to be probed | Name the attribution rule you used, or say you don't know how it was counted |
| Pressure | Ross time-boxing the commercial case | High: Ross is named as the commercial pusher | Pause, restate, hold the position through two follow-ups, then concede the quota specifically |

## Question banks

### Deepa (future manager): Case / Strategist and Skeptic, weighted highest

**A1.** "Walk me through how you'd sequence an operator partner plan over 18 months."
- Type: CASE. Provenance: [generic], since it asks about no past.
- Guidance: Clarify first: which operators, what the 18 months must deliver, what a partner is allowed to do. Then structure: segment operators by what they need first, the approach, the metrics, and the risks. Speak in 90 seconds, and say one measure you would not trust yet.
- Rationale: it is the POV's content in case form. Deepa is the hiring manager, so case reasoning carries the most weight.

**A2.** "What would you measure in year one with an operator partner?"
- Type: JD. Provenance: [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue".
- Guidance: Use the 6-to-40 arc as your reference point. Say that the operator's result comes first, then partner activity. Answer slot: if you measured partner activation in the channel, name the metric and how it was counted; if you did not, say what you would measure first.
- Rationale: F1's quote is the only evidence for measurement. The question is the JD's own territory, so the answer slot is open.

**A3. Highest-ROI prep.** "Which part of this role would you be weakest at on day one?"
- Type: JD. Provenance: [grounded] "Never sold into rail specifically" and "never carried a direct quota, only influenced revenue".
- Guidance: Plain acknowledgment: "I haven't sold into rail, and I haven't carried a direct quota." Then the bridge: "I bring the partner side and the operator planning view. On day one I'd learn how operators buy." Hold through one follow-up. Second follow-up: if asked how you'd close the gap, give the plan, not a past.
- Rationale: F4 and F5 are the two gaps this panel is most likely to test. The question is a Skeptic probe, and a calm acknowledgment with a plan beats a defensive case.

**A4.** "Why do you want to move into rail?"
- Type: EXP. Provenance: [grounded] "so I know the operator world from the other side".
- Guidance: Give the reason in your own words. If it is the operator-side view from your planning years, say that. Answer slot: if the reason is something else, say it plainly; the pack does not supply one.
- Rationale: F2 is your only motivation evidence in the material. Keep the reason to what you can stand behind.

### Ross (Commercial Director): Prober and Pressure, weighted second

**B1.** "Your number is £4M of influenced revenue. How was influence counted?"
- Type: EXP. Provenance: [grounded] "roughly £4M of influenced revenue".
- Guidance: State the attribution rule you used, in your own words, then name the assumption you would defend least. Answer slot: if you know the rule, say it; if you don't, say you don't know how it was counted and what you would check.
- Rationale: F3 is the figure most likely to be probed, and it is the one you are least able to defend.

**B2. Hardest commercial pressure.** "Sixty seconds: why should we trust a partnerships hire with no quota?"
- Type: EXP. Provenance: [grounded] "never carried a direct quota, only influenced revenue" and "took it from 6 partners to 40, roughly £4M of influenced revenue".
- Guidance: Hold: partner growth is the nearest measure you have, and the channel result is your record. Hold through two follow-ups. Concede specifically: "I haven't carried a direct quota." Do not fold on the partner growth.
- Rationale: F4 sits right under this question, and the hold-then-concede structure is the rehearsal. Do not claim more than the quotes carry.

**B3.** "Operators' budgets are tight. Who pays for your partner plan?"
- Type: CASE. Provenance: [generic].
- Guidance: Structure: which budget line the operator uses, what the partner's share is, and what the operator gets for it. Name the metric you would track first. No claim about your past.
- Rationale: a live commercial problem, with no past claim to defend.

**B4.** "What year-one revenue would you forecast on the rail side?"
- Type: CASE. Provenance: [generic].
- Guidance: Do not produce a figure. Say how you would build the forecast, which inputs you lack (the operator pipeline, for one), and when you would commit to a number.
- Rationale: F5 means you cannot forecast from experience. An honest method beats an invented figure.

**B5.** "That £4M. How much of it was actually you?"
- Type: EXP. Provenance: [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue".
- Guidance: Say which part was yours: the partner growth you ran. Say which part was shared. Answer slot: if others were part of the channel's growth, name them and say what you did; if the growth was not yours to lead, say so plainly.
- Rationale: this is the attribution test for F1 and F3, and the honest answer is the one that survives the next follow-up.

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| POV: operator partnerships over 18 months | D1 to D3, A1 |
| What it means for operators | D1 to D3 closes, A4, F2 |
| Commercials | B1 to B4 |
| Quota ownership (not yet confirmed) | A3, B2, question 2 |
| Rail sales (your gap) | A3, F5 |
| Partner growth (your strongest evidence) | A2, B1, B5 |

## Reverse questions

1. "What would a strong first 90 days look like in this role?" Why it lands: it gives Deepa room to say what she needs, and shows you are planning.
2. "Which operators would the first partnership conversations be with, and why those?" Why it lands: it shows you already want the operator view.
3. "How does the commercial team credit partners' contribution: direct revenue, influenced revenue, or both?" Why it lands: it asks about the exact gap in a way that gets information, not defensiveness.
4. "What did your best hires in this team do differently in their first year?" Why it lands: it asks what good looks like without assuming anything.
5. "What would make you say in six months that this hire was a mistake?" Why it lands: it invites the concern directly, and an honest answer lets you address it.

## Sources

- Provided: your message, which includes the recruiter's email as quoted.
- Not provided: job description, Kelverton market report text, interviewer profiles.
- Research tier: L1, searches 0 of 6 (3 sent, all refused: permission not granted), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet (none in this pack). Search refused. |
| 2. Kelverton Rail interview process, Senior Partnerships Manager | unavailable | Loop structure (none in this pack). Search refused. |
| 3. Kelverton Rail strategy and recent news | unavailable | Grounding brief and CO questions. Search refused. |
| 4. Deepa and Ross, public footprint | unavailable | Interviewer read and persona weights per member. No search sent. |
| 5. Representative role JD | unavailable | Would have sourced the requirement rows as [inferred]. No search sent. |

## Upgrade menu

- The job description text → requirement rows become [grounded], and the JD-tagged questions get their wording from the posting
- Your answer to question 2 on quota → F4 and A3 are confirmed or reworded
- Permission to use web search → company values, loop structure, current strategy and the interviewers' public background
- The market report's text (you read it) → checks D1 to D3 against its shortlist for differentiation
- Deepa's and Ross's public profiles, if you share their names and roles → persona weights per interviewer and a reverse question tied to their career path
