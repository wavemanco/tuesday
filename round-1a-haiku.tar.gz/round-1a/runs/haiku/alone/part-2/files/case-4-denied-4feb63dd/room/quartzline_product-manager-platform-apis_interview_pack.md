# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday 2026-11-19
**Interviewer:** not named. Persona weights use round-type priors only.
**Built from:** your underwriting dossier (`tuesday-dossier.md`, dated 2026-08-14, decision conditional_go). This is the first version, so there is no changelog.

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored: **JD** (the listed job), **EXP** (your own record), **CASE** (a live problem), **CO** (company knowledge), **VAL** (values).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse out loud, in your own words, and stop at what you actually did.
- Provenance labels: **[grounded]** traces to your dossier or the supplied role text. **[inferred]** is a derivation from it. **[generic]** is a pattern for the problem, not a fact about you or Quartzline.

## Prep triage (about two days)

1. **A1**, the objection the underwriter named. Rehearse it aloud until the acknowledgment, the scoped bridge, the limit and the ramp plan come out in that order. This is the highest-return item in the pack.
2. **C1**, the "30-plus" figure. Prepare the four defend-the-number answers (how counted, what it is sensitive to, weakest assumption, which part was yours).
3. **F3 and A2**, the shipped-product question. Decide now what your honest answer is, whichever branch it takes.
4. **RQ1 and RQ2**, the two employer questions the dossier flagged. Say them word for word.
5. Write the ramp plan (A1 step 4) as a plan, not a past. Say it once aloud.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | low | [inferred] | transferability | Adjacent, not PM. Say the integration work at its own scope: it covers scoping and requirements, not a product-manager role. Limit, as this pack's observation: no PM title or PM role is in your material. |
| F2 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities) | none given | none | [grounded] | capability | Plain acknowledgment, sourced to dossier prohibited_claims and the acknowledge_gap area: "I haven't owned a product roadmap." Then a ramp plan, said as a plan. No bridge, and no answer slot. |
| F3 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | low | [inferred] | discovery | Your material shows integrating other teams' APIs for clients. It does not show shipping an API or platform product. Answer slot: if you shipped one, say what it was and your part in it; if you did not, say so plainly and stay with the integrations at their own scope. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook her team uses" — dossier row | high | [grounded] | discovery | Playbook is inspectable; whether it reached API docs or schemas is not shown. Answer slot: if schemas or API documentation were in it, say which; if not, say what it covered. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | medium | [grounded] | presentation | Say the two quotes in their own terms: client integrations from scoping to go-live, and roadmap-input sessions to product. Confidence is medium, so expect a probe. Limit, as this pack's observation: engineering and sales are not named in your material. |
| F6 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | Clarify, not bridge. Your material does not show agile delivery. Answer slot: if you ran agile delivery with engineers, say how and your part; if not, say so plainly and say how you would learn the squads' cadence first. |

Decision: conditional_go. No hard gates in the dossier, so no gate rows.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap | Top. Hiring-manager prior. The dossier names the objection | Rehearse the objection until it is plain; scoped bridge; concede the roadmap explicitly | 5 (A1 to A5) |
| Case/Strategist | Live problems on the roadmap and partner adoption | Top. Hiring-manager prior: they are buying capability and checking the gaps | Clarify, then structure, then metrics; name what you would confirm first | 5 (B1 to B5) |
| Data-Driven Prober | Asks how the 30-plus figure and the playbook were used | Mid. Medium-confidence evidence (F5) and a headline figure (F1) | Name the counting rule, the weakest assumption, and which part was yours | 3 (C1 to C3) |
| Pressure | Time-boxed challenge on ownership | Mid. The dossier's objection is a pressure line in practice | Hold through two follow-ups, then concede the specific gap | 3 (D1 to D3) |
| Conversational | Walk-me-through opener and a casual probe on the JD's tools | Low. Casual, but scored | A 90-second arc; treat the casual tools question as scored | 2 (E1 to E2) |

Session total: 18 questions, within the 18 to 26 range.

## Question banks

### Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row; acknowledgment sourced to dossier prohibited_claims ("Having held a product manager title or role", "Having owned a product roadmap") | 1. Acknowledge in one sentence: "I haven't held a product manager title, and I haven't owned a product roadmap." 2. Bridge at the quote's scope: "What I've led is 30-plus end-to-end client integrations of the vendor's REST APIs, from scoping and requirements through go-live." 3. Name the limit: "That is delivery of integrations, not setting a roadmap or prioritising a squad." 4. Ramp plan, as a plan: "In the first 90 days I'd want to learn how the two squads set priorities and where partner pain sits before I propose anything." Hold through two follow-ups by returning to the integration scope. Concede the roadmap and squad authority explicitly on the third. | The underwriter named this as the most likely objection, derived from evidence you confirmed. It is asked as written because every negative in it has a dossier source. This is the highest-return rehearsal in the pack. |
| A2 | "Have you shipped an API or platform product yourself?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | Answer slot (F3): if you shipped one, say what it was and your part; if you did not, say so plainly, then give the integrations at their own scope. Do not stretch "integrations" into "shipped". | R2 is a must-have, and F3 is discovery, so the probe is likely. |
| A3 | "How have you run agile delivery with engineering squads?" | JD | [grounded] JD requirement "Agile delivery experience" (dossier role_profile R5) | Answer slot (F6). The question presumes agile delivery; if you ran it with engineers, say how and your part. If not, say so plainly and say how you would learn their cadence first. | R5 is preferred and clarify-only. The question presumes a practice your material does not show, so the second branch must stay open. |
| A4 | "Which of engineering, sales or customers would you have to win over first for a partner-API change, and how would you do it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row | Customers: the integration scope above, in those words. Product: the roadmap-input sessions, in those words. Engineering and sales: answer slot (F5). If you worked with either on those integrations, say how and your part; if not, say so plainly and say how you would approach engineering first. | R4 is important, and F5 is presentation. The engineering and sales gap is this pack's observation, not a claim about you. |
| A5 | "Why this role, and why now, after integration work rather than a PM track?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | Your motivation is not in your material. Answer slot: say what the integration work taught you that you want to act on, in your own words, and tie it to the partner-facing API. If the answer is not in your material, say so. | The skeptic's motivation probe. The slot keeps your reasons yours. |

### Case/Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd decide which partner-API adoption problem gets next quarter's roadmap slot — what do you need to know first?" | CASE | [generic] | Clarify first: what counts as adoption, which partners, what the squads already carry. Then objective, segmentation, approach, metrics, risks. Speak it in 90 to 120 seconds. | Own-the-roadmap responsibility in the role. Generic, because no company facts were supplied. |
| B2 | "Partner API adoption dropped 20 percent last month. Diagnose it." | CASE | [generic] | Before diagnosing, ask how adoption is measured and what the baseline is. Then segment and test the measurement itself. | The dossier names adoption metrics and their baseline as unknown. The case should surface that question on its own. |
| B3 | "Two squads, one roadmap, and a partner who wants a feature neither squad has capacity for. What do you do this week?" | CASE | [generic] | Name decision rights first: who decides between the squad leads. Say you would confirm that before trading scope. Structure before answering. | Decision authority over the squad leads is the dossier's top unknown. |
| B4 | "What would you measure to tell whether Quartzline's partner API works for partners rather than for internal teams?" | CO | [generic] | Pick one measure and name its weakest assumption. Make no claim about Quartzline's current strategy. | Company research was refused in this session, so this question stays generic and is labelled as such. |
| B5 | "Outline the spec for the first partner-facing API change you'd prioritise — what goes in it?" | JD | [generic] | Schema, versioning, documentation, deprecation path, acceptance criteria. Say the structure aloud. Make no claim about past specs. | R3 (API docs and schemas) needs a live answer, not a claim. |

### Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30-plus integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | Answer slots, each in your own words: how it was counted; what the count is sensitive to; the assumption you would defend least; which of the 30-plus you led end to end. If no counting rule was written down, say so. Do not supply a method. | The headline figure, so a defend-the-number probe is likely. The figure is yours; the method is not in the material. |
| C2 | "What does the integration playbook cover, and how did your team use it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier row | Story map: "I wrote the playbook, and the team uses it." Then the answer slot from F4 on schemas and API documentation. | F4 is discovery on R3, so this is where the probe lands. |
| C3 | "What did you bring to product from the quarterly roadmap-input sessions, and how would you tell whether it was used?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row | Say what you ran and what fed to product, in those words. Name the caveat yourself: your material shows the sessions, not a measured effect. Answer slot: if you saw a change, say what changed and how you knew; if you did not track it, say so. | Medium confidence, so a probe is expected. This also touches the adoption-baseline unknown. |

### Pressure (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That's a lot of integrations. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | Hold: "I led them end to end, from scoping through go-live." Concede what your team did and name the parts you led personally. Hold two follow-ups before conceding anything specific. | A pressure stem that tests attribution. Holding the quote's exact scope is the defence. |
| D2 | "You've never owned a roadmap. Convince me integration work transfers to owning one." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row; plain acknowledgment sourced to dossier prohibited_claims ("Having owned a product roadmap") | Hold: "The transfer is at the requirements level — scoping and requirements — and I haven't owned a roadmap." Concede the roadmap explicitly on the second follow-up. | A pressure version of A1. It rehearses the hold for someone who has already heard the acknowledgment. |
| D3 | "Your ramp plan sounds like a list. What's the first decision you'd make without the squad leads' sign-off?" | JD | [generic] | Say plainly that you would not make a squad priority decision alone until the boundary is confirmed. Then ask for the boundary. Claim no authority. | Squad authority is unknown in the dossier, so this probe is likely. |

### Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how you got from client integrations to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row; "Wrote the internal integration playbook her team uses" — dossier row; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row | A 90-second arc: integrations (scope as quoted), the playbook, the roadmap-input sessions. Close with the bridge sentence from A1. Do not say you moved into product. | The likeliest opener. It is scored casually. |
| E2 | "What are you actually playing with in partner APIs these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row | Answer slot (F4): if you have used a partner-API tool recently, name it. If not, name the ones you worked with in integrations. | A casual R3 probe. Treat it as scored. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| R1 "3+ years product management experience" (must-have) | A1, D2 |
| R2 "Shipped API or platform products" (must-have) | A2 |
| R3 "API docs, schemas" (important) | B5, C2, E2 |
| R4 "Stakeholder management across engineering, sales, customers" (important) | A4, C3 |
| R5 "Agile delivery experience" (preferred) | A3 |
| Own the roadmap (responsibility) | B1, B3 |
| Adoption metrics (responsibility) | B2, RQ2 |

Every hard requirement has a JD question. No requirement is uncovered.

## Reverse questions

Each has a "why it lands". No interviewer profile was supplied, so none is tied to the interviewer's path.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it asks the dossier's top unknown directly, and it reads as diligence.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: it asks the second unknown, and the answer changes B2 and your first-90-day plan.
3. **"What would have to be true at the end of the first 90 days for this hire to have worked?"** Why it lands: it gives you their success criteria, so your ramp plan can match them.
4. **"Which partner integration is causing the most pain right now, and which team is on it?"** Why it lands: it tests whether integration delivery is the real need, which is the whole case for the bridge.
5. **"How is agile delivery run across the two squads, and who sets the cadence?"** Why it lands: it checks the R5 gap and shows whether the process has a PM owner.

## Prohibited claims

This pack will not coach any of the following. Each row gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap area | Plain acknowledgment: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot. |
| Shaped the product roadmap through the roadmap-input sessions | Local inflated form of "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quote at its own scope. This pack's observation: your material says you fed client evidence into product's work, not that you set its roadmap. No first-person negative. |
| Owned the 30-plus integrations | Local inflated form of "Led 30+ end-to-end client integrations" | The quote at its own scope: "Led … end-to-end." C1 asks which of them you led end to end, and stays inside that. |

## Sources

- **Dossier consumed:** `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14, decision conditional_go).
  - `role_profile`: supplied the JD tier (requirements R1 to R5, responsibilities, unknowns).
  - `handoff_to_mock_interview`: supplied the verified evidence quotes, the weak-area strategies, the likely objection (A1), the risks and employer questions (RQ1, RQ2), and the prohibited claims.
  - `decision`: context only.
  - The pasted dossier has no `evidence_map` or `evidence_state`. Confidence and gap types for F3 to F6 are this pack's own grading from the verified quotes, labelled `[inferred]`.
- **Dossier age:** dated 2026-08-14, about three months before this pack. See the upgrade menu.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. Search permission was not granted in this session, so no search ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline company values` | unavailable | Values section. Not produced: no values-style round was detected. Query sent: "Quartzline company values", refused. |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure. Not sent: search was refused for target 1, so no further search was tried. This is a single session, so it would not change the persona weights. |
| 3. `Quartzline strategy` / recent news | unavailable | CO coverage: B4 would have been grounded in current strategy. Query sent: "Quartzline partner API platform", refused. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there is no query to form. |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the requirements and JD-tagged questions. |

## Upgrade menu

- The interviewer's name → a tailored reverse question, persona weights from their public footprint, and an interviewer read.
- The current posting, if it has changed since August → rechecks F1 and F2, which quote the requirement wording from the dossier.
- Search access → grounded company strategy for B4, and a values check. Targets 1 and 3 above would run.
- Deep research (L2), offered once: strategy brief, interviewer writing, recent organisation context. It needs search access and adds six searches and two fetches.
- Your answers to the answer slots (F3, F4, F6, A2, A3, C1, C3) → each answer you can give from your own experience upgrades its row. Write them as you would say them, and the pack will quote them.
- The employer's answers to RQ1 and RQ2 → sharpen B2 and B3, and the decision-rights slot in D3.
