# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, relationship not yet confirmed. Built on a hiring-manager prior (see Persona table). Web research was refused in this session, so company values, loop structure, current strategy and the interviewer's background are not established. Anything about the company is labelled [generic].

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the shape, then answer in your own words.

- **JD**: can you do the listed job, including its gaps
- **EXP**: does what you did survive scrutiny
- **CASE**: structure and reasoning on a live problem
- **VAL**: does past behaviour show a value (none researched here, so these are generic)
- **CO**: company and strategy knowledge (none in this pack, because research was refused)

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message. Rows F1 to F9 are the pool every other section draws on.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your message gives one title and a weekly content-drop calendar, not live events across two titles. Words: "I ran the weekly content-drop calendar for our main title for two years." Answer slot: if you planned events across more than one title, say so; if you did not, say what you did for the one title and what you would do first for the second. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show how you coordinated functions. The JD says coordinate, not lead. Answer slot: name the functions you worked with on a content drop and the decision you drove; if the drop was coordinated by someone else, say so and say what you did inside it. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is not owning the KPI set; do not stretch it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers were reported, or ran a post-event review, say so; if not, say who did and what you presented. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Keep the verb: you wrote it, and QA still uses it. Do not expand it into running the sign-off process. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years meets the length. Your message does not say the title was live-service. Answer slot: say what the title's release schedule was; the weekly content drops you ran are the evidence, in those words. If it did not run a continuous schedule, say so. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Direct. Use the quote's terms: one title, weekly, two years. Expect a probe, because nothing can be inspected here. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Words: "I presented the monthly retention numbers to the studio head." Answer slot: how the figures were counted, which assumption you would defend least, and which part was yours. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | One artifact in continued use. Expect a probe. Bank A, question A6, is a live writing test. |
| F9 | in-app purchase or monetisation experience (no JD line; role-family expectation) [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A stated absence; wording cannot close it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. |

**Gates:** the JD states no location, schedule, right-to-work or licence requirement, so no row is a hard gate.

## Prohibited claims

Not coached, anywhere in this pack. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Any team leadership | Sourced: your stated negative, "Never led a team" | "I haven't led a team." No answer slot on this. |
| Owned the post-event review and the KPIs | Inflated form of F3 | F3's quote at its own scope. Pack observation, not words for you: your material says you presented the numbers. |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Pack observation: your material says one title's content drops. |
| In-app purchase or monetisation experience | Sourced: your stated negative, in F9 | "I haven't worked on a game with in-app purchases." No answer slot on this. |
| Defined the retention metrics | Inflated form of F7 | F7's quote at its own scope. Pack observation: your material says presented. |

## Persona table

No relationship was given. This pack uses the hiring-manager prior: they are buying capability and checking gaps against the JD. Weights: Case/Strategist 6 questions, Skeptic 4, Data-Driven Prober 3, Pressure 3, Values 2, Conversational 2, Peer 2. Values is kept low because no values round was established.

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live plan or a metric drop, from the JD's own calendar and KPI lines | High: hiring managers buy capability through live problems | Clarify, then structure, then answer. Name the first check. |
| Skeptic | "Where's the gap?" on scope, KPIs and in-app purchases | High: F1, F3, F9 are the visible gaps | Hold the quote, concede the scope gap in one sentence, name the first move. |
| Data-Driven Prober | Asks how a figure was counted | Medium: the retention presentation invites it | Say how it was counted only if you know; otherwise say so. |
| Pressure | "Why hire someone who has never led a team?" | Medium: a 60-minute round often includes one hard challenge | Hold, then concede specifically. Never fold on what you ran. |
| Values / Behavioral | Open prompts for unpopular truths | Low: no values round established | Pick a story with a named stake; if none, say so and give the nearest. |
| Conversational | "Walk me through the journey" | Medium: a casual opener is still scored | A 90-second arc from your quoted sentences only. |
| Peer Evaluator | Seams with design and art | Low to medium: the JD's coordination line | Propose seam principles; name who owns each date. |

## Question banks

Banks are ordered by weight. Provenance carries every sentence the guidance rests on. Types are listed; a question marked [generic] is a pattern, not a claim about Saltmarsh.

### Bank A: Case/Strategist (weight 6)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You inherit live events for two of our titles. Walk me through your first 30 days." | CASE | [generic] | Clarify first: which title is healthier, what the calendar already commits, which team is the bottleneck. Then learn, assess, and only then build. Name the two or three numbers you would read first and why. Claim nothing about your past. | JD line "Plan and run the live-events calendar for two of our mobile titles" raises it. Live problem, so it presupposes nothing about you. |
| A2 | "Day-seven retention dropped 15% after the last update. Diagnose it." | CASE | [generic] | Clarify the metric and the cohort; split by platform, app version and segment; separate the update effect from seasonality and any other release that week; name the first check. Do not guess a cause before splitting. | JD line "own the post-event review and the KPIs it reports" raises it. A structure test. |
| A3 | "You coordinate design, art, engineering and community on every update without managing them. How do you get one out the door?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); "Never led a team, and never worked on a game with in-app purchases." (your message) | Scaffold: name the decisions coordination needs (scope, dates, sign-off owners), the escalation path, and the first conversation you would have with each function. Answer slot: if you coordinated across functions on the content drops, name the functions and the decision you drove; if others coordinated them, say so and say what you did inside them. Plain acknowledgment, if asked about leadership: "I haven't led a team." | F2 has no evidence, so this is a scaffold. The JD asks for coordination, not leadership. |
| A4 | "Walk me through how you ran the release checklist with QA." | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped on F4: you wrote it, and QA still uses it. Beats: why it was written, what it covers, how QA uses it today. Answer slot: if you set the sign-off gates, say which and why; if QA or someone else set them, say so and keep to what you wrote. | F4 is the release-checklist requirement. Premised only on the quote. |
| A5 | "Two titles, updates every two weeks, and QA is the bottleneck. What changes in the calendar?" | CASE | [generic] | Options in order of cost: lock freeze dates, risk-tier updates so small changes skip full QA, cut scope before the freeze, add QA capacity. Pick one and say what you would measure. | JD line "manage the release checklist with QA" raises it. The checklist is not presupposed. |
| A6 | "Give me the first two sentences of a post-event review for an update that missed its retention target." | JD | [generic] | Lead with the outcome and the one cause you can support; name the number and its window; state what you don't know yet. Two sentences, no hedging stack. | Covers JD "clear written communication", which no quote carries as a live test. A writing exercise, with no claim about your past. |

### Bank B: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run a content-drop calendar for one title. This role plans live events across two. What's the gap, and how fast do you close it?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | **Highest-ROI prep in this pack.** Hold on the quote: "I ran the weekly content-drop calendar for our main title for two years." Then concede the scope difference out loud, in one sentence: one title, weekly drops, against two titles' live events. Hold through two follow-ups by returning to what you ran. Answer slot: if you planned events across more than one title, say so; if not, say what you would do in the first month to close it. | This objection is most likely here: F1 is transferability, and the JD's scope sits exactly on it. The deepest rehearsal goes here. It never claims more than the quote carries. |
| B2 | "The JD says you'd own the KPIs. You presented retention numbers. Who chose which numbers went in the deck?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the quote. Answer slot: if you chose which numbers were reported, say which; if someone else did, say who and what you presented. Do not claim ownership of the KPI set. | F3, a transferability gap. The question is premised on the quote only; ownership is the JD's line, raised as a probe. |
| B3 | "You've never worked on a game with in-app purchases. Why should we take that on?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what transfers: the calendar and the retention work, in those words. Then how you would learn the monetisation side, as a plan. Never claim monetisation knowledge. | F9, a stated capability gap. The JD does not mention in-app purchases, so this probe is an expectation of the role [generic], but the premise comes from your own stated negative. |
| B4 | "Three years of live-service is in the JD. Four years at a puzzle studio: was that live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Answer slot: say what the title's release schedule was. The weekly content drops you ran are the evidence, in those words. If it did not run a continuous schedule, say so plainly and say what you ran instead. | F5, a transferability gap. The JD's "live-service" line is the raising source. |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: how the figures were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. If you do not know how they were counted, say so plainly. | Defend-the-number slot from F7. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the weakest assumption you know of, in your own words, before they find it. If you did not see how the figure was counted, say so: you can name an assumption only if you check. Do not invent one. | The metric move: it converts a gotcha into credibility. |
| C3 | "When you ran the content-drop calendar, how did you know a drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Answer slot: if you measured drops against a metric, name the metric and how it was counted; if you did not measure per drop, say so, and say what you did watch. | Probes attribution on the JD's content-calendar requirement (F6). |

### Bank D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Hold: "I haven't led a team." Then what you did run: the weekly calendar and the checklist, in those words. Hold through two follow-ups. Concede specifically: you have not managed people. Never claim it. | F2 and the prohibited list. Tests composure, not content. |
| D2 | "That's a content calendar, not live operations. How much of the outcome was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold: say what you ran and what it did. Concede the parts of the outcome you did not set, in one sentence. Never fold on "I ran". | Attribution pressure. |
| D3 | "Why should we take a risk on someone with a smaller scope than this role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Hold four years and one title. Concede the scope gap in one sentence, then name the first thing you would do. | F5 and the scope gap. |

### Bank E: Values / Behavioral (weight 2, generic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, the moment you did not soften it, and a working relationship intact afterwards. If the retention presentation carried such news, use it in those words. If not, say so plainly, then give the nearest thing your material carries, or how you would handle it. Do not supply the ending. | Open prompt. No company value is quoted, because values were not researched. |
| E2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Name a time the player experience and a metric pulled apart, and what you chose. If none comes to mind, say so, then give the nearest. Do not supply the outcome. | Persona stem. Generic until values are researched. |

### Bank F: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | A 90-second arc from quoted sentences only: the studio and the role, the two years on the weekly calendar, the checklist, the retention presentations. Keep it short. | Casual openers are scored. |
| F2 | "What live game are you playing right now, and what does its calendar do well?" | JD | [generic] | Name a live game you actually play and one thing its update cadence does well. Only what you really play. | A casual JD plus-skill question. No claim about your past. |

### Bank G: Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design and art sit beside the calendar. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their org: decisions named up front, one owner per date, disagreements taken to the cadence meeting. For a disagreement story, your material carries none; say so, then say how you would handle it. | The JD's coordination line is the raising source. |
| G2 | "How do you handle credit when a content drop spans teams?" | VAL | [generic] | Name the drop, the checklist, and who wrote what. Credit people by name for their work, and keep your own part exact. | Peer probe on collaboration. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A5, B1 |
| Coordinate design, art, engineering and community | A3, G1, G2 |
| Own the post-event review and the KPIs | A2, B2, C1 |
| Manage the release checklist with QA | A4, A5 |
| 3+ years producing live-service games or apps | B4, D3 |
| Experience running a content calendar | C3, F1 |
| Comfortable with player-retention metrics | C1, C2 |
| Clear written communication | A6 |
| Not in the JD, but the probable gap: in-app purchases | B3 |

Every JD requirement has at least one question. None is uncovered.

## Reverse questions

1. **"What does a good first 90 days look like for this role?"** Why it lands: shows you plan for outcomes and asks for the scorecard.
2. **"Which of the two titles needs the most help right now, and why?"** Why it lands: shows you think in titles, not in generalities.
3. **"How is the post-event review run today, and who reads it?"** Why it lands: probes who owns the KPI reporting, which is the JD's own line.
4. **"Are monetisation and the live calendar planned together, or by separate teams?"** Why it lands: turns the in-app purchase gap into a question about how the studio works, not about your past.
5. **"What would make a release checklist that QA trusts?"** Why it lands: asks about the checklist you already wrote, from the side of the team that uses it.
6. **"What path brought you into live operations, and what did you change first?"** Why it lands: a generic path question, since the interviewer's public background was not established. It invites a conversation rather than an interrogation.

## Sources

Provided documents: the JD text, and your background message.

**Research tier: L1 — searches 4 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet dropped (no published values in hand). Query "Saltmarsh Games values" sent; refused: web search permission not granted. |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Loop structure unknown, so persona weights rest on the hiring-manager prior. Query "Saltmarsh Games interview process live operations producer" sent; refused. |
| 3. Saltmarsh Games strategy / recent news | unavailable | No CO bank and no current-strategy questions. Query "Saltmarsh Games mobile studio strategy news" sent; refused. |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Interviewer read dropped; reverse question 6 is generic. Query "Tobias Wrenfield Saltmarsh Games Head of Live Operations" sent; refused. |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

No fetches were attempted. No query returned a result.

## Upgrade menu

- Permission to use web search → company values mapped to stories (a values cheat sheet), the interview loop (a tailored round structure), current strategy (CO questions), and Tobias's public background (a tailored reverse question and persona weights).
- Your answer to the round question → the persona weights and the bank order.
- The recruiter's note on format → whether any deliverable, such as a presentation or take-home, is pre-declared; if so, a build section.
- The names of the two titles → A1 and B1 can name them, which turns the scope question into your own specifics.
