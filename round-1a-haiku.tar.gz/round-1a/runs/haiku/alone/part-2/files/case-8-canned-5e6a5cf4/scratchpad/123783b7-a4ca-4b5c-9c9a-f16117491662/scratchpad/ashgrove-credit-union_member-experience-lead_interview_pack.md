# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Interviews:** 26 November 2026, three rounds (loop mode)
**Round 1:** 30 min, recruiter. **Round 2:** 45 min, Head of Member Services (your future manager), mostly behavioural. **Round 3:** 60 min, panel of two branch managers, including a 20-minute complaint-escalation case; scored against the four values.
**Interviewers:** Round 2 is the Head of Member Services. Round 3 names are not yet known. No interviewer profile exists, so there is no interviewer read.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values, **EXP** your own work, **JD** the listed job, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.
- Provenance: **[grounded]** traces to your message, the JD text, the values text or the recruiter's email. **[inferred]** is this pack's derivation. **[generic]** is a pattern with no claim about you or Ashgrove.
- Answer slots (lines that say "if you did… / if not, say so") are instructions for the interview. They are not questions to answer here.

## Fit snapshot (shared across all rounds)

Sources: "your message" is the background you gave me. "JD" is the JD text in your message. No CV was supplied, so every quote is from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material shows one branch's complaints log. Words: "At branch level, I handled the formal complaints log." Answer slot: if you owned any step beyond the log, say which and how you decided; if you did not, say so plainly and stay with the log. |
| F2 | "across branches and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence, so the words are yours: "I've never worked in a contact centre." Then how you would learn contact-centre operations, said as a plan, never as a past. |
| F3 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence: "I've never presented to anyone above regional level." Then how you would build that skill, said as a plan. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | low | [inferred] | discovery | The spreadsheet is real, but your material does not say what it counts. Answer slot: if it counted complaint volumes or resolution times, say which and how; if it did not, say so plainly and say what you would report first. |
| F5 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message); "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script, and for the last 3 of my 6 years in retail banking I was a branch supervisor." Limit: your material shows training tellers, not coaching supervisors. Answer slot: if you coached a supervisor on an escalation, say what happened in your words; if you did not, say so and describe how you trained tellers. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in your material touches this. Answer slot: if you have worked with a digital team on a self-service journey, say who and what changed; if not, say so plainly and describe how you would approach one, as a plan. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." Expect a probe on the tool: your material does not name it, so say what you used only if you can say it accurately. |
| F8 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | Closed. Retail banking covers the experience length; the requirement is an experience length, not a gate. |
| F9 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | discovery | "Formal" is not shown to mean regulated. Answer slot: if the log was held to a regulatory rule or timeline, say which and how you applied it; if it was not, say so plainly and say how the log was kept. |

Gate rows: the JD names no licence, location, schedule or credential gate, so none is surfaced.

Reading the table: F2 and F3 are the two stated absences, the largest honest gaps. F1 and F5 are real but adjacent. F4, F6 and F9 are where the material is silent, so they are answer slots.

## Prohibited claims

These are the claims this pack will not coach. Each is an inflated form of something you said, or a claim you did not make.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1, and F2's stated absence | "At branch level, I handled the formal complaints log." Plus "I've never worked in a contact centre." Pack observation (analysis only): your material shows the branch's log, not the whole process. |
| Presented to senior leaders | Stated absence, F3 | "I've never presented to anyone above regional level." No answer slot about it. |
| Owned monthly reporting of volumes and resolution times | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." F4's slot covers what it counted. |
| Coached branch supervisors | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Built the spreadsheet in Excel | Inflated detail: the tool is not stated, F7 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Grounding brief (strategy and values)

Source: your summary of Ashgrove's July 2026 strategy brief, and the values text you copied on 17 November 2026. The full brief was not pasted, so the wording below is your summary, not the document. Check the exact wording before quoting it in the room.

| Fact | Provenance | Why it matters for these rounds |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] your summary of the July 2026 brief | Relevant to F6 and to how complaint volumes may change. Ask what it means for complaints; do not supply a number. |
| Consolidate eight branches into five hubs over 2027 | [grounded] your summary of the July 2026 brief | Branch managers on the panel may be living this. Ask how the hubs will keep members close, not whether a branch is closing. Your brief does not say which branches move, so do not guess in the room. |
| Launch a small-business lending product in Q1 2027 | [grounded] your summary of the July 2026 brief | Complaint processes may extend to a new product. Use only if the panel raises it. |
| The main competitive pressure is app-only banks | [grounded] your summary of the July 2026 brief | Use the phrase accurately. Do not claim knowledge of their complaint processes. |
| "Members First, Always", "Plain Words", "Neighbours, Not Numbers", "Own the Fix" | [grounded] values text copied 17 November 2026 | The four values the panel scores. Map them in the cheat sheet below. |

The brief is four months old. Check for newer announcements before 26 November (see upgrade menu).

## Values cheat sheet (Round 3 scoring)

The panel scores against the four values. No quoted sentence of yours carries a story for any value, so each row is a selection scaffold ending in an honest branch. A real story from you would replace it.

| Value | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always [grounded: values text] | Decide from the member's side of the counter. | Scaffold: pick a time a member's situation made you decide differently from the usual rule. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal complaints log (F1), and what the member's side of it was. |
| Plain Words [grounded: values text] | If a member needs it explained twice, the wording was wrong. | Nearest thing: the escalation script you trained tellers on (F5). Scaffold: if you changed how something was worded for members, say what changed; if you did not, say so and describe how you taught the script. |
| Neighbours, Not Numbers [grounded: values text] | Every branch is part of its town. | Tension to prepare for: your spreadsheet is numbers (F4). Scaffold: if you ever changed something for one branch's customers, say what it was; if not, say so, and say how you would learn what a town needs. |
| Own the Fix [grounded: values text] | Whoever finds the problem keeps hold of it until it is solved. | Nearest thing: the formal complaints log (F1), which you handled. Scaffold: a complaint you kept through to its end. If it was closed by someone else, say so, and say what you did in the meantime. |

## Persona weights by round

| Round | Persona | Weight | Reasoning |
|---|---|---|---|
| 1 Recruiter, 30 min | Conversational / Rapport Builder | Top | Recruiter register. Logistics questions are knockout checks, not small talk. |
| 1 | Skeptic (light) | Mid | Motivation consistency and why this role, why now. |
| 2 Head of Member Services, 45 min | Skeptic | Top | A future manager buys capability and derisks gaps (F2, F3). |
| 2 | Data-Driven Prober | Mid | Monthly reporting (F4) and the spreadsheet (F7). |
| 2 | Case / Strategist | Mid | A live hub problem from the brief. |
| 2 | Values / Behavioural | Low | Values are scored in Round 3, so Round 2 has one. |
| 3 Panel, 60 min | Values / Behavioural | Top | The panel is the values round. Four values, one question each. |
| 3 | Case / Strategist | Mid | The 20-minute escalation case. |
| 3 | Peer Evaluator | Mid | Two branch managers are peers of the future team. Seams and coaching. |

## Round 1: Recruiter screen (6 questions)

Round 1 is 30 minutes, so it carries 6 questions. The session total stays inside 18 to 26 (20 across three rounds).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in your own words: retail banking, the branch supervisor years, the complaints log, the training, the spreadsheet. Do not add a result you did not state. | Rapport question scored for communication economy. Each beat is a sentence you gave me. |
| A2 | "What are you looking for in pay?" | JD | [generic] | Logistics slot. Give your own figure or range, or ask for the band first. | Pay is a knockout check. The pack supplies no figure. |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot. Give the notice you actually owe. | Notice is a logistics check. The pack supplies no figure. |
| A4 | "Where would you be based, and how often on site?" | JD | [generic] | Logistics slot. Give your own constraints. If the posting does not say the office pattern, ask for it. | Location is a logistics check. The JD does not state a pattern. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot. Give your real reason in your own words. You have not given me one, so the reason is yours to supply. | Reason for leaving is a recruiter staple. The pack supplies no reason. |
| A6 | "Why this role, and why now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Speak to the parts of the JD that match your work (complaints, escalations, reporting) in your words. Do not claim interest in a part of the role you have not described. | Motivation consistency under light Skeptic weight. F5 and F4 give the pattern the recruiter will check. |

**Round 1 reverse question.** "Which of the four values carries most weight in the panel's score, and what does a strong example look like for it?" It lands because it shows you read the values as scored, and it tells you what the panel wants.

## Round 2: Head of Member Services (7 questions)

This is your future manager and the most behavioural round. The highest-ROI prep in the whole pack is **B1**: the stated absence of contact-centre experience is the most predictable objection, and it will come in some form.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see contact-centre experience in your background. How would you own a process that runs through a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI prep.** Hold, then concede. Hold through two follow-ups by returning to what you did: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede the contact-centre specifics plainly: "I've never worked in a contact centre." Follow-up 1 ("what would you do in your first week?"): answer as a plan, in your own words. Follow-up 2 ("who would you rely on?"): name the roles you would ask, as a plan. Never describe contact-centre work as if you had done it. | F2 is the stated absence. The objection is aimed at exactly where the material is thin, so the rehearsal is the concession itself, said calmly. |
| B2 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | 60 seconds. Name what you did do (the complaints log, the training, the spreadsheet), then the plain acknowledgment: "I've never presented to anyone above regional level." Then how you would build the presenting skill, as a plan. | F3 stated absence under pressure. Keep the answer short: the time limit is the test. |
| B3 | "Walk me through how you ran the formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 and F9: the log, from intake to closure, in your words. Answer slot: if any stage was yours to set, say which and how you decided; if none was, say so plainly. Also answer slot for F9: if the log was held to a regulatory rule or timeline, say which; if not, say how it was kept. | The premise is your own sentence. F1 is the likeliest place to be probed on scope. |
| B4 | "What did the monthly complaints spreadsheet count, and how was it counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if it counted complaint volumes or resolution times, say which and how it was counted in your words; if it did not, say so plainly and say what you would report first. Expect a follow-up on the tool (F7): answer only what you can say accurately. | F4 is discovery. The question presupposes only that the spreadsheet exists. Defend-the-number applies if you give a figure. |
| B5 | "Tell me about a time you worked with a digital team on a self-service journey." | JD | [grounded] JD line "work with digital teams on self-service journeys" | Selection scaffold ending in an honest branch: "if you have worked with a digital team on a self-service journey, say who and what changed; if not, say so plainly, then say how you would approach one, as a plan." | F6 has no quote. The interviewer will probe a digital journey because the JD raises it. |
| B6 | "A branch manager says her branch is moving into a hub next year, and members are already asking whether they will lose service. What do you do?" | CASE | [generic] | Structure it: what you would find out first, what you would tell the branch manager, what you would tell members, and what you would record. Make no claim about the brief's plan for this branch. | A live problem from the hub plan in the brief. It presupposes nothing about you, and it tests whether you can hold members' trust through a change. |
| B7 | "When did you decide a member's case differently from the usual rule?" | VAL | [generic] | Open prompt. Selection scaffold: pick a time a member's situation made you decide differently from the usual rule. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal complaints log, and what the member's side of it was. | Members First is a published value. Your material has no story carrying it, so the scaffold ends with the honest branch. |

**Round 2 reverse questions.**
1. "What would you need the first 90 days' complaints work to change in the monthly report?" It lands because it asks what the manager will judge the role by.
2. "The brief moves 40% of member service to digital by 2028. What do you expect that to do to complaint volumes, and where would you look first?" It lands because it shows you read the strategy and asks for the manager's view, without supplying a figure.

## Round 3: Panel of two branch managers (7 questions)

Round 3 is the values round. It also holds the 20-minute escalation case. The two branch managers are peers of the future team, so the Peer Evaluator weighs in.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint you took all the way to the fix. Who was involved, and what did you hold on to?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Own the Fix. Selection scaffold: a complaint you kept through to its end. If it was closed by someone else, say so, and say what you did in the meantime. Do not claim a resolution your material does not show. | Values score. The log is the nearest thing you have. |
| C2 | "When did you decide a member's case differently from the usual rule?" | VAL | [generic] | Members First. Same scaffold as B7 with its honest branch. Say whose side of the counter you were on, in your words. | Values score. |
| C3 | "Tell me about something you rewrote so a member did not need it explained twice." | VAL | [generic] | Plain Words. Selection scaffold: the escalation script you trained tellers on is the nearest thing. If you changed the wording for members, say what changed; if not, say so and describe how you taught the script. | Values score. Plain Words is the value most easily tested by a script you wrote or taught. |
| C4 | "Tell me about a time a branch's local situation changed what you would recommend." | VAL | [generic] | Neighbours, Not Numbers. Scaffold: if you changed something for one branch's customers, say what it was; if not, say so and say how you would learn what a town needs. Prepare for the spreadsheet tension (F4): say what it counts and what it does not. | Values score. The question tests the value the hub plan will test in practice. |
| C5 | "A member's complaint started at a branch, went to the contact centre, and has come back twice with different answers. She is now threatening to take it outside. Walk us through the first 20 minutes." | CASE | [generic] | Clarify first: what is the complaint, what has each team said, what is the member's deadline. Contain: one owner now, one reply that is the same across channels. Plan the fix with a named owner. Communicate in plain words. Check the regulated timeline that applies to you, without naming a jurisdiction you have not stated. Think aloud. | 20-minute case from the JD's escalation and contact-centre lines. It presupposes nothing about you. Time it: about 3 minutes clarifying, 5 containing, 7 planning, 5 communicating. |
| C6 | "Our teams sit side by side. Where does a branch's responsibility end and the contact centre's begin, and what happens when you disagree?" | JD | [grounded] JD line "across branches and the contact centre" | Propose seam principles rather than pretending to know the seam: who owns the case, who owns the member contact, who decides when they disagree. Disagreement story: selection scaffold ending in its honest branch; if you have no such story, say so and give the principle. | Peer seam probe. The JD raises the seam. |
| C7 | "A branch supervisor sends you an escalation she handled badly. How do you coach her?" | JD | [grounded] JD line "coach branch supervisors on escalations" | Answer as a plan in your own words. Answer slot: if you have coached a supervisor on an escalation, say what happened; if not, say so and describe how you trained tellers (F5). | F5 is transferability. The question presupposes the JD's coaching practice, so the second branch must allow that you have not done it. |

**Round 3 reverse questions.**
1. "When a branch and the contact centre disagree about a member's complaint, who decides, and how often does that go wrong today?" It lands because it asks how Own the Fix works in practice.
2. "How will the five hubs keep a member close to their town, and what would you need from a complaints lead to help that happen?" It lands because it tests Neighbours, Not Numbers without asking which branch is closing. Ask the how, not the whether.
3. "What would a new complaints lead do in their first month that would genuinely help your branch teams?" It lands because it is a reciprocity question to peers. It signals that you are thinking about what you add to their work.

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, B3, C5, C6 | F1 and F2 |
| Report monthly on volumes and resolution times | B4 | F4 |
| Coach branch supervisors on escalations | C7, C5 | F5 |
| Work with digital teams on self-service journeys | B5 | F6 |
| 4+ years in financial-services customer operations | none, and why: closed by F8 | The years are stated. |
| Experience handling regulated complaints | B3 (slot), C5 | F9 |
| Confident presenting to senior leaders | B2 | F3 |
| Comfortable with Excel reporting | B4 | F7 |

## Sources

- **Provided documents:** the JD text and background in your message; the values text copied on 17 November 2026; the recruiter's email on rounds and scoring; your summary of the July 2026 strategy brief.
- **Research:** none. The research tier and target accounting are below.

## Target accounting

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | Values text is pasted and dated 17 November 2026, so the inputs fix the values cheat sheet. |
| 2. Interview process, role family | skipped | The recruiter's email fixes the three rounds, their lengths and their scoring. |
| 3. Company strategy and recent news | skipped | Your summary of the July 2026 brief fixes the grounding brief. Recent news since July would change it; see the upgrade menu. |
| 4. Interviewer name and company | n/a | No interviewer names were given, so there was no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- **Recent news since July 2026 (L2 deep research, offered, not run):** about six further searches and two fetches. It would check for announcements since the brief, which could change the grounding brief and the CO questions.
- **The full strategy brief pasted:** exact quotes in place of your summary, and the hub plan's wording checked in the room.
- **A sanitised copy of the monthly spreadsheet (headers only, no member data):** F4 moves from discovery to a concrete answer, and B4 gets specifics you can defend.
- **The recruiter's focus areas and any pre-declared exercise:** confirms the Round 1 and Round 2 weights.
- **Names of the Round 2 manager and the two branch managers:** a personalised interviewer read, from public professional information only, and persona weights per member.
- **A CV:** gap rows gain CV quotes. Today every quote is from your message.
- **Prep time before 26 November:** a prioritised triage section.
- **A tuesday-dossier.md:** the verified gaps and fit leads carried into later sessions.
