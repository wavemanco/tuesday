# Interview prep pack: Operations Manager, Atlas Freight

Built for a hiring-manager round, assumed because your note didn't say who you're meeting. Interviewer: unknown. Company research: not run (search was declined in this session), so no values, loop or strategy content is included.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: EXP (your past work), JD (the listed requirements), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding, not a script. Say it in your own words.
- Quoted sentences in Provenance are your own words, from your message.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Your material shows one site's operations, not four. Answer slot: if you have run or covered more than one site, say which and what you were responsible for; if not, say so plainly and say how you would learn the four. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material says three supervisors. The bridge is leading supervisors now, at a smaller span. Do not describe a span you have not held. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Seven years is in the material. Your material does not show how many of them were leadership. Answer slot: if you can count your leadership years, say the count; if you cannot, say when you first had supervisory responsibility. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | none given | none | [grounded] | discovery | Your material shows no on-time or cost-per-shipment figure. Answer slot: if you have tracked either, say what you tracked and how; if not, say so and say what you would measure first. |
| F5 | "cut mis-pick rate 40% by redesigning the pick path" (your message) → JD "drive on-time performance and cost-per-shipment down" | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [inferred] | transferability | A quality result, not a cost or on-time one. Bridge: the same method of finding a process problem and redesigning it. Do not say it reduced cost or improved on-time performance. |
| F6 | "build reporting in Excel/Power BI" (JD), Excel | "solid Excel" (your message) | medium | [grounded] | presentation | Your Excel is stated; the reporting it has supported is not. Say what you have used Excel for, in your words. |
| F7 | "build reporting in Excel/Power BI" (JD), Power BI | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never used Power BI." Then how you would learn it, as a plan, not a past. |
| F8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Covered. Name the Green Belt as a credential; the certificate is the artifact to bring. |
| F9 | Peak-season planning (not in the JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | Not a stated requirement. Useful as evidence of planning under volume; it reaches the multi-site and span questions only by analogy. |

Gate check: none of the JD's requirements is a gate under the suite's definition (a legal or credential bar). "5+ years" is graded on fit, not as a gate.

Confidence grades your evidence. Provenance grades what this pack wrote. Gap type is the separate call on what the evidence covers.

## Persona table

Round type is unknown, so these weights assume a hiring-manager round. Change them if the round is a peer, recruiter or skip-level.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the span gap (3 supervisors vs 12), the four-site gap and the missing leadership years | Highest. F1, F2 and F3 are the gaps a hiring manager is hired to test | Rehearse A1 until it is plain. Name the gap before it is named for you |
| Case / Strategist | Live problems on on-time performance and cost-per-shipment | High. The JD names both as outcomes to drive | Clarify, then structure, then metrics. Say what you would measure first |
| Data-Driven Prober | Asks how the 40% was counted and what was yours | Medium. F5 is a headline number and the likeliest place to be probed | Name the weakest assumption before it is asked |
| Pressure | Time-boxed challenge on the span gap and on how much of the 40% was yours | Lower weight. Used to test composure under the Skeptic's line | Hold the verified position through two follow-ups, then concede the specific gap |
| Conversational | Opens with "walk me through your journey" and peak season | Low, but scored. Casual openers still count | Have a 90-second arc ready |

Relationship prior and loop: the loop structure is unknown, so the archetype fallback is Generic, flat weights, said plainly. Values-style rounds are not detected.

## Question banks

Requirement coverage: "Own daily terminal operations across 4 sites" → A1, B5. "drive on-time performance" → B1, B3, B4, C4. "drive cost-per-shipment down" → B2, C4. "lead a team of 12 supervisors" → A1, A2, B5, D1. "build reporting in Excel/Power BI" → C2, C3, C4. "5+ years operations leadership required" → A2, D1. "Lean/Six Sigma a plus" → B4.

### A. Skeptic (weight: highest, 3 questions)

**Highest-ROI prep in this pack: A1.** The span gap is the most predictable objection to this candidate.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads 12 supervisors across four sites, and you manage three. What's your honest read on that gap?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Start with the three, in your words: you lead supervisors now. Then say what you have done that carries over. Answer slot: if you have led people across more than one site or a larger group of supervisors, say what and how; if not, say so plainly and say how you would ramp in the first 90 days. Do not describe a span you have not held. | F2 is the evidence and F1 is the gap. The premise (12, four sites) is the JD's own line, so the question may stand. |
| A2 | "Five-plus years of operations leadership is required. How many of your seven years have been leadership?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Give the seven years and the current role in those words. Answer slot: if you can count your leadership years, say the count; if you cannot, say when you first held supervisory responsibility. | F3 is the thin bridge, and the honest count is the answer. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message) | Name Power BI first, plainly: "I've never used Power BI." Then name the multi-site scope and say how you would learn it. Give the ramp plan as a plan. | F7 is a stated gap. The honest answer is the plain acknowledgment. |

### B. Case / Strategist (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance across the four sites has slipped. Walk me through how you'd diagnose it in your first 30 days." | CASE | [generic] | Clarify first: which sites, which lanes, which shifts, what "on time" means. Then structure the diagnosis: segment by site and shift, check the process before the people, then the metrics and risks. Think aloud. | A live problem from the JD's on-time line. No claim about your past. |
| B2 | "Cost-per-shipment is the number this role is judged on. What would you measure first?" | CASE | [generic] | Ask for the definition before measuring: which costs are in, how shipments are counted. State the assumption you would test first. | The JD names cost-per-shipment. Your material shows no figure for it (F4), so this answer is built from the method, not a record. |
| B3 | "You cut mis-pick rate 40% by redesigning the pick path. How would that thinking apply to on-time performance?" | CASE | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Describe the redesign in your words: what you saw, what you changed. Then say what transfers (finding the process problem first) and what does not (a pick-path result is not an on-time result). Answer slot: if you measured the problem before you redesigned it, say what you measured; if the redesign was set by someone else, say so. | F5 is the quote. The question asks transfer, which is the honest move. |
| B4 | "You're Green Belt certified. Which Lean tool would you reach for first where on-time performance is slipping?" | CASE | [grounded] "green belt certified" (your message) | Name the tool and why it fits the problem. Answer slot: if you have used it on a live problem, name the problem; if not, say how you would apply it. | F8 is covered; the tool choice is the test. |
| B5 | "How would you lead twelve supervisors you've never met?" | CASE | [generic] | Structure the first 30 days: meet the supervisors, check the shift patterns, agree the metrics, and decide what to change first. The premise is the JD's span, not your history. | Covers the span gap as a plan rather than a record. |

### C. Data-Driven Prober (weight: medium, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 40% mis-pick reduction counted, and which part of it was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say how you counted it, in your words. Name the assumption you would defend least (for example, the baseline period). Say which part was yours. Answer slot: if you cannot say how it was counted, say so plainly. | F5 is a headline figure. Defend the number, do not decorate it. |
| C2 | "How have you used Excel for operational reporting?" | JD | [grounded] "solid Excel" (your message) | Describe the reporting you have done in Excel, in your own words. Answer slot: if you have a report that a manager or team used to decide something, name what it was and who used it; if not, say what you used Excel for. | F6 is the quote. The JD's reporting line makes this the likely follow-up. |
| C3 | "How would you build a Power BI dashboard for four sites from scratch?" | JD | [grounded] "never used Power BI" (your message) | Say plainly: "I've never used Power BI." Then give the plan: the data sources, the first three metrics, and how you would learn the tool. Do not describe past dashboards. | F7 is a stated gap. The plan is the honest answer. |
| C4 | "Walk me through the weekly reporting you'd run for on-time performance and cost per shipment." | JD | [generic] | Structure it: the metric definitions, the data source, the cadence, the audience, and what the report would trigger. No claim about your past. | Covers the reporting and cost-per-shipment requirements together. |

### D. Pressure (weight: lower, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone with three supervisors for a role with twelve?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "7 years in warehouse and distribution ops" (your message) | Hold: the seven years and the current role carry the leadership you have. Concede the specific gap: the span is smaller. Do not fold on the seven years. | F2 and F3 together. Hold-then-concede. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the part that was yours, in your words. Concede what you do not know (for example, whether the baseline was the same). Answer slot: if you led the redesign, say so; if part of it was someone else's, say which part. | F5 is the headline figure. Hold-then-concede. |

### E. Conversational (weight: lower, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "green belt certified" (your message) | 90-second arc: warehouse and distribution, senior shift manager, the pick-path redesign, the peak plan, the Green Belt. Say it in your own words. | Casual, but scored. |
| E2 | "What do you take from running peak season two years running?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Name one thing you changed the second year, and why. Answer slot: if you changed nothing, say so and say what you kept. | F9 is evidence of planning under volume. |

Totals: 16 questions (A 3, B 5, C 4, D 2, E 2). That is below the usual 18-question floor. The shortfall is that the JD and your material give few more distinct angles; the upgrade menu says what would add more.

## Reverse questions

Five questions, with why each lands:

1. "What does success look like for this role at the end of year one, and how is it measured?" Why it lands: it turns the cost-per-shipment and on-time requirements into a measurable target.
2. "Which of the four sites is furthest behind on on-time performance today, and what's driving it?" Why it lands: it shows you have read the JD's four sites and want the real problem.
3. "How are the supervisors reporting today, and what tools are in use for it?" Why it lands: it asks directly about the Power BI gap without apologising for it.
4. "How is the twelve-supervisor team set up, and how much of it has changed in the last year?" Why it lands: it shows you are thinking about the span, not just the title.
5. "What did the last person in this role do well, and what did they find hard?" Why it lands: it shows you want the job as it is, not as it reads in the posting.

## Prohibited claims

What this pack will not coach, built from the fit snapshot. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed or led 12 supervisors | Inflated form of F2 (your material says 3) | "currently a senior shift manager over 3 supervisors" at its own scope. A2's slot asks for your count. |
| Ran operations across four sites | Inflated form of F1 (your material shows one site) | The one site you have run, at its own scope. A1's slot asks what more you have covered. |
| Has five-plus years of operations leadership | Inflated form of F3 (your material shows seven years of ops, not seven of leadership) | "7 years in warehouse and distribution ops." A2's slot asks for your leadership count. |
| Has used Power BI | Stated negative, F7 | "I've never used Power BI." |
| Drove cost-per-shipment down | Inflated form of F5 (the pick-path result was mis-picks) | "cut mis-pick rate 40% by redesigning the pick path." B3 asks what transfers. |
| Drove on-time performance | No quote carries this (F4 is silent) | Not coached. B1 is a plan. |

## Sources

Provided documents: your message (the JD text and your background).

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent: "Atlas Freight regional logistics company values"; "Atlas Freight interview process operations manager"; "Atlas Freight logistics strategy news". All three were refused: the search tool was not granted permission in this session, so no results came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet (none included). Refused. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure and persona weights. Refused; the archetype fallback is Generic, said plainly. |
| 3. `Atlas Freight strategy` / recent news | unavailable | Grounding brief and CO questions (none included). Refused. |
| 4. `{interviewer name} Atlas Freight` | n/a | No name given, so no query could be formed. |
| 5. Representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The round type and who is interviewing → reweighted personas, and a reverse question tied to their path
- Permission to search for Atlas Freight's values, interview process and recent strategy → values, loop and CO questions (this session's search was declined)
- The recruiter's note on any presentation, case or focus area → coverage of any pre-declared deliverable
- Your count of leadership years (F3) and your count of the 40% (C1) → the A2 and C1 answer slots filled in your own words
- A deeper research pass, up to 6 more searches and 2 more fetches, several minutes → strategy brief and loop reports, if you want them
