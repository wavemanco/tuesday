# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer and relationship: not yet known. Built at L0 (no web search; no JD, CV or recruiter notes supplied). Weights are flat until the round type is known.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = role requirement; **EXP** = your past work; **CASE** = live problem; **CO** = company knowledge (not covered yet); **VAL** = company values (not covered yet).
- Guidance is scaffolding, not a script. Speak it in your own words.

## Fit snapshot (worksheet variant)

No CV or JD was supplied, so no evidence is quoted yet. Requirements below are role-family knowledge, not Stripe's posted requirements.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing cross-functional operating processes [generic] | none given | none | [generic] | discovery | Answer slot: describe a process you designed or ran across teams. If none, say so and describe how you would design one. |
| F2 | Operational metrics and decision-making from data [generic] | none given | none | [generic] | discovery | Answer slot: name a number you used to change a decision. If none, say so and say what you would track first. |
| F3 | Stakeholder management across product, eng, finance, ops [generic] | none given | none | [generic] | discovery | Answer slot: name one stakeholder conflict you resolved. If none, say so and describe how you would handle it. |
| F4 | Scaling ambiguous work into repeatable systems [generic] | none given | none | [generic] | discovery | Answer slot: name a process you turned from ad hoc into repeatable. If none, say so and describe how you would approach it. |

## Prohibited claims

Nothing listed yet. No CV or quote exists, so there is nothing to stretch. Once your CV is shared, this section will list the inflated forms of your sentences.

## Persona weights

Flat, because the round type and interviewer are unknown.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Hiring manager | Asks how you'd run the role's core work | High | Answer with the process, then one example |
| Skeptic | Probes whether your experience is real | Medium | Hold your position, then concede exactly what you can't show |
| Prober | Asks for the denominator behind any number | Medium | Name the assumption you'd defend least before you're asked |

## Question banks

### Hiring manager (flat weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you'd design the operating process for a new cross-functional launch." | CASE | [generic] | Structure it: goal, owners, cadence, metrics, and what you would cut first. Makes no claim about your past | Tests F1 as a live problem. CASE because the answer is reasoning, not history |
| A2 | "What operating metric would you watch first for a payments product, and what would make you distrust it?" | CASE | [generic] | Name the metric, then its weakest assumption in your own words. Do not add a figure | Tests F2 without needing your history. Metric question, so the weakest-assumption move applies |
| A3 | "Tell me about a time a number changed how a team worked." | EXP | [generic] | Open prompt: pick a time a figure changed a decision. Say what it was, what you did, and what you didn't own. If no such time comes to mind, say so plainly, then give the nearest thing you have | Tests F2 against your history. Open prompt, so no event is supplied |

### Skeptic (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's the most senior decision you've made that you later had to reverse?" | EXP | [generic] | Open prompt: pick a decision you reversed. Say what was decided, what changed, and what you would do differently. Hold your position on the reasoning, then concede the specific error | Tests F3 under pressure. Hold-then-concede: hold through two follow-ups, then name the exact thing you got wrong |
| B2 | "Which of these have you actually owned end to end, and which did you only support?" | EXP | [generic] | Answer in two lists, in your words. Name the support roles plainly. Don't blur the line | Tests F1 and F4 for inflation. The honest answer is the separation itself |

**Highest-ROI prep:** B2. This objection will come in some form, and the only defence is an exact split between what you ran and what you supported. It can't be rehearsed well until your CV is shared, so treat this as a placeholder.

## Coverage

| Requirement | Question IDs |
|---|---|
| Cross-functional process design | A1, B2 |
| Operational metrics | A2, A3 |
| Stakeholder management | B1 |
| Scaling ambiguous work | A3 |

## Reverse questions

1. "What does a strong first 90 days look like for this role, and how would you know it's on track?" Why it lands: it shows you're planning for ownership.
2. "Which operating problem on the team is hardest to solve right now?" Why it lands: it surfaces the real work and signals you want to engage with it.
3. "How do product ops and the product teams split decisions today?" Why it lands: it tests the role's real authority.
4. "What did the last person in this role get right, and what did they wish they'd had?" Why it lands: it shows you care about continuity.
5. "How does the team measure whether its processes are working?" Why it lands: it asks about the metrics you'd own.

## Values / principles cheat sheet

Not included. Company values are not established: the web search was refused in this session, and I won't supply Stripe's values from memory. Paste the values page and this section will be built.

## Sources

- Provided documents: your message only (role title and company).
- Research tier: **L0**. Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10. Search refused |
| 2. `Stripe interview process product operations` | unavailable | Loop structure and persona weights. Search refused |
| 3. `Stripe strategy` / recent news | unavailable | Company knowledge (CO) questions. No search sent |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name given |
| 5. representative Product Operations Manager JD | unavailable | Would have set [inferred] requirements. No search sent |

## Upgrade menu

- **Job description text** → the four generic requirements become quoted and graded, and the banks cover each one.
- **Your CV** → the fit snapshot gets quoted evidence, and the answers become story-mapped.
- **Round type and who you're meeting** → persona weights are set, and the reverse questions are tailored.
- **Interviewer's name** → a reverse question tied to their career path.
- **Stripe's values page, pasted** → the values cheat sheet is built.
- **Recruiter's prep email** → coverage of any pre-declared exercise.
- **Permission for web search** → company strategy and interview-process questions at L1.
