# Operations Manager, Atlas Freight: interview prep pack

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees). Interviewer: not given. Round: assumed hiring-manager (your note didn't say who you're meeting; the persona weights below change if it's a peer or a panel). No web research was run.

## How to use this pack

- **Personas** are how a question is asked (the tone and pressure). **Types** are what is being scored.
- Type key: **JD** = stated job requirement; **EXP** = a claim from your past, probed for what you actually did; **CO** = company knowledge (not used here, no research run); **CASE** = live problem from the role; **VAL** = company values (not used here, no values provided).
- Guidance is scaffolding for a spoken answer, not a script. Say it in your own words.
- Quoted lines in the Provenance column are your own sentences from your message. Everything the guidance says about your past rests on them.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material describes one site, and the bridge stays at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: if you held responsibility beyond one site, say where and what; if you did not, say so plainly and say how you would run four sites day to day. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [inferred] | transferability | Mis-pick accuracy is not on-time or cost. Say the pick-path result at its own scope and do not say you moved on-time or cost. Answer slot: if you tracked on-time or cost-per-shipment at all, say what and how; if not, say so. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Bridge: "Currently I'm a senior shift manager over 3 supervisors." Answer slot: if you have led more people than that, say how many and in what role; if not, say so and say how you would build to twelve. |
| F4 | "build reporting in Excel/Power BI" (JD), Excel half | "solid Excel" (your message) | medium | [grounded] | presentation | Reword only what the quote says: "I'm solid in Excel." It adds no report, figure or practice. |
| F5 | "build reporting in Excel/Power BI" (JD), Power BI half | "never used Power BI" (your message) | none | [grounded] | capability | You stated this absence. Words: "I've never used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Surfaced, not bridged. Your material does not establish this gate: it shows seven years in operations, not how many of them were leadership. Asked once, in the questions at the end of this message. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | The quote already reaches the requirement. Expect the credential to be asked about; say what it is and where you applied it. |

## Persona weights

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 questions | Quiet probing of the gaps: team size, sites, the reporting tool | High. The material shows four visible gaps (F1, F3, F5, F6) against a hiring manager's stated JD. | Rehearse the team-size and Power BI answers until they are plain. Name the gap before the probe does. |
| Case/Strategist | 4 questions | Live problems from the daily operation | High. A daily-operations role is tested with diagnosis and trade-off problems. | Clarify, segment, state your hypothesis, then name the data that would settle it. |
| Data-Driven Prober | 3 questions | Asks how the 40% was counted | Medium-high. A headline figure on the CV draws this probe. | Know what you can and cannot say about the count. Say plainly when you don't know. |
| Pressure | 3 questions | Time-boxed, challenging, "how much was actually you" | Medium. Nothing in the material says this interviewer is a stress interviewer. | Hold what you did through two follow-ups. Concede only what is specifically true. |
| Conversational | 3 questions | Friendly openers that carry scored content | Medium-low. The opener is common, but the JD's plus-skill can come up casually. | A 90-second arc. Treat casual questions as scored. |

Total: 18 questions. Persona weights are a shown judgment; they can be recalibrated once you know who is interviewing.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message) | Name Power BI first, in your words: "I've never used Power BI." Then how you would learn it, as a plan. Answer slot: if you have built reporting in another tool, name it; if not, say so plainly. | F5 is the stated gap the JD's reporting line meets. This is the likeliest cross-examination of it. |
| A2 | "Your team today is three supervisors. What is your experience leading twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Say "three" plainly, in that wording. Answer slot: if you have led more than three people, say how many and in what role; if you have not, say so and describe how you would build to twelve. Hold the difference; don't blur it. | F3 is the team-size gap, and the JD's twelve is the interviewer's number. This is the highest-ROI prep in the pack: the question will come in some form, and the honest answer changes how it lands. The premise is the quoted three; the second branch allows that you have not led more. |
| A3 | "The role needs five-plus years of operations leadership. Do you have it?" | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | Give the years you have led people, counted from the first time you did, and name the roles. Answer slot: if it's fewer than five years of leadership, say so, then say what you have that is closest. | F6 is a gate the material does not establish. The interviewer will ask it directly. |
| A4 | "The role runs daily operations across four sites. Have you run more than one location?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Describe the site and the peak plan in those words. Answer slot: if you have had responsibility across more than one location, name where and what you were accountable for; if not, say so and say how you would split your time across four sites. | F1: the material describes one site, and the four-site line raises it. The second branch allows that you have not run more than one. |
| A5 | "Why this role, and why now?" | JD | [generic] | One honest sentence of your own reasons, then one reason tied to the role. No claim about your past is needed. | The Skeptic's motivation probe. Nothing in the guidance is about your history. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four terminals dropped eight points last month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: which terminal, which measure, since when, which lanes or shifts. Then segment (carrier, shift, dock, inbound or outbound), check the baseline, form two hypotheses, and say what data would settle each. Do not offer a root cause before the segmentation. | Live problem from the JD's on-time performance line. It is a problem, so it presupposes nothing about your past. |
| B2 | "How would you take cost-per-shipment down without hurting on-time performance?" | JD | [generic] | Name the trade-off first, then the levers you would test (labor mix, dock use, touches per shipment), and which metric you would guard. | The JD pairs the two metrics; the question tests whether you see the tension. No claim about your history. |
| B3 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Name the plan and the two years, in your words. Then the parts you designed and the parts you ran. Answer slot: if the staffing, the volume forecast or the sequence was set by someone else, say so, and describe what was yours. | F1: the strongest operational story. The quote carries the plan and the two years, and nothing more. |
| B4 | "Lean and Six Sigma are a plus here. Where would you start in the first ninety days?" | JD | [grounded] "green belt certified" (your message) | State the certification plainly, then the first process you would map and why. Answer slot: if you have applied Green Belt tools to a real problem, name the problem and the tool; if not, say so and describe the first step. | F7: the credential is solid. The question tests whether you can apply it, so the slot covers the application. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name, in your own words, the assumption you would defend least, before they do. Answer slot: if you know how it was counted, say so in your words; if you don't, say that plainly and say where the count lives. Say which part was yours. | A headline figure on your material is where probing starts. The method is not supplied here, so the slot asks for yours. |
| C2 | "You need both Excel and Power BI here. Which one could you build a report in today?" | JD | [grounded] "solid Excel" and "never used Power BI" (your message) | Say Excel plainly: "I'm solid in Excel." Say Power BI plainly: "I've never used Power BI." Answer slot: if you have built a report in Excel, name what it tracked and who used it; if not, say so and say how you would learn Power BI. | F4 and F5 together. The question asks which tool you can use now, and both quotes answer it honestly. |
| C3 | "Before you set an on-time target, what would you need to know about the baseline?" | CASE | [generic] | Name the definition of on-time (cutoff, which events count), the baseline window, and how you would split it by site. No claim about your history. | The Prober checks measurement discipline. The guidance supplies a method, which is fine here because the question is a case, not your record. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate with twelve supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Hold: name what you have run, then the trade-off you can state. Hold through two follow-ups. Concede only what you can name. Answer slot: if you can name a reason tied to the role, give it; if not, say what you would do in the first month. | F3 under a time limit. The question tests composure more than content. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold what the sentence says: the cut came from redesigning the pick path. Then concede specifically: name the others who did part of the work, if any. Never fold the core claim to restore harmony. | Pressure probe on the headline figure. Hold, then concede the specific thing. |
| D3 | "You haven't used Power BI. Why should we trust you with reporting across four sites?" | JD | [grounded] "never used Power BI" (your message) | Hold the true part: "I've never used Power BI." Hold the second part only with a plan you can state. Concede the tool gap, not the capability. Answer slot: name any reporting you have owned, in your words. | F5 under pressure. The four-site clause is the JD's line, so the question rests on a raising source. |

### E. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | 90-second arc: start with the seven years, the move into shift management, and where you are now. Stop at the present. | A rapport opener, scored for economy and clear sequence. |
| E2 | "What are you actually using in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Name the tools you use, in your words. Answer slot: name specific functions or files only if you have used them; if not, say that. | The JD's plus-skill asked casually. |
| E3 | "What's the piece of work you're proudest of?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the pick-path redesign and what it changed, in your words. If another piece of work is the one you are proudest of, name that instead. | An open prompt. The quote is the default story; the choice is yours. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A4, B1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, F2 |
| Lead a team of 12 supervisors | A2, D1 |
| Build reporting in Excel/Power BI | A1, C2, D3, E2 |
| 5+ years operations leadership required | A3 (gate, surfaced in F6) |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

Role-generic: there is no interviewer profile, so these are built from the JD. Each has a reason it lands.

1. "What does a strong first six months look like for this role?" Why it lands: shows you plan the ramp, and the answer tells you what the gap plan needs to cover.
2. "Which of the four sites is furthest from target right now, and what's behind it?" Why it lands: shows you want the operational detail, and tests how they think about diagnosis.
3. "How is on-time performance measured across the four sites, and who owns the definition?" Why it lands: you would be the one measuring it, so the definition matters.
4. "How does reporting get built today: Excel, Power BI, or something else?" Why it lands: raises the tool gap on your terms before anyone else does.
5. "What would make the first ninety days a success in your eyes?" Why it lands: gives you the scoreboard they will judge you on.

## Prohibited claims

What this pack will not coach, and why. Built here from the fit snapshot, since no dossier was provided.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | "ran the site's peak-season surge plan two years running," at its own scope. The limit is this pack's observation: your material describes one site. |
| Led twelve supervisors | Inflated form of F3 | "currently a senior shift manager over 3 supervisors." |
| Drove on-time performance and cost-per-shipment down | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path." |
| Built Excel or Power BI reporting | Inflated form of F4 and F5 | "solid Excel"; "I've never used Power BI." |
| Led Six Sigma projects | Inflated form of F7 | "green belt certified," at its own scope. |
| Seven years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops." The leadership years are yours to state. |

## Sources

- Provided documents: your message (the JD text and your background).
- Research tier: L0. Provided documents only. No web research was run.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Atlas Freight values | unavailable | A values cheat sheet, if Atlas publishes values |
| 2. Atlas Freight interview process | unavailable | Loop structure and persona weights |
| 3. Atlas Freight strategy and recent news | unavailable | Company-specific CO and CASE questions |
| 4. Interviewer name and company | n/a | No interviewer name was given |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

## Upgrade menu

- The interviewer's name and the round type → persona weights and a tailored reverse question
- Atlas Freight's published values, if any → a values cheat sheet mapped to your stories
- Permission to run research on Atlas Freight at the default tier → company-specific CO and CASE questions, plus a grounding brief
- Your on-time and cost-per-shipment numbers from your current site → defend-the-number answers for the metrics the JD names
- Any Excel report you have built → the A1 and C2 slots filled in your own words
