# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager relationship, per the careers page's loop description).
Format: one 60-minute Outage Hour, a live-incident tabletop followed by a values conversation (cite: saltmarshgames.com/careers/interviewing).
First build: no earlier version. Built on the job description, your background as you stated it, and the research listed under Sources.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural / values alignment. **EXP** work-experience deep-dive. **JD** role and JD-driven. **CO** company and strategy. **CASE** live problem.
- Guidance is scaffolding for a spoken answer, not a script. Where a guidance cell says "answer slot", the honest answer is either branch the slot offers. Never answer with a practice you did not do.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title, not two. Say it at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks about two titles, so expect a probe on the second. If you planned for more than one title, say how; if not, say so and stay with the main title |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote already reaches the requirement. Expect a probe on how the calendar was kept, so have the weekly rhythm ready in your own words |
| F3 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote reaches the requirement in role terms. It says you wrote it and QA still uses it; it does not say who maintains it today. Expect that probe |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote shows you presented the numbers. It does not say you defined or counted them, so the weakest-assumption move is an answer slot (D1) |
| F5 | "own the post-event review and the KPIs it reports" — JD | none given for the post-event review. The retention line touches KPI reporting only: "Presented the monthly retention numbers to the studio head." — your message | low | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran a post-event review, say what it covered and which KPIs it reported; if you did not, say so and say what you would review first, and how |
| F6 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show cross-team coordination on updates. Answer slot: name the functions a content drop needed and how you got their commitments. If others did that coordination, say so |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | presentation | The years match. The live content is shown by the content-drop line, not by the word live-service, so use the content-drop line to carry the claim. Bridge, at the quote's scope: "For four years I was an associate producer at a puzzle-game studio, and for the last two I ran the weekly content drops for our main title." |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [grounded] | discovery | Clarity is not shown by a checklist alone. Answer slot: name one written artifact of yours that a reader needed to act on, and who the reader was |

Hard gates: no JD requirement here is a gate under the suite's definition. The "3+ years" requirement is graded on fit, not treated as a gate.

Requirement that is not in the JD but is in your message: you have never led a team, and never worked on a game with in-app purchases. Neither is a JD requirement, so neither has a fit row. They appear in the prohibited list and the Skeptic bank as plain acknowledgments you can give.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Your negative: "Never led a team" — your message | "I haven't led a team." No answer slot on this point |
| Worked on a game with in-app purchases | Your negative: "never worked on a game with in-app purchases" — your message | "I haven't worked on a game with in-app purchases." No answer slot on this point |
| Ran the live-events calendar for two titles | Inflated form of F1 (the requirement widens your quote) | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: your material says one title, not two |
| Owned the post-event review and its KPIs | Inflated form of F4 and F5 (presenting numbers is not owning a review) | "Presented the monthly retention numbers to the studio head." The review is an answer slot (F5), not a claim |
| Shipped live-service games | Inflated form of F7 (your quote says puzzle-game studio) | "4 years as an associate producer at a puzzle-game studio." Live content is carried by the content-drop line only |

## Reading the interviewer

Public footprint only.

- **Career pattern.** A GDC 2026 talk listing names Tobias as Head of Live Operations at Saltmarsh and previously a QA lead at a console studio (cite: talks.gdconf.example/2026/patch-notes-are-a-promise, search result only; see Sources).
- **Self-described argument.** The talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped. That is the same thing as the value "Ship the Patch Not the Promise".
- **Implications.**
  1. Lead with what shipped and how you checked it. Tobias's argument is about accuracy, so vague outcomes will be probed (D1, D2).
  2. Your release checklist is the strongest bridge to that argument (B2, D3).
  3. Tobias came up through QA. You work with QA on the checklist. That is shared vocabulary, not a shared career move. No fit row carries your side of a QA-to-live-ops path, so do not present it as a jump.
  4. Expect the talk's theme to come back as a question. Read it before Friday if you can.

## Persona table

Relationship is hiring manager. The loop source establishes one session, run by the hiring manager, holding a live-incident tabletop and a values conversation.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The live-incident tabletop: a simulated outage during a live event | Top weight, 5 questions. The careers page names this format as the core of the hour | Clarify the impact first, then decide the player-facing action, then name the owners you would call. Think aloud |
| Values / Behavioral | The values conversation, on three published values | Joint top weight, 4 questions. The careers page documents a values conversation, and the values page names three values | Map a story to each value only where a quote carries one; otherwise use a selection scaffold and its honest branch |
| Skeptic | Probes the gaps: post-event review, cross-team coordination, leadership, in-app purchases | Joint top weight, 4 questions. A hiring manager is derisking gaps, and three JD lines have no quote behind them | Say the negatives plainly, then give the plan. Calibrated candour beats bluffing |
| Data-Driven Prober | Will test the retention figure and the checklist's maintenance | Mid weight, 3 questions. The talk's accuracy argument raises it | Name the weakest assumption before it is named for you. If you did not set how a number was counted, say so |
| Pressure / Stress | Time-boxed challenge on the leadership gap and on the retention number | Low weight, 2 questions. No pressure signal in the research | Hold the calendar line; concede the leadership gap exactly |
| Conversational / Rapport | Opening "walk me through" and a casual question about games you play | Low weight, 2 questions. The opener is scored | Keep a 90-second arc ready. Name a real game you play, and do not invent one |

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and a build with a bad bug has shipped. Walk me through the first hour." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (careers page) | Clarify who is affected and how badly. Decide the player-facing action: hotfix, rollback, or hold and tell players. Name the owners you call: engineering, QA, community, design. Say what you tell players and when. Speak in clauses, not a framework | The Outage Hour format, as the careers page states it. The question makes no claim about your past, so the guidance makes none |
| A2 | "Two days before a content drop, QA reports one open crash on a rare device. What do you decide?" | CASE | [generic] | Clarify the crash rate and the device share. Offer a scoped option, such as shipping without the affected content, and what it costs. Name what QA needs to sign off. Say what players are told | A live problem from the release checklist's territory. It presupposes nothing about your past |
| A3 | "Retention drops after a content drop. Diagnose it." | CASE | [generic] | Clarify the cohort, the baseline and the date range before you suggest a cause. Name the two assumptions you would check first. Propose one test that separates the drop from the content | A metric diagnosis from the JD's retention requirement. Generic, because it is a pattern for the problem |
| A4 | "Walk me through how you would plan the next quarter's live-events calendar for two titles." | JD, CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Clarify the two titles' goals and commitments first. Lock the dates that other teams need. Say what gets cut when capacity runs short. Use the content-drop calendar you ran as the nearest thing you have, and say what it did and did not cover. Answer slot: if you planned for more than one title, say how; if not, say so | F1 is the nearest evidence. The second title is a slot, not a claim. JD because it scores the calendar requirement |
| A5 | "Project Larkspur puts the two titles on one shared events calendar, with a single live-ops group. How would you run that calendar?" | CO | [grounded] "one shared events calendar from February 2027" (Project Larkspur announcement, search result only) | Name the trade-off between one calendar and two titles' separate cadences. Say how you would keep each title's players first. Name what you would want to know from the group before February | Larkspur is the company's own published plan, and it is perishable: it is dated September 2026. The guidance speaks to the plan, not to your history |

### Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (values page) | Selection scaffold: pick a time a date you had committed to met a player-facing problem, and say what you did. If none comes to mind, say so plainly, then give the nearest thing you carry: the content-drop calendar, and how you would handle a clash today | Values page value Players Before Plans. None of your quoted sentences carries this story, so the guidance is a scaffold and its honest branch |
| B2 | "Tell me about a time you had to describe a build as smaller than you wanted." | VAL, JD | [grounded] "we announce what is built, not what is hoped." (values page); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Map to the release checklist: it is the step that decides what is announced. Say that QA uses it. Answer slot: if the checklist ever changed what was announced, say how; if it did not, say so, and describe the nearest step you controlled. Also covers the release-checklist requirement | The value is Ship the Patch Not the Promise, and it is the bridge to Tobias's talk. The checklist is the only quote that carries a release story, so the claim stops at "QA uses it" |
| B3 | "What have you left better than you found it?" | VAL | [grounded] "every release leaves the codebase and the checklist better than it found them." (values page); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say the checklist is still in use. Answer slot: if you changed it after you wrote it, say what changed and why; if you did not, say so and name the next change you would make | The value is Leave the Build Greener. "Still uses" carries durability, not change, so the guidance asks rather than claims |
| B4 | "When did you have to tell a senior leader something they did not want to hear?" | VAL | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Selection scaffold: pick a time a number you presented was unwelcome. Say what it said and what the studio head did with it. If the numbers never landed badly, say so and give the plainest version you have | A standard harmony probe. The quote carries the presentation, not the reaction, so the reaction is a slot |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); [grounded] "none given" for the review, per F5 | Name the post-event review as the place you start thin. Then give the plan: what you would read first, who you would sit with, and what the first review would contain. Plan language only, no claim about a past review | F5 is the weakest row; this is the likeliest cross-examination |
| C2 | "You haven't led a team. How would you coordinate design, art, engineering and community without authority over them?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Plain acknowledgment: "I haven't led a team." Then the plan: name the functions and the commitments you would need for each update. Answer slot: if you did coordinate across functions for a content drop, say which and how; if that coordination was others' work, say so | The negative is yours. The coordination requirement has no quote, so it is an answer slot (F6) |
| C3 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then one plan: ask to sit in on monetisation reviews in your first month, and say what you would want to learn from them. Do not describe the trade-offs as if you had seen them | The negative is yours. The question does not assert that Saltmarsh's titles use in-app purchases; the research did not establish it |
| C4 | "Four years in puzzle games. What from that carries over to live-service?" | JD | [grounded] "3+ years producing live-service games or apps" (JD); [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Say the four years, and the content-drop line: "I ran the weekly content-drop calendar for our main title for the last two years." Name what carries over, in those words. Do not argue that puzzle games are live-service, and do not argue they are not | F7's bridge. The question presupposes only the JD's line and your quote |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention figure you presented was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: say how the numbers were counted, if you know. Name the assumption behind them you would defend least. If you did not set the counting, say so, and say what you would check first | F4's bridge. The counting method is not in your quotes, so the guidance does not supply one |
| D2 | "Which post-event KPI would you defend least?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Answer slot: if you have reported a KPI after an event, name the least defensible one and why. If you have not, say so, then name the first KPI you would define and its weakest assumption. Plan language only | F5's slot. The JD raises the review and the KPIs; your quotes do not carry either |
| D3 | "Your talk's argument is that patch notes are a promise. Did the release checklist ever catch a note that did not match the build?" | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message); [grounded] "a live team is judged by how often its patch notes describe what actually shipped" (GDC 2026 talk listing, search result only) | Answer slot: if the checklist caught a mismatch, say what it caught and what you changed. If it did not, say so, and say how you would check a note against the build. Do not claim a catch you cannot describe | Tobias's own argument, as a probe. Your checklist is the nearest mechanism, and the guidance asks rather than asserts |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "I haven't led a team." (plain acknowledgment of your negative) | Hold the calendar line for two follow-ups, then concede: "I haven't led a team." Then say what you would do in the first month to show the coordination you can do without authority | Hold-then-concede on the leadership gap. The hold is what the quote carries, no more |
| E2 | "That retention number. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you presented, and what you did not produce. Hold that line through two follow-ups. Concede exactly what you cannot defend. Do not claim a method you did not set | A pressure form of D1. The hold is only your presentation |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc: the puzzle studio, the content calendar, the release checklist, the retention presentation, and why Saltmarsh. Keep to those beats | A casual opener scored on the JD. The arc uses only your quoted beats |
| F2 | "What are you playing at the moment?" | JD | [generic] | Name a real game you play, and say what its update cadence looks like to you. Do not invent a game or a claim about it | A casual check of interest in live games. Generic, because it asks about your own experience |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, A5 (second title is an answer slot; F1) |
| coordinate design, art, engineering and community teams on each update | A2, C2 (answer slot; F6) |
| own the post-event review and the KPIs it reports | C1, D2 (answer slot; F5) |
| manage the release checklist with QA | B2, D3 |
| comfortable with player-retention metrics | A3, D1, E2 |
| experience running a content calendar | A4 (F2) |
| 3+ years producing live-service games or apps | C4, F1 (F7) |
| clear written communication | none, and why: the interview is spoken, and the only written evidence is a checklist, which F8 records as low confidence. Answer slot F8 is the honest route if it comes up |

## Values and principles cheat sheet

Published values, from the values page: three, with their working meanings.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win | No quoted sentence carries a story here. Selection scaffold: a time a committed date met a player-facing problem (B1). If none comes to mind, say so plainly |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | "Wrote the release checklist our QA team still uses." (your message). Map to B2; the answer slot is what the checklist changed about announcements, if anything |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | "Wrote the release checklist our QA team still uses." (your message). Map to B3; the answer slot is what you changed since |

## Reverse questions

Five questions, each with why it lands.

1. "Project Larkspur moves the two titles to one shared calendar and a single live-ops group from February 2027. What does this role own in that structure?" Why it lands: it shows you read the company's own news, and it asks the one question the JD cannot answer.
2. "You came up through QA before you ran live ops. What from that shapes how you judge a release today?" Why it lands: it ties the question to Tobias's own path, and turns an interview into a peer conversation.
3. "In the Outage Hour's tabletop, which decisions sit with the producer and which with the title leads?" Why it lands: it shows you understand the role's authority, and it tests whether the role is really coordinating.
4. "How do you know a post-event review was worth running?" Why it lands: it asks how the KPIs are judged, which is the requirement the JD names.
5. "Where do you see patch notes drifting from the shipped build today?" Why it lands: it engages the talk's argument with a question rather than a challenge, and it shows you read it.

## Sources

Provided documents: the job description, your background message, and the values, careers and talk material below.

Research tier: L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name, fetched from saltmarshgames.com/values |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop structure: recruiter call, then the Outage Hour, a single 60-minute session with the hiring manager. Fetched from saltmarshgames.com/careers/interviewing. Persona weights follow it |
| 3. Saltmarsh Games strategy and recent news | yes | Question A5 and reverse question 1: Project Larkspur, announced September 2026. Read from the search result only; the full page was not fetched |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer, persona weights, and reverse question 2. Read from a search result for a GDC 2026 talk listing; the page was not fetched |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, with what came back:

- "Saltmarsh Games values": saltmarshgames.com/values, fetched
- "Saltmarsh Games interview process live operations producer": saltmarshgames.com/careers/interviewing, fetched
- "Saltmarsh Games strategy news": saltmarshgames.com/news/project-larkspur, search result only
- "Tobias Wrenfield Saltmarsh Games": talks.gdconf.example/2026/patch-notes-are-a-promise, search result only

Before Friday, worth checking:

- The Project Larkspur announcement in full. Question A5 and reverse question 1 rest on the search snippet.
- The GDC talk page. Its domain is talks.gdconf.example, which does not look like a real conference site. Verify it before you cite the talk. Reading the interviewer rests on it.
- Tobias's current title on the company's own careers or leadership page.
- The two titles Larkspur names, so your calendar examples match.

## Upgrade menu

- Your prep time before Friday → a prioritised schedule, sized to the hours you have
- Answers to the discovery slots (F5, F6, F8, and the second title in F1) → each one moves its row from discovery to grounded, and the banks that cite it become sharper
- A deeper research pass (L2): a strategy brief, more of Tobias's public talks and writing, and role-family loop reports → up to 6 more searches and 2 more fetches, several more minutes
- Tobias's other talks or posts → a sharper persona read, and more reverse questions tied to his path
- A recruiter email confirming how the hour is split between the tabletop and the values conversation → a timed plan for the session
