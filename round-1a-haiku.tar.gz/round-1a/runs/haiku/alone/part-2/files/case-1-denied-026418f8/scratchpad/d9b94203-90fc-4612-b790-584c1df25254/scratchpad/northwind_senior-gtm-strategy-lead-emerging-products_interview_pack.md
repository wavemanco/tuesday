# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Interviewer: Dan Kovac, Director of Sales Strategy. Relationship: peer, same VP. Round: single 60-minute conversation.

## How to use

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script.

Type key:
- **EXP**: work-experience deep-dive; tests what you actually did.
- **JD**: role and JD-driven; tests whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge.
- **CASE**: hypothetical or live problem from the role.
- **VAL**: values alignment (not used here; no values-style round detected).

## Fit snapshot

Requirements are quoted from your JD highlights, which are not the full JD. Evidence is quoted from your notes on Priya. Words in quotation marks exist in those inputs.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | medium | [grounded] | transferability | Your material shows product strategy and ops, not a GTM strategy owned for a product line. Words: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: expect a probe on whether any launch's go-to-market was yours to set. If one was, say which decisions and how you made them, in your own words. If none was, or it was not yours, say so and stay with the strategy and ops work. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | Your material shows one opportunity you proposed, credited with about $400M ARR. It does not show a whitespace map across the four motions. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you mapped where demand sat across land, adopt, expand or renew, say what you mapped and how you chose the cuts. If you did not, say so plainly and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (your JD highlights) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | none | The tools are on record. "Skilled in" is a self-assessment with no inspected artifact, so expect a probe. Words: "I'm skilled in SQL and Tableau." Answer slot: if you have run an analysis end to end on your own, name the question and the decision it fed. If not, say so. |
| F4 | "strong cross-functional influence" (your JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | Words: "I set annual volume targets with cross-org consensus." Limit: a consensus-built volume target is not a quota. Do not call it one. |
| F5 | "partner-motion design experience required" (your JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | This is partner economics, not partner-motion design. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: expect a probe on partner motion design. If you shaped any partner terms, incentives or motion, say what and how you decided. If not, say so and describe the revenue model's role in the negotiations. |
| F6 | "AI experience a plus" (your JD highlights) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Daily use is adjacent to building AI, and the derivation from this line is this pack's. Words: "I use AI tools every day." Answer slot: if you have built or shipped anything with a model, say what and your part in it. If not, name the tools and what you use them for. |
| F7 | Quota and target-setting for a sales team (your note's gap, not a JD line) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | discovery | Your note records no sales-ops or quota-setting work. It is your note, not Priya's own words, so the pack gives her no first-person line for it. Answer slot: if you have set a quota or a target a sales team works to, say what and your part. If not, say so plainly, then say what target-setting you did and how you would approach a quota. |

Gate rows: none. Your JD highlights name no location, authorization, pay or travel terms. The full JD may name some.

Confidence: F7 is `none` because no evidence in the inputs reaches quota work. Gap type: F7 is `discovery`, not `capability`, because only your note states the absence, not Priya.

## Prohibited claims

These claims are not coached anywhere in this pack. Each entry is an inflated form of a sentence Priya did say, and the honest form is that sentence at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. Your material shows product strategy and ops, not GTM ownership. |
| Drove or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with the uplift. |
| Designed partner motions | Inflated form of F5 | F5's quote: the partner-level revenue model. |
| Set quotas or ran sales ops | Inflated form of F4 and F7 | F4's quote at its own scope: volume targets with cross-org consensus. Not quota-setting. |
| Built AI products or a copilot | Inflated form of F6 | "uses AI tools daily" at its own scope. |

## Persona weights

Relationship prior: peer. Peer and Data-Driven Prober are the starting weights. Signals from Dan's profile: "relentlessly data-driven" raises the Prober. His pricing and monetization career tilts case questions toward pricing, packaging and unit economics. His one early-stage startup chapter means builder stories land, and expect scrappiness probes. The fit gaps (F1, F2, F5, F7) feed the Skeptic bank. Dan's public footprint was not researched (see Sources), so these weights come from his profile text alone.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks for the denominator and the assumption behind each figure | High. Dan's self-description, plus the $400M figure and the volume-target line, are the numbers he will test. | Name the weakest assumption before he does. Say plainly what you do not know about how a figure was counted. |
| Peer Evaluator | Seam questions, credit-sharing, what Priya needs from his team | High. Same VP, and his pricing work sits beside the new product lines. | Reciprocity: say what Priya brings to his team, then propose seam principles, not a seam she has not seen. |
| Case / Strategist | Live problems on land, adopt, expand, renew, pricing | Medium. His pricing spine tilts cases toward pricing and unit economics. | Clarify, then objective, segments, approach, metrics, risks. Name one premise you would challenge. |
| Skeptic | Probes the gaps, the quota gap first | Medium. F1, F2, F5 and F7 are the weak rows. | Rehearse the quota question until it is boring. Use an honest ramp plan. Do not bluff. |
| Conversational / Rapport | Opens with "walk me through the journey" | Low to medium. A casual opener is still scored. | Keep a 90-second arc ready. Treat casual questions as scored. |

Depth: Prober 5, Peer 5, Case 3, Skeptic 3, Conversational 2. Total 18 questions.

## Grounding brief

Source: your research note. No L2 research ran, and no search for Northwind's current news was made. Headline numbers are not in the note, so none appear here.

- Three stated priorities: enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- Main competitive threat: bundling by a much larger platform vendor.

Sound current by naming these in your own words. Check any recent move before using it, because none was verified here.

## Question banks

### Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you arrived at the ~$400M figure." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the sentence's own words: proposed, and credited with. Defend-the-number slots: say how the figure was counted if you know, and say plainly if you do not. Name the assumption you would defend least, in your own words, before he does. Answer slot: say which part of the figure was yours. | F2 is the headline figure, and Prober interviewers test it first. The pack gives no counting method, because the inputs contain none. |
| A2 | "What's your assumption behind that number that you'd defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the input you are least sure of. Say whether the figure is yours or the team's. Answer slot: if you chose the surface or the test design, say so. If the call was made by others, say so plainly. | Same figure as A1, a second probe level. A held answer here matters more than the first. |
| A3 | "On the work in product strategy and ops, who owned go-to-market?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Start from the sentence: product strategy and ops, for nine years. Answer slot: if you set go-to-market for any of it, say what. If it was not yours, say who held it and what you did. | F1 is the JD's first line and the one most likely to be probed. |
| A4 | "Which SQL or Tableau analysis have you run on your own, end to end?" | JD | [grounded] "skilled in SQL/Tableau" | Name the tools in the sentence's words. Answer slot: if you have run an analysis end to end, name the question and the decision it fed. If you have not, say so plainly, then say what you would do first. | F3 is medium confidence with no artifact, so the JD's "independent analysis" line is the probe. |
| A5 | "How did you validate the partner revenue model?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the input you would defend least. Answer slot: say how the model was checked, if it was, in your own words. If it was not checked formally, say so. | Premised on the quote's scope: a model used in negotiations. Its validation is not in the inputs, so it is a slot. |

### Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on pricing. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles: who decides a price, who decides a package, what gets escalated. Do not claim a disagreement story unless you have one. | Persona stem for a peer, drawn from Dan's pricing career. Makes no claim about Priya. |
| B2 | "How do you split credit for a launch that spans both our teams?" | JD | [generic] | Principle first: credit follows the decision. Then one example you can name in your own words, if you have one. | Peer credit probes return from other banks in collegial form. |
| B3 | "What would you need from me to make pricing work on the two new lines?" | JD | [generic] | Reciprocity: say what you would bring to his team, then what you need, in that order. | Reciprocity is the peer's first scored move, and the pack's safest form of it. |
| B4 | "You built the partner revenue model. How does it touch pricing on my side?" | CO | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the handoff: what the model outputs and where a price or package decision would use them. Answer slot: if the model's output fed a price or package decision, say which. If it did not, say so. | Premised on F5's quote. Partner motion design is not in that sentence, so this question does not reach it. |
| B5 | "When you set targets with other teams, how did you get them to agree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped: the consensus process is the sentence's own. Answer slot: the disagreement, the resolution and what changed. If there was no disagreement, say so. | F4 is the cross-functional influence line. The disagreement beats are not in the quote, so they are a slot. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you size the land motion for a new product line?" | CASE | [generic] | Clarify the product and the buyer. Then objective, segments, approach, metrics, risks. Challenge one premise you would test first. | JD land motion is a raising source. The question presupposes nothing about Priya. |
| C2 | "Compass is launching. What do you measure in its first 90 days?" | CO | [grounded] "AI copilot launch ('Compass')" (research note) | Use the company's word, Compass. Name two metrics and what each would tell you. Do not claim knowledge of Compass's internals. | Named in your research note as a priority. Also the JD's AI plus, asked in the business's terms. |
| C3 | "A larger platform bundles its product into the suite. How do we respond without giving away price?" | CO | [grounded] "bundling by a much larger platform vendor" (research note) | Structure: options that hold price, what you would need to know about the bundle first, and what you would test. | The main threat in your note, asked as a live problem. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name the quota and target-setting gap first, in your own words. Then the answer slot: if you have set a quota or a target a sales team works to, say what and your part. If you have not, say so plainly, then say what target-setting you did, then your ramp plan for the first month. Hold through two follow-ups by returning to the target-setting you did. Concede the gap specifically, never fold on the target-setting you did. | F7 is the largest gap and the most predictable objection. The question names no negative, so it presupposes nothing. The deepest rehearsal goes here, with three follow-up levels. |
| D2 | "How would you structure a quota for a new product line where nothing has sold yet?" | CASE | [generic] | Structure: what you know about the buyer, what a sensible first-year target would rest on, and what you would revisit after one quarter. Say what you do not know. | A live problem that follows from D1. It asks for a method, not a past, so no claim is made about Priya. |
| D3 | "On your product strategy and ops work, who held go-to-market?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Start from the sentence. Answer slot: if you set go-to-market for any of it, say what. If not, say who held it and what you did. | F1 is the JD's first line. This is the Skeptic's version of A3, aimed at the gap. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" | Ninety-second arc: consulting, then consumer tech, then the partner model, then why Northwind. The "why Northwind" line is not in your notes, so say it in your own words. | Opening question. Casual, but scored. |
| E2 | "What are you actually playing with in SQL and Tableau these days?" | JD | [grounded] "skilled in SQL/Tableau" | Name what you use, in the sentence's words. Answer slot: if you have built an analysis you would show, name the one. If not, say so. | A casual version of A4. Also the JD's stated analysis requirement. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | A3, D3, D1 |
| identify whitespace across land/adopt/expand/renew | A1, C1, D2 |
| run independent analysis in SQL and Tableau | A4, E2 |
| partner-motion design experience required | B4, A5 (partial; partner motion design itself is uncovered) |
| strong cross-functional influence | B2, B3, B5 |
| AI experience a plus | C2, F6 row (no question on AI build experience; the gap is handled in the fit snapshot) |

## Reverse questions

Five minimum, one tied to Dan's path, one reciprocity.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Dan, what from the startup chapter do you still use in pricing work?" | Ties to his own path. It turns an interview into a peer conversation and shows you looked at him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. Peers weight this heavily. |
| R3 | "Which pricing decisions for the two new lines will sit with you, and which with the GTM lead?" | Maps the seam in the open, which is the peer's real question. |
| R4 | "Where does the partner motion sit today, and who owns it?" | Tests the partner-motion gap directly, from the other side. |
| R5 | "From where your team sits, what's the biggest open question on the Compass launch?" | Uses the priority in your research note and asks for his view. |

## Sources

Provided documents: your message (JD highlights, coach's notes on Priya, Dan's profile text, your research note).

Research tier: L1 — searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | skipped | Values cheat sheet, not emitted. No values-style round detected, so no search could change an emitted output. |
| 2. `{company} interview process {role family}` | skipped | Loop structure. Your note fixes it: one 60-minute conversation with a peer. |
| 3. `{company} strategy` / recent news | skipped | Current priorities. Your research note supplies the three priorities and the bundling threat. |
| 4. `Dan Kovac Northwind Data` | unavailable | Interviewer footprint: would have moved persona weights and the reverse questions. Query "Dan Kovac Director of Sales Strategy Northwind Data" was refused by the host's permission check. |
| 5. representative `{role title}` JD | skipped | Requirement rows. Your highlights fix them, but they are not the full JD, so the full text is requested below. |

No user links read.

## Upgrade menu

- The full JD text → the six highlight rows become verbatim JD quotes, and any gate terms (location, authorization, pay, travel) would surface.
- Dan's public footprint, if you grant search permission → persona weights from his talks and writing, and a reverse question tuned to his published path.
- Priya's own one-line statement on quota work → F7 moves from your note to her words, with a plain acknowledgment that the pack can quote.
- The recruiter's note on focus areas or any pre-declared deliverable → a build section for it, and recalculated coverage.
- Priya's own words on how the ~$400M figure was counted → A1 and A2 move from answer slots to her sentences.
- Deep research (L2, at most 6 searches and 2 fetches, one-time offer) → interviewer talks, a strategy brief, and recent Northwind news.
