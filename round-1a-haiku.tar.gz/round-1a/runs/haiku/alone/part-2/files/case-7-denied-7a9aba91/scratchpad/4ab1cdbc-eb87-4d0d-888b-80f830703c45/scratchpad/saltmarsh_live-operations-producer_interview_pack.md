# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not yet confirmed. Built on hiring-manager priors, the likeliest reading for a Head of Live Operations; it is reweighted once you confirm the round.
**Research:** did not run. The web search tool was refused permission, so nothing here about Saltmarsh, its values, its interview process or Tobias comes from outside your message. Company facts are the ones you gave: a mobile game studio of about 350 people.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

- **JD**: tests a stated responsibility or requirement in the posting.
- **EXP**: tests what your message claims, and how much of it was yours.
- **CASE**: a live problem for the role; tests structure, not your past.

## The fit snapshot

No JD line here is a gate. "3+ years" is a length requirement, so it is graded on fit like the rest.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one main title's calendar, for two years. Bridge: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names two titles, so expect a probe. If you planned for a second title in any form, say how; if not, say so and say what would carry over. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across these teams. Answer slot: if you coordinated any of them on a drop, say which and how, in your own words; if you did not, say so plainly and say how you would run one update across all four. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material says you presented the numbers, not that you ran a review or reported KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran any review after a content drop, say what it covered and who it went to; if not, say so and say what you would review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Bridge: "I wrote the release checklist our QA team still uses." Expect a probe on what "still uses" means in practice. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Your material gives four years as an associate producer at a puzzle-game studio, and two years on the content-drop calendar. It does not show three years of live-service production. Bridge: "I was an associate producer at a puzzle-game studio for four years." Answer slot: if three or more of those years were live-service work, say which and how you know; if fewer were, say which were and say the gap plainly. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Bridge: as F1. Expect a probe on the calendar's scope. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Bridge: as F3. No figures are in your material, so no defend-the-number claim is made. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | One written artifact is thin evidence; this label is the derivation from the checklist alone. Answer slot: if you wrote something else others relied on, say what and who read it; if the checklist is your main example, say so and stay with it. |
| F9 | [generic] leading the teams you would coordinate | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Words: "I have never led a team." Then coordination as F2 allows, with no leadership claim. |
| F10 | [generic] experience with games that sell in-app purchases (not named in the JD; from your own flag) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Words: "I have never worked on a game with in-app purchases." Then how you would learn it, stated as a plan. |

Gap types follow the routing rule: a stated negative is `capability`; a quote that reaches a requirement in other terms is `presentation`; adjacent work that stops short is `transferability`; silence is `discovery`.

## Prohibited claims

Built locally from the fit snapshot. These are wordings a candidate reaches for under pressure and this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Led design, art, engineering and community teams | Stated negative (F9) | "I have never led a team." Coordination only as F2 allows |
| Ran live events for two titles | Inflated form of F1 | The calendar for one main title, at its own scope |
| Owned the post-event review and KPI reporting | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." |
| Managed the release checklist with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Three years of live-service production | Inflated form of F5 | Four years as an associate producer at a puzzle-game studio |
| Experience with in-app purchase games | Stated negative (F10) | "I have never worked on a game with in-app purchases." |

## Persona weights

| Persona | How it shows up here | Likelihood and weight | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the coordination gap, the two-title scope, the post-event review and the years of live-service work | High, 6 questions. Hiring-manager prior, and the JD's coordination line plus your own flag on leadership point at it | Acknowledge the gap in one sentence, then return to what you ran. Hold through two follow-ups |
| Case/Strategist | Live problems on the calendar, a retention dip, sequencing four teams | High, 4 questions. Hiring-manager prior | Clarify before structuring; name your retention definition |
| Data-Driven Prober | Asks how retention was defined, what the calendar counted | Medium, 4 questions. Your retention and calendar work is the likeliest target | Say what you know of how figures were counted; say plainly when you do not |
| Pressure | Time-boxed challenge on leadership and on what was actually yours | Medium, 2 questions | Pause, restate, hold once, concede the one true gap |
| Conversational | A walk-through opener, a casual question about what you play | Lower, 3 questions. Casual questions are still scored | A 90-second arc built from your own sentences |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never led a team. How would you coordinate design, art, engineering and community on each update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep in this pack.** Open with: "I have never led a team." Make no coordination claim your material does not show. Answer slot: if you coordinated any of these teams on a drop, say which and how; if you did not, say so plainly and set out how you would run one update across the four: what you would set up first, and how you would settle a disagreement between two teams. Hold through two follow-ups by returning to the calendar you ran, never by adding to it. | F9 and F2 are the largest gaps, and the JD's coordination line raises this objection directly. The guidance concedes the leadership gap in your own words and does not claim the coordination. |
| A2 | "The JD asks for two titles. You've run one. What changes when you're running two calendars?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say the calendar you ran, in those words. Answer slot: if you planned for a second title in any form, say how; if not, say so and describe how you would sequence two calendars rather than copy one. | F1 is the transferability gap. The question presupposes two titles, which the JD raises; the second branch admits you did not plan for one. |
| A3 | "Walk me through the post-event review you'd own. What did you look at after a drop?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from the quote. Answer slot: if you ran any review after a content drop, say what it covered and who it went to; if not, say so plainly and say what you would review first after a drop and where you would report it. | F3. Presenting numbers is not a review you owned. "What did you look at" presumes a review; the second branch lets it be false. |
| A4 | "You haven't worked on a game with in-app purchases. What would you learn first?" | EXP | [grounded] "never worked on a game with in-app purchases." | Plain acknowledgment: "I have never worked on a game with in-app purchases." Then a plan, stated as a plan: which spend and retention data you would ask for first. Describe no in-app purchase work. | F10. The JD does not name in-app purchases. The probe is an inference [inferred] that mobile live-ops at a studio this size often involves them. |
| A5 | "Of your four years as an associate producer, how many were live-service work, and which?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Answer with the count you can defend. Answer slot: if three or more years were live-service work, say which and how you know; if fewer, say which years were, and say the gap plainly. Do not round up. | F5, the "3+ years" requirement. Length is graded on fit, so a count you can defend beats a rounded one. |
| A6 | "What's the best thing you've written that a team relied on, other than a checklist?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Start from the checklist: you wrote it and QA still uses it. Answer slot: if you wrote something else others relied on, say what and who read it; if the checklist is your main example, say so and stay with it. | F8, clear written communication. One artifact is thin evidence, so the guidance does not inflate it. |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Day-7 retention on one of your titles dropped three points over two weeks. What do you check first, and what do you change in the calendar?" | CASE | [generic] | Clarify before structuring: which cohort, what changed in the build or content, whether the drop is one segment or all. Then the calendar: what you would hold and what you would ship. Name the retention definition you are using as a question, and say what you would measure to confirm the cause. About 90 seconds spoken. | A live problem drawn from the role's KPIs. It makes no claim about your past. |
| B2 | "You're handed a title you haven't played. What do you need to know before planning its next event?" | CASE | [generic] | Clarify: audience, the event's goal, team capacity in the window, the QA window, and the metric the event is judged on. State one assumption and say how you would check it. | Tests clarification before structure. No claim about your past. |
| B3 | "Design, art, engineering and community each need a different lead time. Sketch how you'd sequence one update across them." | CASE | [grounded] (the JD line on coordination; no claim about you) | Work backward from the release date: content lock, art and design handoff, engineering build, QA window, community announcement, post-event check. Name the dependency that usually slips and how you would protect it. | Sequencing across four teams is what the JD's coordination line asks for. |
| B4 | "Which of our two titles would you put first, and what would you need to see to decide?" | CASE | [grounded] (the JD line on two mobile titles; no claim about you) | You do not know the titles yet. Say what you would need: retention by segment, team capacity, the next release dates. Give a decision rule, then say what would change it. | Tests judgment under missing information. The JD raises the two titles. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers. How was retention defined, and what was the denominator?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say the definition in your own words if you know it. If you did not set it, say so plainly. Name the weakest assumption you know of behind the figures. If you do not know how they were counted, say so. Do not reconstruct a formula you did not use. | F7 and F3. The quote gives no figure and no method, so the defend-the-number moves are slots, not facts. |
| C2 | "Your release checklist: what did it catch most often?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: if you tracked what it caught, say what and how you counted; if you did not, say so and say what the checklist is for. | F4. The question presumes a count; the second branch allows that none was kept. |
| C3 | "Of the content drops in your two years, which missed their retention target, and why?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if drops had targets, name one that missed and say what you would say about it; if they had none, say so plainly, then describe how a drop was judged. | F1 and F6. "Missed their target" presumes targets, which the quote does not carry. |
| C4 | "How many of your weekly drops went out on time, and what counted as on time?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: give a count only if you have one; say what counted as on time in your team's terms; if you did not track it, say so. Never estimate a count you cannot defend. | F6's scope. The count is yours to give or withhold; the guidance supplies none. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Concede: "I have never led a team." Hold through two follow-ups; concede the leadership gap once, specifically, and do not fold on the calendar. | F9. The hold is the quote you can defend; the concession is one you already made. |
| D2 | "That retention result — how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: you presented the monthly retention numbers to the studio head. If you did not produce the figures, say so. If you did, say which part and stop there. | F7, the attribution probe. Presenting is not producing; the honest answer is which part was yours. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc in your own sentences: the studio, the content-drop calendar, the release checklist, the retention presentation, and what you want next. Use the quotes as your beats. | An opener scored for clarity. Stay with the quotes. |
| E2 | "What are you playing on your phone these days?" | EXP | [generic] | Answer truthfully, in one sentence. If it is a puzzle game, say what you watch in its live calendar. Then turn back to your work. | A casual question, scored for interest and honesty. No claim about your past. |
| E3 | "Why this role, and why now?" | EXP | [generic] | Answer slot: give the reason you actually have, in your own words, and tie it to the calendar and retention work you know. | Motivation is a probe the Skeptic will also try. Your material gives no reason, so the reason is yours to supply. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B4 |
| Coordinate design, art, engineering and community teams on each update | A1, B3 |
| Own the post-event review and the KPIs it reports | A3, C1 |
| Manage the release checklist with QA | C2 |
| 3+ years producing live-service games or apps | A5 |
| Experience running a content calendar | C3, C4 |
| Comfortable with player-retention metrics | C1, D2 |
| Clear written communication | A6 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first 90 days look like to you?" | Scopes the role against its real outcomes. |
| R2 | "Which two titles does the calendar cover, and how far apart are their release cycles?" | Shows you noticed the two-title scope in the posting. |
| R3 | "Where does the post-event review sit today: who writes it, and who reads it?" | Tests the F3 gap in the open and shows what ownership would mean. |
| R4 | "Which KPIs does the live team report upward, and which of them does the calendar move most?" | Links the calendar to the metrics the role owns. |
| R5 | "How does QA sign off a release today, and where does the checklist get pushed back on?" | Shows you know the checklist is a shared tool. |
| R6 | "What did your last content drop teach the team that the dashboard did not show?" | A post-mortem question; signals that you think in reviews. |

No interviewer profile exists, so none of these ties to Tobias's own path. The round is not confirmed as a peer, so no reciprocity question is included.

## Sources

- **Provided:** your message (background, the JD text, your notes on leadership and in-app purchases).
- **Research tier:** L1. Searches 0 of 6 (3 attempted, all refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, absent: no values round detected and no values source supplied |
| 2. Saltmarsh interview process | unavailable | Loop structure; persona weights stay on hiring-manager priors |
| 3. Saltmarsh strategy / recent news | unavailable | CO bank, absent; not sent after the search tool was refused |
| 4. Tobias Wrenfield / Saltmarsh | unavailable | Interviewer read and interviewer-tied reverse questions |
| 5. Representative Live Ops Producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: "Saltmarsh Games values mobile game studio"; "Saltmarsh Games interview process live operations producer"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".

## Upgrade menu

- Confirm the round: whether Tobias is your hiring manager, a peer or a panel member, and whether a take-home or presentation was announced → reweights the persona table and adds a graded section if a deliverable exists.
- Saltmarsh's values page or a loop outline, pasted in → a values cheat sheet and loop-specific banks.
- Tobias's public profile, pasted in → an interviewer read and reverse questions tied to their path.
- The two title names → case questions B3 and B4 become specific instead of generic.
- A `tuesday-dossier.md` → would let F1, F3 and F5 be graded on verified evidence rather than your message alone.
