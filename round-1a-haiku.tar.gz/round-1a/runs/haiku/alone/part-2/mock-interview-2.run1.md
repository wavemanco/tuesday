Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-2-denied-b910986e/2fcda6c5-442c-4846-88aa-7cfe1b4f5b52/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I couldn't research Atlas Freight because the web search permission was declined, so the pack rests on your JD text and your message. I built it on hiring-manager priors, since your note doesn't say who you're meeting.

The main finding: the JD presses three places where your material is thin. Your experience is at one site against their four. You've led three supervisors, not twelve. And Power BI is a stated gap. The pack's highest-ROI prep is the four-site question (A2), because it's the biggest requirement against the thinnest evidence. Your strongest material is the 40% mis-pick cut and the two surge plans, so expect probes on how the 40% was counted (B1) and how much of it was yours (D2).

Other points:
- **Scale gap:** answer from what you did, and for the parts you haven't done, say how you'd approach them.
- **Leadership years:** the JD's "5+ years operations leadership" is a hard requirement. Your message gives seven years of operations work but not how long you've led people.

Offers, one line each:
- I can play the Skeptic on A2, the four-site question, so you can rehearse it live.
- I can save a `tuesday-dossier.md` recording these gaps for later sessions.
- I can convert the pack to a Word document if you want one.

Two questions, which would reshape the pack:
1. Is the person you're meeting your future manager, or a peer on the team? If the recruiter sent focus areas or a prep email, paste them in too.
2. How many years have you led people, as opposed to doing the work? Count only roles where you managed people.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview pack

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Round and relationship: not known, so this pack is built on hiring-manager priors. Research: none run (web search was not permitted), so everything below rests on your JD text and your message.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = stated responsibility or qualification. **EXP** = your past work, probed for attribution. **CASE** = a live problem from the role. **VAL** = values (none detected, so none here). **CO** = company knowledge (none researched, so none here).
- Guidance is scaffolding, not a script. Aim for 90 to 120 seconds spoken.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site, not four. The bridge is the one site's daily operation, in your words. Answer slot: if you have run anything across more than one location or shift structure, say what and how. If not, say so plainly, then say how you would build a daily picture across four sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your measured result is accuracy, not on-time performance or cost. Answer slot: did you track on-time or cost per shipment? If yes, say what and which way it moved. If no, say so, then say how you would set the baseline. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the scope your material shows. The bridge is that scope at its own size. Answer slot: how would you run supervisors through supervisors, and what would you set up first? |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message); "never used Power BI" (your message) | low | [grounded] | capability | Power BI is a stated absence: words "I haven't used Power BI." Then a plan to learn it, said as a plan. Excel is a partial match; say what you built in Excel and what someone did with it, if anything. |
| F5 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | hard_gate | Your material does not establish the leadership years, only the operations years. The pack asks nothing about the gate here beyond the one question in the upgrade menu. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | The quote reaches the requirement. Lead with the certification as stated; do not stretch it to project work you did not describe. |

The pack's observations, in analysis only: your material shows one site (F1), three supervisors (F3), and no Power BI (F4). It does not show how long you have led people (F5).

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily operations across four sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one site. |
| Led twelve supervisors | Inflated form of F3 | F3's quote at its own scope: three supervisors. |
| Built Power BI reporting | Negative you stated, F4 | "I haven't used Power BI." No slot on the Power BI claim itself. |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote: the 40% mis-pick reduction, by redesigning the pick path. |
| Any denominator, baseline or period behind the 40% | Silence in the material | Not supplied. The defend-the-number slot in B1 asks you for it. |

## Persona weights

Relationship is unknown, so these are hiring-manager priors. They are the default for an ops leadership role, where the interviewer is buying capability and derisking gaps. Re-weight when you tell me the round.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 4 (top) | "Where are you weakest?" and the one-site and three-supervisor gaps | High: F1, F3 and F4 are visible gaps against JD requirements | Name the gap first, then the plan. Hold nothing you do not have. |
| Case / Strategist | 4 | A live terminal or surge problem | High: the JD is about running sites daily | Clarify, structure, then answer. Think aloud. |
| Data-Driven Prober | 3 | Asks how the 40% was counted | Medium-high: a headline metric on a CV is a magnet | Name the weakest assumption before they do. Say when you do not know. |
| Pressure | 2 | "How much of that was actually you?" | Medium | Hold through two follow-ups. Concede specifically. |
| Conversational | 2 | "Walk me through the journey." | Medium: casual openers are still scored | 90-second arc from your own sentences. |
| Peer Evaluator | 2 | Seam and credit questions from another site or function | Low to medium: depends on the round | Reciprocity framing. Name principles, not invented seams. |

Total: 18 questions, within the 18 to 26 range.

## Question banks

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message) | Name Power BI first, in your words: "I haven't used Power BI." Then how you would learn it, as a plan with a first step. Answer slot: the four-site scope is the other likely answer. Name it in your own words, and say what you would do in the first 90 days. | F4 is the stated absence the Skeptic can check. JD because it scores the stated requirement. |
| A2 | "Your experience is at one site. How do you run four?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | The highest-ROI rehearsal in this pack. Hold: "The site I ran daily was one site." Answer slot: if you have run anything across more than one location or shift structure, say what and how. If not, say so plainly, then describe the daily picture you would build across four sites: what you would check each morning and whom you would call first. | F1 is the biggest JD requirement against the thinnest evidence, and the JD presses it hardest. The premise "one site" is the quote's own word, "the site's". |
| A3 | "You manage three supervisors. What changes with twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Describe the three supervisors' work in your own words: what you actually did as their manager. Answer slot: how you would run supervisors through supervisors, and what you would set up first. Do not describe a larger team than the one you have led. | F3 is the scope gap; the premise is the quote's own "3 supervisors". |
| A4 | "The role needs five years of operations leadership. How many years have you led people?" | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | Give the years you led people, in your own words, and the roles. If it is fewer than five, say so plainly, then say what the seven years of operations work covers. Do not count years of operations work as years of leadership. | F5 is a hard gate the material does not establish. The question is the gate's own. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the measure you used and the period it covered, in your words. Name the assumption you would defend least before they do. Answer slot: if you do not know the baseline period or how mis-picks were recorded, say so plainly. Do not reconstruct the number live. | The defend-the-number slot for a headline figure. F2's quote is the only measured result in your material. |
| B2 | "What on-time and cost-per-shipment numbers did your site run at, and which way did they move?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the metric you did track: mis-pick rate. Answer slot: if you tracked on-time or cost per shipment, say what and which way it moved. If you did not, say so plainly, then say how you would set the baseline in the first month. | F2's gap. The question presupposes the JD's metrics; the answer's second branch allows they were never yours to track. |
| B3 | "What have you built in Excel that someone acted on? And what would you reach for in Power BI?" | JD | [grounded] "solid Excel" (your message); [grounded] "never used Power BI" (your message) | Excel: say one thing you built and what someone did with it, if there is one. Answer slot: if you have not built a report that someone acted on, say so plainly. Power BI: "I haven't used Power BI." Then how you would start, with the first report you would build. | F4's partial match and its stated absence. The JD raises the reporting requirement directly. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "One of your terminals is eight points behind on-time, and cost per shipment is up. What do you do in your first two weeks?" | CASE | [generic] | Clarify: which terminal, which shifts, what changed. Then structure: volume, labour, dock, and carrier causes. Then data you would pull first and the first action. Think aloud. No claim about your past. | A live problem from the JD's own two performance requirements. Generic because it is a pattern for the problem. |
| C2 | "A peak surge is three weeks out and two supervisors are on leave. Plan it." | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Structure first: demand forecast, labour, cover for the leave, and the decision points. Then say which parts of a surge plan you have actually run, in your own words, and which you would add. Do not describe steps beyond those two runs as yours. | The JD's surge-plan substance is in your material; the question is a live version of it. |
| C3 | "Which one metric would you put on a single daily dashboard for four sites, and why?" | JD | [generic] | Name one metric that ties to the JD's own two performance requirements. Give the reason. Then say what you would not put on the dashboard and why. | Covers the reporting requirement as a decision, not a claim about past builds. |
| C4 | "Which of the four sites would you fix first, and why?" | CASE | [generic] | Clarify what you would need to see on each site. Name a rule for choosing (volume at risk, cost gap, leadership gap). Then give your pick and the reason. No claim about past sites. | Tests judgment across sites without any claim about your history. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has run four sites?" | EXP | [grounded] "7 years in warehouse and distribution ops" and "ran the site's peak-season surge plan two years running" (your message) | Pause, restate the question, then answer from what you have: seven years in warehouse and distribution operations, and two surge plans. Hold the position through two follow-ups. Concede specifically: "I have not run four sites." Do not fold to match a candidate you have not met. | The hold-then-concede structure. The position held is the one your quotes carry. |
| D2 | "That 40% cut: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause. Say which part you did and which part the team did, in your own words. If you redesigned the path yourself, say so. If others shaped it, say that and what you did. Hold through two follow-ups. Concede what you do not know about the attribution. | The attribution probe. The quote does not say whether the redesign was yours alone; the answer must say so plainly, not assume. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: seven years in warehouse and distribution, then the senior shift manager role over three supervisors, then what you want next. Nothing beyond those sentences. | Casual openers are scored. The arc draws only on your own sentences. |
| E2 | "What are you playing with in Power BI these days?" | JD | [grounded] "never used Power BI" (your message) | "I haven't used Power BI yet." Then how you are starting, with the first thing you would build. Do not claim a learning path you have not started. | The conversational form of F4's stated absence. |
| E3 | "What does a normal Tuesday look like for you?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Describe a real shift: the handovers, the supervisor check-ins, the daily numbers. Answer slot: if your Tuesday includes no daily numbers, say so, and say what you look at instead. | Tests daily operating habit, the JD's first responsibility, in a casual register. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Name the seam as a principle: where the handovers are, who owns the decision. For disagreement, describe the process you would use, not a past dispute you have not given. | Peer seam questions test partnership, not history. |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | State a rule you would use: name the people who did the work, and say who decided. If you have a real example, use only what you did. If not, say how you would handle it. | Credit questions are a peer probe. The rule comes first; any example must be your own. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, C4, E3 |
| Drive on-time performance and cost-per-shipment down | B2, C1 |
| Lead a team of 12 supervisors | A3 |
| Build reporting in Excel/Power BI | B3, C3, E2 |
| 5+ years operations leadership required | A4, D1 |
| Lean/Six Sigma a plus | none, and why: F6's quote reaches the requirement; a probe is answered from the Green Belt line |

## Reverse questions

Each one has a "why it lands."

1. "What does success look like for this role in the first ninety days?" Why it lands: it shows you are planning for the job, not for the interview.
2. "Which of the four sites has the biggest gap to on-time target right now?" Why it lands: it shows you have thought about the four-site scope, the requirement you are least able to show.
3. "How do you measure cost per shipment today, and where do the numbers come from?" Why it lands: it shows you care about the data, and it tests whether the reporting work is built or not.
4. "What would the twelve supervisors say is the hardest part of their job?" Why it lands: it asks about the team's real problems, not the job description.
5. "How do the ops managers and the regional leadership work together on the surge plan?" Why it lands: it links to your two surge runs and shows you know peak season is a shared job.

## Sources

- Provided documents: the job description text and your message, as pasted.
- Research tier: L0 (provided documents only). Web search was requested and not permitted, so no search or fetch ran.
- Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (not built: no values detected). Query sent: "Atlas Freight regional logistics company values operations", refused. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. No query sent; research was declined. |
| 3. Atlas Freight strategy / recent news | unavailable | Grounding brief and CO questions. No query sent; research was declined. |
| 4. Interviewer name plus company | n/a | No interviewer name was given, so there is no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- The round and who you are meeting (manager or peer) → re-weights every bank.
- Full JD text, if the excerpt above is not the whole posting → rows F1 to F6 quote the posting's exact wording.
- A fuller account of how long you have led people → F5 moves from `low` confidence and can be quoted into A4.
- Any Power BI or multi-site experience, however small → F1 and F4 can be upgraded, and A1 and A2 get a stronger honest answer.
- Deep research on Atlas Freight (values, strategy, the interview loop) → a grounding brief and a values cheat sheet if the company publishes values. Available on request, with its time cost stated.
- A `tuesday-dossier.md` → verified evidence in place of the quotes above, and its unresolved risks carried into the reverse questions.
