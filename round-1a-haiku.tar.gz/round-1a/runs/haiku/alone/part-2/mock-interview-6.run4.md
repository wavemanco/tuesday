Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-6-denied-a9d6b589/27b91b8d-2e7f-4a62-9762-f196e0f0c5ba/scratchpad/larkfield_engineering-manager_interview_pack.md`. It is built on your role summary and background. I couldn't run web research because search permission wasn't granted, so the pack has no company values, interview-loop or strategy facts, and the VP round's values questions use scaffolds.

# Interview pack: Engineering Manager, Larkfield Systems

**Mode:** loop mode, three scheduled rounds. **Candidate:** Yusuf. **Built on:** your role summary and your background, as sent. No full posting. No web research (search permission was not granted).

| Round | Date | Who | Length | Persona weights |
|---|---|---|---|---|
| A | Tuesday | Director of Engineering (hiring manager, your future boss) | 45 min | Skeptic 4, Case/Strategist 3, Prober 2 |
| B | Thursday, the week after | Panel: two staff engineers and a product manager | 60 min | Prober 3, Peer Evaluator 2, Pressure 2, Case/Strategist 2 |
| C | Following Monday | VP Engineering, "values and leadership philosophy" | 30 min | Values/Behavioral 4, Pressure 2, Case/Strategist 2 |

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it scores: **VAL** (behavioural and values fit), **EXP** (your experience, and whether it survives scrutiny), **JD** (the role's own requirements), **CO** (company strategy), **CASE** (a live problem).
- Question IDs are lettered by round: A for Tuesday, B for Thursday, C for Monday.
- Guidance is scaffolding, not a script. Each guidance cell is written to be said aloud in about 90 to 120 seconds.
- **Answer slot:** an instruction for the interview. It is not a question to me, and it ends with a full stop.
- Provenance: `[grounded]` means traceable to your own words. `[inferred]` means a derivation I made. `[generic]` means a pattern for this kind of role, with no claim about Larkfield or about you.

## Prep triage

Dropped. Your prep time is not stated.

## Fit snapshot

Requirements are quoted from your role summary. Your background is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says a team of six, not two squads, and says nothing about device management. Bridge: "For three years I was team lead of six." Answer slot: if you have led more than one team, or led people through other leads, say what that was in your own words; if you have not, say so, and describe how you would split eleven engineers into two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | The quote already reaches delivery in its own terms. Bridge: "I pushed a reliability quarter through against roadmap pressure." The 60% raises the defend-the-number slots in A8 and B1. The pack supplies no counting method for it. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | Hiring is reached in role terms, at backend scope. Bridge: "I run our hiring loop for backend roles." Keep the scope at backend. Eleven engineers and device roles are not in the quote. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message), growth part | none given | none | [grounded] | discovery | Your material does not show growth work: no development, promotion or ramp is named. Answer slot: if you have grown people, say what you did and what changed for them; if you have not run a growth process, say so and say how you would start with eleven engineers. |
| F5 | "Lead two squads building device-management services" (your message), domain part | "currently at a payments company" (your message) | medium | [grounded] | transferability | Your material places you in payments, not in device management or industrial IoT. Bridge: "I'm currently at a payments company." Answer slot: if any of your payments work touched devices, connectivity or telemetry, say what it was; if none did, say so and name the operational habit you would carry over, in your own words. |
| F6 | "partner with hardware and product on roadmap" (your message), hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | high | [grounded] | capability | Stated absence, from your own message. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | "partner with hardware and product on roadmap" (your message), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Adjacent work: you have pushed roadmap trade-offs under pressure, with product-side demands. It is not hardware-roadmap work. Bridge: "I pushed a reliability quarter through against roadmap pressure." Do not stretch it to a hardware roadmap. |
| F8 | Leading the leads of two squads (derived from "Lead two squads building device-management services"; the summary does not say the squads have leads, so this is a derivation) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message), managers part | high | [grounded] | capability | Stated absence, from your own message. Words: "I've never managed managers." Then how you would learn it, said as a plan and never as a past. |

**Gate check.** No gate row. Your role summary names no location, on-site, or work-authorisation term. Question 2 below asks about it.

## Prohibited claims

The pack will not coach any of these, and no answer, hold, bridge or reverse question asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1: "team lead of 6" stretched to a wider scope | F1's quote at its own scope. Analysis only: your material says six, not two squads. |
| Has managed managers | Stated negative, F8 | "I've never managed managers." Plain acknowledgment. No answer slot. |
| Owned a hardware-adjacent roadmap | Stated negative, F6 | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment. No answer slot. |
| Ran hiring across the whole function | Inflated form of F3: "backend roles" widened | "I run our hiring loop for backend roles." Scope stays at backend. |
| The on-call drop was caused by my quarter alone | Inflated form of F2: "after" stretched to "because" | "after I pushed a reliability quarter through." Analysis only: your material says after, not cause. |

## Persona table

**Round A, Tuesday, Director of Engineering.** The hiring-manager prior weights Skeptic and Case highest. There is no interviewer profile, so there is no adjustment.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the two stated gaps: managing managers and hardware roadmap | High. A hiring manager is buying capability and checking gaps. F6 and F8 are the absences most likely to be probed | Name each gap in your own words, then a plan. Hold your scope. Do not claim experience |
| Case/Strategist | Live roadmap and delivery problems | Medium. Hiring-manager rounds usually include a live problem | Clarify first, then structure, then decide |
| Prober | Counts the 60% and the 40 interviews | Low to medium. Figures in your message invite questions | Say how each was counted, or say you do not know |

**Round B, Thursday, panel.** Panel members are not named. Personas are blended across the members, with the staff engineers as Prober and Pressure and the product manager as Peer Evaluator and Case.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Prober | Asks for the denominator and the decision rule | High, from the staff engineers. The 60% and the hiring loop are the figures to test | Name the weakest assumption before they do |
| Peer Evaluator | Seams with hardware, credit, disagreement | Medium, from the product manager. Peer rounds price what the hire costs their work | Propose seam principles. Do not claim a seam you have not run |
| Pressure | Holds you to the reliability quarter, and to the hardware gap | Medium, from the staff engineers | Hold the statement you made. Concede the specific gap |
| Case/Strategist | Roadmap trade-off with hardware and product | Medium, from the product manager | Clarify the constraint, then give options and a decision |

**Round C, Monday, VP Engineering.** The recruiter's own words name a values and leadership round. That makes it a loop source, so the Values/Behavioral persona is weighted highest.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Asks for a time you delivered an unpopular truth, a leadership philosophy | High. The recruiter named this round as values and leadership | Use a story with a named stake. If none comes to mind, say so, then use the nearest thing your material carries |
| Pressure | Asks why you over someone who has managed managers | Medium. A VP tests the top gap | Hold the strongest true fact. Concede the gap plainly |
| Case/Strategist | Strategy-level question about the two squads and the partners | Medium. The VP is skip-level and altitude matters | Clarify, then structure, then name a first priority |

## Question banks

**Round A, Tuesday, Director of Engineering (45 min).** Nine questions. Skeptic 4, Case 3, Prober 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Name the two stated gaps in your own words: "I've never managed managers," and "I haven't owned a hardware-adjacent roadmap." Then give a plan for each, as a plan: what you would do in the first 90 days. Do not add experience. Hold two follow-ups by returning to the plan. | F6 and F8 are the two gaps the role maps onto. JD because it scores the role's own requirements, Skeptic because it invites you to name the gap first. |
| A2 | "I don't see managing managers in your background. How would you lead two squads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | **Highest-ROI prep in this pack.** Open with the plain acknowledgment: "I've never managed managers." Then the plan, as a plan: how you would set up and support the leads, how you would check their work, and when you would step in. Answer slot: if you have led people through other leads in any form, say what it was; if you have not, say so plainly and stay with the plan. Hold through two follow-ups by returning to the plan. Never describe manager-of-manager experience. | F8 is the gap most likely to be probed, and it sits where your material is thinnest. The question presupposes only the stated absence and the role's "lead two squads", both sourced. |
| A3 | "You lead six today. How would you lead two squads of 11 engineers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Use the quote's own scope: "For three years I was team lead of six." Then the plan for two squads, as a plan. Answer slot: if you have led more than one team, say what that was; if you have not, say so and describe how you would split 11 engineers. | F1 is transferability: a team of six is adjacent to two squads, not the same. |
| A4 | "Why this role, now, and why hardware after payments?" | JD | [grounded] "currently at a payments company" (your message) | Scaffold: state the pull in terms of the work, in your own words. If the pull is mostly away from payments, say so plainly. Do not claim a hardware interest you cannot show. | The Skeptic's motivation probe. No quote carries a motivation, so the guidance is a scaffold, and it claims nothing about why you want the role. |
| A5 | "Device-management services are late. Hardware says the fix needs a firmware release your team does not control. What do you do?" | CASE | [generic] | Clarify first: what is late, what customers see, and who owns the firmware date. Then objective, options, your decision, and the risk you would carry. Name the hardware counterpart you would call and the question you would ask them. | A live problem from "partner with hardware". It asks about no past, so it makes no claim about you. |
| A6 | "Two customer groups want the same device feature this quarter, and one squad has the capacity. How do you decide?" | CASE | [generic] | Clarify the constraint and what each group would lose. Lay out two or three options, the one you would pick, and what you would tell the group that loses. | A live roadmap trade-off. It asks about no past. |
| A7 | "You need two senior device engineers in six weeks. The hiring loop you run is for backend roles. What changes?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Start from the loop you run: "I run our hiring loop for backend roles." Say what you would keep and what you would change for device roles: the bar, the exercises, the people on the panel. Keep it a plan. Answer slot: if you have changed a loop for a new kind of role, say what; if you have not, say so. | F3 is the loop you run. The change is a plan, not a record. |
| A8 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number answer slot, in your own words: say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you know the counting method, say it. If you do not, say so. Then state your part as the quote states it: you pushed the quarter through. | F2's figure. The pack supplies no counting method, and "I don't know how it was counted" is an honest branch. |
| A9 | "How do you count the 40 interviews you ran last year?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Answer slot: say which of those interviews you ran yourself and which you joined, and how you counted. If you do not know the split, say so. The count is your figure to defend. | Defend-the-number slot on the hiring figure, F3. |

**Round A reverse questions.** Each one is for the Director.

| # | Question | Why it lands |
|---|---|---|
| RA1 | "What would success look like at six months, and what would tell you it is going wrong?" | It shows you are planning against how the role will be scored. |
| RA2 | "Which of the two squads needs the most help in the first quarter?" | It turns the gap into a conversation about where you would start. |
| RA3 | "What hardware decision in the last quarter would you want your manager to have an opinion on?" | It opens the partnership ground the role names, and asks for the Director's view. |

**Round B, Thursday, panel (60 min).** Nine questions. Prober 3, Peer 2, Pressure 2, Case 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What does the 60% include, and what does it leave out?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Answer slot: say what is in the measure and what is not, in your words. If you do not know the denominator, say so. | Prober's denominator probe on the figure in F2. |
| B2 | "How do you decide a candidate passes your loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Open prompt. State your decision rule in your own words. If the rule is your team's, say whose it is. If you have no written rule, say so. | Prober's decision-rule probe. It rests on the loop you run, F3. |
| B3 | "Did the reliability quarter cost the roadmap anything, and who decided?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: name anything deferred and who decided it. If nothing was deferred, or the call was not yours, say so and describe the pressure. | Premise: the quote carries roadmap pressure, not a deferral. The question asks about the cost and leaves the answer open. |
| B4 | "Where does your squad's work end and the hardware team's begin, and what happens when you disagree?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Propose seam principles, not a seam you have run. As you said, you have not owned a hardware-adjacent roadmap. Say the principle you would start from, and how you would settle a disagreement: who decides, and on what. | Peer Evaluator seam probe. Your guidance claims nothing about a seam you have run. |
| B5 | "How do you handle credit when work spans teams?" | JD | [generic] | Say how you name who did what, in your own words. If a piece of work is yours, name your part precisely. | Peer credit-sharing probe. The guidance makes no claim about your past. |
| B6 | "That reliability quarter: how much of the result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold the statement you made: "I pushed the quarter through." Through two follow-ups, return to what you did. If you cannot separate your share from the team's, concede that specifically: name the part of the drop you cannot attribute. Do not concede the push itself. | Pressure: hold, then concede a specific point. The held position is the one in your quote. |
| B7 | "You run backend hiring. Why should a staff engineer trust your call on firmware?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message); "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Hold your scope: you run the backend hiring loop. Concede the gap plainly: you have not owned a hardware-adjacent roadmap, and you would not claim firmware judgment. Hold through two follow-ups before you concede anything more. | Pressure, on the hardware gap in F6. |
| B8 | "Hardware says a device release slips six months. Product wants the feature this quarter. What is your call?" | CASE | [generic] | Clarify: what the feature unlocks, what a slip costs, and what hardware can commit to. Pick an option. Name the decision owner and what you would tell product. | A live roadmap trade-off from "partner with hardware and product on roadmap". |
| B9 | "Pick one roadmap item to cut for reliability work. How do you decide?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Name the decision criteria first: cost, risk, and customer impact. Then give one example from your material, in the quote's words. Answer slot: if you cut something for the reliability work, say what and who agreed; if the cut was not yours to make, say so. | Adjacent to F7. The example stays at the quote's scope. |

**Round B reverse questions.**

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer panel rewards. It moves the conversation from what you need to what you bring. |
| RB2 | "Which roadmap call with hardware in the last two quarters would you have made differently?" | It opens the seam story, and asks the product manager for judgment. |
| RB3 | "Where has the device-management stack been most fragile, and who owns that today?" | It shows technical interest without claiming knowledge you do not have. |

**Round C, Monday, VP Engineering (30 min).** Eight questions. Values/Behavioral 4, Pressure 2, Case 2. Larkfield's published values are not in hand, so there is no values cheat sheet. The VAL questions use selection scaffolds with honest branches.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, the words you actually used, and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in the words above. | The recruiter named a values round. The theme comes from the persona stem, and no published values are in hand. |
| C2 | "When did you put a customer's need ahead of an internal metric?" | VAL | [generic] | Scaffold: a decision where a customer's outcome beat a number you were measured on. If you have no such decision, say so plainly. Do not supply a customer story. | Your material holds no customer story, so the honest branch is required. |
| C3 | "What is your leadership philosophy, in a sentence, and where did it come from?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Give the sentence in your own words, then one example from your material, kept at the quote's scope. Do not name a principle you cannot show. | The philosophy must rest on something you said. The reliability quarter is the strongest example you have. |
| C4 | "How do you grow engineers who could take your job?" | VAL | [generic] | Selection scaffold: name a person you developed and what changed for them. If you have not developed someone toward a larger role, say so, then say how you would start with eleven engineers. | The role's "growth" line is the raising source. F4 is discovery. |
| C5 | "You have not managed managers. Why should I believe you can lead leads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Hold: "I've never managed managers." Hold the plan you gave in A2. Through two follow-ups, return to the plan. Concede the uncertainty specifically: say which part you are not sure of. Do not fold on the core. | Pressure, hold-then-concede, on the top gap. The VP is the one who would decide it. |
| C6 | "Sixty seconds: why you over an internal leader who has managed managers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Hold the strongest true fact: "9 years engineering, 3 as a team lead of 6." Concede the gap plainly: an internal leader has managed managers, and you have not. Do not argue it away. | Pressure stem. It rests only on F1's quote. |
| C7 | "What is the first question you would ask our product and hardware leads?" | CASE | [generic] | Clarify: what product commits to, what hardware can commit to, and where the two disagree. | A strategy-level live question. It makes no claim about you. |
| C8 | "You inherit two squads with a delivery slip. What are your first 30 days?" | CASE | [generic] | Clarify the facts. Talk to the squad members and both partners. Name one priority, and decide what you will stop. | A plan question. It asks about no past. |

**Round C reverse questions.**

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What does the company need from its engineering managers in the next year that it does not have yet?" | It asks at the VP's altitude, and invites a strategy answer. |
| RC2 | "When hardware and product disagree on a date, how is that call made today?" | It tests how decisions get made, which is the governance question a VP owns. |
| RC3 | "What would you need to see in the first 90 days to be confident in this hire?" | It shows you expect to be measured, and asks what the measure is. |

## Coverage: stated requirements to question IDs

| Requirement | Question IDs |
|---|---|
| "Lead two squads building device-management services" | A3, A5, A6, C8 |
| "own delivery, hiring and growth for 11 engineers": delivery | A8, B9, C8 |
| "own delivery, hiring and growth for 11 engineers": hiring | A7, A9, B2 |
| "own delivery, hiring and growth for 11 engineers": growth | C4 (F4 is discovery, so the answer slot is in C4) |
| "partner with hardware and product on roadmap": hardware | A1, A5, B4, B8 |
| "partner with hardware and product on roadmap": product | B3, B8, B9 |
| Leading the leads of two squads (inferred from the role line) | A2, C5 |

Industrial IoT appears in the company description, not as a separate requirement. A5 and B8 cover it.

## Sources

- Provided: your message. It holds the role summary and your background.
- Research: three web searches were sent. Each was refused, because permission to use the search tool was not granted. No fetches were sent.
  - "Larkfield Systems values": refused
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT strategy news": refused

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, section 10. Its absence is why the VAL questions in round C use scaffolds |
| 2. Larkfield interview process | unavailable | Loop structure. Your message names the three rounds and who runs each, so the loop is established and no archetype fallback is needed |
| 3. Larkfield strategy / recent news | unavailable | The CO bank and the strategy-level CASE questions. None are in this pack, and C7 and A6 are generic |
| 4. Interviewer name and Larkfield | n/a | No interviewer names were given. The interviewer read is absent |
| 5. Representative role JD | skipped | Your role summary supplies the requirements the fit snapshot draws on. The full posting is still missing (question 1 below) |

Values-style round: detected, because the recruiter's own words name a values and leadership round. Section 10 is dropped because no published values are in hand.

No interviewer profile exists, so the interviewer read is dropped. The grounding brief is dropped because no strategy brief was run. No graded deliverable was declared. No working-style assessment was given.

## Upgrade menu

- **The full posting text** → any requirement your summary dropped becomes a fit row, and the summary's lines are checked against the full wording.
- **The names of the Director, the two staff engineers, the product manager, and the VP** → persona assignment per panel member, and one tailored reverse question for each interviewer.
- **Any deliverable or focus areas the recruiter named for the panel or the VP round** → graded-deliverable sections.
- **Larkfield's published values page, pasted** → the values cheat sheet (section 10), with each value mapped to a story your quoted sentences carry, where one exists.
- **Permission to run web search** → an L1 pass: values, interview loop structure, and strategy. Today the CO questions are generic. Your three refused searches would become `yes` rows.
- **A deeper research pass**, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief, interviewer public talks, role-family loop reports, and recent org context.
- **How the 60% and the 40 interviews were counted**, in your own words → quoted material. Answer slots A8, A9 and B1 regenerate around it.
- **A location, on-site, or right-to-work term, if the posting has one** → a gate row, surfaced as a hard gate.
- **A `tuesday-dossier.md`, if you have one** → verified evidence and the underwriter's prohibited claims would replace the prohibited list built here. Without one, the list rests on your message alone.

---

I can also play the Director on A2, the highest-value question, and give feedback against its guidance. Say the word and I'll start.
I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full posting? Your summary covers the lines the pack is built on, and the posting may hold requirements it drops.
2. Does the role carry a location, on-site, or right-to-work term? Your summary doesn't say, and a term like that would become a gate row.
3. Did the recruiter name any deliverable or focus areas for the panel or the VP round? A declared deliverable would change the pack's structure.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Mode:** loop mode, three scheduled rounds. **Candidate:** Yusuf. **Built on:** your role summary and your background, as sent. No full posting. No web research (search permission was not granted).

| Round | Date | Who | Length | Persona weights |
|---|---|---|---|---|
| A | Tuesday | Director of Engineering (hiring manager, your future boss) | 45 min | Skeptic 4, Case/Strategist 3, Prober 2 |
| B | Thursday, the week after | Panel: two staff engineers and a product manager | 60 min | Prober 3, Peer Evaluator 2, Pressure 2, Case/Strategist 2 |
| C | Following Monday | VP Engineering, "values and leadership philosophy" | 30 min | Values/Behavioral 4, Pressure 2, Case/Strategist 2 |

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it scores: **VAL** (behavioural and values fit), **EXP** (your experience, and whether it survives scrutiny), **JD** (the role's own requirements), **CO** (company strategy), **CASE** (a live problem).
- Question IDs are lettered by round: A for Tuesday, B for Thursday, C for Monday.
- Guidance is scaffolding, not a script. Each guidance cell is written to be said aloud in about 90 to 120 seconds.
- **Answer slot:** an instruction for the interview. It is not a question to me, and it ends with a full stop.
- Provenance: `[grounded]` means traceable to your own words. `[inferred]` means a derivation I made. `[generic]` means a pattern for this kind of role, with no claim about Larkfield or about you.

## Prep triage

Dropped. Your prep time is not stated.

## Fit snapshot

Requirements are quoted from your role summary. Your background is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says a team of six, not two squads, and says nothing about device management. Bridge: "For three years I was team lead of six." Answer slot: if you have led more than one team, or led people through other leads, say what that was in your own words; if you have not, say so, and describe how you would split eleven engineers into two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | The quote already reaches delivery in its own terms. Bridge: "I pushed a reliability quarter through against roadmap pressure." The 60% raises the defend-the-number slots in A8 and B1. The pack supplies no counting method for it. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | Hiring is reached in role terms, at backend scope. Bridge: "I run our hiring loop for backend roles." Keep the scope at backend. Eleven engineers and device roles are not in the quote. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message), growth part | none given | none | [grounded] | discovery | Your material does not show growth work: no development, promotion or ramp is named. Answer slot: if you have grown people, say what you did and what changed for them; if you have not run a growth process, say so and say how you would start with eleven engineers. |
| F5 | "Lead two squads building device-management services" (your message), domain part | "currently at a payments company" (your message) | medium | [grounded] | transferability | Your material places you in payments, not in device management or industrial IoT. Bridge: "I'm currently at a payments company." Answer slot: if any of your payments work touched devices, connectivity or telemetry, say what it was; if none did, say so and name the operational habit you would carry over, in your own words. |
| F6 | "partner with hardware and product on roadmap" (your message), hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | high | [grounded] | capability | Stated absence, from your own message. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | "partner with hardware and product on roadmap" (your message), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Adjacent work: you have pushed roadmap trade-offs under pressure, with product-side demands. It is not hardware-roadmap work. Bridge: "I pushed a reliability quarter through against roadmap pressure." Do not stretch it to a hardware roadmap. |
| F8 | Leading the leads of two squads (derived from "Lead two squads building device-management services"; the summary does not say the squads have leads, so this is a derivation) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message), managers part | high | [grounded] | capability | Stated absence, from your own message. Words: "I've never managed managers." Then how you would learn it, said as a plan and never as a past. |

**Gate check.** No gate row. Your role summary names no location, on-site, or work-authorisation term. Step 1 asks about it.

## Prohibited claims

The pack will not coach any of these, and no answer, hold, bridge or reverse question asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1: "team lead of 6" stretched to a wider scope | F1's quote at its own scope. Analysis only: your material says six, not two squads. |
| Has managed managers | Stated negative, F8 | "I've never managed managers." Plain acknowledgment. No answer slot. |
| Owned a hardware-adjacent roadmap | Stated negative, F6 | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment. No answer slot. |
| Ran hiring across the whole function | Inflated form of F3: "backend roles" widened | "I run our hiring loop for backend roles." Scope stays at backend. |
| The on-call drop was caused by my quarter alone | Inflated form of F2: "after" stretched to "because" | "after I pushed a reliability quarter through." Analysis only: your material says after, not cause. |

## Persona table

**Round A, Tuesday, Director of Engineering.** The hiring-manager prior weights Skeptic and Case highest. There is no interviewer profile, so there is no adjustment.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the two stated gaps: managing managers and hardware roadmap | High. A hiring manager is buying capability and checking gaps. F6 and F8 are the absences most likely to be probed | Name each gap in your own words, then a plan. Hold your scope. Do not claim experience |
| Case/Strategist | Live roadmap and delivery problems | Medium. Hiring-manager rounds usually include a live problem | Clarify first, then structure, then decide |
| Prober | Counts the 60% and the 40 interviews | Low to medium. Figures in your message invite questions | Say how each was counted, or say you do not know |

**Round B, Thursday, panel.** Panel members are not named. Personas are blended across the members, with the staff engineers as Prober and Pressure and the product manager as Peer Evaluator and Case.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Prober | Asks for the denominator and the decision rule | High, from the staff engineers. The 60% and the hiring loop are the figures to test | Name the weakest assumption before they do |
| Peer Evaluator | Seams with hardware, credit, disagreement | Medium, from the product manager. Peer rounds price what the hire costs their work | Propose seam principles. Do not claim a seam you have not run |
| Pressure | Holds you to the reliability quarter, and to the hardware gap | Medium, from the staff engineers | Hold the statement you made. Concede the specific gap |
| Case/Strategist | Roadmap trade-off with hardware and product | Medium, from the product manager | Clarify the constraint, then give options and a decision |

**Round C, Monday, VP Engineering.** The recruiter's own words name a values and leadership round. That makes it a loop source, so the Values/Behavioral persona is weighted highest.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Asks for a time you delivered an unpopular truth, a leadership philosophy | High. The recruiter named this round as values and leadership | Use a story with a named stake. If none comes to mind, say so, then use the nearest thing your material carries |
| Pressure | Asks why you over someone who has managed managers | Medium. A VP tests the top gap | Hold the strongest true fact. Concede the gap plainly |
| Case/Strategist | Strategy-level question about the two squads and the partners | Medium. The VP is skip-level and altitude matters | Clarify, then structure, then name a first priority |

## Question banks

**Round A, Tuesday, Director of Engineering (45 min).** Nine questions. Skeptic 4, Case 3, Prober 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Name the two stated gaps in your own words: "I've never managed managers," and "I haven't owned a hardware-adjacent roadmap." Then give a plan for each, as a plan: what you would do in the first 90 days. Do not add experience. Hold two follow-ups by returning to the plan. | F6 and F8 are the two gaps the role maps onto. JD because it scores the role's own requirements, Skeptic because it invites you to name the gap first. |
| A2 | "I don't see managing managers in your background. How would you lead two squads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | **Highest-ROI prep in this pack.** Open with the plain acknowledgment: "I've never managed managers." Then the plan, as a plan: how you would set up and support the leads, how you would check their work, and when you would step in. Answer slot: if you have led people through other leads in any form, say what it was; if you have not, say so plainly and stay with the plan. Hold through two follow-ups by returning to the plan. Never describe manager-of-manager experience. | F8 is the gap most likely to be probed, and it sits where your material is thinnest. The question presupposes only the stated absence and the role's "lead two squads", both sourced. |
| A3 | "You lead six today. How would you lead two squads of 11 engineers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Use the quote's own scope: "For three years I was team lead of six." Then the plan for two squads, as a plan. Answer slot: if you have led more than one team, say what that was; if you have not, say so and describe how you would split 11 engineers. | F1 is transferability: a team of six is adjacent to two squads, not the same. |
| A4 | "Why this role, now, and why hardware after payments?" | JD | [grounded] "currently at a payments company" (your message) | Scaffold: state the pull in terms of the work, in your own words. If the pull is mostly away from payments, say so plainly. Do not claim a hardware interest you cannot show. | The Skeptic's motivation probe. No quote carries a motivation, so the guidance is a scaffold, and it claims nothing about why you want the role. |
| A5 | "Device-management services are late. Hardware says the fix needs a firmware release your team does not control. What do you do?" | CASE | [generic] | Clarify first: what is late, what customers see, and who owns the firmware date. Then objective, options, your decision, and the risk you would carry. Name the hardware counterpart you would call and the question you would ask them. | A live problem from "partner with hardware". It asks about no past, so it makes no claim about you. |
| A6 | "Two customer groups want the same device feature this quarter, and one squad has the capacity. How do you decide?" | CASE | [generic] | Clarify the constraint and what each group would lose. Lay out two or three options, the one you would pick, and what you would tell the group that loses. | A live roadmap trade-off. It asks about no past. |
| A7 | "You need two senior device engineers in six weeks. The hiring loop you run is for backend roles. What changes?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Start from the loop you run: "I run our hiring loop for backend roles." Say what you would keep and what you would change for device roles: the bar, the exercises, the people on the panel. Keep it a plan. Answer slot: if you have changed a loop for a new kind of role, say what; if you have not, say so. | F3 is the loop you run. The change is a plan, not a record. |
| A8 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number answer slot, in your own words: say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you know the counting method, say it. If you do not, say so. Then state your part as the quote states it: you pushed the quarter through. | F2's figure. The pack supplies no counting method, and "I don't know how it was counted" is an honest branch. |
| A9 | "How do you count the 40 interviews you ran last year?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Answer slot: say which of those interviews you ran yourself and which you joined, and how you counted. If you do not know the split, say so. The count is your figure to defend. | Defend-the-number slot on the hiring figure, F3. |

**Round A reverse questions.** Each one is for the Director. Why each one lands is in the right-hand column.

| # | Question | Why it lands |
|---|---|---|
| RA1 | "What would success look like at six months, and what would tell you it is going wrong?" | It shows you are planning against how the role will be scored. |
| RA2 | "Which of the two squads needs the most help in the first quarter?" | It turns the gap into a conversation about where you would start. |
| RA3 | "What hardware decision in the last quarter would you want your manager to have an opinion on?" | It opens the partnership ground the role names, and asks for the Director's view. |

**Round B, Thursday, panel (60 min).** Nine questions. Prober 3, Peer 2, Pressure 2, Case 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What does the 60% include, and what does it leave out?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Answer slot: say what is in the measure and what is not, in your words. If you do not know the denominator, say so. | Prober's denominator probe on the figure in F2. |
| B2 | "How do you decide a candidate passes your loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Open prompt. State your decision rule in your own words. If the rule is your team's, say whose it is. If you have no written rule, say so. | Prober's decision-rule probe. It rests on the loop you run, F3. |
| B3 | "Did the reliability quarter cost the roadmap anything, and who decided?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: name anything deferred and who decided it. If nothing was deferred, or the call was not yours, say so and describe the pressure. | Premise: the quote carries roadmap pressure, not a deferral. The question asks about the cost and leaves the answer open. |
| B4 | "Where does your squad's work end and the hardware team's begin, and what happens when you disagree?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Propose seam principles, not a seam you have run. As you said, you have not owned a hardware-adjacent roadmap. Say the principle you would start from, and how you would settle a disagreement: who decides, and on what. | Peer Evaluator seam probe. Your guidance claims nothing about a seam you have run. |
| B5 | "How do you handle credit when work spans teams?" | JD | [generic] | Say how you name who did what, in your own words. If a piece of work is yours, name your part precisely. | Peer credit-sharing probe. The guidance makes no claim about your past. |
| B6 | "That reliability quarter: how much of the result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold the statement you made: "I pushed the quarter through." Through two follow-ups, return to what you did. If you cannot separate your share from the team's, concede that specifically: name the part of the drop you cannot attribute. Do not concede the push itself. | Pressure: hold, then concede a specific point. The held position is the one in your quote. |
| B7 | "You run backend hiring. Why should a staff engineer trust your call on firmware?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message); "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Hold your scope: you run the backend hiring loop. Concede the gap plainly: you have not owned a hardware-adjacent roadmap, and you would not claim firmware judgment. Hold through two follow-ups before you concede anything more. | Pressure, on the hardware gap in F6. |
| B8 | "Hardware says a device release slips six months. Product wants the feature this quarter. What is your call?" | CASE | [generic] | Clarify: what the feature unlocks, what a slip costs, and what hardware can commit to. Pick an option. Name the decision owner and what you would tell product. | A live roadmap trade-off from "partner with hardware and product on roadmap". |
| B9 | "Pick one roadmap item to cut for reliability work. How do you decide?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Name the decision criteria first: cost, risk, and customer impact. Then give one example from your material, in the quote's words. Answer slot: if you cut something for the reliability work, say what and who agreed; if the cut was not yours to make, say so. | Adjacent to F7. The example stays at the quote's scope. |

**Round B reverse questions.**

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer panel rewards. It moves the conversation from what you need to what you bring. |
| RB2 | "Which roadmap call with hardware in the last two quarters would you have made differently?" | It opens the seam story, and asks the product manager for judgment. |
| RB3 | "Where has the device-management stack been most fragile, and who owns that today?" | It shows technical interest without claiming knowledge you do not have. |

**Round C, Monday, VP Engineering (30 min).** Eight questions. Values/Behavioral 4, Pressure 2, Case 2. The recruiter named this round as values and leadership. Larkfield's published values are not in hand, so there is no values cheat sheet. The VAL questions below use selection scaffolds with honest branches.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, the words you actually used, and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in the words above. | The recruiter named a values round. The theme comes from the persona stem, and no published values are in hand. |
| C2 | "When did you put a customer's need ahead of an internal metric?" | VAL | [generic] | Scaffold: a decision where a customer's outcome beat a number you were measured on. If you have no such decision, say so plainly. Do not supply a customer story. | Your material holds no customer story, so the honest branch is required. |
| C3 | "What is your leadership philosophy, in a sentence, and where did it come from?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Give the sentence in your own words, then one example from your material, kept at the quote's scope. Do not name a principle you cannot show. | The philosophy must rest on something you said. The reliability quarter is the strongest example you have. |
| C4 | "How do you grow engineers who could take your job?" | VAL | [generic] | Selection scaffold: name a person you developed and what changed for them. If you have not developed someone toward a larger role, say so, then say how you would start with eleven engineers. | The role's "growth" line is the raising source. F4 is discovery. |
| C5 | "You have not managed managers. Why should I believe you can lead leads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Hold: "I've never managed managers." Hold the plan you gave in A2. Through two follow-ups, return to the plan. Concede the uncertainty specifically: say which part you are not sure of. Do not fold on the core. | Pressure, hold-then-concede, on the top gap. The VP is the one who would decide it. |
| C6 | "Sixty seconds: why you over an internal leader who has managed managers?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Hold the strongest true fact: "9 years engineering, 3 as a team lead of 6." Concede the gap plainly: an internal leader has managed managers, and you have not. Do not argue it away. | Pressure stem. It rests only on F1's quote. |
| C7 | "What is the first question you would ask our product and hardware leads?" | CASE | [generic] | Clarify: what product commits to, what hardware can commit to, and where the two disagree. | A strategy-level live question. It makes no claim about you. |
| C8 | "You inherit two squads with a delivery slip. What are your first 30 days?" | CASE | [generic] | Clarify the facts. Talk to the squad members and both partners. Name one priority, and decide what you will stop. | A plan question. It asks about no past. |

**Round C reverse questions.**

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What does the company need from its engineering managers in the next year that it does not have yet?" | It asks at the VP's altitude, and invites a strategy answer. |
| RC2 | "When hardware and product disagree on a date, how is that call made today?" | It tests how decisions get made, which is the governance question a VP owns. |
| RC3 | "What would you need to see in the first 90 days to be confident in this hire?" | It shows you expect to be measured, and asks what the measure is. |

## Coverage: stated requirements to question IDs

| Requirement | Question IDs |
|---|---|
| "Lead two squads building device-management services" | A3, A5, A6, C8 |
| "own delivery, hiring and growth for 11 engineers": delivery | A8, B9, C8 |
| "own delivery, hiring and growth for 11 engineers": hiring | A7, A9, B2 |
| "own delivery, hiring and growth for 11 engineers": growth | C4 (F4 is discovery, so the answer slot is in C4) |
| "partner with hardware and product on roadmap": hardware | A1, A5, B4, B8 |
| "partner with hardware and product on roadmap": product | B3, B8, B9 |
| Leading the leads of two squads (inferred from the role line) | A2, C5 |

Industrial IoT appears in the company description, not as a separate requirement. A5 and B8 cover it.

## Sources

- Provided: your message. It holds the role summary and your background.
- Research: three web searches were sent. Each was refused, because permission to use the search tool was not granted. No fetches were sent.
  - "Larkfield Systems values": refused
  - "Larkfield Systems interview process engineering manager": refused
  - "Larkfield Systems industrial IoT strategy news": refused

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, section 10. Its absence is why the VAL questions in round C use scaffolds |
| 2. Larkfield interview process | unavailable | Loop structure. Your message names the three rounds and who runs each, so the loop is established and no archetype fallback is needed |
| 3. Larkfield strategy / recent news | unavailable | The CO bank and the strategy-level CASE questions. None are in this pack, and C7 and A6 are generic |
| 4. Interviewer name and Larkfield | n/a | No interviewer names were given. The interviewer read is absent |
| 5. Representative role JD | skipped | Your role summary supplies the requirements the fit snapshot draws on. The full posting is still missing (Step 1 question) |

Values-style round: detected, because the recruiter's own words name a values and leadership round. Section 10 is dropped because no published values are in hand.

No interviewer profile exists, so the interviewer read is dropped. The grounding brief is dropped because no strategy brief was run. No graded deliverable was declared. No working-style assessment was given.

## Upgrade menu

- **The full posting text** → any requirement your summary dropped becomes a fit row, and the summary's lines are checked against the full wording.
- **The names of the Director, the two staff engineers, the product manager, and the VP** → persona assignment per panel member, and one tailored reverse question for each interviewer.
- **Any deliverable or focus areas the recruiter named for the panel or the VP round** → graded-deliverable sections.
- **Larkfield's published values page, pasted** → the values cheat sheet (section 10), with each value mapped to a story your quoted sentences carry, where one exists.
- **Permission to run web search** → an L1 pass: values, interview loop structure, and strategy. Today the CO questions are generic. Your three refused searches would become `yes` rows.
- **A deeper research pass**, offered once: up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief, interviewer public talks, role-family loop reports, and recent org context. Want it?
- **How the 60% and the 40 interviews were counted**, in your own words → quoted material. Answer slots A8, A9 and B1 regenerate around it.
- **A location, on-site, or right-to-work term, if the posting has one** → a gate row, surfaced as a hard gate.
- **A `tuesday-dossier.md`, if you have one** → verified evidence and the underwriter's prohibited claims would replace the prohibited list built here. Without one, the list rests on your message alone.
