Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/haiku/alone/part-2/rooms/case-6-denied-5260b4b0/larkfield_engineering-manager_interview_pack.md`. It treats the three rounds as one loop: a shared fit snapshot, a question bank for each round, a persona table, a prohibited list, and a sequencing plan across the two weeks.

Web search was refused in this session, so the pack has nothing from Larkfield itself. There is no values cheat sheet for the Monday round yet. Those selection scaffolds stand in until I have Larkfield's values page. The round structure comes from your schedule and the recruiter's wording.

The two things that hurt most are your stated gaps: you have never owned a hardware-adjacent roadmap, and you have never managed managers. The pack's highest-return prep is question T1 (Tuesday, "Which part of this roadmap would you be weakest at on day one?"). I can play that interviewer as a drill. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed. A Word version of the pack is available on request.

Two things would sharpen it:
1. Can you paste the full job posting? I built the requirements from your one-paragraph summary.
2. Did the recruiter name any focus areas or a deliverable, such as a take-home or a presentation, for any round?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: three-round prep pack (loop mode)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.

**Rounds:**
- **Tuesday:** 45 min, hiring manager (Director of Engineering, your would-be boss). Name not given.
- **Thursday, after Tuesday:** 60 min panel, two staff engineers and a product manager. Names not given.
- **Following Monday:** 30 min, VP Engineering. The recruiter describes it as "values and leadership philosophy". Name not given.

**First version.** No earlier pack to change.

---

## How to use

Personas are how a question arrives. Types are what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values: does past behavior show the company's published values |
| EXP | Experience deep-dive: do the claims in your own message survive scrutiny |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge. None in this pack, because company research did not run |
| CASE | Live problem from the role, delivered now. Tests structure, not your past |

---

## Sequencing across the two weeks

Sized to the calendar, since you have not given prep hours. Weekdays are as you gave them; I have not fixed dates.

1. **Now:** send me the full posting and the recruiter's note (the two questions at the end). Say T1 and T8 aloud. They are the two most likely to be asked in some form.
2. **Before Tuesday:** drill T1 (hardware roadmap) and T10 (sixty seconds against a hardware candidate). For T8 and T9, write down only what you actually know about how the 60% was counted. Leave the rest blank in your head, and say so when asked.
3. **Tuesday to Thursday:** if Tuesday showed the hardware line is weaker than the pack assumes, I regenerate the affected rows. Then drill P1 (seam) and P4 (weakest assumption).
4. **Thursday to Monday:** if you have Larkfield's values page, paste it and I will build the values cheat sheet. Then rehearse V4 (premised, hardware) and V1 (unpopular truth).
5. **Monday:** V4 and V1 are the two you cannot skip. Everything else is insurance.

---

## Fit snapshot (shared across all three rounds)

Requirements come from your one-paragraph role summary, the only job text in hand. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | medium | [grounded] | transferability | Your material gives a team of six, not two squads. Keep it at that scope: "3 as a team lead of 6". Answer slot: if you have had work split across more than one group at once, say how you split it and who held each part; if you have not, say so and say how you would divide two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | The quote reaches hiring in role terms: backend roles, a loop you run, about 40 interviews last year. Lead with the loop in those words. The 11 is the role's scope, not something your material says you have held. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | A reliability quarter pushed through against roadmap pressure is delivery under pressure, not delivery owned across 11 engineers. Keep the sentence's scope. The 60% is a figure, so the defend-the-number questions apply: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. None of those is in your material. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary), growth part | none given | none | [grounded] | discovery | Your material is silent on growing engineers' careers. Answer slot: if you have moved an engineer's career forward, say who and how, in your own words; if you have not, say so and say how you would start with this team. Do not describe growth you cannot name. |
| F5 | "partner with hardware and product on roadmap" (role summary) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The gap you stated: you have never owned a hardware-adjacent roadmap. Words the pack gives back: "I've never managed managers and never owned a hardware-adjacent roadmap." Then how you would learn the hardware constraints, said as a plan, never as a past. No claim to roadmap work. |
| F6 | managing through leads, a role-family requirement the summary does not quote: [generic] | "I've never managed managers" (your message) | none | [grounded] | capability | The gap you stated: you have never managed managers. Words: "I've never managed managers." Then how you would lead through leads, said as a plan. The role summary does not say whether any of the 11 report through a lead, so this pack does not assume it. |

**Coverage of the role summary's requirements:**

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | T2, T7, V6 |
| Own delivery | T8, T9, P9 |
| Own hiring | T3, P6, V3 |
| Own growth for 11 engineers | T5 |
| Partner with hardware and product on roadmap | T1, T6, T10, P7, V4 |

---

## Prohibited list

Built locally from the fit snapshot. Your material cannot be stretched past these, and the banks are written against them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran a hardware-adjacent roadmap | Stretched form of F5, which you stated as never | The sentence F5 quotes, plus the plain acknowledgment: "I've never managed managers and never owned a hardware-adjacent roadmap." No claim to roadmap work |
| Managed managers, or led through leads | Negative you stated, F6 | The plain acknowledgment: "I've never managed managers." Then a plan |
| Led the whole reliability effort, or caused the 60% drop | Stretched form of F3 | "pushed a reliability quarter through" at its own scope. The limit, as this pack's observation: your material says the quarter you pushed through and the drop after it, not what caused the drop |

---

## Persona weights

Relationship priors set the start. Interviewer names are not given, so the panel's per-member personas are a best guess from each member's role, not a read of anyone.

| Round | Persona | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Tuesday, hiring manager | Skeptic (5) | Priors for a hiring manager are Case and Skeptic: they are buying capability and checking gaps. Your stated hardware gap and the summary's roadmap line put this round's centre on the Skeptic | Rehearse the single most predictable objection until it is boring. Concede by name |
| Tuesday | Case / Strategist (2) | Live problems on the roadmap. The Skeptic took the budget, so this is the thin side of the bank | Clarify, then structure, then one premise challenged |
| Tuesday | Data-Driven Prober (2) | The 60% is the one figure in your material | Name the weakest assumption before they do; say plainly when you do not know how it was counted |
| Tuesday | Pressure (2) | Composure on the hardware line | Pause, restate, hold through two follow-ups, concede specifically |
| Tuesday | Conversational (1) | Opener only | A ninety-second arc built from your own sentences |
| Thursday, staff engineer | Peer Evaluator (4) | Peer prior: seams with other teams and how disagreement goes. The hardware seam is the sharpest | Propose seam principles, not seams you do not know |
| Thursday, staff engineer | Data-Driven Prober (3) | Staff engineers scrutinise numbers. The 60% gets this weight | Same as Tuesday's Prober |
| Thursday, product manager | Case / Strategist (3) | Roadmap trade-offs are the product manager's native ground | Clarify the objective, name the hardware dependency, decide |
| Thursday, product manager | Values / Behavioral (2) | Cross-functional prior, with a values-style question from the recruiter's note | Map a story to the sentence it rests on, or give the selection scaffold and its honest branch |
| Monday, VP Engineering | Values / Behavioral (4) | Your recruiter's words, "values and leadership philosophy", name a values-style round. That is a loop source, so the round is detected | No published values are in hand, so the banks use selection scaffolds with their honest branch |
| Monday | Pressure (2) | Altitude and composure at 30 minutes | Hold, then concede |
| Monday | Case / Strategist (1) | Altitude only | Clarify first |
| Monday | Conversational (1) | Opener | Two-minute arc |

---

## Round 1: Tuesday, hiring manager (12 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T1 | "Which part of this roadmap would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI prep in this pack. Start with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then how you would learn the hardware constraints before committing to dates, as a plan. Follow-up one, "Who on the hardware side would you go to first?": name a role, not a person you know. Follow-up two, "What would you refuse to commit to before you had seen the constraints?": say what you would need first. Never claim roadmap work. | F5 is the requirement the summary names and your material is silent on. A hardware manager will go straight to it. JD because the roadmap line is in the summary |
| T2 | "You've been a team lead of six. How would you run two squads, and who in them carries the day-to-day?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the six, in those words. Then how you would split two squads and who would hold what, as a plan. Answer slot: if you have had work split across more than one group at once, say how and who held each part; if you have not, say so plainly, then give the split you would make | F1 is transferability: a team of six is adjacent to two squads, not the same. The question's premise, a team lead of six, is quoted |
| T3 | "What in your background says you can hire for the roles this one needs?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer with the loop: backend roles, about 40 interviews last year, in those words. Then the plan for roles outside backend, as a plan. Answer slot: if you have interviewed for any role outside backend, say which and what you assessed; if you have not, say so | F2 is your strongest hiring evidence. The hardware side of the hiring scope is raised by the roadmap line |
| T4 | "Why leave a payments company for device management?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your material does not carry your reason for moving, so the reason is yours to give. Say the true reason in one sentence, then what draws you to the device problem. Do not borrow the role's language about devices unless it is your own | The skeptic's "why leave, why here, why now" probe. Motivation is not in F1, so the answer is the one you give |
| T5 | "Tell me about an engineer whose career you moved forward." | JD | [generic] for the growth requirement, which F4 shows silent. Nearest sentence: "I run our hiring loop for backend roles — about 40 interviews last year." | Pick an engineer whose career you moved forward: what you did, what they did. If none comes to mind, say so plainly, then give the nearest thing your material carries: the loop you run. Do not describe growth you cannot name | F4 is discovery: growth is in the role summary and silent in your message. The honest answer is yours to find |
| T6 | "A device fleet's check-in rate drops twenty percent after a firmware push. What do you do first?" | CASE | [generic] | Clarify what the rate counts, which devices, when the push went out, and what else changed. Then objective, segments, the first two checks, and who on the hardware side you bring in. Name one premise you would challenge. Do not claim a device background | Tests the partnership with hardware on a live problem. The question asks about no past of yours |
| T7 | "Sketch the first ninety days on device-management services. What do you need to know first?" | CASE | [generic] | Clarify scope, what the two squads are doing now, and what hardware and product have committed to. Then sequence and risks. Speak the structure aloud before using it | Tests structure on the role's own work. Lead two squads is the summary's first line |
| T8 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: if you know the measure and the window it was counted over, say them in your own words; if you do not, say so plainly and say what you would check. Then name the assumption you would defend least, before they do. Never explain a method you cannot repeat under a second question | The one figure in your material, so the defend-the-number slots apply. EXP because it tests what you measured. Highest-ROI with T1 |
| T9 | "Which part of that drop was the quarter, and which part was anything else?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: say which part you can attribute to the quarter you pushed through, in your own words. If you cannot separate them, say that plainly. Do not assign credit to anyone without a source | F3 attribution, asked as a prober asks it |
| T10 | "Sixty seconds: why you over a candidate who has run a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Pause, restate the question in your own words, then answer from what you have stated: nine years, the hiring loop, the quarter you pushed through. Concede the hardware gap in the first sentence and do not fold. Hold through two follow-ups, and concede specifically | Pressure persona. Hold-then-concede on the gap you stated. F5 is the held position's weak point, so concede it rather than defend it |
| T11 | "That result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the claim that you pushed the quarter through. Answer slot: name the part that was yours, in your own words. Concede what you cannot attribute, specifically, without folding on what you pushed through | Pressure version of F3's attribution. The second follow-up is where this breaks if you stretch it |
| T12 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A ninety-second arc in your sentences' order: nine years, three leading six, now at a payments company, then the hiring loop. Keep the gaps for the questions that ask for them | F1. Conversational openers are scored casually |

**Reverse questions for Tuesday** (ask the hiring manager, at least five):

| Question | Why it lands |
|---|---|
| "What would make the first six months a clear success on the hardware side?" | Turns T1 into a question you ask, and shows you have thought about the partnership |
| "What did the last person in this role find hardest?" | Names the real constraint without guessing it |
| "Which of the two squads is more at risk this year, and why?" | Shows you think in delivery terms and invites the roadmap picture |
| "How are the roadmap dates set against hardware release dates?" | Tests whether the partnership is real before you accept it |
| "What would you need from me in the first thirty days?" | Shows you plan for their support, not just your own work |

---

## Round 2: Thursday, panel (12 questions)

Panel members are not named. The per-member persona labels are my guess from their roles. Reciprocity is in the reverse questions, since the panel includes peers.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose seam principles, not a seam you do not know. Walk the quarter in the sentence's beats: the quarter, the pressure, the drop. Answer slot: if you disagreed with an equal and were right, or wrong, say what happened in your words; if no such disagreement comes to mind, say so plainly, then give the quarter's pressure as the nearest thing your material carries | Peer Evaluator. The seam is the summary's partnership line. The disagreement beat is not in your material, so it is a slot |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Keep "I" for what you pushed, and "my team" for the drop, as the sentence does. Answer slot: if others shared the work, name the share in your words, without a figure you cannot source | Peer Evaluator. F3 carries the attribution the sentence states, and nothing more |
| P3 | "Where do your two squads depend on another team, and what do they need from you?" | JD | [generic] | Name the dependency types you would check first, ask what they need, and do not claim a map of their dependencies you do not have | Peer seam question. No claim about your past |
| P4 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the weakest assumption in your own words before they do. Answer slot: if you do not know the assumption, say so | Prober. The defend-the-number question, asked as a staff engineer asks it. F3 |
| P5 | "What would you need to see to believe the 60%?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the source data and the check you would want. If you have seen such a check, say what it was; if not, say so | Prober. Asks for the denominator and the method, which you may not have |
| P6 | "How would you know the interview loop works?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if you tracked how the loop's results held up, say what you tracked; if you did not, say so and say what you would measure first. Never describe a check you did not run | Prober on F2. The loop is strong evidence of running it, not of measuring it |
| P7 | "Sketch how we'd decide between two roadmap items if hardware can commit to only one." | CASE | [generic] | Clarify the objective and what each item unlocks. Name the hardware dependency and its date. Structure, then the trade-off in one sentence | Case / Strategist. The product manager's roadmap, with hardware in it |
| P8 | "A customer asks for a feature we have deferred. How do you respond?" | JD | [generic] | Clarify what the customer needs and by when. Decide what you can say before you know. Plan the response and name the owner | Product manager's question. No claim about your past |
| P9 | "Think of a reliability quarter competing with a feature for the same people. How would you size the cost of deferring the feature?" | CASE | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Use the quarter you pushed as the example, in your own words. Answer slot: if you sized a cost of this kind, say what you counted; if you did not, say so and say what you would count first. Never invent a cost figure to fit the example | Case. F3 is the one example in your material, and the sizing is not in it |
| P10 | "Tell me about a time you delivered an unpopular truth to a product leader." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." | Story from the quoted sentence: the quarter, the pressure, the push. Answer slot: if the truth you delivered to a product leader is yours, say what it was; if the quarter was not a truth delivered to anyone, say so and give the nearest thing your material carries | Values-style, from the recruiter's "values and leadership philosophy". No published values are in hand, so there is no value name to map |
| P11 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need and an internal number pulled apart, and say what you chose and why. If none comes to mind, say so plainly, then give the nearest thing your material carries | Values-style with no published values in hand. Flagged: a value name would change this question |
| P12 | "Our release cadence is set by two groups who disagree. How would you find where the disagreement sits?" | JD | [generic] | Clarify each group's constraint. Ask for the disagreement in each group's own words. Name the decision that would settle it | Peer seam. No claim about your past |

**Reverse questions for the panel** (at least five, one reciprocity):

| Question | Why it lands |
|---|---|
| "What could a new engineering manager do in their first month that would genuinely help your team?" | Reciprocity. It asks what the peer's load needs, which is what a peer weighs |
| "Where do product and engineering most often disagree about the device roadmap?" | Finds the seam you will work on, in their words |
| "How are architecture decisions made across the two squads?" | Shows you think about the staff engineers' ground |
| "What has made a recent engineering hire here succeed, or stall?" | Gets the team's real standard, not the posted one |
| "What does product need from engineering that it is not getting now?" | Puts the product manager's need in front of you, in their words |

---

## Round 3: Monday, VP Engineering (8 questions)

The recruiter's "values and leadership philosophy" is the loop source for this round. No published values are in hand, so these questions use selection scaffolds with honest branches. The values cheat sheet (section 10 of the pack template) is not built; see the upgrade menu.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story from the quoted sentence: the quarter, the pressure, the push, the drop. Answer slot: the leadership reaction and the truth you delivered, if they are yours, in your words; if the quarter was not an unpopular truth delivered to leadership, say so and give the nearest thing your material carries | The strongest story in your material. The reaction beat is not in it, so it is a slot |
| V2 | "Give me your leadership philosophy in one sentence, and how you would know it is working." | VAL | [generic] | Keep to one sentence. The second half is a signal you would watch, as a plan. If you have watched such a signal before, say which one | The recruiter's phrase, asked directly. No claim about your past |
| V3 | "What's the hardest hiring call you've had to make?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Selection: a call made inside the loop you run. Answer slot: if one call was hard, say what made it hard and what you decided; if none was, say so and give the nearest thing the loop carries | F2, under the values framing |
| V4 | "Why should we trust you with a hardware partnership you haven't owned?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then the first ninety days as a plan. Hold through two follow-ups, and concede the gap specifically. Never adopt a hardware claim | The premise, that you have not owned one, is the sentence you wrote. This is the premised question you most need to answer cleanly |
| V5 | "That drop in on-call — how much of it was you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the claim that you pushed the quarter through. Answer slot: name the part that was yours, in your words, and concede what you cannot attribute without folding on the push | Pressure. The same attribution as T11, at altitude |
| V6 | "Two squads, one hardware dependency, and a date that is slipping — what's your first call?" | CASE | [generic] | Clarify what slips and for whom. Decide what you can commit to today. Name who you would talk to first on the hardware side | Altitude case. The partnership line is in the summary |
| V7 | "What would you want to be known for after a year here?" | VAL | [generic] | One answer tied to the role's three parts: delivery, hiring, growth. Say it in your own words | Scored casually. No claim about your past |
| V8 | "So — walk me through the journey in two minutes." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A two-minute arc in the sentence's order. Keep the hardware gap for the question that asks about it | Conversational opener |

**Reverse questions for the VP** (at least five):

| Question | Why it lands |
|---|---|
| "How do you decide which parts of the roadmap engineering owns and which belong to hardware?" | Tests the partnership boundary the role sits on |
| "What leadership habit do you most want the next manager here to keep?" | Asks for the philosophy in the VP's words |
| "Which decision from the last year would you make differently now?" | Invites candour, which the round is scoring |
| "What do you want to see from this role in the first quarter?" | Turns the round into a conversation about the real bar |
| "How much of next year's hiring is for roles that do not exist yet?" | Tests the scope of the growth requirement |

---

## Requirement-coverage check

Each row of the fit snapshot's coverage table lists the question IDs that cover it. Every requirement in the role summary has at least one JD-tagged question. No requirement in this pack is uncovered.

---

## Sources

**Provided documents:** your message, which holds the role summary, the three-round schedule, the recruiter's phrase "values and leadership philosophy", and your background. No full job posting, no dossier, no interviewer profile.

**Searches sent:**
- "Larkfield Systems values industrial IoT engineering": refused, because web search permission was not granted in this session.
- "Larkfield Systems engineering manager interview process": refused, because web search permission was not granted in this session.

**Research tier: L1 — searches 2 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet (section 10), which needs published values in hand. The search was refused, so none is established. The Monday round uses selection scaffolds instead |
| 2. Larkfield interview process | unavailable | Confirmation of loop structure. Your schedule already names the three rounds and who runs each, so the pack's round structure stands on your words. The search was refused |
| 3. Larkfield strategy and recent news | unavailable | Current-strategy CO questions. Not sent, because the budget was spent on the two calls above and web search was refused. No CO questions are in this pack |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. No interviewer read is included |
| 5. Representative role JD | unavailable | A representative posting, to stand in for the full job text, which you have not supplied. Not sent. The fit snapshot's requirements come from your role summary |

Interviewer names, if you have them, would unlock the reading of the interviewer and a per-person reverse question. None is in this pack.

---

## Upgrade menu

- **The full job posting** → requirement rows quoted from the posting instead of the summary, and each JD question tested against its full list.
- **The recruiter's focus areas or any deliverable** (a take-home, a presentation) → coverage of anything pre-declared, and a build section for it.
- **Larkfield's values page, pasted** → the values cheat sheet for the Monday round, with each value mapped to a sentence you wrote or a selection scaffold.
- **Allowing web search** → the two refused checks run: values and the loop structure. A strategy pass for the CO questions.
- **Interviewer names** (the Director, the two staff engineers, the product manager, the VP) → a persona per person instead of per round, a reverse question tied to each person's path, and a reading of their public footprint.
- **Your answers to the slots in F1, F3, F4 and T8 to T11** → the fit snapshot rows those answers draw on, regenerated. Only answers you give yourself, in your own words, count.
- **A tuesday-dossier.md** → verified evidence and a sourced prohibited list, carried in from a prior session. Not needed for this pack.
- **Prep hours per round** → a triage sized to the time you have, in place of the calendar sequence.
