Your prep pack is saved at `/var/tmp/tuesday-measure/1a/runs/haiku/alone/part-2/rooms/case-8-denied-c3118255/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It is built as three loop-mode mini-packs, one per round, with a shared fit snapshot and values sheet.

Three things to know before you open it:

- **The biggest gap is the contact centre.** The role owns complaints across branches and the contact centre, and you've said you've never worked in one. Question B2 is the one to rehearse hardest. The pack gives you a plain acknowledgment, a return to the branch log at its own scope, and a plan for learning the contact-centre side. It doesn't let you claim experience you don't have.
- **Presenting above regional level is the second gap.** Your material says so directly, so the pack gives you the plain sentence and a plan, and nothing more.
- **Round 3's escalation case isn't known yet.** C1 to C3 are a generic example shape. Ask the recruiter for the real brief if they'll share it.

I used only the material you gave me. I didn't run any searches, because the values, the process and the strategy were all in hand. No interviewer names were given, so the pack has no interviewer read yet. The upgrade menu at the end lists what would sharpen it, including an anonymised copy of your monthly spreadsheet, with no member details, to test your Excel and reporting claims.

Two offers, neither pushed:
- Say the word and I'll play the Skeptic on B2, the contact-centre question.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead at Ashgrove Credit Union: interview prep pack

**Build:** first build, loop mode (three scheduled rounds on 26 November 2026), prepared 17 November 2026.

- **Role:** Member Experience Lead
- **Company:** Ashgrove Credit Union (member-owned, about 900 staff)
- **Interviewers:** not yet assigned. Round 2 is the Head of Member Services (your likely manager). Round 3 is a panel of two branch managers.
- **Rounds:** 26 November 2026. Round 1 is 30 minutes with the recruiter. Round 2 is 45 minutes, mostly behavioural. Round 3 is 60 minutes, including a 20-minute complaint escalation case, and the panel scores you against the four values.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioural and values | Whether past behaviour shows the four published values |
| EXP | Experience deep-dive | Whether your past claims hold up under scrutiny |
| JD | Role requirement | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you think at their altitude |
| CASE | Live problem | How you structure a problem and reason through it |

Guidance is scaffolding, not a script. Each answer slot is an instruction for the interview: answer the branch that is true for you. A logistics slot works the same way: give your own answer. Every row that describes your past carries the sentences it rests on, and nothing else about your past is claimed.

**Highest-return prep:** question **B2**. The role owns the complaints process across the contact centre, and you have said you have never worked in one. Rehearse the plain acknowledgment and the plan until they sound ordinary.

## Persona weights

No interviewer names were given, so these weights are relationship priors with no interviewer signal. Each round's bank carries its own weights below.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter | Conversational (5 of 8) | Casual openers; logistics asked in passing | High. Recruiter screens are friendly and still scored, and logistics are the screen's job | Pre-rehearse a 90-second arc; treat casual questions as scored |
| 1, recruiter | Skeptic (3 of 8) | Gentle probes on contact centre and Excel | Medium. The recruiter screens for knockouts quietly | Name the gap in one sentence, then stop |
| 2, Head of Member Services | Skeptic (4 of 9) | Gap probes framed as "what would you do on day one" | High. The manager owns the gaps they would be derisking, and "mostly behavioural" puts those probes inside the behavioural frame | Rehearse B2 until the plain acknowledgment is boring |
| 2, Head of Member Services | Values/Behavioral (3 of 9) | Scored stories, one per value | High. The round is mostly behavioural and the panel later scores values | One decision per value, told in your own words |
| 2, Head of Member Services | Pressure (1 of 9) | One hard follow-up | Low to medium. The top persona here is the skeptic, so pressure is a single check | Hold through two follow-ups, concede a gap and never the core claim |
| 2, Head of Member Services | Data-Driven Prober (1 of 9) | "How was that counted?" | Medium. The spreadsheet invites it | Answer slot on B9 |
| 3, panel | Case/Strategist (4 of 9) | The escalation case, plus a strategy question | High. The 20-minute case is announced | Clarify before you structure; think aloud |
| 3, panel | Values/Behavioral (3 of 9) | Scoring against the four values | High. The panel scores against the values by design | One story per value; land the hard part |
| 3, panel | Peer Evaluator (2 of 9) | Seams with branches and the contact centre | Medium to high. Branch managers are your working counterparts | Propose seam principles, not a known seam; offer reciprocity |

## Section 4: Fit snapshot

Requirements are quoted from the requirement lines you gave me. Evidence is quoted from your message, the only source of your background. No requirement is a gate in the suite's sense: the posting names no licence, credential or location bar, so no row is `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap on the years. Say it in your own words: six years in retail banking, the last three as a branch supervisor. Expect a probe on what the customer-operations part of that was. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows formal complaints, not whether they were regulated. Answer slot: if the log carried external deadlines, a regulator or a referral route, say which and what you did with them; if it did not, say so and say what it did carry. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote is one branch's log, not the process end to end. Words, at its own scope: "I handled the branch's formal complaints log." Answer slot: if any step beyond that log was yours to decide, say which and how you decided; if none was, say so and stay with the log. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your own statement is the gap. Words: "I've never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan and never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The spreadsheet is monthly and about complaints. Your material does not show whether it counted volumes, resolution times or both. Answer slot: if it tracked resolution times, say how they were counted; if it did not, say so and say what it did track. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached anyone beyond tellers on escalations, say whom and on what; if not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with any team on a customer journey, say which and what you did in it; if not, say so and say how you would start with the digital team. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your own statement is the gap. Words: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan. Never a claim to presentation experience. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a spreadsheet, not Excel by name. The bridge rewords only the quote: "I built the monthly complaints spreadsheet our regional manager uses." It adds no tool, figure or practice. |

## Section 13: Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and no answer, hold or reverse question below asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end across branches and the contact centre" | Inflated form of F3 | "I handled the branch's formal complaints log," at its own scope. Your material says one branch's log, not the process. |
| "Coached branch supervisors on escalations" | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Any contact-centre experience | Negative you stated, F4 | "I've never worked in a contact centre." Plain acknowledgment, no slot. |
| "Presented to senior leaders" | Negative you stated, F8 | "I've never presented to anyone above regional level." Plain acknowledgment, no slot. |
| "Designed the reporting" or "owned the resolution-time figures" | Inflated form of F5 and F9 | "I built the monthly complaints spreadsheet our regional manager uses." |
| "Handled regulated complaints" | Inflated form of F2 | "I handled the branch's formal complaints log." |

## Section 6: Grounding brief

From the strategy brief you summarised (July 2026). I have your summary, not the document. Nothing in it is flagged as stale; it is recent enough to speak to directly.

| Item | Source as provided | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief | [grounded] |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief | [grounded] |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief | [grounded] |
| Main competitive pressure is app-only banks | 2026 strategy brief | [grounded] |
| Vocabulary to use: member service, digital channels, hubs, small-business lending, app-only banks | 2026 strategy brief | [grounded] |

## Section 10: Values cheat sheet

The panel scores against these four values, so a values-style round is detected. The values are the copy you pasted from ashgrovecu.org on 17 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Row F3 carries the complaints ("I handled the branch's formal complaints log"), but not a member-side decision. Scaffold: pick a complaint where the member's side changed the decision. If none did, say so and say what the log's standard route was. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Nearest quote, row F6: "trained new tellers on our escalation script." Scaffold: pick a time an explanation had to be clearer. Say what you changed, if anything; if nothing changed, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | Row F5 and F9 carry the numbers side: "I built the monthly complaints spreadsheet our regional manager uses." Scaffold: pick a time a figure led you to a branch's town or its members. If the report never did, say so and say what you would add. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Row F3: "I handled the branch's formal complaints log." Scaffold: pick a complaint you stayed with to the close and say what kept you on it. If the log closed it without your follow-through, say so. |

## Section 9: Question banks

Coverage is shown in the table after the banks. Depth follows persona weight.

### Round 1: recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor", "I handled the branch's formal complaints log", "trained new tellers on our escalation script", "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in four beats, each a sentence you said: the six years and the last three as a branch supervisor; the formal complaints log; the tellers you trained on the escalation script; the monthly spreadsheet. Say each in your own words and stop there. | Conversational opener, and the recruiter's first read of you. EXP because it tests what you did. Rests on F1, F3, F6 and F5. |
| A2 | "What's drawing you to Ashgrove Credit Union?" | CO | [grounded] the published values you pasted | Name one thing from the member-owned model or the values that you would want to work on, and say why in terms of what you would do. Do not recite all four values. | Motivation consistency is the screen's first check. The guidance makes no claim about your past. |
| A3 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. Your material gives no figure, so the figure is yours to supply. | Pay is a logistics check. JD because the listed job's terms set it. |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. Your material gives none. | Notice is a logistics check. The answer is yours alone. |
| A5 | "Where could you work from, and how often can you be on site?" | JD | [generic] | Logistics slot: state where you can work and the on-site pattern you can accept. The material you gave me names no office pattern; if you don't know the role's pattern, ask for it before you answer. | Location is a logistics check and the posting you gave me names no pattern. |
| A6 | "Why are you thinking about leaving your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. Your material gives none, so it is yours to supply; keep to the reason you actually have. | Reason for leaving is a logistics check. The guidance makes no claim about your past. |
| A7 | "This role covers the contact centre as well as the branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre", "I handled the branch's formal complaints log" | Say it plainly: "I've never worked in a contact centre." Then the complaints log you did handle, at its own scope, and how you would learn the contact-centre side, said as a plan. Answer slot: if you have ever worked alongside a contact centre on complaints, say how; if not, say so. | F4 is the capability gap. The question is raised by the JD line about the contact centre. F3's quote supports the bridge at its own scope. |
| A8 | "How comfortable are you with Excel for monthly reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built, which is the monthly complaints spreadsheet and who uses it, and name the tool. If it was Excel, say so; if it was another tool, name it. | F9's presentation gap: the spreadsheet reaches the requirement in other terms, and Excel is not in the quote. |

Round 1 reverse questions:

- "What happens between this call and the next round, and who will I speak to?" Why it lands: it shows you are thinking about the process rather than only your answers.
- "What would a good first 90 days look like for whoever takes this role?" Why it lands: it asks for success criteria, which the manager will answer in round 2.

### Round 2: Head of Member Services (45 minutes, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint from your log where the member didn't accept the outcome." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one complaint from the log where the member rejected the result. Four beats: what the member wanted, what you did with the log, what you decided, and the outcome, in your words. Answer slot: if no complaint went that way, say so and give the nearest one. | Members First. The theme comes from the values stem for an unwelcome outcome. Rests on F3's quote. |
| B2 | "You've never worked in a contact centre, and this role owns complaints across it. Why should we believe you can do that end to end?" | JD | [grounded] "Never worked in a contact centre", "I handled the branch's formal complaints log" | Highest-return prep in this pack. Hold: "I've never worked in a contact centre." Return to the log at its own scope: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to the log, never by adding to it. Concede specifically: the contact-centre side is what you would learn first, and say how, as a plan. Do not claim contact-centre experience. | F4 and F3 are the gaps. The question's premise is the JD line; "never worked" is your own sentence. The Skeptic will raise this in some form, and a rehearsed answer that does not get defensive changes the round. |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level", "Never worked in a contact centre" | Name the two gaps as plain acknowledgments, in your own words, then the plan for each. Do not name a third gap you have not been asked about. | F8 and F4 are capability gaps. This is the Skeptic's open probe, and it also covers the senior-presenting requirement. |
| B4 | "When did you put a customer ahead of an internal number?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Neighbours, Not Numbers and Members First. Open prompt. Pick a time a figure in your reporting pointed one way and a member's interest the other, then say which you chose and why. Answer slot: if your reporting never pulled against a member, say so and give the nearest case where a member came first. | The quote is the number side of the story. The scaffold ends in the honest branch. |
| B5 | "Tell me about a time you explained something to a member who needed it twice." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. Open prompt. Pick a time an explanation had to be clearer. If the nearest is training tellers on the script, say what you changed in how it was explained, if anything. If you changed nothing, say so. | Plain Words is the one value without a stronger quote. The guidance will not supply a change you did not make. |
| B6 | "What does regulation change about how a complaint is run in your log?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if the log carried external deadlines, a regulator or a referral route, say which and what you did with them; if it did not, say so and say what it did carry. | F2's discovery gap. The question presupposes regulation because the JD raises it. |
| B7 | "You've been a branch supervisor for three years. Why is that enough for this role?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Pressure. Hold: say what the three years give you, from that sentence. Concede specifically: the contact-centre side and presenting above regional level are what those years did not give you. Hold through two follow-ups and concede the gap, never the core claim. | Hold-then-concede. The held position is the one the quote carries, not a stronger one. |
| B8 | "How would you coach a branch supervisor whose escalations are slow?" | JD | [grounded] "trained new tellers on our escalation script", "6 years in retail banking, the last 3 as a branch supervisor" | Answer slot: if you have coached a supervisor on escalations, say how; if not, say so, say what you would check first, and say how you would start. The nearest thing your material carries is the tellers you trained. | F6's transferability gap. The JD line "coach branch supervisors on escalations" raises it. |
| B9 | "Did the monthly complaints spreadsheet track resolution times? Walk me through how." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if it tracked resolution times, say how they were counted and the assumption you would defend least, in your own words. If it did not, say so and say what it did track. Do not name a method. | F5's discovery gap. Probers test how a figure was counted, and no figure has been given here. |

Round 2 reverse questions:

- "How is the escalation route working for branch supervisors at the moment?" Why it lands: it shows you are already thinking about coaching them.
- "How do you know a complaint is resolved, and do members agree?" Why it lands: it puts the member's view into the measure, which is the values test in question form.
- "How will the move to five hubs over 2027 change the way complaints get handled?" Why it lands: it draws on the strategy brief and shows you read it as a complaints problem, not only a branch problem.

### Round 3: panel of two branch managers (60 minutes, including a 20-minute escalation case)

The panel's case has not been announced. C1 is an example shape for the case, and the recruiter can supply the real brief (upgrade menu).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has escalated the same complaint twice, and the branch says it's resolved. Take us through what you'd do." | CASE | [generic] | Structure: clarify first. What does resolved mean to the member, and to the branch? What is the objective, and who holds the complaint now? Then approach: check the file, speak to the member and the branch separately, and decide who owns the fix. Then metrics and risks. Think aloud, and name one premise you would challenge. | The 20-minute case. Generic because the panel's case is not yet known. The guidance makes no claim about your past. |
| C2 | "What do you need to know from the branch before you decide?" | CASE | [generic] | List three things before any action: the complaint file, the member's stated outcome, and what the branch did and when. Then say what you would not decide until you had them. | A follow-up that tests clarify-before-structure. |
| C3 | "The branch manager tells you the member is wrong. How do you proceed?" | CASE | [generic] | Keep the member's outcome central. Name the disagreement, agree the facts first, then decide who owns the fix and say so. State the decision you would make, and what would change it. | A peer disagreement inside the case. Generic. |
| C4 | "Tell us about a complaint you followed until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. Scaffold: pick a complaint you stayed with to the close, and say what kept you on it. If the log closed it without your follow-through, say so and say what you would have done. | VAL for Own the Fix. The scaffold ends in the honest branch. |
| C5 | "When did a figure on a report make you look at a branch's town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Neighbours, Not Numbers. Scaffold: pick a time the monthly report pointed at a branch and you looked at its town, its members or its local context. If the report never led you there, say so and say what you would add. | The number side is your sentence; the town side is the scaffold's. |
| C6 | "Tell us about a decision you made from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First. Scaffold: pick a decision where the member's side changed the outcome. If your log decisions followed the branch's standard route, say so and say what you would change. | VAL for Members First. The honest branch is built in. |
| C7 | "Our branches and the contact centre sit side by side. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: one owner per complaint, a shared record, and a rule for who escalates. Say how you would disagree with a peer: facts first, then the member. | Peer Evaluator. Seams are the peer's own territory, so the guidance proposes principles only. |
| C8 | "How do you handle credit when work spans teams?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say who uses the spreadsheet, in your words. Answer slot: if you built it with anyone, name them and what they did; if you built it alone, say so. | Peer credit probe. The quote is kept at its own scope. |
| C9 | "How would you think about the plan to move member service into digital channels?" | CO | [grounded] the 2026 strategy brief, as you summarised it | Start from the member: what routes members use, and where a complaint gets stuck when it moves online. Answer slot: if you have worked with a digital team on a customer journey, say which; if not, say so and say how you would start with the digital team. | Your material shows no digital work (F7), which is the discovery gap. The question is open and presupposes nothing from the brief. |

Round 3 reverse questions:

- "Where does the seam between the branches and the contact centre hurt members most today?" Why it lands: it is a peer question, and it shows you want the problem, not just the job.
- "What could someone new do in their first month that would genuinely help your branches?" Why it lands: it is the reciprocity question for a peer panel, and it asks what you would bring them.

## Requirement coverage

| Stated requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, B7 |
| Own the member complaints process end to end across branches and the contact centre | A7, B2, C4 |
| Experience handling regulated complaints | B6 |
| Report monthly on complaint volumes and resolution times | A8, B9 |
| Coach branch supervisors on escalations | B8, C1 |
| Work with digital teams on self-service journeys | C9 |
| Confident presenting to senior leaders | B3 (only; the answer is a plain acknowledgment and a plan) |
| Comfortable with Excel reporting | A8 |

## Sources

- **Provided:** the values you copied from ashgrovecu.org/about/values on 17 November 2026; the recruiter's process email; the 2026 strategy brief (July 2026), as you summarised it; your background message; the requirement lines from the role.
- **Dossier:** none present.
- **Searches and fetches:** none sent.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2. Every target was fixed by material in hand.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet (section 10). The values you pasted fix that output. |
| 2. Ashgrove interview process, member services | skipped | Loop structure. The recruiter's email fixes the three rounds and what each covers. |
| 3. Ashgrove strategy and recent news | skipped | Could not have moved the company bank beyond what the brief you summarised already supplies: current priorities and recent moves. Recent news beyond the brief is the L2 offer. |
| 4. Interviewer name and Ashgrove | n/a | No names given, so there was no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The requirement lines you supplied fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The names of the Head of Member Services and the two branch managers → an interviewer read, persona weights for each panel member, and a tailored reverse question for each.
- The escalation case brief from the recruiter, or confirmation that the case can be shared before 26 November → C1 to C3 become the real case, not an example shape.
- The full posting text → confirms the wording of the quoted requirements; the fit snapshot currently quotes the lines you gave me.
- Your CV, if you have a copy → the evidence quotes move from your message to your CV, and the confidence bands can be checked against it.
- An anonymised copy of the monthly complaints spreadsheet, with headings and counts only and no member details → F5 and F9 could move from medium to high confidence if it shows what you describe.
- Any task the panel has announced beyond the interview itself, such as a presentation or a written plan → a graded deliverable section. None has been announced so far.
- Deep research (L2) on the full strategy brief and recent member-services news → a grounding brief with current vocabulary. This would add four targets, at most six more searches and two more fetches, and takes a few minutes.
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims that bind the rows above.
