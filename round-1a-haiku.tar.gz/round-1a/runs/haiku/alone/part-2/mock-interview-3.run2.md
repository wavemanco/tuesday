Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-3-denied-59f1b1d2/ed31c9e9-5322-4fb1-a338-146df73a795e/scratchpad/stripe_product-operations-manager_interview_pack.md`. It is a first build, because I had only the company and the role title. The web search was refused in this session, so the pack has no Stripe values, strategy or interview-format facts. I did not fill those in from memory. The pack covers 22 questions across six interviewer styles, a generic fit snapshot, and reverse questions. Its highest-ROI prep is B1, the "why would you be weaker than someone who has run a product team" objection.

Three things would make it much sharper:

1. Who is interviewing you, and what is their role relative to yours? Is the final one session or several, and is there a take-home or presentation?
2. Can you paste the job description and your CV? If not, I'll keep going without them.
3. Does the posting list any hard requirements, such as location, in-office days or work authorisation?

I can also play the Skeptic on B1 in a live drill, save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round prep pack

**Role:** Product Operations Manager. **Company:** Stripe. **Interviewer:** not given. **Relationship:** unknown, so the persona weights are blended. **Round format:** "final round", schedule unknown.
**Changelog:** first build. No JD, CV or search results were available, so this is a worksheet-level pack. Rebuild it when the inputs below arrive.

## 1. How to use this pack

- **Personas** describe how a question is asked (the register and the pressure). **Types** describe what is being scored.
- **Type key:**
  - **VAL**: behavioral and values alignment. Tests whether past behavior shows the company's published values.
  - **EXP**: work-experience deep-dive. Tests whether your claims survive scrutiny.
  - **JD**: role-driven. Tests whether you can do the listed job, gaps included.
  - **CO**: company and strategy knowledge. Not included here (see Sources).
  - **CASE**: live problem. Tests structure and reasoning, not recall.
- **Guidance is scaffolding, not a script.** Speak it in your own words, in 90 to 120 seconds.

## 2. Fit snapshot

No JD and no CV were supplied, so every requirement below is role-family prose and is tagged `[generic]`. No evidence exists yet to quote. Each row's bridge is therefore a selection scaffold or an answer slot. Silence in the material is recorded as `discovery`, not as a capability gap.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Owns cross-team process and handoffs (role family) | none given | none | [generic] | discovery | Strong evidence is one cross-team process you ran or shaped, with the decisions you made in it. Answer slot: describe one process that crossed teams and say which parts were yours to decide. If you have not run one, say so plainly, then describe how you would start. |
| F2 | Runs operating cadence and planning (role family) | none given | none | [generic] | discovery | Strong evidence is a recurring review or planning cycle you ran, with what it decided. Answer slot: name one recurring review you ran or attended, and the decision it produced. If none, say so plainly, then describe the review you would set up first. |
| F3 | Prioritises competing requests with limited capacity (role family) | none given | none | [generic] | discovery | Strong evidence is a prioritisation you made, with the criteria you used and what you declined. Answer slot: describe one call where you said no, and the criteria behind it. If you have not made one, say so, then name the criteria you would use. |
| F4 | Builds metrics and dashboards that teams act on (role family) | none given | none | [generic] | discovery | Strong evidence is a metric someone acted on, with how it was counted. Answer slot: name one metric you used to decide something, what it counted, and the assumption you would defend least. If none, say so plainly and say which metric you would build first. |
| F5 | Drives change adoption through people who do not report to you (role family) | none given | none | [generic] | discovery | Strong evidence is a change that landed without authority over the people it affected. Answer slot: describe one change that needed people outside your reporting line to adopt it, and what you did. If there was none, say so plainly and describe how you would build buy-in. |

No requirement in this table is a hard gate. The material does not show any gate, so `hard_gate` does not apply. Posting-level gates (location, in-office days, work authorisation) are unknown until the JD arrives.

## 3. Prohibited claims

**None listed.** No candidate sentence exists yet for this pack to stretch, so there is nothing to inflate. This section will be built from the CV once it arrives. Until then, do not claim a metric, team size, outcome, tool or specific prior role in the interview unless you can defend it in your own words.

## 4. Persona weights

Relationship and round format are unknown, so the weights below blend the priors. Session totals are 22 questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live operating problems: "a launch slipped", "ten requests, capacity for two" | Highest weight. A final round for an operations role usually tests judgement on a live problem. A hiring-manager or executive prior both raise this. | Clarify, then objective, then segments, approach, metrics, risks. Think aloud. |
| Skeptic (B) | Quiet probing of the gaps: "which part would you be weakest at" | High. With no CV in hand, the gaps are the unknowns, and a final round is where they get tested. | Rehearse the single most predictable objection until it is boring. Concede precisely. |
| Values / Behavioral (C) | Scenario prompts about truth, customers and standards | Medium. A final round often includes a behavioral interviewer. Stripe's values are not verified here (see Sources), so these prompts are generic. | Scaffold each story with a selection criterion. If none comes to mind, say so. |
| Data-Driven Prober (D) | "How was that counted?" follow-ups | Medium. Ops roles are judged on the numbers they use. A peer or specialist prior raises this. | Name the weakest assumption before they do. Say plainly what you do not know. |
| Peer Evaluator (E) | Seam-splitting: "where does your work meet mine?" | Medium. Peer interviewers are common in final loops for ops roles. | Propose seam principles rather than pretending to know their seam. |
| Pressure / Stress (F) | Time-boxed challenges to a position | Lower. Relevant if the interviewer is an executive or the round is a stress panel. | Pause, restate, hold through two follow-ups, concede a specific uncertainty without folding the core. |
| Conversational (G) | Friendly openers that are still scored | Lower but present. Casual openers are a common scoring point. | Pre-scripted 90-second arc. Treat casual questions as scored. |

## 5. Question banks

Every row is `[generic]`, because no candidate sentence exists yet. Each question is either an open prompt, a live problem, or an opener, and no question presupposes anything about your past.

### A. Case / Strategist (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you were coordinating slipped two weeks, and three teams are blaming each other. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify what slipped and what the blame is about. Find where the slip started. Separate causes into scope, dependency and decision latency. Name the metric you would watch and one risk. | A live cross-team problem, the core of the operations remit. Presupposes nothing about you. |
| A2 | "Our product teams want different planning cadences. What would you do in your first 90 days?" | CASE | [generic] | Learn the current cadences, the decision rights and where the time goes. Propose a principle before a process. Pilot with one team, and name the measure. | Tests whether you start with diagnosis, not a new process. |
| A3 | "You have ten requests for new internal tooling and capacity for two. How do you choose?" | CASE | [generic] | Criteria first (impact, reach, cost of delay, reversibility). Name what you would need to know and who decides. Say what you would decline. | Prioritisation under scarcity, a core ops judgement (F3). |
| A4 | "A key operating metric dropped 20% in a month. Diagnose it." | CASE | [generic] | Check the definition first, then segment, then compare timing with releases or incidents. Name the mechanism you would test first, and what you would check before you believe the drop. | Tests metric hygiene before analysis. |
| A5 | "Design a weekly review for a product group that has none." | CASE | [generic] | State the purpose, the attendees, the inputs, and the one decision the review must produce. Then the cadence. | Tests whether you design for a decision, not a meeting. |

### B. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why would you be weaker in this job than someone who has run a product team?" | JD | [generic] | **Highest-ROI prep in this pack.** Hold: say what you would bring that is specific to the seat. Answer slot: if you have worked directly inside a product team, say what that gave you; if not, say so plainly. Then name the one part of the job where the gap would cost the team most, and how you would close it in the first quarter. Through two follow-ups, return to the part you would learn fastest. Concede precisely; never fold the core. | The most predictable objection to a generic candidate with no CV in hand. Deepest rehearsal, with the most follow-ups. |
| B2 | "What about this job is most likely to make you fail?" | JD | [generic] | Name one specific failure mode and how you would detect it early. A plan, not a denial. | A standard skeptic probe. It rewards a named risk over reassurance. |
| B3 | "Why are you leaving where you are now?" | EXP | [generic] | Give the reason in one sentence that is true for you, then what you are moving toward. Answer slot: if the reason is about your current role, say so plainly. Do not invent dissatisfaction. | Motivation consistency is scored in every final. |
| B4 | "Tell me about a process you proposed that did not hold up." | EXP | [generic] | Selection scaffold: pick a process you proposed that failed or underperformed. Say what you missed, what changed, and what you kept. If none comes to mind, say so plainly, then describe how you check your own process designs now. | Tests honest self-assessment. An open prompt, so it presupposes no event. |

### C. Values / Behavioral (weight: medium, 3 questions)

Stripe's published values are not verified in this pack (see Sources). Each question is generic, and no value is named.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you had to say something a senior person did not want to hear. It needs the truth, the moment you said it, and what happened after. If none comes to mind, say so plainly, then describe how you would handle it now. | A standard values probe. An open prompt, with no event supplied. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer outcome and an internal number pulled apart, and what you chose. If none comes to mind, say so, then describe how you would decide. | Tests judgement over metric worship. |
| C3 | "Tell me about a process change people resisted. How did you get it adopted?" | VAL | [generic] | Selection scaffold: pick a change that met resistance. Say who resisted, what you did, and what you would do differently. If none, say so, then describe your approach. | Tests change adoption (F5). Open prompt. |

### D. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you know whether a process change actually worked?" | EXP | [generic] | State a baseline, a comparison group, and the metric you would defend least. Say what you could not measure. | Tests whether you can separate signal from noise in operations. |
| D2 | "Which metric in an inherited dashboard would you check the definition of first?" | JD | [generic] | Name one metric and what you would ask its owner. Name the definition question, not an answer. | Tests metric hygiene. |
| D3 | "Walk me through how a number you relied on was counted." | EXP | [generic] | Selection scaffold: pick a report or number you built or relied on. Say what it counted, its weakest input, and the assumption you would defend least. If you did not build it, say whose it was and how you used it. If you have none, say so and describe the one you would build first. | Persona stem for the Prober. Open prompt, no event supplied. |

### E. Peer Evaluator (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam between product operations and engineering, and what happens when we disagree?" | VAL | [generic] | Propose seam principles: who owns the decision, who owns the data. Do not pretend to know their seam. For disagreement, name a position and how you would resolve it with an equal. | Peer probes come collegially. It scores partnership fit. |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick work that crossed teams. Name the contributions, and what you named as yours. If none, say so and describe your approach. | Persona stem. Open prompt. |
| E3 | "What would you need from my team to do this job well?" | JD | [generic] | Name two specific asks and what you would offer in return. | Reciprocity. Shows you are thinking about the peer's load. |

### F. Pressure / Stress (weight: lower, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has done this job before?" | JD | [generic] | Answer from what you can defend. Hold your strongest specific point. If you have no advantage over that person, concede it once, then state the one reason you still want this seat. Hold through two follow-ups. | Persona stem. Time-boxed challenge to the position. |
| F2 | "That answer was weak. Defend it." | JD | [generic] | Pause. Restate the question. Hold your position through two follow-ups. Concede a specific uncertainty without folding the core. | Tests composure, not content. |

### G. Conversational (weight: lower, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | JD | [generic] | Pre-script a 90-second arc: where you have worked, what you did in your own words, and why this seat. Fill it with your CV sentences once you share them. | A casual opener that is still scored. |
| G2 | "What are you most curious about in this space right now?" | CO | [generic] | Name one question about how operations scales with a product org. A genuine question, not flattery. | Casual questions are scored for interest. Research was not available, so no company-specific content is included. |

### Requirement coverage

| Role-family requirement | Question IDs | Note |
|---|---|---|
| Cross-team process ownership (F1) | A1, E1, E2 | |
| Operating cadence and planning (F2) | A2, A5 | |
| Prioritisation (F3) | A3, B2 | |
| Metrics and dashboards (F4) | A4, D1, D2, D3 | |
| Change adoption (F5) | C3, E1 | |
| Specific tools or domain knowledge | none, and why | No JD was supplied, so no tool or domain requirement can be identified. Add the JD to cover it. |

## 6. Reverse questions

Each question ties to a reason it lands. None is generic.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like in this seat?" | Gives you the real scoring sheet for the role. |
| R2 | "Which decision in this area has been slowest to make, and why?" | Shows you think about operating friction, not about the job description. |
| R3 | "Is the remit of product operations set by the product organisation or by the company?" | Shows you know remit ambiguity decides how the role succeeds. |
| R4 | "What would make you regret hiring the wrong person for this role?" | Surfaces the failure mode behind B2, in their own words. |
| R5 | "If someone held this seat before, what did they leave unfinished?" | Shows you assume there is context you do not have yet. |
| R6 | *(If the interviewer is a peer only:)* "What could a new person do in the first month that would genuinely help your team?" | A reciprocity question, which peers weight heavily. |

## 7. Sources

- **Provided documents:** your message, with the company (Stripe) and the role title (Product Operations Manager). Nothing else.
- **Research:** the search tool was refused, so no company, values or process facts were gathered. Nothing has been filled in from memory. Stripe's values are not in this pack for that reason.
- **Research tier:** L1. Searches 0 of 6 run, fetches 0 of 2 run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe company values principles` | unavailable | Values cheat sheet, section 10. Refused: the search tool was not granted, so no values page was read. |
| 2. `Stripe interview process product operations manager final round` | unavailable | Loop structure and persona weights. Refused: the search tool was not granted, so the round format is unverified. |
| 3. `Stripe strategy` / recent news | unavailable | Grounding brief and CO questions. No call was sent. Without it, G2 is the only CO question, and it is generic. |
| 4. Interviewer name search | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot quotes, marked `[inferred]`. No call was sent. The requirements above are role-family prose instead. |

## 8. Upgrade menu

- **The JD text** → the five `[generic]` fit-snapshot rows become quoted `[grounded]` rows, any hard gates become visible, and the requirement-coverage table can cover each one.
- **Your CV** → each question's guidance becomes a story map from your own sentences, and the Skeptic and Pressure banks get concrete material to hold against.
- **Round format and who is interviewing** → reweights the personas. If the final is several sessions, send the schedule and a per-session mini-pack can be built.
- **The interviewer's name** → a tailored reverse question, and persona weights read from their public footprint (this needs search access).
- **Search access granted** → the values cheat sheet, the strategy grounding, and company-specific CO questions. Those are currently missing.
- **Any take-home or presentation the recruiter announced** → a graded-deliverable build section.
- **Prep time available** → a prioritised schedule keyed to question IDs.
- **`tuesday-dossier.md`, if you have one**, would add verified evidence and any known objections. None is in this session.
