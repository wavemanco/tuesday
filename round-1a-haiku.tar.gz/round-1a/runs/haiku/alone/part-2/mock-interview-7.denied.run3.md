Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-7-denied-8a99a1c5/cd198f22-aa5a-42ac-bea4-e37bb391b133/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting, and I ran no web research. It works from your message and the JD only.

The most important thing to rehearse is A2: how you coordinated design, art, engineering and community on each update. Your material doesn't show that, so the honest answer is the one you'd give from your own experience. The pack also flags where you'll need a real example from your history, such as one weekly drop from request to release, or a post-event review if you ran one.

Say the word and I'll play the Skeptic on A2. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or is this a different kind of round, such as a peer or a panel? And has the recruiter mentioned a take-home or presentation? The answer reweights the personas.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer, interview prep

**Company:** Saltmarsh Games (mobile, about 350 people)
**Role:** Live Operations Producer
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not stated; this pack assumes a hiring-manager round, and the persona weights below follow from that.
**Length:** 60 minutes, Friday.
**Research tier:** L0. Only your message was used. No search or fetch was run; see Sources.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. The guidance is scaffolding, not a script: say it in your own words, and if a sentence is not yours, cut it.

- **VAL**: behavioral / values alignment. Not used here: no published values were supplied.
- **EXP**: work-experience deep-dive. Tests whether your claims survive a close read.
- **JD**: role-driven. Tests the listed responsibilities, including the gaps.
- **CO**: company and strategy knowledge. Not used here: no research was run.
- **CASE**: live problem. Tests structure and reasoning on a problem from this role.

Answer slots (marked "Answer slot") are instructions for the interview. They are not questions to me.

## Fit snapshot

The JD requirements, each set against your own sentences. Your sentences are quoted exactly as you wrote them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows a weekly content-drop calendar for one title, not live events across two. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned anything for a second title, or anything beyond weekly drops, say which and what was yours; if not, say one title and its cadence. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with these four teams. Answer slot: describe how one update got made, from request to release, in your own words. Name each team you worked with on it and what each one had to deliver. If others coordinated it, say so. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is adjacent to owning KPIs; the material does not show a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Limit: your material does not show who set the KPIs. Answer slot: did you run a post-event review, or set what the KPIs measured? If yes, say how, in your own words. If not, say so, and say what you would measure first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: if you did more than write it, say what. If not, say so, and describe how QA used it. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years are stated. Live-service is not in your material; this pack does not describe your title as live-service. Bridge: "I have four years as an associate producer at a puzzle-game studio." Answer slot: say whether you would call the title's model live-service, and in your own words what it was. Length of experience is not a gate (`evidence-conventions.md` §3); it is graded on fit like any other row. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Bridge: "I ran the weekly content-drop calendar for our main title for the last two years." Medium because the calendar itself has not been inspected. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge rewords only this quote: "I presented the monthly retention numbers to the studio head." Answer slot (defend the number): how each figure was counted, the assumption you would defend least, and which part was yours. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a checklist other teams use every release. Bridge: "I wrote the release checklist our QA team still uses." |

No requirement in the JD is a gate. Every row above is a stated JD line.

**Not in the JD, but likely to come up:** the JD does not mention monetization or in-app purchases, and it does not ask for people management. Neither is a fit row. If either is raised, use the plain acknowledgment in the prohibited list below. The pack does not predict that Tobias will ask.

## Prohibited claims

Claims this pack will not coach, with the basis for each. The rule is in `references/question-rubric.md`: inflated forms are built locally from your sentences, and the honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1. Your sentence says one title, weekly drops | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: your material shows one title, not two. A1 and F1's answer slot stay inside that scope. |
| Owned post-event reviews and the KPIs they report | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." This pack's observation: your material does not show a review or who set the KPIs. |
| Managed the release process with QA | Inflated form of F4. "Wrote" is not "managed" | "I wrote the release checklist our QA team still uses." |
| Worked on a live-service title | Inflated form of F5. The live-service label is not in your material | "I have four years as an associate producer at a puzzle-game studio." |
| "I haven't led a team." | A negative you stated: "Never led a team" | Plain acknowledgment, usable if asked. No slot attached. |
| "I haven't worked on a game with in-app purchases." | A negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment, usable if asked. No slot attached. |

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the thin spots: four-team coordination, the post-event review, the live-service claim | High. The hiring-manager prior, and the JD's headline asks sit where the material is thinnest (F2, F3, F5) | Rehearse the coordination objection (A2) until it is plain. Hold the calendar claim; concede only the limits |
| Case / Strategist | A live plan for two titles; a slipped update; a team conflict | High. The hiring-manager prior, and the JD asks for coordination on each update | Clarify first, then structure. Say the assumption you are making |
| Data-Driven Prober | Asks how the retention figure was counted | Medium-high. The JD names retention metrics, and one of your sentences touches them (F7) | Name the weakest assumption before they do. Say plainly what you do not know |
| Pressure | Time-boxed "why you" | Medium. No signal of a stress style, but a 60-minute round can include one | Hold through two follow-ups, then concede the specific limit |
| Conversational | Opener, "walk me through" | Low to medium. Rounds usually open friendly | Use the 90-second arc (E1). Treat casual questions as scored |

**Interviewer read: absent.** No public footprint of Tobias was checked. The upgrade menu says what a check would unlock.

**Likely shape of the 60 minutes (generic, not a fact about Saltmarsh's process):** about 5 minutes opening, 10 on your background, 25 on the calendar, coordination and a live case, 10 on metrics and the post-event review, and 10 for your questions and close. Use this to pace, not to predict.

## Question banks

Question IDs are letter-by-persona. Provenance comes before guidance. A row's guidance may say only what its own Provenance quotes say about you; everything else is an answer slot.

### A. Skeptic (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How does your puzzle-game work map to live-service production, if at all?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the calendar, in your words: the weekly content-drop cadence, for the main title, for two years. Then say what the title ran on, in your own words. Answer slot: if you ran anything beyond the weekly drops, say what, and which part was yours. If not, say the title ran on weekly drops and stop there. | F5 is transferability: the years are stated, live-service is not. The question tests whether the claim widens. F1 is the calendar line it leans on. |
| A2 | "Which parts of the live-events calendar did you coordinate with design, art, engineering and community, and which did others run?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Hold: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: describe how one update got made, from request to release, in your own words. Name each team you worked with and what each had to deliver. If others coordinated it, say so. Hold through two follow-ups by returning to the calendar. Never add a team or a step to fill the gap. | F2 is the gap the Skeptic will press, and the material is silent on it. The question presumes coordination the quotes do not carry; the second branch allows it never happened. |
| A3 | "You haven't led a team. Why would this role be different?" | JD | [grounded] "Never led a team" (plain acknowledgment: "I haven't led a team.") | Plain acknowledgment: "I haven't led a team." Then state what the posting asks of you: "The posting asks me to coordinate design, art, engineering and community on each update." Do not claim leadership. | Not a JD requirement, so no bridge is manufactured. Calibrated candor beats bluffing a competency the interviewer owns. |
| A4 | "You presented the retention numbers. Did you decide what they meant, or did someone else?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented, to whom, and how often, in those words. Answer slot: if you chose what a retention figure was read against, or what action it led to, say so. If the reading was someone else's, say so plainly. | F7 is presentation: the quote reaches retention, not interpretation. The question tests attribution. |
| A5 | "Have you owned a post-event review? Walk me through the last one." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | The JD raises the post-event review; your material does not show one. Answer slot: if you ran a post-event review, describe its steps in your own words. If you did not, say so, and say what you would measure first. That last part is a plan, not a past. | F3 is transferability. The question's premise is the JD's, so the guidance does not adopt it: it asks, and the honest branch is open. |

### B. Case / Strategist (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would plan the live-events calendar for two titles over the next quarter. What do you need to know first?" | CASE | [generic] | Clarify before you structure: each title's current cadence, team capacity, the release windows QA will need, which events are fixed, and what each title's KPIs are. Then the approach, then the metrics you would watch, then the risks. Say the assumption you are making. | A JD headline requirement. [generic] because it is a problem, not a claim about you. |
| B2 | "An update slips two days before launch and QA finds a blocker. What do you do?" | CASE | [generic] | Clarify the blocker's severity, who owns the release decision, and what slips if you wait. Name who you would tell and in what order. | R4 manage the release checklist with QA. A live problem; it asks for no past. |
| B3 | "Design and community want different things from the same update. Who decides, and how?" | CASE | [generic] | Name the decision owner first, then the tradeoff, then the KPI the update is meant to move. Keep the answer to the structure: the calendar and KPIs are your shared reference. | F2 is discovery. This rehearses structure, not history. |
| B4 | "Retention drops on day three after an event. How would you run the post-event review?" | CASE | [generic] | Structure: what you would measure, what you would compare it against, what would count as a cause, who needs the answer, and what you would change. Do not describe a review you ran unless you ran one. | F3 and R3. The question presumes nothing about your past; the guidance keeps it that way. |

### C. Data-Driven Prober (weight: medium-high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that monthly retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot (defend the number): how the figure was counted, the assumption you would defend least, and which part was yours. If you did not count it yourself, say so. Do not supply a method, a window or a cohort definition your material does not state. | F7 is presentation. Defend-the-number: the probe asks for the denominator, and the honest answer may be that you did not count it. |
| C2 | "A KPI moved after an update. How do you know the update caused it?" | JD | [generic] | Name the confounds you would check first: concurrent events, seasonality, cohort mix. Say what evidence would change your mind. | R3, KPIs reported. [generic] because it is a method, not a claim about you. |
| C3 | "Which retention metric would you not trust a single number from, and why?" | JD | [generic] | Name the metric and what makes a single reading unreliable: cohort mix, the early-game versus late-game split, and what changed in the same window. | R7. Tests whether you know the metric's sensitivities, not whether you have used it. |
| C4 | "After an event, which KPI would you put in front of the studio head first, and what would make you drop it?" | JD | [generic] | Name one KPI, what it tells the studio head, and the condition under which you would stop reporting it. | R3. Forward-looking; it asks for judgment, not history. |

### D. Pressure (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over an internal candidate who already knows our titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Restate the question first. Concede the specific limit: your material does not show a second title or live-service work. Hold the calendar claim through two follow-ups; concede only the limits. | F1 and F5 as the Skeptic's objection under time pressure. Hold-then-concede. |
| D2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer with the sentence, then say which parts you set and which others set. If none of it was yours to set, say so plainly. | Attribution under pressure. "Ran" is the verb: do not promote it to "built" or "owned". |
| D3 | "You wrote a checklist QA still uses. Which items were yours, and which were QA's?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: say which items you wrote and which QA set or changed, in your own words. If you cannot separate them, say so. | F4. The question presumes the split exists; the second branch allows that it does not. |

### E. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order: the studio and the years, the calendar, the checklist, the retention presentation. Stop before the JD. Every beat is a sentence you wrote. | Rapport openers are scored. This is the arc the pack's spoken answers are built on. |
| E2 | "What live-service game do you admire, and what is its update rhythm?" | JD | [generic] | Name one game you can describe concretely: its update rhythm, and what you would take from it. Do not claim expertise you do not have. | Casual, but scored for interest and fit with the role. [generic] because it is about the world, not you. |

**Requirement coverage**

| JD requirement | Covered by | Gap |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B1 | none |
| Coordinate design, art, engineering and community on each update | A2, B3 | none |
| Own the post-event review and the KPIs it reports | A5, B4, C2, C4 | none |
| Manage the release checklist with QA | B2, D3 | none |
| 3+ years producing live-service games or apps | A1, D1 | none |
| Experience running a content calendar | A1, B1 | none |
| Comfortable with player-retention metrics | A4, C1, C3 | none |
| Clear written communication | none, and why: the interview is spoken, and the spoken arc is E1. The written side shows in your answers and is not tested by a question | — |

## Reverse questions

Five questions, each with why it lands. No interviewer profile exists, so none is tied to Tobias's path. This is a hiring-manager round, so no reciprocity question is needed.

1. "What does a good post-event review look like here, and who reads it?" Why it lands: shows you already think about KPI ownership as a deliverable.
2. "Which two titles does the calendar cover, and how different is each one's update rhythm?" Why it lands: shows you have heard the scope and want its shape.
3. "When a release date and a QA blocker conflict, who makes the call?" Why it lands: tests the release-checklist decision with the person who owns it.
4. "How do design, art, engineering and community get their asks into the calendar today?" Why it lands: names the coordination problem directly and asks how it is solved now.
5. "What would make this role succeed in six months, in numbers?" Why it lands: a standard close that shows you want to be measured.

## Examples to bring from your own history

Only if they happened. Each one unlocks an answer slot above; if none happened, the honest answer is the plain one.

1. One weekly content drop, start to finish: who you worked with on it and what each one delivered (A2, B3).
2. A time a QA finding changed a live date, if one did (B2).
3. A retention result you presented: how it was counted, and what happened afterwards (A4, C1).
4. A post-event review, if you ran one. If not, say so and say what you would measure first (A5, B4).
5. A decision you influenced without managing anyone, if one happened. This is for the "why would this role be different" question (A3).

## Sources

**Provided documents:** the JD text and the background notes in your message. Nothing else.

**Searches and fetches:** none. Research was not run at L0; the consent question was deferred to the upgrade menu.

**Dossier:** none consumed.

**Research tier: L0. Searches 0 of 0, fetches 0 of 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Values cheat sheet. No values-style round was detected. Unavailable at L0 |
| 2. Saltmarsh interview process, live ops | unavailable | Loop structure and persona weights. Unavailable at L0 |
| 3. Saltmarsh strategy / recent news | unavailable | The CO bank. Unavailable at L0 |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Interviewer read and a tailored reverse question. The name is given; no query was sent at L0 |
| 5. Representative Live Ops Producer JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and whether Tobias is your future manager → reweights every persona and tailors the reverse questions. The pack currently assumes a hiring-manager round.
- Any take-home or presentation the recruiter has pre-declared → adds a graded-deliverable build section.
- Tobias's public profile (the name is given, not searched) → an interviewer read and a tailored reverse question.
- Research at L1 (up to 6 searches and 2 page fetches) on Saltmarsh's values, interview process and live-ops titles → the loop structure, and a values sheet if the round is values-style. Not run at L0.
- Deeper research at L2, offered once: four further targets, up to 6 more searches and 2 fetches. It takes a few minutes.
- The content calendar, the release checklist, or a retention deck you presented → inspectable artifacts. These raise F4 and F6 to high, and F7 too.
- A post-event review you ran, if one exists → gives F3 a grounded example instead of a low-confidence one.
- A tuesday-dossier.md → would add verified evidence and any prohibited claims from a reviewer.
