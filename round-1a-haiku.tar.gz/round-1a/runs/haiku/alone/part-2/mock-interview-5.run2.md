Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-5-denied-16c7c8c7/0b80ef46-8f54-41c4-a7d1-eb3525254144/scratchpad/kelverton_rail_senior_partnerships_manager_interview_pack.md`. It is built from your message and the recruiter's email as you quoted it. I had no JD, CV or market report text, and web search was refused this session, so there is no company research in it. The values, strategy and interviewer sections are marked unavailable rather than filled from memory.

The most useful part for Tuesday is section 5, the 15-minute point of view. It gives three theses, each with its concession, a differentiation step against the report's consensus, and a close on what it means for operators. Your 4 hours are triaged in section 2.

The highest-ROI rehearsal is B1: "You've never carried a quota. Why should we hire you to own a commercial number?" Hold on the 6-to-40 partner record, then concede the quota gap plainly with a plan, not a past. Ross is the one who will press on it.

Pack-wide, the pack won't coach rail sales, quota ownership, "£4M generated", or operator buying experience. Those claims are your stated gaps or stretches of your own sentences, so they are listed in section 4.

Two things would sharpen it:

Want a drill? I can play Ross on B1 and B3 and give feedback against the pack's own guidance for each question.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Is there a location, travel or right-to-work condition in the posting? The pack has no gate row for it because the material doesn't say.

Can you paste the market report's top recommendation in one sentence? Section 5's differentiation step needs it, and it's the step most likely to separate you from the other candidates.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_rail_senior_partnerships_manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail (second round, panel)

Round: 60-minute panel on Tuesday. First 15 minutes: a short spoken point of view (no slides) on where to take operator partnerships over 18 months, landing on what it means for the operators. Remaining time: Q&A, with commercials pressed by Ross.
Panel: Deepa (VP Partnerships, future manager) and Ross (Commercial Director).
Built from: your message and the recruiter's email as you quoted it. No job description, CV or market report text was available to me, so the pack is built on the recruiter's own words and your own sentences only.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: `CASE` live problem, `EXP` what you did, `JD` the listed job, `CO` company and commercial knowledge, `VAL` values (none detected here).
- Guidance is scaffolding for a spoken answer, not a script. Where the guidance says "answer slot", the honest answer is either branch: what you did, in your own words, or that it was not yours or did not happen.
- Provenance column: the quoted sentence(s) each guidance cell rests on. If a claim in your answer is not in the quote, do not say it.

## 2. Prep triage (about 4 hours)

1. **75 min: build the POV (section 5).** Pick one thesis, write the three beats, say it aloud twice, time it at 12 to 13 minutes. Aim for the 15-minute slot with room for interruption.
2. **60 min: rehearse the commercial pressure (bank B).** Ross will push here. Start with B1 (the highest-ROI rehearsal in this pack) and B3. Hold-then-concede, out loud.
3. **45 min: rehearse Deepa's case and motivation questions (bank A and D).** Focus on A1 and A4.
4. **30 min: reverse questions (section 11).** Choose three you would actually ask.
5. **30 min: close the market-report gap.** Write the report's top recommendation in one sentence, then your departure from it (section 5, differentiation).

Everything else is insurance. The opener bank (C) takes five minutes to rehearse once.

## 3. Fit snapshot

Requirements come from the recruiter's email and your message, quoted. Gate items: the posting's location, travel and right-to-work conditions are not in the material; see the question in the closing section.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "9 years in partnerships" (your message); "running the ISV channel" (your message) | medium | [grounded] | transferability | Your material shows the channel you ran, not operator partnerships. Words: "I was running the ISV channel at a payments company." ISV partners and train operators are different counterparties, and say so. Answer slot: if you set any partner's priorities or commercial terms, say which and how you decided; if you did not, say so and describe how the channel was run. |
| F2 | "Please land on what it means for the operators themselves." (recruiter's email) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | transferability | Words: "I spent five years on bus and light rail network planning, so I know the operator world from the other side." Limit: that was planning work. Your material does not show how operators buy or approve a change. Answer slot: if you saw an operator decide on a planning or scheduling tool, say what you saw and whose decision it was; if you did not, say so. |
| F3 | "Ross will push on commercials." (recruiter's email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message); "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | transferability | Words: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Plain acknowledgment: "I haven't carried a direct quota." Influenced revenue is not revenue you closed; do not let the figure carry more. The figure raises the defend-the-number slots in B3 and B4. |
| F4 | Rail sales experience (role-family expectation, not in a supplied posting) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Words: "I haven't sold into rail." Then how you would learn it, said as a plan and never as a past. Never a claim to rail buyers or rail sales work. |

## 4. Prohibited claims

These are claims the pack will not coach, because the material contradicts them or stretches a sentence you wrote. None of them may appear in an answer, a hold or a reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| "I sold into rail" or "I know rail buyers" | Negative you stated (F4) | "I haven't sold into rail." No slot |
| "I carried a quota" or "I owned a revenue target" | Negative you stated (F3) | "I haven't carried a direct quota." |
| "I generated £4M" or "£4M of revenue came from my partners" | Inflated form of F3: your figure is influenced revenue | "roughly £4M of influenced revenue," at that scope |
| "I ran operator partnerships" or "I managed train operator relationships" | Inflated form of F1 | "I was running the ISV channel at a payments company" |
| "I know how operators buy" | Inflated form of F2 | "I know the operator world from the other side," with the limit that you did not see how they buy |

The limits in this table are the pack's own observations, in analysis. They are not first-person claims for you to say.

## 5. Graded deliverable: the 15-minute point of view

Recruiter's instruction, quoted: "a short POV on where you'd take our operator partnerships over the next 18 months," landing on "what it means for the operators themselves." Grounded facts to build on: F1 and F2 (quoted above).

**Structure (about 13 minutes of talk plus room for interruption):**
1. The operator's problem, in their terms (2 min). Describe what an operator has to get through to change a schedule. Do not describe the product.
2. Three theses for 18 months (7 min). Pick one or two to lead with. Each thesis carries its concession, stated aloud.
3. What it means for the operators (3 min). This is the close the recruiter named.

**Thesis options (each with a mandatory concession):**
- **T1: Start from the operator's live scheduling decision, not from the feature roadmap.** Pick two or three operators where a change is a live decision this year, and build the partnership around that decision. Concession: I do not know how an operator's approvals and customer communication work internally; I would test this with two operators before committing to it.
- **T2: Tie commercial terms to what the operator is measured on.** Concession: I have not seen the funding or contract structures that set operator budgets, so this model may not fit their budget cycle, and I would check it with Ross's team first.
- **T3 (the anti-pick): do not chase every operator.** A short list is better than a wide one. Concession: fewer partners means a thinner pipeline in the short term, and you will have to explain that to the commercial side.

**Differentiation against the consensus answer:** the report you read is the consensus any prepared candidate assembles. In one sentence, state the report's top recommendation. Then depart from it, with a reason, using one of T1 to T3. Do not recite the report. Its content is not in this pack, so this step needs the report's recommendation (see the upgrade menu).

**Requested close (operator benefit):** "What changes for an operator's planning team in the first month, and what they can measure by month eighteen." Do not promise outcomes you have no data for. Frame them as what they should be able to check.

## 6. Persona table

Panel: blend the two top personas of each member's relationship. Deepa is the future manager and has the hiring-manager prior; Ross is the commercial voice and has the executive prior.

| Persona | Member | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist (weight 5) | Deepa | Live problem on operator partnerships; clarify before structure; she will check whether your POV is an operator's view | High: a hiring manager buys capability and tests the POV on her own roadmap | Clarify, then structure around the operator's decision (section 5) |
| Skeptic (weight 3) | Deepa | Quiet probes on the gaps: rail, quota, operator-side experience | High: F1, F2 and F4 are the gaps the panel will see first | Bridges built only from quotes; acknowledge the gap plainly |
| Pressure (weight 5) | Ross | Time-boxed challenges on commercials; questions on motive | High: "Ross will push on commercials" is the recruiter's own warning | Pause, restate, hold through two follow-ups, then concede precisely |
| Data-Driven Prober (weight 4) | Ross | Asks how the £4M was counted and what you would defend least | High: a headline figure with a stated limit is a magnet for probers | Say what you know about the counting, and say plainly what you do not |
| Conversational (weight 3) | Both | Friendly opener; a casual question about the POV or about the ISV channel | Medium: openers are scored too | Pre-scripted 90-second arc |

## 7. Question banks

Ordered by weight within each persona. Depth follows weight: the top persona gets five or six questions, mid-weight three, low-weight two or three.

### Bank A: Deepa, Case / Strategist and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you structure anything: what do you need to know about one operator before you would change how you partner with them?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | Clarify first: which operator, which decision, what they already buy. Then structure around that decision, using T1 from section 5. Say the hypothesis early. | A live problem from the POV brief; it presupposes nothing about your past |
| A2 | "Walk me through the first 18 months for one operator relationship." | CASE | [grounded] "Please land on what it means for the operators themselves." (recruiter's email) | Use the POV's three steps: the operator's problem, the shape, what it means for them. Keep it to two minutes and offer the rest on request. | The POV's second half is the most likely probe; it draws on the recruiter's close |
| A3 | "What did you learn about operators from transport consulting that you would bring here?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | Say what you learned in planning terms. Answer slot: if you saw an operator decide on a planning or scheduling tool, say what you saw and whose decision it was; if you did not, say so. Do not say how operators buy. | F2 is the only operator-side evidence; this question tests whether the planning view is the one you claim |
| A4 | "You haven't sold into rail. Why should we believe you can do this here?" | JD | [grounded] "Never sold into rail specifically" (your message) | Acknowledge it first: "I haven't sold into rail." Then say what transfers and what you would do in the first 90 days. Plan language only, no past tense about rail. Hold through one follow-up, then concede any remaining gap plainly. | F4 is the largest gap in the material; this is the objection in its simplest form |
| A5 | "Why leave a payments company, and why rail?" | EXP | [generic] | Give your own reason in your own words; the material does not contain one, so this slot is yours to fill. Say the reason in one sentence and tie it to the operator side. | A motivation probe a skeptic asks; no reason is in the material, so none is supplied here |
| A6 | "What would you need from a partnerships lead in the first 90 days to feel the hire was right?" | CASE | [generic] | Name the two or three outcomes you would ask for and how you would test them with operators. | A forward-looking question that tests whether your POV has operator-level detail; no past claim |

### Bank B: Ross, Pressure and Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI rehearsal in this pack.** "You've never carried a quota. Why should we hire you to own a commercial number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message); [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Hold: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Hold through two follow-ups by returning to the partner count. Then concede: "I haven't carried a direct quota, and that is a real gap; here is how I would close it in the first quarter." The concession is a plan, not a past. | F3 is the likeliest objection; Ross's brief is commercials. The hold is what the quotes carry; a bigger number would not survive the second follow-up |
| B2 | "Sixty seconds: why would an operator sign with you rather than build it themselves?" | CO | [generic] | Structure in three beats: the operator's cost of building, the cost of your offer, the proof they could check. Do not claim proof you do not have. | A commercial pressure question on the POV's core claim; [generic] because it is a pattern for this kind of sale |
| B3 | "Roughly £4M of influenced revenue. How was influence counted, and which assumption would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Answer slot: say how influence was counted in your payments channel, in your own words. Name the assumption you would defend least. If you do not know how it was counted, say so. The figure is yours; the counting method is not in the material. | F3's figure is the headline; a defend-the-number probe is the expected follow-up |
| B4 | "Of the four, which part of the channel's growth was yours to set?" | EXP | [grounded] "running the ISV channel" (your message); [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say which part of the growth you set (partner recruitment, terms, priorities), and how you decided. If none of it was yours to set, say so and say what you did run. | Attribution probe on F1; the answer must stay inside what you ran |
| B5 | "What's the revenue from an operator partnership in 18 months? Give me the number." | CO | [generic] | Do not invent a number. Say what you would forecast, what it depends on, and what you would need to know from operators first. | A commercial close that tests whether you will invent a figure under pressure |
| B6 | "Sixty seconds: what does a train operator get from you that doesn't show up in the licence fee?" | CASE | [generic] | Name the operator's own outcome in its terms, not yours, and say how they would know. | Forces the "what it means for operators" close under commercial pressure |

### Bank C: Conversational opener, both

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships" (your message); [grounded] "5 years in transport consulting" (your message) | A 90-second arc: nine years in partnerships, the ISV channel, and the transport planning years before them, in that order. Stop after 90 seconds. | Openers are scored; a pre-scripted arc keeps the answer short and in your own words |
| C2 | "What's the most interesting thing about operators at the moment?" | CO | [generic] | Name one operator-side pressure you can defend and say how you know. If you do not know, say that. | A casual question on the POV topic, scored as homework |
| C3 | "What made you want this role?" | EXP | [generic] | Give your own reason, in one sentence, tied to the operator side. The material does not contain one; this slot is yours. | A motivation question at the start of the round |

### Bank D: Skeptic and motivation (mid-weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message) | Name rail sales first, in the plain acknowledgment: "I haven't sold into rail." Then say how you would learn it. Do not name a second gap you have not checked. | Open prompt on the largest gap; a candid answer scores better than a defended one |
| D2 | "Operators are not your customers in the usual sense. What's the difference, from where you sit?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | Say what the difference looks like from planning: operators are the decision-makers, and their constraints come first. Do not claim you sold to them. | Tests whether F2's "other side" is a claim about buying |
| D3 | "Where do you want to be in 18 months, and what would you have to have done by then?" | JD | [generic] | Tie the answer to the POV: two or three operator outcomes you would check at month 18. | An open forward-looking question; the POV is the best answer |

## 8. Requirement coverage

| Requirement | Question IDs |
|---|---|
| Operator partnerships over 18 months (recruiter) | A1, A2, A6, D3, B6 |
| What it means for operators (recruiter) | A2, B2, B6, D2 |
| Commercials (recruiter) | B1, B3, B4, B5 |
| Rail sales experience (role-family, [generic]) | A4, D1 |
| Operator-side experience (F2) | A3, D2 |
| Motivation | A5, C3 — none in the material; both are yours to fill |

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 (to Deepa) | "What did the last operator partnership that worked look like, and who inside the operator drove it?" | It makes the operator the unit of the answer, which is the brief |
| R2 (to Ross) | "What share of partner revenue today is direct and what share is influenced, and how is influenced counted?" | It asks him to define the figure you will be measured on, and shows you read the commercial question |
| R3 (to Deepa) | "What would the first 90 days need to deliver for you to feel this hire was right?" | A manager's question; the answer tells you what she will test first |
| R4 (to either) | "Which operator relationship is the one you most need to fix in the next six months?" | Shows you are thinking about live work, not the brochure |
| R5 (to either) | "What did the market report get right, and where do you think it is wrong?" | Shows you read it critically; use only after you have the report's recommendation (see the upgrade menu) |

No reverse question is tied to Deepa's own career path: no profile was available (see the upgrade menu).

## 10. Sources

- Provided: your message; the recruiter's email as you quoted it.
- Not read by me: the internal market report (you read it; its text is not in this conversation).
- Searches sent this session: "Kelverton Rail values" (refused); "Kelverton Rail strategy news train operating companies scheduling software" (refused). Both were refused by the host's search permission, so nothing was found and nothing from them is used.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet, section 10 of the template: not produced. Search refused. The pack uses no published values |
| 2. `Kelverton Rail interview process` | unavailable | Loop structure: no search was sent. The panel format from the recruiter's email is the only loop source |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Grounding brief and CO questions go generic; the strategy search was refused |
| 4. `Deepa Kelverton Rail` (interviewer footprint) | unavailable | Interviewer read and tied reverse questions: no search sent; first name, title and company form a query |
| 5. representative JD | unavailable | Not run: no JD was supplied, so requirements come from the recruiter's own words |

## 11. Upgrade menu

- The market report's top recommendation in one sentence → section 5's differentiation step becomes specific, and R5 becomes usable.
- The posting or job description, pasted → the requirement rows move from the recruiter's words to the posting's words, and more JD questions are generated.
- Your CV → the four quoted sentences move from "your message" to a CV line, which is stronger to say aloud.
- Deepa's and Ross's public professional profiles (full names) → an interviewer read, persona weights per member, and reverse questions tied to their career paths. Search was refused this session.
- The recruiter's exact POV instructions (length, format, whether slides are allowed later) → the triage and section 5 structure can be confirmed.
- The posting's location, travel and right-to-work conditions → a gate row, if any apply.
