Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-3-denied-5344c7e5/7fb4df7d-5958-43f5-9659-4c6d718c2bf0/scratchpad/stripe_product-operations-manager_interview_pack.md`.

The pack is thin, because I had nothing about you or the role to build on. The web searches were refused permission, so it has no Stripe values, strategy or loop structure. The fit snapshot's requirements are generic product-ops requirements, not the posting's. Every question about your past is an open prompt, because there's no CV to draw on. The persona weights are flat, since I don't know who you're meeting.

The most useful next step is the job description plus your CV. That turns the generic rows into quoted requirements and lets me build story-mapped answers. Once you grant web search, I can add the values, the current strategy and the interview loop.

Offers, neither pushed:
- Say the word and I'll run a live drill as the Pressure interviewer on B1, "Sixty seconds: why this role?"
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Two questions:
1. Who are you meeting in the final round: your future manager, a peer, or someone else? Did the recruiter name any focus areas?
2. Can you paste the job description and your CV, or should I proceed without them?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final. Interviewer: not known. Relationship: not known, so persona weights are flat. No job description, CV or research was available when this was built, so this is a worksheet-level pack: every candidate-evidence cell is empty, and the banks use open prompts and live problems rather than questions about your past.

## How to use this pack

Personas are how a question is asked. Types are what it is scoring.

- VAL: behavioral and values alignment
- EXP: your experience, tested for attribution
- JD: role and requirement fit
- CO: company and strategy knowledge
- CASE: a live problem, reasoned aloud

Guidance is scaffolding, not a script. Rehearse the structure and the honest branch, and fill them in with what you actually did.

## Fit snapshot

No requirements were supplied, so the rows below are role-family requirements written as plain prose and labeled [generic]. None of them has a quote behind it, so every row is a worksheet row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run operating cadence and reviews across several teams (role family) | none given | none | [generic] | discovery | Strong evidence looks like a recurring review you ran and what changed because of it. Answer slot: describe one review cadence you have run or helped run, in your own words; if you have not run one, say so and say how you would set it up |
| F2 | Define, track and report operating metrics (role family) | none given | none | [generic] | discovery | Strong evidence looks like a metric you defined, the decision it fed, and what you would not count. Answer slot: name one metric you have tracked and how it was counted; if you have not tracked one, say so and say what you would measure first |
| F3 | Design process and tooling that internal teams adopt (role family) | none given | none | [generic] | discovery | Strong evidence looks like a process you designed and whether teams kept using it. Selection scaffold: pick a process you introduced or changed, say what was yours to decide, and if none was, say so plainly and describe how the team handled it |
| F4 | Manage cross-functional projects to a deadline (role family) | none given | none | [generic] | discovery | Strong evidence looks like a project with several owners and a deadline you tracked. Selection scaffold: pick a project that crossed functions, say what you tracked and what slipped; if you were not the one tracking, say so |
| F5 | Influence leaders with a recommendation they did not want at first (role family) | none given | none | [generic] | discovery | Strong evidence looks like a disagreement with a senior person and how it resolved. Selection scaffold: pick a time you pushed back on a leader; if none comes to mind, say so plainly, then give the nearest thing you did |

## Prohibited claims

These are the claims this pack will not coach, because nothing supports them yet. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Stripe-specific knowledge of its operations, products or strategy beyond what you have read yourself | No research ran, so the pack has no source for any Stripe fact | Name what you have read and where you read it. If you have read nothing specific, say you are learning it |
| Any headline result or figure the pack has not heard from you | No CV or background was supplied | Give the figure only if you can say how it was counted. Otherwise use an answer slot |
| Owning an outcome or decision that you have not described in your own words | No quotes exist yet, so every ownership claim is unsupported | Describe what you did in your own words and let the interviewer draw the inference |

## Persona table

Weights are flat (3 / 3 / 3 / 3 / 2 / 2 / 2) because the relationship is unknown. The depth of each bank follows from that. Recalibrate once you know whether this is your future manager or a peer.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Asks how a number was counted, what the denominator was | Medium | Product ops roles are metric-heavy; a generic metric question is likely | Name the weakest assumption before they do |
| Pressure / Stress | Interrupts, plays devil's advocate on your process | Medium | Final rounds often include one stress interviewer | Pause, restate, hold through two follow-ups, concede specifically |
| Values / Behavioral | Scenario probes for stories | Medium | Behavioral questions are standard in final rounds; no published values were fetched, so the probes are generic | Open-prompt stories with an honest branch |
| Case / Strategist | Live problem about an operating issue | High | Product ops is judged on live problem-solving | Clarify, then structure, then metrics, then risks |
| Skeptic | Asks where you are weakest | Low to medium | Ordinary final-round pressure | Name the weakness plainly and give a ramp plan |
| Conversational | Warm opener, casual scored question | Low to medium | Often the first question of a final | Pre-scripted 90-second arc |
| Peer Evaluator | Seam between ops and product, credit sharing | Low to medium | Depends on whether a peer is on the loop | Propose seam principles, not claimed knowledge |

## Question banks

Provenance is [generic] on every row because no question states, presupposes or evaluates a fact about your past. Rows that ask about your past are open prompts with a theme drawn from the persona stems.

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you counted the result you are proudest of." | EXP | [generic] | Name the result, the count, the denominator, and the assumption you would defend least, in your own words. Answer slot: if you have no result you can count, say so plainly, then give the nearest thing you measured and how you counted it | Open prompt built from the prober stem; the count is the first thing a prober checks |
| A2 | "Which metric do you watch most closely, and what would make it mislead you?" | JD | [generic] | Name the metric, what it is for, and one condition under which it misleads. Do not add a figure you have not given | Tests metric judgement for the operating-metrics requirement (F2) |
| A3 | "What did you do when a number and an anecdote disagreed?" | EXP | [generic] | Pick a time the numbers and the anecdote disagreed, say which you trusted and why. If none comes to mind, say so, then describe how you would test the disagreement | Open prompt, theme from the prober stem; tests whether you know your assumptions |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why this role and not one with a more established ops function?" | EXP | [generic] | Pause, then give one reason anchored in what you actually want to do. Hold it through two follow-ups; concede specifically if a follow-up is fair | Motivation probe under time pressure; tests composure |
| B2 | "That process sounds slow. How do you defend it to a team shipping every day?" | CASE | [generic] | State the tradeoff in one sentence, concede the specific cost you are unsure of, do not fold on the core point | Hold-then-concede structure on a live tension |
| B3 | "Name the one thing you would cut from your plan right now." | CASE | [generic] | Commit to one cut and its cost. Do not hedge it into several | Tests commitment under time pressure |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time the truth landed or did not, say what you said and what happened. If the truth did not land, say so | Open prompt from the behavioral stem; the honest ending is part of the answer |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time you chose the customer outcome over the internal number, and say what the number was | Open prompt from the behavioral stem |
| C3 | "Tell me about a time you were wrong about a process and how you found out." | VAL | [generic] | Pick a time you were wrong, what signal showed it, and what you changed | Open prompt; tests self-correction |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A team has no shared operating review. Sketch what you would set up, and what you need to know first." | CASE | [generic] | Clarify scope and goals first, then structure: cadence, owners, metrics, risks. Say the structure aloud | Live problem from the operating-cadence requirement (F1) |
| D2 | "A cross-team launch's throughput fell sharply this month. Diagnose it." | CASE | [generic] | Clarify what fell and against what baseline, segment the drop, then test each hypothesis against data you would need | Tests diagnosis, not a right answer |
| D3 | "For a new internal tool, what would you measure first, and what would you deliberately not measure?" | CASE | [generic] | Name the first measure, one you would not use and why, and the decision each one feeds | Tests judgement on metrics (F2) |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the area plainly, then give a ramp plan: what you would learn first, from whom, by when | Standard final-round probe; answer by naming the gap, not hiding it |
| E2 | "Why are you looking to move now?" | EXP | [generic] | Give one reason about the work, stated in your own words. Avoid criticising your current employer | Motivation consistency probe |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: where you started, the two or three moves that shaped you, and why this role now. Keep it spoken, not a list | Casual-sounding opener still scored on communication economy |
| F2 | "What are you curious about in how we run operations?" | CO | [generic] | Ask about something you have actually read or observed. Do not claim familiarity you lack | Tests genuine interest; company facts are not available to the pack |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where is the seam between operations and product, and what happens when we disagree?" | JD | [generic] | Propose one principle for the seam and how you would handle disagreement. Do not claim to know the seam before you have seen it | Peer-style seam probe |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name how you share credit and where you draw the line. Keep it to your own practice | Tests partnership fit |

## Requirement coverage

No job description was supplied, so no stated requirement exists to map. The rows F1 to F5 are role-family requirements. A1 to G2 cover them as follows: F1 by D1 and B2; F2 by A2, A1 and D3; F3 by C3 and F4 by C3, E1; F5 by B1 and C1. Recheck this table against the JD once you send one.

## Reverse questions

No interviewer profile exists, so these are role-generic. Each has a reason it lands.

1. What does a strong first 90 days look like for this role? It shows you the outcome you will be judged on.
2. Where does this role make operating decisions, and where does it not? It tells you the decision rights, which most candidates never ask about.
3. What usually stalls operations work here? It tests where the real friction is.
4. How does the team know the operations function is working? It shows you the measure they use.
5. What would make you regret this hire six months from now? It surfaces the concern they will not state openly.

No reciprocity question is included, because the relationship is unknown. Add one if the interviewer is a peer.

## Sources

Provided documents: none. The user's message is the only input.

Searches sent, with results:

- "Stripe company values principles": refused (permission to use WebSearch was not granted)
- "Stripe interview process final round loop": refused
- "Stripe Product Operations Manager job description": refused

No page fetches were sent.

Research tier: L1, searches 0 of 6 returned results (3 attempted, all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10) would have been built from published values. Refused, so no values cheat sheet is included |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Refused, so weights are flat |
| 3. Stripe strategy and recent news | unavailable | Current-strategy case questions and CO questions. No search was sent, because the budget went to targets 1, 2 and 5 first |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the role-family rows into quoted requirements. Refused |

## Upgrade menu

- JD text → rows F1 to F5 become quoted requirements, the coverage table becomes real, and the questions are checked against the JD
- CV or background → worksheet rows take quotes, and the open prompts become story-mapped answers
- Round type and who you are meeting → persona weights and reverse questions are recomputed
- Recruiter's prep email → any pre-declared deliverable or focus area gets its own section
- Permission to run web search → the Stripe values cheat sheet, current strategy questions, the loop structure and a representative JD
- Interviewer's name → a tailored reverse question and persona weights from public footprint
