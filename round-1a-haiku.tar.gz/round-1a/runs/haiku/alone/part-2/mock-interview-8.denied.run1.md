Your prep pack is saved as /var/tmp/tuesday-measure/1a/runs/haiku/alone/part-2/rooms/case-8-denied-0007113a/ashgrove_member_experience_lead_interview_pack.md. I built it as a loop: one shared fit snapshot, then a mini-pack for each of the three rounds on 26 November. I ran no web research, so everything rests on what you pasted and the recruiter's email.

The pack's most useful finding: the contact centre is the gap an interviewer is most likely to press. The JD makes you responsible for complaints across branches and the contact centre, and you have never worked in a contact centre. Question B1 covers it, and it's the one to rehearse first. Your other stated gaps are presenting above regional level (A6, B3) and coaching supervisors on escalations (B4, which your quote supports only as training tellers). Every answer in the pack is built only from sentences you wrote, and every gap has a plain acknowledgment or an answer slot. Nothing is written as something you did when you haven't said so.

The case in Round 3 is a generic complaint-escalation scenario (C5), because the panel hasn't shared theirs. It gives a structure you can use with any version of the case.

Say the word and I'll play the Skeptic on B1 so you can rehearse it live. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep (Dara)

Interviews: three rounds on 26 November 2026. Round 1 is the recruiter (30 min). Round 2 is the Head of Member Services, your future manager (45 min, mostly behavioural). Round 3 is a panel of two branch managers, not yet named (60 min, including a 20-minute complaint-escalation case, scored against the four values).

Built as a loop: one shared fit snapshot and sources, then a mini-pack per round. Built from your background message, the JD, the recruiter's email, the values as you copied them on 17 November 2026, and the strategy brief summary you sent. No web research was run.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script. Answer in your own words, and only with what you actually did.

Type key:

- **VAL**: behavioural and values alignment
- **EXP**: your past work, and what you actually did in it
- **JD**: the job's stated requirements, including its gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role, worked out in the room

## The fit snapshot

Shared across all three rounds. Requirements are quoted from the JD. Evidence is quoted from your message, and nothing else is used as evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. The quote reaches the requirement. Say the years and the supervisor role as they are, without rounding up. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows a formal complaints log. It does not show whether the log carried regulatory duties, and the pack does not know. Answer slot: if the log carried rules a complaint had to meet, such as timescales or escalation rights, say which and how you applied them. If it did not, say so plainly and say what you would check first. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Never claim presenting work you have not done, and add nothing to make the gap feel smaller. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | No gap. The quote reaches the requirement. Expect a probe on what the sheet counts. The spreadsheet itself, with names removed, is the artifact that would raise this row (see the upgrade menu). |
| F5 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work at one branch's log. The quote does not reach end to end, or across branches. Say the log as one branch's log, in those words. Any step beyond the log is an answer slot: if you owned a stage beyond it, say which and how you decided. If not, say so and stay with the log. |
| F6 | "the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "Never worked in a contact centre." Then what you would learn first, said as a plan. Do not claim contact-centre experience. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your material reaches monthly reporting. It does not show resolution times. Answer slot: if the sheet tracked how long complaints took to close, say what it counted and how. If it did not, say so plainly and say how you would add that measure. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Training tellers on the escalation script is adjacent to coaching supervisors on escalations, and the quote does not reach supervisors. Say what you trained: tellers, on the script. Answer slot: if you coached supervisors on escalations, say how, in your own words. If you did not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show this, and you have not stated it is absent. Answer slot: if you have worked with a team on a self-service journey, say what you did. If you have not, say so plainly and say how you would start. |

Hard gates: the JD names no licence, credential or fixed term, so no gate row is surfaced.

Gap types follow the routing rule: `discovery` is where the material is silent, `capability` only where you stated the absence, and `transferability` where adjacent work does not reach the requirement.

## Prohibited claims

Built locally from the fit snapshot. None of the banks, holds, or rehearsal lines below may assert or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F5. Your sentence is about one branch's log. | F5's quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation: your material says one branch's log, not end to end. B2's slot stays inside the log. |
| Ran or led complaints in a contact centre | Negative you stated (F6) | Plain acknowledgment: "Never worked in a contact centre." Then a plan. No slot about a contact-centre practice. |
| Presented to senior leaders | Negative you stated (F3) | "I've never presented to anyone above regional level." Then a plan. No slot. |
| Coached branch supervisors on escalations | Inflated form of F8. Your sentence is about training tellers. | F8's quote at its own scope: "trained new tellers on our escalation script." B4's slot asks what you did, with the honest second branch. |
| Owned monthly reporting on resolution times | Inflated form of F4 and F7. No resolution-time measure is quoted. | "I built the monthly complaints spreadsheet our regional manager uses." The resolution-time measure is an answer slot (F7), not a claim. |
| Handled regulated complaints to the standard required | Inflated form of F2 | F2's quote: "I handled the branch's formal complaints log." B2's slot asks which rules the log carried. |

## Persona weights by round

Loop mode, because the recruiter's email names the three rounds, their lengths, who runs each, and which one scores values. Weights are relationship priors, adjusted by the round's format. No interviewer names were given, so no interviewer read is included.

| Round | Relationship | Weights (depth) | Why |
|---|---|---|---|
| 1, recruiter, 30 min | Recruiter | Conversational 3 (A1, A7, A8). Light Skeptic 1 (A6). Logistics slots A2 to A5 | The recruiter's prior is conversational, with light skepticism. Pay, notice, location and reason for leaving are knockout checks, and the risk is treating the round as unscored. |
| 2, Head of Member Services, 45 min | Hiring manager, future manager | Skeptic 4 (B1 to B4). Values/Behavioral 3 (B5 to B7). Case and CO 2 (B8, B9) | The manager prior is Case plus Skeptic. The email says the round is mostly behavioural, so Values/Behavioral is lifted to the middle, and Skeptic stays on top because the contact-centre gap is the manager's first question. |
| 3, panel, 60 min | Two branch managers, scoring against values | Values/Behavioral 4 (C1 to C4). Case 2 (C5, C6). Peer Evaluator 2 (C7, C8). Data-driven Prober 1 (C9) | The panel prior blends the top two personas of each member, peer and values. The email says the panel scores values, so the four values questions carry the round. |

Persona counter-strategies, applied to this candidate:

- **Skeptic**: rehearse the contact-centre objection until it is boring. Hold the true sentence, concede the gap, and give a plan. Do not bluff a competency you have not shown.
- **Values/Behavioral**: map a story only where one of your sentences carries one. Where none does, the scaffold names the honest branch: say so, then give the nearest thing your material carries.
- **Case**: clarify, then structure, then steps. Think aloud, and challenge one premise.
- **Peer Evaluator**: propose seam principles, not a history of seams you have not run.
- **Data-driven Prober**: say what the spreadsheet counts in your own words, and say when you do not know how a field was defined.
- **Conversational**: treat the casual questions as scored, and give your answers in the same order as the arc.

## Round 1: recruiter screen (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in financial-services customer operations." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Give the arc in about 90 seconds, in this order: six years in retail banking, the last 3 as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly spreadsheet your regional manager uses. Say each in those words, then stop. | Covers the years requirement (F1) and the complaints work (F2, F4, F8) in one pass. Tagged JD because it is the first place the 4+ years line is scored. |
| A2 | "What notice period would you need to give?" | JD | [grounded] No notice period appears in your message. This answer is yours to give. | Logistics slot: give your actual notice period, in your own words. If you are not sure, ask what start date the role assumes before you answer. | Recruiter screens check notice. The pack supplies no figure, so the only safe answer is yours. |
| A3 | "What salary are you looking for?" | JD | [grounded] No pay figure appears in your message. This answer is yours to give. | Logistics slot: give your own figure, or ask which band the role sits in before you answer. Either is sound. Pick one and say why. | Pay is a knockout check. The pack will not supply a figure or a pay history. |
| A4 | "Which hub could you work from?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (the strategy brief, as you summarised it) | Logistics slot: name the hub you could reach, in your own words. If you do not yet know where the hubs are, say so and ask which hubs the role sits in. | The hub move is in the brief, so the question is fair. The pack does not know the hub locations and says nothing about them. |
| A5 | "Why are you leaving your current role?" | EXP | [grounded] No reason for leaving appears in your message. This answer is yours to give. | Logistics slot: give your real reason, in your own words. The pack has none to supply, so do not borrow one from the job description. | Reason for leaving is a standard screen check. A borrowed reason fails the first follow-up. |
| A6 | "You've never presented to anyone above regional level. Is that going to be a problem in this role?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Say it plainly: "I've never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare for a senior audience. Do not add anything to shrink the gap. | F3 is a gap you stated. The honest answer is the plain sentence and a plan. It is a light skeptic probe here and returns harder in Round 2 (B3). |
| A7 | "What drew you to Ashgrove, given it is member-owned?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (the values, as you copied them on 17 November 2026) | Name one value and one thing from the strategy summary that you actually read, in your own words. Do not claim a reason you do not hold. | Conversational register, still scored. A motive that matches a value is a good answer if it is yours. |
| A8 | "Tell me about a complaint that was hard to explain to a member." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: pick a complaint that was hard to explain. Say what the member needed, what you said, and what happened. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled at the branch. | Complaints are the JD's core, and the question asks you to choose an instance, so the guidance supplies none. F2 and F5 carry the only quoted complaints work. |

## Round 2: Head of Member Services (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Ownership of complaints runs across branches and the contact centre. You've never worked in a contact centre. What's your answer?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" (your message) | Hold one: say it plainly, "Never worked in a contact centre." Hold two, on the follow-up: say what carries over, in those words: you handled the branch's formal complaints log. Concede on the third follow-up: you would learn the contact-centre routine before you change anything, and name the first thing you would ask the contact-centre lead. Answer slot: if any of your work reached a contact centre, say what. If none did, say so. | F6 is the gap the JD's responsibility line names, and it is the most predictable objection to you. Highest-ROI prep in this pack: rehearse two follow-ups and one concession. |
| B2 | "Tell me how the branch's formal complaints log worked in practice." | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Walk through the log as you ran it, in your own words, stage by stage. Answer slot: if the log carried regulatory rules such as timescales or escalation rights, say which and how you applied them. If it did not, say so plainly and say what you would check first. Do not add a rule the log did not carry. | F2 is a regulated-complaints requirement the material does not settle. The question asks about the log's practice, which the quote carries, and the slot asks about regulation without supplying any. |
| B3 | "You've never presented above regional level. How will you present to senior leaders in this job?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain sentence first: "I've never presented to anyone above regional level." Then a plan, said as a plan: what you would prepare, who you would rehearse with, and what you would ask for first. Hold once. The concession is that you have not done it yet. | F3 is a stated absence. The second follow-up tests whether the plan is real, so the plan must be one you would carry out. |
| B4 | "What have you done to coach supervisors on escalations?" | JD | [grounded] "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | Say what you trained: tellers, on the escalation script. Answer slot: if you coached supervisors on escalations, say how, in your own words. If you did not, say so plainly and say how you would start with branch supervisors. Do not stretch training tellers into coaching supervisors. | F8 is medium: the JD asks about supervisors, and your quote is about tellers. The premise comes from the JD, so the second branch lets it be false. |
| B5 | "Tell me about a time you delivered an unwelcome truth to someone senior." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a time you told someone senior what they did not want to hear. It needs a stake, what you said, and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled, and anything you raised from it. | A persona stem for a behavioural round. No quoted sentence carries a story about this, so the guidance is a scaffold, not a mapped story. Members First. |
| B6 | "Tell me about a time you held a problem until it was actually fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: pick a time you kept a problem with you until it was solved. Say what you held, what you did, and how you knew it was solved. If none comes to mind, say so, then describe the spreadsheet you built and what it is used for. Do not claim the spreadsheet fixed anything. | Own the Fix is the value this tests. The quote is a tool you built, not a story about a fix, so the guidance does not make it one. |
| B7 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold: pick a time you explained something and had to say it again. Say what you changed in how you explained it. If none comes to mind, say so, then give the nearest thing your material carries: the escalation script you trained tellers on, and how you taught it. | Plain Words is the value this tests. The quote is about training, not about wording, so the guidance does not claim the script was written plainly. |
| B8 | "A branch supervisor says the same complaint keeps coming in and nobody is fixing it. What are your first moves?" | CASE | [generic] | Structure it: clarify what the complaint is, how often it arrives, and who owns the fix today. Set the objective as a member getting a fix and one named owner. Then the steps: the supervisor's facts, the complaints data, and a timeline agreed with the owner. Then what you would record. Think aloud and challenge one premise. | A live problem from the supervisor-coaching requirement (F8). Generic because it is a pattern for the problem, and it asks about no past of yours. |
| B9 | "The strategy moves 40% of member service to digital channels by 2028. Which complaints move with that, and what would you do about them?" | JD | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief, as you summarised it); "work with digital teams on self-service journeys" (JD) | Structure: which complaints start in digital channels, which need a person, and who owns a complaint that crosses the two. Name the digital teams you would work with and what you would ask them first. Answer slot: if you have worked with a digital team on a self-service journey, say what you did. If not, say so plainly. | Covers the digital requirement (F9, discovery). Primary tag JD, with CO content from the brief. The answer slot asks about the practice the JD raises without supplying one. |

## Round 3: panel of two branch managers (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter, when the process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a time a process pointed one way and a member needed another. Say what you decided, why, and what happened. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled, and whether any complaint in it did not fit the process. | Members First, Always. The scaffold ends in the honest branch, because no quoted sentence carries a decision of this kind. |
| C2 | "Tell me about a time a member had to ask you twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold: pick a time a member had to ask twice. Say what you changed in how you explained it, and what they did next. If none comes to mind, say so, then give the escalation script you trained tellers on, and how you taught it. Do not claim the script was written in plain words. | Plain Words: if a member needs it explained twice, the wording was wrong. The quote is about training, so the guidance does not claim the wording was plain. |
| C3 | "Eight branches are becoming five hubs over 2027. How would you keep each town's complaints visible?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" (the strategy brief, as you summarised it); "Neighbours, Not Numbers — every branch is part of its town." (the values, as you copied them on 17 November 2026) | Structure: what changes for a member in a town that loses its branch; what to keep (how a complaint is raised, who answers it, how the answer gets back to the town); how you would test that with the branch managers. Answer slot: if you have been through a branch change or service move, say what happened to complaints. If not, say so and set out how you would protect continuity. | Neighbours, Not Numbers, set against the consolidation the panel is living with. Primary tag VAL, with CO content from the brief. The premise is the brief's own line. The guidance does not claim you have run a change. |
| C4 | "Tell me about a time you kept a problem with you until it was actually fixed." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a time you held a problem to its fix. Say what you held, what you did, and how you knew it was solved. If none comes to mind, say so plainly, then give the nearest thing your material carries: a complaint you handled through the log, and how far you took it. Do not claim the log fixed anything it did not. | Own the Fix, Always keeps hold until it is solved. The scaffold ends in the honest branch because no quoted sentence shows a fix that was held through. |
| C5 | "Scenario, as a generic case for this role: a member's payment was taken late twice, the branch has not answered, and today the member asks for the complaint to go up a level and says they will leave. You have twenty minutes. Walk us through what you do." | CASE | [generic] (a role-family scenario, not the panel's actual case) | Structure: clarify what the member needs, how long the complaint has been open, who owns it now, and what timing rules apply. Objective: the member gets a plain answer, one named owner, and a date. Steps: put the complaint with one owner today; call the member and say what happens next in plain words; ask the supervisor for the facts and coach them on the escalation route; check whether the late payment has hit other members; keep the complaint until the cause is fixed. Then record and report. Think aloud and challenge one premise. If the panel's case differs, the structure still holds. If the panel asks what you have done like this, answer with the complaints log, in your own words, and stop at what you did. | [generic], because the case is a role pattern and claims nothing about you. The structure answers the 20-minute test: clarify, then steps, then ownership. |
| C6 | "The member is calm now, but the supervisor says the same late payment will happen again next month. Sixty seconds: what do you do?" | CASE | [generic] | Hold the position in one sentence: the complaint is closed only when the cause is fixed. Hold through two follow-ups. Concede specifically where you do not know, such as who owns the payment process or how often it fails. Do not fold on the core point to restore harmony. | Pressure delivery: the panel times answers and interrupts. This tests Own the Fix under time pressure. Hold-then-concede is the structure. |
| C7 | "Branch supervisors bring escalations to you. Where's the seam between their call and yours?" | JD | [grounded] "coach branch supervisors on escalations" (JD) | Propose seam principles, not a history: who decides a complaint's outcome, who coaches the supervisor, and when a decision goes up a level. Answer slot: if you have set such a seam before, say where, in your own words. If you have not, say so and say how you would agree it with the supervisors. | Peer seam-splitting is a branch manager's first question. The principles are generic, and the slot keeps your past out of the answer. |
| C8 | "When a complaint fix runs across two branches, who gets the credit?" | VAL | [generic] | Name the people who did the work before you name yourself. Answer slot: if you have shared credit on a fix before, give one instance in your own words. If not, say so and say how you would credit the branch teams. | Peer test of partnership and credit. Generic, and the slot keeps the past honest. |
| C9 | "What does your monthly complaints spreadsheet count, and how?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what the sheet counts, in your own words, and name the assumption you would defend least. If you do not know how a field was defined, say so plainly. Answer slot: if the sheet tracked how long complaints took to close, say how it counted. If not, say so and say how you would add that measure. | Probers aim at the one artifact you have (F4), and the reporting requirement (F7) turns on what the sheet counts. The guidance names no method. |

## Values cheat sheet

Lives with Round 3, the round the recruiter's email names as the values panel. Working meanings are paraphrased from the values you copied on 17 November 2026. None of the four values is carried by a story in your quoted sentences, so each maps to a selection scaffold with its honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a story. Scaffold, C1: pick a time a process pointed one way and a member needed another. Honest branch: if none comes to mind, say so, then give the nearest thing your material carries (F2 and F5). |
| Plain Words | If a member needs it explained twice, the wording was wrong. | No quoted sentence carries a story. Scaffold, C2: pick a time a member had to ask twice. Honest branch: if none comes to mind, say so, then give the escalation script you trained tellers on (F8). |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a story. Scaffold, C3: pick a time a figure and a person disagreed about a place. Honest branch: if none comes to mind, say so, then give the spreadsheet you built and what it can and cannot show (F4). |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No quoted sentence carries a story. Scaffold, C4: pick a time you held a problem to its fix. Honest branch: if none comes to mind, say so, then give the nearest complaint you handled through the log (F5). |

## Grounding brief

Shared across rounds. You gave us a summary of the strategy brief, not the brief itself, so this section is limited to what you summarised. It is dated July 2026, under six months old.

- Digital: move 40% of member service to digital channels by 2028.
- Branches: consolidate eight branches into five hubs over 2027.
- Lending: launch a small-business lending product in Q1 2027.
- Competition: the main pressure is app-only banks.

Use the brief's own words: digital channels, hubs, member service. Do not correct the interviewer's framing if it differs from the brief. Sound current, not archival.

## Reverse questions

Round 1 (recruiter):

1. "What did the last person in this role do well, and what did they find hard?" Why it lands: it shows you are thinking about the job's real scope, and gives the recruiter something specific to answer.
2. "How is the planned move from eight branches to five hubs shaping the complaints work?" Why it lands: it ties your question to the strategy the recruiter sent, and shows you read it.

Round 2 (Head of Member Services):

3. "Where do you expect the contact-centre part of this role to be hardest in the first ninety days?" Why it lands: it pins the gap you named and asks for a plan, so the manager answers your objection for you.
4. "How will you judge this role at six months?" Why it lands: it asks for the manager's own success measures, which tests your reporting plan against their expectations.

Round 3 (panel):

5. "How do a complaint and its fix pass between the branches and the contact centre today?" Why it lands: it asks the branch managers to show you the seam, which the peer test scores.
6. Reciprocity, since the panel are peers: "What could a new person do in their first month that would genuinely help your branch?" Why it lands: it turns the interview toward what you would contribute, which the peer test rewards.

## Requirement coverage

| JD requirement | Fit row | Questions |
|---|---|---|
| 4+ years in financial-services customer operations | F1 | A1 |
| Experience handling regulated complaints | F2 | B2, A8 |
| Confident presenting to senior leaders | F3 | A6, B3 |
| Comfortable with Excel reporting | F4 | C9 |
| Own the member complaints process end to end across branches | F5 | B2, A8 |
| Own the member complaints process across the contact centre | F6 | B1 |
| Report monthly on complaint volumes and resolution times | F7 | C9 |
| Coach branch supervisors on escalations | F8 | B4, C7, B8 |
| Work with digital teams on self-service journeys | F9 | B9 |

Every hard requirement has at least one JD-tagged question. Session totals: 8 in Round 1, 9 in Round 2, 9 in Round 3, 26 in all.

## Sources

Provided documents:

- The JD, as you pasted it
- The recruiter's email on the three rounds
- The values, as you copied them from ashgrovecu.org/about/values on 17 November 2026
- The strategy brief summary you sent, July 2026, as you summarised it
- Your background message

No dossier was present. No search or fetch was run.

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values and their working meanings are fixed by the values you pasted. Feeds the values cheat sheet and C1 to C4. |
| 2. Interview process | skipped | The recruiter's email is a loop source. It fixes the three rounds, their lengths, who runs each, and the values panel. |
| 3. Strategy and recent news | skipped | The brief summary you sent is under six months old. A search would have added only a fresher sweep, which feeds A4, B9 and C3. |
| 4. Interviewer name | n/a | No names were given for Round 2 or the panel. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The monthly complaints spreadsheet, with names removed → F4 moves from medium toward high, and C9's slot has an artifact to rest on.
- Your branch's complaints rules, in your own words, if the log carried any → F2 moves from discovery to a stated limit, and B2's slot closes.
- The recruiter's case brief, if the panel shares it → C5 is replaced with the actual case, not the generic one.
- The names of the Round 2 and panel interviewers → per-interviewer persona weights and a tailored reverse question.
- The full strategy brief, not the summary → the grounding brief expands, and C3 and B9 get exact wording. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available. Want it?
- How many hours you can give before 26 November → a prep triage section, ordered by the banks.
- Your CV, if you have one → the fit rows cite it directly, and any line in it becomes material.
- A `tuesday-dossier.md` → verified evidence and rehearsal constraints carried into the next pack.
