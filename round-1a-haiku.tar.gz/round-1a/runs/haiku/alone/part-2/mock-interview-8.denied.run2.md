Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-8-denied-172d93d6/cbde1a2f-2f6a-43aa-86cc-f44000f26ad4/scratchpad/ashgrove_member-experience-lead_interview_pack.md. It covers all three rounds on 26 November: the recruiter screen, the Head of Member Services, and the branch-manager panel with the 20-minute escalation case.

Three things matter most:

- **Highest-ROI prep is H2.** The Head of Member Services is likely to press on the two gaps you stated: no contact-centre work, and nothing above regional level. The answer is to name both plainly, hold on the complaints log you actually handled, and give a 90-day plan. Don't claim experience you don't have.
- **Stated gaps first.** In H1 and P3, name the contact-centre gap yourself before anyone presses on it.
- **Escalation case (P6).** Clarify the facts before you structure a response, and make no claims about your own past in it.

I took the loop reading, since you have three scheduled rounds. I didn't run any web research: your pasted values, the recruiter's round details and the strategy summary already cover what the pack needs. The strategy points are my inferences from the summary, not verified against the full brief.

Want me to play the Head of Member Services on H2? Or I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead prep pack

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Candidate:** Dara
**Rounds:** three, on 26 November 2026 (loop mode)
**Built:** 17 November 2026
**Changelog:** first build.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** = behavioural / values alignment. **EXP** = work-experience deep-dive. **JD** = role / JD-driven. **CO** = company and strategy knowledge. **CASE** = live problem.
- Guidance is scaffolding, not a script. Rehearse the shape and your own words, not a memorised paragraph.
- Anything marked **[inferred]** is my derivation. Anything marked **[generic]** is a role pattern with no fact about Ashgrove or about you.
- Your evidence is quoted from your own message to me. Where I write "your material", I mean those quoted sentences and nothing more.

---

## 2. Fit snapshot

Requirements are quoted from the job description you sent. Evidence is quoted from your message. Nothing in this table is a claim about you that you did not state.

No requirement in the JD is a term gate (licence, location, pay, schedule). So no row is marked `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | Your sentence says retail banking and branch supervisor, not the JD's words. Keep your words: "I have six years in retail banking, the last three as branch supervisor." Limited inspectable proof, so expect a probe on whether branch work counts as customer operations. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: formal complaints. Your sentence does not say regulated, so the bridge does not either. Answer slot: if the log ran to a regulatory timetable or a referral route, say which and how you tracked it; if it did not, say so and describe how the formal log ran. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: log handling at one branch. The end-to-end, multi-branch scope is not in your sentence. Stay with the quote's scope; for the wider scope, say how you would start, as a plan. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated absence, so the words are yours: "I have never worked in a contact centre." Then how you would learn the contact-centre side, said as a plan, never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The sentence shows a monthly spreadsheet. It does not show whether volumes or resolution times were in it. Answer slot: if the spreadsheet counted volumes or resolution times, say which and how; if it counted something else, say what. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a spreadsheet a regional manager relies on. The word Excel is not in your sentence. Answer slot: name the tool it was and what you did in it, in your own words. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent work: you trained tellers, not supervisors. Bridge: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say how; if you trained only tellers, say so. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not absence. Answer slot: if you have worked with any team on a channel or self-service journey, say what it was and your part in it; if you have not, say so plainly and say what you would look at first. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your stated absence: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan. |

**Gap-type routing.** F4 and F9 are `capability` because you stated the absence. F5 and F8 are `discovery` because the material is silent. F3 and F7 are `transferability` because adjacent work is real but does not reach the requirement. F1, F2 and F6 are `presentation` because the quote already reaches the requirement in other terms.

---

## 3. Grounding brief (the strategy you sent)

This is built from the July 2026 strategy summary you pasted. I have not verified it against the full document. Use these words so you sound current; check the full brief before the interview.

- **Digital shift:** "move 40% of member service to digital channels by 2028." Vocabulary: member service, digital channels, self-service.
- **Branch consolidation:** "consolidate eight branches into five hubs over 2027." Vocabulary: hubs, consolidation.
- **Small-business lending:** "launch a small-business lending product in Q1 2027."
- **Competitive pressure:** "the main competitive pressure is app-only banks."

**[inferred]** For this role, the consolidation and the digital shift together mean complaints will move through fewer, larger hubs and more self-service routes. That is my derivation from the brief, not something the brief says. Ask about it, do not assert it.

**[inferred]** The small-business lending launch may bring complaint types that the current branch log has never handled. Treat it as a question to ask, not a fact.

---

## 4. Coverage: JD requirements to questions

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1 |
| Experience handling regulated complaints | P6, H3 |
| Own the complaints process end to end across branches and the contact centre | R7, H2, H3, P3 |
| Report monthly on complaint volumes and resolution times | H7 |
| Coach branch supervisors on escalations | P7 |
| Work with digital teams on self-service journeys | P8 |
| Confident presenting to senior leaders | H1, H2 |
| Comfortable with Excel reporting | H7 |

---

## 5. Round 1: Recruiter screen (30 minutes)

**Persona weights:** Conversational / Rapport Builder leads, with a light Skeptic. Logistics are scored here as knockouts. Prep time was not stated, so the triage section is omitted.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly biography opener; notice, pay and location as logistics | High. Recruiter screens are logistics-first, and the risk is treating them as unscored | Ninety-second arc; each logistics answer in your own figure |
| Skeptic (light) | "Why this, why now"; reason for leaving; the contact-centre gap | Medium. The reason for leaving and the contact-centre question are the likeliest probes | Say the stated gap plainly; do not bridge it |

### R-bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A ninety-second arc from F1 and F2: six years in retail banking, the last three as branch supervisor; then the formal complaints log; then the escalation script you trained tellers on; then the spreadsheet. Use those words. Add no role, size or outcome. | The biography is scored for economy. Its clauses are the pack's quoted sentences, so the arc cannot grow past them. Draws on F1, F2 and F6. |
| R2 | "What's your notice period?" | JD | [generic] no candidate sentence is used | Logistics slot: give your actual notice period, in your own figure. | Knockout check in a friendly register. The only safe answer is your own, and no figure is supplied here. |
| R3 | "What are your pay expectations?" | JD | [generic] no candidate sentence is used | Logistics slot: say your own number, or ask first what the role's band is. Do not give a salary history you have not stated. | Pay is a logistics slot. Naming your own figure and asking for the band both supply no figure of mine. |
| R4 | "Where would you be working from, and how often would you need to be on site?" | JD | [generic] no candidate sentence is used | Logistics slot: name the locations and days you can actually work, in your own words. | Location is a logistics slot. The posting states no office pattern; **[inferred]** the hub moves in the brief could change it, so ask about it in the reverse questions, not here. |
| R5 | "Why are you leaving your current role?" | EXP | [generic] no candidate sentence is used | Logistics slot: the reason for leaving, in your own words. Keep it to the reason and what you want next. Say nothing about your current branch or team. | The reason for leaving is a logistics slot. A Skeptic will test it against the career line in F1. |
| R6 | "Why this role, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Pick one reason of your own and tie it to the role's words: complaints across branches and the contact centre. The brief gives the company's direction, not your view, so do not claim an opinion on it you have not formed. Answer slot: if your reason is the digital shift, say which part of complaints work you would move onto it; if it is not, say what it is. | A CO question grounded in the strategy you sent. Motivation probes are where a Skeptic starts, so this is asked here first. |
| R7 | "This role covers the contact centre as well as branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Say the stated absence plainly: "I have never worked in a contact centre." Then the nearest thing your material carries: "I handled the branch's formal complaints log." Then how you would learn the contact-centre side, as a plan. Claim no contact-centre work in any form. | F4 is a stated absence, so the words come from your sentence. The second quote carries the nearest adjacent work. This question is the first place the objection in H2 appears. |
| R8 | "Is there anything about your background you'd like me to know that isn't in the CV?" | EXP | [generic] no candidate sentence is used | Selection scaffold: if something specific comes to mind, say it in your own words, with what you did and what you did not. If nothing does, say so plainly, and point to the complaints log you handled. | An open close. A Conversational interviewer scores whether you answer briefly and truthfully. No candidate sentence raises it, so the guidance makes no claim. |

### R-reverse questions

- **"What does a strong first 90 days look like in this role?"** Why it lands: it turns your stated gaps into a plan the interviewer can measure you against.
- **"What is the recruiter's sense of which parts of the role the team is least sure about?"** Why it lands: it shows you want to know where the risk sits before you answer about it.

---

## 6. Round 2: Head of Member Services (45 minutes, your future manager)

**Persona weights:** Skeptic leads, then Values / Behavioural. A Case question and a Data-Driven Prober question round it out. The round is mostly behavioural, so the Values questions carry weight. No interviewer profile exists, so there is no interviewer read.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Which part would you be weakest at?"; "why should we trust you with both?" | High. A manager is buying capability and derisking the gaps in F4 and F9 | Name the stated gaps first; hold only the complaints log; concede exactly |
| Values / Behavioural | "Tell me about a time…" against Members First, Own the Fix, Plain Words | High. The round is mostly behavioural | STAR shape; "we" for context, "I" for what you did |
| Data-Driven Prober | "Walk me through how that spreadsheet counted it" | Medium. The manager relies on the spreadsheet in F6 | Say what it counted and what you would defend least; say "I don't know" where true |
| Case / Strategist | A live member problem | Low to medium. Included because the manager owns the escalation work | Clarify before structuring; think aloud |

### H-bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name the contact-centre gap in your words: "I have never worked in a contact centre." Name the senior-presenting gap the same way: "I've never presented to anyone above regional level." Then one first step for each, said as a plan. Concede both; hold neither. | F4 and F9 are the stated gaps. Naming them first costs less than being pressed on them. |
| H2 | "You haven't worked in a contact centre, and you haven't presented above regional level. Why should we hand you both?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level"; "I handled the branch's formal complaints log" | **The highest-ROI prep in this pack.** Hold through two follow-ups, holding only what the quotes carry: the formal complaints log you handled at one branch, and the escalation script you trained tellers on. Follow-up one: say the two gaps plainly, then say how you would close them in the first 90 days, as a plan. Follow-up two: concede exactly, "I haven't worked in a contact centre, and I haven't presented above regional level." Never fold on the log, and never describe contact-centre or senior-presenting experience as if you had it. | This objection is the most predictable one for this candidate. F3, F4 and F9 are the sources. The question presupposes both stated negatives, which the quotes carry. |
| H3 | "Your complaints work was one branch's log. What would you change about how it runs across branches and a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log" | Stay with the log you ran. Describe what you would check first across the other branches, as a plan, not as something you did. Answer slot: if you changed anything in the log that crossed your branch, say what and your part; if nothing crossed branches, say so plainly. | F3 is `transferability`. The JD's scope ("across branches") is the premise, and the second branch lets it be false. |
| H4 | "Tell me about a time you put a member ahead of the process." | VAL | [grounded] "trained new tellers on our escalation script" | Members First. Pick a case where the script and the member's interest pulled apart. If none comes to mind, say so plainly, then give the nearest thing your material carries: how you trained tellers to use the escalation script for a member. Say what you did and who decided. | Mapped to F7, the nearest story. Scaffold, because no quoted sentence carries a member-over-process decision. |
| H5 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. Name one complaint you held from log to close: what stayed open, what you did at each point, and how you knew it was solved. If you handed one on before it closed, say so and why. | The story sits in F3's quote at the log's scope. Name only what you did at the log. |
| H6 | "Tell me about a time a member didn't understand a decision. What did you do?" | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. Describe one time you explained something a second time and what changed in how you said it. If no such time comes to mind, say so plainly, then give how you trained tellers to explain the escalation script. | No quoted sentence carries a plain-words story. Scaffold, with the honest branch. |
| H7 | "Walk me through how the monthly spreadsheet counted what it counted." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name what the sheet counted and the column you would defend least. If you cannot say how a figure was counted, say so: "I don't know how that figure was counted" is an honest answer. Answer slot: if the sheet counted volumes or resolution times, say which and how; if it did not, say what it counted. Name the tool. | The prober's question on the reporting requirement. F5 and F6. |
| H8 | "A member complains publicly about how a branch decision was handled. What do you do first?" | CASE | [generic] | Clarify first: which decision, what the complaint file records, what any regulatory timetable requires, and who must be told. Structure aloud and state one assumption. Make no claim about your own past. | A live problem drawn from the JD's end-to-end ownership. It presupposes nothing about you. |

### H-reverse questions

- **"What does a strong first 90 days look like for this role?"** Why it lands: it converts the stated gaps into a plan the manager can check.
- **"How do escalations from branches reach the contact centre today?"** Why it lands: it shows you have found the seam you would own.
- **"When eight branches become five hubs, where does complaint ownership move?"** Why it lands: it shows you read the strategy you were sent. The question asks the manager's view; it asserts none.
- **"How does the team measure a complaint that is resolved but the member is still unhappy?"** Why it lands: it links Members First and Own the Fix to a measure.

---

## 7. Round 3: Panel of two branch managers (60 minutes, incl. a 20-minute case)

**Persona weights:** Values / Behavioural leads, because the panel scores against the four values. Pressure and the escalation Case follow. The branch managers are not named, so there is no interviewer read.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scored stories against the four values | High. Your recruiter says the panel scores against them | Map one story per value; say what was yours |
| Pressure | "Why should we trust…?"; "how much of that was you?" | High. Two managers can run a challenge in turns | Pause; hold the complaints log; concede exactly |
| Case / Strategist | The 20-minute complaint escalation | Certain. The recruiter says it is in the round | Clarify, structure, think aloud |
| Peer (reciprocity) | "What would you need from us?" | Medium. Branch managers are peers to this role | Ask what would help their branches |

### P-bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time a member's side of a case changed what you did in the log." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First. Pick a moment the member's view changed a step in the log. If nothing changed, say so plainly, then say what you did with the member's view. | Scaffold. No quoted sentence carries a member-led decision. |
| P2 | "Every branch is part of its town. What would you protect for members in that town if a branch closed?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027"; "move 40% of member service to digital channels by 2028" | Neighbours, Not Numbers, against the consolidation. Name the principle, then what you would check for a member in that town: where they would go, and how their complaint would still reach the team. Answer slot: if you have been part of a branch closure, say what you did for members; if not, say so and say what you would check first. | The premise is the brief's own sentence, so the question may presuppose the consolidation. A values answer that runs straight into the strategy. |
| P3 | "Sixty seconds: why should we trust someone who has never worked in a contact centre to run complaints across one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Pressure question. Hold the one position the quotes carry: the formal complaints log you handled, and the process you would bring. Hold through two follow-ups, then concede exactly: "I have never worked in a contact centre." Do not add contact-centre experience you have not had. | F4 is a stated absence. The hold sits at the log's own scope. |
| P4 | "That complaints log: how much of the outcome was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Name which steps you ran yourself and which the team ran; say what you did not control. Answer slot: if any decision in the log was yours to make, say which and how; if none was, say so and describe your role. | Attribution under pressure. F3 at its own scope. |
| P5 | "Tell me about a time a complaint came back after you thought it was closed." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix. If one reopened, say what you missed and what you changed. If none did, say so plainly, then give the nearest case you held from log to close, in your own words. | An open prompt. The log is the only quoted source, so the theme stays inside it. |
| P6 | "A member has escalated a fee complaint to you twice. Your branch says it was handled. Walk us through what you would do." | CASE | [generic] | The 20-minute escalation case. Clarify: what the file records, what the first handling said, what the member was told, and what any timetable requires. Name the escalation route and who owns the decision. Structure: who holds the case, what evidence you need, what the member must hear, and the supervisor's part. Think aloud and challenge one premise. Make no claim about your own past. | Covers the JD's regulated-complaints and escalation requirements as a live problem. Presupposes nothing about you. |
| P7 | "A branch supervisor's escalation notes are weak. How would you coach them without taking the case off them?" | JD | [grounded] "trained new tellers on our escalation script" | Name the difference: you trained tellers on a script, and coaching a supervisor is a different job. Say what you would do first: sit in on one escalation with them and say what you would check. Answer slot: if you have coached a supervisor on an escalation, say how; if you trained only tellers, say so. | F7 is `transferability`. Coaching supervisors is the JD's own wording, and the second branch lets it be false. |
| P8 | "Members are moving to the app. What would you change in a complaint journey for a member who never comes into a branch?" | JD | [grounded] "move 40% of member service to digital channels by 2028" | Describe the journey from the member's side first, then one change you would test. Answer slot: if you have worked with a digital team on a self-service journey, say what and your part; if you have not, say so plainly and say what you would look at first. | F8 is `discovery`. The brief's digital target is the raising source. |

### P-reverse questions

- **"What do your branch managers find hardest about escalations today?"** Why it lands: it shows you have thought about the coaching part of the role.
- **"How will complaint data flow from branches to the hubs?"** Why it lands: it is the place the strategy and the role meet.
- **"What could a new lead do in their first month that would genuinely help your branches?"** Why it lands: it is the reciprocity question for peers. It tells the panel you are asking what they need, not only what you need.
- **"When a member's view and a branch target pull apart, which does the panel decide from?"** Why it lands: it tests Members First directly, and the answer tells you what the panel values.
- **"Which of the four values is hardest to keep when a branch is consolidated?"** Why it lands: it names the tension in the strategy and lets the panel say where they feel it.

---

## 8. Values / principles cheat sheet

Shared across the loop. The values are scored by the panel. Working meanings are my paraphrase.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F7, the nearest story: "trained new tellers on our escalation script." Scaffold: H4 and P1. If no decision of yours carries a member-first story, say so and give the nearest one. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F7: "trained new tellers on our escalation script." Scaffold: H6. If no time comes to mind, say so plainly. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a story. Selection scaffold: P2. If you have not been part of a branch closure, say so and say what you would check first. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F3: "I handled the branch's formal complaints log." Mapped story: H5. |

---

## 9. Prohibited list

Claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| "Has worked in a contact centre" | Stated negative: "Never worked in a contact centre" | "I have never worked in a contact centre." No slot. |
| "Has presented to senior leaders" | Stated negative: "I've never presented to anyone above regional level" | "I've never presented to anyone above regional level." No slot. |
| "Owned the complaints process end to end across branches" | Inflated form of F3 | The quote at its own scope: "I handled the branch's formal complaints log." Analysis, not words for you: your material says one branch's log, not the process end to end. |
| "Ran regulated complaints" | Inflated form of F2 | The quote at its own scope: "I handled the branch's formal complaints log." Analysis: your material says formal complaints; it does not say regulated. |
| "Reported on resolution times" | Inflated form of F5 | The quote at its own scope. Analysis: your material says a monthly spreadsheet, not what it counted. |
| "Coached branch supervisors on escalations" | Inflated form of F7 | "trained new tellers on our escalation script," at its own scope. |

---

## 10. Sources

- **Provided documents:** the job description you sent; your background message; the Ashgrove values, copied by you on 17 November 2026; the recruiter's email on the three rounds; the July 2026 strategy summary you pasted.
- **Research tier:** L1. Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | The values you pasted fix the values cheat sheet. A search would have moved nothing. |
| 2. Interview process | skipped | The recruiter's email fixes the loop structure, so the persona weights follow the three named rounds. |
| 3. Strategy / recent news | skipped | The strategy summary you pasted fixes the grounding brief. |
| 4. Interviewer name | n/a | No names were given; panel members and the Head of Member Services are not yet named. |
| 5. Representative JD | skipped | The job description you sent fixes the fit snapshot and the JD-tagged questions. |

- **Method note:** no searches or fetches were run. The pack is built from your inputs only.

---

## 11. Upgrade menu

- The interviewers' names → persona weights from their public footprint, and a reverse question tied to their career path.
- Your CV or résumé → replaces "your message" with the CV's wording; tightens F1, F5 and F6 from presentation or discovery toward grounded.
- A description of the complaints spreadsheet (its columns, or what it counted) → turns F5 from discovery into a grounded answer, and removes the answer slot in H7.
- Any contact-centre, digital or self-service work, even informal → fills the answer slots in F8 and P8.
- The full strategy document, rather than the summary you pasted → the grounding brief moves from your summary to the text.
- Deep research (L2), offered once: the company's strategy talks, its published interview reports for this role family. Caps: six further searches and two further fetches. Costs time, and returns only what is public.
- A `tuesday-dossier.md`, if you have one → would add a verified evidence map and sharpen the highest-ROI rehearsal in H2.
