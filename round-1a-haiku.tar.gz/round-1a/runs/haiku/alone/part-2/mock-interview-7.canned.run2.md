Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-alone-part-2-rooms-case-7-canned-635d29af/5abe0a77-a647-4015-bf1c-6e7692e615f0/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`.

Two findings from the company's own site shape the whole pack. Their interviewing page describes the 60-minute hiring-manager round as the Outage Hour: a live-incident tabletop on a simulated outage during a live event, then a values conversation. And a September 2026 news post says both titles move to one shared events calendar from February 2027. The pack is built around both.

The highest-return prep is B1: "You have run one title's calendar. This role owns two calendars and the post-event review with its KPIs. Which part of that have you owned?" It is the objection your material is thinnest on, so rehearse it until the honest answer is plain.

I can play the Skeptic on B1 if you want to drill it. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would sharpen it:
1. Is Tobias Wrenfield your future manager, and is this the Outage Hour? I've assumed yes.
2. Can you paste your CV? It would replace several of the slots with your own wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games, Live Operations Producer: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (see the upgrade menu). Round: 60-minute interview, most likely the Outage Hour (see Reading the interviewer).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **CASE**: a live problem from the role, scored on structure and reasoning.
- **EXP**: a question about your past work, scored on whether the claims survive scrutiny.
- **JD**: a question about a stated responsibility in the posting.
- **CO**: company knowledge, such as current strategy and recent moves.
- **VAL**: behaviour tested against the company's published values.

The guidance is scaffolding, not a script. Where a bracketed label appears, it marks provenance. Where the material does not support a story, the pack gives you a slot to fill in your own words, not a line to say.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title's weekly content drops over two years. It does not show live events across two titles. Say the calendar in your own words as you ran it. Answer slot: if you have planned across more than one title or event stream, say how; if not, say so plainly and say how you would sequence two calendars. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across those four teams, and the pack does not claim it. Answer slot: if you coordinated any of these teams on a release, name which and what you were responsible for; if you did not, say so plainly and say how you would set up that coordination for a live event. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting retention numbers is not owning a post-event review, and the bridge should not stretch to it. Answer slot: if you chose which KPIs a review reported, say which and why; if you presented numbers someone else set, say so and say what you presented. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement. Limited inspectable proof: expect a probe on how QA uses it and what it has changed. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years is the length you have. The material shows a puzzle title with weekly content drops, not the producer role at the level the posting describes. Say the years and the kind of title in those words. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the calendar was built and changed. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: you presented retention figures to the head of the studio. The bridge only rewords it. Expect a probe on how the figures were counted (see D1). |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is a written artifact other teams use, so the quote reaches the requirement in other terms. The bridge only rewords it: "I wrote the release checklist our QA team still uses." Expect a request for a sample. |
| F9 | Not a JD line. Your own list of gaps: people leadership | "Never led a team." (your message) | none | [grounded] | capability | A stated absence, so no answer slot. Words for the candidate: "I haven't led a team." Then how you would learn it, said as a plan and never as a past. |
| F10 | Not a JD line. Your own list of gaps: in-app purchase experience | "Never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A stated absence, so no answer slot. Words for the candidate: "I haven't worked on a game with in-app purchases." Then the nearest thing you have done, in your own words. |

Gate check: the JD states no legal, credential or term-based gate. Nothing is marked hard_gate.

What the snapshot shows, row by row: F1, F3 and F5 are where the posting asks for more than your material shows. F2 is silence, not a negative. F4, F6 and F8 are the strongest rows. F9 and F10 are negatives you stated, so they are plain acknowledgments, not slots.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I led a team" or "I managed people" | F9, a negative you stated | "I haven't led a team." No slot. |
| "I have worked on in-app purchase monetization" | F10, a negative you stated | "I haven't worked on a game with in-app purchases." No slot. |
| "I ran the live-events calendar across two titles" | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The material says one title, not two. |
| "I owned the post-event review and its KPIs" | Inflated form of F3 | The pack's observation: your material shows presenting retention numbers, not owning a post-event review. |
| "I managed the release checklist with QA" | Inflated form of F4 | "Wrote the release checklist our QA team still uses." The material says the writing and current use, not management. |

## Reading the interviewer

Public footprint only.

- **Career pattern.** A GDC 2026 talk page describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio.
- **Stated argument.** The talk's stated argument is "a live team is judged by how often its patch notes describe what actually shipped." That is his own framing from the talk listing.
- **Round format.** The company's interviewing page describes every loop as "a recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." Your 60-minute slot matches that format.

Practical implications:

1. Expect a live-incident scenario first. Rehearse the first fifteen minutes of an outage, not a general framework.
2. Expect accuracy probes. His talk's argument is about announced versus shipped, so the checklist (F4) and the retention figures (F7) are where he will press.
3. The release checklist is your strongest bridge. His QA background means the checklist quote (F4 and F8) will land with him.
4. No shared jump exists between his path and yours. The QA adjacency is a professional mirror, not a shared career move.

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case/Strategist | A live outage tabletop during a live event | 5. The company's interviewing page names the tabletop as the first half of this round. | Clarify, then contain, then communicate, then decide. Think aloud. | A1 to A5 |
| Skeptic | Probing the gaps in F1, F3, F9 and F10 | 4. Hiring-manager prior, plus the JD requirements your material does not reach. | Rehearse the single most predictable objection (B1) until it is plain. Concede precisely. | B1 to B4 |
| Values/Behavioral | The values conversation after the tabletop | 3. The second half of the round, per the company's page. | Map a story to each published value where a quote carries one. Otherwise use the selection scaffold and its honest branch. | C1 to C3 |
| Data-Driven Prober | Follow-ups on how figures were counted and what changed | 3. His talk's accuracy theme points toward probes on announced versus shipped. | Name the weakest assumption before he does. Say plainly when you do not know how a figure was counted. | D1 to D3 |
| Pressure | Interrupting, time-boxing, questioning motive | 2. A lower prior for a hiring-manager round, kept for composure. | Pause, restate, hold through two follow-ups, then concede the specific uncertainty. | E1 to E2 |
| Conversational | Opening and closing small talk | 2. The round opens with a friendly start, and casual questions are still scored. | A 90-second arc, grounded in your quoted sentences only. | F1 to F2 |

Weights total 19 questions. Session total is within the 18 to 26 guideline.

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Players report that rewards for an event are missing for about one in five accounts, 40 minutes after the event opened. Walk me through your first 15 minutes." | CASE | [grounded] company interviewing page: "a live-incident tabletop on a simulated outage during a live event" | Clarify first: which title, what share of players, what changed in the last hour, whether a release shipped. Then decide containment, who to tell and in what order (engineering on call, QA, community), what you tell players and when, and the one step you would not take without engineering. Speakable in 90 to 120 seconds. | The Outage Hour's stated format. The scenario is generic, so the guidance makes no claim about your past. |
| A2 | "Your calendar drops a major event at 18:00, and a balance patch ships the same hour. Which do you hold, and what do you tell each team?" | CASE | [grounded] company values page: "when the calendar and the players disagree, the players win." | Decide on player impact, not the calendar. Name design, engineering and community, and what each needs to hear. State the hold condition and who can lift it. | The calendar-versus-players tension is the role's core, and the published value supplies the premise. |
| A3 | "How would you run one calendar for two titles that share a season pass?" | CASE | [grounded] company news: "one shared events calendar from February 2027" ; [grounded] your message: "I ran the weekly content-drop calendar for our main title for the last two years" | Start with what is shared and what is separate: player base, currency, events. Name one owner for cross-title conflicts. Say what you would need from each title's design lead. Describe the calendar you ran as the starting point, at its own scope. Answer slot: if you have planned across more than one stream, say how; if not, say so plainly and sequence two calendars from your one. | F1 is the only calendar evidence. The company's February 2027 change is the premise. |
| A4 | "Tell me about a calendar change you made because a drop performed a particular way." | EXP | [grounded] JD: "own the post-event review and the KPIs it reports" ; [grounded] your message: "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F1: the weekly drop cadence the quote states, told in your words. Answer slot: if a drop's result led to a change in the calendar, say which and what the result was; if none did, say so plainly and say how you would decide what to change after a drop. | An open prompt, themed on the JD's post-event review. F6 and F1 carry the only calendar evidence. |
| A5 | "Retention fell three points week on week in one title. What do you check before you call it an event problem?" | JD | [grounded] JD: "comfortable with player-retention metrics" ; [grounded] your message: "Presented the monthly retention numbers to the studio head." | Name what you would check first: the cohort mix, any change shipped in the window, any calendar overlap. Name the assumption you would defend least in that read. Do not claim a past analysis of this kind. | F7 is the closest evidence. The question is a live problem, so it asks no more of your history. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have run one title's calendar. This role owns two calendars and the post-event review with its KPIs. Which part of that have you owned?" | JD | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" ; "own the post-event review and the KPIs it reports" ; your message: "I ran the weekly content-drop calendar for our main title for the last two years" ; "Presented the monthly retention numbers to the studio head." | Hold the calendar: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you set the cadence, the content of each drop, or what a review reported, say which and how you decided; if none of that was yours, say so plainly, then say what you presented to the studio head and what happened to it. Hold through two follow-ups by returning to the calendar, never by adding to it. | The highest-return rehearsal in this pack. F1 and F3 are the largest gaps, so this objection is the likeliest. The deepest rehearsal goes here. |
| B2 | "How do you get design and engineering to move a date for you when they don't report to you?" | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" ; your message: "Never led a team." | Answer slot: if you have moved a team's dates without line authority, say how and what happened; if you have not, say so plainly and describe how you would get the move. If he asks directly about leading people, use the F9 acknowledgment: "I haven't led a team." | F2 is silence, so this is a discovery slot. The leadership line is a stated absence, so only the plain acknowledgment is allowed. |
| B3 | "Season passes are a paid model. Which parts of paid-content planning have you worked on?" | CO | [grounded] company news: "moves Tidepool Tactics and Lantern Row to a season-pass model" ; your message: "Never worked on a game with in-app purchases." | Say the stated absence first: "I haven't worked on a game with in-app purchases." Then the nearest thing you have done, which is the weekly content-drop cadence, described at its own scope. Do not describe monetization work you did not do. | The company's season-pass news raises the monetization topic, and F10 is a stated absence. |
| B4 | "Project Larkspur retires per-title event teams for a single live-ops group. What does that change for the role you'd be in?" | CO | [grounded] company news: "retires per-title event teams in favour of a single live-ops group" ; your message: "I ran the weekly content-drop calendar for our main title for the last two years" | Name two things you would keep per title and one you would merge, and say why. Draw on the calendar you ran as the thing a single group must keep. Use the company's own term, "single live-ops group." | A CO question from the September 2026 news. It tests whether you read the change and think at the company's altitude. |

### C. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] company values page: "when the calendar and the players disagree, the players win." ; your message: "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a drop where players' reaction or results moved a date or a piece of content. Answer slot: if no such moment comes to mind, say so plainly, then give the nearest thing your material carries: the weekly cadence you ran. | Players Before Plans is the published value, and F1 is the nearest quoted sentence. The quote carries no disagreement, so this is a slot. |
| C2 | "Tell me about a time what was announced and what shipped did not match. What did you do?" | VAL | [grounded] company values page: "we announce what is built, not what is hoped." ; your message: "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the checklist and QA still uses it. Answer slot: if a mismatch led you to change the checklist or the announcement, say what changed; if none did, say so plainly and say how you would keep announcements matched to builds. | Ship the Patch Not the Promise, with the checklist as the mechanism. The mismatch story is not in your material. |
| C3 | "What have you left in better shape for the next team than you found it?" | VAL | [grounded] company values page: "every release leaves the codebase and the checklist better than it found them." ; your message: "Wrote the release checklist our QA team still uses." | Say what is still in use: the checklist, which QA uses today. Do not claim it improved after you wrote it. Answer slot: if you changed it after writing it, say what changed and why. | Leave the Build Greener. The quote supports persistence, not improvement. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] your message: "Presented the monthly retention numbers to the studio head." | Say how the figure was counted, in your own words. Name the assumption behind the figure you would defend least. If you did not know how it was counted, say so plainly. | F7 is the evidence, and the question is a defend-the-number slot. |
| D2 | "Walk me through the release checklist you wrote. What is on it, and who uses each item?" | JD | [grounded] your message: "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it, and QA uses it today. Answer slot: if you changed an item after an incident or a release, say which and why; if you did not, say so plainly and say how you would check which items QA uses. | F4 and F8 are the release checklist evidence. Expect this probe, since his background is QA. |
| D3 | "A post-event KPI report says retention rose four percent. What would you check before you repeat that to the studio?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" ; your message: "Presented the monthly retention numbers to the studio head." | Name the window, the cohort, and the counterfactual: what would have happened without the event. Name the assumption you would defend least. Answer slot: if you have checked a post-event figure before presenting it, say how; if not, say so plainly and describe the checks you would run. | The JD's review and KPI requirement, asked as a decision. F3 and F7 are the evidence. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we trust a producer who has run one title's calendar to run two?" | JD | [grounded] your message: "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on the calendar you ran: one title, weekly, two years. Hold through two follow-ups. Answer slot: if you have planned across titles, say how; if not, say so plainly and concede that part in your own words. | F1 is the evidence. The concession must be one you can stand behind. |
| E2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] your message: "Presented the monthly retention numbers to the studio head." | Hold the position the quote carries: you presented the numbers. Answer slot: say which part of the figure you set, produced, or only presented. If you only presented it, say so and hold that. | F7 is the evidence. The honest branch is the one that holds. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] your message: "4 years as an associate producer at a puzzle-game studio" | A 90-second arc built only from F5, F1, F4 and F7: the puzzle studio, the associate producer role, the weekly content-drop calendar, the release checklist, the monthly retention presentations. No detail beyond those sentences. | Casual openers are still scored. |
| F2 | "What live-service game have you been playing lately, and what does its calendar do well?" | CO | [generic] | Name a live-service title you have played and one thing its calendar does well, in your own words. If you have not played one recently, say so and name one you know. Do not invent a play history. | A light check of whether you follow the category. No claim about your past. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, B1, E1 |
| "coordinate design, art, engineering and community teams on each update" | A2, B2 |
| "own the post-event review and the KPIs it reports" | A4, B1, D3 |
| "manage the release checklist with QA" | C2, C3, D2 |
| "3+ years producing live-service games or apps" | F1, B1 |
| "experience running a content calendar" | A4, B1 |
| "comfortable with player-retention metrics" | A5, D1, E2 |
| "clear written communication" | none, and why: the round is a live tabletop and a conversation, so written work is not scored here. A checklist sample is the only artifact (upgrade menu). |
| Not a JD line: people leadership (your gap) | B2, plus the F9 acknowledgment |
| Not a JD line: in-app purchases (your gap) | B3, plus the F10 acknowledgment |

## Values / principles cheat sheet

The company's interviewing page describes this round as ending in "a values conversation," so this section applies. The three published values come from the company's values page.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win. | F1 is the nearest quoted sentence: "I ran the weekly content-drop calendar for our main title for the last two years." It carries no disagreement, so use the selection scaffold in C1 and its honest branch. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F4: "Wrote the release checklist our QA team still uses." It carries the mechanism, not a mismatch story. Use C2's selection scaffold. |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them. | F4 again: the checklist is still in use. It does not show an improvement, so say persistence, and use C3's honest branch. |

## Reverse questions

Each one has a reason it lands.

1. "Your GDC talk argues that a live team is judged by how often its patch notes describe what actually shipped. What is the last patch note that didn't match, and what changed afterwards?" Why it lands: it shows you read his talk, and it invites the story that matters most to him.
2. "Project Larkspur moves both titles to one calendar from February 2027. Which decisions are already made, and which will this role make?" Why it lands: it shows you read the news and separates what is settled from what is open.
3. "Which KPI in the post-event review does the team trust least, and why?" Why it lands: it signals that you expect honest measurement, not a polished dashboard.
4. "What went out late in the last quarter, and which release step would have caught it?" Why it lands: it ties the checklist to a real failure, and shows you think about the release process as a system.
5. "What would a strong first 90 days look like for the person in this role?" Why it lands: a standard question that gets the scorecard, without a lecture on your side.
6. "How is the Outage Hour scored, and what do you look for in the values conversation?" Why it lands: it shows you understand the round's format and asks directly for the bar.

## Sources

Provided documents: your message (background and gap list), and the job description pasted in it.

Searches (5 of 6 used) and fetches (2 of 2 used):

1. "Saltmarsh Games mobile studio". No results.
2. "Saltmarsh Games values". Returned saltmarshgames.com/values.
3. "Tobias Wrenfield Head of Live Operations". Returned the GDC 2026 talk page, talks.gdconf.example/2026/patch-notes-are-a-promise.
4. "Saltmarsh Games interview process live operations producer". Returned saltmarshgames.com/careers/interviewing. Read from the search snippet only, since the fetch budget was spent.
5. "Saltmarsh Games live operations recent news". Returned saltmarshgames.com/news/project-larkspur.

Fetches: saltmarshgames.com/values (read in full). talks.gdconf.example/2026/patch-notes-are-a-promise (read; it gave the talk's abstract and his role only).

No dossier was consumed.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet, the C bank, and the company-sourced provenance in C1 to C3 |
| 2. Saltmarsh Games interview process | yes | Round format (Outage Hour), persona weights, and the A bank |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur, questions A3, B3, B4, and reverse question 2 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read, persona weights, and reverse question 1 |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |
| Un-numbered: "Saltmarsh Games mobile studio" | yes | No results, so nothing was moved |

## Upgrade menu

- Your CV → specific lines for F2, F3 and F5, which would replace the slots in those rows with your own wording.
- Confirmed round and relationship → persona weights confirmed or reweighted, and the interviewer read checked against your future manager.
- A redacted copy of the release checklist, if you can share one → F4 and F8 move from medium to high confidence, since the checklist is an inspectable artifact.
- The monthly retention figures, and how each was counted → D1 and E2 get your own sentences in place of slots.
- Interviewing page, opened in full → the round's exact structure and scoring, replacing the snippet read in Sources.
- Deep research (L2, offered once): about six further searches and two fetches, covering the strategy brief, the interviewer's talks and writing, role-family loop reports, and recent organisational context. It would cost one more round of searching and no change to your prep.
- A recruiter prep email → confirmation of any pre-declared deliverable. The company page says there is no take-home.
