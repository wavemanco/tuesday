Your prep pack is saved as saltmarsh_live-operations-producer_interview_pack.md in the scratchpad. I built it for a hiring-manager round, since your note didn't say who you're meeting. I ran no web searches, so it draws only on your message and the JD you pasted.

The biggest prep item is A2: the in-app purchase gap sits right on the KPI ownership the JD asks for. Rehearse the plain acknowledgment ("I haven't worked on a game with in-app purchases") followed by a plan. Don't describe any purchase-side work you haven't done. The pack's prohibited-claims section lists the stretched versions to avoid, such as "owned the KPIs" and "led a team."

Say the word and I'll play the Skeptic on A2, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or is this a panel or a peer round? Also, do you want me to run the web searches now (Saltmarsh's values, its live-ops interview loop, and Tobias's public footprint)? Either answer would reweight the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi (they/them)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed.
**Format:** 60-minute interview, Friday.
**Research tier:** L0. No searches were run for this pack, so everything here comes from your message and the JD you pasted.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse out loud, in your own words.
- Every "answer slot" is an instruction for the interview. Answer whichever branch is true for you, and say plainly when the practice was not yours.

## Prep triage (sized to the 60-minute interview)

Do these in order. Everything else is insurance.

1. **A2**, the highest-ROI prep in this pack. The no-in-app-purchase gap sits right on the KPI ownership the JD asks for. Rehearse it until the plain acknowledgment and the plan sound natural.
2. **A3**, the no-team-lead gap, which the JD's coordination line will raise.
3. **A1** and **A4**, the day-one weakness question and the two-title calendar.
4. **B1** and **B4**, the planning case and the post-event review.
5. **C1** and **C2**, how you knew a drop worked and what your retention numbers meant.
6. **E2** and **E3**, your arc and the three-sentence written check.

### Suggested pacing for the 60 minutes

- 0 to 5 min: introduction and arc (E2).
- 5 to 25 min: the case and the two-title calendar (B1, A4, B4).
- 25 to 40 min: the gaps (A2, A3, A5).
- 40 to 50 min: metrics and the checklist (C1 to C4, B3).
- 50 to 55 min: the written check (E3).
- 55 to 60 min: your reverse questions (from the section below).

This is a plan, not a script. The interviewer may reorder it.

### Gap-handling strategy

For each gap: state it in one plain sentence from your own words, then say what you would do first, as a plan. Never describe a past you did not have.

## The fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Bridge: "I spent four years as an associate producer at a puzzle-game studio." Your material does not say the role was a producer role, or that the titles were live-service in the JD's sense. Answer slot: say what live meant on your titles, in your own words; if the associate role was not producing, say so plainly and describe the role you did hold. |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Bridge: "For two years I ran the weekly content-drop calendar for our main title." That is one title's content drops, not live events across two titles. Answer slot: if you planned events on a second title, say which and how; if not, say so and say how you would take on the second. |
| F3 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | No gap. Lead with that sentence in your own words. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with design, art, engineering or community. Answer slot: if you coordinated any of those teams on an update, say which and what you needed from each; if updates went through someone else, say so plainly and say how you would coordinate them. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Bridge: "I wrote the release checklist our QA team still uses." Your material shows the checklist, not how each release was run against it. |
| F6 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | transferability | Bridge: "I presented the monthly retention numbers to the studio head." Your material shows presenting, not owning the review or choosing the KPIs. Answer slot: if you chose which KPIs a report carried or ran a review after an event, say which and how; if not, say so plainly and say what you would review first after an event. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Bridge: "For the studio head, I presented the monthly retention numbers." This rewords only that quote. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Bridge: "I wrote the release checklist our QA team still uses." It shows written output in use, not clarity itself. The written check in E3 tests that live. |
| F9 | In-app purchase monetization. Not in the JD; [generic], inferred from the KPI ownership and the two live titles. | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan, as a plan: which purchase-side KPI you would ask for first in your first month. |
| F10 | Leading people you coordinate. Not in the JD, which says coordinate; [generic]. | "Never led a team" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't led a team." Then how you would coordinate four teams without managing them, as a plan. |

**Reading the table.** Confidence grades your evidence. Provenance grades what this pack wrote about it. F9 and F10 are gaps you stated yourself, so they are words you can say as they stand.

## Prohibited claims

These are not to be coached, in any answer, under any phrasing. The honest form is shown beside each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F2 | "I ran the weekly content-drop calendar for our main title for the last two years." Your material says one title's content calendar, not events across two titles. |
| Owned the post-event review and the KPIs | Inflated form of F6 | "I presented the monthly retention numbers to the studio head." Your material says presenting. |
| Coordinated design, art, engineering and community on updates | Inflated form of F3 | Use F4's answer slot: say what you actually coordinated, or say it was not yours. |
| Leads or led a team | Negative you stated (F10) | "I haven't led a team." No slot. |
| Worked on in-app purchase monetization | Negative you stated (F9) | "I haven't worked on a game with in-app purchases." No slot. |
| Wrote the checklist and runs it with QA on every release | Inflated form of F5 | "I wrote the release checklist our QA team still uses." |

## Interviewer read

Public profile: not read. No search was run, so the only input is the name. Persona weights below assume a hiring-manager relationship with no adjustments.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Day-one weakness; the no-IAP and no-lead gaps | 5. Hiring-manager prior. A Head of Live Ops checks gaps like these first. | Plain acknowledgment, then the plan. Hold a position through two follow-ups. |
| Case/Strategist | A two-title calendar; a late update; a cut decision | 5. Hiring-manager prior. Expect a live problem on the real roadmap. | Clarify first, then structure. Name one premise you would challenge. |
| Data-Driven Prober | Retention definitions; how you knew a drop worked; the checklist | 4. The JD names KPIs and retention, so a Head of Live Ops is likely to read the numbers closely. | Name the weakest assumption before they do. Say "I don't know" where it is true. |
| Pressure | The "why you, with no leadership" motive question | 2. Possible in a 60-minute loop, not the default. | Pause, restate, hold the calendar and checklist, then concede specifically. |
| Conversational | The opener and the written check | 2 to 3. Opener and written-clarity check. | Rehearse the arc aloud. Treat casual questions as scored. |

## Question banks

Depth follows weight: Skeptic 5, Case 5, Prober 4, Pressure 2, Conversational 3.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Start with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then name the part of the job the puzzle work did not cover, in your own words, and what you would do first. If you need a second part, the release checklist is the part your material shows most. | F9 is the most direct route to this question. It is scored on honest self-assessment. |
| A2 | "This role owns the KPIs for two live titles. Which of those KPIs would you check first, and what would you need to learn before you trusted them?" | JD | [grounded] "never worked on a game with in-app purchases" (your message); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | The highest-ROI rehearsal in this pack. Start with the plain acknowledgment, then name the KPI you would check first and the data you would ask for behind it. Hold through two follow-ups by returning to that data: "I'd want the purchase data first, because I haven't worked with it." Concede specifically if pushed: "I don't yet know how purchases change retention on these titles. I would learn it from the first month's data." Do not claim you have tracked any purchase KPI. | F9 meets the JD's KPI ownership in the place the JD presses hardest. This is the most predictable objection to you for this role, so it gets the deepest rehearsal: a third follow-up, if it comes, asks what you would do if the purchase data contradicted the retention read. Answer that as a plan. |
| A3 | "You've never led a team, and this role coordinates four of them on every update. What would you do differently when no one reports to you?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Start with: "I haven't led a team." Then describe how you would coordinate without line authority, as a plan. Answer slot: if in the calendar work you got a team to act on a date without managing it, say which team and how; if you did not, say so plainly and say what you would do first with each team. Hold through two follow-ups by returning to the plan. | F10 and F4 meet in this question. The JD's coordination line is what raises it. |
| A4 | "The role plans live events for two titles. Which parts of your content-drop calendar would carry over to two titles, and which wouldn't?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name the parts that carry over and the parts that don't, in your own words. Answer slot: if you set any part of the calendar's cadence or priorities, say which; if you did not, say so and say what you would check across the two titles first. | F2 and F3. The question covers the two-title requirement with your own calendar as the base. |
| A5 | "Tell me about a time a retention number went against what the team expected." | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | An open prompt. Story map: you presented the monthly numbers to the studio head; the beats are the number and what was said in the room. Answer slot: if one month came in off-plan, say what the number was and what you did with it; if none did, say so plainly and describe how you would present an off-plan number. | F7 and the JD's "comfortable with player-retention metrics". |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan the live-events calendar for two titles for next quarter. What do you need to know first?" | CASE | [generic] | Clarify before you structure: each title's goal, what the teams can take in one quarter, which events are already committed, and what the quarter will be judged on. Then objective, segments, approach, metrics and risks, in that order. Name one premise you would challenge. | JD line: "Plan and run the live-events calendar for two of our mobile titles." A live problem, so no claim about your past. |
| B2 | "An event's day-three retention is down against plan. Walk me through the diagnosis." | CASE | [generic] | Clarify what "plan" means and which cohort is affected, and what else shipped in the same window. Then split the causes into event-driven (content, rewards, timing) and other (release, outage, cohort mix). Name the assumption you would check first. | JD line: "own the post-event review." Scored on structure and on what you ask first. |
| B3 | "An update's art is late and engineering says the build is ready. What do you ship, and what does QA need from you?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Name the decision: ship with cut content, slip, or split. Then the checklist: what QA needs to sign off and who decides. You may name the checklist as the tool, at the scope of your quote, and say how you would use it on this release. Answer slot: if you have made a call like this, say what happened, in your own words; if not, say so and say what you would ask QA for first. | JD line: "manage the release checklist with QA". F5 and F8. |
| B4 | "After an event, how would you decide whether it was worth running again?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the goal you would set before the event, the retention window you would read, and what you would not conclude from a single event. Answer slot: if you have run a post-event review, say what you measured and how; if not, say so and say what you would put in one. | JD line: "own the post-event review and the KPIs it reports". F6. |
| B5 | "The two titles compete for the same design and art time next month. How do you choose which events to cut?" | CASE | [generic] | Clarify each title's goal and the time each event needs. Rank by goal impact against cost. Name the one stakeholder you would talk to before anything is cut. | JD line: "coordinate design, art, engineering and community teams on each update". A live problem, so no claim about your past. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you know a content drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | An open prompt. Say what you looked at after a drop and where the read came from, in your own words. Answer slot: if you measured drops one at a time, say the metric and the window; if the monthly numbers were the only read, say so plainly and say that is what you used. Name the assumption behind the read you would defend least, before it is asked. | F2 and F6. A prober's first question on any content calendar. |
| C2 | "How did your monthly retention numbers define retention?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | The question presupposes a definition exists. Answer slot: if you chose the definition, say which, and name the assumption you would defend least; if it was set for you, say so, and say what you would check about it. | F7. A prober asks for the definition behind any retention figure. |
| C3 | "How would you know a live event improved retention, rather than just coinciding with it?" | JD | [generic] | Clarify the comparison you would need: the same cohort before and after, or a holdout group. Say what you would need to trust the read. Describe these as what you would check, not as methods you have used. | JD line: "comfortable with player-retention metrics". A pattern, not a fact about your past. |
| C4 | "If you rewrote the release checklist today, what would you change?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Name one step you would change and why, in your own words. Answer slot: if you would change none, say so and say why. | F5 and F8. The checklist is your strongest quote and the prober's likely object. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team for this seat?" | EXP | [grounded] "Never led a team" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Pause and restate the question. Hold: "I haven't led a team. What I've run is the calendar." Hold the calendar and the checklist through two follow-ups. Then concede specifically: "I'd rather learn leading from the first two quarters than claim it now." | F10. Hold a position your quotes carry. Concede the gap, never the calendar. |
| D2 | "That retention presentation: how much of the result was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: you presented the numbers. Answer slot: say what you produced and what you only presented. Hold through two follow-ups. Concede exactly what you did not build. | F6 and F7. An attribution probe. |

### E. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Your CV says four years as an associate producer. How does that line up with the three years this role asks for?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Say the years and the title in your own words. Then the live part, only as you ran it. Answer slot: if the producing was live, say which; if the associate role was not producing, say so plainly and say what it was. | JD line: "3+ years producing live-service games or apps". F1. |
| E2 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message) | A 90-second arc: where you started, the four years, the content calendar, the checklist, the retention presentation, and why live operations. Each beat is a sentence above, in your own words. Do not add titles or events. | The arc is the first scored answer. Casual openers are still scored. |
| E3 | "In three sentences, tell me what a release checklist is for, to someone in community who has never seen one." | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Three sentences: what it protects, who signs off, and what it stops. Say it aloud twice before Friday. | JD line: "clear written communication", tested live in spoken form. F8. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4 (JD), B1 (CASE), B5 (CASE) |
| Coordinate design, art, engineering and community teams on each update | A3 (JD), B5 (CASE); F4 answer slot |
| Own the post-event review and the KPIs it reports | A2 (JD), B4 (JD), C1 (EXP) |
| Manage the release checklist with QA | B3 (CASE), C4 (EXP) |
| 3+ years producing live-service games or apps | E1 (JD) |
| Experience running a content calendar | A4 (JD), E2 (EXP) |
| Comfortable with player-retention metrics | A5 (JD), C2 (EXP), C3 (JD) |
| Clear written communication | E3 (JD) |
| Not in the JD: in-app purchase monetization (gap F9) | A1, A2 |
| Not in the JD: leading people you coordinate (gap F10) | A3, D1 |

## Values / principles cheat sheet

None. No values-style round was detected, and no company values were provided.

## Grounding brief

None. Research did not run, so the pack has no current strategy or recent news for the company.

## Graded deliverables

None declared.

## Reverse questions

Each one has a reason it lands.

1. "What does a good live event look like here, and what does a weak one look like?" Why it lands: it asks for the bar in outcomes, and shows you think in results.
2. "Which of the two titles is harder to plan for right now, and why?" Why it lands: it shows you are already thinking about both titles, and surfaces the hard part of the calendar.
3. "After a post-event review, how do the findings get back to design and art, and who decides what changes?" Why it lands: the JD's KPI ownership depends on this seam. It tests where your ownership would actually stop.
4. "How are monetization decisions made during a live update, and who is in the room?" Why it lands: it turns your no-IAP gap into a question about their process, and it lets you learn the answer in the interview.
5. "What did the last person in this seat get wrong in their first 90 days?" Why it lands: it gives an honest picture of the role and signals humility.
6. "When an update slips, how does QA sign-off work and who makes the call?" Why it lands: it shows you care about the checklist you wrote and how the release decision is actually made.

## Sources

- **Provided:** your message (background, gaps and format) and the JD text you pasted.
- **Searches:** none run.

**Research tier: L0, searches 0 of 0, fetches 0 of 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Whether section "Values / principles cheat sheet" applies. No search was run in this pack. |
| 2. Saltmarsh interview process, live ops | unavailable | Loop structure and persona weights, currently assumed. |
| 3. Saltmarsh strategy and recent news | unavailable | The grounding brief, and the CO question the pack lacks. |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | The interviewer read, and a reverse question tied to Tobias's own path. |
| 5. Representative Live Ops Producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's public footprint (talks, roles, posts) → persona weights from their profile, and a reverse question tied to their own path
- Saltmarsh's values page pasted or fetched → a values cheat sheet with a story for each value
- Recent Saltmarsh news or live-ops strategy → a company-strategy question and a grounding brief
- Round details: whether this is a panel or a first round, and any recruiter note on focus areas or a take-home → persona weights re-tuned to the round
- Any live-service or purchase-side work outside the puzzle title, in your words → F9 can move from a stated gap to a bridge
- Whether your four years as an associate producer count as the "3+ years producing" requirement → F1 confirmed or reframed
- A `tuesday-dossier.md` from a prior session → verified evidence to replace the quotes in the fit snapshot
