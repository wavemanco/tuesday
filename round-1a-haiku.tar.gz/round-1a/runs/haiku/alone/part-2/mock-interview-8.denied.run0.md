Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/haiku/alone/part-2/rooms/case-8-denied-274f60df/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a loop, one mini-pack per round, since your recruiter's email names all three.

The three things to work on, in order:

1. **The objection you will get is the gap, not the spreadsheet.** You've run one branch's formal complaints log and never worked in a contact centre, and the JD asks for end-to-end ownership across both. Question B2 is the highest-value rehearsal: hold the log, then concede the contact-centre gap in one plain sentence and give your plan for closing it.
2. **Plain acknowledgments for the two stated gaps.** "I've never worked in a contact centre" and "I haven't presented to anyone above regional level." Say them early and briefly. Panels punish the gap more when they find it themselves.
3. **None of the four values has a story your material carries.** Each has a selection scaffold with an honest branch in section 6. Prepare one real decision for each, and if one didn't happen, say so rather than stretching the log.

Other things I found:
- **The branch consolidation is a real trap for round 3.** "Neighbours, Not Numbers" sits against eight branches becoming five hubs, and two branch managers will be on the panel. Before the 26th, check which of the eight are in the consolidation, and don't describe any branch as safe or closing.
- **Pay, notice, location and reason for leaving** each get a logistics slot in round 1. You supply those answers yourself. The pack gives you no figures.
- **Research:** none ran. Your pasted values, the recruiter's email and your summary of the strategy brief covered every target. The figures in section 3 come from your summary, so check them against the brief itself.

Is the role based in one of the eight current branches or one of the five hubs? The answer changes the location answer in A9 and the reverse questions.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. Say the word to do a rehearsal as the skeptical Head of Member Services on B2. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

**Role:** Member Experience Lead, Ashgrove Credit Union
**Interviewers:** not yet assigned. Personas are set by round relationship, per the recruiter's email.
**Dates:** three rounds on 26 November 2026 (nine days from 17 November).
**Mode:** loop. One shared fit snapshot, a mini-pack per round, shared sources and upgrade menu.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioural and values; EXP = your own past work; JD = a requirement from the job description; CO = company and strategy; CASE = a live problem. Logistics questions are tagged JD or EXP.
- **Guidance is scaffolding, not a script.** Each guidance cell is about 90 to 120 seconds spoken.
- **Answer slots** are instructions for the interview, not questions for this conversation. Answer from your own experience. Where something was not yours or did not happen, say so plainly.

---

## 2. Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Confidence grades your evidence. Provenance grades what this pack wrote about it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your material gives the years and the setting: six years in retail banking, the last three as a branch supervisor. It says retail banking, not customer operations, so use that phrase and let the panel make the match. Nothing inspectable backs it, so expect the years to be checked. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your material says formal complaints, not regulated ones. Words: "I handled the branch's formal complaints log." Answer slot: if the log was run to regulatory timescales, say which and how you met them. If it was not, say so, and say how you tracked a complaint from receipt to outcome. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't presented to anyone above regional level." Then how you would build the skill, as a plan and never as a past. No claim to senior presentation work. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Lead with it in its own words: you built the spreadsheet, and your regional manager uses it. Expect a probe on how deep your Excel goes. The material shows the artefact, not the formulas. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The spreadsheet touches the reporting requirement. Your material does not show whether it held volumes or times. Answer slot: say what the spreadsheet recorded, in your own words. If it recorded neither, say so, and say what you would report first. Derivation: the spreadsheet line is the only evidence, and it does not show these fields. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" (JD), branch part | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's log. Words at its own scope: "I handled the branch's formal complaints log." The process across branches is not in your material. Answer slot: which stages of the process were yours to set, and how you decided them. If none were, say so and stay with the log. |
| F7 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I've never worked in a contact centre." Then how you would learn a contact centre's complaint routes, as a plan and never as a past. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | low | [inferred] | transferability | The quote is about training tellers, not coaching supervisors. Derivation: the training line is adjacent, and nothing shows you coached a supervisor. Words at its own scope: "I trained new tellers on our escalation script." Answer slot: if you coached other supervisors on an escalation, say how. If you did not, say so, and say how you would start. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not a stated absence. The material does not show whether you have worked with a digital team. Answer slot: if you have, say what the journey was and what your part was. If not, say so, and say how you would start with a digital team. The strategy context is in section 3. |

**Gate check:** the JD states no gate. It names no location, licence, schedule or credential term. "4+ years" is a length-of-experience requirement, not a gate. The hub consolidation may make location a term; question A9 covers it.

---

## 3. Grounding brief: the company

From your summary of Ashgrove's July 2026 strategy brief. I have not seen the brief itself, so check the figures against it before the interview.

- **Digital:** "move 40% of member service to digital channels by 2028"
- **Branches:** "consolidate eight branches into five hubs over 2027"
- **Lending:** "launch a small-business lending product in Q1 2027"
- **Competition:** the main pressure is app-only banks.

**Vocabulary to use:** member service, digital channels, hubs, member-owned.

**The tension to expect:** the values say "Neighbours, Not Numbers: every branch is part of its town." The strategy consolidates eight branches into five hubs. A panel of branch managers may test this directly. Before round 3, check which of the eight branches are in the consolidation. Do not talk about any branch as if it were safe or as if it were closing.

---

## 4. Persona table

Weighting uses the recruiter's words. The email names three rounds, who runs each, and what each assesses. That establishes the loop. It also documents a values round, so the values cheat sheet applies.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1. Recruiter screen, 30 min | Conversational (dominant) | Friendly arc, logistics, motivation check | High. The recruiter's email names logistics and motivation. Casual questions are still scored. | A 90-second arc for "walk me through it". Treat logistics as scored. Give the one gap plainly. |
| 1. Recruiter screen | Skeptic (light) | Quiet check on the contact-centre gap and why you are leaving | Medium. The gap is visible on your background. | Say the gap in one sentence, then the plan. |
| 2. Head of Member Services, 45 min, behavioural | Skeptic (dominant) | Probes gaps and presenting, and checks whether the story holds | High. They will be your manager, so they test fit directly. | Rehearse the one predictable objection (B2) until it is steady. Concede specifically. |
| 2. Head of Member Services | Values / Behavioral | STAR-shaped stories against the values | High. The recruiter calls the round "mostly behavioural". | Use the scaffolds in section 6. Say when a story is not yours. |
| 2. Head of Member Services | Case / Strategist (low) | One question on the digital shift | Low-medium. One strategy question in the round. | Clarify, then structure, then name the risk. |
| 3. Panel of two branch managers, 60 min | Values / Behavioral (dominant) | Each member scores the four values | High. The recruiter says the panel scores against all four values. | Work through the cheat sheet, one value at a time. |
| 3. Panel | Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter names it. | Clarify the facts first. Structure before answering. |
| 3. Panel | Pressure (moderate) | Challenges on attribution and on the contact-centre gap | Moderate. This is a generic stress pattern, not a read of these people. | Hold the position through two follow-ups. Then concede what you cannot back. |
| 3. Panel | Peer Evaluator | Seams between branches and the contact centre | Medium. Two branch managers will weigh what the hire does to their work. | Offer seam principles, not claims about their routing. Bring the reciprocity point. |

---

## 5. Question banks (loop mode)

Depth follows persona weight: the top persona gets 4 to 5 questions, mid-weight personas 3, low-weight personas 2. Each round is 8 to 12 questions.

### Round 1: Recruiter screen, 30 minutes

**Weights:** Conversational 4 (A1 to A4), Skeptic 2 (A5 and A6), logistics 4 (A7 to A10).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through how you got here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; [grounded] "I handled the branch's formal complaints log" | The beats your sentences state, in your own words: six years in retail banking, the last three as a branch supervisor, and the formal complaints log. Stop there and let the next question come. If a specific moment changed your direction, name it in your own words. | F1 and F2 are the arc. Casual openers are scored, and this one sets the register for the rest of the screen. |
| A2 | "Why Ashgrove, and why this role now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Name one thing in the strategy that you find interesting, in your own words, and tie it to the complaints remit. Do not claim knowledge beyond the summary in section 3. | The digital target is the recruiter's own strategy brief, so a generic answer will land badly. |
| A3 | "What would you want to know about our complaints process in your first week?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" | Ask about the current volumes, where complaints come in, and how a complaint moves from branch to contact centre. Asking well is the answer here. | The question tests whether you think at the role's altitude. It makes no claim about your past. |
| A4 | "What are you playing with in digital channels at the moment?" | JD | [grounded] "work with digital teams on self-service journeys" | Answer slot: if you have used a self-service journey as a customer, name it and say what made it easy or hard. If you have not looked at any, say so, and say what you would look at first. | F9 is silence in your material. The honest answer is what you have actually used. |
| A5 | "What's the honest gap between your background and this job?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then how you would close it, as a plan. Keep it to one sentence, then stop. | F7 is the stated absence. Naming it first is calibrated candour, and it costs less here than under a panel's probe. |
| A6 | "How would you present a complaints trend to a senior leader?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: what you would present and how you would prepare. | F3 is the stated absence, and the recruiter's screen is where it is found. |
| A7 | "What are you looking for in pay?" | JD | none given | Logistics slot: give your own number, or ask what the band is before you name one. The pack supplies no figure. | Pay is a logistics item the recruiter screens for. |
| A8 | "What's your notice period?" | JD | none given | Logistics slot: give your actual notice period. | A fact only you can supply. |
| A9 | "Where would you be based, and could you work from a hub?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" | Logistics slot: say where you can work and what would change it. Do not assume which hub or branch the role sits in. | The hub move makes location a real term, so the answer matters. Your location is yours to give. |
| A10 | "Why are you looking to move now?" | EXP | none given | Logistics slot: give your reason in your own words, true and short. Do not criticise your employer. | A fact only you can supply. |

### Round 2: Head of Member Services, 45 minutes (future manager, mostly behavioural)

**Weights:** Skeptic 4 (B2, B7, B8, B9), Values / Behavioral 3 (B1, B4, B5), EXP 1 (B3), Case / Strategist 1 (B6).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put a member ahead of a process rule." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: pick a time you decided from the member's side of the counter, where the member's view changed the outcome. Say what the member wanted, what you decided, and your part. If none comes to mind, say so plainly, then give the nearest thing the log carries. | Members First, Always is the value. None of your sentences carries a member-side decision, so this is a scaffold. |
| B2 | "Your experience is one branch and no contact centre. Why should we trust you across both?" | JD | [grounded] "I handled the branch's formal complaints log"; [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Hold the log and the spreadsheet as what they are: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to the log, not by adding to it. Then concede the gap in words: "I've never worked in a contact centre." Then the plan for closing it. Never say you know how a contact centre works. | F6 and F7 are the gap this question will test, and it will come in some form. The hold is only what the quotes carry. The concession is the plain acknowledgment. |
| B3 | "What did the spreadsheet show, and what was done with it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot on F5: say what the spreadsheet recorded, in your own words. If it held volumes or times, say which. If not, say so. Then say what you can and cannot say about how the figures were counted. Name the weakest assumption you know of before they do. | F5 is the reporting gap. The question is a defend-the-number slot in its honest form: you say what you know. |
| B4 | "Tell me about a time you explained a process that someone had to hear twice." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Selection scaffold: pick a time you explained a route or a rule to someone who needed it more than once. Answer slot: if you changed how the script was explained, say what you changed and why. If you did not, say so, and say how you would test whether it reads plainly. | Plain Words is the value. Your sentence states training on the script, and nothing about plain wording, so the wording part is a slot. |
| B5 | "Tell me about a complaint you kept hold of until it was fixed." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: pick a complaint you kept hold of, with the log as its record. If the log passed it on at any point, say so and to whom. If you did not keep one through to a fix, say so, then give the nearest thing the log carries. | Own the Fix is the value. The log carries "handled", not "held to a fix", so the scaffold must not supply the ending. |
| B6 | "Forty percent of member service is moving to digital by 2028. What would you change first in the complaints process?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" | Clarify first: which complaints move digital, and which stay on the phone or at the counter. Then the objective, the segments, the approach, the measures, and the risk. Name the risk of a complaint that cannot be moved to digital. Use their vocabulary. No claim about your past. | The digital target is the strategy in the recruiter's own brief. The case is a live problem, so it asks about no past. |
| B7 | "Experience handling regulated complaints: what does a regulated complaint need that an ordinary one doesn't?" | JD | none given | Answer slot on F2: say what regulatory requirements applied to the complaints you handled, if any. If you handled complaints to regulatory timescales, say which. If the log was not run that way, say so, and say what you would check first. | The JD raises the requirement. Your material says "formal", not "regulated", so the slot stays inside that. |
| B8 | "How would you coach a branch supervisor on an escalation they handled badly?" | JD | [grounded] "trained new tellers on our escalation script"; [grounded] "the last 3 as a branch supervisor" | Answer slot on F8: if you coached a colleague on an escalation, say how. If you did not, say so, and say what you would look at first in their handling. Use your three years as a supervisor as the frame. | F8 is adjacent. You trained tellers; you have not been shown to have coached supervisors. |
| B9 | "What would your first presentation to this leadership team look like?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: what you would present, to whom, and who you would rehearse with first. | F3 is the stated absence. The question asks for a plan, and a plan is what you can honestly offer. |

### Round 3: Panel of two branch managers, 60 minutes (values, 20-minute case)

**Weights:** Values / Behavioral 4 (C1 to C4), Case / Strategist 2 (C5, C6), Pressure 2 (C7, C8), Peer Evaluator 2 (C9, C10).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you decide something from the member's side of the counter?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: pick a decision where the member's view changed the outcome. Say the member's view, your decision, and your part. If none comes, say so plainly, then give the nearest thing the log carries. | Members First, Always. Section 6 gives the branch. |
| C2 | "Explain a complaint outcome to a member who needed it twice. How did you do it?" | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. Selection scaffold: pick a time a process was explained to someone who needed it twice, and what you did about the wording. If you changed the wording, say what and why. If you did not, say so, and say how you would test it. | Plain Words. Your sentence carries training, not plain wording, so the wording beat is a slot. |
| C3 | "Tell me about a complaint where the branch's place in its town mattered." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt. Selection scaffold: pick a complaint where you treated the member as a neighbour, not a row. If the numbers reached a person, say how. If the spreadsheet only held rows, say so, and say what you would do differently. | Neighbours, Not Numbers. The spreadsheet is numbers, so the story is a slot. Never say it held member stories it did not hold. |
| C4 | "Tell me about a problem you found that was not yours to fix. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Selection scaffold: pick a problem you found and kept hold of until it was fixed. If you passed it on, say to whom and why. If you did not keep one to a fix, say so, then give the nearest thing the log carries. | Own the Fix. The scaffold does not supply an ending the log does not show. |
| C5 | Case: "A member's complaint has been escalated to you. Two branches have each said no. Walk us through your first hour." | CASE | [generic] (the recruiter's "20-minute case on a complaint escalation" is the raising source) | Clarify first: what the complaint is, what each branch said, what the member wants, and whether a regulatory deadline applies. Then structure: stop the loop, own the case, contact the member, decide, record, and find the root cause. Say what you would check before you decide. No claim about your past. | This is the 20-minute case the recruiter named. It asks for structure and reasoning, not facts about you. |
| C6 | Case follow-up: "The member's complaint is now in the contact centre, and the agent says it's the branch's fault. What do you do?" | CASE | [grounded] "Never worked in a contact centre" | Propose a seam principle: the member owns one fix, whatever the seam. Say what you would ask the contact centre, and how you would learn their routing. If asked how the contact centre works, say plainly you have not worked in one. | The follow-up tests the seam, and your gap is the contact centre. Say the gap plainly; do not pretend. |
| C7 | "That spreadsheet: how much of its result was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold through two follow-ups: "I built the monthly complaints spreadsheet, and my regional manager uses it." Concede what you cannot back, specifically: how the regional manager uses it, or how the figures were counted if you do not know. Never fold the core claim. | Pressure on attribution. The hold is only the sentence you wrote; the concession is the part you cannot back. |
| C8 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; [grounded] "Never worked in a contact centre" | Pressure. Hold: "six years in retail banking, the last three as a branch supervisor, and the formal complaints log." Concede plainly: "I haven't run a contact centre, and that is the gap. Here is how I would close it." | The stem is a pressure stem. Hold the years and the log; concede the gap specifically. |
| C9 | "Our branches and the contact centre sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" | Peer probe. Propose seam principles, not a map you have not seen. Answer slot: pick a time you disagreed with a peer and kept the working relationship. If none comes, say so, and say how you would approach it. | The JD raises the branch-to-contact-centre seam. Peer Evaluator probes seams. |
| C10 | "How do you handle credit when work spans teams?" | JD | none given | Open prompt. Name the principle you would use, then the practice you would follow. Make the reciprocity point: what you bring to their teams, not just what you need. | The stem is a Peer Evaluator pattern. It needs no claim about your past. |

### Requirement coverage

| JD requirement | Question IDs | Coverage |
|---|---|---|
| 4+ years in financial-services customer operations | A1, C8 | Covered |
| experience handling regulated complaints | B7 | Covered (F2) |
| confident presenting to senior leaders | A6, B9 | Covered (F3) |
| comfortable with Excel reporting | B3, C7 | Covered (F4) |
| Own the member complaints process end to end across branches and the contact centre | A3, B2, C6, C9 | Covered (F6, F7) |
| report monthly on complaint volumes and resolution times | B3 | Covered (F5). Upgrade menu asks for the spreadsheet's fields |
| coach branch supervisors on escalations | B8 | Covered (F8) |
| work with digital teams on self-service journeys | A4 | Covered (F9) |
| Strategy: SME lending launch in Q1 2027 | none, and why | Not in the JD, so no question. Reverse question R6 raises the app-only competition instead |

---

## 6. Values cheat sheet (round 3)

The recruiter's email names the panel as the values round, scored against all four values. None of the four values has a story that your quoted sentences carry, so each gets a selection scaffold and its honest branch.

| Value | Working meaning, paraphrased | Mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold. Your material carries the log, not a member-side decision. Honest branch: if none comes, say so, and give the nearest thing the log carries. | C1, B1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold. Your material carries training on the escalation script, not plain wording. Honest branch: if you did not change the wording, say so, and say how you would test it. | C2, B4 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold. Your material carries a spreadsheet, which is numbers. Honest branch: if the numbers never reached a person, say so. | C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold. Your material carries handling the log, not a fix held to the end. Honest branch: if you did not keep one to a fix, say so, then give the nearest thing the log carries. | C4, B5 |

---

## 7. Reverse questions

Each has a reason it lands. No interviewer profile exists yet, so none is tied to a career path. Add names through the upgrade menu.

| # | Question | Ask | Why it lands |
|---|---|---|---|
| R1 | "What happens after the three rounds, and who decides?" | Round 1 (recruiter) | It shows you think about the process, and the answer tells you how the panel's scores are used. |
| R2 | "What would a good first 90 days look like, and what would the complaints process do differently by the end of 2027?" | Round 2 (Head of Member Services) | It ties the question to the hub timetable from the strategy and asks for the outcome, not the activity. |
| R3 | "How will the move to five hubs change where complaints are handled?" | Round 2 | It shows you read the strategy and see the complaint consequences of the hub move. |
| R4 | "How will you measure the 40% digital target for member service, and what happens to members who cannot or will not move?" | Round 2 | It joins the strategy's target with the values. It asks how Neighbours, Not Numbers is kept in the shift. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Round 3 (peer reciprocity) | The rubric's reciprocity question. It turns the panel's scoring into a working conversation. |
| R6 | "Against app-only banks, what does Ashgrove offer a complaining member that an app cannot?" | Round 1 or Round 2 | It takes the competitive pressure from the brief seriously and asks about the member's side. |

---

## 8. Prohibited claims

Claims this pack will not coach, because the material does not carry them. No answer, hold, bridge or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F6. The JD says "Own ... end to end across branches and the contact centre". Your material says "I handled the branch's formal complaints log". | The F6 quote at its own scope. The limit is this pack's observation: your material says one branch's log, not the process across branches. |
| Has worked in a contact centre, or run contact-centre complaints | Stated negative, F7 | Plain acknowledgment: "I've never worked in a contact centre." No slot. |
| Has presented to senior leaders | Stated negative, F3 | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot. |
| Coached branch supervisors on escalations | Inflated form of F8. Your material says you trained tellers on a script. | The F8 quote at its own scope: "I trained new tellers on our escalation script." |
| Reported monthly volumes and resolution times | Inflated form of F5. Your material says you built the spreadsheet, not what it measured. | The F5 quote at its own scope. A4 and B3 slots ask what was recorded, in your own words. |
| Handled regulated complaints under regulatory timescales | Inflated form of F2. Your material says "formal complaints", not regulated ones. | The F2 quote at its own scope. This pack's observation: your material says formal, not regulated. |
| Owned the regional complaints reporting | Inflated form of F4. The quote says you built a spreadsheet the regional manager uses. | The F4 quote at its own scope. |
| Wrote the escalation script | Inflated form of "trained new tellers on our escalation script". The script is "our", not yours. | The quote at its own scope: you trained tellers on it. |

**Note:** no prohibited-list entry covers digital self-service work. F9 is silence in your material, not a claim, so it has an answer slot instead (A4).

---

## 9. Sources

**Provided documents** (all from your message):
- Your background: 6 years in retail banking, the last 3 as a branch supervisor; formal complaints log; training on the escalation script; the monthly spreadsheet; no contact-centre work; no presenting above regional level.
- The JD text you pasted.
- Ashgrove's values, as you copied them from ashgrovecu.org/about/values on 17 November 2026.
- The recruiter's email: three rounds, 26 November, their format and what each assesses.
- Your summary of the July 2026 strategy brief. I have not seen the brief itself.

**Searches and fetches:** none run. Your inputs answered every research target.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted fix the values cheat sheet (section 6). |
| 2. Interview process | skipped | The recruiter's email establishes the three rounds, who runs each and what each assesses. |
| 3. Strategy and recent news | skipped | Your summary of the July 2026 brief fixes the current priorities (section 3). The brief itself is not in hand. |
| 4. Interviewer name and company | n/a | No interviewer has been named, so there was no query to form. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Targets 6 to 9 (deep research) were not run, and the offer is in the upgrade menu.

---

## 10. Upgrade menu

- **The panel's names** → personas per member in round 3, and reverse questions tied to each person's path.
- **The strategy brief itself** → check the 40%, the eight-to-five hubs and the Q1 2027 lending launch against the source, and ground section 3 in the text.
- **The spreadsheet's column headers, or one figure from it** → defend-the-number slots become real (B3, C7), and F5 moves from [inferred] to [grounded].
- **Your CV text** → the background rows (F1 to F8) can be quoted from it, not from your message.
- **The recruiter's prep email, if it names deliverables or sends the case brief** → coverage for anything pre-declared.
- **A deeper research pass (L2):** up to 6 more searches and 2 more fetches, several more minutes. It would cover the strategy brief, the leadership, and recent reorganisations. Want it?
