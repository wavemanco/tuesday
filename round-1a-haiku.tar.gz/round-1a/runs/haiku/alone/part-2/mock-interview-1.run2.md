Your prep pack is saved as `/var/tmp/tuesday-measure/1a/runs/haiku/alone/part-2/rooms/case-1-denied-fda51dbe/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`.

I built it as a peer round, since you said Dan is Priya's peer, with no declared deliverable, and on the highlights and background you sent. I did no web research, so the company and interviewer material comes from your note and Dan's profile.

The pack's most important prep is question D1: "Your background is product strategy and operations. Where have you owned go-to-market for a product line?" The JD's headline requirement meets a CV that doesn't show GTM ownership, so expect this in some form.

Say the word and I'll play the Skeptic on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Did Dan or the recruiter say what the 60 minutes covers, such as focus areas or anything to prepare as a deliverable?
2. Can you paste the full JD? The six requirements in the pack come from your highlights.
3. Has Priya herself said anything about quota-setting or sales-ops work, in her own words? That would turn the gap in F7 into a stated absence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Northwind Data · Senior GTM Strategy Lead, Emerging Products

**Mock-interview pack for Priya** · single 60-minute conversation · interviewer: Dan Kovac, Director of Sales Strategy · relationship: **peer** (you both report to the same VP)
Research tier: L0, provided material only (see Sources). Built 2026-11-17.

---

## 2. How to use this pack

- **Personas** describe *how* a question arrives: its tone, pace and stance. **Types** describe *what* is being scored. Each question carries one type tag, listed first.
- **Guidance is scaffolding, not a script.** Speak it in your own words. Every claim about your past is one of your own sentences, quoted in the Provenance column, or it is an answer slot: an instruction to answer from your own experience, with both branches honest.
- **Labels.** `[grounded]` traces to what you sent me or to the research note you gave. `[inferred]` is derived from that material, with the derivation named. `[generic]` is a role-family pattern with no claim about Northwind or Dan.

| Tag | Type | What it scores |
|---|---|---|
| **VAL** | Behavioral / values | Whether past behavior shows the behavior the question names |
| **EXP** | Experience deep-dive | Whether your claims survive scrutiny, and what you actually did |
| **JD** | Role / JD-driven | Whether you can do the listed job, including its gaps |
| **CO** | Company and strategy | Whether you think at the company's altitude, using its current priorities |
| **CASE** | Live problem | Structure and reasoning on a problem from the role |

---

## 4. Fit snapshot

The requirements are the highlights from your note, not the full JD (see the upgrade menu). The evidence is quoted from the background you sent; its source is named in each cell.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | Your notes say you proposed a change, not that you ran go-to-market for a product line. Say it at the quote's scope: "proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if you made a go-to-market call on a launch (channel, pricing or rollout), say which and how you decided; if you didn't, say so plainly and stay with the proposal. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | The material shows no whitespace work, so the words are an answer slot: if you identified whitespace across land, adopt, expand or renew, name the stage, what you found and how you sized it; if you haven't, say so plainly and say how you would find it first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | discovery | "Skilled" names the tools, not the level, and the bridge should not be stretched. Say the tools only: "I work in SQL and Tableau." Answer slot: if you ran an analysis end to end in either tool, name the question, the data and the call it changed; if none comes to mind, say so plainly and say what you would check first. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Bridge at the quote's scope: "built a partner-level revenue model used in carrier negotiations." The pack's observation: the material shows a partner revenue model, not partner-motion design. Answer slot: if you designed any part of how partners were paid, onboarded or measured, say which and how; if not, say the model was the part you built. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote already reaches cross-functional influence in other terms. Reword only: "set annual volume targets with cross-org consensus." Expect a probe on how the consensus was reached; the quote carries no more than that. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Bridge at the quote's scope: "uses AI tools daily." Limit: that is usage, not building or shipping AI products. Answer slot: if AI changed a piece of your work, name it; if none did, say so and say where you would start. |
| F7 | [generic] sales-strategy role: quota and target-setting (role-family; not in your JD highlights) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | discovery | Your notes record no classic sales-ops or quota-setting experience. That is the coach's record, not Priya's own words, so the pack writes no first-person line for it. The nearest thing the material carries is the target line in F5, which the pack notes as its observation only. Answer slot: if a target you set was worked to by a sales team, say what it was and how you set it; if none was, say so plainly and say what you would learn first. |

**Gap-type notes.** F1, F4 and F6 are transferability because each quote is real work that does not reach the requirement at its full scope. F5 is presentation because its quote already reaches the requirement in other terms. F7 is discovery and not capability: a stated absence would be capability, and only Priya's own sentence can supply one. Confidence is medium for F1, F4 and F5 because nothing was inspected, and low for F3 and F6 because the evidence is a self-description or a usage line.

---

## 7. Reading the interviewer

Public footprint only, as you described it to me. I did not search for Dan's talks or writing.

- **Career pattern:** a pricing and monetization spine, with one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven."
- **Implications for you:**
  1. Every number you give will be taken to its denominator. A1 to A5 are the core of the pack.
  2. Case angles will tilt toward pricing and unit economics, which is his native language (C2).
  3. A startup chapter means builder stories land well, and big-company pace will draw a scrappiness probe (D3).
  4. As a peer, he is pricing what a hire adds to his load. Reciprocity matters (B2, and the reverse questions).
- **Mirror opportunity, a shared domain and not a shared identity:** his monetization thread meets F4, "built a partner-level revenue model used in carrier negotiations." Use it to open the peer conversation on pricing. Its limit is F4's: a revenue model, not partner-motion design.
- **Shared jump:** none flagged. The material shows no career move similar to one of his.

---

## 8. Persona table

Relationship prior: a peer round sets Data-Driven Prober and Peer Evaluator as the two dominant personas. Interviewer signals and the round's content adjust those weights below.

| Persona | How it shows up in this round | Likelihood and reasoning | Weight | Counter-strategy (rehearsal method) |
|---|---|---|---|---|
| A. Data-Driven Prober | Numbers taken to their denominators; follow-ups two levels deep | **High.** He self-describes as "relentlessly data-driven," and the peer prior already leans this way | 5 questions | Know how each figure was counted or say you don't; name your weakest assumption first; offer to walk through an analysis you ran |
| B. Peer Evaluator | Seam questions, disagreement, credit, "what would you need from me" | **High.** The round is a peer round, and he is pricing what a hire adds to his team | 4 questions | Propose seam principles rather than pretending to know his seam; reciprocity framing; a disagreement story that shows spine and tact |
| C. Case / Strategist | Live problems on the two product lines, whitespace, pricing against a bundle | **Medium-high.** The JD's live problems plus his pricing spine tilt the cases toward pricing | 3 questions | Clarify, then structure, then state a view and flag it as a view; challenge one premise |
| D. Skeptic | Gap probes: GTM ownership, quota work, transfer from consumer tech | **Medium.** The JD's headline requirement sits against a background that is product strategy and operations | 3 questions | Rehearse the single most predictable objection until it is calm; calibrated candor, not bluffing |
| E. Pressure | Interruptions on the headline claim, time-boxed answers | **Low-medium.** A peer round rarely pressures, but a sharp prober can | 2 questions | Pause, restate, hold a challenged position through two follow-ups, concede only what is true |
| F. Conversational | A casual opener; a casual question about the AI plus | **Medium.** Openers are scored, and the JD's plus is asked casually | 2 questions | Use a 90-second arc for the opener; treat the casual AI question as scored |
| G. Values / Behavioral | One behavioral stem | **Low.** No values round was detected and no published values are in hand; kept at one question so the register is not new | 1 question | Story from your own sentence where one carries it; otherwise a selection scaffold with its honest branch |

Session total: 20 questions, inside the 18 to 26 range. Depth follows weight.

---

## 9. Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M uplift was counted." | EXP, JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say the figure the way the sentence does: a credited uplift, from a change you proposed. Name the weakest assumption behind the credit before he does. Answer slot: if you know how the credit was counted, say how in your own words; if you don't, say so plainly. Do not rebuild a method you cannot repeat under a second question. | F1 holds the headline figure, and it is the likeliest probe. EXP because it tests attribution: what was yours and how the number was reached. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Name the assumption you would defend least, in one sentence, in your own words. If you cannot name one, say so and say what you would check. Hold it through one follow-up, then concede specifically rather than defend the number. | This is the second level of the same figure. A Prober asks it deliberately so that the first answer does not finish the job. |
| A3 | "Walk me through how the partner revenue model was built. What did it take as inputs, and where did you distrust them?" | JD, EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Story-map from the quote: the model, and the carrier negotiations it was used in. Answer slot: if you chose the inputs or decided where to distrust them, say which and how; if the inputs were set by others, or you distrusted none, say so plainly and describe how the model was used. | F4 is the requirement the model only partly reaches. This probe checks whether the model is hers, and it is the partner-motion question in its most likely form. |
| A4 | "Take one annual volume target you set. What did it assume, and what would have told you it was wrong?" | EXP, JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Pick one target. Name the assumption you would defend least and the signal you would have watched. Answer slot: if you did this, say which target, in your own words; if the targets came from a process you did not shape, say so plainly. Do not name an assumption you cannot tie to a target you set. | F5 carries "targets" and "cross-org consensus." This tests attribution on the consensus, which is the Prober's version of the influence requirement. |
| A5 | "Describe an analysis you ran in SQL or Tableau that changed a decision. What did you assume about the data?" | JD, EXP | [inferred] "skilled in SQL/Tableau" (coach's notes); theme from the JD line "run independent analysis in SQL and Tableau" | Open prompt: pick an instance. Answer slot: if one comes to mind, name the question, the data and the assumption you would defend least; if none does, say so plainly, then say which of your work used SQL or Tableau and what you would check first in this role. | F3 is low confidence, so the guidance asks for an instance and does not assume one. The JD line is the raising source for the theme. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on these product lines. Where's the seam between your GTM work and ours, and what happens when we disagree?" | JD, VAL | [generic] | Propose seam principles, not a map you don't have: who sets the price, who owns the account, who decides when two motions conflict. Then ask one question about where his team's seam sits. Do not claim to know his team's seam. | The seam sits on the two-product-line requirement (JD highlights). Generic because it makes no claim about Dan's team. |
| B2 | "What would you need from my team in the first ninety days?" | JD, VAL | [generic] | Name needs as things you would ask for, not things you have done: data, a stakeholder list, the current motion. Frame each as what it would let you bring to his team. | A peer asks this to measure load. It is the reciprocity framing in its scored form. |
| B3 | "You've set targets before. When your plan and mine disagree on a number, how do you handle it?" | VAL, JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Story-map from the quote: the targets you set and the cross-org consensus they needed. Answer slot: name a disagreement you resolved on a target; if the consensus came without one, say so plainly. Do not add a conflict the quote does not carry. | F5 is the source. This is the collegial return of the influence objection, asked by an equal. |
| B4 | "How do you handle credit when work spans teams?" | VAL, EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Credit precisely: separate what you proposed from the uplift that is credited to it. Answer slot: name one piece of shared work and how you handled credit for it; if you never had to split credit on one, say so plainly. | F1's "credited with" is your own attribution. Keeping it exact is what makes this answer credible. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Enterprise expansion is one of three priorities here. If you were leading one of the two product lines, what would you need to know first?" | CO, CASE | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Clarify, then structure: the objective, which accounts, land, adopt, expand and renew, the metrics and the risks. Think aloud and challenge one premise. Answer slot: name the stage you would check first if one is clear; if not, say what you would ask. | The current-strategy case the research note supports. This is where most candidates go generic. |
| C2 | "A much larger platform vendor is bundling against us. How would you think about pricing a product line that has to sell next to a bundled alternative?" | CO, CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Separate what the buyer pays for from what the bundle includes. Name the unit-economics question you would need answered first. State a view and flag it as a view. Do not assume the bundle's price or contents; ask. | The threat is in your note, and pricing is his native language. This is the question he is most likely to take up. |
| C3 | "Whitespace across land, adopt, expand and renew: where would you look first, and what would you measure?" | JD, CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Structure by stage, name the data you would need at each, and choose one stage to defend. Answer slot: if you have identified whitespace before, name the stage and what you found; if not, say so plainly and give the first measure you would use. | F2 has no evidence, so a case lets you structure the problem rather than claim the work. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your background is product strategy and operations. Where have you owned go-to-market for a product line?" | JD, EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" and "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold the position on what you did: the proposal at its quoted scope, and the revenue model. Hold through two follow-ups by returning to those sentences, not by adding to them. Concede only what is true, and concede it specifically. Answer slot: if you made a go-to-market call on a launch (channel, pricing or rollout), say which and how you decided; if you didn't, say so plainly, then say what you would do in your first thirty days on the product line. | **Highest-ROI prep in this pack.** The JD's headline requirement meets a background of product strategy and ops, so this will be asked in some form. F1 and F4 are the rows it presses. The question asks; it does not assert a negative. |
| D2 | "I don't see quota-setting in your background. How would you handle the quota work in this role?" | JD, EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Calibrated candor, not bluffing. Name the nearest thing your material carries, the volume-target line, at its own scope. Then say how you would learn the quota work first, as a plan: the territory logic, the compensation mechanics, and testing any number against history. Answer slot: if a target you set was worked to by a sales team, say what it was and how you set it; if none was, say so plainly. | "I don't see X" is the Skeptic's stem. The pack writes no first-person negative for Priya; F7 is the coach's record and stays that way until she says it herself. |
| D3 | "That uplift came from a consumer-tech store surface. What transfers to an enterprise data product?" | JD, EXP, CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Say what the consumer-tech work did and did not prepare you for, at its own scope. Then name the limit: the buyer, the sales motion and the data product differ. Answer slot: say which part you would test first in an enterprise setting. | Tests whether the consumer background transfers. It makes no claim about enterprise experience, which the material does not show. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD, VAL | [grounded] "set annual volume targets with cross-org consensus" and "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Pause and restate the question. Answer in sixty seconds: the two sentences as your strongest evidence, and where that evidence stops. Hold the partner model through two follow-ups. Concede its limit specifically: it is not partner-motion design. Do not name any other candidate. | A stress version of the fit question. F4 and F5 are the rows it uses. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Restate and pause. Answer with the quote's own attribution: you proposed it, and the uplift is credited to it. Hold the proposal. Concede the credit honestly: the part that was yours is the proposal. Answer slot: if you know who else shaped the change or the attribution, say who and what they did; if you don't know, say so. | The pressure form of A1. The held position is the one the quote carries, and the concession is specific. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A ninety-second arc in your own words: the consulting years, the consumer-tech years in product strategy and ops, and why this role. Keep to those two sentences and end at the role. | An opener looks casual and is scored. The arc is a story map from two quoted sentences. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools you use daily and one task each one changed. Answer slot: if AI changed a piece of your work, name it; if you use tools without a change you can point to, say so. Do not describe building or shipping an AI product. | The JD's plus, asked casually, which makes it scored. This is F6. |

### G. Values / Behavioral (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] stem; nearest candidate quote "set annual volume targets with cross-org consensus" (coach's notes) | Open prompt: pick a time. Selection scaffold: pick a time you told someone senior a number or plan was not holding. It needs a named stake, the words you used and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, at its own scope: the target line above. | One behavioral stem, to keep the register familiar. No values round was detected and no published values are in hand, so no values cheat sheet is included. |

### Requirement coverage

| JD requirement (source) | Question IDs |
|---|---|
| own GTM strategy for two new product lines | D1, C1, B1 |
| identify whitespace across land/adopt/expand/renew | C3 |
| run independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | A3 |
| strong cross-functional influence | A4, B3 |
| AI experience a plus | F2 |
| [generic] quota and target-setting (role-family, not in highlights) | D2 |
| Headline figure (defend-the-number, from F1) | A1, A2, B4, E2 |

---

## 11. Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| 1 | "What would make the first product line's go-to-market plan count as a success by the end of its first year?" | Shows you are thinking about outcomes before activity. |
| 2 | "Compass is one of three priorities. How is it expected to be packaged against the rest of the platform?" | Ties the question to the bundling threat in your research note. |
| 3 | "Your path runs from a startup chapter through pricing and monetization. Which of those lessons has most changed how you would price a new line here?" | Tied to his own path. It turns the interview into a peer conversation about how he thinks. |
| 4 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the question a peer weighs most. |
| 5 | "Which of the three priorities is the plan most worried about, and why?" | Tests where the team's actual pain sits. |
| 6 | "When two product lines compete for the same accounts, who decides the seam?" | Opens the seam conversation on his terms, and tests the B1 answer. |

---

## 13. Prohibited claims

Built locally from the fit snapshot. None of these may be asserted, softened or implied in any answer. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market strategy for two product lines | Inflated form of F1 | "proposed a store-surface change credited with a ~$400M ARR uplift." Your material says a proposal, not ownership of go-to-market. |
| Designed the partner motion | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations." The model, not the motion. |
| Set quotas, or set targets sales teams worked to | Inflated form of F5 and F7 | "set annual volume targets with cross-org consensus." No quota claim. F7's absence is the coach's record, not a first-person negative. |
| Delivered the ~$400M, or the uplift is yours | Inflated form of F1; drops the attribution | "proposed a store-surface change credited with a ~$400M ARR uplift," keeping "credited with." |
| Ran independent SQL or Tableau analysis end to end, or is expert in either | Inflated form of F3 | "skilled in SQL/Tableau," at its own scope. |
| Built or shipped AI products | Inflated form of F6 | "uses AI tools daily." |

A requirement that no quote speaks to, such as B2B or enterprise sales experience, is silence and not a listed claim. It appears as an answer slot (D3), not as a negative.

---

## 14. Sources

- **Provided documents:** your brief for this session, which contains the role and company, your JD highlights, the candidate's background, your research note on Northwind's priorities and its main threat, and Dan's profile.
- **Research tier:** L0, no searches. Research consent was not given, so this pack uses only what you provided.

Research tier: L0, no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Would have moved the values cheat sheet, which is only included if a values round is confirmed. No search was sent (L0). |
| 2. Northwind interview process, senior GTM | unavailable | Would have moved loop structure and the persona weights. The pack assumes one peer round. No search was sent (L0). |
| 3. Northwind strategy and recent news | skipped | Your research note already fixes the three priorities and the bundling threat, so the inputs fix this output. |
| 4. Dan Kovac, Northwind | unavailable | Would have moved the interviewer read's public footprint (talks, writing). The name is given, so this is not n/a. No search was sent (L0). |
| 5. Representative Senior GTM JD | skipped | Your highlights fix the requirement list. The full JD is requested in the upgrade menu. |

---

## 15. Upgrade menu

- **The full JD text** → the six `[grounded]` highlight rows become quotes from the full posting, and the requirement list can be checked in full.
- **Priya's own sentence on quota-setting or sales-ops work** (or its absence) → F7 becomes a stated absence, which allows a plain first-person acknowledgment in D2, and A-row guidance can use her words.
- **Priya's own account of the ~$400M attribution** (what she proposed, who else shaped it, how the credit was set) → A1, A2, E2 and B4 fill their answer slots in her words.
- **Dan's or the recruiter's focus areas, or any pre-declared deliverable** → coverage of any deliverable, and a reweighting of the personas for the round.
- **Research at L1 (up to 6 searches and 2 page fetches)** → Dan's public footprint (career pattern, talks, writing) firms up the reverse questions and the interviewer read; Northwind's published values can be added if a values round is confirmed. Offered once; nothing is run without your consent.
- **Research at L2 (up to 6 further searches and 2 further fetches, on top of L1)** → a strategy brief, Dan's talks and writing, loop reports for this role family, and recent organisational context. Offered once; cost and caps stated here, run only with consent.
- **`tuesday-dossier.md`** → if you carry one forward, it records this prep's gaps for the next session. Not required.
