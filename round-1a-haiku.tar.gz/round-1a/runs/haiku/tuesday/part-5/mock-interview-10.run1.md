Before the prep, one thing in the invite. It says "our hiring process is fully remote and is carried out entirely on Telegram" and "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat, offer and onboarding included, is a known scam pattern. Until you've checked the invite, don't send documents or bank details here. Check it with Lumenvale Software using a phone number or address from its own website or careers page, not a contact from this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite checked, job-underwriter can do that as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-10-denied-842897e4/2d3eeca4-ab4d-457a-972b-363698a4e502/scratchpad/Lumenvale_customer-support-specialist_interview_pack.md`. I built it for a team-lead round, since your note didn't say whether the team lead would be your manager.

Say the word and I'll play the Skeptic on S3, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is the support team lead the person you'd report to, and is this the only interview before an offer?
2. Does the ad say where you must be based, or whether you need the right to work in the country the company is in?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Lumenvale Software: Customer Support Specialist interview prep

- **Role:** Customer Support Specialist (remote)
- **Company:** Lumenvale Software
- **Interviewer:** support team lead (name not given)
- **Round:** text-chat interview on Telegram
- **Built on:** your message and your summary of the job ad. No full job-ad text, no CV text, and no research this session.

## How to use

Personas describe how a question is asked; types describe what it scores. Type key: **VAL** values/behavioral, **EXP** your experience, probed, **JD** the role's requirements, **CO** company knowledge (none in this pack, since no research ran), **CASE** a live problem. Guidance is scaffolding, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | presentation | Your material says customer service advisor, not customer support. Keep the words there: "I was a customer service advisor at an energy supplier for three years." |
| F2 | "experience with Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool, used daily. Say it in those words. Do not name Zendesk. |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume is not writing quality, and the material does not show how clear your writing is. Answer slot: if a written reply of yours resolved a customer's problem, say what it said; if none did, say so plainly and say how you check a reply before you send it. |
| F4 | "confidence handling escalations" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show escalations at all. Answer slot: if you escalated a case, say what you did before passing it on, in your own words; if you did not escalate cases, say so plainly and describe how you would decide what to escalate. |
| F5 | Right to work and location for a remote role (not stated in your message) | none given | none | [grounded] | hard_gate | Your material does not establish this. It is asked in the closing questions, not bridged here. |
| F6 | Support work for a software company (not in your summary of the ad; the setting of the role) | "I've never worked for a software company." (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never worked for a software company." Then a plan, said as a plan: what you would learn about the product first and how you would check you had it. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | "I use Freshdesk every day." Your material does not show Zendesk, so do not name it as a tool you have used. |
| Has handled escalations | Inflated form of "answering around 60 calls and emails a day"; F4 has no quote | The volume at its own scope. Escalations come up only in F4's answer slot. |
| Ran the refunds process | Inflated form of "I trained four new starters on our refunds process last year" | "I trained four new starters on our refunds process last year." |
| Has worked in software support | Stated negative, F6 | "I've never worked for a software company." Plain acknowledgment, no answer slot. |

## Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "Which part of this role would you be weakest at on day one?" | High. A team-lead round usually probes the gaps, and F4 and F6 are open. | Say the gap in your own words, then answer with a plan. |
| Case / Strategist | A live support scenario in the chat | High. A hiring-manager-type round usually includes a live problem. | Clarify, then act. Think aloud in short lines. |
| Conversational | An opener such as "walk me through your background" | Medium. Text-chat openers are common. | A 90-second arc, in your own words. |
| Values / Behavioral | A customer-focus scenario | Low. No values-style round is documented, so this is not a named round. | Tell one true story and say where it ends. |
| Pressure | "Sixty seconds: why you over someone who has worked in software support?" | Low to medium. Text removes live interruption, not the time limit. | Hold the position through two follow-ups. |

Depth follows weight: Skeptic 4 questions, Case 3, Values 2, Conversational 2, Pressure 1. The pack has 12 questions, under the usual range. The reason is the missing job text and CV: the banks cannot cover mid-list requirements honestly without them.

## Question banks

### Skeptic (top weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company." | Say the acknowledgment in those words. Then name the first thing you would learn about the product and how you would check you had learned it, as a plan. Do not describe product knowledge you do not have. | F6 is the capability gap most likely to be probed. A plan is the answer this material supports. |
| S2 | "You haven't worked for a software company. Why support, and why here?" | JD | [grounded] "I've never worked for a software company." and "I use Freshdesk every day" | Start from the work that draws you: the ticketing you do every day in Freshdesk. Then the software gap in one line. Say nothing about Lumenvale's product, since you have not been given it. | F6 and F2 together. The motivation probe lands on the gap, so the answer starts from what you already do. |
| S3 | "How do you decide when a case goes to someone else, and what happens first?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you escalated a case, say what you did before passing it on, in your own words; if you did not escalate cases, say so plainly and describe how you would decide what to escalate. | F4 has no quote, and the JD names escalations directly. This is the highest-ROI prep in the pack: the objection will arrive in some form, and an honest answer ready in advance changes the interview. |
| S4 | "The ad asks for Zendesk or a similar tool. Which have you used?" | JD | [grounded] "I use Freshdesk every day" | Answer with Freshdesk, which you use every day. Say how you would learn the other tool, as a plan. Your material does not show Zendesk, so do not say you have used it. | F2 is medium confidence. The question is a raising-source question, since the ad names the tool. |

### Case / Strategist (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer's refund has not arrived after two weeks, and they say they will cancel. Walk me through your first three moves." | CASE | [generic] | Clarify first: which order, which payment, and what the refund policy says. Then say what you can promise now and when you would bring in a colleague. Think aloud in short lines. | A live problem from the role. It presupposes nothing about your past. |
| C2 | "Five customers report the same login error this morning. What do you do, and in what order?" | CASE | [generic] | Check whether it is one issue, not five, by matching the details each customer gives. Tell the team lead before replying in bulk. Send a holding reply that states nothing you cannot back. | Tests clarify-before-answer. |
| C3 | "What would you track in your first month to know the queue is healthy?" | JD | [generic] | Name two or three measures and say what each tells you. Say what would make you change one. | A question about judgment. It supplies no figure and asserts nothing about your past. |

### Values / Behavioral (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to tell a customer something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time the answer was no, or a delay, and say what you told them and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | An open prompt on a persona stem. Values weight is low because no values round is documented. |
| V2 | "Tell me about a time you taught someone how a process works." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Say it as you did: four starters, the refunds process, last year. Do not extend it to results you have not stated. | The one story your material carries on teaching. The quote holds the beats. |

### Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | A 90-second arc: the job and the three years, the call and email volume in your words, Freshdesk daily, the refunds training, then why support. Use only those sentences. | An opener in a casual register, still scored. A pre-scripted arc avoids a freeze. |
| R2 | "What do you use day to day in your current job?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk and one thing you do in it, in your own words. | A casual question on a JD topic is still scored. F2. |

### Pressure (1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has worked in software support?" | JD | [grounded] "I've never worked for a software company." | Hold: name the call and email handling and the Freshdesk use. Concede the software gap in one plain sentence. Hold through two follow-ups before conceding anything more. | A pressure stem. The position held is the one your quotes carry, with no software claim. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | R1, F1 |
| Zendesk or a similar ticketing tool | S4, R2 |
| Clear written communication | none, and why: this interview is itself a written exchange, judged on every reply |
| Confidence handling escalations | S3 |
| Software company background (not in your summary of the ad) | S1, S2, P1 |
| Right to work and location | none, and why: a gate your material does not settle; asked in the closing questions |

## Reverse questions

1. "What would a good first month look like, and what would you need from me to get there?" Why it lands: it draws the team lead's own view of the ramp, which answers S1 from the other side.
2. "How are escalations routed on the team, and who makes the call?" Why it lands: it names the area where your material is thinnest, and shows you have thought about it.
3. "Which kinds of tickets take longest to close, and why?" Why it lands: it shows interest in the work itself, not only in the role.
4. "How is a refund decision made today, and who owns it?" Why it lands: it links to the refunds training you can describe.
5. "What does the team use alongside the ticketing tool to track a case?" Why it lands: it shows you already think about the tools a support team runs on.

## Sources

- **Provided documents:** your message (the Telegram invite, your summary of the job ad, and your background).
- **Search:** one search was sent, "Lumenvale Software company careers Customer Support Specialist". It was refused because search permission was not granted.

Research tier: L1 — searches 1 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Would have moved a values section. That section is omitted, since no values-style round is documented. |
| 2. Lumenvale interview process, customer support | unavailable | Would have moved the loop structure. The one search sent here was refused, so the round is the one you describe. |
| 3. Lumenvale strategy / recent news | unavailable | Would have moved the CO questions. None are in this pack. |
| 4. Interviewer name and Lumenvale | n/a | No interviewer name was given. |
| 5. Representative Customer Support Specialist JD | skipped | Your summary of the ad fixes the requirements in the fit snapshot. |

Un-numbered row: the search for "Lumenvale Software company careers Customer Support Specialist" was refused, and it is counted in the total above.

## Upgrade menu

- **The full job ad text:** F1 to F4 quote the ad's own lines instead of your summary, and the requirement coverage becomes exact.
- **Your CV text:** the years and tools rows get CV quotes, and their medium bands can rise.
- **One escalation, or a written reply that resolved a case, in your own words:** F3 and F4 get a quote, and S3 gets a story to rehearse.
- **The team lead's name:** persona weights from a public footprint, and a reverse question tailored to their path.
- **Research access:** company values, the interview process and recent news. This would make the CO and CASE questions use Lumenvale's own terms. It did not run this session.
- **Your answer on right to work and location:** closes F5.
- **tuesday-dossier.md:** records the gaps this prep found, so you can carry them into later sessions.
