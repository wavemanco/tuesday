Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ..." and to "reply with a photo of your passport and your bank details before the interview." It also says "you deposit the cheque and send the balance on to the vendor." A fee before interview, a cheque to deposit with money sent back, and passport and bank details before any offer are a known scam pattern, and this job is very likely a scam. Hold all three: don't pay, don't deposit the cheque, and don't send documents or bank details until you've checked the invite with the company through a phone number or address from its own website or careers page, not any contact in the invite. A real interview needs none of these. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-12-denied-6e71d408/88c8f0ad-018f-47ca-a147-a20c7a4de469/scratchpad/unverified-invite_remote-admin-assistant_interview_pack.md`, and I've attached it. I built it from your message alone. I didn't search the company, so it doesn't use any of its real values or interview structure.

**What to expect:** a 30-minute video call with the office manager. Expect a friendly opener, then pointed questions on the gaps: travel booking and invoice processing, which your background doesn't show, and Word and Excel. There may also be one practical "what would you do" scenario.

**How to prepare:**
- Build a 90-second introduction using only your own sentences: the clinic, the appointment book for four physios, chasing unpaid invoices, Word and Excel.
- Describe what you did, not the system around it. "Ran the appointment book for four physios" is your strongest line, and a probe will ask how you handled clashes between diaries.
- Rehearse the gap answers honestly: say what you have done, then what you'd learn first. Don't upgrade "okay with Excel" or stretch "chased unpaid invoices" into processing invoices.
- Prepare two or three questions. The one to ask is "How is equipment for remote staff supplied, and who pays for it?" A real employer answers that in one line.

Can you paste the full text of the ad? My summary is paraphrased, and exact wording would make the pack more precise.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: unverified-invite_remote-admin-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant

Company: as named in the invite, not verified. Round: 30-minute video call with the office manager. Built from your message alone; no research ran (see Sources). Check the invite before you spend time or money on it. Rehearsing is still useful whatever the outcome.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (a listed requirement), EXP (your past work), CASE (a live problem), VAL (values).
- Guidance is scaffolding, not a script. Say it in your own words.
- Provenance: [grounded] means it traces to your message or your summary of the ad. [inferred] means this pack's derivation. [generic] means a pattern for the role, not a fact about you or the company.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (your summary of the ad) | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | "For two years as a receptionist, I ran the appointment book for four physios." Medium: no artifact to show, so expect a probe. If you handled a clash between two diaries, say how, in your words. If the physios set their own slots, or you never handled one, say so. |
| F2 | "booking travel" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show travel booking, so there are no words for it yet. Answer slot: if you have booked travel for anyone, even personal trips, say what and how. If you haven't, say so, and say how you would learn the company's booking tools. |
| F3 | "preparing documents in Word" (your summary of the ad) | "I'm good with Word" (your message) | low | [inferred] | discovery | Vague, and no example behind it. Answer slot: name one document you have prepared in Word and what it needed to do. If none comes to mind, say so. |
| F4 | "preparing documents in Excel" (your summary of the ad) | "okay with Excel" (your message) | low | [inferred] | discovery | Keep your word "okay" unless you can name more. Answer slot: say what you have used Excel for, in your words. If you have used it only lightly, say so. |
| F5 | "processing supplier invoices" (your summary of the ad) | "chased unpaid invoices" (your message) | low | [inferred] | transferability | "I chased unpaid invoices at the clinic." Adjacent work only. Limit: chasing is a different step from processing, and the pack says so here, not in your mouth. Say where your experience stops. |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I manage supplier invoices end to end" | Inflated form of F5 | "I chased unpaid invoices at the clinic." The limit is this pack's observation: your material says chasing, not processing. |
| "I'm an Excel expert" | Inflated form of F4 | "okay with Excel," at its own scope. |
| "I ran the practice's whole diary system" | Inflated form of F1 | "ran the appointment book for four physios," at its own scope. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: travel, invoices, Excel | Top weight. Three listed tasks have no quote behind them (F2, F4, F5), and an office manager is the one who will notice. | Rehearse the gap answers until they are plain: what you have, then what you would learn. |
| Case / Strategist | One live admin problem | Mid weight. A 30-minute call with an operational lead often includes one scenario. | Clarify first (what is fixed, who decides), then steps. |
| Conversational | A friendly opener, then casual questions about the tasks in the ad | Mid weight. Video calls often open this way, and casual questions are still scored. | A 90-second arc built only from your own sentences. |
| Prober | "How did that work?" about the appointment book | Low weight. Your CV is one line, so a prober has little to go on. | Name the part you ran, not the system around it. |
| Pressure | Challenges "okay with Excel" | Low weight. Short calls rarely test composure for long, but it can happen. | Hold what you said. Concede specifically what you have not done. |

## Question banks

### Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] persona stem | Name two areas where your material shows least: travel booking (F2) and invoices (F5). Say what you would learn first and how. Claim neither. | The role's hardest-pressed areas are the ones with no quote behind them. |
| A2 | "I don't see travel booking or invoice processing in your background. How would you handle those in this role?" | JD | [grounded] "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices" (your summary of the ad) | Answer slot: if you have booked travel or processed an invoice for anyone, say what and how, in your words. If you haven't, say so plainly, then describe how you would learn the company's tools. | F2 and F5 carry this answer. The interviewer's line is the ad's own list. |
| A3 | "You chased unpaid invoices. What did that involve, step by step?" | EXP | [grounded] "chased unpaid invoices" (your message) | Say the steps you took, in your words: who you contacted and what you asked for. If someone else decided on payment, say so. Answer slot: if you ever matched an invoice to an order or approved one for payment, say how. If you did not, say so. | F5 is the bridge. The second branch allows that the practice never existed. |
| A4 | "Tell me about a document you prepared in Word. What did it need to do?" | EXP | [generic] open prompt, theme from the ad's "preparing documents in Word" | Choose a real document. If none comes to mind, say so and give the nearest thing you have. | Open prompt on a listed requirement; F3 is the thin row it tests. |

### Case / Strategist (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's 9 a.m. Two directors need the same meeting room, and one of their flights has just been cancelled. What do you do first?" | CASE | [generic] | Clarify which meeting is fixed and who decides. Check replacement flights against the traveller's needs. Update both directors. Do not book without the traveller's agreement. | A live problem from the calendar and travel requirements. It asks about no past. |
| B2 | "A supplier invoice arrives with no purchase order. What happens to it?" | CASE | [generic] | Hold it. Say what you would check and who approves it. Do not pay before approval. | A live problem from the invoice requirement. |
| B3 | "How would you keep one shared calendar for three people whose availability keeps changing?" | CASE | [generic] | Ask who owns the calendar. Agree which changes need sign-off. Say how you would tell people about a change. | A calendar problem from the ad. |

### Conversational (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" (your message) | A 90-second arc from your own sentences: the clinic, the appointment book for four physios, chasing unpaid invoices, Word and Excel. Stop there. | An opener is scored as well as friendly. |
| C2 | "What do you use Word for day to day?" | JD | [grounded] "I'm good with Word" (your message) | Name what you actually use it for, in your words. If the answer is letters and simple tables, say that. | Tests F3 in a casual register. |
| C3 | "What did you enjoy most at the clinic?" | EXP | [grounded] "ran the appointment book for four physios" (your message) | Name the part you enjoyed, and keep it to your own work. | Shows what you would bring to the calendar work. |

### Prober (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the appointment book worked across four physios." | EXP | [grounded] "ran the appointment book for four physios" (your message) | Name the steps you did yourself. Answer slot: if you handled a clash between two physios' diaries, say how, in your words. If the physios set their own slots, or you never handled one, say so. | F1 is the figure a prober will test. |
| D2 | "How much of the chasing was yours, and how much was done by others?" | EXP | [grounded] "chased unpaid invoices" (your message) | Say what you did and who else was involved, if anyone. | Attribution. Probers ask this about any shared work. |

### Pressure (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You say you're okay with Excel. Why should I trust you with our supplier spreadsheets?" | JD | [grounded] "okay with Excel" (your message) | Hold: say what you have used Excel for, in your words, and that you can learn the company's sheets. Concede specifically: name what you have not used Excel for yet, in your words. Hold through two follow-ups. | F4 is the row this pressure tests. |
| E2 | "Sixty seconds: why you over someone who has done this before?" | JD | [generic] persona stem | Hold on what you bring that is in your sentences: two years at a front desk, and the appointment book for four physios. Concede plainly that someone with office-admin experience will know more about travel and invoices. | Pressure on a stated gap, answered without bluffing. |

## Reverse questions

1. "What does a normal week look like for whoever holds this role?" Why it lands: it tests the ad's task list against real work.
2. "Which calendar and travel tools does the team use day to day?" Why it lands: it tells you what to learn first.
3. "How are supplier invoices approved before they're paid?" Why it lands: it shows you think in process, and it links to B2.
4. "How is equipment for remote staff supplied, and who pays for it?" Why it lands: it is the most useful question here. An employer answers in one line. If the answer is that you pay, you need to hear that before anything else.
5. "What would you hope someone in this role has done well by the end of the first month?" Why it lands: it turns the interview into a planning conversation.

## Sources

- Provided: your message, which holds the invite's text, your summary of the ad, and your background.
- Research tier: L0, no searches. The company's values, interview process and strategy are not in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Values cheat sheet, which does not apply without a values round. |
| 2. company interview process | unavailable | Would have named the real rounds. Not searched in this run. |
| 3. company strategy | unavailable | Would have fed a company-knowledge bank. Not searched in this run. |
| 4. interviewer name and company | n/a | No name was given. |
| 5. representative JD | unavailable | You gave a summary, not the full ad, so the requirement quotes are yours and not exact. |

## Upgrade menu

- The full ad text: replaces the summarised requirements with exact quotes, and turns A2 and A3 from your summary into grounded text.
- A document you made in Word, or a formula you wrote in Excel, described in your words: could lift F3 or F4 from low to medium.
- The office manager's name, once you have checked the invite through the company's own website or careers page: allows one tailored reverse question.
- L1 research on the company's values, interview process and strategy (up to 6 searches and 2 page fetches), once the invite is verified: would replace the generic round with the company's documented one.
- `tuesday-dossier.md`: would carry the gaps this prep exposed into later sessions.
