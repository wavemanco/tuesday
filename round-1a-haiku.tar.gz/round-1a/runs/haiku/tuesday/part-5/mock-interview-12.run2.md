Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN IE00 ..." and to "reply with a photo of your passport and your bank details before the interview." It also says "Successful candidates receive a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor." Paying a fee, depositing a cheque and sending the balance on, and sending passport and bank details before any offer are a known scam pattern. This invite is very likely a scam. Hold all of those until you've checked the invite with Brennock Facilities through a phone number or address from its own website or careers page, not through this email or its domain. Don't send your passport either. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-12-denied-7347d437/0f6afe78-fbf4-4d7a-a0b2-6ae998af7932/scratchpad/brennock-facilities_remote-administrative-assistant_interview_pack.md. It covers the job's four listed tasks against your background, eight questions weighted toward a skeptical office manager, and five reverse questions. I couldn't search for the company, so there's no company-specific material.

What to expect: a 30-minute video call where the office manager will likely probe the gaps first. For you those are booking travel (nothing in your background), Excel (you said "okay"), and supplier invoices (you chased unpaid invoices, which is not the same). Your strongest material is the appointment book for four physios, which covers calendars.

How to prepare:
- Practise a 90-second walk-through of the clinic job in your own words.
- For each gap, have a true answer ready: what you have done, or that you haven't and how you'd learn it. Don't claim travel or Excel experience you don't have.
- Prepare one or two real questions for them, such as which booking tools the team uses.

Two questions:
1. Did the posting or the email state pay, hours or work location? The pack's remote-work row can't be completed without them.
2. Is this your first interview with them, or has a manager already spoken to you?

I can run a live drill with the office manager on any question in the pack, if you want to rehearse it. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Round: 30-minute video call with the office manager (first interview, as the invite describes it). Relationship: likely your future manager, not confirmed.
Built from: the job description as you relayed it, and your background message. No interviewer profile, no company research (search was unavailable; see Sources).

## How to use + type key

Personas = how the question is asked. Types = what is being scored.

- **EXP**: your past work, checked for accuracy and attribution
- **JD**: the listed job requirements
- **CASE**: a live problem from the job
- **CO**: company knowledge (none gathered; no bank uses it)
- **VAL**: values (none published or pasted; not included)

Guidance is scaffolding, not a script. Say only what you actually did, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (ad, as relayed in your message) | "I ran the appointment book for four physios" - your message | medium | [grounded] | presentation | Your material says you ran the appointment book for four physios. Keep those words. Answer slot: if you set rules for how the book was kept, say which rules and how you decided them; if you did not, say so and describe how you kept it. |
| F2 | "booking travel" (ad, as relayed in your message) | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and how; if you have not, say so plainly and say how you would learn the booking tools in your first week. |
| F3 | "preparing documents in Word and Excel" (ad, as relayed in your message), Word part | "I'm good with Word" - your message | medium | [grounded] | none | Your statement reaches Word, with no sample behind it, so expect a probe. Offer to show a document you prepared, if you have one. |
| F4 | "preparing documents in Word and Excel" (ad, as relayed in your message), Excel part | "okay with Excel" - your message | low | [inferred] | discovery | Your statement does not show what Excel work you have done. Answer slot: if you have built or used a spreadsheet for a task, name the task and what it did; if you have not, say so plainly and say how you would build up your Excel. |
| F5 | "processing supplier invoices" (ad, as relayed in your message) | "chased unpaid invoices" - your message | low | [inferred] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices, and does not reach it. Answer slot: say which side of the invoices you chased and what steps you took; if you did not process or pay supplier invoices, say so plainly. |
| F6 | Background (your message) | "two years as a receptionist at a physiotherapy clinic" - your message | medium | [grounded] | none | Gives the setting for F1 and F5; no requirement of its own. |

Gate: the invite says "Remote". Your material does not show remote working terms (location, hours). See the question in the closing section.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Set up the clinic's scheduling system | Inflated form of F1 | F1's quote at its own scope. The material says you ran the appointment book, not that you designed how it worked. |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: chased unpaid invoices. |
| Expert or advanced in Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: travel booking, Excel, invoices | Highest. A hiring-manager-style round for an admin role usually tests the listed gaps first (F2, F4, F5). | Rehearse the gap answers until they are plain; hold the true statement, concede what you cannot yet do. |
| Conversational | Friendly opener, "walk me through", open questions | Medium. A 30-minute video call often opens this way. | A 90-second arc in your own words. Treat casual questions as scored. |
| Data-Driven Prober | Asks how the appointment book or invoices were counted | Lower. Your material has no figures beyond "four physios". | Say what you know; say when you do not know. |

Weights: Skeptic highest (4 questions), Conversational (2), Prober (2). Lower depth follows lower weight.

## Question banks

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" - your message | Name Excel depth as the likely gap, in your own words. Then say how you would close it in the first month. | F4 is where the listed Word and Excel requirement presses hardest. |
| A2 | "I don't see travel booking in your background. How would you handle it?" | JD | [grounded] none given. Answer slot: the ad lists booking travel, and no quote of yours carries it | If you have booked travel for anyone, say what and how. If not, say so plainly and say how you would learn the booking tools. Never describe travel booking you have not done. | F2 is the gap with no quote; the slot's second branch allows that you have not done it. |
| A3 | "Your background is appointment booking. Why is that a base for this role?" | JD | [grounded] "I ran the appointment book for four physios" - your message | Use the quote: you ran the appointment book for four physios. Then connect that to managing calendars. Do not add rules or processes you did not state. | F1 is the strongest fit for the calendar requirement. |
| A4 | "You chased unpaid invoices. What did that involve?" | EXP | [grounded] "chased unpaid invoices" - your message | Say which invoices, and the steps you took, in your own words. If it did not include processing or paying supplier invoices, say so plainly. | F5 is adjacent, not direct; say it at its own scope. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through your journey so far." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" - your message | 90-second arc: the clinic, the appointment book, the invoices, and what you want next. Use your own words. | F6 gives the opening; keep it short. |
| B2 | "What would you want to learn first in this role?" | JD | [generic] | Name one real item, such as the travel booking tools, and say how you would start. | Open question; the answer shows judgment about your own gaps. |

### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How many appointments did the book hold in a typical week?" | EXP | [grounded] "I ran the appointment book for four physios" - your message | Give a figure only if you know it. If you do not, say so plainly. Do not estimate in the interview. | No figure appears in your material; the slot is honest either way. |
| C2 | "Which of your invoice steps would you defend least?" | EXP | [grounded] "chased unpaid invoices" - your message | Name the step you are least sure of, and why. | Common prober follow-up on attribution. |

## Coverage

| Requirement | Questions |
|---|---|
| managing calendars | A3, B1, C1 |
| booking travel | A2, B2 |
| Word and Excel | A1, F3 |
| processing supplier invoices | A4, C2 |

Pack size: 8 questions, below a full session pack. A full pack would need the full job text or the office manager's name.

## Reverse questions

1. "What does a typical week look like for the admin side?" Why it lands: shows you are picturing the job.
2. "Which tools does the team use for calendars and travel bookings?" Why it lands: asks about the gap directly.
3. "How is a new starter's first month structured for remote work?" Why it lands: tests how the remote setup works.
4. "Who would I work with most day to day?" Why it lands: asks about the team, not only the role.
5. "How do supplier invoices move from receipt to payment?" Why it lands: shows you understand the invoice requirement.

## Sources

Research tier: L1 - searches 0 of 6, fetches 0 of 2 (3 searches were attempted and every one was refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities values | unavailable | Values section; not included. Query "Brennock Facilities values careers" refused. |
| 2. Brennock Facilities interview process | unavailable | Loop structure and persona weights; the pack assumes the single 30-minute call. Query "Brennock Facilities interview process administrative assistant" refused. |
| 3. Brennock Facilities strategy / news | unavailable | Company-knowledge bank (CO); none written. |
| 4. Interviewer name | n/a | No name given. |
| 5. Representative JD | skipped | The job description as relayed fixes the fit snapshot. |

Un-numbered: "Brennock Facilities Ltd" search, unavailable, refused. It would have checked that the company exists.

Provided documents: your message (the ad as relayed, and your background). No dossier.

## Upgrade menu

- The full job text, or the posting link → replaces the relayed requirements with exact wording and upgrades F1 to F5 where possible.
- The office manager's name → a tailored persona weighting and a reverse question about their path.
- Pay, hours and work location from the posting → fills the remote gate row.
- Company search results, once search works → company-specific values and strategy questions.
- A tuesday-dossier.md, if you have one → sharpens the gap answers. Not needed for this pack.
