Before the prep, one thing in the invite: it says the hiring process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat is a known scam pattern, so until you've confirmed the invite, don't send money, documents or bank details here. Check it with Lumenvale through a phone number or address from its own website or careers page, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-10-denied-9bb5de76/bc34a0c6-badd-4ca8-a9eb-00f747e9d8d8/scratchpad/lumenvale_customer_support_specialist_interview_pack.md`. I built it for a hiring-manager-style round with the team lead, from your message and the job-ad points you gave me. Web research was denied in this session, so the company values and interview structure are not in it.

The four things to rehearse most are the escalation question (A4), the written-communication sample (B3), the "never worked for a software company" question (C1), and the volume figure (B2), because you'll need to explain how the 60 a day was counted.

I can also play the team lead on A4 as a text drill, or save a `tuesday-dossier.md` that carries these gaps into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Who is the team lead, and is this round a hiring-manager interview or a peer chat? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Round: text-chat interview with the support team lead (name not given), run on Telegram. Relationship: hiring manager, so the persona weights below follow a hiring-manager round. Research tier: none ran (see Sources).

## How to use this pack

- Personas are how a question is asked. Types are what is being scored.
- Type key: **CASE** live scenario from the job. **JD** the job ad's own requirements. **EXP** your own history and whether it holds up. **VAL** values (none detected here). **CO** company knowledge (no research ran, so none here).
- Guidance is scaffolding, not a script. In a text chat, speak in your own words and keep answers short enough to read in one go.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your message) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | Meets the years, with nothing inspected behind it. Lead with the role and the volume in your own words. |
| F2 | "Zendesk or similar ticketing tool" (your message) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a similar ticketing tool. Do not say you have used Zendesk unless you have. |
| F3 | "clear written communication" (your message) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have written support replies you are proud of, describe one in your own words; if not, say so and describe how you check your written replies before they go out. |
| F4 | "confidence handling escalations" (your message) | "I trained four new starters on our refunds process last year" (your message) | medium | [grounded] | transferability | The quote is refund-process training, not escalations. Your material says training on refunds, and the words stay there. Answer slot: if you handled escalations yourself, say how and where you drew the line, in your own words; if you did not, say so and describe how you handled refund disputes. |
| F5 | none; stated negative about the employer type (your message) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A plain negative you stated. Words you can say: "I haven't worked for a software company." Then how you would learn their product, as a plan and never as a past. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Handled escalations" | Inflated form of F4 | The training quote at its own scope. My observation, not words for you: your material says refunds-process training, not escalations. The slot in F4 stays inside the training. |
| "Experienced with Zendesk" | Inflated form of F2 | "I use Freshdesk every day." Nothing about Zendesk. |
| "Software support experience" | Sourced negative, F5 | "I haven't worked for a software company." Plain acknowledgment, no slot. |

## Persona table

| Persona | How it shows up in a text chat | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live ticket scenarios: a refund chase, an escalation, a backlog | High. A hiring manager buys capability, and a support lead tests it with a live case | Clarify, then act, then tell the customer what happens next. Say what you would check first. |
| Skeptic | Quiet probing of the gaps: software, escalations, written quality | High. F3, F4 and F5 are the gaps a team lead will check | Rehearse the escalation objection until it is plain. Concede the gaps you have, and state your plan for each. |
| Conversational | A warm opener and a casual question about your path | Medium. Chat interviews open softly, and the casual questions are still scored | Keep a 90-second arc ready, built from F1 and F2. |
| Pressure | Short-answer demands and interrupting follow-ups | Low to medium. Text limits this, but a team lead may ask for a one-line answer | Hold a point through two follow-ups, then concede the specific gap. |

## Question banks

Weights: Case 40 percent, Skeptic 30 percent, Conversational 20 percent, Pressure 10 percent. Depth follows weight.

### Case / Strategist (weight 40 percent, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in angry that their refund is 10 days late. What do you do first?" | CASE | [generic] | Check the refund status before replying. Then reply with what you found, what happens next, and by when. Write the reply in your own words. | A live problem from the role. It needs no claim about your past, so the guidance makes none. |
| A2 | "A ticket needs engineering and has been open three days. Do you escalate, and what does the customer hear?" | CASE | [generic] | Say the threshold you would use to escalate. Say what the escalation note must contain. Tell the customer the next step and the date to expect an update. | A live problem from the escalation requirement in F4. It needs no claim about your past. |
| A3 | "Forty tickets are open and a spike has come in. How do you prioritise?" | CASE | [generic] | Sort by customer impact and deadline first, then by age. Say what you would clear first and what you would leave for the day. | A live problem from the role. Generic on purpose. |
| A4 | "What is your threshold for escalating a ticket, and what does the escalation note contain?" | JD | [grounded] "confidence handling escalations" (your message) | Highest-ROI prep in this pack. Answer slot: if you have escalated tickets yourself, describe the threshold you used and what the note contained, in your own words. If you have not, say so plainly and describe the threshold you would use. | F4 is the thinnest evidence against a stated requirement, and this is where a team lead presses hardest. It is the deepest rehearsal here. |
| A5 | "Walk me through a refund request that falls outside policy." | JD | [grounded] "I trained four new starters on our refunds process last year" (your message) | Story-mapped on F4: you trained four new starters on the refunds process. Answer slot: if you decided a case outside policy, say how; if you escalated it or someone else decided, say that. | F4 again, from the refund side. The question's premise comes from the quote's own refund process. |

### JD (requirements from the ad; included in the Case block above, plus these)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which ticketing tools have you used day to day, and what did you do in them?" | JD | [grounded] "I use Freshdesk every day" (your message) | Name Freshdesk and what you did in it daily. Answer slot: if you have used Zendesk, say so; if you have not, say so and name what carries over from Freshdesk. | F2 is the tool requirement. Answer only from what you have used. |
| B2 | "What volume did you handle each day, and how did you count it?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Give the figure in your words. Answer slot: how the 60 was counted, what it was sensitive to, and which part was yours to handle. Say plainly if you do not know how it was counted. | A figure raises defend-the-number slots, and this is one. The answer must be one you can repeat under a second question. |
| B3 | "Show me clear written communication: explain a refund delay to a customer in three sentences." | JD | [grounded] "clear written communication" (your message) | Write it live. Keep to facts you have, and say what happens next. Do not invent the reason for the delay. | F3 is the weakest evidence against the writing requirement, so the live sample is the proof. |

### Skeptic (weight 30 percent, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never worked for a software company. Why would you fit ours?" | JD | [grounded] "I've never worked for a software company" (your message) | Plain acknowledgment: "I haven't worked for a software company." Then how you would learn the product, as a plan. Do not claim software experience. | F5 is the negative you stated, so the acknowledgment has its source. |
| C2 | "Why are you leaving energy support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Give your actual reason in your own words. Do not borrow the pack's wording. | A motivation probe on F1. The reason is yours to give. |
| C3 | "Which of our requirements would you be weakest at on day one?" | JD | [grounded] "confidence handling escalations" (your message) | Name escalations as the weakest area, and say what you would do in the first two weeks. Answer slot: if you have handled escalations, say so; if not, say so plainly. | Calibrated candour scores better than a bluff. Ties to F4. |
| C4 | "Tell me about a time a customer's reply went badly. What did you write?" | EXP | [generic] | Pick one instance, name what you wrote, and what changed after. If no such time comes to mind, say so plainly and give the nearest case you have. | An open prompt, so it names no event and supplies none. |

### Conversational (weight 20 percent, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through your support background in 90 seconds." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I use Freshdesk every day" (your message) | A 90-second arc: role and years, the volume you handled (B2's figure), Freshdesk daily, refund training (F4). Use only those facts. | F1 and F2 are the arc's facts. Scripted once, then spoken in your own words. |
| D2 | "What do you enjoy most about support work?" | VAL | [generic] | Answer honestly and briefly. No claim-coaching needed. | Casual register, still scored for genuine interest. |

### Pressure (weight 10 percent, 1 question)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "One line only: why should we hire you over someone with software support experience?" | JD | [grounded] "I've never worked for a software company" (your message) | Hold on what you can back: volume, Freshdesk, refund training. Concede the software gap plainly. Do not fold on the core. | Hold through two follow-ups, then concede the specific gap. |

## Requirement coverage

| Requirement | Questions | 
|---|---|
| 2+ years in customer support | D1, B2 |
| Zendesk or similar ticketing tool | B1 |
| Clear written communication | B3 |
| Confidence handling escalations | A4, A5, C3 |

## Reverse questions

1. "What does a typical first week look like for a new starter?" Why it lands: it shows you are already planning the role.
2. "How do escalations move between support and engineering here?" Why it lands: it tests the requirement that is your thinnest.
3. "What does good look like at 90 days?" Why it lands: it gives you the team lead's bar.
4. "How do you check written replies before they go out?" Why it lands: it links to B3 and shows you care about quality.
5. "Which tools does the team use beyond the ticket system?" Why it lands: it shows you want to learn their stack, and it is honest about F5.

## Upgrade menu

- The job ad's full text, copied from Lumenvale's own careers page → the requirement quotes become verbatim and firmer.
- The team lead's name → persona weights and a reverse question on their own path.
- Permission for web research → the values and interview-structure rows.
- A `tuesday-dossier.md` → would carry the gaps this prep found into later sessions.
