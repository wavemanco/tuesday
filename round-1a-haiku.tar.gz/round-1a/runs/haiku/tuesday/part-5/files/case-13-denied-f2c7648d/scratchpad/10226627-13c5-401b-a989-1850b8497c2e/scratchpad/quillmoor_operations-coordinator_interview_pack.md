# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner (recruiter screen)
**Round:** 30-minute phone call, Thursday 2pm, on the mobile number on your application
**Sources used:** the advert, Hannah's LinkedIn message, and what you told me about yourself. No CV was supplied. Web search was refused in this session, so nothing here comes from Quillmoor's own pages.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = the listed job's requirements and terms. **EXP** = what you actually did. **CASE** = a live problem from the job. **VAL** = values (none detected in this round). **CO** = company knowledge (none researched).
- Guidance is scaffolding, not a script. Say it in your own words.

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — JD | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Four years is stated but no CV has been inspected, so expect a check on dates. Say it as the sentence states it. |
| F2 | "chase late orders" — JD | "I chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches the requirement in your own terms. Say it as written. |
| F3 | "Coordinate production schedules between planning, the warehouse and QA" — JD | "I schedule deliveries for our three depots" — your message | low | [inferred] | transferability | Scheduling depot deliveries is adjacent work, not production scheduling. No quote mentions planning, production, or QA. Say the sentence at its own scope. Answer slot in S2. |
| F4 | "track supplier deliveries" — JD | "I chase suppliers when orders slip." — your message | low | [inferred] | transferability | Chasing is in the quote. Tracking deliveries is not. Say the chasing at its own scope. If you kept a record of when supplier deliveries were due, say how. If not, say so and say how you knew an order had slipped. |
| F5 | "keep stock records accurate" — JD | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches the requirement. It is a stated result with no inspectable proof, so the figure gets defend-the-number slots in P1 and P2. |
| F6 | "confident with Excel" — JD | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel. Derivation: a spreadsheet is probably a spreadsheet tool, but the tool is not named. Answer slot in P3. |
| F7 | "ERP experience (SAP or similar) a plus" — JD | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | Stated absence for SAP. The in-house stock system is not stated as ERP, and nothing here treats it as one. Words: "I've never used SAP." Then how you would learn it, as a plan. This is a plus, not a gate. |
| F8 | "£38,000–£44,000" — JD | "I'm hoping for £42,000." — your message | high | [grounded] | none | Pay is a gate term. Your figure sits inside the advertised band, so the gate reads met. Say the figure at its own scope. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — JD | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Location and schedule gate, read met at two days. The limit of three is yours. |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Not bridged here. It is asked in the message that presents this pack. |
| F11 | Reason for moving — Hannah's message ("what's prompting a move") | "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | A specific, stated reason with no document behind it. Say it in those words. It is not a gap. |

**Gap rules applied:** F10 is the only gate the material does not establish. Pay (F8) and location (F9) are gates the material shows met, so they route by their evidence. F7 is a stated absence, so its words come from your sentence and nothing more.

## 2. Persona table

Relationship prior for a recruiter screen is Conversational plus a light Skeptic. Hannah's own message sets the agenda: pay, notice, hybrid pattern, reason for moving, then team and next steps. That makes the logistics questions the core of the call.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, then the four logistics questions in turn | Highest. The agenda is stated, and logistics are scored even in a friendly register. 5 questions (C1–C5). | Pre-scripted 90-second arc. Treat each logistics question as scored. |
| Skeptic | Checks the SAP gap and the motivation for moving | High. The SAP gap is your biggest gap, and "why now" is the predictable motivation probe. 4 questions (S1–S4). | Rehearse S1 until it is plain. Say the SAP fact once and move on. |
| Data-Driven Prober | Asks how the one-third figure was counted | Medium. Your one headline number is the likeliest target. 3 questions (P1–P3). | Say how you counted, and name the weakest assumption before they do. |
| Pressure | Tests whether you hold your figure or your position | Low to medium. Light in a screen. 3 questions (Pr1–Pr3). | Hold, then concede specifically. Never fold on the core claim. |
| Case / Strategist | A live problem from the job's duties | Low. Recruiter screens rarely use cases, but the advert's duties are worth a structured answer. 3 questions (Ca1–Ca3). | Clarify, then structure, then name the risk. Think aloud. |
| Values / Behavioral | Not weighted | Not plausible for this round. No values round is established. | None. |
| Peer / Executive | Not weighted | Not plausible for a recruiter screen. | None. |

## 3. Question banks

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | C1, F1 |
| Coordinate production schedules between planning, the warehouse and QA | S2, Ca3 |
| Track supplier deliveries and chase late orders | C1, Ca1, F4 |
| Keep stock records accurate | P1, P2, Pr1 |
| Report weekly on on-time dispatch | Ca2 |
| Confident with Excel | P3 |
| ERP experience (SAP or similar) a plus | S1, Pr2 |
| £38,000–£44,000 | C3, Pr3 |
| Hybrid: two days a week at Avonmouth | C2, S4 |
| Notice period (recruiter agenda, not in advert) | C4 — none of the material establishes it |

**Conversational (weight: top, 5 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through your journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "I chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc using only those sentences, in that order: the role and years, the depot deliveries, chasing suppliers, the stock-count sheet. Stop there. Add no team, system or outcome beyond these lines. | F1, F3, F4 and F5 are the opener. The arc is built from your sentences, not new material. |
| C2 | "How would the two-day hybrid pattern at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say two days works and that more than three would not, in those words. | F9 is the location logistics slot. Asked in a friendly register, but it is a knockout check. |
| C3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Give the figure as you stated it. It sits inside the advertised £38,000–£44,000. You may ask for the band first if you prefer. | F8 is the pay slot. You stated the figure, so no defend-the-number question follows from it. |
| C4 | "What's your notice period?" | JD | [grounded] Hannah's message: "your notice period" | Give your actual notice period in your own words. Your material does not state it, so the pack does not supply one. | F10 is a hard gate the material does not establish. The answer is not in this pack. |
| C5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in those words. Stop there: the reason is the closing office and the relocation offer. | F11 is the reason-for-leaving slot. It stays at its own scope. |

**Skeptic (weight: second, 4 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "I don't see SAP in your background — how would you handle it in this role?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say "I've never used SAP." Then how you would learn it, as a plan, in your own words, and what you would do first. Do not describe any ERP work you did not do. Highest-ROI prep in this pack: it is your biggest gap and the most likely knockout check. Rehearse it until the plain sentence is boring. | F7. ERP is a plus, not a gate, but a stated absence is the question most likely to be asked. |
| S2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: the production-schedule work across planning, the warehouse and QA is the part your material does not show. If you have coordinated a schedule across any of those teams, say which and what you set. If not, say so and say what you would learn first. | F3 is transferability. The answer slot keeps the honest branch open. |
| S3 | "Why leave, why here, why now?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Give the closing office as the reason for now. For "why here", answer slot: say what about this role made you apply, in your own words. If the main reason is the closing office, say that plainly. | F11. The "why here" probe is the Skeptic's motivation check. |
| S4 | "The advert says two days at Avonmouth. Would three be a problem?" | JD | [grounded] "I wouldn't want more than three." | Two days is fine. Three is the most you would want. Say it as stated. | F9. A knockout check worded as a probe. |

**Data-Driven Prober (weight: mid, 3 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how that discrepancy figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say how you counted, in your own words. Answer slot: if you did not count the discrepancies yourself, or you do not know how the figure was counted, say so plainly. | F5. The one headline number gets defend-the-number treatment. |
| P2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Name the assumption you are least sure of before they do. If you have none in mind, say so. | Weakest-assumption slot for the same figure. |
| P3 | "Which spreadsheet tool was the stock-count sheet built in?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the tool. If it was Excel, say what you have done in it. If it was not, say so plainly. | F6. The quote does not name Excel, so this checks the one thing the pack cannot. |

**Pressure (weight: mid, 3 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pr1 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold: you rebuilt the sheet. Concede specifically: if other things changed over the year, say you do not know their share. Through two follow-ups, return to the sheet. Do not add to it. | F5. Hold-then-concede on the one result you stated. |
| Pr2 | "Sixty seconds: why should we pick you over someone who already runs SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold your four years of coordination and the stock sheet. Concede SAP plainly. Do not argue the SAP point. | F7 and F1. Tests composure under a comparison you cannot win on SAP. |
| Pr3 | "You said £42,000 — would you take less?" | JD | [grounded] "I'm hoping for £42,000." | Hold the figure as yours. If you would consider a lower number, say the number you would accept. That choice is yours. | F8. The pay slot under pressure. |

**Case (weight: low, 3 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Ca1 | "A supplier's order is late and a production run depends on it. What do you do first?" | CASE | [generic] Raising source: the advert's "chase late orders" | Structure: confirm the new date with the supplier, tell planning and the warehouse what moves, check whether other stock covers the run, record the slip. No claim about your past. | A pattern for the problem, not a fact about this employer. |
| Ca2 | "Weekly on-time dispatch has slipped two weeks running. What do you check?" | CASE | [generic] Raising source: the advert's "report weekly on on-time dispatch" | Separate late supply from late dispatch, check the schedule, and report the cause alongside the figure. No claim about your past. | Live problem from the advert's reporting duty. |
| Ca3 | "How would you build one schedule that planning, the warehouse and QA can all work to?" | CASE | [generic] Raising source: the advert's "Coordinate production schedules between planning, the warehouse and QA" | Name each team's constraint, agree the cut-off, and say who changes the plan when it moves. No claim about your past. | Covers the advert's main duty as a decision, not a record. |

**Reverse questions** (the recruiter's agenda ends with team and next steps, so ask these after that)

1. "What does a typical week look like, and how much of it is production planning?" Why it lands: it tests the advert against the actual job and shows you read the duty list.
2. "Which two days at Avonmouth does the pattern use, and can it move?" Why it lands: it pins down the location limit of three.
3. "Who would I work with most day to day: planning, the warehouse or QA?" Why it lands: it shows you are mapping the three teams.
4. "Is the stock system SAP or something else, and what would I be expected to learn first?" Why it lands: it turns the SAP gap into a question about onboarding.
5. "What are the next steps after this call, and who makes the decision?" Why it lands: it closes the call the way the recruiter opened it.

## 4. Prohibited claims

These are claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production scheduling across planning, the warehouse and QA | Inflated form of F3 | "I schedule deliveries for our three depots." The limit is the pack's own observation: the material says depot deliveries, not production schedules. |
| Tracked supplier deliveries | Inflated form of F4 | "I chase suppliers when orders slip." |
| Confident with Excel | Inflated form of F6 | "I rebuilt our stock-count spreadsheet." The tool is not named. P3 asks. |
| Knows SAP or ERP systems | Negative you stated, F7 | "I've never used SAP." No further slot. |
| Cut discrepancies by a third through my own work alone | Inflated form of F5 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." |

## 5. Sources

- Provided: the advert, Hannah Lowther's LinkedIn message, your self-description.
- Searches: four sent, all refused ("permission not granted"). Queries: "Quillmoor Diagnostics values"; "Quillmoor Diagnostics interview process operations coordinator"; "Quillmoor Diagnostics strategy news"; "Hannah Lowther Quillmoor Diagnostics talent partner". Nothing came back.

**Research tier:** L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have moved the values section, which is dropped because no values round is established. |
| 2. Quillmoor Diagnostics interview process | unavailable | Would have confirmed the loop. Hannah's message already establishes this single 30-minute session, so the loop is established without it. |
| 3. Quillmoor Diagnostics strategy / recent news | unavailable | Would have moved the company-knowledge questions. None are in this pack because the round is a recruiter screen. |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Would have moved the interviewer read, which is absent. |
| 5. Representative operations coordinator JD | skipped | Your advert fixes the fit snapshot and the JD questions. |

## 6. Persona weighting note

The pack uses the recruiter-screen prior because the round is named as a recruiter call with a stated agenda. No archetype fallback is used for the loop, because Hannah's message establishes it.

## 7. Upgrade menu

- Your notice period → C4 and F10 become stated; the blank in the pack is filled.
- Your CV or work history → F1 moves to a document you can show, and the dates can be checked before the call.
- The stock-count sheet's headings, or a redacted copy → F6 and P1–P3 can name the tool and what the sheet counts, which the pack cannot say now.
- Web search enabled in a later session → the values, interview-process and strategy targets run. They add a values section only if a values round is established.
- A tuesday-dossier.md → records the gaps this prep exposed, so later sessions start from them.
- A deeper research pass (L2) → up to 6 more searches and 2 more fetches, several minutes. It needs search, which was refused here.
