# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Round: 45-minute panel interview on Thursday. Panel: Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given).
Changelog: first version.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you did.

Type tags:
- **JD**: can you do the listed job, including its gaps
- **EXP**: do your past claims hold up under scrutiny
- **CASE**: how you structure a live problem from the role
- **VAL**: not used; no values round was detected
- **CO**: not used; no company research was run

## Persona table

Panel: the principal's round blends Skeptic and Case/Strategist; each team member's round blends Peer Evaluator and Data-Driven Prober. Which member asks which is unknown.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Principal asks about fourth-grade fit and team lead | 5. The two stated gaps are the likeliest questions, and the principal is the decision-maker | Rehearse A1 until it is boring. Acknowledge the gap plainly, then state the adjacent work at its own scope |
| Case/Strategist | Live reading-block or standards problem | 3. Planning and standards are where a grade-team panel tests judgment | Clarify first, then structure, then your check |
| Peer Evaluator | Seams between teams, disagreement, credit | 3. Team members price what a new grade colleague adds to their work | Reciprocity framing. Propose principles, not facts about their team |
| Data-Driven Prober | Asks for counts and how you knew something worked | 3. Team members are likely to probe claims about results | Say what you counted. Say plainly when you did not count |
| Pressure | Time-boxed challenge on the fourth-grade gap | 2. Possible in a 45-minute panel | Pause, restate, hold, then concede only what is real |
| Conversational | Opener: "walk me through the journey" | 2. Panels often open this way | A 90-second arc built only from quoted facts |

## Fit snapshot

Requirements come from the invite, which is the only quoted source. Your CV and message supply the evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | The gate is shown met on your CV, so no bridge is needed. Say it in these terms: "My Illinois Professional Educator License, elementary endorsement, is active through June 30, 2029." The pack cannot confirm its status; check it with the state's licensure lookup before Thursday. |
| F2 | "Fourth Grade Teacher position" (invite) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | none | [grounded] | capability | Your stated absence, not bridged. Words: "I haven't taught fourth grade." Then the adjacent work at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Anything about learning fourth-grade content is a plan, said as a plan and never as a past. |
| F3 | Leading a grade-level team (not in the invite; role-family expectation, [generic]) | "I've never been a team lead" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't been a team lead." Do not stretch F4 into team lead; name it only as the nearest thing your material carries. |
| F4 | Reading instruction (role-family, [generic]) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | The quotes already reach this in role terms. Say them in these words and no more. |
| F5 | Communicating with families (role-family, [generic]) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Say it as written: "I write a weekly email to families." |
| F6 | Fourth-grade curriculum and standards (role-family, [generic]) | none given | none | [generic] | discovery | Your material does not show this. Answer slot: if you have worked with fourth-grade standards or the materials a fourth-grade team uses, say which and what you did with them; if you have not, say so plainly and say how you would learn them. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and this pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Your stated absence, F2 | "I haven't taught fourth grade." No slot. |
| Has been a team lead, or led a team | Your stated absence, F3 | "I haven't been a team lead." No slot. |
| Designed the reading curriculum | Inflated form of F4. The material says you led the move to one | Quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The pack's observation: the material says led the move, not designed the curriculum. |
| Ran the reading program for the grade | Inflated form of F4 | Quote at its own scope: "I've run the after-school reading club for the last two years." |

## Question banks

### A. Skeptic (weight 5, five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role is fourth grade, and your last six years were third grade. Why is this a move you're making now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Open with the third-grade facts in those words. Then the case you can stand behind: the reading and family work (F4, F5). Hold that the reading work carries over. Concede plainly that fourth-grade content is new to you. Answer slot: if you have taught or worked with any fourth-grade material, name it; if you have not, say so and say what you would do first. | F2 is the largest gap and the likeliest objection. **A1 is the highest-ROI prep in this pack.** Rehearse the concession until it is plain and short. JD because it scores the posting's grade requirement |
| A2 | "Have you ever coordinated other teachers' work?" | JD | [grounded] "I've never been a team lead" (your message) | Plain acknowledgment: "I haven't been a team lead." Then the nearest thing your material carries, in its own words: "I led our grade level's move to a new reading curriculum in 2024" (your CV). Answer slot: if you coordinated anyone's work on that move, say whose and what you coordinated; if you did not, say so and stay with the move as you led it. | F3. The question is open, so the honest branch is always available |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your message) | Name the fourth-grade content first, plainly. Then the ramp: what you would learn first and from whom. Do not name an area you have not worked in as if you had. | F2 in a Skeptic's form. The ramp is a plan, so it carries no past claim |
| A4 | "A student in the third week of fourth grade can decode but cannot retell what she read. What do you do on Monday?" | CASE | [generic] | Clarify what you would check first about her reading. Then the next step, in your own classroom terms. Do not name a program you have not used | A live reading problem from F4's area. It asks about no past, so the guidance makes no claim about you |
| A5 | "You're joining a team that is already working. How would you learn its routines before changing anything?" | JD | [generic] | Observe, ask, and name one first step, as a plan. Do not describe routines you have not seen | F2 and F3 in a ramp form. The panel is testing whether you change things before you understand them |

### B. Case/Strategist (weight 3, three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Plan a 45-minute reading block for a fourth-grade class with students at very different levels." | CASE | [generic] | Clarify class size, materials, and what assessment exists before you structure anything. Then group, sequence, and one check you would run at minute 40. Keep it speakable in 90 seconds | Reading is F4's territory. The panel is testing planning, not a memory of a program |
| B2 | "Which fourth-grade standards would you read first, and why?" | JD | [generic] | If you know the standards, name them and how they would shape your plan. If you have not read them, say so and name the order you would read them in. Answer slot, per F6 | F6 is silent in your material. The honest branch is built in |
| B3 | "You led a move to a new reading curriculum. If this team moved to one, what would you do in the first month?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Tell the 2024 move in those words first. Then your plan for this team, stated as a plan. Answer slot: if you chose parts of the 2024 move, say which; if it was decided above you, say so plainly | F4 is your strongest quote. The question builds on it and the guidance stays inside it |

### C. Peer Evaluator (weight 3, three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for handling a seam, such as asking what the team has agreed on and raising disagreement early. Do not claim knowledge of their team | Peer probe on turf and disagreement. Stem from the persona file |
| C2 | "How do you handle credit when work spans teams?" | JD | [generic] | Name the principle you use. Answer slot: if you have a time when work spanned teams, name it and whose credit it was; if you do not, say the principle and stop there | Credit-sharing is a peer probe. Your material holds no such example, so the slot is honest |
| C3 | "Tell me about a time you disagreed with a colleague about how to teach something." | EXP | [generic] | Pick one time. Say what you proposed and what was decided. If none comes to mind, say so plainly, then give the nearest thing your material carries, the 2024 move (B3), and how that decision went. Do not invent a disagreement | Open prompt. The panel's peers test collegial disagreement, and the honest branch is built in |

### D. Data-Driven Prober (weight 3, three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Your reading club ran for two years. How many students did it have, and how did you know it helped?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Say the figures you actually have. If you did not count, say that plainly. Name the weakest assumption you know of about why it helped, before they do. Answer slot: if you tracked results, say what and how; if you did not, say so | Claims on a CV get probed for their counts and their assumptions |
| D2 | "What did you track to see whether the 2024 curriculum move worked, and what did it show?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot. If you tracked anything, name it and what it showed in your own words. If you did not track results, say so, and say what you would track first. Do not describe an outcome you did not see | The question presupposes tracking that your quote does not state, so its second branch must allow that none existed |
| D3 | "You write a weekly email to families. How do you know families read it?" | EXP | [grounded] "I write a weekly email to families" (your CV) | Answer slot. If you know, from replies or questions, say what you saw. If you do not know, say so and name one way you would check | F5 in a prober's form. The premise is only that you write the email |

### E. Pressure (weight 2, two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade" (your message) | Pause. Restate the question. Hold the case you can make from your quotes (F4, F5). Concede plainly that fourth-grade content is new. Do not fold on the reading and family work | Pressure version of F2. Composure is the thing scored here |
| E2 | "That curriculum move. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Hold: "I led the move." Concede specifically: name any parts decided by others, in your own words. Hold through two follow-ups before conceding anything more | Attribution honesty. The held position is the one your quote carries, and nothing more |

### G. Conversational (weight 2, two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've run the after-school reading club for the last two years" (your CV) | A 90-second arc using only those facts, in your words. End on what brings you to fourth grade, stated as your plan | Panel openers are often this. Speakable and short is the scoring |
| G2 | "What do you enjoy most about teaching reading?" | JD | [generic] | One true sentence from your own classroom experience. Do not name a method you have not used | Casual, but the panel scores it. The reading interest is the JD-adjacent part |

## Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| Valid Illinois PEL with elementary endorsement (invite) | F1 only, and no question: none, and why. The CV already states it, and a question would restate a gate that is shown met |
| Fourth Grade Teacher position (invite) | A1, A3, E1 |
| Team lead (your stated gap; [generic]) | A2 |
| Reading instruction ([generic]) | B1, B3, D1, G2 |
| Families ([generic]) | D3 |
| Fourth-grade curriculum and standards ([generic]) | B2, F6 |
| Seams and collegial disagreement ([generic]) | C1, C2, C3 |

## Reverse questions

Each one has a reason it lands. No interviewer profile was supplied, so none is tied to a career path.

- **"What does a strong first month look like for someone on this grade team?"** It lands because it shows you are planning for the ramp that A3 and A5 raise.
- **"What would you want a new teacher on this team to bring?"** It is the reciprocity question, since team members are on the panel. It shows you are asking what you add, not only what you need.
- **"How does the team plan reading instruction across the grade?"** It lands because reading is where your strongest quotes sit (F4), and it shows you think in the grade's terms.
- **"How are teachers supported when they have to teach content they haven't taught before?"** It lands because it treats F2 as a normal situation, which is how a principal will read it.
- **"How do families usually hear about what's happening in fourth grade?"** It lands because it connects to your weekly family email (F5).
- **"What has the team been working to improve this year?"** It lands because it shows you are interested in the team's current work, not only its history.

## Sources

Provided documents:
- The invite text, as pasted.
- Your résumé. Only its quoted lines are used. Its identification numbers, including the social-security number, are not used or repeated here.
- Your message: "I've never taught fourth grade" and "I've never been a team lead."

Research: Research tier: L1 — searches 2 of 6, fetches 0 of 2

Queries sent:
- "Halvering Elementary School Orrinsford Community School District": no results.
- "Orrinsford Community School District fourth grade teacher panel interview": returned https://orrinsfordschools.example/careers/how-we-hire-teachers. Snippet only; the page was not opened. The snippet says the district uses one 45-minute building panel (the principal and two grade-level teachers), and that panels ask about reading instruction, classroom routines, and working with families. Because the page was not opened, the snippet is not a raising source: no question in this pack presupposes its topics.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering values | yes | Query 1 was the school and district name and returned no results. Values not established, so the values section is dropped |
| 2. Interview process for this role family | yes | Query 2 returned the district's hiring page (snippet only). It moved the panel format and the persona weights. The page itself is unopened |
| 3. Strategy and recent news | unavailable | Not searched. Would have moved the grounding brief, which only L2 adds |
| 4. Interviewer name (Dolores Vantongeren, Principal) | unavailable | Not searched. Would have moved the interviewer read and a reverse question tied to her path |
| 5. Representative JD | unavailable | Not searched. Would have sourced the fit-snapshot requirements beyond the invite's one quoted line |

## Upgrade menu

- The posting text → F1 through F6 gain sources, the [generic] rows become [grounded], and B2 and A2 can be sharpened against the posting's own words.
- What HR says the panel will cover, and any demo lesson or written piece → a graded-deliverable section and a tighter coverage map.
- The principal's public profile, and the team members' names if you have them → the interviewer read, per-member persona weights, and a reverse question tied to her path.
- Opening the district's hiring page → its panel topics become raising sources, which would let the banks ask about them directly.
- Deep research at L2 → a grounding brief on the district's current priorities.
- A `tuesday-dossier.md` → would record the gaps this prep exposed, for later sessions.
