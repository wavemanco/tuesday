# Quillmoor Diagnostics: Operations Coordinator, recruiter screen prep

Interviewer: Hannah Lowther, Talent Partner (recruiter screen). Format: 30-minute phone call, Thursday 2pm.

## How to use

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse the shape, say the words in your own sentences.

Type key: **EXP** = what you actually did. **JD** = the advert's requirements and the recruiter's logistics. **CASE** and **CO** and **VAL** do not appear, because a recruiter screen does not use them.

This pack is short on purpose. A 30-minute screen cannot use a longer one.

## Fit snapshot

Requirements are quoted from the advert or from Hannah's message. Evidence is quoted from your message. Nothing else is treated as your evidence. No CV was supplied, so every claim below is one you stated, not one anyone has checked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | Stated by you, with no CV behind it yet, so expect the years to be checked. Say them as you wrote them. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries across three depots, not production schedules, and the words stay there. Answer slot: if you coordinated more than one function to get a delivery out, say which functions and how, in your own words. If not, say so plainly and stay with the depot scheduling. |
| F3 | "track supplier deliveries and chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | The quote reaches the requirement. Say it as you wrote it: you chase suppliers when orders slip. |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote reaches the requirement and carries a figure, so expect a probe on it (C1). |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The spreadsheet shows you built one. It does not show your level in Excel, and the material does not say. Answer slot: name the features you used to build it, in your own words. If you used only basic ones, say so. |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have produced a figure like this, say what it counted. If you have not, say so plainly and say what you would need to start. |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | "I've never used SAP." Then the in-house stock system, at its own scope. Answer slot: if you entered or maintained stock records in it, say what you did. If you did not work in it directly, say so plainly. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your own stated constraint, and the advert's pattern meets it. Say both halves as you wrote them. |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advert's band. Say it as your figure. This pack gives it no basis you have not stated. |

Confidence is set by what can be inspected. Everything here is "stated by you," so medium is the honest band for the work rows, and high is correct for your own constraints.

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has coordinated production schedules | Inflated form of F2 | "I schedule deliveries for our three depots." The limit is this pack's observation: your material says deliveries, not production. |
| Has used SAP or any ERP | Negative you stated, F7 | "I've never used SAP." No slot. |
| Caused the fall in discrepancies by the rebuild alone | Inflated form of F4 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The sentence says the two things happened; C1 asks which part was yours. |
| Has produced an on-time dispatch report | Silence, not a stated claim, F6 | Not listed as a claim. F6's answer slot asks only what you have produced. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, logistics asked casually: pay, hybrid, notice, reason for moving | High (weight 4–5). A recruiter screen's prior. Logistics and motivation are scored, even when asked casually | Rehearse a 90-second background arc. Treat every logistics question as scored |
| Skeptic | "Why this role, why now," and probes on the gaps | Medium (weight 3). A light skeptic is the recruiter-screen prior; F2, F5, F6 and F7 are the gaps it will find | Hold to your quotes. Say what you have not done, once, plainly |
| Data-driven prober | "How was that counted?" on the one-third figure | Low to medium (weight 2). F4 carries a figure, which invites it | Name the assumption you would defend least. Say plainly what you do not know |
| Pressure | Short challenge on the SAP gap or the salary | Low (weight 2). It can appear in any screen with a knockout criterion | Hold the facts you stated. Concede the SAP gap once and precisely |

## Question banks

### Bank A: Conversational (weight 4–5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, talk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet" | A 90-second arc: the role and the four years, the three depots, chasing suppliers, the stock-count rebuild. Stop at the rebuild. The figure is held for C1. | The opener is scored for economy. F1, F3 and F4 are the evidence; the arc is built only from those sentences. |
| A2 | "What are you hoping to be paid?" | JD | [grounded] "I'm hoping for £42,000" | Give your figure in those words. It sits inside the advert's £38,000–£44,000. Logistics slot: the figure is yours. This pack gives you no basis for it and no salary history. | F9. The recruiter named pay in her message, and the advert's band is the only other input. |
| A3 | "How do you feel about the hybrid pattern?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it as the quote gives it: two days is fine, three is the most. Keep both halves. | F8. A constraint you stated, so it carries no slot. |
| A4 | "What's your notice period?" | JD | [grounded] "your notice period" — Hannah's message | Logistics slot: give your actual notice period. No figure is supplied here, and the pack does not know yours. | Hannah named it. The advert does not state it, so the figure is open. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the closure and the Reading offer in those words, then stop. Keep "which I don't want" as your reason. Do not add anything about the employer. | Hannah named the reason for leaving. The quote is your reason; the pack adds nothing to it. |

### Bank B: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why this role, and why are you looking now?" | JD | [grounded] "our Bristol office is closing next year" — your message | Answer slot: say what in the advert made you apply, in your own words. If you found no reason in it beyond the move, say so plainly. | The material gives a reason for moving, not one for this role. Motivation consistency is the skeptic's scored item. |
| B2 | "The advert asks for SAP or similar. What have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say "I've never used SAP," then describe the in-house stock system in your own words. Answer slot: if you entered or maintained stock records in it, say what you did. If you did not work in it directly, say so plainly. | F7. The highest-ROI prep in this pack: the gap is the most likely objection, so say it first and cleanly. |
| B3 | "The role coordinates production schedules across planning, the warehouse and QA. What is closest to that in your experience?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you coordinated more than one function to get a delivery out, say which and how. If not, say so plainly and describe how the depot scheduling carries over. | F2. The question's premise is the advert's, and the answer's premise is yours. |

### Bank C: Data-driven prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Defend-the-number: say how it was counted, in your words. Say what it is sensitive to, and the assumption you would defend least. Say which part was yours. If you do not know how it was counted, say that plainly. | F4. A figure raises these four slots and no others. The pack does not name a method. |
| C2 | "The role reports weekly on-time dispatch. Have you produced a figure like that?" | JD | [grounded] "report weekly on on-time dispatch" — advert | Answer slot: if you have, say what it counted and how often. If you have not, say so plainly and say what you would need to start. | F6. Your material is silent, so the honest answer is either branch. |

### Bank D: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we move you forward over someone who's used SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Hold what you stated: the depot scheduling and the stock-count rebuild. Concede the SAP gap once: "I've never used SAP." Do not fold on the rest. | F7. Pressure answers hold, then concede precisely. |
| D2 | "Four years in, why should we pay £42,000?" | JD | [grounded] "I'm hoping for £42,000"; "4 years as a logistics coordinator at a building-supplies wholesaler" | Hold the figure as your stated hope and the four years as stated. Do not cite market rates. If pressed, say what your figure rests on, in your own words. If it rests on nothing you can name, say so. | F9 and F1. The pressure is on a figure you gave, not on a benchmark you have. |

Coverage: each advert requirement maps to a question. F1 to A1. F2 to B3. F3 to A1. F4 to C1. F5 to none, and why: the answer slot sits in F5's own row and the screen will not test it further. F6 to C2. F7 to B2 and D1. F8 to A3. F9 to A2 and D2. The recruiter's four logistics topics map to A2 (pay), A3 (hybrid), A4 (notice) and A5 (reason for moving).

## Reverse questions

Each one lands for a reason.

1. "What happens between this call and an interview?" Lands: it shows you are planning the process, not just the call.
2. "How is on-time dispatch reported today, and who reads it?" Lands: it ties to the weekly report in F6 and asks for specifics rather than adjectives.
3. "When a supplier delivery slips, who usually makes the call to chase?" Lands: it shows you know the chase work in the advert.
4. "Which days does the Avonmouth team usually plan to be on site?" Lands: it tests the two-to-three-day range you stated.
5. "What would the first three months look like for someone starting in this role?" Lands: it asks for the job, not the title.

## Sources

Provided documents: the advert, Hannah Lowther's message, and your message. No CV was provided.

Research tier: L0. No searches or fetches were run, so this pack contains no claims about Quillmoor beyond the advert and Hannah's message.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Not run at L0. The values section is dropped because this is not a values-style round |
| 2. Quillmoor interview process | unavailable | Not run at L0. Would have tuned the reverse questions to the stage structure |
| 3. Quillmoor strategy / recent news | unavailable | Not run at L0. Would have grounded a reason-to-apply slot in public facts |
| 4. Hannah Lowther, Quillmoor | unavailable | Not run at L0. Her public footprint would have tuned the recruiter persona |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and every question |

## Upgrade menu

- Your notice period, in your own words → fills A4's slot and the recruiter's logistics line
- Your CV → F1 and F4 become checkable, and F5 can be raised from low
- Research at L1 on Quillmoor's public process and recent news (up to 6 searches, 2 page fetches) → reverse questions tuned to the process, and B1's slot grounded in public facts
- Any prep email or stated focus from Hannah → a coverage check against her list
- A tuesday-dossier.md → carries the gaps this prep exposed into later rounds
