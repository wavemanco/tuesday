# Halvering Elementary: Fourth Grade Teacher panel prep pack

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** 45-minute panel on Thursday: Principal Dolores Vantongeren and two fourth-grade team members (names of the two not given)
**Session mode, first version.** Research tier L0: no search was run, so the pack is built only on your invite and your resume.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it scores: EXP (what you actually did), JD (the role as the invite describes it), CASE (a live problem), VAL (values; none detected), CO (company knowledge; none, since no research ran).
- Guidance is scaffolding, not a script. Say it in your own words.
- **Highest-ROI prep: A1.** The panel will likely open on the fourth-grade gap. Rehearse the plain sentence and the plan until they feel boring.

## Fit snapshot

The invite names one requirement, the license. No posting was supplied, so every other requirement below is role-family prose, labeled `[generic]`, with no quotation marks.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (the invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Your CV shows the gate met. Have a copy of the license ready, and be able to say its status and expiry in one sentence. Check the status yourself through the state's lookup. |
| F2 | Elementary classroom teaching (role-family) | "Six years teaching third grade at a public elementary school in Joliet" (your CV) | medium | [generic] | none | Closed by the quote. Lead with the six years and the grade, in those words. |
| F3 | Fourth-grade teaching experience (the title, Fourth Grade Teacher) | "I've never taught fourth grade" (your message) | none | [grounded] | capability | Your stated words: "I haven't taught fourth grade." Then the nearest thing you carry is third grade, named as adjacent. Then a plan for learning fourth-grade content, said as a plan and never as a past. |
| F4 | Leading a grade-level team (role-family; not named in the invite) | "I've never been a team lead" (your message) | none | [grounded] | capability | Your stated words: "I haven't been a team lead." Then how you would earn a team's trust as a member, said as a plan. |
| F5 | Leading a change in classroom instruction (role-family) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | transferability | This is a curriculum move you led, not a team you led. Say it in the sentence's own terms. The team question stays with F4. |
| F6 | Reading instruction (role-family) | "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | none | Closed by the quote. Say what you ran and for how long. Do not describe what it achieved; the material does not say. |
| F7 | Communication with families (role-family) | "I write a weekly email to families" (your CV) | medium | [grounded] | none | Closed by the quote. This is the one family channel the material shows. |

**Confidence** is set by what can be inspected. Your CV and message are self-reported, so the band stays at medium for the CV lines and none for the stated absences.

## Persona weights

Panel: blend the top two personas of each member's relationship. The principal's prior is hiring manager (Case, Skeptic). The team members' prior is peer (Peer Evaluator, Data-Driven Prober). The Conversational persona opens the panel.

| Persona | How it shows up | Likelihood, and why | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic (principal) | "Why you, why now," "why fourth grade," "why not a team lead" | High. A principal-led panel probes the two gaps that show on the surface of your CV | Plain acknowledgment, then the plan, then hold through two follow-ups | 5 (A1 to A5) |
| Peer Evaluator (team members) | Seam between classes, what they would need from you, credit and disagreement | High. Team members price what a new colleague costs and adds to their own work | Reciprocity: what you bring their team, and seam principles rather than a claimed seam | 4 (B1 to B4) |
| Case / Strategist (principal) | A live problem from the role: a struggling reader, a rollout, a parent | Medium. A hiring manager tests planning as well as history | Clarify, then approach, then how you would know it is working | 4 (C1 to C4) |
| Data-Driven Prober (team members) | How you know a reading move or club worked | Medium. Team members read the CV closely and will ask about the basis for any claim | Say what you can see and how sure you are; say plainly when you did not measure it | 3 (D1 to D3) |
| Conversational / Rapport | An easy opener and a "what are you looking forward to" | Low to medium. Casual questions are still scored | A 90-second arc in your own words | 2 (E1 to E2) |

## Question banks

Total 18 questions, weighted to the Skeptic and the two panel priors.

### A. Skeptic (principal), 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have six years of third-grade teaching. Why should we trust you with fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | Hold the core: "I haven't taught fourth grade." Then say what carries over from third grade, in the CV's own words: six years, third grade, Joliet. Then the first-month plan, as a plan. Hold through two follow-ups by returning to the third-grade years. Never describe a fourth-grade result you do not have. | The single most likely objection. F2 and F3 are where the material is thinnest, so this gets the deepest rehearsal. |
| A2 | "Fourth grade isn't third grade with bigger words. What do you expect to find hardest?" | JD | [generic] | Name one thing you expect to be hard, such as the pace of the year or the content load, and one specific thing you would do in the first month. Keep it a forecast. | A probe on F3, asked about the role, so it makes no claim about your past. |
| A3 | "You haven't been a team lead. Why would this team take direction from you on grade-level decisions?" | JD | [grounded] "I've never been a team lead" (your message) | Hold: "I haven't been a team lead." Then the nearest thing your material carries: "I led our grade level's move to a new reading curriculum in 2024" (your CV), said in its own terms. Then how you would earn a team's trust as a member. Answer slot: if you had a say in the 2024 decision, say what it was; if you did not make that decision, say so plainly. | F4 is a stated gap. F5 is the nearest evidence, and it is a move, not a team. |
| A4 | "The grade team has its own routines. What do you do when you think one of them is wrong?" | JD | [generic] | Open prompt. If you have a real instance, say what you did and why. If no such time comes to mind, say so, then say how you would raise it: ask for the reasons first, then propose a change through the team. | Team fit with no raising source for a past disagreement, so the answer is your choice of instance. |
| A5 | "What did the reading curriculum move involve, and what are you still unsure about?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Describe the move in the sentence's terms: you led it, for your grade level, in 2024. Then name one thing you are still unsure of. Answer slot: if you chose the curriculum, say how; if the choice was made elsewhere, say so and say what you did do. | The 2024 move is the strongest evidence in your file. The panel will probe the decision, so the slot asks for it. |

### B. Peer Evaluator (team members), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our two classes sit side by side. Where is the seam between them, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as shared assessment dates, one family-communication pattern, and a rule for changing a shared unit. Do not pretend to know the seam. Say you would bring a disagreement to them directly. | Peer probes come collegially. Nothing here claims a past event. |
| B2 | "What would you need from us in your first month?" | JD | [generic] | Name what you would ask for: the shared unit plans, the assessment calendar, and a standing meeting time. Ask rather than assume. | Turns the question into a reciprocity answer and shows you have planned for the F3 and F4 gaps. |
| B3 | "What would you bring to this team that we don't already have?" | JD | [grounded] "I write a weekly email to families" (your CV); "I've run the after-school reading club for the last two years" (your CV) | Lead with what these two quotes carry: a weekly family email and two years of the after-school reading club, each in those words. Do not say what the club achieved; the material does not say. | Reciprocity: what you bring their team, not only what you need. |
| B4 | "How do you handle credit when work spans teams?" | EXP | [generic] | Open prompt. Pick a time work crossed a team line. If none comes to mind, say so, then give the nearest thing your material carries: the 2024 move, told in its own terms. Say who did what, not who deserves credit. | A peer probe on credit. The honest branch keeps the answer inside what the quote carries. |

### C. Case / Strategist (principal), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A student reads two years below grade level in October. What do you do in the first two weeks?" | CASE | [generic], with "I've run the after-school reading club for the last two years" (your CV) and "I write a weekly email to families" (your CV) | Clarify first: what the assessment shows, what the student can already read, what the family knows. Then the approach, and a check after two weeks. If you would use the reading club or the family email here, say so, in those terms. | A live problem from the role. The club and the email are real tools you hold. Name them only as tools you would use. |
| C2 | "Your grade is moving to a new reading program next year. Walk me through how you would roll it out." | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Use the 2024 move as the one thing you have done: which step you would keep and which you would change, in your own words. The rollout is hypothetical, so answer as a plan. Answer slot: if the 2024 move taught you a sequence, name it; if you did not set its timeline, say so and name what you would want to set. | The principal is testing whether you can plan a change across a grade. The 2024 move is the evidence, held at its scope. |
| C3 | "A parent emails, upset about a reading decision your class made. How do you respond?" | CASE | [grounded] "I write a weekly email to families" (your CV) | Start with the channel you already use, the weekly family email. Then listen, explain the reason, and offer a meeting if it stays unresolved. Do not claim you have handled this before; if you have, say it in your own words. | A family-communication problem from the role. The family email is the one channel the material shows. |
| C4 | "What is the first fourth-grade content area you would want to learn well, and how?" | CASE | [generic] | Name one area and how you would learn it: the standards, a colleague's unit, a week of observing the grade. Say it as a plan, since you have not taught it. | Turns the F3 gap into a plan the principal can use. No claim about past work. |

### D. Data-Driven Prober (team members), 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you know whether the 2024 reading move was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you tracked something, say what you counted, how you counted it, and which assumption you would defend least. If you did not track it, say so plainly and say what you would measure first. Never describe a result the material does not carry. | The question presumes a measure, so it gets an honest branch on both sides. Your CV names no outcome, so this pack names none. |
| D2 | "How do you know whether the reading club is working for the children who attend?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Open prompt. Say what you can see about the children's progress and how sure you are of it. If you have not measured it formally, say so and name the simplest check you would use. | The club is a claim with no outcome on the CV, so the probe asks for its basis. |
| D3 | "How do you check that a reading intervention is working for one particular child?" | JD | [generic] | Describe a check: a short progress probe every two weeks, compared with the starting point and shared with the family. Say it as a plan. | A method question with no claim about your history. |

### E. Conversational (opener), 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you came to teaching." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" (your CV) | A 90-second arc in your own words: how you started, the six years in Joliet, the third-grade work. Do not invent a turning point. | A casual opener that is still scored for communication economy and interest. |
| E2 | "What are you most looking forward to, if you join us?" | JD | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Name one thing and why, tied to something the quotes carry: the reading club or the family email. Do not fake enthusiasm for a program you do not know. | Rapport, and a chance to show you have looked at the work. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Illinois Professional Educator License with elementary endorsement (invite) | F1 only; a gate the CV shows met, so no question |
| Elementary classroom teaching | E1, B3 |
| Fourth-grade teaching | A1, A2, C4 |
| Leading a grade-level team | A3, A4, B4 |
| Leading a change in instruction | A5, C2, D1 |
| Reading instruction | C1, D2, D3 |
| Communication with families | C3, B1 |
| Other posting requirements | none, and why: no posting was supplied. The upgrade menu asks for it |

## Reverse questions

Each has a one-line "why it lands."

1. "What does a new teacher's first month on this team usually look like?" Why it lands: it shows you are planning for the fourth-grade gap, not waiting to be told.
2. "Which fourth-grade units are the hardest for students each year?" Why it lands: it shows you are already thinking about the content, not only the job.
3. "How does the grade team decide on a change to reading or math?" Why it lands: it asks about the decision process, which is where the team-lead gap will show.
4. "What does the team find hardest about reading instruction right now?" Why it lands: it links to the 2024 move and the club without claiming either as a result.
5. "How do families hear from the team, and through which channel?" Why it lands: it opens the family-email conversation on the team's terms.
6. Peer reciprocity: "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" Why it lands: it turns a probe into a shared-work conversation, the peer-prior question the team members are most likely to answer.

## Prohibited claims

What this pack will not coach, and why. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I taught fourth grade" | Negative you stated (F3) | "I haven't taught fourth grade." Plain acknowledgment. No slot. |
| "I was a team lead" or "I led the grade team" | Negative you stated (F4) | "I haven't been a team lead." Then the 2024 move, at its own scope. |
| "I chose the new reading curriculum" | Inflated form of F5. The material says you led the move, not that you chose the program | "I led our grade level's move to a new reading curriculum in 2024." The limit is this pack's observation: your material does not say who chose the program. |
| "The reading club improved children's reading" | Inflated form of F6. The material carries no outcome | "I've run the after-school reading club for the last two years." |
| "Reading scores rose after the 2024 move" | Outcome no quote carries | The 2024 quote at its own scope. D1's slot asks what, if anything, was counted. |

## Sources

- **Provided documents:** the invite from Human Resources, Orrinsford Community School District (the panel format, the 45 minutes, and the license requirement); your resume and message (the details in the fit snapshot).
- **Research tier: L0.** No search or fetch was run.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Halvering or district values | unavailable | The values cheat sheet, which is omitted because no values were supplied |
| 2. Interview process for an elementary panel | unavailable | The loop structure and persona weights |
| 3. Recent district strategy or news | unavailable | One CO question |
| 4. Principal Dolores Vantongeren, public footprint | unavailable | The interviewer read and one tailored reverse question |
| 5. Representative fourth-grade teacher posting | unavailable | Turns the `[generic]` role-family rows into `[inferred]` rows |

## Upgrade menu

- The posting's list of requirements → F2 to F7 gain quoted requirements, and the coverage table can be checked line by line
- The two team members' names → per-member persona weights and a tailored question for each
- A light research pass (L1) on the district's public values and the principal's public profile → a values cheat sheet and a tailored reverse question
- Your written account of the 2024 move or of the club's results → the answer slots in A3, A5, C2, D1 and D2 get your own words to quote
- The panel's agenda or scoring criteria, if the recruiter sent them → persona weights reset to match
