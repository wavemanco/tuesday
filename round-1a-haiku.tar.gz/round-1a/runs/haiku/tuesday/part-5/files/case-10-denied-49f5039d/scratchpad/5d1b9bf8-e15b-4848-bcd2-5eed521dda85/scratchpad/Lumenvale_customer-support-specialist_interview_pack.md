# Interview prep pack: Customer Support Specialist, Lumenvale Software

Round: first interview, text chat with the support team lead (name not given). Relationship: hiring manager. Weights: Case/Strategist and Skeptic lead, with a short Conversational opener.

Based on: your message to me, the invite from Marcus Hale, and your summary of the job ad. No research was run for this pack, so company-specific content is absent and anything about how Lumenvale works is `[generic]`.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: CASE (live problem), EXP (your past work), JD (the ad's requirements), CONV (the opener).
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- The interview is typed, so your written answers are scored as they are sent. Take your time.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap on years. Say the 3 years and the energy supplier in those words. Expect a probe on what the 60 a day covered. |
| F2 | Zendesk or a similar ticketing tool (job ad, as you summarised it) | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Freshdesk is a ticketing tool in the same family, and your quote says so. Say that you use Freshdesk every day, and do not stretch it to Zendesk. Answer slot: if you have used Zendesk, say when and how; if not, say so plainly. |
| F3 | Clear written communication (job ad, as you summarised it) | none given | low | [inferred] | discovery | Your material does not show written work beyond the role lines. The interview is typed, so it will be tested live. There are no words to supply here. Answer slot: if you have written a reply that resolved a customer's problem, describe what it said and what happened next; if not, say what you would check before sending. |
| F4 | Confidence handling escalations (job ad, as you summarised it) | none given | none | [grounded] | capability | Your message says: "I trained four new starters on our refunds process last year" — that is training, not escalation. Words: "I trained four new starters on our refunds process last year." Then how you would handle an escalation, as a plan, never as a past. |
| G1 | Remote role, fully online (the invite) | none given | none | [grounded] | hard_gate | Your material does not establish whether you can work in this role where you live, or whether you have the right to work for a company based there. Surfaced, not bridged. The one question below asks whether it is met. |

Notes on the table:

- F2 is `presentation`, not `none`, because the quote reaches the requirement in other terms, and the ad names a different tool.
- F4 is `capability` because the material shows no escalation work. The words for it come from the plain acknowledgment only where you stated one; you have not, so the row carries the answer slot above.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2: the ad names Zendesk, and your quote names Freshdesk | "I use Freshdesk every day," at its own scope |
| Handling escalations | Inflated form of F4: your quote is about training starters on refunds | "I trained four new starters on our refunds process last year" |
| Software-company experience | Negative you stated | "I've never worked for a software company." (plain acknowledgment) |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live customer problems from the role | High: a hiring manager buys capability, and a support team lead tests how you would handle a ticket | Clarify the facts, state the options, name the step you would take first |
| Skeptic | Probes on the gaps: software, Zendesk, escalations | High: the three gaps above are where a team lead will press | Rehearse the single most predictable objection until it is calm |
| Conversational | Friendly opener: "tell me about yourself" | Medium: common first questions are casual, and they are still scored | A 90-second arc you can say without notes |
| Pressure | Interrupts or time-boxes an answer | Low: no signal in the invite | Pause, restate the question, hold a true position |
| Data-Driven Prober | Asks how a number was counted | Medium: the 60 a day is the one figure you gave | Say how you know it, or that it is an estimate |

Interviewer read: dropped, because no profile was given.

## Question banks

### A. Case/Strategist (weight: highest; 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer wrote in angry because a refund was promised and never paid. Walk me through how you would handle it." | CASE | [grounded] "I trained four new starters on our refunds process last year" — your message | Clarify: what was promised, by whom, and when. Check the account. Decide what is within your authority, and when it goes to someone else. Reply in writing. Use the refunds process as the spine. Answer slot: if you have handled a case like this, say what you did; if not, say how you would proceed. | A live problem from the role, typed. The only process you have quoted is refunds. |
| A2 | "Walk me through a typical day in your current role. Where does your time go?" | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Give the split between calls and emails, in your own words. If you know how the 60 was counted, say so; if it is an estimate, say that. | F1 is the evidence for the years requirement. The figure invites a probe on how it was counted. |
| A3 | "Walk me through how you would get up to speed on a ticketing tool you haven't used before." | CASE | [grounded] "I use Freshdesk every day" — your message | Say what you do in Freshdesk every day, in your own words. Then describe a plan for learning a new tool. If you have used Zendesk, say so; if not, say so plainly. | F2 is the evidence for the tool requirement; the open prompt is the honest place to say it. |
| A4 | "A customer insists it's a software bug, but the ticket says user error. What do you do?" | CASE | [generic] | Structure it: confirm the steps, check what is already known, decide what goes to engineering and what goes back to the customer, and what you would write. | A live problem about escalation, asked as a decision. It makes no claim about your past. |
| A5 | "What would make you escalate a ticket to the team lead, and what would the note say?" | CASE | [grounded] the ad asks for "confidence handling escalations" (your summary of it) | Give the criteria, then write a short note with the facts, the customer's ask, and what you have already tried. | This is F4's requirement, asked as a decision rather than as a record. |

### B. Skeptic (weight: high; 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. What would make you effective here anyway?" | JD | [grounded] "I've never worked for a software company." — your message; [grounded] "I use Freshdesk every day" — your message | Say it plainly: "I've never worked for a software company." Then name the work that carries over, in the words above: the daily ticket tool, the refunds process. Answer slot: how you would learn the product; say it as a plan. | The most likely objection. The plain acknowledgment is yours to say. |
| B2 | "The ad asks for Zendesk. What is your experience with it?" — **highest-ROI prep**: this will be asked in some form | JD | [grounded] "I use Freshdesk every day" — your message | Hold: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say when and how; if not, say so plainly, and say how quickly you would learn it. Hold through two follow-ups by returning to Freshdesk. | F2 is where the tool requirement presses hardest. The honest branch is a limit, not a confession. |
| B3 | "Three years is not two-plus years of customer support. Why should we count it?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | Say the three years and the energy supplier in those words. Say what the role was. Do not stretch it: the energy role is customer service, and you can say so. | F1 is the evidence for the years requirement. The objection targets a stated number. |
| B4 | "What is your experience with escalations?" | JD | [grounded] the ad asks for "confidence handling escalations" (your summary of it) | Answer slot: if you escalated cases in your role, say when and to whom; if you did not, say so plainly, then describe what you would do. | F4 is `capability`. The honest answer is the limit, stated plainly. |

### C. Conversational (weight: low; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about yourself. What's the short version?" | CONV | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" — your message | A 90-second arc: the energy supplier, the three years, the daily tool, the refunds training, and why you want this role. | Casual openers are still scored. The arc keeps the answer to what you have said. |
| C2 | "What's your biggest strength in customer support?" | CONV | [grounded] "I trained four new starters on our refunds process last year" — your message | Name the training, and what the new starters could do afterwards only if you know it. | A common opener, and your training line is your best evidence. |

Requirement coverage:

- 2+ years in customer support: B3, C1
- Zendesk or similar tool: B2, A3
- Clear written communication: A1, A4 (both answered in typed text)
- Confidence with escalations: A5, B4

## Reverse questions (5)

1. "What does a strong first month look like for someone in this role?" Why it lands: it shows you are planning for the job, not just the interview.
2. "How does a case move from the front line to the team lead, and how quickly is that usually?" Why it lands: it ties your escalation answers to the team's actual process.
3. "Which ticketing tool does the team use day to day, and how is it set up?" Why it lands: it shows you care about the tool, and it sets up A3.
4. "What is the most common thing customers write in about right now?" Why it lands: it shows you want to understand the work, not only the title.
5. "How does the team give feedback on written replies?" Why it lands: the interview is typed, and this asks how quality is judged.

## Sources

- Provided: your message (background, job-ad summary, and "I've never worked for a software company"), and the invite from Marcus Hale.
- No searches or page fetches were run for this pack. Research tier: L0.
- Target accounting: company values, interview process and strategy rows are `unavailable` (no search run this turn); the interviewer row is `n/a` (no interviewer name given); the representative JD row is `unavailable` (no search run this turn).

## Upgrade menu

- The full job ad text → the four rows marked as your summary become `[grounded]` from the ad's own words, and A5 and B4 quote the escalation line.
- Whether the remote role is open to you where you live, and whether you have the right to work for a company based there → resolves gate G1.
- Lumenvale's own careers page or published values → a values cheat sheet, and company-specific questions in place of the `[generic]` ones.
- Prep time before the interview → a prioritised schedule for the questions above.
- A deep research pass on Lumenvale → strategy and interview-process questions, if you want them.
- `tuesday-dossier.md` → records the gaps this prep exposed, for later sessions.
