# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Round: 45-minute panel with Principal Dolores Vantongeren and two fourth-grade team members. Session mode, one panel. Persona weights are blended per the panel (Section 8).

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: JD (the posting's requirement), EXP (your experience), VAL (the district's stated beliefs), CASE (a live problem), CO (company knowledge).
- Guidance is scaffolding for a spoken answer, not a script. Every claim about your past is a sentence you wrote, quoted in the Provenance column. Where the material is silent, the guidance is an answer slot: say the true thing, in your own words.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (the invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | The one gate, and your material shows it met. Your CV is a self-report, so check the license status with the state lookup before Thursday. |
| F2 | "reading instruction" (the district's hiring page: panels ask about reading instruction) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [grounded] | none | The quote reaches reading instruction. Say the move in those terms: what you led, and when. Expect a probe on why the grade chose the curriculum; say what you know. |
| F3 | "each teacher speaks with every family each term" (the district's mission page, Families Are Partners) | "I write a weekly email to families" (your CV) | medium | [grounded] | transferability | Written contact is adjacent to the belief, which names speaking with families. Words: "I write a weekly email to families." Answer slot: if you have spoken with families beyond the email, say how often and in what setting; if you have not, say so and describe what the email does. |
| F4 | "two members of our fourth-grade team" (the invite) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Third grade is the adjacent grade below. Words: "I've taught third grade for six years. I've never taught fourth grade." Then a plan, not a past: what you would read, observe and ask the team first. |
| F5 | "Team lead" is not in the invite; the panel is the fourth-grade team itself | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | medium | [grounded] | transferability | The quote is a curriculum move you led, not a team you led. Words: "I led our grade level's move to a new reading curriculum." Plain acknowledgment: "I've never been a team lead." |

Requirement not supplied in full: the invite lists only the license. The rest of the snapshot comes from the district's own hiring and mission pages.

## 3. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a fourth-grade team or grade team | Inflated form of F5 and sourced negative | "I've never been a team lead." The pack's observation: your material says the curriculum move, not a team. |
| Taught fourth grade, or any fourth-grade classroom experience | Negative you stated, F4 | "I've never taught fourth grade." No slot. |
| Chose or designed the reading curriculum | Inflated form of F2 | "I led our grade level's move to a new reading curriculum." Answer slot: if you had a say in choosing it, say what you did; if you did not, say so. |
| Speaks with every family every term | Inflated form of F3 | "I write a weekly email to families." The pack's observation: your material describes the email, not conversations. |

## 4. Reading the interviewer

Public footprint only, from a speaker page on the state principals forum:

- Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist.
- A 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5.

Implications:
- Reading, and small-group reading in particular, is likely to come up. Your material has no small-group sentence, so B5 and A5 are answer slots.
- Your after-school reading club (quoted in C1) is the nearest thing you can speak to. Say it as the club, not as a small-group method.
- The team members' names were not given, so their personas are blended, not individually read.

## 5. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | Presses the gaps: no fourth grade, no team lead, "why should a team want you" | High: the principal is the hiring authority and the gaps are in the CV | Say the stated fact first, then the plan. Hold the third-grade and reading record through two follow-ups. |
| Case / Strategist (principal) | A first-month or mixed-reading-level problem | Medium: panels for classroom roles often use a live problem | Clarify the students' levels first, then structure the plan. |
| Peer Evaluator (team members) | Seam between third and fourth grade; how you work with a grade team | High: the two team members will price what you add to their work | Reciprocity: what you bring and what you need. Propose principles, not a seam you do not know. |
| Data-Driven Prober (team members) | How you know a group is working | Medium: the CV has no figures, so probes will be on what you measured | Say what you counted, or say plainly you did not count. |
| Values / Behavioral | "Every Child a Reader" and "Families Are Partners" | Medium: the district's beliefs are published and a panel will ask about them | Map one story to each belief only where your material carries one; otherwise a selection scaffold ending in the honest branch. |
| Conversational (opener) | "Walk me through your path" | High: panels open this way | A 90-second arc from your own sentences. |
| Pressure (principal, one follow-up) | "Sixty seconds: why you over a fourth-grade teacher?" | Low to medium | Pause, restate, hold the third-grade and reading record, then concede the fourth-grade gap in one sentence. |

Weights: Skeptic 4, Peer Evaluator 4, Case 3, Data-Driven Prober 3, Values 2, Conversational 1, Pressure 1. Total 18.

## 6. Question banks

### A. Skeptic and Case (principal)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth grade in your background. How would you handle the first month with fourth-grade reading expectations?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I've never taught fourth grade" | Say the fact plainly: "I've never taught fourth grade." Then the plan: what you would read, observe and ask the team first. A plan, not a past. | F4. The most predictable objection and the highest-ROI rehearsal in this pack. |
| A2 | "Walk me through how you ran the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Tell it in your words: the club, its two years. Answer slot: if you chose what it covered, say how; if you did not, say so. | Premised on your own sentence. Tests what was yours. |
| A3 | "What made the grade level decide on the new reading curriculum?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if you know the grade's reasons, say them; if the decision was not yours, say so and describe what you led. | F2. The question presupposes a grade-level decision the quote carries. |
| A4 | "A student reads well above level but cannot yet hold a conversation about the text. Plan the next four weeks of small-group reading." | CASE | [generic] | Structure it: what you would assess first, the groups, the text, the weekly check. The question makes no claim about your past. | Live problem in the principal's published theme. Public footprint, not a raising source. |
| A5 | "Your class has a range of reading levels in the same room. What is your first move?" | CASE | [generic] | Structure it: assess, group, teach to the group, check. Answer slot: name a routine you have used for this; if you have not, say what you would try first. | Routines and levels are the district's stated panel topics. |

### B. Peer Evaluator and routines (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between third and fourth grade, and what happens when we disagree about pacing?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Name the seam from the inside: what third grade hands on at year's end. Answer slot: if you have disagreed with a colleague about pacing, say what happened; if not, say so and say how you would raise it. | F4 and the team's own words. |
| B2 | "Tell me about working with your grade level on the reading curriculum move." | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the quote: the move you led. Answer slot: how you worked with the grade on it, in your own words. | F5. Peer probe on working across the grade. |
| B3 | "When a grade-level project comes out well, who gets the credit, and how do you share it?" | VAL | [generic] | Open prompt. Pick a time a shared piece of work came out well, name what you did and what others did. If no such time comes to mind, say so, then give the nearest from the club or the curriculum move. | Peer credit probe. Theme from the peer persona. |
| B4 | "How do you keep families informed across a term?" | VAL | [grounded] "I write a weekly email to families" | Story-mapped on the quote: the weekly email and what it covers. Answer slot: any conversations with families beyond the email, and how often; if there were none, say so and say what you would add. | F3. Theme from the district belief "Families Are Partners." |
| B5 | "What does a reading block look like in your classroom from start to finish?" | JD | [generic] | Describe a routine you have run, in your own words, step by step. If you have no routine you can name from your material, say what you would start with. | The district names classroom routines as a panel topic. No routine is quoted, so no routine is supplied. |

### C. Data-Driven Prober (team members)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What do you measure to know a reading group is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you counted anything in the club, name it and how; if you did not, say so and say what you would count first. | No figure is quoted, so no defend-the-number slot exists. The probe asks what you measured. |
| C2 | "How did you know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: name any measure you looked at; if none, say so plainly. The question presupposes an evaluation the quote does not carry, so the second branch allows there was none. | F2. Prober follow-up on the curriculum move. |
| C3 | "What would tell you a reading program is working?" | JD | [generic] | Open, no claim about your past. Name two or three indicators and how you would check them. | Prober pattern for reading roles. |

### D. Values (district beliefs)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader: tell me about a student who was behind on reading and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Open prompt. Pick a student from the club, or say plainly if none stands out. Answer slot: what you saw change, only if you saw it; if you did not track it, say so. | Raising source: the district's own belief, fetched from its mission page. |
| D2 | "How do you keep in touch with families across a term?" | VAL | [grounded] "I write a weekly email to families" | Same as B4 from the values angle. Keep the email as the fact, and say any further contact only if you had it. | Raising source: "Families Are Partners," the district's own belief. |

### E. Opener and pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your path to fourth grade." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; [grounded] "I led our grade level's move to a new reading curriculum in 2024"; [grounded] "I've run the after-school reading club for the last two years" | A 90-second arc from those three sentences, in that order. Answer slot: say why you are applying for fourth grade, in your own words. | Opener. The arc is built only from your quoted sentences. |
| E2 | "Sixty seconds: why you over a fourth-grade teacher?" | JD | [grounded] "I've never taught fourth grade" | Pause, restate the question. Hold: "I've taught third grade for six years, and I've led the reading work." Concede once: "I haven't taught fourth grade, and I won't pretend I have." | F4. Hold-then-concede. |
| E3 | "You haven't been a team lead. Why should a team want you on it?" | JD | [grounded] "I've never been a team lead" | Pause. Hold: the curriculum move you led is the nearest record. Concede: "I haven't led a team, and I'd want to learn what the team needs." | F5. Hold-then-concede. |

Question count: 18 (A 5, B 5, C 3, D 2, E 3).

## 7. Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| Illinois PEL with elementary endorsement | F1 | none, and why: your material meets it. Verify the status before Thursday. |
| Reading instruction | A3, B2, C2, C3 | |
| Classroom routines | B5, A5 | |
| Families (speaks with every family each term) | B4, D2 | |
| Fourth-grade team membership | A1, B1, E2 | |
| Team lead | E3 | |
| Every Child a Reader | D1 | |

## 8. Reverse questions

Five or more, each with why it lands:

1. "Your talk on small groups covered grades 3 to 5. What did the weekly conferences change for the students?" Why it lands: it shows you read the principal's published work. It ties to her own path from reading specialist to principal.
2. "What does a first-year fourth-grade teacher here usually get help with first?" Why it lands: it is practical and tells the team you are planning to start.
3. "How does the grade team plan reading across the year?" Why it lands: a peer conversation about the work you would join.
4. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity with the team members.
5. "What would you want to see from the first six weeks?" Why it lands: it asks the principal to state the bar in her own words.

## 9. Sources

Provided documents: the invite, your resume, and your messages in this conversation.

| Query | Result |
|---|---|
| "Orrinsford Community School District Halvering Elementary" | No results |
| "Orrinsford Community School District teacher hiring interview process values" | Returned the district's "How we hire teachers" and "Mission and Beliefs" pages; both fetched |
| "Dolores Vantongeren principal Halvering Elementary" | Returned a state principals forum speaker page |

Fetched: the district's Mission and Beliefs page (quoted in Sections 2, 6 and 8); the district's How we hire teachers page (a 45-minute building panel of the principal and two grade-level teachers; panels ask about reading instruction, classroom routines and how you work with families; references are taken up after the panel).

Research tier: L1 — searches 3 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Mission and Beliefs fetched: three beliefs, named exactly. Moved VAL questions B3, B4, D1 and D2. |
| 2. Orrinsford interview process | yes | How we hire teachers fetched: one 45-minute building panel. Sets Session mode and the panel's blended persona weights. |
| 3. Strategy / recent news | unavailable | Not searched. Would have moved the CO bank; the panel format on the district's own page names no CO or CASE element, so the bank would stay generic. |
| 4. Interviewer name and district | yes | Principal's public footprint found: principal since 2022, nine years as reading specialist, 2025 talk. Moved Section 4 and persona weights. |
| 5. Representative JD | unavailable | Not searched. The invite and the hiring page supply the requirements, so the JD-tagged questions rest on them. |

Values-style round: no values round is detected. The district's page names a panel, not a values round, so Section 10 (values cheat sheet) is dropped. The beliefs still theme VAL questions as raising sources.

## 10. Upgrade menu

- The full posting text → adds any duties the invite leaves out, and turns the JD-tagged questions from the invite and hiring page into posting-based ones.
- The two team members' names → individual persona weights for each member, and a sharper reverse question for each.
- The panel's question list, if HR sends one → replaces the inferred panel topics with the district's own.
- State license lookup result → confirms F1 before the panel; nothing in the banks changes.
