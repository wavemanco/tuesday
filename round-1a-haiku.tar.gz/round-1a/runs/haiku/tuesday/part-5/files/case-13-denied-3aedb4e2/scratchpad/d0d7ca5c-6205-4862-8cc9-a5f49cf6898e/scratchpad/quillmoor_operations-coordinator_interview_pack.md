# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, 30 minutes by phone, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Built from:** the advert, your background notes, and Hannah's message. Research did not run (see Sources), so nothing here about Quillmoor's values, interview process or strategy is established.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **JD**: the role's own requirements or terms
- **EXP**: your past work, and whether it holds up when asked about
- **VAL**: values (none detected for this round)
- **CO**: company knowledge (none; no research ran)
- **CASE**: a live problem (none for this round)

Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage

Sized to a 30-minute screen. Hannah has said what she will cover, so the order below is what to have ready.

1. **Pay (A1).** Have your figure ready in one sentence. The advert's band is £38,000 to £44,000.
2. **Notice period (A2).** Know your exact figure before the call. It is not in your notes.
3. **Hybrid pattern (A3).** Your two-day, three-maximum position, said once and plainly.
4. **Reason for leaving (A4).** Your Bristol office closure and the Reading offer, in your own words.
5. **The gaps (B2, B3).** Production scheduling and SAP. Say each plainly; do not stretch either.
6. **Reverse questions.** Ask two or three from section 11 when she asks whether you have questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | No gap. Your material gives the four years and the employer type. Expect a probe on what the coordination covered day to day |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material says delivery scheduling across three depots, not production scheduling across planning, the warehouse and QA. Say the scheduling you did, in those terms. Answer slot: if you coordinated across more than one team on anything, say what and how; if the scheduling was deliveries only, say so plainly and say how you would learn production planning |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | presentation | Your sentence already reaches this requirement. Say it in your words: you chase suppliers when orders slip. Do not add a number of suppliers or orders you did not give |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | No gap. Confidence is medium because no spreadsheet or count record has been inspected. Expect a probe on how discrepancies were counted |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your sentence shows you built a spreadsheet, not the level of Excel the advert means. Answer slot: name the functions or features you used in that rebuild, in your own words; if you did not use any particular ones, say so plainly |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | The gap is one you stated. Words: "I haven't used SAP. We run our own in-house stock system." Then how you would learn it, said as a plan and never as a past. Do not describe the in-house system as ERP experience |
| F7 | "two days a week at our Avonmouth site" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Met on your own stated constraint. Say it in those words |
| F8 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | Met: your figure sits inside the advert's band. Say your figure in your own words |

Notice period is not in the advert or your notes, so it has no row. It is a logistics slot under A2.

Gate note: location and pay are met (F7, F8). Right to work is not mentioned anywhere in the advert or your notes, so this pack does not assume it.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Managed production scheduling across planning, the warehouse and QA | Inflated form of F2 | Your scheduling of deliveries for three depots, at that scope. The limit is this pack's observation: your material says deliveries, not production |
| Ran supplier management end to end | Inflated form of F3 | "chase suppliers when orders slip" at its own scope |
| Improved stock accuracy by a third | Inflated form of F4 | "discrepancies fell by about a third over a year". Keep the word discrepancies; do not turn it into an accuracy percentage |
| Experience with SAP | Negative you stated, F6 | "I haven't used SAP." No slot |

## Question banks

### Persona weights (recruiter screen)

| Persona | Weight | Why |
|---|---|---|
| Conversational / rapport | 4 to 5 questions | Recruiter screens open with logistics asked casually; each one is scored |
| Skeptic (light) | 3 questions | Checks the gaps (SAP, production scheduling) against the CV and the reason for leaving |
| Data-driven prober | 2 questions | The discrepancy figure is the one number you have given |

Named interviewer read: none. Hannah is the recruiter, so there is no interviewer profile to read.

### Logistics and screen questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" (your message) | Say your figure in your own words. Answer slot: give the number you want, or ask what the band is for this role first | Pay is a logistics slot. Your figure sits inside the advert's band (F8) |
| A2 | "What is your notice period?" | JD | [generic] | An instruction: give your actual notice period, in one plain sentence. Your notes do not give it, so know it before Thursday | Notice is a logistics slot. The figure is yours to state, and this pack does not supply one |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | Say it in those words. You live in north Bristol, and two days is what you can do | Location and schedule are gates, and F7 meets them on your own constraint |
| A4 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" (your message) | Say the reason in those words. It is a fact about the office, not about you or the role | The reason for leaving is a logistics slot. Keep it to what happened |

### Role questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about your experience in logistics coordination." | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | Walk through the four years: the role, the employer type, and what the coordination covered. Keep to what you did | F1 is the requirement the screen checks first |
| B2 | "This role coordinates production schedules across planning, the warehouse and QA. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Describe the delivery scheduling in those words. Answer slot: if you coordinated across more than one team on anything, say what and how; if the scheduling was deliveries only, say so plainly and say how you would learn production planning | F2 is the likeliest gap to be probed, and the advert's own wording raises it |
| B3 | "Have you used SAP or another ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" (your message) | "I haven't used SAP. We run our own in-house stock system." Then the plan for learning it, said as a plan | F6 is a stated gap, so the words are the plain acknowledgment. No slot about past use |
| B4 | "How do you keep stock records accurate?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | Say what you rebuilt and what changed, in those words. Answer slot: how discrepancies were counted, what the count is sensitive to, and the assumption you would defend least; if you do not know how it was counted, say so | F4 is a figure, so it raises the defend-the-number slots. The weakest assumption is yours to name |
| B5 | "How confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" (your message) | Answer slot: name the functions or features you used in that rebuild, in your own words; if you used none in particular, say so plainly | F5 is a discovery gap. A plain answer beats an adjective |
| B6 | "What's your experience chasing late supplier orders?" | JD | [grounded] "chase suppliers when orders slip" (your message) | Say it in those words: you chase suppliers when orders slip. Give one example if you have one, in your own words | F3 is the advert's chase requirement. Presentation only, no slot |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| C1 | "What would a good first 90 days look like in this role?" | Shows you are planning the work, not just the job |
| C2 | "How is the production schedule shared between planning, the warehouse and QA today?" | Asks about the gap in B2 directly, and the answer tells you how the work is split |
| C3 | "What does the weekly on-time dispatch report look like, and who reads it?" | Ties to the advert's reporting duty and shows you read it closely |
| C4 | "Which days at Avonmouth does the team usually work from the site?" | Turns the hybrid pattern into a concrete question about the team |
| C5 | "What ERP does the business run, and how much of the coordination sits in it?" | Asks about the SAP requirement without claiming any SAP experience |
| C6 | "What are the next steps after this call, and who would I speak to?" | Hannah has said she will cover next steps, so this is the close |

Reciprocity question: not needed. No peer interviewer.

### Coverage against the advert

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | B1, F1 |
| Coordinate production schedules across planning, warehouse and QA | B2, F2 |
| Track supplier deliveries and chase late orders | B6, F3 |
| Keep stock records accurate | B4, F4 |
| Confident with Excel | B5, F5 |
| ERP experience (SAP or similar), a plus | B3, F6 |
| Salary £38,000 to £44,000 | A1, F8 |
| Hybrid, two days at Avonmouth | A3, F7 |
| Weekly on-time dispatch reporting | C3 (reverse question only); no answer guidance. This is a gap you can ask about, not one you have a story for |

## Values / principles cheat sheet

Not included. No values page was read, and no loop source establishes a values round.

## Upgrade menu

- Hannah's list of what the rest of the process holds → a loop structure, so the persona weights follow named rounds instead of a fallback
- Quillmoor's careers page or published values, pasted → a values cheat sheet, if a values round appears
- A note of how the discrepancy count was taken (the stock-count spreadsheet's basis) → F4 and B4 become fully grounded, and the defend-the-number slot gets a fact to work from
- Your Excel functions list, in your own words → F5 and B5 move from discovery to grounded
- The advert's full on-time dispatch definition → a sharper answer to the reporting duty, which no story currently covers
