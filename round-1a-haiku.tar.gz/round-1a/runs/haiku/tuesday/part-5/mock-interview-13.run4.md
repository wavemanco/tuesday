I've loaded the mock-interview playbook and checked the input rules. Hannah's message and the advert give me the company, role, round type and your background, so there are no questions to ask before the pack. Web search was refused permission, so the pack is built from your materials alone. I'll write the pack file now.
Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-13-denied-d13620bb/011611bc-09df-42e2-986b-84207a5876f1/scratchpad/quillmoor_operations-coordinator_interview_pack.md.

Web search was refused permission, so the pack has nothing about Quillmoor's values, interview process or recent news. It's built only from the advert, your message and Hannah's message.

The short version for Thursday:

- **Logistics, as you already told me:** pay "I'm hoping for £42,000", which sits inside the advertised £38,000–£44,000; two days at Avonmouth, no more than three; and the real reason, that the Bristol office is closing and the only offer is Reading. Give your notice period as it actually is. You haven't given it to me, so the pack leaves it as an instruction, not a figure.
- **Where you'll be probed:**
  - **SAP:** say "I've never used SAP", then describe how you'd learn it as a plan, not as experience.
  - **Production scheduling and QA:** your material shows scheduling deliveries across three depots, not production runs. Don't stretch that.
  - **Excel:** your message says "spreadsheet", not Excel. Say what tool you actually used.
  - **Dispatch reporting:** nothing in your material covers the weekly on-time report. Say whether you've done one, and if not, how you'd set one up.
- **The one-third figure:** expect "how was that counted?" Say what you know, and say plainly if you don't know. Name the assumption you'd least defend before she does.

Five reverse questions are in the pack for the end of the call. The pack has 13 questions, fewer than the usual range, because the screen is 30 minutes and there's no company research to add more.

If you can give web search permission, I can rerun the company research and add a values cheat sheet, a CO bank and the interview-stage structure. Otherwise, the upgrade menu in the file lists what else would help.

I can also play Hannah for a drill on the SAP or the one-third question, or save a tuesday-dossier.md recording these gaps for your later rounds.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30 minutes by phone, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Interviewer:** Hannah Lowther, Talent Partner. No profile was supplied, so there is no interviewer read.

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored: JD (the advert's requirements), EXP (your past work), CASE (a live problem), CO (company knowledge), VAL (values).
- Guidance is scaffolding, not a script. Say things in your own words, and only what you did.
- Every quoted sentence is one you wrote in your message or CV, or one from the advert or Hannah's message. Nothing else is in quotation marks.
- A recruiter screen is mostly logistics. Pay, notice, the hybrid pattern and your reason for moving are scored in a friendly tone. Answer them plainly and consistently.

## Prep triage

Prep time is not stated, so no schedule is given. In order:

1. Say your pay figure, notice period, Avonmouth pattern and reason for moving exactly as you told me them (A1 to A5).
2. Rehearse the two requirements you do not meet on paper: SAP and production scheduling (B1, B2).
3. Rehearse the one-third figure until you can say how it was counted and which part was yours (C1).

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | "Four years as a logistics coordinator." Self-reported, with no document behind it, so expect a question about it. |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | medium | [grounded] | transferability | Your material shows scheduling deliveries across three depots. It does not show production scheduling or QA. Keep the words at that scope. Any wider step is the answer slot in B2. |
| F3 | "track supplier deliveries and chase late orders" (advert) | "chase suppliers when orders slip" (your message) | medium | [grounded] | none | "I chase suppliers when orders slip." |
| F4 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" (your message) | medium | [grounded] | none | Say the rebuild and the figure in those words. The figure raises the defend-the-number questions in C1. |
| F5 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [grounded] | discovery | Your message says spreadsheet but not Excel, so Excel is not shown. Answer slot: if you built it in Excel, say what it did; if it was another tool, say which. |
| F6 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never used SAP." The in-house stock system is your own adjacent work, quoted at its own scope. Learning SAP is a plan you can state, never a past. |
| F7 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000" (your message) | high | [grounded] | none | "I'm hoping for £42,000." Your figure sits inside the advertised range. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol." (advert) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" (your message) | high | [grounded] | none | Your own constraint, stated as you stated it. |
| F9 | "report weekly on on-time dispatch" (advert) | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you have produced a regular delivery-timing report, say what it showed; if you have not, say so, and say how you would set one up. |

The notice period is not in the advert, and you have not stated it, so no fit row covers it. It is covered by A3.

## Prohibited claims

Not coached: these go beyond what your sentences say. The honest form of each is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned production scheduling or QA coordination | Inflated form of F2 | "I schedule deliveries for our three depots." Your material shows deliveries, not production scheduling. |
| Owned stock accuracy, or cut discrepancies by a third through my work alone | Inflated form of F4 | The quote as written: "discrepancies fell by about a third over a year." Your material does not say how much of that was yours. |
| Knows SAP, or has ERP experience | Stated negative (F6) | "I've never used SAP." Nothing added. |
| Expert in Excel | Inflated form of F5 | The spreadsheet sentence at its own scope. |

## Persona table

Relationship prior for a recruiter screen is conversational, with a light skeptic. No interviewer profile and no loop source were found, so the weights below rest on that prior, not on Quillmoor's own process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly openers, logistics asked casually | High. This is the stated format, and logistics are scored even when asked casually. | Give each logistics answer in one or two sentences and stop. |
| Skeptic | Probes the SAP gap, the production-scheduling gap and the missing Excel evidence | Medium. Your CV and message have the three gaps described in F2, F5 and F6. | Plain acknowledgment, then the quote, then a plan you can state. |
| Data-driven prober | Asks how the one-third figure was counted | Low to medium. The figure is the only number in your material. | Say how it was counted, if you know; say plainly if you do not. Name the weakest assumption before they do. |
| Case / strategist | A live problem from the role | Low. A recruiter screen rarely runs one, but it can. | C4 covers it. |
| Pressure / stress | Interruptions or time limits | Low for a recruiter screen. Shows up mainly if the pay or notice answers are challenged. | Hold your stated pay and notice, and concede only what is actually unknown. |
| Values / behavioral | A values round | Not detected. No loop source names one. | Not applicable. |

## Question banks

### Conversational (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about your background." | EXP, JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | About 90 seconds: four years as a logistics coordinator, the three depots, chasing suppliers when orders slip, and the stock-count rebuild if there is time. Use your own words. | F1 and F3 are the first things she checks against the advert, and this question also covers the 2+ years requirement. |
| A2 | "What are you looking for in salary?" | JD | [grounded] "I'm hoping for £42,000" | Say it as you wrote it: "I'm hoping for £42,000." If she asks whether that is a minimum, your material does not say. Answer in your own words. | F7. Your figure falls inside the advert's £38,000–£44,000 range. |
| A3 | "What's your notice period?" (recruiter's own words: "your notice period") | JD | [grounded] "your notice period" (Hannah's message) | Give your actual notice period. Do not round it or estimate it. This is an instruction for the call, not a question for this conversation. | Logistics slot. The material does not state a notice period, so no figure is supplied here. |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say it as you wrote it. | F8. Your constraint is stated and high-confidence. |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say it in those words. Do not add a reason you have not given. | Logistics slot. The true reason is the strongest answer. |

### Skeptic (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't used SAP. How would you get up to speed?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment: "I've never used SAP." Then say how you would learn it, as a plan, not as something you have done. Answer slot: the advert asks for ERP experience, so expect this probe; if you have worked with any ERP, say which, in your own words. | F6. The advert calls ERP a plus, not a requirement. |
| B2 | "Coordinating production schedules between planning, the warehouse and QA is the core of the job. Have you done that?" | JD | [grounded] "I schedule deliveries for our three depots" | Say the deliveries sentence at its own scope. Answer slot: if you have scheduled production or coordinated with QA, say what it was, in your own words; if you have not, say so, and say which part of deliveries scheduling carries across. | F2. The biggest transferability gap in the advert. |
| B3 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: if you built the stock-count spreadsheet in Excel, say what it did; if it was another tool, say which, and how confident you are with it. | F5. The advert names Excel and your message does not. |
| B4 | "The role reports weekly on on-time dispatch. Have you done that?" | JD | none given | Answer slot: if you have produced a regular delivery-timing report, say what it showed; if you have not, say so and say how you would set one up. | F9. Nothing in your material covers this requirement. |

### Data-driven prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you arrive at a one-third fall in discrepancies?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: say how the figure was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. Say plainly if you do not know how it was counted. Your material gives no method, so do not supply one. | F4. The figure is the only number you gave, so it is where a prober will look. |
| C2 | "How do you keep stock records accurate day to day?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: say what routine you run, in your own words. If there is no routine beyond the rebuild, say so. | Covers the stock-records requirement in the advert. |

### Case / strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Tell me about the last time a supplier order slipped. What did you do?" | EXP, JD | [grounded] "chase suppliers when orders slip" | Open prompt. Pick one real slip and say what you did about it, in your own words. If you cannot name a specific one, say so, then describe how you normally handle a slipped order. | F3. Covers the chase-late-orders requirement with an instance you choose. |
| C4 | "Two of your suppliers miss deliveries in the same week, and the warehouse is waiting on both. Walk me through what you would do." | CASE | [generic] | Structure it: confirm what is late and what is blocking, tell the warehouse and planning, decide what can run first, and say what you would record. Do not claim a past event. | Live problem from the advert's late-order and planning requirements. [generic] because it is a pattern, not a fact about this employer. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F1 |
| Coordinate production schedules across planning, warehouse and QA | B2, C4 |
| Track supplier deliveries and chase late orders | C3, A1 |
| Keep stock records accurate | C2, C1 |
| Weekly on-time dispatch reporting | B4 |
| Confident with Excel | B3 |
| ERP (SAP or similar) a plus | B1 |
| £38,000–£44,000 | A2 |
| Hybrid, two days at Avonmouth | A4 |

The session has 13 questions, below the usual 18 to 26. The screen is 30 minutes and no research was available, so I have not padded it.

## Reverse questions

Each one is for you to ask Hannah, and each has a reason it lands.

1. "What does a typical week look like for this role, and how much of it is planning against chasing?" It shows you have read the advert closely.
2. "How is the Avonmouth hybrid pattern set, which days, and is it fixed?" It turns the logistics you already settled into a question about the team.
3. "What is the biggest pressure on on-time dispatch at the moment?" It shows you are thinking about the job, not only the pay.
4. "Is the stock system SAP, and what would I use it for day to day?" It gives B1 a live answer rather than a rehearsed one.
5. "What happens next, and what is the timeline?" It is the question a recruiter expects.

No interviewer profile exists, so no reverse question is tied to a career path.

## Sources

- Provided documents: the advert text, your message about yourself, and Hannah Lowther's message.
- Searches: "Quillmoor Diagnostics values" (refused); "Quillmoor Diagnostics Avonmouth interview process operations coordinator" (refused).
- No pages fetched.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Values cheat sheet. Not needed, since no values round was detected. |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Loop structure. The persona weights rest on the recruiter-screen prior, not on the company's documented process. |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Company-knowledge questions (CO). Without it, no CO question is in the pack. |
| 4. `{interviewer name} Quillmoor Diagnostics` | n/a | No interviewer name beyond Hannah Lowther's own; no profile is available. |
| 5. Representative JD for this title | skipped | The advert you supplied fixes the fit snapshot. |

## Upgrade menu

- Web search permission → the values page and the interview process for this role, which would add a values cheat sheet if values are published and a loop structure for the persona weights.
- A copy of the stock-count spreadsheet, or a description of it → F4 and F5 could move from medium and low to a checkable artifact, and B3 would have something to rehearse from.
- Your notice period → A3 becomes a figure you can state, rather than an instruction to give it on the call.
- The hiring manager's name → a reverse question tied to their own career path, and persona weights for the next round.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) → company strategy, interviewer footprint and recent organisation news, which would add CO questions.
