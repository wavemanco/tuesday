Before the prep, one thing in the invite. It says "your interview will be a text chat here with our support team lead" and that "your offer and onboarding will be completed in this chat as well." A hiring process run entirely over chat is a known scam pattern, so until you've confirmed who sent this, don't send documents, bank details, or any payment through Telegram. Check the invite with Lumenvale using a phone number or address from their own careers page, not anything in this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite checked in more depth, job-underwriter can do that as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-10-denied-5ee6525c/49b1586b-4e2d-4a26-8efc-4b6bd8f87e22/scratchpad/lumenvale_customer-support-specialist_interview_pack.md`. I built it for a text-chat screen with the team lead and assumed they'd be your future manager.

The pack leans hardest on the software gap. You've never worked for a software company, and the ad names Zendesk where you use Freshdesk. The two questions to rehearse out loud are "You've never worked for a software company. Why would you do well supporting our product?" and "We run on Zendesk. You've used Freshdesk. How long to get productive?" The guidance is to say what you haven't done plainly, describe the closest real work, and never claim Zendesk experience.

Company research didn't run. Both searches for Lumenvale were refused because search permission isn't granted in this session, so the pack rests on your material and the invite alone. The pack also has no values section or interviewer read, because nothing supports them.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. I can run a drill on A1 whenever you're ready.

Two questions:
1. Did you apply through Lumenvale's own careers page, and can you find Marcus Hale listed there or on their site?
2. Could you paste the full job ad? The pack currently works from your summary of it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

Round: first interview, a text chat on Telegram with the support team lead (unnamed). Built for a text-chat screen; I assumed the team lead is your future manager.
Research: none ran (see Sources). Every bank below is built from your own material, the invite, and generic role patterns.

## How to use + type key

- **Personas** = how the question is asked. **Types** = what is being scored.
- JD = requirement check. EXP = work-experience deep-dive. CASE = live problem. VAL and CO are not used in this pack.
- Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Persona table

| Persona | How it shows up in a chat | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Pointed questions on the software gap and the Zendesk gap | High (weight 5) | You said you have never worked for a software company, and the ad asks for Zendesk. A team lead will check both | Answer plainly, then rehearse the closest real work. Do not bluff a tool you have not used |
| Case / Strategist | A live support scenario typed into the chat | Medium (weight 3) | The role is a support role, so a short problem is the natural test | Clarify first, then state your first three steps |
| Conversational | A friendly opener that is still scored | Medium (weight 2) | Chat openers are often casual but still count | Have a 90-second arc ready |
| Pressure | A short challenge on why not a software-experienced candidate | Low (weight 2) | Team leads sometimes test composure | Hold your position through two follow-ups, then concede the specific gap |

Depth follows weight: Skeptic 4 questions, Case 3, Conversational 2, Pressure 2.

## Prep triage

Prep time was not stated, so no schedule is set. If you have one evening: rehearse A1 and A2 out loud until they feel boring, then A4 and B1. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | presentation | Your material says customer service advisor, not support specialist. Say the role's title and its length in those words: "I've worked three years as a customer service advisor." |
| F2 | "Zendesk or a similar ticketing tool" (job ad, as you summarised it) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | Freshdesk is a ticketing tool and you use it daily. You have not used Zendesk, so do not say you have. |
| F3 | "clear written communication" (job ad, as you summarised it) | none given (your message) | none given | [grounded] | discovery | Your material does not show this yet. Answer slot: the chat itself is your written test, so if you have written customer replies, say what they were and how you checked them. |
| F4 | "confidence handling escalations" (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | Training people on refunds is adjacent to escalations, not the same thing. Answer slot: if you have passed a case up to a senior colleague, say what you passed and why, in your own words; if you have not, say so and describe how you would decide. |
| F5 | Software company background (not in the ad) | "I've never worked for a software company" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked for a software company." Then say what you would learn first. Never claim software work. |

Seven rules applied: confidence and gap type each hold one token; quotes are only your own sentences; the bridges for F1 and F2 reword only those quotes.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Zendesk experience | Inflated form of F2; the ad asks for Zendesk and you use Freshdesk | "I use Freshdesk every day." |
| Software or SaaS background | Stated negative, F5 | "I haven't worked for a software company." No slot |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. Why would you do well supporting our product?" | JD | [grounded] "I've never worked for a software company" (your message) | Say it plainly: "I haven't worked for a software company." Then the closest real work: "I've worked three years as a customer service advisor." Answer slot: if you learned a product or system on the job, name it and how you used it, in your own words; if not, say so and say how you would learn theirs first. Hold through two follow-ups by returning to what you did, not by adding to it | The most predictable objection. F5 is the gap; this is the question to rehearse hardest |
| A2 | "We run on Zendesk. You've used Freshdesk. How long to get productive?" | JD | [grounded] "I use Freshdesk every day" (your message) | "I use Freshdesk every day." Name the parts you use daily, in your own words. Then say how you would learn Zendesk: a plan, stated as a plan, never as past use | F2 is the match; the ad names Zendesk directly |
| A3 | "Tell me about a customer contact you had to take further than the first answer." | JD | [generic] | Open prompt, theme from the ad's escalations line. Pick one contact: the stake, what you did, how it ended. If no such contact comes to mind, say so plainly, then give the nearest one your material carries | F3 and F4 are thin on escalations; an honest pick beats an invented one |
| A4 | "Walk me through how you trained new starters on a process." | EXP | [grounded] "I trained four new starters on our refunds process last year" (your message) | Say what you covered and how you checked they had it. Answer slot: if you did not check, say so | F4 is adjacent evidence; EXP because it tests what you actually did |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer says the same fault has come back three times and they are cancelling. What do you do in the first hour?" | CASE | [generic] | Clarify first: what the record shows, what the customer needs today. Then state three steps: check the history, make the right next contact, and escalate with the facts written down. Say the steps aloud, one at a time | A live problem from the role; asks nothing about your past |
| B2 | "Write me a reply to a customer who is angry about a refund we can't give." | JD | [generic] | Short acknowledgment, what is happening, the next step with a time. Write it in the chat, as you would send it | Tests the written-communication requirement in the same channel the interview uses |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through how you got into customer service." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | A 90-second arc with three beats, each a clause from that sentence: the role, the energy supplier, the volume of calls and emails you handled. Do not add a beat | Casual opener that is still scored; F1 is its source |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Why should we hire someone with no software background over someone who has one?" | JD | [grounded] "I've never worked for a software company" (your message) | Hold: "I haven't worked for a software company, and I'd be learning your product." Hold through two follow-ups by returning to the support work you did. Concede specifically: the product is new to you. Do not fold on the daily-contact experience | A challenge to F5; tests composure, not content |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| 2+ years in customer support | A4, C1 | F1 is a title match, not the same title |
| Zendesk or a similar ticketing tool | A2, A1 | F2 covers Freshdesk only |
| Clear written communication | B2 | F3: discovery |
| Confidence handling escalations | A3, B1 | F4 is adjacent |

## Values / principles cheat sheet

Not included: no values-style round is documented for this invite.

## Reading the interviewer

Not included: no interviewer profile was given.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical escalation look like, and who decides it?" | Shows you are thinking about the escalations line in the ad |
| R2 | "Which ticketing tool does the team use day to day, and how?" | Lets you hear the tool before you commit to anything |
| R3 | "What does a new starter's first 30 days look like?" | Asks for the onboarding plan in the open, not in chat |
| R4 | "How will the offer and onboarding be confirmed, and through which company channels?" | A legitimate question for any employer, and a fair check on the process |
| R5 | "What does the next step after this chat look like?" | Gives the team lead a clean close and shows you want the next step, not just the chat |

## Sources

- Provided: the invite message from Marcus Hale (Telegram); your summary of the job ad; your background.
- Research: two searches were sent for Lumenvale (company identity, and its interview process). Both were refused: the search permission was not granted in this session. Nothing was fetched.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | No values round is documented here, so this would move nothing in the pack |
| 2. Lumenvale interview process | unavailable | The two refused calls; the invite's own words already name a single text chat with the team lead |
| 3. Lumenvale strategy / recent news | unavailable | Would feed CO questions; none are in this pack |
| 4. Interviewer name | n/a | No interviewer name was given |
| 5. Representative JD | skipped | Your summary of the ad fixes the requirements |

Refused calls: "Lumenvale Software" and "Lumenvale Software careers interview process Telegram" (both refused).

## Upgrade menu

- The full job ad text → each `from your summary` requirement becomes a quoted line
- Your Zendesk or other ticketing experience, if any, stated in your own words → A2 and F2 can be rehearsed on it
- The team lead's name → a tailored reverse question and persona weights from their public footprint
- Company research, once search is allowed → the values, interview process and strategy targets above
- `tuesday-dossier.md` from an earlier session, if you have one → sharper objections and verified evidence
