Your resume text includes a full Social Security number. Nothing in this prep needs it, so I haven't used or repeated it. Take it off the resume before anything goes to Halvering or the district, since an application resume doesn't need it.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-9-canned-01f78181/6534dc41-d0d4-4ad9-9211-9b2f05ce114d/scratchpad/Halvering-Elementary_fourth-grade-teacher_interview_pack.md. I built it for a panel, since the invite names the principal and two team members. I had no job description and ran no outside research, so the questions rest on your resume and the invite.

The two gaps the panel is most likely to press are fourth grade and team lead. The pack's top rehearsal is A2, "Why should we hire someone who has never taught fourth grade?" Plan to hold on your six years of third grade and the 2024 reading move, then concede the gap plainly.

Say the word and I'll play the Skeptic on A2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the posting or full job description? Pasting it would ground the rest of the fit snapshot.
May I run a quick web check on Halvering's published values and interview process? It's public research and takes a few searches.
Did HR mention a demo, lesson plan or other deliverable for Thursday?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Halvering Elementary: Fourth Grade Teacher, panel interview prep

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Interview:** 45-minute panel on Thursday. Principal Dolores Vantongeren and two fourth-grade team members (names not given).
**Built from:** the HR invite and your resume text, plus your message. No job description, no outside research.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

| Type | Name | What it scores |
|---|---|---|
| VAL | Values / behavioral | Past behavior that shows a published value |
| EXP | Experience | Whether what you did, and what you did not, survives scrutiny |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company | Knowledge of the school's strategy. Not covered: no research was run |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding for a spoken answer, not a script. Each answer should fit in 90 to 120 seconds. In 45 minutes with three interviewers, expect roughly eight to ten questions. Rehearse A2, A1 and B1 first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Gate met on your material. Say it plainly: your license carries the elementary endorsement and is active through June 30, 2029. Expect a verification check; the state's educator license lookup is the artifact that would confirm it. |
| F2 | "Fourth Grade Teacher position" (invite title) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade" (your message) | medium | [grounded] | transferability | Adjacent work: elementary school, one grade down. Words: "For six years I taught third grade at a public elementary school in Joliet." Plain acknowledgment: "I haven't taught fourth grade." Answer slot: if any of your third-grade work carried into fourth-grade content, say which and how; if none did, say so and name what you would study first. |
| F3 | Works within and contributes to a grade-level team (role-family pattern, no source) [generic] | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've never been a team lead" (your message) | medium | [grounded] | transferability | Adjacent leadership at the scope of the move: words "I led our grade level's move to a new reading curriculum in 2024." Plain acknowledgment: "I've never been a team lead." Answer slot: if you had any other part in the grade level's work, say what it was; if not, say so. |

Seven rules the columns enforce: confidence, provenance and gap type each hold one token. Evidence cells hold only your sentences. Bridges speak at the scope of your quotes; none adds a practice, figure or event.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade, or fourth-grade experience | Negative you stated (F2), and the inflated form of F2 | "I've never taught fourth grade." Plain acknowledgment; no slot. |
| Team lead, or led a team | Negative you stated (F3) | "I've never been a team lead." Plain acknowledgment; no slot. |
| Chose or selected the reading curriculum | Inflated form of F3's quote. Your material says the move, not who selected the curriculum | "I led our grade level's move to a new reading curriculum in 2024," at its own scope. Your material does not show who made the selection; A3 and C3 hold that slot. |
| Built or ran a family communication program | Inflated form of "I write a weekly email to families" | "I write a weekly email to families." |
| Any figure you did not give: students, families, reading gains, club attendance | Silence in the material; no figure is coached | Name a number only if you have one; if you do not track it, say so (D1 to D3). |

## Persona weights

Relationship priors: a hiring-manager prior gives Skeptic and Case/Strategist. A peer prior gives Peer Evaluator and Data-Driven Prober. A panel blends the top two personas of each member's relationship. The principal decides, so the Skeptic leads. Team members are unnamed, so their personas are the peer defaults.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Principal | Probes the fourth-grade gap and the team-lead gap; asks why hire someone without fourth-grade experience | High. Both stated gaps are the ones a principal weighs first | Hold the six years of third grade and the 2024 move; concede the gaps specifically; never claim fourth-grade experience |
| Case / Strategist | Principal | A live problem from a fourth-grade classroom | Medium-high. The role's core is reading instruction | Clarify, then structure; think aloud; name the reading move only at its own scope |
| Peer Evaluator | Team members | Seam questions: planning together, disagreement, credit | High. Peer prior | Reciprocity framing: what you would need and what you would bring |
| Data-Driven Prober | Team members | How you knew the reading move worked; how many families read the email | Medium-high. Team members will want evidence | Say what you tracked; if nothing, say so |
| Conversational | Any | An opener about your path, and a closing "anything else?" | Medium. Casual questions are still scored | A 90-second arc; one prepared closing point |

## Question banks

Question column = the interviewer's line. Provenance precedes guidance.

### A. Skeptic (principal), weight high, 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What in fourth grade would you have to learn first?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" (your message) | Open with the six years, in those words. Then say plainly that you haven't taught fourth grade, and name the two or three things you would study first, in order. Answer slot: if any fourth-grade content has reached you through the third-grade work, say which; if none has, say so. | F2 is the requirement the title raises; this is the likeliest opener. |
| A2 | "Why should we hire someone who has never taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" (your message); "I led our grade level's move to a new reading curriculum in 2024" | **Highest-ROI prep in this pack.** Hold with the six years of third grade and the 2024 move, at the scope of those sentences. Then concede specifically: "I haven't taught fourth grade, so my first months would go to learning the fourth-grade year." Hold through two follow-ups by returning to third grade and the move. Never hold a claim of fourth-grade experience. | F2 is the transferability gap the title raises, and the objection a principal will press. |
| A3 | "What have you led, and what haven't you led?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" (your message) | Name the move in your own words. Then say, plainly: "I haven't been a team lead." Answer slot: if you led anything else on the grade level, say what it was and whose it was. | F3 is the team-lead gap; the question asks for the candidate's account of both sides. |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" (your message); "I've never been a team lead" (your message) | Name one honest weak point, not both as a flourish, then a ramp plan: what you would study and when you would ask the team to walk you through their year. | Skeptic stem, aimed at F2 and F3. |

### B. Case / Strategist (principal), weight medium, 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "It's October. Three students in your fourth-grade class read well below grade level. What do you do in the first two weeks?" | CASE | [generic]; "I led our grade level's move to a new reading curriculum in 2024" (your CV, if used) | Clarify first: what "below grade level" means on their assessment, what data exists, what the team already does. Then objective, options (small-group support, progress monitoring, a conversation with the team and family), and how you would know it worked. Think aloud. The 2024 move may be named only at its own scope. | The role's core is reading instruction; a live problem shows judgment without any claim about your past. |
| B2 | "What would you want to know about the fourth-grade team before you planned your first unit?" | CASE | [generic] | List what you would ask: the team's pacing, the assessments they already use, the reading materials in place, what students have covered. Make no claim about your past. | A CASE question about onboarding; the principal's stake is a safe first unit. |
| B3 | "Your after-school reading club: if a student stopped coming in January, what would you do?" | CASE | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Plan: reach out to the student and family, find out what changed, adjust the group. Answer slot: if this happened in the club, say what you did; if no such case came up, say so and give the plan. | The club is your strongest reading-instruction evidence; this tests how you would respond to it. |

### C. Peer Evaluator (team members), weight medium, 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans together every week. What would you need from us, and what would you bring?" | JD | [generic]; "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Reciprocity framing. Name what you would need (planning time, shared assessments, the year's pacing guide) and what you would bring: six years of third grade and the move, at its own scope. | A peer's load question; the reciprocity answer is the one they score. |
| C2 | "When you disagree with a colleague about how to teach something, what does that look like?" | VAL | [generic] | Pick a time you disagreed with a colleague over a plan or a method. Say what each of you wanted and how it resolved, whether or not you decided it. If no such time comes to mind, say so plainly and describe how you would raise a disagreement. | Peer stem on disagreement with equals; the theme comes from the persona, not from your past. |
| C3 | "Who else was part of the 2024 reading move, and what part was yours?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the others involved, if you know them, and your part in your own words. Answer slot: if others made parts of the call, say which; if you made the call alone, say so plainly. | Credit-sharing probe on your strongest leadership sentence; the answer must stay at its scope. |

### D. Data-Driven Prober (team members), weight medium, 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did you look at to judge the reading move, if anything?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Answer slot: if you tracked something, say what and when; if you did not track it, say so and say what you would track first. Never name a measure you did not track. | The team's most likely probe on your strongest sentence. |
| D2 | "Your reading club has run for two years. What tells you it's working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Answer slot: say what you have watched for; if you have counted anything, say what and how. If you have counted nothing, say so and what you would look at. | Prober's favorite follow-up: an outcome claim needs a basis. |
| D3 | "How many families read your weekly email, and how do you know?" | EXP | [grounded] "I write a weekly email to families" (your message) | Answer slot: if you know how families respond, say what you see and how you know; if you do not track it, say so. | Defend-the-number probe; the answer must match what you actually observe. |

### E. Conversational (any), weight low, 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about your path into teaching, and why this position interests you." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" (your CV) | A 90-second arc: six years of third grade, the 2024 move, the reading club, then why this position. Answer slot: the material gives no reason for this position; say it in your own words. | The panel opener; casual questions are still scored. |
| E2 | "Is there anything you'd like us to know that we haven't asked?" | EXP | [generic] | Choose one point you would want on the record, and say it in one sentence. Do not invent a new one for the moment. | The closing slot is scored for preparation. |

Requirement coverage: **Valid Illinois PEL with elementary endorsement** (invite): none, and why: the gate is met on your material; expect a verification check, which F1 answers. **Fourth Grade Teacher position** (invite title): A1, A2, A4, B2. **Team membership** (panel composition): A3, C1, C2, C3.

## Reverse questions

At least five; one is a peer reciprocity question. No interviewer profile was used, so none is tied to an interviewer's own path.

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a strong first year in fourth grade look like on this team?" | Shows you think in outcomes. Asked of the principal. |
| R2 | "What support does a teacher new to fourth grade get in the first six weeks?" | Names your gap usefully and invites a description of the actual support. |
| R3 | "How is planning divided across the grade team, and where does the team lead sit?" | Tests the team-lead gap without apologizing; shows you understand the structure. |
| R4 | "What could a new person do in the first month that would genuinely help your team?" | Reciprocity for the peers: it asks about their load, not your needs. |
| R5 | "Which part of the current reading plan is the team most keen to keep?" | Asks about their practice and lets them show it; ties to your reading experience. |
| R6 | "What do families most often ask the grade team about?" | Connects to your weekly family email. |

## Sources

- Provided: the HR invite (Human Resources, Orrinsford Community School District); your resume text; your message.
- Research tier: L0 — no searches. No user links read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Halvering Elementary values | unavailable | Not run: research waits on your consent, asked in the message. Would have moved the values cheat sheet, which is absent because no values round was detected |
| 2. Halvering interview process, fourth-grade role | unavailable | Not run (same reason). Would have moved the loop structure and persona weights |
| 3. Halvering strategy / recent news | unavailable | Not run (same reason). Would have moved any CO question |
| 4. Dolores Vantongeren, Halvering | unavailable | Not run (same reason). A name was given, so this is not n/a. Would have moved the principal's persona weights and a reverse question |
| 5. Representative fourth-grade teacher JD | unavailable | Not run (same reason). Would have grounded more rows, were no JD supplied |

## Upgrade menu

- The job posting or full JD text → the fit snapshot's role requirements become `[grounded]`, and the coverage line gets real rows.
- Your consent to a quick research pass on Halvering's values and interview process → a values cheat sheet if the school publishes values, and a loop structure for the persona weights.
- The two team members' names and roles → per-member persona weights in place of the peer defaults.
- Your consent to research Principal Vantongeren's public professional footprint → persona weights from her career, and a tailored reverse question.
- Any demo, lesson plan or written deliverable HR mentioned → a graded deliverable section.
- A copy of your license, or the state lookup page for it → F1 moves from medium to high confidence.
- Your own words for the answer slots (A1, A2, A3, B1, B3, C3, D1 to D3, E1) → each row regenerates with your quoted sentences, which become new material.
- A `tuesday-dossier.md` → records the gaps this prep exposed, for later sessions.
