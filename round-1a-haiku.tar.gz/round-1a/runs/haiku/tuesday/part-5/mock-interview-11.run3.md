Before I build a prep pack, I need the company name and the exact role title. Those are the minimum a pack can be built on.

One thing in the invite first. It says "Everything, from the interview through to your contract, is done right here over WhatsApp messages, so no calls or video are needed." A hiring process run entirely by chat, from a number you don't recognise, is a known scam pattern, though it doesn't prove this one is a scam. Until you've confirmed who sent it, don't send documents, bank details or any payment through this chat. To check, find the company's phone number or contact page on its own website or careers page, not in the message or through the number that contacted you.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Which company and role title is the interview for? The job advert or your application confirmation should show both.