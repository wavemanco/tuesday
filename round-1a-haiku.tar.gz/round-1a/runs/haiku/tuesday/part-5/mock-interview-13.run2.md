Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-13-denied-4eaf3715/e5bcadb3-fb38-4dd4-8c29-56fa19b46396/scratchpad/quillmoor_diagnostics_operations_coordinator_interview_pack.md. I built it for a 30-minute recruiter screen with Hannah, using the advert and your background as you wrote them. Company research didn't run because search permission was refused, so the pack has no values, interview-loop or strategy content.

The three things to rehearse most: the logistics answers (pay, hybrid, reason for moving, notice), the two real gaps (no SAP, and delivery scheduling rather than production or QA scheduling), and defending the "about a third" discrepancy figure. The pack gives the exact wording to use for each.

I can run a live drill on any of these: a Conversational question like "what's prompting the move?", or the Skeptic's "how would you bridge production and QA?". I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions. If you'd like a Word version of the pack, say so and I'll convert it.

Is your notice period something you can state? The pack has no figure for it, and the notice answer depends on it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_diagnostics_operations_coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** Recruiter screen, 30-minute phone call, Thursday 2pm, with Hannah Lowther (Talent Partner). She will call the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, the hybrid pattern, what is prompting the move, then the team and next steps.
**Built from:** the advert as you pasted it, and your background as you described it. No company research ran (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: EXP (your experience), JD (the listed job), CASE (a live problem), VAL (values), CO (company knowledge).
- Guidance is scaffolding, not a script. Say it in your own words, and only what you actually did.

## Prep triage

With a 30-minute call, do these in order:

1. **Logistics in one breath each:** pay (A3), hybrid (A4), reason for moving (A5), notice (A2). Hannah asked for all four, so they will be scored as logistics. Keep each answer to a few sentences.
2. **The two real gaps:** SAP or ERP (B2) and production or QA coordination (B1). Rehearse the plain acknowledgment and the bridge until they sound unforced.
3. **Defend the discrepancy figure** (C1). It is your strongest number and the likeliest place to be probed.

Everything else is insurance.

## Persona weights

Recruiter screens carry a relationship prior of Conversational plus light Skeptic. No interviewer profile exists, and no loop source establishes a loop. The fallback archetype is "Generic", so no values-style round is detected and no values cheat sheet is included.

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport Builder | 5 questions (top) | Friendly opener, then the four logistics items in a relaxed register | Highest. Hannah has already set the agenda, and screens are scored on logistics and motivation consistency | Treat every casual question as scored. Give the 90-second background (A1) and the logistics answers in plain words |
| Skeptic | 4 questions | Probes the mismatch between a delivery background and a production-and-QA role, and the missing SAP | High. The advert names production, QA and SAP, and your message says "Never used SAP" | Say the plain acknowledgment once, then the bridge. Do not bluff |
| Data-Driven Prober | 3 questions | Asks how the discrepancy figure was counted and what Excel you used | Medium. Your strongest number is also the one most likely to be checked | Name the weakest assumption before it is named for you. Say plainly what you do not know |
| Pressure / Stress | 3 questions | Pushes on the pay figure, the three-day ceiling and the Reading offer | Lower for a screen, but pay and location are where a screen can turn | Hold each position through two follow-ups. Concede only what is true |

This pack holds 15 questions, under the roughly 18 floor. A 30-minute screen cannot rehearse more, and every row above is a logistics or gap question that a longer pack would only repeat.

## Fit snapshot

Requirements are quoted from the advert you pasted. Evidence is quoted from your message, unless the Source column says otherwise.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" (advert) | "4 years as a logistics coordinator at a building-supplies wholesaler" (your message) | medium | [grounded] | none | Direct match. Say the title and the four years in those words. Expect a probe on scope, so say which depots and what you ran |
| F2 | "track supplier deliveries and chase late orders" (advert) | "I schedule deliveries for our three depots" (your message); "chase suppliers when orders slip" (your message) | medium | [grounded] | none | Your material reaches this requirement in your own terms. Say what you did: scheduled deliveries across three depots, and chased suppliers when orders slipped |
| F3 | "keep stock records accurate" (advert) | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | medium | [grounded] | none | A figure with limited inspectable proof, so expect a probe. Lead with the rebuild, then the figure, with "about" kept in |
| F4 | "confident with Excel" (advert) | "I rebuilt our stock-count spreadsheet" (your message) | low | [inferred] | discovery | Your material names a spreadsheet, not Excel, and says nothing about your skill level. Answer slot: name the features you used to rebuild it, in your own words. If it was not built in Excel, say so |
| F5 | "ERP experience (SAP or similar) a plus" (advert) | "Never used SAP — we run our own in-house stock system." (your message) | medium | [grounded] | transferability | Say the plain acknowledgment first: "I haven't used SAP." Then the adjacent work, quoted at its own scope: "we run our own in-house stock system." Learning SAP is a plan, not a past |
| F6 | "Coordinate production schedules between planning, the warehouse and QA" (advert) | "I schedule deliveries for our three depots" (your message) | low | [grounded] | transferability | Your material shows delivery scheduling, not production scheduling, and says nothing about planning or QA. Say what you scheduled and where the production side is new to you. Answer slot: if you have coordinated work across teams whose timings differed, say which; if you have not, say so |
| F7 | "report weekly on on-time dispatch" (advert) | none given | none | [generic] | discovery | Your material does not show dispatch reporting. Answer slot: if you reported on delivery timing, say what and how often; if you did not, say so and say how you would build it |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" (advert) | "two days at Avonmouth is fine, but I wouldn't want more than three" (your message); "I live in north Bristol" (your message) | high | [grounded] | none | Your own constraint, stated clearly. Say two days works and three is the ceiling |
| F9 | "£38,000–£44,000" (advert) | "I'm hoping for £42,000." (your message) | high | [grounded] | none | Your own figure, inside the advert's band. Say it once, in your own words |
| F10 | "your notice period" (Hannah's message) | none given | none | [generic] | hard_gate | Your material does not establish your notice period. Give your actual figure, in your own words. The one question below asks for it |

## Prohibited claims

Each entry names its basis. Honest form is the quote at its own scope, with any limit stated as the pack's observation.

| Not coached | Basis | Honest form |
|---|---|---|
| "I coordinated production schedules" | Inflated form of F2 and F6. Your material says deliveries | "I schedule deliveries for our three depots." The limit is this pack's observation: your material does not show production scheduling |
| "I know SAP" or "I have ERP experience" | Negative you stated | "I haven't used SAP. We run our own in-house stock system." No slot |
| "Advanced Excel" or "Excel expert" | Inflated form of F4 | "I rebuilt our stock-count spreadsheet." Features answer slot only |
| "I cut discrepancies by a third" | Inflated form of F3. Your sentence credits the figure to the sheet's fall over a year, not to you alone | "Discrepancies fell by about a third over a year." Keep "about", and say what was yours |
| "I reported on on-time dispatch" | Not in your material. Inflated form of F7 | None. Answer slot only |

## Question banks

### Conversational (5 questions, weight top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background, the short version." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" (your message); "I schedule deliveries for our three depots" (your message); "chase suppliers when orders slip" (your message) | A 90-second arc in this order: the role and four years; the three depots and the delivery scheduling; chasing suppliers when orders slip; the stock-count rebuild if there is time. Use your own words for each clause | F1 and F2 are the spine of this answer. The arc says only what those sentences say |
| A2 | "What's your notice period?" | JD | [generic] | Give your actual notice period in your own words. If it depends on something, say what, and say when you could start | A logistics slot for the notice item Hannah named. Your material does not give a figure, so none is supplied here (F10) |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." (your message) | Say £42,000 as what you are hoping for. You may ask for the band first if you want, and the advert gives £38,000 to £44,000. Your current salary is not something you are required to give; you can say what you expect instead | F9 fills the pay slot. The figure is yours and sits inside the band |
| A4 | "How do you feel about the hybrid pattern?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Two days at Avonmouth works. Three days is the most you would want. Say it plainly, once | F8 is a location gate. Your stated limit meets it |
| A5 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message) | State the closure first, then the relocation offer, in those terms. Do not criticise the employer. Do not add a reason your material does not give, such as growth or a career change | The reason-for-leaving logistics slot. The true answer is the closure, and that is enough |

### Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates production schedules across planning, the warehouse and QA. Your background is deliveries. How do you bridge that?" | JD | [grounded] "I schedule deliveries for our three depots" (your message) | Say what you scheduled: deliveries across three depots. Say the production side is new to you. Answer slot: if you coordinated work across teams whose timings differed, say which and how you handled it, in your own words; if you did not, say so and say what you would do first | F6 is the largest real gap. The question's premise comes from the advert, and the answer stays inside what your sentence carries |
| B2 | "Have you used SAP or another ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." (your message) | "I haven't used SAP. We ran our own in-house stock system." Then how you would learn it, as a plan. Do not describe any ERP as a past | F5. The plain acknowledgment is your own sentence, so you can say it aloud |
| B3 | "Why should I believe the discrepancy result was yours?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." (your message) | Say that you rebuilt the sheet, and the figure in those words. Answer slot: if the count process changed beyond the sheet, say what changed and who else was involved; if the sheet was the only change, say so | F3. Keep your attribution exact. This is a credibility question, not a trap |
| B4 | "What happens after you've chased a supplier twice?" | JD | [grounded] "chase suppliers when orders slip" (your message) | Say what you did. Answer slot: if you escalated anywhere, say where and what followed; if you did not, say what you did instead | F2. The escalation path is a practice the advert implies, so the second branch allows that you did not use one |

### Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the discrepancies, and what would the figure be sensitive to?" | EXP | [grounded] "discrepancies fell by about a third over a year" (your message) | Name the count method only if you know it. Name the weakest assumption you know of before they do. Say which part was yours. Answer slot: if you know how the figure was counted, say so in your own words; if you do not, say that plainly | F3. A figure you gave raises this defend-the-number slot. Do not reconstruct a method you cannot repeat |
| C2 | "How confident are you in Excel? Which functions do you use?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" (your message), with the advert's "confident with Excel" as the derivation | Answer slot: name the features you used to rebuild the sheet, in your own words. If it was not in Excel, say what it was | F4. The advert asks about Excel; your sentence says spreadsheet. The gap between them is the thing to answer honestly |
| C3 | "Do you report on on-time dispatch? How?" | JD | [generic] | Answer slot: if you reported on delivery timing, say what, to whom and how often; if you did not, say so and say how you would build the report | F7. The question asks about your past with a requirement the advert names, and your material is silent on it |

### Pressure / Stress (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The band tops out at £44,000 and you're asking for £42,000. Why not ask for more?" | JD | [grounded] "I'm hoping for £42,000." (your message) | Hold £42,000 through two follow-ups. Say it is what you are hoping for. Do not invent a reason beyond that. Concede only what is true | F9. Hold the figure, do not fold to restore harmony |
| D2 | "We need three days in Avonmouth. Would you do that?" | JD | [grounded] "two days at Avonmouth is fine, but I wouldn't want more than three." (your message) | Two days works. Three is the most you would want. Hold that position through two follow-ups | F8. Your stated ceiling is three. Do not agree to more to be accommodating |
| D3 | "Reading is the only offer, and you don't want it. Why not move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." (your message); "I live in north Bristol" (your message) | Hold: you live in north Bristol and do not want to relocate. Two follow-ups, then the plain position. Do not attack the employer's decision | A5 under pressure. The stated constraint is a location gate, and it is yours to hold |

## Requirement coverage

| Stated requirement (advert) | Covered by | Note |
|---|---|---|
| "2+ years in operations or logistics coordination" | A1 | |
| "Coordinate production schedules between planning, the warehouse and QA" | B1 | |
| "track supplier deliveries and chase late orders" | A1, B4 | |
| "keep stock records accurate" | B3, C1 | |
| "report weekly on on-time dispatch" | C3 | |
| "confident with Excel" | C2 | |
| "ERP experience (SAP or similar) a plus" | B2 | |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A4, D2 | |
| "£38,000–£44,000" | A3, D1 | |
| Hannah's logistics items: notice, reason for moving | A2, A5, D3 | |

## Reverse questions

Five or more, each with why it lands. Ask one or two, not all of them.

1. "What does a typical week look like for this role between planning, the warehouse and QA?" Why it lands: it shows you read the advert's three-way coordination line and want the real shape of it.
2. "How is on-time dispatch reported today, and who reads the weekly report?" Why it lands: it tests the requirement you have no story for, and asks for the answer rather than supplying one.
3. "What stock system does the team use now, and is any change planned?" Why it lands: it shows you have noticed the SAP line and want to know where it sits, without claiming experience you do not have.
4. "What's the next step after this call, and roughly when?" Why it lands: it is the question a recruiter expects, and it places you in the process without guessing its length.
5. "Who would I work with day to day?" Why it lands: it gives you the team picture Hannah has promised, and shows you care who you would work beside.

## Sources

- **Provided documents:** the advert text and your background, both as pasted in this conversation.
- **Searches sent:** "Quillmoor Diagnostics values" (refused: search permission was not granted). "Quillmoor Diagnostics interview process operations coordinator" (refused: search permission was not granted).
- **Target accounting**

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Would have fixed value names for a values cheat sheet, which only applies if a values-style round is detected. Both calls for this target were refused |
| 2. Quillmoor Diagnostics interview process | unavailable | Would have named the screen's loop and whether a values round exists. The fallback archetype stands in for now. The call was refused |
| 3. Quillmoor Diagnostics strategy or recent news | unavailable | Would have fed the CO bank and reverse questions. No call was sent, because search permission was not granted |
| 4. Hannah Lowther (public footprint) | unavailable | Would have fed the interviewer read and a tailored reverse question. No call was sent, because search permission was not granted |
| 5. Representative JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Hannah's prep email, if she sends one → confirms whether pay and notice are fixed agenda items and whether any other focus areas apply
- Your notice period, in your own words → fills logistics slot A2 with your figure (see the question below)
- Search permission granted → targets 1 to 4 run: values, loop structure, strategy and Hannah's public footprint
- Quillmoor's published values or careers page, pasted → checks for a values-style round, which would add a values cheat sheet
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → strategy brief and loop reports, which would sharpen the reverse questions
