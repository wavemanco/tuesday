Before the prep, one thing in the invite. It says "Everything, from the interview through to your contract, is done right here over WhatsApp messages," and it comes from a number you don't recognise. A hiring process run wholly by chat is a known scam pattern. Until you know who sent it, don't send money, documents or bank details through the chat, and don't treat the 11am slot as confirmed.

To check it, find the employer or agency through its own website or careers page, and contact them on a number or address you look up yourself, not one from the message. Ask whether they are running this interview. Having applied to a lot of roles doesn't prove this is one of them: the message says they "found your profile online," which isn't the same as you applying.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

To build the prep pack, I need the company name and the role title. Which company and role is this for?