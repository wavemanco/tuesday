Before the prep, one thing about the invite. It says the process is "fully remote and is carried out entirely on Telegram," and that "your offer and onboarding will be completed in this chat as well." A hiring process run wholly by chat, through to the offer, is a known scam pattern, though some real employers do interview by chat. It doesn't prove this one is fake. Before you reply or send anything, check that Marcus Hale and this interview are real: use the contact details on Lumenvale's own website or careers page, not the ones in the Telegram chat. Hold off on sending documents or bank details until then. I'm going only on what you've shared, and I can get this wrong. Please confirm who sent it. It's your call. If you want the invite weighed properly, job-underwriter can check it as a separate request.

Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-10-denied-4e9a6483/b087c861-48df-43ac-a225-554fcfdccbe1/scratchpad/lumenvale_customer_support_specialist_interview_pack.md`. I built it for a hiring-manager-style round with the support team lead, since your note didn't say who you're meeting.

**The main points:**

- **Your strongest match** is "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day". Say both in those words.
- **The biggest objection** is the software gap, and specifically the Zendesk line. Rehearse S2 ("Our ad asks for Zendesk. You use Freshdesk. How quickly would you be productive in our tool?") until your answer is calm. Name Freshdesk and describe a concrete plan to learn their tool.
- **Escalations and written clarity** are not shown anywhere in what you've told me. The pack leaves those as answer slots, not claims. Think of a real example for each before the interview.
- **Your background** is strong on volume and training. Don't stretch "trained four new starters" into designing the process.

I haven't run web research on Lumenvale, so company values and current news are unverified.

Three quick questions, which would reshape the pack:

1. Is Zendesk specifically required, or would a similar tool like Freshdesk be accepted?
2. Could you paste the full job ad? Your summary is what the pack is built on.
3. Is the person you're meeting the team lead who would manage this role, or a peer on the team?

Two offers, neither pushed: I can run a drill where I play the Skeptic on S2 and push back on your answer. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. A Word version of the pack is available too, if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** support team lead (name not given). Invite sent by Marcus Hale, talent team. Format: text-chat interview on Telegram.
**Round type:** hiring-manager-style interview. Built on that assumption.

## How to use this pack

Personas are how a question is asked. Types are what it scores: **JD** (stated requirement), **EXP** (what you actually did), **CASE** (live problem), **VAL** (values), **CO** (company knowledge).

Guidance is scaffolding, not a script. Rehearse in your own words, and only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" - your message | high | [grounded] | none | Your line already reaches the requirement. Say it as written: three years as a customer service advisor. |
| F2 | "Zendesk or similar ticketing tool" (job ad, as you summarised it) | "I use Freshdesk every day" - your message | high | [grounded] | hard_gate | Your material shows daily use of Freshdesk but does not establish that a similar tool meets the requirement. Whether it does is the question in the upgrade menu. Until then, say Freshdesk, in those words. |
| F3 | "clear written communication" (job ad, as you summarised it) | "answering around 60 calls and emails a day" - your message | low | [inferred] | discovery | The quote shows volume, not clarity, so the bridge must not stretch it. Answer slot: if anything you wrote was checked, reused or praised, say what it was; if you have no such example, say so and say how you would show clarity in this chat. |
| F4 | "confidence handling escalations" (job ad, as you summarised it) | "I trained four new starters on our refunds process last year" - your message (refunds, not escalations) | low | [inferred] | discovery | The quote touches refunds, not escalations. Answer slot: if you took a case that needed a supervisor or another team, say what it was and what you did; if you have not, say so and say how you would decide when to escalate. |
| F5 | No software background (stated by you) | "I've never worked for a software company" - your message | none | [grounded] | capability | A gap you stated. Words: "I've never worked for a software company." Then the nearest thing your material carries, at its own scope. |

Pack observation: your material does not show escalation handling or written clarity in your own words. The pack does not supply either.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Software or SaaS support experience | Negative you stated (F5) | "I've never worked for a software company." No slot. |
| Handling escalations as a routine part of the role | Inflated form of F4: your quote covers refunds training | The refunds quote at its own scope. A4 slot stays inside what you did. |
| Designing or writing the refunds process | Inflated form of "I trained four new starters on our refunds process" | "I trained four new starters on our refunds process." Trained, not designed. |
| A figure for how many customers you handled | Not in your material beyond the volume quote | Use "around 60 calls and emails a day" exactly. |

## Persona weights

Relationship prior: hiring manager (team lead). Starting weights: Skeptic and Case/Strategist. Depth follows weight.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Top (5 + 1 motivation) | Probes the software gap, the Zendesk gap, and the escalation gap | High. The ad lists three things your message does not show in your own words | Rehearse the single most likely objection (S2 below) until plain |
| Case/Strategist | Mid (4) | Live support scenarios from the queue | High. Team leads in support run cases | Clarify, then act, then close the loop |
| Pressure | Low (2) | Challenges "2+ years" or your claims | Medium | Hold the quoted position, then concede the software gap plainly |
| Conversational | Low (2) | Opens with "walk me through" | Medium. Casual questions are still scored | 90-second arc from your own sentences |

## Question banks

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Your background is in energy, not software. Why would you be good at supporting our product?" | JD | [grounded] "I've never worked for a software company" | Say the plain acknowledgment first: "I haven't worked for a software company." Then give the volume you did handle: "answering around 60 calls and emails a day". Do not claim the gap is closed. | F5 is the likeliest objection; rehearse it until it is calm |
| S2 | "Our ad asks for Zendesk. You use Freshdesk. How quickly would you be productive in our tool?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk in those words. Ramp as a plan, said as future: how you would learn the new tool in your first two weeks. Highest-ROI prep in this pack. | F2 is the most predictable objection |
| S3 | "Walk me through the hardest escalation you've handled. What did you decide?" | EXP | [generic] | Pick a real time a customer's problem went beyond your own authority. If you have none, say so plainly, then give the nearest thing your material carries: the refunds process you trained on. | F4 has no quote; the honest branch is the answer |
| S4 | "How would you write a reply to an angry customer whose refund is late?" | CASE | [generic] | Structure: acknowledge, state the action and its date, give the next step. Make no claim about your past. | Live problem from the role; no claim needed |
| S5 | "You trained four people on refunds. Did you write the process or deliver it?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Keep "trained". If you wrote any of the process, say which part. If you did not, say so, and say what you did as trainer. | Probes the verb; the honest answer is the trainer's role |
| S6 | "Why leave an energy supplier for a software company?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Give the real reason in your own words. Do not invent a story about wanting software. | Motivation probe; the answer must be yours |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer says their refund never arrived. Walk me through what you check first." | CASE | [generic] | Clarify: order, payment route, date issued. Then act and tell the customer the next step. | A live problem from the role |
| C2 | "Our queue spikes on Monday mornings. What would you do in the first hour?" | CASE | [generic] | Triage by urgency, then by age. Name what you would escalate. | A live problem; no claim about your past |
| C3 | "A customer was charged twice. Write two lines to them." | CASE | [generic] | Two lines: what happened, what happens next. Plain words. | Tests written clarity in a short form |
| C4 | "Show me how you would explain a delay in plain English." | JD | [inferred] "answering around 60 calls and emails a day" | Answer slot: say how you have explained a delay to a customer in writing or on a call, in your own words. If you have not, say so and show a two-line example. | F3's thin bridge; the clarity probe |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Three years is not two years of support work, is it?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Hold: three years in customer service. Hold through two follow-ups by returning to those three years. Concede only the specific gap: no software company. | Pressure on the years line |
| P2 | "Tell me about a time you held a line with an unhappy customer." | EXP | [generic] | Pick a real time you held a position without folding. If none comes to mind, say so plainly, then give the nearest thing your material carries. | Composure probe |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So — walk me through your journey." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | 90 seconds: role, volume, Freshdesk, refunds training. Your sentences, in order. | Casual openers are scored |
| R2 | "What are you playing with in support tools these days?" | JD | [grounded] "I use Freshdesk every day" | Name Freshdesk, and say what you use it for. Do not name tools you have not used. | Tests the tool requirement casually |

Total questions: 14. The pack is short because the material is a summary. The upgrade menu adds coverage.

## Reverse questions

1. "What does a new starter's first week look like?" Why it lands: shows you plan ahead.
2. "How does the team hand off cases that need engineering?" Why it lands: tests escalation know-how.
3. "Which ticketing tool does the team use day to day, and how do people learn it?" Why it lands: shows the tool gap is on your radar.
4. "What does a good first 90 days look like for this role?" Why it lands: asks for the standard.
5. "How does the team cover time zones when everyone is remote?" Why it lands: tests remote working, which the process depends on.

## Sources

Research tier: L0. No web search was run for this pack. Company values, loop structure and current news are not verified.

Provided documents: your message, and the recruiter's invite as quoted in your message.

## Upgrade menu

- The full job ad text → the six requirements above become `[grounded]` rows instead of your summary
- Whether Zendesk is required or a similar tool is acceptable → F2 moves from a hard gate to a stated fit or a stated gap
- Web research on Lumenvale (values, interview process, current news), at the default tier → company-specific questions and a loop structure
- Your own examples of written clarity and of escalations → F3 and F4 move from slots to quoted evidence
- The recruiter's prep email, if one arrives → coverage of anything announced in advance
