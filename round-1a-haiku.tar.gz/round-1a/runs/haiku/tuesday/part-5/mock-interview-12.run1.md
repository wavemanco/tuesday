Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account" before your interview is confirmed, to "reply with a photo of your passport and your bank details before the interview", and it offers a "cheque for €1,850" that you "deposit", then "send the balance on to the vendor". Paying fees, sending passport and bank details before any offer, and depositing a cheque and forwarding part of it are known scam patterns, and this job is very likely a scam. Don't pay anything, send documents or bank details, or deposit any cheque until you've checked the invite with the employer, using a phone number or address from its official website or careers page, not from this email. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite and posting checked properly, job-underwriter can do that as a separate request.

The prep below is for the interview itself, so use it only if you confirm the invite is genuine.

# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

**Round:** 30-minute video call with the office manager. Likely a hiring-manager-style round: short, so expect a skeptical read of your gaps and a few practical questions. Persona weights: Skeptic highest, then Conversational (the opener), then Case for the remote-working question.

## Fit snapshot

| # | Requirement | Your evidence (verbatim) | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | managing calendars | "ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your words already reach this: "I ran the appointment book for four physios." |
| F2 | booking travel | none given | none | [grounded] | discovery | Your material doesn't show travel booking. Answer slot: if you have booked travel for anyone, say what and for whom; if not, say so plainly and say how you would learn the booking tools. |
| F3 | preparing documents in Word | "good with Word" — your message | medium | [grounded] | presentation | "I'm good with Word." Give one document you produced in it, if you have one. |
| F4 | preparing documents in Excel | "okay with Excel" — your message | low | [grounded] | discovery | Your material says "okay", not more. Say that. Answer slot: if you've used Excel for a specific task, name it; if not, say so and say how you would get up to speed. |
| F5 | processing supplier invoices | "chased unpaid invoices" — your message | low | [inferred] | transferability | Chasing unpaid invoices is adjacent to processing supplier invoices, not the same. Say "I chased unpaid invoices" and nothing more. |
| F6 | remote working | none given | none | [generic] | discovery | Your material doesn't show remote working. Answer slot: if you have worked remotely, say how; if not, say so and say how you would keep on top of a day with nobody in the room. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars across a company | Inflated form of F1 | "ran the appointment book for four physios." The material shows one clinic, not a company's calendars. |
| Experienced or proficient in Excel | Inflated form of F4 | "okay with Excel." |
| Processed supplier invoices | Inflated form of F5 | "chased unpaid invoices." |
| Booked travel | Silence, not a listed claim | Answer slot only (F2). |

## Persona table

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic | "You've never processed supplier invoices, have you?" | High: your gaps are visible from your CV | Name the gap, then the adjacent work, in that order. |
| Conversational | Friendly opener, "walk me through your background" | High: short call, opener is scored too | Prepare a 90-second arc. |
| Case / Strategist | "How would you handle a week with three people wanting the same meeting room?" | Medium | Clarify first, then state your steps. |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Clinic, the appointment book for four physios, chasing unpaid invoices. About 90 seconds. | Opener; F1 and F5 are both in it. |
| A2 | "How have you managed someone's calendar?" | JD | [grounded] "ran the appointment book for four physios" | Describe how you kept four diaries in order, in your own words. Answer slot: if you dealt with clashes or rescheduling, say how; if not, say so. | F1 is your strongest match for calendars. |
| A3 | "Have you booked travel before?" | JD | none given | Answer slot: if you have, say what and for whom; if not, say so plainly and say how you would learn the booking tools they use. | F2 has no evidence. Don't invent travel experience. |
| A4 | "Show me a document you've prepared in Word." | JD | [grounded] "good with Word" | Name one document and what it was for. Answer slot: if you have none, say so and describe how you would produce one. | F3 is a self-rating, so an example is what makes it credible. |
| A5 | "How comfortable are you in Excel?" | JD | [grounded] "okay with Excel" | Say "okay", then name one task you have done in it, if any. Answer slot: if none, say so and how you would get up to speed. | F4 is low confidence. Don't upgrade "okay". |
| A6 | "Have you processed supplier invoices? How is chasing unpaid ones different?" | JD | [grounded] "chased unpaid invoices" | Highest-ROI prep. Hold: "I chased unpaid invoices." Answer slot: if you entered or matched supplier invoices, say how; if not, say so and stay with the chasing. Hold through two follow-ups by returning to what you did. | F5 is the requirement most likely to be probed, and the biggest gap. |
| A7 | "Why are you moving from clinic reception into remote admin?" | EXP | none given | Answer slot: give your own reason in your own words. | No reason is in your material. |
| A8 | "How do you keep on top of a day when nobody is in the room?" | CASE | [generic] | Structure: how you plan the day, how you check in, how you flag problems. Makes no claim about your past. | F6. |

## Requirement coverage

- Managing calendars: A2
- Booking travel: A3 (no evidence)
- Preparing documents in Word: A4
- Preparing documents in Excel: A5
- Processing supplier invoices: A6
- Remote working: A8 (no evidence)

## Reverse questions

1. "What does a typical week look like in this role?" It shows you want the job, not just any job.
2. "Which tools would I use day to day for calendars, travel and invoices?" It tests whether the job is what the ad says.
3. "How is the work split between you and the rest of the team?" It reveals whether the role is a real admin job or a catch-all.
4. "What would you want this person to have done in their first 90 days?" It asks for their expectations directly.
5. "Who approves supplier invoices here?" It shows you've thought about the invoice part of the role.

## Upgrade menu

- The full job ad text → the six rows above become checkable against the real requirements.
- The office manager's name → a tailored reverse question.
- A `tuesday-dossier.md` recording your gaps from this prep → carries them into later sessions.

Want a 5-minute drill on A6, the invoice question? And should I save this pack as a Word document?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.