**Status: `no_go`.** Don't pay anything, deposit the cheque, or send your passport or bank details, and don't prep for this interview on these terms. The email asks you to do three things a real interview doesn't need, and this job is very likely a scam. I can't confirm the firm from here, because my search tool was refused in this session.

**Fit ledger** (your background against the ad; self-rated and CV-only claims stay at `medium` or lower)

- `must_have`: `direct` — R1 (calendars, from running the appointment book for four physios, `medium`), R3a (Word, `medium`); `adjacent` — R3b (Excel, `low`, self-rated)
- `important`: `adjacent` — R4 (supplier invoices, `medium`); `absent` — R2 (booking travel)

R1 is your strongest match. R4 is the nearest but on the wrong side: chasing unpaid invoices is receivables, not processing supplier bills, so the limit is the payables side. R2 has no evidence at all.

**Opportunity ledger.** RR1 to RR3 are confirmed severe requests. RR4 is unresolved. RR5 is a positive: the duties are specific and conventional.

**Hard gates:** none stated; candidate constraints not given, so checks against them are unknown. The posting gives no pay. The €1,850 cheque is not pay.

**Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`)

**Risk register**

- **RR1: fee before any offer** (`red_flag`, `severity: high`, confirmed)
  - Quote: "transfer the €95 equipment registration fee to our supplier's account, IBAN ..."
  - Hypothesis: you are asked to pay a third party before any employment. `[grounded]` from the wording; `[generic]` that paying for equipment up front is a known scam pattern.
  - Verification question (to the employer): "Does Brennock charge candidates any fee for equipment or registration?"
  - Decision rule: pay nothing. This job is very likely a scam. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.
- **RR2: cheque to deposit and forward** (`red_flag`, `severity: high`, confirmed)
  - Quote: "Successful candidates receive a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor."
  - Hypothesis: this is an overpayment setup. A cheque can be returned after it seems to have cleared, and you would owe the bank the balance you sent on. `[generic]`
  - Verification question: "Do you issue equipment cheques to new hires, and do you pay the vendor directly?"
  - Decision rule: don't deposit the cheque or send any balance.
- **RR3: passport photo and bank details before interview** (`red_flag`, `severity: high`, confirmed)
  - Quote: "reply with a photo of your passport and your bank details before the interview."
  - Hypothesis: ID and bank details are not needed before an interview. This would be routine only after a written offer naming the role and pay, and this is an interview invite. `[grounded]`
  - Verification question: "At which stage do you collect passport and bank details, and through what secure system?"
  - Decision rule: send neither.
- **RR4: employer not established** (`risk_signal`, `severity: medium`, unresolved)
  - Quote: "hr@brennock.example"
  - Hypothesis: the employer could not be attributed here, but the search was refused, so this is not yet a research finding. The domain ends in `.example`, a reserved name that doesn't belong to a live company. `[grounded]` from the address. Possible reasons, none ranked: the email isn't from the employer, it was mistyped, or the sender is not who it names. Severity stays `medium` because the payment requests already carry the weight.
  - Verification question: "Can you point me to this role on Brennock's own careers page, and confirm the hr address is yours?"
  - Decision rule: check the employer through contact details you find yourself, on its own website or in the Irish Companies Registration Office register. `[generic]`
- **RR5: specific duties** (`positive_signal`)
  - Quote: "managing calendars, booking travel, preparing documents in Word and Excel, and processing supplier invoices"
  - Hypothesis: a conventional admin scope, a pattern rather than a finding about this firm. `[generic]`
  - Verification question: "What does a typical week look like, and who would I report to?"

**Research tier: L1 — searches 2 of 5, fetches 0 of 2**

| Target | Status | Reason |
|---|---|---|
| L1-1: company's official site and careers page | unavailable | Both search calls were refused (permission not granted), so the firm could not be attributed |
| L1-2: role-family sweep for title and pay | unavailable | Search refused; the posting states no pay |
| L1-3: hiring manager's public footprint | n/a | No name given; the email is signed by no one |

**Gap recovery queue** (no questions here)

- R2, travel booking (`absent`): no evidence. Closure path: any travel booking you've done, even for yourself.
- R3b, Excel (`adjacent`): self-rated only. Strengthener: an example workbook you built.
- R4, supplier invoices (`adjacent`): the limit is payables. Strengthener: any invoice-approval or payment step you handled.

**Application plan.** Don't apply further or accept this interview until the employer is verified through contact details you find yourself. Don't reply with documents or money. If the employer verifies and invites you again, the duties fit your Word and calendar experience. In that case, mock-interview can build the prep.

**Dossier offer:** At the natural end of this, I can save this assessment as a `tuesday-dossier.md` for later sessions if you want one.

**Upgrade menu**

- A live posting link or the employer's own careers page would confirm or clear RR4 and the duties.
- Your remote-work, pay and schedule constraints would let the hard-gate checks run. They are unknown now.
- Search access would let me run the company check and a pay band. Both targets are unavailable in this session.

**Questions**

1. Have you sent anything yet: the €95, a cheque, a passport photo, bank details, or a reply containing any of them?
2. Where did you see the ad, and do you have the link?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.