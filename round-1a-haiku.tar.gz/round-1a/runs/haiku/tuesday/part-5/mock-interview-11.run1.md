**Decision snapshot**
- **Opportunity:** not assessable yet. No job description, company name or role title has been provided.
- **Decision:** `hold_pending_answers`. Don't accept the 11am slot, and don't send ID, bank details, or money until the sender is verified.
- **Fit:** not assessable. No posting or CV was provided.
- **Hard gates:** unknown. Pay, location, authorization and schedule are not stated.
- **Opportunity risk:** high on the message's own terms.

Research tier: L0, no searches. There is no named company or agency to search for.

**Red flags in the message**
1. **No employer named.** The sender is "Jess, a recruitment consultant" from an unknown number, with no firm, client or job title. `[grounded]`
2. **The whole process runs on WhatsApp, with "no calls or video."** Legitimate hiring is rarely done end to end on a personal messaging app. Refusing every verifiable channel is a common feature of fake-job schemes. `[generic]`
3. **An interview is booked for tomorrow before any conversation about the role.** Urgency like this is a pressure tactic. `[generic]`
4. **The lure is vague:** "remote", "flexible hours", "found your profile online". No pay, duties or employer are given. `[grounded]`
5. **Contract handled over chat.** In these schemes, the next requests are usually for ID, bank details, or a payment for equipment or training. `[generic]`

This could still be genuine. Some agencies do use WhatsApp, and one of your applications may have reached a real firm. Nothing in the message confirms it, though.

**Checking whether it came from one of your applications**
- Find the original posting or your application confirmation email. Does it name this agency or Jess?
- If you can't find it, treat the message as unverified.
- Reply asking for the role, the client company's name, and a message from a company email address. A real recruiter can do this easily.
- Contact the firm through the number or email on its official website, not through the sender's details.

**Interview prep:** I'd hold off on preparing for this interview until the opportunity is verified. Once there's a confirmed role, the mock-interview module can build your prep pack.

I can save these findings to a `tuesday-dossier.md` file if you want a record to come back to.

**What would move this assessment:**
- The original job posting or link, plus the job board you applied through. This would let me check the role's requirements, pay and location against you.
- Your CV or a short background summary. This would let me assess fit requirement by requirement.
- The company or agency name, if the posting gives one. This would let me run a light public-web check, up to 5 searches and 2 page fetches.

1. Can you paste the job posting or share its link, and tell me which site you applied through?
2. What is the full name of the company or agency Jess says she works for? Does the original posting name it?
3. Would you share your CV, or a short summary of your background, so I can check fit once the role is confirmed?

Answer any of these, or reply "skip" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.