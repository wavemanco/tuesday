Your Social Security number is on the resume, and I didn't use it or repeat it. An employer doesn't need it on a resume or in interview prep. Remove it before you send the resume to anyone.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-5-rooms-case-9-canned-9a121c82/c986df86-d9e6-4627-9aa9-4f5679716fdb/scratchpad/Halvering_fourth-grade-teacher_interview_pack.md`. I built it from the invite and your resume only, with no web research, since no job posting was supplied.

**What the panel will likely probe**

- **Fourth-grade experience is the main gap.** Your six years of third grade are adjacent, not the same. The principal will probably open with it. Your answer: say plainly that you haven't taught fourth grade, then give a concrete plan for the first months. This is the highest-value thing to rehearse.
- **Team leadership is the second gap.** You've never been a team lead. Don't stretch "I led our grade level's move to a new reading curriculum" into team leadership. Say what you did at its real scope, and be ready for "how much of that was actually you?"
- **Your reading work has no numbers.** The peers may ask how you measured the reading club or the curriculum move. If you measured anything, say what and how. If not, say so and say what you'd track.

**Who asks what:** the principal gets a skeptic and a case-style problem. The two team members get a peer-collaboration angle and a data probe. The pack has 18 questions, each with guidance and a provenance line showing which of your sentences it rests on, plus five reverse questions to ask them.

**Questions for you**

1. Does the panel have any focus areas, or a demo lesson or other assignment? Do you know the names of the two team members?
2. Can you paste the full job posting? Right now the requirements are inferred from the title and the license line, so a posting would sharpen the questions.
3. Do you want me to research the school, the district, and the principal's public background? That would add context and tailor the principal's questions. It takes a few searches.

Offers: I can run a live mock drill with the principal, starting with the fourth-grade question, and I can save a `tuesday-dossier.md` recording the gaps this prep exposed. I can also convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview Prep Pack: Fourth Grade Teacher, Halvering Elementary (Orrinsford Community School District)

**Format:** panel, 45 minutes, Thursday. Principal Dolores Vantongeren plus two fourth-grade team members (names not given).
**Research tier:** L0. Built from the invite and the resume only. No web research has run.
**Relationship:** principal (supervisor) and two peers.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the role), CO (company), CASE (a live problem).
- Guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds.

## Fit snapshot

No job posting was supplied. The invite gives the title and one requirement. Other rows are role-family patterns, marked [generic].

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | Gate shown met by your CV. No gap. Have the license details ready. |
| F2 | "Fourth Grade Teacher" (invite title) | "Six years teaching third grade at a public elementary school in Joliet" (your CV); "I've never taught fourth grade." (your message) | medium | [grounded] | transferability | Third-grade work is adjacent, not fourth-grade work. Words: "I have taught third grade for six years. I haven't taught fourth grade." Then a plan. The bridge stops there. Answer slot: how your third-grade work carries into fourth, in your own words, and what you would do in the first weeks. |
| F3 | Team leadership: [generic] a grade-team role usually involves leading parts of the team's work; not stated in the invite | "I've never been a team lead." (your message) | none | [grounded] | capability | Stated absence. Words: "I haven't been a team lead." Then how you would learn to work with a grade team, as a plan and never as a past. |
| F4 | Reading instruction and curriculum: [generic] | "I led our grade level's move to a new reading curriculum in 2024." (your CV) | medium | [grounded] | none | Reaches the reading requirement in role terms. Use the sentence at its own scope: a grade-level move. Do not widen it to school-wide or to team leadership. |
| F5 | Reading support beyond the classroom: [generic] | "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | none | Reaches the requirement. Results are not stated; see C1. |
| F6 | Family communication: [generic] | "I write a weekly email to families." (your CV) | medium | [grounded] | none | Reaches the requirement. Contents and response are not stated; see C3. |

**Requirement coverage**

| Requirement | Question IDs |
|---|---|
| Valid IL license (gate) | F1; no question needed |
| Fourth-grade teaching (title) | A1, A2, E2, F3 |
| Team leadership ([generic]) | A2, A3, F3 |
| Reading instruction and curriculum | B2, C1, C2, D2, F2 |
| Family communication | C3, D1 |
| Other requirements | None stated in the invite, and no posting supplied. Every JD-tagged question is therefore drawn from the title, the invite's gate, or [generic] patterns. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has been a team lead, or has led a team | Inflated form of F4: "led our grade level's move" widened to team leadership | F4's quote at its own scope. Pack observation: your material shows one grade-level curriculum move, not team leadership. Plain acknowledgment from F3: "I haven't been a team lead." |
| Has taught fourth grade, or has fourth-grade experience | Negative you stated, F2 | "I haven't taught fourth grade." No answer slot. |
| Led the reading curriculum school-wide or district-wide | Inflated form of F4's scope | F4's quote. The move was at grade level. |

## Persona weights

Panel rule: each member's relationship sets their personas. The principal gets Case and Skeptic. Peers get Peer Evaluator and Data-Driven Prober. Conversational and Pressure are low weight for a 45-minute panel.

| Persona | Who | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Skeptic | Principal | top (4 questions) | "I don't see fourth-grade experience"; weak points on day one | The invite is for a fourth-grade role and your record is third grade. The principal will test that gap first. | Name the gap in your own words, then a plan. |
| Peer Evaluator | Team members | top (3 questions) | Seams between grades, disagreement, credit | Peers price what a hire costs their work. | Reciprocity: what you bring the team, not only what you need. |
| Data-Driven Prober | Team member | mid (3 questions) | How was it counted, what changed | Your reading work has no numbers in the material, so expect the question. | Say what you measured, or say plainly that you did not. |
| Case / Strategist | Principal and team | mid (2 questions) | A live class problem | The role is a live classroom. | Clarify, then objective, then approach. |
| Conversational | Opener | low (2 questions) | "Walk me through your journey" | Panels often open this way. It is still scored. | A 90-second arc. |
| Pressure | Principal | low (2 questions) | Sixty-second challenges | A 45-minute slot is short, so challenges come quickly. | Hold, then concede specifically. |

## Question banks

Provenance: the sentences each row's guidance rests on, quoted as they appear in the fit snapshot.

### A. Skeptic (principal), weight top

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see fourth-grade experience on your resume. How would you handle the first months of teaching fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade." | Say the third-grade years and the fourth-grade gap in those words. Then the plan: what you would learn about fourth-grade content and team routines first, and whom you would ask. The plan is future tense and names no past. | F2 is the most likely objection in this panel. This is the highest-ROI prep in the pack. The premise is your own stated negative. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the two honest weak points: fourth-grade content, and working as a grade-team member without having led one. Give a ramp plan for each. Do not claim either is already covered. | Skeptic stem. [generic] because it asks for a pattern, not a fact about you. |
| A3 | "You haven't been a team lead. What would you need to learn to work with a grade-level team?" | JD | [grounded] "I've never been a team lead." | Plain acknowledgment: "I haven't been a team lead." Then what you would need to learn and how you would find out, such as asking the principal or observing the team's planning. Claim no past leadership. | F3 is a capability gap. The likely form is a learning question. |
| A4 | "What draws you to Halvering specifically?" | EXP | [generic] | Answer in your own reasons. The material does not give your reasons, so this is an answer slot: give your actual reasons in your own words. Name nothing about the school that the invite does not say unless you have checked it. | Motivation probe. [generic] because it asks about your reasons, not a stated fact. |

### B. Peer Evaluator (team members), weight top

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "We teach side by side. Where is the seam between third and fourth grade, and what happens when we disagree about pacing?" | JD | [generic] | Propose seam principles rather than pretending to know the seam, for example how students are handed off and how assessments are shared. Answer slot for disagreement: if you have a time you disagreed with colleagues about instruction, describe it in your words; if not, say how you would raise a disagreement. | Peer seam probe. The seam is not in any source. |
| B2 | "Tell us about the reading curriculum move. What did you do, and what did your colleagues do?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024." | Tell the move as the sentence states it: a grade-level move in 2024. Answer slot: which decisions were yours and which were the grade's. If the grade decided together, say so and say what you did. | Peers test credit sharing. The sentence's scope is the grade level, not the school. |
| B3 | "How do you share credit when a team effort goes well?" | VAL | [generic] | Use "we" for the team's work and "I" for what you did. Tie it to B2 only if B2 is the example you use. | Peer stem. [generic]. |

### C. Data-Driven Prober (team member), weight mid

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you measure the reading club's effect on the students who attended?" | EXP | [grounded] "I've run the after-school reading club for the last two years." | Answer slot: if you measured anything about the club's readers, say what and how it was counted. If you did not measure it, say so and say what you would track. | A prober asks for the denominator. No figure is in the material, so no defend-the-number slot applies. |
| C2 | "What did you look at to judge whether the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024." | Answer slot: say what you looked at, in your words. If you did not assess the curriculum's effect, say so and say what you would look at now. | The question presumes a curriculum move, which the sentence states. It presumes no outcome. |
| C3 | "How do you know your weekly family emails are doing their job?" | EXP | [grounded] "I write a weekly email to families." | Answer slot: describe what the email covers and how you know it reaches families, in your words. If you have no feedback on it, say so. | Probe on whether the claim is backed. |

### D. Case / Strategist (principal and team), weight mid

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A student who finished third grade reading at a second-grade level is in your fourth-grade class in October. What do you do in the first two weeks?" | CASE | [generic]; [grounded] "I write a weekly email to families." | Clarify: what assessment you would use and what the student's records show. Then objective, approach, and who you would tell. Mention the family email as the existing channel, in the sentence's own terms. | A live problem from the role. The question asks about no past of yours. |
| D2 | "Your fourth-grade team wants a shared approach to the reading block. Sketch how you would start." | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024." | Clarify what the team already uses and what it wants. Then objective, approach, and how you would know it works. Refer to the 2024 move only as the sentence states it. Do not describe its outcome. | Tests whether you think at team altitude. |

### E. Conversational (opener), weight low

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey to teaching." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years." | A 90-second arc using only those sentences, in your own words: the license, six years of third grade, the 2024 curriculum move, the reading club. Stop there. | Casual register, still scored. |
| E2 | "Tell us about the reading club you run." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Describe the club in your words: how long you have run it and what happens in it. The material does not describe the club, so you supply those details yourself. | Casual register. A rapport question that is still scored. |

### F. Pressure (principal), weight low

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we pick you over a candidate who's taught fourth grade?" | JD | [grounded] "I've never taught fourth grade."; "Six years teaching third grade at a public elementary school in Joliet" | Pause and restate the question. Then: "I haven't taught fourth grade. What I bring is six years of teaching third grade and a grade-level reading curriculum move in 2024." Hold through two follow-ups. If pressed, concede specifically: "That is a real gap, and here is how I would close it." Never fold the core claim. | Time-boxed challenge on your largest gap. |
| F2 | "That reading curriculum move. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024." | Hold the sentence: a grade-level move in 2024. Say which parts were yours and which were the grade's. If parts were the grade's, say so. Concede only what you cannot back. | Pressure on credit. The honest answer is the attribution. |
| F3 | "You've taught one grade for six years. Why should we trust you with another?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Hold: the six years are real and specific. Then say what transfers and what does not, and concede the second part plainly. Do not claim fourth-grade work. | A second pressure line on the same gap. Hold, then concede. |

## Reverse questions

Each has a reason it lands. The pack has no interviewer profile, so none of these is tied to an interviewer's own path.

1. "What would a new teacher do in their first month that would genuinely help your team?" Why it lands: a reciprocity question for the peers. It shows you want to contribute, not just to be hired.
2. "Where does the fourth-grade team plan together, and how often does it meet?" Why it lands: it shows you are thinking about how the team works, which matters given your team-lead gap.
3. "How is the reading block set up in fourth grade now, and who decides the curriculum?" Why it lands: it links to your 2024 curriculum work and shows you know the question is about decisions.
4. "What would make this role a success at the end of the first year?" Why it lands: a principal's question. It turns the panel's weakest point into a stated standard.
5. "What does the principal see as the first-year priority for this role?" Why it lands: it invites the Skeptic to name the gap in their own words, so you can answer it directly.

## Upgrade menu

- Panel members' names → persona assignment per member, and reverse questions tied to their public paths.
- Full job posting text → the rows resting on the invite's title and license become grounded, and the [generic] requirements get tested against the real list.
- Any scheduled demo lesson or other pre-declared deliverable from HR → a build section for each one.
- Deep research (after your consent) → school and district context, and the principal's public footprint for persona weights.
- A `tuesday-dossier.md` file → carries verified evidence and the prohibited claims into later sessions.
