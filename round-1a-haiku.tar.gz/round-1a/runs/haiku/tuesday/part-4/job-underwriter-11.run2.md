**Duinvaart: worth applying to, on conditions (`conditional_go`). Kroonhaven: not worth your time now (`no_go`).**

## 1. Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Decision snapshot: `conditional_go`.** Your core skills match most of the role. The gaps are cold-chain data and the Dutch level, and the employer is not yet checked.

**Fit ledger.**
- `hard_gate`: unclear: R1
- `must_have`: direct: R2, R3, R4, R5; absent: R6
- `important`: direct: R7
- `preferred`: adjacent: R8

R6 (temperature compliance) is the one real gap. R8 (Dutch) is adjacent, with the limit named: conversational, not fluent.

- **Hard gates:** none failed; unconfirmed: R1 (hybrid, three days in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** the posting is specific about outputs and scope (RR3). Salary is withheld and the employer is unverified (RR1, RR2).
- **Conditions for go:** (1) the posting is confirmed on Duinvaart's own careers page; (2) your commute to Rotterdam three days a week works; (3) the application says plainly that you have no cold-chain data work yet.

**Role reality.** Ops analyst for a refrigerated fleet: on-time delivery, temperature compliance, weekly Power BI dashboards, and route changes with depot managers. `[grounded]` posting. No salary and no market band, because the salary search was declined (see research line).

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning / next action |
|---|---|---|---|---|---|---|
| R1 | Hybrid, 3 days/week, Rotterdam office | hard_gate | unclear | none | hard_gate | Your location is not given. Q-R1 |
| R2 | 2+ yrs logistics or ops analysis | must_have | direct | medium | none | Four years as an ops analyst at a parcel carrier. CV-only, so `medium`. `[grounded]` your intake |
| R3 | Strong SQL | must_have | direct | medium | none | Used daily. No artifact yet |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Used daily |
| R5 | On-time delivery tracking | must_have | direct | medium | none | Your message says the depot managers use the dashboard. It does not say you built it. Q-R5 |
| R6 | Temperature compliance, refrigerated fleet | must_have | absent | none | transferability | No temperature or cold-chain data on your CV. The on-time work carries over; the domain does not. Q-R6 |
| R7 | Route changes with depot managers | important | direct | medium | none | Ran the weekly route-performance review |
| R8 | Dutch | preferred | adjacent | medium | transferability | Conversational, not fluent. "A plus," so not a gate |

**Opportunity risk register.**

| # | Signal | Class | Severity | Verification question | Status |
|---|---|---|---|---|---|
| RR1 | Salary withheld | unknown | — | What is the salary range for this role? | unresolved |
| RR2 | Employer not yet verified | unknown | — | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Outputs and scope named in the posting | positive_signal | — | Who owns the temperature data today, and who would I work with at the depots? | noted |

RR2 is unchecked, not a finding against the employer. Searches were declined, so the employer may be real and simply unverified.

**Application plan.**
- **A1 (your action):** find this posting on Duinvaart's own careers page before you apply. Anything you find elsewhere is not verified.
- **A2:** `resume_edits_pending_approval`. Use your own sentence: "SQL and Power BI daily, including the on-time delivery dashboard our depot managers use." Do not change "used" to "built" unless it is true (Q-R5).
- **A3:** `pending your approval`. In the application, say you have no cold-chain data work yet and name the temperature-tracking piece as what you would learn.

## 2. Supply Planner, Kroonhaven Foods, Utrecht

**Decision snapshot: `no_go`.** Three must-have requirements are absent from your record, and nothing in your current experience closes them within this role. This is about fit, not the posting, which is clear.

**Fit ledger.**
- `hard_gate`: unclear: R1
- `must_have`: absent: R2, R3, R4; adjacent: R5; unclear: R6
- `important`: adjacent: R7

R2, R3 and R4 are the planning core: no evidence, and a years-based requirement that a course does not close. R5 is conversational Dutch against a fluent requirement. R6 (advanced Excel) is untested, and the verdict does not depend on it.

- **Hard gates:** none failed; unconfirmed: R1 (on-site Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a real planning-analyst path. Your record shows no capacity or forecast ownership, and no planning-system experience, so the verdict stands for this posting.

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning / next action |
|---|---|---|---|---|---|---|
| R1 | On-site, Utrecht | hard_gate | unclear | none | hard_gate | Your location is not given. Q-R1 |
| R2 | 3+ yrs FMCG supply or demand planning | must_have | absent | none | capability | No planning experience on record. Closure is years in planning roles |
| R3 | SAP IBP or similar planning system | must_have | absent | none | capability | No planning-system experience |
| R4 | Own a 13-week plan; balance capacity vs forecast | must_have | absent | none | capability | No capacity or forecast ownership on your record |
| R5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational. Treated as a must-have, not a gate, because language is not in the gate list. Confirm with the employer if it matters to you |
| R6 | Advanced Excel | must_have | unclear | low | discovery | Your CV is silent. SQL and Power BI suggest analysis, not Excel modelling |
| R7 | Weekly S&OP-style meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. That is a performance review, not a supply-demand decision meeting |

**Application plan.**
- **A4 (your action):** do not apply to this posting now.
- **If you want the planning route:** search for planning-analyst or demand-analyst titles, where your analytics could count as direct. I have not checked whether such roles exist or what they ask for.

## Research

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both employer searches were declined. Neither employer's existence, careers page or live posting is checked. This moves RR2 and the Duinvaart condition |
| 2. Role-family sweep | unavailable | The supply-planner requirements search was declined. No market band is given for either role; salary calibration is not possible |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Evidence status.** Verified: none yet. Your background is self-report from the intake message, so it is leads, not proof.

I can write both assessments to a `tuesday-dossier.md` you can keep and reuse.

**Upgrade menu**
- Allow web search, and I will run the two employer checks and the salary sweep. Those calls are the ones declined above, so this is your call.
- The live Duinvaart posting URL, or the link from its careers page. This verifies RR2.
- Where you live. This settles R1 for both roles.
- Any temperature, sensor or condition data from past work. This would move R6.
- A dashboard screenshot or sanitized report you used. This would raise R3, R4 and R5 from `medium` to `high`.
- Excel evidence. This would settle R6 on Kroonhaven, though the verdict stands either way.

**Questions**
- **Q-R1 (Duinvaart R1; Kroonhaven R1):** Where do you live, and can you get to Rotterdam three days a week?
- **Q-R5 (Duinvaart R5):** Did you build the on-time delivery dashboard, or use one your team built?
- **Q-R6 (Duinvaart R6):** In your current work, did any dashboard, report or review cover temperature, condition or sensor data?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.