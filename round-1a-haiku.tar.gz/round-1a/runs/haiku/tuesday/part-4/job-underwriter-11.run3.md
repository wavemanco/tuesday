## Role 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R9 (Rotterdam, three days a week; your location and work authorization are not in the input)
- `must_have`: direct: R1 (ops analysis, 2+ years), R2 (SQL), R3 (Power BI); adjacent: none
- `important`: direct: R4 (weekly Power BI dashboards), R5 (on-time delivery tracking), R7 (depot-manager work, route changes); adjacent: R6 (temperature compliance)
- `preferred`: adjacent: R8 (Dutch, conversational)

Your three must-haves line up with your stated background. Your gap is temperature compliance, which is outside your parcel-carrier work.

- **Hard gates:** none failed; unconfirmed: R9 (location and schedule, and work authorization for the Netherlands). Candidate constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm the posting is live on Duinvaart's own careers page, since the employer could not be verified this session (RR1); (2) confirm Rotterdam three days a week and your work authorization (R9); (3) answer the temperature-compliance question below before the interview (R6).

**Role reality.** `[grounded]` = from the posting you pasted.

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, refrigerated fleet operator, Rotterdam | `[grounded]` posting header |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | A defined analyst role with reporting and stakeholder duties; no people management stated | `[inferred]` from the listed duties |
| Market calibration | Not established. Research was unavailable, so no pay or scope norm is given | — |
| Unknowns | Salary; contract type; whether route changes are decided by you or by depot managers; how temperature compliance is measured today | — |
| Contradictions | None visible in the pasted posting; not checked against the careers page | — |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your background, not yet inspected |
| R2 | Strong SQL | must_have | direct | medium | none | SQL daily | `[grounded]` your background |
| R3 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily | `[grounded]` your background |
| R4 | Weekly dashboards in Power BI | important | direct | medium | none | Built around the on-time delivery dashboard depot managers use | `[grounded]` your background |
| R5 | Track on-time delivery across the fleet | important | direct | medium | transferability | The metric transfers; the fleet is refrigerated, not parcel vans | `[inferred]` |
| R6 | Track temperature compliance | important | absent | none | capability | No temperature or cold-chain work stated | `[grounded]` absence in your background |
| R7 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the weekly route-performance review; whether you proposed route changes is unstated | `[inferred]` |
| R8 | Dutch a plus | preferred | adjacent | high | capability | Conversational, self-stated | `[grounded]` your statement |
| R9 | Rotterdam, three days a week | hard_gate | unclear | none | hard_gate | Your location and commute were not given | `[grounded]` posting; your constraints unknown |

**Gap recovery queue.**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (R6) | capability | No temperature work stated | Named as a core duty; the likeliest interview probe | Any sensor, alert, or temperature-sensitive shipment data you touched; any food-safety or cold-chain course | A data sample, a report, or a training certificate | `[inferred]` |
| G2 | Route changes (R7) | transferability | You reported on routes; decision rights unknown | Determines how much the role leans on your route-review experience | Any route proposal or depot-level change you were part of | A short description of your route review's outputs | `[inferred]` |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified this session | unknown | — | — | The posting may be genuine but unconfirmed | `[generic]` standing entry; research not run | Can you send the live posting link or the company's careers page? | unresolved |
| RR2 | Salary and contract type not in the posting | unknown | — | — | Terms may be on the full posting or withheld | `[grounded]` absence | What is the salary range, and is the post permanent? | unresolved |
| RR3 | Cold-chain domain is new | risk_signal | low | "Track … temperature compliance across our refrigerated fleet" | Interviewers will probe temperature data first | `[inferred]` from R6 | — | unresolved |
| RR4 | Duties are specific and measurable | positive_signal | — | "build weekly dashboards in Power BI" | Scope is defined and your stack matches it | `[grounded]` posting | — | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting on Duinvaart's careers page and check the recruiter's email domain before applying | RR1 | `[generic]` standard practice | none needed; advice |
| A2 | Prepare one honest answer on temperature compliance: what you'd measure first, and what you have not done | G1, RR3 | `[inferred]` | none needed; advice |
| E1 | CV line: "Ran the weekly route-performance review; SQL and Power BI daily, including the on-time delivery dashboard depot managers use." Uses your own sentences; no added scope | R1, R4, R7 | `[grounded]` your background | `resume_edits_pending_approval` |

I have not proposed any line claiming cold-chain or temperature experience, because you have not stated any.

**Evidence status.** Verified: none yet. Your background claims are as you stated them, not checked against a CV document.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search permission was not granted this session, so the employer's existence and the posting's live status are unverified (RR1) |
| 2. Role-family sweep | unavailable | No pay or scope calibration; the market line stays blank |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

## Role 2: Supply Planner, Kroonhaven Foods (Utrecht)

**Not worth applying to. Status: `no_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R7 (on-site Utrecht; your location is not in the input)
- `must_have`: absent: R1 (3+ years planning), R2 (13-week supply plan), R5 (SAP IBP or similar); adjacent: R3 (weekly S&OP-style meeting), R4 (advanced Excel, unclear), R6 (fluent Dutch)
- `important`: none stated
- `preferred`: none stated

Three must-haves are absent, and the Excel and Dutch requirements are not yet met. Hard gates are not failed, so the decision rests on fit.

- **Hard gates:** none failed; unconfirmed: R7 (Utrecht on-site location and work authorization). Candidate constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Why no_go:** you have never worked in planning, and nothing in your background is a planning system. The posting asks for years of that work, which a stronger application can't fake. A pivot into planning would need a route you don't yet have.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, FMCG, chilled ready meals, Utrecht | `[grounded]` posting |
| Mandate | Own the 13-week supply plan; balance capacity against forecast; run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | Single-range planning ownership with a recurring executive meeting | `[inferred]` from the listed duties |
| Market calibration | Not established; research unavailable | — |
| Unknowns | Salary; team size; whether the planning system is SAP IBP or a different one | — |
| Contradictions | None visible; not checked against the careers page | — |

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 3+ years supply or demand planning in FMCG | must_have | absent | high | capability | You state you have never worked in planning | `[grounded]` your statement |
| R2 | Own a 13-week supply plan; balance capacity against forecast | must_have | absent | high | capability | No planning or capacity work stated | `[grounded]` absence |
| R3 | Run a weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review, a comparable recurring cross-functional review | `[inferred]` |
| R4 | Advanced Excel | must_have | unclear | low | discovery | Your background names SQL and Power BI; Excel is not mentioned | `[grounded]` absence |
| R5 | SAP IBP or a similar planning system | must_have | absent | high | capability | Not stated | `[grounded]` absence |
| R6 | Fluent Dutch | must_have | adjacent | high | capability | Conversational, self-stated | `[grounded]` your statement |
| R7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your location was not given | `[grounded]` posting; your constraints unknown |

**Gap recovery queue.**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Planning experience (R1, R2) | capability | None | Years of planning are the core requirement | Any forecasting, capacity, or inventory work, even informal | A planning artifact you produced | `[grounded]` |
| G2 | Excel (R4) | discovery | Not stated | Cheap to close if true | Lookups, pivots, Power Query, modelling | Describe one workbook you built | `[grounded]` |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Years of planning absent | mismatch | high | "3+ years of supply or demand planning in FMCG" | Screened out at the first read | `[grounded]` | — | unresolved |
| RR2 | Salary not in the posting | unknown | — | — | Terms may be on the full posting | `[grounded]` absence | What is the salary range? | unresolved |
| RR3 | Fluent Dutch required | risk_signal | medium | "fluent Dutch" | Conversational is unlikely to pass a fluent bar in a weekly S&OP meeting | `[inferred]` | — | unresolved |
| RR4 | Ownership is explicit | positive_signal | — | "Own the 13-week supply plan" | Role is clearly defined | `[grounded]` | — | noted |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Skip this role for now | RR1, R1, R2, R5 | `[inferred]` from the fit ledger | advice |
| A2 | If you want to pursue planning later, look for logistics-analyst roles that touch forecasting or capacity, and build a planning sample | G1 | `[generic]` role-family pattern | advice |

No CV edit is proposed for this role. I did not propose any planning language, because it would claim experience you have not stated.

**Evidence status.** Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0 (same calls as Role 1; counted once)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Kroonhaven's existence and posting status are unverified |
| 2. Role-family sweep | unavailable | No planning-salary calibration |
| 3. Hiring manager's public footprint | n/a | No name was given |

---

**Dossier offer.** I can save a `tuesday-dossier.md` covering both roles, so this analysis carries into any interview prep.

**Upgrade menu.**
- Permission to run web search (this session's was denied): the employers' pages, the live postings, and salary bands. Up to 5 searches and 2 fetches; this would verify RR1 for Duinvaart and settle the Kroonhaven posting.
- Your CV or a background document: would let the claims be checked, raising R1–R4 for Duinvaart from medium toward high.
- Any temperature data, sensor, or cold-chain work, or a food-safety course: would move R6 from absent.
- An Excel sample or an example of Dutch at work: would move R4 (Kroonhaven) or R8 (Duinvaart).

**Questions.** Answer in text, or say skip for any of them.

1. Can you work in the Netherlands without sponsorship, and are Rotterdam (three days a week) for Duinvaart and Utrecht (on-site) for Kroonhaven workable for you? (R9, R7)
2. Has any of your parcel-carrier work involved temperature data, sensor alerts, or temperature-sensitive shipments? (G1, R6)
3. Do you use Excel beyond basics, such as lookups, pivots, or Power Query, or any forecasting or planning tool? (R4, G1)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.