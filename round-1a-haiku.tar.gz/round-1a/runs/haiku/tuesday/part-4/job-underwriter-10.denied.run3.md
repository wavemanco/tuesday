**Yes, take the call, but verify Fernquay first.** Status: `conditional_go`. I could not confirm from here that Fernquay exists or that the role is live. Nothing you've shared asks for money, bank details, or chat-only interviewing, so I see no scam signal. Legitimacy is still unverified.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

The web search permission was refused, so none of the searches ran. I did not retry. Everything below rests on your background and the two messages you shared.

**Fit ledger**

- `hard_gate` — direct: R1 · unclear: R2 (Pay: €52,000–€60,000 plus equity)
- `must_have` — direct: R4 (Run your own user research), R5 (Work directly with engineers), R6 (Strong Figma), R7 (3+ years of product design) · adjacent: R3 (Own the booking flow end to end)
- `important` — adjacent: R8 (Sole designer, first design hire)

R3 — checkout redesign carries over, end-to-end ownership not yet shown; R8 — squad work carries over, solo design untested; R2 — no pay floor given, so the gate can't be checked.

**Opportunity ledger.** RR1 is the open item that caps the decision: the employer is unverified. RR2 and RR3 are open questions, not red flags. RR4 is a positive signal.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay: €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 verifies; (2) R2: your pay floor is at or below €52,000; (3) RR3 comes out clear on the call.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools; co-founder Ronan Kehoe, CTO Saoirse | `[grounded]` posting and WhatsApp message; existence not verified |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two office days a week in Galway | `[grounded]` posting |
| Market calibration | Not run; the salary band can't be checked against Galway norms from here | — (see research tier) |
| Unknowns | Whether the company is registered and the role is live; equity terms; who reviews design work | — |
| Contradictions | None between the posting and the message | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Galway | hard_gate | direct | medium | none | You live in Galway. You didn't state it as a constraint, so the band grades residence only | `[grounded]` your background | none |
| R2 | Pay: €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given, so the check can't run | `[grounded]` posting | Q2 |
| R3 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout and worked in a squad. Limit: checkout is one step of the flow, and research-to-release ownership isn't shown | `[inferred]` adjacency from the checkout work | Q3 |
| R4 | Run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Owner research is B2B, a different audience; that's a domain gap, not a method gap | `[grounded]` your background | none |
| R5 | Work directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your background | none |
| R6 | Strong Figma | must_have | direct | medium | none | Daily use. The case study is the inspectable artifact, and I haven't seen it | `[grounded]` your background | upload the case study |
| R7 | 3+ years of product design | must_have | direct | medium | none | Four years. A length requirement, graded on fit like any other | `[grounded]` your background | none |
| R8 | Sole designer, first design hire | important | adjacent | medium | transferability | Squad work and the redesign carry over. Solo design and peer review are untested; you've never been the only designer | `[inferred]` adjacency; `[grounded]` your statement | ask on the call (RR3) |

**Gap recovery queue**

- **G1 (R3, transferability):** You shipped a booking step alone, but not research through release on a whole flow. Closes with an account of what you owned, or with the case study.
- **G2 (R8, transferability):** Solo design is new to you. Closes with a clear answer on who reviews design work here.
- **G3 (R2, hard_gate):** The pay check needs your floor.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies this size, not a claim about this one | Where is the live role on your own careers page, and what is the registered company name? | unresolved |
| RR2 | Salary band unchecked | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The band may sit above or below the Galway market for this role. The check didn't run | `[inferred]` from the posting; market side `[generic]`, not run | What vesting and exercise terms apply to the equity? | unresolved |
| RR3 | No named design peers | risk_signal | medium | "You would be our first designer" | There may be no design review and no one to challenge decisions | `[inferred]` from "first designer" against silence on design review | Who reviews design work, and who decides when design and engineering disagree? | unresolved |
| RR4 | Stated pay and named team | positive_signal | — | "Ronan Kehoe … our CTO, Saoirse" | Pay and team are stated openly | `[grounded]` posting and message | Who else is on the team beyond the two engineers? | noted |

The WhatsApp message is not a signal by itself. It asks for nothing, and the interview is a video call with an emailed invite, so it isn't a hiring process run by chat.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Fernquay's own website and its role page; search the Companies Registration Office for the registered name | verifies RR1 | `[generic]` public-check method | proposed |
| A2 | Check that the calendar invite came from a company address, not a personal one | RR1 | `[generic]` method | proposed |
| A3 | Reply on WhatsApp to confirm the slot and ask for the live role link | RR1 | `[grounded]` the message's own "just shout" | proposed |
| A4 | Prep the call with mock-interview, the sibling module for interview prep | R3, R8 | — | proposed |

**Evidence status.** Verified: none yet. Your background is self-report until it's checked.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused. Would have checked that Fernquay exists as described and the role is live (RR1) |
| 2. Role-family sweep | unavailable | Search refused. Would have checked €52,000–€60,000 against Galway product-design pay (RR2) |
| 3. Hiring manager's public footprint | unavailable | Search refused. A name was given (Ronan Kehoe); a search would cover public professional history only |

Upgrade menu:
- The live role link or Fernquay's careers page → RR1 closes; if the company checks out, the status can move to `go`.
- Permission to use web search → the three targets above, including the salary check.
- Your pay floor → R2 closes and the hard-gate check runs.
- The checkout case study, as a file or link → R3 and R6 can rise to `high`.

I can also write this up as a `tuesday-dossier.md` if you want to keep it for the next round.

Questions:
- **RR1:** Where is the role posted: a link to the live listing, or Fernquay's careers page?
- **R2:** What is your pay floor, and does the €52,000–€60,000 band clear it?
- **R3:** On the checkout redesign, what did you personally own from first research to release, and who designed alongside you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.