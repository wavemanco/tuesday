**Verdict: this is a scam. Don't go ahead, and don't send anything.**

Each step of this process is a known fraud pattern:

- **Telegram-only hiring, no calls or video.** Real employers, including remote ones, use company email, a live video call, and a verifiable company domain.
- **Your IBAN, PPS number and passport before any interview.** Payroll doesn't need these at the screening stage. Collecting them this early is identity theft.
- **Paying €349 for a "standard work kit."** Employers don't charge new hires for their equipment. This is an upfront payment to the scammer.
- **The €2,850 cheque.** You deposit it, keep €350, and send the rest to "their partner." The cheque is fake or will be reversed once the bank checks it. You're left out the money you transferred, and your bank may hold you responsible for it.
- **Vague pay with high-pressure steps.** "Up to €26/h plus commission," "you passed," "the job is yours," and a generic email at `postmail.example` instead of a company domain are all warning signs.

**What to do now:**

1. **Don't paste your IBAN, send your PPS number or passport, or pay anything.** Don't deposit the cheque if one arrives.
2. **Stop replying to @VellowayHiring** and block the account. Keep the chat history as evidence.
3. **If you've already sent any details:** contact your bank's fraud team today and ask them to flag your account. Contact the Department of Social Protection about your PPS number. Keep an eye on your statements.
4. **Report it** to the Gardaí, and to the platform where you found the posting.
5. **Check the company.** If Velloway Logistics is Irish, search the CRO register (cro.ie). A real company should show up with its registered address and officers. Don't rely on the company's name in the posting.

**For your job search:** your background is a strong fit for real roles, including customer operations coordinator, support team lead, Zendesk or helpdesk specialist, and operations analyst (Excel-heavy). Your training experience and the tracker you maintain are good evidence for team-lead or coordinator roles, and those can reach €30,000+. Look on Indeed, LinkedIn and employers' own careers pages, and ask for a video interview early in any process.

I haven't run the full underwriting module here, so I haven't built the evidence map or risk register. I can do that, or help you tailor your CV to a specific real posting, if you share one.