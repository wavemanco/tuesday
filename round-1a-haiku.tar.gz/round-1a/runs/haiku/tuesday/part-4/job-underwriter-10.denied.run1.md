**Worth applying, and the 45-minute call is a reasonable next step. Status: `conditional_go`.** Your background matches most of the requirements. The open question is the company itself. Web search was declined for this turn, so I could not confirm that Fernquay exists as described, and I did not retry.

**Is it legit?** Unverified, not confirmed and not failed. Nothing in the posting or the WhatsApp message asks for money, a deposit, bank details, or a process run only over chat. The WhatsApp message asks for a video call with an invite by email. That is ordinary for a small company, but it isn't proof. Two checks take about ten minutes: find Fernquay through its own website and the Irish companies register (CRO), not through links in messages, and check that the calendar invite comes from the company's own email domain.

**Fit ledger.**
- `hard_gate`: direct: R1 · unclear: R2 (pay range against your floor)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (own the booking flow end to end)
- `important`: adjacent: R9 (research calls with school owners) · absent: R8 (working without design peers)

R7 is a credible bridge from your checkout work, with the end-to-end limit named. R8 is your one real gap, and squad work covers only part of it. R9's research habit transfers, but the buyer is different. R2 is waiting on your pay floor.

**Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (€52,000–€60,000 pay range). Your pay floor was not given, so that check is unknown.

**Severe red flags:** none found.

**Opportunity ledger.** Sound on paper: pay and scope are stated concretely, and you would work directly with the co-founder and CTO (RR5, positive). The open items are that the company is unverified from here (RR1), equity terms are unstated (RR3), and decision rights over the booking flow are unclear (RR2).

**What would change this:** the company and live posting check out on its own site or the CRO (RR1); your pay floor sits within the range (R2); on the call, booking-flow decision rights turn out to be concrete (RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, booking software for sea-kayak and surf schools, six people, Galway | `[grounded]` posting only, not verified |
| Scope read | First designer owning the booking flow, research and shipping, alongside two engineers: a generalist-senior scope | `[inferred]` from listed duties |
| Market calibration | Not checked this run. Compare the €52,000–€60,000 band against Irish salary surveys yourself | `[generic]` |
| Working pattern | Two days a week in the Galway office, otherwise remote | `[grounded]` posting |
| Unknowns | Pay floor fit, equity vesting and strike price, booking-flow decision rights | — |
| Contradictions | None found: six people, two engineers, and a CTO named in the WhatsApp message fit together | `[grounded]` posting and message |

**Evidence map.** Confidence is capped at `medium` for your background, since it is self-reported.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in Galway for two office days a week | hard_gate | direct | medium | none | You moved back to Galway last year | `[grounded]` your background | none |
| R2 | Pay €52,000–€60,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given, so nothing to test | `[grounded]` posting | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use; no file yet to inspect | `[grounded]` your background | upgrade menu |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly customer usability sessions; unclear whether you planned and moderated them | `[grounded]` your background | upgrade menu |
| R6 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one step in a booking flow, inside a squad; end-to-end ownership is not stated | `[inferred]` adjacency from checkout work | G3 |
| R8 | Work as first designer, without design peers | important | absent | none | transferability | You have never been the only designer; squad work with engineers is the transferable part | `[inferred]` from "you would be our first designer"; `[grounded]` your statement | G2 |
| R9 | Run research calls with school owners | important | adjacent | medium | transferability | Customer usability work with travellers; school owners are a different buyer | `[inferred]` adjacency | G4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Pay floor (R2) | hard_gate | No floor given | Your floor, checked against €52,000 | `[grounded]` posting |
| G2 | Design peers (R8) | transferability | Squad of engineers, no design peers | A project you led with no other designer on it (freelance, side project, sub-product) | `[inferred]` from the role's scope |
| G3 | End-to-end flow (R7) | transferability | Checkout redesign inside a squad | Which decisions were yours, and whether your ownership went past checkout | `[inferred]` bridge from checkout work |
| G4 | School-owner research (R9) | transferability | Traveller usability sessions | Whether you ran any interviews with small operators or business owners | `[inferred]` adjacency |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer unverified from here | unknown | — | "Product Designer — Fernquay. We are six people in Galway" | Research was declined, so the company is neither established nor failed; check it independently | `[generic]` pattern for small, early companies, not a claim about this one | Can you give me the company's registered name and a link to the live posting on your own careers page? | unresolved |
| RR2 | Decision rights over the booking flow | risk_signal | low | "own the booking flow end to end" | End-to-end ownership without a named product owner; the co-founder or CTO may hold the final call | `[inferred]` from the JD's scope against its silence on decision rights | When the co-founder and the CTO disagree about the booking flow, who makes the final call? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Vesting, strike price and dilution are not stated, so the value is unknown | `[inferred]` from what the posting omits | What is the vesting schedule and strike price for the equity? | unresolved |
| RR4 | Market band not checked | unknown | — | "€52,000–€60,000" | Whether this band matches the market for this seniority in Galway was not checked this run | `[generic]` role-family pattern | How was this salary band set, and is there room within it? | unresolved |
| RR5 | Concrete pay, scope and access | positive_signal | — | "salary €52,000–€60,000"; "work most closely with our co-founder" | The posting states pay and scope concretely, with direct access to the leadership | `[grounded]` the posting | Which engineering projects would the booking flow touch first? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Fernquay on its own website and the CRO; confirm the live posting | RR1 | `[grounded]` RR1 | proposed |
| A2 | Check that the calendar invite comes from the company's email domain | RR1 | `[grounded]` the WhatsApp message says the invite is by email | proposed |
| A3 | Put RR2 and RR3 to the interviewers on the call | The register doubles as call prep | `[grounded]` register | proposed |
| A4 | Rehearse the 45-minute call. mock-interview can run that next. | Interview prep | `[grounded]` the call invite | proposed |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer job Galway" were refused. Would have checked RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | Search "product designer salary Ireland 2026 3+ years experience" was refused. Would have set the market band for RR4 |
| 3. Hiring manager's public footprint | unavailable | Search "Ronan Kehoe Fernquay co-founder" was refused. Would have checked his public professional background for positioning |

If you want, I can write this assessment up as a `tuesday-dossier.md` file to carry into your call prep.

**Upgrade menu**
- Web search allowed for this session: targets 1–3 run, and RR1 and RR4 can be checked.
- Your pay floor: R2 closes, and the decision could move to `go` if it sits within the range.
- The checkout case study you sent Ronan, pasted or linked: R7 and R3 could move to `high`.
- A usability-session plan or summary: R5 could move to `high`.
- A Figma link: R4 could move to `high`.

**Questions**

G1 — What is your pay floor, and is €52,000 the bottom of what you would accept?

G2 — Have you ever shipped work where no other designer weighed in: freelance, a side project, or a sub-product you led alone?

G3 — On the checkout redesign, which decisions were yours and which did the squad make? Did your ownership reach past checkout into search or confirmation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.