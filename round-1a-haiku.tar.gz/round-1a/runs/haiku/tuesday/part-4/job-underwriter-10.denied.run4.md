## Decision snapshot

Yes, take the 45-minute call, but I can't yet confirm Fernquay is legitimate: web search was refused, so I couldn't check the company or Ronan. `conditional_go`

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (own the booking flow end to end)
- `important`: adjacent: R8 (research calls with school owners), R9 (first designer, no design team)
- `preferred`: direct: R10 (one real project over a polished deck)

R6 — adjacent, checkout built inside a squad, not a flow owned alone; R8 — adjacent, travel-booking sessions, not school owners; R9 — adjacent, squad work, no sole-designer record; R2 — unclear, your pay floor isn't given.

**Opportunity ledger.** RR1 (employer not established) caps this at `conditional_go` because nothing could confirm the company. RR2 (solo-designer scope) and RR3 (equity terms undefined) stay open. RR4 (pay range stated openly) and RR5 (a call with the co-founder and CTO) read the other way.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (salary €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your own checks confirm Fernquay and the invite come from the company (RR1); (2) €52,000 clears your floor (R2); (3) you can show one piece of the booking flow you owned, or a credible plan for the solo-designer role (R6, R9)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting, self-described, not verified |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Reporting line | Works most closely with co-founder Ronan Kehoe; CTO Saoirse on the call | `[grounded]` posting and message |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting; market band not checked |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting |
| Contact | WhatsApp for scheduling, email invite for the video call | `[grounded]` message; WhatsApp for scheduling is not a flagged pattern `[generic]` |
| Scope read | A first designer owning a flow at a company this size is a broad, mostly solo scope | `[inferred]` from "first designer" and "own end to end" with two engineers |
| Market calibration | Not run; the search that would have checked the pay band was refused, so no band is given | — |
| Unknowns | Who the sixth person is (five roles are named); equity class, vesting and valuation; any design-review support | — |
| Contradictions | None between the posting and the message | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the hybrid term is met | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your floor isn't given, so the gate can't be checked | `[grounded]` posting; floor not given | Question 1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; prose, not inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file inspected | `[grounded]` your background | none |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly customer usability sessions | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign inside a squad; sole ownership of a flow is not stated | `[inferred]` from checkout work against "end to end" | Gap G1, Question 3 |
| R7 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your background | none |
| R8 | Research calls with school owners | important | adjacent | medium | transferability | Your sessions were with travel-booking customers; school owners are a different audience | `[inferred]` from your sessions; `[generic]` that small-business owners recruit differently | Gap G3 |
| R9 | First designer, no design team ("You would be our first designer") | important | adjacent | medium | transferability | Squad work is inside a larger team; sole accountability is not in your history | `[inferred]` from the posting against your background | Gap G2 |
| R10 | One messy real project over a polished deck | preferred | direct | medium | none | The checkout case study, which Ronan praised | `[grounded]` your message and Ronan's reply | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R6, must_have) | transferability | Checkout redesign inside a squad; no record of owning the whole flow | A must-have row at adjacent; a clear account of what you decided would narrow it | Any checkout decisions you made alone: flow order, error states, what shipped without review | A short write-up of the checkout decisions, marked yours or the squad's | `[inferred]` bridge from the checkout work |
| G2 | First designer, no design team (R9, important) | transferability | No sole-designer record; a squad of four engineers | The posting's central condition for this role | Times you set direction with no design peer reviewing it | Any note on how decisions were made and reviewed | `[inferred]` from the posting's wording |
| G3 | Research with school owners (R8, important) | transferability | Consumer usability sessions in travel booking | The posting's second core duty; the audience differs | Interview guides or session notes you ran, even with non-school users | An interview guide or session summary | `[generic]` that small-business owners are a different audience to recruit |
| G4 | Salary range against your floor (R2, hard_gate) | hard_gate | Floor not given | The only hard gate the inputs leave unsettled | — (surfaced, not recovered) | Your own minimum | `[grounded]` posting and your input |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too new or small for a public footprint, the posting may be stale, or it may not be a real hiring employer. Not checked: the search was refused | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at the role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Solo-designer scope with no design peer named | risk_signal | medium | "You would be our first designer: own the booking flow end to end" | Accountability for the flow may exceed the design review and decision support available | `[inferred]` from "first designer" against no mention of review | "Who reviews design decisions, and which ones are mine to make without sign-off?" | unresolved |
| RR3 | Equity terms undefined | unknown | — | "plus 0.5–1% equity" | No class, vesting or valuation is given, so its value can't be judged | `[inferred]` from the posting's silence on terms | "What class of shares is this, what is the vesting schedule, and what is the latest valuation?" | unresolved |
| RR4 | Pay range and scope stated openly | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Terms given up front | `[grounded]` posting | — | noted |
| RR5 | Early call with co-founder and CTO | positive_signal | — | "a 45-minute video call with me and Saoirse, our CTO" | Senior founder and technical involvement at an early stage | `[grounded]` message | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Look up Fernquay on the Companies Registration Office register, and confirm Ronan and Saoirse appear on the company's own site | Settles RR1 without relying on the sender | `[generic]` verification method | yours to do |
| A2 | Check the invite: sender address on the company domain, and the video link matches the invite | Settles RR1 | `[generic]` verification method | yours to do |
| A3 | Ask Ronan for the live posting link. Draft: "Thanks Ronan, looking forward to the call. Could you send me the live posting link so I can check the details against the careers page?" | Settles RR1 | `[grounded]` RR1 | pending your approval |
| A4 | Before the call, write up the checkout redesign with each decision marked yours or the squad's. The mock-interview module can drill the call if you want | Moves R6 and R9 | `[grounded]` your checkout work; no claim added | pending your approval |
| A5 | Decide your pay floor before any pay conversation | Moves R2 | `[grounded]` your own constraint, not yet given | yours to do |

## Evidence status

Verified: none yet. Your background is prose and counts as CV-equivalent until you confirm specifics. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software Galway sea kayak surf schools" and "Fernquay Galway product designer jobs"; both refused by a permission prompt. Would have moved: whether the company exists as described and the posting is live |
| 2. Role-family sweep | unavailable | Searched "product designer salary Ireland Galway senior 2026"; refused. Would have moved: the market band for €52,000–€60,000 and the scope read |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. Would have moved: whether Ronan's public profile matches a co-founder role at this company |

## Upgrade menu

- Web search permission: with it, I'd run the three targets above, up to 5 searches and 2 fetches. That would test RR1 and R2's market band directly.
- The checkout case study you sent Ronan: lets me inspect R10 and R6, and could raise R6 if it shows what you owned.
- Your pay floor and any other non-negotiables (schedule, right to work): closes R2 and makes the hard-gate line checkable.
- The live posting link or careers page: clears or confirms RR1.
- Equity terms from Ronan: closes RR3.

If you want this kept as a file, I can write it up as `tuesday-dossier.md`; say the word.

1. Does €52,000, the bottom of their range, clear your minimum? (R2)
2. Where did you first see this posting: on Fernquay's own site, or on a job board? (RR1)
3. In the checkout redesign, which decisions were yours alone, and which were the squad's or product's? (G1, R6)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.