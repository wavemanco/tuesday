**Decision: don't go ahead, and send nothing. Status: `no_go`.** Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't deposit the cheque. Each of those is a common pattern in job scams, and this posting asks for all of them.

**Fit ledger (candidate side):** Your background fits this kind of role well (R2, R5). The real problems are on the opportunity side.
- `hard_gate`: unconfirmed: R1 (€30,000 floor against "up to €26/hr", 15–30 hours, commission unquantified)
- `must_have`: direct: R2 (Excel tracker, attention to detail); unclear: R3 (good written English, not established)
- `important`: adjacent: R5 (3 years of order and ticket handling at a courier; Zendesk); unclear: R4 (quiet workspace, not yet stated)

At €26/hr with no commission, €30,000 needs about 22 hours a week all year. The posting doesn't say the rate is guaranteed, so R1 stays unconfirmed.

**Opportunity ledger.** Four severe red flags, each confirmed in the messages:
- **RR1 (`severity: high`): pay for equipment.** "Please pay €349 by bank transfer to our equipment partner." Confirmed.
- **RR2 (`severity: high`): cheque deposit and onward transfer.** "Lodge it to your account… transfer the rest to our equipment partner." Confirmed. This is an overpayment scam shape: the cheque is likely to bounce after you have sent money on.
- **RR3 (`severity: high`): bank, tax and ID details before any offer.** Asked for "before your chat interview." Confirmed.
- **RR4 (`severity: high`): hiring run wholly by chat.** "No calls or video interviews." Confirmed. This is a sign, not a verdict.

**Employer not established.** Two searches for "Velloway Logistics" returned nothing, and the only contact is a generic mail domain (postmail.example), not a company domain. That is a `risk_signal` at `severity: high`.

**Hard gates:** unconfirmed: R1 (pay floor against stated rate). Candidate constraints given: yes.

**Severe red flags:** RR1, RR2, RR3, RR4.

**My verdict:** This job is very likely a scam. I can't establish the firm from here, and the messages may not come from who they name. Before you reply or send anything, confirm who sent them. The call is yours; I'm working only from what you've shared, and I can get this wrong.

**Research tier:** L1, searches 2 of 5, fetches 0 of 2. Nothing returned for the employer, so the register's employer entry stands.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics remote order processing coordinator" and "Velloway Logistics"; no results, so the employer is not established. |
| 2. Role-family sweep | skipped | The no_go is fixed by RR1–RR3, so a pay band cannot change the status. |
| 3. Hiring manager's public footprint | n/a | Only a handle (@VellowayHiring) was given, no name. |

**What would have to change for this to be worth a look:**
- The company is confirmed from its own website, a registry search and a phone number you find yourself. Not the number or address in the messages.
- No money, cheque or bank/ID requests before a written offer from a company address.
- Pay and hours are in writing, with the commission explained.

**Next steps**
- Don't paste your IBAN, PPS number or passport anywhere in this chat or on Telegram. I haven't repeated them here.
- If you've already sent any details, tell your bank now and ask them to watch the account. If money has moved, report it to your bank and the Gardaí.
- If you want to check the employer yourself, use the Irish CRO register and the company's own site, not the links in these messages.

I can write a `tuesday-dossier.md` with this assessment if you want to keep it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.