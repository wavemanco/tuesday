**Decision snapshot**

Yes, asking for bank details, a PPS number and a passport check is normal once a written offer like this one has been made. But the offer itself needs checking before you send anything, because I could not verify the employer from here. `conditional_go`.

**Fit ledger.**
- `hard_gate` — unclear: R1 (eligibility to work in Ireland without sponsorship)
- `must_have` — direct: R2, R4, R5 · unclear: R3 (Irish PAYE, PRSI and USC knowledge)
- `important` — direct: R6, R7 · adjacent: R8 (pension changes)

R1 has no answer yet, R3 (`low`) is the must-have the ad needs you to show, and R8 is adjacent with its limit named.

**Opportunity ledger.** The offer is consistent with the ad and with your interviews: it names the role, a salary of €40,000 inside the advertised €38,000–€42,000 band, and your manager (RR3 and RR4 are positive). Two things are open: who sent it (RR1), and the portal that will take your bank, PPS and passport details (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (eligibility to work in Ireland without sponsorship); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** for `conditional_go`, the conditions are (1) the offer confirmed through a phone number and address on Marrowgate's own website (RR1); (2) the portal's domain matching that website (RR2); (3) R1 confirmed by your own answer.

You don't need to send me your passport, PPS or bank details, and I haven't asked for them.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` job ad |
| Role | Permanent Payroll Administrator, hybrid, two days a week in Limerick, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Pay | €40,000 offered; advertised band €38,000–€42,000 | `[grounded]` ad and offer |
| Onboarding | Bank, PPS and passport details collected through a portal after you accept | `[grounded]` offer email |
| Onboarding norm | Collecting PPS and bank details for payroll after acceptance, and checking right to work, is ordinary practice. Ask what happens to a passport scan and how long it is kept. | `[generic]` Irish onboarding practice, not checked against a source |
| Unknowns | Whether the sender is the employer; whether the portal is theirs; start date; pension scheme | — |
| Contradictions | None between the ad and the offer | `[grounded]` |
| Market calibration | Not run. The €38,000–€42,000 band is the employer's own figure, not a market norm. | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Eligibility to work in Ireland without sponsorship | hard_gate | unclear | none | hard_gate | The passport check implies the employer will verify this. Your status is not in the material, so the gate is not established. | `[inferred]` from the offer's right-to-work step | Q1 below |
| R2 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated by you. Stated, not inspected, so medium. | `[grounded]` your background | Anonymised payroll-run summary would raise to high |
| R3 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Not in your background. A hotel group's payroll probably used them, but that is not established. | `[inferred]` | Q2 below |
| R4 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated | `[grounded]` your background | Anonymised reconciliation sheet would raise to high |
| R5 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; the certificate is the inspectable artifact | `[grounded]` your background | Copy of the certificate would raise to high |
| R6 | Process starters and leavers | important | direct | medium | none | Stated in your background | `[grounded]` your background | none |
| R7 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Stated in your background | `[grounded]` your background | none |
| R8 | Process pension changes | important | adjacent | medium | transferability | Adjacent: you have run payroll, and pension deductions are part of that. Limit: you have never made a pension change yourself; your manager did. | `[grounded]` your statement; `[inferred]` that payroll runs touch pension deductions | G1 / Q3 below |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Pension changes (R8, important) | transferability | Payroll experience, but no pension change made by you | Pension changes are part of the ad's responsibilities | An example of a pension deduction or enrolment change you processed as input in a payroll run | `[grounded]` your statement; `[generic]` that pension changes are routine in this role type |
| G2 | Irish PAYE, PRSI and USC (R3, must_have) | discovery | Not stated | Named in the ad's requirements | Which of the three you calculated, not just checked | `[grounded]` ad requirement |

R1 is a hard gate, so it is surfaced in the snapshot and not in this queue.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and sender not verified | unknown | — | "Marrowgate Housing People Team" (sender people@marrowgate.example) | The sender domain as pasted is `.example`, a reserved placeholder that cannot belong to a real employer. Either the paste was redacted, or the sender is not the employer. Research could not run, so the employer is unverified, not disproved. | `[grounded]` address as pasted; `[generic]` the reserved-domain reading | Can you confirm this offer and the sender domain through the contact details on Marrowgate's own website? | unresolved |
| RR2 | Onboarding portal not yet verified | risk_signal | low | "we will send you a link to our onboarding portal" | Bank, PPS and passport details will go to a portal whose owner and domain are not yet known. Lookalike links are a common route for this kind of fraud. | `[inferred]` from the offer's wording; `[generic]` lookalike-link pattern | Which company hosts the onboarding portal, and on which domain? | unresolved |
| RR3 | Offer names role, pay and manager after in-person interviews | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh" | Specific, written and consistent with the ad | `[grounded]` offer and ad | Who would I be working with day to day in the first month? | noted |
| RR4 | Salary inside the advertised band | positive_signal | — | "€38,000–€42,000" against "€40,000" | Offer sits within the employer's own range | `[grounded]` ad and offer | Is €40,000 the full annual salary, before any pension contribution or allowance? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the offer through a phone number and address from Marrowgate's own website, not from the email | RR1 | `[grounded]` RR1 | proposed |
| P2 | Before accepting, ask the People Team which domain the portal runs on, what the passport scan is for, and how long it is kept | RR2 | `[inferred]` RR2 | proposed |
| P3 | Note the five-working-day deadline in the offer. If P1 checks out, accept by reply; if it does not, ask for a call with a named person. | RR1 | `[grounded]` offer | proposed |
| P4 | Confirm your right-to-work status before the start date | R1 | `[grounded]` offer's right-to-work step | proposed |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every search was refused, because search permission was not granted in this session. It would have checked that the employer exists and the posting is live, which bears on RR1. |
| 2. Role-family sweep | unavailable | Refused. It would have set the €38,000–€42,000 band against role-family norms. |
| 3. Hiring manager's public footprint | unavailable | Refused. A name was given (Declan Garvagh), so this is not `n/a`. It would have covered public professional footprint only. |

I can write this up as a tuesday-dossier.md file if you want to keep it with the offer.

**Upgrade menu**

- Search access, to run the three L1 targets above (up to 5 searches and 2 fetches) → RR1 and the market calibration.
- A copy of your payroll certificate → R5 to high.
- An anonymised payroll sample showing PAYE, PRSI and USC lines → R3 may move from low.
- The portal's domain confirmed against the employer's website → RR2 closes.
- The employer confirmed through its own contact details → RR1 closes, and the decision could move to `go`.

**Questions**

R1 — Do you have the right to work in Ireland without needing sponsorship?

G2 (R3) — In your hotel payroll, did you calculate PAYE, PRSI and USC yourself, or only check the outputs? Which of the three did you handle?

G1 (R8) — Have you ever processed a pension deduction or enrolment change in a payroll run, even as an input, however small?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.