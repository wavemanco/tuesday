## Decision snapshot

**Posting 1, Duinvaart: worth applying to, `conditional_go`.** Your four years of SQL, Power BI and on-time delivery work match most of the core. Apply once two things check out: the three-day Rotterdam schedule works for you, and the employer is confirmed on its own careers page. I could not verify the employer here.

**Posting 2, Kroonhaven: not worth applying to now, `no_go`.** Its must-haves are planning years, S&OP, a 13-week supply plan and SAP IBP. None of them are in your history, and no closure is available inside this posting. Your analytics work is a real bridge into planning roles, but not into this one.

**Posting 1, fit ledger**
- `hard_gate`: unclear: R1 (hybrid, three days a week in Rotterdam office)
- `must_have`: direct: R2 (2+ years logistics or ops analysis), R3 (strong SQL), R4 (Power BI or Tableau), R5 (on-time delivery tracking) · adjacent: R6 (temperature compliance across refrigerated fleet)
- `important`: direct: R7 (weekly Power BI dashboards), R8 (route changes with depot managers)
- `preferred`: adjacent: R9 (Dutch, conversational)

Items that matter: R6 — no cold-chain evidence; SLA-style tracking is the bridge · R1 — unchecked against where you live · R9 — conversational only, limit stated.

- **Hard gates:** none failed (no `direct` gate rows); unconfirmed: R1 (hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 is workable from where you live; (2) RR1, the employer, is confirmed on its own careers page; (3) R6 is framed as adjacent, never as cold-chain experience.

**Posting 2, fit ledger**
- `hard_gate`: unclear: R1 (on-site Utrecht)
- `must_have`: adjacent: R2 (3+ years planning), R3 (S&OP meeting), R7 (fluent Dutch) · unclear: R5 (advanced Excel) · absent: R4 (13-week supply plan), R6 (SAP IBP or similar)

Items that matter: R2 and R3 — ops measurement and a weekly review are the bridge, but you have not owned forecasts or capacity · R4 and R6 — no evidence · R7 — conversational only.

- **Hard gates:** none failed (no `direct` gate rows); unconfirmed: R1 (on-site Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this to `hold_pending_answers`:** evidence that you forecast volumes or took part in capacity planning at the carrier (Q2 below).

## Role reality

| Element | Posting 1: Duinvaart | Posting 2: Kroonhaven |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam | Kroonhaven Foods, Utrecht |
| Scope | Track on-time and temperature compliance across a refrigerated fleet; weekly dashboards; route changes with depot managers | Own the 13-week plan for chilled ready meals; balance capacity against forecast; run the weekly S&OP |
| Working pattern | Hybrid, three days a week in Rotterdam | On-site Utrecht |
| Pay | Not in the text you shared | Not in the text you shared |
| Market calibration | Not run; research unavailable | Not run; research unavailable |
| Unknowns | Employer existence; schedule; temperature-metric scope | Employer existence; whether the years requirement is firm; pay |
| Contradictions | None visible in the text | None visible in the text |

Provenance: all rows `[grounded]` from the two posting texts you shared. The market calibration is not in this run.

## Evidence map

**Posting 1, Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, 3 days/week in Rotterdam | hard_gate | unclear | none | hard_gate | No statement from you on location or schedule | `[grounded]` posting | Q1 |
| R2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years as an ops analyst at a parcel carrier; self-reported | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily use | `[grounded]` your background | none |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Daily use; built the on-time dashboard | `[grounded]` your background | none |
| R5 | On-time delivery tracking across a fleet | must_have | direct | medium | none | You built the on-time dashboard depot managers use | `[grounded]` your background | none |
| R6 | Temperature compliance, refrigerated fleet | must_have | adjacent | low | transferability | No temperature metrics in your history; SLA-style compliance tracking is the bridge. Limit: no temperature data | `[inferred]` from the SLA-style bridge | Q3 |
| R7 | Weekly dashboards in Power BI | important | direct | medium | none | Your dashboard work | `[grounded]` your background | none |
| R8 | Route changes with depot managers | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background | none |
| R9 | Dutch, a plus | preferred | adjacent | medium | transferability | Conversational, not fluent; limit named | `[grounded]` your statement | none |

**Posting 2, Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Utrecht | hard_gate | unclear | none | hard_gate | No statement from you on location | `[grounded]` posting | Q1 |
| R2 | 3+ years supply or demand planning, FMCG | must_have | adjacent | low | transferability | Planned-vs-actual measurement and route performance are the bridge. Limit: no forecast or capacity ownership | `[inferred]` from the bridge | Q2 |
| R3 | Run a weekly S&OP meeting | must_have | adjacent | low | transferability | You ran a weekly route-performance review. Limit: not a planning or S&OP forum | `[inferred]` from the bridge | Q2 |
| R4 | Own a 13-week supply plan | must_have | absent | none | capability | No evidence | `[grounded]` your background | closure path below |
| R5 | Advanced Excel | must_have | unclear | none | discovery | Not stated in your background | `[grounded]` your background | upgrade menu |
| R6 | SAP IBP or similar planning system | must_have | absent | none | capability | No evidence | `[grounded]` your background | closure path below |
| R7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent; limit named | `[grounded]` your statement | none |

Note: R2 and R3 are `adjacent`, not `direct`. Your analytics work measures plans; it does not make them.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Closes it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Temperature compliance (P1 R6) | transferability | SLA-style tracking; no temperature data | The one must-have on Posting 1 not directly covered | Any temperature, cold-chain or threshold-based reporting | `[inferred]` bridge |
| G2 | Planning capability (P2 R2, R3, R4) | transferability / capability | Measurement and review work; no forecast or capacity ownership | Decides whether Posting 2 moves off `no_go` | Forecasting, capacity or planning-meeting work at the carrier | `[grounded]` background; `[generic]` that planning roles probe this directly |
| G3 | Advanced Excel (P2 R5) | discovery | Not stated | A must-have that is cheap to close if true | Your actual Excel level | `[grounded]` background |

The queue holds no questions. Q1 to Q3 below cover these rows.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" / "Kroonhaven Foods, Utrecht" | The entity may be too small or too new for a footprint, or the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about these two | "Can you point me at the live posting on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Schedule and location unchecked | unknown | — | "hybrid, three days a week in our Rotterdam office"; "on-site in Utrecht" | The schedule may not fit where you live | `[grounded]` posting text | "Is the three-day pattern fixed, and is there flexibility on it?" | unresolved |
| RR3 | Scope and outcomes named | positive_signal | — | "Track on-time delivery and temperature compliance" | Scope is measurable | `[grounded]` posting | "Which temperature thresholds and reporting cadence apply today?" | noted |
| RR4 | Pay not shown | unknown | — | Pay not in the text you shared | Unknown against your floor | `[grounded]` absence | "What is the salary range for this role?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the Duinvaart posting on its careers site before applying | RR1 | `[grounded]` RR1 | proposed |
| A2 | Lead the Duinvaart application with the on-time dashboard your depot managers use; do not say it ran the cold-chain programme | R5 and R6; the reframing audit cuts any temperature-compliance claim | `[grounded]` background | proposed |
| A3 | Hold Posting 2 for now; target planning-adjacent roles instead (demand planning, ops planning) | R2 to R6 | `[generic]` pattern for planning roles | proposed |
| A4 | Describe your Dutch as conversational, not fluent | R9, R7 | `[grounded]` your statement | proposed |

## Evidence status

Verified: R2, R3, R4, R5, R7, R8 (Posting 1, your background); R9 and R7 (Dutch) as conversational only. Unverified: R6 and R2/R3 on Posting 2 are bridges, not claims. Rejected inferences: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for both employers were refused by the permission gate. Would have moved RR1 and the posting's live status, for both postings |
| 2. Role-family sweep | unavailable | Salary and scope searches were refused. Would have set the market calibration line and the pay band (RR4) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Your location and commute → R1 on both postings closes; this is the largest single unlock.
- Any temperature, cold-chain or threshold reporting → R6 moves toward `direct`.
- Forecasting, capacity or planning-meeting work → R2 and R3 move; Posting 2 may move to `hold_pending_answers`.
- Your Excel level → R5 on Posting 2 closes.
- The pay range (or your floor) → RR4 closes and sets against the band.
- Search access, granted later → reruns the employer check and the salary band (L1: up to 5 searches and 2 fetches).

## Dossier offer

If you want, I can write this analysis to a `tuesday-dossier.md` you can keep and bring into interviews.

## Questions

**Q1 (R1, both postings):** Can you be in the Rotterdam office three days a week, and on-site in Utrecht, given where you live?

**Q2 (P2 R2, R3, R4):** Did you ever forecast volumes, plan capacity, or present in a planning or S&OP-style review at the carrier? If so, what did you own?

**Q3 (P1 R6):** Did you ever track temperature, cold-chain or threshold-based compliance, or work with temperature-controlled vehicles or depots? If so, what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.