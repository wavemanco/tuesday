**Yes, it's worth applying, with conditions: `conditional_go`.** R1, R2 and R3 (registration, driving licence, Halifax) are `direct`, and R4 (one year post-registration) is `direct`. The main gap is R10, the own caseload, which is `adjacent` to your discharge visits.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4 · unclear: R9 (written records)
- `important`: direct: R5a, R6a, R7a · adjacent: R5b (leg-ulcer care), R10 (own caseload) · unclear: R6b (continence care), R7b (care planning), R8 (end-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R5b — wound work carries over, leg-ulcer work not stated; R10 — home visits, no held caseload; R9 — no record-keeping described; R11 — no Doppler experience.

**Opportunity ledger.** The advert is specific on duties, pay (£31,050–£37,800 plus mileage) and a named contact. Three things are unknown: whether the posting is live on the employer's own site (RR1), caseload size and support (RR2), and on-call or out-of-hours work (RR3). Severe red flags: none found.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown. You haven't given a pay floor or contract preference, so those haven't been checked.

**Conditions for go:** (1) the post is confirmed live on the employer's careers page (RR1); (2) the caseload support is workable (RR2); (3) you describe discharge visits as home-visit experience with senior support, not as a caseload you already held.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax | `[grounded]` advert |
| Scope | District nursing for housebound adults; a small own caseload under a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage, stated | `[grounded]` advert |
| Market calibration | Not run; no research pass was done, so the band is not checked against role-family norms | — |
| Unknowns | Caseload size, on-call, employer and posting status | — |
| Contradictions | None visible in the advert itself | `[grounded]` advert |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as Adult Nurse | hard_gate | direct | medium | none | PIN and active status stated; CV only | `[grounded]` your CV | You check the NMC register shows Adult, active |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Category B stated; not inspected | `[grounded]` your CV | You check the licence card |
| R3 | Work in Halifax | hard_gate | direct | medium | none | You live in Halifax; the post is in Halifax | `[grounded]` advert, CV | none |
| R4 | One year post-registration | must_have | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R5a | Wound care | important | direct | medium | none | Pressure ulcers and surgical wounds; expect a probe on dressings used | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | adjacent | medium | transferability | Wound work carries over; no leg-ulcer work stated; compression management not exercised | `[inferred]` from R5a | Bridge case in the queue (G4) |
| R6a | Catheter care | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | Not in CV; catheter work is related but not the same | `[inferred]` from R6a | Q2 |
| R7a | Insulin administration | important | direct | medium | none | Stated | `[grounded]` CV | none |
| R7b | Care planning | important | unclear | low | discovery | Discharge visits imply planning; not stated | `[inferred]` from the visit description | Q1 |
| R8 | End-of-life visits | important | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Q2 |
| R9 | Clear, timely written records on an electronic record | must_have | unclear | low | discovery | Essential in the advert; no record-keeping described | `[grounded]` advert, CV silence | Q3 |
| R10 | Own small caseload with senior support | important | adjacent | medium | transferability | Your own home-visit work, but episodic and first-week-after-discharge; no held caseload | `[inferred]` from CV | Q1 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one | `[grounded]` your statement | Closure path in the plan |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R10) | transferability | Home visits after discharge, with your own patient decisions, but no ongoing caseload | This is the stated core of the role | Follow-up visits, next-step decisions, handover to community services | A discharge-visit summary or handover note (anonymised) | `[inferred]` from CV |
| G2 | Continence, end-of-life, care planning (R6b, R7b, R8) | discovery | Not in CV | Each is a listed duty | Continence assessments, palliative or end-of-life visits, care-plan entries | Any care-plan template you have used | `[grounded]` CV silence |
| G3 | Written records (R9) | discovery | Not described | Essential in the advert | Visit notes, EPR entries, timeliness under load | A redacted note example (no patient identifiers) | `[grounded]` advert |
| G4 | Leg-ulcer care (R5b) | transferability | Wound work carries over; leg-ulcer work not stated | Desirable overlap with the post's work | Any venous or compression work | Wound-care training record | `[inferred]` from R5a |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not checked | unknown | — | "Calderbrook Community Health CIC" | Not checked in this pass | `[grounded]` advert names the employer; nothing checked | Can you point me at the live posting on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Caseload size and support not stated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | Size and supervision decide whether R10 is workable | `[inferred]` from the advert's silence | How many patients would a new holder carry, and what does senior support look like in months one to three? | unresolved |
| RR3 | On-call and out-of-hours not stated | unknown | — | Silent | Work pattern may be heavier than the duties suggest | `[inferred]` from the advert's silence | Is there on-call or out-of-hours work for this post? | unresolved |
| RR4 | Pay and mileage stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Terms are transparent | `[grounded]` advert | What mileage rate applies, and how do pool cars work? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the home-visit work and the wound, catheter and insulin lines; no new claims | R5a, R6a, R7a, R10 | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | Describe discharge visits as home visits with the senior-nurse support you had, not as a caseload you held | R10, RR2 | `[grounded]` CV; reframing audit: no added scope | `resume_edits_pending_approval` |
| A1 | Confirm the NMC entry and the licence yourself, and check the live posting before applying | R1, R2, RR1 | `[grounded]` | pending your approval |
| A2 | Ask for the informal chat with Rhiannon Mabbott and put RR2 and RR3 to them | RR2, RR3 | `[grounded]` advert contact | pending your approval |
| A3 | Doppler: a short course or supervised practice is the usual route, so it's worth asking the employer whether it's funded | R11 | `[generic]` common route for this skill | pending your approval |

## Evidence status

Verified: none yet. Your CV details are self-reported, so they stay as leads until you confirm them.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Not run in this pass. Would settle RR1 (the employer and the live posting) |
| 2. Role-family sweep | unavailable | Not run in this pass. Would check the pay band against role-family norms |
| 3. Hiring manager's public footprint | n/a | No hiring-manager name was given, so there is no query to form |

I didn't run research this time because it wasn't part of this quick decision. It's the default tier, and the offer is in the upgrade menu.

I can save this assessment as `tuesday-dossier.md` if you'd like a file to keep it.

## Upgrade menu

- A search of the employer's careers page and the role-family pay norms (up to 5 searches and 2 fetches) → RR1 and the market band in role reality. Say the word and I'll run it.
- The caseload details from the chat with Rhiannon Mabbott → R10 and RR2.
- Your NMC register entry and licence card → R1 and R2 move to `high`.
- Your pay floor and any contract preference → the hard-gate line can then check them.

## Questions

**G1 / R7b / R10:** In your discharge-to-assess visits, did you follow patients over several visits and decide next steps yourself, or was each visit a one-off? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**G2 / R6b / R8:** Have you done continence assessments, end-of-life or palliative visits, or written care-plan entries, even on a ward? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**G3 / R9:** Which electronic record system have you written visit or ward notes on, and how did you keep them timely? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.