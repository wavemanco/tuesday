**Yes, it's worth applying for, on conditions.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R11
- `must_have`: direct: R3, R6a, R7a, R8a · adjacent: R5, R6b · unclear: R4, R7b, R8b, R9
- `preferred`: absent: R10

R5 — held caseload never owned, first-week home visits are the nearest work; R6b — leg-ulcer care not in your CV, wound care is; R4, R7b, R8b, R9 — the CV is silent, so the answer is a question, not a gap.

**Opportunity ledger.** The employer is real and the pay sits mid-market, but the advert itself isn't verified as live and the caseload and mileage terms are undefined (RR1, RR2, RR4). The public footprint of the named contact points the same way as the role (RR5, positive).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R11 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your own NMC register and licence checks come back clean (R1, R2); (2) the advert is confirmed live on Calderbrook's own careers site (RR1); (3) the caseload model and the records and end-of-life work hold up at interview (R4, R5, R9).
- **What would change this:** a closed or unverifiable advert, or a caseload that is in practice the whole team's referrals with no named patients, would move this to `hold_pending_answers`.

**Research tier: L1 — searches 5 of 5, fetches 1 of 2**

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a CIC running adult community nursing under a Calderdale NHS contract; founded 2015; 410 staff in four hubs | `[grounded]` employer's About page |
| Mandate | District nursing for housebound adults, small personal caseload, senior nurse support, EPR-recorded | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Survey median for Band 5 community staff nurses is £34,300 (interquartile £32,400–£36,600); 61% are paid mileage | `[generic]` one 2026 survey (n=1,240); I did not verify the official NHS pay table |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team; has spoken on nurse-led leg-ulcer clinics and Doppler training for new community staff | `[grounded]` public speaker profile |
| Unknowns | Caseload size, support model, records expectations, mileage rate, whether the advert is still open | — |
| Contradictions | The careers address I tried returned no page, so the advert is not confirmed on the employer's own site | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | CV states active registration, revalidation March 2028; not checked against the register | `[grounded]` CV | You check your own register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states full category B; expiry and endorsements not stated | `[grounded]` CV | You confirm licence status |
| R11 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax; the post is Halifax-based | `[grounded]` CV, advert | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse, acute medical ward | `[grounded]` CV | none |
| R4 | Clear, timely written records on EPR | must_have | unclear | low | discovery | CV is silent on records or EPR | `[grounded]` CV silence | Q: G2 |
| R5 | Hold a small caseload with senior support | must_have | adjacent | medium | transferability | No caseload owned; first-week home visits after discharge are the nearest work. Limit: visits were not a caseload you managed end to end | `[inferred]` from the CV's visit description | G1 |
| R6a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds stated | `[grounded]` CV | none |
| R6b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care is evidenced; leg ulcers are not named | `[inferred]` | G3 |
| R7a | Catheter care | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R7b | Continence care | must_have | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Q: G2 |
| R8a | Insulin administration | must_have | direct | medium | none | Stated in CV | `[grounded]` CV | none |
| R8b | Care planning | must_have | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Q: G2 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | Not in CV | `[grounded]` CV silence | Q: G2 |
| R10 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have told me you have never done one. Closure path: formal Doppler training, which the contact's talks suggest is offered | `[grounded]` your statement; `[generic]` that training exists for new staff | Minor risk, given preferred priority |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload (R5) | transferability | Home visits in the first week after discharge; no caseload owned | The interview will probe whether you can run a list, not just visits | Any defined list you followed up, a referral pathway you managed, visits you planned yourself | A description of how visits were allocated, or a note on follow-up | `[inferred]` bridge from the CV |
| G2 | Records, care planning, continence, end-of-life (R4, R7b, R8b, R9) | discovery | CV silent on all four | Four must-haves rest on it; any one could be the decision | Written care plans, documented visits, EPR use, palliative or end-of-life visits, continence assessments | Anonymised record extract, or a training record | `[grounded]` CV silence |
| G3 | Leg-ulcer care and Doppler (R6b, R10) | transferability / capability | Wound care evidenced; leg ulcers not named; no Doppler | Desirable, and the contact's public talks suggest the team cares about both | Any leg-ulcer dressing or compression work; any vascular or pulse assessment | Course certificate or training plan | `[generic]` that leg-ulcer clinics are a team focus |

The queue holds no questions; the closing block carries them.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Advert not confirmed on employer's careers page | unknown | — | "For an informal chat about the role, contact…" | The advert may have closed, or it sits on a page I could not reach | `[inferred]` from the failed careers fetch | Where is this advert on your own careers site, and when does it close? | unresolved |
| RR2 | Caseload size and support undefined | unknown | — | "a small caseload of your own, supported by a senior community nurse" | The caseload may be large or referral-driven in practice | `[inferred]` from the advert's silence on numbers | How many patients would the caseload carry at the start, and how does senior support work day to day? | unresolved |
| RR3 | Pay sits mid-band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the surveyed median, so pay is not a concern on its face | `[generic]` survey band against `[grounded]` advert | Where would a candidate with five years' experience start on the band? | noted |
| RR4 | Mileage unquantified | unknown | — | "plus mileage" | Travel costs for home visits may be significant | `[inferred]` from the advert's silence on the rate | What is the mileage rate, and is there a cap? | unresolved |
| RR5 | Named contact is active in the team's clinical focus | positive_signal | — | "For an informal chat…" | The team's public focus matches the role's clinical content | `[grounded]` public speaker profile | Would Doppler training be available to a new starter, and how soon? | noted |

Severity is `—` on unknown and positive rows by design. No red flags.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the discharge-to-assess home visits, as a patient-facing home role, not as a caseload | Closest bridge to R5 | `[grounded]` CV sentence "visiting patients at home in their first week after discharge" | `resume_edits_pending_approval` |
| E2 | Describe Doppler as a development interest, not experience | R10 is absent; claiming it would be inflation | `[grounded]` your statement | `resume_edits_pending_approval` |
| A1 | Confirm the advert on Calderbrook's careers site before applying | RR1 | `[grounded]` fetch result | pending your approval |
| A2 | Use the informal chat with Rhiannon Mabbott to ask RR2, RR4 and RR5 | The register doubles as interview prep | `[grounded]` register | pending your approval |

Your own sentences are the baseline for E1 and E2. Nothing has been added: "caseload" is not used, and Doppler is not claimed.

## Evidence status

Verified: none yet. Your CV claims are leads until you confirm them.

Research tier: L1 — searches 5 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers staff nurse vacancy Halifax district nursing"; read the About page (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page found. Moved: the employer is attributed, so no standing employer-not-established entry; posting liveness not confirmed (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change band 5 pay scale 2026", which returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Also searched "Calderbrook Community Health community staff nurse band 5 jobs", which returned only the About page. Moved: market calibration `[generic]`; RR3 and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned the speaker profile (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: RR5; positioning for E2 |

## Upgrade menu

- The advert on Calderbrook's own careers site → RR1 closes.
- Answers to G1 and G2 → R4, R5, R7b, R8b and R9 move from `unclear` or `discovery` to a band.
- A Doppler or leg-ulcer training certificate, or a leg-ulcer work sample → R6b and R10 move.
- Your pay floor, mileage limit and shift preferences → the hard-gate checks run; without them, the snapshot's constraint flag stays.
- A deeper pass on Calderbrook (leadership, staffing, past adverts; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can also emit a `tuesday-dossier.md` with this assessment, so the analysis carries into interview prep later.

1. G2 — Have you written care plans, done end-of-life visits, or handled continence assessments for patients at home? Where were the records kept?
2. G1 — In the discharge-to-assess team, did you have your own list of patients to follow through, or were visits allocated to you each day?
3. G3-constraints — What are your non-negotiables on pay, mileage or shift pattern? I haven't been given them, so I can't check the role against them.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.