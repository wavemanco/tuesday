**Short answer:** Duinvaart is worth applying to, on conditions. Kroonhaven is not worth your time right now. I could not check either company or the pay market, because web search was refused in this session, so the employer checks are still open.

## Decision snapshot

**Role 1, Operations Analyst, Duinvaart Cold Chain (Rotterdam): `conditional_go`.** Your current job matches the stated requirements (D1, D2, D3 are `direct`). The gap is cold-chain temperature work, which you have not done. Two things could still change this: the Rotterdam schedule (D8) and whether the employer is real.

- **Hard gates:** none failed; unconfirmed: D8 (three days a week in Rotterdam). Candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work three in-office days a week in Rotterdam; (2) you confirm the role on Duinvaart's own careers page, since I could not verify the employer; (3) temperature compliance is presented as an open gap, not as experience.

**Role 2, Supply Planner, Kroonhaven Foods (Utrecht): `no_go`.** Two of the stated must-haves are not met and I see no realistic route to closing them for this application. K3 (planning system such as SAP IBP) is `absent`, and K1 (3+ years of planning) is only `adjacent`, because you have never owned a plan, forecast or capacity decision. K4 (fluent Dutch) is also only `adjacent`.

- **Hard gates:** none failed; unconfirmed: K5 (on-site in Utrecht). Candidate constraints not given.
- **Severe red flags:** none found.
- **What would change this:** evidence that you have owned forecasting or capacity planning. Nothing you have described so far suggests that.

## Research tier

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Search permission was refused on all four calls. Would have checked that Duinvaart and Kroonhaven exist as described and that the postings are live. Employer existence is therefore unverified. |
| 2. Role-family sweep (both roles) | unavailable | Would have set a market salary band and scope norms. Neither role has a market calibration. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Duinvaart: organization | Duinvaart Cold Chain, Rotterdam; existence not checked | `[grounded]` posting text only |
| Duinvaart: scope | Refrigerated fleet on-time and temperature tracking, weekly Power BI dashboards, route changes with depot managers. Concrete and close to your current work | `[grounded]` posting |
| Duinvaart: pay | Not stated. No band available | unknown |
| Kroonhaven: organization | Kroonhaven Foods, Utrecht; existence not checked | `[grounded]` posting text only |
| Kroonhaven: scope | Owns a 13-week supply plan, capacity balancing, runs S&OP | `[grounded]` posting |
| Kroonhaven: pay | Not stated. No band available | unknown |

## Evidence map

**Role 1: Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier | `[grounded]` your description; no artifact | none |
| D2 | Strong SQL | must_have | direct | medium | none | Daily use | `[grounded]` your description | none |
| D3 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your description | none |
| D4 | Weekly dashboards on on-time delivery | important | direct | medium | presentation | Your on-time dashboard was used by depot managers; that is the closest match in the posting | `[grounded]` your description | lead with it; bullet edit pending your approval |
| D5 | Temperature compliance across a refrigerated fleet | important | unclear | low | discovery | No cold-chain experience stated. Parcel temperature data, if any, is unknown | `[grounded]` absence from your background | Q3 |
| D6 | Route changes with depot managers | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your description | none |
| D7 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, not fluent | `[grounded]` your description | state your level plainly |
| D8 | Three days a week in the Rotterdam office | hard_gate | unclear | — | hard_gate | Your location and schedule constraints were not given | — | Q1 |

**Role 2: Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | 3+ years supply or demand planning in FMCG | must_have | adjacent | medium | transferability | Route-performance review and on-time tracking sit beside planning. You have not owned a plan, forecast or capacity decision. Limit: no planning ownership | `[inferred]` adjacency from your background | Q2 |
| K2 | Advanced Excel | must_have | unclear | low | discovery | Not in your background | `[grounded]` absence | Q2 |
| K3 | SAP IBP or a similar planning system | must_have | absent | none | capability | No evidence. Not closable for this application | `[grounded]` absence | none; this is the gap |
| K4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational. Limit: not fluent for a Dutch-language S&OP meeting | `[grounded]` your description | state your level plainly |
| K5 | On-site in Utrecht | hard_gate | unclear | — | hard_gate | Your location constraints were not given | — | Q1 |

## Gap recovery queue

- **D5 (temperature compliance): discovery.** Gap: no cold-chain evidence. Why it matters: it is the main part of the job description that is new to you. Would close it: any temperature-sensitive shipment, cold-storage or food-safety data you have worked with.
- **K1 and K2 (planning and Excel): discovery and transferability.** Gap: no planning ownership is stated. Would close it: any forecast, capacity or inventory plan you built, even informally.
- **K3 (planning system): capability.** Gap: no evidence. No question asked; carried as a material risk.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RD1 | Employer existence unverified | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale, or the employer may be too small to show online | `[generic]` pattern for unverified postings | "Can you confirm this role on your own careers page, and who would I report to?" | unresolved |
| RD2 | Salary not stated | unknown | — | Posting silent on pay | Pay may sit below your current level | `[inferred]` from the posting's silence | "What is the salary range for this role?" | unresolved |
| RD3 | Scope is concrete | positive_signal | — | "Track on-time delivery and temperature compliance" | Success is measurable; the role is defined | `[grounded]` posting | "What are the current on-time and temperature targets?" | noted |
| RK1 | Employer existence unverified | unknown | — | "Kroonhaven Foods, Utrecht" | As RD1 | `[generic]` | "Can you confirm this role on your careers page, and which planning system does the team use?" | unresolved |

## Application plan (proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Check Duinvaart's careers page yourself before applying | RD1 | `[generic]` | your action |
| E2 | Lead with the on-time dashboard and the route review for Duinvaart; state temperature work as an open gap | D4, D5, D6 | `[grounded]` | pending your approval |
| E3 | Do not apply to Kroonhaven unless Q2 turns up real planning ownership | K1, K3 | `[grounded]` | recommendation |

If you do apply to Duinvaart and want the CV edited, the resume-tailor module does that work, not this one.

## Evidence status

Verified: none yet. Every claim above rests on your description in this conversation, with no artifact to inspect.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

(The target accounting is in the Research tier table above.)

## Upgrade menu

- A link to each live posting or the company's careers page: this lets the employer checks run. Search was refused here, so it is still open. D4 and the employer rows (RD1, RK1) move from unresolved to checked.
- A sanitized screenshot of your on-time dashboard: raises D4 from `medium` to `high`.
- Your target salary, or the salary the posting gives: lets RD2 close.
- If you enable web search, I can run the employer and market checks: up to 5 searches and 2 page fetches.

If it would help, I can write both assessments into a `tuesday-dossier.md` file you keep, with the unverified points marked.

**Questions**

1. **D8 and K5:** What is the longest commute you would accept, and would three office days a week in Rotterdam work for you? For Utrecht, would you be able to do the same?
2. **K1 and K2:** Have you ever built a forecast, capacity plan, or inventory or production plan, even in Excel and informally? If so, what did you own and what did it change?
3. **D5:** Have you worked with temperature-sensitive shipments, cold-storage logs, or food-safety records, even partly? Any exposure counts.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.