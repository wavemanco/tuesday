**Yes, it's legit, and it's worth the call. Status: `conditional_go`.** Fernquay is a real company with a live posting that matches its own careers page, and your design background covers most of the role. The call should settle one open question: who decides design and reviews it, since you would be the only designer.

**Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0**

**Fit ledger**

- `hard_gate`: direct: R1
- `must_have`: direct: R2, R3, R4, R5 · adjacent: R6 (own the booking flow end to end)
- `important`: adjacent: R7 (research calls with school owners), R8 (first designer, no design peers)

R6 — your checkout redesign carries over, but not kayak-school booking; R7 — consumer usability work carries over, owner interviews don't; R8 — squad work carries over, sole-designer ownership doesn't.

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 — the call answers who decides design direction and who reviews design work; (2) RR3 — you can size the 0.5–1% equity before accepting anything

Opportunity ledger: positive on the employer and pay (RR2, RR4, RR5); open on design decision rights (RR1) and equity value (RR3).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, founded 2023, building booking software for sea-kayak, surf and sailing schools | `[grounded]` about page, searched |
| Posting | Live; matches the posting word for word on pay and hybrid pattern | `[grounded]` careers page, fetched |
| Pay | €52,000–€60,000 plus 0.5–1% equity. The Tillerby 2026 Ireland survey gives a median of €57,000 for product designers with 3–5 years, interquartile €51,500–€62,000, so the range sits inside the band | `[grounded]` posting; `[generic]` survey band |
| Working pattern | Two days a week in Galway; you live there | `[grounded]` posting; user-stated |
| Scope read | First design hire, one end-to-end flow, two engineers: a normal early-stage remit | `[inferred]` from the posting's scope language |
| Unknowns | Design decision rights, design review, equity value, contract type | — |
| Contradictions | None between the posting and the careers page | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days in Galway | hard_gate | direct | medium | none | You live in Galway; no stated non-negotiable | `[grounded]` user-stated | none |
| R2 | 3+ years product design | must_have | direct | medium | none | Four years at one company; not a gate, graded on fit | `[grounded]` CV | none |
| R3 | Strong Figma | must_have | direct | medium | none | Daily use; no artifact inspected yet | `[grounded]` CV | none |
| R4 | Has run own user research | must_have | direct | medium | none | Monthly customer usability sessions | `[grounded]` CV | none |
| R5 | Works directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` CV | none |
| R6 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | Checkout redesign at a travel-booking company. Limit: not kayak-school booking, and not a flow you owned alone from research to ship | `[inferred]` bridge from the checkout work | see G1 |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Consumer usability sessions carry over. Limit: no B2B owner interviews | `[inferred]` bridge | see G2 |
| R8 | First designer, no design peers | important | adjacent | medium | transferability | Squad work with engineers. Limit: never the only designer | `[grounded]` your statement | see G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Booking domain (R6) | transferability | Checkout redesign for travel; no kayak or school booking | A checkout or booking case study you can show, with the constraints you worked within | `[inferred]` bridge; `[generic]` that schools book differently from travel firms |
| G2 | Owner research (R7) | transferability | Consumer usability work only | Any call or interview with a business customer, even informal | `[grounded]` CV |
| G3 | Sole designer (R8) | transferability | Squad work; never alone on design | Who reviewed your work in the squad, and what you decided without them | `[grounded]` your statement |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership without visible decision rights | risk_signal | medium | "You would be our first designer: own the booking flow end to end" | You may own the flow's outcome while engineering or the founders make design calls | `[inferred]` from scope language against silence on decision rights | Who makes the final design call when you and an engineer disagree, and who reviews design work before release? | unresolved |
| RR2 | Pay inside market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The range is realistic for your experience | `[grounded]` posting; `[generic]` survey | — | noted |
| RR3 | Equity value unstated | unknown | — | "0.5–1% equity" | The percentage means little without the share count or valuation | `[inferred]` from the posting's silence on either | What is the share count, the latest valuation, and the vesting schedule? | unresolved |
| RR4 | Employer established | positive_signal | — | "Product Designer — Fernquay" | Real company, consistent across its own pages | `[grounded]` about and careers pages | Who will I work with day to day, and what is the hiring plan? | resolved |
| RR5 | Says it values real work over polish | positive_signal | — | "we would rather see one messy real project than a polished deck" | A transparent team that wants evidence, which suits you | `[grounded]` posting | — | noted |

The WhatsApp message is ordinary scheduling, not a warning sign. It says the invite came by email, so check that the invite comes from a Fernquay address before you accept.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | On the call, ask RR1 and RR3 verbatim | They decide whether `conditional_go` becomes `go` | `[grounded]` register | pending your approval |
| P2 | Describe your research as "monthly usability sessions with customers". Do not describe it as research with school owners | "Customers" widened to "owners" changes who you talked to (reframing audit: relationship) | `[grounded]` your CV | pending your approval |
| P3 | Check the invite's sender domain, then accept. For call rehearsal, the `mock-interview` module can build the prep pack | Scheduling is fine; the domain check is the cheap verification | `[generic]` practice | pending your approval |

**Evidence status**

Verified: none yet.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software Galway sea-kayak surf schools" and "Fernquay Product Designer job Galway"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved organization and contradictions: about page (fernquay.example/about, seen in search) agrees with the posting |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned the public profile linkedin.example/in/ronan-kehoe: co-founder and CEO, previously product lead at a Galway travel-software company for five years. Moved the scope read and which story to lead with |

I can't confirm the invite email or anyone's current role beyond these public listings.

Dossier offer: I can write this assessment to `tuesday-dossier.md` so the register and the call questions travel with you.

**Upgrade menu**

- A checkout or booking case study you can share → R6 moves toward `high`.
- Your answer on who reviewed your squad's design work → R8 moves toward `direct`.
- The share count or valuation behind the 0.5–1% → RR3 closes.
- A deeper research pass on Fernquay (funding, hiring, public candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. When you worked in the squad, who reviewed your design work before it shipped, and did you ever decide something without them?
2. Have you ever talked with a business owner, not a consumer? If so, what was it, and what did you ask?
3. What pay floor and contract type (permanent or fixed-term) do you need? The posting doesn't settle either, so I can't check them yet.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.