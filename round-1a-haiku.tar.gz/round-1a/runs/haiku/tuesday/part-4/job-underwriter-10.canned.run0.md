## Verdict: worth taking the call. The company is real, and the posting matches its own site.

**Decision snapshot.** Yes, it's a real company, and the 45-minute call is worth doing. The main question is whether you've ever been the only designer, not whether this is a scam. `conditional_go`

**Fit ledger.**
- `hard_gate`: direct: R1 · unclear: R2 (pay €52,000–€60,000)
- `must_have`: direct: R5, R6, R7 · adjacent: R3 (own the booking flow end to end)
- `important`: direct: R8 · adjacent: R4 (research calls with school owners) · absent: R9 (first designer, no design peers)
- `preferred`: adjacent: R10 (sea-kayak and surf booking domain)

The rows that matter most are R9, the sole-designer gap that could change the call, and R2, the pay question I can't answer yet. R3 and R4 are adjacent, with their limits named.

**Opportunity ledger.** Sound on what can be checked: the company exists, its careers page matches the posting, and the pay is in line with the market. Unknowns are the equity terms (RR2) and Saoirse's title (RR3). Positive signal: the pay and hybrid terms are stated plainly (RR1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or under the band (R2); (2) the 0.5–1% equity is confirmed as options or shares, with vesting and strike terms (RR2); (3) Saoirse's role is confirmed (RR3).
- **What would change this:** a pay floor above €60,000 would make R2 `hard_gate_fail` and the status `no_go`.

On the WhatsApp message: scheduling by chat isn't a risk signal here. The posting gives an email address, and you're being invited to a video call. Before the call, check that the invite and the video link come from a fernquay.example address.

## Research tier: L1 — searches 5 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay Product Designer jobs Galway"; fetched fernquay.example/careers/product-designer and fernquay.example/about. The entity exists as described (six people, Galway, founded 2023, customer-funded), and the posting is live and matches the careers page. No contradictions. |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience", which returned the Tillerby 2026 Ireland Design Salary Report (n=520, 3–5 years: median €57,000, interquartile range €51,500–€62,000). Market calibration below. |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a LinkedIn profile snippet (not fetched): co-founder at Fernquay, previously product lead at a Galway travel-software company for five years. Used for the positioning read. |
| Un-numbered: Saoirse Doyle | yes | Searched "Saoirse Doyle Fernquay CTO". No results. The CTO title is not established. |

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; founded 2023 by Ronan Kehoe and Saoirse Doyle; customer-funded | `[grounded]` fernquay.example/about |
| Mandate | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting and careers page |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page |
| Scope read | A first design hire with no design peers, owning research and a flow; a normal scope for a team this size | `[inferred]` from the posting's responsibilities against its six-person headcount |
| Market calibration | The posted €52,000–€60,000 sits in the middle half of the band, a little under its median | `[generic]` Tillerby 2026 band for 3–5 years; `[grounded]` posted figure |
| Unknowns | Equity terms; Saoirse's role; whether Ronan is the hiring manager | — |
| Contradictions | None between the posting and the careers page. The WhatsApp message calls Saoirse "CTO", and the about page names her as a co-founder with no title. | `[grounded]` both pages |

**Evidence map.** Your background is self-reported, so confidence tops out at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Galway hybrid, two office days | hard_gate | direct | medium | none | You say you moved back to Galway last year; the two office days are a commute question | `[grounded]` your statement; `[grounded]` posting | none |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No pay floor given, so the gate can't be checked | `[grounded]` posting | Q1 |
| R3 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking checkout; you haven't said you owned the whole flow. Limit: checkout, not end to end | `[grounded]` your background; `[inferred]` adjacency | Q3 |
| R4 | Research calls with school owners | important | adjacent | medium | transferability | You ran monthly usability sessions with customers, but with travellers, not business owners | `[grounded]` your background; `[inferred]` adjacency | upgrade menu |
| R5 | 3+ years product design | must_have | direct | medium | none | Four years, stated. Not a gate: years of experience are graded on fit | `[grounded]` your statement | none |
| R6 | Strong Figma | must_have | direct | medium | none | You use Figma daily | `[grounded]` your statement | none |
| R7 | Has run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers | `[grounded]` your statement | none |
| R8 | Works directly with engineers | important | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your statement | none |
| R9 | Designs with no design peers | important | absent | medium | transferability | You've never been the only designer. Credible adjacent work exists but isn't shown; the squad context is the nearest case | `[grounded]` your statement | Q2 |
| R10 | Sea-kayak and surf school booking | preferred | adjacent | medium | transferability | Travel-booking domain, not school booking | `[inferred]` from the posting's domain | none |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer decisions (R9, important) | transferability | Never been the only designer; team experience is a squad | This is the fit gap most likely to come up on the call | A freelance job, side project, or club/school app where you made design calls without review | A short case of your own decisions, or the closest project | `[grounded]` your statement; `[generic]` that founders probe this in first-design roles |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and terms stated plainly | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | A budget exists for this hire, and the company is open about it | `[inferred]` from the posting | What budget is set for this hire, and when do you want it filled? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Equity is worth little without its type, vesting and strike price | `[generic]` small-company equity is usually options on a vesting schedule | Is the 0.5–1% in options or shares? What are the vesting schedule, strike price, and dilution history? | unresolved |
| RR3 | Saoirse's title unconfirmed | unknown | — | "Saoirse, our CTO" (WhatsApp message) | The CTO title is not on the about page and a search found nothing | `[grounded]` about page and search results | What does Saoirse own day to day, and does she review design decisions? | unresolved |

**Application plan** (proposed, not sent):

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Bring one messy real project with a flow you can walk through step by step | The posting asks for this | `[grounded]` posting | proposed |
| P2 | Say plainly that you've never been the only designer, then give the closest case | Avoids a claim the record can't support | `[grounded]` R9 | proposed |
| P3 | Ask about the equity terms and the pay band on the call | RR2 and R2 are unresolved | `[inferred]` from the register | proposed |

**Evidence status.** Verified: none yet. Your background is still your own statement; no artifact has been checked.

## Upgrade menu

- Your pay floor → R2 closes, and the status moves to `go` or `no_go`.
- A project where you made design calls alone, even freelance or on a side project → R9 moves toward `adjacent`.
- The checkout case study you sent Ronan, shared with me → R3 moves toward inspectable evidence.
- Equity terms in writing → RR2 closes.
- Saoirse's role → RR3 closes.
- A deeper pass on Fernquay (funding, hiring history, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs. I'm offering it once.

I can also save this as a `tuesday-dossier.md` you can reuse before the call.

## Questions

Q1 (R2): What's the lowest base salary you'd accept? The posting is €52,000–€60,000, and I need your floor to say whether the pay gate is met.

Q2 (R9): Have you ever been the only designer on anything, such as a freelance job, a side project, or a club or school app, where you made the calls without a design review? If not, what was the nearest case?

Q3 (R3): Did your checkout work cover the whole booking flow, or only the final steps? Which decisions did you make yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.