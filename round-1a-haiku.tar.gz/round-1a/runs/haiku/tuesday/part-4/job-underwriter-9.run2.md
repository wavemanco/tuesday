**Yes, asking for bank details, a PPS number and a passport after a written offer is normal. What matters is the channel you send them through. Status: `conditional_go`.** The role fits your skills and is worth pursuing, but verify the employer and the sender before you accept or send anything.

## Decision snapshot

**Fit ledger**
- `hard_gate`: unclear: R1 (Limerick, two office days a week), R2 (your pay floor), R3 (right to work)
- `must_have`: direct: R4 (2+ years payroll), R6 (Excel), R7 (qualification); adjacent: R8 (monthly, 240 staff); unclear: R5 (Irish PAYE, PRSI, USC)
- `important`: direct: R9 (starters and leavers), R10 (payroll-to-ledger); adjacent: R11 (pension changes); unclear: R12 (staff payroll queries)

R5 is the one to answer before accepting. R8 is the real step up: monthly payroll for over two and a half times your headcount. R1, R2 and R3 stay open until you tell me your constraints.

**Opportunity ledger.** RR2 means the employer and sender are unverified, not shown to be fake, since no search ran. RR1 means the data requests are routine after a written offer that names role and pay. RR3, two in-person interview rounds at their office, is a positive signal.

- **Hard gates:** none failed; unconfirmed: R1 (Limerick, two office days a week), R2 (pay floor), R3 (right to work); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for `conditional_go`:** (1) the sender and onboarding link are verified through the company's own website or switchboard before you accept (RR2); (2) you confirm R1 and R2; (3) R5 is answered honestly.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Marrowgate Housing, a Limerick housing association | `[grounded]` ad and offer |
| Scope | Monthly payroll for 240 staff, plus starters, leavers, pensions, GL reconciliation, staff queries | `[grounded]` ad |
| Pay | €38,000–€42,000 posted; €40,000 offered, inside the band | `[grounded]` ad and offer |
| Market calibration | Not run; the band's fit with the market is unchecked | `[generic]` not researched |
| Contradictions | None between ad and offer (same role, same reporting line) | `[grounded]` |
| Unknowns | Your pay floor, location, pension scheme detail, whether the hotel group ran Irish statutory payroll | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two office days a week in Limerick | hard_gate | unclear | none | hard_gate | You have not stated your location or availability | `[grounded]` ad | Question below |
| R2 | Pay within your floor | hard_gate | unclear | none | hard_gate | Offer is in the posted band; your floor is not given | `[grounded]` ad and offer | Question below |
| R3 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | Not in the ad; the offer requires a check; your status is not given | `[grounded]` offer | Confirm your status |
| R4 | 2+ years running payroll | must_have | direct | medium | none | Three years fortnightly for 90 staff; self-reported, no artifact | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | none | discovery | Not stated; the certificate may cover it | `[grounded]` silence in your background | Question below |
| R6 | Strong Excel | must_have | direct | medium | none | Pivots and XLOOKUP stated; no file inspected | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | Share a copy to raise to high |
| R8 | Monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Same process at 90 staff, fortnightly; monthly cycle and headcount not yet exercised | `[inferred]` from your scale against the ad | Name the limit in interview |
| R9 | Starters and leavers | important | direct | medium | none | Stated and specific | `[grounded]` your background | none |
| R10 | Monthly payroll-to-GL reconciliation | important | direct | medium | none | Stated; matches the ad | `[grounded]` your background | none |
| R11 | Pension changes | important | adjacent | low | transferability | You ran payroll but your manager handled pension changes | `[grounded]` your statement | Say so plainly; claim nothing more |
| R12 | Answering staff payroll queries | important | unclear | none | discovery | Not in your background | `[grounded]` silence | Question below |

**Gap recovery queue:** R5, R8, R11 and R12 are open. Their recovery moves are in the next-action column; the questions sit in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Hypothesis and basis | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Bank, PPS and passport requested after the offer | unknown | — | Routine onboarding after a written offer that names role and pay. `[generic]` Irish onboarding pattern; the channel is what to check | "Can you confirm the portal address and the People Team contact, matched to your website?" | unresolved |
| RR2 | Employer and sender not verified | risk_signal | medium | The sender domain you gave, marrowgate.example, ends in `.example`, a reserved name not assigned to live organisations. The address may have changed in copying, or the sender may not be the company. `[inferred]` from the address as given | "Can you confirm this email came from your domain, and that the onboarding link will too?" | unresolved |
| RR3 | Two in-person interview rounds at their office | positive_signal | — | A physical site and a real process. `[grounded]` your report | "Who would I report to day to day, and will I meet Declan Garvagh before starting?" | noted |
| RR4 | Market band unchecked | unknown | — | €40,000 sits in the posted band; whether that band matches the market was not checked. `[generic]` | "How was the €38,000–€42,000 band set for this role?" | unresolved |

Severity is medium on RR2 because nothing else in the material marks it as high: no pay withheld, no off-domain contact beyond scheduling, and only a five-day reply window.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before you accept, find the People Team and Declan Garvagh's role on the company's own website, and call the switchboard to confirm | RR2, RR3 | `[generic]` standard verification | pending your approval |
| A2 | Ask for the onboarding link from the company domain; send nothing until it arrives from there | RR1, RR2 | `[generic]` | pending your approval |
| A3 | Send bank, PPS and passport only through that verified portal; ask whether the right-to-work check can be done in person with originals | RR1 | `[generic]` Irish onboarding norm | pending your approval |
| A4 | On pension changes, say: "I haven't run pension changes; my manager handled them. Here's how I'd learn them." Claim nothing more | R11 | Reframing audit: no added experience | pending your approval |
| A5 | Prepare Irish PAYE, PRSI and USC examples only from work you actually did | R5 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was sent and refused, because search permission was not granted in this session. Would have checked the employer exists, the posting is live, and the sender domain |
| 2. Role-family sweep | unavailable | Search was sent and refused. Would have calibrated the €40,000 offer against the market |
| 3. Hiring manager's public footprint | unavailable | No call sent; search permission is not granted in this session. Would have shown Declan Garvagh's public professional role |

If you grant search permission, I can run these checks.

## Dossier offer

If you want to keep this, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Search permission granted → checks the employer and sender (RR2) and tests the €40,000 offer against the market (RR4). Runs at L1 on your go-ahead.
- A copy of your Payroll Technician certificate → R7 to `high`.
- An anonymised Irish payroll output, such as a payslip or RTI summary with personal data removed → R5 to `high`.
- Your location, pay floor and right-to-work status → R1, R2 and R3 close.

## Questions

R1 — Can you get to the Limerick office two days a week?

R2 — Is €40,000 above the lowest salary you would accept?

R5 — Have you run Irish PAYE, PRSI and USC on live payroll, and which parts?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.