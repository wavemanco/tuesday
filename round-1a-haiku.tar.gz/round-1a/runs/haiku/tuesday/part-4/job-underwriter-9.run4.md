**Short answer:** Bank details, a PPS number and an ID check are normal onboarding requests in Ireland, but only after you have accepted a genuine offer and only through a channel you have verified. This offer is not verified yet, so don't enter anything in the portal until it is. **Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: direct: R2 · unclear: R1 (right to work in Ireland)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: direct: R7, R8 · adjacent: R9 (pension changes) · unclear: R10 (answering staff payroll queries)

R3, R5 and R6 rest on your account of three years' payroll, the certificate and Excel; none is inspected yet. R4 is not in your account at all. R9 is a bridge from starters and leavers, and you did not run pension changes. R10 is not in your account.

**Opportunity ledger.** Positive: RR4 (pay of €40,000 sits inside the posted €38,000–€42,000 band; permanent and hybrid as advertised) and RR5 (two interviews at their office, by your account). Open: RR1, the employer itself is not established, and RR2, whether the data request is routine depends on RR1.

- **Hard gates:** none failed (R2 `direct`); unconfirmed: R1 (right to work in Ireland, not stated); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** (1) your answer on R1; (2) RR1 cleared by a contact you find on Marrowgate's own website, plus a portal on its own domain. Clearing 1 and 2 moves this to `conditional_go`. (3) how deep your PAYE, PRSI and USC work goes decides whether the R4 must-have holds.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a Limerick housing association (per the ad) | `[grounded]` job ad |
| Remit | Monthly payroll for 240 staff, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` job ad |
| Pay and terms | Advertised €38,000–€42,000; offer €40,000; permanent; two days a week in the Limerick office | `[grounded]` ad and offer email |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Market calibration | Not run. The search permission was refused, so there is no market band | — |
| Unknowns | Right to work; whether the portal is the employer's own system; what the employer keeps and for how long; how wide the pension scope is | — |
| Contradictions | None between the ad and the offer. The sender's domain ends in `.example`, which is reserved for documentation and is not a live company domain (RFC 2606) | `[generic]` for the domain rule; `[grounded]` for the address in the offer |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland | hard_gate | unclear | none | hard_gate | The offer runs a right-to-work check, but you have not said your status | `[inferred]` from the offer's check | Q1 below |
| R2 | Pay within the posted band | hard_gate | direct | medium | none | €40,000 is inside €38,000–€42,000; the offer is unverified (RR1) | `[grounded]` ad and offer | none |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years' fortnightly payroll for 90 staff; the CV has no artifact yet | `[grounded]` your account | an anonymised payroll run summary would raise it |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Not in your account | `[grounded]` absence | Q2 below |
| R5 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your account | a copy of the certificate would raise it |
| R6 | Strong Excel | must_have | direct | medium | none | Pivot tables and XLOOKUP, daily use | `[grounded]` your account | an anonymised workbook would raise it |
| R7 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | You ran it monthly | `[grounded]` your account | none |
| R8 | Starters and leavers | important | direct | medium | none | You ran these at the hotel group | `[grounded]` your account | none |
| R9 | Pension changes | important | adjacent | medium | transferability | Starters and leavers carry over; you never ran pension changes, your manager did | `[inferred]` bridge from R8 | closure: ask how pension changes flow through the payroll run |
| R10 | Answering staff payroll queries | important | unclear | low | discovery | Not in your account | `[grounded]` absence | Q2 can cover it |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory payroll (R4, must_have) | discovery | You have payroll and a certificate, but not the Irish rules in your own words | A must-have. Once you show it, it decides whether this is a go | Payslip calculations, PAYE, PRSI and USC returns, Revenue queries you handled | A certificate module or a sample return | `[grounded]` absence in your account |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from what you have | risk_signal | medium | "Marrowgate Housing People Team" (signature on the offer) | The sender may not be the employer, or the domain in the offer may be a placeholder. Most small employers are simply small, so this is not a finding of fraud | `[generic]` pattern for an unverified sender, not a claim about this one | "Can you confirm this offer from the People Team's own phone number on your website, and tell me the portal's domain?" | unresolved |
| RR2 | Bank, PPS and passport requested after the offer | unknown | — | "bring the original passport on your first day" | Routine after a real offer; ask what is stored and for how long. The check depends on RR1 | `[generic]` Irish onboarding practice, not checked here; the original document check is usually done in person | "What systems do you use, what do you keep, and for how long?" | unresolved |
| RR4 | Pay and terms in the ad match the offer | positive_signal | — | "€38,000–€42,000" and "€40,000 a year" | Pay and contract are what was advertised | `[grounded]` ad and offer | none needed | noted |
| RR5 | Interviews at the employer's office | positive_signal | — | your account: two in-person interviews | Suggests a real site, though the site still needs verifying | `[grounded]` your account | none needed | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Marrowgate's own website and People Team number yourself, and check the offer against them | RR1 | `[grounded]` RR1 | your call |
| P2 | Enter nothing in the portal until P1 is done and the portal is on the employer's own domain | RR2 | `[generic]` onboarding practice | your call |
| P3 | Ask what the employer stores and for how long before sending a passport scan | RR2 | `[generic]` GDPR-style practice | your call |
| P4 | Revise your answer to R4 with a concrete example, which also tests G1 | G1 | `[grounded]` your account | your call |
| P5 | Be ready to explain R9 honestly: you watched pension changes run and did not run them | R9 | `[grounded]` your account | your call |

**Evidence status.** Verified: none yet. Everything in your account is self-report.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers payroll administrator") were refused. Would confirm the employer exists and the ad is live; this is the RR1 check |
| 2. Role-family sweep | unavailable | One search ("payroll administrator salary Limerick Ireland") was refused. Would set the market band for the pay row |
| 3. Hiring manager's public footprint | unavailable | Not sent, because the permission refusal stopped the run. Declan Garvagh is named as reporting manager; would check public professional footprint only |

**Upgrade menu**

- Your own check of Marrowgate's website and People Team number → RR1 resolves or hardens; the decision could move to `conditional_go`.
- The live job posting link → confirms the ad and the pay row.
- Your right-to-work status → R1 moves from unclear to direct or failed.
- An anonymised payroll run summary or workbook → R3 and R6 to `high`.
- Your certificate copy → R5 to `high`.
- Search permission for the research targets above → market band for R2, and the employer's public footprint.

If you want, I can save this as a `tuesday-dossier.md` file.

1. Did you find the advert and the first contact through a site you know, and do you have the original link? This tests RR1.
2. Have you calculated or submitted PAYE, PRSI and USC yourself, and for what kind of pay run? This tests R4 and R10.
3. Are you eligible to work in Ireland without needing an employer to sponsor you? This is the hard gate R1; the answer is what matters, not a workaround.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.