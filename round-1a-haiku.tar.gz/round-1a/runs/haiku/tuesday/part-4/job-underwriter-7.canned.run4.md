**Worth applying: `conditional_go`.** The three hard gates (R1 NMC registration, R2 full UK driving licence, R3 Halifax base) are met on your CV, and no severe red flags came up. The open items are whether you can show written records and EPR use (R5, R13), your first caseload (R6), and Doppler (R14, absent). Interviews will probe those, so the conditions are below.

**Fit ledger.**

- `hard_gate`: direct: R1, R2, R3
- `must_have`: direct: R4 · unclear: R5 (Clear, timely written records)
- `important`: direct: R8 (Catheter care), R11 (Insulin administration) · adjacent: R6 (Own small caseload), R7 (Wound care incl. leg-ulcer), R12 (Care planning) · unclear: R9 (Continence care), R10 (End-of-life visits), R13 (Electronic patient record)
- `preferred`: absent: R14 (Doppler assessment)

**Opportunity ledger.** The employer is established: Calderbrook is a CIC with an NHS contract and 410 staff (RR3 is about the posting, not the employer). Pay and band are stated, and the role names senior nurse supervision (PS1). Two items need asking: mileage alongside pool cars (RR1) and the bottom of the pay band (RR2).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`). Your constraints were not given, so checks against pay, schedule and location preferences are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live through the careers page or the recruiter (RR3); (2) the written-records and EPR question (R5, R13) answers well in a conversation; (3) Doppler training is available to you, or you are comfortable learning it on the job (R14).
- **What would change this:** a gate failing, or the recruiter saying the role has no supervision in practice.

Your National Insurance number isn't needed for this, so I haven't used or repeated it. I also didn't search your NMC PIN or your licence; checking those is yours.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health careers Community Staff Nurse Band 5 Halifax"; fetched calderbrookhealth.example/about. Employer established (CIC, NHS contract, 410 staff). The live posting was not found; RR3 stays open |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 staff nurse pay range 2026", which returned the Wardround 2026 UK Community Nursing Pay Guide. Market calibration `[generic]`: one survey, England, n=1,240; interquartile range £32,400–£36,600; 61% paid mileage, 24% pool or lease car. Feeds RR2 and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned a community nursing forum speaker page: leads the Halifax district nursing team; spoke on nurse-led leg-ulcer clinics and Doppler training for staff new to community work. Professional footprint only. Feeds the interview plan (A2) |

**Role reality.**

| Item | Reading | Provenance |
|---|---|---|
| Title and organisation | Community Staff Nurse, Band 5, Calderbrook Community Health CIC, Halifax | `[grounded]` posting |
| Scope | Housebound adults at home; a small personal caseload with senior support; EPR | `[grounded]` posting |
| Pay | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` posting |
| Market position of pay | Floor sits below the survey's lower quartile; top sits within range | `[generic]` one 2026 survey |
| Employer | Established: CIC, NHS contract, 410 staff | `[grounded]` employer's about page |
| Contradictions | Pool cars plus mileage: unclear whether mileage applies to a pool car | `[inferred]` from posting wording |

**Evidence map.** Your CV is self-report, so nothing is `high` yet, and nothing is verified.

| # | Requirement (priority) | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse (hard_gate) | direct | medium | none | PIN stated; revalidation March 2028 | `[grounded]` CV | You check the register |
| R2 | Full UK driving licence (hard_gate) | direct | medium | none | Full category B, stated | `[grounded]` CV | You confirm the licence |
| R3 | Based in Halifax (hard_gate) | direct | medium | none | You live in Halifax | `[grounded]` CV | none |
| R4 | At least one year post-registration (must_have) | direct | medium | none | Five years as staff nurse | `[grounded]` CV | none |
| R5 | Clear, timely written records (must_have) | unclear | low | discovery | No records evidence in the CV | `[grounded]` CV silence | G1 |
| R6 | Own small caseload, supported (important) | adjacent | medium | transferability | Discharge-to-assess home visits; no caseload ownership | `[grounded]` CV | G3 |
| R7 | Wound care incl. leg-ulcer (important) | adjacent | medium | transferability | Pressure and surgical wounds stated; leg ulcers not | `[grounded]` CV | Bridge case, see E2 |
| R8 | Catheter care (important) | direct | medium | none | Stated | `[grounded]` CV | none |
| R9 | Continence care (important) | unclear | low | discovery | Not mentioned | `[grounded]` CV silence | G2 |
| R10 | End-of-life visits (important) | unclear | low | discovery | Not mentioned | `[grounded]` CV silence | G2 |
| R11 | Insulin administration (important) | direct | medium | none | Stated | `[grounded]` CV | none |
| R12 | Care planning (important) | adjacent | medium | transferability | Planning during discharge; not community care plans | `[grounded]` CV | Bridge case |
| R13 | Electronic patient record (important) | unclear | low | discovery | No EPR use stated | `[grounded]` CV silence | G1 |
| R14 | Doppler assessment for leg ulcers (preferred) | absent | none | capability | You've never done one; you said so | `[grounded]` your message | Closure path: training, see E3 |

**Gap recovery queue.** Rows only; the questions are in the closing block.

- **G1** (R5, R13), discovery: written records and EPR use are unestablished. Closes with an anonymised example of a note you wrote, and whether you used an electronic system.
- **G2** (R9, R10), discovery: continence and end-of-life work are unestablished. Closes with any home-based end-of-life or continence work, including on the ward.
- **G3** (R6), transferability: your home visits are real, but you've never owned a caseload. Limit: no ongoing caseload or prioritising your own week. Strengthener: a time you decided visit order alone and escalated.
- **G4** (R14), capability: Doppler is absent. Closure path: a short training course, `[generic]`. Ask whether the employer provides it. Their speaker page covers Doppler training for new community staff (`[inferred]`).

**Opportunity risk register.**

- **RR1** — unknown. Source: "£31,050–£37,800 a year plus mileage" beside "pool cars are provided." Hypothesis: mileage may not apply to pool cars, so total pay may be lower. `[inferred]` from posting wording. Question: "When a pool car is used for visits, is mileage paid, and at what rate?" Rule: compare total pay once known. Status: unresolved.
- **RR2** — risk signal, severity low. Source: "£31,050–£37,800." Hypothesis: the start may sit low in the band. `[generic]` from one 2026 survey (interquartile £32,400–£36,600). Question: "Where in the band would a new community nurse start, and what does progression look like?" Rule: proceed unless the start is below what you need. Status: unresolved.
- **RR3** — unknown. Source: "Current vacancies are listed on our careers page" (employer's about page). Hypothesis: the posting may be stale, or the careers page may list it differently. Question: "Is this role still open, and who would I interview with?" Rule: confirm before investing effort. Status: unresolved.
- **PS1** — positive signal. Source: "supported by a senior community nurse." Question: "What does the senior nurse's support look like in the first month?" Status: positive.

Severe red flags: none found.

**Application plan.** Every row needs your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV bullets with the discharge-to-assess home visits and first-week care plans | Bridge for R6 and R12 | `[grounded]` CV | pending your approval |
| E2 | Describe wound care as pressure and surgical wounds; don't claim leg-ulcer experience | R7 is adjacent, not direct | `[grounded]` R7 | pending your approval |
| E3 | Ask whether Doppler training is provided in your first months | R14 absent; closure path | `[generic]` training pattern | pending your approval |
| A1 | Ask the recruiter about mileage with pool cars and whether the posting is live | RR1, RR3 | `[grounded]` RR1, RR3 | pending your approval |
| A2 | Ask Rhiannon Mabbott, "Your talk covered Doppler training for staff new to community work; is that offered to new starters here?" | Public talk, professional footprint | `[inferred]` from speaker page | pending your approval |

**Evidence status.** Verified: none yet. Your CV claims are self-reported until you confirm them in conversation.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0 (already stated above).

**Upgrade menu.**

- **The careers page or recruiter's confirmation of the live posting:** lifts RR3 from unknown to verified.
- **An anonymised example of a written note or plan you wrote:** would move R5 from low to medium, and is inspectable.
- **Your pay floor, and whether you need mileage paid:** lets the hard-gate checks against your constraints run (currently unknown).
- **Deeper company diligence and recent news (L2):** up to 5 more searches and 2 more fetches. Offered once; say if you want it.

I can also save this as `tuesday-dossier.md` if you'd like a file to keep.

Three questions, tagged to the gaps:

- **G1:** Have you written clinical records on an electronic system? Share an anonymised example of a note you wrote, and how you kept it timely on a busy shift.
- **G2:** Have you supported a patient at home with continence care or at end of life, on the ward or in the discharge team?
- **G3:** In the discharge-to-assess team, did you ever decide the order of your visits and escalate on your own? Give one example.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.