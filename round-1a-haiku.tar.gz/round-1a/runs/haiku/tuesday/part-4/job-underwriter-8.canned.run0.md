**Decision: `no_go`. Don't send anything, don't pay anything, and don't deposit the cheque.** Your instinct is right. This job is very likely a scam, and the recruiter's requests match a well-known pattern: a fake cheque, then a request to send most of it onward.

**Research tier: L1, searches 3 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers remote order processing coordinator". Both returned no results, so the employer is not established from attributable sources. |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland". Returned the Pennoral 2026 Ireland Customer Operations Pay Guide (pennoral.example/2026-ireland-customer-operations-pay-guide). Market calibration below. |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a Telegram handle, so there was no query to form. |

**Decision snapshot**

**Not worth applying to. Status: `no_go`.** The reason is three confirmed severe red flags (RR1, RR2, RR3), each a request the recruiter made of you directly. A confirmed severe red flag forces `no_go`, and nothing in the posting or the chat changes that.

**Fit ledger.**
- `hard_gate`: unclear: R3 (Pay, €30,000 a year floor)
- `must_have`: adjacent: R2 (Order processing or coordination work); direct: R1 (Spreadsheet confidence)
- `important`: unclear: R4 (Good written English)

R1 is `direct` on your Excel tracker, which is a self-report with no artifact, so it is `medium`. R2 is `adjacent`: Zendesk ticket work and parcel-courier customer service carry over, but no order-processing role is on record. R3 cannot be settled from the posting, because it advertises "up to €26 an hour" for 15 to 30 hours a week with commission and no annual figure.

- **Hard gates:** unconfirmed: R3 (Pay, €30,000 a year floor); candidate constraints given: pay floor. At €26 an hour you would reach €30,000 only at about 22 hours a week for 52 weeks. The top of the advertised range is about €40,500 and the bottom about €20,300, before commission, which the posting does not quantify.
- **Severe red flags:** RR1, RR2, RR3, RR4 (`severity: high`), and the standing employer entry (RR5).
- **Conditions for go:** none. No condition in the posting or the chat can clear RR1 to RR3.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", with no attributable web presence found | `[grounded]` posting and chat; search returned nothing |
| Pay | "Up to €26/hour plus commission", 15–30 hours a week, withheld annual figure | `[grounded]` posting |
| Market calibration | Ireland order-processing and customer-operations coordinators: median €31,200, interquartile range €28,400 to €34,100, salaried roles only. One source, n=1,140. | `[generic]` Pennoral 2026 pay guide; this is a band, not this employer's offer |
| Unknowns | Legal entity, contract type, the real pay structure, whether any employer exists | — |
| Contradictions | The posting says "no calls or video interviews" but the chat promises a "chat interview". A cheque, bank transfer and personal documents are all requested before any offer. | `[grounded]` chat messages |

**Evidence map (candidate side)**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Confident with spreadsheets, attention to detail | must_have | direct | medium | presentation | You keep your team's weekly Excel tracker. Self-reported, no artifact. | `[grounded]` your background |
| R2 | Order processing or coordination | must_have | adjacent | medium | transferability | Parcel-courier customer service, about 60 Zendesk tickets a day, trained two starters. No order-processing role. Limit: no order-entry or fulfilment work on record. | `[inferred]` from your background |
| R3 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | high | hard_gate | Your own stated floor is `high` confidence. The posting does not settle it. | `[grounded]` your statement; posting |
| R4 | Good written English | important | unclear | low | discovery | Written customer-service work supports it; nothing inspected. | `[inferred]` |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The request asks you to pay before any job starts. | `[grounded]` the chat, plus `[generic]` that this request is a known scam pattern | Which employer's own payroll system pays new starters and asks them to buy equipment first? | confirmed |
| RR2 | Cheque deposit and onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 ... and transfer the rest to our equipment partner." | Deposit a cheque, keep part, and send the rest out. If the cheque bounces, you owe the money back. | `[grounded]` the chat | Does your company pay wages by cheque, and does it ever ask staff to send money to a third party? | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | Sensitive identity and bank details are requested before any written offer. | `[grounded]` the chat | Will you send a written offer on your own domain before any payroll or identity details are needed? | confirmed |
| RR4 | Whole hiring process by chat | risk_signal | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interviews and offers happen only in chat, which a legitimate employer rarely does. | `[generic]` pattern for this kind of posting; the chat is the grounded part | Can you confirm a video interview and a written contract from your own domain? | unresolved |
| RR5 | Employer not established | risk_signal | high | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Searches returned nothing. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay below your floor | risk_signal | medium | "up to €26/hour plus commission" | At 15–30 hours a week you may not reach €30,000 without commission. | `[inferred]` from the posting's arithmetic against your stated floor | What annual pay do you expect at 40 hours a week, and how is commission calculated? | unresolved |

**Verify with the employer, not the sender.** I could not find an independent employer contact, so the employer check cannot be done from here. Until the recruiter's identity is verified, the chat, the address `velloway.hr@postmail.example`, and the handle `@VellowayHiring` are all unverified. This job is very likely a scam. Don't deposit the cheque. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't send your IBAN, PPS number, passport photo, or any other personal details to this chat | RR3 | `[grounded]` the chat | pending your approval |
| P2 | Don't pay the €349 and don't deposit the €2,850 cheque | RR1, RR2 | `[grounded]` the chat | pending your approval |
| P3 | If you have already sent anything, call your bank now, and report the chat to Gardaí and to the Telegram account | Limits further loss | `[generic]` standard advice for this pattern | pending your approval |
| P4 | Look for roles on an employer's own careers site that pay a stated salary and interview by video | Your background fits roles like this | `[grounded]` your background | pending your approval |

**Evidence status**

Verified: your pay floor (R3) and your spreadsheet and customer-service background (R1, R2), from your own statements. Not verified: anything about the employer. Verified: none yet for the employer.

**Upgrade menu**
- A link to the live posting on a job board or the employer's own careers page, and the domain the recruiter writes from → RR5 and RR4 could close.
- A written offer on the employer's domain with a named legal entity and a salary in writing → RR6 can be checked, though RR1 to RR3 would still stand.
- A deeper research pass on Velloway Logistics (company registration, reports from other applicants; up to 5 more searches and 2 more fetches). Say the word and it runs.

Questions:
1. Can you share the job-board link where you found this posting, and any company name or domain the recruiter uses outside Telegram?
2. Have you sent anything yet (bank details, a photo of ID, or money)?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.