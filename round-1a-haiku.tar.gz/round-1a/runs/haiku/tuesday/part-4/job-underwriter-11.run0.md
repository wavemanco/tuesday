This is a go/no-go question on specific postings, so I'll load the job-search skill that handles it.
The playbook requires several reference files before I build anything. I'll read them in parallel.
The playbook's default research tier is L1: up to 5 searches and 2 fetches, aimed at the company's own site and a role-family pay and scope check. The search tool is deferred, so I'll load it first.
**Short answer:** Apply to the Duinvaart Operations Analyst role. Skip the Kroonhaven Supply Planner role.

I couldn't check either company online. The web searches were refused by the permission check, so the employers and postings are unverified.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

## Posting 1: Duinvaart Cold Chain, Operations Analyst — `conditional_go`

**Fit ledger**
- `hard_gate`: unclear: D1 (hybrid, three days a week in Rotterdam)
- `must_have`: direct: D2 (2+ years in ops analysis), D3 (SQL), D4 (Power BI or Tableau), D5 (on-time delivery tracking)
- `important`: direct: D7 (weekly Power BI dashboards), D8 (depot managers and route changes) · adjacent: D6 (temperature compliance)
- `preferred`: adjacent: D9 (Dutch)

**Hard gates:** none failed; unconfirmed: D1 (hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.

**Opportunity:** Scope is clearly defined. The salary is not stated, and the employer is unverified.

**Conditions for go:** (1) the posting appears on Duinvaart's own careers page; (2) you can work in Rotterdam three days a week (D1); (3) you frame temperature compliance as adjacent, not as experience you have.

**Severe red flags:** none found.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam | [grounded] posting; existence unverified |
| Scope | Track on-time and temperature compliance across a refrigerated fleet; weekly Power BI dashboards; route changes with depot managers | [grounded] posting |
| Schedule | Hybrid, three days a week in the Rotterdam office | [grounded] posting |
| Pay | Not stated | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, 3 days/week, Rotterdam office | hard_gate | unclear | none | hard_gate | Posting states it; your constraint isn't on record | [grounded] posting | Q1 |
| D2 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years as an operations analyst | [grounded] your background | none |
| D3 | Strong SQL | must_have | direct | medium | none | Daily SQL use; no artifact inspected yet | [grounded] your background | none |
| D4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | [grounded] your background | none |
| D5 | On-time delivery tracking | must_have | direct | medium | none | Your depot managers use the on-time dashboard | [grounded] your background | confirm your role in building it (see plan) |
| D6 | Temperature compliance, refrigerated fleet | important | adjacent | low | transferability | Monitoring against targets carries over; you have no temperature or cold-chain data | [inferred] from D5 | Q2 |
| D7 | Weekly dashboards in Power BI | important | direct | medium | none | Same evidence as D4 | [grounded] your background | none |
| D8 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review; whether you changed routes yourself isn't stated | [grounded] your background | Q2 |
| D9 | Dutch (a plus) | preferred | adjacent | medium | transferability | Conversational, not fluent | [grounded] your self-report | none |

**Gap recovery queue**
- **D6 (transferability):** The bridge is your on-time compliance tracking. The limit is that you have no temperature, cold-chain or refrigerated-fleet work. The strengthener is any threshold or alert metric you tracked. `[inferred]` bridge from D5.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting unverified | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale, or the employer may be small and hard to find | [generic] pattern for companies this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in posting) | The band is unchecked, so the offer may sit below expectations | [generic] pattern; band not checked | What is the salary range for this role? | unresolved |
| RR3 | Scope and tools are named | positive_signal | — | "Track on-time delivery and temperature compliance…" | The role is defined and measurable | [grounded] posting | Which KPIs and thresholds does this role own? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find the posting on Duinvaart's careers page before you apply | RR1 | [grounded] RR1 | your action |
| P2 | Tailor the CV to SQL, Power BI and the on-time dashboard; `resume-tailor` can do this | D3–D5 | [grounded] your background | pending your approval |
| P3 | Proposed bullet: "Ran the weekly route-performance review; worked daily in SQL and Power BI, including the on-time delivery dashboard depot managers use." Do not use "built" or "maintained" unless you did it. | D5 | [grounded] your sentences | pending your approval |

## Posting 2: Kroonhaven Foods, Supply Planner — `no_go`

The status is not a gate failure. Two must-haves, 3+ years of FMCG planning and SAP IBP or a similar system, are absent from your background, and no short closure path exists for this posting. Nothing here shows a red flag.

**Fit ledger**
- `hard_gate`: unclear: K1 (on-site in Utrecht)
- `must_have`: adjacent: K4 (fluent Dutch) · unclear: K5 (advanced Excel) · absent: K2 (3+ years FMCG planning), K3 (SAP IBP or similar)
- `important`: adjacent: K6 (weekly S&OP, capacity against forecast)

**Hard gates:** none failed; unconfirmed: K1 (on-site in Utrecht); candidate constraints not given — checks against them unknown.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | On-site, Utrecht | hard_gate | unclear | none | hard_gate | Posting states it; your constraint isn't on record | [grounded] posting | Q1 |
| K2 | 3+ years FMCG supply or demand planning | must_have | absent | medium | capability | You've never worked in planning; your ops work doesn't count as planning years | [grounded] your statement | none; closure is a planning role, not this post |
| K3 | SAP IBP or similar planning system | must_have | absent | medium | capability | No planning-system use stated | [grounded] your background | none |
| K4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational; fluency is the limit | [grounded] your self-report | none |
| K5 | Advanced Excel | must_have | unclear | low | discovery | Excel isn't mentioned; SQL and Power BI are | [grounded] absence | Q3 |
| K6 | Weekly S&OP; capacity against forecast | important | adjacent | low | transferability | You ran a weekly performance review, but not capacity or forecast work | [inferred] from your review | none |

**Gap recovery queue**
- **K2 (capability):** No credible adjacent evidence. The closure path is a planning role, not this posting. `[generic]` that planning-years requirements are usually screened literally.
- **K4 (transferability):** The bridge is conversational Dutch. The limit is that it is not fluent. No strengthener is in hand.

**Risk register:** Only the shared unknowns in posting 1 apply here: RR1 (employer unverified) and RR2 (salary not stated).

**Application plan:** Don't apply now. If Q3 turns up planning or forecasting work, the decision moves to `hold_pending_answers`, and I'll rerun this assessment.

## Evidence status

Verified: none yet. Your background is intake prose, not a confirmed claim.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both company searches were refused by the permission check. Would have moved RR1 for both postings. |
| 2. Role-family sweep | unavailable | Both pay and scope searches were refused. Would have moved RR2 and the market calibration. No salary band is given here, because I won't use remembered figures. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

**Upgrade menu**
- Permission to run web search: the employer checks and salary checks for both postings would run.
- Your answer to Q1: resolves D1 and K1.
- Any temperature or threshold metric you tracked: moves D6 toward `direct`.
- Your Excel and planning-tool experience: resolves K5 and K3.
- A hiring manager's name: unlocks target 3.

If you want this assessment saved as a `tuesday-dossier.md`, say so.

**Questions**
1. Where do you live, and how long a commute will you accept for three days a week in Rotterdam and for on-site work in Utrecht? (D1, K1)
2. Did your on-time dashboard or route review ever track temperature, cold-chain or alert thresholds, and did you decide route changes yourself or only recommend them? (D6, D8)
3. Have you done any forecasting, capacity or planning-tool work, and how comfortable are you with advanced Excel (formulas, pivots, modelling)? (K5, K3)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.