**Yes, take the call (`conditional_go`).** The company checks out on public sources, and the WhatsApp message is a normal way for a six-person startup to schedule. Nothing you've described asks for money, bank details or ID, so nothing here is a scam signal.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 salary); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Fit ledger:**
  - `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000 salary)
  - `must_have`: direct: R3, R4, R5, R8 · adjacent: R6 (Owns the booking flow end to end)
  - `important`: adjacent: R7 (Research calls with school owners) · absent: R9 (Designer on a team of one)
- R6 — adjacent, checkout is one stage of the flow; R7 — adjacent, your research was with travel customers, not school owners; R9 — absent, you've never been the only designer.
- **Opportunity ledger.** Sound and specific: the scope is clear and the salary is posted (RR1, RR4 positive). Two things are open: the "first designer" role may have no design peers (RR2), and the 0.5–1% equity has no stated terms (RR3).
- **What would change this:** the conditions for `conditional_go` are (1) your pay floor sits at or below the posted range (R2); (2) the first-designer answer on the call is one you can work with (RR2); (3) the equity terms are stated (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 by Ronan Kehoe and Saoirse Doyle | `[grounded]` about page, fetched |
| Mandate | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` JD; careers page matches |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` JD and careers page |
| Salary and equity | €52,000–€60,000 plus 0.5–1% equity; equity vesting and terms not stated | `[grounded]` JD and careers page |
| Market calibration | Tillerby 2026 Ireland survey (n=520), product designers with 3–5 years: median €57,000, IQR €51,500–€62,000. The posted range brackets the median. | `[generic]` role-family sweep; snippet only, not fetched |
| Co-founder footprint | Ronan Kehoe: co-founder and CEO; previously product lead for five years at a Galway travel-software company | `[grounded]` public profile snippet, not fetched |
| Contact | Scheduling by WhatsApp, with the invite by email. Scheduling by chat for an interview held elsewhere is not a signal. | `[grounded]` your message |
| Unknowns | Equity terms; whether the role has design peers; your pay floor | — |
| Contradictions | None between the JD, careers page and about page | `[grounded]` three pages compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, Galway two days a week | hard_gate | direct | medium | none | You moved back to Galway last year. Self-report, not checked. | `[grounded]` intake | none |
| R2 | Base pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not given, so the check is unknown. | `[grounded]` JD | Q1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. Self-report. | `[grounded]` intake | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use. Self-report. | `[grounded]` intake | Share a file to raise to high |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. | `[grounded]` intake | none |
| R6 | Owns the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout. End-to-end ownership is not stated. | `[grounded]` intake; `[inferred]` checkout as one stage of a booking flow | Share the case study |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Your research was with travel customers. | `[grounded]` intake; `[generic]` small-operator buyers differ from consumer travel customers | Q3 |
| R8 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers. | `[grounded]` intake | none |
| R9 | Designer on a team of one | important | absent | medium | transferability | You have never been the only designer. | `[grounded]` your statement | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | End-to-end booking ownership (R6) | transferability | Checkout redesign, not the whole flow | A case study showing what you decided beyond checkout | `[grounded]` intake |
| G2 | School-owner research (R7) | transferability | Consumer travel research | Any interview or session notes with small operators | `[grounded]` intake; `[generic]` buyer difference |
| G3 | Solo design work (R9) | transferability | Squad work with engineers | Whether design peers existed on that squad | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posted pay inside market band | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The range is realistic for the title and experience | `[generic]` survey median | What range has been budgeted for this hire? | noted |
| RR2 | First designer, possibly no design peers | risk_signal | low | "You would be our first designer" | Critique and design decisions may sit with the founders | `[inferred]` from "first designer" against silence on design peers | Who reviews design work day to day, and which product decisions would I make without a design colleague? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Terms may be negotiable or may need explaining | `[grounded]` JD silent on vesting | What is the vesting schedule, and on what valuation basis is the equity granted? | unresolved |
| RR4 | Employer verified | positive_signal | — | "Six people, based in Galway" | The company is real and the posting is live | `[grounded]` about page and careers page | What does the booking-flow work look like over the next six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Accept the 45-minute call. Before sharing anything beyond your availability, confirm the calendar invite came from the fernquay.example address. | The call is the next step, not a request for money or bank details | `[grounded]` WhatsApp message; careers page domain | pending your approval |
| A2 | On the call, ask RR2 and RR3 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Prepare to describe R6, R7 and R9 in your own words only: what you owned, and what you did not. mock-interview can drill this once you're set. | Your own sentences are what you'll be asked to defend | `[grounded]` R6, R7, R9 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay Product Designer job Galway". Fetched the careers page (fernquay.example/careers/product-designer) and the about page (fernquay.example/about). Moved the role reality row on organization and the contradictions row: the employer exists as described, the posting is live, and the jobs address is on the company domain. |
| 2. Role-family sweep | yes | Searched "Product Designer salary Ireland 2026 €52,000 €60,000". It returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report), read as a search snippet only. Moved the market calibration line, `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder". It returned a public profile (linkedin.example/in/ronan-kehoe), read as a snippet only. Moved the co-founder row in role reality: the title is confirmed, and the scope read is unchanged. |

## Upgrade menu

- The checkout case study you sent Fernquay, shared here → R6 and R4 can move if it shows your decisions beyond checkout.
- Your pay floor → R2 closes.
- A Figma file or your usability-session notes → R4 and R5 can move to high.
- A deeper research pass on Fernquay (funding, hiring, public reviews; up to 5 more searches and 2 more fetches) → say the word and it runs.

If you want, I can save this as a tuesday-dossier.md to take into the call.

1. **R2:** What is your lowest acceptable base salary, and is €52,000 above or below it?
2. **R9:** Have you ever worked on a team where you were the only designer, even for a short stretch?
3. **R7:** Have you talked with business owners outside travel, or only with your travel-booking customers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.