**Decision: no_go. Don't send anything to this contact.** That includes your IBAN, your PPS number, the passport photo, and the €349. This has the hallmarks of a fake-job scam. Your background fits the role well, but the opportunity is not safe to pursue.

**Hard gates:** None of the role's stated terms breaks a gate. Pay is the exception: at €26/hour, base pay is about €20,300 at 15 hours a week and about €40,600 at 30 hours. Your €30,000 floor is met only at roughly 22+ hours a week, before commission, which they don't quantify. [grounded]

**Fit (your side):** Strong. Zendesk ticket volume, training new starters, and the Excel tracker map directly onto the posting's requirements. Fit is not the problem. Scam postings are often written to match a candidate's profile exactly.

**Opportunity (their side):**
1. **You pay them first.** A €349 "equipment kit" fee, refunded "with your first wages." Legitimate employers supply their own equipment. [grounded]
2. **The cheque is the classic overpayment scam.** They send a €2,850 cheque, you deposit it, keep €350, and transfer €2,500 onward. Cheques can take days or weeks to clear, then bounce or get reversed as fraud. The money you sent is gone, and you're liable for it. [generic]
3. **Identity data before any interview.** IBAN, PPS number and passport photo are requested before the "chat interview." [grounded]
4. **No verifiable company or contact.** Telegram-only hiring, no calls or video, "passed screening" within minutes, and a contact address on a generic postmail domain, not a company domain. [grounded]
5. **Employer unverified.** I did no web research (L0), so I could not confirm that Velloway Logistics exists as described. That is a standing finding, and it stays open.

**Immediate steps:**
- Don't send the IBAN, PPS number, passport or any money, and don't deposit any cheque they send.
- If a cheque arrives, tell your bank before you do anything with it.
- You can stop replying and block the account on Telegram.
- If you have already shared the IBAN or PPS number with anyone, tell your bank and watch the account. Consider reporting to the Gardaí.

**Research tier: L0, no searches.** This verdict rests on the posting and the messages, not on any check of the company.

**Dossier offer:** When you're done, I can save this assessment as `tuesday-dossier.md`.

**Upgrade menu: what would change the call.** The €349 fee and the cheque-transfer arrangement each disqualify this role on their own, so nothing below would make it a go on its own:
- A live posting on Velloway's own website or careers page, with a named hiring manager.
- A company registration you can look up with Ireland's Companies Registration Office (CRO), matching the name and address on their site.
- A phone number from that website, not from the chat, that you call to confirm the role.
- A written offer on company letterhead, sent only after you've verified the company.

**Questions:**
1. Which jobs site did you find the posting on, and is there a link? I can check that the listing is still live.
2. Would you like me to look for legitimate remote customer-service or operations roles that use your Zendesk and Excel experience? If yes, `resume-tailor` can then adapt your CV to a specific one.

Answer either, both, or neither; silence is fine.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.