**Yes, it looks like a real company, and the call is worth taking.** `conditional_go`: apply and take the call, with the pay and equity terms checked before any offer.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given. Checks against your own pay floor are unknown.
- **Strong fit on the core craft requirements:** the evidence map below shows direct fit on most must-haves. The one real gap is being the only designer, which you have never done.
- **Opportunity:** the employer checks out, the pay sits inside the market band, and no red flags were found. The open items are equity terms and how product decisions are split between the founders.
- **What would change this:** the call confirms the equity terms and the decision split (RR1, RR3), and your pay floor is at or below €52,000 (R2).

**Research tier: L1 — searches 4 of 5, fetches 2 of 2**

## Role reality

- **Employer:** Fernquay exists as described. Its About page says it is six people in Galway, founded in 2023 by Ronan Kehoe and Saoirse Doyle, and funded by its customers. Its product is Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Its careers page shows this exact role, with the same salary, hybrid terms and an application address on its own domain. So the standing "employer not established" entry does not apply.
- **Ronan's public footprint:** co-founder and CEO, previously product lead for five years at a Galway travel-software company. That is a search snippet; I did not open the profile.
- **Market calibration** `[generic]`: a 2026 Ireland design salary survey (n=520) puts product designers with 3–5 years at a median base of €57,000, with an interquartile range of €51,500–€62,000. The posted €52,000–€60,000 sits inside that range, near the median. This is a pattern for the market, not a claim about Fernquay's offer.
- **Contradictions:** none found between the posting and the company's own pages.

## Evidence map

| # | Priority | Requirement | Fit | Gap | Confidence | Provenance |
|---|---|---|---|---|---|---|
| R1 | hard_gate | Hybrid, two days a week in Galway | direct | — | high | `[grounded]` you live in Galway |
| R2 | hard_gate | Salary €52,000–€60,000 | unclear | discovery | medium | `[grounded]` posting figure; your floor not given |
| R3 | must_have | 3+ years product design | direct | — | high | you stated 4 years |
| R4 | must_have | Strong Figma | direct | — | high | you stated daily use |
| R5a | must_have | Has run own user research | direct | — | high | monthly customer usability sessions |
| R5b | important | Research calls with school owners | adjacent | transferability | medium | the method transfers; the customer segment does not |
| R6 | must_have | Works directly with engineers | direct | — | high | squad of four engineers |
| R7 | must_have | Owns the booking flow end to end | adjacent | transferability | medium | you redesigned checkout; you did not own it end to end |
| R8 | important | Works as the only designer | unclear | discovery | low | never done it |
| R10 | preferred | Booking-domain experience | adjacent | transferability | medium | travel-booking checkout is structurally close |

## Gap recovery queue

- **G1 (R8, discovery):** you have never been the only designer. Closure: a question in the call about how the company plans for the first 90 days of a design hire, and whether anyone reviews design work.
- **G2 (R7, transferability):** you have owned a checkout redesign, not a whole flow. Bridge: the checkout work covers the same ground at a smaller scale. Limit: you have not owned booking setup, schedules or payments for a school. Strengthener: the one real project the posting asks for.
- **G3 (R5b, transferability):** the research method carries over. Limit: school owners are a different customer group from travel customers.

## Risk register

- **RR1 · unknown · high-impact:** the 0.5–1% equity has no vesting, strike price or valuation basis stated. Verification question for the employer: *"What is the vesting schedule and strike price for the 0.5–1%, and what is the most recent valuation it was based on?"*
- **RR2 · positive signal:** the About page says the company is funded by its customers. That suggests revenue rather than a funding round. Runway is unknown. Verification question: *"What is the company's runway, and is the design hire funded for at least 12 months?"*
- **RR3 · risk_signal · low:** six people, with a CTO and two engineers. Product direction runs through the CEO. `[inferred]` from the posting naming Ronan as the main counterpart. Verification question: *"How are product priorities set between you and Saoirse, and who decides when design and engineering disagree?"*

WhatsApp: the company's invite came by email with a video link, and the chat was only for scheduling. The rules treat that as no signal, and there were no requests for money, deposits or bank details.

## Application plan

You have already applied and been invited to a 45-minute video call with Ronan and Saoirse. Before joining:

1. Check the calendar invite came from the company's own domain, not a personal address.
2. Send the one real project the posting asks for, if you have one. The checkout case study has already been shared.
3. In the call, describe the checkout redesign as what you did: the research, the usability sessions, and shipping with four engineers. Do not describe it as end-to-end booking ownership.
4. Ask RR1 and RR3 directly.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | About page and careers page on the company's domain; founder snippet |
| 2. Role-family sweep | yes | 2026 Ireland design salary report |
| 3. Hiring manager's public footprint | yes | search snippet for Ronan Kehoe; profile not opened |

If you want deeper diligence (funding, reviews, recent news), I can run it. That is up to 5 more searches and 2 more fetches.

I can also run a full dossier on this role if you want to keep it.

**Questions**

- **R2 — What is your pay floor? Is €52,000 one you can accept, and would any figure in the €52,000–€60,000 range make the pay gate fail for you?** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **R8 — Are you open to being the only designer for the first year, or is that a condition you would want clarified before accepting?** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.