**Yes, worth applying, and it looks legit.** Fernquay's own site lists the same role and terms as the posting, and the co-founder has a public professional profile. The status is `conditional_go`, with one open check: whether €52,000–€60,000 meets your base-salary floor, which you haven't told me.

## Decision snapshot

**Status: `conditional_go`**

- **Fit ledger.**
  - `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000)
  - `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
  - `important`: adjacent: R9 (Research with school owners) · absent: R8 (First designer, no design peers)
  - `preferred`: adjacent: R10 (Booking domain)

  R7 is checkout work, which is adjacent to owning the whole flow; R8 is no record of working alone as the designer; R9 is travel customers, not owner-run schools.
- **Opportunity ledger.** The employer checks out (RR4). The open risks are a solo design role (RR1), a broad remit (RR2) and unstated equity terms (RR3). Nothing is a red flag.
- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your base floor sits at or below €60,000 (R2); (2) you can describe your sole-designer situation (R8) accurately, without claiming more than you did.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: customer-funded booking software for sea-kayak, surf and sailing schools in Ireland and Scotland; six people in Galway; founded 2023 | `[grounded]` About page |
| Role | First product designer: owns the booking flow, runs research with school owners, ships with two engineers | `[grounded]` posting and careers page |
| Terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in Galway | `[grounded]` posting and careers page (same terms) |
| Reporting line | Ronan Kehoe, co-founder and CEO | `[grounded]` LinkedIn search snippet |
| Scope read | One designer covering research, flow design and shipping in a six-person team: a wide remit | `[inferred]` from three functions in one post against team size |
| Market calibration | Ireland, product designers with 3–5 years: median base about €57,000, interquartile range €51,500–€62,000; the posted range sits inside it | `[generic]` Tillerby 2026 salary report (search snippet, not fetched); a pattern, not this employer's offer |
| Unknowns | Equity vesting and strike price; whether there is a design budget or tooling; Saoirse Doyle's title | — |
| Contradictions | None between posting, careers page and About page. The WhatsApp message calls Saoirse Doyle the CTO; the About page names her only as a co-founder | `[grounded]` fetched pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so two office days fit. Confidence grades your residence fact, not a stated constraint | `[grounded]` your background; `[inferred]` that residence meets the gate | none |
| R2 | Pay €52,000–€60,000 | hard_gate | unclear | none | hard_gate | No floor stated, so the check is unknown. The posted range sits near the market median | `[grounded]` posting; `[generic]` salary band | Ask your floor (closing question 1) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as product designer at a Dublin travel-booking company. Self-report; no artifact yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated; no file inspected | `[grounded]` your background | Upgrade menu: a Figma file from checkout work |
| R5 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Not stated whether you planned and ran them alone | `[grounded]` your background | Confirm in the call prep |
| R6 | Works directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, the last stage of a booking flow. Ownership from research through release is not stated | `[grounded]` your background; `[inferred]` adjacency | Gap G1; closing question 2 |
| R8 | Work as the first designer, with no design peers | important | absent | medium | transferability | You have never been the only designer. The squad experience carries over; deciding alone does not | `[grounded]` your background; `[inferred]` requirement from "first designer" | Gap G2; closing question 3 |
| R9 | Research with owners of small schools | important | adjacent | medium | transferability | Research with travel-booking customers, a different customer type | `[grounded]` your background; `[inferred]` adjacency | Gap G3 |
| R10 | Booking domain: sea-kayak and surf schools | preferred | adjacent | medium | transferability | Travel-booking experience; no sea-kayak or surf knowledge stated | `[grounded]` your background; `[inferred]` adjacency | Gap G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end ownership (R7, must_have) | transferability | Checkout redesign confirmed; ownership from research to release not stated | A must-have at `adjacent`; a clear account narrows the objection | Research that set the checkout direction; a launch you shipped with engineers; decisions you made without sign-off | The checkout case study you sent; the research readout | `[inferred]` bridge from the checkout work; `[generic]` that this is the likeliest objection |
| G2 | Working without design peers (R8, important) | transferability | Squad of four engineers; no solo design record | This company is one designer's first hire, so the question is likely | Any project where you made calls with no reviewer; work where you set the research plan alone | A project note or review outcome | `[inferred]` from "first designer"; `[generic]` that first hires get this question |
| G3 | Owner-run school customers (R9, R10, important) | transferability | Travel-booking customers, not sea-kayak or surf schools | Research with school owners is the core of the role | Customer interviews with small business owners; any booking flow with seasonal or group bookings | Interview guide or notes, anonymized | `[grounded]` posting; `[inferred]` adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Solo design role in a small team | risk_signal | medium | "our first designer" | No design review, process or tooling beyond the one hire | `[inferred]` from "first designer" against a six-person team | Who reviews design decisions day to day, and what has shipped without a designer so far? | unresolved |
| RR2 | Broad remit for one person | risk_signal | low | "own the booking flow end to end, run research calls … and ship alongside our two engineers" | Year-one scope may exceed one person's capacity | `[inferred]` from three functions in one post | Which parts of the booking flow are in scope in the first six months, and how is research weighed against shipping? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | Equity value depends on vesting, strike price and dilution, none stated | `[generic]` pattern for early-stage equity offers | What is the vesting schedule, and what is the strike price? | unresolved |
| RR4 | Transparent, consistent posting | positive_signal | — | "we would rather see one messy real project than a polished deck" | The company is consistent across posting, careers page and About page, and is funded by its customers | `[grounded]` fetched careers and About pages | What project would you want the designer to start on first? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the checkout case study, and state which parts you owned | R7, R3 | `[grounded]` case study and your background | pending your approval |
| P2 | On the sole-designer question, say: "I've worked in a squad with four engineers, and I've never been the only designer on a team." | R8. Audit: each clause traces to your sentences; nothing added | `[grounded]` your sentences | pending your approval |
| P3 | Ask on the call: who reviews design decisions, what the first six months look like, and the equity vesting | RR1, RR2, RR3 | `[generic]` pattern for early-stage hiring calls | pending your approval |
| P4 | Check the calendar invite comes from a fernquay.example address before you share anything | The contact moved to WhatsApp; scheduling by chat is not a warning sign | `[grounded]` posting names fernquay.example | your call |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay Product Designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) and "About Fernquay" (fernquay.example/about). The entity exists as described, the posting is live, and its terms match. Standing "employer not established" entry cleared |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland 3 years experience 2026", which returned the Tillerby 2026 Ireland Design Salary Report (tillerby.example/2026-ireland-design-salary-report). Snippet only, not fetched. Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned a LinkedIn profile (linkedin.example/in/ronan-kehoe). Snippet only, not fetched. Moved the scope read: co-founder and CEO, previously five years as product lead at a Galway travel-software company |

## Upgrade menu

- You have a checkout case study (the one Ronan liked). Sharing it with a note on what you owned would move R7 toward `direct`; a Figma file from it would raise R4 to `high`.
- Anonymized usability notes or a research readout would raise R5 to `high`.
- A brief for the first six months from the company would close RR2.
- Your base-salary floor closes R2, which is the one gate that could change the decision.
- A deeper research pass on Fernquay (funding, reviews, recent news; up to 5 more searches and 2 more fetches) is available if you want it, and I won't run it unless you say so.

If you want, I can save this as `tuesday-dossier.md` to re-read before the call.

For the 45-minute call, `mock-interview` can drill the questions with Ronan and Saoirse.

Three questions:

1. **R2:** What is the lowest base salary you'd accept? If it sits above €60,000, this stops being a go.
2. **G1 (R7):** Did you own the checkout redesign from research through release, or did you join it partway?
3. **G2 (R8):** Have you ever made design calls with no designer or peer to review them? If so, what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.