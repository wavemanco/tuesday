Aoife, the short answer to your question: asking for bank details and a PPS number is normal, but only after a signed contract and through a channel you've verified. A passport scan by email is the part to be careful with. I couldn't check the employer myself, though, so this stays conditional.

**Status: `conditional_go`.** Apply on the offer only after you've verified the employer yourself. Send nothing sensitive until then.

**Is it normal?** [generic] Irish employers need a PPS number for Revenue (PAYE) and bank details to pay you, so both are routine once you've accepted. A right-to-work check is also routine, but it's usually done against the original document, and a scan sent by email is the riskier form. Your first reply should ask for the written contract, not your details.

**Fit ledger.**

- `hard_gate` — direct: R1 (pay, €40,000 against the posted €38,000–42,000) · unclear: R2 (hybrid, two days a week in the Limerick office)
- `must_have` — direct: R3 (2+ years running payroll), R4 (strong Excel), R5 (payroll qualification, Payroll Technician 2024) · unclear: R6 (working knowledge of Irish PAYE, PRSI and USC)
- `important` — direct: R7 (starters, leavers, payroll-to-ledger reconciliation) · adjacent: R9 (90 staff against the 240 in the role) · unclear: R8 (pension changes)

R3, R4, R5 and R7 are `medium` because the evidence is your CV, which is the ceiling at intake. R6 has no evidence yet. R8 is one you haven't done.

**Opportunity ledger.** The offer names the role, the pay, the manager and the contract type, which is what a credible written offer looks like (RR1). Nothing yet confirms that Marrowgate is a real employer (RR2), because the research that would check it did not run.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (hybrid, two days a week in the Limerick office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm the employer through a phone number or careers page you find yourself, not through the email; (2) you get a written contract before any bank, PPS or passport details go anywhere; (3) the onboarding portal's address is on Marrowgate's own domain.

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Marrowgate Housing, a housing association in Limerick | `[grounded]` job ad and offer |
| Pay | €40,000 offered; the ad's band is €38,000–42,000 | `[grounded]` offer and ad |
| Scope | 240 staff, monthly payroll, starters and leavers, pension changes, ledger reconciliation | `[grounded]` job ad |
| Market calibration | Not run; no band for Payroll Administrator pay in Ireland was checked | — |
| Unknowns | Pension scheme details; whether the portal is run by Marrowgate or a third party | — |
| Contradictions | The sender domain is `marrowgate.example`. `.example` is a reserved placeholder domain that can't belong to a real company. If that's your copy of the address, check the real one. | `[grounded]` offer email |

**Evidence map** (the rows above, in full):

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay within the posted band | hard_gate | direct | medium | none | €40,000 is inside €38,000–42,000 | `[grounded]` offer, ad | none |
| R2 | Hybrid, Limerick office two days a week | hard_gate | unclear | medium | hard_gate | Your location isn't in what you've shared | `[grounded]` ad | Q2 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years fortnightly, 90 staff | `[grounded]` CV | none |
| R4 | Strong Excel | must_have | direct | medium | none | Pivots and XLOOKUP daily | `[grounded]` CV | none |
| R5 | Payroll qualification or working towards | must_have | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` CV | none |
| R6 | Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Not stated in your background | `[grounded]` ad, CV silence | Q1 |
| R7 | Starters, leavers, payroll-to-ledger reconciliation | important | direct | medium | none | Done in the hotel role | `[grounded]` CV | none |
| R8 | Pension changes | important | unclear | none | discovery | You haven't done these; you haven't said whether you saw the process | `[grounded]` CV silence | Q1 |
| R9 | Payroll for 240 staff | important | adjacent | medium | transferability | 90 staff is a smaller population. Limit: no 240-scale cycle | `[inferred]` from headcount | none |

**Gap recovery queue.**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE/PRSI/USC (R6, must_have) | discovery | Not in your CV; the qualification may have covered it | A must-have; if you know it, the gap closes | Payslip runs for the hotel group with statutory deductions; the certificate's modules | Certificate modules; a sample payslip you ran | `[grounded]` ad and CV |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer asks for bank, PPS and passport after the offer | unknown | — | "add your bank details ... your PPS number ... a scan of your passport" | Routine if the employer is real and the portal is theirs | `[generic]` Irish onboarding practice | Is the onboarding portal run by Marrowgate or a third party, and what is your data-protection notice? | unresolved |
| RR2 | Employer not verified; sender domain is `.example` | unknown | — | "people@marrowgate.example" | Could be a placeholder in your copy, or an address that doesn't belong to Marrowgate | `[inferred]` from the domain; research did not run, so this isn't the standing "not established" entry | Can you point me at the live role on your own careers site, and who would I be interviewing with? | unresolved |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Marrowgate's phone number and careers page yourself, and check the offer against them | Verifies RR2 | `[generic]` standard check | pending your approval |
| P2 | Reply asking for the written contract and the portal's address; send no details yet | RR1 | `[generic]` standard practice | pending your approval |

**Evidence status.** Verified: none yet. The CV claims in R3, R4, R5 and R7 are unverified until you confirm them.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Marrowgate's careers page and the Limerick housing association were refused. Would have moved RR2 and the contradictions row |
| 2. Role-family sweep | unavailable | A salary search for payroll administrators in Limerick was refused. Would have set the market band in role reality |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but no search was sent. Would have shown whether he exists in the role you were told |

**Upgrade menu.**

- A result from Marrowgate's own careers page or a company registry listing → RR2 closes; the decision may move to `go`.
- A Limerick payroll-role salary search → the market calibration line in role reality.
- Your location and two days a week in Limerick → R2 closes.
- The pension scheme details → R8's gap is scoped.

The dossier offer: I can save all this as a `tuesday-dossier.md` so you have it ready when you talk to Marrowgate.

Questions (asked in one place):

1. Did you meet Declan Garvagh or anyone from the People Team at the two interviews? Who introduced themselves, and what were their roles? (RR2)
2. Where do you live, and is two days a week in the Limerick office workable? (R2)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.