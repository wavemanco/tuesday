**Yes, worth taking the call: `conditional_go`.** I can't confirm Fernquay is legitimate from here. The web searches were refused, so nothing about the company, the role's market rate, or Ronan Kehoe has been checked. The WhatsApp message itself asks for nothing risky: no payment, deposit, bank details or ID. It asks for a video call with a calendar invite, which is ordinary for a small company. The open question is whether the company is real, and you can check that yourself in about ten minutes (see the application plan).

**Fit ledger.**

- `hard_gate`: direct: R8 · unclear: R9 (Pay €52,000–€60,000 plus equity)
- `must_have`: direct: R1, R2, R3, R4 · adjacent: R5 (Solo ownership as first designer), R6 (Owns a booking flow end to end)
- `important`: adjacent: R7 (Research calls with school owners)

R1 to R4 are your stated experience, `medium` and not yet inspected. R5 is the real gap, `low`. R6 and R7 are a shift from consumer travel customers to operators who run schools. R9 can't be checked until you give a pay floor.

**Hard gates:** none failed (R8 `direct`); unconfirmed: R9 (Pay €52,000–€60,000 plus equity); candidate constraints not given — pay check unknown.

**Opportunity ledger.** The posting is specific about pay, location and process (RR5). The company itself is unverified (RR1), and "first designer" with no design peers named is a modest risk (RR2). Pay and equity are stated but their value is unknown (RR3).

**Severe red flags:** none found.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2.** Four searches were sent and each was refused by a permission prompt. I haven't retried.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people, Galway; booking software for sea-kayak and surf schools | `[grounded]` posting, unverified |
| Mandate | First designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not run; no search allowed, so no band for this role | unavailable |
| Unknowns | Funding and runway; whether the role is funded; equity value and terms; who gives design direction; your pay floor | — |
| Contradictions | None inside the posting or the message. "Ronan Kehoe" and "Ronan from Fernquay" match, which is not verification | `[grounded]` posting and message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company | `[grounded]` your background, self-reported | none |
| R2 | Strong Figma | must_have | direct | medium | none | Figma daily | self-reported | none |
| R3 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers | self-reported | a session plan or one-page read-out, if you have one |
| R4 | Works directly with engineers | must_have | direct | medium | none | Squad of four engineers | self-reported | none |
| R5 | Owns a product area alone (implied by "first designer") | must_have | adjacent | low | transferability | You have never been the only designer; you owned checkout inside a team | `[inferred]` from posting against background | G1 |
| R6 | Owns a booking flow end to end | must_have | adjacent | medium | transferability | You owned a checkout redesign, in a consumer travel domain | `[inferred]` adjacency | G2 |
| R7 | Research calls with school owners | important | adjacent | medium | transferability | Consumer usability sessions; no operator interviews stated | `[inferred]` adjacency | G2 |
| R8 | Hybrid, two days a week in Galway | hard_gate | direct | medium | none | You moved back to Galway last year | user-stated | none |
| R9 | Pay €52,000–€60,000 plus equity | hard_gate | unclear | low | hard_gate | Your pay floor isn't given, equity is unvalued, market band not checked | `[grounded]` posting | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Solo ownership (R5) | transferability | Team-based ownership of checkout; no solo ownership stated | "First designer" means no design peer to review your work | Any flow you drove with little review, or a side project you owned alone | A short account of how design decisions were made on checkout | `[inferred]` |
| G2 | Operator research (R6, R7) | transferability | Consumer usability work; no business-owner interviews | The role's research is with school owners, not travellers | Any interview with a business owner, customer or supplier about how they work | Interview guide or notes, even from a non-design setting | `[inferred]` |
| G3 | Pay floor (R9) | hard_gate | Floor not given; equity not valued | Decides whether the range is a gate or a negotiation point | Your stated minimum, and whether equity counts toward it | Your number | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified: research could not run | unknown | — | "Fernquay … six people in Galway" | Company is real and small; a footprint check is still required before you commit effort | `[generic]` small companies often have thin footprints; not a finding about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | "First designer", no design peers named | risk_signal | low | "You would be our first designer" | You may be the only design voice with no critique or direction | `[inferred]` from the posting's wording | Who gives design direction day to day, and who makes the final call when design and engineering disagree? | unresolved |
| RR3 | Pay and equity value unknown | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | Equity may be worth little or nothing without vesting and dilution terms | `[inferred]` from the posting's silence on terms | Is €52,000–€60,000 base salary, and what are the vesting, strike price and dilution terms? | unresolved |
| RR4 | Funding and runway unstated | unknown | — | "six people" | The role may depend on a funding round that hasn't closed | `[generic]` stage pattern | Is this role funded for at least the next twelve months? | unresolved |
| RR5 | Posting is specific on pay, location and process | positive_signal | — | "we would rather see one messy real project than a polished deck" | Transparent hiring stance | `[grounded]` posting | — | noted |

The WhatsApp contact is not a signal under the rules. It asks for no money, deposit or bank details, and it sets up a call with an emailed invite.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check Fernquay's own website and careers page, confirm the role is listed, and check the invite came from the company's email domain | Resolves RR1 | `[generic]` practice | your action |
| A2 | On the call, ask RR2, RR3 and RR4 verbatim | Turns the register into interview prep | `[grounded]` register | pending your approval |
| A3 | Describe R5 and R6 as they are: you have owned flows inside a team, and say how you'd work alone | Avoids claiming solo ownership you haven't had | `[grounded]` evidence map | pending your approval |
| A4 | Bring the checkout case study and one rougher piece, such as research notes or something that didn't work, since the posting asks for messy real work | Matches what the posting says it values | `[grounded]` posting | pending your approval |

## Evidence status

Verified: none yet.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Queries "Fernquay Galway booking software sea kayak surf school" and "Fernquay product designer careers" were refused. Would have settled RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | Query "product designer salary Ireland Galway 3 years experience" was refused. Would have set the market calibration for R9 |
| 3. Hiring manager's public footprint | unavailable | Query "Ronan Kehoe Fernquay co-founder" was refused. Would have confirmed Ronan is a co-founder of this company |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can carry into the call, if you want it.

## Upgrade menu

- **Search permission granted:** I run the three targets above (up to 5 searches and 2 fetches). This settles RR1, sets the market band for R9, and checks the co-founder's public footprint.
- **Your pay floor:** R9 becomes `direct` or `absent`.
- **Any solo-owned work, even a side project:** R5 moves from `low` confidence.
- **The live posting link and the invite's sender domain:** RR1 can be verified without searching.
- **Rehearsing the 45-minute call:** mock-interview can build that prep next.

**Questions**

1. (R9) What is the lowest base salary you'd accept, and does equity count toward it?
2. (R5) On the checkout redesign, who made the final call on design decisions, and have you ever shipped a flow with no design peer reviewing it?
3. (R7) Have you ever interviewed a business owner rather than a consumer? If not, say so; it's useful to know.

Answer each in a line, or write "skip" to leave one out. If you grant search permission, say so and I'll run the three targets.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.