**Yes, it's worth applying, on three conditions: `conditional_go`.** The licence, registration and location gates are met on what you've told me. The open items are whether the CV can show clear, timely records (R5), care planning (R8b) and how the caseload works (R10). Doppler (R11) is a preferred skill you don't have, but the team appears to train for it.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4, R6a, R7a, R8a · adjacent: R6b (leg-ulcer care), R10 (own small caseload) · unclear: R5 (clear, timely written records), R8b (care planning)
- `important` — unclear: R7b (continence care), R9 (end-of-life visits)
- `preferred` — absent: R11 (Doppler assessment)

R10 — the discharge-to-assess visits are the bridge, and the limit is that you've never held a continuing caseload; R5 — essential, and the CV says nothing about records; R8b — care planning is not claimed; R6b — pressure and surgical wound care is adjacent, and no leg-ulcer work is stated; R11 — absent, preferred, with an in-post route to closing it.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the advert is confirmed open (RR1); (2) records evidence for R5 comes up in the informal chat or in your own material; (3) the caseload is described as visits you have made, not a caseload you have held (R10, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing across Calderdale under an NHS contract; founded 2015, about 410 staff, four locality hubs | `[grounded]` organization's About page (search snippet) |
| Mandate | Housebound adults in their own homes; wound and leg-ulcer care, catheter and continence, end-of-life visits, insulin, care planning; a small caseload with senior support | `[grounded]` advert |
| Pay and terms | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | Band 5 community staff nurse, England, self-reported survey: median £34,300, interquartile range £32,400–£36,600. The advert's range sits around that median. The band is not this employer's offer, and the survey's date and method are unverified | `[generic]` Wardround 2026 pay guide |
| Scope read | A Halifax district nursing team that runs leg-ulcer clinics and trains new community staff in Doppler; the team lead is named as the contact for an informal chat | `[grounded]` speaker profile; `[inferred]` on the training route |
| Unknowns | Caseload size; amount of senior support; patch geography; schedule; whether end-of-life visits form much of the caseload | — |
| Contradictions | None found between the advert and the About page. The careers page returned no page, so the advert is not checked against it | `[grounded]` fetch result |

The team lead's public profile: eleven years as a district nurse, now leading the Halifax team, spoke at the 2025 community nursing forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. That is a published talk, which is within the people-research guardrail.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse (essential) | hard_gate | direct | medium | none | CV states active registration. Only you can check the register, so no research call used your registration details | `[grounded]` CV | Confirm your own register entry shows active |
| R2 | Full UK driving licence (essential) | hard_gate | direct | medium | none | CV states full licence, category B; no copy inspected | `[grounded]` CV | none |
| R3 | Base in Halifax | hard_gate | direct | medium | none | You live in Halifax and the advert names Halifax. Patch geography is not stated | `[grounded]` advert and CV | Raise patch area in the chat |
| R4 | At least one year post-registration (essential) | must_have | direct | medium | none | Five years as staff nurse. Length of experience is graded on fit, not treated as a gate | `[grounded]` CV | none |
| R5 | Clear, timely written records on the electronic record (essential) | must_have | unclear | none | discovery | CV is silent on records and on the electronic system. No evidence either way | `[grounded]` CV silence | Question Q1 |
| R6a | Wound care | must_have | direct | medium | none | CV: pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6b | Leg-ulcer care | must_have | adjacent | medium | transferability | Pressure and surgical wound care is adjacent work. The limit: no leg-ulcer work is stated | `[inferred]` adjacency from CV; `[grounded]` clinics talk | Ask in the chat what leg-ulcer work the caseload includes |
| R7a | Catheter care | must_have | direct | medium | none | CV: catheter care | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | none | discovery | CV silent on continence | `[grounded]` CV silence | Raise in the chat |
| R8a | Insulin administration | must_have | direct | medium | none | CV: insulin administration | `[grounded]` CV | none |
| R8b | Care planning | must_have | unclear | none | discovery | CV silent on who wrote and owned plans | `[grounded]` CV silence | Question Q3 |
| R9 | End-of-life visits | important | unclear | none | discovery | CV silent | `[grounded]` CV silence | Raise in the chat |
| R10 | A small caseload of your own, with senior support | must_have | adjacent | medium | transferability | Discharge-to-assess visits are home visits you made in the first week after discharge. The limit: you have not held a continuing caseload or owned a plan to review | `[inferred]` from CV secondment; `[grounded]` CV | Question Q2 |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | No Doppler work, and no adjacent evidence stated. Closure route: the team's Doppler training for new community staff | `[grounded]` your statement; `[inferred]` on the route | Ask whether the post includes Doppler training and when |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clear, timely records (R5, must_have) | discovery | No records or electronic-system evidence on the CV | Essential, and it is the first thing a community manager will read for | Notes written on the discharge visits; any audit or handover you did | An anonymised example of your notes, within your employer's policy | `[grounded]` CV silence |
| G2 | Own caseload (R10, must_have) | transferability | Home visits in the first week after discharge, but no continuing caseload | The role is built around a caseload you hold | Visits you followed up to a review; patients you saw through to a plan | A discharge-team service description | `[inferred]` from the secondment |
| G3 | Care planning (R8b, must_have) | discovery | No planning ownership stated | Named as a responsibility in the advert | Plans you wrote or updated on discharge visits | An example plan, anonymised | `[grounded]` CV silence |
| G4 | Doppler (R11, preferred) | capability | None | Preferred only; closable in post | None credible yet | A training record, if any | `[grounded]` your statement |

The queue holds no questions. Each question is asked once, in the closing block, tagged by row.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Advert liveness unverified | unknown | — | "Current vacancies are listed on our careers page" | The advert may be closed, or the page may be stale | `[inferred]` from the careers page returning no page | Is this post open now, and what is the closing date? | unresolved |
| RR2 | Caseload size and senior support unstated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | The caseload may be large, or the support thin | `[inferred]` from the advert's silence on numbers | How many patients would I hold at once, and what does senior support look like week to week? | unresolved |
| RR3 | Team trains new staff in Doppler | positive_signal | — | "Doppler training for staff new to community work" (speaker profile) | An in-post route exists to closing R11 | `[grounded]` speaker profile | Is Doppler training given in post, and how soon? | noted |
| RR4 | Pay stated with range and mileage | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The offer is transparent and sits near the survey median | `[grounded]` advert; `[generic]` median | Where in the range does a Band 5 start, and what moves it? | noted |

No `severity: high` entries.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the advert is live before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Take the register questions (RR2, RR3, RR4) into the informal chat | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A3 | Describe the discharge work as home visits and their limits, not as a caseload you held | Calling it a caseload would be a Kind change on the record: visits became ownership | `[grounded]` CV; reframing audit | pending your approval |
| A4 | Do not claim leg-ulcer or Doppler experience; name them as not yet done | R6b, R11 | `[grounded]` CV and your statement | pending your approval |
| A5 | Prepare one anonymised example of your notes, within your employer's policy | G1 | `[inferred]` from R5 | pending your approval |

No CV wording is proposed here. Tailoring the CV to this advert is resume-tailor's job, and you can ask for that next.

## Evidence status

Verified: none yet. The CV's claims and your brief are leads until you confirm them in detail.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched the careers page, which returned no page. Moved: attribution is established; liveness of the advert is not (RR1) |
| 2. Role-family sweep | yes | Searched the Band 5 community staff nurse salary, which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example). Moved: the `[generic]` market calibration |
| 3. Hiring manager's public footprint | yes | Searched the team lead's name with the organization, which returned her speaker profile (communitynursingforum.example). The advert names her as the contact for a chat, not as hiring manager. Moved: scope read and RR3 |

## Upgrade menu

- The advert link or the careers page → RR1 closes.
- An anonymised example of your notes, or a records audit summary → R5 moves from `none` to `medium`.
- Any leg-ulcer or Doppler training record → R6b or R11 moves.
- Your pay floor, schedule and other non-negotiables → the hard-gate checks run. Right now they are unknown.
- Deeper diligence on the organization (leadership, contract, published reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want to keep this analysis, I can write it to a `tuesday-dossier.md` file.

**Questions**

Q1 (R5): How did you record visits on the discharge team, which system did you use, and how soon after a visit did the notes go in?

Q2 (R10): On the discharge visits, did you ever keep a list of people you saw through to a review, or did each visit end at discharge?

Q3 (R8b): Did you write care plans for the people you visited, and who reviewed them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.