**Yes, asking for bank details, a PPS number and a passport scan after a written offer is normal payroll onboarding, but asking before an offer is not. What needs checking is whether the employer and the onboarding link are genuinely theirs. I can't establish that from here, so `conditional_go`: accept only once the employer and the sending address check out.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Right to work in Ireland without sponsorship), R2 (Hybrid, two days a week in the Limerick office)
- `must_have`: direct: R3 (2+ years running payroll), R5 (Starters, leavers and reconciliation), R7 (Strong Excel) · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: adjacent: R6 (Pension changes)
- `preferred`: direct: R8 (Payroll qualification or working towards one)

R4 — Irish statutory deductions, not mentioned in your background; R6 — pension changes, adjacent through your starters and leavers work.

**Opportunity ledger.** The role is coherent: the scope matches your background, the €40,000 offer sits inside the posted €38,000–€42,000 range, and you had two in-person interviews at the office (RR4, a positive signal). The open items are that the employer is not yet established (RR1) and that the sender address is on a `.example` domain (RR2). RR3 is an unknown about the onboarding portal, not a red flag.

- **Hard gates:** none failed; unconfirmed: R1 (Right to work in Ireland without sponsorship), R2 (Hybrid, two days a week in the Limerick office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1, the employer is confirmed through its own website and a phone number you find yourself; (2) RR2, the offer and the onboarding link come from that company's domain; (3) R1, your right to work is stated and checked.
- **What would change this:** If RR1 or RR2 fails to clear, hold: enter no details and reply through the verified contact only.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches on the employer and its job page were refused, so the posting and sender domain are unchecked. Would have moved RR1 and RR2. |
| 2. Role-family sweep | unavailable | The pay search was refused, so there is no market band. Would have set the market calibration line. |
| 3. Hiring manager's public footprint | unavailable | The search for Declan Garvagh was refused. A name was given, so this target was live. Would have moved the scope read and interview positioning. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` posting and offer |
| Mandate | Monthly payroll, starters and leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Limerick office; permanent post | `[grounded]` posting and offer |
| Pay | €40,000 offered; posting range €38,000–€42,000 | `[grounded]` offer and posting |
| Scope read | One person runs payroll for 240 staff, with pension changes in the remit | `[inferred]` from the posting's responsibilities |
| Market calibration | Not run: research was refused, so no band is stated | none |
| Unknowns | Whether the employer exists as described; whether the sender is theirs; your right to work; pension scheme details | none |
| Contradictions | The employer is named as Marrowgate Housing, but the sender address is on `.example` | `[grounded]` offer email as you pasted it |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland without sponsorship | hard_gate | unclear | none | hard_gate | Not stated in your background; the passport check comes after acceptance, so it doesn't settle this first | `[inferred]` from the posting's gate and your silence on it | Question 1 |
| R2 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | Both interviews were at the office, which suggests you can attend, but you haven't stated your location or availability | `[grounded]` posting; `[inferred]` from the interviews | Confirm you can work two office days a week |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated by you; no artifact yet | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Not mentioned in your background | `[grounded]` silence in your background | Question 2 |
| R5 | Starters, leavers and monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Both named, with specifics; no artifact | `[grounded]` your background | none |
| R6 | Pension changes | important | adjacent | low | transferability | You process starters and leavers, which touch pension enrolment and exit, but you have never made pension changes yourself | `[inferred]` adjacency from starters and leavers | Gap queue G1 |
| R7 | Strong Excel | must_have | direct | medium | none | Pivot tables and XLOOKUP in daily use; no artifact | `[grounded]` your background | none |
| R8 | Payroll qualification or working towards one | preferred | direct | medium | none | Payroll Technician certificate, 2024 | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pension changes (R6, important) | transferability | You run starters and leavers, which touch pension, but you have not made pension changes yourself | A named duty of this role, and the likeliest objection at interview | Starters and leavers runs where pension deductions or scheme exports were checked | A scheme change checklist you followed, or a sample pension export | `[inferred]` bridge from starters and leavers; `[generic]` that pension changes are a common interview probe |
| G2 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | Three years of payroll, with no Irish statutory specifics stated | The core of an Irish payroll role; Revenue compliance is what this job is judged on | Revenue returns you filed, deduction checks, payslips where you checked USC or PRSI | A redacted payslip, or a P30 summary you prepared | `[grounded]` silence in your background; `[generic]` that Irish payroll interviews test Revenue returns |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The employer may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; research could not run | Which page on your own website lists this post, and which phone number should I use to confirm this offer? | unresolved |
| RR2 | Sender address does not match the employer's name | risk_signal | medium | "people@marrowgate.example" | The address sits on `.example`, which is reserved for documentation, so it may be a placeholder from how the email was pasted, or not the employer's real address | `[inferred]` from the address as pasted; `[generic]` that `.example` is reserved, not used by real employers | Which domain do your offer emails and onboarding links come from? | unresolved |
| RR3 | Payroll and identity details requested through an onboarding link | unknown | — | "we will send you a link to our onboarding portal, where you add your bank details for salary payments, your PPS number for Revenue, and a scan of your passport" | Routine after a written offer that names the role and pay, if the portal is the employer's own system | `[generic]` pattern for payroll onboarding; `[grounded]` the quoted request | Which web address does the portal sit on, and which payroll provider runs it? | unresolved |
| RR4 | Two in-person interviews at the office | positive_signal | — | "I had two interviews in person at their office" | Suggests a real office and an in-person hiring process | `[grounded]` your account | Who were the two interviewers, and what are their roles? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Marrowgate's website yourself, and confirm this post and a phone number there, not from the email | RR1 | `[grounded]` RR1 | proposed |
| P2 | Compare the sender domain with the website's domain | RR2 | `[grounded]` RR2 | proposed |
| P3 | Enter no bank, PPS or passport details until P1 and P2 clear, and only on the employer's own portal | RR3 | `[generic]` standard onboarding caution | proposed |
| P4 | If the checks aren't done in five working days, ask for a short extension in writing | RR1, RR2 | `[generic]` common practice | proposed |

**Evidence status**

Verified: none yet. Your background is self-report, so it stands as a lead until you confirm specifics. Unverified leads: none. Rejected inferences: none.

**Upgrade menu**

- Allow web searches in this session and I'll re-run the three checks at the same caps: the company's website, a pay check for this role, and Declan Garvagh's public professional profile. That would move RR1, RR2 and the scope read.
- The careers page link or the company's switchboard number would close RR1 faster than any search.
- The sending address as it appears in the email headers would settle RR2.
- A redacted payslip or a P30 summary would move G2 and R4 from `low` upward.
- A one-line statement of your right to work would settle R1.

I can also save this as a `tuesday-dossier.md` you can keep and add to.

Questions:

1. R1: Do you have the right to work in Ireland without sponsorship?
2. R4: Have you worked with PAYE, PRSI and USC yourself, and in which payroll system?
3. RR1: Who were the two people who interviewed you, and what are their titles?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.