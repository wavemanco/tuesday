**Yes, apply. Status: `conditional_go`.** She meets every essential the posting lists that she can show on paper: current Adult NMC registration, a full UK licence, and five years post-registration. Her wound, catheter and insulin work is direct. The gaps are the parts the posting builds the role around: running her own caseload, and leg-ulcer and end-of-life care, which her CV doesn't mention. The employer is real and the pay sits in a normal Band 5 range. Nothing I found is a severe red flag.

**Fit ledger.**
- `hard_gate`: direct: R1 (NMC Adult registration), R2 (full UK driving licence), R3 (Halifax base)
- `must_have`: direct: R4 (at least one year post-registration); unclear: R11 (clear, timely written records on an EPR)
- `important`: direct: R5 (wound care, incl. pressure and surgical wounds), R6 (catheter care), R7 (insulin); adjacent: R8 (care planning and caseload); unclear: R9 (end-of-life visits), R10 (leg-ulcer care)
- `preferred`: absent: R12 (Doppler assessment)

R8 — her discharge-to-assess visits are real home-based care planning, but only for the first week after discharge. R12 — no evidence yet.

**Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown.

**Opportunity ledger.** The employer checks out: a CIC with an NHS contract, 410 staff and four locality hubs, per its own about page (`[grounded]`). Pay is £31,050–£37,800 plus mileage, and the posting says pool cars are provided (`[grounded]`). The posting does not state the contract type or which hub the caseload sits in (RR1, RR2). I could not confirm the posting is live on the careers page.

**Evidence map** (confidence grades her own statement, not the role's match):

| # | Requirement | Fit | Conf. | Gap | Provenance |
|---|---|---|---|---|---|
| R1 | NMC Adult registration | direct | medium | none | `[grounded]` CV, her statement |
| R2 | Full UK licence | direct | medium | none | `[grounded]` CV |
| R3 | Halifax base | direct | medium | none | `[grounded]` CV and posting |
| R4 | ≥1 yr post-reg | direct | medium | none | `[grounded]` CV: five years |
| R5 | Wound care | direct | medium | presentation | `[grounded]` CV: pressure and surgical wounds |
| R6 | Catheter care | direct | medium | none | `[grounded]` CV |
| R7 | Insulin | direct | medium | none | `[grounded]` CV |
| R8 | Care planning / caseload | adjacent | medium | transferability | `[inferred]` from discharge-visit role |
| R9 | End-of-life visits | unclear | none | discovery | CV silent |
| R10 | Leg-ulcer care | unclear | none | discovery | CV names wounds, not leg ulcers |
| R11 | Written records / EPR | unclear | none | discovery | CV silent |
| R12 | Doppler | absent | none | capability | `[generic]` closure is usually short training plus supervised practice |

**Gap recovery queue.** R8 needs a bridge with its limit stated: first-week visits, not an ongoing caseload. R9 and R10 need a question about her own ward or visit experience. R11 needs the EPR name and how she handled note timeliness. R12 has a closure path if the employer supports training (see the public talk below).

**Risk register.**
- RR1 — contract basis unstated (unknown, `unresolved`). Ask: "Is this post permanent or fixed-term?"
- RR2 — caseload area and mileage radius unstated (unknown, `unresolved`). Ask: "Which hub would I cover, and what is a typical daily radius?"
- RR3 — the posting names senior nurse support (positive signal, `noted`).
- RR4 — pay is inside the Band 5 range; a survey of 1,240 community staff nurses in England puts the median at £34,300 and the middle half at £32,400–£36,600 (`[generic]`, a pattern, not this employer's offer). No mismatch.

**Application plan.**
- A1: Check her own NMC register entry before applying (`[grounded]`, pending your approval).
- A2: Take RR1, RR2 and R12 to the informal chat with Rhiannon Mabbott (`[grounded]`, pending your approval).
- A3: Keep her CV wording on the discharge visits as they are: "visiting patients at home in their first week after discharge." Don't describe it as caseload management (reframing audit: a caseload is a kind of work she has not done). Pending your approval.

**Evidence status.** Verified: none yet; every claim is CV-stated. The NMC register check would verify R1. Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and fetched calderbrookhealth.example/about. Employer established as described; careers page not fetched, so the posting's live status is unverified. |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change band 5 pay scale 2026-27 registered nurse", which returned the Wardround 2026 UK Community Nursing Pay Guide (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned a forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Her public talk covered Doppler training for staff new to community work; that is her footprint, not proof the role provides training. |

I haven't used her National Insurance number or NMC PIN; neither is needed for this check.

**Upgrade menu**
- Her NMC register printout → R1 to `high`.
- Any leg-ulcer or end-of-life contact, on the ward or in visits → R9 and R10 move off `unclear`.
- A list of patients she was responsible for, even briefly → R8 moves from adjacent toward direct.
- The careers-page listing → confirms the posting is live.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want the CV tightened for this posting, `resume-tailor` can do that next.

Your dossier offer: I can save all of this as a `tuesday-dossier.md` for your records, if that would help.

**Questions**
- R9 / R10: On the ward or on discharge visits, did you dress or assess leg ulcers, or care for anyone at end of life? What did you do?
- R8: Did you ever have a list of patients you were responsible for across visits, or only the first-week visits?
- R11: Which electronic record system have you used, and how did you keep your notes timely?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.