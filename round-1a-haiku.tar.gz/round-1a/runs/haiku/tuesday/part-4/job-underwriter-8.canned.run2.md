**Don't go ahead, and send nothing yet.** Status: `no_go`. This job is very likely a scam. Don't send the IBAN, PPS number or passport photo, don't pay the €349, and don't deposit the cheque. I can't establish the firm from here: a search for "Velloway Logistics" returned nothing. The requests in the messages are what decide this.

**Decision snapshot**

- **Hard gates:** none stated in the JD. Your €30,000 floor is unconfirmed: "up to €26 an hour" at 15–30 hours a week comes to about €20,000–€40,500 a year before commission, and the posting gives no figure you can rely on.
- **Fit ledger (your side, `[grounded]` from your message only):** R1 spreadsheets, `direct`, confidence `medium`: your Excel tracker is stated, not inspected. R2 attention to detail, `adjacent`, `medium`: Zendesk ticket work at about 60 a day is close but not the same. R3 written English, `unclear`, `low`: not evidenced yet. R4 quiet workspace, `unclear`, `low`: not asked. Fit is not what's blocking this.
- **Severe red flags:** RR1, RR2, RR3 and RR4 (`severity: high`).
- **What would change this:** a verified employer, a live posting on their own careers page, and a written offer that names the role and pay. None of the requests above would be needed to get there.

**Opportunity register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Hold |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pays for equipment before any job starts | red_flag | high, confirmed | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The money goes to the sender, not to an equipment supplier. | `[generic]` pattern of advance-fee job scams | Does your company ask new hires to pay for their own equipment? | Pay nothing. |
| RR2 | Cheque deposit with money sent back | red_flag | high, confirmed | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 … and transfer the rest to our equipment partner." | This is an overpayment scam: the cheque bounces later and the money you sent is gone. | `[generic]` pattern of cheque-overpayment scams | Will you send any cheque or payment through your own payroll, and can I see the job on your careers page? | Don't deposit anything. |
| RR3 | Bank, tax and ID details before an offer | red_flag | high, confirmed | "send your IBAN, your PPS number and a clear photo of your passport" | Identity and bank details collected before any written offer. | `[grounded]` the message text | Do you collect bank or ID details before a written offer? | Send nothing; keep your IBAN to yourself for now. |
| RR4 | Hiring run wholly by chat | red_flag | high, confirmed | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | An interview and offer that happen only in a chat app can't be checked against the employer's own systems. | `[grounded]` the posting | Can you point me at this role on your careers page and name the person I'd report to? | No verdict on the process alone; the RR1–RR3 requests hold. |
| RR5 | Employer not established | risk_signal | high | "Velloway Logistics" | The firm may be new, small or not hiring. | `[generic]` pattern for employers with no web presence, not a claim about this one | Please give me a link to this role on your own website. | Don't invest effort until it verifies. |
| RR6 | Pay below your floor | risk_signal | medium | "up to €26 an hour plus commission" | The realistic income may fall short of €30,000. | `[grounded]` the posting's own figures, calculated | What hours and base pay are guaranteed? | Only a concern if RR1–RR5 clear. |

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

**Evidence status**

Verified: none yet. Your IBAN and background are unverified and not needed for this decision.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics": no results. The employer is not established; RR5 stands. |
| 2. Role-family sweep | skipped | The posting's own figures and its requests decide the verdict; a pay band would not change the hold. |
| 3. Hiring manager's public footprint | n/a | Only a Telegram handle was given, not a name. |

**Upgrade menu**

- A link to the live role on the employer's own careers page, plus a named contact found on their official site → RR5 closes or stays open.
- The company's registered name and address from a public register → RR5 narrows.

Do you want me to draft a short reply to @VellowayHiring that asks for the careers-page link and a named contact, and nothing else?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.