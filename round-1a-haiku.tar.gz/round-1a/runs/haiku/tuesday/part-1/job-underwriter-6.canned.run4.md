**Yes, apply, but as a conditional go.** Your tooling, years and reporting match the posting. The two must-haves you can't claim directly are forecast ownership (R7) and billing or revenue-data work with finance (R8).

**Decision snapshot: `conditional_go`**

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (Bristol hybrid, two days in office), R2 (salary £61,500–£67,000)
  - `must_have`: direct: R4 (4+ years RevOps/sales ops), R5 (Salesforce admin), R6 (SQL and spreadsheet modelling); adjacent: R7 (owning a forecast), R8 (finance work on billing or revenue data)
  - `important`: direct: R9 (CRM ownership), R10 (pipeline and renewal reporting)

  R7 — pipeline review is an input to a forecast, not the forecast; R8 — pipeline and renewal data is revenue data, not billing data.
- **Opportunity ledger.** Funded and transparent: a stated salary and a Series A (RR4, RR6). The scope is broad: CRM, billing data, reporting, forecast and finance partnership in one post (RR1, RR2).
- **Hard gates:** unconfirmed: R1 (Bristol hybrid, two days in office), R2 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the forecast boundary with the CFO is clear and your pipeline-to-forecast work counts (RR2); (2) billing data is learnable through finance access, not something you're expected to own from day one (RR1); (3) the posting is live on Quillfield's own careers page (not yet checked).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 staff; £11M Series A, April 2025 | `[grounded]` quillfield.co.uk/about (search snippet, not fetched) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options. A UK RevOps lead survey (n=438) has median £64,200, IQR £57,800–£70,400, so the posted range sits in the middle | Posting `[grounded]`; band `[generic]` from one survey, not this employer's offer |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield; previously four years in sales operations at Corvane Payments | `[grounded]` public profile snippet |
| Contradictions | None between the posting and the company's own About page | `[grounded]` |

**Evidence map** (confidence is `medium` where a claim is yours and specific but has no artifact yet)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Next action |
|---|---|---|---|---|---|---|---|
| R4 | 4+ years RevOps/sales ops/analytics at a B2B software company | must_have | direct | medium | none | Years and role match. "Software" vs. payments is a reading, not a fact; name it | Lead with the payments-company background |
| R5 | HubSpot or Salesforce admin | must_have | direct | medium | none | Salesforce admin certified | Attach the certificate |
| R6 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily | Offer a work sample |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review but never owned the company forecast; finance did | Work sample: pipeline-to-forecast model on sanitised data |
| R8 | Working with finance on billing or revenue data | must_have | adjacent | medium | transferability | Pipeline and renewal data is revenue data; no billing data; finance collaboration not stated | Ask whether you ever reconciled with finance |
| R9 | Owning the CRM | important | direct | medium | none | Salesforce admin | None |
| R10 | Pipeline and renewal reporting | important | direct | medium | none | You rebuilt both dashboards | Attach a screenshot |
| R1 | Bristol hybrid, two days in office | hard_gate | unclear | none | hard_gate | Your location isn't in the material | Confirm |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | Your floor isn't in the material | Confirm |

**Gap recovery queue**

- **G1 (R7):** Pipeline work is the closest evidence to forecasting but not the same thing. Closes if you can show a pipeline-weighted forecast input, reconciliation to actuals, or a CFO presentation. Closure path: the sanitised work sample above.
- **G2 (R8):** Billing data is the one thing you have not touched. Closes with any finance-side revenue or billing reconciliation, even as a data consumer. If there is none, it becomes a stated limit.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Bundled remit: CRM, billing data, reporting, forecast and finance partnership in one post | risk_signal | medium | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The post may be broader than one lead's job. `[inferred]` from the listed duties | Which of these responsibilities sit with this role, and which stay with finance or the CRM team? | unresolved |
| RR2 | Forecast boundary with finance | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The forecast may be handed over from finance, or the role may only prepare inputs for it. `[inferred]` from the posting's wording | Is this role taking over the forecast from finance, or preparing inputs for the CFO's forecast? | unresolved |
| RR3 | Billing data ownership undefined | unknown | — | "own our CRM and billing data" | Ownership may mean data quality and access, not the billing system itself. `[inferred]` from the posting's silence on who controls billing | Which billing system and data does this role own, and what does finance control? | unresolved |
| RR4 | Funded growth | positive_signal | — | Series A £11M, April 2025 | Budget and headcount plans for revenue operations are likely to be real. `[grounded]` company About page | How does this role's reporting support the growth plan? | noted |
| RR5 | Reporting line to the Head of RevOps unclear | unknown | — | Head of Revenue Operations listed on Tamsin Achebe's profile | This may be a deputy or a successor role, and it changes what you'd own. `[inferred]` from two titles | How does this role relate to the Head of Revenue Operations' remit? | unresolved |
| RR6 | Pay stated and in range | positive_signal | — | £61,500–£67,000 | The range is near the RevOps band midpoint. `[generic]` band | None | noted |

**Application plan** (all proposed; nothing is sent or edited without your approval)

- **E1:** Lead with pipeline and renewal dashboards, and describe the monthly pipeline review as forecast input. Don't claim forecast ownership. `[grounded]` CV.
- **E2:** Attach the Salesforce certificate and one dashboard screenshot. `[grounded]` your credentials.
- **W1:** A sanitised pipeline-to-forecast model as a work sample, for R7. `[inferred]` from G1.
- **A1:** Check the posting on Quillfield's careers page before applying. `[grounded]` research gap.
- **A2:** Ask the recruiter the forecast and billing questions in RR1–RR3 before the first interview. `[grounded]` register.
- **H1:** Tamsin Achebe's profile shows the same path you have: sales operations at a payments company. Lead with that shared background for her. `[grounded]` profile snippet.

**Evidence status**

- Verified: none yet.
- Unverified leads: none.
- Rejected inferences: none.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol"; result quillfield.co.uk/about (snippet). Confirmed the company exists as described. The posting's live status on the company's own careers page is still unchecked |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol"; result Ledgerline 2026 UK RevOps Pay Guide (n=438). Set the pay band and calibrates the posted range |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; result a public profile (snippet). Title and prior employer, used for H1 |

**Upgrade menu**

- A sanitised pipeline-to-forecast model or forecast process note → R7 moves toward `direct`.
- Any finance-side billing or revenue reconciliation, even as a data consumer → R8 moves toward `direct`.
- Your location and salary floor → R1 and R2 close.
- The careers-page check (fetch quillfield.co.uk careers) → the posting's live status is confirmed.
- A deeper pass on Quillfield (funding history, leadership changes, reviews; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this up as `tuesday-dossier.md` for your records.

**Questions**

1. **R7:** Have you ever built or contributed to a forecast, such as pipeline-weighted inputs, reconciling forecast to actuals, or presenting to a CFO? Answer in text, or say skip.
2. **R8:** Have you ever reconciled revenue or billing data with finance, even as a data consumer? Answer in text, or say skip.
3. **R1/R2:** Are Bristol hybrid (two office days a week) and £61,500–£67,000 within your terms? Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.