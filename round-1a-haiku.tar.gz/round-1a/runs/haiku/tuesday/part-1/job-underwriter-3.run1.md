**No, this posting is not worth pursuing.** Two of its terms fail your stated constraints outright. Status: `no_go`.

- **Hard gates:** R1 (base pay $70–85k against your $150k floor) and R2 (five days on-site in Austin against remote-only) both fail on the posting's own terms.
- **Why it feels off:** the gates explain the no-go. The rest of the posting is also a risk: one person is asked to cover seven growth functions with no team named, and the hours and success measures are vague (RR1 to RR3 below).

**Fit ledger**
- `hard_gate` · hard_gate_fail: R1 (base salary), R2 (on-site location)
- `must_have` · direct: R3, R4, R5, R6
- `important` · unclear: R7 (SEO/content), R8 (brand, PR), R9 (partnerships), R10 (sales ops)

R1: the top of the posted base is $65k under your floor, and equity doesn't count toward base. R2: Austin five days a week, "no exceptions." R3 to R6: your strongest matches, but they rest on your own statements with no artifact yet. R7 to R10: not in your material, so unestablished.

- **Hard gates:** failed: R1 (base salary), R2 (on-site location).
- **Severe red flags:** RR1 (`severity: high`).
- **Opportunity ledger:** RR1 is the severe red flag: seven functions for one person with no headcount named. RR2 (always-on hours) and RR3 (no success targets) are risk signals. RR4 is the posting's own claim of Series A and profitability, unverified because no search ran.
- **What would change this:** both gates would have to change in writing, base at or above $150k and remote work from Portland. Either change alone leaves the other gate failing.

**Research tier: L0 — no searches; user links read none**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Both gates fix the decision, so confirming Novaline exists can't turn this into a go. It would only settle RR4. |
| 2. Role-family sweep | skipped | The posted base already sits under your floor, so a market band can't change R1 or R2. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, profitable since day one | `[grounded]` posting claim, not checked |
| Mandate | All revenue growth: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | Austin on-site five days; evenings and weekends | `[grounded]` posting |
| Scope read | Seven functions for one person, "team of one to start" | `[inferred]` from the posting's scope against its silence on headcount |
| Market calibration | Not run (no search) | — |
| Unknowns | Budget, headcount timeline, success targets | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base salary at or above $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | Posting $70–85k base; equity isn't base | `[grounded]` posting; floor is your own constraint | none; only the employer changing terms resolves it |
| R2 | Remote-only from Portland | hard_gate | hard_gate_fail | high | hard_gate | Posting requires on-site Austin, "no exceptions" | `[grounded]` posting | none; same as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, Growth lead then Head of Growth | `[grounded]` your statement; expect a probe | none |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid at two B2C subscription companies | `[grounded]` your statement | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze | `[grounded]` your statement | none |
| R6 | Revenue growth end to end | must_have | direct | medium | none | $8M to $40M ARR over three years, with a budget you controlled | `[grounded]` your statement | none |
| R7 | SEO/content | important | unclear | low | discovery | Not in your material | `[grounded]` absence | none; decision doesn't depend on it |
| R8 | Brand and PR | important | unclear | low | discovery | Not in your material | `[grounded]` absence | none; same as R7 |
| R9 | Partnerships | important | unclear | low | discovery | Not in your material | `[grounded]` absence | none; same as R7 |
| R10 | Sales ops | important | unclear | low | discovery | Not in your material | `[grounded]` absence | none; same as R7 |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seven functions for one person | red_flag | high | "You will be a team of one to start" | You may be accountable for seven functions without budget or headcount | `[inferred]` from scope against silence on budget | What headcount and budget are committed to this role in year one, and which functions are expected to wait? | unresolved |
| RR2 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond the stated schedule are the norm | `[inferred]` from the posting's wording | How often does the team work evenings and weekends in a typical quarter, and how is that planned or compensated? | unresolved |
| RR3 | No success targets on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be held to targets not yet defined | `[inferred]` from the posting's wording | What revenue targets and timeline would I be measured against in the first six months? | unresolved |
| RR4 | Funding and profitability claim | positive_signal | — | "Series A, profitable since day one" | If true, the company is better funded than most at this stage | `[grounded]` posting claim, unverified | Can you confirm current revenue, runway, and the budget under this role? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to this posting | R1 and R2 fail | `[grounded]` R1, R2 | recommendation; your call |

**Evidence status:** Verified: none yet. Your experience claims are intake prose, which counts as CV-equivalent. Your two constraints are your own statements and are graded high.

**Upgrade menu**
- A one-line L1 check (five searches, two fetches) would confirm Novaline exists and sharpen RR4 and the market band. It won't change the status.
- A written change from Novaline on either gate would move the decision to a hold at most. I'd re-assess then.

Do you want me to save this assessment as `tuesday-dossier.md`?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.