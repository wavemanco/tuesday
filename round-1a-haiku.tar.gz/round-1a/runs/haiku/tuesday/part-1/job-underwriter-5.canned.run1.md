**Yes, worth applying, as `conditional_go`.** The stack matches what you run daily, and the posted pay sits inside the market band. Before you spend effort, confirm the employer is real: my one search found nothing outside Pellucid's own site.

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (Remote US or Denver location), R2 (salary floor)
  - `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5a (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
  - `important`: adjacent: R5b (BigQuery specifically); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

  R5b is the BigQuery gap. R8 and R9 are not in your intake, so they are unknown, not missing.
- **Opportunity ledger.** The stated salary and defined scope are positive (RR4, RR3). The employer is not established from attributable sources (RR1), and the data-contract scope is unknown (RR2).
- **Hard gates:** unconfirmed: R1 (Remote US or Denver location), R2 (salary floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the role is on Pellucid's own careers site and the recruiter writes from its domain; (2) R1 and R2 are confirmed as yours; (3) the BigQuery gap (R5b) is stated plainly, not framed as experience.
- **What would change this:** RR1 failing to verify moves this to `hold_pending_answers`. A location or salary floor that the role misses makes it `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` its about page, read as your link; not independently verified (RR1) |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse on BigQuery, and data contracts | `[grounded]` posting |
| Scope read | Senior ownership of pipelines, no reports stated | `[inferred]` from the posting; matches typical scope |
| Market calibration | Posted $148k–$166k against median $151k, IQR $139k–$163.5k; the posting sits inside the IQR | `[generic]` band from the Datawright 2026 report you sent; `[grounded]` posted figure |
| Unknowns | Hiring manager, contract type, equity amount, who owns the data contracts | — |
| Contradictions | None between the posting and the about page | `[grounded]` both read |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver location | hard_gate | unclear | medium | hard_gate | Your location and preference are not in the intake | `[grounded]` posting | Q1 |
| R2 | Salary floor under $148k | hard_gate | unclear | medium | hard_gate | Your floor is not stated | `[grounded]` posting | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, self-reported, no artifact | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake | none |
| R5a | dbt and a cloud warehouse | must_have | direct | medium | none | 180-model dbt project on Snowflake | `[grounded]` your intake | edit E1 |
| R5b | BigQuery | important | adjacent | medium | transferability | Snowflake and dbt carry over; BigQuery never used | `[inferred]` from your stack against the posting | edit E2 |
| R6 | Airflow or similar | must_have | direct | medium | none | Orchestration in production, self-reported | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up, self-reported | `[grounded]` your intake | none |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your intake | `[grounded]` posting; silence in intake | Q3 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your intake | `[grounded]` posting; silence in intake | Q3 |

**Gap recovery queue**

- **G1 (R5b, transferability):** Snowflake and dbt transfer; BigQuery's cost model, partitioning and tooling are the limit. A short BigQuery project would narrow the limit. `[inferred]`
- **G2 (R8, R9, discovery):** Ask whether you have built ingestion or owned a contract analysts used (Q3).

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring…" | The company may be small or new with a thin footprint, or the posting may be stale. My one search returned nothing, which is not evidence of fraud. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Data-contract ownership unstated | unknown | — | "the data contracts our analysts depend on" | Ownership may sit with analysts, or the role may build the contract layer from scratch | `[inferred]` from the posting | Who owns the data contracts today, and which analysts depend on them? | unresolved |
| RR3 | Stated salary inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is realistic for the seniority and stage | `[generic]` band; `[grounded]` posted figure | What equity is granted, and how is the band set against level? | noted |
| RR4 | Hiring manager not named | unknown | — | (posting names none) | Could be a standard listing; ask at screen | `[inferred]` from the posting | Who would I report to, and what is the scope? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with "built and ran a ~180-model dbt project on Snowflake" | Matches R5a | `[grounded]` your intake | pending your approval |
| E2 | Describe BigQuery as "not yet used in production" | Matches R5b without implying experience | `[grounded]` your intake | pending your approval |
| A1 | Before applying, confirm the posting on Pellucid's own careers site and the recruiter's email domain | Clears RR1 | `[generic]` pattern for employers this size | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring Denver K-12": no results. The posting and about page were read as your links and match your paste. Entity not established from attributable sources, so RR1 stands |
| 2. Role-family sweep | skipped | The Datawright report you sent already fixes the band |
| 3. Hiring manager's public footprint | n/a | No name given |

**Upgrade menu**

- The recruiter's email domain or the live posting URL → RR1 closes or escalates.
- Your location and salary floor → R1 and R2 close.
- Any ingestion or data-contract work → R8 and R9 move from unknown.
- A deeper pass on Pellucid (funding, leadership, reviews; up to 5 more searches and 2 more fetches) would firm up RR1 — say the word and it runs.

If you want this kept, I can write it up as a `tuesday-dossier.md`.

**Questions**

1. R1, R2: Are you US-based, is remote workable or do you need Denver, and is $148k your floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. RR1: Did a recruiter send this, and from what domain? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. R8, R9: Have you built ingestion from an app or CRM, or owned a data contract analysts relied on? Give one example. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.