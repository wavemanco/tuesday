**Decision snapshot**

Yes, worth applying to, on three conditions. Status: `conditional_go`.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (fully remote UK, right to work)
  - `must_have`: direct: R2, R3, R4, R5
  - `important`: direct: R6b; adjacent: R7 (product-side recommendations), R9 (pet-insurance product); unclear: R6a (designing price tests)
  - `preferred`: direct: R8

  R2, R3, R4 and R5 read `direct`, and each is backed by your own statement. R9 is the real gap: the method transfers, but pet pricing is new to you. R1 is unconfirmed because your location and right to work aren't in what you've given me.

- **Opportunity ledger.** The posting is specific and shows no red flags, but pay is not stated (RR1), line management is unstated (RR2), and the employer and this posting are unverified because web search was not permitted (RR5).
- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK, right to work); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting are confirmed on Brindlemoor's own careers page (RR5); (2) UK location and right to work are confirmed (R1); (3) pay and line management are answered in the first conversation (RR1, RR2).
- **What would change this:** a confirmed right-to-work or location problem (R1 would fail, which would make it `no_go`), or a role that turns out to be a pet-product owner with no access to pet claims data (RR3 would become a must-have gap).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, pet-insurance product | `[grounded]` JD; existence not checked |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD silence |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; public footprint not checked |
| Scope read | Senior ownership of one product's pricing; whether it includes reports is unstated | `[inferred]` from "senior" and "own" |
| Market calibration | Not run; no band given, because the role-family sweep was not permitted | — |
| Unknowns | Pay, line management, existing models and who signs them off, decision rights, employer verification | — |
| Contradictions | None within the JD as provided | `[grounded]` JD |

Pet pricing usually turns on species, breed, age and vet-cost inflation, which is a pattern for the line and not a claim about this employer. `[generic]`

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based; right to work in the UK | hard_gate | unclear | low | hard_gate | Your UK motor-insurer history implies UK work but doesn't settle residence or status | `[grounded]` JD; `[inferred]` from employer history | Question 1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two as senior analyst; self-reported, no artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your background | Optional: an anonymised query or script sample would raise this to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for a young-driver motor book; the technique carries over, the rating factors do not | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6a | Designing price tests | important | unclear | low | discovery | "Ran 14 tests" doesn't say whether you designed them or executed a design someone else set | `[grounded]` silence on design | Gap G1 |
| R6b | Reading price-test results | important | direct | medium | none | Ran 14 tests and reported results to underwriting | `[grounded]` your background | none |
| R7 | Turning results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are evidenced; product-side recommendations are not in your background | `[grounded]` your background | Gap G3 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in UK motor insurance pricing | `[grounded]` your background | none |
| R9 | Pricing for a pet-insurance product | important | adjacent | medium | transferability | Method transfers; pet risk drivers and claims history are absent, and you've said you've never worked on pet | `[inferred]` from the JD's product scope against your background; `[generic]` on pet drivers | Gap G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R6a, important) | discovery | Ran 14 tests; design step not stated | Design is half the test responsibility; confirming it could move R6a to direct | Setting the test split, hypothesis or success metric; choosing which segments to test | A test brief, design doc, or readout from one of the 14 | `[grounded]` background silence |
| G2 | Pet-insurance domain (R9, important) | transferability | Motor pricing method; no pet data | The JD makes pet the product; the limit should be named, not hidden | Any frequency or severity modelling on a non-motor line; any vet-cost or pet-owner data work | A short limits note and a sketch of how you'd approach pet pricing | `[inferred]` bridge from motor work; `[generic]` on pet drivers |
| G3 | Product-side recommendations (R7, important) | transferability | Recommendations to underwriting are evidenced; product is not | Half of the JD's outcome is product | Any pricing proposal taken to product managers, or a product change you influenced | A decision memo or product paper | `[grounded]` background silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay not stated | unknown | — | JD as provided has no salary | Pay may sit outside a senior band, or may simply be unpublished | `[grounded]` JD silence; band not checked | What is the base salary for this role? | unresolved |
| RR2 | Line management unstated | unknown | — | "Senior Pricing Analyst"; "own pricing analytics" | The role may carry direct reports; you have not managed anyone | `[inferred]` from title and "own" against silence | Does this role have direct reports now or within the first year? | unresolved |
| RR3 | Pet-product ramp | risk_signal | medium | "our pet-insurance product" | The first months may go to learning pet risk drivers before pricing | `[inferred]` from JD scope against your background; `[generic]` on pet drivers | What pet policy and claims data exists, how far back does it go, and which existing models would I inherit? | unresolved |
| RR4 | Model ownership and decision rights | unknown | — | "build and monitor rating models" | The build may be greenfield or inherit a live model; sign-off may sit elsewhere | `[inferred]` from JD silence | Which rating models exist today, who signs off a price change, and where are recommendations decided? | unresolved |
| RR5 | Employer and posting unverified | unknown | — | "Brindlemoor (insurtech)" | Unverified, not found missing: no search ran | Research tier line below | Can you confirm this role is open and name the team I'd join? | unresolved |
| RR6 | Specific responsibilities and stated requirements | positive_signal | — | Full responsibilities and requirement list | The scope is defined enough to test against | `[grounded]` JD | Who owns the pet product's loss-ratio targets? | noted |

**Application plan** (all proposed; pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the employer and live posting on Brindlemoor's careers page before applying | First condition for go | `[grounded]` RR5 | pending your approval |
| P2 | Put RR1–RR4 to the recruiter or hiring manager in the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |
| P3 | Lead with the GLM build (R4), the quarterly review (R5) and the 14 tests (R6b); name pet as the limit, not something to hide | Keeps the claim where the evidence is | `[grounded]` R4, R5, R6b; `[inferred]` on the lead choice | pending your approval |

**Evidence status**

Verified: none yet. Your background is self-report at intake, so nothing is verified until you confirm it specifically.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for the employer and posting was refused by the session. Would have checked the entity exists and that this role is live (RR5) |
| 2. Role-family sweep | unavailable | Salary and remit search was refused. Would have set the title, seniority and pay against a `[generic]` band (RR1) |
| 3. Hiring manager's public footprint | unavailable | Name was given, so a query could be formed; the search was refused. Would have fed positioning in P3 |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can keep and reuse for interview prep, if you want one.

**Upgrade menu**

- A link to the live posting or careers page: verifies the employer and sharpens RR1, RR2 and RR5.
- An anonymised model document or a price-test readout: raises R3 and R6a.
- Any pet-related pricing, claims or product work, even adjacent: moves R9 toward direct.
- Web search, if you allow it: the employer check, a role-family salary band, and the hiring manager's public footprint. Up to 5 searches and 2 fetches.

**Questions**

R1 — Are you based in the UK, with the right to work here without sponsorship, for a fully remote UK role?

G1 — On the 14 price tests, did you set the design, hypothesis and success measures, or run tests someone else designed?

Constraints — Do you have non-negotiables, such as a pay floor, no line management, or a start date, that I should check against this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.