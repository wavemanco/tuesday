**Yes, apply, but on conditions. Status: `conditional_go`.** On paper you fit all six must-haves (R1–R6). Two things stop this being a plain `go`: I couldn't check the company (web search was declined in this session), and the posting leaves your right to work and the role's scope unstated.

**Fit ledger.**

- `hard_gate` — unclear: R9 (Fully remote, UK)
- `must_have` — direct: R1 (4+ years pricing analytics), R2 (SQL and Python), R3 (GLM experience), R4 (presenting to underwriting or actuarial leads), R5 (designing and reading price tests), R6 (building and monitoring rating models)
- `preferred` — adjacent: R7 (Insurance experience)

R5 is `direct` on running and reading tests; whether you designed them is open (G1). R7 is the only row below `direct`, and its limit is pet specifically.

**Opportunity ledger.** The mandate is specific and measurable (RR5, positive). Against that, the employer is unverified (RR1), reporting lines are unstated for a senior title when you have never managed people (RR2), the salary is not stated (RR3), and it is unclear whether the role sets rate changes or only recommends them (RR4).

- **Hard gates:** none failed; unconfirmed: R9 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Brindlemoor and this posting confirmed on its own careers page (RR1); (2) R9 confirmed, meaning you are UK-based and can work there without sponsorship; (3) RR2 and RR4 answered cleanly.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Market calibration | Not run; no salary band | — |
| Unknowns | Employer's existence and scale; reporting lines; salary; rate-change authority | — |
| Contradictions | None visible in the JD alone | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years stated, two as senior analyst, at a UK motor insurer. Years are graded here, not gated | `[grounded]` your stated background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no query or script to inspect | `[grounded]` your stated background | Sanitized query or script (upgrade menu) |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. It is motor, not pet (see R7) | `[grounded]` your stated background | Sanitized model documentation (upgrade menu) |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. Actuarial audiences not stated | `[grounded]` your stated background | none |
| R5 | Designing and reading price tests | must_have | direct | medium | discovery | Ran 14 tests with underwriting. Whether you designed them is not stated, and the posting asks for design | `[grounded]` background; `[generic]` that interviewers probe design authorship | G1 |
| R6 | Building and monitoring rating models | must_have | direct | medium | none | Built and maintained the GLM; maintenance covers monitoring in the motor book | `[grounded]` background; `[inferred]` that maintenance includes monitoring | none |
| R7 | Insurance experience (pet-specific not stated) | preferred | adjacent | medium | transferability | Motor pricing carries over. No pet pricing, claims or product work | `[grounded]` background; `[inferred]` carry-over | G2 |
| R9 | Fully remote, UK | hard_gate | unclear | low | hard_gate | Your UK employer history suggests but does not settle location or right to work. You have not stated either | `[inferred]` from employer history; not confirmed | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R5, must_have) | discovery | You ran 14 tests; your part in designing them is not stated | The posting asks for design, the part a Director of Pricing will probe | Setting the hypothesis or test cells; choosing the sample; writing the brief for the 14 tests | A test brief, read-out, or sanitized design note | `[grounded]` background; `[generic]` interviewer focus |
| G2 | Pet-specific insurance (R7, preferred) | transferability | Motor pricing carries over; no pet evidence | Insurance is a plus, not a gate. The limit is the product, not the discipline | Motor-to-pet bridge work; any pet pricing or claims exposure, even reading | A short motor-to-pet analysis plan; any pet dataset you have seen | `[inferred]` bridge; `[generic]` that pet products price on different drivers than motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | "Senior Pricing Analyst — Brindlemoor (insurtech)" | Not checked: research was declined, and the JD is the only source | `[grounded]` JD header; research did not run | Can you point me at this role on Brindlemoor's own careers site, and who would I interview with? | unresolved |
| RR2 | Senior title, reporting lines unstated | risk_signal | medium | "Senior Pricing Analyst" | The seniority may carry direct reports the posting omits; you have never managed people | `[inferred]` from the title against the posting's silence | Does this role line-manage anyone, now or in its first year? | unresolved |
| RR3 | Salary not stated | unknown | — | No salary in the posting provided | Band unknown; market calibration did not run | `[grounded]` posting silence | What is the salary band for this post? | unresolved |
| RR4 | Rate-change authority unclear | unknown | — | "Own pricing analytics"; "recommendations for underwriting and product" | The role may recommend rather than set rates | `[inferred]` from the recommend-versus-own wording | Which rate changes does this role approve itself, and which go to underwriting or the Director of Pricing? | unresolved |
| RR5 | Mandate is specific and measurable | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined | `[grounded]` JD | Which rating models are live today, and who monitors them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the young-driver GLM you built and maintained. Say "built and maintained", not "owned pricing for the book". resume-tailor can turn this into a CV draft for the posting | R3, R6 | `[grounded]` your background | pending your approval |
| P2 | In interview, say what you designed in the 14 tests and what you only ran. Don't claim design you didn't do | R5, G1 | `[grounded]` your background | pending your approval |
| P3 | Frame pet as a bridge: same GLM and test discipline, no pet data yet. Name that limit yourself | R7 | `[inferred]` from R7 | pending your approval |
| P4 | Get the employer and live posting confirmed before spending application effort | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches were refused in this session, so the employer, the live posting and the contract basis are unchecked. Would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Would have set the salary band for RR3 and the scope norm for R5 |
| 3. Hiring manager's public footprint | unavailable | Odile Varga was named, so a query could be formed. Would have shown their background and what they publish. Not run |

Dossier offer: I can write this up as a `tuesday-dossier.md` to carry into your interview prep.

## Upgrade menu

- Your CV, or a sanitized extract of the GLM documentation → R3 and R6 move toward `high`
- A sanitized write-up of one price test, with your part marked → R5 closes (G1)
- The live posting link or Brindlemoor's careers page → RR1 closes
- Permission to allow web search in this session → the three L1 checks run again: employer, salary band, and Odile Varga's public footprint
- Any pet pricing or claims exposure, even reading → R7 and G2

## Questions

Q1 — R9 (hard gate): Are you based in the UK, and can you work there without sponsorship?

G1 — Did you design the 14 price tests, or run tests someone else designed? For any you designed, what did you choose: the hypothesis, the test cells, or the sample?

RR2 — Has anyone at Brindlemoor said whether this role line-manages anyone, now or in its first year?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.