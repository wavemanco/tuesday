## Decision snapshot

Yes, on the core of this role you are a credible fit: R1, R2, R3, R4 and R5 are your must-haves, and all five read `direct`. Apply only once the employer checks out, because I could not verify it. Status: `conditional_go`.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (define and maintain the metrics layer), R8 (partner with product managers and clinicians) · unclear: R7 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R3 — 30+ tests a year with a stated 11% retention lift, your strongest evidence; R6 — adjacent, no metric-definition ownership stated; R7 — no evidence either way; R8 — product side direct, clinician side absent; R9 — consent-model work, no HIPAA controls.

**Opportunity ledger.** The posting describes a defined scope with named partners, which is a positive signal (OR4). Two things are open: the employer is unverified (OR1, because web search was refused), and no pay is stated (OR2). Mentoring scope is unclear (OR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (OR1); (2) R7 and OR3 show the mentoring scope is one you can credibly take on; (3) R6 is confirmed as something you owned.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` your posting text, unverified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker, PM and clinician partnership, mentoring two juniors | `[grounded]` posting |
| Scope read | Senior IC-plus-mentoring scope; whether mentoring means direct reports is not stated | `[inferred]` from "mentor two junior analysts" against the title |
| Market calibration | Unavailable: the role-family search was refused, so no pay band is given | — |
| Unknowns | Employer and posting status; pay; contract type; whether mentoring means direct reports; clinician-facing work | — |
| Contradictions | None visible in the posting text you gave me; there is no second source to compare it with | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; self-report with no artifact yet, so the intake ceiling applies | `[grounded]` your intake statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated | `[grounded]` your intake statement | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift, stated; the lift's baseline is unconfirmed | `[grounded]` your intake statement | Offer: a sanitized readout would raise to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance, 40+ governed dashboards, stated | `[grounded]` your intake statement | Offer: a dashboard screenshot would raise to high |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents to the VP Product | `[grounded]` your intake statement | none |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and a consent-state model are close; metric-definition ownership is not stated | `[inferred]` bridge from Looker work | G2 |
| R7 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in the material settles it | `[grounded]` absence in your material | G1 |
| R8 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | medium | transferability | PM and VP Product partnership is direct; clinician partnership is absent | `[inferred]` from your PM and VP work | Name the clinician-facing limit in any answer |
| R9 | Healthcare data, HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model; no PHI or HIPAA controls | `[grounded]` your intake statement; `[inferred]` adjacency | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R7) | discovery | No mentoring of junior analysts is stated | A named important requirement; unresolved, it is the most likely interview probe | Onboarding or reviewing a new analyst's SQL; owning a junior's goals; interviewing or hiring analysts | A written onboarding plan, a review note, or a hiring loop you ran | `[grounded]` absence; `[generic]` that interviewers probe people-development claims |
| G2 | Metrics layer (R6) | transferability | Governed dashboards are stated; definition ownership is not | The posting names the metrics layer as a core responsibility | Writing metric definitions others used; resolving conflicting definitions; deprecating or certifying dashboards | A metric dictionary or definition doc | `[inferred]` adjacency from Looker work |
| G3 | Healthcare data (R9) | transferability | Consumer PII under GDPR/CCPA and a consent-state model | A preferred item; the adjacency is credible but its limits must be named | Consent and data-minimization decisions; access controls on sensitive fields | A sanitized consent-model design note | `[inferred]` adjacency; `[generic]` that HIPAA differs from GDPR/CCPA in its controls |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| OR1 | Employer and posting not verified | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be real and the posting live, but I could not check. Verification is needed before effort is spent | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Harborlight's own careers site, and who would I interview with? | unresolved |
| OR2 | Pay not stated | unknown | — | (no compensation in the posting as given) | The band and whether the employer publishes pay are unknown; the band search was refused | `[grounded]` absence in the posting | What is the base salary range for this role? | unresolved |
| OR3 | Mentoring scope unclear | unknown | — | "mentor two junior analysts" | Mentoring may be a line-management duty or an informal one | `[inferred]` from the title against the mentoring line | Is this a role with direct reports, or an IC role with mentoring duties? | unresolved |
| OR4 | Defined scope with named outcomes | positive_signal | — | "Own product analytics for our care-navigation app" | The scope is concrete, with named partners and responsibilities | `[grounded]` posting | Which metrics does the team treat as the care-navigation north star? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the employer and live posting before you apply | see OR1 | `[grounded]` OR1 | pending your approval |
| A2 | Proposed HIPAA line: "Built the consent-state model for the warehouse covering GDPR/CCPA consumer PII; have not worked under HIPAA." | see R9; every clause traces to your sentences | `[grounded]` your intake statements | `resume_edits_pending_approval` |
| A3 | Do not claim mentoring until G1 is answered | see R7 | `[grounded]` R7 | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your intake statements, which are leads until you confirm them specifically.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused, so the employer and posting could not be checked (OR1). This is a permission refusal, not a finding that the company is absent |
| 2. Role-family sweep | unavailable | No pay band or scope norm could be checked; OR2 and the market calibration stay open |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as a `tuesday-dossier.md` you can keep and reuse later.

## Upgrade menu

- Permission for web search → verifies the employer and posting (OR1), gives a pay band (OR2), and a scope norm for R6 and R7.
- The full posting, or a link to it → pay, location, contract type, and reporting line.
- Your own limits (location, pay floor, start date, contract type) → adds real gate checks; none can be run now.
- A sanitized experiment readout or a Looker dashboard screenshot → R3 and R4 move from `medium` to `high`.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. G1 (R7): Have you mentored or trained junior analysts? Did you own their reviews, hiring, or goals, or only informal help?
2. G2 (R6): When you ran the Looker and metrics work, did you define the metric definitions yourself, or inherit them?
3. Gate check: Do any of your own limits (location, pay floor, start date, contract type) rule this role in or out?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.