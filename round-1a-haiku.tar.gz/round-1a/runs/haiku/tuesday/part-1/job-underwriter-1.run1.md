**Yes, apply, on conditions. `conditional_go`.** Your five must-haves (R1, R2, R3, R4, R6) are `direct` against the posting. R8 (mentoring, unevidenced) and R9 (healthcare data, the preferred item) are the weakest rows. R5 and R7 are adjacent. I could not verify the employer, so the decision is capped at `conditional_go`.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6
- `important` — adjacent: R5 (metrics layer), R7 (partner with clinicians) · unclear: R8 (mentor two junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R5 — metrics layer is near your governed dashboards, not a stated definitions layer; R7 — PM partnership is direct, clinician work is not evidenced; R8 — no mentoring in your background; R9 — consent and PII work is the nearest, no health data.

**Opportunity ledger.** RR1 (no compensation in the posting text) is unknown, and RR4 (regulated data and clinical review of experiments) is unknown. RR2 (employer not verified) is a medium risk signal. RR3 (explicit scope) is a positive signal.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR2 — the posting is live on Harborlight's own careers page; (2) R8 — you have some mentoring or coaching to point to, or you accept it as a learning curve; (3) RR4 — the interview clears how experiments on care flows are reviewed and what data access looks like under HIPAA.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD as you pasted it |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, two junior analysts | `[grounded]` JD |
| Scope read | Senior-level scope with a named product and named deliverables | `[inferred]` from the responsibility list against the requirement list |
| Market calibration | Not run; the role-family search was refused | — |
| Compensation | Not stated in the posting text | `[grounded]` JD |
| Unknowns | Pay, reporting line, whether the metrics layer is yours or a central data team's, clinical and HIPAA governance | — |
| Contradictions | None visible within the posting as pasted; the careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; self-report, no inspectable artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; self-report | `[grounded]` your background | W1 (sanitized query sample) |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year; pricing test behind an 11% retention lift; no readout to inspect | `[grounded]` your background | W1 (sanitized test readout) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance from scratch; 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Define and maintain the metrics layer | important | adjacent | medium | transferability | Governed dashboards and the metrics memo are near it; no stated ownership of definitions | `[inferred]` from the dashboard work | Q-RR3 (see register) |
| R6 | Strong written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; presents to VP Product monthly | `[grounded]` your background | none |
| R7 | Partner with PMs and clinicians | important | adjacent | medium | transferability | PM partnership is direct; clinician work is absent from your background | `[grounded]` background; `[inferred]` adjacency | G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in your background; the question was not yet asked | `[grounded]` background silence | G1 |
| R9 | Healthcare data, HIPAA | preferred | adjacent | medium | transferability | Consent-state model and GDPR/CCPA PII work are the nearest; no PHI or HIPAA obligations exercised | `[grounded]` your background; `[inferred]` adjacency | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentor two junior analysts (R8, important) | discovery | No mentoring or coaching in the background | A visible unknown in a duty the posting names | Onboarding someone to your SQL or Looker standards; reviewing a colleague's test readout; running an analytics guild | A review note, an onboarding doc, or a short example | `[inferred]` that this duty is probed in interviews |
| G2 | Clinicians and health data (R7, R9) | transferability | Consent and PII work; no health data, no clinical partners | Adjacent evidence with a stated limit; a strengthener narrows the objection | Designing consent logic that others relied on; working with a non-analytics partner team on a regulated flow | A sanitized note on the consent model's design | `[generic]` that regulated-domain hiring probes this line |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Compensation not stated | unknown | — | No pay line in the posting text | The band can't be calibrated here; the search that would have set it was refused | `[inferred]` from the posting's silence | What is the base range, and is there bonus or equity on top? | unresolved |
| RR2 | Employer not verified | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company facts are your account, unchecked; the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Harborlight's own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Scope explicit | positive_signal | — | "define and maintain the metrics layer" | Scope is concrete and measurable | `[grounded]` JD | Does the metrics layer sit with this role, or with a central data team? | noted |
| RR4 | Regulated data and clinical review not described | unknown | — | "healthcare data (HIPAA) a plus"; "partner with … clinicians" | Experiments on care pathways may need clinical or privacy review that changes test design and cadence | `[inferred]` from the clinician partnership and the HIPAA line | How are experiments on care-navigation flows reviewed for clinical and privacy risk, and what data access does analytics have under HIPAA? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with your own sentence: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | R3 | `[grounded]` your sentence | resume_edits_pending_approval |
| E2 | Describe the consent work as consumer-PII handling: "Built the consent-state model for the warehouse." Do not write health data, HIPAA or PHI. | R9 | `[grounded]` your sentences; the limit is R9 | resume_edits_pending_approval |
| A1 | Confirm the posting on Harborlight's careers page before applying | RR2 | `[generic]` pattern, see RR2 | pending your approval |
| Q1 | Ask RR4's question verbatim in the first interview | RR4 | `[grounded]` register | pending your approval |
| W1 | Send a sanitized SQL sample or test readout | R2, R3 | `[grounded]` rows | pending your approval |

## Evidence status

Verified: none yet. Your background is still self-report.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were sent (two for this target). The host refused all three under the search permission, so nothing returned. This would have verified the employer and the live posting (RR2). |
| 2. Role-family sweep | unavailable | The third search was refused. This would have set the market band for RR1 and the scope norm. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Upgrade menu

- Enable web search in this session. The two unavailable targets run next (up to 5 searches and 2 fetches): RR2 and the market band for RR1.
- A sanitized SQL sample or test readout → R2 and R3 to `high`.
- Any mentoring example, even informal → R8 to `medium`.
- The posting's careers-page link, or the recruiter's email domain → RR2 closes.
- The base-salary range → RR1 closes.

If you want this kept as a `tuesday-dossier.md` you can append to as answers arrive, I can emit it on your word.

**Questions**

- R8: Have you mentored or coached junior analysts, even informally? If so, what did you own, and what happened?
- R9: Has any of your work touched health data, even de-identified, or sat alongside clinicians or care teams?
- RR2: Do you have the posting link from Harborlight's own careers site?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.