**Not wasted time, if you argue the adjacency well.** R1, the posting's one must-have (3+ years of PM experience), is an adjacent fit for you, not a direct one. That is a gap to argue, not a disqualifier · `conditional_go`

**Fit ledger.**

- `must_have` — adjacent: R1 (3+ years PM experience)
- `important` — direct: R3 (API docs and schema fluency), R4a (stakeholder management: engineering and customers), R8 (discovery with integration partners) · adjacent: R2 (shipped API or platform products), R6 (specs and delivery with two squads), R7a (roadmap input), R10 (launch coordination) · unclear: R4b (sales stakeholders), R5 (agile delivery), R7b (roadmap decisions), R9 (adoption metrics)

R1 is adjacent through roadmap-input and coordination work, with the limit named: you did not own the roadmap. R2 is integration delivery, not product lifecycle. R3 and R8 are direct. R7b and R9 are unclear and are the subject of this turn's questions.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The scope is concrete: a partner API platform, two squads, a roadmap (RR3, positive). Level, compensation and contract basis are not in the posting (RR2). The employer is not verified from here (RR4). The 3+ years line may be screened as a titled bar (RR1).
- **Conditions for go:** (1) you can name a prioritization decision you made, not only input you gathered (R7b, question 1); (2) the posting is confirmed on Quartzline's own careers page (RR4); (3) the recruiter accepts adjacent PM work against the years requirement (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs; drive delivery with two engineering squads; define adoption metrics; coordinate launches | `[grounded]` JD |
| Scope read | A full ownership role over one platform, not a support role | `[inferred]` from the responsibility list |
| Market calibration | Not run. The search was declined, so no pay or scope band is given | — |
| Unknowns | Level, compensation, location, reporting line, contract basis | — |
| Contradictions | None found within the JD text. Not checked against the careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must_have | adjacent | medium | transferability | No PM title. Roadmap input and PM coordination are adjacent; ownership is not shown | `[grounded]` JD marks it must-have; `[grounded]` CV | Q1; state the limit |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | 30+ REST integrations delivered end to end; you did not ship the product | `[grounded]` CV | State the limit; see G2 |
| R3 | API docs and schema fluency | important | direct | medium | none | Postman, SQL, OpenAPI reading, and integration architecture work | `[grounded]` CV | None |
| R4a | Stakeholders: engineering and customers | important | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds | `[grounded]` CV | None |
| R4b | Stakeholders: sales | important | unclear | none | discovery | No sales coordination in the CV | `[grounded]` CV silence | G3 |
| R5 | Agile delivery | important | unclear | low | discovery | "Coordinated engineers" is not agile detail | `[grounded]` CV silence on method | Q3 |
| R6 | Specs and delivery with two squads | important | adjacent | medium | transferability | Wrote requirements documents; no two-squad delivery | `[grounded]` CV | G7 |
| R7a | Roadmap input | important | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback | `[grounded]` CV | None |
| R7b | Roadmap decisions | important | unclear | low | discovery | Input is shown; decisions are not | `[grounded]` CV silence on decisions | Q1 |
| R8 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and client discovery; frame as discovery, not implementation | `[grounded]` CV | Reframe; see application plan |
| R9 | Adoption metrics | important | unclear | low | discovery | Only an unconfirmed prior-context lead; not evidence | `[grounded]` absence in CV; lead from memory | Q2 |
| R10 | Launch coordination with sales and support | important | adjacent | medium | transferability | Go-lives and UAT with clients; no sales or support launch work | `[grounded]` CV | G8 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | What would close it |
|---|---|---|---|---|---|
| G1 | 3+ years PM (R1) | transferability | Roadmap input and PM coordination; no ownership | The one must-have | A decision you made and its outcome; Q1 |
| G2 | Shipped products (R2) | transferability | Integration delivery; no product lifecycle | Second-tier gap | An API version, deprecation or changelog you ran |
| G3 | Sales (R4b) | discovery | Nothing in the CV | Named in the JD's stakeholder list | Any sales-facing work; no question this turn (budget) |
| G4 | Agile (R5) | discovery | No method named | Delivery with squads | Q3 |
| G5 | Roadmap decisions (R7b) | discovery | Input only | Decides R1 and the first condition | Q1 |
| G6 | Adoption metrics (R9) | discovery | Lead only | Explicit responsibility | Q2 |
| G7 | Two-squad delivery (R6) | transferability | Specs written; delivery across two teams not shown | Adjacent only | A spec you wrote, to inspect |
| G8 | Sales and support launches (R10) | transferability | Client go-lives | Adjacent only | Any launch with sales or support |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | 3+ years may be screened as a titled bar | risk_signal | medium | "3+ years product management experience (must-have)" | Adjacent PM work may be rejected without review | `[generic]` titled-years requirements are often screened literally; not a claim about this employer | Would you consider 3+ years of product-adjacent work to meet this requirement? | unresolved |
| RR2 | Level, pay and contract basis withheld | unknown | — | Not stated in the posting | The band may sit below your expectations | `[inferred]` from the posting's silence | What is the level and compensation band for this role? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "Own the roadmap for our partner-facing API platform" | The role has defined ownership and two squads | `[grounded]` JD | Which two squads, and what share of their roadmap does this role set? | noted |
| RR4 | Employer not verified | unknown | — | Company name and posting as given | Not checked from here; the search was declined | `[grounded]` evidence status below | Can you send the live posting and the careers page URL? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Describe the roadmap work as "collected client feedback that fed product's roadmap," not as owning it | Keeps R7a adjacent and R7b unclaimed | `[grounded]` CV wording | pending your approval |
| P2 | State the limit for R2 in the first answer: integration delivery, not product lifecycle | Protects the adjacency from a follow-up probe | `[grounded]` R2 row | pending your approval |
| P3 | Ask the recruiter for the live posting before investing in the loop | RR4 | `[grounded]` RR4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; both searches were declined by permission in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search for Quartzline's careers page was declined. Would have checked the company exists as described and the posting is live (RR4) |
| 2. Role-family sweep | unavailable | One search for pay and scope was declined. Would have set the pay band and market calibration (RR2) |
| 3. Hiring manager's public footprint | n/a | No hiring manager name was given |

Unverified lead: a prior-context mention of an internal request-triage tool that support adopted. Unconfirmed, so it prompts Q2 and is not evidence.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can reopen after the answers come in.

**Upgrade menu:**
- A requirements document or spec you wrote → R6 to `high`.
- Roadmap-input notes or an output showing what got prioritized → R7a and R7b.
- Adoption data for any tool you built → R9.
- A product-lifecycle example, such as an API version or deprecation → R2.
- The live posting → RR4.
- Searches once they are allowed → pay band (RR2) and the company check (RR4).

**Questions:**

Q1 — R7b (G5): Did you ever decide what got built next and what got cut, or did you gather input that someone else prioritized? Give one example: what you owned, who decided, and what happened.

Q2 — R9 (G6): Have you built an internal tool that other people adopted? Did you track adoption, and what did you measure?

Q3 — R5 (G4): Have you worked in sprints or another agile cadence with engineering squads? What did you own in planning, and what did you deliver through it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.