**Yes, on conditions: `conditional_go`.** Your six must-haves are covered on your own account (R2–R7), and the posting names the Director of Pricing as hiring manager, with a defined remit (RR3). Before you apply, confirm you're UK-based for this fully remote role (R1), and check that the posting is live on Brindlemoor's own careers page (RR5). I couldn't run either check, because the search permission was refused.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R10 (pet-insurance product); unclear: R8 (product recommendations)
- `preferred`: direct: R9 (insurance experience)

R2, R3, R4, R5, R6 and R7 are all six must-haves, each `direct` on your account (`medium`, because it's self-reported). R10 is a transfer from motor with its limits named. R8 has no evidence yet on the product side. R1 is the one gate, and it's unconfirmed, not failed.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Opportunity ledger.** Scope is specific and the hiring manager is named (RR3, positive). Line management, salary and the employer's live posting are unknown (RR1, RR4, RR5). None is a red flag yet.
- **Conditions for go:** (1) you confirm you're UK-based and eligible to work there (R1); (2) the posting is verified live on Brindlemoor's own site (RR5); (3) you confirm whether the role line-manages anyone (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech | `[grounded]` JD header; not verified |
| Scope | Own pet-insurance pricing analytics; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; footprint not researched |
| Market calibration | Not run. Salary band unavailable | — |
| Unknowns | Salary, line management, depth of pet data, product's decision rights | — |
| Contradictions | None visible in the material; the careers page couldn't be checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | Your base isn't in the material | `[grounded]` JD location term | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior, at a UK motor insurer; self-reported | `[grounded]` your account | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no code inspected | `[grounded]` your account | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for the young-driver book (motor, not pet) | `[grounded]` your account | none |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 tests last year with underwriting | `[grounded]` your account | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | "Maintained" covers building; monitoring isn't described | `[grounded]` build; `[inferred]` monitoring from "maintained" | Describe your monitoring in the interview |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to head of underwriting meets the underwriting branch of the requirement | `[grounded]` your account | none |
| R8 | Product-side recommendations | important | unclear | low | discovery | Underwriting work is evidenced; product work isn't | `[grounded]` silence | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your account | none |
| R10 | Pet-insurance product | important | adjacent | low | transferability | Motor pricing carries over; pet claims, breed and vet-cost data aren't exercised | `[inferred]` transfer from the JD's product and your motor work; `[generic]` pet pricing differs from motor | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side recommendations (R8, important) | discovery | Underwriting recommendations are evidenced; product isn't | Product is named in the JD's remit | Any test readout or pricing change that product adopted or rejected | A slide or memo sent to product | `[grounded]` silence |
| G2 | Pet product (R10, important) | transferability | Motor only | The posting is pet-specific | Any non-motor pricing, or pet-claims or policy data work | A sanitised model or readout | `[inferred]` transfer; `[generic]` pet-specific differences |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management not stated | unknown | — | "Senior Pricing Analyst" | The role may or may not line-manage; you've never managed anyone | `[inferred]` from title against silence | Does this role line-manage anyone now or within the year, and who would I report to? | unresolved |
| RR2 | Rating-model maturity | risk_signal | medium | "Build and monitor rating models" | A young pet product may have thin data behind its model | `[generic]` pattern for young product lines | How many years of pet policy and claims data does the current rating model rest on? | unresolved |
| RR3 | Defined scope and named sponsor | positive_signal | — | "Own pricing analytics for our pet-insurance product" | Ownership is explicit and the hiring manager is senior | `[grounded]` JD | Who sits above this role, and how is success measured? | noted |
| RR4 | Salary withheld | unknown | — | Not stated | Pay may be below market or simply unpublished | `[inferred]` from the posting's silence | What salary is budgeted for this post? | unresolved |
| RR5 | Employer and posting unverified | unknown | — | "Brindlemoor (insurtech)" | Not checked. Search was refused, so no claim is made about the company | `[generic]` no entity claim | Can you point me at the role on Brindlemoor's own careers page, and who would I interview with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Brindlemoor's careers page, and send me the link | Clears RR5 | `[grounded]` RR5 | pending your approval |
| A2 | Put RR1, RR2 and RR4 to the recruiter as written | Register doubles as prep | `[grounded]` register | pending your approval |
| P1 | Lead with your GLM and price-test work. Describe motor as insurance experience and pet as adjacent, never as pet experience | Matches R4, R5 and R10 | `[grounded]` your account; no claim beyond the stated motor work | pending your approval |

## Evidence status

Verified: none yet. Your account is self-report, so it sits at `medium`.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused. Would have confirmed Brindlemoor exists and the posting is live (RR5) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the salary band (RR4) |
| 3. Hiring manager's public footprint | unavailable | Same refusal. Would have shown Odile Varga's public track |

Dossier offer: I can write this up as a `tuesday-dossier.md` you can keep and add to later.

## Upgrade menu

- The live posting link, or Brindlemoor's careers page → RR5 closes; the decision moves to `go` if the posting is confirmed.
- The budgeted salary → RR4 closes, and it can be set against a band.
- A pet or non-motor pricing artifact, even a sanitised readout → R10 moves to `medium`.
- An anonymised GLM document or price-test readout → R4 and R5 move to `high`.
- Your product-side example (G1) → R8 moves to `medium`.
- Search permission → the three refused targets run in order, within the caps above.

Questions:

Q1 (R1): Are you based in the UK and able to work for a UK employer on a remote basis, without sponsorship? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 (R8): Did your price-test recommendations go to product as well as underwriting, and what did product do with them? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.