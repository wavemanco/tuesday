**Yes, apply, on conditions. Status: `conditional_go`.** On what you've told me, the analytics core matches the must-haves. The posting itself is unverified, and the clinician and mentoring parts are open.

**Fit ledger.**

- `must_have`: direct R1, R2, R3, R4 · adjacent R5 (define and maintain the metrics layer)
- `important`: direct R6, R7 · unclear R8 (partner with clinicians), R9 (mentor two junior analysts)
- `preferred`: adjacent R10 (healthcare data, HIPAA)

R5 — governed dashboards are evidence, but metric ownership is not stated; R8 and R9 — no evidence yet; R10 — consent-model work is a bridge, with its limit named.

**Opportunity ledger.** The mandate is concrete: a metrics layer, experiments, Looker, mentoring (RR5, positive). The posting is unverified and pay and location are absent (RR2, RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting checks out on the employer's own careers page (RR2); (2) the metrics-layer decision rights are confirmed (R5, RR3); (3) your answers on clinicians and mentoring hold up as stated, not stretched (R8, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital health, ~400 people, Series C | `[grounded]` JD header; not verified (see Evidence status) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, two junior analysts | `[grounded]` JD |
| Scope read | Senior IC plus mentoring, a normal shape for the title | `[inferred]` from the listed responsibilities |
| Market calibration | Not run; no pay or scope band is claimed | — |
| Unknowns | Pay, location, reporting line, team size, whether a metrics layer already exists | — |
| Contradictions | None visible in the one JD provided | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company, stated, no artifact yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is stated; "expert" is a level the material doesn't establish | `[grounded]` your background | Offer an anonymized query or model as a work sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a program you ran; the 11% lift is stated without its measure | `[grounded]` your background | Pin down the lift's measure before you use it (see E2) |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards | `[grounded]` your background | Offer a dashboard screenshot as a work sample |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards imply shared definitions, but ownership of canonical definitions is not stated | `[grounded]` dashboards; `[inferred]` that ownership moves the decision | G1, question Q1 |
| R6 | Written communication to non-technical stakeholders | important | direct | medium | none | Writes the monthly exec memo and presents it to the VP Product | `[grounded]` your background | none |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Monthly VP Product presentations; roadmap influence not stated | `[grounded]` your background | none |
| R8 | Partner with clinicians | important | unclear | low | discovery | No clinician work in the material; not established either way | `[grounded]` silence | G3 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring stated | `[grounded]` silence | G2, question Q2 |
| R10 | Healthcare data, HIPAA | preferred | adjacent | medium | transferability | Consent-state model and GDPR/CCPA PII work are a bridge; no PHI or HIPAA controls | `[grounded]` your background; `[inferred]` the bridge | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics ownership (R5, must_have) | transferability | Governed dashboards; no statement that you set canonical definitions | Decides condition 2 | Owning a metric dictionary; settling a retention or churn definition dispute; changing a definition and handling downstream fallout | A metric dictionary, a LookML model excerpt, or a definitions doc | `[grounded]` CV; `[inferred]` that it moves the decision |
| G2 | Mentoring (R9, important) | discovery | No mentoring or management stated | Interviewers will ask; you need an honest answer | Onboarding a new analyst, reviewing their SQL, running a team's analysis training | A onboarding plan or review example | `[grounded]` silence; `[generic]` that mentoring is probed in this role family |
| G3 | Clinician partnership (R8, important) | discovery | No domain-expert collaboration stated | The posting names clinicians as stakeholders | Validating analysis with experts outside product (finance, ops, legal) | An example of expert review changing a conclusion | `[grounded]` silence |
| G4 | Healthcare data (R10, preferred) | transferability | Consent model for consumer PII; no health data or HIPAA controls | Bridge, with its limit named | Consent-state logic that touched sensitive categories; access controls on personal data | The consent-state data dictionary | `[inferred]` bridge; `[generic]` that a HIPAA gap is usually asked about |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Mandate is concrete | positive_signal | — | "define and maintain the metrics layer… mentor two junior analysts" | Scope and outcomes are defined | `[grounded]` JD | — | noted |
| RR2 | Employer and posting unverified | unknown | — | "Harborlight Health… digital-health scale-up, Series C" | Research was refused, so the employer and the posting's live status are unchecked | `[inferred]` from no attributable source this run | Can you point me at this role on your own careers page, and who would I interview with? | unresolved |
| RR3 | Metrics-layer decision rights | unknown | — | "define and maintain the metrics layer" | The role may maintain definitions that a central team owns | `[inferred]` from the JD's verbs against its silence on team and authority | Who else sets canonical metric definitions, and what decision rights does this role hold over them? | unresolved |
| RR4 | Pay and location absent | unknown | — | (not stated in the JD) | Pay and location may be set later in the process | `[inferred]` from the JD's omission | What is the base range, and where is the role based? | unresolved |
| RR5 | Clinician process undefined | unknown | — | "partner with… clinicians" | Clinician input may be informal, or may include a clinical review step for claims | `[inferred]` from the JD naming clinicians without a process | How do clinicians shape analysis priorities, and is there a clinical review step for claims? | unresolved |

No entry is `severity: high`.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with the Looker build and the 40+ governed dashboards | Strongest direct match (R4) | `[grounded]` your background | resume_edits_pending_approval |
| E2 | State the 11% lift's measure exactly: relative or percentage points, sample, duration, guardrails | Interviewers probe this kind of number | `[grounded]` your stated figure; `[generic]` that such numbers get probed | pending your approval |
| E3 | Describe the consent-state model as GDPR/CCPA consumer PII work; don't use "healthcare" or "HIPAA" for it | Keeps R10 honest | `[grounded]` your background | resume_edits_pending_approval |
| A1 | Verify the posting on the employer's careers page before you invest in the loop | Closes RR2 | `[generic]` aggregator postings can be stale | pending your approval |
| A2 | Prepare true answers on mentoring and clinicians, claiming nothing beyond them | R8, R9 | `[generic]` interview practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused because search permission wasn't granted. Would have checked the employer exists, the posting is live, and nothing contradicts the JD (RR2) |
| 2. Role-family sweep | unavailable | Refused by the same prompt. Would have set the market calibration for title, seniority and pay |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

**Upgrade menu**

- Grant search permission and I'll run the employer and pay checks (up to 5 searches and 2 fetches at L1). That closes RR2 and sets the market calibration.
- The live posting link closes RR2 by hand, and makes the decision more reliable.
- A base range and a location close RR4.
- An anonymized SQL sample or experiment readout moves R2 and R3 to `high`.
- A metric dictionary or LookML excerpt moves R5 toward `high`.
- The hiring manager's name unlocks target 3.

If you want this kept for later, I can save it as `tuesday-dossier.md`, which the mock-interview module can pick up.

**Questions** (tagged to their rows)

- **Q1 (G1, R5):** Did you define and maintain the canonical metric definitions, such as retention or churn, or did you build dashboards on definitions someone else set? Who decided, and what changed when there was a dispute?
- **Q2 (G2, R9):** Have you formally mentored or managed junior analysts? Who, for how long, and what changed for them?
- **Q3 (RR2):** Can you paste the live posting link from the employer's careers page, or tell me the recruiter's email domain?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.