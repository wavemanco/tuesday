**No, it's not a waste of time, but expect the 3+ years line to screen you out first. `conditional_go`:** apply, with the conditions below. You'd be applying on transferable work, not a product-management record.

**Fit ledger.**

- `must_have`: adjacent: R1 (3+ years product management), R2 (shipped API or platform products), R3 (own roadmap and discovery with integration partners)
- `important`: direct: R4 (API docs and schema fluency) · adjacent: R6 (stakeholders across engineering, sales, customers), R8 (launch coordination with sales and support) · unclear: R5 (specs and delivery with two squads, agile), R7 (define and track adoption metrics)

R1–R3 are transferable work with the limits named. R4 is the clearest match. R5 and R7 are unclear, and the closing questions address them. The posting labels only the 3+ years line must-have, so I tiered R2 and R3 that way myself.

**Opportunity ledger.** The posting is specific: a named scope, two squads, and adoption metrics the role owns (RR3). Its title line is the likely screen (RR1), decision rights are unstated (RR2), and pay and location are not in the text you pasted (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the roadmap-ownership question (G1) comes back as real prioritization, even on one client's custom build; (2) the agile question (G2) gets a credible answer; (3) you frame the work as adjacent, never as a PM title; (4) the role is confirmed on Quartzline's own careers page. Condition 4 is the employer check I could not run (see evidence status).

**Role reality.**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B | `[grounded]` JD as pasted |
| Mandate | Own the roadmap for a partner-facing API platform; discovery with integration partners; specs and delivery with two squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | One platform, two squads, named launch duties: a single-owner product role | `[inferred]` from the listed responsibilities |
| Market calibration | Not run; research permission was refused | — |
| Unknowns | Location, pay, whether the role sets priorities outright, reporting line | — |
| Contradictions | None in the pasted text | `[grounded]` |

**Evidence map.** These are your resume claims, which are leads until you confirm them, so confidence stays at medium at most.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Seven years as solutions engineer and implementation lead; no PM title. The years line is graded on fit, not treated as a gate | `[grounded]` CV | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Shipped 30+ client integrations of the company's REST APIs. You did not own the product or its roadmap | `[grounded]` CV | G3 |
| R3 | Own roadmap and discovery with integration partners | must_have | adjacent | medium | transferability | Ran quarterly roadmap-input sessions collecting client feedback for product. No claim of owning prioritization | `[grounded]` CV | G1 |
| R4 | API docs and schema fluency | important | direct | medium | none | Postman, SQL, OpenAPI, integration architecture | `[grounded]` CV | none |
| R5 | Specs and delivery with two squads, agile | important | unclear | low | discovery | You wrote requirements documents; agile delivery is not stated | `[grounded]` CV silence | G2 |
| R6 | Stakeholders across engineering, sales, customers | important | adjacent | medium | transferability | Coordinated vendor engineers, client engineers and PMs. Sales is not mentioned | `[grounded]` CV | none |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | No metric ownership stated | `[grounded]` CV silence | G3 |
| R8 | Launch coordination with sales and support | important | adjacent | medium | transferability | Ran go-live end to end for each client. Sales and support coordination is not stated | `[grounded]` CV | none |

**Gap recovery queue.** Each row names what would close the gap. The questions are in the closing block.

- **G1** (R1, R3; transferability): The bridge is your work shaping what the client built and the order it came in. It would be stronger with one example where you decided priority or scope, or where you said no to a request. Its limit is that you have not owned a roadmap across a product.
- **G2** (R5; discovery): Your delivery experience may include sprint or backlog work that was never labeled agile.
- **G3** (R2, R7; discovery): An internal request-triage tool appears in a prior conversation. It is unconfirmed, so it is a lead only, not evidence. If it is real and people adopted it, it would bear on R2 and R7.

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Title screen | risk_signal | medium | "3+ years product management experience (must-have)" | The application may be filtered on the years line before the adjacent work is read | `[generic]` pattern for PM postings with a years requirement, not a claim about this employer | Is the 3+ years of product management a hard screen, or would seven years of integration and delivery work be weighed? | unresolved |
| RR2 | Decision rights unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may set priorities with squad leads and sales, not outright | `[inferred]` from silence on decision rights against the ownership language | Does this role set roadmap priorities outright, or together with the engineering leads and sales? | unresolved |
| RR3 | Measurable outcomes | positive_signal | — | "define and track adoption metrics" | Success is defined and the scope is concrete | `[grounded]` JD | Which adoption metrics will this role be measured on in year one? | noted |
| RR4 | Pay and location not stated | unknown | — | Not in the pasted text | Pay and location may sit on the careers page or be withheld | `[inferred]` from their absence in the pasted text | What is the base salary range, and where is the role based? | unresolved |

**Application plan.**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the 30+ integrations and the roadmap-input sessions | see R2, R3 | `[grounded]` CV | pending your approval |
| A2 | Keep "product management" out of your headline and title | see R1 | `[grounded]` JD years line | pending your approval |
| A3 | Answer G3 before drafting anything about the triage tool | see R2, R7 | `[grounded]` prior-conversation lead | pending your approval |
| A4 | Seek a referral before applying cold | Applications from referrals tend to get a human read at companies this size | `[generic]` hiring pattern | pending your approval |

Proposed resume lines, marked `resume_edits_pending_approval`:

- "Led 30+ client integrations of the company's REST APIs end to end: scoping workshops, requirements documents, integration architecture, UAT and go-live." Every clause traces to your sentence.
- "Ran quarterly roadmap-input sessions collecting client feedback for product." Traces to your sentence; no added ownership.

**Evidence status.** Verified: none yet. Unverified lead: the triage tool from a prior conversation.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused by permission. The employer's existence and the posting's liveness are unchecked |
| 2. Role-family sweep | unavailable | Same refusal. Would have placed the 3+ years title against role-family norms and a pay band |
| 3. Hiring manager's footprint | n/a | No name given |

**Upgrade menu.**

- Granting web search lets me run the employer and posting checks and the pay band (targets 1 and 2). That would settle RR4 and most of the employer check in condition 4.
- A roadmap doc, sprint plan or triage-tool artifact would move R2, R3 and R5 toward `direct`.
- The careers-page posting would close RR2 and RR4 if it states them.
- A hiring manager's name would shape the positioning.

Want me to save this as a `tuesday-dossier.md` so the map carries into interview prep?

1. **G1:** Have you ever decided the order of work for a client's custom build or an integration backlog, such as what shipped first or what got cut? What did you own, and what happened?
2. **G2:** How did delivery run with the engineering teams you wrote specs for: sprints, planning, who ran the backlog?
3. **G3:** The internal request-triage tool mentioned in a previous conversation: did you build it, what did support agents use it for, and how did you know it was in use?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.