## Decision snapshot

**Yes, it's worth applying to, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts rely on)

All five must-haves (R3, R4, R5, R6, R7) are direct, so your core stack matches; R8 is a credible bridge with its limit named; R9 and R10 aren't in your background, so they're unestablished.

- **Opportunity ledger.** Pay is posted inside the role-family band (RR1, positive). Equity is unstated (RR2). The company facts are its own claims and I could not check them (RR3).
- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 check out for you; (2) RR3: the Series C and the live posting are confirmed by the company or recruiter; (3) R8 is framed as a bridge with its limit named, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the company's About page as you pasted it; not independently checked |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse in BigQuery, and analyst-facing data contracts | `[grounded]` posting |
| Scope read | One domain's reporting pipelines, senior IC; no direct reports stated | `[inferred]` from the responsibilities |
| Pay | Posted $148,000–$166,000; midpoint $157,000, above the $151,000 median and inside the $139,000–$163,500 IQR | `[grounded]` posting; `[generic]` band from the Datawright report |
| Market calibration | Senior Data Engineer, Series B–D: median $151,000; 5–8 years is typical for "Senior" | `[generic]` Datawright 2026 report (n=2,310), via your recruiter |
| Unknowns | Equity terms; contract type; team and hiring manager; stage (assumed evaluating, you didn't say); the K-12 tutoring domain is new to your background but isn't a stated requirement | — |
| Contradictions | None between the posting and the About page as pasted | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in what you sent | `[grounded]` posting | Confirm (question 1) |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor isn't in what you sent | `[grounded]` posting | Confirm (question 2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-report, not probed | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models | `[grounded]` your intake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your intake | none |
| R8 | Warehouse in BigQuery (role description) | important | adjacent | medium | transferability | dbt and SQL carry over; BigQuery never used. Limit: partitioning, clustering, cost model, dialect | `[inferred]` bridge from Snowflake dbt work | G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background | `[grounded]` absence | G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your background | `[grounded]` absence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R8) | transferability | Snowflake dbt work; no BigQuery | Important tier, adjacent; interviews will likely test the BigQuery-specific choices | Snowflake cost or performance tuning; any partitioning or clustering decisions | A dbt model snippet or a warehouse-cost note | `[inferred]` bridge; `[grounded]` BigQuery absent from your intake |
| G2 | CRM ingestion and data contracts (R9, R10) | discovery | Neither appears in your intake | Both are named responsibilities of the role | Any CRM sync into a warehouse; any schema agreement with the models' consumers | A pipeline diagram, a contract document | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay posted and inside the band | positive_signal | — | "$148,000–$166,000" | The midpoint sits in the upper half of the band | `[grounded]` posting; `[generic]` band | Is this range set for this level, and how is equity sized on top of it? | noted |
| RR2 | Equity unstated | unknown | — | "plus equity" | Equity could move total pay a lot in either direction | `[inferred]` from the posting's silence | What equity comes with this level, with vesting, strike price and the latest valuation? | unresolved |
| RR3 | Company facts unchecked | unknown | — | "Series C ($52M, February 2026)" | No independent source yet; I could not run the check | `[generic]` companies state their own funding on their site; this one is unchecked | Can you point me to the Series C announcement, and who would this role report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and pay floor before applying | R1, R2 gates | `[grounded]` posting | pending your approval |
| A2 | Check the posting is live on the careers page, and ask the recruiter for the Series C source | RR3 | `[grounded]` RR3 | pending your approval |
| A3 | Describe BigQuery as a bridge with its limit stated, never as experience | R8, G1 | `[inferred]` R8 | pending your approval |

## Evidence status

Verified: none yet. Your intake is self-report at `medium`, and nothing has been probed. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search and both page fetches were refused permission in this session, and I did not retry. Would have checked whether the posting is live, whether the Series C claim holds, and whether the employer exists as described (RR3). |
| 2. Role-family sweep | skipped | The Datawright report you forwarded already fixes the band for this title and seniority (n=2,310), so a sweep would repeat it. |
| 3. Hiring manager's public footprint | n/a | No hiring manager is named in the posting or your intake. |

I can write this up as a `tuesday-dossier.md` you can carry into the next step.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the status likely moves to `go` or `no_go`.
- A CRM-ingestion example or a pipeline diagram → R9 and R10 leave `unclear`.
- A Snowflake cost or partitioning note → R8's bridge gets concrete.
- Web access, if granted → one L1 pass (company site and posting, up to 5 searches and 2 fetches) would check RR3.

Questions:

R1: Are you based in the US, and would you take this fully remote, or only from Denver?

R2: What is your base-pay floor, and does $148,000 clear it?

G2: Have you built a CRM-to-warehouse ingestion, or owned a data contract analysts relied on? If so, which system, and what did the contract cover?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.