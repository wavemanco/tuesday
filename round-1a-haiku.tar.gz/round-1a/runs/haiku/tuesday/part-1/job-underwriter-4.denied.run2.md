**Yes, apply, on conditions.** Status: `conditional_go`. Your must-haves match your record directly. The open items are whether the role is UK-remote for you, whether it carries direct reports, the pet-insurance ramp, and whether the posting checks out.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0.** The web search tool was refused in this session, so no employer, pay or hiring-manager checks ran. Everything about Brindlemoor below is from the pasted JD only.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote, UK)
- `must_have` — direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R6 (presenting to underwriting leads)
- `important` — direct: R5 (design and read price tests); adjacent: R8 (pet-insurance product)
- `preferred` — direct: R7 (insurance experience)

R2, R3, R4 and R6 are your strongest ground. R8 is the one real limit. R1 is a location term nothing you've said settles.

**Opportunity ledger.** The remit is concrete and reports to a named Director of Pricing (RR5). Pay and contract are withheld (RR4). The posting is silent on line management (RR2). The employer and live posting are unchecked from here (RR1). The pet-product ramp is the main risk (RR3).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager Odile Varga, Director of Pricing | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Senior individual-contributor analytics for one product; no management stated | `[inferred]` from the JD's scope against its silence on reports |
| Market calibration | Not run; search unavailable. No pay band given, and model memory is not used for market values | — |
| Unknowns | Employer and live posting; pay; contract type; reports; how pet-product decisions get made | — |
| Contradictions | None visible in the pasted JD; the careers page was not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | none | hard_gate | A location term. Your location and right to work are not stated, so the gate is not established | `[grounded]` JD | Question 1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior, at a UK motor insurer. This is length of experience, so it is not a gate. Prose intake caps at medium | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, as you stated. No artifact yet | `[grounded]` your background | Optional: a sanitized query or notebook would raise this to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for a young-driver motor book. The technique is direct; the line of business is motor, not pet | `[grounded]` your background | none; name the line of business in any claim |
| R5 | Design and read price tests | important | direct | medium | discovery | You ran 14 tests. Your account says "ran", not "designed", so design ownership is unconfirmed | `[grounded]` your background; ownership gap `[inferred]` | Question 3 |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7 | Insurance experience | preferred | direct | medium | none | Five years in UK motor insurance; not pet | `[grounded]` your background | none |
| R8 | Pet-insurance product | important | adjacent | medium | transferability | Inferred from "our pet-insurance product" in the scope; not a stated requirement. Motor rating and test methods carry over. You have no pet experience and should not claim any | `[inferred]` from the JD scope; transfer `[inferred]` from R4 and R5; `[generic]` that pet cover's loss drivers differ from motor's | G1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R8, important) | transferability | Motor pricing work only; no pet-related pricing or claims work on record | The main objection the team will raise. A stated limit narrows it | Motor pricing where a product's loss drivers were modelled from scratch; any work with claims or vet-cost data | A pricing note, a model-monitoring summary, or a claims analysis you can describe | `[inferred]` bridge from R4 and R5; `[generic]` that pet cover's drivers differ from motor's |
| G2 | Price-test design (R5, important) | discovery | 14 tests run with the underwriting team; design ownership not stated | "Design" is in the JD's responsibilities. Ownership decides whether R5 reads as direct or as execution only | Hypothesis framing, test-cell design, power calculations, or deciding what the test measured | A test brief or results pack you authored | `[grounded]` your background; `[inferred]` that ownership matters to the JD's wording |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting unchecked | unknown | — | "Brindlemoor (insurtech)" | The posting could be stale or aggregated, or the employer could be too small to have a footprint. Research could not run, so this is not a finding against Brindlemoor | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Brindlemoor's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | No line-management scope stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may carry direct reports the posting does not name. You have not managed anyone | `[inferred]` from the JD's scope against its silence on reports | Does this role have direct reports now or planned, and how is the analytics function's success measured? | unresolved |
| RR3 | Pet-product ramp | risk_signal | medium | "build and monitor rating models … for our pet-insurance product" | The team may expect pet-specific pricing judgement from the start, and you have none on record | `[inferred]` from the product scope against your history; `[generic]` that pet cover's drivers differ from motor's | Which pet-product pricing decisions will I own in the first 90 days, and what has the product's claims experience shown so far? | unresolved |
| RR4 | Pay and contract withheld | unknown | — | No pay or contract term in the pasted JD | The figure may be on the careers page or not published. No band is calibrated here | `[generic]` that postings often withhold pay | What is the salary band and contract type for this role? | unresolved |
| RR5 | Concrete remit and named leader | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The scope is defined and sits under a named Director of Pricing | `[grounded]` JD | How do pricing recommendations reach underwriting and product decisions today? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on Brindlemoor's own careers site before you invest in the application | RR1 | `[grounded]` register | proposed |
| A2 | Write the pet-insurance transfer case: motor methods carry over, the limit named, no pet claim | R8 | `[inferred]` R8 row | pending your approval |
| A3 | Put RR2 to RR4 to the employer in the first call; the register doubles as interview prep | RR2–RR4 | `[grounded]` register | proposed |

**Evidence status.** Verified: none yet.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst pet insurance"; both refused. Would have checked the employer exists and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK motor insurance salary GLM"; refused. Would have set the market calibration and the RR4 band |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. Would have fed the scope read and which story to lead with |

I can write this up as a `tuesday-dossier.md` you can keep and update as answers come in.

**Upgrade menu**

- The posting link from Brindlemoor's careers site → RR1 closes, and the conditional go becomes a clean one
- The salary band and contract type → RR4 closes, and the band is set against the role-family norm
- Search permission granted → the three L1 targets run; they would check the employer, the pay band, and the hiring manager's public background
- A sanitized query, notebook, or test brief → R3 or R5 can move to a higher confidence or a cleaner gap call
- A pet-product example from any work you've done, even secondhand → R8 narrows from a stated limit to a bridge

**Questions**

1. **R1:** Are you based in the UK and eligible to work there without sponsorship?
2. **Constraints:** What are your non-negotiables for this search: pay floor, contract type, earliest start date, and would a role with direct reports be a problem?
3. **G2 (R5):** For the 14 price tests, did you design them, or did someone else design them and you ran them? What did you own at each stage?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.