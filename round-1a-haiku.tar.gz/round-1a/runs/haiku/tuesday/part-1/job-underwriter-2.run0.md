**No, you're not wasting your time, but the must-have PM years are the real hurdle. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1 (3+ years product management), R2 (shipped API or platform products), R4 (sales coordination), R5 (specs and squads), R7 (roadmap ownership) · unclear: R6 (agile delivery)
- `important` — direct: R8 (discovery with partners) · adjacent: R10 (launch coordination) · unclear: R9 (adoption metrics)

R3 — the one must-have at `direct`, backed by your CV but not yet inspected; R1, R2, R5 and R7 — adjacent, each with its limit named in the queue; R6 — no evidence yet; R8 — direct; R10 — adjacent; R9 — no evidence yet.

**Opportunity ledger.** Concrete scope and a defined mandate (RR3); roadmap authority, pay and contract basis not stated (RR1, RR2); employer and posting not verified (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR4); (2) decision authority over the roadmap is concrete (RR1); (3) R6 gets a real answer; (4) R1 is presented as adjacent experience, never as PM years.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` posting as you provided it |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; spec and drive delivery with two engineering squads; define adoption metrics; coordinate launches with sales and support | `[grounded]` posting |
| Scope read | A roadmap owner with delivery and launch duties across two squads; a plausible mid-level product role | `[inferred]` from the responsibility list against its silence on decision rights |
| Market calibration | Not run; the search that would have set it was refused, so no band is given | — |
| Unknowns | Roadmap decision rights; compensation; contract basis; whether agile is practised; whether the employer and posting are live | — |
| Contradictions | None found inside the posting as provided | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | Seven years of implementation and requirements work, no PM title. Experience, not a gate, so graded, not failed | `[grounded]` CV; `[generic]` that PM titles are often screened literally | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ integrations of a vendor's REST APIs. Limit: the CV does not show you shipped the API product itself | `[grounded]` CV | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI named. Inspectable only by a probe on schema design | `[grounded]` CV | none |
| R4 | Stakeholder management across engineering, sales, customers | must_have | adjacent | medium | transferability | Engineers, client engineers and PMs coordinated on custom builds. Sales is not named | `[grounded]` CV | G3 |
| R5 | Writing specs and driving delivery with engineering squads | must_have | adjacent | medium | transferability | Requirements documents and coordination on custom builds. No squad ownership or cadence stated | `[grounded]` CV | G4 |
| R6 | Agile delivery experience | must_have | unclear | low | discovery | No agile evidence in the material you gave | `[grounded]` absence in CV | G5 |
| R7 | Owning a partner-facing platform roadmap | must_have | adjacent | medium | transferability | Ran quarterly roadmap-input sessions. Input, not ownership | `[grounded]` CV | G6 |
| R8 | Discovery with integration partners | important | direct | medium | none | Scoping workshops and requirements gathering across 30+ integrations | `[grounded]` CV | none |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | No metric in the CV. SQL is a tool, not a measured outcome. An unconfirmed earlier note may bear on this, used only as a question basis | `[grounded]` CV absence; memory lead, not evidence | G7 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | UAT and go-live ran on each integration. Sales and support coordination not named | `[grounded]` CV | G8 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM years (R1) | transferability | Implementation and requirements ownership; no PM title | The must-have most likely to be screened literally | A prioritization call you made in requirements work (what was cut, what went first, why); a roadmap you shaped for a client track | Sanitized requirements document with decisions visible | `[grounded]` CV; `[generic]` screening pattern |
| G2 | Shipped products (R2) | transferability | You shipped integrations on the vendor's API | Separates integrator from product owner | Any API change you specified that shipped; deprecation or versioning decisions | Sanitized integration playbook | `[grounded]` CV |
| G3 | Sales coordination (R4, R10) | transferability | Customer and engineering coordination; sales not named | Half of the stakeholder requirement is unevidenced | Pre-sales scoping calls; commercial commitments you flagged to engineering | Scoping workshop agenda | `[grounded]` CV |
| G4 | Squad delivery (R5) | transferability | Requirements and coordination on builds | The JD expects you to drive two squads | Backlog or sprint work on a custom build | Sanitized backlog extract | `[grounded]` CV |
| G5 | Agile (R6) | discovery | No agile evidence | A must-have with no evidence; could move the decision | Any sprint-based team you worked inside | Team charter or sprint record | `[grounded]` absence |
| G6 | Roadmap ownership (R7) | transferability | Input sessions, not ownership | Central to the role's first ask | Any roadmap decision, even shared | Roadmap-input summary you produced | `[grounded]` CV |
| G7 | Adoption metrics (R9) | discovery | Nothing measured in the CV | Important responsibility with no evidence | Any usage or go-live metric you tracked | Dashboard or query output | `[grounded]` CV absence |
| G8 | Launch coordination (R10) | transferability | UAT and go-live ran; sales and support absent | Launch duty is explicit in the JD | Go-live checklists; support handover | Launch checklist | `[grounded]` CV |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap decision rights not stated | unknown | — | "Own the roadmap for our partner-facing API platform" | Ownership may be advisory, with priorities set by leadership | `[inferred]` from "own the roadmap" against silence on prioritization | When the roadmap conflicts with a sales commitment, who makes the final call? | unresolved |
| RR2 | Pay and contract basis absent | unknown | — | Posting gives neither | Compensation may be withheld; the band cannot be checked, research being refused | `[inferred]` from the posting's silence | What is the base salary range, and is this a permanent role? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "run discovery… write specs and drive delivery… define and track adoption metrics" | Success is measurable and the role is defined | `[grounded]` posting | Which adoption metrics does this role own today, and what are they now? | noted |
| RR4 | Employer and posting unverified | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The posting may be stale or not represent a live hire; the employer may be too small to have a footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the live posting on Quartzline's own careers page before applying | RR4 | `[generic]` pattern | proposed |
| A2 | Lead with: "Led 30+ client integrations of our REST APIs end to end, from scoping workshops and requirements documents through UAT and go-live." | R2, R8 | `[grounded]` CV | pending your approval |
| A3 | Describe roadmap work as it was: "Ran quarterly roadmap-input sessions collecting client feedback for product." Do not write that you owned the roadmap | R7 | `[grounded]` CV | pending your approval |
| A4 | Put RR1 and RR2 to the recruiter in the first call | RR1, RR2 | `[grounded]` register | pending your approval |
| A5 | Offer one sanitized work sample from a real integration: a requirements document or playbook section, with decisions visible. Check your confidentiality terms first | R1, R5 | `[generic]` screening practice | pending your approval |

Under this shape, RR1 and RR2 are not fixed by wording. If the recruiter confirms that prioritization sits with leadership, the role is closer to R7's adjacency than to ownership, and the decision should be re-read.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent and refused by the session's permission setting. Would have moved RR4 and the role-reality contradictions row |
| 2. Role-family sweep | unavailable | Refused with the same setting. Would have set the market calibration for R1 and the band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- A reply to the three questions below → R1, R7 and R9 move off `low` or `adjacent` where you can show decisions or metrics.
- The live posting link or your careers-page check → RR4 closes.
- The posting's salary and contract basis, from the recruiter → RR2 closes, and the decision can simplify.
- Web search permitted for this session → the employer and salary checks run at L1 (up to 5 searches, 2 fetches); deeper diligence is available once after that (up to 5 more searches, 2 more fetches).
- A sanitized integration playbook or requirements document → R2 and R5 move to `high` if inspectable.
- A sprint record or team charter → R6 moves from `unclear`.

I can write this analysis out as a `tuesday-dossier.md` for reuse with the mock-interview module when you're ready.

R1, R7 — Think of one decision in the last seven years where you shaped what got built next for an integration or API: a sequence, a cut, or a trade-off. What did you decide, what did you only recommend, and who had the final say?

R6 — Have you worked inside a sprint-based squad with an engineering team: sprints, a backlog, standups, reviews? If so, which team, for how long, and what was your part?

R9 — Your earlier notes mention an internal request-triage tool that support agents adopted. Did you build it, what did it do, and did anyone measure whether people kept using it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.