**Yes, worth applying, on conditions.** Status: `conditional_go`. Your Snowflake dbt and Airflow work covers most of the must-haves. BigQuery is the real gap, and it's recoverable. Two important requirements have no evidence yet, and the location gate can't be checked from what you've given me.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office)
- `must_have`: direct: R2 (5+ years data engineering), R3 (strong SQL and Python), R4a (dbt), R4b (cloud warehouse), R6 (orchestration with Airflow or similar), R7 (experience with data quality testing)
- `important`: adjacent: R5 (BigQuery warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R5 — Snowflake carries over, BigQuery-specific work doesn't. R8 and R9 — nothing in your background yet shows either.

**Opportunity ledger.** The posting is live on the company's own careers page and its pay is disclosed and near market. Open items are the unnamed team and hiring manager (RR1), a scope that spans ingestion, warehouse and contracts (RR2), unquantified equity (RR4), and a company footprint that so far exists only on its own pages (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for `go` are (1) R1 confirmed, (2) a credible BigQuery plan for R5, (3) R8 and R9 backed by a real example in interview, (4) RR5 checked against an independent source.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states, founded 2016, Denver | `[grounded]` About page, fetched |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts | `[grounded]` posting, fetched; matches your paste |
| Pay | $148,000–$166,000 plus equity; midpoint $157,000 | `[grounded]` posting |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years; typically one domain's pipelines, no direct reports | `[generic]` Datawright 2026 report |
| Scope read | Covers three domains (ingestion, warehouse, contracts), wider than the typical one-domain senior scope | `[inferred]` from the posting against the `[generic]` norm |
| Unknowns | Team, hiring manager, direct reports, equity size, location terms for your candidacy | — |
| Contradictions | None between the posting and the careers page | `[grounded]` both fetched |

Against the market, the low end sits $3,000 under the median and the high end sits $2,500 above the top of the interquartile range. That's a band, not this employer's offer.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location or work-authorization statement in your inputs | `[grounded]` posting; nothing from you | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years, self-reported at intake; a length of experience, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, no artifact yet | `[grounded]` your background | none |
| R4a | dbt | must_have | direct | medium | none | Built a ~180-model dbt project | `[grounded]` your background | none |
| R4b | Cloud warehouse | must_have | direct | medium | none | Snowflake in production | `[grounded]` your background | none |
| R5 | BigQuery warehouse | important | adjacent | medium | transferability | Same warehouse class; BigQuery's cost model, partitioning and dialect unused | `[inferred]` from Snowflake against BigQuery | G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; whether you owned it or ran it is not yet stated | `[grounded]` your background | none |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not mentioned | `[grounded]` absence in your inputs | G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Test suites are not contracts with consumers | `[inferred]` from the difference between tests and contracts | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R5) | transferability | Snowflake dbt and warehouse work; no BigQuery | Most likely interview objection; narrowing it removes the main reason to hesitate | Any GCP project, BigQuery cost or partitioning work, a dbt adapter switch | A sandbox project, a short course certificate, or a migration note | `[inferred]` bridge from Snowflake work; `[generic]` that BigQuery is the likeliest objection |
| G2 | Ingestion from app and CRM (R8) | discovery | Your background is silent on source ingestion | Important-tier; likely probed in interview | Product database replication, CRM sync, event pipelines you owned | Pipeline diagram, DAG list, a runbook | `[grounded]` absence |
| G3 | Data contracts (R9) | discovery | Tests exist; consumer-facing contracts are not mentioned | The posting names contracts as a core duty | Schema agreements with analysts, breaking-change process, owner sign-off | A contract doc, changelog, or review note | `[inferred]` difference between tests and contracts |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager or team named | unknown | — | (posting silent) | The role may sit alone under a non-data leader | `[generic]` pattern for unnamed-manager postings | Who would I report to, and how many engineers are on the team? | unresolved |
| RR2 | Scope spans three domains | risk_signal | low | "Build and run the pipelines behind our … reporting: ingestion …, a dbt-modelled warehouse …, and the data contracts" | One person may own the whole stack, not one domain | `[inferred]` from the JD's scope against the `[generic]` norm | Which of these three areas would I own, and which belong to other teams? | unresolved |
| RR3 | Pay disclosed and near market | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is credible against the market band | `[grounded]` posting; `[generic]` band | Is the range for this role's level, and what would move a candidate within it? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity could be a meaningful part of total pay | `[inferred]` from the posting's silence on grant size | What is the equity grant size and vesting schedule? | unresolved |
| RR5 | Company footprint is its own pages only | risk_signal | low | "Series C ($52M, February 2026)" | The funding and size may be accurate but are uncorroborated by any third party | `[generic]` pattern for companies this size; three searches found no independent source | Can you point me to the funding announcement or the investors' statement? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for team size, hiring manager, reporting line, and equity size | RR1, RR2, RR4 | `[grounded]` register | pending your approval |
| A2 | Check the Series C claim against an independent source before the loop | RR5 | `[generic]` pattern | pending your approval |
| A3 | Prepare the BigQuery bridge: "Snowflake in production, BigQuery new, here's my ramp plan" | R5 | `[grounded]` R5 row | pending your approval |

**Evidence status.** Verified: none yet. Your background is intake-level, so every row tops out at `medium`.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer (live, "Accepting applications", text matches your paste) and pellucidlearning.com/about (matches your paste). Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "\"Pellucid Learning\" Series C funding 2026" (returned only the About page). Moved: posting verified live; employer attributable only to its own pages (RR5) |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer salary", which returned datawright.example/2026-data-engineering-pay-report; its excerpt matches your paste. Moved: market calibration (`[generic]`) |
| 3. Hiring manager's public footprint | n/a | No name in the inputs, so no query to form. The upgrade menu says what a name would unlock |

**Upgrade menu**

- Your location and US work authorization → R1 resolves. This is the one gate that decides the status.
- One real example each of app/CRM ingestion (R8) and a data contract (R9) → both move from `unclear` to `direct`.
- Any BigQuery exposure, even a sandbox run → R5 narrows and G1 closes.
- The hiring manager's name → unlocks research target 3 and the scope read.
- Deeper diligence on Pellucid (funding and leadership churn, public reports, recent news; up to 5 more searches and 2 more fetches) → would test RR5 further. Say the word and it runs.

I can write these results to `tuesday-dossier.md` so the other modules can read them later.

**Questions**

Q1 (R1): Are you based in the US, and are you authorized to work for a US employer without sponsorship?

G2 (R8): Have you built ingestion from a product database or a CRM? If so, which one, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.