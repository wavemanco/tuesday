**No, don't pursue this one. Both of your hard constraints fail on the posting's own terms, so nothing in your experience changes the answer. Status: `no_go`.**

Your sense that something is off is right. The fit on paper is real: paid, lifecycle, experimentation, and leadership all line up. But the role is on-site in Austin five days a week with "no exceptions," and it pays $70–85k base against your $150k floor.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (on-site Austin, five days a week), R2 (base pay $70–85k)
- `must_have` — direct: R3 (paid acquisition), R4 (lifecycle/CRM), R5 (8+ years growth leadership)
- `important` — adjacent: R9 (e-commerce enablement); unclear: R6 (SEO/content), R7 (brand and PR), R8 (partnerships and sales ops), R10 (no team, ambiguity at the start)

R1 and R2 are both gates and both fail, which caps the status regardless of the rest. R3, R4 and R5 are your strongest case, at `medium` until something is inspected. R9 is a credible bridge with its limit named. R6, R7, R8 and R10 are functions or conditions your account doesn't describe.

**Opportunity ledger.** The posting is transparent about pay, but its scope and expectations are the warning signs: a team of one owning seven functions (RR1, RR5), always-on hours (RR2), success metrics that aren't defined yet (RR3), and pay that looks low for the seniority it asks for (RR4). RR6 is the one positive: the pay is stated, not withheld.

- **Hard gates:** failed: R1 (on-site Austin, five days a week), R2 (base pay $70–85k); candidate constraints given, both checked.
- **Severe red flags:** none found. The two gate failures sit on the hard-gates line, not in the register.
- **What would change this:** only the employer changing R1 or R2 would reopen the role, for example a remote arrangement or a base at or above $150k in writing. The posting rules out both, so I wouldn't spend application effort here.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claims; not checked |
| Mandate | All revenue growth end to end, across seven listed functions | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | Austin on-site five days; evenings and weekends "when it matters" | `[grounded]` posting |
| Scope read | One person to start, with the full function list | `[inferred]` from the list against "team of one" |
| Market calibration | Not run. Pay is judged against your floor, not a market band | — |
| Unknowns | Whether the posting is live; equity terms; what "when it matters" means | — |
| Contradictions | "8+ years growth leadership required" against "team of one to start" | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, five days a week (your constraint: remote-only) | hard_gate | hard_gate_fail | high | hard_gate | Posting says "no exceptions." High grades your own stated constraint, not the fit | `[grounded]` posting; your statement | none; only the employer changing the term reopens it |
| R2 | Base pay $70–85k (your floor: $150k) | hard_gate | hard_gate_fail | high | hard_gate | Top of the posted range is $65k under your floor | `[grounded]` posting arithmetic; your statement | none; only a different posted range reopens it |
| R3 | Paid acquisition | must_have | direct | medium | none | You say you owned paid with a budget you controlled; no artifact inspected | `[grounded]` your statement | none |
| R4 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze; no artifact inspected | `[grounded]` your statement | none |
| R5 | 8+ years growth leadership | must_have | direct | medium | none | Nine years; Head of Growth at two companies; managed teams of 3–7 | `[grounded]` your statement | none |
| R6 | SEO and content | important | unclear | low | discovery | Not in your description | `[grounded]` absence | none; doesn't change the decision |
| R7 | Brand and PR | important | unclear | low | discovery | Not in your description | `[grounded]` absence | none; doesn't change the decision |
| R8 | Partnerships and sales ops | important | unclear | low | discovery | Not in your description | `[grounded]` absence | none; doesn't change the decision |
| R9 | E-commerce enablement | important | adjacent | medium | transferability | B2C subscription growth carries over to lifecycle and paid. Novaline's customer type isn't stated, so the limit is unknown | `[inferred]` from your two companies' work | none |
| R10 | Ambiguity at the start, team of one | important | unclear | low | discovery | Your history is scaling existing companies; no build-from-zero stated | `[grounded]` absence | none; doesn't change the decision |

**Gap recovery queue.** The gaps on R6, R7, R8 and R10 aren't worth closing for this posting. The decision rests on R1 and R2, and no answer about your experience changes either one.

## Opportunity risk register

- **RR1: Accountability without resources.** `risk_signal`, severity medium. Quote: "You will be a team of one to start." Hypothesis: you could own all revenue growth with no team, budget or decision rights in sight. `[inferred]` from the scope against the team-of-one line. Question: "What budget, headcount and decision rights come with this role on day one, and which of the seven functions are staffed in year one?" Status: unresolved.
- **RR2: Always-on expectation.** `risk_signal`, severity medium. Quote: "evenings and weekends when it matters is just who we are." Hypothesis: evenings and weekends may be routine, not occasional. `[inferred]` from the phrasing; `[generic]` that "when it matters" usually covers launches and quarter-ends. Question: "How many evenings or weekend days has this role worked in the last six months, and what triggered them?" Status: unresolved.
- **RR3: Success metrics undefined on a demanding mandate.** `risk_signal`, severity medium. Quote: "success metrics will evolve as we learn," alongside "8+ years ... required." Hypothesis: you could be reviewed against criteria nobody has written down. `[generic]` pattern for Series A roles. Question: "What three numbers will you judge this role on at six and twelve months, and what are today's baselines?" Status: unresolved.
- **RR4: Seniority-compensation mismatch.** `risk_signal`, severity medium. Quote: "8+ years growth leadership required" against "$70–85k base." Hypothesis: the pay looks low for a Head-level mandate. Not calibrated, since no market search ran. `[generic]` pattern; not a claim about Novaline's budget. Question: "Is $70–85k the approved range for this seniority, and what is the equity worth in dollars and percentage?" Status: unresolved.
- **RR5: Bundled functions.** `risk_signal`, severity medium. Quote: "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops." Hypothesis: several specialist roles folded into one head, a pattern usually priced below the sum of those roles. `[generic]` pattern. Question: "Which of these functions will be hired or contracted in the first year, and in what order?" Status: unresolved.
- **RR6: Pay is stated.** `positive_signal`. Quote: "$70–85k base plus meaningful equity upside." Hypothesis: the range is disclosed, so the problem is the range itself. `[grounded]` posting. Question: "Is $70–85k the figure you would put in writing?" Status: noted.

**Application plan.** None proposed. Nothing in the posting's terms can be fixed from your side.

## Evidence status

Verified: your R1 and R2 constraints (your own statements, `high`). R3, R4 and R5 are your statements in this conversation, at `medium`, with no artifact inspected. Unchecked: the posting's Series A and profitability claims, and whether Novaline exists as described. The decision doesn't depend on either.

Research tier: L1 — searches 0 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | The inputs fix this output: both gates fail on the posting's terms, and no employer fact could reopen them. It would have confirmed the posting is live and the employer exists |
| 2. Role-family sweep | skipped | R2 is decided against your floor from the posted range, so no market band is needed for the status. It would have checked RR4 against a band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- **A live posting or careers-page listing** would show whether "Austin, no exceptions" and "$70–85k" are current. If either reads differently, R1 or R2 reopens and the status moves to `hold_pending_answers`.
- **Written confirmation from the recruiter** of the location policy and pay range would have the same effect.
- **A search on Novaline** (official site, funding, leadership, hiring pattern) would check that the employer exists. It matters only if the gates reopen.
- **A market sweep for Head of Growth pay at Series A** would turn RR4 from a pattern into a checkable band. It wouldn't change the decision.

If you want a record of this, I can write it up as a `tuesday-dossier.md`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.