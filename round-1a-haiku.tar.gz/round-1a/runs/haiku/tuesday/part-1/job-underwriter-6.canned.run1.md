**Decision: `conditional_go`.** Apply, but only once two gaps and the posting's status are checked. Your strongest matches are the Salesforce, SQL and pipeline/renewal reporting requirements. The two real gaps are owning a forecast and working with billing data, and both are central to this role.

**Research tier: L1, searches 1 of 5, fetches 0 of 2; user links read 1**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | `yes` | One search found Quillfield's About page: invoicing and payments software for UK builders' merchants, founded 2018, Bristol, 96 staff, £11M Series A closed April 2025. Their own careers page did not come up, so the posting's live status is unverified. |
| 2 | Role-family sweep (pay and scope) | `unavailable` | Not run in this pass. The £61,500–£67,000 band is not calibrated against market. |
| 3 | Hiring manager's public footprint (Tamsin Achebe) | `unavailable` | Not run in this pass. |

**Fit ledger**

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in office), R2 (£61,500–£67,000 plus share options); candidate constraints not given, so checks against them are unknown.
- **Must-have:** R3 `direct` (4+ years in revenue or sales operations, B2B; your five years at a payments company), R4 `direct` (Salesforce admin), R5a `direct` (SQL), R5b `adjacent` (spreadsheet modelling; you use Excel daily but not described as modelling), R6 `adjacent` (forecast ownership; you run the pipeline review, but finance owned the company forecast), R7 `adjacent` (billing or revenue data with finance; you have not worked on billing data).
- **Important:** R8 `direct` (pipeline and renewal reporting), R9 `adjacent` (owning CRM and billing data; CRM yes, billing no).

**Opportunity ledger.** Positive: Series A closed recently, a sizeable pay range is stated, and the scope is clear. Unknown: whether the forecast is truly owned by this role or shared with the CFO, and how hands-on the billing data work is. The role bundles RevOps, forecasting and billing data into one title; that is a question to ask, not a red flag. No severe red flags found.

**Gap recovery queue (no questions here)**
- R6 forecast ownership: the closure path is showing that your pipeline review fed a forecast, or that you tracked forecast accuracy.
- R7 billing data: the closure path is any reconciliation or revenue-data work at your payments company, even if it was not billing data itself.
- R5b modelling: the closure path is a model or scenario sheet you built in Excel.

**Application plan.** Lead with the pipeline and renewal dashboards, Salesforce certification, and SQL. Say plainly that you have run pipeline reviews, not owned a forecast, and have not worked on billing data. Do not claim forecast ownership; it would not survive the first interview.

**What would change this:** if your location or pay floor rules out R1 or R2, the status drops to `no_go`. If the careers page shows no such role, it stays `conditional_go` until the posting is verified.

**Upgrade menu:**
- A pipeline-to-forecast or forecast-accuracy sheet, if you have one; it would move R6 from adjacent.
- An example of billing or revenue reconciliation, if you did any at the payments company.
- A link to Quillfield's own careers page, to verify the posting.
- A salary sweep for Bristol, to calibrate the £61,500–£67,000 band.
- Public research on Tamsin Achebe's background, to shape your positioning.

I can run the salary and careers-page checks if you want them.

Want me to draft a `tuesday-dossier.md` so this assessment carries into interview prep?

1. Are you based in Bristol or able to commute there two days a week, and does £61,500 plus share options meet your floor?
2. Did you ever contribute to or check a revenue forecast, even as a pipeline input or an accuracy review?
3. At your payments company, did you query or reconcile revenue or invoice data, and who owned it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.