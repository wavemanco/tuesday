**Yes, worth applying, on three conditions.** Status: `conditional_go`.

**Fit ledger**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (base $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration, Airflow or similar), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery, named as the warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 — a credible transfer from Snowflake, its limit named. R9 and R10 — unanswered; the questions are in the closing block.

**Opportunity ledger.** RR1 caps the decision: the employer isn't independently established. RR2 (scope spans the whole data platform) and RR4 (equity unstated) are open. RR3 (the stated base band sits near the market median) runs the other way.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** (1) RR1 closes with an independent source for the company; (2) R1 and R2 are confirmed as met by your location, work authorization and pay floor; (3) R8 is framed as a Snowflake-to-BigQuery transfer, with the limit named, and R9 and R10 come back as things you have owned.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; founded 2016, 264 employees, Series C ($52M, Feb 2026) per its About page | `[grounded]` the company's own About page; funding and headcount not independently checked |
| Scope | Ingestion, warehouse, data contracts, orchestration and quality in one role | `[inferred]` from the JD's responsibilities |
| Seniority | "Senior" fits 6 years; no direct reports stated | `[generic]` Datawright typical range of 5–8 years |
| Market calibration | Base $148k–$166k against a Series B–D senior median of $151k (IQR $139k–$163.5k); the top of the range sits just above the IQR | `[generic]` Datawright report you pasted; `[grounded]` the JD's range |
| Unknowns | Equity amount; who else owns these pipelines; hiring manager (not named) | — |
| Contradictions | None between the JD you pasted and the live careers page | `[grounded]` careers page fetched |

**Evidence map** (confidence is capped at `medium` for your background, since nothing is inspected yet)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location or authorization stated | `[grounded]` JD | Q1 |
| R2 | Base $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor stated | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; a length of experience, not a gate | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, stated | `[grounded]` your intake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated | `[grounded]` your intake | none |
| R8 | BigQuery (named as the warehouse) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery itself is not in your background | `[inferred]` adjacency from Snowflake work | G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not stated; Airflow work suggests it may be yours, not established | `[inferred]` | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not stated | `[grounded]` silence in intake | Q3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt and warehouse work; no BigQuery | The most likely technical objection | Any dbt model or query tuning you did on Snowflake that you could map to BigQuery's partitioning, cost and SQL differences | A sanitized model or a short BigQuery sandbox project | `[inferred]` bridge from Snowflake work; `[generic]` that this is the likeliest objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from independent sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Company's own pages are the only sources found; my search for the company returned nothing | `[generic]` pattern for companies of this size, not a claim about this one | Which legal entity employs this role, and where can I see its funding and headcount? | unresolved |
| RR2 | Scope spans the whole data platform | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | Could be a one-person platform role, wider than the usual one-domain senior scope | `[inferred]` from the JD's responsibilities against `[generic]` scope norm | Who else owns these pipelines, and which of these areas would be yours alone? | unresolved |
| RR3 | Base band stated | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Range sits near the market median, a transparent signal | `[grounded]` JD; `[generic]` band from Datawright | Is this base range final for the level you would hire at? | noted |
| RR4 | Equity amount unstated | unknown | — | "plus equity" | Equity value cannot be compared | `[grounded]` JD | What is the equity grant size, vesting schedule and valuation basis? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the employing entity before spending application time | see RR1 | `[generic]` pattern | pending your approval |
| A2 | Ask RR1–RR4 verbatim on the first recruiter call | the register doubles as interview prep | `[grounded]` register | pending your approval |
| A3 | Frame BigQuery as a transfer from Snowflake, with the limit named | see R8 | `[inferred]` | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver": no results. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): the posting is live and matches the JD you pasted. No independent source attributed the company, so RR1 stands |
| 2. Role-family sweep | skipped | The Datawright pay report you pasted already fixes the market band in Role reality |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer.** I can save this assessment as `tuesday-dossier.md`, which a later interview-prep pass can read.

**Upgrade menu**

- Your location, work authorization and pay floor → closes R1 and R2, the two gates.
- An example of owning app or CRM ingestion, or a data contract analysts used → moves R9 and R10 off `unclear`.
- A BigQuery sandbox or a sanitized dBT model on BigQuery → R8 toward `direct`.
- An independent source for the company (press, a funding announcement, a LinkedIn page) → closes RR1.
- A deeper research pass on Pellucid Learning (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

Q1 — R1: Are you authorized to work in the US, and can you work remotely from the US or from Denver?

Q2 — R2: What base-salary floor do you need, and does $148,000–$166,000 plus equity clear it?

Q3 — R9 and R10: Have you owned ingestion from an app or CRM, or defined a data contract that analysts relied on? Name what you built, who consumed it, and what broke.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.