## Decision: `conditional_go`

You're not wasting your time, but this is not a straight go. Your client-side work matches the job well. Your titled product-management years don't match at all, and that is the line a screen will check first.

- **Fit ledger** (rows from the evidence map below):
  - `must_have`: direct: R2; adjacent: R1 (roadmap ownership), R3 (specs and delivery), R4a (3+ years adjacent); absent: R4b (3+ years titled PM)
  - `important`: direct: R6 (technical fluency), R7 (stakeholder management); adjacent: R5 (shipped API products), R8 (launch coordination); unclear: R9 (adoption metrics), R10 (agile delivery)
  - R4b is the titled-years gap. R1, R3 and R4a are credible bridges with their limits named. R9 and R10 are unsettled by anything in the material.
- **Opportunity ledger:** RR3 (`positive_signal`) reads the scope as concrete. RR1 and RR2 (both `severity: medium`) are the open risks: the employer is unverified, and the titled-years line may be applied literally. RR4 is an unknown about decision rights.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** For `conditional_go` to hold, three things have to come back as you'd want. RR1 clears: the role is confirmed on Quartzline's own careers page. G1 turns up a product decision you made, which would move R1 toward `adjacent` at `medium`. G2 turns up a metric you defined or tracked, which would move R9 off `unclear`. If G1 and G2 both come back empty, this title is a stretch, not a go.

## Role reality

- **Role:** Product Manager, Platform APIs, at Quartzline (B2B logistics-tech, about 150 people, Series B). `[grounded]` from your description; not verified.
- **Stated responsibilities:** own the partner-facing API roadmap; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support. `[grounded]` from the JD.
- **Gates in the posting as pasted:** none. The JD labels only the 3+ years line as a must-have, so I tiered the rest myself. The years line is a term-free experience requirement, not a legal gate, so it keeps its must-have tier and is graded on fit.
- **Compensation:** not stated in the posting as pasted. The band is unknown, and no market search has been run.
- **Unknowns:** decision rights, budget, whether a PM already exists, and who the hiring manager is.
- **Contradictions:** none found in what you gave me.

## Evidence map

Every confidence here is `low`. Your resume is the only source, and unprobed resume claims are leads, not proof. Each row names what would raise it.

| # | Priority | Requirement | Fit | Gap | Confidence | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | must_have | Own the roadmap for a partner-facing API platform | adjacent | transferability | low | Quarterly roadmap-input sessions collected client feedback for product. The CV does not show you setting priorities or deciding scope. | `[grounded]` CV line | G1 |
| R2 | must_have | Run discovery with integration partners | direct | presentation | low | Scoping workshops and requirements documents across 30+ integrations are discovery in substance, but the CV frames them as implementation. | `[grounded]` CV; `[inferred]` that a product reader would see discovery here | Confirm two workshops and what product changed because of them |
| R3 | must_have | Write specs and drive delivery with two engineering squads | adjacent | transferability | low | You wrote requirements documents and coordinated engineers on custom builds. Nothing shows sprint-level ownership of a shared backlog. | `[grounded]` CV | Name one spec and the delivery it drove |
| R4a | must_have | 3+ years of product-adjacent experience | adjacent | transferability | low | Seven years as solutions engineer and implementation lead. These are adjacent years, not titled PM years. | `[grounded]` CV | Covered by R1 to R3 |
| R4b | must_have | 3+ years of titled product management | absent | transferability | none | No PM title held. R4a is the bridge, and its limits are named. This is a literal-screen risk (RR2), not a legal gate. | `[grounded]` CV | RR2 |
| R5 | important | Shipped API or platform products | adjacent | transferability | low | You delivered 30+ REST integrations on another vendor's API, from the consumer side. You did not ship a product. | `[grounded]` CV | Artifact: a release note or launch plan for any API you shipped to clients |
| R6 | important | Technical fluency: reads API docs, discusses schemas | direct | none | low | Postman, SQL and OpenAPI are named, and you wrote integration architecture. | `[grounded]` CV (self-reported) | An OpenAPI or architecture doc you can show |
| R7 | important | Stakeholder management across engineering, sales and customers | direct | none | low | Coordinated engineers, client engineers and PMs, plus quarterly client sessions. Sales is not in the CV; see R8. | `[grounded]` CV | none |
| R8 | important | Coordinate launches with sales and support | adjacent | transferability | low | You led UAT and go-live end to end. Sales and support coordination is not stated. | `[grounded]` CV | Name one launch and who you worked with in sales and support |
| R9 | important | Define and track adoption metrics | unclear | discovery | none | The CV is silent. SQL is listed, but no metric is defined or tracked. | `[inferred]` from the gap in the CV | G2 |
| R10 | important | Agile delivery experience | unclear | discovery | none | Delivery coordination is in the CV. The methodology is not. | `[grounded]` CV silence | Name the cadence and tooling on your last build |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Roadmap authority (R1) | discovery | Input collection is in the CV. Decisions are not. | A decision you made that changed what a product team built next: a scope cut, a priority, a deprecation, a new endpoint | `[grounded]` CV silence on decisions |
| G2 | Adoption metrics (R9) | discovery | SQL is listed, but no metric is named | Any adoption number you defined, tracked, or reported, and its source | `[inferred]` that this row resolves R9 |
| G3 | Titled PM years (R4b) | transferability | No PM title | No closure from the resume. Name the bridge in the cover note and let RR2 get answered | `[grounded]` CV |
| G4 | Partner discovery (R2) | presentation | Workshops and requirements work exist, but the CV frames them as implementation | Two workshops, and what changed in the product as a result | `[grounded]` CV framing |
| G5 | Shipped product (R5) | transferability | Delivery of other vendors' APIs | Any product-side launch artifact you touched | `[grounded]` CV |

## Risk register

- **RR1** · `risk_signal` · `severity: medium` · Employer not established from attributable sources. Source: "Quartzline (B2B logistics-tech, ~150 people, Series B)". Hypothesis: `[generic]` pattern for companies of this size, not a claim about this one: the company may be small or new with a thin footprint, or the posting may be stale. Verification question: "Can you point me at this role on your own careers page, and who would I be interviewing with?" Decision rule: verify the posting is live before investing application effort. Status: unresolved.
- **RR2** · `risk_signal` · `severity: medium` · Titled-years must-have may be screened literally. Source: "3+ years product management experience (must-have)". Hypothesis: `[inferred]` from the posting's own must-have label, plus `[generic]` that titled-years lines are often applied as a screen before a conversation. Verification question: "Is the three years of product management applied as written, or does equivalent product-adjacent work count?" Decision rule: apply if adjacent work counts. If it doesn't, expect a literal screen. Status: unresolved.
- **RR3** · `positive_signal` · Concrete scope. Source: "Own the roadmap ... drive delivery with two engineering squads; define and track adoption metrics". Hypothesis: `[inferred]` from the scope language: one platform, two named squads, and defined metrics suggest real authority. Verification question: "Which of the two squads report into this role?" Status: unresolved.
- **RR4** · `unknown` · Decision rights and budget not stated. Source: "own the roadmap". Hypothesis: `[inferred]` from silence on authority: decision rights may sit with a VP above this role. Verification question: "Which scope and funding decisions does this role make itself, and what budget is committed to the platform?" Decision rule: proceed only if authority is concrete and consistent across interviewers. Status: unresolved.

## Application plan

**Positioning (pending your approval):** Lead with the partner side of the API. You spent years inside integrations, collecting what partners needed and bringing it to product. Don't claim product ownership until G1 confirms it. When you reach interviews, mock-interview can drill the titled-years question.

**Resume edits (resume_edits_pending_approval):**

| Current line | Proposed | Source | Audit |
|---|---|---|---|
| "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live." | "Led scoping workshops and requirements documents for 30+ REST API integrations, end to end through UAT and go-live." | Your CV line | Scope kept at 30+ integrations. Your words kept. "Discovery" is not borrowed from the JD. |
| "Ran quarterly roadmap-input sessions collecting client feedback for product." | Keep as written | Your CV line | Do not change to "shaped the roadmap" unless G1 confirms it. |
| "Wrote the internal integration playbook the whole team uses." | Keep as written | Your CV line | Nothing to change. |

## Evidence status

Research tier: L0 — no searches; user links read 0

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Quartzline official site and careers page | unavailable | No search sent in this first pass. It would move RR1; offered in the upgrade menu. |
| 2 | Role-family sweep: PM title and pay for this scope | unavailable | No search sent. It would calibrate RR2 and the titled-years expectation. |
| 3 | Hiring manager's public footprint | n/a | No name given. |

I haven't run a market calibration line, because no research was run.

Keep your résumé and this assessment together: if you want, I can write this to `tuesday-dossier.md` so a later prep run can read it.

## Upgrade menu

- **Non-negotiables** (pay floor, location, schedule, work authorization): unlocks the hard-gate check, which is currently unknown.
- **Live posting link or Quartzline careers page:** unlocks clearing RR1.
- **Research at L1** (up to 5 searches and 2 fetches): checks that Quartzline exists and what the PM title and years norm looks like for this scope. Moves RR1 and RR2.
- **One OpenAPI doc, integration architecture doc, or spec you wrote:** raises R6 and R3 from `low` toward `high`.
- **One launch plan or release note:** raises R5 and R8.

## Questions

G1 — Have you ever made a call that changed what a product team built next: a scope cut, a priority, a deprecation or a new endpoint? What did you own, who else decided, and what happened?

G2 — Did you measure whether integrations or your playbook were adopted (time to go-live, integrations per quarter, client usage)? Who defined those numbers, and where did they come from?

G3 — I have an unconfirmed note that you may have built an internal request-triage tool that support agents adopted. If that's real, what did it do, who used it, and how did you know it worked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.