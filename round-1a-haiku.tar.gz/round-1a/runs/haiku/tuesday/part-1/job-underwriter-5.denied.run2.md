**Yes, with conditions: `conditional_go`.** Apply once two things check out: you can work remote US or from Denver, and $148,000 base clears your floor. Confirm the posting is live on Pellucid's careers page too, since I could not check that here.

## Decision snapshot

- **Fit ledger.**
  - `hard_gate` — unclear: R1, R2
  - `must_have` — direct: R3, R4, R5, R6, R7
  - `important` — adjacent: R8, R10 · unclear: R9, R11

R8 — Snowflake dbt work bridges to BigQuery, with no BigQuery use yet; R10 — dbt tests are the adjacent piece, consumer-facing contracts not yet shown; R9 — source ingestion unanswered; R11 — domain ownership unanswered.

- **Opportunity ledger.** The stated pay band and the Series C funding read as positive (RR5, RR6). The employer is unverified here (RR1), and the equity terms (RR3), the hiring manager (RR2) and the ownership and on-call scope (RR4) are unstated.
- **Hard gates:** none failed (R1 `unclear`, R2 `unclear`); unconfirmed: R1 (remote US or Denver), R2 (base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:**
  - Conditions for `conditional_go`: (1) R1 and R2 check out, and if either fails this becomes `no_go` on that gate; (2) the posting is live on Pellucid's own site (RR1); (3) BigQuery is framed as adjacent, never as used (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, Denver, founded 2016, 264 employees, Series C $52M (Feb 2026) | `[grounded]` About text you pasted; not checked live |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt warehouse on BigQuery, data contracts for analysts | `[grounded]` posting |
| Scope read | One domain's pipelines, with no direct reports named | `[inferred]` from the posting's scope against its silence on team size |
| Market calibration | Stated base $148k–$166k: the low end sits just under the report's $151k median, the midpoint (~$157k) is in the upper half of the $139k–$163.5k interquartile range | `[generic]` band from the Datawright report you pasted; not checked online |
| Working pattern | Remote US or the Denver office | `[grounded]` posting |
| Unknowns | Equity size, vesting and form; hiring manager; team size; on-call expectation; whether ingestion is greenfield or inherited | — |
| Contradictions | None found between the posting and the About text you pasted | `[grounded]` your pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material, so the gate is unsettled | `[grounded]` posting terms | Q1 |
| R2 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | The band is stated; your floor is not | `[grounded]` posting | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, not yet probed | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use for six years; self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of ~180 models on Snowflake, a cloud warehouse | `[grounded]` background; `[inferred]` that Snowflake meets the posting's wording | A repo or sanitized model tree would raise to high |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration, self-reported | `[grounded]` background | A DAG description would raise to high |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` background | A suite summary would raise to high |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake modelling and testing carry over; BigQuery never used, so the limit is the platform | `[grounded]` Snowflake claim; `[generic]` that dbt models port across warehouses | G1 |
| R9 | Ingestion from app and CRM sources | important | unclear | none | discovery | The material does not say you built source ingestion | `[grounded]` silence in your background | Q3 |
| R10 | Data contracts analysts depend on | important | adjacent | low | transferability | GE and dbt tests are the enforcement tools; no consumer-facing contract is shown | `[inferred]` from R7 and the dbt work | G3 |
| R11 | Owns one domain's reporting pipelines | important | unclear | low | discovery | Ownership of a domain is not stated | `[inferred]` from the scope read | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake dbt work; no BigQuery | The posting names BigQuery; the bridge narrows the objection | Any warehouse migration, dbt adapter work, or cost tuning on a cloud warehouse | A small BigQuery dbt project on public data | `[generic]` that dbt ports across warehouses |
| G2 | Source ingestion (R9) | discovery | Nothing on app or CRM ingestion | Named in the first responsibility | Pipelines from a production database, SaaS APIs or CDC | A pipeline diagram or DAG | `[grounded]` silence |
| G3 | Data contracts (R10) | transferability | Tests exist; no analyst-facing agreement | Named as a responsibility | Agreed schemas, breaking-change rules, dataset ownership notes | A contract or schema-change note | `[inferred]` |
| G4 | Domain ownership (R11) | discovery | Ownership not stated | Sets the scope read | Sole ownership of a reporting domain's models and their SLAs | Ownership statement or roadmap | `[inferred]` |
| G5 | Location (R1) | hard_gate | Your location not given | Could fail the gate outright | None; the gate is met or not | None | `[grounded]` posting |
| G6 | Pay floor (R2) | hard_gate | Your floor not given | Could fail the gate outright | None; the gate is met or not | None | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from here | risk_signal | medium | "Series C ($52M, February 2026)" | The posting may be stale or aggregated; this is a pattern, not a finding about Pellucid | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | No hiring manager named | unknown | — | the posting names no manager | Common for this title; alone it tells you little | `[generic]` posting pattern | Who is the hiring manager for this role? | unresolved |
| RR3 | Equity unstated | unknown | — | "plus equity" | Total pay is unknown until the grant is described | `[inferred]` from the posting's silence | What is the grant's size, vesting schedule, and form (options or RSUs)? | unresolved |
| RR4 | Ownership and on-call unstated | unknown | — | "Build and run the pipelines" | "Run" may carry on-call duty, and team size is unstated | `[inferred]` from "run" against the silence on team and rota | How many engineers own these pipelines, and what does "run" mean for on-call? | unresolved |
| RR5 | Stated pay within market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band sits around the pasted median and inside its interquartile range | `[grounded]` posting; `[generic]` band from the pasted report | Is $148,000–$166,000 the full base figure, and where in the band are offers usually set? | noted |
| RR6 | Recent Series C funding | positive_signal | — | "Series C ($52M, February 2026)" | Recent funding often supports hiring, though it does not show what this team is for | `[generic]` pattern for Series C companies; `[grounded]` About text | What share of this year's hiring plan goes to the reporting team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the posting on pellucidlearning.com and confirm it is live and matches the text you pasted | RR1 | `[grounded]` URL you gave; not checked here | pending your approval |
| A2 | Confirm location and your pay floor before applying | R1, R2 | `[grounded]` posting | pending your approval |
| A3 | Lead the CV with the Snowflake dbt build, Airflow and the Great Expectations suite, in the same verbs you used ("built"); do not list BigQuery | R5, R6, R7, R8 | `[grounded]` your background | resume_edits_pending_approval |
| A4 | Build a small dbt project on BigQuery with public data and keep it as a work sample | R8 | `[generic]` that dbt ports across warehouses | pending your approval |
| A5 | Prepare a plain account of what you built versus what your team owned, for ingestion and domain ownership | R9, R11 | `[generic]` that interviewers ask who owned what | pending your approval |

For the CV wording itself, resume-tailor is the module for that work.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches and one fetch of pellucidlearning.com/careers/senior-data-engineer were refused by permission. Would have checked whether the posting is live and consistent with the About text (RR1, contradictions row) |
| 2. Role-family sweep | unavailable | A search to check the Datawright report was refused. Would have checked the market band (RR5, market calibration) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Web access was refused in this session, so targets 1 and 2 are unchecked. The pasted material is used as given and not treated as verified.

## Dossier offer

If you want it, I can write this up as `tuesday-dossier.md`, so a later mock-interview run can start from it.

## Upgrade menu

- Web access granted: re-run targets 1 and 2 (up to 5 searches and 2 fetches) to check the posting is live and where the pay band comes from.
- Your location and pay floor → R1 and R2 close, and the decision moves to `go` or `no_go` on the gates.
- A repo or sanitized model tree → R5 to `high`; a Great Expectations suite summary → R7 to `high`.
- A BigQuery work sample → narrows R8's limit.
- The hiring manager's name → RR2 closes and the scope read (R11) sharpens.

## Questions

Q1 (R1): Are you based in the US, and can you work remote or from the Denver office?

Q2 (R2): Is $148,000 base above your floor?

Q3 (R9): Have you built ingestion from an application database or a CRM's API, and with which tools?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Resume edits belong with resume-tailor.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.