## Decision snapshot

**Yes, apply, on three conditions. Status: `conditional_go`.** Your stack matches the posting's must-haves. BigQuery is the one real gap. Whether you clear the location and pay gates is unknown, because I don't have those facts.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Based in the US or Denver; authorized to work in the US), R2 (Base pay meets your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3, R4, R5, R6, R7 are the core stack on your own account, all direct; R8 is BigQuery, adjacent with its limit named; R9 and R10 are not yet in your material.

**Opportunity ledger.** Positive: RR4, the stated pay. Unknowns: RR2 (reporting line and team size) and RR3 (whether BigQuery is the warehouse in place or one the team is moving to). Open: RR1, the employer check, which I could not run.

- **Hard gates:** none failed (R1 and R2 both `unclear`); unconfirmed: R1 (Based in the US or Denver; authorized to work in the US), R2 (Base pay meets your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:**
  - R1 holds: you are US-based and can work for a US employer without sponsorship. If not, this becomes `no_go` on the location gate.
  - R2 holds: your base floor is at or under the posted $166,000 top. If it is above, this becomes `no_go` on pay.
  - RR1 clears: the role is live on Pellucid's own careers page, confirmed through the recruiter's company email domain.
  - R8 goes in as adjacent, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the about-page text you pasted; not checked here |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled warehouse on BigQuery, data contracts analysts rely on | `[grounded]` JD |
| Pay | $148,000–$166,000 base, plus equity | `[grounded]` JD |
| Location | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain's pipelines with no reports named: the usual scope for this title | `[generic]` role-family pattern in the pay report you pasted |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500, senior typically 5–8 years. The posted midpoint ($157,000) sits above the median and inside the IQR; the posted top is $2,500 above the IQR top | `[generic]`: the report as you pasted it, not verified, since the search to check it was refused |
| Unknowns | Hiring manager (none named), reporting line, data-team size, whether BigQuery is current or being migrated to, ingestion sources | — |
| Contradictions | None between the JD and the about-page text you pasted | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in US (remote) or Denver; authorized to work in the US (posting silent on sponsorship) | hard_gate | unclear | none | hard_gate | Location is a posted term; your location and authorization are not in the material, so the gate is not settled | `[grounded]` JD location line | Q1 |
| R2 | Base pay meets your floor | hard_gate | unclear | none | hard_gate | Posted $148,000–$166,000; your floor was not given | `[grounded]` JD; `[generic]` band in role reality | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in your message. Prose only, so medium is the ceiling until a probe | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily; self-reported | `[grounded]` your statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models you built; Snowflake is a cloud warehouse | `[grounded]` your statement | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration; self-reported | `[grounded]` your statement | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your statement | none |
| R8 | dbt-modelled warehouse in BigQuery (JD responsibilities) | important | adjacent | low | transferability | You have never used BigQuery. dbt and a cloud warehouse carry over; BigQuery's SQL dialect, partitioning and cost model, and GCP access are not exercised. Low, because the bridge is inferred from Snowflake work | `[grounded]` your statement; `[inferred]` adjacency from your Snowflake dbt work | G1 |
| R9 | Ingestion from our app and CRM (JD responsibilities) | important | unclear | low | discovery | Pipeline work is in your history, but source systems are not named | `[grounded]` JD; `[inferred]` from your general DE work | G2 |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | Great Expectations checks are adjacent to contracts, but no producer–consumer agreements appear in your material | `[grounded]` JD; `[inferred]` adjacency from GE work | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | No BigQuery in your material; dbt and cloud-warehouse work on Snowflake | Named in the JD's own responsibilities. A bridge with its limit stated is the honest version | dbt model work on Snowflake; any SQL-dialect or warehouse-tuning work you did | A small BigQuery sandbox or dbt-bigquery project, even a few models | `[inferred]` bridge from Snowflake dbt work; `[generic]` that BigQuery-specific depth is a common probe |
| G2 | Ingestion from app and CRM (R9) | discovery | Pipeline work is in the material; source systems are not named | Ingestion is the first responsibility in the JD | App-event or SaaS/CRM API pipelines you built or ran | A pipeline diagram or source list | `[grounded]` JD |
| G3 | Data contracts (R10) | discovery | Quality checks are in the material; consumer agreements are not | Contracts are a stated deliverable, not a nice-to-have | Schema agreements, owned datasets with named analyst consumers, published check results | A contract or schema spec you wrote | `[grounded]` JD; `[inferred]` from GE work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | low | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | Not checked here: both searches were refused, so the company details and the live posting rest on your paste. The posting could be stale, or the description may not match the live listing | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at the live role on your careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Reporting line and team unnamed | unknown | — | "The posting names no hiring manager." | The data team may be small, so the hire could own the pipelines alone, or sit under a lead; the posting does not say | `[inferred]` from the posting's silence | "Who would this role report to, and how many people are on the data team today?" | unresolved |
| RR3 | Warehouse direction unstated | unknown | — | "a dbt-modelled warehouse in BigQuery" | BigQuery may be in place already or being moved to; the answer changes how much the role leans on BigQuery-specific depth | `[inferred]` from the posting's wording | "Is BigQuery the warehouse in place today, or is the team moving to it?" | unresolved |
| RR4 | Stated base pay range | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is disclosed and sits inside the market band, so the posting is transparent about pay | `[grounded]` JD; `[generic]` band from the pasted report | "Is this range the budgeted band for this level, and how is equity structured?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before applying, open the role from Pellucid's careers page and confirm it is live. Ask the recruiter to confirm from the company's own email domain | RR1 | `[grounded]` standing entry | Your action; no approval needed |
| P2 | Keep the Snowflake dbt build (about 180 models) as the lead bullet, naming Snowflake. Add no BigQuery line | R5, R8 | `[grounded]` your statement | `resume_edits_pending_approval` |
| P3 | If you write outreach or a cover note, say it plainly: "I haven't used BigQuery; my dbt and cloud-warehouse work is on Snowflake." Use no other framing | R8 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on what you wrote in your message and the two pasted texts.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for the company's description and the posting were refused. The employer, the Series C figures and the live posting are unchecked here. Would have moved RR1 and the condition that the posting is live |
| 2. Role-family sweep | unavailable | One search to check the Datawright report against its public source was refused. The market band rests on the report as you pasted it, labelled `[generic]`. Would have moved the market calibration and the R2 pay reasoning |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- A BigQuery sandbox or a small dbt-bigquery project, even a few models → R8 moves from `low` toward `medium`, and G1 closes.
- A sanitized dbt project structure, or the Great Expectations suite config → R3–R7 move from `medium` to `high`, since each gains an inspectable artifact.
- The list of source systems you ingested from, and any consumer agreements you wrote → R9 and R10 resolve from `unclear`.
- The recruiter's answers on reporting line, team size and warehouse direction → RR2 and RR3 close.
- Your location, authorization and base floor → R1 and R2 close, and the decision either firms up to `go` or moves to `no_go`.
- The live posting link, or the recruiter's company email domain → RR1 closes.
- The two refused searches can run again if you allow search. They would confirm the company and the pay report.

If you want it, I can save this as `tuesday-dossier.md`, so later modules can read the same map.

1. R1 — Are you based in the US, or within reach of Denver, and are you authorized to work for a US employer without sponsorship?
2. R2 — What is your base-salary floor?
3. R8 — Have you touched BigQuery at all: a sandbox, a course project, a dbt-bigquery adapter, or a pipeline someone else ran? What did you do there?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.