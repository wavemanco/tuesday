**Hold for one question, then probably yes.** Status: `hold_pending_answers`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (work location: fully remote UK, or Leeds four days a week)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R7 · adjacent: R9 (pet-insurance product knowledge)
- `preferred`: direct: R8 (insurance experience)

R2, R3, R4 and R5 are the four must-haves, each direct on your record. R4 is GLM work on motor, not pet. R9 is the one real gap: motor pricing bridges to pet, and the limit is that no pet claims behaviour has been exercised.

**Opportunity ledger.** The posting contradicts itself on location: the JD says fully remote, and the careers page says a Leeds office four days a week (RR1). RR2 (thin public footprint), RR3 (line management not stated) and RR4 (salary not stated) are unknowns, not warnings. RR5 is a positive: the scope is clear and the role reports to the Director of Pricing.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK vs Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** RR1 (`severity: high`)
- **What would change this:** a written recruiter answer that the role is fully remote UK moves R1 to `direct`, and the status can go to `go` once RR2–RR4 are asked. A written answer of Leeds four days a week that you cannot meet makes R1 `hard_gate_fail`, and the status becomes `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` JD; live careers page |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | Conflict: "Fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median £58,400, IQR £52,100–£64,900 (Pricewell 2026, n=612) | `[generic]` role-family sweep; not this employer's offer |
| Stated salary | None found in the JD or the careers page | `[grounded]` absence |
| Unknowns | Team size, company stage, line management, age of the pet product, contract type | — |
| Contradictions | Location (above) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | No candidate claim; your location and constraints were not given; the sources conflict | `[grounded]` both sources | A1; Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics, last 2 as senior analyst; self-report, not inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; self-report | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for the young-driver motor book | `[grounded]` your background | A2 |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | important | direct | medium | none | 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R7 | Build and monitor rating models | important | direct | medium | none | Build and maintenance confirmed; the monitoring cadence is not yet stated, so expect a probe | `[grounded]` your background | A4 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R9 | Pet-insurance product pricing (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over; pet claims behaviour and cover structure are not exercised. Pet-specific dynamics are `[generic]` | `[inferred]` adjacency from motor pricing | G1; A3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R9, important) | transferability | Motor pricing and GLM work; no pet work | R9 is the only important row below `direct` | Any non-motor pricing (home, health, travel, accident); any model on a long-tail claim profile | A sanitized rating-factor summary from any non-motor product, or a note on how frequency and severity modelling would differ for pet | `[inferred]` adjacency from motor pricing; `[generic]` that pet claim patterns differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms conflict | risk_signal | high | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The careers page may be stale, or the role may be office-based despite the JD | `[inferred]` from the two sources disagreeing | "Is this role fully remote in the UK, or is it a Leeds office role four days a week?" | unresolved |
| RR2 | Thin public footprint for the employer | unknown | — | First search returned no results; only the careers page and one profile found | Company stage and team size are not established from public sources | `[generic]` pattern for smaller insurtechs; not a claim about this one | "How large is the pricing team, and how long has the pet product been live?" | unresolved |
| RR3 | Line management not stated | unknown | — | JD describes owning analytics, with no reporting-line duties | The role may be individual-contributor, or may carry people duties | `[inferred]` from the JD's silence | "Does this role line-manage anyone, now or in the first year?" | unresolved |
| RR4 | Salary not stated | unknown | — | No figure in the JD or the careers page | The posting may withhold pay, or the figure may sit outside the band | `[generic]` band from the Pricewell survey, against the posting's silence | "What is the base salary range for this role?" | unresolved |
| RR5 | Clear scope and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing." | Scope is defined, with a clear line to pricing leadership | `[grounded]` careers page | "Which rate and test decisions does this role make itself?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter in writing whether the role is fully remote UK or Leeds four days a week, before applying | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | CV: lead with the young-driver GLM build and maintenance and the 14 price tests, labelled as motor insurance pricing | R4, R6 | `[grounded]` your background | pending your approval |
| A3 | Frame the pet gap as adjacent: motor pricing and GLM work carry over; pet claims behaviour is not yet exercised | R9 | `[inferred]` from G1 | pending your approval |
| A4 | Interview positioning: the hiring manager has a public talk on monitoring rating models in small books (2025 forum, public profile). Your maintained GLM is a true point of connection. Claim no view on her topic that you have not stated | R7 | `[grounded]` public profile | pending your approval |
| A5 | Ask RR2–RR4 of the employer verbatim in the first conversation | RR2, RR3, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst jobs", which returned brindlemoor.co.uk/careers/senior-pricing-analyst. Fetched that page: the role is live, Leeds office four days a week, reports to the Director of Pricing. Moved the contradiction in R1 and RR1; company size and stage not established (RR2) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary GLM pricing", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration line and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned a public professional profile (linkedin.example/in/odile-varga): Director of Pricing at Brindlemoor; previously head of pricing analytics at Calloway Re for six years; a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books. Used roles and the talk only. Moved A4 |

## Dossier offer

If useful, I can write this up as `tuesday-dossier.md`, so the map and register carry into any later interview prep.

## Upgrade menu

- The recruiter's written answer on location → R1 and RR1 close; the status moves to `go` or `no_go`.
- The base salary → RR4 closes against the band above.
- The line-management answer → RR3 closes.
- A non-motor pricing example, or a sanitized rating-factor summary or price-test readout → R9 narrows; R4 and R6 can move to `high`.
- Your constraints (pay floor, contract type, start date) → the checks against them run, and the "candidate constraints not given" flag goes.
- Deeper research on Brindlemoor (funding, leadership, news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**Q1 (R1):** Are you UK-based, and could you work from a Leeds office four days a week, or is a remote-only role what you need? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q2 (constraints):** Do you have any non-negotiables for this role, such as a pay floor, a contract type or a start date, that I should check against it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.