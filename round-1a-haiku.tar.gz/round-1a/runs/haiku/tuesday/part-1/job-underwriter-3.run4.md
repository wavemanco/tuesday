**No. Two hard constraints fail on the posting's own terms, so I'd not apply.** R1 (on-site in Austin five days a week, no exceptions) and R2 (base $70–85k against your $150k floor) are both `hard_gate_fail` · `no_go`.

- **Fit ledger**
  - `hard_gate` — failed: R1, R2
  - `must_have` — direct: R3, R4, R5, R6 · unclear: R7, R8, R9, R10
  - `important` — adjacent: R11
- R3–R6 are your strongest match: 9 years, the $8M→$40M ARR scale-up, and paid and lifecycle ownership. R7–R10 (SEO/content, brand and PR, partnerships, sales ops) are not in what you've told me, so they're unknown, not missing. R11 is adjacent because your experience is B2C subscription and the posting doesn't say who the e-commerce buyer is.
- **Opportunity ledger.** The posting is internally strained: a "team of one" is asked to cover seven functions, with an always-on expectation and no success metrics yet (RR1–RR3). Against that, the first-year scope is clear and profitability is stated (RR6). Nothing I could check is confirmed; the employer is not established (RR5).
- **Hard gates:** failed: R1 (on-site Austin five days, no exceptions), R2 (base $70–85k, below the $150k floor)
- **Severe red flags:** none found
- **What would change this:** only the posting's own terms changing. R1 says "no exceptions", so the realistic answer is no.

## Research tier

Research tier: L1 — searches 3 of 5, fetches 0 of 2

The three searches were refused (permission not granted), so no outside facts were checked.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two Novaline searches were refused. The employer is unverified, so RR5 stays open. |
| 2. Role-family sweep | unavailable | A salary search was refused. I have no market band for this title, and I won't supply one from memory. R2's comparison is against your floor only. |
| 3. Hiring manager's public footprint | n/a | No name given. |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, 5 days/week | hard_gate | hard_gate_fail | high | hard_gate | Your remote-only constraint is specific and yours; the posting says "no exceptions" | `[grounded]` posting; your stated constraint | Surfaced in snapshot; not resolvable by wording |
| R2 | Base $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Your $150k floor is specific and yours; the posting's own band sits well below it | `[grounded]` posting; your stated floor | Surfaced in snapshot |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Stated in your intake; no CV inspected yet | `[grounded]` your intake prose | Send CV to verify |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned, per your intake | `[grounded]` your intake prose | Verify with CV |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned, Braze named | `[grounded]` your intake prose | Verify with CV |
| R6 | Revenue growth, budget-owning | must_have | direct | medium | none | $8M→$40M ARR over three years with a budget you controlled | `[grounded]` your intake prose | Verify with CV |
| R7 | SEO/content | must_have | unclear | none | discovery | Not mentioned | `[grounded]` absence in your intake | Ask whether you've owned it |
| R8 | Brand and PR | must_have | unclear | none | discovery | Not mentioned | `[grounded]` absence in your intake | Ask whether you've owned it |
| R9 | Partnerships | must_have | unclear | none | discovery | Not mentioned | `[grounded]` absence in your intake | Ask whether you've owned it |
| R10 | Sales ops | must_have | unclear | none | discovery | Not mentioned | `[grounded]` absence in your intake | Ask whether you've owned it |
| R11 | E-commerce enablement | important | adjacent | low | transferability | B2C subscription background; the posting's buyer isn't stated, so the bridge's limit is unknown | `[inferred]` from your background against the posting | Confirm who the customer is |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Work hours may run past the posting's stated terms | `[inferred]` from the posting's own language | What does a typical week look like, and how often has the team worked weekends this year? | unresolved |
| RR2 | Responsibility without resources | risk_signal | medium | "a team of one to start … don't need a bench" | Seven functions may land on one person with no budget | `[inferred]` from scope against team size | What budget and headcount are committed for year one? | unresolved |
| RR3 | Pay below the stated scope | risk_signal | medium | "$70–85k base" | Scope and pay may not match; the market band wasn't checked (R2 covers the gate) | `[inferred]` posting's band against its scope; no market band checked | How was the base set for this scope? | unresolved |
| RR4 | Success metrics undefined | risk_signal | low | "success metrics will evolve as we learn" | Accountability may be set before its measures are | `[inferred]` from the posting | What three numbers define success at 6 and 12 months? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A)" | `[generic]` pattern for companies of this size, not a claim about this one | `[generic]` | Can you point me at the role on your own careers site, and who would I interview with? | unresolved |
| RR6 | Profitable since day one | positive_signal | — | "profitable since day one" | A stated claim, unverified | `[grounded]` posting claim | What is current runway and revenue trend? | noted |

## Application plan

Nothing to propose. With R1 and R2 failing, applying wouldn't change the outcome.

## Evidence status

Verified: R1 and R2 (your own stated constraints, confirmed in this conversation). Everything else in the map is intake prose, not verified.

## Upgrade menu

- **Your CV** → verifies R3–R6 and may move them to `high`.
- **Any SEO, brand, PR, partnerships or sales-ops work** → resolves R7–R10 from `unclear`.
- **Live posting link or the company's careers page** → settles RR5.
- **Enabling search** (WebSearch permission) → runs the L1 employer check and market band.

I have no questions for you: nothing you could answer would change the status, since both gates are already failed.

Two things I'd flag: I haven't checked whether Novaline exists, and I haven't checked the market band for this title, so treat RR3 as unverified.

*Dossier offer:* I can write this up as a `tuesday-dossier.md` file for your records, if you want it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.