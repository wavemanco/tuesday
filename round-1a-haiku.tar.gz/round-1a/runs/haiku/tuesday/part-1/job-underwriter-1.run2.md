**Yes, apply, on conditions: `conditional_go`.** On the core analytics requirements you're a direct fit. The gaps are clinician work, mentoring, and healthcare data. I could not verify the employer from here, because web search was refused permission in this session.

**Fit ledger** (candidate side; the requirement IDs are in the evidence map below)

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6, R7a · unclear: R7b
- `important` — unclear: R8
- `preferred` — adjacent: R9

R6 — governed dashboards and a metrics memo, but no claim of owning metric definitions; R7b — no clinician work in what you shared; R8 — no mentoring in what you shared; R9 — the consent-state work carries over, HIPAA does not.

**Opportunity ledger.** Unknown: the employer is unverified (RR1) and no compensation appears in the posting text (RR2). The posting names concrete deliverables, which is a positive signal (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm the posting is live on Harborlight's own careers site and the employer is as described (RR1); (2) get the compensation range (RR2); (3) frame healthcare as consent and PII work under GDPR/CCPA, not as health-data experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` posting text you shared; not verified |
| Mandate | Own product analytics for the care-navigation app | `[grounded]` posting |
| Scope | Metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two junior analysts | `[grounded]` posting |
| Scope read | Senior individual-contributor role with mentoring duties | `[inferred]` from the mentoring line |
| Market calibration | Not run; the role-family search was refused | — |
| Unknowns | Compensation; employer verification; whether the Looker instance already exists | — |
| Contradictions | None found in the text you shared | — |

## Evidence map

Your background is self-report, so the confidence ceiling is `medium` until you have inspectable proof.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, in your own words | `[grounded]` your stated history | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; "expert" is not yet shown by an artifact | `[grounded]` your stated history | Offer: one anonymized complex query as a work sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year; the 11% lift is a claim until a readout exists | `[grounded]` your stated history | Offer: the pricing test readout, sanitized |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch; 40+ governed dashboards | `[grounded]` your stated history | none |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec memo; presents monthly to VP Product | `[grounded]` your stated history | none |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards are close work; you have not said you owned canonical metric definitions | `[inferred]` adjacency from the dashboard work | G1 |
| R7a | Partner with product managers | must_have | adjacent | medium | transferability | Presenting to VP Product is adjacent; a PM partnership is not stated | `[inferred]` from the VP Product presentation | Covered by the G2 question |
| R7b | Partner with clinicians | must_have | unclear | none | discovery | No clinician work in your material | `[grounded]` silence | G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring in your material | `[grounded]` silence | G3 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consent-state model under GDPR/CCPA is real and specific; no PHI or HIPAA context | `[grounded]` consent model; `[inferred]` adjacency | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | transferability | Governed dashboards and a metrics memo; no statement of owning canonical definitions | Decides whether R6 can reach `direct` | Settling a KPI definition across teams; owning certified datasets | A metric dictionary or dashboard certification doc | `[grounded]` your history; `[inferred]` adjacency |
| G2 | Clinician partnership (R7b, must_have) | discovery | No clinical stakeholders in your material | The posting names clinicians as partners | Working with clinical ops or care coordinators on definitions or launches | A PRD or readout co-written with a clinical stakeholder | `[grounded]` silence; `[generic]` that care-navigation roles lean on clinical input |
| G3 | Mentoring (R8, important) | discovery | No mentoring mentioned | Two junior analysts report into the role | Reviewing analysts' SQL, onboarding a new analyst | A review checklist or onboarding plan you used | `[grounded]` silence |
| G4 | Healthcare data (R9, preferred) | transferability | Consent and PII work under GDPR/CCPA; no health data | Adjacent only. Limit: no PHI or HIPAA controls exercised | The consent model's handling of sensitive fields | A HIPAA course, or a healthcare data project | `[inferred]` bridge; `[generic]` that HIPAA differs from GDPR in scope |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified from here | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The lookups were refused, not failed; nothing here says the employer is fake or real | `[grounded]` the refused calls in the research tier line | Which team would this role sit in, and who would I interview with? | unresolved |
| RR2 | Compensation absent from the posting text | unknown | — | No pay line in the posting text | Pay may be withheld, or sit below the band you expect | `[grounded]` absence in the text | What is the base range for this role? | unresolved |
| RR3 | Concrete deliverables named | positive_signal | — | "define and maintain metrics layer; design and analyze A/B tests; build self-serve dashboards in Looker" | Scope is defined and success is measurable | `[grounded]` posting | Which of these is the first-year priority? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Verify the live posting on Harborlight's careers site before investing effort | RR1 | `[grounded]` RR1 | Your next step |
| P2 | Lead the CV with the experiment program and the Looker build, in your own words | R3, R4 | `[grounded]` your history | resume_edits_pending_approval |
| P3 | Describe healthcare work as consent and PII under GDPR/CCPA, never as health-data experience | R9 | `[grounded]` your history | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent and both were refused. Would have confirmed the employer exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | One search was sent and refused. Would have set the market band for this title and seniority (RR2) |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- Permission to use web search: verifies the employer (RR1), sets the salary band (RR2), and lets me retry the three refused calls.
- The live posting link: confirms the posting text and its stated scope.
- A metric dictionary or dashboard certification doc: moves R6 toward `direct`.
- The pricing test readout: moves R3 to `high`.
- If you want this written up, I can produce `tuesday-dossier.md` for later use.

**Questions**

G1 — Have you owned the canonical definitions for a metric, not only built dashboards on top of them? Which metric, who signed off, and what happened?

G2 — Have you worked directly with clinicians or clinical staff on a product's metrics or launch decisions? What did you own?

G3 — Have you mentored or onboarded junior analysts? What did you own, and what did they do afterward?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.