**Yes, worth applying, on conditions: `conditional_go`.** R1, R2, R3, R4 and R5 each land `direct` against the posting's requirements. The gaps are BigQuery (R6), data contracts (R7), and two gates I can't check because you haven't given me your location or pay floor (R8, R9).

- **Fit ledger.**
  - `hard_gate`: unclear: R8 (Remote (US) or Denver office), R9 (Pay $148,000–$166,000 base plus equity)
  - `must_have`: direct: R1 (5+ years data engineering), R2 (Strong SQL and Python), R3 (dbt and a cloud warehouse), R4 (Airflow or similar), R5 (Data quality testing)
  - `important`: adjacent: R6 (BigQuery warehouse, from the posting's description); unclear: R7 (Data contracts analysts depend on)
  - R6 is `adjacent` because Snowflake transfers, but BigQuery itself is unexercised. R4 and R5 are direct, but each is self-reported with no artifact yet.
- **Opportunity ledger.** The employer is verified and the posting matches what you pasted (RR4), and the stated pay sits around the market median (RR5). The unknowns are team scope (RR1), whether the warehouse is on BigQuery today (RR2) and the equity terms (RR3).
- **Hard gates:** none failed; unconfirmed: R8 (Remote (US) or Denver office), R9 (Pay $148,000–$166,000 base); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R8 and R9 are met on your terms; (2) BigQuery exposure is real or you can ramp on it before a screen (R6, G1); (3) the role owns the pipelines and contracts rather than a shared team (RR1, R7).

Stage assumed to be evaluating; you didn't say.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C $52M, Feb 2026 | `[grounded]` about page, search result |
| Role | Build and run reporting pipelines: app and CRM ingestion, dbt warehouse in BigQuery, data contracts | `[grounded]` posting, fetched; matches your paste |
| Scope read | One domain's pipelines with data contracts, no direct reports is the usual remit for this title | `[generic]` Datawright 2026; `[inferred]` from the posting's wording |
| Market calibration | Base median $151,000; IQR $139,000–$163,500. The posting's $148k–$166k sits around the median, with its top just above the IQR | `[generic]` Datawright 2026 (n=2,310); figure `[grounded]` from posting, not an offer |
| Unknowns | Team size, whether you'd be the only pipeline owner, warehouse state, equity terms, hiring manager (none named) | — |
| Contradictions | None found between the posting, careers page and about page | `[grounded]` fetched pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; stated, no artifact. A length requirement, not a gate | `[grounded]` intake | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Used daily; no artifact | `[grounded]` intake | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake; "a cloud warehouse" is met by Snowflake | `[grounded]` intake | none |
| R4 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration; no artifact | `[grounded]` intake | none |
| R5 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; no artifact | `[grounded]` intake | none |
| R6 | BigQuery warehouse (from the posting's description) | important | adjacent | medium | transferability | Snowflake dbt and warehouse work carries over. Limit: BigQuery itself, its cost model and SQL dialect unexercised | `[inferred]` bridge from Snowflake work; `[grounded]` "never used BigQuery" | G1 |
| R7 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your intake; nothing stated | `[grounded]` posting; intake silent | G2 |
| R8 | Location: Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your constraint not given | `[grounded]` posting | Q3 |
| R9 | Pay: $148,000–$166,000 base plus equity | hard_gate | unclear | none | hard_gate | Your pay floor not given | `[grounded]` posting | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | Snowflake dbt and warehouse work; no BigQuery use | The posting names BigQuery in its description, so a screener may probe it | Any BigQuery query or load; a dbt project run on a BigQuery sandbox; schema work on any non-Snowflake warehouse | A sandbox dbt project, a query log, or a migration note | `[inferred]` bridge; `[generic]` that screens probe named platforms |
| G2 | Data contracts (R7, important) | discovery | No mention of contracts with downstream consumers | The posting names contracts as a core deliverable | Schema agreements with analysts, freshness or breaking-change processes, dbt model contracts or tests treated as agreements | A contract doc, a dbt contract YAML, or a sanitized analyst agreement | `[grounded]` posting; intake silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope and authority unknown | unknown | — | "Build and run the pipelines" | You may own pipelines alone, or sit in a shared team | `[inferred]` from the single-role wording | Who else works on these pipelines and contracts, and who would I report to? | unresolved |
| RR2 | Warehouse state | unknown | — | "a dbt-modelled warehouse in BigQuery" | R6's weight depends on whether BigQuery is live or being migrated to | `[inferred]` | Is the warehouse on BigQuery today, and is a migration planned? | unresolved |
| RR3 | Equity terms | unknown | — | "plus equity" | The total comp figure is unknown without grant size and vesting | `[inferred]` | What is the equity grant size, vesting schedule and strike price? | unresolved |
| RR4 | Employer verified; posting live | positive_signal | — | "Accepting applications" | A funded, established employer with a live, consistent posting | `[grounded]` about and careers pages | — | noted |
| RR5 | Stated pay within market band | positive_signal | — | "$148,000–$166,000" | The band sits near the median for this title | `[generic]` band; `[grounded]` figure | — | noted |

Severe red flags: none found. The standing employer-not-established entry does not trigger.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead resume bullets with Airflow orchestration and the Great Expectations suite; make no BigQuery claim | see R4, R5 | `[grounded]` intake | pending your approval |
| A1 | Ask the recruiter whether the warehouse is on BigQuery today and whether this role owns contracts | see RR2, R7 | `[grounded]` RR2 | pending your approval |
| A2 | Before a screen, build a small dbt project on a BigQuery sandbox, only if you do it. It produces real evidence for R6 | see G1 | `[generic]` screens probe named platforms | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning tutoring company careers Denver", which returned pellucidlearning.com/about and the careers posting. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, text matches your paste. Moved the organization row and the contradictions row |
| 2. Role-family sweep | yes | Searched "senior data engineer salary Series B-D company 2026 pay report", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report). Its figures match the report you sent. Moved the market calibration and the scope read |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. The upgrade menu names what a name would unlock |

Your pasted material is the source for everything else; no page was used beyond these.

Dossier offer: I can write this up as a `tuesday-dossier.md` if you want a record to carry into interview prep.

## Upgrade menu

- A sanitized dbt project, DAG file or Great Expectations config → R3, R4, R5 move from `medium` to `high`.
- A BigQuery artifact (sandbox project or dbt run) → R6 moves from `adjacent` toward `direct`.
- A data contract doc or dbt contract YAML → R7 moves to `direct`.
- Your location and pay floor → R8 and R9 close.
- The hiring manager's name → scope read and the story to lead with for that reader.
- A deeper pass on Pellucid (funding, leadership churn, hiring patterns, employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Q1 (G1):** Have you touched BigQuery at all, such as a sandbox, a query you wrote, or a migration? If so, what did you own?

**Q2 (G2):** Have you owned contracts with downstream consumers, such as schema agreements, freshness commitments or breaking-change processes? Who agreed to them?

**Q3 (R8, R9):** Can you work remote in the US or from Denver, and is $148,000 base plus equity above your floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.