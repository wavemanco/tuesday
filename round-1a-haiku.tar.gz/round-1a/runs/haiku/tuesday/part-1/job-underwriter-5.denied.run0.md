**Snapshot: yes, worth applying, on conditions. Status: `conditional_go`.** The fit is solid on your core requirements. The open items are the posting itself (I couldn't verify it) and two hard gates that your location and pay floor would settle.

- **Fit ledger.**
  - `hard_gate` — unclear: R1 (remote-US or Denver location), R2 (base pay, $148,000–$166,000)
  - `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration), R7 (data quality testing)
  - `important` — adjacent: R8 (BigQuery); unclear: R9 (data contracts and app/CRM ingestion)

  R3–R7 are the strongest part of the case. R8 is the one real technical gap and is recoverable.
- **Opportunity ledger.** The pay is stated and sits inside the market band (RR5), and the company's stated scale and funding are a positive signal (RR6). Against that, the scope is wider than a typical senior role (RR3), the equity is unexplained (RR4), and neither the posting nor the hiring manager is verified (RR1, RR2).
- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver location), R2 (base pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the company's own careers page and the employer checks out (RR1); (2) your location and pay floor meet R1 and R2; (3) you can say which of the data-contract and ingestion work you own (R9, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016; 264 employees; Series C ($52M, February 2026) | `[grounded]` your pasted About page, not checked externally |
| Mandate | Build and run the pipelines behind reporting: app and CRM ingestion, a dbt warehouse on BigQuery, and data contracts analysts depend on | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Market calibration | Base median $151,000; IQR $139,000–$163,500 for Senior Data Engineers at Series B–D companies. The stated range sits around the median and runs $2,500 past the top of the IQR | `[generic]` Datawright 2026 report (n=2,310), as you supplied it, not checked against the source |
| Scope read | Wider than the usual senior role, which typically owns one domain's pipelines. This one spans ingestion, warehouse and contracts | `[generic]` typical scope from the same report; `[inferred]` from the JD's three scope items |
| Unknowns | Hiring manager, reporting line, team shape, equity terms, whether a platform team shares the work | — |
| Contradictions | None found in what you pasted | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the material, so the gate isn't settled | `[grounded]` JD; location not given | Q1 |
| R2 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | You haven't stated a floor | `[grounded]` JD; floor not given | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; prose intake, no artifact yet, so medium with the caveat named | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, per your background; no artifact yet | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, per your background | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your background | none |
| R8 | BigQuery warehouse (scope item) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery itself is untested. Limit: no BigQuery experience | `[grounded]` JD scope; `[inferred]` adjacency from R5 | G1 |
| R9 | Data contracts and app/CRM ingestion | important | unclear | low | discovery | Not in your background; may exist and may not | `[grounded]` JD scope; silence in your background | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake dbt work at about 180 models; no BigQuery use | The one scope item where you're not direct; a clear bridge narrows the objection | A BigQuery sandbox project running dbt, or a short write-up of a Snowflake model you could port | `[inferred]` bridge from R5; `[generic]` that this is the likeliest objection |
| G2 | Data contracts and ingestion (R9) | discovery | Nothing in your background either way | The scope lists it, and contracts are where analysts will push | One example of a contract you owned or ingestion you built | `[grounded]` silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Pellucid Learning runs live online tutoring…" | The posting may be stale, or the company's page may describe a different entity | `[generic]` pattern for an unchecked posting, not a claim about this company | "Is this role still open on your careers site, and who would I interview with?" | unresolved |
| RR2 | Hiring manager not named | unknown | — | (no name in posting) | Reporting line and team are unknown | `[inferred]` from the posting's silence | "Who would this role report to, and what team does it sit in?" | unresolved |
| RR3 | Scope spans ingestion, warehouse and contracts | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse…, and the data contracts…" | Ownership may be wider than one domain, possibly without a platform team to share it | `[generic]` typical scope from the Datawright report | "Which of these would I own myself, and which sit with a platform or analytics team?" | unresolved |
| RR4 | Equity unexplained | unknown | — | "plus equity" | Value to you is unknown | `[grounded]` JD gives no terms | "What equity is offered, on what vesting, and at what valuation?" | unresolved |
| RR5 | Pay is stated and in band | positive_signal | — | "$148,000–$166,000" | Pay is transparent and sits in the band | `[grounded]` JD figure; `[generic]` band | "Where in the range would an offer for this level land?" | noted |
| RR6 | Funded, stated scale | positive_signal | — | "Series C ($52M, February 2026)… 264 employees" | Stable funding and size, as the company itself states it | `[grounded]` your pasted About page; not checked externally | "What is the data headcount plan for the next year?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the posting on the company's own careers page, and confirm it is open before you apply | RR1 | `[grounded]` the posting link | pending your approval |
| A2 | Lead with the Snowflake dbt project (about 180 models) and the Great Expectations suite as your strongest verifiable items | R5, R7 | `[grounded]` your background | pending your approval |
| A3 | Describe BigQuery as "Snowflake dbt, no BigQuery yet, learning it", never as BigQuery experience | R8 | `[grounded]` you said you've never used BigQuery | pending your approval |

Each of these is a proposal. None adds a fact to your history.

## Evidence status

Verified: none yet. Your claims are intake-level, so they stay at medium until you confirm them with specifics or an artifact.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for the company and a fetch of the posting were both refused by permission, so I didn't retry. This leaves RR1 and the employer's existence unverified. Verifying it is what would move the decision from conditional to go |
| 2. Role-family sweep | skipped | Your pasted Datawright figures already fix the market band in role reality, so a search could not change it |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want, I can write these findings to a `tuesday-dossier.md` file for your records and later interview prep.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the decision likely moves to `go` or `no_go`.
- Permission to retry the company-page search and fetch → RR1 resolves, which could clear the `conditional_go`.
- A BigQuery sandbox project or a ported dbt model → R8 moves from adjacent toward direct.
- An example of a data contract or ingestion you built → R9 resolves from unclear.
- The hiring manager's name → RR2 closes and the positioning can aim at that reader.

## Questions

R1 — Are you based in the US, and would you work fully remote or in the Denver office? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R2 — What is your base-salary floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R9 — Have you owned a data contract or built app or CRM ingestion? Describe one example. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.