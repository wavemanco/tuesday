**No, not as posted: R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**

- `hard_gate`: failed: R1 (base $70–85k against your $150k floor); failed: R2 (five on-site days in Austin against remote-only)
- `must_have`: direct: R3 (8+ years growth leadership), R4 (paid, lifecycle, experimentation), R6 (end-to-end revenue ownership); unclear: R5 (SEO/content, brand, PR, partnerships, sales ops)

R3, R4 and R6 are your strongest rows, at medium confidence on your own account. R5 has nothing in what you've shared yet. R1 and R2 are your two stated limits, and the posting breaks both.

**Opportunity ledger.** The role is not a red flag on its face, but it is under-specified in ways that matter: a team-of-one start against an 8+-year, six-function mandate (RR1), an always-on norm (RR2), success metrics left undefined (RR3), equity left unquantified (RR4), and an employer I could not verify (RR5). I found no severe red flag.

- **Hard gates:** failed: R1 (base pay $70–85k against your $150k floor), R2 (five on-site days in Austin against remote-only)
- **Severe red flags:** none found
- **What would change this:** the employer would have to change both terms, offering base at or above $150k and remote work. No rewording of your resume touches either gate.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting's own claims; not verified (RR5) |
| Mandate | Own all revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Authority | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Compensation | $70–85k base, plus "meaningful equity upside" (unquantified) | `[grounded]` posting |
| Location and hours | Austin on-site five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Market calibration | Unavailable: the role-family search was refused, so I give no market band | — |
| Unknowns | Equity terms; success metrics; whether the posting is live | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay at or above $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor, specific and confirmed here; the posting's figure sits below it at both ends | `[grounded]` posting and your statement | Surfaced in the snapshot |
| R2 | On-site in Austin, five days a week (vs. remote-only) | hard_gate | hard_gate_fail | high | hard_gate | Your stated non-negotiable; the posting says "no exceptions" | `[grounded]` posting and your statement | Surfaced in the snapshot |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years: growth lead, then Head of Growth, at two B2C subscription companies; self-reported, no artifact | `[grounded]` your statement | None |
| R4 | Paid acquisition, lifecycle/CRM, experimentation | must_have | direct | medium | none | You owned all three; stated, no artifact | `[grounded]` your statement | None |
| R5 | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Absent from what you've shared; the posting names six functions here | `[grounded]` silence in your background | Question 1 below |
| R6 | End-to-end revenue ownership with budget authority | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled; your figures, unverified | `[grounded]` your statement | None |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Non-paid growth scope (R5, must_have) | discovery | Nothing in your account about SEO, brand, PR, partnerships or sales ops | Half the posted scope; if you have it, the scope gap narrows | Owning an organic or content channel; a brand or PR launch; a partner program; sales-to-marketing handoff or CRM ops | A channel dashboard, a partner deal list, a clip list | `[grounded]` silence in your background |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without resources, against seniority | risk_signal | medium | "You will be a team of one to start" beside "8+ years growth leadership required" | Accountable for six functions with no team, budget or decision rights in sight | `[inferred]` from the posting's own sentences | Which budget and headcount are committed to this role in year one, and who owns each function today? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond the stated week are the norm | `[grounded]` posting language; the reading is `[inferred]` | How often did the team work evenings or weekends last quarter, and what triggered it? | unresolved |
| RR3 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability with no stated definition of success | `[grounded]` posting | What two numbers will my first year be judged by, and when will they be set? | unresolved |
| RR4 | Equity unquantified | unknown | — | "meaningful equity upside" | The upside cannot be priced: no grant size, percentage or vesting | `[grounded]` posting silence | What is the equity grant size, vesting schedule and share count? | unresolved |
| RR5 | Employer not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The employer and its "profitable" claim are unchecked; the search was refused | `[generic]` pattern for early-stage companies, not a claim about this one | Can you point me to this role on Novaline's own careers page, and who is the hiring manager? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply as posted | R1 and R2 fail on terms the posting states | `[grounded]` R1, R2 | Recommendation; your call |
| P2 | If you want to test flexibility, send the recruiter one message asking whether base pay and on-site are negotiable | Only the employer changing both terms changes the gate outcome | `[inferred]` from the posting's "no exceptions", which argues against it | Pending your approval |

**Evidence status.** Verified: R1, R2, R3, R4, R6, from your statements in this conversation. No artifacts are attached, so R3, R4 and R6 stay at medium, and the $8M-to-$40M figure is unverified. Unverified: R5, and the employer (RR5).

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin"; the call was refused by the permission setting. Would have moved RR5: whether Novaline exists as described and whether the posting is live |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary Series A e-commerce United States"; the call was refused. Would have moved the market calibration for the $70–85k band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Dossier offer: I can write this up as `tuesday-dossier.md` if you want it on file.

**Upgrade menu**

- Granting search permission lets me rerun targets 1 and 2. That would verify whether Novaline exists and is hiring, and calibrate the pay against a market band. It would not change either gate, since both rest on your own numbers.
- The live posting's URL or the careers-page listing closes RR5.
- The recruiter's answer on base pay and on-site terms is the only thing that could move R1 and R2.
- An inspectable artifact for R3, R4 or R6, such as a dashboard or a planning deck, would raise those rows to high.
- A deeper pass on Novaline (funding, leadership changes, public reviews; up to 5 more searches and 2 more fetches) is available once; say the word and it runs.

**Questions**

1. (G1, R5) Have you owned any SEO/content, brand, PR, partnership or sales-ops work, even part of it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. (RR5) Where did you find this posting: Novaline's own careers page, or a job board? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.