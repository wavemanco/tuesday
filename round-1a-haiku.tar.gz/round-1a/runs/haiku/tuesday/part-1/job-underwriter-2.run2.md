**Worth applying, with a real screen risk: `conditional_go`.** You aren't wasting your time, but the posting's first must-have is a titled-years count, and R1b (titled PM years) is `absent`. Expect the screen to test that first.

**Fit ledger**
- `must_have`: direct: R3, R4a · adjacent: R1a, R2, R6 · unclear: R4b, R5 · absent: R1b
- `important`: adjacent: R8, R9, R10 · unclear: R7

R3 (`medium`) is confirmed but has no artifact yet, so expect a probe. R1b is the titled years and can't be closed by wording. R1a, R2 and R6 carry the case as adjacent work with the limits named.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the recruiter confirms the posting is live and that product-adjacent years count toward the 3+ years (RR1, RR2); (2) you can show one concrete product artifact or outcome, such as the triage tool or an API decision you shaped (G1, G3); (3) you can name an example of agile delivery with an engineering team (G2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your JD |
| Mandate | Own the roadmap for the partner-facing API platform, with two engineering squads and adoption metrics | `[grounded]` JD |
| Scope read | A platform PM with defined squads and metrics is a normal scope for the title at this stage | `[generic]` pattern, not a claim about this employer |
| Market calibration | Not run; no compensation band given | — |
| Unknowns | Pay, location, whether partners are external integrators, whether this is a PM title or a platform lead role | — |
| Contradictions | None visible in the material you gave | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ yrs PM: product-adjacent years (requirements, scoping, roadmap input) | must_have | adjacent | medium | transferability | About 7 years of requirements and scoping work with clients; adjacent, never titled | `[grounded]` CV · `[inferred]` adjacency | Ask recruiter whether it counts (RR1) |
| R1b | 3+ yrs PM: titled PM years | must_have | absent | medium | transferability | You stated you have never held a PM title; the statement is specific but not inspectable | `[grounded]` your statement | Don't claim it; the case rests on R1a |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations delivered end to end; you shipped integrations, not the platform's product decisions | `[grounded]` CV | G3 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI on the CV; no artifact yet | `[grounded]` CV | Offer a redacted spec or Postman collection |
| R4a | Stakeholders: engineering and customers | must_have | direct | medium | none | Coordinated internal engineers, client engineers and PMs; quarterly client sessions | `[grounded]` CV | None |
| R4b | Stakeholders: sales | must_have | unclear | none | discovery | The CV has no sales coordination | — | State the gap honestly if asked |
| R5 | Agile delivery | must_have | unclear | none | discovery | The CV is silent on sprints or backlog ownership | — | G2 |
| R6 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions; that was requirement capture, not open product discovery | `[grounded]` CV · `[inferred]` adjacency | Bridge with the limit named |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | Only a memory lead (an internal triage tool support supposedly adopted), unconfirmed; it prompts a question and is not evidence | `[inferred]` from unconfirmed memory | G1 |
| R8 | Own the roadmap | important | adjacent | medium | transferability | You ran client-input sessions feeding product's roadmap; you did not set priorities | `[grounded]` CV | G3 |
| R9 | Launch coordination with sales and support | important | adjacent | medium | transferability | 30+ go-lives coordinated with customers; sales and support not on the CV | `[grounded]` CV | State the support gap |
| R10 | Write specs; drive delivery with two squads | important | adjacent | medium | transferability | Requirements documents and coordination on custom builds; no two-squad delivery ownership | `[grounded]` CV | G2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | Adoption metrics, product outcomes (R7, R2) | discovery | A memory lead only | The strongest PM-shaped proof you could offer, if it exists | A triage tool's spec, usage or adoption numbers | `[inferred]` from memory, unconfirmed |
| G2 | Agile delivery (R5, R10) | discovery | CV silent | A must-have at `unclear` | An example of sprint or backlog work | — |
| G3 | Roadmap ownership and API decisions (R8, R2) | transferability | Input and integrations, no recorded decisions | The main objection to the adjacent case | One API decision you shaped (a field, endpoint, deprecation) and what followed | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Literal 3+ years screen | risk_signal | medium | "3+ years product management experience (must-have)" | Adjacent years may not get a conversation | `[generic]` pattern for must-have thresholds, not a claim about this employer | How do you weigh product-adjacent experience against titled PM years for this role? | unresolved |
| RR2 | Employer and posting unverified | unknown | — | "Product Manager, Platform APIs — Quartzline" | Not verified here: searches were refused this session | `[grounded]` your JD; verification not run | Can you point me to this role on Quartzline's careers site? | unresolved |
| RR3 | Scope and metrics defined | positive_signal | — | "define and track adoption metrics" | The mandate is specific: a platform, two squads, named metrics | `[grounded]` JD | What adoption metric matters most in year one, and how many partners are live today? | noted |
| RR4 | Pay not stated | unknown | — | No compensation in the JD | Band unknown; market calibration not run | — | What is the budgeted range for this role? | unresolved |

**Application plan** (each row pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with: "I led 30+ REST API integrations end to end, from requirements through go-live." | Covers R1a, R2, R6 | `[grounded]` CV | pending your approval |
| A2 | Don't use "product manager," "owned the roadmap" or "drove adoption" anywhere | Titled and ownership drift (R1b, R8) | `[grounded]` the reframing audit | pending your approval |
| A3 | Reword roadmap input as: "Collected client feedback for product's quarterly roadmap." | Ownership stays with product | `[grounded]` CV | pending your approval |
| A4 | Ask the recruiter RR1, RR2 and RR4 before investing in the full loop | Settles the screen and the posting | `[grounded]` register | pending your approval |
| A5 | Seek a referral to a PM or the hiring manager before applying cold | How hiring often works at companies this size | `[generic]` pattern | pending your approval |

**Evidence status**

Verified: none yet. Unverified lead: the triage tool (G1), which prompts a question only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by the tool's permission, and I did not retry. Would have moved RR2 and the organization row. |
| 2. Role-family sweep | unavailable | Same refusal. Would have moved market calibration and RR4. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Upgrade menu**
- A redacted spec, roadmap doc or playbook excerpt → R3 to `high`, and it gives the R8 probe something to check.
- Answers to G1 → R7 and R2 either strengthen or stay `low`. A triage tool with adoption numbers would be your best PM-shaped evidence.
- The recruiter's answers on RR1 and RR4 → the decision moves to `go` or `no_go`.
- A live posting link → RR2 closes.
- Search permission granted → L1 can verify Quartzline and run the role-family sweep.

I can also emit a `tuesday-dossier.md` with this map, so the next session starts from it.

1. Is there an internal triage tool you built and shipped, and what adoption numbers did you track? (G1)
2. Have you run sprint planning or backlog prioritization with an engineering team, and what did you decide versus recommend? (G2)
3. On the 30+ integrations, did you ever decide an API behavior, such as a field, an endpoint or a deprecation? What happened afterward? (G3)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.