**Worth applying, on conditions: `conditional_go`.** You meet the functional core of this role: 4+ years in sales or revenue operations, Salesforce admin, SQL and Excel, and building pipeline and renewal reporting. The real gaps are owning the quarterly forecast and billing data. Both are named below, and neither is a reason to skip the application. Two things to check before you commit time: whether the role owns the forecast number, and whether the employer posted it on its own site.

**Fit ledger**
- `hard_gate`: unconfirmed: R1 (Bristol hybrid, two days in office), R2 (£61.5–67k plus share options)
- `must_have`: direct: R4 (Salesforce administration), R5 (SQL and spreadsheet modelling), R7 (pipeline and renewal reporting); adjacent: R3 (sector is payments, not software), R6 (forecast ownership)
- `important`: adjacent: R8 (revenue data with finance); absent: R9 (billing data)

R6 is adjacent because pipeline review feeds a forecast, but you have never owned the number. R9 is absent by your own account.

**Opportunity ledger.** The employer is established and funded, and the posting is not verified on its own site. The forecast scope and the reporting line are unclear. Severe red flags: none found.

- **Hard gates:** unconfirmed: R1 (Bristol hybrid, two days in office), R2 (£61.5–67k plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 resolves as the role preparing the forecast for CFO sign-off, or you have a credible plan to own it; (2) RR2 clears, meaning the role appears on Quillfield's own site or the recruiter confirms it; (3) R1 and R2 are confirmed against your own constraints.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants, Bristol, founded 2018, 96 staff, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about (search result) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the office; salary £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | Owning a forecast and billing data alongside reporting is a broad remit for a Lead, and the forecast clause suggests the role carries the number itself | `[inferred]` from the posting's clauses |
| Market calibration | Not run this pass, so the salary band is uncalibrated | — |
| Contradictions | Careers page at quillfield.co.uk/careers returned no page; the posting is on an aggregator only | `[grounded]` fetch result |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days in office | hard_gate | unclear | high | hard_gate | Your location constraint was not given; cannot test it | `[grounded]` posting | Q2 below |
| R2 | £61.5–67k plus share options | hard_gate | unclear | high | hard_gate | Your pay floor was not given; the band is stated, so this is a comparison, not a gap in the posting | `[grounded]` posting | Q2 below |
| R3 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales ops, the last two in RevOps, but at a payments company | `[grounded]` your background | Name the sector limit in applications |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; you rebuilt pipeline and renewal dashboards | `[grounded]` your background | none |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; "modelling" is not yet named as a specific piece of work | `[grounded]` your background | Name one model you built |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Pipeline review is an input; finance owned the company forecast | `[grounded]` your background | Q1 below; RR1 |
| R7 | Pipeline and renewal reporting for sales and finance | must_have | direct | medium | none | You rebuilt both dashboards | `[grounded]` your background | none |
| R8 | Working with finance on revenue data | important | adjacent | medium | transferability | Renewal dashboards touch revenue, but not finance-owned reporting | `[inferred]` from the renewal work | Q3 below |
| R9 | Working with billing data | important | absent | — | capability | You have never worked on billing data | `[grounded]` your statement | Closure path: a short billing-to-renewals reconciliation project |

**Gap recovery queue**
- **R6 (transferability):** Limit: you never owned the number. Strengthener: a pipeline-to-revenue forecast accuracy check you ran or could run.
- **R9 (capability):** No direct or adjacent evidence. Closure path: a scoped reconciliation project between renewals and invoices.
- **R8 (transferability):** Limit: finance owned the reporting. Strengthener: one reconciliation example you can describe.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The role may own the number, or only prepare it for the CFO | `[inferred]` from the clause against the finance-owned forecast you describe | Does this role own the forecast number, or prepare the model for CFO sign-off? | unresolved |
| RR2 | Posting not on employer's own site | risk_signal | low | Posting only on Tallyboard | The posting may be stale or aggregated | `[grounded]` careers page not found | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR3 | Funded, established employer | positive_signal | — | Series A closed April 2025 | Hiring is likely tied to the post-raise build-out | `[grounded]` company About page | How is the Series A shaping this hire? | noted |
| RR4 | Reporting line unclear | unknown | — | Hiring manager is Head of RevOps | This role may sit under, beside, or outside the Head of RevOps remit | `[grounded]` public profile, Tamsin Achebe, Head of Revenue Operations | How does this role split work with the Head of Revenue Operations? | unresolved |
| RR5 | Salary band uncalibrated | unknown | — | £61,500–£67,000 plus share options | Band may be above or below the role-family norm | `[generic]` no sweep run | Is the range final, and how are the share options valued? | unresolved |

**Application plan** (all pending your approval)
- Lead the forecast point with the pipeline work as input, and say plainly that finance owned the final number. Pending approval.
- Name one reconciliation or modelling example for R5 and R8. Pending approval.

**Research tier:** L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (returned the About page) and "Quillfield Revenue Operations Lead job" (no results); fetched quillfield.co.uk/careers (no page). Moved the employer-established line and RR2 |
| 2. Role-family sweep | unavailable | Not run this pass; would calibrate the £61.5–67k band (RR5) |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" (returned a public profile: Head of Revenue Operations at Quillfield, previously a sales operations manager at a payments company). Moved RR4 |

**Dossier offer:** I can save this as a `tuesday-dossier.md` to carry into interview prep later.

**Upgrade menu**
- Your salary floor and your answer on Bristol hybrid → R1 and R2 resolve.
- A role-family sweep on this title and band → RR5 calibrates.
- The role on Quillfield's own site, or the recruiter's email domain → RR2 clears.
- A forecast accuracy sheet or pipeline-to-revenue check you ran → R6 could move from adjacent toward direct.
- A billing reconciliation example → R9 moves from absent to at least adjacent.

**Questions**

1. RR1 / R6 — Does this role own the quarterly forecast number, or prepare it for the CFO to sign off? Have you ever built or checked a forecast, even as a pipeline-to-revenue accuracy check?
2. R1 / R2 — Can you work in the Bristol office two days a week, and is £61,500–£67,000 plus share options above your floor?
3. R8 / R9 — Have you ever worked on billing data, or reconciled renewals against invoices, even informally?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.