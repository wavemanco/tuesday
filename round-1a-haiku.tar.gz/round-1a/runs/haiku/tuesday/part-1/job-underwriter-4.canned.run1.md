**Yes, apply, as `conditional_go`, once you've confirmed you're UK-based and can work fully remote from there, and you're comfortable pitching your motor work as the route into pet.**

Research tier: L0 (no searches). Nothing about Brindlemoor or Odile Varga has been checked online.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK-based)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads), R6 (designing and reading price tests)
- `important`: adjacent: R8 (pet-insurance product); unclear: R7 (recommendations to product)
- `preferred`: direct: R9 (insurance experience)

R1 is unconfirmed, not failed; R8 is a transfer case with its limit named; R7 has no product evidence yet.

**Opportunity ledger.** Scope is concrete (RR6); pay, contract type and start date are unstated (RR2); management scope is unknown (RR3); the employer is unverified because no research ran (RR1); "recommendations" may mean underwriting and product make the rate decisions (RR4, low).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) R1 confirmed: you're UK-based and can work remote from there. (2) R8: a pet transfer case you can state without overclaiming, tested in the first interview. (3) RR1: the posting confirmed on Brindlemoor's own careers page.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not verified |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| Scope read | An individual-contributor pricing role with named deliverables | `[inferred]` from the listed deliverables; the JD asks for no people management |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; no public footprint checked |
| Market calibration | Not established; no role-family sweep ran | — |
| Unknowns | Pay, contract type, start date, reports, pet book size and history, decision rights | RR2 to RR6 |
| Contradictions | None visible in the posting; no careers page checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | Your employer was UK-based, but your residence isn't stated | `[inferred]` from employer location | Confirm you're UK-based and can work remote from there |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior; stated, no artifact | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact | `[grounded]` your statement | Optional: a sanitised query to raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for a young-driver book | `[grounded]` your statement | Optional: sanitised model documentation to raise to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Designing and reading price tests | must_have | direct | medium | none | Fourteen tests last year with underwriting | `[grounded]` your statement | Optional: a test readout to raise to `high` |
| R7 | Recommendations to product | important | unclear | none | discovery | Underwriting recommendations are evidenced (R5); product isn't mentioned | `[inferred]` from CV silence | Ask G2 |
| R8 | Pet-insurance product | important | adjacent | medium | transferability | Motor rating and test work carries over; pet-specific drivers not exercised | `[inferred]` adjacency from motor work; `[generic]` that pet pricing turns on species, breed and vet-cost drivers | Ask G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years in UK motor insurance | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R8, important) | transferability | Motor rating and price tests; no pet work stated | The product is pet, so the transfer case is what interviews will probe | Any health, lifetime or vet-cost analysis; any claims-cost work with non-motor drivers | A motor-to-pet transfer note or a learning plan | `[generic]` that pet pricing turns on species, breed and vet-cost drivers |
| G2 | Recommendations to product (R7, important) | discovery | Underwriting recommendations evidenced; product not in the CV | The JD names product as a recipient | A test result that changed a product feature, price or eligibility rule | A product review slide or a test readout | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | unknown | — | "Brindlemoor (insurtech)" | The employer and live posting are unconfirmed; no research has run | `[grounded]` the posting is the only source | Can you point me at this role on Brindlemoor's own careers page? | unresolved |
| RR2 | Pay, contract, start date unstated | unknown | — | (no pay, contract or start-date language) | Withheld terms may matter to the decision; the posting gives no basis to say how | `[grounded]` posting is silent | What is the base salary range, is the role permanent, and what is the start date? | unresolved |
| RR3 | Management scope unknown | unknown | — | "Senior Pricing Analyst" | The senior title may carry reports; the posting doesn't say | `[inferred]` from the title against a silent requirements list | Does this role manage anyone now, or is that expected within a year? | unresolved |
| RR4 | Recommend versus decide | risk_signal | low | "turn the results into recommendations" | The role may recommend while underwriting and product decide, which narrows what "own" means | `[inferred]` from "recommendations" against "own pricing analytics" | Who approves a rate change once this role recommends it? | unresolved |
| RR5 | Pet book volume and history | unknown | — | "our pet-insurance product" | A young product may have too little claims history to validate a rating model | `[generic]` pattern for new insurtech products, not a claim about this one | How many policies and years of claims history does the pet book hold? | unresolved |
| RR6 | Concrete scope | positive_signal | — | "build and monitor rating models, design and read price tests" | Named deliverables suggest a defined pricing remit | `[inferred]` from the listed deliverables | Who else is on the pricing team, and what do they own? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with GLM and price-test work as your two strongest matches | R4, R6 | `[grounded]` rows R4, R6 | pending your approval |
| P2 | Describe pet as a transfer, not expertise. Proposed line: "My pricing work is in UK motor: a GLM for a young-driver book and fourteen price tests last year. I haven't priced pet yet." | R8 | `[grounded]` your sentences; every clause traces to them | pending your approval |
| P3 | Put RR1 to RR3 to the recruiter in the first call | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above is your own account, which counts as intake-level evidence until you confirm specifics.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Research not consented to yet. Would confirm the employer and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Would set pay and scope norms (RR2 and the market calibration line) |
| 3. Hiring manager's public footprint | unavailable | You gave a name, so a query can be formed. Would show Odile Varga's background and which story to lead with |

## Dossier offer

I can write all of this to a `tuesday-dossier.md` file you can keep and reuse.

## Upgrade menu

- **Inspectable artifacts:** a sanitised GLM documentation page (R4) or a redacted price-test readout (R6) would raise those rows to `high`.
- **Research at L1** (up to 5 searches and 2 page fetches): checks Brindlemoor and the live posting (RR1), sets pay and scope norms (RR2), and reads Odile Varga's public footprint. Say the word and it runs.
- **From the recruiter:** the pet book's volume and history (RR5) and the management answer (RR3).

## Questions

R1 — Are you UK-based, and can you work fully remote from there?

R8 — Have you priced or analysed any product with health, vet or lifetime-cover risk, even as a side project?

G2 — Have you taken a test result or pricing recommendation to a product team? What did they do with it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.