**Not worth pursuing. Status: `no_go`.** Your sense that something is off is right. Two of your hard constraints fail on the posting's own terms: it requires on-site in Austin five days a week, and it pays $70–85k base against your $150k floor. Wording can't close either gap, and the posting says "no exceptions" on location.

**Fit ledger**
- `hard_gate`: failed H1 (on-site Austin five days a week), H2 (base $70–85k)
- `must_have`: direct M1 (8+ years growth leadership), M3 (paid acquisition), M4 (lifecycle/CRM); adjacent M2 (end-to-end revenue ownership as a team of one)
- `important`: absent M5 (SEO/content, brand, PR, partnerships, sales ops)

H1 and H2 fail regardless of the rest. Your experience fits the paid and lifecycle core, and the scope beyond it is unevidenced.

**Opportunity ledger.** RR1 (evenings and weekends), RR2 (all revenue, one person, no bench) and RR3 (success metrics to be defined later) are risk signals. RR4 (seniority against pay) is pending a market check. RR5 (employer not verified) is unknown. RR6 is the one positive: the posting states profitability since day one.

- **Hard gates:** failed: H1 (on-site five days a week, Austin), H2 (base $70–85k against $150k floor)
- **Severe red flags:** none found
- **What would change this:** the posting would have to drop the on-site requirement and move base to your floor. Equity doesn't count toward a base floor.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2.** The web search permission was refused in this session, and I didn't retry.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would verify Novaline exists and the posting is live (RR5) |
| 2. Role-family sweep | unavailable | Would give the market band for RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claims, unverified |
| Mandate | All revenue growth across paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Working pattern | On-site Austin, five days a week, "no exceptions" | `[grounded]` posting |
| Scope read | One person owning every revenue channel, reporting to the CEO | `[inferred]` from "team of one" against "all revenue growth" |
| Market calibration | Not run; the search was refused | — |
| Unknowns | Budget, spend authority, success metrics, equity terms | — |
| Contradictions | "8+ years growth leadership required" sits beside "team of one… don't need a bench" | `[inferred]` from the two lines together |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | On-site Austin five days a week | hard_gate | hard_gate_fail | high | hard_gate | Your remote-only, Portland, not relocating constraint is your own confirmed statement; the posting says "no exceptions" | `[grounded]` posting plus your statement | none; only changed terms would resolve it |
| H2 | Base $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Your $150k base floor is your own statement; the top of the posted range is $65k below it, 43% under the floor | `[grounded]` posting plus your statement | none; equity doesn't bridge a base floor |
| M1 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth, teams of 3–7; self-reported, no artifact | `[grounded]` your account | none |
| M2 | Owns all revenue growth end to end | must_have | adjacent | medium | transferability | You owned paid, lifecycle and experimentation with a budget you controlled; the full channel scope isn't in your account | `[inferred]` from your account against the posting | none while H1 and H2 stand |
| M3 | Paid acquisition | must_have | direct | medium | none | Owned it at two B2C subscription companies; self-reported | `[grounded]` your account | none |
| M4 | Lifecycle/CRM | must_have | direct | medium | none | Owned it; Braze experience; self-reported | `[grounded]` your account | none |
| M5 | SEO/content, brand, PR, partnerships, sales ops | important | absent | none | discovery | Nothing in your account covers these | `[grounded]` your account silence | none while H1 and H2 stand |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work may be routine, not occasional | `[inferred]` from the sentence | How often did the last two quarters' evenings and weekends get used, and by whom? | unresolved |
| RR2 | Accountability without resources | risk_signal | medium | "own all revenue growth end to end… team of one" | You may carry the whole number with no budget or authority behind it | `[inferred]` from scope against "don't need a bench" | What budget, headcount and spend authority come with the role in year one? | unresolved |
| RR3 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be set before its measure exists | `[inferred]` from the sentence | What three numbers define success at the 12-month review, and who sets them? | unresolved |
| RR4 | Seniority against pay | risk_signal | medium | "8+ years" against "$70–85k base" | The pay may sit well below what the title usually commands | `[generic]` pattern; the sweep didn't run | What is the base band for this title, and why is it below $150k? | pending market check |
| RR5 | Employer not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A…)" | The employer may be too new to have a footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Novaline's own careers site, and who would I interview with? | unresolved |
| RR6 | Profitability stated | positive_signal | — | "profitable since day one" | Stated financial strength, not verified | `[grounded]` posting | Can you share the company's most recent financials? | noted |

**Application plan:** do not apply on these terms. Nothing in the plan changes H1 or H2.

**Evidence status:** verified claims are your own constraints, H1 and H2, at `high`. Everything else in your account is self-reported and unverified.

**Upgrade menu**
- A live posting link or Novaline's own careers page would verify the employer (RR5). It wouldn't change H1 or H2.
- Permission to web-search would run the employer check and the market band for RR4. The search was refused this session, so the band is unknown.
- A hiring manager's name would add a scope read, but it isn't needed for this decision.

I can write this up as a `tuesday-dossier.md` you can keep and append to later if that helps.

No questions this turn: the decision is stable.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.