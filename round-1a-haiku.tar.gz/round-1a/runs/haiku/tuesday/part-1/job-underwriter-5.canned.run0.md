**Yes, it's worth applying, with three things to confirm first: `conditional_go`.** Your core stack matches the posting, and the company checks out. The open items are your own constraints (location, work authorization, pay floor), which I don't have, and the BigQuery gap.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (work authorization), R3 (pay floor); candidate constraints not given, so checks against them are unknown.
- **Fit ledger:**
  - `hard_gate`, `unclear`: R1 (Remote US or Denver office), R2 (work authorization), R3 (pay floor).
  - `must_have`, `direct`: R4 (5+ years data engineering), R5 (strong SQL and Python), R6 (dbt and a cloud warehouse), R7 (orchestration with Airflow), R8 (data quality testing).
  - `important`, `adjacent`: R9 (BigQuery warehouse, from the role description).
  - `important`, `unclear`: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on).
  - R9 is a credible bridge with its limit named. R10 and R11 have no candidate evidence stated yet. R1 through R3 wait on your answers.
- **Opportunity ledger:** RR4 (pay sits inside the market band) and RR5 (employer and posting verified) read positive. RR1 (whether the role owns its pipelines, and with what team) and RR3 (scope breadth) are unknowns to ask about. No severe red flags.
- **Severe red flags:** none found.
- **What would change this:** the status becomes `conditional_go` → `no_go` if R2 or R3 fails. Confirming R1 through R3 and getting a clear answer on RR1 at the first recruiter call would make it a plain `go`.

### Research tier

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning senior data engineer careers BigQuery dbt" (returned the careers page). Fetched pellucidlearning.com/careers/senior-data-engineer: "Accepting applications", text matching the posting. The about page's facts appeared in search results but were not fetched. Moved RR5; no standing employer-not-established entry |
| 2. Role-family sweep | yes | Searched "senior data engineer salary Series B to D company 2026 pay report"; fetched the Datawright 2026 report page, which carries the same figures the recruiter sent. Moved the market calibration and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

### Role reality

- **Organization:** Pellucid Learning, live online tutoring for K-12 schools in 31 states. Founded 2016, Denver; 264 employees; Series C, $52M, February 2026. `[grounded]` company about page and careers page.
- **Mandate:** Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts. `[grounded]` posting.
- **Scope read:** One domain (tutoring reporting) with ingestion and contracts included. That is at the upper edge of what the title usually means, since the typical pattern is one domain's pipelines. `[inferred]` from the posting's scope against the `[generic]` norm below.
- **Market calibration:** Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically means 5–8 years. `[generic]` Datawright 2026 report. The posting's $148,000–$166,000 range has a midpoint of $157,000, which sits above the median and inside the range. `[inferred]` from the two figures. This is a market band, not this employer's offer.
- **Unknowns:** Hiring manager, team size, whether the role owns ingestion or only the warehouse, equity terms, Denver/remote split.
- **Contradictions:** None between the posting and the careers page. `[grounded]`

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No candidate location constraint was given, so the match is not established | `[grounded]` posting | Q3 |
| R2 | Work authorization (US) | hard_gate | unclear | none | hard_gate | The posting is silent on sponsorship; no candidate statement was given | `[grounded]` posting | Q3 |
| R3 | Pay floor against $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No floor was given; the band comparison is in role reality | `[grounded]` posting | Q3 |
| R4 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated by you; nothing inspectable | `[grounded]` your statement | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated by you; no artifact yet | `[grounded]` your statement | none |
| R6 | dbt and a cloud warehouse | must_have | direct | medium | none | Built a dbt project on Snowflake, about 180 models; no artifact yet | `[grounded]` your statement | upgrade item 1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, stated by you | `[grounded]` your statement | upgrade item 1 |
| R8 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, stated by you | `[grounded]` your statement | upgrade item 2 |
| R9 | BigQuery warehouse (role description) | important | adjacent | medium | transferability | Dbt and warehouse modelling carry over from Snowflake. Limit: no BigQuery use, so dialect, cost and partitioning are untested | `[inferred]` from Snowflake dbt work against the BigQuery description | G1 |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | Not stated in your background | `[grounded]` absence in your background | G2 |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Not stated in your background | `[grounded]` absence in your background | G2 |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9) | transferability | Snowflake dbt work, no BigQuery | This is the one specific tool the posting names that you have not used | Any BigQuery use: a sandbox project, a query cost review, a partitioning decision, a course project | A query history or sandbox project summary | `[inferred]` bridge; `[generic]` that this is the likeliest interview probe |
| G2 | Ingestion and data contracts (R10, R11) | discovery | Your background covers the warehouse and orchestration, not source ingestion or analyst-facing contracts | These are two of the posting's five responsibilities | Pipelines pulling from an app database, Salesforce or similar; schema agreements with analysts | A sanitized pipeline diagram or contract doc | `[grounded]` absence in your background |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership and team not stated | unknown | — | "Build and run the pipelines" | The role may own the pipelines alone or sit inside an existing team | `[generic]` pattern for posts with no named hiring manager | Is this a new team or an existing one, who would I report to, and how many engineers work on these pipelines? | unresolved |
| RR3 | Scope spans ingestion, warehouse and contracts | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse … data contracts" | The role may be broader than a single domain's pipelines | `[inferred]` against the `[generic]` norm | Which parts of ingestion do I own, and which belong to a platform team? | unresolved |
| RR4 | Pay sits inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The offer is at market, not below it | `[grounded]` posting; `[generic]` band | Is the equity grant standard for this stage, and is the base range final? | noted |
| RR5 | Employer attributed; posting live | positive_signal | — | "Accepting applications" | The entity exists as described and the role is current | `[grounded]` company site and careers page | none needed | noted |

### Application plan

- **Apply**, after R1–R3 are confirmed. Don't spend time on the application before the location and authorization check is settled.
- **Lead with** the Snowflake dbt project, Airflow orchestration and Great Expectations testing. These are the must-haves, and each is at medium confidence, so expect a probe on depth.
- **State BigQuery plainly:** you have not used it in production. Name the transfer you expect (dialect, cost model) and don't claim the tool itself.
- **In the first recruiter call,** ask the RR1 and RR3 questions verbatim.
- No resume wording is proposed in this pass. Any CV change would come as a pending edit for your approval.

### Evidence status

| Target | Status | What it moved |
|---|---|---|
| 1 | yes | See Research tier table above |
| 2 | yes | See Research tier table above |
| 3 | n/a | No name given |

---

If you want, I can write this up as a `tuesday-dossier.md` you can keep and carry into prep. Just say so.

**Upgrade menu**
1. A sanitized dbt project excerpt, or a lineage diagram, would raise R6 and R7 from medium to high.
2. A sanitized Great Expectations suite excerpt would raise R8 to high.
3. A BigQuery sandbox query history, or any written note on BigQuery cost or partitioning, would move R9 toward direct.
4. Deep research (L2), offered once: funding and leadership churn, hiring patterns, employee and candidate reports, and recent news. This would cost up to 5 more searches and 2 more fetches. I'll run it only if you say yes.
5. The hiring manager's name, if you have it, would let me check that person's public professional footprint (target 3).

**Questions**

- G1 (R9): Have you worked with BigQuery in any form, such as a sandbox, a course project, or a cost or partitioning review?
- G2 (R10, R11): Have you built ingestion from an application database or a CRM, or owned data contracts that analysts rely on? Which one, and how did you keep it working?
- R1–R3: Are you authorized to work in the US without sponsorship, is remote US or the Denver office workable for you, and what is your base-pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.