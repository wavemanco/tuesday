**Yes, apply, on three conditions: `conditional_go`.** R2, R3, R4, R5, R6 and R7 (the must-haves) read `direct` on what you've told me, and R8, the pet-insurance gap, is transferable rather than disqualifying. Two checks are still open: whether you're UK-based with right to work (R1), and whether the employer is real (RR4). Web research was refused in this session, so neither is verified.

**Research tier: L1, with every search refused.** No employer, pay or hiring-manager facts were checked. The assessment rests on the posting and what you told me.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK-based)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads), R6 (building and monitoring rating models), R7 (designing and reading price tests)
- `important`: direct: R9 (recommendations to underwriting) · adjacent: R8 (pet-insurance product knowledge) · unclear: R10 (recommendations to product)
- `preferred`: direct: R11 (insurance experience)

R8 — motor pricing carries over, pet specifics not yet exercised; R10 — product-side recommendations not in your history.

**Opportunity ledger.** Concrete scope and measurable outputs (RR5), but pay is withheld (RR1), line management is unstated (RR2), and rate-setting authority is unclear (RR3). The employer is unverified (RR4), which caps the decision at `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed: UK-based with right to work; (2) RR4 cleared against a live posting on the company's own careers page; (3) R8 framed as adjacent motor experience, never as pet expertise.
- **What would change this:** R1 failing makes it `no_go`. Pay far below the band, or a role with no rate authority, would be worth weighing before investing effort.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header, unverified |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Individual-contributor senior title; no reports stated | `[inferred]` from title and silence |
| Market calibration | Not run. No salary band offered; the search was refused | — |
| Unknowns | Pay; reports; final rate authority; employer verification | — |
| Contradictions | None visible from the posting alone | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (location and right to work) | hard_gate | unclear | none | hard_gate | Posting sets the term; your residence and right to work are not stated | `[grounded]` JD | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years pricing analytics, self-reported; expect a probe | `[grounded]` intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | SQL and Python daily, self-reported | `[grounded]` intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM, self-reported (motor) | `[grounded]` intake | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting, self-reported | `[grounded]` intake | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained a rating model; monitoring is the "maintained" half | `[grounded]` intake; `[inferred]` mapping onto the JD's "monitor" | none |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting, self-reported | `[grounded]` intake | none |
| R8 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing and testing transfer; pet risk drivers and claims behaviour are not exercised | `[inferred]` adjacency from motor pricing; `[generic]` that pet lines differ in their drivers | Gap queue G1 |
| R9 | Recommendations to underwriting | important | direct | medium | none | Underwriting recommendations through the quarterly review | `[grounded]` intake | none |
| R10 | Recommendations to product | important | unclear | none | discovery | Nothing in your history on product-side recommendations | `[grounded]` absence in intake | Q3 below |
| R11 | Insurance experience (preferred) | preferred | direct | medium | none | Five years at a UK motor insurer, self-reported | `[grounded]` intake | none |

Confidence is capped at `medium` because your background is self-reported and no artifact has been inspected.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R8, important) | transferability | Motor pricing, GLM, and testing; nothing pet-specific | The likeliest objection in interview, so the bridge needs stating with its limit | Any pricing or claims work on a non-motor line, or pet-related data | A pet-line pricing deck or claims extract, if you can share one | `[inferred]` bridge from motor work; `[generic]` that pet risk drivers differ |

The question for G1 sits in the closing block, tagged to its row.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay withheld | unknown | — | (no pay in the posting) | The post may pay below the band, or the company may not publish pay | `[generic]` pattern for posts that withhold pay | What is the base salary range for this role? | unresolved |
| RR2 | Line management unstated | unknown | — | "Senior Pricing Analyst" | The role may or may not have reports, and you have not managed anyone; the posting does not require it | `[inferred]` from the title and silence | Does this role line-manage anyone, and if so, who? | unresolved |
| RR3 | Rate-setting authority unclear | risk_signal | low | "turn the results into recommendations for underwriting and product" | The role may recommend while final rate decisions sit elsewhere | `[inferred]` from "recommendations" against silence on sign-off | Who makes final rate-change decisions, and does this role have sign-off? | unresolved |
| RR4 | Employer unverified | risk_signal | medium | "Brindlemoor (insurtech)" | The employer's existence and the posting's currency are unconfirmed, because the search was refused | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me at the live role on your careers site, and who would I be interviewing with? | unresolved |
| RR5 | Concrete scope | positive_signal | — | "build and monitor rating models ... design and read price tests" | Defined, measurable responsibilities | `[grounded]` JD | Which price tests ran last year, and how were the results read? | noted |

No severe red flags. The posting asks nothing of you (no fees, no deposits, no bank details).

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the CV with the GLM rating model, the 14 price tests, and the quarterly review to the head of underwriting, each stated as motor | R4, R5, R7 | `[grounded]` intake | pending your approval |
| P2 | Add a bridge line for pet: what carries over (rating-model method, test design, underwriting translation), what is not yet exercised (pet risk drivers and claims), and what you would learn first. Do not claim any pet experience | R8 | `[inferred]` adjacency; `[generic]` on pet differences | pending your approval |
| P3 | Ask RR1 to RR4 verbatim in the first recruiter contact | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Confirm UK base and right to work before applying | R1 gate | `[grounded]` JD | pending your approval |

Keep "built and maintained" as written. Do not upgrade it to "owned", and do not write "pet pricing" for anything you have not done. Every line above is proposed, not applied.

## Evidence status

Verified: none yet. Your claims are intake prose and have not been probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search refused. Would have checked the employer exists and the posting is live (RR4) and the contradictions row |
| 2. Role-family sweep | unavailable | Search refused. Would have set a pay band and a scope norm for senior pricing analysts (RR1, market calibration) |
| 3. Hiring manager's public footprint | unavailable | Search refused. The name, Odile Varga, was given, so a query could form. Would have fed the positioning for the Director of Pricing |

## Upgrade menu

- Confirming UK base and right to work → R1 to `direct`, which removes the gate and lets the status move to `go`.
- Your pay floor and any non-negotiables → constraint rows, so the hard-gate line can be checked against them.
- A pet-line pricing deck or claims extract, if you can share one → R8 toward `direct`.
- A live posting link or the company's careers page → RR4 clears and the `conditional_go` cap lifts.
- Re-enabling research (the three searches were refused in this session) → the employer check, a pay band, and the hiring manager's public background.

I can save this assessment as `tuesday-dossier.md` whenever you want it on file.

G1 — Have you ever priced, or worked with data from, a non-motor line, such as pet, home, or travel? What did you own, and what did you learn from it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R1 — Are you based in the UK, with the right to work there, for a fully remote role?

Structural — What is your pay floor, and what are your non-negotiables on contract type, hours, or remote working?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.