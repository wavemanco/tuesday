**Yes, apply.** You fit the analytics core of this role. The open items are a healthcare gap, mentoring, and an employer I couldn't verify. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R1 (5+ years product analytics), R2 (expert SQL), R3 (experiment design at scale), R4 (Looker or similar BI), R7 (written communication to non-technical stakeholders) · adjacent: R5 (define and maintain the metrics layer)
- `important`: direct: R6 (self-serve dashboards), R8a (partner with PMs) · unclear: R8b (partner with clinicians), R9 (mentor two junior analysts)
- `preferred`: adjacent: R10 (healthcare data experience, HIPAA)

What matters: R5 — you built the Looker layer, but nothing yet shows you owned metric definitions; R9 — no mentoring in your background so far; R10 — GDPR/CCPA and consent work transfers, HIPAA doesn't yet; R8b — no clinician work on record.

**Opportunity ledger.** RR1: the employer is unverified, because web search was refused and nothing was checked. RR2: the pasted posting gives no pay. RR3 is a positive signal: the responsibilities are concrete and measurable.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 verified on Harborlight's own careers page; (2) R10 confirmed as a plus, not a day-one requirement; (3) R9 and R8b answered in the questions below.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` posting; not verified (RR1) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker dashboards, mentoring two juniors | `[grounded]` posting |
| Scope read | Senior IC plus mentoring; the people-leadership element is unstated | `[inferred]` from "mentor two junior analysts" |
| Pay, location, contract | Not in the posting text | — (RR2) |
| Market calibration | Not established; no search ran | — |
| Unknowns | Pay, location, reporting line for mentoring, whether the metrics layer is greenfield, clinician involvement | — |
| Contradictions | None visible in the text you shared | `[grounded]` posting |

## Evidence map

Your background is self-report, so every claim sits at `medium` at most until something is inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, stated | `[grounded]` background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated | `[grounded]` background | Sanitized query sample (upgrade menu) |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and the 11% pricing-test lift, stated | `[grounded]` background | Experiment readout (upgrade menu) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` background | Governance note or screenshot |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards are close, but the brief doesn't say you owned canonical metric definitions. Limit: definitions may have been set by others | `[inferred]` from the governed-dashboard claim | Q3 |
| R6 | Self-serve dashboards | important | direct | medium | none | Governed dashboards for self-serve use | `[grounded]` background | none |
| R7 | Written communication to non-technical readers | must_have | direct | medium | none | Monthly metrics memo read by the exec team; monthly VP Product presentation | `[grounded]` background | Memo excerpt (upgrade menu) |
| R8a | Partner with product managers | important | direct | medium | none | Presents to the VP Product; works with product teams | `[grounded]` background | none |
| R8b | Partner with clinicians | important | unclear | low | discovery | Nothing on record either way | — | Q2 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring in the brief | — | Q1 |
| R10 | Healthcare data (HIPAA) | preferred | adjacent | medium | transferability | No healthcare work. GDPR/CCPA consent-state model is credible adjacency. Limit: HIPAA's PHI rules are not exercised | `[grounded]` background; `[generic]` that HIPAA is a different regime | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Metric ownership (R5) | transferability | Governed Looker layer, no statement of who owned definitions | A confirmed answer on who set metric definitions | `[grounded]` background |
| G2 | Clinician partnership (R8b) | discovery | No record of non-PM stakeholders | Any cross-functional work outside product | — |
| G3 | Mentoring (R9) | discovery | No mentoring in the brief | Any onboarding, review or coaching of analysts | — |
| G4 | Healthcare data (R10) | transferability | Consent model and PII governance, no PHI | Any health or regulated data work | `[grounded]` background; `[generic]` HIPAA scope |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "digital-health scale-up (~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Not checked | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on Harborlight's own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Pay not in the posting | unknown | — | (no pay line in the text shared) | Budget may sit outside the band you expect, or the posting may simply omit it | `[grounded]` the posting text | "What base range is budgeted for this role?" | unresolved |
| RR3 | Concrete mandate | positive_signal | — | "own product analytics for our care-navigation app" | Scope is defined, and experimentation is part of it | `[grounded]` posting | "Which experiments ran last year, and how were decisions made from them?" | noted |
| RR4 | Mentoring may carry reports | unknown | — | "mentor two junior analysts" | Mentoring may be informal, or may be a step toward line management | `[inferred]` from the mentoring line | "Are the two analysts direct reports or a mentoring arrangement?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Harborlight's careers site before investing effort | RR1 | `[grounded]` RR1 | your action |
| A2 | Use your own words for the Looker work: "built the instance from scratch, 40+ governed dashboards." Don't adopt "self-serve" unless you drove adoption | Reframing audit: the JD's vocabulary is not yours | `[grounded]` background | pending your approval |
| A3 | Answer the healthcare question candidly: GDPR/CCPA consent work transfers; you have no PHI or HIPAA experience | R10 | `[grounded]` R10 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused for permission, so no company page was checked. Would have moved RR1 |
| 2. Role-family sweep | unavailable | The search was refused. Would have set a pay and scope calibration and moved RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to run web search: up to 3 more searches and 2 fetches on targets 1 and 2 would verify RR1 and set RR2 against a pay band.
- Deeper employer diligence (funding, leadership changes, public candidate reports) would take up to 5 more searches and 2 more fetches. I'm offering this once.
- A sanitized SQL sample or experiment readout would raise R2 and R3 to `high`.
- A sanitized memo excerpt would raise R7 to `high`.
- A Looker governance note or dashboard screenshot would raise R4 and R5.
- Your constraints (pay floor, location, contract type) would let the hard-gate checks run. Right now they are unknown.

Would you like me to write this up as `tuesday-dossier.md`, so the verification questions carry into interview prep?

1. **G1 (R5):** Did you own the metric definitions, such as what counts as an active subscriber or as retention, or did someone else set them? What was yours, and how did you know they held?
2. **G2 and G4 (R8b, R10):** Have you worked with clinicians or other non-product teams, or with health, clinical or other regulated data? What rules governed that work, and what was your part?
3. **G3 (R9):** Have you mentored, trained or formally reviewed junior analysts? What did you own, and how did you know it worked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.