**Decision: conditional_go.** Apply if you can show adjacent evidence for the two gaps below. Your tooling and SQL match well, but the posting explicitly asks for forecast ownership and billing-data work, and you haven't done either.

**Decision snapshot**

- **Must-have, meets:** 4+ years in RevOps or sales ops (5 years) [grounded, your background]; Salesforce admin (certified) [grounded]; strong SQL and spreadsheets (weekly and daily) [grounded].
- **Must-have, partial:** B2B *software* experience. You worked at a B2B payments company. Whether that counts depends on how strictly they read the requirement.
- **Must-have, gap:** Owning a forecast. You run the monthly pipeline review but finance owned the company forecast. The posting asks the Lead to run the quarterly forecast with the CFO.
- **Must-have, gap:** Working with finance on billing or revenue data. You've never worked on billing data, and the posting says the Lead will "own our CRM and billing data."
- **Hard gates, unknown:** Location (Bristol, two days a week in the office) and salary (£61,500–£67,000 plus options). I don't have your location or your floor, so I can't check either.

**Role reality**

- The posting covers CRM, billing data, pipeline and renewal reporting for both sales and finance, plus the quarterly forecast. That is a wide scope for one role [inferred].
- The company is a Series A invoicing and payments business for UK builders' merchants, founded 2018, with 96 staff and an £11M Series A in April 2025 [grounded, company About page, seen only as a search snippet].
- Tamsin Achebe is listed as Head of Revenue Operations and previously ran sales operations at Corvane Payments for four years [grounded, profile snippet]. Since she heads RevOps, this Lead probably reports to her [inferred]. The posting doesn't state the reporting line.
- I did not check the salary against a market band, so I have no `[generic]` view on whether £61.5–67k is fair for this seniority.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Partial. The About page came up in search, but I only saw the snippet. I did not fetch it or the careers page, so I have not confirmed the posting is live on their own site. |
| 2 | Role-family sweep (market pay and scope) | skipped | Not run in this pass. |
| 3 | Hiring manager's public footprint | yes | Profile snippet from a search on her name and the company. |

**Recovery queue (no questions here)**

- **G1, forecast ownership:** The gap is real. Closing it needs evidence that you supplied forecast inputs, such as conversion rates, weighted pipeline, or close-date accuracy.
- **G2, billing data:** The gap is real. Closing it needs evidence of work with invoices, bookings-to-revenue reconciliation, or payment-event data. Your payments background may be closer to this than you're treating it.
- **G3, B2B software:** Partial. Closing it needs a clear account of how the payments company's product and customers match the requirement.
- **G4, location and hybrid pattern:** Unknown.
- **G5, pay against your floor:** Unknown.

**Application plan (as far as the evidence allows)**

- Lead with the pipeline and renewal dashboards you built and the Salesforce work. That is your strongest match.
- Do not describe the pipeline review as forecasting. If you supplied any forecast inputs, say exactly what they were.
- Address the forecast and billing gaps in your first reply, not in the interview. Saying what you have done closer to them is better than leaving the reader to find the gap.

**Dossier offer:** I can write a `tuesday-dossier.md` file with this assessment, so you can carry it into any later prep.

**Upgrade menu:** A CV would let me check your evidence rows directly. A forecast-input example or a billing-data example would move G1 and G2. A market-pay check (L1 target 2) would give a `[generic]` view on the salary. A check of the careers page (L1 target 1) would confirm the posting is live. Deeper company diligence and recent news are available at L2 on your say-so, up to 5 more searches and 2 more fetches.

**Questions**

1. Did you ever supply inputs to a forecast, such as stage-conversion rates, weighted pipeline, or close-date accuracy, even if finance produced the final number?
2. Have you ever reconciled bookings, invoices or payments to revenue, or pulled billing or payments data for finance? Your payments-company work might be closer to this than you think.
3. Where do you live relative to Bristol, could you do two office days a week, and what is your base-salary floor?

Answer in prose, or say "skip" on any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.