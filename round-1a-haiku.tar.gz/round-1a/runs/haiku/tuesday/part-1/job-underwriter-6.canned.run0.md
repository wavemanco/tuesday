**Yes, apply, with conditions.** Your experience matches most of the posting. The gaps are the forecast and billing data, and the posting itself needs checking. Verdict: `conditional_go`.

**Fit ledger**
- **hard_gate:** unclear: R10 (Bristol hybrid, two days a week in the office), R11 (£61,500–£67,000 base)
- **must_have:** direct: R1 (4+ years in revenue or sales ops), R3 (HubSpot or Salesforce admin), R4 (strong SQL); adjacent: R5 (spreadsheet modelling), R7 (owning a forecast); absent: R8 (billing data with finance)
- **important:** direct: R6 (pipeline and renewal reporting); adjacent: R2 (B2B software company)

R7 is the forecast gap, R8 is billing data, R5 is modelling, and R10 and R11 are the two gates nobody has confirmed. R2 is adjacent because the posting says "software" and your employer is a payments company.

- **Hard gates:** none failed; unconfirmed: R10 (Bristol hybrid, two days a week), R11 (£61,500–£67,000 base); candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** RR4 is a positive signal: Quillfield is funded (Series A £11M, April 2025, per its own site). RR1 is a medium scope risk: the role bundles CRM admin, billing data, reporting and the CFO forecast. RR2 and RR3 are open questions about where the posting lives and who you'd report to.
- **What would change this:** Conditions for `conditional_go`: the forecast split with finance is clear (R7, RR1); billing scope is clear (R8); Bristol and the pay band work for you (R10, R11); the role is confirmed on Quillfield's own site with a clear reporting line (RR2, RR3). It moves toward `no_go` if the pay floor is above £67,000 or two office days a week in Bristol are unworkable, because a failed gate has no path.

**Role reality**
- **Employer:** Quillfield makes invoicing and payments software for UK builders' merchants, is based in Bristol, has 96 staff and closed a £11M Series A in April 2025. `[grounded]` from quillfield.co.uk/about (fetched).
- **Role:** Owns CRM and billing data, builds pipeline and renewal reporting, runs the quarterly revenue forecast with the CFO. `[grounded]` from the posting.
- **Hiring manager:** Tamsin Achebe, Head of Revenue Operations at Quillfield; previously four years in sales operations at Corvane Payments. `[grounded]` from a public profile in search results (not opened). Her background is close to yours, which is useful.
- **Market calibration:** The posted £61,500–£67,000 sits inside the 2026 UK revenue-ops interquartile range (£57,800–£70,400, median £64,200, n=438). `[generic]` for the role family, from the Ledgerline 2026 pay guide (search snippet only). This is not a claim about Quillfield's offer, and there is no compensation mismatch.
- **Scope read:** This reads as a bundled role: CRM administration, billing data, reporting and the forecast in one title. `[inferred]` from the posting's scope language. Whether the Head of RevOps is the hiring manager for a role under her, or a peer, is unknown.
- **Contradictions:** None found between the posting and the Quillfield site, but the posting is hosted on an aggregator and I did not find it on Quillfield's careers page.

**Evidence map**

| # | Requirement (priority) | Fit | Gap | Confidence | Reasoning | Provenance |
|---|---|---|---|---|---|---|
| R1 | 4+ years RevOps / sales ops (must_have) | direct | none | medium | Five years in sales ops, the last two running UK RevOps; self-reported, no artifact | `[grounded]` your CV statement |
| R2 | B2B software company (important) | adjacent | transferability | medium | B2B payments, not software; the limit is the product, not the sales motion | `[grounded]` and `[inferred]` |
| R3 | HubSpot or Salesforce admin (must_have) | direct | none | medium | Salesforce admin certified; certificate not yet seen | `[grounded]` your statement |
| R4 | Strong SQL (must_have) | direct | none | medium | SQL weekly; no query or artifact yet | `[grounded]` your statement |
| R5 | Spreadsheet modelling (must_have) | adjacent | transferability | low | Excel daily, but no models named | `[grounded]` |
| R6 | Pipeline and renewal reporting (important) | direct | none | medium | Rebuilt pipeline and renewal dashboards | `[grounded]` your statement |
| R7 | Owning a company forecast (must_have) | adjacent | transferability | medium | Run the monthly pipeline review, never owned the forecast; finance owned it | `[grounded]` your statement |
| R8 | Billing or revenue data with finance (must_have) | absent | transferability | medium | Never worked on billing data; payments-side data is the nearest | `[grounded]` your statement |
| R10 | Bristol hybrid, two days in office (hard_gate) | unclear | hard_gate | none | No statement from you yet | `[grounded]` posting |
| R11 | £61,500–£67,000 base (hard_gate) | unclear | hard_gate | none | Your pay floor is not stated | `[grounded]` posting |

**Gap recovery queue**
- **G1 (R7, transferability):** You run the pipeline review but have not owned the forecast. Closes with: the forecast's build, the owner, and which parts sit with finance.
- **G2 (R8, transferability):** No billing work. Limit: you cannot claim billing knowledge. Strengthener: any finance-facing revenue work you did, described precisely.
- **G3 (R5, transferability):** Daily Excel, no modelling named. Closes with: a model you built, even a personal one.
- **G4 (R10, R11, hard_gate):** Surfaced in the snapshot. Only your answer can close them.

**Opportunity risk register**
- **RR1** (risk_signal, medium): Scope is bundled. `[inferred]` from the JD's scope language. Verification question: "Which parts of the quarterly forecast does this role own, and which stay with finance?" Decision rule: proceed only if the split is concrete. Status: unresolved.
- **RR2** (risk_signal, low): Posting found on an aggregator, not on Quillfield's careers page. `[inferred]` from the URL and the search results. Verification question: "Is this role on your own careers site, and who would I be interviewing with?" Status: unresolved.
- **RR3** (unknown): Reporting line unclear. `[inferred]`. Verification question: "Who does this role report to, and is the Head of Revenue Operations the hiring manager?" Status: unresolved.
- **RR4** (positive_signal): Funded company with recent Series A. `[grounded]` from its About page.

**Application plan**
- **Lead with:** five years in sales ops, the last two running UK revenue ops; Salesforce admin certified; rebuilt pipeline and renewal dashboards; weekly SQL. `[grounded]` in your statements.
- **Forecast line (proposed, pending your approval):** "I run the monthly pipeline review with our sales director. I haven't owned a company forecast, and I want to learn how one is built with finance." Only use it if it is true. It is your own sentence reworded, not a claim of ownership.
- **Shared background (pending your approval):** Tamsin's public career path also runs through sales operations at a payments company. Mention it in outreach only if it helps; do not imply a relationship.
- **Next step:** If you go ahead, mock-interview can drill the forecast question. I have not run that here.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | yes | About page fetched (Bristol, 96 staff, Series A). No careers page found, so the posting is not confirmed on the employer's site. |
| 2 | Role-family sweep | yes | Ledgerline 2026 pay guide (search snippet only, not opened). Moved the market-calibration line. |
| 3 | Hiring manager's public footprint | yes | Search for Tamsin Achebe at Quillfield returned a public profile. Moved the positioning line. |

L2 was not run. It is offered in the upgrade menu.

**Dossier offer:** If you want, I can save this as `tuesday-dossier.md` so you can keep and update it.

**Upgrade menu**
- Your Bristol commute and two office days, and your pay floor: this settles R10 and R11 and could move the verdict to `go` or `no_go`.
- Your CV as a document, and your Salesforce certificate: moves R1 and R3 to `high` with an artifact.
- Research at L2 (up to 5 more searches and 2 more fetches): Quillfield's funding and leadership changes, recent news, and public candidate reports. Say if you want it.

**Questions**
1. Does this role own the company forecast end to end, or does finance keep the model and this role supply the pipeline inputs? (G1, RR1)
2. Is Bristol two days a week workable for you, and is £61,500 within your floor? (G4)
3. Is this role on Quillfield's careers page, and who would you report to? (RR2, RR3)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.