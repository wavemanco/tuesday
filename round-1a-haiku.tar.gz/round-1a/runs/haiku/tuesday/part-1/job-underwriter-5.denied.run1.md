**Worth applying to on the substance, but not a clear go yet. Status: `hold_pending_answers`.** Three things could change that: your location, your pay floor, and an employer check I could not run.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver), R2 (base $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow orchestration), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts)

R3, R4, R5, R6 and R7 are the five must-haves, all `direct`. R8 is a credible bridge from Snowflake, with its BigQuery limit named. R9 and R10 have nothing in your background yet.

**Opportunity ledger.** The scope is specific, the stack is named, and the salary is published (RR4). Open: the employer is unverified (RR1), the hiring manager is unnamed (RR2), and equity is unquantified (RR3).

- **Hard gates:** none failed (no gate row `direct`); unconfirmed: R1 (remote US or Denver), R2 (base $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) your location answers R1; (2) your pay floor answers R2; (3) RR1 verifies on Pellucid's own careers page. Clean answers to all three move this to `go`. A location outside the US, or a floor above $166,000, moves it to `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 staff, Series C ($52M, Feb 2026) | `[grounded]` your pasted About page; not verified externally (see Evidence status) |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, a dbt warehouse on BigQuery, and data contracts analysts depend on | `[grounded]` posting |
| Scope read | One domain's pipelines, owned end to end; no reports stated | `[inferred]` from "build and run" and "data contracts our analysts depend on" |
| Seniority | Posting asks 5+ years; your 6 years sits inside the report's 5–8 year "Senior" norm | `[grounded]` posting and the Datawright report you pasted |
| Market calibration | Posted $148,000–$166,000 against the report's median $151,000 and IQR $139,000–$163,500: the range runs from the median to just past the upper quartile. Equity is unpriced | `[grounded]` posting and the report you pasted; this is the title's band, not this employer's offer |
| Working pattern | Remote US, or the Denver office | `[grounded]` posting |
| Unknowns | Equity, hiring manager, team, your location relative to the role | — |
| Contradictions | None between the posting and the About page you pasted; the careers page was not checked | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location is not stated, so the gate is not established | `[grounded]` posting; your location not given | Q1 below |
| R2 | Base $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor is not stated, so the gate is not established | `[grounded]` posting; your floor not given | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in your background. No inspectable artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated in your background | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, stated | `[grounded]` your background | none |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow used for orchestration, stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, stated | `[grounded]` your background | none |
| R8 | BigQuery (named in the role's warehouse) | important | adjacent | medium | transferability | Snowflake dbt work carries over. You have never used BigQuery, and its specifics (partitioning, cost model, IAM) are unexercised | `[inferred]` requirement from the posting's role text; `[grounded]` your Snowflake work and the BigQuery limit | Q3 is not about this; see the gap queue |
| R9 | Ingestion from app and CRM sources | important | unclear | low | discovery | Named in the role, absent from your background | `[inferred]` requirement from the role text; `[grounded]` silence in your background | Q3 below |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Named in the role, absent from your background | `[inferred]` requirement from the role text; `[grounded]` silence in your background | Q3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1) | hard_gate | Location not stated | Decides whether the gate is met at all | — | — | `[grounded]` posting |
| G2 | Pay floor (R2) | hard_gate | Floor not stated | The posted range sits from the median up past the upper quartile; a floor above $166,000 fails it | — | — | `[grounded]` posting and report |
| G3 | BigQuery (R8) | transferability | Snowflake dbt work; no BigQuery | The posting names BigQuery as the warehouse | Any dbt model work on another cloud warehouse; any BigQuery sandbox or course | A BigQuery sandbox project, or a short design note on partitioning and cost | `[inferred]` bridge from Snowflake; `[generic]` that the BigQuery specifics are the likeliest probe |
| G4 | Ingestion and contracts (R9, R10) | discovery | Your background is silent on both | Both are named responsibilities of the role | Any source-system ingestion you built or ran; any schema or interface agreement analysts relied on | A pipeline diagram, a contract doc, or an anonymised example | `[inferred]` from the role text; `[grounded]` your silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | low | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The posting may be stale, or the entity may not match the page; research to confirm it did not run | `[generic]` pattern for companies of this size, not a claim about this one | "Can you confirm this posting is live on your careers page, and who the hiring manager is?" | unresolved |
| RR2 | Hiring manager and team not named | unknown | — | "Senior Data Engineer — Pellucid Learning." | Reporting line and team unknown; it bears on the scope read | `[inferred]` from the posting's silence | "Which team is this role on, and who would I report to?" | unresolved |
| RR3 | Equity unquantified | unknown | — | "Salary $148,000–$166,000 plus equity" | Equity could be small or large; no grant size or vesting is stated | `[inferred]` from the posting's silence | "What equity grant is this role offered, as shares or a percentage, with what vesting schedule?" | unresolved |
| RR4 | Salary published; scope and stack stated | positive_signal | — | "Salary $148,000–$166,000 plus equity"; "Build and run the pipelines behind our tutoring platform's reporting" | Pay is disclosed and the scope is specific, which is unusual enough to say | `[grounded]` posting | "How is this range set against the level this role is hired at?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the live posting and the hiring manager on Pellucid's own careers page before any effort | RR1, RR2 | `[inferred]` from the register's verification questions | pending your approval |
| A2 | Lead the data-quality line with the Great Expectations suite and the dbt model count, in your own verbs: "set up", "about 180 models on Snowflake" | R5, R7 | `[grounded]` your background | pending your approval |
| A3 | For BigQuery, state the limit plainly: "I've built dbt models on Snowflake, about 180 of them. I haven't worked in BigQuery, and I'd expect the modelling to transfer while its specifics need ramp-up." | R8 | `[grounded]` your background; the limit is your own | pending your approval |

Every row is a proposal, and A2 and A3 are language you would say or send. Nothing is finalized until you approve it.

## Evidence status

Verified: none yet. Your background is prose, so it is CV-equivalent: leads for verification, not proof. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both calls (one search, one fetch on the careers page) were refused by a permission prompt, and I did not retry. Would have confirmed that Pellucid exists as described and that the posting is live. Until it does, the decision stays on hold |
| 2. Role-family sweep | skipped | The Datawright figures you pasted already fix the band and the seniority norm, so a search would change nothing in the map |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

The upgrade menu below offers a re-run of target 1 if you grant permission.

## Upgrade menu

- A BigQuery sandbox project, or a short write-up of one → R8 moves from `adjacent` toward `direct`.
- An anonymised ingestion or data-contract example → R9 and R10 move from `unclear` toward `direct`.
- Your confirmed location and pay floor → R1 and R2 close, and the status can move to `go` or `no_go`.
- A permitted re-run of target 1 (the posting and employer check) → RR1 closes.

I can also write this assessment to a `tuesday-dossier.md` if you want to keep it or hand it to the mock-interview module later.

Three questions, one for each open item:

Q1 (R1): Are you based in the US, and could you work from there or from Denver?

Q2 (R2): What is the lowest base salary you would accept for this role?

Q3 (R9, R10): Have you built ingestion from an app or CRM source, or a data contract that analysts relied on? What did you own, and what did it look like?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.