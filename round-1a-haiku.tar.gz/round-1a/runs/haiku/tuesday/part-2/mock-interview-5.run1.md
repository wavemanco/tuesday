I'll save the pack to the scratchpad and then summarise it here.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-5-denied-10f85fe8/c444b73e-4329-4adb-a80d-aaa385acb8e9/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it as a panel round, with Deepa as hiring manager and Ross as commercial director.

**Company research didn't run.** Web search was refused in this session, so the pack has no Kelverton values, loop structure or strategy. Anything about rail and operators is labelled `[generic]`, a sector pattern rather than a claim about Kelverton. The internal market report is the strongest fix: paste its headline points and I'll rebuild the POV and the commercial bank around it.

**The POV.** I'd build it on three points, each with a concession:
- **Build around the operator's performance measure.** Punctuality is set partly by track access and Network Rail, so you can't promise to move it alone. Lead with the planning work, but don't claim you know how timetables are built.
- **Start with the planning side, not only the IT buyer.** Planners and the commercial team may be different buyers. Concede that you haven't sold into rail and the cycle may be long.
- **Close on what changes in the operator's week.** Fewer disrupted hours, a clearer planner-to-operations handoff, and a forecastable cost for their commercial director. Anti-pick: don't chase every operator at once, and don't build a bespoke integration for each one.

**Where the panel will press.** The three hardest questions are:
- "You've never sold into rail. Why would an operator trust a payments person with its timetable?" Hold on the planning work, then concede the learning curve.
- "You ran partners, not a quota." Say plainly that you haven't carried a direct quota, then go to how you'd set and track the number.
- "Your £4M is influenced revenue. How much would have happened without you?" You need to say how it was counted. If you can't repeat the method, say so.

Don't say "I've sold into rail", "I know how operators run timetables", "I generated £4M", or "I built the channel". The pack lists these as prohibited, with the honest wording for each.

**Prep order, about 4 hours:** the POV first (about 75 minutes, spoken and timed to 12–13 minutes), then the three Skeptic questions aloud, then the commercial drills on paper.

Three things would sharpen it:
1. Does the role's JD exist? If you have it, paste it and the requirement rows become sourced.
2. In your transport consulting, were your clients operators, authorities, or both? That decides how you can answer the "operator world" question honestly.
3. Can you paste the market report's headline points? I'd use them to test the consensus answer you're differentiating from.

I can play the Skeptic on B1, the question the pack names as highest-ROI prep, if you want a live rehearsal. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Round:** second-round panel, 60 minutes. First 15 minutes is a spoken POV (no slides) on operator partnerships over 18 months, landing on what it means for the operators. Remaining 45 minutes is Q&A, with commercials pushed hard.
**Panel:** Deepa (VP Partnerships, future manager); Ross (Commercial Director).
**Mode:** session. **Research tier:** L1, with no search run (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is scored: **VAL** values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem. Guidance is scaffolding, not a script. Answer slots are instructions for the interview, not questions to answer here.

## Prep triage (about 4 hours)

1. **About 75 min: write the POV in your own words.** Three points, each with its concession, and a close for operators. Speak it aloud at 12 to 13 minutes, then cut. Do not memorise it word for word.
2. **About 45 min: rehearse B1, B2 and B3 aloud.** These are the Skeptic questions on rail, quota and the £4M figure. Hold, then concede plainly.
3. **About 60 min: commercials.** Work C1, D1 and D3 on paper. Build one operator deal sketch over three years, and say which numbers you do not yet know.
4. **About 30 min: reverse questions.** Pick five, and say why each one lands.

Everything else is insurance.

## Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa | Live problem on operator sequencing and the 18-month plan | High. A hiring manager buying capability for a new territory, with the POV as the setup | Clarify the operator segment first, then structure. Name your first two assumptions |
| Skeptic | Deepa | Why would an operator trust a rail outsider; why not someone who has sold into rail | High. The recruiter's own brief and your background both put rail sales and the quota question in front of her | Hold your strongest adjacent evidence, then concede the gap in the same breath |
| Pressure | Ross | Interrupts, time-boxes the commercial answer, asks for a number | High. The recruiter said Ross will push on commercials | Pause, restate the commercial question, hold a position through two follow-ups, then concede what you do not know |
| Data-Driven Prober | Ross | Asks how the 6-to-40 and the £4M were counted, and what share was yours | Medium to high. Headline numbers from the CV are the first place a commercial director looks | Say how each figure was counted, in your own words, and name the assumption you would defend least |
| Conversational | Neither | Opener; the POV itself is the warm-up | Low weight. No public profile was researched, so there is no basis to tilt it | Do not let the opener become unscored |

**Weights.** Deepa's bank carries 8 questions, Ross's carries 10, reflecting that the recruiter named Ross's commercial push. Each member's top two relationship priors are blended: Deepa is hiring manager, so Case and Skeptic. Ross is executive, so Case (commercial) and Pressure.

## Reading the interviewer

Not built. No public footprint was researched, because web search was not permitted in this session. Upgrade menu covers it.

## Fit snapshot

The recruiter's own sentences, quoted from your message, are the requirements. No JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email, as quoted by you) | "running the ISV channel" (your message), "took it from 6 partners to 40" (your message) | medium | [grounded] | transferability | Your material shows an ISV channel, not operator partnerships. Bridge at its own scope: "For four years I ran the ISV channel, and I took it from 6 partners to 40." Your 18-month operator view is a plan, and should be said as one |
| F2 | "what it means for the operators themselves" (recruiter email, as quoted by you) | "bus and light rail network planning" (your message), "so I know the operator world from the other side" (your message) | low | [inferred] | transferability | The planning work is real, but the material does not say which side paid for it, or whether the operators were the clients. Answer slot: say who the planning clients were and what you delivered for them, in your own words. If the operators were not your clients, say so, and say what the planning work taught you about how operators decide |
| F3 | "Ross will push on commercials" (recruiter email, as quoted by you) | "never carried a direct quota" (your message), "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Influenced revenue is adjacent, not quota. Plain acknowledgment: "I haven't carried a direct quota." Then the £4M at its own scope, as influenced revenue |
| F4 | sells "scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | transferability | Stated negative, so it may be given back: "I haven't sold into rail." Then the adjacent sales work at its own scope, with the ramp you would need stated as a plan |
| F5 | "roughly £4M of influenced revenue" (your message) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | none | The figure reaches the commercial ask in role terms. Caveat: it is your own figure, with limited inspectable proof, so expect a probe on how it was counted |
| F6 | sells "scheduling software" into rail (your message) | none given | none | [inferred] | discovery | The material is silent on product knowledge of scheduling software. Answer slot: say what you already know about how a scheduling tool is used by an operator's planners, and what you would need to learn first. If you have no such knowledge, say so plainly |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or "I know rail sales" | Inflated form of F4 and F2 | "I haven't sold into rail." Then the adjacent work at its own scope |
| "I know how operators run their timetables" | Inflated form of F2 | "bus and light rail network planning," at its own scope. Your material does not show the operator side of that work |
| "I generated £4M" or "I drove £4M" | Inflated form of F5 | "roughly £4M of influenced revenue." The limit is the pack's own observation: the material says influenced, not sourced |
| "I hit quota" or "I carried a number" | Negative stated by you, F3 | "I haven't carried a direct quota." No slot |
| "I built the ISV channel" | Inflated form of F1 | "running the ISV channel," and "took it from 6 partners to 40" |

## Graded deliverable: the 15-minute POV

Recruiter-declared. Build from the fit snapshot. Your material supports only F1, F2, F3 and F5 as grounded facts; everything about rail and operators in this section is `[generic]`, a pattern in the sector, not a claim about Kelverton. Treat each point as a position to test in the room, and not as a fact you have checked.

**Consensus answer (the one most candidates will give):** operators need better disruption recovery and smarter scheduling, so partner with them on data and software. Differentiate from it, do not recite it.

**Thesis 1: build around the operator's performance measure, not the feature list.** `[generic]` Operators are judged on punctuality and cancellations, and those are set by track access and Network Rail as well as by the operator. Concession: a partnership cannot move punctuality alone, and I would not promise it can. Your F2 planning work is the evidence to lead with, as a limit: "bus and light rail network planning." Do not say you know how operators' timetables are built.

**Thesis 2: start with the planning side, not only the IT buyer.** `[generic]` Scheduling software is used by planners, and the planners and the commercial team may not be the same buyer. Your F1 channel lesson is that partners bring deals when the partner's own customer gains from them. Concession: I have not sold into rail, and the buying cycle may be long. I would time it in my first 90 days, not assume it.

**Thesis 3 (the operator close): what changes in the operator's week.** `[generic]` The operator gets fewer disrupted hours and a clearer handoff between planners and operations, and its commercial director gets a cost they can forecast. Anti-pick: I would not chase every operator at once, nor build a bespoke integration per operator. Concession: I would be wrong if operators will not share the data the value depends on.

**Close:** "For an operator, the first thing that changes is ..." Say it in one sentence, and say what the operator sees on Monday.

## Question banks

### Deepa: Case/Strategist (5 questions, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you sequence the first six months: which operators first, and why?" | CASE | [generic] | Clarify the operator segment, then structure around the first two assumptions. Name what you would test first | The live problem her 18-month question sets up. No claim about your past |
| A2 | "What would you stop doing in partnerships to fund this?" | CASE | [generic] | Name one thing you would stop, and the cost of stopping it. Do not invent a current programme | Tests prioritisation and what the role gives up |
| A3 | "An operator's ops director says the scheduling tool is nice to have during disruption. How do you prove it is not?" | CASE | [generic] | Name the measure you would ask them to share, and the one you could not get. A stated limit is stronger than a promise | The objection is live, not a fact about this operator |
| A4 | "What does an operator partnership look like when the operator has no budget for new software?" | CO | [generic] | Name the commercial option you would test first, such as a pilot inside an existing contract, and say what you do not know about their budget cycle | Tests whether you think at the operator's altitude |
| A5 | "Which of your 40 partners mattered most to the revenue, and why?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer in the 6-to-40 terms you used. Answer slot: if you can say which partners drove the figure, name them and how you knew. If you cannot, say so plainly | Premised on your own figure; the answer must stay at the scope of the number |

### Deepa: Skeptic (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 (highest ROI) | "You have never sold into rail. Why would an operator trust a payments person with its timetable?" | JD | [grounded] "Never sold into rail specifically" (your message); "so I know the operator world from the other side" (your message) | Hold: "I haven't sold into rail." Then the planning work at its own scope: "bus and light rail network planning." Hold through two follow-ups by returning to what you have done, not by adding to it. Concede the domain learning curve plainly and state your ramp plan | F4 is the most likely objection. The hold stays inside your quotes; the limit is that the planning work was not the sale |
| B2 | "You ran partners, not a quota. Why should we believe you can own a number?" | JD | [grounded] "never carried a direct quota" (your message) | Plain acknowledgment: "I haven't carried a direct quota." Then how you would set the number, and the leading measures you would track first | F3 is the second likeliest objection. Concede, then move to the plan, not to a claim |
| B3 | "Your £4M is influenced revenue. How much of it would have happened without you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Defend the number: how it was counted, which assumption you would defend least, and which part was yours. Answer slot: if you can say how it was counted, do; if you cannot, say so plainly | F5's caveat; a figure raises a defend-the-number slot. Do not explain a method you cannot repeat |

### Ross: Pressure (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have 18 months and no quota. What number would you commit to, and what happens to you if you miss it?" | JD | [grounded] "never carried a direct quota" (your message) | Name a leading measure you can defend, and say what you would not promise yet. Do not invent a target figure | Pressure on the quota gap. Hold the plan, concede the number |
| C2 | "Sixty seconds: why you over someone who has sold to operators for ten years?" | JD | [grounded] "9 years partnerships" (your message); "bus and light rail network planning" (your message) | Hold the operator-side view and the partner-scale record, at their own scope. Concede the rail sales experience first, then the advantage you think it gives | Pressure on the fit question, held then conceded |
| C3 | "Operators are paid through management contracts. Who pays for your partnership, and why would they?" | CO | [generic] | Name the buyer you would test, and say what you do not know about how the operator is funded. Answer slot: if you have seen an operator's funding terms, say which ones, and if not, say so plainly | Commercial pressure with no claim about your past |
| C4 | "What would you change about how we price a partner-led deal to an operator?" | CO | [generic] | Name one pricing lever and what it costs the operator. Say what you would need to see first | Tests commercial thinking, not recall |

### Ross: Prober / commercial (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Show me the unit economics of one operator deal over three years." | CASE | [generic] | Sketch the shape: revenue, partner margin, support cost, ramp. Say which three numbers you do not know. Do not produce figures you cannot source | A live commercial problem; the honest answer is a model with named unknowns |
| D2 | "Your channel went from 6 to 40. How many of the 40 were live and earning at month 12?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say how a partner was counted as live, and what the count was. If you do not know how many were live, say so plainly | Defend the number; this is the question the 6-to-40 figure invites |
| D3 | "Where does the first £1m of operator revenue come from in year one?" | CASE | [generic] | Name the first two sources you would test, and the one you would drop. Say what you would not claim until you have run a pilot | Commercial pressure in year one, with no past claim |

## Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months | POV build; A1, A2 |
| What it means for the operators | POV close; A3, A4, B1 |
| Commercials (Ross) | C1, C3, C4, D1, D2, D3 |
| Sell into rail (implied by the brief) | B1, B2 |
| Sells scheduling software to train operating companies | F6 (answer slot); no separate question, covered by A3 and B1 |

## Reverse questions

Five, each with why it lands.

1. "Which operator relationship would you most want us to win first, and why?" Why it lands: it shows you are thinking about the first customer, not the whole market.
2. "What has an operator bought from a partner in the last two years, and what did it fail to do?" Why it lands: it asks for their hardest lesson, which only someone inside the business can give.
3. "Does your product get into an operator's planning process through the planners or through IT?" Why it lands: it shows you know there may be two buyers. It also tests your planning background.
4. Ross: "Where has the commercial model been hardest to get past an operator?" Why it lands: it turns the commercial push into a shared problem.
5. Deepa: "What would make you say the first year went well?" Why it lands: it gives you the success measure she will judge you on.

## Sources

- **Provided documents:** your message to me, including the recruiter's email as you quoted it. The internal market report was not pasted into this conversation, so it is not used here.
- **Searches attempted (all refused, because web search was not permitted in this session):**
  - "Kelverton Rail rail technology scheduling software train operating companies": refused
  - "Senior Partnerships Manager Kelverton Rail job description": refused

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fixed the values cheat sheet; none was built because no values-style round is detected |
| 2. `Kelverton Rail interview process` | unavailable | Would have confirmed the loop structure and the round's format |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have fed the CO bank and the POV's sector grounding. The market report would fix this if pasted |
| 4. `Deepa` and `Ross`, with Kelverton Rail | unavailable | Would have built the interviewer read and tuned their persona weights |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have given a JD to score the fit snapshot against |

## Upgrade menu

- The JD text → the requirement rows become `[grounded]` and the JD-tagged questions get their source
- Web search permission, or the market report pasted → the POV's sector claims move from `[generic]` to `[grounded]`, and the CO bank is tuned to current strategy
- The client base of your transport consulting, operators or authorities → F2 resolves, and B1's planning answer is written against it
- Deepa's and Ross's public profiles, or their names with the company → the interviewer read and persona weights
