Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-4-denied-312f5155/f8d7ca50-9b06-48c2-b36c-4fda0b3aee60/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`.

Two things to know before you rehearse:

- **The dossier is three months old** (dated 14 August; today is 17 November). The posting may have changed since then.
- **Web search was refused**, so I couldn't check Quartzline's values, interview process or current strategy. The pack uses only the dossier.

The highest-ROI prep is question A1: "You've never held the PM title or owned a roadmap. Why should we hire you into one?" It's the objection the dossier names. The pack gives you a hold-then-concede structure for it, with the concession worded before it's asked for. The pack also covers the squad-authority question (A2), Agile (A4, an answer slot because nothing in your material speaks to it), and the adoption-metrics questions (C1, B2). It holds five reverse questions drawn from the dossier's employer questions and risks.

The pack never claims PM title, roadmap ownership, or squad prioritization. Each of those is either a plain "I haven't" or sits in the prohibited list.

Drill: I can play the Skeptic on A1 and give feedback against its guidance cell.

Dossier: I can write a `tuesday-dossier.md` with a `pack_feedback` section recording any gaps this prep exposes.

Word: I can convert the pack to .docx if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager. Built from `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). Web search was refused, so the pack rests on the dossier alone and carries no current company facts.

How to use: personas describe how a question is asked; types describe what is scored. JD = role and requirements, EXP = your past work under scrutiny, CASE = a live problem, CO = company knowledge (none in this pack, since research did not run), VAL = values (not detected). Guidance is scaffolding, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence 1) | high | [grounded] | transferability | The material shows integration leadership on the vendor's REST APIs, end to end. It does not show product management or roadmap work, so the bridge stays adjacent and never becomes the PM title. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Limit, as the pack's own observation: the material shows no roadmap or prioritization work. |
| F2 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence 1) | high | [grounded] | transferability | The quote is integrating an API someone else built, not shipping one. The dossier does not list R2 as weak, so this reading is the pack's own. Say the integrations at their own scope and do not describe them as shipping a platform. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier, verified_candidate_evidence 2) | high | [grounded] | presentation | Reword only: "I wrote the integration playbook my team uses." Schemas do not appear in the material. Answer slot: if you wrote or reviewed API schemas, say which and how; if you did not, say so and name the document you would write first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier, verified_candidate_evidence 3) | medium | [grounded] | presentation | Say the sessions in those terms: quarterly, client evidence into product. Caveat, named: confirmed, with limited inspectable proof. Expect a probe. Answer slot: if engineering or sales took part in those sessions, say how; if not, say so. |
| F5 | Owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas, R1 sub-claim, acknowledge_gap) | none given | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap area: "I haven't owned a product roadmap." Then the ramp plan, stated as a plan and never as past work. |
| F6 | "Agile delivery experience" (dossier role_profile R5) | none given | low | [grounded] | discovery | Clarify strategy: no verified entry speaks to this requirement, so the answer is a slot. Answer slot: if you ran planning or sprint cadence with an engineering team, say what that was; if you worked to another delivery rhythm, or not in this way, say so and say what you would want to confirm about how this team defines it. |

## Prohibited claims

Absolute. No guidance cell below asserts, softens or implies any entry here.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims (sourced) | "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap (sourced) | "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims (sourced) | "I haven't set prioritization for an engineering squad." No slot. |
| Owned the partner API roadmap | Inflated form of F1 and F5, built locally | F1's quote at its own scope. The limit is the pack's observation: the material shows integration work, not roadmap ownership. |
| Shipped an API platform product | Inflated form of F2, built locally | F2's quote at its own scope. The limit is the pack's observation: the material shows integrating an API, not shipping one. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (weight: top, 5 questions) | Quiet, persistent probing of the gaps: the title, the roadmap, the day-one weakness | Highest. The hiring-manager prior is Case plus Skeptic. The dossier names an objection built on F1 and F5, and R5 is unevidenced. | Rehearse the named objection until it is boring. Bridge from quoted integration work only, name the limit, give a ramp plan. |
| B. Case/Strategist (weight: 4 questions) | Live problems on the partner API roadmap | High. The hiring-manager prior is Case, and the dossier's open decision-authority and adoption-baseline questions are exactly what a case would expose. | Clarify, then objective, segmentation, approach, metrics, risks. Say what you need to know first. |
| C. Data-Driven Prober (weight: 4 questions) | Asks how a figure was counted and what the metric assumes | Medium-high. The dossier lists adoption metrics as a responsibility with no baseline, and the 30+ integration figure invites a count probe. | Name the weakest assumption before they do. Say plainly what you do not know. |
| D. Pressure (weight: 2 questions) | Time-boxed challenge on fit and motive | Medium-low for a hiring manager. Kept at two questions for the 45-minute window. | Pause, restate, hold through two follow-ups, then concede the real gap. |
| E. Conversational (weight: 3 questions) | Open opener and an easy question about the JD's tools | Medium. Casual register, still scored. | Keep a 90-second arc ready. Treat the tools question as scored. |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the job?" | JD | [grounded] dossier likely_interviewer_objections. Its negatives are sourced to dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap). Bridge clause rests on "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence 1) | Hold 1: "I haven't held the product manager title, and I haven't owned a roadmap. What I have done is lead 30+ end-to-end integrations of the vendor's REST APIs, from scoping to go-live, and the part that carries over is client-facing scoping and requirements." Hold 2, when pressed on prioritization: return to the scope of those integrations and say nothing more. Concede: "I haven't set prioritization for an engineering squad. That is what I would learn first, and this is my plan for the first 90 days." | The dossier named this as the highest-ROI objection. It maps to F1 and F5, so it gets the deepest rehearsal: three follow-up levels, with the concession worded before it is asked for. |
| A2 | "Which roadmap decisions would you make on your own here?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities). Slot premise rests on the same raising source. | Answer slot: if you can name a roadmap decision that was yours before, say it. If none was, say so plainly, then name the decisions you would want to confirm with the two squad leads. | The dossier's unresolved decision-authority risk. The second branch allows that you have never made such a decision. |
| A3 | "Where would you be weakest on day one?" | JD | [grounded] dossier uncertain_or_weak_areas (roadmap ownership, acknowledge_gap; Agile, clarify) | Name the two weak areas in the dossier's own terms: roadmap ownership, which you haven't held, and Agile delivery inside a product org, which you would need to confirm. Then give the ramp plan. | Shows calibrated candor, the Skeptic's scoring target. No bridge is coached on roadmap ownership. |
| A4 | "What have you actually run in Agile delivery inside a product org?" | JD | [inferred] R5 raised by the JD, with no verified entry touching it | Clarify form: quote no evidence, since none speaks to R5. Answer slot: if you ran planning or sprint cadence with an engineering team, say what it was. If you worked another way, or not in this way, say so and say what you would want to confirm about how this team defines it. | F6 is discovery with no verified entry, so the slot is the honest answer. |
| A5 | "You led integrations on the client side of the vendor's APIs. What would partner discovery change about what you already know?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence 1) | State the integration side in your own words. Concede what discovery would teach you: the partners' needs, which you have not gathered. Do not claim discovery you have not done. | Covers R2 and the role's "Run discovery with integration partners" responsibility. It probes the relationship axis: you were the vendor-side integrator, not the partner. |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would prioritize the partner API roadmap for the next two quarters. What do you need to know first?" | CASE | [generic] pattern for a live problem, with no claim about your past | Clarify, then objective, segmentation by partner type, approach, metrics, risks. Ask first for the adoption baseline and who holds decision rights with the two squad leads, since the dossier records both as unknown. | A live problem from the role's own roadmap responsibility. It asks no past claim. |
| B2 | "Partner API adoption dropped 20% last quarter. Diagnose it." | CASE | [generic] pattern for a live problem | Clarify the metric's definition first. Segment the drop by partner, then separate supply-side changes from demand-side ones. Say that you would confirm the baseline before drawing conclusions. | Tests the structure the Case persona scores. The adoption baseline is an unknown in the dossier. |
| B3 | "A partner asks for a feature that a squad has already scheduled. How do you decide?" | CASE | [generic] pattern for a live problem | Name the decision rights you would check first, then propose a principle for the trade-off. Do not claim authority you have not held. | Targets the squad-authority unknown and R4's engineering stakeholder. |
| B4 | "How would you know a new partner integration had gone well after 90 days?" | CASE | [generic] pattern for a live problem | Name two or three leading indicators and what each would show. Note that the current adoption baseline is not yet known to you. | The adoption-metrics requirement, asked as a case. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which metric would you use for partner API adoption, and which assumption behind it would you defend least?" | JD | [generic] stem for a metric probe | Name the metric and its weakest assumption before they do. If you do not know how adoption is counted today, say so plainly. | The dossier lists adoption metrics as a named responsibility with no stated baseline. |
| C2 | "Walk me through how you counted the 30 integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence 1) | Defend-the-number slot. Answer slot: say in your own words how you counted an integration as done, the assumption you would defend least, and which of those integrations were yours to lead. If you did not set the count, say so. | The figure is the dossier's, so its method, sensitivity and your share are the slots. The pack supplies no counting method. |
| C3 | "What is in your integration playbook that a new integration lead would get wrong without?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier, verified_candidate_evidence 2) | Name one or two things the playbook prevents, in your own words. If you cannot name one, say so and describe what it covers. | Tests whether the playbook is a real artifact. It is the high-confidence inspectable proof in the dossier. |
| C4 | "What changed in product because of the quarterly roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier, verified_candidate_evidence 3) | Medium confidence, so volunteer the limit before they find it. Answer slot: if you tracked what changed, say so and name it. If you did not track it, say so plainly and say what you could show. | F4 is medium with a named probe. Volunteering the limit beats having it extracted. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] dossier likely_interviewer_objections and the quote in A1 | Hold the integration-to-product argument through two follow-ups. Concede the title and the roadmap gap plainly, without folding on the integration record. | Stress-tests the hold-then-concede structure for A1. |
| D2 | "That's a lot of integration. How much of the product thinking was actually yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier, verified_candidate_evidence 1) | Pause and restate the question. Name the stages from the quote that were yours to lead. Say what was not yours to decide, in your own words. | Attribution honesty under pressure. Claims stay at the quote's scope. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | EXP | [grounded] the three verified entries in the fit snapshot (F1, F3, F4) | A 90-second arc: integrations, then the playbook, then the roadmap-input sessions, then why product now in your own words. | An easy opener that is still scored. Keep the arc to what the three entries carry. |
| E2 | "What are you playing with in the API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier, verified_candidate_evidence 2) | Name the docs and the playbook you actually worked in. If you have not worked with schemas, say so plainly. | Covers R3, a casual version of the JD's tools question. |
| E3 | "What would you want to learn in your first 90 days?" | JD | [generic] stem about a ramp | Name the two dossier unknowns: decision authority with the squad leads, and the current adoption baseline. Give the ramp plan. | A ramp question that the acknowledge_gap and unknowns rows already support. |

### Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| R1, 3+ years product management | A1, A2, A3, D1 | Covered. |
| R2, shipped API or platform products | A5, C2 | Covered by the limit, not by a shipping story. No shipping quote exists. |
| R3, technical fluency: API docs, schemas | C3, E2 | Covered. Schemas are an answer slot in F3. |
| R4, stakeholder management | B3, C4 | Covered. Sales is not evidenced in the material. |
| R5, Agile delivery | A4 | Covered by a clarify slot. No verified entry exists. |

## Reverse questions

Each one comes from the dossier's employer questions or risks.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it is the dossier's first employer question and the decision-authority risk. It reads as diligence.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the adoption baseline is an unknown in the dossier. Asking it shows you need the answer before you accept.
3. "What did the person in this role own in the first 90 days?" Why it lands: it sets the ramp against the role's real scope, which the dossier leaves open.
4. "How would partner discovery be split between this role and the integration team?" Why it lands: discovery with partners is a named responsibility, and the integration team already knows the partners' use. It tests the seam without claiming the seam.
5. "Where does the partner API roadmap conflict with the two squads' own plans today?" Why it lands: it asks about the real tension behind R4 and the squad-authority risk.

## Delivery coaching

Not included. No working-style assessment was provided.

## Sources

- Provided document: `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). Consumed: role_profile (requirement text as supplied-JD lines; its unknowns and inferred outcomes not used as candidate facts), and handoff_to_mock_interview in full (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims). No evidence_map or risk_register is present in this dossier.
- The dossier is three months old. Its requirements and unknowns may have changed in the live posting.
- Calls sent and refused: "Quartzline values"; "Quartzline Product Manager Platform APIs interview process". Both refused: search permission not granted.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet, section 10, if a values round were detected. Calls refused. |
| 2. `Quartzline interview process Product Manager` | unavailable | Loop structure and persona weights. Calls refused. |
| 3. `Quartzline strategy` / recent news | unavailable | CO bank, and a check that the August dossier still matches the live posting. No call sent: the host refused the search. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given. |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the requirement list and the JD-tagged questions. |

## Upgrade menu

- Search access → rows 1 to 3 move from unavailable to yes, which adds current values, interview-process facts and strategy for CO questions. It also checks the August dossier against the live posting. A deep-research pass (L2, offered once) would add four more targets, with up to 6 more searches and 2 fetches.
- The current posting text → checks that R1 to R5 still read the same as the dossier's role_profile.
- Your CV → puts your own sentences in the fit snapshot in place of the dossier's entries, so the evidence is inspectable.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their career path.
- The recruiter's note on focus areas → a coverage check for Thursday.
