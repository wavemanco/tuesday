Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-8-denied-ced42172/61044467-5dfd-44a1-a1ae-339e5fca80ea/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it for all three rounds, since you gave their order and lengths, and I used only what you sent me. I ran no web searches.

The gap that matters most is the contact centre. The JD asks you to own complaints "across branches and the contact centre," and you've never worked in one. The Head of Member Services will probably test that first, so the pack gives it the deepest rehearsal (question B1). Presenting above regional level is the second-biggest gap, and the pack handles it the same way: say it plainly, then give a plan.

Two things to do before the 26th:
- Send me your CV if you have one. Your own sentences would replace the quotes I took from your message, and I'd rather quote your CV than my summary of it.
- Tell me the names of the Head of Member Services and the two branch managers when you know them. That lets me tailor the reverse questions and the persona weights.

Offers, one line each:
- Want to rehearse? I can play the Skeptic on B1, the question the pack names as its highest-ROI prep.
- I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union
**Candidate:** Dara (pronouns not stated; this pack uses they/them)
**Interviewers:** Not yet assigned. Round 1 is with the recruiter. Round 2 is with the Head of Member Services, who would be Dara's manager. Round 3 is a panel of two branch managers.
**Rounds:** 26 November 2026. Recruiter screen (30 min), behavioural round (45 min), panel with a 20-minute complaint-escalation case (60 min). The panel also scores against the four values.
**Mode:** Loop. The recruiter's email names the three rounds, so the pack runs one shared fit snapshot and one mini-pack per round.
**Pack date:** 17 November 2026. First version, so there is no changelog.

## How to use and type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values and behaviour | Whether past behaviour shows the published values |
| EXP | Experience deep-dive | Whether what you say about your past holds up under questions |
| JD | Role and JD | Whether you can do the listed job, including its gaps |
| CO | Company and strategy | Whether you know where Ashgrove is heading |
| CASE | Live problem | How you structure a problem from the role |

Answer slots are instructions for the interview. They ask nothing in this conversation. Each one gives an honest branch for when the practice was not yours or did not happen.

Dropped sections: prep triage (prep time was not given), interviewer read (no names yet), and delivery coaching (no assessment was provided).

## Fit snapshot (shared across all rounds)

Requirements are the JD's own words. Evidence is quoted from your message, which is the only account of your background in this conversation. No requirement is a gate: they are experience and skill terms, not licences, credentials or fixed terms (`evidence-conventions.md` §3). Each row's gap type follows its evidence cell.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | Your message says retail banking, not customer operations. Bridge in your own words: "For six years I've worked in retail banking, and for the last three I was a branch supervisor." Limit, as this pack's observation: your material shows branch work and no time in a contact centre or a back-office operations team. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote is one branch's log. Words you can say: "I handled the branch's formal complaints log." Limit, as this pack's observation: the material shows one log, not the whole process or several branches. Answer slot: if any step beyond the log was yours to set, say which and how you decided. If none was, or it was not yours, say so plainly and stay with the log. |
| F3 | "...and the contact centre" (JD, contact-centre part of the line above) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated absence, so the words are yours: "I have never worked in a contact centre." Then say how you would learn it, as a plan and never as a past. |
| F4 | "report monthly on complaint volumes and resolution times" (JD, volumes part) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches monthly complaints reporting in other words. Bridge only with that quote: "I built the monthly complaints spreadsheet our regional manager uses." Add no figures and no tools. |
| F5 | "report monthly on complaint volumes and resolution times" (JD, resolution-times part) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] (derived from F4's quote) | discovery | Your material does not say the spreadsheet recorded resolution times. Answer slot: if it did record them, say how you counted them, in your own words. If it did not, say so plainly and say what it did record. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Words you can say: "I trained new tellers on our escalation script." Limit, as this pack's observation: training tellers and your own time as a supervisor are not the same as coaching other supervisors. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with anyone building a digital channel, say who and what changed. If you have not, say so plainly, then say how you would find out where members get stuck. |
| F8 | "experience handling regulated complaints" (JD) | "handled the branch's formal complaints log" (your message) | low | [inferred] (derived from F2's quote) | discovery | Your material shows formal complaints but not the rules or deadlines they ran under. Answer slot: if the complaints you handled ran to a regulator's rules or a response deadline, say which and how you applied them. If they did not, say so plainly and describe how the log was run. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your stated absence, so the words are yours: "I have never presented to anyone above regional level." Then say how you would learn to present to senior leaders, as a plan and never as a past. |
| F10 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your message names a spreadsheet, not the software or the functions you used. Bridge only with the quote. Answer slot: if it was built in Excel, say which parts you built yourself and which you inherited. If it was not, say so plainly and say what you used. |

## Prohibited claims (built locally from the fit snapshot)

No answer, hold, bridge, reverse question or rationale in this pack asserts any entry below. Inflated-form entries never get a first-person negative. Sourced entries get only their plain acknowledgment.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the end-to-end complaints process across branches and the contact centre | Inflated form of F2 and F3 | "I handled the branch's formal complaints log." Limit, as this pack's observation: your material shows one branch's log. |
| Has worked in a contact centre | Negative you stated (F3) | "I have never worked in a contact centre." No slot. |
| Has presented to senior leaders | Negative you stated (F9) | "I have never presented to anyone above regional level." No slot. |
| Tracks or reports resolution times monthly | Inflated form of F4 and F5 | "I built the monthly complaints spreadsheet our regional manager uses." Limit, as this pack's observation: your material does not say it recorded resolution times. |
| Built Excel models, dashboards or senior-level reports | Inflated form of F10 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Coached branch supervisors | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F8 | "I handled the branch's formal complaints log." |

## Sources and target accounting

Provided material: the four values as you pasted them from ashgrovecu.org/about/values (copied 17 November 2026); the recruiter's email on the process; your summary of Ashgrove's July 2026 strategy brief (the brief itself is not in this conversation, so the pack uses only the points you gave); the JD in your message; your background in your message. No CV was provided.

Research tier: L0, no searches. No search or fetch was sent, so the budget was not spent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove values` | skipped | The pasted values text fixes the values cheat sheet, so no search was needed. |
| 2. `Ashgrove interview process` | skipped | The recruiter's email is a loop source. It names the three rounds, their lengths and the values scoring, which fixes the loop and the persona weights. |
| 3. `Ashgrove strategy` / recent news | skipped | Your summary of the July 2026 brief fixes the grounding points. The brief itself was not read. |
| 4. Interviewer footprint | n/a | No interviewer names were given, so there was no query to form. |
| 5. Representative JD | skipped | The JD in your message fixes the fit snapshot and the JD-tagged questions. |

## Grounding brief (from your summary of the July 2026 brief)

Current language, using the employer's own framing:

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

No question in this pack presupposes the hub plan, because the JD does not raise it. If an interviewer raises it, answer from your own view and say only what you know.

## Persona weights by round

Relationship priors set the starting weights. The loop (the three named rounds) and the recruiter's note on behavioural focus adjust them.

| Round | Persona | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Recruiter screen (30 min) | Conversational (heavy); light Skeptic | Logistics and knockout checks, in a friendly register. The risk is treating it as unscored. | Rehearse the 90-second arc. Answer logistics in your own terms. |
| B. Head of Member Services (45 min) | Skeptic (heavy); Values/Behavioural; Data-Driven Prober; Case | Manager-level round, mostly behavioural, so VAL and EXP lead. The manager is buying capability and testing the gaps. | Hold the quotes. Say the stated absences plainly, then the plan. |
| C. Panel of two branch managers (60 min) | Values/Behavioural (scoring); Peer Evaluator; Case (20 min); Pressure | The panel scores the four values. Branch managers are peers of the seam, so they probe the seams between branches and the contact centre. | Map each value to a quoted story or an honest branch. Structure the case before answering. |

## Values cheat sheet

A values round is detected: the recruiter's email says the panel scores against the four values. The working meanings below paraphrase the official text.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quote carries a member-side decision. Scaffold: pick a decision where the member's view changed the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log (F2). |
| Plain Words | If a member needs it explained twice, it was written wrong. | The nearest quote is "trained new tellers on our escalation script" (F6), which does not say the script was plain. Scaffold: pick a time you changed an explanation so no one needed it twice. If none comes to mind, say so plainly, then say what you taught from the script and how you checked it landed. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quote carries a town or local context. Scaffold: pick a decision where local context changed the answer a number would have given. If none comes to mind, say so plainly, then say what you would ask about the town first. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F2's quote says "handled", not "solved". Scaffold: pick a complaint you held until it was resolved and say what closed it. If you handed one on, say when and to whom. If none comes to mind, say so plainly, then say what you would do with a complaint that stalls. |

## Round A: Recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far in two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | A 90-second arc in the order of the quotes: six years in retail banking, the last three as a supervisor, the complaints log, then training tellers. Say each beat in your own words. Add nothing. | Opener. Uses only F1, F2 and F6. |
| A2 | "How many years have you got in financial-services customer operations?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor" | Answer with the quote in your own words: six years in retail banking, the last three as a supervisor. Do not adopt "customer operations" as a description of your own work. | Knockout check on F1. The years are a term the JD states, not a gate. |
| A3 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I have never worked in a contact centre." Then a plan for learning it, said as a plan. | F3 is a headline JD line and a knockout check. |
| A4 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give your own figure in your own words, or ask what the band is before naming one. Do not give a past salary unless you choose to. | Pay is a logistics question, so the answer is yours alone. |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. | Notice is a logistics question. |
| A6 | "Where can you work from, and how far would you travel?" | JD | [generic] | Logistics slot: state the places and days you can work, in your own terms. | Location is asked as logistics. Ashgrove's posting names no location rule. |
| A7 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. Your material gives no reason, so the reason is yours to say. | The screen tests motivation consistency against your reason for leaving. |
| A8 | "Why member experience, and why Ashgrove?" | VAL | [grounded] "we decide from the member's side of the counter" (published Ashgrove value; the value is the raising source, not a claim about you) | Name one published value you can speak to, and say why from your own six years. If the why is not clear to you yet, say so plainly and say what would make it clear. | Motivation consistency, asked at the screen. |

Reverse questions for Round A (at least five):

- "What would make the first six months in this role clearly successful?" Why it lands: it sets up the Round B conversation with the Head of Member Services.
- "How will the 40% digital target in the 2026 strategy affect member complaints?" Why it lands: it shows you read the published brief, and it is the seam the panel will care about.
- "Who would I be working with in the branches first?" Why it lands: it asks about the people, which is what a manager weighs.
- "What does the panel score most heavily?" Why it lands: it shows you are preparing to be scored.
- "What happens after the panel?" Why it lands: it shows you are planning ahead.

## Round B: Head of Member Services (45 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role owns complaints across the contact centre as well as the branches. How would you handle the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" | Deepest rehearsal. Level one: "I have never worked in a contact centre." Level two, follow-up "So how would you run it?": a plan only, such as asking the contact-centre leads how complaints are routed, shadowing a shift and reading their log. Level three, follow-up "What would you not assume?": hold the plan, and concede that you will not claim to know their process until you have seen it. | F3 is a stated absence on a headline JD line. A manager buying capability will test it first. This is the highest-ROI prep in the pack. |
| B2 | "Your material shows no presenting above regional level. How would you present to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I have never presented to anyone above regional level." Then a plan: rehearse with a peer, and have a senior reader review the first deck. | F9 is a stated absence. The plan is a plan, never a past. |
| B3 | "Why is this a step up for you, rather than a sideways move?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor" | Anchor in the quote: six years, the last three in supervision. Say what you would move toward. Do not claim readiness you have not shown. | Tests motivation against F1. |
| B4 | "Tell me about a time a member was not happy with a complaint outcome. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" | Story map from the quote: a formal log you handled, and what you did with an outcome the member would not accept. Answer slot: if the outcome went against the member, say what and why, and what you told them. If no such time comes to mind, say so plainly, then describe how you handle an outcome a member will not accept. | Open prompt on Members First. The quote gives only the log, so the story stays inside it. |
| B5 | "Tell me about a complaint you held until it was solved. What closed it?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint you held until it was resolved, and say what closed it. If you handed one on, say when and to whom. If none comes to mind, say so plainly, then say what you do with a complaint that stalls. | Tests Own the Fix. F2 says "handled", not "solved", so the honest branch matters. |
| B6 | "Walk me through how the monthly complaints spreadsheet counted complaint volumes." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name, in your own words, the assumption behind the figure you would defend least. Answer slot: if you did this, say how, in your own words. If the spreadsheet did not count volumes that way, or the counting was not yours to set, say so plainly and say what it did count. | Defend-the-number rehearsal on F4. The JD names complaint volumes, so the probe is likely. |
| B7 | "Did the spreadsheet show how long complaints took to resolve?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if it recorded resolution times, say how, in your own words. If it did not, say so plainly and say what it recorded. | F5 discovery. The JD names resolution times. |
| B8 | "A supervisor escalates every complaint over a set amount to the contact centre. What would you do in your first month?" | CASE | [generic] | Clarify what the rule is for and what volumes it sends. Then talk to the supervisor and the contact-centre lead, decide whether to change the rule, and say what you would record. | Live problem on the coaching-supervisors line. Asks nothing about your past. |
| B9 | "Sixty seconds: why should we pick you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor" | Hold the quote. Then name what you would bring, and concede the contact-centre and presenting gaps specifically, in your own words. Do not fold on the six years. | Pressure. Hold then concede. Tests the comparison honestly. |
| B10 | "When did you put a member ahead of an internal target?" | VAL | [grounded] "we decide from the member's side of the counter" (published value; the raising source) | Scaffold: pick a decision where the member's side changed the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries, the complaints log (F2), and say how the member's side would have changed it. | Members First. The question is a persona stem, not a claim about you. |

Reverse questions for Round B (at least five):

- "What do supervisors bring to you first when an escalation goes wrong?" Why it lands: it shows you are thinking about the coaching job.
- "What is the first thing you would want changed in the complaints process?" Why it lands: it asks what the manager most needs, not what the company is like.
- "Which of the four values is hardest to show in a day's escalations?" Why it lands: it shows you have read the values and want to be scored on them honestly.
- "How do you tell whether a complaint was really resolved?" Why it lands: it links to Own the Fix and to your reporting.
- "What did the last person in this role get right, and what did they wish they had done differently?" Why it lands: it shows you want to learn from the role, not just be assessed on it.

## Round C: Panel of two branch managers (60 minutes, including a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to tell a branch manager something they did not want to hear." | VAL | [generic] | Scaffold: name a situation where the hard truth was about a member's case. If none comes to mind, say so plainly, then give the nearest thing your material carries: three years as a branch supervisor (F1). | Open prompt on the persona stem. The honest branch matters more than a story here. |
| C2 | "Our branches sit side by side with yours. Where's the seam, and what happens when we disagree about a member's complaint?" | VAL | [grounded] "trained new tellers on our escalation script" | Propose seam principles, not knowledge of their seam. Name a disagreement only if one happened. Say how you would bring the escalation training to their branches. | Peer Evaluator. Branch managers price what the hire does to their load. |
| C3 | "A member has been passed between three staff over a disputed fraud claim, and the branch has missed the response deadline the complaints rules set. The branch manager asks whether to escalate. Walk us through what you would do." | CASE | [generic] | Clarify the member's need and the deadline. Then name who owns the claim now, the escalation route, what to tell the member in plain words, and the clock you would set. Say what you would record. Asks nothing about your past. | 20-minute case. Covers regulated complaints (F8) and Own the Fix. |
| C4 | "Your answer keeps it in the branch. Why is the right answer not to hand it to the contact centre?" | CASE | [generic] | Pressure, hold then concede. Hold your structure for the case. Concede one thing you cannot know without the case file. | Pressure follow-up to C3. |
| C5 | "Tell me about an explanation you had to give twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Answer slot: if you rewrote or re-taught an explanation, say what changed and how you knew it landed. If you did not, say so plainly, then say how you would find out where a script fails. | Open prompt on Plain Words. The published value is the raising source. |
| C6 | "Tell me about a decision where the local context of a town mattered more than the numbers." | VAL | [generic] | Scaffold: pick a decision where local context changed the answer. If none comes to mind, say so plainly, then say what local context you would check first. Do not reference any branch plans. | Open prompt on Neighbours, Not Numbers. The honest branch keeps the answer clear of the hub plan. |
| C7 | "How would you work with a digital team on a self-service journey for members who are stuck?" | JD | [grounded] the JD line "work with digital teams on self-service journeys" | Answer slot: if you have worked with a digital team before, say who and what changed. If not, say so plainly, then say how you would find out where members get stuck. | F7 discovery. |
| C8 | "Your monthly report goes to a regional manager. What would you put in front of a senior panel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say which measure you would lead with and why, in your own words. Say plainly that the spreadsheet was a regional report. | Covers F4 and F9, reporting and presenting above regional level. |
| C9 | "Two branch supervisors bring you the same escalation problem a week apart. What do you do?" | CASE | [generic] | Coaching sequence: ask what each supervisor did, check the script, decide whether one fix serves both, and record the decision. | Live problem on coaching supervisors. Asks nothing about your past. |
| C10 | "What would you change in the escalation route in your first ninety days, and what would you leave alone?" | JD | [generic] | Structure it: what you would look at first, what you would change, what you would keep, and what you would measure to know. Do not name a change you have not seen the need for. | Closing case question. Tests judgement, not recall. |

Reverse questions for Round C (at least five, with a reciprocity question because the panel is peers):

- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: a reciprocity question turns the panel into a peer conversation.
- "Where do escalations stall most often between your branches and the contact centre?" Why it lands: it shows you are thinking about the seam.
- "What does a strong answer on Own the Fix look like to you?" Why it lands: it lets you show you understand the value in their terms.
- "What did the last hire into this kind of role get wrong in their first ninety days?" Why it lands: it shows you want to avoid the same mistakes.
- "What would you want this role to protect in the branches?" Why it lands: it turns the values into a question about the people they manage.

## Coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A2, B3 |
| Own the member complaints process end to end across branches and the contact centre | B1, B5, C2, C3 |
| Report monthly on complaint volumes and resolution times | B6, B7, C8 |
| Coach branch supervisors on escalations | B8, C9 |
| Work with digital teams on self-service journeys | C7 |
| Experience handling regulated complaints | C3 |
| Confident presenting to senior leaders | B2, C8 |
| Comfortable with Excel reporting | B6, C8 |

| Value | Question IDs |
|---|---|
| Members First, Always | B4, B10 |
| Plain Words | C5 |
| Neighbours, Not Numbers | C6 |
| Own the Fix | B5, C3 |

Question budget: this pack carries 28 interviewer questions across three rounds (8 in Round A, 10 in Round B, 10 in Round C), plus answer slots, which are instructions and not questions to you.

## Upgrade menu

- Your CV, pasted or uploaded → quotes from its wording instead of your message, which upgrades F1, F2 and F6 and sharpens A1.
- The names of the Head of Member Services and the two branch managers → persona weights from their public footprint, and reverse questions tailored to their paths.
- Whether the formal complaints log ran to a regulator's rules or a response deadline → turns F8 from a slot into a quote, and sharpens C3.
- Whether your spreadsheet recorded resolution times, and the tool it ran in → turns F5 and F10 from slots into quotes.
- Any work with a digital team → turns F7 and C7 from a slot into a quote.
- The recruiter's note on what the screen focuses on → confirms Round A's coverage.
- Your prep time before 26 November → adds a prep triage section.
- A `tuesday-dossier.md` file, if you have one → would carry this pack's gaps between sessions without changing the pack.
