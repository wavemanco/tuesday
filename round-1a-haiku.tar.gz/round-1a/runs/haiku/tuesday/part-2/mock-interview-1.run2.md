Priya's pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-1-denied-dea88733/79b0671a-4569-45b4-bbb4-9772c522d476/scratchpad/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`, and I've sent it to you.

I built it for the peer round you described, from your message alone. The JD was the highlights you gave, not the full posting, and web search was refused this session, so the Northwind values, the interview structure and Dan's public footprint are not established. The interviewer read comes only from the profile you shared.

The pack has 19 questions across six personas, weighted toward the Prober and the Peer Evaluator, since he's a peer and describes himself as data-driven. Each question is tagged by type (VAL, EXP, JD, CO, CASE), and the file includes a fit snapshot, the prohibited-claims list, reverse questions and a requirement-coverage table.

Three points matter most:
- **Highest-ROI prep (E2):** "I don't see you owning a go-to-market strategy." The JD's headline requirement is where her evidence is thinnest, so this is the objection to rehearse until it's boring.
- **The $400M figure (A1, A2, D1):** she needs to be able to say how it was counted and what was actually hers. The pack holds her to "proposed" and "credited with," not "drove."
- **No quota or sales-ops experience:** your note says so, but she hasn't said it herself, so the pack doesn't coach any words for it. If she confirms it in her own words, the pack can rehearse an honest answer.

Two things would sharpen this. Is there a full JD I can check the highlights against? And how much prep time does she have before the conversation?

Offers, not pushed:
- **Drill:** I can play Dan as the Prober on A1, with live follow-ups.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for her to carry forward.
- **Word:** I can convert the pack to a .docx once you're done editing it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP.
**Format:** One 60-minute conversation.
**Built on:** Your message (JD highlights, candidate summary, research note). No full JD, no CV file, and no web research. The web search was refused this session (see Sources).

Sections left out by their own conditions: prep triage (prep time not given), graded deliverables (none declared), grounding brief (no L2 run; the research note covers the strategy bank), values cheat sheet (no values-style round detected), delivery coaching (no assessment given).

---

## 2. How to use + type key

**Personas** describe how a question arrives. **Types** describe what it scores. Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Past behavior, mapped to a stated value |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you think at Northwind's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

**Answer slot:** an instruction for the interview, with two branches. "If you did this, say how; if not, or it was not yours, say so plainly." Both branches are honest answers.

---

## 4. Fit snapshot

Requirements are your JD highlights, quoted from your message. Evidence is quoted from your message. Nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (your message); "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Your material shows adjacent work: targets set with cross-org consensus, and a proposed change. It does not show you owning a GTM strategy. Answer slot: if you owned any part of a go-to-market plan, say which part and how you decided; if you did not, say so and stay with the targets you set. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | A revenue model is adjacent to finding whitespace. The four lifecycle stages are not in your material. Answer slot: if you have looked for whitespace in any of these stages, say which and what you found; if not, say so and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (your message) | low | [inferred] | discovery | A skill claim with nothing inspected behind it. It touches the requirement without showing that it reaches it. Answer slot: name one analysis you ran yourself in SQL or Tableau, the question it answered, and what you did; if you have not run one, say so. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | A partner-level model is adjacent to designing a partner motion. Your material does not show the motion. Answer slot: if you designed any part of how a partner channel ran, say which part and how; if the model was an input to a negotiation and nothing more, say so. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | Say it in the quote's own terms: targets set with cross-org consensus. Do not restate it as influence. The consensus carries the point. |
| F6 | "AI experience a plus" (JD highlights, your message) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Daily use is adjacent to AI experience. It is not building or deploying AI. Answer slot: name the tool you use most and a decision it changed, if one did; if none did, say so. |
| F7 | Sales-ops and quota-setting experience (role-family expectation for this peer's domain, plain prose, not a JD line) | "No classic sales-ops or quota-setting experience" (your message, coach's note) | none | [grounded] | discovery | Your note records none. Priya has not said so in her own words, and nothing in the JD highlights asks for it, so no answer slot is raised here. Keep it out of her spoken lines unless the full JD or Dan raises it. |

Routing note: gap types follow the evidence cells. F1 and F2 are transferability because adjacent work is quoted and the requirement is not reached. F5 is presentation because the quote already reaches the requirement in other terms. F3 and F7 are discovery because the material is inconclusive. No row is capability, because Priya has not stated an absence in her own words. No row is hard_gate: the highlights name no term (authorization, location, credential, pay) that the material could fail.

---

## 7. Reading the interviewer

**Source:** The profile you shared. The public-footprint search was refused, so no talks, posts or published writing are established. Nothing below comes from anywhere else.

- **Career pattern:** Pricing and monetization roles are the spine. One early-stage startup chapter. Now Director of Sales Strategy, a peer under the same VP.
- **Self-described:** "relentlessly data-driven" (profile you shared).

Practical implications:

1. **Every metric gets its denominator asked.** Rehearse A1 and A2 first.
2. **Cases will tilt toward pricing and unit economics.** Bank C rehearses that angle.
3. **The startup chapter may bring a scrappiness probe.** One chapter is not a pattern, so treat it as possible, not certain.
4. **A shared domain, not a shared jump.** Revenue modelling is common ground: F4's sentence about the partner-level revenue model is the one to bring if pricing comes up. Do not build rapport on it. No career jump of his resembles Priya's, so no reverse question is built on a jump.

---

## 8. Persona table

Relationship prior for a peer: Peer Evaluator and Data-Driven Prober dominate. Interviewer signals move the Prober up (data-driven profile) and tilt cases to pricing (pricing spine). Loop: a single session, and no loop source establishes the loop, so the fallback is the generic archetype: flat weights, said plainly. No values round is detected, so no Values/Behavioral bank is written.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Data-Driven Prober | Counts, denominators, assumptions two levels deep | High. Peer prior, plus the "relentlessly data-driven" profile | Defend the number in your own words; name the weakest assumption before he does | 5 (A1 to A5) |
| Peer Evaluator | Seams between teams, disagreement with equals, credit, what a hire would need | High. Peer prior, and the same VP makes the seam live | Propose seam principles, not a claimed seam; bring reciprocity | 4 (B1 to B4) |
| Case / Strategist | Live problems on the two product lines, with a pricing tilt | Medium. The JD's GTM ownership, and the pricing spine | Clarify, then objective, segmentation, approach, metrics, risks; state a hypothesis early | 3 (C1 to C3) |
| Skeptic | Thinnest-row probes, GTM ownership, motivation | Medium-high. The GTM-ownership gap (F1) is the most predictable objection | Bridge only from quoted work; name the thinnest row honestly | 3 (E1 to E3) |
| Pressure / Stress | Time-boxed challenges to what you claim you did | Low-medium. A peer prior is weak, but the $400M figure invites it | Hold the quoted position through two follow-ups; concede specifically | 2 (D1, D2) |
| Conversational / Rapport | Casual openers and a casual SQL question | Medium. Peer talks open casually, and casual is still scored | A 90-second arc built only from quotes | 2 (F1, F2) |

Total: 19 questions, within the 18 to 26 range. Weights sum to 5, 4, 3, 3, 2 and 2 across the six personas.

---

## 9. Question banks

Provenance comes first: every quoted sentence a row's guidance rests on is listed there. Rows with no quote carry their label alone.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Story-mapped on F1. The beats are the ones the sentence states: you proposed a change, and the uplift is credited to it. Say the figure as credited. Answer slot: if you know how the uplift was counted, say how, in your own words; if you do not, say so plainly. Name the assumption you would defend least before he asks. If the proposal was yours to decide, say what you decided; if it went into someone else's decision, say so. | F1 carries the figure. It is the headline metric, and a data-driven peer will start with how it was counted. EXP because it tests attribution. |
| A2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | The weakest-assumption slot. Name an assumption only if you know one, and say what it would change. If you did not build the count, say so and say what you can speak to. Do not name an assumption the quote does not carry. | The second level of the defend-the-number slots. The Prober goes two levels deeper than the answer. |
| A3 | "Walk me through the partner-level revenue model: what went in, and which of the numbers did you produce yourself?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | The beats: you built it, and it was used in carrier negotiations. Answer slot: name the inputs, and which of them were yours. If you took inputs from others, say so. | F4 and F2 rest on this sentence. Pricing is Dan's home ground, so this model is where he will look first. |
| A4 | "Tell me about the last analysis you ran end to end in SQL or Tableau." | JD | [grounded] "run independent analysis in SQL and Tableau" (your message, JD highlights) | An open prompt. Pick one analysis you ran yourself: the question, the data, the output, and what changed. Answer slot: if none was yours end to end, say so and describe how you would scope one. | F3 is a discovery row. The JD line raises the theme, so the prompt has a source. |
| A5 | "What AI tool do you use daily, and what decision did it change?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tool you use most. Answer slot: a decision it changed, only if one did; if none did, say so. | F6, a JD plus-skill asked casually and still scored. The likely follow-up is how often, so have that number ready. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your GTM work and my team's work, and what happens when we disagree on a launch?" | JD | [generic] persona stem; no quote carries it | Propose seam principles rather than claiming to know his seam. Name the principle you would use to settle a disagreement with an equal. Answer slot: if you have disagreed with an equal on a launch, say how it was settled; if not, say so and give the principle. | The peer prior's scored question. Collegial packaging of objections. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (your message) | The beat the sentence states: targets, set across orgs, by consensus. Answer slot: if credit was shared on that target, say how it was shared and what was yours; if you did not lead the consensus, say so. | F5 is the cross-functional evidence. This is the only VAL question in the pack, by design: no values round was detected. |
| B3 | "What would you need from my team to make the first launch work?" | JD | [generic] persona stem; no quote carries it | Name the inputs you would need, and what you would bring back to his team. Reciprocity, not a list of needs. | Peer question about what a hire costs his team and what it returns. |
| B4 | "Tell me about a time you disagreed with an equal over a number." | EXP | [generic] persona stem; no quote carries it | Pick a time. If none comes to mind, say so plainly, then give the nearest thing your material carries: the cross-org volume target and how consensus was reached, and only the parts that were yours. | An open prompt on disagreement with equals. The honest branch is built in. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You own GTM for two new product lines with one sales team. Where do you spend the first two quarters?" | CASE (JD) | [grounded] "own GTM strategy for two new product lines" and "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | A live problem that asks about no past of yours. Clarify, then objective, then segmentation using the land/adopt/expand/renew lens, then approach, metrics and risks. State a hypothesis early. | F1 and F2 requirements. The problem is set by the JD line, so the question has a source. |
| C2 | "Price the first of these product lines. What would you test first?" | CASE | [inferred] derived from the interviewer's pricing and monetization career spine (section 7) | Pricing and packaging angle. State the hypothesis early and name the metric you would trust least. No claim about your past. | Tilts the case to Dan's native language. [inferred] because the basis is his profile and this is a pattern, not a fact about this company. |
| C3 | "Northwind has three stated priorities: enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability. Which would your product lines compete for, and which would you protect?" | CO | [grounded] "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" (your research note) | Pick one, and defend it with a metric. The bundling threat in your note is the obvious place to go. If you use it, bring a divergence with reasons; do not recite the consensus view. | The CO question, grounded in the strategy note you supplied. Target 3 is skipped because your note fixes it. |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold-then-concede. Hold the sentence as written: you proposed the change, and the uplift is credited to it. Through two follow-ups, hold the proposal. Concede specifically: any part of the decision that was not yours, and any part of the count you did not see. Never fold on the proposal itself. | A direct test of attribution honesty. The held position is the quote, not more. |
| D2 | "Sixty seconds: why you over someone who has owned a go-to-market strategy?" | JD | [grounded] "set annual volume targets with cross-org consensus" and "own GTM strategy for two new product lines" (your message) | Hold-then-concede. Hold on the targets and the proposal. Answer slot: if you owned any part of a GTM plan, say which; if not, say so plainly and hold the adjacent work. | The time-boxed version of the most predictable objection. The deeper rehearsal is in E2. |

### E. Skeptic (weight 3). E2 is the highest-ROI prep in this pack.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] persona stem; no quote carries it | Name the requirement your material carries least evidence for. The fit snapshot reads F4 (partner motion) and F1 (GTM ownership) as the thinnest. Name one, and a ramp plan for it. Name only a line the material supports. | The Skeptic's stem. It rewards honest naming of the thinnest row over a bluff. |
| E2 | "I don't see you owning a go-to-market strategy in your background. How would you handle that on day one?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | **Highest-ROI prep.** This objection comes from the JD's headline line and will likely arrive in some form. Answer slot: if you owned any part of a GTM plan, say which and how you decided; if you did not, say so plainly, describe the targets you set with cross-org consensus, and say how you would learn the rest, as a plan and never as a past. Hold through two follow-ups by returning to the targets quote. Never add a GTM plan the material does not show. | F1 is the gap this objection aims at. The premise "I don't see" is an observation, as the persona stem allows. The words "I haven't owned" are not Priya's yet, so they stay an answer slot. |
| E3 | "Why this role, and why now?" | EXP | [generic] persona stem; no quote carries motivation | Selection scaffold: pick what you actually did that points at two new product lines. If the honest answer is what you want next, say it in your own words. No claim about her motives. | A motivation probe with no quote behind it, so the guidance is a scaffold, not a story. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | A 90-second arc built only from these three sentences, in that order, in her own words. No more. | Casual register, scored. The arc is pre-scripted from quotes, so it cannot grow. |
| F2 | "What are you actually playing with in SQL and Tableau these days?" | JD | [grounded] "skilled in SQL/Tableau" (your message) | Name the last thing you actually built. If you cannot name one, say so. | A JD plus-skill asked casually. Scored like any other question. |

### Coverage

**Requirement coverage.** Each JD highlight, and the questions that cover it.

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | C1, C3, E2 |
| identify whitespace across land/adopt/expand/renew | C1 |
| run independent analysis in SQL and Tableau | A4, F2 |
| partner-motion design experience required | A3 (adjacent only). None direct, and why: no quote carries a partner motion, so a question asking for one would presuppose it. E1 names it as a thinnest row. |
| strong cross-functional influence | B1, B2, B3 |
| AI experience a plus | A5 |

**Type coverage:** VAL 1 (B2), EXP 7, JD 8, CO 1 (C3), CASE 2 (C1, C2). Total 19. VAL is thin by design: no values-style round was detected.

---

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent most of your career in pricing and monetization, with one startup stint. Which of those shaped how you call a launch on thin data?" | Ties to his own path. It turns the interview into a peer conversation and shows you researched him, not only the company. |
| R2 | "What could someone in this seat do in the first month that would genuinely help your team?" | Reciprocity. It signals you think about what a hire costs his team and what it returns. |
| R3 | "Where does your team's work hand off to GTM today, and where does it stall?" | The seam question, asked from his side. It invites him to name the friction. |
| R4 | "Of the three priorities in the research note, enterprise expansion, Compass and profitability, which does the first launch have to move?" | Shows company-level judgment. Grounded in the note you supplied. |
| R5 | "If the larger platform vendor's bundle reached Northwind's accounts first, what should the first two quarters protect?" | Uses the bundling threat from your note as a question, not a claim. It invites his view. |

---

## 13. Prohibited claims

Built locally from the fit snapshot. No dossier was present, so there are no sourced entries and no candidate-stated negatives to quote. Each entry is a stretched wording of a sentence Priya did say. Its honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for the two product lines | Inflated form of F1: "set annual volume targets with cross-org consensus" widened to the JD's requirement | The F1 quote at its own scope. Pack observation, in analysis only: your material shows targets, not GTM strategy. E2's slot stays inside the targets. |
| Built the partner motion | Inflated form of F4: "built a partner-level revenue model used in carrier negotiations" widened to a motion | The F4 quote at its own scope. Pack observation, in analysis only: your material shows a model, not a motion. A3's slot stays inside the model. |
| Drove the ~$400M ARR uplift | Inflated form of the sentence "proposed a store-surface change credited with a ~$400M ARR uplift": "credited with" becomes "drove" | The quote as written, with "credited with" kept. D1 holds the proposal, not the uplift. |
| Expert in SQL and Tableau | Inflated form of F3: "skilled in SQL/Tableau" widened to expertise | The F3 quote at its own scope. F3's slot asks only for one analysis she ran. |

Not listed: the absence of sales-ops or quota-setting work (F7). It is the coach's note, not a statement Priya has made, so no plain acknowledgment is supplied. F7 is an observation only, and no bank line raises it.

---

## 14. Sources

**Provided documents:** Your message, which contains the JD highlights, the candidate summary, the interviewer profile and the research note. No CV file, no full JD, no dossier.

**Searches and fetches:**

- "Northwind Data company values operating principles": refused (search permission not granted).
- "Northwind Data interview process sales strategy": refused (search permission not granted).
- "Dan Kovac Director of Sales Strategy Northwind Data": refused (search permission not granted).
- Fetches: none attempted.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. All three searches were refused. No retry was made.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Every call refused. Would have fed the values cheat sheet, which is dropped: no values-style round is detected. |
| 2. Northwind interview process, sales strategy | unavailable | Every call refused. Would have set the loop structure. Persona weights therefore follow the generic archetype, said plainly. |
| 3. Northwind strategy and recent news | skipped | Your research note already supplies the three priorities and the bundling threat. Those fix the CO bank's content. Check the note's date (upgrade menu). |
| 4. Dan Kovac, Northwind | unavailable | Search refused. The interviewer read comes from the profile you shared, not from public research. |
| 5. Representative Director-level JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

Numbered targets 6 to 9 (L2) did not run and are not in the table.

---

## 15. Upgrade menu

- **Full JD text** → checks the six highlight rows against the whole posting. A mid-list requirement you have not seen would get its own JD question.
- **Dan's or the recruiter's words on what the role does with sales planning or quotas** → would raise an answer slot on F7 and a bank question. Until then, no source raises it.
- **Your own account of the ~$400M figure: how it was counted and what was yours** → turns A1, A2 and D1 from slots into story-mapped answers.
- **Whether you have set quotas or run sales-ops work, in your own words** → F7 becomes a capability row, and the words for "I haven't" become yours to say.
- **Search access, once it is granted** → would fetch Northwind's values page, its loop structure, and Dan's public footprint. Until then, the loop and values are generic.
- **The date of your research note** → if it is more than about six months old, C3, R4 and R5 need a fresh check.
- **Prep time before the conversation** → sizes a prep triage section.
- **A tuesday-dossier.md** → would add verified evidence and a prohibited-claims guardrail, and carry this pack's feedback forward.
