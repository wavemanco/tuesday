Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-7-canned-84a08893/8278b4a8-10c4-4e17-897c-4767d78e62cc/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. My company searches for Saltmarsh found nothing, so the pack has no values, interview structure or strategy. Tobias's GDC 2026 talk is the one public source I found.

The biggest risk is the question "why should we trust you with two titles and four teams, when you've never led a team?" (B1). It gets the deepest rehearsal, and the pack's guidance is to hold on the calendar you ran, then concede "I haven't led a team" plainly.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Friday's round with Tobias alone, and is he your future manager? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (not yet confirmed).
**Round:** 60 minutes, Friday.
**Candidate:** Femi (pronouns not stated; this pack says "you").

## 1. How to use

Personas describe how a question arrives. Types describe what it scores.

| Type | Name | What it scores |
|---|---|---|
| EXP | Experience deep-dive | Whether what you did survives scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CASE | Live problem | Structure and reasoning on a problem from this role |

No VAL or CO questions: no company values or strategy were found (see Sources).

Guidance is scaffolding, not a script. Answer slots are instructions for the interview: they ask for no reply here.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | presentation | Your material gives four years at a puzzle-game studio, under the title associate producer. It does not say the studio's game was live-service. Say the years and the studio in those words. The live-service link is what F2 carries. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap. The quote reaches the requirement in the JD's terms. Expect a probe on how much of the calendar was yours to set (A2 slot). |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material has one main title and a weekly content-drop cadence. It does not show live events or a second title. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have run a second title or a live event, say which and what you did; if not, say you have run one title's calendar, and say how you would approach a second. |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The material touches QA and shows no coordination across design, art, engineering or community. Answer slot: which functions you coordinated on a drop, and what you asked each for. If the coordination stayed within one team, say so plainly. |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | discovery | Your material shows a presentation of retention numbers. It does not show a post-event review. Answer slot: if you wrote or ran a review after an event or update, say what it covered and which KPIs it reported. If you did not, say so plainly and say how you would set one up. |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Writing the checklist reaches the requirement. Managing it with QA is a step further. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: who decided when a build passed, in your words. If QA owned that decision, say so. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers reaches the metric. It does not show the analysis behind them. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: which figures you chose to show and how they were counted, in your words. If someone else produced the analysis, say so. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in the quote. The checklist is the written artefact to bring; see upgrade menu. |
| F9 | Not a JD line: a stated absence | "Never led a team" — your message | none | [grounded] | capability | A gap wording cannot close, and you have stated it. Words: "I haven't led a team." Then how you would learn it, said as a plan and never as a past. |
| F10 | Not a JD line: a stated absence | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." The JD does not name monetisation. The pack raises it as a Skeptic risk because a mobile title may carry in-app purchases; that is a generic observation, not a fact about this studio. |

**Pack observation, not words for you:** your material says *one main title*, *presented* numbers, and *wrote* a checklist. It does not show the wider versions of those.

## 3. Reading the interviewer

**Public footprint only.** Source: GDC 2026 talk page, https://talks.gdconf.example/2026/patch-notes-are-a-promise (fetched).

- **Career pattern:** previously a QA lead at a console studio; now Head of Live Operations at Saltmarsh Games.
- **Self-described thesis:** "a live team is judged by how often its patch notes describe what actually shipped."

**Practical implications:**
1. Expect probes on release accuracy. Your release checklist (F6, F8) is the line he is most likely to test.
2. Bring the checklist in your head as evidence, and be ready to say what QA changed about it.
3. He will hear "QA" as a credibility signal. Speak about QA as a partner you worked with, not a team you handled.
4. Do not claim his talk's ideas as yours. Quote them only as his.

**Mirror opportunity:** release discipline and QA. No shared career jump is offered: no row carries your side of his QA-to-live-ops move.

## 4. Persona table

Hiring manager relationship prior: Case/Strategist and Skeptic dominate. The talk adds a release-accuracy lens, which raises the Prober and the release questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems on the two-title calendar | High (5): the JD's calendar and coordination lines are case material | Clarify, then structure, then metrics, then risks |
| B. Skeptic | Probes the one-title gap and the team gap | High (4): F3, F4, F9 are the largest gaps in the fit snapshot | Rehearse the objection until it is boring; hold, then concede the stated gap |
| C. Data-Driven Prober | Retention and release checklist probed for assumptions | Medium (3): F5, F7 are metric-adjacent | Say what you did and did not count; name your weakest assumption |
| D. Pressure | Time-boxed challenge on the team gap | Low-medium (2): a hiring manager may test composure on the stated gap | Pause, restate, hold through two follow-ups |
| E. Conversational | Journey and "what do you play" | Low (3): casual questions are still scored | Pre-script a 90-second arc |

## 5. Question banks

Provenance is the candidate's own sentence, quoted, or [generic] / [inferred] for what the pack derived.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of our titles have live events in the same fortnight. Walk me through how you would plan the calendar." | CASE, JD | [generic] | Clarify first: which events, what each depends on, which team is the bottleneck. Then the order you would decide in: each event's objective, the sequence, the QA window, and what you would cut if the window is tight. Name one metric you would check the plan against. Speakable in about 90 seconds. | F3 is the live problem. CASE because it scores structure, not a past. The pattern is for the problem; it makes no claim about this studio. |
| A2 | "Walk me through the content-drop calendar you ran for your main title." | EXP, JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F2: the weekly cadence and the two years, in your own words. Answer slot: how much of the calendar was yours to set, which drops you decided, and how you decided them. If you took the calendar as given, say so and describe how you worked within it. | F2 is the strongest match for the calendar requirement. This is where the interviewer checks whether "ran" means set or carried out. |
| A3 | "A drop is two days out and QA finds a crash on one platform. What do you do?" | CASE, JD | [generic] | Structure it: what decides go or no-go, who you call first (QA, engineering, community), what you tell players and when, and what goes into the post-event review. | F6 is the release-checklist requirement this question scores. The scenario is hypothetical and makes no claim about your past. |
| A4 | "Design, art, engineering and community all need to land on the same update, and you coordinate them without managing them. Where does that go wrong?" | JD | [generic] | Name two failure modes you watch for: a date slip nobody owns, and one team learning of a change last. Then how you keep each team's dependency visible. Answer slot: if you coordinated more than one function on a drop, name them and what you asked each for. If the coordination stayed within one team, say so plainly. | F4 is discovery: the material does not show cross-team coordination, so the answer is a recall, not a claim to prepare. |
| A5 | "What would your first thirty days look like on these two titles?" | CASE, JD | [generic] | Listen first: two weeks reading the live calendar, post-event reviews and KPI dashboards; meet each team lead; sit in on one release. Then one change you would propose once you have data. No claim about your past. | The two-title line from the JD. A plan, not a record. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran the calendar for your main title, and you have never led a team. Why should we trust you with two titles and four teams?" | JD, EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." / [grounded] "Never led a team" | **Highest-ROI prep in this pack.** Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups by returning to what that calendar covered. Concede, specifically: "I haven't led a team." Then the plan, as a plan: how you would set ownership for each team and the first two things you would check. Answer slot: if you coordinated across functions on a drop, name them and what you asked; if not, say so plainly. Deepest rehearsal: three follow-ups. | F3, F4 and F9 meet in this question. The premise "two titles and four teams" comes from the JD, which raises it. |
| B2 | "Which part of this job would you be weakest at on day one?" | Skeptic stem | [grounded] "Never led a team" | Name the one stated gap: "I haven't led a team." Then the ramp plan. Do not name a gap the material is silent on; that is an answer slot, not a confession. | F9 is the only gap with a stated negative, so it is the only one with words. |
| B3 | "What was the last post-event review you wrote, and what did it report?" | EXP, JD | [inferred] "Presented the monthly retention numbers to the studio head." | Answer slot: if you wrote or ran a review after an event, say what it covered and which KPIs it reported. If you did not, say so plainly and say how you would structure one. The guidance does not supply a review. | F5 is low confidence: the question is premised on a practice the material does not carry, so the second branch must allow that it never existed. |
| B4 | "Why leave the puzzle studio now?" | Motivation | [generic] | Give your actual reason in your own words. No reason is supplied here. Keep it under sixty seconds and end on what you want next. | A Skeptic motivation probe. The pack has no fact about your reason, so it supplies none. |
| B5 | "You come from puzzle games. What would you need to learn first about a mobile title with in-app purchases?" | JD, Skeptic | [grounded] "never worked on a game with in-app purchases" | Say it plainly: "I haven't worked on a game with in-app purchases." Then name what you would learn first: how purchases change the event calendar, and which KPI shows it. | F10 is a stated gap. The plain acknowledgment is your own words; the learning plan is a plan, not a past. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you read the retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: you presented the monthly retention numbers to the studio head. Answer slot: which figures you chose to show, how they were counted, and which assumption behind them you would defend least. If someone else produced the analysis, say so. No figure is given here, so the slot asks what you did with the numbers. | F7 is the evidence for the retention requirement, and this is where the probe into the analysis lands. |
| C2 | "For a live event on one of these titles, which retention figure would you watch first, and what would make you call it a miss?" | JD | [generic] | Name the window (day one, day seven) and why that one. Then the threshold you would agree with the title's team before the event. Speakable in about ninety seconds. | The retention requirement in the JD. A method for the problem; no claim about your past. |
| C3 | "Walk me through the release checklist you wrote. Which step has failed in practice?" | EXP, JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6: you wrote it, and QA still uses it. Answer slot: which step has failed, if one has, and what you changed. If none has, say so and name what you would check first. Also be ready to say which parts you wrote and which QA added or changed. | F6 and F8 are the release and written-communication requirements. The second branch allows that no step has failed. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team for this role?" | Pressure | [grounded] "Never led a team" | Hold the position with the work you have done: one calendar, one checklist QA still uses, one set of retention numbers presented. Hold through two follow-ups. Concede specifically: "I haven't led a team." Do not fold on the calendar. | Pressure on the stated gap. Hold-then-concede: the held position is one your quotes carry. |
| D2 | "You presented retention numbers to the studio head. How do I know the ones you showed weren't the flattering ones?" | Pressure, EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold: say which figures you chose and why, in your own words. Hold through two follow-ups. Concede what you cannot prove. Answer slot: if you chose the figures, say how; if someone else chose them, say so plainly. | A probe on attribution. Truthful answers here are the rehearsal. |

### E. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | Conversational | [grounded] "4 years as an associate producer at a puzzle-game studio" | Pre-scripted 90-second arc, with each beat a clause the sentence states: four years, an associate producer, a puzzle-game studio. Then the calendar, the checklist and the retention numbers, in those words. | F1 is the years requirement. Casual register, scored content. |
| E2 | "What's the best live update you've seen in any game, and what did it get right?" | Conversational | [generic] | Name one update and one thing it got right, in plain terms. Keep it to one minute. | Casual, but it tests whether you think about live updates the way the role does. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A5, B1 |
| Coordinate design, art, engineering and community teams on each update | A4, B1 |
| Own the post-event review and the KPIs it reports | B3, C1 |
| Manage the release checklist with QA | A3, C3 |
| 3+ years producing live-service games or apps | E1, F1 (no dedicated question) |
| Experience running a content calendar | A2 |
| Comfortable with player-retention metrics | C1, C2 |
| Clear written communication | none, and why: a written test needs a written artefact. The release checklist is the artefact to bring; see upgrade menu. |

## 6. Reverse questions

Each one carries a "why it lands."

1. "Your GDC 2026 talk argues that patch notes are a promise. What was the last update where the notes and what shipped didn't match, and what changed afterwards?" — *Why it lands:* ties to his public talk, and shows you read it.
2. "You came to live ops from QA at a console studio. What from that job do you still lean on when you run a live calendar?" — *Why it lands:* ties to his own career path, which is public.
3. "Who signs off a drop today, and where does QA's sign-off sit against the producer's?" — *Why it lands:* tests the release-checklist requirement.
4. "What does a good post-event review look like here, and which KPIs does it have to report?" — *Why it lands:* the post-event review requirement, asked as a question about the job.
5. "Across the two titles, how far apart are the live cadences, and where do they collide?" — *Why it lands:* shows you have thought about the two-title calendar.
6. "What would have to be true in six months for you to say this hire worked?" — *Why it lands:* signals you want the success criteria, not just the job description.

## 7. Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran the calendar for two titles" | Inflated form of "I ran the weekly content-drop calendar for our main title for the last two years." | The quote at its own scope: one main title, two years. Pack observation: your material says one main title. |
| "I owned the post-event review and its KPIs" | Inflated form of "Presented the monthly retention numbers to the studio head." | The quote at its own scope. Presenting is not owning the review. |
| "I analysed retention and drove decisions from it" | Inflated form of the same sentence | The quote at its own scope. Pack observation: your material says presented. |
| "I am a producer with four years of producing" | Inflated form of "4 years as an associate producer at a puzzle-game studio" | The quote at its own title: associate producer. |
| "I led a team" | Sourced negative: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| "I have worked on in-app purchase games" | Sourced negative: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## 8. Sources

**Provided documents:** the JD text and your background, both in your message. No CV file was supplied.

**Searches and fetches:**

| Query or URL | Result |
|---|---|
| "Saltmarsh Games mobile studio live operations" (company, not a declared target) | No results |
| "Tobias Wrenfield Head of Live Operations" | One result: GDC 2026 talk page, https://talks.gdconf.example/2026/patch-notes-are-a-promise |
| "Saltmarsh Games games portfolio" (company, not a declared target) | No results |
| Fetch: https://talks.gdconf.example/2026/patch-notes-are-a-promise | Returned the talk summary (Section 3) |

**Research tier:** L1, searches 3 of 6, fetches 1 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Values cheat sheet (section 10 of the skeleton) is absent. No values query was run this pass, and the company searches returned nothing |
| 2. Saltmarsh interview process | unavailable | Loop structure, so persona weights rest on the relationship prior alone. Not run this pass |
| 3. Saltmarsh strategy / recent news | unavailable | Company-strategy questions (CO) are absent. Not run this pass |
| 4. Tobias Wrenfield, Saltmarsh | yes | Interviewer read (section 3); reverse questions 1 and 2; persona weights |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

## 9. Upgrade menu

- Saltmarsh's published values or careers page (paste or link) → a values cheat sheet, and VAL questions. The search found none.
- How many rounds follow Friday, and who is in the room → loop-aware persona weights.
- The release checklist itself, or its section headings → rehearsal on the written-communication requirement, which has no question yet.
- Whether you wrote any post-event review or KPI report → upgrades B3 and F5 from [inferred].
- Details of the two titles (genre, live cadence) → a sharper A1.
- Deep research (L2), offered once: a strategy brief, Tobias's talks and writing, role-family loop reports and recent company news. It adds up to six searches and two fetches, and takes a few minutes.
