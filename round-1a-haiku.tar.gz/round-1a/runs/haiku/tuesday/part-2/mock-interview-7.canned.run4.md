Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-7-canned-2d76d64e/8708e503-4dec-4cc6-8e25-62bc88e81eec/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round. Saltmarsh's own interviewing page describes a single 60-minute interview with the hiring manager: a live-incident tabletop, then a values conversation. That matches your slot, so I've assumed Tobias runs it.

**What the pack says, in short:**

- **Your strongest evidence** is the content-drop calendar you ran for two years, the retention presentations, and the release checklist QA still uses. Each maps to a JD requirement.
- **Your biggest exposure** is leadership. Tobias is likely to press on coordinating design, art, engineering and community without having led a team. The pack's highest-return rehearsal is that question, A2. The honest move is a plain "I haven't led a team," then a concrete account of how you coordinate, held through two follow-ups.
- **The second exposure** is in-app purchases. Saltmarsh's news says Project Larkspur moves two titles to a season-pass model and merges them onto one shared events calendar from February 2027. You should expect a monetisation probe.
- **Two-title planning** is the thing you haven't done on the evidence you gave me. Don't claim it. Answer with what you ran and how you would start on the second title.
- **Tobias** wrote a GDC 2026 talk arguing that a live team is judged by whether its patch notes describe what actually shipped. He came up through QA. Lead with what shipped, not what was planned.

**What I did:** I ran five searches and two page fetches (the values page and his talk). The pack includes a 19-question prep set, a values section, reverse questions, and a requirement-coverage table. Every claim about your experience is quoted from your message.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me. Rehearse only what you actually did, in your own words.

Two questions before Friday:
1. Is Tobias the hiring manager who runs the Outage Hour for this loop? If not, the persona weights and reverse questions change.
2. Do you want a deeper research pass (a strategy brief, more of Tobias's talks, loop reports)? It's up to six more searches and two fetches.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager running the round (see the upgrade menu).
**Round:** One 60-minute hiring-manager interview, the "Outage Hour" per the company's interviewing page: a live-incident tabletop on a simulated outage during a live event, then a values conversation.
**Candidate:** Femi (they/them). Background from your message only.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Type key: **JD** = a requirement from the posting; **EXP** = what your own past work actually was; **CASE** = a live problem; **CO** = company strategy; **VAL** = values. Guidance is scaffolding for a spoken answer, not a script.

## Fit snapshot

Requirements are the posting's own words, quoted. Candidate evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one main title's calendar, run for two years. Two titles are not shown. Answer slot: if you have planned across more than one title, say how; if not, say so and say how you would start on the second. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating those four disciplines on an update. Answer slot: if you coordinated work across design, art, engineering or community on a release, say how, in your own words; if not, say so and say what working agreements you would set on day one. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is not the same as owning the review that produces them. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went in, or ran the review, say how; if you only presented figures someone else produced, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Words: "I wrote the release checklist our QA team still uses." No claim to managing the release process around it. |
| F5 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms: a written artifact others work from. Expect a probe on what it contains. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Shows you presented retention numbers monthly. Does not show you checked, questioned or owned them. Answer slot: what you did to check the numbers before presenting them; if you took them as given, say so. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years, on a puzzle title. Length is not a gate; it is graded on fit. The quote does not say whether that title ran as live-service. Answer slot: say whether it did, in your own words, and how you would describe its content drops. |
| F8 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on what the calendar covered. Its limit is one title (see F1). |
| F9 | Leading people (not a JD line; the coordination requirement invites the probe) | "Never led a team" (your message) | none | [grounded] | capability | Your stated gap. Words: "I haven't led a team." Then how you would coordinate without line authority, said as a plan and never as a past. |
| F10 | In-app purchase games (not a JD line; the company's season-pass news makes it a likely probe) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Your stated gap. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the economics, as a plan. |

Gate rows: none. The JD sets no legal, credential or term requirement, and the material states none.

The gaps most likely to be pressed are F1, F2 and F9, the two-title line and the leadership gap. They are where the material is thinnest, so they are where the pack is most tempted to thicken the story, and where it should not.

## Prohibited claims

Each entry is a claim this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or led coordination across design, art, engineering and community | Stated negative F9; inflated form of F2 | "I haven't led a team." The material shows no team leadership; say that as the pack's own observation, not as words for you. |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: one main title's calendar, run for two years. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." |
| Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." |
| Worked on games with in-app purchases | Stated negative F10 | "I haven't worked on a game with in-app purchases." |

## Reading the interviewer

**Public footprint only.** Tobias's career, as published: QA lead at a console studio, then Head of Live Operations at Saltmarsh Games. Published talk: "Patch Notes Are a Promise" (GDC 2026), whose argument is that "a live team is judged by how often its patch notes describe what actually shipped."

Implications:
1. Expect questions about the gap between what is promised and what ships. Answers should describe what shipped, not what was planned.
2. The release checklist is the most natural shared ground. Tobias's own path runs through QA, and your F4 sentence is about a checklist QA still uses. That is a shared professional path, fair to mention once, in your own words.
3. The Outage Hour tests process under pressure, not recall. Think aloud, name the decision and who signs off.
4. Expect a monetisation probe. The company's news moves two titles to a season-pass model, and you have stated no in-app purchase experience.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Quiet probing of the gaps: leadership, in-app purchases, the two-title line | Highest. Hiring-manager rounds buy capability and derisk gaps; your stated gaps are on the page. | Rehearse the leadership objection until it is plain. Hold one plain acknowledgment, then return to what you did. |
| Case/Strategist (weight 5) | The Outage Hour tabletop and a shared-calendar problem | Highest. The round is a live-incident tabletop by the company's own description. | Clarify, then structure aloud, then decide. Name the decision and who signs off. |
| Pressure (weight 4) | Time-boxed "why you over someone who has led" and "how much was you" | Medium-high. A 60-minute live round favours interruption and time limits. | Pause, restate, hold one position through two follow-ups, then concede a specific point. |
| Data-Driven Prober (weight 2) | "How was that counted" on the retention numbers | Lower. Your retention evidence is a presentation, not a figure, so there is little to count. | Say what you can and cannot say about how the numbers were counted. |
| Conversational (weight 2) | The opening "walk me through the journey" and a written patch note | Low-medium. Casual openers are still scored. | Pre-scripted 90-second arc. Treat the written task as scored. |

Weights follow the hiring-manager prior, with Case and Skeptic dominant. Peer personas are absent because this is not a peer round. The values conversation is covered in its own section below.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name the two-titles line in one sentence, then what you would do in week one. Answer slot: if you have planned across more than one title, say how; if you have not, say so and stay with the one-title calendar you ran. | F1 is where the day-one gap sits, and this question asks for it directly. |
| A2 | "This role coordinates design, art, engineering and community on each update. Why would that work for someone who has never led a team?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | **The highest-return rehearsal in this pack.** Hold: "I haven't led a team." Then return to the coordination method, not to a team you did not lead. Hold through two follow-ups; concede specifically where a team lead's judgment would have changed the outcome. Answer slot: if you coordinated work across those disciplines on a release, say how, in your own words; if not, say so and describe the working agreements you would set on day one. | F9 and F2 together are the single most likely objection. The rehearsed hold and the concession are what change the interview. |
| A3 | "How would you come up to speed on in-app purchase economics for a title you had not worked on?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then your plan: what you would read, whom you would ask, and what you would check in the first month. Claim no past work in it. | F10 is a stated gap, and this is where the season-pass news makes a probe likely. |
| A4 | "Walk me through what the monthly retention numbers you presented actually measured." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say what you presented, to whom and how often, in those words. Answer slot: if you calculated or checked the numbers, say how; if you took them from someone else, say so plainly. Never describe a counting method you did not use. | F6 is the retention requirement, and the quote contains no figure to defend. |
| A5 | "Walk me through how the release checklist you wrote gets used on a release day." | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Say first that you wrote it and that QA still uses it, then what QA does with it, in your own words. Answer slot: if you revised it after a release, say what changed and why; if you did not, say so. | F4 is the release-checklist requirement; EXP because it asks what was yours. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two titles, one team. Sketch how you'd plan the next quarter's events for both. What do you need to know first?" | CASE | [generic] | Clarify first: what counts as an event, which KPIs matter, team capacity. Then the objective, segmentation by player cohort, approach, metrics and risks. Say the structure aloud before you use it. Make no claim about your past. | A live problem drawn from the JD's first line (F1). Generic because it is a pattern, not a fact about this company. |
| B2 | "It's a live event, twenty minutes in, and the reward-claim endpoint fails for some players. What do you do, and who do you talk to first?" | CASE | [grounded] "Outage Hour: a live-incident tabletop on a simulated outage during a live event" (company interviewing page, research) | Stop the damage and tell the players something true, then decide on rollback, then plan the review. Name each decision and who signs off. Make no claim about any outage you have handled. | This is the round's own format, from the company's interviewing page. It presupposes nothing about you. |
| B3 | "Walk me through what you'd put in a post-event review, and which KPIs you'd stand behind." | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); "Presented the monthly retention numbers to the studio head" (your message) | Structure: the goal, what shipped against what was planned, the KPI and its window, and what you would change. Answer slot: if you ran or contributed to a post-event review, say what you did, in your own words; if you have only presented retention figures, say so and stay with the structure. | F3 is the transferability case for the post-event requirement; the JD asks for this directly. |
| B4 | "When the calendar and the players disagree, what decides it?" | CASE | [grounded] "when the calendar and the players disagree, the players win" (company values page, research) | Structure the decision: what the players' side is evidence of (retention, complaints), what the calendar commitment costs, who decides. Say the principle and the tradeoff, not the slogan. Make no claim about your past. | Built from a published company value, so the question is grounded in company material. |
| B5 | "Our two titles move to one shared events calendar from February 2027. What would you get right first?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (company news, research) | Say what you need to know first: capacity across the merged group, cadence of events against season passes, and how you would test the calendar before it ships. Make no claim about your past. | The strongest differentiator in this pack, from L1 research. The news names two titles, which may be the two in the JD; confirm before the round. |

### Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how those retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you know the definition and the window, say them; if you did not count them, say so plainly. If you know the assumption you would defend least, name it. Never supply a retention definition you did not use. | F6; the quote contains no figure, so the defend-the-number slots apply only if a figure comes up. |
| C2 | "How would you tell whether a content drop moved retention, and not something else?" | CASE | [generic] | Name the comparison you would use, its time window, and the confounders you would have to rule out, such as other drops and seasonality. Say what you could not rule out. Make no claim about your past. | Measures the analytic habit behind F6 without asking for a past event. |

### Pressure (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message) | Pause, then restate the question. Hold: "I haven't led a team," and lead with what you did run, the calendar. Hold through two follow-ups. Concede specifically where a team lead's judgment would have helped. Do not fold on the calendar. | F9; the hold is only what the quote carries. |
| D2 | "That calendar: how much of its success was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold on what you ran. Concede specifically what was the team's, in your own words. Answer slot: which decisions on the calendar were yours; if the cadence or content was set elsewhere, say so. | Attribution probe on F1 and F8; the honest answer is precise, not modest. |
| D3 | "The company is moving titles to a season-pass model. You haven't worked on in-app purchases. Why would that not sink you here?" | JD | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model" (company news, research); "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then your plan for learning the model. Do not argue the economics. | F10 under pressure. |
| D4 | "You ran the calendar for your main title for two years. Why should we trust you with two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold on the discipline you did run: weekly cadence, two years. Concede what you have not run, which is the second title. Answer slot: if you have planned across more than one title, say how; if not, say so. | F1 under pressure; the hold rests on the quote, not on a second title. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc in your own words: the four years, the calendar, the retention presentation. Add no scope. | F7 and F8 are the requirements this arc covers. Casual openers are still scored. |
| E2 | "Show me how you'd write the patch note for an update that missed its date." | JD | [grounded] "clear written communication" (JD); "Patch Notes Are a Promise" (company talk, GDC 2026, research) | Write it aloud: what shipped, what did not, and the next date you would commit to, without promising what is not built. | F5 is the writing requirement; the talk's title sets the test. |

## Values cheat sheet

Included because the round's values conversation is company-described. Each value's meaning is paraphrased from the company's values page; the mapped story is drawn only from your quoted sentences.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | Nearest sentence: "I ran the weekly content-drop calendar for our main title for the last two years." Scaffold: pick a time a calendar choice had to bend for players. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F4: "I wrote the release checklist our QA team still uses." Scaffold: pick a time a release note nearly overstated what shipped. If none comes to mind, say so plainly, then describe how the checklist keeps notes honest. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4 again. Your quote does not say you revised the checklist. Answer slot: if you changed it after a release, say what changed and why; if you did not, say so. |

## Reverse questions

Each has a "why it lands" line.

1. "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. Where does that get hardest to hold on a two-title calendar?" **Why it lands:** it ties to his own QA-to-live path and turns the interview into a peer conversation.
2. "The company's news puts one shared events calendar in place from February 2027. What would the first quarter on it need to get right?" **Why it lands:** it shows you read the company's strategy, not only the posting.
3. "What does a strong first month look like for the person in this role on the two titles?" **Why it lands:** it makes the Outage Hour's practical side concrete and tells you how success is scored.
4. "How do you know a post-event review has worked?" **Why it lands:** it puts the KPI requirement in Tobias's own terms.
5. "Which part of the release checklist process is the team least satisfied with today?" **Why it lands:** it asks about the release-checklist requirement and invites a candid answer.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B1, B5, D4 |
| Coordinate design, art, engineering and community teams on each update | A2, B2 |
| Own the post-event review and the KPIs it reports | B3, C1 |
| Manage the release checklist with QA | A5 |
| 3+ years producing live-service games or apps | E1 (arc); live-service status is not asked directly, and its answer slot is F7 |
| Experience running a content calendar | E1, B1 |
| Comfortable with player-retention metrics | A4, C1 |
| Clear written communication | E2, A5 |

Stated gaps with rehearsal: leadership (A2, D1), in-app purchases (A3, D3).

## Sources

**Research tier: L1, searches 5 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name, with their meanings. |
| 2. Saltmarsh Games interview process | yes | Round format: one 60-minute hiring-manager interview, a live-incident tabletop then a values conversation, no take-home. Shapes B2 and the values section. |
| 3. Saltmarsh Games strategy and recent news | yes | Project Larkspur (September 2026): season-pass model and one shared events calendar. Feeds B5, D3 and reverse question 2. |
| 4. Tobias Wrenfield with Saltmarsh | yes | Interviewer read: QA-lead background and the GDC 2026 talk. Feeds reverse question 1 and the persona weights. |
| 5. Representative JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions. |

Queries sent:
- "Saltmarsh Games mobile studio values": returned the company values page (saltmarshgames.com/values). Fetched.
- "Saltmarsh Games live operations mobile games": no results.
- "Tobias Wrenfield Head of Live Operations Saltmarsh": returned the GDC 2026 talk page (talks.gdconf.example/2026/patch-notes-are-a-promise). Fetched.
- "Saltmarsh Games interview process live operations producer": returned the company interviewing page (saltmarshgames.com/careers/interviewing). Read from the search snippet only; not fetched.
- "Saltmarsh Games news 2026": returned the Project Larkspur announcement (saltmarshgames.com/news/project-larkspur). Read from the search snippet only; not fetched.

Provided documents: your message and the JD text.

## Upgrade menu

- Confirm that Tobias is the hiring manager running the Outage Hour → the persona weights and the reverse questions are built on that assumption.
- Confirm that the two titles in the company news (Tidepool Tactics and Lantern Row) are the two in the JD → B5 and D3 become fully grounded.
- Whether the puzzle title ran as live-service → closes F7 and its answer slot.
- Whether you coordinated any release across design, art, engineering or community → lifts F2 from discovery to a quoted account, and reshapes A2.
- The retention numbers you presented, as a file → makes A4 and C1 answerable on figures rather than slots.
- The release checklist, or one calendar, as a file → F4, F5 and F8 move from medium to high confidence, because each becomes an inspectable artifact.
- Deep research (L2), offered once: a strategy brief, Tobias's other talks and writing, and loop reports for the role family. Cost: up to 6 more searches and 2 more fetches.
