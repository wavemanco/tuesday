Your prep pack is saved as atlas-freight_operations-manager_interview_pack.md, and I've sent it to you. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has nothing verified about Atlas Freight's values, interview process or strategy.

Start with B1 ("You're currently over three supervisors. The role is twelve across four sites. Why are you ready for that?"). It's the question the pack names as highest-ROI: your biggest gap is scale, and it will almost certainly come up in some form. Then C1: be ready to say how the 40% mis-pick figure was counted and which part was yours.

Two offers, neither pushed:
- I can play the Skeptic on B1 as a live drill.
- I can save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not given. Round type: not given, so this pack assumes a hiring-manager round with flat-leaning persona weights (see the persona table). Sources: the JD text and your background, as you gave them. Web search was refused in this session, so nothing here about Atlas Freight's values, interview process or strategy is verified.

## How to use this pack

- **Personas** = how the question is asked (tone, pressure, angle).
- **Types** = what is being scored: **VAL** values/behaviour, **EXP** your past work, **JD** the listed requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Rehearse it in your own words, and say only what you did.

## Prep triage (about one week)

1. **Days 1–2:** Write out B1 and B2 in your own words. These are the hardest questions, because the JD asks for four sites, twelve supervisors and five years of leadership, and your material shows one team of three.
2. **Days 2–3:** Prepare the numbers for C1 and C2: how the 40% mis-pick figure was counted, which part was yours, and whether the peak-season plan had targets.
3. **Days 3–4:** Practise the two CASE questions, A1 and A2, out loud for 5 minutes each.
4. **Day 5:** Write your honest Power BI answer (B3, G2) and a 90-second background arc (G1).
5. **Day 6:** Read the reverse questions aloud and pick your top three.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows distribution work and a shift team at one site, not four. Keep the words at that scope: "I've spent seven years in warehouse and distribution operations. I'm currently a senior shift manager over three supervisors." Answer slot: if you have coordinated anything across more than one site, say what and how; if not, say so and say what you would check first at the first site you took on. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the team you have led, so say that number first. The material does not show a team of twelve. Answer slot: if you have led more people through supervisors than three, say how, in your own words; if not, say so and say how you would set up the first month with twelve. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Seven years of operations work is not the same as seven years of leadership, and your material does not say how many years you led people. The derivation: the JD's leadership line against your operations years. Answer slot: say how many of the seven years you led people, and in what role. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message); "never used Power BI" (your message) | medium | [grounded] | transferability | Excel is adjacent to building reporting; your material does not show a report you built. Words at scope: "My Excel is solid." For Power BI, the plain acknowledgment you gave: "I haven't used Power BI." Answer slot: say how you would learn it and by when, as a plan, never as past work. |
| F5 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Mis-pick accuracy is adjacent to on-time and cost, and is not the same metric. Words at scope: "I cut the mis-pick rate by 40% by redesigning the pick path." The figure raises the defend-the-number slots in C1. Answer slot: say whether on-time or cost-per-shipment was tracked at your site and, if so, what moved; if not, say so and say which measure you would start with. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Certification is stated and nothing has been inspected. Words: "I'm Green Belt certified." Expect a probe on what the certification was applied to (A4). |
| F7 | No JD line; headline claim | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | Not a JD requirement, but a headline claim, so it gets a defend-the-number question (C2). Words: "I ran the site's peak-season surge plan two years running." |

## Prohibited list

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of them is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| I ran operations across four sites | Inflated form of F1 | F1's quote at its own scope. Your material shows distribution work and a three-supervisor shift team, not four sites (the pack's observation, not words for you). B1 stays inside that scope. |
| I lead a team of twelve supervisors | Inflated form of F2 | The three-supervisor quote, at its own scope. |
| I have five-plus years of operations leadership | Inflated form of F3 | "7 years in warehouse and distribution ops", at its own scope. The leadership years are the question in B2. |
| I have Power BI experience, or built Power BI reports | Negative you stated (F4) | The plain acknowledgment: "I haven't used Power BI." No slot. |
| I ran a Lean/Six Sigma project | Inflated form of F6 | The certification, at its own scope. A4 asks what, if anything, it was applied to. |
| I drove on-time performance or cost-per-shipment down | Inflated form of F5 | The 40% mis-pick figure, at its own scope. |

## Persona table and weights

Round type and interviewer are not known. These weights rest on the JD's shape (a leadership role with metrics), not on a documented loop for Atlas Freight. Tell me the round type and I will re-weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live ops problems: on-time drop, cost spike, peak surge | **Top (4 questions).** The JD is a list of operating outcomes; a hiring manager tests how you would diagnose them. | Clarify, then structure: objective, segments, approach, metrics, risks. Think aloud. |
| Skeptic | "Why you, for this scale?" and "Why now?" | **Top (4 questions).** The biggest visible gaps are scale (F1, F2), leadership years (F3) and Power BI (F4). | Rehearse the predictable objection until it is plain. Concede the gap without folding on what you did. |
| Data-Driven Prober | Asks how the 40% was counted and who owns the numbers | **Mid (3 questions).** Your three numbers are the figures a prober will test. | Name the assumption you would defend least before they do. Say plainly what you do not know. |
| Pressure | Time-boxed "why you?" and "how much was you?" | **Mid (3 questions).** Common in senior ops rounds where one seat is being chosen. | Pause, restate, hold a position through two follow-ups, then concede only what is true. |
| Values/Behavioral | STAR-shaped stories about changing methods or handling disagreement | **Low (2 questions).** No values round was detected, since no loop source was read. Cross-functional interviewers still do this. | Pick a real time with a named stake; say plainly if none fits, then give the nearest one. |
| Peer Evaluator | Seams between shifts and other teams; credit-sharing | **Low (2 questions).** Relevant only if a peer or cross-functional person is in the room. | Frame reciprocity: what you bring their team, not just what you need. |
| Conversational | Friendly opener: "walk me through the journey" | **Low (2 questions).** Every round starts this way, and casual questions are still scored. | Have a 90-second arc ready; never answer the reverse-question slot with "I think you've covered it." |

## Question banks

### A. Case/Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance has dropped eight points over three weeks across the network. Where do you start?" | CASE | [generic] | Clarify the window and which sites moved. Then segment by shift, dock, carrier and lane, and name the metric you would check first. Give the first two checks, then the risk to the customer. The question makes no claim about your past. | Tests the JD's on-time line as a live problem. `[generic]` because it is a pattern for the problem. |
| A2 | "Cost per shipment is up in one region but flat in the others. What do you look at, and in what order?" | CASE | [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Structure first: volume, labour hours, rework, linehaul. Say which two you would check today. Do not claim you have run this analysis. | Scores the JD's cost line. The raising source is the JD itself. |
| A3 | "Peak volume doubles for six weeks, and two of your sites are short-staffed. Plan it." | CASE | [generic] | Clarify the volume forecast and the staffing gap. Then sequence: what to lock first, what to flex, which decisions go to the site leads. The question presupposes no event from your past. | Asks for the surge planning you have done, as a decision. |
| A4 | "Your Green Belt: what did you apply it to, and what did it change?" | EXP | [grounded] "green belt certified" (your message) | Name the certification and stop. Answer slot: if you applied it to a project, name the project and its measured result, in your own words; if it was not applied to one, say so and name the method you would use on the next problem. | F6 is the evidence and the likely probe for the Lean/Six Sigma line. The honest branch is "not applied yet". |

### B. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're currently over three supervisors. The role is twelve supervisors across four sites. Why are you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI rehearsal in this pack.** Hold: "I'm currently a senior shift manager over three supervisors," then say what you have done at that scale that carries over. Hold through two follow-ups by returning to three supervisors, not by adding to them. Answer slot: if you have coordinated work across more than one site, say what and how; if not, say so and say what you would check first at a new site. | F1 and F2 are the largest gaps. This objection is near-certain in some form, and a calm, specific answer changes the interview. |
| B2 | "The role asks for five years of operations leadership. How many years have you led people, not just processes?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer in numbers, and say which role you held in each period. Answer slot: if some of the seven years were not in a leadership role, say which; never count operations years as leadership years. | F3 is the discovery gap: the material does not say. The honest answer is a number you can defend. |
| B3 | "You haven't used Power BI, and the role builds reporting in it. Why should we take that risk?" | JD | [grounded] "never used Power BI" (your message); [grounded] "solid Excel" (your message) | Plain acknowledgment: "I haven't used Power BI." Then Excel at its scope: "My Excel is solid." Then how you would learn it and by when, as a plan. Hold the plan through two follow-ups; never claim BI experience. | F4 is a stated gap. The honest answer names it, then gives a plan. |
| B4 | "This is a step up from a shift manager role. What makes you sure it isn't a stretch?" | EXP | [generic] | Answer with the one thing in your background closest to the step (the seven years, the team of three, the pick-path result), then name the piece you would learn first. The question makes no claim about your history. | Motivation and consistency probe. Pairs with B1. |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slots, in your own words: how the rate was counted, what it is sensitive to (volume, SKU mix, the baseline period), the assumption you would defend least, and which part of the redesign was yours. If you do not know how it was counted, say so. Do not supply a baseline. | F5's headline figure. The prober tests whether you know your own assumptions. |
| C2 | "Did the peak-season surge plan have numeric targets, and how did you do against them?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Answer slot: if it had targets, state them and the result in your own words; if it did not, say so and say what you would set as the first target. Do not invent targets for the past. | F7's defend-the-number question. The honest branch is "there were no targets" or "I don't know". |
| C3 | "Show me how you'd build a weekly on-time report in Excel, and where Power BI would take it." | JD | [grounded] "solid Excel" (your message); [grounded] "never used Power BI" (your message) | Excel: describe what you would build and what each column would answer, in your words. Power BI: "I haven't used Power BI", then the plan for it. Do not describe a dashboard you have not built. | F4 is the reporting requirement. The Excel answer is strong; the Power BI answer is the plan. |

### D. Pressure (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause. Restate the question. Hold your position: seven years in the work and a measured result on a pick path. Do not claim the four-site experience. Hold through two follow-ups; then concede what is true. | Composure test on the scale gap. The hold uses only your quotes. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: say which part of the redesign was yours, in your own words; say plainly which part was the team's. Hold the part that was yours through one follow-up; concede the team's part without folding on yours. | F5's attribution test. A prepared, honest split beats a vague "we". |
| D3 | "You've never used Power BI. Why shouldn't we hire someone who has?" | JD | [grounded] "never used Power BI" (your message) | Pause. "I haven't used Power BI." Hold on the rest: Excel and the plan to learn the tool. Concede the gap plainly without apologising for it. | A pressure version of B3. Practise the concession until it is short. |

### E. Values/Behavioral (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you changed how a shift ran when your supervisors disagreed with you." | VAL | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Open prompt: choose a real instance with a named stake, a decision you made, and a working relationship at the end. Story-map it on the pick-path change only if your quote carries it. If no such time comes to mind, say so plainly, then give the nearest one. | Values/behaviour stem. No values round is detected, so this is a low weight. |
| E2 | "Tell me about a time you reported a number that people did not want to hear." | VAL | [generic] | Open prompt: choose a real instance with the number, the audience, and what you did next. If you have no such instance, say so plainly and give the nearest one. | Tests the honest-number reflex that a prober will also test. |

### F. Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-1 | "Our teams sit side by side. Where's the seam between your shifts and ours, and what happens when we disagree?" | VAL | [generic] | Name the seam as a principle (who owns handoffs, who calls the exception), not as a detail you do not know. Say what you would bring to their team, not only what you need. | Peer-style seam probe. Low weight unless a peer is in the room. |
| F-2 | "How do you handle credit when a peak plan spans two departments?" | VAL | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Say "we" for the context and "I" for your contribution, using the plan you ran. Answer slot: if other departments shared the plan, say who did what; if you ran it alone, say so. | Credit-sharing probe using your F7 quote. |

### G. Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G-1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "green belt certified" (your message) | A 90-second arc: seven years in distribution, now a senior shift manager over three supervisors, a pick-path result, the Green Belt. Use only those quotes; do not stretch the arc. | Casual-sounding but scored. Have it timed. |
| G-2 | "What are you playing with in Power BI these days?" | JD | [grounded] "never used Power BI" (your message) | "I haven't used Power BI." Then your plan to learn it, and what you have already done toward it. Never a tool you have not touched. | Asked casually, but it scores honesty on a JD gap. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | B1, D1, A1 |
| Drive on-time performance and cost-per-shipment down | A1, A2, C1, D2 |
| Lead a team of 12 supervisors | B1, D1, E1 |
| Build reporting in Excel/Power BI | C3, B3, G-2, D3 |
| 5+ years operations leadership required | B2 |
| Lean/Six Sigma a plus | A4 |

## Reverse questions

Each one should land for a reason. Choose three and rehearse them.

1. "What does the first 90 days look like for someone taking over one of the four sites?" Why it lands: it shows you are planning for the scale gap, not hiding from it.
2. "Which site's on-time performance worries you most right now?" Why it lands: it shows you have thought about the job's outcomes, not just its title.
3. "How is cost-per-shipment measured today, and who owns that number?" Why it lands: it asks about the measure the JD names, and the answer tells you how decisions get made.
4. "What reporting do the supervisors use day to day, and what would you change in it?" Why it lands: it opens the Excel/Power BI requirement from their side.
5. "Where does the team of twelve break down today?" Why it lands: it invites a candid answer about the hardest part of the job.
6. If the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Why it lands: it is a reciprocity question, which turns the interview into a working conversation.

## Sources

- Provided: the JD text and your background, as pasted in this conversation.
- Search, "Atlas Freight regional logistics company values": refused (search permission not granted in this session). No results.
- Search, "Atlas Freight interview process operations manager": refused (same). No results.
- Not run: the strategy target (budget went to the values and loop targets first); the interviewer target (no name given); the representative-JD target (JD supplied).

Research tier: L1, searches 2 of 6 (both refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet (section 10): search refused. Dropped, since no values round is detected. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure and persona weights: search refused. Weights use the JD's shape instead. |
| 3. `Atlas Freight strategy` / recent news | unavailable | CO bank: budget went to targets 1 and 2 first. No CO questions written. |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. |
| 5. Representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name, and whether the round is a hiring-manager, peer or panel → persona weights and a tailored reverse question.
- Round type and any focus areas from the recruiter → coverage of what they will score.
- Atlas Freight's published values or leadership principles, pasted → a values cheat sheet and VAL questions mapped to your stories.
- The company's interview process, from their careers page or your recruiter → a named loop, and whether a values round exists.
- A deeper research pass on Atlas Freight's strategy and recent news (up to 6 more searches and 2 more fetches, several minutes) → a grounding brief and CO questions. Available on request.
- If the round has several sessions, send the schedule → per-session mini-packs.
- A short note on how many years you led people → resolves F3 and B2 from discovery to grounded.
