The search tool was refused by permission, so I can't pull Stripe's values, interview structure, or strategy from the web. I'll build the pack from what you've given me and label everything else as generic.
Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-3-denied-3a5f531a/97a0a25e-9c90-458a-bed5-4184c90cd4e3/scratchpad/stripe_product-operations-manager_interview_pack.md. It has 18 questions across seven personas, a fit snapshot, a prohibited-claims list, five reverse questions, and an upgrade menu at the end.

Two things shape it. I don't know who you're meeting or how the final is run, so the persona weights are a blended prior. And web search was refused by a permission setting, so I could not check Stripe's values, its interview structure, or recent strategy. Those are marked not established, and the company questions are generic. Nothing about Stripe's values or process is from memory.

The highest-return prep is B3: "Your background is not the obvious path into this role. Why should we believe you can do it?" It is the question most likely to come up in some form. Want a live drill on it? I can also save a tuesday-dossier.md recording the gaps this prep exposed.

Two questions so I can tighten the pack:

1. Who are you meeting in the final, and is it one session or several? A hiring manager, a peer, or a panel changes which personas matter most.
2. Can you paste your CV and the job description? Without them I can't quote your experience, so every answer stays generic. I can proceed without them if you prefer.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

**Interviewer:** not given. **Relationship:** not given. **Round format:** not given, so this is a session-mode pack with blended persona weights.
**First pack:** no changelog.

## How to use this pack

- **Personas** describe how a question arrives (friendly, skeptical, time-boxed). **Types** describe what is being scored: CASE (live problem), EXP (your past work), JD (the role's job), VAL (values or behaviour), CO (company knowledge).
- Guidance is scaffolding, not a script. Speak each answer in 90 to 120 seconds, in your own words.
- Where a guidance cell says "answer slot" or "selection scaffold", the content is yours to supply. The pack will not fill it in for you.

## Prep triage

Prep time was not stated, so this is the default order.

1. Rehearse B3 out loud until it no longer sounds rehearsed. It is the question most likely to come up in some form.
2. Rehearse A1 and A2 with a timer. Final rounds usually include a live problem.
3. Prepare two or three real stories for C1 and C2, each with a figure you can explain.
4. Everything else is insurance.

## Fit snapshot (worksheet variant)

No CV, no job description and no background were supplied, so every evidence cell is `none given`. The requirements below are role-family patterns, not quoted from any posting, so they are unquoted and labelled `[generic]`. They raise no answer slots. Each bridge says what strong evidence would look like and gives a selection scaffold ending in an honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running recurring operating reviews or decision forums for a team (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a review you ran, what decisions it made, what you cut. Scaffold: pick a recurring meeting or review you were part of; say what it decided. If none, say so plainly and name the nearest thing you did. |
| F2 | Designing a process and measuring whether a change worked (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a process you changed, the metric you watched, the result you could show. Scaffold: pick a change; say what you measured before and after. If you measured nothing, say so plainly. |
| F3 | Coordinating product, engineering, finance and support on one plan (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a plan several teams had to agree to, and who decided what. Scaffold: pick a cross-team plan; say which parts you owned and which were set by others. |
| F4 | Choosing among competing operational projects with limited capacity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a prioritisation you made and what you dropped. Scaffold: pick a time you had to say no to something; say what criteria you used. If you have not, say so. |
| F5 | Answering operations questions with data (role-family pattern) | none given | none | [generic] | discovery | Strong evidence: a question you answered with data and the method you used. Scaffold: pick one analysis; say how it was counted and what it could not show. If you have not done one, say so plainly. |

Gate rows: none. A gate is a term such as work authorisation, location or schedule. None was stated, and with no job description none can be read from the posting.

## Prohibited claims

Nothing has been quoted from you yet, so there are no stretched versions of your sentences to list. The rule for this pack: no answer, bridge or drill feedback asserts a responsibility, figure or outcome that you have not stated yourself. Where a question asks about your past, the answer is a story from your own experience or an honest "I have not done that."

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operational problem, scored on structure and clarifying questions | High. Final rounds for operations roles often include a live problem; relationship unknown, so this is a prior, not a finding | Clarify, then objective, segmentation, approach, metrics, risks. Say the first two questions aloud |
| Skeptic | Quiet probing of gaps, motive and "why now" | High. Final rounds test whether the story holds | Name one real gap in your own words, then a ramp plan. Do not bluff |
| Data-Driven Prober | Asks how a number was counted and what it assumes | Medium. Likely only if you bring numbers | Know how each figure you use was counted. Say plainly when you do not know |
| Values / Behavioral | Scenario prompts for past behaviour | Low to medium. No values round was detected, so this is a fallback prior | Choose stories where you can say what you did and what it cost |
| Pressure / Stress | Interrupts, time-boxes, challenges your attribution | Medium. Common at final rounds | Pause, restate, hold a position through two follow-ups before conceding |
| Peer Evaluator | Seam questions between adjacent teams, credit sharing | Medium if the final includes a peer | Propose seam principles rather than claiming to know the seam |
| Conversational / Rapport | Friendly opener and "walk me through your journey" | Low to medium. Casual questions are still scored | Keep a 90-second arc ready; use only facts you have stated |

## Question banks

Weights: Case 5 questions, Skeptic 3, Prober 3, Values 2, Pressure 2, Peer 2, Conversational 1. Total 18.

### Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A team's onboarding completion rate fell 20% after a process change. What do you do first?" | CASE | [generic] | Clarify the metric, the baseline and the change. Segment before you hypothesise: new versus returning, channel, step. Name two hypotheses and the check that would separate them. Ask one question about the change itself | Core live-problem type for this persona; no claim about your past |
| A2 | "You can start one of three operations projects next quarter with one person. How do you pick?" | CASE | [generic] | State criteria first: impact, reversibility, dependencies, cost of delay. Score them as judgment, not formula. Name the one you would drop and why | Tests prioritisation, the F4 pattern; generic |
| A3 | "A cross-functional launch slipped two weeks and two teams disagree on the cause. What do you do?" | JD | [generic] | Separate facts from positions. Map the dependencies. Name who decides. Reset the date with an explicit trade-off, then say who you tell and when | Tests cross-team coordination (F3); asked as a problem, not a record |
| A4 | "Design a weekly operating review for a team of six that does not become a status meeting." | CASE | [generic] | Start with the decisions the meeting must make. Then inputs, cadence, the few metrics that matter, and what you would cut | Tests F1 pattern; generic |
| A5 | "What would you measure in the first 90 days to know this role is working?" | JD | [generic] | Give three or four measures and what each would be sensitive to. Name the weakest assumption in the first one. Say what you do not yet know | Tests F2 pattern; generic |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real area in your own words. Give a two-step ramp plan. If you have related work, say what it was; if not, say that | Skeptic's standard question; generic |
| B2 | "Why are you leaving where you are, and why here, why now?" | EXP | [generic] | Give your actual reason in one true sentence, then the reason tied to this role's work. Do not criticise your current employer. Answer slot: your real reason, in your words | Motivation consistency; the honest answer is yours |
| B3 | "Your background is not the obvious path into this role. Why should we believe you can do it?" | EXP | [generic] | Highest-ROI prep in this pack. Name the closest piece of work you have that carried the role's core task, and say plainly where it stops. Do not argue. Hold through two follow-ups by returning to the work you did | Most likely objection; a limit stated plainly beats a bluff. Answer slot: if you have such work, say what you did; if not, say so and give your ramp plan |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a number you reported. How was it counted, and which assumption would you defend least?" | EXP | [generic] | Choose a figure you actually produced. Say how it was counted and name the weakest assumption before they do. If you do not know how it was counted, say so. Answer slot: the figure is yours; its method is yours to state | Probers test headline numbers; the honest answer is precision about your own figure |
| C2 | "Walk me through a process you designed end to end. What did you decide, and what was set for you?" | EXP | [generic] | Pick one process. Separate what you set from what was given to you. If none was yours, say so plainly and describe how you worked within it | Tests attribution; generic until you give a process |
| C3 | "How would you know a process change worked, and how would you tell it had not?" | CASE | [generic] | Name a baseline, a comparison, a leading and a lagging measure, and a guardrail metric that would reveal damage | Tests measurement design; generic |

### Values / Behavioral (fallback prior, not a detected round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unwelcome truth to a senior person." | VAL | [generic] | Pick a time with a real stake, a point where you did not fold, and a relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing you have or how you would handle it | Open prompt; you choose the instance |
| D2 | "When did you put a user's need ahead of an internal metric?" | VAL | [generic] | Same structure as D1. Say what the metric was and what you did instead. If you have not done this, say how you would decide | Open prompt; generic |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has done this job before?" | JD | [generic] | Pause. Restate the question. Hold your strongest true claim, concede the specific gap in one sentence, and do not fold on the core claim | Time-boxed challenge; hold then concede |
| E2 | "That result sounds good. How much of it was actually you?" | EXP | [generic] | Name what you did, what others did, and the limit of your part. Hold through two follow-ups | Tests attribution under pressure; you can only say what you did |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where is the seam between ops and ours, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, not a claim to know it. For disagreement, use a real example, or say how you would handle it | Peer seam probe; generic |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Name who did what on a shared piece of work, in your own words. If you have no example, say what you would do | Peer credit probe; generic |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: what you did, why it led here, what you want next. Use only facts you have stated | Casual opener is still scored |

## Reverse questions

Each one lands for a reason. Round format and interviewer are unknown, so none is tied to an interviewer's path.

1. "What does a strong first 90 days look like in this role, and who would tell me if I was off track?" Lands because it shows you are scoping for results, not tasks.
2. "How is the team's operating review set up today, and which decision does it still fail to make?" Lands because it shows you think about operations as decisions.
3. "Which part of this role do people most often underestimate when they join?" Lands because it invites the interviewer to speak candidly, and you hear what they value.
4. "What is the biggest open problem this role is expected to solve in the next two quarters?" Lands because it tests whether you can think at the team's altitude.
5. "How do you decide between a process fix and a headcount request?" Lands because it signals you understand the trade-off that operations leaders live with.

If the final round includes a peer, add: "What could a new person do in their first month that would genuinely help your team?"

## Sources

- Provided documents: the request only. No CV, no job description, no interviewer name, no round format, no dossier.
- Research tier: L1, searches 4 of 6, fetches 0 of 2. Every search was refused because the host's search permission was not granted.
- Stripe values: refused. Values are not established, so no values cheat sheet appears in this pack.
- Stripe interview process for product operations: refused. Loop structure is not established. Persona weights rest on a generic prior.
- Stripe strategy and recent news: refused. Company-knowledge (CO) questions are generic.
- Interviewer footprint: n/a, no name given.
- Representative product operations JD: refused. Requirements are role-family patterns labelled `[generic]`.

## Upgrade menu

- Your CV or a background paste → fit snapshot rows get your verbatim quotes, and the banks are rebuilt around work you actually did.
- The job description → requirements become quoted, and JD-tagged questions and gap rows regenerate.
- The round format (how many sessions, who runs each, what each holds) → per-session mini-packs and persona weights for each.
- The recruiter's email on the final round's focus areas or any take-home → coverage of any announced deliverable.
- Stripe's values or operating-principles page, pasted → a values cheat sheet mapped to your stories.
- The interviewer's name → a personalised reverse question and persona weights from their public footprint.
- Turning on web search and asking again → values, loop structure and recent strategy become sourced rather than not established.
