Your prep pack is saved as ashgrove_member-experience-lead_interview_pack.md. I built it as three mini-packs, one per round, because you have three rounds on 26 November. Interviewers aren't named yet, so the persona weights rest on each round's format.

Say the word and I'll play the Skeptic on B2, the contact-centre question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Does the panel expect slides or a written piece for the 20-minute case, or is it verbal on the day? Knowing this changes whether the case needs a prepared structure you can show.
How much prep time do you have before 26 November?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep

**Loop:** three rounds on 26 November 2026. **Interviewers:** not yet named. **Built:** 17 November 2026.

**Read first**
- Three gaps will come up in every round: no contact-centre work (F4), nothing presented above regional level (F7), and no digital-journey work (F9). The first is the JD's opening requirement, so expect it early.
- Your strongest true material is the formal complaints log (F3) and the monthly spreadsheet (F5, F6). Both are real and both are narrower than the JD's wording. The prohibited list shows where each would break under a follow-up.
- The panel scores against the four values, and your material holds one sentence for each value at most. The honest answers are scaffolds with a plain "say so" branch. Rehearse those now; do not build stories on the day.

*Sections dropped because the input is absent: prep triage (prep time not given), interviewer read (no names yet), delivery coaching (no assessment offered), graded deliverables (none declared).*

## How to use

- **Personas** describe how a question arrives. **Types** describe what is scored: **VAL** values and behaviour, **EXP** work-experience deep-dive, **JD** a stated requirement, **CO** company and strategy, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- **Provenance:** `[grounded]` traces to your message, or to the JD, values and strategy text you supplied. `[generic]` is a pattern with no claim about you or Ashgrove. Any cell that says what you did quotes the sentence it rests on.
- "Your material" means the sentences in your message, quoted in the fit snapshot below.

## Loop map and persona weights

Each round has its own bank, and the banks are built to the round's format. Question counts are in brackets.

| Round | Length | Who | Format signal from the recruiter | Weights |
|---|---|---|---|---|
| 1. Recruiter screen | 30 min | Recruiter | Screen, logistics | Conversational 4, light Skeptic 1, logistics 4 [9] |
| 2. Head of Member Services (your future manager) | 45 min | HoMS | "mostly behavioural" | Skeptic 4, Values/Behavioral 4, Case 2, Pressure 2 [12] |
| 3. Panel of two branch managers | 60 min, including a 20-min case | Two branch managers | "the values round", scored against the four values | Values/Behavioral 4, Case 3, Prober 2, Peer Evaluator 2 [11] |

**Persona table (all rounds)**

| Persona | Round 1 | Round 2 | Round 3 | Why it weighs this way, and the counter-strategy |
|---|---|---|---|---|
| Conversational | 4 (A1 to A4) | — | — | The recruiter's register is casual, and casual questions are scored. Pre-scripted 90-second arc for the journey question. |
| Skeptic | 1 (A5) | 4 (B1 to B4) | — | Your future manager is buying derisking. The contact-centre and senior-presentation gaps are the objections most likely to be put to you. Counter: plain acknowledgment, then a plan. |
| Values/Behavioral | — | 4 (B5 to B8) | 4 (C1 to C4) | The HoMS round is "mostly behavioural", and the panel scores the four values. Counter: a story only where one of your sentences carries it, otherwise a scaffold with the honest branch. |
| Case/Strategist | — | 2 (B9, B10) | 3 (C5 to C7) | The 20-minute escalation case is the panel's live test. Counter: clarify before structuring, then say the tension out loud. |
| Pressure | — | 2 (B11, B12) | — | Your stated gaps are the natural pressure points. Counter: hold the position your sentence carries through two follow-ups, then concede exactly what is uncertain. |
| Data-Driven Prober | — | — | 2 (C8, C9) | The monthly spreadsheet invites a prober. Counter: say what it counts and how you would check it. Never defend a figure you cannot explain. |
| Peer Evaluator | — | — | 2 (C10, C11) | Branch managers sit at the seam between a branch and the contact centre. Counter: propose principles for the seam; claim no knowledge of it. |

Recruiter-screen logistics (A6 to A9) sit under the recruiter's prior. Conversational, Pressure and Prober are each tested in at least one round, so no style is met for the first time live.

## Fit snapshot (shared across rounds)

The JD requirements are quoted from your message. Your evidence is quoted from your message too; nothing is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it in your words: six years in retail banking, the last three as a branch supervisor. Expect a probe on whether branch work is what the requirement means by customer operations. Answer from what the branch's day-to-day covered, in your words. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | Say what the formal log was for, in those words. Expect a probe on which rules made an entry formal. Answer slot: if you knew the rules that set how fast an entry had to move, name them; if you did not, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material shows one branch's formal log, not the process end to end across branches or the contact centre. Keep the words at the log. Answer slot: if you set any stage of how a complaint moved from first contact to close, say which and how you decided; if the process was set elsewhere, say so and say what you did inside it. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn it, as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | transferability | The sentence reaches monthly complaint reporting. It does not say the spreadsheet counts resolution times. Answer slot: if it does, say what it counts; if it does not, say so and say what you would add. |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The sentence reaches the requirement in other terms. Words: the same sentence, unchanged. Limit: the spreadsheet is the proof, and you have not shown it yet. An anonymised copy with no member data would move this up (see the upgrade menu). |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material shows training tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached any supervisor on an escalation, say how; if you did not, say so and return to the tellers. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material shows this. Answer slot: if you worked with any team on something a member does without visiting a branch, say what you did; if not, say so and say how you would start. |

Gap types follow the routing rule in the rubric. F4 and F7 are `capability` because you stated the absence. F9 is `discovery` because the material is silent. Your material holds no sentence that is a gate, so no row is `hard_gate`. The JD states no location, schedule or credential bar.

## Prohibited claims

These are not to be coached, in any round. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches and the contact centre | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log". The limit is this pack's observation, not words for you: your material shows one branch's log. B3 and C10 stay inside the log. |
| Reported resolution times monthly | Inflated form of F5 | F5's quote at its own scope. The pack's observation: the material does not say what the spreadsheet counts. |
| Coached branch supervisors on escalations | Inflated form of F8 | "trained new tellers on our escalation script", at its own scope. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log". The pack's observation: your material says formal, not which rules applied. |
| Expert in Excel | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Presented to senior leaders | Negative you stated (F7) | Plain acknowledgment: "I haven't presented to anyone above regional level." |
| Worked in a contact centre | Negative you stated (F4) | Plain acknowledgment: "I haven't worked in a contact centre." |

## Grounding brief: Ashgrove's 2026 strategy

Source: your summary of the July 2026 strategy brief. The full brief was not supplied, so the strategy questions rest on the summary. The brief is about four months old, inside the window for current strategy.

- Move 40% of member service to digital channels by 2028. `[grounded]` "move 40% of member service to digital channels by 2028" (your message)
- Consolidate eight branches into five hubs over 2027. `[grounded]` "consolidate eight branches into five hubs over 2027" (your message)
- Launch a small-business lending product in Q1 2027. `[grounded]` "launch a small-business lending product in Q1 2027" (your message)
- Main competitive pressure: app-only banks. `[grounded]` "the main competitive pressure is app-only banks" (your message)

Vocabulary to use: member service, digital channels, hubs, small-business lending, app-only banks.

The tension to hold: the complaints process has to serve "every branch is part of its town" while the strategy closes branches and moves service online. Answer it; do not spin it.

## Round 1: Recruiter screen (30 min)

**Persona table:** Conversational top (4), light Skeptic (1), logistics (4). Logistics rows are the recruiter's own items, and each has a logistics slot, not a fact.

**Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." · "I handled the branch's formal complaints log" · "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using only these three sentences in order: the six years and the three as supervisor, the formal log, the monthly spreadsheet your regional manager uses. Leave out the escalation training until asked. Add nothing these sentences don't say. | The opener sets the first impression of scope. EXP because it tests what is yours. F1, F3 and F5 are the rows the arc draws on. |
| A2 | "What are you actually doing in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the spreadsheet is for and who uses it, in your words. Answer slot: if you can say where its data comes from, say so; if you cannot, say that plainly. | Casual register, scored. This is the R8 requirement in the recruiter's words. F6 holds the sentence. |
| A3 | "What's caught your eye about Ashgrove?" | CO | [generic] | Name one thing from the values or the strategy, the digital target or the hubs, and say what it means from the member's side. Use your own words, not theirs. | The recruiter checks motivation consistency. A specific reason beats praise. |
| A4 | "What's the part of this role you're most curious about?" | JD | [generic] | Pick the part you can answer from your own material, the complaints process or the reporting, and name one thing you would check first. | Conversational openers are scored. A view on the role beats no view. |
| A5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | Lead with the contact-centre part, plainly: "I haven't worked in a contact centre." Then the first thing you would do about it. | Skeptic-light. The honest answer is early in the process and it is the JD's first line. F4 holds the stated absence. |

**Logistics (recruiter prior: light Skeptic)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A6 | "What are you looking for on pay?" | JD | [generic] | Logistics slot: give your own target in your own words, or ask for the role's band before you name one. | Pay is a recruiter-screen item. The pack holds no figure from you, so it asks for none. |
| A7 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | Same. The answer is yours to give. |
| A8 | "Where are you based, and where could you work from?" | JD | [generic] | Logistics slot: give your actual location and working pattern in your own words. If you do not know which hub or branch the role sits in, ask. | The 2027 hub moves may change where the role sits, so the question is live. |
| A9 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your own reason in a sentence or two. Keep it about what you want, not about the branch or anyone in it. | Only your own reason is a safe answer. It must match the motivation in B4. |

**Reverse questions (round 1)**

- "Which hub or branch would this role sit in after the 2027 consolidation?" Lands because it is a logistics fact only the recruiter can give, and it shows you read the brief.
- "Who sits on the panel, and what is each member's part in the decision?" Lands because it signals process interest and lets you set the persona mix.
- "What has the complaints process been asked to change in the 2026 strategy?" Lands because it is a strategy-level question that matches the brief.
- "What happens between the panel and an offer?" Lands because it shows you plan past the interview.
- "What would make the first 90 days a success for whoever takes this role?" Lands as a preparation signal in a conversational register.

## Round 2: Head of Member Services (45 min, mostly behavioural)

**Persona table:** Skeptic top (4), Values/Behavioral (4), Case (2), Pressure (2). The relationship prior for a hiring manager is Case and Skeptic. The recruiter says the round is mostly behavioural, which moves Values/Behavioral up to match the Skeptic weight.

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see presenting to senior leaders in your background — how would you handle that part of this role?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then your plan for a senior audience, as a plan. Answer slot: if any of your monthly reporting went to your regional manager in a meeting, say what it was for; if it did not, say so. Hold the plan, not a past. | F7 is a stated absence, and the HoMS is buying derisking. The plan is the answer, and a claimed past would collapse on the first follow-up. |
| B2 | "You've never worked in a contact centre — why should we trust you to own complaints across it?" | JD | [grounded] "Never worked in a contact centre" | **Deepest rehearsal in this pack.** Level 1: "I haven't worked in a contact centre." Level 2, when they ask what carries over: name what you would do first, which is to sit with the contact-centre team and read how their complaints are logged, before you change anything. Level 3, when they press that you cannot know it yet: "I don't know how the contact centre routes complaints yet. That is what I would find out first." Never claim contact-centre knowledge, and never fold on the plain acknowledgment. | The highest-ROI prep. The JD's first requirement names the contact centre, and F4 is the stated absence, so this question will come in some form. |
| B3 | "Your complaints work is one branch's log — what's different about end to end across branches?" | JD | [grounded] "I handled the branch's formal complaints log" · JD: "Own the member complaints process end to end across branches and the contact centre" | Say what the log was, at its own scope. Answer slot: if you set any stage of how complaints moved from first contact to close, say which and how you decided; if the process was set elsewhere, say so and say what you did inside it. Name the first thing you would map across branches. | F3 is transferable. The raising source is the JD's own line, and the answer slot must allow that the stage was not yours. |
| B4 | "Why this role, and why now?" | EXP | [generic] | Say what you want to do in the role, from the member's side, and why now, in a sentence you can defend. No claim about your past. | Motivation consistency. Moving from a supervisor role to a lead role is the step a skeptic checks, and it must match A9. |

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B5 | "Tell me about a time you delivered an unpopular truth to a manager." | VAL | [generic] | Scaffold: pick a time you told someone above you something they did not want to hear about a complaint. It needs a named stake, a moment you did not fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing you did. | The HoMS is your future manager and the round is behavioural. The stem is the persona file's own example. |
| B6 | "Tell me about a formal complaint you handled and what happened to it." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped only as far as the sentence: name one entry in the log and what became of it, in your words. Answer slot: if you can name an entry and how it ended, say so; if the log only recorded entries you did not see through, say that and say what you would change. | Tests Own the Fix from the one thing you can point at. The honest answer is safe. |
| B7 | "When did you put a customer ahead of a number?" | VAL | [generic] | Scaffold: pick a time a member's outcome cost you something a figure rewarded. If none comes to mind, say so plainly, then give the nearest thing you did. | Neighbours, Not Numbers and Members First. The stem tests a value the spreadsheet could be read against. |
| B8 | "What made an entry in your formal complaints log formal, and which rules set how fast it had to move?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what made an entry formal, in your words. Answer slot: if no rules set how fast an entry moved, or you did not know them, say so; if you did, name them. | Covers the regulated-complaints requirement. "Which rules" presupposes rules, so the second branch must allow that you did not know them. |

**Case**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B9 | "A branch supervisor wants to close a complaint early, and the member has not agreed. You're asked to coach the supervisor. What do you say and do?" | CASE | [generic] | Clarify what the member has agreed and what is on the record. Objective: the member's outcome and an honest record. Approach: help the supervisor see the member's side first, agree the next contact, and check the record together. Metric: time to next contact, and whether the member accepts the close. Risk: a closed complaint the member reopens. | The live form of the coaching requirement. It presupposes nothing about you. |
| B10 | "Ashgrove plans to move 40% of member service to digital channels by 2028. Who would you need to work with first, and what would you bring to them?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message, summary of the July 2026 brief) | Name the team you would meet first, the digital team, and say what you would ask it first: which complaints start in self-service, and how they reach a person. Name the one thing you would bring from the branch side, in your words. If you cannot name one, say so. | Covers the digital requirement and the strategy's largest move. The answer must not borrow the contact-centre experience you lack. |

**Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B11 | "Sixty seconds: why you, for this role?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Open with what you have done and the plan for the gap. No negatives in the first sixty seconds. Hold a plan over a claim through two follow-ups. Concede the gap you have already named, specifically, and never fold on the core. | Pressure tests composure. The opening's content is fixed by your own sentence. |
| B12 | "That log — how much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Hold: say what you handled in the log, in its own words. Hold through two follow-ups by returning to the log. Concede the parts that were not yours, specifically, only where that is true. Do not fold to restore harmony. | Attribution is the test. The held position must be what the sentence carries, nothing more. |

**Reverse questions (round 2)**

- "What does this role need to have changed by the time the 2027 hub moves are under way?" Lands because it ties the role to the brief.
- "When the monthly complaints figures go out, what decision do they usually change?" Lands because it puts the spreadsheet into the values question.
- "Which branch's complaints would you most want reviewed in the first month?" Lands because it is specific and shows you think in cases.
- "What did the last person in this role leave unfinished?" Lands as a manager-level question.
- "How do you want to hear about a problem: first sight, or a written summary?" Lands because it shows you plan to work with them.

## Round 3: Panel of two branch managers (60 min, values scored, 20-min case)

The recruiter's email says this panel is the values round and scores against the four values. The values cheat sheet lives here.

**Persona table:** Values/Behavioral top (4), Case (3), Prober (2), Peer Evaluator (2). The panel relationship is unknown, so the weights follow the cross-functional values round, with a peer tilt because branch managers sit at the seam.

**Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter. What did you decide?" | VAL | [generic] | Scaffold: pick a decision where the member's side and the rule pointed different ways, and say which you chose and why. If the nearest one was mostly the rule's, say so. | Members First, Always. No sentence of yours carries a decision story, so the scaffold rules. |
| C2 | "Tell me about a time you explained a process to someone who needed it explained again. What changed?" | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped only to the training: say what you taught about the script, using only what the sentence states. Answer slot: if a teller needed it explained again, say what you changed in how you explained it; if that did not happen, say so and say what you would do to find out. | Plain Words. The value's test is a process explained twice, and the honest answer may be that it never happened. |
| C3 | "Tell me about a time the spreadsheet you built pointed one way when a branch's members needed the other." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the spreadsheet was for and who it went to, in your words. Answer slot: if a figure in it pointed one way and a branch needed another, say what happened; if none did, say so, and say what you would check before a figure decided something for a town. | Neighbours, Not Numbers. Your only numbers source is the spreadsheet, and "no such case" is an honest answer. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" · value text: "whoever finds the problem keeps hold of it until it is solved" | Name one entry you carried to a close, and what you did at each stage, in your words. Answer slot: if you can name one, say how it ended; if the log did not carry entries to a close, say so and say what you would change. | Own the Fix is the value a log-keeper finds hardest to show. The raising source is the published value. |

**Case**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "A member has been passed between three people about one complaint and says they will take it higher. You have twenty minutes. Walk us through what you do." | CASE | [generic] | Structure: clarify what has been said and what is on record. Objective: the member's outcome and an honest record. Approach: name one owner today, write back in plain words, and check the branch's step with the branch manager. Do not argue with the member about going higher. Metric: time to first honest contact, and whether the member knows the next step. Risk: a promise you cannot keep, or a file that says closed when it is not. Test each step against the four values. | The 20-minute scored case, and the panel's live test of presenting. It is hypothetical and makes no claim about you. |
| C6 | "The branch manager says it's closed. The member says it isn't. Now what?" | CASE | [generic] | Treat the member's account as the record until it is checked. Say who you would ask and what you would tell the member. Do not accept "closed by the branch" as closed. | The follow-up that tests Own the Fix under pressure from a manager. |
| C7 | "A town's branch moves into a hub during 2027. What would you look at in that town's complaints?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your message, summary of the July 2026 brief) | Clarify complaints by channel before and after the move. Look at the members who lose a branch and what the branch did for them. Say the tension between Neighbours, Not Numbers and a hub move in your own words, and do not spin it. If a real branch is named in the room, answer for the principle, not for that branch. | The one question where the strategy and a value collide. Naming the tension is what the values score rewards. |

**Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C8 | "What does your monthly complaints spreadsheet count, and how would you check it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it counts, in your words. Answer slot: if you cannot say what it counts, say so and say how you would find out. No figure is given here, so no defend-the-number slot applies yet. | R2 and R8 through the prober's lens. Asking for the counting method is the prober's habit. |
| C9 | "Who uses the spreadsheet, and what do they do with it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say who uses it and what for, in those words. Answer slot: if you know a decision it changed, say what; if you do not, say so. | Tests whether the report drives action. Branch managers may ask this to see if numbers serve members. |

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C10 | "Our teams sit side by side — where's the seam between a branch and the contact centre, and what happens when we disagree?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) · "Never worked in a contact centre" | Propose principles for the seam: who owns a complaint at each handoff, and what happens on disagreement. Do not claim to know this seam. Say plainly that you have not worked in a contact centre, and what you would ask. | The branch managers sit at the seam. The honest version is principles with no claimed knowledge. |
| C11 | "How do you handle credit when a complaint fix needs three teams?" | JD | [generic] | Say how you would name the people who did the work, and what you would bring to their teams. Make no claim about past credit. | Peer credit probe. The reciprocity framing is the answer. |

**Values cheat sheet**

| Value (official name) | Working meaning (paraphrase) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a decision. F3 holds the log only. Scaffold: pick one decision where the member's side and the rule pointed different ways. If the nearest was mostly the rule's, say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8 carries the training: "trained new tellers on our escalation script". Scaffold: pick an explanation you changed after it failed. If none changed, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | F5 carries the spreadsheet: "I built the monthly complaints spreadsheet our regional manager uses." Scaffold: pick a figure of yours that pointed one way while a town needed the other. If there was none, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 carries the log: "I handled the branch's formal complaints log". Scaffold: pick one complaint you carried to a close. If the log did not carry entries to a close, say so. |

**Reverse questions (round 3)**

- "What could a new person do in their first month that would genuinely help your branches?" Reciprocity, for a peer panel. Lands because it turns the interview into a working conversation.
- "Which of the four values is hardest to show in a complaint decision here?" Lands because it signals you have read them.
- "What does a good complaint outcome look like to a branch manager?" Lands because it asks for their standard.
- "How do you see the complaints process changing after the 2027 hub moves?" Lands because it ties the question to the brief.
- "What would you want the new lead to stop doing in their first quarter?" Lands as a candid operational question.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B2, B3, C5, C10 |
| Report monthly on complaint volumes and resolution times | A2, C8, C9. Resolution times are asked only through what the spreadsheet counts. |
| Coach branch supervisors on escalations | B9, C6 |
| Work with digital teams on self-service journeys | B10 |
| 4+ years in financial-services customer operations | A1, B11 |
| Experience handling regulated complaints | B8, B12 |
| Confident presenting to senior leaders | B1, C5 |
| Comfortable with Excel reporting | A2, C8 |

The most predictable objection, the one this pack rehearses most deeply, is B2: the contact-centre gap set against a requirement that names the contact centre.

## Sources

**Provided documents:** your message, which carries the JD text, the recruiter's three-round structure, the values as copied from ashgrovecu.org/about/values on 17 November 2026, your summary of the July 2026 strategy brief, and your background. **Not seen:** the full strategy brief, and the live values page, which was not re-checked.

**Research tier:** L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove values | skipped | The pasted values fix the four names and their meanings in the cheat sheet. No quick check was run. Check the live page before 26 November. |
| 2. interview process | skipped | The recruiter's three-round description fixes the loop: rounds, lengths, the case and the values scoring. |
| 3. strategy / recent news | skipped | Your summary of the July 2026 brief supplies the current priorities and the competitive frame. The full brief was not supplied. |
| 4. interviewer name and company | n/a | No names given. |
| 5. representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The full CV, in place of your message → fit rows F1, F2, F5 and F6 quote your CV's own wording, and the arc in A1 draws on it.
- The names of the Head of Member Services and the two branch managers → persona weights per person, and reverse questions tied to their career paths.
- A complaint volume or resolution-time figure, with what it counted → defend-the-number slots in A2, C8 and C3, and a stronger case answer in C5.
- An anonymised copy of the monthly spreadsheet, with no member data → F6 moves from medium to high, and C8 gets a real artifact to point at.
- The regulator and complaint rules that Ashgrove works to, if you know them → F2 and B8 get specific answers instead of the generic ones.
- The full July 2026 strategy brief → B10 and C7 quote the brief, not your summary.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent organisational context, and interviewer footprints once names are in. Offered once, and not run without your say-so.
- A `tuesday-dossier.md` → verified evidence and prohibited claims from a job-underwriter run, to tighten the fit snapshot.
