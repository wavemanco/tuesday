Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-8-denied-89b55e4a/e6394bca-4132-4e20-9a7c-bf1286117ca4/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it in loop mode, one mini-pack per round, on the shared fit snapshot. I used only what you sent: the JD text, your background, the recruiter's round outline, the values you copied, and your summary of the strategy brief. I didn't run any web searches, because those inputs already cover everything.

What matters most going in:

- **The fit snapshot is built on your own sentences.** Every claim about your past is either a quote of something you wrote or an answer slot you fill in the room. Two gaps are stated absences, so the pack gives you plain acknowledgments for them: you have never worked in a contact centre, and you have never presented above regional level. The pack's rehearsal for senior presenting is a plan for how you'd learn it, not a past.
- **"Regulated" is the word to watch.** Your material says "formal complaints log". The pack won't let you say "regulated" unless you can name the rules or timescales the log followed.
- **Round 3 is the one to weight most.** The panel scores against the four values, and the 20-minute case is an escalation where you should hold ownership until it's solved. The strategy's hub consolidation sits badly with Neighbours, Not Numbers, so expect that tension to come up.
- **Round 2 is mostly behavioural.** The Head of Member Services will be your manager, so the Skeptic questions on presenting, supervisors and the contact centre carry the most weight there.

I haven't run any drills yet, because a drill needs your answers turn by turn. Name a round and I'll start the drill with the recruiter's logistics questions, the Head of Member Services, or the escalation case.

Nothing in the pack needs an answer from you before you can use it. The upgrade menu lists what would sharpen it, mainly your CV, the spreadsheet's column headers, and the panel's names.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

Three rounds on 26 November 2026. Built 17 November 2026. Loop mode: one shared fit snapshot, then a mini-pack for each round.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words.
- Every claim about your past in this pack is either a quote of your own sentence or an answer slot, which is a question for you to answer in the room. Where your material says nothing, the pack says so and does not fill the gap.

## Shared: fit snapshot

Requirements are quoted from the JD you sent. Evidence is quoted from your message. The pack adds no words about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Say it as: "I have six years in retail banking, the last three as a branch supervisor." The material says retail banking, not customer operations, and the pack does not add the words. Confidence is medium because nothing has been inspected yet. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Say it in your own terms: "I handled the branch's formal complaints log." Your material says formal, not regulated. Answer slot: if the log followed a named regulator's rules or timescales, say which; if it followed the branch's own procedure, say so and describe it. |
| F3 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement. Lead with it as written. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | low | [inferred] | discovery | Your material shows a monthly complaints spreadsheet and says nothing about resolution times. Answer slot: if the spreadsheet recorded how long complaints took to close, say how it was counted; if it did not, say so and say what you would add first. |
| F5 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I've never worked in a contact centre." The branch experience is F2's quote, at its own scope. Do not say end to end. Answer slot: if any complaints reached you by phone or in writing, say how; if none did, say so and say how you would learn the contact-centre side. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | The quote is about tellers, not supervisors. Say: "I trained new tellers on our escalation script." The material does not show coaching a supervisor. Answer slot: if you coached a supervisor on an escalation, say what you did; if you trained tellers only, say that and say how you would coach a supervisor. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence is not an absence. Answer slot: if you worked with anyone on a digital or self-service process, say what it was and your part in it; if you have not, say so and say how you would learn it. |

No requirement in the JD is a gate in the sense of a licence, credential, location or schedule term. The "4+ years" line is a length of experience, graded on fit like the others.

## Shared: prohibited list

These claims are not coached in any answer, bridge or question in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F2 and F6 | "I handled the branch's formal complaints log." and "I've never worked in a contact centre." The pack's observation: the material shows the branch log, not the end-to-end process. |
| Handled complaints under a regulatory framework | Inflated form of F2 | "I handled the branch's formal complaints log." The pack's observation: your material says formal, not regulated. |
| Presented to senior leaders | Stated negative, F5 | "I've never presented to anyone above regional level." No slot. |
| Reported resolution times every month | Inflated form of F4 | The spreadsheet quote at its own scope. The slot asks only what it counted. |
| Coached branch supervisors | Inflated form of F7 | "I trained new tellers on our escalation script." |
| Wrote or designed the escalation script | Incident or practice: the quote says "our" escalation script | "I trained new tellers on our escalation script." |

## Shared: grounding brief

From your summary of the Ashgrove 2026 strategy brief. The brief's own text was not in the material, so the wording below is your summary, not a quote.

- [grounded] Move 40% of member service to digital channels by 2028.
- [grounded] Consolidate eight branches into five hubs over 2027.
- [grounded] Launch a small-business lending product in Q1 2027.
- [grounded] The main competitive pressure is app-only banks.

Round 3 is where the hub plan and the Neighbours, Not Numbers value meet. Use the strategy as background for questions you ask. Do not present it as something you know from inside Ashgrove.

## Round 1: recruiter screen (30 minutes)

**Persona weights.** Conversational 5, Skeptic 3. A recruiter screen is friendly in register, but the logistics and motivation questions are scored and the knockout checks are real.

| Persona | Weight | How it shows up | Counter-strategy |
|---|---|---|---|
| Conversational | 5 | Pay, notice, location, reason for leaving, and why this role | Answer each logistics item in your own words; keep the motivation answer tied to the JD |
| Skeptic | 3 | Probes on the four requirements you do not yet have fully covered | Give the plain acknowledgment where a negative is stated; stay in scope |

**Bank, round 1**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first before you give one. | Pay is a logistics check in every screen. The figure is yours alone. |
| R1-2 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | Notice is a logistics check. The answer is yours alone. |
| R1-3 | "Where are you based, and which branches could you work from?" | JD | [generic] | Logistics slot: give your actual location and the travel you can do, in your own words. | Location is not stated in the JD, so the answer stays yours. |
| R1-4 | "Why are you leaving your current role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Logistics slot: give your actual reason in your own words. Keep it short and factual. Your material does not supply a reason. | Reason for leaving is screened in every recruiter round. F1 is the only part of your history that frames it. |
| R1-5 | "Why this role, and why Ashgrove?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Lead with what you have done that the JD asks for: "I have six years in retail banking, the last three as a branch supervisor." Then your reason for applying, in your own words. Your material does not give one. | A motivation question is scored casually. Tie your history to the role's requirements, not to the strategy. F1 is the evidence. |
| R1-6 | "Walk me through the complaints log you handled." | JD, EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map from F2: the formal complaints log at the branch, in your words. Answer slot: if the log followed a named regulator's rules or timescales, say which; if it followed the branch's own procedure, say so and describe it. | F2 is the evidence for the regulated-complaints requirement and the likeliest probe. JD because the requirement is listed; EXP because it tests what you did. |
| R1-7 | "This role works with digital teams on self-service journeys. Have you worked on one?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you worked with anyone on a digital or self-service process, say what it was and your part in it; if you have not, say so and say how you would learn it. | F8 is silent in your material, so the answer has to come from you. |
| R1-8 | "This role covers the contact centre. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | Say it plainly: "I've never worked in a contact centre." Then what you did handle, within its scope: "I handled the branch's formal complaints log." | F6 is a stated absence. The plain acknowledgment needs no slot, and the bridge stays at the branch's scope. |

**Reverse questions, round 1**

- "What does a successful first three months look like for someone in this role?" Why it lands: it shows you are thinking about the job, not only about being hired.
- "How does the recruiting team hear about candidates' experience of the process?" Why it lands: it is a light question that signals you care about the member-side view of hiring too. No interviewer profile exists, so no question is tied to an interviewer's path.

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Persona weights.** Values/Behavioral 4, Skeptic 3, Case/Strategist 1, Pressure 1, Data-Driven Prober 1. Relationship priors for a hiring manager are Case and Skeptic. The recruiter's note that this round is mostly behavioural moves Values/Behavioral to the top. This person will be your manager, so the Skeptic bank carries the gaps.

| Persona | Weight | How it shows up | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | 4 | STAR-shaped prompts on the four values | Choose stories where you can name the stake; say where your material is silent |
| Skeptic | 3 | Questions on the gaps: presenting, contact centre, supervisors | Plain acknowledgment where stated; plan for the rest |
| Case/Strategist | 1 | How you would handle a member who cannot use the digital channel | Structure first; clarify before answering |
| Pressure | 1 | "How much of it was actually you?" | Hold what you built; concede what it does not show |
| Data-Driven Prober | 1 | How the monthly report measures resolution times | Say what the spreadsheet counts; say plainly what it does not |

**Bank, round 2**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-1 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses." | Open prompt. Pick a time you told someone above you a hard thing: name the stake, what you said and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the spreadsheet your regional manager uses. | The stem is a persona stem. F3 is the nearest sentence; the story has to come from you. |
| R2-2 | "When did you put a member ahead of an internal number?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: pick a time a member's need changed a figure or target you were reporting against. Name the stake and what you did. If none comes to mind, say so plainly and say what you would check first. | Neighbours, Not Numbers and Members First. F3 is the monthly numbers you own. |
| R2-3 | "Tell me about a complaint you kept until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map from F2: you handled the log, in your words. Answer slot: if you kept a complaint until it was solved, say how; if the log closed complaints without you following them, say so. | Own the Fix. The quote is the log; keeping hold to the end is not in it. |
| R2-4 | "We coach branch supervisors on escalations. Have you coached one?" | JD | [grounded] "coach branch supervisors on escalations" (JD) and "trained new tellers on our escalation script" | Answer slot: if you coached a supervisor on an escalation, say what you did; if you trained tellers only, say that and say how you would coach a supervisor. | Skeptic probe on F7's transferability. The answer stays in the tellers' scope unless you did more. |
| R2-5 | "You've never presented above regional level. How will you present to our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare and what you would practise first. | F5 is a stated absence. The plan is the only forward claim. |
| R2-6 | "Your experience is in a branch, not a contact centre. What do you do with that?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then what the branch side gave you: "I handled the branch's formal complaints log." Do not stretch that to contact-centre work. | F6 is a stated absence. The bridge stays at its scope. |
| R2-7 | "Walk me through how you would report monthly on complaint volumes and resolution times." | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Say what your spreadsheet counts and how, in your words. Answer slot: if it recorded how long complaints took to close, say how it was counted; if it did not, say so and say what you would add first. | The Prober's probe on F4's discovery gap. Resolution times are not in your material, so the honest branch is ready before the probe. |
| R2-8 | "A member cannot use the app and would rather phone or come in. What do you do?" | CASE | [generic] | Structure: what you need to know; what you would do for this member today; how you keep the same care across channels; what you would record. The guidance makes no claim about your past. | A live problem from the self-service requirement. The Case persona tests structure, not history. |
| R2-9 | "You built the spreadsheet. How much of the reporting was actually yours?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold: you built it, and your regional manager uses it. Concede: what it does not show, such as resolution times if it does not track them. Hold through two follow-ups; never fold on what you built. | Pressure. F3 is the position you can hold. The second follow-up breaks anything you cannot back. |
| R2-10 | "Tell me about a time you trained someone to handle something difficult." | VAL | [grounded] "trained new tellers on our escalation script" | Story map: you trained new tellers on the script, in your words. Answer slot: if you saw how the tellers handled an escalation afterwards, say what changed; if you did not see it, say so. | Plain Words and Own the Fix. The training is in your quote; what followed is not. |

**Reverse questions, round 2**

- "What would the first 90 days look like for someone coming from the branch side of complaints?" Why it lands: it names the difference between branch and contact centre and asks for a plan.
- "How will you measure whether this role is working at six months?" Why it lands: it shows you think in outcomes, and it gives you their measures.
- "As more members use self-service, where do you expect complaints to change?" Why it lands: it links to the digital requirement without claiming experience. No interviewer profile exists, so no question is tied to their path.

## Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

**Persona weights.** Values/Behavioral 4, Case/Strategist 3, Peer Evaluator 2, Data-Driven Prober 1. The panel scores against the four values, so Values/Behavioral is the top persona. The 20-minute escalation case sits with Case/Strategist. Two branch managers are peers to a Member Experience Lead, which puts the Peer persona in play.

| Persona | Weight | How it shows up | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | 4 | One question per value, scored against the four values | A story per value where your material carries one; the honest branch where it does not |
| Case/Strategist | 3 | The escalation case, plus two live problems on channels and branch complaints | Clarify, then structure, then answer; hold Own the Fix as the thread |
| Peer Evaluator | 2 | Where the seam is between branches and the contact centre | Propose seam principles; do not claim to know their seam |
| Data-Driven Prober | 1 | What the monthly spreadsheet counts | Say how it counts and what you would defend least |

**Values cheat sheet (values-style round)**

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: pick a complaint where the member's need changed what you did. If none comes to mind, say so plainly, then say what you did with the log you handled. Quote: "I handled the branch's formal complaints log" (F2). The quote carries handling, not the member's side, so say what you did. |
| Plain Words | If a member needs it explained twice, the writing was wrong | Scaffold: pick a time you explained something to a teller or a member so it landed first time. Quote: "trained new tellers on our escalation script" (F7). If you did not check that it landed, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: pick a time a branch's own situation changed a decision you were making. No sentence of yours carries this, so say so if none comes to mind and say what you would ask the branch first. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | Quote: "I handled the branch's formal complaints log" (F2). Scaffold: pick a complaint you kept until it was solved. If the log closed complaints you had not followed, say so. |

**Bank, round 3**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-1 | "Tell me about a time you put a member's side first." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a complaint where the member's need changed what you did. Name the stake and the decision. If none comes to mind, say so plainly, then say what you did with the log. | Members First. F2 is the only sentence about complaints you handled. |
| R3-2 | "Tell me about a time you explained something hard to a member or a teller so it landed the first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story map from F7: you trained new tellers on the script, in your words. Answer slot: if the explanation changed how a teller handled an escalation, say how you knew; if you did not check, say so. | Plain Words. The training is the quote; whether it landed is the slot. |
| R3-3 | "Tell me about a time a local view changed a decision you were making." | VAL | [generic] | Open prompt. Pick a time a branch's own situation changed a decision; name the stake. If none comes to mind, say so plainly and say what you would ask the branch first. | Neighbours, Not Numbers. No sentence of yours carries this, so the guidance makes no claim. |
| R3-4 | "Tell me about a complaint that came back to you after it looked closed." | VAL | [grounded] "I handled the branch's formal complaints log" | Answer slot: if a complaint came back after you closed it, say what you did until it was solved; if none came back, or you did not see it, say so and say what you would check. | Own the Fix. The quote is the log; the return and keeping hold are not in it. |
| R3-5 | "A member's complaint about a fee was marked closed a month ago with no reply. She now says she will take it outside the credit union. You are the branch manager. What do you do?" | CASE | [generic] | Structure: clarify what was closed, by whom and what she wants; acknowledge plainly; keep hold until it is solved; check the timescales and the rules that apply; name who owns the next step; say what happens next and when, in plain words; record what went wrong; say what you would change in the process. | The 20-minute case, scored on Own the Fix and Members First. It is a live problem and presupposes nothing about your past. |
| R3-6 | "Complaints are rising in one branch and nobody has said why. What is your first week?" | CASE | [generic] | Structure: what you check first (complaint types, staff, channel); who you talk to in the branch; what you tell the branch team; how you keep the numbers honest; what would make you escalate. | Neighbours, Not Numbers, under time pressure. The answer is structure, not a story. |
| R3-7 | "A member complains through an app. How do you make sure it gets the same care as one made at the counter?" | CASE | [generic] | Structure: what the app captures and what it misses; who sees the complaint and by when; how the app and counter routes meet; what you would measure. | The digital shift is the strategy's direction. The question is a scenario, not a claim about this employer. |
| R3-8 | "Our contact centre and our branches both take complaints. Where's the seam, and what happens when we disagree?" | JD | [grounded] "Never worked in a contact centre" | If asked about the contact centre: "I've never worked in a contact centre." Then propose seam principles: one owner per complaint, one record, one timescale. Do not claim to know their seam. | Peer Evaluator. F6 is a stated absence; the principles are a plan, not a past. |
| R3-9 | "How would you coach a supervisor who escalates too late?" | JD | [grounded] "trained new tellers on our escalation script" | Answer slot: if you coached a supervisor on late escalation, say what you did; if you trained tellers only, say how you would coach it. | F7's scope. This question raises the coaching requirement directly. |
| R3-10 | "What does your monthly complaints spreadsheet count, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Defend-the-number: say in your words how it counts complaints, the assumption you would defend least, and which part you built. If you cannot say how a figure was counted, say so. | Data-Driven Prober. No figure of yours is in the quote, so the slots ask how it was counted, not for a number. |

**Reverse questions, round 3**

- "What happens to a complaint that is open on the day a branch joins a hub?" Why it lands: it shows you are already thinking about Own the Fix during the consolidation.
- "How would the panel tell that a member's side was heard?" Why it lands: it asks for their scoring in concrete terms, which is what a values panel scores against.
- "What could a new person do in their first month that would really help your branches with escalations?" Why it lands: it is the reciprocity question a peer panel expects. No interviewer profile exists, so no question is tied to their path.

## Requirement coverage

| JD requirement or responsibility | Questions |
|---|---|
| 4+ years in financial-services customer operations | R1-5, R1-6 |
| Experience handling regulated complaints | R1-6, R2-3 |
| Confident presenting to senior leaders | R2-5 |
| Comfortable with Excel reporting | R2-9, R3-10 |
| Own the complaints process end to end across branches and the contact centre | R1-8, R2-6, R3-8 |
| Report monthly on volumes and resolution times | R2-7, R3-10 |
| Coach branch supervisors on escalations | R2-4, R3-9 |
| Work with digital teams on self-service journeys | R1-7, R2-8, R3-7 |
| Values (four) | R2-1, R2-2, R2-3, R2-10, R3-1 to R3-4 |

## Sources and target accounting

Provided documents: the JD text, your background, the recruiter's round outline, the four values copied from ashgrovecu.org/about/values this morning, and your summary of the July 2026 strategy brief.

Research tier: L1, searches 0 of 6, fetches 0 of 2. No search was sent. Every declared target is answered by material you provided, or has no name to search.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values you pasted fix the values cheat sheet |
| 2. Ashgrove interview process | skipped | The recruiter's round outline fixes the three rounds and the weights |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the four priorities in the grounding brief. The brief's own wording would firm the phrasing, not the bank |
| 4. Interviewer name and Ashgrove | n/a | No names were given for the Head of Member Services or the two branch managers. The interviewer read is absent; the upgrade menu says what names would unlock |
| 5. Representative JD | skipped | The JD you sent fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or a written summary of the complaints log's fields → F1 to F4 quote a document instead of your message, and their confidence can rise once there is an inspectable artifact.
- The headers of the monthly complaints spreadsheet, with no member data → settles whether resolution times were ever in it, which resolves F4 and R2-7.
- The names of the Head of Member Services and the two branch managers → personas weighted per person, an interviewer read, and a tailored reverse question for each round.
- The recruiter's notes on each round's focus → weights the round 3 case and the round 2 behavioural mix against what they actually said.
- The July 2026 strategy brief as sent → firms the grounding brief's wording from your summary to the brief's own text.
- Your notice period, pay expectation, location and reason for leaving → fill the logistics slots R1-1 to R1-4 in your own words. The pack will not supply them.
- Prep time before 26 November → adds a prioritised triage section for the rounds.
