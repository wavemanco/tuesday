I built a first-pass prep pack, but it's generic. My web searches for Stripe's values, interview process and recent strategy were refused because search permission isn't granted, so the pack has no Stripe-specific facts. I also don't have your CV or the job description yet, so nothing in it is drawn from your experience.

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-3-denied-c8933899/a5d56e4f-820e-4d67-843b-0a712aa8060e/scratchpad/stripe_product-operations-manager_interview_pack.md. It has 18 practice questions across six interviewer styles, five reverse questions to ask them, and a fit worksheet with selection prompts where your own material should go. Each answer prompt includes an honest fallback for when you have no example.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep: "Which part of this role would you be weakest at on day one?"
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Three things would sharpen it the most:

1. Who are you meeting, and is it one conversation or several? A hiring manager, a peer and an executive would each call for a different emphasis.
2. Can you paste the job description and your CV? That would replace the generic requirements with Stripe's actual wording and let the answers draw on your real experience.
3. Can you grant search permission so I can retry the Stripe research? That would add their values, interview format and current priorities.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Built without research and without a job description or CV. Everything below is `[generic]` unless marked otherwise. Company-specific facts (values, loop structure, current strategy) are missing; see Sources and the upgrade menu.

## How to use this pack

- **Personas** describe how a question arrives (friendly, skeptical, time-boxed, and so on).
- **Types** describe what is being scored: `VAL` behavioral/values, `EXP` your past work, `JD` the role's stated requirements, `CO` company knowledge, `CASE` a live problem.
- Guidance is scaffolding for a spoken answer of 90–120 seconds. It is not a script.

## Fit snapshot (worksheet variant)

No CV and no JD were provided, so every evidence cell reads `none given` and confidence is `none`. These are role-family requirements written as plain prose, labeled `[generic]`. They are not quoted from a posting. Each bridge says what to bring to the interview and gives an answer slot or selection scaffold in place of a claim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Owning an operating process end to end across several teams (role family) | none given | none | [generic] | discovery | Answer slot: name one process you ran from start to finish and say which steps were yours. If none, say so and say how you would learn it. |
| F2 | Metrics and dashboards that drive a decision (role family) | none given | none | [generic] | discovery | Answer slot: name a number you used to make a call, and what it was sensitive to. If you did not track one, say so and say what you would track first. |
| F3 | Working with product, engineering, risk and support at once (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a time two of these groups wanted different things. Say what you did, and whether the disagreement was resolved. |
| F4 | Running launches or programs with clear owners and dates (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a launch or rollout you helped run. Name the owner, the date, and what slipped. |
| F5 | Written updates for senior leaders (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a written update that changed a decision. Say who read it and what they decided. |

Gate rows: none. Work authorization, location, pay and notice period would be gates if a JD listed them. None was supplied.

## Prohibited claims

Nothing is listed yet. The pack holds no sentence of yours to stretch, so no inflated form exists to name. Once your CV is in, this list fills from it. Until then, do not claim a specific process, metric or launch you have not described to me in your own words.

## Persona weights

No round type or interviewer was given, so weights are flat. Every plausible persona is covered at depth 3 (or 2 for the lighter ones). Your answer to the round question in the message will reweight this table.

| Persona | Weight | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 3 | Live problem from the role | A final round for an ops role usually tests how you structure a problem | Clarify, then structure, then answer |
| Data-Driven Prober | 3 | Asks how a number was counted | Ops roles live on metrics | Name the weakest assumption before they do |
| Pressure | 3 | Interrupts, time-boxes, challenges | Final rounds often test composure | Pause, restate, hold two follow-ups, then concede specifically |
| Skeptic | 3 | "Why here, why now?" and gap probes | Final rounds often check motivation and gaps | Name your weakest area first, with a ramp plan |
| Conversational | 2 | Casual openers that are still scored | Common at the start of a final | Have a 90-second arc ready |
| Peer Evaluator | 2 | Seam and disagreement probes | Ops sits between teams | Propose seam principles, not a made-up history |
| Values/Behavioral | 2 | Scenario questions | Not detected as a named round, since no loop source was read | Use a selection scaffold; do not supply an ending you did not have |

## Question banks

Session totals: 18 questions.

### Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A new onboarding flow has raised support tickets by 30% in two weeks. How would you diagnose it?" | CASE | [generic] | Clarify what changed and when. Segment by merchant size, region, and integration path. Propose one check per hypothesis, then name the risk of acting too early. | A live problem an ops role meets. Generic because no posting or CV supplied a specific. |
| A2 | "Design an operating rhythm for a launch that touches product, engineering, risk and support. What do you need to know first?" | CASE | [generic] | Ask about scope, owners, decision rights and deadlines before proposing anything. Then give one cadence and one escalation path. | Tests structure before answers. Generic. |
| A3 | "Pick a process you think is broken at a company this size. How would you fix it without adding meetings?" | CASE | [generic] | Name the process and the symptom. Propose one change that removes work, not adds it. Say how you would know it worked. | Tests judgment about cost. Generic. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Think of a process you ran or shaped. What did you measure, and how was it counted?" | EXP | [generic] | Open prompt. Pick one process. Name the metric, the denominator, and the assumption you would defend least. Answer slot: if you did not measure it, say so and say what you would measure first. | Probers test whether the number holds up. Generic. |
| B2 | "Think of a number you reported. Which assumption behind it would you defend least?" | EXP | [generic] | Open prompt. Name the number and the assumption before the interviewer does. If you cannot say how it was counted, say that plainly. | Metric questions raise the weakest-assumption move. Generic. |
| B3 | "How would you know a process change worked, and what would make you say it did not?" | EXP | [generic] | Name one leading and one lagging signal. Say what result would make you roll back. | Tests whether you plan to be wrong. Generic. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has done this inside the company?" | JD | [generic] | Pause. Restate the question. Give your one strongest fit point, in your own words. Hold through two follow-ups. Concede specifically where an insider would be faster. | A stress probe on fit. Hold, then concede. |
| C2 | "That sounds like process work, not product work. Convince me otherwise." | JD | [generic] | Hold: name what the role decides, not only what it runs. Concede the part you would need to learn. | Tests whether you fold under a challenge. Generic. |
| C3 | "Most ops roles stall because people won't adopt the process. What is your answer?" | JD | [generic] | Name the adoption lever you would use first. Hold it. Concede one case where adoption failed, if you have one, or say you have not seen one yet. | Hold-then-concede structure. Generic. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area. Say what you already know about it, if anything. Give a ramp plan of two or three steps. | The most likely objection. Highest-ROI prep: rehearse this one until it is boring. Generic. |
| D2 | "Why are you leaving where you are, and why now?" | EXP | [generic] | Give your actual reason in your own words. Keep it forward-looking. Do not invent a story. | Motivation consistency probe. Generic. |
| D3 | "Ops at a company of this size is a different job from a smaller one. Why would you fit?" | JD | [generic] | Answer slot: name one thing about scale you have handled before, if any. If none, say so and say what you would do first. | A gap probe. Generic. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | Three beats in 90 seconds: what you did, what you learned, why this role. Use only what you can say from your own history. | Casual openers are scored. Generic. |
| E2 | "What have you been reading about payments or fintech lately?" | CO | [generic] | Name one public piece you actually read and one observation about it. Do not claim knowledge of internal Stripe work. | Casual, scored, and easy to fake. Generic. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our product and risk teams sit side by side. Where is the seam with ops, and what happens when we disagree?" | JD | [generic] | Propose a principle for the seam, such as who decides what. Give one disagreement story only if you have one. Otherwise say how you would handle the next one. | Seam probes return from peers. Generic. |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say how you name contributors and where you draw the line. If you have no example, give the principle you would use. | Peer credit probes. Generic. |

### Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth changed something. If none comes to mind, say so plainly, then give the nearest thing you have and how you would handle it. | Common in final rounds. No Stripe value is named, so the story is not mapped to one. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a case where the customer's need beat a number. Say what you gave up. If none, say so, and give the nearest case. | Values-style probe. Generic. |

## Reverse questions

Each one has a reason it lands.

1. "What does a strong first 90 days look like in this role?" Lands because it shows you are planning, not only interviewing.
2. "Which teams would this role work with most, and where do they disagree today?" Lands because it asks about the seam directly.
3. "What is the most common reason people in this role struggle?" Lands because it asks for candor and signals you expect difficulty.
4. "What decision from last quarter would you have wanted this role to make?" Lands because it shows you think about judgment, not tasks.
5. "How do you measure whether the operations this role supports are healthy?" Lands because it tests whether they measure at all.

No interviewer profile was provided, so no reverse question is tied to their career path.

## Requirement coverage

No JD was supplied, so there is no posting to map. The role-family requirements above are covered as follows: F1 by A2, B1, D3; F2 by B1, B2, B3; F3 by A2, F1, F2; F4 by A2, A3; F5 by C1, C3.

## Sources

- No documents were supplied beyond the request itself.
- Research tier: L0. Three searches were attempted and each was refused because search permission was not granted. No fetches were made.
- Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet. Calls refused: "Stripe values operating principles". |
| 2. Stripe interview process, product operations manager | unavailable | Loop structure and persona weights. Calls refused: "Stripe interview process product operations manager final round". |
| 3. Stripe strategy / recent news | unavailable | Current priorities for the CO bank. Calls refused: "Stripe news strategy 2026". |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative JD for the title | unavailable | Would have grounded the fit snapshot. No call was sent; the search budget was not spent, so this row records what it would have moved. |

Because these searches did not run, no Stripe-specific values, loop structure or strategy appear in this pack. Nothing here is drawn from memory of Stripe.

## Upgrade menu

- The job description → fit rows become quoted, and the coverage line becomes a real mapping
- Your CV → the worksheet becomes a fit snapshot, and selection scaffolds become story maps from your own sentences
- The round format and who you are meeting → persona weights and reverse questions are reweighted
- Search permission granted → the Stripe values page, the interview loop, and current strategy, which together turn the generic CO and values questions into specific ones
- A recruiter email asking which sessions the final round has → confirms whether it is one conversation or several
