I've built a first-pass pack, but it is generic. Web search was refused in this session, so I couldn't check Stripe's values, interview loop, or recent strategy, and I have no job description or CV from you. Nothing below about Stripe is sourced. Anything not drawn from your input is marked `[generic]`. The pack is in chat only, not saved as a file.

# Stripe, Product Operations Manager: final-round prep pack

Dropped for lack of inputs: prep triage, grounding brief, interviewer read, values cheat sheet, graded deliverables, and delivery coaching.

## How to use
Personas describe how a question is asked. Types describe what it scores: **VAL** behavioral/values, **EXP** your past work, **JD** the listed job, **CO** company knowledge, **CASE** a live problem. Guidance is scaffolding, not a script.

## Sources and research tier
Research tier: L1, searches 4 of 6, fetches 0 of 2, user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet dropped; VAL questions use generic behavioral scaffolds |
| 2. Stripe interview process, product operations | unavailable | Loop structure unknown; persona weights stay flat |
| 3. Stripe strategy / recent news | unavailable | No company-strategy (CO) questions written |
| 4. Interviewer name and Stripe | n/a | No interviewer named |
| 5. Representative JD | unavailable | Fit snapshot rows stay generic |

Calls sent, all refused: "Stripe company values operating principles" (target 1); "Stripe interview process final round onsite product operations" (target 2); "Stripe strategy news 2026" (target 3); "Stripe Product Operations Manager job description requirements" (target 5).

No loop source establishes the loop, so the generic archetype applies: flat persona weights, and no values-style round is assumed.

## Fit snapshot (worksheet: no CV or JD supplied)
The requirements below are role-family prose, not quotes from a posting.

| # | Requirement | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and improving cross-team operating processes | none given | none | [generic] | discovery | Answer slot: if you changed a process others depended on, name it and what changed. If not, say so, and say how you would map the current process first. |
| F2 | Metrics and reporting for a product organisation | none given | none | [generic] | discovery | Selection scaffold: pick a number you reported. Name how it was counted and the assumption you'd defend least. If you never reported one, say so. |
| F3 | Coordinating launches and cross-functional readiness | none given | none | [generic] | discovery | Selection scaffold: pick a launch you helped get out the door. Name your part and what others owned. If none, say so. |
| F4 | Prioritising requests across several teams | none given | none | [generic] | discovery | Selection scaffold: pick a time you sequenced or declined competing requests. Name the rule you used. If none, say so. |

## Prohibited claims
No candidate sentences are quoted yet, so no inflated-form entries can be built. Nothing is listed. The pack will not coach any claim about your past that you have not said yourself. This list is rebuilt when a CV or notes arrive.

## Persona weights
Round type is unknown, so weights are flat: three questions per persona, 18 in total. That is noticeably weaker than a weighted pack; knowing the round type would restructure it.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live launch or intake problem | High: the role is operating design `[generic]` | Clarify, then structure |
| Pressure | Time-boxed challenge to a claim | Medium: common in final rounds `[generic]` | Hold through two follow-ups, then concede the specific uncertainty |
| Values/Behavioral | STAR stories on hard truths and customers | Medium: generic behavioral pattern, no Stripe values round assumed | "We" for context, "I" for your part |
| Data-Driven Prober | How a number was counted | Medium | Name the definition and the weakest assumption |
| Skeptic | Where you are weakest | Medium | Name a real gap and a ramp plan |
| Peer Evaluator | Seams with the team, credit | Medium if a peer is in the loop | Propose seam principles, not facts about their team |
| Conversational | "Walk me through your journey" | High at the opening | A 90-second arc |

## Question banks
All rows are `[generic]`: no candidate material is quoted, so no guidance makes a claim about your history.

**Case/Strategist (flat weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A launch slipped two weeks and three teams give three reasons. How do you find out what happened?" | CASE | [generic] | Clarify what the launch was meant to deliver and by when. Build one timeline from records. Separate what happened from each team's account. Then propose the fix and how you'd test it. | Live problem from launch work (F3); tests structure, not history |
| C2 | "Cross-team requests to a product org are running at 200 a month. Design the intake." | CASE | [generic] | Ask about volume by type, who asks and who decides. Segment requests, set a response target and a review cadence. Name two metrics and what each could hide. | Intake design covers F1 and F4 |
| C3 | "What would you measure to know a product org is shipping well?" | CASE | [generic] | Name two or three measures and state each denominator. Say what each could hide. Ask what decision the number serves before choosing it. | Covers F2; tests judgement over vocabulary |

**Pressure (flat weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has run this function longer?" | JD | [generic] | Pause and restate. Answer from the one piece of operating work you know best: its stake, your part, the result you can attribute. Hold through two follow-ups. If no such piece comes to mind, say so, then give the nearest one. | Selection scaffold; no claim about your history is written |
| P2 | "That result: how much of it was actually you?" | EXP | [generic] | Name your part in one sentence and what others did in one sentence. Concede the shared part plainly. Never claim more than your sentence says. | Tests attribution under pressure |

**Values/Behavioral (flat weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time a hard message landed, or didn't. Give the situation, what you said, what happened next. "We" for context, "I" for your contribution. If it didn't land, say so and say what changed. | Generic behavioral pattern |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold. Name what the metric was and what you gave up for the customer. | Generic behavioral pattern |
| V3 | "Describe a process you changed that people resisted." | VAL | [generic] | Name who resisted and why. The test is whether you changed the process or changed your mind, and what you measured afterwards. | Covers F1 |

**Data-Driven Prober (flat weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you counted the last number you reported." | EXP | [generic] | Name the source, the definition and the denominator. Say what the number was sensitive to. If you didn't count it yourself, say so. | Defend-the-number question for F2 |
| D2 | "Which assumption behind your favourite metric would you defend least?" | EXP | [generic] | Name it before they do, then say what you'd check. If you have no metric you'd defend, name the one you'd build first. | Weakest-assumption move |
| D3 | "Two weeks of ticket data land on your desk. What do you check first?" | CASE | [generic] | Check definitions and data quality first, then the sample, then which decision the data informs. | Live data problem; asks nothing about your past |

**Skeptic (flat weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap. Give a ramp plan for the first 30 days. Don't bluff a skill you lack. | Calibrated candour over bluffing |
| S2 | "Which requirement do you have the least direct experience with?" | JD | [generic] | Name it in one sentence, then the nearest thing you've done and the limit of it. | Probes the gap without assuming one |

**Peer Evaluator (flat weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam with product ops, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their team. For disagreement, pick a time you pushed back with tact. If none, say so. | Peer probe in collegial packaging |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name whose work it was and how you described your part. Be specific, not modest by reflex. | Credit-sharing probe |
| E3 | "What would you need from my team to do this job well?" | JD | [generic] | Name two concrete inputs, and one thing you'd bring their team. | Reciprocity framing |

**Conversational (flat weight)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the through-line, why this role, what you want next. Build it from your own material once you share it. | Casual register is still scored |
| R2 | "What are you playing with in product operations these days?" | JD | [generic] | Name one tool or practice you've used and what it changed. If none, name one you're learning and say so. | A casual question on a hot topic is scored |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| F1 processes | V3, C2 |
| F2 metrics | C3, D1, D2 |
| F3 launches | C1 |
| F4 prioritising | C2, P1 |

## Reverse questions
1. "What does product operations do here that product teams would notice if it stopped?" Why it lands: asks what the function is for, in their words.
2. "Where do product and ops disagree most often about who owns launch readiness?" Why it lands: shows you think about seams.
3. "What is the team's biggest operational bottleneck this half?" Why it lands: surfaces current priorities.
4. "How will this role's success be judged in the first six months?" Why it lands: turns evaluation into planning.
5. "What would a strong first 30 days look like to you?" Why it lands: gets their picture of the job.
6. If a peer is in the loop: "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity.

## Upgrade menu
- **Round type and who you're meeting** → real persona weights instead of flat ones; reverse questions fitted to the round.
- **Paste the job description** → F1–F4 quote their wording, and the `[generic]` questions become grounded.
- **Your CV or notes on your work** → quoted evidence for each row, story-mapped answers in place of scaffolds, and a prohibited list built from your actual sentences. This is the biggest upgrade.
- **Permission to search** → Stripe's values, loop structure and strategy, plus company-strategy questions. A deeper pass, up to 6 more searches and 2 fetches, is also available if you want it.
- **Your interviewer's name** → reverse questions and persona weights from their public professional background.
- **Any recruiter note on focus areas or an exercise** → coverage of anything they announced.

Want a live round? I can play the Pressure interviewer on P2 and give feedback against its guidance. I can also save a `tuesday-dossier.md` logging the gaps this prep exposed, for later sessions.

Two questions:
1. Is the final one conversation or several back-to-back sessions, and who are you meeting in each?
2. Can you paste the job description and your CV, or a few lines on work you've done that this role touches?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.