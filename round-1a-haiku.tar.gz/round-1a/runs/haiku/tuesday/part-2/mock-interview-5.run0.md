Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-5-denied-075aa826/c07c0308-762b-412e-8df4-d984084f1bbf/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it on your message and the recruiter's email as you quoted it. I did not have the JD or the market report, so every row that depends on them is marked.

**What the pack says, in short:**

- **The POV is the highest-value prep.** It is built as open, three beats, and close, timed at 12 minutes spoken. Beat 1 uses your planning background, but only at its real scope: operator-side planning, not operator commercial relationships. The POV still needs three real operator facts from the market report before it can be finished.
- **Ross's likely first question is the quota gap** (B1). The answer is to concede first ("I haven't carried a quota"), then give the influenced number as influenced, then show how you'd set and track a target. Don't argue the gap.
- **The rail sales cycle** (B3) is a plan, not a claim. You have never sold into rail, so don't bluff it.
- **Prohibited claims:** no quota or closed-revenue claims, no rail selling claims, no "I know how TOCs buy", and no treating the £4M as yours alone.
- **Your ISV-to-operator gap** should be named before a probe names it (R4). Those were partners, not operators.
- **The drill plan** fits 4 hours: report and POV first, then timed POV runs, then the commercial drill, then a final pass through the prohibited list.

I didn't run web research. Permission for WebSearch was declined, so Kelverton's published values and current strategy are unchecked.

Two offers, neither pushed:
- I can play Ross and run B1 with reactive follow-ups, then give feedback against that question's own guidance.
- I can save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions.

Three questions that would change the pack:
1. Can you paste the JD, and the 3 to 5 operator findings from the market report that matter most?
2. Does Kelverton expect anything written before Tuesday, or is the POV spoken only?
3. Do you want me to try web research on Kelverton? If so, you'll need to approve WebSearch.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, panel, Tuesday. 60 minutes: 15-minute spoken POV, then Q&A.
**Panel:** Deepa (VP Partnerships, your future manager); Ross (Commercial Director, will push on commercials).
**Built on:** your message and the recruiter's email as you quoted it. The JD text and the internal market report were not in my context, so every row that depends on them is marked.
**Research tier:** L0 (provided documents only). Web search was declined this session, so nothing about Kelverton's published values or current strategy has been checked.

## How to use + type key

- **Personas** = how the question is asked. **Types** = what is being scored.
- **VAL** Behavioral / values. **EXP** Work-experience deep-dive. **JD** Role-driven. **CO** Company and strategy. **CASE** Live problem.
- Guidance is scaffolding, not a script. Rehearse the structure, then say it in your own words.

## Prep triage (about 4 hours)

1. **The POV (highest ROI).** The 15 minutes are scored on whether you land on what it means for operators. Build it from the market report's operator findings first (see the POV section below).
2. **B1, the quota question.** Ross will likely open here. Rehearse the hold-then-concede answer until it is plain.
3. **B3, the rail sales cycle.** You have never sold into rail. Have a credible plan ready, not a bluff.
4. **Everything else is insurance.** Skim it once.

## The POV: structure and timing (12 minutes spoken, 3 minutes slack)

Speak it, don't read it. Use three beats, each one sentence on a card.

- **Open (1 min): the operator's problem in 18 months, in the operator's terms.** Take it from the market report: which operator pressure is rising (cost, performance, reliability, franchise or contract change). Do not open with Kelverton's product.
- **Beat 1 (3 min): what changes for operators.** Name the outcome they will be measured on. Use your transport planning background here, quoted as it stands: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." Do not stretch that to claim TOC commercial experience.
- **Beat 2 (4 min): three partnership moves that deliver that outcome.** Each move ends in an operator metric, not a Kelverton one. Example shape: "Move 1, reach the operator's planning team, not only the procurement team, because that is where the scheduling pain sits."
- **Beat 3 (3 min): the first 90 days and what you would stop.** One thing to measure, one thing to drop. This is where you show you think like a commercial leader without quota history.
- **Close (1 min): what it means for operators, in one sentence.**

**Answer slot:** the market report's operator findings are not in this pack. Your POV needs at least three real operator facts from it. Paste them in and this section is regenerated with them.

## Fit snapshot

Requirements are the recruiter's own words, quoted from her email as you supplied it. The JD was not supplied, so no other requirement is quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Ross will push on commercials" (recruiter's email) | "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | Stated by you, so the words are yours: "I haven't carried a direct quota. I've carried influenced revenue, and I can show you how I'd tie that to a target." Answer slot: what conversion from influence to closed revenue, if you know it. |
| R2 | "operator partnerships" (recruiter's email) | "Never sold into rail specifically" (your message) | none given | [grounded] | capability | Stated absence, so the words come from it: "I haven't sold into rail." Then a plan, said as a plan, not as a past. |
| R3 | "where you'd take our operator partnerships" (recruiter's email) | "5 years in transport consulting (bus and light rail network planning...)" (your message) | medium | [grounded] | transferability | This carries adjacent work: operator-side planning, not operator commercial relationships. Quote it at its own scope. Any wider step is an answer slot. |
| R4 | "build and manage partnerships" at scale (role-family, [generic]) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | none | Strong, but these were ISV partners, not operators. Say so before a probe does. |
| R5 | "what it means for the operators themselves" (recruiter's email) | none given | none given | [grounded] | discovery | Silence in your material, so the words are an answer slot: what you know about operator outcomes from the report and from your planning work. |
| R6 | Scheduling and rail operations domain (role-family, [generic]) | none given | none given | [generic] | discovery | Answer slot: how you would learn the domain in your first 90 days. |

## Prohibited claims

Built locally from the fit snapshot. None of these will be coached.

- **"I carried a quota / closed £X direct."** Basis: "never carried a direct quota, only influenced revenue." Honest form: "I influenced £4M of revenue, through partners, and I have not carried a quota."
- **"I sold into rail / I know how TOCs buy."** Basis: "Never sold into rail specifically." Honest form: "I haven't sold into rail. Here is how I'd learn the buying process."
- **"I know the operator world as an operator."** Basis: transport consulting, bus and light rail network planning. Honest form: "I've worked on the planning side for operators, not on their commercial side."
- **"I drove the £4M."** Basis: "roughly £4M of influenced revenue." Honest form: "£4M influenced, and I'd say how much of that was mine versus the partner's own sales if asked."

## Persona weights

| Persona | Who | Likelihood | Why | Counter-strategy |
|---|---|---|---|---|
| Strategist | Deepa | high | She is buying capability for a senior role and will test the POV's logic and your 90-day plan. | Build the POV so each move has a reason and an operator metric. Rehearse the Q&A follow-ups out loud. |
| Skeptic / Data-Driven Prober | Ross | high | A commercial director pricing an unproven commercial hire. Your quota gap is the first thing he will find. | Concede first, then reframe with the numbers you do have. Don't argue the gap. |
| Conversational | both | low | The warm-up or the "why rail" question. | Keep the answer short and true. |
| Values / Behavioral | Deepa | low to medium | Partnerships managers usually get a "tell me about a time" question. | Use a real partner story, with what you did, not what the team did. |

Reasoning: no interviewer profiles were supplied, so these weights rest on the round type and the recruiter's warning about commercials. Correct them if you know more.

## Question banks

### Strategist (Deepa): A

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | CASE | "What would you do in your first 90 days?" | [inferred] your message: "9 years in partnerships" | Learning plan first: which operators, which planners, what you need to learn. Three steps, each with a result you would expect. | The POV will have set this up; she will test whether your plan is specific. |
| A2 | CO | "What would you stop doing in operator partnerships?" | [inferred] no quote; answer slot | Name one practice that does not fit operators. Give the reason from your own experience. | Tests judgement, not enthusiasm. |
| A3 | VAL | "Tell me about a partner relationship that went wrong." | Answer slot: "took it from 6 partners to 40" (your message) only if you fixed a failing partner | Use a real case: what was wrong, what you changed, what the result was. If you have none, say so and pick the closest. | Partnerships roles are judged on how you handle failure. |
| A4 | EXP | "You ran ISV partners, not operators. What transfers?" | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Name two things that transfer (partner recruitment, enablement, a scoring model) and one that does not. | Exposes the gap early and fairly. |

### Skeptic / Prober (Ross): B

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | EXP / JD | "You've never carried a quota. Why should we trust you with a number?" | "never carried a direct quota, only influenced revenue" (your message) | **Hold, then concede.** "I haven't carried a quota." Then the number you do have, labelled as influenced. Then how you would set and track a target. Answer slot: any conversion data you have. | Your highest-ROI prep. Concede plainly and move to the plan. Don't defend the gap. |
| B2 | EXP | "£4M of influenced revenue. How much was you?" | "roughly £4M of influenced revenue" (your message) | Give your share honestly, with the method. If you can't split it, say that and say how you would. | Tests whether you can separate influence from ownership. |
| B3 | CO / CASE | "Rail sales cycles are long and procurement-led. What's your pipeline logic?" | [generic]: long cycles are a general pattern, not a sourced figure | Lay out stages and what moves a deal between them. Say where your ISV experience maps and where it does not. | You have never sold into rail; the answer is a plan, not a claim. Check the cycle length against the market report. |
| B4 | CO | "You know the operator world from consulting. Who signs, and what do TOCs actually buy?" | "5 years in transport consulting (bus and light rail network planning...)" (your message) | Be precise: planning-side knowledge, not commercial buying knowledge. Name what you would need to learn. | Ross will check whether your claim stretches to rail commercial decisions. |
| B5 | JD | "What's a realistic first-year number for you?" | Answer slot | Give a range with the assumptions behind it, and say what you do not yet know. | Commercial directors test whether you will commit to a number. |

### Conversational / Values: C

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | VAL | "Why leave payments for rail?" | "9 years in partnerships, last 4 at a payments company" (your message) | A true reason, in two sentences. Answer slot: your actual reason. | Motivation-consistency check, often asked early. |

## The POV in practice: pairing

Rehearse the POV, then B1 and B3 right after. Ross will almost certainly follow the POV with a commercial question.

## Reverse questions (at least five, why each lands)

1. **To Deepa:** "What did the last partnerships hire get right and wrong in the first six months?" Lands because it is tied to her path and shows you plan to be useful.
2. **To Deepa:** "Which operator relationships are strongest now, and which are the 18-month swing ones?" Lands because it shows you are already thinking in operators.
3. **To Ross:** "How is partnership performance measured today: bookings, influence, or contracted value?" Lands because it turns the quota gap into a question about the measure.
4. **To Ross:** "What would make you say in 12 months that this hire worked?" Lands because it frames success in his terms.
5. **To both:** "What's the biggest operator objection to the product right now?" Lands because it signals you go to the customer's problem first.

## Mock drill plan (about 4 hours)

| Time | Task | Output |
|---|---|---|
| 0:00 to 0:30 | Read the market report. Pull three operator facts. | Three facts, each with its source line. |
| 0:30 to 1:15 | Write the POV on cards: open, three beats, close. | Cards, one sentence each. |
| 1:15 to 2:00 | Speak the POV aloud, twice, timed at 12 minutes. Fix the weakest beat. | A timed run. |
| 2:00 to 2:45 | Drill B1 and B3 with a reactive follow-up. | Two answers in your own words. |
| 2:45 to 3:30 | Run the Q&A drill across A and B banks. Note any answer that stretches a claim. | A list of stretched answers to cut. |
| 3:30 to 4:00 | Re-read the prohibited list. Sleep. | Nothing new. |

## Sources

- Provided: your message; the recruiter's email as you quoted it.
- Not provided: JD text; the internal market report (read by you, not pasted here).
- Searches: none. Web search was declined in this session. Company values and strategy: not checked.
- Target accounting: research tier L0. Company research: skipped (permission declined). JD: not supplied. Interviewer profiles: not supplied.

## Upgrade menu

- JD text → the R-rows become [grounded] against the full requirement list, and the B5 answer slot gets a sourced anchor.
- The market report's three to five operator findings → the POV opens on real operator data and the Beat 1 and Beat 2 moves become checkable.
- Deepa's and Ross's public background → persona weights and a tailored reverse question for each.
- Permission for web research → the company's published values and current strategy get checked, not assumed.
