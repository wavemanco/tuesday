Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-5-denied-98df3f43/ffbe77d4-292b-44f9-9daf-15fde64ad35e/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It has the fit snapshot, the POV build, the persona table, 18 questions, the prohibited claims, and the upgrade menu.

**Research didn't run.** The host refused web search, so I have nothing on Kelverton's values, interview process, strategy, or Deepa and Ross's backgrounds. The pack is built only on your message and the recruiter's email. If you grant web search, I can rerun the research.

**Prep triage (about 4 hours)**
1. **90 min: build the POV.** Pick one thesis and state its concession. Speak it twice against a 15-minute timer, ending on what it means for operators.
2. **60 min: Ross's commercial questions.** The £4M figure is the one to rehearse hardest.
3. **45 min: Deepa's skeptic questions.** Start with the rail gap.
4. **30 min: reverse questions and the 90-day plan.**
5. Everything else is insurance.

**The POV.** The recruiter asked for a POV, so it's graded. Three theses, each with a required concession:
- **T1: Treat operators as planners, not buyers.** Built on your network-planning years. Concession: you haven't tested the planning constraint from a rail buyer's seat.
- **T2: Partner-led reach in rail needs a different partner type from the ISV model.** Concession: procurement may stall it.
- **T3: Judge partnerships by what happens to the operator, not partner revenue.** Concession: operator outcome data is hard to get, so you'd start with partner-sourced measures.

I haven't seen the internal strategy report, so I can't tell you which consensus items to avoid. Bring one item from it to show you've read it, then one place you depart from it, with reasons.

**Your two biggest exposures**
- **Rail sales (Deepa's D1).** Say "I haven't sold into rail specifically" plainly, then give your network-planning years in one line. Don't reach for the influenced revenue as a substitute.
- **The £4M figure (Ross's A1 and B1).** Keep the wording as "influenced." Be ready to say how it was counted, what it's sensitive to, and which part was yours. If you didn't track something, say so.

Don't claim quota ownership, rail buyer relationships, or that you "drove" the £4M. Your material supports only what you said: influenced revenue, partners taken from 6 to 40, and operator-side planning work.

**Two questions**
- Can you paste the job description? It would add the gate rows and the requirement-by-requirement questions. Without it, the pack is built on your message and the recruiter's email only.
- Want me to play Deepa on D1 and give feedback against its guidance? Say the word.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, round 2 panel prep

**Interviewers** (names and titles from your recruiter's email): Deepa, VP Partnerships, your future manager; Ross, Commercial Director. No public footprint was researched, so there is no interviewer read.
**Format:** 60 minutes. First 15 minutes a spoken POV, no slides, on where you would take operator partnerships over 18 months, landing on what it means for the operators. Then Q&A, with Ross pushing on commercials.
**Built on:** your message and the recruiter's email. No job description was supplied.
**Changes:** first pack.

## How to use

Personas are how a question arrives. Types are what it scores: VAL values, EXP your experience, JD the role, CO company and commercial mechanics, CASE a live problem. Guidance is scaffolding, not a script. Say it in your own words.

Research tier: L1 — searches 4 of 6, fetches 0 of 2 (all four refused; see Sources)

## Prep triage (about 4 hours)

1. **90 min: build the POV** (section 5). Pick one thesis and its concession, then speak it twice against a 15-minute timer. It must end on what it means for operators.
2. **60 min: Ross bank**, A1 to A4 and B1 to B4. Say each answer aloud once, including the honest branch of each answer slot. The £4M figure is the one to rehearse hardest.
3. **45 min: Deepa bank**, D1 and D3. D1 is the highest-ROI prep in this pack.
4. **30 min: reverse questions and the 90-day plan** (C1).
5. Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter email | "9 years in partnerships" — your message; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material shows partnership work and operator-side planning work, not operator partnerships run from the vendor side. Bridge, in your words: "Five years in transport consulting, bus and light rail network planning." Limit, as my analysis: the material does not show you managing operator partnerships. |
| F2 | "Ross will push on commercials" — recruiter email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | presentation | Bridge, using the quote's own words: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Expect a probe on how the figure was counted. |
| F3 | Direct revenue ownership (role-family expectation, no JD supplied) — [generic] | "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | capability | Stated absence. Plain acknowledgment: "I haven't carried a direct quota." Then how you would learn to run one, said as a plan, never as past work. |
| F4 | "sells scheduling software to train operating companies" — your message (your description of Kelverton) | "Never sold into rail specifically" — your message | none | [grounded] | capability | Stated absence. Plain acknowledgment: "I haven't sold into rail specifically." Then how you would ramp on the rail buyer, said as a plan. |
| F5 | "sells scheduling software to train operating companies" — your message | "bus and light rail network planning" — your message | low | [inferred] | transferability | Planning work is adjacent to scheduling software but is not the same thing. Bridge: "I did bus and light rail network planning for five years." Answer slot: if you used scheduling software in that work, name which; if not, say so. Derivation: adjacency of network planning to scheduling, not a stated link. |
| F6 | "operator partnerships" — recruiter email | "running the ISV channel" — your message | medium | [grounded] | transferability | Bridge: "I ran the ISV channel at a payments company." Limit, as my analysis: ISVs build on the platform; Kelverton's operators are the buyers. The channel mechanics may carry over; the partner type does not. |
| F7 | "land on what it means for the operators themselves" — recruiter email | none given | none | [grounded] | discovery | Answer slot: if you have seen what a partnership changed for a customer's own results, say what it was; if you have not, say so and say how you would find out. |

No gates identified: the recruiter's email names no location, right-to-work or other term, and no job description was supplied.

## 5. Graded deliverable: 15-minute spoken POV

**Declared by the recruiter:** a short POV, no slides, on where you would take operator partnerships over 18 months, landing on what it means for the operators themselves. Talk it through; no written deliverable.

**Facts to build on:** F1, "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message. F6, "running the ISV channel" — your message.

**Theses (pick one; each carries its concession):**

- **T1: Treat operators as planners, not buyers.** Built on F1. Concession: this assumes operators' planning constraints are the binding problem, and you have not tested that from a rail buyer's seat.
- **T2: Partner-led reach in rail needs a different partner type from the ISV model.** Built on F6. Concession: operators buy through procurement, so the change may stall there, and you should expect that objection.
- **T3: Judge partnerships by what happens to the operator, not by partner revenue.** Concession: operator outcome data is hard to get, so you would start with partner-sourced measures and say so.

**Differentiation:** the report your strategy team circulated is the consensus answer any prepared candidate has read. This pack has not seen its contents, so it cannot say which items the report lists. Bring one consensus item to show grounding, then one divergence with your reasons. Name one operator segment you would not chase first, and why (the anti-pick).

**Requested close, [generic]:** name one operator-facing outcome you would measure, and the operator-side team that would notice it first.

## 8. Persona table

| Persona | Member | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Pressure / Stress | Ross | Challenges the £4M and the quota gap; time-boxes answers | High: the recruiter says he will push on commercials | Hold through two follow-ups, then concede specifically |
| Data-Driven Prober | Ross | Asks how the influenced figure was counted and what it is sensitive to | High: "influenced" invites the denominator and attribution questions | Name the weakest assumption before he does; say what you did not count |
| Case / Strategist | Deepa | The 90-day plan, operator segments, the POV challenged live | High: the POV is her round and she will test its thinking | Clarify, objective, segment, approach, metrics, risks |
| Skeptic | Deepa | Rail gap, quota gap, why leave | High: she is the future manager and carries the hire's risk | Plain acknowledgment, then a ramp plan |

Values and Conversational personas are dropped: no loop source names a values round, and the recruiter's words set a POV and Q&A, not a rapport round.

## 9. Question banks

Depth follows weight: Ross and Deepa each carry two personas. Types show what is scored; primary type only.

**Ross: Pressure (A)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sixty seconds: why should we believe that roughly £4M of influenced revenue is yours?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Hold the figure in its own word, "influenced." Answer slot: say how the figure was counted, in your words. If you did not count it, say so and name the part you can vouch for. Concede the specific gap, never the number. | F2 is the commercial headline, and a pressure round goes for it first. |
| A2 | "You've never carried a direct quota. Why would we hand you a revenue number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" — your message | Plain acknowledgment: "I haven't carried a direct quota." Hold through two follow-ups by returning to what you did: "I took it from 6 partners to 40." Concede: "I wouldn't commit to a number before we agree how it is measured." | F3 is the likeliest commercial objection. Hold, then concede specifically. |
| A3 | "You took it from six to forty partners. How many of the forty were productive?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Answer slot: if you tracked how many partners produced revenue, give the count and how you counted. If you did not track it, say so and say what you would measure first. | A pressure round asks for the denominator under a headline. "Not tracked" is an honest branch. |
| A4 | "In a partner-led motion, how do you split credit between you and the partner?" | CO | [grounded] "roughly £4M of influenced revenue" — your message | Answer slot: if you had a credit rule, say it. If none existed, say so and say the rule you would propose. Do not invent a split. | "Influenced" invites the credit question, which is a commercial mechanism. |

**Ross: Prober (B)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Defend-the-number slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Each in your own words. Name the weakest assumption before he does. | The defend-the-number rule for this figure. |
| B2 | "How much of that growth was actually yours, and how would you know?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Answer slot: if you can separate your work from the growth around it, say how. If you cannot, say so, and say what would let you separate them. | An attribution probe. The question names no practice the quote lacks. |
| B3 | "How do you know influenced revenue was not partners' own pipeline?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Answer slot: if you tested the figure against partners' own pipeline, say how. If you did not, say so and name the test you would run. | The standard challenge to an influence figure. |
| B4 | "You've spent five years on the operator side. Which planning decision there would a scheduling tool have changed?" | CO | [grounded] "5 years in transport consulting (bus and light rail network planning...)" — your message | Answer slot: name a planning decision you made in that work, in your words. If the work did not touch scheduling tools, say so and say what you would check first. | Tests whether F5's adjacency is real, and keeps the answer at the scope of the work. |

**Deepa: Skeptic (D)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never sold into rail. Why you over someone who has?" | JD | [grounded] "Never sold into rail specifically" — your message | Plain acknowledgment: "I haven't sold into rail specifically." Bridge in the quote's terms: "Five years in transport consulting, bus and light rail network planning." Hold once. Concede: "I'd ramp on the rail buyer, and here is how I'd do it." | The highest-ROI prep in this pack: the gap every panel sees first. Practise saying it in one breath. |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the quota or rail-buyer part plainly, then the ramp. Do not present a strength as the fix. | A skeptic stem. The honest answer is F3 or F4. |
| D3 | "I don't see direct rail sales or quota ownership in your background. How would you handle that?" | JD | [grounded] "Never sold into rail specifically" and "never carried a direct quota" — your message | Plain acknowledgment: "I haven't sold into rail, and I haven't carried a direct quota." Then the ramp, said as a plan. Do not reach for the influenced figure as a substitute. | Both gaps are your own stated negatives, so the acknowledgment is sourced. |
| D4 | "Why leave a payments company for rail?" | EXP | [generic] | Answer slot: give your actual reason in your own words. Your material gives none, so do not borrow one from the POV. | Motivation consistency. The reason is yours to supply. |
| D5 | "Name one signal that would tell you this hire is not working, and how early you would see it." | JD | [generic] | Name one operator-facing signal and one partner signal, and when each would show. | A skeptic's exit question. It tests whether you know what success looks like. |

**Deepa: Case / Strategist (C)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the first 90 days for operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify, objective, segmentation, approach, metrics, risks. Speak the framework aloud before using it. | The 90-day plan is the usual follow-up to a POV. No claim about your past. |
| C2 | "What would an operator need to see before committing to a partnership?" | CO | [generic] | Structure it: who decides, what proof they need, what it costs them to switch. Name one thing you would ask them first. | The operator-side question the POV's close depends on. |
| C3 | "Which operator segment would you not chase first, and why?" | CASE | [generic] | Name the anti-pick and what it costs you to say no. | Tests the POV's anti-pick. |
| C4 | "Pick one of your three theses. What would change your mind?" | CASE | [generic] | State the concession and the evidence that would change your view. | Tests the mandatory concession. |
| C5 | "What would you measure at month six, and what would it tell you about the operators?" | CASE | [generic] | Name one operator-facing measure and one partner measure. Say which you would trust more, and why. | Connects the POV's close to measurement. |

**Coverage line.** Recruiter's requirements, mapped to question IDs: operator partnerships (F1), commercials (A1 to A4, B1 to B3), rail and quota gaps (D1, D3), operators' own outcomes (F7, C2, C5), POV (section 5, C1, C4). No job description was supplied, so no JD-tagged row maps to a posting requirement.

## 11. Reverse questions

1. **To Deepa:** "What did the last person in this seat get right in their first 90 days, and what did they get wrong?" *Why it lands:* it treats her as the person who knows what the seat needs, and it shows you are thinking about the job, not the offer.
2. **To Deepa:** "What would make you say in six months that this was the right hire?" *Why it lands:* it asks her to name the bar, which is what a future manager wants to talk about.
3. **To Deepa:** "Which operator relationship would you most want the new lead to inherit?" *Why it lands:* it shows you think about the operator book, and it does so by asking.
4. **To Ross:** "When a partner's revenue is influenced rather than sourced, how does the commercial team decide credit?" *Why it lands:* it goes straight to his territory and invites him to talk about how he runs the numbers.
5. **To Ross:** "Which operator teams own the scheduling budget, and how does that shape a partnership deal?" *Why it lands:* it shows operator-side thinking through a question, without claiming any operator-side experience.

No reverse question ties to an interviewer's own career path, because no profile was researched.

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I carried a quota" or "I owned a revenue target" | Sourced: your stated negative, "never carried a direct quota" | "I haven't carried a direct quota." Plain acknowledgment. No slot. |
| "I've sold into rail" or "I know rail buyers" | Sourced: your stated negative, "Never sold into rail specifically" | "I haven't sold into rail specifically." Plain acknowledgment. No slot. |
| "I drove £4M" | Inflated form of F2 | F2's quote at its own scope: "roughly £4M of influenced revenue." My analysis: your material says influenced, not sourced. |
| "I built the ISV channel" | Inflated form of F6 and "took it from 6 partners to 40" | "I ran the ISV channel. I took it from 6 partners to 40." |
| "I've managed operator relationships" | Inflated form of F5 (relationship side of the transaction) | "I did bus and light rail network planning, on the operator side." |

## 14. Sources

**Provided:** your message (background, the £4M figure, your stated negatives, the company description); the recruiter's email as quoted in your message. No documents attached. The internal strategy report was read by you and was not supplied, so nothing from it is used.

**Searches and fetches sent (all refused by the host's permission gate; none returned results):**
- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships" — refused
- "Kelverton Rail strategy news" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- Fetches: none sent

**Target accounting:** Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values section. No values round is detected from your inputs, so the section is dropped either way. |
| 2. Kelverton Rail interview process | unavailable | Loop structure and persona weights. Would have confirmed or ruled out a values round. |
| 3. Kelverton Rail strategy | unavailable | Grounding brief and the CO questions. C2 and C5 stay generic without it. |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Interviewer read and a reverse question tied to a career path. The query could be formed from title and company. |
| 5. Representative JD | unavailable | JD-tagged rows and questions. No search was sent; no job description was supplied. |

## 15. Upgrade menu

- **Job description text** → the gate rows, JD-tagged questions, and a requirement-by-requirement coverage line. Currently F3 to F4 are the only JD-shaped rows.
- **Permission to run web search** (refused this session) → values, interview process, strategy, and interviewer targets. Or paste Kelverton's values page and the recruiter's description of the round.
- **How the £4M was counted, in your words** → turns A1, B1 and B3 from answer slots into grounded answers.
- **One sentence from the internal strategy report: its headline recommendation** → sharpens the differentiation in section 5.
- **Interviewers' surnames** → an interviewer read, persona weights for each member, and a reverse question tied to their path.
- **One planning decision you made in the transport work** → upgrades F1 and F5 from transferability to a grounded bridge.

---

Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-5-denied-98df3f43/ffbe77d4-292b-44f9-9daf-15fde64ad35e/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md.

Say the word and I'll play Deepa on D1, the rail gap, and give feedback against that question's own cell.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

Can you paste the job description? It is the one input that changes the gate rows and the JD-tagged questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
