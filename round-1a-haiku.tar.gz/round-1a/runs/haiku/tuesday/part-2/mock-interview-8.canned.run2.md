Your prep pack is saved as ashgrove_member-experience-lead_interview_pack.md, at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-8-canned-80d1e7f8/60229315-5784-4a5f-8ebb-7ac111fa5f33/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds, with a shared fit snapshot and a separate question bank for each round. I ran no web searches; it rests on what you sent me.

The single highest-value prep is B2, the "why hire someone who has never worked in a contact centre" objection. Your honest answer is the branch complaints log, plus a clear concession and a plan. Round 3's values scoring also has no story in your material for three of the four values, so the pack gives you honest "I haven't done this" branches for those rather than invented ones.

Say the word and I'll play the Head of Member Services on B2. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

Loop mode: three rounds on 26 November 2026. Candidate: Dara. Built 17 November 2026 from what you sent. No searches were run.

## How to use

- **Personas** describe how each question arrives: tone, pressure, who is asking.
- **Types** describe what is being scored: **VAL** values, **EXP** your experience, **JD** the posting's requirements, **CO** company and strategy, **CASE** a live problem.
- **Provenance** lists the sentences a guidance cell rests on, quoted from your message, the JD, the recruiter's email or the values page you pasted. `[generic]` means a pattern with no claim about you or Ashgrove.
- Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: give your own answer in your own words, including "that was not mine" when it isn't.

## Fit snapshot (shared across all rounds)

The JD's requirements are quoted from your pasted JD. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Same facts in the role's terms: "I've spent 6 years in retail banking, the last 3 as a branch supervisor." Whether branch work counts as customer operations is the panel's call. Your material shows no service operation beyond the branch. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Closest evidence, adjacent rather than the same thing: a branch's formal log. Say it as you ran it: "I handled the branch's formal complaints log." Limit: your material does not say the log carried regulatory timescales or external referrals. Answer slot: if it did, say which and what your part was; if it did not, say so and stay with the log you ran. |
| F3 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated gap, so the words are yours: "I haven't presented to anyone above regional level." Then a plan, given as a plan and never as a past: how you would prepare for your first senior presentation. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Reporting in other terms. Your material does not name the tool, so the pack does not name it either. If asked which tool, answer in your own words. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Adjacent: one branch's log, not the whole process and not across branches. Words: "For the branch, I handled the formal complaints log." Answer slot: if you saw a complaint from first contact to close, say which steps were yours; if you did not, say so and say what you would own first. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A stated gap: "I haven't worked in a contact centre." Then a plan: how you would learn its queues and complaint routes. |
| F7 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | The sentence shows monthly reporting, not which measures it held. Answer slot: if the spreadsheet counted complaint volumes or resolution times, say how each was counted; if it counted neither, say so and say what you would report first. |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | low | [inferred] | transferability | Teaching tellers a script is adjacent to coaching supervisors. Words at their own scope: "I trained new tellers on our escalation script." Answer slot: if you coached supervisors on escalations, say how; if you did not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: if you worked with a digital or channel team on how members self-serve, say what it was and your part in it; if you did not, say so and say how you would start with their digital team. |

Gates: the posting states no licence, location, schedule or pay gate, so none is listed. Where the office or hub is not stated, that is a recruiter question (see the upgrade menu), not a gate.

## Grounding brief

Provided material only: the values as you copied them on 17 November 2026, the recruiter's round structure, and the 2026 strategy brief as you summarised it (not its full text).

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Vocabulary to use: member-owned, members, hubs, digital channels, and the four values by their official names. The brief is dated July 2026, under six months old on 17 November 2026, so nothing is flagged as stale.

## Loop structure and shared personas

| Round | Format | Who | Weighting |
|---|---|---|---|
| 1 | 30 minutes | Recruiter | Conversational leads, light Skeptic. Screening logistics and motivation. |
| 2 | 45 minutes, mostly behavioural | Head of Member Services, your future manager | Skeptic leads (manager buying capability and testing gaps), then Values/Behavioral. |
| 3 | 60 minutes, including a 20-minute complaint-escalation case | Two branch managers | Values/Behavioral leads (the panel scores the four values), with Peer Evaluator and Case/Strategist. |

The recruiter's email names the rounds and what the panel scores, so the loop is established. Round 3 is the values round.

## Round 1: recruiter screen (30 minutes)

**Persona weights**

| Persona | Weight | Why |
|---|---|---|
| Conversational / Rapport Builder | 5 | Recruiter screen prior. Logistics and first impression are scored in a friendly register. |
| Skeptic | 2 | Light: motivation consistency and the reason for leaving. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; [grounded] "I handled the branch's formal complaints log"; [grounded] "trained new tellers on our escalation script" | Ninety-second arc. Start with "6 years in retail banking, the last 3 as a branch supervisor." Then the log and the teller training, in the quoted words: "I handled the branch's formal complaints log" and "trained new tellers on our escalation script." Stop there. Add no adjectives. | F1, F2 and F8 are the first things a recruiter checks. |
| A2 | "What drew you to this role?" | JD | [generic] | Answer slot: give the reason you actually have, in one sentence, tied to something the posting says, such as the complaints process end to end. Your material gives no reason, so none is supplied. | Motivation consistency. |
| A3 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give the figure you actually want, or ask for the band before you name one. Do not name a figure you have not decided. | Pay is a knockout check. The posting gives no band and your material gives no figure. |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | Notice is a knockout check. |
| A5 | "Where would you be based, and how often could you be in the office?" | JD | [generic] | Logistics slot: name the office and the days you can work, in your own words. The posting names no location. | Location is a logistics check, and the hub changes may come up. |
| A6 | "Why are you leaving your current role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Logistics slot: give your own reason in one sentence, looking forward. Your material gives none. Do not criticise your current employer. | Reason for leaving is the screen's motivation test. |
| A7 | "What do you know about our member-owned model?" | CO | [grounded] "Members First, Always — we decide from the member's side of the counter."; [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Name one value and say what it would change in a complaint you handle. Do not recite all four. | Recruiter screens for homework on the values. |

**Reverse questions**

- "What does a strong first six months look like in this role?" Why it lands: it signals you think in outcomes before the manager round.
- "Which of the four values do candidates most often find hardest to show?" Why it lands: it signals you have read the values, and the recruiter knows what the panel scores.

## Round 2: Head of Member Services (45 minutes)

**Persona weights**

| Persona | Weight | Why |
|---|---|---|
| Skeptic | 4 | Hiring-manager prior: they are buying capability and checking the gaps in F3 and F6 against the role. |
| Values/Behavioral | 3 | The recruiter says the round is mostly behavioural. |
| Case/Strategist | 1 | Light, because the round is not case-led. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level"; [grounded] "Never worked in a contact centre" | Name the weakest part plainly: "I haven't worked in a contact centre," and "I haven't presented to anyone above regional level." Then a plan for each, given as a plan. | F3 and F6 are the gaps this question is aimed at. |
| B2 | "Why should we hire someone who has never worked in a contact centre to own the complaints process across it?" | JD | [grounded] "Never worked in a contact centre"; [grounded] "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Hold: "For the branch, I handled the formal complaints log." Hold through two follow-ups by returning to the log. Concede: "I haven't worked in a contact centre, and I would learn its queues first." Do not add to the hold. | This objection will come in some form. It is aimed at where your material is thinnest, which is why it needs the most rehearsal. F5 and F6. |
| B3 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Open prompt, with the persona's stem as its theme. Pick a time you told someone senior something they did not want to hear. It needs a stake, what you actually said, and what happened next. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Standard Values/Behavioral stem. Your material contains no such story, so the guidance does not supply one. |
| B4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Scaffold: pick a complaint you carried to a real end. Name the moment you took it, what you did, and the point it closed. Your material has no such story. If none comes, say so, then give the nearest thing you have: "I handled the branch's formal complaints log." | Own the Fix is one of the panel's four values. |
| B5 | "Tell me about a time you put a member's interest ahead of a branch target." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Scaffold: a time you chose the member's outcome over a target or process, what it cost you, and what you told the member. Your material shows none. Honest branch: say so, then give the nearest thing you have and what you would do now. | Members First is one of the panel's four values. |
| B6 | "When a branch closes or merges, where should its open complaints go, and who owns them?" | CASE | [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Structure it: clarify (how many open, which branch, which members), objective (no complaint lost or explained twice), one named owner per complaint until closed, member contact in plain words, and a metric (open complaints by branch, monthly). Name your weakest assumption: that the open list is complete. Do not claim you have done a merger. | Hub consolidation is in the brief, so the question is likely. The question itself presupposes nothing about Ashgrove's plans. |
| B7 | "Digital is meant to take a large share of member service. Which complaints would you refuse to move to self-service?" | CASE | [grounded] "work with digital teams on self-service journeys" (JD) | Name the criteria: complaints where the member must be heard, disputed decisions, and signs of vulnerability. Then say how you would test a journey before moving anything to it. Answer slot: if you have worked on a self-service change, say what it was and your part; if you have not, say so. | F9 is the gap, and this question puts it to you directly. |
| B8 | "What would make you leave this role within a year?" | VAL | [generic] | Answer in your own reasons, honestly. A real reason, said calmly, lands better than an answer that avoids the question. Your material gives no reason, so none is supplied. | Skeptic stem on motivation: why this, why now. |

**Reverse questions**

- "Which complaint trends worry you most over the next year?" Why it lands: it shows you want the risk, not just the job.
- "What would you want changed in the complaints process in my first 90 days?" Why it lands: it asks for a concrete ask, which managers like to give.
- "How will the move to five hubs change where complaints first arrive?" Why it lands: it shows you have read the brief. No interviewer profile exists, so no question ties to their own career path.

## Round 3: panel of two branch managers (60 minutes, with a 20-minute case)

The panel scores against the four values, so this is the values round. The values cheat sheet below belongs here.

**Persona weights**

| Persona | Weight | Why |
|---|---|---|
| Values/Behavioral | 4 | The panel is scored against the four values, and the loop source documents that. |
| Peer Evaluator | 2 | Both members manage branches, so the complaints lead is a peer for seam questions. |
| Case/Strategist | 1 | The 20-minute escalation case. |
| Pressure | 1 | Branch managers may challenge the presenting gap. |
| Data-Driven Prober | 1 | The monthly numbers. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Case (20 minutes): "A member has phoned three times about a fee. Each call gave a different answer. They have now asked for it in writing and say they will take it to the external complaints body. You are the lead. Walk us through what you would do, in the order you would do it." | CASE | [generic]; the JD line "experience handling regulated complaints" raises the regulatory frame | Structure it. Clarify: what each call said, whether anything is written, and which regulatory deadline applies to you. Objective: one answer, in writing, in plain words, before the deadline. Owner: one named person until it is solved. Coaching: three different answers point to a script or training gap for that escalation, so coach the supervisor on that escalation. Metrics: time to first contact and time to written answer, both in the monthly report. Name your weakest assumption: that all three answers came from the same product. This is a structure, not a script, and it claims no past case. | The case is the scored centre of the round. |
| C2 | "Tell us about a time you chose the local view over the number." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Scaffold: name the number, the local view, your decision, and what it changed. Your material shows no such decision. Honest branch: say so, then say how you would weigh a town's view against a volume figure. | Neighbours, Not Numbers. Your monthly spreadsheet is a numbers view, so expect the panel to test this. |
| C3 | "When did you last change wording that members had to read twice?" | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong."; [grounded] "trained new tellers on our escalation script" | Answer slot: if you changed the script's wording or the words tellers used, say what and why; if you did not, say so and say what you would test first with members. | Plain Words. The script is the nearest wording you have. |
| C4 | "Branch managers hold the member relationship. Where does a central complaints lead's job stop and yours start, and what happens when you disagree?" | JD | [grounded] "coach branch supervisors on escalations"; [grounded] "trained new tellers on our escalation script" | Propose seam principles rather than pretending to know the seam: who decides what, and how a disagreement is escalated. Reciprocity: what you bring to the branch, not only what you need. Answer slot: a time you disagreed with a peer; if none comes to mind, say so. | The peer's seam question. |
| C5 | "You have said you have never presented above regional level. Why would a panel of branch managers trust your monthly numbers?" | JD | [grounded] "I've never presented to anyone above regional level"; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Hold through two follow-ups. Concede: "I haven't presented to anyone above regional level." Then a plan, not a claim. | F3, F4. The panel may well press here. |
| C6 | "Walk me through what the monthly complaints spreadsheet counts, and how." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Defend-the-number answer: what each measure counts, what it is sensitive to, the assumption you would defend least, and which part was yours. If it did not count resolution times, say so. | F7. Prober stem on the monthly report. |
| C7 | "What does 'solved' mean for a complaint, and who decides?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Give your own test for "solved," in your own words. For example: the member has a written answer, the fix is in place, and someone checked it held. Do not claim a past case. | Own the Fix. |
| C8 | "A member's complaint is right, but the policy says no. What do you do?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Live problem: check the policy and its reason, tell the member plainly, escalate to a named owner, and record the decision. Your material has no such case, so no past is claimed. | Members First, as a decision rather than a story. |

**Values / principles cheat sheet**

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F-row: none. Your material shows no decision of this kind. Selection scaffold: pick a time you chose the member's outcome over a process or target and say what it cost. If none comes to mind, say so plainly. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F8 is the nearest: "trained new tellers on our escalation script." Your material does not show you changed the wording. Selection scaffold, with that honest branch. |
| Neighbours, Not Numbers | Every branch is part of its town. | F-row: none. Your material shows no local decision. Selection scaffold, with the honest branch in C2. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F5 is the nearest: "I handled the branch's formal complaints log." Scaffold: a complaint you kept hold of to a real end. If none, say so, then describe how you handled the log. |

**Reverse questions**

- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: it is the reciprocity question a peer expects.
- "When a complaint escalates, who decides it is finished?" Why it lands: it ties to Own the Fix and shows you think about closure.
- "What do you need from the complaints lead that you do not get now?" Why it lands: it turns the panel into a conversation about their needs.

## Prohibited claims

Built from the fit snapshot. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F5 | "For the branch, I handled the formal complaints log." Limit, as the pack's own observation: your material describes one branch's log. |
| Worked in or ran a contact centre | Negative you stated, F6 | "I haven't worked in a contact centre." No slot. |
| Presented to senior leaders | Negative you stated, F3 | "I haven't presented to anyone above regional level." No slot beyond the plan. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." Limit, as the pack's own observation: your material does not show regulatory timescales or referrals. |
| Coached branch supervisors on escalations | Inflated form of F8 | "I trained new tellers on our escalation script." |
| Designed the measures in the monthly report | Inflated form of F7 | The spreadsheet sentence, at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." |

## Upgrade menu

- Names of the round 2 and round 3 interviewers → persona weights from their public footprint, and reverse questions tied to their career paths.
- The full strategy brief, not your summary → the CO questions (B6 and B7) can quote its figures as `[grounded]` rather than resting on your summary.
- The recruiter's pay band and the office or hub you would work from → logistics slots A3 and A5 can state facts, not instructions.
- Your own notice period and pay figure → A3 and A4 become facts you can give without a pause.
- The column headings of your monthly spreadsheet, in your words → F7 moves from `low` to `medium`, and C6 can cover the figures it counted.
- A complaint you handled that went outside the branch, if you had one → F2 and B2 can carry it. Nothing is supplied for you.
- Deep research (L2), if you want it: up to 6 more searches and 2 more fetches, several minutes. It would cover the interviewers' public talks, role loop reports and recent organisational context.
- A `tuesday-dossier.md` file would carry the gaps this prep exposed into later sessions. Without one, nothing above changes.

## Sources

Provided documents: your message (background, the JD text, and the values copied on 17 November 2026); the recruiter's email; your summary of the 2026 strategy brief.

Searches and fetches: none. The pack rests on the documents above.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet and C2, C3, C7, C8. The values you pasted fix the four names and definitions. |
| 2. Ashgrove interview process | skipped | Loop structure and persona weights. The recruiter's email names the three rounds and the panel's values scoring. |
| 3. Ashgrove strategy | skipped | CO questions (A7, B6, B7) and the grounding brief. Your summary of the brief supplies the current priorities and moves. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. The interviewer reads are absent and the upgrade menu says what names would unlock. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Target accounting: no interviewer profile exists, so no reading of the interviewer is included, and no reverse question ties to an interviewer's career path.

## Question coverage against the JD

| Requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, B1 |
| Experience handling regulated complaints | A1, B2, C1 |
| Confident presenting to senior leaders | B1, C5 |
| Comfortable with Excel reporting | C5, C6 |
| Own the complaints process end to end, branches and contact centre | B2, B6, C1 |
| Report monthly on volumes and resolution times | C6 |
| Coach branch supervisors on escalations | C1, C4 |
| Work with digital teams on self-service journeys | B7 |
