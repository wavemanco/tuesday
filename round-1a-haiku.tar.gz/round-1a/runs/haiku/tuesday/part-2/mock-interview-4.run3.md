Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-4-denied-46966568/e3de4736-89b7-4b23-bccb-849ec05beaf9/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a 45-minute hiring-manager conversation on Thursday, using the dossier's handoff section as the source.

The most important rehearsal is A1, the question the underwriter flagged as the likely objection: "You've never held the PM title or owned a roadmap. Why should we hire you into one?" Open with the plain acknowledgment, then the integration work at its own scope, then a 90-day plan written as a plan, not a past. Say it aloud a few times before Thursday. C1 is the same objection in a pressure format.

Things you should know:

- **The dossier is about three months old.** It was generated 2026-08-14. If the role or its requirements have changed, rerun the underwriting before relying on the prohibited claims.
- **No research ran.** Web search permission was refused three times, so the pack has no Quartzline values, interview-loop, or strategy content. The questions are built from the dossier and the job description. If you grant search permission, I can re-run it.
- **Two inflated claims are excluded.** The pack won't have you say you set the roadmap from the sessions or owned the partner API platform. Your material supports only the scope of each quote.
- **Open gap.** Whether you'd have decision authority against the two squad leads isn't shown in your material. G1 and reverse question 1 are built to test it.

Would you like a drill on A1 before Thursday? I can also save a `tuesday-dossier.md` with what this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday. Interviewer name not given.
**Built from:** `tuesday-dossier.md` (job-underwriter v1.1, generated 2026-08-14, decision `conditional_go`). Sections consumed: `handoff_to_mock_interview`, `role_profile`.

## 2. How to use, and the type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: rehearse what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Your own experience, probed for attribution |
| JD | The listed job: can you do it, including its gaps |
| CO | Company and strategy knowledge (not built: research did not run) |
| CASE | A live problem from the role; no claim about your past |

## 3. Prep triage

Two days, sized to a 45-minute conversation. In order:

1. Today: say A1 aloud until the plain acknowledgment comes out in one breath, then C1.
2. Wednesday: B1 and A4 out loud, timed to 90 seconds each. Run one drill on A1 (offer below).
3. Thursday morning: the E1 arc, once, and the reverse questions in section 11.

Everything else is insurance.

## 4. Fit snapshot

Requirement text is the dossier's `role_profile` lines (the supplied JD). Evidence is quoted from the dossier's `verified_candidate_evidence` and `uncertain_or_weak_areas`, with the dossier row as source. Confidence and gap type are the dossier's vocabulary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row 3 | low | [grounded] | transferability | The material supports the sessions, not years in a product role. Bridge at the sessions' own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." The years are a limit to state plainly, not something to bridge. |
| F2 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas (R1 sub-claim) | none given | none | [grounded] | capability | The dossier records this as a gap to acknowledge. Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan, never as a past. No answer slot. |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier row 1 | high | [inferred] | transferability | The material shows integrating a vendor's APIs, not shipping an API product. Bridge: "I led 30+ end-to-end client integrations of the vendor's REST APIs." State the limit; do not claim the product. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Wrote the internal integration playbook" — dossier row 2 | high | [inferred] | discovery | The material shows a playbook. It does not show schema work. Answer slot: if the playbook covered schemas or API docs, say what it covered; if it did not, say so and say how you would check a schema before relying on it. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row 3; "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier row 1 | medium | [grounded] | presentation | Reword only: the sessions put client evidence in front of product, and the integrations ran from scoping through go-live. The material shows nothing about sales, and the pack does not add it. |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Answer slot: if you worked in sprints or ceremonies on an integration team, say which; if you did not, say so and say what you would want to confirm about working with two squads. |
| F7 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | Answer slot: if you measured adoption of anything you integrated, say what and how; if you did not, say so and say what you would measure first. The dossier records that no current baseline is stated. |

**Analysis (pack's own observation, not words for the candidate):** The dossier names decision authority against the two squad leads as unknown. Your material does not show it either way, so the pack does not coach any claim about it. It is covered by G1, B2 and reverse question 1.

## 5. Graded deliverables

None declared.

## 6. Grounding brief

Not built. Research did not run (see Sources).

## 7. Reading the interviewer

Not built: no interviewer name was given.

## 8. Persona table

Relationship prior for a hiring-manager round is Case/Strategist and Skeptic: they are buying capability and checking gaps. No loop source established more than this one session, so the weights below rest on that prior and on the dossier, not on a documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the gaps: the missing title, the missing roadmap, "why you" | Top weight. Hiring-manager prior, and the dossier's named objection sits here | Plain acknowledgment first, then the evidence at its own scope, then a plan | A1 to A4 |
| Case/Strategist | Live problems from the role | Top-weight prior for a hiring manager | Clarify, structure, then answer; think aloud | B1 to B4 |
| Pressure | Interrupts; asks how much was really you | Mid weight. Dossier-named gaps draw probes; no stated pressure style | Hold through two follow-ups, then concede specifically | C1 to C3 |
| Data-driven prober | Asks how the 30+ figure was counted; what was measured | Mid weight. The one headline figure on the record is 30+ | Name the weakest assumption in your own words, or say you do not know | D1 to D3 |
| Conversational | Opens with "walk me through" | Low-mid weight. Casual register is still scored | 90-second arc, with the gap said plainly inside it | E1 to E2 |
| Values/Behavioral | Scenario probes | Low weight. No values-style round is detected: the user's words name a conversation and nothing else, and no loop source documents one | Selection scaffold with its honest branch | F1 to F2 |
| Peer evaluator | Seams with the two squads | Low weight. Hiring manager is not a peer; seams still matter because the JD names two squads | Propose seam principles; do not invent history | G1 to G2 |

## 9. Question banks

Provenance comes first in each row. Answer slots are instructions for the interview, not questions to me.

### A. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Led 30+ end-to-end client integrations of the vendor's REST APIs"; acknowledgment from dossier prohibited_claims ("Having held a product manager title or role"; "Having owned a product roadmap") and uncertain_or_weak_areas (acknowledge_gap) | Open with the plain acknowledgment: "I haven't held the PM title or owned a roadmap." Then the evidence at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Then how you would learn to own prioritisation across two squads, said as a plan for your first 90 days, never as a past. Hold through two follow-ups by returning to the integrations; never add a roadmap decision to the sessions. If pushed to concede: a PM with three years would start faster on roadmap calls, and you would close that gap in the open with the squad leads. | The underwriter named this objection, so it gets the deepest rehearsal. Its negatives are the dossier's own, each sourced by field, so the question is asked as the underwriter wrote it. F1, F2 and F3 carry it. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas) | Name roadmap ownership first, in your own words, as the gap. Then a day-one plan as a plan: who you would sit with first, and which decisions you would ask the squad leads to walk you through. No past claim. | F2 is a capability gap. The question asks for a weakness, so it presupposes nothing about your history. |
| A3 | "Three years of product management is a stated requirement. Where does your experience line up with it?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (F1) | Bridge at the sessions' own scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Then state the years plainly with the acknowledgment from A1. Do not stretch the sessions into years or into a roadmap. | Transferability per F1; the dossier's strategy for R1 is bridge, with its limit named. |
| A4 | "Walk me through how you'd review a change to an API schema before partners depend on it." | CASE | [generic] for the problem; [grounded] "Wrote the internal integration playbook" (F4), cited only for what the playbook covered | Structure: what the change breaks for a partner, who signs off, how the change is versioned and communicated, and what you would check first. Cite the playbook only for what it covered. If it covered no schema work, say so and give the review as a plan. | A live problem from the role's API platform responsibility. It asks about no past, so it presupposes nothing about you. F4 is a discovery gap. |

### B. Case/Strategist (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration breaks after a release that changed one response field. Walk me through the first 48 hours." | CASE | [generic] | Clarify scope first: how many partners, which field, whether the change is breaking. Then contain, communicate, find the root cause, and prevent the repeat through versioning. Think aloud. | A live problem from the partner-facing platform. Nothing about your past is presupposed. |
| B2 | "Partners ask for three new endpoints this quarter, and you have room for one. How do you choose?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" (role_profile responsibility, supplied JD line) | State criteria before a choice: partner count, evidence of adoption, cost, reversibility. Name who decides with you, the squad leads, and the trade-off you would accept. Make no claim about past choices. | The JD's roadmap line, and the open decision-authority question from the analysis. |
| B3 | "Adoption has been flat for six months. Diagnose it." | CASE | [generic] | First question: what is the baseline, and how is adoption counted? Say plainly that you may not know yet. Then segment: new partners versus active ones, and where in the integration they stop. | The dossier records no current baseline. The honest first move is to ask the measurement question. |
| B4 | "What does your first month on the two squads look like?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility, supplied JD line) | Plan only: the first week listening, the first spec you would write, and one decision you would take to the squad leads. If you have worked in sprints, name the team. If you have not, say so and do not describe a ceremony you did not run. | Covers the JD's delivery line, and the agile gap (F6), through a plan rather than a past. |

### C. Pressure (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone who has the PM title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; acknowledgment from dossier prohibited_claims ("Having held a product manager title or role") | Hold the integrations as the reason, at their scope, with the plain acknowledgment. Hold through two follow-ups. Concede specifically: the PM with the title is ahead on roadmap calls, and you would close that gap in the open with the squad leads. | Hold-then-concede. The position held is the one the quote carries, not a stronger one. |
| C2 | "That integration count. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" | Name the stages the quote states (scoping, requirements, architecture, UAT, go-live) and, for each, your part in your own words. If some stages were others' work, say so. Answer slot: if you did not own every stage, name the ones you did. | The attribution probe on the headline figure. The beats are the quote's own. |
| C3 | "You say you ran roadmap-input sessions. Did product change its plan because of them?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold to what the sessions fed: client evidence, to product. Answer slot: if a product decision changed because of the sessions, name it and your part in it; if none did, or you do not know, say so and say what you did with the evidence. | The question presupposes a plan and an outcome. The second branch lets that premise be false. |

### D. Data-driven prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you count those integrations?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" | Say what the count includes, in your own words. Then name the assumption behind it that you would defend least. If you cannot name one, say so. | Defend-the-number for the headline figure. The assumption is yours to name, not the pack's. |
| D2 | "How did you know the go-lives went well? What did you measure?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (go-live is in the quote's stage list) | Answer slot: if you measured how a go-live went, say what. If you did not, say so and say what you would measure on the next one. | The outcome probe. The material shows no measure, and the slot does not supply one. |
| D3 | "What would you need to see to call partner API adoption a success?" | JD | [grounded] "Define and track adoption metrics" (role_profile responsibility, supplied JD line) | Name one measure and its denominator as a proposal, then the weakest assumption in it, in your own words. Answer slot: name the baseline you would need first. Do not describe a metric you tracked. | F7 is none, and metric questions include the weakest-assumption move. |

### E. Conversational (weight: low-mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; "Wrote the internal integration playbook"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc: the integrations and their stages, the playbook, the sessions, and then the gap said plainly, with the acknowledgment from A1. | Biography stems are scored casually. Saying the gap inside the arc keeps the hiring manager from having to dig for it. |
| E2 | "What API tooling have you used hands-on lately?" | JD | [generic] | Name the tools you have used, by name and in what role. For any tool you have not used, say so. | The JD's plus-skill, asked casually. Nothing about your past is presupposed. |

### F. Values/Behavioral (weight: low)

No values-style round is detected, so no values cheat sheet is built (section 10 is dropped).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to a partner." | VAL | [generic] persona stem; no raising source | Selection scaffold: pick a time you told a partner something unwelcome about an integration. It needs a named stake, a moment you did not soften it, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the integration work. | An open prompt with no sentence in the material for it, so the honest branch is written in. |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] persona stem; no raising source | Same scaffold and the same honest branch. Use "client", as your material does. | Open prompt; the material carries no such story. |

### G. Peer evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Your two squad leads disagree with a roadmap call you've made. What happens?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility, supplied JD line) | Propose seam principles, not an invented history: who decides, how disagreement is escalated, and what you would show the squad leads first. Answer slot: if you have had a disagreement of this kind with a team, say what happened and what you did; if not, say so. | The dossier's first unknown is decision rights, and this question tests it. |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] persona stem | Name who did which stage, using the stages in your own words, and avoid "we" as cover. Say what you would credit to others. | Open prompt; the answer must be your own. |

**Requirement coverage.** Every JD line is covered, or says why not.

| JD requirement or responsibility | Covered by |
|---|---|
| R1: 3+ years product management | A1, A3, C1 |
| R2: shipped API or platform products | A1 (limit), C2 (the integrations, not shipping) |
| R3: technical fluency, API docs, schemas | A4 |
| R4: stakeholder management | C3, G1, G2 |
| R5: agile delivery | B4 (plan), F6 slot inside B4 |
| Own the roadmap for the partner-facing API platform | A1, A2, B2 |
| Run discovery with integration partners | B2, B1 |
| Write specs and drive delivery with two squads | B4, G1 |
| Define and track adoption metrics | B3, D3 |
| Unknown: decision authority against squad leads | G1, B2, reverse question 1 |
| Unknown: adoption baseline | B3, D3, reverse question 2 |

## 10. Values / principles cheat sheet

Not built: no values-style round detected.

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority and your material shows none. It is the dossier's first unknown, and the answer decides how you would spend the first quarter. |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption is a named responsibility with no stated baseline. The answer shows whether the work is defined or inherited. |
| 3 | "Where do the two squads and the partner discovery work most often collide?" | The seam is where this role will be hardest. Their answer tells you what to prepare. |
| 4 | "What does 'shipped' mean for a platform API here: a public release, or general availability to partners?" | R2 is the requirement you have least direct evidence for. Their definition tells you what the integrations bridge has to reach. |
| 5 | "What has made this role hard to fill?" | It shows whether the bar is the PM title or the judgement, which is the question A1 turns on. |
| 6 | "What would a good first 90 days look like to you?" | It makes them describe the bar in their own words, so you can test your plan against it. |

## 13. Prohibited claims

What this pack will not coach, and why. Dossier entries are sourced; the two inflated forms are built here from the candidate's own sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims (field named) | "I haven't held the PM title or a product role." Plain acknowledgment, sourced by the field. |
| Having owned a product roadmap | dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap) | "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | dossier prohibited_claims (field named) | "I haven't set prioritization for an engineering squad." |
| Set the roadmap from the roadmap-input sessions | Inflated form of dossier row 3 | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." Pack's observation: the material says the sessions fed evidence to product, and says nothing about what they set. |
| Owned the partner API platform | Inflated form of dossier row 1 | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." Pack's observation: the material shows client-side integrations of a vendor's APIs, not a platform. |

## 14. Sources

- **Provided:** `tuesday-dossier.md`, job-underwriter v1.1, generated 2026-08-14, decision `conditional_go`. The dossier is about three months old against today's date (2026-11-17). If the role or the process has changed since August, the requirements and the prohibited claims need re-checking.
- **Round:** from the user's message: a 45-minute conversation with the hiring manager, Thursday.
- **Loop:** the user's own words establish one session, a hiring-manager conversation, so no archetype fallback is used. No values-style round is detected.

**Research tier: L1, searches 3 of 6, fetches 0 of 2.** Web search permission was not granted, so all three calls were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet (section 10). Not built anyway, since no values-style round was detected, so no output changed. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure and persona weights. Weights rest on the hiring-manager prior and the dossier, not on a documented loop. |
| 3. Quartzline strategy and recent news | unavailable | CO bank and the differentiator questions. None were written, so the pack has no CO questions. |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The dossier's `role_profile` supplies the JD lines that fix the fit snapshot and the JD-tagged questions. |

Queries sent, each refused:
- "Quartzline values": refused
- "Quartzline interview process product manager": refused
- "Quartzline strategy news": refused

## 15. Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Web search permission granted → targets 1 to 3 re-run; a values page or a loop description would replace the archetype-free weights where they exist
- A recruiter's note on the round's format (conversation only, or a case or exercise) → reweights B against E and F
- The adoption baseline, once the employer gives it → B3 and D3 rewritten against a real figure instead of the slot
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) → company strategy brief for the differentiator bank. Offered once; say if you want it.
