Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-8-denied-9563e543/2ece18b2-0f4e-4dee-97fd-e315fe78a5ed/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it for all three rounds on 26 November, from the recruiter's round structure.

Say the word and I'll play the Head of Member Services on B4, the question the pack names as its highest-ROI prep: "You've run one branch's log. Why should we trust you to own complaints across every branch and the contact centre?"
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two things would change the pack:

1. Did any complaint in your log go beyond the branch, to a central team, a formal external route or a regulator? If so, what was your part?
2. Does your monthly spreadsheet carry resolution times, or volumes only?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

First version. Built for all three rounds on 26 November 2026 from the recruiter's round structure, the values you pasted and the strategy summary you sent.

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union
**Interviewers:** recruiter (name not given); Head of Member Services, your future manager (name not given); two branch managers (names not given)
**Rounds:** A, recruiter, 30 minutes. B, Head of Member Services, 45 minutes, mostly behavioural. C, panel of two branch managers, 60 minutes, including a 20-minute complaint escalation case, scored against the four values.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

Question IDs run by round: A for the recruiter screen, B for the Head of Member Services, C for the panel. Each question has one primary type; the rationale notes any second type.

Type key:
- **VAL**: behavioural and values alignment, scored against Ashgrove's four published values.
- **EXP**: your own experience, tested for what you actually did.
- **JD**: the listed job's requirements.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role.

Answer slots read as instructions ("if you did this, say how; if not, say so plainly"). They are for the interview, not questions to me. A slot names a practice only where the job posting raises it.

## Fit snapshot

Evidence comes from your message only. No CV was sent, so every evidence cell quotes that message. Requirements are quoted from the job description you sent.

No requirement here is a gate (a licence, location, credential or similar term). "4+ years" is graded like any other requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's log. Say it at that scope: "I handled the branch's formal complaints log." Answer slot: the JD asks for end-to-end ownership across branches. If you set any step of how complaints moved through the branch, say which step and how you decided it; if none was yours to set, say so plainly and stay with the log. |
| F2 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is not coaching supervisors, so the bridge stops at the quote: "trained new tellers on our escalation script." Answer slot: if you have coached a supervisor on an escalation, say which and what you did; if not, say so plainly and say how you would set up that coaching. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches monthly complaint reporting for a regional manager. Say it as written; add no measure, figure or method. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The material does not show which measures the sheet carried, so neither volumes nor resolution times is established. Answer slot: say which measures the sheet carried and how they were counted; if resolution times were not in it, say so plainly and say what you would measure first. Derivation: the quote touches reporting without showing the measures. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | The quote reaches the experience requirement in other terms: six years in retail banking, the last three as a branch supervisor. Say it that way; it adds no practice. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | Your message says "formal" and nothing about external or regulated routes. Answer slot: if any complaint in the log went outside the branch under a formal process, say which process, what you did and what you did not decide; if none did, say so plainly and say what the formal log involved. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not an absence you stated. Answer slot: if you have worked alongside a digital or app team, say which and what the work was; if not, say so plainly and say what you would learn first. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | You stated the absence, so the words come from your statement only: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan, never as a past. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated the absence. Words: "Never worked in a contact centre." Then how you would learn the contact centre's complaint flow, said as a plan. |
| F10 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote already reaches the requirement in role terms. The row is closed; say it as written. |

**Requirement coverage.** Every JD requirement has at least one question.

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches | F1: B4, C5, C6 |
| Across the contact centre | F9: A3, C5, C10 |
| Coach branch supervisors on escalations | F2: B10, C5 |
| Report monthly on complaint volumes | F3, F4: B6, C8 |
| Report monthly on resolution times | F4: B6, C9 |
| Work with digital teams on self-service journeys | F7: B7, C7 |
| 4+ years in financial-services customer operations | F5: A1 |
| Experience handling regulated complaints | F6: B9 |
| Confident presenting to senior leaders | F8: B5 |
| Comfortable with Excel reporting | F10: B6 |

## Prohibited claims

Not coached, and why. Each entry gives its basis and the honest form to use instead. Built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | "I handled the branch's formal complaints log," at its scope. The limit is this pack's observation, not words for you: your material says one branch's log. |
| Coached branch supervisors on escalations | Inflated form of F2 | "trained new tellers on our escalation script," at its scope. |
| Handled regulated complaints | Inflated form of F6 | "I handled the branch's formal complaints log." The pack's observation: your material says formal, not regulated. |
| Reported resolution times | Inflated form of F4 | The sheet quote at its scope. The pack's observation: your material does not show whether the sheet carried resolution times. |
| Worked in a contact centre | Negative you stated, F9 | "Never worked in a contact centre." |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." |

## Grounding brief: the strategy

Source: your summary of Ashgrove's July 2026 strategy brief. The brief itself was not pasted, so these are your words, not the brief's. Check each figure against the brief before the interview.

- [grounded] "move 40% of member service to digital channels by 2028": the digital shift. Round B's B7 and Round C's C7 rest on it.
- [grounded] "consolidate eight branches into five hubs over 2027": the network change. B8 and A6 rest on it.
- [grounded] "launch a small-business lending product in Q1 2027": a new product the JD does not mention. Use it only if growth comes up.
- [grounded] "the main competitive pressure is app-only banks": the competitive frame.

The brief is four months old, inside the six-month freshness window. Use these four as Ashgrove's current frame.

## Values cheat sheet

The recruiter's email says the panel scores against the four values, so this sheet applies to Round C. Each value also appears in Round B's bank.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Row F1, quote "I handled the branch's formal complaints log." Scaffold: pick one complaint from the log where the member's side and the process pulled apart. If none comes to mind, say so plainly, then give the nearest complaint the log carries. |
| Plain Words | If a member needs it explained twice, the wording was wrong | Row F2, quote "trained new tellers on our escalation script." Scaffold: a time an explanation did not land and what you changed. If you changed nothing, say so and say what you would change now. |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries a story. Scaffold: a time a local fact changed a decision, and how you knew it. If none, say so plainly, then say how you would weigh a local need against a target. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Row F3, quote "I built the monthly complaints spreadsheet our regional manager uses." Scaffold: if the sheet surfaced a problem you then held to a fix, say what the problem was and how it ended. If it did not, say so and give the problem you did hold. |

## Round A: recruiter screen (30 minutes)

**Persona weights**

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, then logistics asked casually | Top. A recruiter screen runs on this register, and the logistics are scored even when they sound casual. | A 90-second arc built from your quoted sentences. Treat casual questions as scored. |
| Skeptic (light) | One or two checks on the two negatives you stated | Mid. The contact centre and senior-presentation gaps are the first things a recruiter tests against the JD. | Plain acknowledgment in those words, then the bridge you can stand behind. |

Values, Case and Pressure are not weighted: a 30-minute screen does not run them.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Give the six years and the last three as a branch supervisor, in those words. Then the complaints log, at its own scope. Under 90 seconds. Add no scope the quotes do not give. | F5 and F1 are the first things checked against the JD. EXP because it is your own account. |
| A2 | "What's drawn you to this role?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Name what draws you, in your own words, tied to the complaints process, the part of the JD your material speaks to. Say what you want to learn about the rest. | Motivation has to be consistent with the rest of the screen. |
| A3 | "You haven't worked in a contact centre. What's your answer to that?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "Never worked in a contact centre." Answer slot: if any complaint you handled reached you by a phone or app route, say which; if none did, say so plainly, then say how you would learn the contact centre's complaint flow. | F9 is a capability gap, and this is the probe your own negative invites. |
| A4 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. Do not name a figure you have not decided. | Pay is a term the screen checks. No figure is in this pack, and none should be supplied. |
| A5 | "What notice would you need to give your current employer?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | Notice is a term the screen checks; the only safe answer is your own. |
| A6 | "Which branches or hubs could you work from?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Logistics slot: say which locations you can work from, in your own words. If you have not checked yet, say that and say when you will. | The hub plan makes location a live question. The JD itself states no location. |
| A7 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your reason in your own words, true and forward-looking. This pack supplies none. | Reason for leaving is a screen item; only your own reason fits. |
| A8 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" (your message) | Name the two gaps yourself, in those words: "Never worked in a contact centre," then "I've never presented to anyone above regional level." Then one bridge: "I handled the branch's formal complaints log." Stop there. | A recruiter who names your gaps first scores you higher than one who has to find them. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What does the screen-to-panel process look like, and who is on the panel?" | It shows you are planning the three rounds, and it may surface the panel's names for the upgrade menu. |
| "How is this role measured in its first year?" | It asks the recruiter what success looks like before you have to guess. |
| "How is the hub plan affecting the team this role would lead?" | It connects the 2027 consolidation to the job, and shows you read the brief. |
| "What has made candidates strong or weak in this process so far?" | It is a recruiter's own read, and it shows you care how you are judged. |
| "What's the next step after the panel?" | It closes with a clear next step, not a polite exit. |

## Round B: Head of Member Services (45 minutes, mostly behavioural)

Your future manager runs this round. It is mostly behavioural, so the values and skeptic personas carry most of it.

**Persona weights**

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes against the four values; STAR-shaped asks | Top. The round is mostly behavioural, and this is your manager. | Anchor each story in a quoted sentence. Where none carries the story, use a selection scaffold. |
| Skeptic | Quiet probing of scope and presentation | Top-mid. A manager is buying capability and checking gaps. B4 and B5 are the two you cannot avoid. | Hold, then concede the exact gap. Plans, never pasts. |
| Case / Strategist | One or two strategy asks on the digital shift and the hubs | Low-mid. Forty-five minutes, mostly behavioural, so strategy arrives as a question, not a case. | Clarify, objective, approach, metrics, risks. Use only the brief's words. |
| Data-Driven Prober | Asks what the spreadsheet counted | Mid. A manager who has seen the report may ask. | Say what it counted. Name the weakest assumption before they do. |

Pressure is low and covered by B4's second follow-up.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided a complaint from the member's side of the counter, when the process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one complaint from the log. Say what the member needed, what the process said and which way you went, in your words. Answer slot: if the choice was yours, say what you chose and why; if the process decided it, say so and what you did inside it. If no such case comes to mind, say so plainly, then give the nearest complaint the log carries. | Tests Members First. The quote carries the log, not a decision, so the decision is a slot. |
| B2 | "Tell me about a time someone needed something explained twice, and what you did." | VAL | [grounded] "trained new tellers on our escalation script" | Start from the training. Then how you explained the script, in your words. Answer slot: if you changed how the script was taught after someone did not follow it, say what changed; if not, say so and say what you would change now. | Tests Plain Words. F2 supports the training, not the explanation. |
| B3 | "Tell me about a decision where a local need outweighed the numbers." | VAL | [generic] | Scaffold: pick a time a customer's local circumstances changed a decision you made or recommended. Say what you decided and what you weighed. If none comes to mind, say so plainly, then say how you would weigh a branch's local need against a target. | Tests Neighbours, Not Numbers. No quote carries a neighbour story, so the scaffold ends in its honest branch. |
| B4 | "You've run one branch's log. Why should we trust you to own complaints across every branch and the contact centre?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold, then concede. Hold: say what the log was, at its own scope, in those words. Do not add branches, a contact centre or ownership the quote does not give. On the second follow-up, return to the log. Concede exactly: the cross-branch and contact-centre part is not in my material, and here is how I would close it. That last part is a plan, not a past. | **Highest-ROI prep in this pack.** The objection is the most predictable one, aimed at the thinnest part of the evidence. F1 and F9 meet it. Tests Own the Fix as well. |
| B5 | "You've never presented above regional level. How would you take a complaints trend to the executive team?" | JD | [grounded] "I've never presented to anyone above regional level" | Words: "I've never presented to anyone above regional level." Then the plan: what you would put in front of an executive team, how you would test it first, and what you would ask for. Answer slot: if you have presented to a regional audience, say the audience and the subject; if not, say so and give the plan. | F8 is a capability gap. The answer that works is the plan, said as a plan. |
| B6 | "Take me through the monthly spreadsheet. What did it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counted, in your words. Answer slot: if the sheet carried complaint volumes, say so; if it carried resolution times, say how they were counted; if it carried neither, say so plainly and say what you would measure first. Add no figure, source or method. | F3, F4 and F10 meet this. The measures are not in the quote, so they are a slot. |
| B7 | "The bank plans to move 40% of member service to digital channels by 2028. Where would you start with the digital teams?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Answer with a first plan, not a past: which digital team you would meet first, what you would ask them, and which complaint pattern you would bring. Answer slot: if you have worked with a digital or app team, say which and what it was; if not, say so plainly and say what you would learn first. | F7 is discovery. The strategy number is the company's own. |
| B8 | "Eight branches are becoming five hubs over 2027. How do you keep complaint handling consistent while that happens?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Clarify: which complaints are open when a branch closes? Objective: no complaint lost in the move. Approach: one log, one named owner per complaint, a written handover. Metrics: open complaints at transfer, time to resolution across the move, repeat contacts. Risk: local knowledge lost. Two minutes spoken. | CO and CASE. No claim about your past: the structure is generic and the strategy is the company's. |
| B9 | "Tell me about a time a complaint went beyond the branch." | EXP | [grounded] "I handled the branch's formal complaints log"; the JD's "experience handling regulated complaints" (JD) | Start from the log. Answer slot: if any complaint went outside the branch under a formal process, say which process, what you did and what you did not decide. If none did, say so plainly and say what the formal log involved. | F6 is low confidence: "formal" is all the quote gives. The slot keeps the answer inside it. |
| B10 | "Tell me about a time a supervisor brought you an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Start from the training. Answer slot: if you have coached a supervisor on an escalation, say what the escalation was and what you did; if not, say so plainly and say how you would set up that coaching. | Tests coaching supervisors, the JD line F2 reaches only at the training's scope. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What would you want this role to have settled by the first hub move?" | Shows you plan against the 2027 consolidation, from the brief. |
| "Which complaints do you expect to rise as the digital share grows?" | Connects the 40% target to the complaint work. |
| "How would you want this role to work with branch supervisors on escalations, day to day?" | Shows you want to know whether coaching is standard, not assume it. |
| "Which measure on the monthly report would you most want changed?" | Opens the reporting conversation the JD names. |
| "What does a good first 90 days look like from your side?" | Lets your manager describe the job, which you can then test your plan against. |

## Round C: panel of two branch managers (60 minutes, including a 20-minute escalation case)

The panel scores against the four values. Each branch manager's relationship to you is a peer's, so their top personas are Peer Evaluator and Data-Driven Prober. The values round adds Values / Behavioral; the escalation case adds Case / Strategist. Names are not known, so personas are shared across the panel.

**Persona weights**

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Each of the four values scored | Top. The panel is the values round. | C1 to C4 each map one value. |
| Peer Evaluator | The seam between branches and the contact centre; credit | Top. Branch managers price what you add to their work; reciprocity matters. | Propose seam principles, not a seam you have not seen. Ask what you can do for their team. |
| Case / Strategist | The 20-minute escalation case | Top for the case segment. | C5. |
| Data-Driven Prober | How the spreadsheet counted, and resolution times | Mid. Branch managers read the monthly numbers. | C8, C9: name the weakest assumption first. |
| Pressure | A sixty-second challenge on contact-centre experience | Low-mid. One question, held and conceded. | C10. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint where the member's side and the process's side pulled apart." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one complaint from the log. Say what the member needed, what the process said and which way you went. Answer slot: if the choice was yours, say what you chose and why; if the process decided it, say so and what you did inside it. If no such case comes to mind, say so plainly, then give the nearest complaint the log carries. | Members First, scored. Differs from B1 by asking for the tension, not the decision. |
| C2 | "Tell me about a time something you said had to be said again." | VAL | [generic] | Scaffold: pick a time a first explanation did not land and say what you changed, in words a member would use. If none comes to mind, say so plainly, then say how you would check that a member had understood a decision. | Plain Words, scored. No quote carries an explanation story, so the scaffold ends in its honest branch. |
| C3 | "Tell me about a time your branch's town shaped what you did." | VAL | [generic] | Scaffold: pick a time a local circumstance changed a decision, and say which local fact you knew and how you learned it. If none, say so plainly, then say how you would learn a town's needs in your first month. | Neighbours, Not Numbers, scored. No quote carries a neighbour story. |
| C4 | "Tell me about a problem you found that was not yours, and what you did until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Start from the sheet: you built it, and your regional manager uses it. Answer slot: if the sheet surfaced a problem you then held until it was fixed, say which problem and how it ended. If it did not, say so plainly, and give the problem you did hold. | Own the Fix, scored. The sheet is the only quoted sentence close to it, so the story is a slot. |
| C5 | "A member has phoned three times about a fee refund a branch manager promised. The contact centre says no, and it is escalated to you. What do you do in the next 24 hours, who do you bring in and what do you record?" | CASE | [generic] | Clarify first: what did the branch promise, in writing, and what is the refund rule? Objective: the member gets a clear answer within the promised time, and the cause is fixed. Segments: this member, the pattern across branches, the promise. Approach: one named owner for the member; check the promise with the branch; decide, or escalate with a recommendation; record the decision and its reason. Metrics: time to answer, repeat contacts, how often branch and contact centre disagree. Risk: deciding against a branch manager's word. Challenge one premise. If the panel pushes ("the branch manager gave their word"), hold that the decision rests on the record, and concede what you cannot verify. | The recruiter named a complaint escalation case. This is a live problem from the role and asks about no past. |
| C6 | "Your branches and the contact centre sit side by side. Where's the seam, and what happens when they disagree about a complaint?" | JD | [grounded] "across branches and the contact centre" (JD) | Name the seam as principles: one owner per complaint, one record, a rule for who decides when the two disagree. Do not pretend to know the seam's current shape. Answer slot: if you have settled a disagreement across a team boundary, say what it was and how; if not, say so plainly and say how you would settle one. | Peer Evaluator. F9 and F1 meet it, and the answer must not claim contact-centre experience. |
| C7 | "Tell me about a fix that needed more than one team. Who did what?" | JD | [generic] | Scaffold: pick a fix that needed two teams, and say who did which step in your words. If no fix of yours needed another team, say so, then say how you would share credit for a fix with the digital team. | Peer credit probe. The JD raises digital teams (F7), so the slot is raised; no quote supports a past. |
| C8 | "Walk me through how the monthly complaints spreadsheet counted complaints." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say how the sheet counted complaints, in your words. Then name the assumption you would defend least, before they name it. Answer slot: if you know a counting assumption you would defend least, name it; if the sheet had no assumption you would question, say how it counted. | F3 and F4. The weakest-assumption move converts a gotcha into credibility. |
| C9 | "How would you measure a complaint's resolution time?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD) | Answer as a method: the start point, the end point, and what you would exclude. Answer slot: if the sheet you built recorded resolution times, say how they were counted; if it did not, say so plainly and say what you would measure first. | F4 is discovery. The JD names resolution times, so the method question is raised. |
| C10 | "Sixty seconds: why should we give this role to someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Hold, then concede. Acknowledge in those words: "Never worked in a contact centre." Hold the claim your log supports: "I handled the branch's formal complaints log." Do not fold into a contact-centre claim. On the second follow-up, concede exactly what you do not know about the contact centre's flow, and say how you would learn it in your first month. | Pressure persona. F9. The hold is the quote, and the concession is specific. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What does a complaint look like when it moves from a branch to the contact centre, and where does it usually stall?" | Treats the seam as a process, which is the question the panel is most likely to be asking themselves. |
| "Which branch measure would you most want improved in the first quarter?" | Lets them name a problem, which you can then speak to with your own reporting. |
| "After the hub moves, which decisions do you expect branch managers to keep?" | Ties the 2027 consolidation to the decisions they make, from the brief. |
| "How do a branch manager and the contact centre currently agree who closes a complaint?" | Exposes the seam directly, and shows you want to understand it before you change it. |
| "What could a new person do in their first month that would genuinely help your team?" (reciprocity, because the panel is peers) | Turns an interview into a peer conversation about what you would add. |

## Sources

Provided documents:
1. The job description, as pasted in your message.
2. Ashgrove's four values, as pasted from ashgrovecu.org/about/values and copied 17 November 2026.
3. The recruiter's round structure, from your message.
4. The July 2026 strategy brief, as your summary in your message. The brief itself was not pasted.
5. Your background, from your message. No CV was provided.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet, Section "Values cheat sheet". The four values were pasted and copied this morning, so they fix the sheet; a fetch would have checked nothing new. |
| 2. Interview process | skipped | Round structure, persona weights and bank sizes. The recruiter's email names the three rounds, their lengths, who runs each, and the case, which establishes the loop. |
| 3. Strategy and recent news | skipped | Grounding brief and CO and CASE questions. The brief, as summarised in your message, is four months old and fixes the current priorities. |
| 4. Interviewer footprint | n/a | No name was given for the Head of Member Services or the panel, so there was no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The Head of Member Services' name → persona weights for Round B from their public footprint, and a reverse question tied to their career.
- The two branch managers' names → personas assigned per panel member, instead of shared across the panel.
- The recruiter's note on the case format, and whether any deliverable is expected in the panel → a build section for any declared deliverable, and a closer case structure in Round C.
- A redacted copy of the spreadsheet's column headers (no member data) → F4 gets a checkable measure set, and F3 a checkable scope.
- One redacted complaint that went beyond the branch, or a line on how it was resolved → F6 moves from low to medium, and B9 gets a quote.
- Your CV → every row's evidence moves from your message to your CV, and bridges can cite the actual role titles.
- The July 2026 brief itself, pasted → the four grounding lines move from your summary to the brief's own words.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief, interviewer public footprint, role-family loop reports and recent org context. Want it?
- A tuesday-dossier.md → verified evidence and prohibited claims carried into later sessions, with sharper objections.
