WebSearch was refused by a permission prompt, so this pack will run without research. I'm building it from the dossier alone and will say so in the sources.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-4-denied-c89cadd4/3bad0df6-bce6-4a7e-9662-06cd3b67e126/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round from your dossier. Web search was refused, so the pack has no Quartzline values or strategy. Your dossier is also dated 14 August, so check whether the squads or adoption facts have changed.

**The one answer to rehearse:** the objection "You've never held the PM title or owned a roadmap, so why not hire a PM with three years?" Open with the plain acknowledgment: "I haven't held a product manager title or owned a roadmap." Then the bridge with its limit: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live. That's integration leadership, not product management." Then a ramp plan, stated as a plan. Hold through two follow-ups by returning to the integrations, and concede where a PM with three years has more of the job.

**Other things to get right:**
- **Roadmap authority:** don't claim the decision. Ask which calls belong to the squad leads, and say what you'd bring to that conversation.
- **Stage-by-stage:** for "which parts were yours," name only what you personally drove, and say plainly where you didn't decide.
- **Adoption:** ask for the current baseline before you propose metrics.
- **Agile (preferred requirement):** answer from what you've actually done. Don't claim sprint or product-org experience you don't have.

**Prohibited claims:** don't say you've held the PM title, owned a roadmap, or set prioritization for an engineering squad. The pack gives plain acknowledgments for these, not stories.

**Reverse questions to ask:** which roadmap decisions this PM makes alone versus with the squad leads; how adoption is measured today and what the baseline is; what the first quarter looks like.

Would you like a live drill? I can play the Skeptic on the highest-ROI question. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, and I can convert the pack to Word if you'd like.

Has anything about the role changed since 14 August, such as the squad structure or whether an adoption baseline now exists? If so, I'll update the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Quartzline, Product Manager, Platform APIs: hiring-manager round prep

Round: 45-minute conversation with the hiring manager, Thursday 19 November 2026. Built from `tuesday-dossier.md` (conditional_go, dated 14 August 2026). No web research ran (the search permission was refused), so Quartzline's values and current strategy are not in this pack. Interviewer name not given. Nothing here has changed since the dossier; check the squad and adoption facts (see the upgrade menu).

## 1. How to use this pack

Personas are how the question is asked. Types are what is being scored. The guidance is scaffolding for a spoken answer, not a script.

Type key: **JD** = stated requirement or responsibility. **EXP** = what you actually did. **CASE** = live problem. **CO** = company knowledge (none in this pack, see Sources). **VAL** = values (none detected).

Persona weights for a hiring-manager round: Skeptic and Case/Strategist dominate. A hiring manager is buying capability and checking the gaps. Relationship priors from the persona model put Case + Skeptic on top; Pressure and Prober are mid; Conversational is low but still scored.

## 2. Prep triage (about two days)

1. **A1, out loud, five times.** This is the single most likely objection and the highest-return rehearsal. Say the plain acknowledgment first, then the integration work, then the limit.
2. **A2 and C2, stage by stage.** Rehearse only the parts of the 30+ integrations that you personally drove. Name the stages you ran; say plainly where you did not decide.
3. **B3 and A3, the roadmap-authority question.** Do not claim the decision. Ask which decisions belong to the squad leads, and say what you would bring to that conversation.
4. Everything else is insurance.

## 3. Fit snapshot

Confidence is the candidate-evidence band (high, medium, low, none). Provenance is the label on what this pack wrote (`[grounded]`, `[inferred]`, `[generic]`). Gap type follows the evidence cell, not the writer's sense of the row. Evidence is quoted verbatim from the dossier's `verified_candidate_evidence` or its row fields. Origin is `dossier row`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row E1 | low | [inferred] | transferability | Adjacent work only, and the limit is the bridge. Say the integration work in those words, then say plainly that it is not product management experience. Derivation: the underwriter's bridge, from E1. Never as PM experience. |
| F2 | "Owning a roadmap and prioritization authority" (dossier uncertain area, R1 sub-claim) | none given for ownership; nearby: "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row E3 | none | [grounded] | capability | The dossier records no credible evidence. E3 reaches roadmap input, not roadmap ownership. Words: the plain acknowledgment in section 4, then a ramp plan stated as a plan, never as a past. |
| F3 | "Shipped API or platform products" (JD, R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row E1 | high | [grounded] | discovery | Client integrations are evidence near the requirement, not a shipped platform. Answer slot: if any of this became a product or platform release with decisions of yours in it, say which; if these were client deliveries, say so and stay with the integrations. |
| F4 | "Technical fluency: API docs, schemas" (JD, R3) | "Wrote the internal integration playbook her team uses" — dossier row E2 | medium | [grounded] | discovery | The playbook shows documentation of integration practice; the material does not show schema work. Answer slot: if you have worked with API specs or schemas, say which; if not, say what you did handle. Expect a probe; name the caveat before it comes. |
| F5 | "Stakeholder management across engineering, sales, customers" (JD, R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier row E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row E3 | medium | [grounded] | discovery | Customer and product-facing work is shown. Engineering and sales are not. Answer slot: if you worked with engineering or sales on those integrations, say how; if the work went through someone else, say so and stay with customers and product. |
| F6 | "Agile delivery experience" (JD, R5, preferred) | none given | low | [inferred] | discovery | The dossier has no verified evidence here. Answer slot (clarify, section 5 B4): if you have run sprint-based delivery, say which; if your work was client-side, say you ran integrations through a delivery cycle and have not worked inside a product org's cadence. |

Confidence on F1 and F6 is the dossier's grading of the requirement. The underlying E1 claim is high.

## 4. Prohibited claims

Each entry says what the pack will not coach, its basis, and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier `prohibited_claims` | Plain acknowledgment, sourced to that field: "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | dossier `prohibited_claims` and `acknowledge_gap` (R1 sub-claim) | Plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | dossier `prohibited_claims` | Plain acknowledgment, sourced to that field: "I haven't set prioritization for an engineering squad." No slot. |
| Set the product roadmap from client evidence | Inflated form of E3 | E3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is this pack's observation, in analysis: the material says the sessions fed input, not that you set what product built. |
| Led the partner API platform | Inflated form of E1 | E1 at its own scope: the integrations you led, not the platform you ran. |

## 5. Question banks

Personas, weighted: **A** Skeptic (top, 5 questions), **B** Case/Strategist (4), **C** Data-Driven Prober (3), **D** Pressure (3), **E** Conversational (3). Session total 18.

### A. Skeptic (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier `prohibited_claims` and `acknowledge_gap` (R1 sub-claim), named by field; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1) | Deepest rehearsal in this pack. Open with the plain acknowledgment: "I haven't held a product manager title or owned a roadmap." Then the bridge, limit named: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live. That is integration leadership, not product management." Then the ramp plan, stated as a plan. Hold through two follow-ups by returning to the integrations. Concede where a PM with three years has more of the job. | The underwriter named this as the highest-ROI objection, and it is the one the evidence cannot answer on its own. The premise's negatives carry dossier sources, so the Question may keep them. |
| A2 | "Walk me through the integrations. Which stages were yours to decide, and which went to the client or the product team?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1) | Story-mapped on E1: the five beats the quote states, in your own words. Answer slot: if any stage was yours to set and not the client's, say which and how you decided; if none was, say so plainly and describe how you ran the integration. | E1 is the strongest evidence and the likeliest place for a probe; EXP because it tests what was actually yours. |
| A3 | "Tell me about a time you had to choose which work an engineering team did next. What was your part?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (E3, the nearest thing the material carries) | Open prompt. Selection scaffold: pick a time you influenced what a team built next. If none comes to mind, say so plainly, then give the roadmap-input sessions and say what you did and did not decide. | Targets F2 (roadmap ownership), where the material is thin and the interviewer will press. The honest branch is the answer. |
| A4 | "A partner wants a feature that your platform roadmap has ranked low. What do you say?" | JD | [generic] | Live problem, no claim about your past. Structure it: the partner's need, what the roadmap ranking rests on, who decides, and what you would do this week. | The JD's prioritization responsibility, as a decision rather than a record. |
| A5 | "Tell me about a time you pushed back on a customer request to protect a product decision." | EXP | [generic] | Open prompt, selection scaffold: pick a time a customer asked for something you said no to. If none comes to mind, say so plainly and give the nearest integration decision you made with a customer. | R4 stakeholder management, customer side. The honest branch is the answer. |

### B. Case / Strategist (second weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner asks for a webhook for a use case the platform does not support. Walk me through how you'd decide." | CASE | [generic] | Clarify the request, then the objective, the segments of partners affected, the options, the metric you would watch, and the risks. Think aloud. | The JD's partner discovery responsibility. A problem, not a past. |
| B2 | "Adoption of the partner API has been flat for two quarters. Diagnose it." | CASE | [generic] | Clarify what adoption means first. Name the baseline you would need, then the segments, then the hypotheses in order of cost to test. | The JD's adoption metrics responsibility. The dossier's unknown is the baseline, so the first move is to ask for it. |
| B3 | "Two squads and a roadmap of more items than either can take. What would you cut first, and what would you need from the squad leads?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (JD responsibility) | Ask, do not claim. Say which decisions you would bring to the squad leads and which you would make, and say you are not sure yet where that line sits here. | The dossier's squad-authority unknown. Do not claim the decision; the question is open on purpose. |
| B4 | "How would you run discovery and delivery with the two squads in your first quarter?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1, the nearest delivery evidence; it does not carry agile itself) | Clarify (F6). Answer slot: if you have run sprint-based delivery, say which; if your work was client-side, say you ran integrations through a delivery cycle and have not worked inside a product org's cadence. Then the discovery plan you would start with. | R5 is preferred, not must-have, and the dossier's clarify strategy gives no bridge. |

### C. Data-Driven Prober (third weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you count adoption of a partner API? What's the denominator?" | CASE | [generic] | Name the denominator, then the weakest assumption in your own definition before they do. If you do not know how adoption is counted here, say so and ask for the baseline. | The dossier's unknown on adoption measurement; the Prober checks the definition. |
| C2 | "Of the 30+ integrations you led end-to-end, which stages did you run yourself?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1) | Stage by stage, from the quote's own beats. Answer slot: if any stage was not yours, say so plainly and name who ran it. | F3: this is the shipped-platform probe; the answer states what was yours. |
| C3 | "Your integration playbook: what does it cover, and who signs off on changes to it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (E2) | State what you wrote and what it covers. Answer slot: if others approved changes, say so; if you set its rules yourself, say which. | F4 (API docs). The answer shows documentation; it does not show schemas, so say so if asked. |

### D. Pressure (third weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take the risk on someone without the title?" | JD | [grounded] dossier `prohibited_claims` (PM title), named by field; [grounded] E1 | Hold: the integrations, in E1's words, for the first thirty seconds. Concede: the title is not there and a PM with three years has more of the job. Do not fold on the integration work. | Hold-then-concede on F1; the position held is the one E1 carries. |
| D2 | "Thirty integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1) | Hold: you led them, at the stages E1 lists. Concede: name the team's share precisely. Do not state a percentage you did not count. | F3 and F5: a pressure probe on attribution. |
| D3 | "You're being asked to own a roadmap for the first time. Why should I believe you won't hide behind the squad leads?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (JD responsibility) | Hold the position: the role owns the roadmap, so you will own the decisions the role owns and bring the squad leads into the rest. Concede: you have not owned one before, and it is the first thing you would check with them. | F2 under pressure. The premise is the role's, not your past, so it is a fair question. |

### E. Conversational (low weight, still scored)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] E1, E2, E3 (three quoted sentences, each stated as above) | A 90-second arc using only those three sentences: the integrations, the playbook, the roadmap-input sessions. Add nothing. | A casual opener is still scored, and the arc must not outrun its three quotes. |
| E2 | "What are you playing with in API docs right now?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (E2, the nearest thing the material carries) | Answer slot, F4: if you have worked with schemas or API specs lately, say which; if not, say what documentation work you have done and say you would want to get current. | R3 is an important requirement and the material does not show it; the answer is the candidate's own. |
| E3 | "What did you enjoy most about the integration work?" | EXP | [generic] | Answer in your own words, from your own experience. The pack offers no content here. | Rapport question with a real answer; it is cheap to get right and cheap to get wrong. |

## 6. Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| R1, 3+ years PM | A1, D1 | JD-tagged questions present. |
| R1 sub-claim, roadmap ownership | A3, B3, D3 | Acknowledgment, not a claim. |
| R2, shipped platform products | A2, C2 | Discovery; answer slot. |
| R3, API docs and schemas | C3, E2 | Schemas are not shown in the material. |
| R4, stakeholders | A5, B3 | Engineering and sales covered via B3; customers via A5. |
| R5, agile delivery (preferred) | B4 | Clarify only. |
| Adoption metrics (JD responsibility) | B2, C1 | Baseline is the open unknown. |
| Partner discovery (JD responsibility) | A4, B1 | |

## 7. Reverse questions

Each with its "why it lands".

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it is the dossier's squad-authority unknown, asked as diligence.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the dossier's adoption unknown. You need the answer before accepting.
3. "What does a partner discovery cycle look like here, and who is in the room?" Why it lands: it tests the R5 and discovery work with the one person who knows.
4. "What would the first quarter look like if the squads and the roadmap are both new to me?" Why it lands: it shows how you would ramp, and it draws out the squad-authority answer.
5. "What did the last person in this seat have to learn fastest?" Why it lands: it turns the gap into a conversation about the job, not an interview.

There is no interviewer profile, so no reverse question ties to the interviewer's path.

## 8. Sources

- Provided: `tuesday-dossier.md` (version 1.1, dated 14 August 2026). Consumed sections: `handoff_to_mock_interview` (verified evidence E1 to E3, uncertain areas, objection, prohibited claims, risks, employer questions), `role_profile` (requirements R1 to R5, unknowns), and `decision` as context. The dossier is about three months old; facts may have moved.
- Research tier: L1, searches 0 of 6 (2 refused), fetches 0 of 2.
- Queries sent: "Quartzline platform APIs partner integrations" (refused), "Quartzline company values" (refused). Nothing attributable came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet would have been built from it. Both queries refused; values not detected, so the cheat sheet is dropped. |
| 2. Quartzline interview process | unavailable | Loop structure and persona weights. No call sent; the host refused search. |
| 3. Quartzline strategy / recent news | unavailable | CO questions and a grounding brief. The dossier does not fix strategy, so this is not skipped. |
| 4. Hiring manager's name | n/a | No name given; interviewer read absent. |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the JD tier. |

## 9. Upgrade menu

- Quartzline's public values and recent news, from web search or a pasted values page → a values cheat sheet, a strategy-grounded CASE question, and reverse questions tied to current moves.
- The hiring manager's name → a persona read from their public footprint, and a reverse question tied to their own path.
- A current `tuesday-dossier.md` if the role has changed since 14 August → the squad-authority and adoption questions rewritten against the current facts.
- Your CV → gives E1 to E3 a second source, so the rows can be graded `[grounded]` on the document as well as on the dossier.

Question for you: has anything about the role changed since 14 August, such as the squad structure or whether an adoption baseline now exists? If so, I will update the pack.
