Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-8-canned-9847022d/36da3b91-2500-44da-b373-587fd08b9678/scratchpad/ashgrove_member_experience_lead_interview_pack.md. It's built as a three-round loop with a shared fit snapshot, one question bank per round, a values cheat sheet for the panel, and a list of claims not to coach. I didn't run any web searches, since your pasted values, the recruiter's description of the rounds, and the strategy points already cover those.

The most important prep is question M4, the contact-centre objection. The JD asks you to own the complaints process across the contact centre, and you have never worked in one. The Head of Member Services will likely press on it, so rehearse saying "I haven't worked in a contact centre" first, then your first-month plan, and conceding plainly on what you can't yet do.

Two other gaps matter. Your material doesn't show resolution times or the digital-team work the JD asks for, so those answers depend on what you actually did. Also, your "presented above regional level" line is a real gap for the Head of Member Services round, so prepare a plan rather than a story.

Say the word and I'll play the Skeptic on M4 with follow-ups. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Prepared for:** Dara
**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union
**Rounds (all on 26 November 2026):**
- Round 1: recruiter screen, 30 minutes (recruiter named in the email, not by name here)
- Round 2: Head of Member Services, 45 minutes, mostly behavioural. This is your prospective manager. Name not given.
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. Names not given. The panel scores against the four values.

**Changelog:** first version.

**Loop mode.** Shared fit snapshot and sources first, then one mini-pack per round with its own persona weights, question bank and reverse questions. The values cheat sheet sits with Round 3, because the recruiter says the panel is the values round.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores: VAL (behavioural and values), EXP (work-experience deep-dive), JD (a stated requirement), CO (company and strategy), CASE (live problem).
- **Guidance is scaffolding, not a script.** Each guidance cell can be spoken in about 90 to 120 seconds.
- **Answer slots** are instructions for the interview. They ask nothing of you here. Where your material does not show something, the slot gives you both honest branches.
- **Provenance** shows the sentence each claim about your experience rests on. Quotes are from your message or from the JD and recruiter email you pasted.

---

## 1. Fit snapshot (shared across rounds)

Confidence grades your evidence. Provenance grades this pack's statement. Gap type says what kind of gap it is.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap in years. Expect a probe on whether branch supervision counts as customer operations. Say it in your quote's terms: six years in retail banking, the last three as a branch supervisor. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material says formal complaints. It does not say regulated. Keep the words at the log: "I handled the branch's formal complaints log." Answer slot: if you were responsible for any regulatory step in that log, name it and say what you did. If none was yours, say so and stay with the log. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material covers the branch level only. End to end is not in it. Words: "I handled the branch's formal complaints log." Answer slot: if you followed a complaint from first contact to close, say which steps were yours. If the log covered only the branch part, say so. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. The words are the plain acknowledgment: "I haven't worked in a contact centre." Then a plan, said as a plan and never as a past: how you would learn its queues and records first. Add nothing to make the gap feel smaller. |
| F5 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Verified monthly reporting exists in role-relevant terms. The bridge rewords only that quote: "I built the monthly complaints spreadsheet our regional manager uses." Do not add volumes you have not stated. |
| F6 | "and resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet tracked resolution times. Answer slot: if it did, say how they were counted. If it did not, say so and say what you would measure first. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Coaching tellers on a script is adjacent to coaching supervisors on escalations, and the bridge does not stretch it. Words: "trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say what you did. If you did not, say so and say how you would approach it. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Not in your material. Answer slot: if you worked with a digital team on any journey, say which and what your part was. If you did not, say so and say what you would ask them first. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then a plan for preparing a first senior presentation, said as a plan. |
| F10 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred]: that the spreadsheet was Excel is a derivation, not your statement | discovery | Your material does not name the tool, so the bridge cannot say Excel. Answer slot: name the tool you built the spreadsheet in, and the most involved thing it did. If it was not Excel, say what it was. |

**Gates:** none. Years of experience are graded on fit, not treated as gates. The posting states no location or schedule terms.

---

## 2. Prohibited claims

Built from the fit snapshot. These are the claims a candidate reaches for under pressure. None of them may appear in any guidance cell, slot, hold or drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end" | Inflated form of F3 | F3's quote at its own scope. Pack observation, in analysis only: your material describes the branch log, not the process end to end. |
| "Has worked in a contact centre" | Negative you stated, F4 | "I haven't worked in a contact centre." No claim about the past. |
| "Coached branch supervisors on escalations" | Inflated form of F7 | "trained new tellers on our escalation script," at its own scope. |
| "Built the spreadsheet in Excel" | Inflated form of F10 | "I built the monthly complaints spreadsheet our regional manager uses." The tool is an answer slot, not a claim. |
| "Presented to senior leaders" | Negative you stated, F9 | "I've never presented to anyone above regional level." |
| "Handled regulated complaints" as a flat claim | Inflated form of F2 | "I handled the branch's formal complaints log." The regulatory side stays an answer slot. |

---

## 3. Grounding brief (strategy)

Source: the strategy brief points in your message, which summarise the July 2026 brief the recruiter sent. Check exact wording against the document before you quote it in the room. You gave no older brief, so nothing here is stale.

- **Digital:** "move 40% of member service to digital channels by 2028"
- **Network:** "consolidate eight branches into five hubs over 2027"
- **Lending:** "launch a small-business lending product in Q1 2027"
- **Competition:** "the main competitive pressure is app-only banks"

Vocabulary to use: digital channels, hubs, consolidate, small-business lending, app-only banks.

---

## 4. Persona table

Relationship priors set the starting weights. The recruiter's own words adjust them.

| Round | Persona | Depth | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Recruiter | Conversational | 2 | High. Recruiter-screen prior. Casual questions are still scored. | 90-second arc. Treat casual questions about the JD as scored. |
| 1 Recruiter | Skeptic (light) | 2 | High. The contact-centre gap (F4) is the first thing a screener will notice. | Name the gap plainly, then the plan. |
| 1 Recruiter | Logistics (no persona) | 4 | Certain. Pay, notice, location and reason for leaving are screened in the first call. | Give your own figures in your own words. |
| 2 Head of Member Services | Values/Behavioral | 3 | Medium-high. The usual hiring-manager prior is Case and Skeptic, but the recruiter says the round is "mostly behavioural". That moves Values up. | STAR. "We" for context, "I" for your contribution. |
| 2 Head of Member Services | Skeptic | 3 | High. A prospective manager will test F4, F9 and F3. | Hold, then concede specifically. |
| 2 Head of Member Services | Case/Strategist | 3 | Medium. Digital and hub consolidation are the manager's live roadmap. | Clarify, then structure, then challenge one premise. |
| 2 Head of Member Services | Prober | 1 | Medium. The spreadsheet is the one CV artefact a manager is likely to open. | Say what it counted and what you do not know. |
| 3 Panel | Values/Behavioral | 4 | Certain. The recruiter says the panel scores against the four values. One story per value. | Scaffold where your material has no story, and say so. |
| 3 Panel | Case | 1 | Certain. A 20-minute escalation case. | Clarify, structure, member side first. |
| 3 Panel | Peer Evaluator | 3 | Medium-high. Two branch managers are peers on the seam with the contact centre. | Reciprocity. Name seam principles, not claims about the past. |
| 3 Panel | Pressure | 1 | Medium. A time-boxed "why you" is a common panel opener. | Hold, then concede specifically. |

**Interviewer read:** not included. No interviewer profile was given. The upgrade menu says what names would unlock.

---

## 5. Question banks

Scoring guide: the pack's own labels only. Question IDs are per round (S for screen, M for manager, P for panel).

### Round 1: Recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "So, walk me through your journey." | EXP, JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; [grounded] "I handled the branch's formal complaints log" | Story-mapped on the two sentences, using only their beats: six years in retail banking; the last three as a branch supervisor; you handled the branch's formal complaints log. About 90 seconds. Stop there. | Opens the screen and sets the frame. JD because it scores the four-year requirement (F1). |
| S2 | "What's your experience with complaints?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F2: the log and the script, in your words. Answer slot: the JD asks about regulated complaints. If you were responsible for any regulatory step in the log, name it. If none was yours, say so and stay with the log. | F2 is the regulated-complaints requirement, the one the screener will tick or cross first. |
| S3 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then one sentence on what you did bring, in F2's words. Nothing more. | The JD names the contact centre. The honest answer is short and comes first. |
| S4 | "What's your notice period?" | JD (terms) | None stated. Logistics slot. | Give your actual notice period. | Recruiter screens the terms. A logistics slot is an instruction, not a blank to fill. |
| S5 | "What are your pay expectations?" | JD (terms) | None stated. Logistics slot. | Give your own figure, or ask for the role's band first. The figure is yours to choose. | Logistics slot. Never a salary history you did not give. |
| S6 | "Where are you based, and which branches can you reach?" | JD (terms) | None stated. Logistics slot. | Say where you can work, in your own words. If the location matters for the role, ask the recruiter. | Logistics slot. The posting states no location. |
| S7 | "Why are you looking to leave your current role?" | EXP | None stated. Logistics slot. | Give the real reason in one sentence, in your own words. Do not explain it by the appeal of this role. | Reason for leaving is a logistics slot. It also tests motivation consistency. |
| S8 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | Name the contact centre plainly, then the plan: what you would learn first. Add no claim to the plan. Rehearse until it is dull. | The likeliest opener from a skeptic. Covers F4. |

### Round 2: Head of Member Services (45 minutes, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped only where the log is the story: you handled the log, and the beats are the ones you can state. Answer slot: if you held one complaint until it was resolved, tell that one. If you did not, say so and tell the nearest case you handled. | Own the Fix, the value a manager tests first. |
| M2 | "Tell me about a time you put a member's side ahead of a process." | VAL | [generic] | Selection scaffold: pick a case where the process said one thing and the member needed another. It needs a named stake, a decision you made, and what happened. If none comes to mind, say so plainly and give the nearest thing you handled. | Members First. No quote carries this decision, so no story is mapped. |
| M3 | "Tell me about a time you had to explain something a member didn't want to hear." | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. If you have a member explanation, use it. If the nearest is the script, say what it was for and how you taught it, in your own words. If none comes, say so. | Plain Words. The only sentence is about training, so training is the only beat. |
| M4 | "You haven't worked in a contact centre. Your role owns one. What would you do in your first month?" | Skeptic, JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first: "I haven't worked in a contact centre." Then the plan, in order, as a plan. Hold through two follow-ups by returning to the plan. Concede plainly on what you cannot yet do. Never claim contact-centre experience. | **Highest-ROI prep.** This is the likeliest objection, and the material is thinnest exactly here. Rehearse naming the limit and the plan before you are asked for them. |
| M5 | "You've never presented above regional level. How would you present monthly numbers to the executive team?" | JD, Skeptic | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare: which numbers you would check first, and who you would rehearse with. Plan only. | Presenting to senior leaders is a stated requirement (F9). |
| M6 | "How would you own a complaint from first contact to close across branches and the contact centre?" | JD, Skeptic | [grounded] "I handled the branch's formal complaints log" | Transferability: the branch steps are what you can describe. Answer slot: if you followed a complaint from first contact to close, say which steps were yours. If your part stopped at the branch log, say so, and describe only your branch steps. | F3's end-to-end scope, with its limit held. |
| M7 | "A branch supervisor escalates a complaint to you that she has handled badly. How do you coach her?" | CASE, JD | [generic] | Live problem, no claim about your past: what you would ask her first, what you would fix on this file, how you would coach the pattern, and what you would check next time. Do not say you have coached supervisors. For your supervisor years, use only the quoted sentence: "the last 3 as a branch supervisor." | Tests the coach-supervisors requirement as a live problem. The inflated form is on the prohibited list. |
| M8 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What changes for the complaints team?" | CO, JD | [grounded] "move 40% of member service to digital channels by 2028" | Structure: which complaints move to digital, which stay human, and which escalations rise. Answer from the complaints team's side, with self-service journeys in mind. Name one risk and one thing you would measure. No claims about your past. | Brings the self-service requirement (F8) in through the strategy. The brief is the raising source. |
| M9 | "Eight branches become five hubs during 2027. What happens to complaints from the branches that go?" | CO, CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Structure: where complaints from consolidated branches land, what members lose, and what the team must hold steady. Use the brief's own words, hubs and consolidate. Do not claim to know which branches. | Strategy altitude. The brief is the raising source. |
| M10 | "Walk me through the complaints spreadsheet you built. What did it count, and who uses it?" | JD, EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Premised on the quoted sentence: say what it counts, who uses it each month, and what you built it to answer. Answer slot: the JD asks about resolution times. If the spreadsheet tracked them, say how they were counted and which assumption you would defend least. If not, say so and say what you would measure first. Name the tool only if asked, and only if it is true. | Prober. Covers the monthly reporting requirement and F6. No figures were given, so no defend-the-number slot yet. |

### Round 3: Panel (60 minutes, including the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "When did you put a customer ahead of an internal metric?" | VAL (Members First) | [grounded] "I handled the branch's formal complaints log" | Story-mapped only on the log. Say what the member's side of the file was and what you decided from it. Answer slot: if you made a call from the member's side, say the call and why you made it. If you did not, say so and give the nearest log decision. | Members First. The panel scores it. |
| P2 | "Tell me about an explanation that didn't land. What did you change?" | VAL (Plain Words) | [grounded] "trained new tellers on our escalation script" | Scaffold with an honest branch: pick one explanation you gave that had to be repeated, and say how you rewrote it. The nearest in your material is the escalation script. Say what you changed in it, if you changed anything. If not, say so. | Plain Words. |
| P3 | "What does a branch owe the town around it, and what have you done about it?" | VAL (Neighbours, Not Numbers) | [grounded] "the last 3 as a branch supervisor" | Scaffold: your only sentence about branch life is the three years as supervisor. Say what you knew about your town from that post, but only if it is true. If you did nothing specific, say so and say what you would do first. | No quote carries a community act. The honest branch matters here. |
| P4 | "Tell me about a problem you found that wasn't yours to fix. What did you do with it?" | VAL (Own the Fix) | [grounded] "I handled the branch's formal complaints log" | Scaffold: the Own the Fix story is one where you found a problem and kept hold of it until it was solved. If your log work is that story, say so. If you kept hold of nothing, say so and give the nearest problem you found. | Own the Fix has the thinnest story in the material. Be honest about that. |
| P5 | Escalation case (20 minutes): "A member has been escalated twice over a fee. The branch says it was refunded. The member says it wasn't. The contact centre's record shows a different amount. The regulator's complaint timelines are running, and you have a review on Monday with two branch managers. Walk us through what you do." | CASE | [generic] | Structure the 20 minutes. About 3 minutes to clarify: what the record shows, what the member has been told, and who owns the file today. About 5 minutes for objective and segments: the member, the branch, the contact centre, the regulator. About 8 minutes for actions in order: stop further contact on the wrong information, give the file one owner, write a plain-words explanation to the member, reconcile the record, check the timeline. About 4 minutes on what changes and what you would measure. Think aloud. Challenge one premise: "refunded" against "the member says it wasn't." Hold Own the Fix: keep the file until it is closed. | The recruiter named this case. It makes no claim about your past, and all four values are visible in it. Do not invent regulator deadlines. Name the rule you would check. |
| P6 | "Our branches sit beside the contact centre. Where's the seam, and what happens when we disagree?" | VAL, peer | [generic] | Name two principles for when a branch complaint hands to the contact centre, and say what you would do when the two sides disagree about a file. No claim about how the handoff works today. | Peer Evaluator. Turf awareness and disagreement style. |
| P7 | "How do you handle credit when a complaint fix spans two teams?" | VAL, peer | [generic] | Scaffold: pick a fix that involved two teams, and say who did what, in your own words. If you did not share credit on a case, say so and say how you would do it. | Credit-sharing probe. |
| P8 | "What do your branches send to the contact centre that you wish arrived differently?" | VAL, peer | [generic] | Say what you would want to know before you agree to a handoff. Make no claim about the centre's current handoffs. | Peer reciprocity. It opens the seam question from their side. |
| P9 | "Sixty seconds: why you over someone who already works here?" | Pressure | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; [grounded] "Never worked in a contact centre" | Answer from the branch years and the complaints log only. If pushed, hold the position through two follow-ups. Then concede plainly: "I haven't worked in a contact centre," and the plan. Never fold on the branch record. | Pressure. Hold, then concede. The premise about an internal candidate is the panel's line, not a claim about your past. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | S1, M5 |
| Experience handling regulated complaints | S2, M1 |
| Own the complaints process end to end across branches and the contact centre | S3, S8, M4, M6 |
| Report monthly on complaint volumes and resolution times | M10, F6 slot |
| Coach branch supervisors on escalations | M7 |
| Work with digital teams on self-service journeys | M8 |
| Confident presenting to senior leaders | M5 |
| Comfortable with Excel reporting | M10 |
| The four values | M1 to M3, P1 to P4 |
| Strategy (CO) | M8, M9 |
| Live case (CASE) | M7, M9, P5 |

No JD requirement is left without a question.

---

## 6. Values and principles cheat sheet

The recruiter says the panel scores against these four values. Names are as published, copied on 17 November 2026 from ashgrovecu.org/about/values.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a member-side decision. Selection scaffold, with its honest branch: P1 and M2. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | Nearest F7 sentence: "trained new tellers on our escalation script." Scaffold: P2 and M3. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a community act. Nearest F1 sentence: "the last 3 as a branch supervisor." Scaffold: P3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Nearest F3 sentence: "I handled the branch's formal complaints log." Scaffold: P4 and M1. |

---

## 7. Reverse questions

Each one has a "why it lands". No interviewer profile was given, so none ties to an interviewer's own path.

1. **"What does a good first 90 days look like in this role?"** Why it lands: shows you plan rather than pitch.
2. **"How do the branches and the contact centre share a complaint today?"** Why it lands: a seam question, and it invites an honest answer from the panel.
3. **"How will the 2027 hub consolidation change who owns a complaint?"** Why it lands: shows you have read the strategy and link it to the job.
4. **"Which of the four values is hardest to hold in a complaints team?"** Why it lands: tests the values frame in their own terms.
5. **"What would make you say a year from now that the complaints lead did well?"** Why it lands: shows you think in outcomes, and tells you how they will judge you.
6. **Reciprocity (for the two branch managers):** "What could a new person do in their first month that would genuinely help your branches?" Why it lands: a peer question. It shows you are weighing their load, not only your own.

---

## 8. Sources

**Provided documents:**
- The JD text (your message)
- The recruiter email on the process (your message)
- The four values, copied on 17 November 2026 from ashgrovecu.org/about/values (your message)
- The July 2026 strategy points (your message, summarising the brief the recruiter sent)
- Your background (your message)

No dossier was consumed. No links were read. No searches or fetches were run.

**Research tier:** L0, no searches. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet, section 6. The four values you pasted fix it. |
| 2. Ashgrove interview process, member experience | skipped | Loop structure. The recruiter's email names three rounds on 26 November and what each holds, which establishes the loop. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief and CO bank. Your message gives the July 2026 points, which fix both. I have not seen the brief itself. |
| 4. Interviewer name | n/a | No names given for the Head of Member Services or the two branch managers. The interviewer read is absent. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 9. Upgrade menu

- **Names of the Head of Member Services and the two branch managers.** Unlocks an interviewer read, persona weights per person and tailored reverse questions.
- **The strategy brief itself, or its link.** Checks the wording of M8 and M9 and the grounding brief against the source.
- **The regulatory rules you worked under, or the complaint types you handled.** Upgrades F2 from transferability and fills the S2 slot.
- **Figures from the complaints spreadsheet (volumes, resolution times, anything counted).** Unlocks defend-the-number slots for M10 and upgrades F5 and F6.
- **Your notice period, pay expectation, location and reason for leaving.** Fills the logistics slots S4 to S7 in your own words.
- **Prep time available.** Unlocks a prioritised schedule, which this version omits because no time was stated.
- **The recruiter's note on the 20-minute case format.** Unlocks a case bank matched to its format, written or spoken.
- **A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes.** It would cover the public version of the strategy brief, public talks or writing by the interviewers if you name them, role-family loop reports and recent organisational context. Want it?
