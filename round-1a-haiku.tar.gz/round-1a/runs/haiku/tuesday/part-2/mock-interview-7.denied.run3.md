Your prep pack is saved as /var/tmp/tuesday-measure/1a/runs/haiku/tuesday/part-2/rooms/case-7-denied-9ec82bd4/Saltmarsh_Games_live-operations-producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Web search was refused in this session, so the pack has no company values, no interviewer profile and no strategy material. Every bank is built from the JD you pasted and your background message. The pack has 20 questions, and the file's upgrade menu lists what a search-enabled run would add.

**What the pack says about your gaps**

- **Monetisation KPIs (B2) is the highest-return prep.** The JD asks you to own the KPIs the role reports, and you have never worked on a game with in-app purchases. The honest answer is one plain sentence, "I haven't worked on a game with in-app purchases," followed by how you would learn it. Don't present monetisation as something you have read before.
- **Leading a team (B5, D1).** The JD asks you to coordinate four teams, not to manage them. Answer with "I haven't led a team," then how a date held without authority. Don't claim leadership.
- **Post-event review (B3).** Your material shows you presented the retention numbers, not that you owned the review or chose its KPIs. Say what you presented, and say so plainly if no review ran.
- **Coordinating design, art, engineering and community (A4).** Your material is silent here. This is the riskiest answer, so rehearse it with a real drop if you have one.

**Your strongest material:** the content calendar (F2) and the release checklist (F6). Bring both if you can. They are the artifacts an interviewer can inspect, and that moves them from medium to high confidence.

**Drills.** You asked me to run drills on these gaps. A drill runs turn by turn, so I haven't started one yet. Say which one you want:
- B2, the monetisation KPI question. This is the one the pack names as highest-ROI.
- B5, the leadership question.
- D1, the 60-second "why you over someone who has led a team" pressure question.

I can also save a `tuesday-dossier.md` that records these gaps for later sessions, or convert the pack to Word.

Two questions so I can tighten the pack:
1. Is Tobias your future manager, or will a panel be in the room?
2. Does the team expect a deliverable, such as a take-home, a presentation or a written exercise?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, two mobile titles
- **Company:** Saltmarsh Games (mobile games, about 350 people)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed.
- **Round:** 60 minutes, built as a hiring-manager round
- **Built from:** the JD you pasted and your background message. Web research did not run this session (see Sources), so there is no company values, interviewer profile or strategy in this pack.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| JD | The posting's own requirement, asked directly |
| EXP | Your experience, examined closely |
| CASE | A live problem from the role, solved aloud |
| VAL | Values alignment (none in this pack: no published values were found) |
| CO | Company knowledge (none in this pack: research did not run) |

Guidance is scaffolding, not a script. Aim for 90 to 120 seconds spoken. An answer slot is an instruction for the interview: answer from your own experience, in your own words, and say plainly when a practice was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | discovery | Years are not in doubt. Whether the title ran as a live service is not shown. Answer slot: if the title kept running after launch, say what kept it running; if it did not, say so plainly and say which of your work was live. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap: the quote names the calendar, its cadence and its span. Bringing the calendar itself would show the record, not just the claim. |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | The quote carries one title. Words stay at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned anything for a second title, say what and how; if not, say so and say how you would plan two calendars at once. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show who you coordinated with on a drop. Answer slot: name the teams you worked with on a content drop and what you did with each, in your own words; if one of them was not part of your work, say so. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is adjacent to owning a review and choosing its KPIs. The material shows neither. Words at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs a review reported, say which and why; if they were set for you, or no review ran, say so. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: a checklist QA works from. Words: "I wrote the release checklist our QA team still uses." Adds no practice. The checklist itself is the artifact that would raise this to high. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: monthly retention numbers, in front of the studio head. Words: "I presented the monthly retention numbers to the studio head." It says nothing about how the numbers were built; the Prober bank covers that. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | presentation | A written artifact that a team uses is adjacent evidence. It does not show how clearly you write for other readers. Words: "I wrote the release checklist our QA team still uses." A written sample from your work would carry this further. |
| F9 | [generic] Monetisation KPIs on a live mobile title (not a JD line) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | You stated the absence, so the words come from it: "I haven't worked on a game with in-app purchases." No slot, and nothing added to make it feel smaller. Then how you would learn it, said as a plan and never as a past. |
| F10 | [generic] Leading a team (not a JD line; the JD asks you to coordinate, see F4) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | You stated the absence: "I haven't led a team." The coordination story belongs to F4's slot, not to a claim of leadership. |

## Persona table

Weights start from the hiring-manager prior: Case/Strategist and Skeptic dominate, because a hiring manager is buying capability and derisking gaps. No interviewer profile was available, so no interviewer signal adjusts the weights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case/Strategist | A live problem on a drop, a dip in retention, a plan for two titles | High: the hiring-manager prior, and the JD's coordination and calendar lines are live problems | Clarify, then sequence, then name the trade-off aloud | 5 |
| Skeptic | "Where would you be weakest on day one?" and the gap questions | High: F9 and F10 are the gaps a hiring manager will check | Rehearse the single predictable objection; say the gap once, plainly, then the plan | 5 |
| Data-Driven Prober | Follow-ups on the retention line, asking how a number was built | Medium: the JD names retention metrics and F7 is the only quantitative line | Name the weakest assumption you know of; say plainly when you do not know how a number was counted | 3 |
| Pressure | Time-boxed challenges on why you, and how much was actually yours | Medium: a 60-minute loop gives room for a challenge; no interviewer style is known | Hold the one-title record through two follow-ups; concede once, specifically | 3 |
| Conversational | A casual "walk me through the journey" opener | Medium-low: openers are common, but casual questions are still scored | A 90-second arc, in your own words | 2 |
| Peer Evaluator | Seam questions between you and design or engineering | Low: a hiring manager asks these in case form, not as peers | Seam principles, not claims about their teams | 2 |

## Question banks

Total: 20 questions across six personas. Depth follows weight.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Plan the next quarter of live events for two mobile titles. Where do you start?" | JD | [generic] | Clarify each title's goal for the quarter and what each drop must hit. Sequence by the constraints: the QA window, the engineering freeze, the community calendar. Commit to one order and name what you would cut first. Makes no claim about your past. | The JD's calendar line, asked as a live problem. Covers the two-titles requirement (F3). |
| A2 | "A drop due Thursday is at risk: engineering needs another week, and design has already announced the date. What do you do?" | CASE | [generic] | Clarify what is at risk and for whom. Get engineering's real estimate and what can be cut. Decide with QA's sign-off in view. Tell design, art and community the same thing at the same time, and name the trade-off. Answer slot: if you have made this call on a real drop, say how, in your own words; if not, say how you would handle it. | The JD's coordination line (F4) as a live problem. Generic because it is a pattern for the problem, not a fact about this studio. |
| A3 | "Retention on a live title dropped after last week's event. Where do you start?" | JD | [generic] | Confirm the metric definition and the cohort. Check what else changed: a release, a price, seasonality. Segment before you blame the event. Say what data you would need. Name the weakest assumption aloud: that the event was the only change. | The retention requirement (F7) as a live problem. Scored on method, with no claim about your history. |
| A4 | "You would coordinate design, art, engineering and community on every update without managing any of them. How do you get four teams to one date?" | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Structure: who decides scope, who decides the date, what each team needs and by when, and where the decision is written down. Answer slot (F4): if you did this on a drop, say which teams and what you did with each, in your own words; if one of them was not part of your work, say so. | F4 has no quote, so this is the highest-risk answer. The JD raises the coordination; your material is silent on it. |
| A5 | "QA says the build is not ready, and the event date is fixed. What is on your checklist before you call it ready?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Walk the checklist in order: what each line checks, who signs it, and what stops the release. Say that you wrote it and that QA still uses it. Answer slot: if the checklist caught something on a real release, say what and how you changed it; if no release tested it that way, say so. | The release-checklist requirement (F6). The quote carries the checklist; the scenario tests whether you know what each line does. |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Two beats. The gap in one plain sentence: "I haven't worked on a game with in-app purchases." Then your first-month plan: the people you would meet and the first numbers you would ask for. Do not stretch the gap into partial experience. | The Skeptic's stock question. F9 is the likeliest answer, so the answer is rehearsed before the probe. |
| B2 | "This role reports KPIs on two live mobile titles. Which KPI would you be least sure how to read on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message); [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Hold the one you can read first: retention, the numbers you presented. Then the one you cannot, in your own words: "I haven't worked on a game with in-app purchases." On the second follow-up, hold the plan rather than the experience: the first revenue number you would ask for, and what would make you distrust it. Do not present monetisation as something you have read before. | Highest-ROI prep in this pack. The likeliest objection is F9, and the KPI-reporting line of the JD makes it likely to come up. Deepest rehearsal here. |
| B3 | "Tell me about the last post-event review you ran. What did you own in it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot (F5): if you ran a review of a drop, say what you owned in it, in your own words. If no review ran, or the choices were not yours, say so plainly, and say what you presented: "I presented the monthly retention numbers to the studio head." | The JD raises the post-event review; your material does not carry one, so the second branch allows that none ran. |
| B4 | "Show me how you would write up a post-event review that went badly. What goes in the first paragraph?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Structure: what shipped, what the numbers say, what you would change, who owns each change. Keep each claim to a sentence you could defend. Offer the checklist as your sample of written work, described as you wrote it: a checklist QA still uses. | The JD's clear-written-communication line (F8). |
| B5 | "Teams take direction from a lead, and you have not led one. Why would four teams take it from you?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Two beats: "I haven't led a team." Then what makes a date hold without authority: the decision written down, one owner named per team. Answer slot (F4): if you did this on a drop, say how; if not, say so and name the coordination you did do. | F10 meets the coordination requirement. The honest answer is the acknowledgment plus the F4 slot, not a claim of leadership. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How was the cohort defined?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what the number was and who it was for, in your own words. Name the assumption behind it you would defend least. Answer slot: if you chose the cohort definition, say what you chose and why; if it was set for you, say so. If you do not know how it was defined, say so plainly. | F7's method probe. No figure was given, so no defend-the-number slot applies; the honest branch is "I don't know how it was counted." |
| C3 | "Which KPI in those monthly numbers do you trust least?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the one you would defend least, and why. If you did not check the set, say so and say what you would check first. | The prober's denominator question, aimed at the same quote. |
| C4 | "Was the puzzle title you worked on a live-service title? Walk me through what kept it running after launch." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Answer slot (F1): if the title kept running after launch, say what kept it running; if it did not, say so plainly and say which of your work was live. | The JD's three-years-live-service line. The premise is the JD's; the quote gives only the studio and the years. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we choose you over someone who has led a live team?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Hold on the calendar: "For the last two years I ran the weekly content-drop calendar for our main title." Concede once, specifically: "I haven't led a team." Do not fold on the calendar, and do not add a team you led. | Pressure stem. Hold-then-concede: the position held is the one the quote carries. |
| D2 | "Those retention numbers you presented: how much of them was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or checked any of those numbers, say which; if you only presented them, say so plainly. | An attribution probe on F5 and F7. The honest branch is the concession, given once. |
| D3 | "Why should we believe you can run two titles when you ran one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Hold the one-title record at its own scope: weekly, two years, the main title. Concede the gap once, in that scope: the calendar was for one title. Answer slot (F3): if you planned for a second title, say what and how; if not, say how you would plan two calendars at once. | Pressure on the transferability gap in F3. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc: the studio and the four years, then the calendar, in your own words, ending on the calendar. Do not add a title or a team the quotes do not carry. | The opener. Casual in register and still scored, against the JD's content-calendar and experience lines. |
| E2 | "What is a live mobile game you know well, and what would its next update have to do?" | JD | [generic] | Name a title you have played closely. Say what its next update would have to hold: retention, the event, the cadence. Keep it to what you have seen from outside unless you worked on it. | A casual live-service question. Scored on how you think about a live update, with no claim about your history. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Design and engineering sit beside your role. Where is the seam between you and them, and what happens when you disagree?" | JD | [generic] | Propose seam principles: who decides scope, who decides the date, who calls a rollback. Do not pretend to know their seam. Answer slot: if you have disagreed with a lead on a drop, say what you did, in your own words; if not, say how you would raise it. | Peer probing returns in collegial form. Seam principles, not claims about their teams. |
| F2 | "How do you handle credit when a drop's result came from another team's work?" | JD | [generic] | Name whose work did what, in specifics you can name. Credit the team by name. Keep your own part to a sentence you can defend. | The credit-sharing probe, aimed at the coordination requirement (F4). |

### Coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, D3 |
| Coordinate design, art, engineering and community teams | A2, A4, B5, F2 |
| Own the post-event review and the KPIs it reports | B2, B3 |
| Manage the release checklist with QA | A5 |
| 3+ years producing live-service games or apps | C4, E1 |
| Experience running a content calendar | D3, E1 |
| Comfortable with player-retention metrics | A3, C1, C3 |
| Clear written communication | B4 |

Not JD lines, but scored: monetisation KPIs (B2, F9), leading a team (B5, D1). No JD requirement is uncovered.

## Reverse questions

Each one, with why it lands:

1. "What does a good month on this calendar look like for each title?" Why it lands: it shows you think in outcomes, not in shipped items.
2. "Which of your current titles is most at risk on retention this quarter, and why?" Why it lands: their answer tells you where the work is, and asking it signals you are already thinking about the job.
3. "When a post-event review lands badly, who writes the next version?" Why it lands: it tests the ownership line of the JD, and it shows you know reviews are a process.
4. "Which release gate has QA pushed back on most in the last year?" Why it lands: it names the checklist you would own, and shows you care how it works.
5. "What would make you say the first 90 days went well?" Why it lands: it asks for the success measure directly, which is what a hiring manager is ready to answer.
6. "How do monetisation KPIs reach the producers here?" Why it lands: it shows you know there is a side you need to understand, asked as a question rather than a claim.

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review and its KPIs | Inflated form of F5 | "I presented the monthly retention numbers to the studio head." The limit is the pack's own observation: your material says you presented numbers, not that you owned a review. B3's slot stays inside what you presented. |
| Led a team | Negative you stated: "Never led a team" | "I haven't led a team." Plain acknowledgment, no slot. |
| Has worked with in-app purchase economics | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Plain acknowledgment, no slot. |
| Ran the live calendar for two titles | Inflated form of F3 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit: the material shows one title. |
| Owned the release checklist process with QA | Inflated form of F6 | "I wrote the release checklist our QA team still uses." |

## Sources

- **Provided documents:** the JD text you pasted; your background message. No dossier was present.
- **Searches and fetches sent:**
  - "Saltmarsh Games values live operations": refused (search permission was not granted in this session).
  - "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused, for the same reason.
- No fetches were sent. No user links were read.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have moved the values cheat sheet (section 10, omitted: no values detected) and the VAL questions. Both searches for the company and the interviewer were refused. |
| 2. Saltmarsh Games interview process, live-operations role family | unavailable | Would have moved loop structure and the persona weights. No call was sent: search was not permitted in this session. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have moved the grounding brief and the CO bank. No call was sent: search was not permitted in this session. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have moved the interviewer read and the interviewer-tied reverse question. Search was refused. |
| 5. Representative Live Operations Producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Because values, strategy and the interviewer's footprint could not be checked, no CO questions are in the pack, and the banks are built on the JD and your background alone.

## Upgrade menu

- A search-enabled run, or a copy of Saltmarsh's values page and any recent strategy material you can paste → the values cheat sheet, CO questions, and a grounding brief. Search was refused this session, so this is the largest single gap.
- Tobias's public profile or a paste of his talks or posts → an interviewer read, persona weights tuned to him, and a reverse question tied to his own path.
- The content calendar you ran and the release checklist you wrote, brought to the interview → F2 and F6 move from medium toward high, since the artifact can be inspected.
- A retention figure you presented, with what it moved → defend-the-number slots on C1 and C3, which are the probes a number raises.
- One coordination example from a real drop, with the teams and what you did with each → F4's answer slot becomes a story-mapped answer for A4, B5 and F2.
- Whether the puzzle title ran as a live service → F1 moves from discovery to a grounded answer.
- Whether the round includes a take-home or a presentation → a build section for any declared deliverable.
- How many hours you have before Friday → a timed prep triage in the order to work through the banks.
