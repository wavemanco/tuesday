Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-2-denied-3823b6c1/24123eaa-db83-47d6-80fb-1ad670f1d446/scratchpad/atlas-freight_operations-manager_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web research was refused here, so nothing about Atlas Freight itself is in it beyond your message and the JD you pasted.

The three gaps the JD names are the ones to rehearse. Your material shows three supervisors where they want twelve, seven years of operations where they want five-plus years of leadership, and no Power BI. The pack's highest-ROI prep is question A2: "You lead three supervisors today. This role leads twelve across four sites. Why would that work?" Hold what you actually lead, give the plan for the structure, and concede the scale gap plainly.

The other rehearsal priority is the 40% mis-pick figure (B1 and E2). Be ready to say how it was counted, which part of the pick-path redesign was yours, and what you'd defend least about the number.

I can also play the Skeptic on A2 as a live drill, save a tuesday-dossier.md recording the gaps this prep exposed, or convert the pack to Word if you want it that way.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank. And did the recruiter name any focus areas or send a prep email?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep pack

Role: Operations Manager, Atlas Freight (regional logistics, about 800 employees). Interviewer: not known. Round: not stated, so this pack is built as a hiring-manager round with flat-ish weights. Research: none ran (see Sources), so nothing about Atlas Freight comes from outside your message and the JD you pasted.

## How to use

Personas describe how a question is asked. Types describe what is being scored:

- **JD**: can you do the listed job, gaps included
- **EXP**: do your past claims survive scrutiny, and what exactly was yours
- **CASE**: structure and reasoning on a live problem from this role
- **VAL**: past behavior against a principle (no company values were found, so these are generic)
- **CO**: company knowledge (none in this pack, because research did not run)

Guidance is scaffolding, not a script. Answer slots are instructions for the interview, not questions to you. Each one gives two honest branches: a practice you did, or a plain statement that it was not yours or never happened.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site and one recurring plan. Four sites is not in it. Words: "For two years I ran the site's peak-season surge plan." Answer slot in B-row A1 below. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the scale your material shows. Twelve is not in it. Words: "I'm currently a senior shift manager over three supervisors." The structure for twelve is an answer slot (A2). |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Your material shows seven years in operations. It does not show how many of them were leadership. This is not a gate: it is a length of experience, so it is graded like any other requirement. Answer slot: say how many years you have led people and from when, in your own words. If it is under five, say so and lead with the seven years of operations. |
| F4 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The certificate reaches the requirement. Words: "I'm Green Belt certified." Expect a probe on the process it was used on (B3). |
| F5 | "build reporting in Excel/Power BI" (JD, Excel half) | "solid Excel" (your message) | low | [inferred] | discovery | "Solid Excel" states a skill, not reporting work. Your material does not show whether you have built reports in Excel. Answer slot in B4. |
| F6 | "build reporting in Excel/Power BI" (JD, Power BI half) | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past. No timeline is supplied here. |
| F7 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows an accuracy metric. It does not show on-time performance or cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot in B1 and A5. |

Gate check: the JD you pasted has no legal or credential gate (no licence, location, schedule or authorization term). No hard_gate rows.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "Owns terminal operations across four sites" | Inflated form of F1 | "ran the site's peak-season surge plan two years running", at its own scope. Limit, as the pack's own observation: your material says one site's plan, not four sites. |
| "Leads twelve supervisors" | Inflated form of F2 | "currently a senior shift manager over 3 supervisors" |
| "Improved on-time performance or cost per shipment" | Inflated form of F7 | "cut mis-pick rate 40% by redesigning the pick path". Limit: an accuracy metric, not the two JD metrics. |
| "Built Power BI reporting" or "knows Power BI" | Negative you stated (F6) | "I have never used Power BI." Plain acknowledgment, no slot. |
| "Led a Lean/Six Sigma project to a result" | Inflated form of F4 | "green belt certified". The project behind it is a probe to answer in your own words. |
| "I designed the pick path" | Inflated form of role in the 40% | "cut mis-pick rate 40% by redesigning the pick path". Your share of the redesign is a slot (B2). |

## Persona table

Round type is unknown, so the weights below are the hiring-manager prior, adjusted for the JD's three named gaps. They will move once you answer the question in the closing message.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probes on the gaps: four sites, twelve supervisors, leadership years, Power BI | High. A hiring manager is buying capability and checking gaps, and the JD names three of them. Depth: 5 questions. | Rehearse the scale question until it is plain. Say the gap first, then the nearest thing you have done, then the plan. |
| Data-Driven Prober | Follows the 40% and the Excel line to the assumptions | High to mid. The 40% is the headline number on your CV, and "solid Excel" invites a question. Depth: 4 questions. | Say how the figure was counted, or say plainly that you do not know. Name the assumption you would defend least. |
| Case / Strategist | Live terminal problems from this role | Mid. "Own daily terminal operations" invites a live problem. Depth: 4 questions. | Clarify, then measure, then find the bottleneck. Think aloud. |
| Values / Behavioral | Scenario probes on how you lead and deliver bad news | Low to mid. No company values were found. Depth: 3 questions, all generic. | Pick a real story. Say "we" for context and "I" for your part. |
| Pressure | Composure tests: "why you over someone who has run four sites" | Low to mid. Depth: 2 questions. | Pause, restate, hold the position through two follow-ups, then concede only what is true. |

## Question banks

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role runs daily operations across four sites. What have you run across more than one?" | JD | [grounded] "ran the site's peak-season surge plan two years running" | Start with the surge plan: what it covered and that it ran two years. Answer slot: if you have run daily operations across more than one site or shift pattern, say which and what you were responsible for. If you have not, say so plainly, and say how you would set up daily control across four sites, as a plan. | F1 is where the four-site requirement presses hardest. The question presupposes only what the JD raises. |
| A2 | "You lead three supervisors today. This role leads twelve across four sites. Why would that work?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **Highest-ROI prep in this pack.** The scale objection will come in some form. Hold: "I'm currently a senior shift manager over three supervisors." Then the plan for structuring twelve, in your own words. Concede the specific gap: "The scale at twelve is the part I'd need to learn fastest." Answer slot: if you have led more than three people at once, say how many and when. If you have not, say so plainly. | F2 and F3 are the thinnest evidence and the likeliest probe. Deepest rehearsal here; the hold never adds scale the quote does not carry. |
| A3 | "Walk me through your first 90 days in this role." | CASE | [generic] | A plan, not a past. Structure: learn each site's daily numbers, visit each site's floor, meet the supervisors one to one, then pick one measured problem. Nothing here asserts a past event. | Plans are scored separately from history. Nothing needs a source because nothing is claimed about you. |
| A4 | "Where is your reporting gap, and what do you do about it in month one?" | JD | [grounded] "never used Power BI" | Words: "I have never used Power BI." Then the plan: how you would learn it, stated as a plan. Do not give a timeline you have not set. | F6 is a stated absence. The plain acknowledgment is the honest answer; the plan is the part you control. |
| A5 | "What part of this job are you least ready for?" | JD | [grounded] "never used Power BI"; [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pick one gap and name it specifically: Power BI, the scale of supervisors, or the on-time and cost metrics, which your material does not show. Say what you would do first. Do not name all three as a list of excuses. | Shows the self-assessment the Skeptic scores. The 40% quote is there so you do not claim the JD metrics by implication. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number in your own words: the period, the baseline, and the sites it covered. Answer slot: how it was counted, the assumption behind it you would defend least, and which part was yours. If you did this, say how. If there was no such step, or it was not yours, say so plainly and return to the redesign and the 40%. Your material supplies no baseline, so do not supply one now. | F7's headline number. It is the figure the Prober will test first. |
| B2 | "Who designed the pick path change, and what did you do on it?" | EXP | [grounded] "by redesigning the pick path" | Open question, so answer with your own share. If you designed it, say what you did. If the team designed it, say your part plainly. Do not claim the design. | Tests the attribution the quote leaves open. The question presupposes nothing about who did it. |
| B3 | "You're Green Belt certified. Tell me about a process you used it on." | EXP | [grounded] "green belt certified" | Certification is the claim. If you applied it on a project, the project is your story: what the problem was, what you did, and what changed. If the certificate is the only thing, say so plainly and say what you would apply it to first. | F4 is medium confidence with no inspected project. Expect a probe on the project. |
| B4 | "Does your current work involve regular reporting? If so, what, and in which tool?" | JD | [grounded] "solid Excel"; [grounded] "never used Power BI" | Answer with the reports you actually run. Answer slot: name a report you built or maintained in Excel, what it tracked and who used it. If you have not built one, say so and describe the first one you would build. | F5 and F6 together: the Excel half and the Power BI half of the reporting requirement. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance has slipped at one of the four sites. What do you do in the first two weeks?" | CASE | [generic] | Clarify first: which lanes, which shifts, what changed. Then measure, visit the floor, and find the bottleneck. Name one hypothesis you would test first. | A live problem from the JD's first requirement. It asks about no past, so it claims nothing about you. |
| C2 | "Cost per shipment is trending up. How would you diagnose it?" | CASE | [generic] | Split cost into labor, transport and rework. Ask which of the three moved. Name the data you would need and the one number you would check first. | The JD's second metric as a diagnosis, not a history. Nothing about you is asserted. |
| C3 | "Peak season is six weeks away at a site that is already short-staffed. What do you do?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Draw on the surge plan you ran, in your own words: name what it covered. If a step in it was not yours, do not claim it. Then the plan for this site, as a plan. | Your nearest real experience. The quote is the only past claim here. |
| C4 | "Pick accuracy is up at one site and flat at another. Why?" | CASE | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Clarify what differs between the sites: layout, staffing, product mix. Name what you would check first. Connect to your own pick work only as a method, and say it was your work only if it was. | The mis-pick story as a method. The guidance does not claim the other site's data. |

### Values / Behavioral (generic: no company values found)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to tell a senior person bad news." | VAL | [generic] | Pick a real time you had to give bad news to someone senior. Give the named stake, what you said, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the surge plan. | An open prompt. Theme from the persona stem; no past claim is supplied. |
| D2 | "When did you put a customer ahead of an internal number?" | VAL | [generic] | Pick a time a customer or site-level need outweighed a target. Describe what you chose and what it cost. If none comes to mind, say so and give the nearest thing you did. | Generic values probe. The honest branch is built in. |
| D3 | "Describe a time you changed how a team worked to fix a problem." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | This is the pick path story: the problem, who you worked with, what changed, and the result as you can state it. Say only what you did. | Your strongest team-change story. The quote is the only claim about your past. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has run four sites?" | EXP | [grounded] "ran the site's peak-season surge plan two years running"; [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Anchor in what you stated: the surge plan and the 40%. Hold that you can do the job's core work. Concede the scale gap plainly, then the plan. | Composure test. The hold is on what you did, not on what you have not done. |
| E2 | "That 40% figure: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold your part, specifically. Concede where the team's work carried it, without folding on your own contribution. Answer slot: if the redesign was yours, say which parts. If it was the team's, say your part plainly. | The second follow-up breaks anything you cannot back. Say only what you did. |

**Requirement coverage.** F1: A1, A2, C1. F2: A2, A3. F3: A2. F4: B3, F4 row. F5: B4. F6: A4, B4. F7: B1, B2, C2, C4. "Lead 12 supervisors" and "5+ years" are both A2. "Own daily terminal operations" and "Drive on-time performance" are both covered above. No JD requirement is left without a question.

## Reverse questions

Each one has a reason it lands.

1. "What would success look like in the first six months across the four sites?" Why it lands: it shows you think at the site level, not only the headline.
2. "How many supervisors does the team have today, and how are they spread across the sites?" Why it lands: it tests the scale you would be taking on, and it is a question you need answered.
3. "Which of the four sites has the hardest on-time problem right now, and what is causing it?" Why it lands: it shows you want the real operational picture before you commit.
4. "Is Power BI a day-one requirement, or a skill the role grows into?" Why it lands: it asks the gap question directly, which reads as candour and tells you whether it is a deal-breaker.
5. "How is cost per shipment measured today, and who owns that number?" Why it lands: it shows you ask about the metric before you accept responsibility for it.
6. "What did the last person in this role do well, and what did they not get to?" Why it lands: it signals you want the handover, and the answer tells you where the role's real weight is.

## Sources

- **Provided documents:** your message (the JD text and your background summary). No CV file was supplied; all evidence quotes are from your message.
- **Searches sent:** "Atlas Freight regional logistics operations manager": refused, because the web-search permission was not granted. "Atlas Freight regional logistics company values": refused, for the same reason.
- **Research tier:** L0 (documents only). Searches 0 of 6 used, fetches 0 of 2 used, because both searches were refused by the host.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet (section 10), which was not built. Its search was refused. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure and persona weights. The search was refused, so weights rest on the hiring-manager prior. |
| 3. `Atlas Freight strategy` / recent news | unavailable | Grounding brief and CO questions. No search was sent, and the inputs do not fix these outputs. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name and title → persona weights from their public footprint, and a reverse question tied to their career path. Web research was refused here, so none is in the pack.
- Who is in the room (your future manager, a peer, or a skip-level) → reweights every persona bank.
- How many years you have led people, and from when → F3 moves from `low` confidence, and A2's answer slot becomes a stated fact.
- A recent Atlas Freight press item or their careers-page values → the values cheat sheet, and CO questions about current strategy.
- A copy of your Green Belt certificate, and the before-and-after mis-pick report → F4 and F7 can move from `medium` toward `high`, since each would be an inspectable artifact.
- The full posting text, if the paste you sent was abridged → any JD rows that are only partly quoted become `[grounded]` in full.
- The recruiter's prep email, if one exists → coverage of any pre-declared deliverable.
