Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-1-denied-872d390a/1e08473d-45a1-4209-84aa-cb7b7e462681/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. I built it on a peer round with Dan, using your JD highlights, Priya's background, Dan's profile and your research note. I ran it at L0 (no searches) because your note said the research was in hand.

What the pack leans on:
- **Highest-ROI prep:** the ~$400M attribution. Dan will likely ask how much of it was hers. Questions A1 to A3 (and E2 under pressure) carry the rehearsal. The pack keeps her to "proposed" and "credited with," and does not add a method or a stake.
- **Persona weights:** Data-Driven Prober and Peer Evaluator are heaviest, since Dan's profile is self-described data-driven and the round is a peer one. Case is tilted toward pricing and unit economics, because that is his native frame.
- **Thin areas:** quota-setting and sales-ops, and partner-motion design. Both are flagged in the fit snapshot. The honest answers are plans, not past claims.
- **Coverage:** 22 questions across seven personas, with a requirement-coverage table and six reverse questions.

Your summaries are the only source for her sentences, so the quotes are your wording, not hers. Her CV lines would firm them up.

One question for you: does the posting carry any hard gate I haven't seen, such as a location, work-authorization, schedule or credential requirement?

Would you like me to run a deeper research pass on Dan's public writing and Compass status, or to play Dan's Prober on A3 as a drill?

Would you also like the pack as a Word document? I can convert it when you're ready.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data, Senior GTM Strategy Lead (Emerging Products): interview prep pack

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer (same VP). One 60-minute conversation.
**Candidate:** Priya.
**Built on:** your message (JD highlights, Priya's background, Dan's profile, your research note). No CV text, no full JD, no dossier. Research tier L0.

## How to use + type key

Personas = how the question is asked. Types = what is being scored. Guidance is scaffolding, not a script. Say it in your own words.

| Tag | Name | Scored on |
|---|---|---|
| VAL | Behavioral / values alignment | Past behavior that shows cross-functional influence |
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny and what was actually hers |
| JD | Role / JD-driven | Whether she can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Current priorities: Compass, enterprise expansion, profitability, bundling |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from this role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | low | [grounded] | transferability | Your material places her in product strategy and ops, not in GTM for a new product line. Words: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: if she set a go-to-market plan for anything, name it and whose decision it was. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | The material shows a product change with an uplift credited to it, not a whitespace analysis across the four stages. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: name one whitespace she found, by stage, and what she did with it. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | low | [inferred] | discovery | A skill claim with no analysis behind it. Answer slot: name one analysis she ran herself in SQL or Tableau and what it changed; if none, say so and say what she would learn first. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The material shows a revenue model used in negotiations, not a partner motion designed end to end. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if she designed any part of a partner motion (terms, incentives, co-selling), name it; if not, say the model is the nearest thing and where it stops. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Lead with it in those words. Expect a probe on who had to agree. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Tool use, not building AI features. This line is near the Compass launch, so it will be probed. Answer slot: name one AI tool use and one concrete result in her own words; if she has built nothing with AI, say so. |
| F7 | Quota-setting and sales-ops experience (no JD highlight carries it; your message flags it as a gap) | "set annual volume targets with cross-org consensus" (your message) | low | [grounded] | discovery | Target-setting is near quota-setting but is not shown as quota-setting. Answer slot: how she would set a quota for a sales team, and the nearest target she set herself. |

No gate rows. Your material names no location, work-authorization, schedule or credential term. The one question at the end asks whether one exists.

## Prohibited claims

Not coached | Basis | Honest form
---|---|---
Owns GTM strategy for new product lines | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material does not show GTM for a new line.
Drove the ~$400M ARR uplift, or owned the uplift | Inflated form of F2 | "proposed a store-surface change credited with a ~$400M ARR uplift." No slot uses the wider word.
Designed the partner motion | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations."
Runs SQL and Tableau analysis end to end | Inflated form of F3 | "skilled in SQL/Tableau," with the answer slot only.
Has sales-ops or quota-setting experience | Inflated form of F7 | The quote "set annual volume targets with cross-org consensus" at its own scope. The observation: the material does not show a quota process.
Built AI features | Inflated form of F6 | "uses AI tools daily."

No candidate-stated negative exists in the material, so no plain acknowledgment is given anywhere in this pack.

## Prep triage

Prep time was not stated, so this section is omitted. Default to the full pack.

## Reading the interviewer

**Career pattern (profile):** a pricing and monetization spine, with one early-stage startup chapter.
**Self-described style:** "relentlessly data-driven."

Implications:
1. Every figure will be taken apart for its assumptions. A1 to A3 are the rehearsal.
2. Case questions lean toward pricing, packaging and unit economics. That is his native language. C1 is built that way.
3. The startup chapter is a conversation he will enjoy. R1 asks about it.
4. Do not claim pricing expertise. Say where his expertise sits and where her work meets it.

Mirror opportunities: the profile shows no shared professional jump, so none is offered.

## Persona table

Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth
---|---|---|---|---
Data-Driven Prober | Reads the CV line by line; two levels of follow-up | **High.** The peer prior, plus his self-described data orientation (interviewer-signal rule: Prober up) | Know what you can and cannot say about how each number was counted; name the weakest assumption first | 5 (A1 to A5)
Peer Evaluator | Seam-splitting, "what would you need from me," credit and disagreement | **High.** The peer prior. His pricing work is what her hire costs and contributes to | Reciprocity framing; propose seam principles, not a map of his team | 5 (B1 to B5)
Case / Strategist | Live problems on whitespace and the Compass launch | **Medium.** The pricing spine tilts case questions toward pricing and unit economics | Clarify, then objective, segmentation, approach, metrics, risk; think aloud | 3 (C1 to C3)
Skeptic | Quiet probing of the quota-setting and partner gaps | **Medium.** Both gaps are in the fit snapshot, and a peer will test whether her load goes up | Rehearse the quota objection until it is plain; calibrated candor over bluffing | 3 (D1 to D3)
Pressure / Stress | Interrupts, time-boxes, asks how much was really hers | **Low to medium.** A peer round is less composure-testing, but a 60-minute conversation can still hold a hard challenge | Pause, restate, hold through two follow-ups, concede specifically | 2 (E1, E2)
Conversational / Rapport | Casual opener and a casual JD-topic question | **Low.** Still scored: the opener frames everything after it | 90-second arc; treat casual AI questions as scored | 2 (F1, F2)
Values / Behavioral | Cross-org influence probes | **Low.** No values round is detected and no published values are in hand, so the values section is dropped; the cross-org line is a JD line | Story-map from the quote; an honest branch where none carries a story | 2 (G1, G2)

Total: 22 questions. Within the 18 to 26 band.

**Highest-ROI prep:** the $400M attribution (A1 to A3, with E2 as the pressure version). It is the headline figure on the CV, and a peer will test the word "credited" first. Rehearse A3 until the hold and the concession come out the same way every time.

## Question banks

### Data-Driven Prober (weight: high)

ID | Question | Type | Provenance | Answer guidance | Rationale
---|---|---|---|---|---
A1 | "Walk me through how the store-surface change's ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Say the figure in the quote's words, "credited with," and who did the crediting. Defend-the-number slot: if she knows how the uplift was counted, she says how in her own words; if not, she says so plainly and says where the count came from. No method, baseline or model is supplied. | F2 is the figure a prober tests first. EXP because it tests what was hers.
A2 | "Which assumption behind that $400M would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Name the weakest assumption she knows of before he does. Answer slot: if she cannot name one, she says she has not tested the figure's assumptions and what she would check first. | The weakest-assumption move a figure raises. It turns a gotcha into a credibility point.
A3 | "How much of that $400M was actually yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | **Highest-ROI prep.** Say what she proposed and who decided. Hold the quote's scope, "proposed" and "credited with," through two follow-ups. Answer slot: if she did more than propose it, she says what; if the decision and the crediting belonged to someone else, she says so plainly and stays with the proposal. Concede specifically where she does not know. Never fold on the proposal itself. | The sharpest probe on the headline figure, and the pack's named objection. Deepest rehearsal because the sentence says "credited."
A4 | "Walk me through how you set annual volume targets with cross-org consensus." | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Story-map the process only in the quote's beats: the targets, the orgs that agreed, the consensus. Answer slot: if a target moved after it was set, say what moved and why; if none did, say so. | F5's quote and F7's nearest target. A prober asks who had to agree and what it cost.
A5 | "When have you run an analysis yourself in SQL or Tableau, and what did it change?" | JD | [grounded] "run independent analysis in SQL and Tableau" (JD highlights); "skilled in SQL/Tableau" (your message) | Open prompt. She names one analysis she ran, the question it answered and what changed. Answer slot: if the work supported someone else's analysis, she says so. | F3 is low confidence. A hiring peer tests this requirement with one specific example, so she needs one ready.

### Peer Evaluator (weight: high)

ID | Question | Type | Provenance | Answer guidance | Rationale
---|---|---|---|---|---
B1 | "Where is the seam between your GTM work and my pricing and monetization team?" | JD | [generic] | Propose seam principles: who sets list price, who owns packaging changes, what a GTM plan needs from pricing. Say what she does not yet know about his team, and ask. | A peer pricing the hire's contribution asks this collegially. [generic] because it is a pattern, not a fact about Northwind's teams.
B2 | "What would you need from my team to launch a new product line?" | JD | [generic] | Name the three inputs she would ask for first and why. Do not name data she has not seen. | Tests "own GTM strategy for two new product lines" from the peer's side.
B3 | "Tell me about a disagreement with an equal that changed something." | VAL | [generic] | Selection scaffold: a time she disagreed with a peer, held a position, and the outcome changed something. If none comes to mind, she says so plainly, then gives the nearest thing her material carries, the carrier talks or the store-surface proposal, in the scope stated. | Disagreement with equals is what a peer scores. [generic] because no quote carries a disagreement story.
B4 | "How do you handle credit when work spans two teams?" | VAL | [grounded] "credited with a ~$400M ARR uplift" (your message) | Describe how the credit was assigned, in the quote's words, and who assigned it. Answer slot: if credit was shared, say how and with whom; if she was not part of that assignment, say so. | Credit is the probe the word "credited" invites. A peer reaches for the same quote.
B5 | "Walk me through the partner-level revenue model. What did it have to get right for the carrier talks?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Premised on the quote, so it stays in the quote's scope: built, used in negotiations. Answer slot: if she designed any part of a partner motion (terms, incentives, co-selling), she names it; if the model was all of her partner work, she says so and what the model does not cover. | The "partner-motion design" requirement is the one a peer will test by asking what the model depends on.

### Case / Strategist (weight: medium)

ID | Question | Type | Provenance | Answer guidance | Rationale
---|---|---|---|---|---
C1 | "How would you size the whitespace across land, adopt, expand and renew for a new product line?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify the product line, the objective and the segments first. Then approach and metrics. Name the pricing and unit-economics angle, since that is his frame. Name one risk. Think aloud. No claim about her past. | A live problem from the whitespace line, tilted to his pricing spine. The JD is the only source it needs, because it asks nothing about her past.
C2 | "Compass is an AI copilot launch. How would you take it to market?" | CO | [grounded] "an AI copilot launch ('Compass')" (your research note) | Clarify who the copilot is for and what it replaces. Then one sequencing point between land and expand. Offer one divergence from the obvious answer. No claim about Compass internals. | A current-priority question from your note. Its facts are the note's and unverified at L0.
C3 | "Bundling by a much larger platform vendor is the main threat. What would you not do about it?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | The anti-pick: name one response she would refuse, then the divergence she would prefer, with reasons. Do not recite a list of standard counters. | Competitive threat from your note. The anti-pick is the judgment signal a peer who must own the plan looks for.

### Skeptic (weight: medium)

ID | Question | Type | Provenance | Answer guidance | Rationale
---|---|---|---|---|---
D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | Answer slot: name the part her material shows least of, quota-setting or the sales-ops process, and how she would learn it, said as a plan and never as past work. Stay with what the material does show. | The question asks for a weakness, not a negative she asserts. The honest answer is the gap named as a plan.
D2 | "How would you set a quota for a sales team you had not run?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Hypothetical, so it claims no past. Say how she would set it first: the inputs and the check she would make. Then the nearest thing she did, in the quote's words. Answer slot: if none of it was quota-setting in the sales sense, she says so plainly. | The quota gap (F7) is the thin area a peer will probe. The hypothetical keeps the answer honest.
D3 | "Why leave a consumer company for B2B data infrastructure, and why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Answer slot: she gives her reason in her own words. The material contains no reason for the move, so the reason is hers to say. Tie it to the role's terms, not to a claim the material does not carry. | The motivation probe. The pack holds no stated reason, so this is an answer slot, not a script.

### Pressure / Stress (weight: low)

ID | Question | Type | Provenance | Answer guidance | Rationale
---|---|---|---|---|---
E1 | "Sixty seconds: why you over someone who has run sales planning?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Pause, restate the question, anchor in the quote. Hold through two follow-ups. Concede specifically on quota-setting. Never fold on the partner-model claim. | A time-boxed version of the quota gap. Pressure is lower-weight here, but the challenge is cheap for him to make.
E2 | "That $400M — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | The pressure version of A3, with the same hold-then-concede structure. Drill it against A3. | The composure version of the headline probe.

### Conversational / Rapport (weight: low)

ID | Question | Type | Provenance | Answer guidance | Rationale
---|---|---|---|---|---
F1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc in those words, ending on why she is in front of this role. A list of tasks is the wrong shape. | The opener frames every later answer. Communication economy is scored here.
F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name one or two tools and one concrete use. Answer slot: if she has built anything with AI, she names it; if her use is tools only, she says so. | "AI experience a plus," asked casually. A casual question on a JD topic is scored.

### Values / Behavioral (weight: low)

ID | Question | Type | Provenance | Answer guidance | Rationale
---|---|---|---|---|---
G1 | "Tell me about a time you got two orgs to agree on a number." | VAL | [grounded] "set annual volume targets with cross-org consensus" (your message) | Story-map from the quote: the targets, the orgs, the consensus. Beats only what the quote states. Answer slot: if a hard truth had to land with leadership, she says it; if none did, she says so. | The "strong cross-functional influence" requirement. No published values are in hand, so this is an open prompt from the JD line.
G2 | "What did you change your mind on after a debate?" | VAL | [generic] | Scaffold: a time she changed a position on evidence. If none comes to mind, she says so, then gives the nearest thing from her material. | Low-weight coverage. No quote carries a changed mind.

## Requirement coverage

JD requirement | Question IDs
---|---
own GTM strategy for two new product lines | C2, B2, D1
identify whitespace across land/adopt/expand/renew | C1
run independent analysis in SQL and Tableau | A5
partner-motion design experience required | B5, E1
strong cross-functional influence | G1, B4, A4
AI experience a plus | F2, C2
Quota-setting (no JD highlight; flagged in your message) | D1, D2, E1

## Reverse questions

ID | Question | Why it lands
---|---|---
R1 | "What did your early-stage chapter change about how you think about pricing?" | Ties to his own path. It turns the interview into a peer conversation and shows he was researched, not just the company.
R2 | "What could someone new do in the first month that would genuinely help your team?" | Reciprocity. It is the peer's version of "any questions," and it is weighted heavily.
R3 | "Where does a new product line's GTM plan sit between pricing and the land and expand motion today?" | Asks him to describe the seam. It shows she is pricing her own role against his team.
R4 | "How is the team thinking about bundling pressure on the land motion right now?" | Tests whether the competitive threat from your note is live internally. It also shows she read it.
R5 | "When Compass launches, which pricing decisions will be hardest to reverse?" | A pricing question inside the AI launch. It fits his spine and the copilot priority.
R6 | "What would a strong first ninety days look like for this role, from where you sit?" | Gives him a chance to state the success measure, which she can then plan against.

## Sources

Provided documents: JD highlights, Priya's background, Dan's profile, and your research note. All of them came in your message. No dossier was consumed. No CV or full JD was supplied, so the quotes are your summary sentences.

Research tier: L0, no searches; user links read 0

Target | Status | What it moved, or would have
---|---|---
1. Northwind values | unavailable | Would have moved the values section. This round does not trigger it. L0 was used because your note said the research was in hand.
2. Northwind interview process, peer or analytics | unavailable | Would have moved loop structure. Low yield for a single peer conversation.
3. Northwind strategy and recent news | unavailable | Would have refreshed the CO bank. Your note's three priorities and the bundling threat are used as provided material, unverified.
4. Dan Kovac and Northwind | unavailable | Would have moved the interviewer footprint, persona weights and R1. The name was given, so a query could be formed.
5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights in your message fix the requirement list.

## Upgrade menu

- Priya's CV lines in her own words → the quotes move from your message to her CV, and F2's line can reach high confidence if the uplift readout or test results are shown.
- The full JD text → each requirement gets a line-level quote, and any mid-list requirement that is not a highlight gets its own row.
- Dan's name, with an L1 search of his public roles and writing (up to 6 searches and 2 fetches) → persona weights from his published themes, and R1 tuned to his writing.
- An L2 deep run on current strategy and Compass status → C2 and C3 move from your note to cited sources.
- The recruiter's note on focus areas → confirms which bank is weighted.
- One quota or target example Priya tracked to a result → upgrades D1, D2 and F7.
