Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-8-canned-2c81f0a9/8739008e-b09f-4908-9e9d-961d4cf9d7d4/scratchpad/ashgrove_member-experience-lead_interview_pack.md. It covers all three rounds, with a question bank for each, a fit snapshot, and a values cheat sheet for the panel.

The two gaps the pack keeps coming back to are no contact-centre experience and no presenting above regional level. Your own sentences state both, so the pack has you say them plainly and then give a plan. It does not supply experience you don't have. The highest-return rehearsal is B1 in round 2, the contact-centre question.

Say the word and I'll play the Skeptic on B1. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Does the 20-minute case come as a written brief in advance, or live on the day, and may you bring notes? Does the recruiter's email name the hub or branch the role sits in?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Prepared for Dara, 17 November 2026. Three rounds on 26 November 2026: recruiter screen (30 min), Head of Member Services (45 min, your future manager), panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values).

Built on: the JD text you sent, your background note, the values copied from ashgrovecu.org/about/values, the strategy-brief summary, and the recruiter's email. Panel members and the Head of Member Services are not yet named, so there is no interviewer read yet.

## Contents

- How to use
- Fit snapshot (shared)
- Prohibited claims (shared)
- Grounding brief (shared)
- Round 1: Recruiter screen
- Round 2: Head of Member Services
- Round 3: Panel (with values cheat sheet)
- Requirement coverage
- Sources
- Upgrade menu

## How to use

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioural and values alignment
- **EXP**: your own past work
- **JD**: the listed job and its requirements
- **CO**: company and strategy
- **CASE**: a live problem

Provenance labels: **[grounded]** traces to your message or to a document you gave me. **[inferred]** is my derivation from a source. **[generic]** is a pattern for this kind of question and makes no claim about you or Ashgrove.

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: it tells you what to say if the question comes up, in your own words. It is not a question for me.

## Fit snapshot (shared)

Gap type "none" means your material already reaches the requirement. "Transferability" means adjacent work only. "Presentation" means the evidence exists but is not put in JD terms. "Discovery" means the material is silent. "Capability" means you have said the thing is absent.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | none | No gap. Lead with the six years in your own words. Expect a probe on whether retail banking counts as the customer operations the JD means. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | medium | [grounded] | transferability | Transferable: you handled one branch's formal complaints log. Your material does not show end-to-end ownership across branches, and you have not worked in a contact centre. Say "I haven't worked in a contact centre." Answer slot: if any of the process was yours to set, say which step and how you decided; if it was not yours to set, say so and stay with the log you handled. |
| F3 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your sentence already reaches monthly reporting. Use it as written. Confidence is medium because nothing has been inspected. |
| F4 | "resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message; it touches the requirement but does not show whether it reaches it) | low | [inferred] | discovery | Your material does not show whether the spreadsheet holds resolution times. Answer slot: if it does, say what it measures and how the time is counted; if it does not, say so and say what you would add first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message; no tool is named) | low | [inferred] | discovery | Your material says spreadsheet, not which program. Answer slot: name the tool, and say which parts of it you built or changed yourself. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | You trained tellers, not supervisors. Say "I trained new tellers on our escalation script." Answer slot: if you coached anyone beyond tellers on escalations, say who and what happened; if not, say that and describe how you would coach a supervisor on an escalation. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would learn it, stated as a plan and never as a past. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital team, say what you did; if not, say so and say how you would start. |
| F9 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message; "formal" does not say which framework applied) | low | [inferred] | discovery | Answer slot: if the log followed a regulatory framework or deadlines, name them; if you do not know whether it was regulated, say that plainly. |

No row is a gate. The JD states no location, licence or credential. Location and hours still come up in the recruiter screen.

## Prohibited claims (shared)

These are the claims this pack will not coach, and why. Nothing in the banks asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F2 | "I handled the branch's formal complaints log." The limit is my observation, not words for you: your material shows one branch's log, not end-to-end ownership. |
| Presented to senior leaders | Negative you stated (F7) | "I haven't presented to anyone above regional level." No slot. |
| Worked in a contact centre | Negative you stated (F2) | "I haven't worked in a contact centre." No slot. |
| Coached branch supervisors | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F9 | "I handled the branch's formal complaints log." My observation: your material says formal, not which framework. |
| Excel skills | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Reported resolution times | Inflated form of F4 | Only if the spreadsheet held them. Answer slot, as F4. |

## Grounding brief (shared)

Your summary of Ashgrove's July 2026 strategy brief gives the vocabulary the interviewers will use. Use the brief's own words, and cite numbers only as the brief states them:

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- The competitive pressure the brief names is "app-only banks."

Read the published brief before 26 November. Your summary is not its exact wording.

---

## Round 1: Recruiter screen (30 min)

**Relationship:** recruiter. **Personas:** Conversational (weight 3), Skeptic-light (weight 2). The recruiter's email gives the loop: three rounds, and this one is a screen.

**Why these weights:** a recruiter screen prior is conversational with light skepticism. The logistics questions (pay, notice, location, reason for leaving) are scored, and the gap check is short and friendly.

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | A friendly open, then logistics | High: the recruiter screen prior | A 90-second background arc. Treat casual questions as scored. |
| Skeptic-light | "Where are you weakest?" | Medium: the JD is in front of the recruiter, and your two gaps are visible on it | Name the two gaps once, in plain words, with a plan for each. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "Tell me about your background." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log" | About 90 seconds: six years in retail banking, the last three as a branch supervisor, then the formal complaints log and the escalation script you taught. Use those words and stop. Do not add a bigger role. | Opens every screen. F1 and F2 are the first things checked. |
| R1-2 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. If you do not know it yet, say that and when you will know. | Notice is a logistics term, and the answer is only yours. |
| R1-3 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask which band the role carries before you name one. | The pay figure is yours. Your material gives none. |
| R1-4 | "Where would you be based, and how often on site?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" | Logistics slot: say where and how often you can work. If the hub is not stated, ask which hub the role sits in before you agree to anything. | The consolidation makes location a live question, and the JD states none. |
| R1-5 | "Why are you leaving your current role?" | EXP | [generic] | Slot: one sentence giving your actual reason, then what you want from this role. | The reason for leaving is a logistics slot, and your material gives no reason, so none is supplied here. |
| R1-6 | "Why this role, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Tie the role to complaints work you have done, using R1-8 and F2. Mention the digital target only as the brief states it. If digital work is new to you, say so. | A strategy-fluency signal in a friendly register. Scored. |
| R1-7 | "Where do you think you're weakest against this job?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name both: "I haven't worked in a contact centre. I haven't presented to anyone above regional level." Then one sentence on how you would close each one as a plan. Do not add a third gap. | These are the two gaps the recruiter can see. Naming them first costs less than being asked twice. |
| R1-8 | "Walk me through the monthly complaints spreadsheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it holds and who reads it, in those words. If you know how a figure on it was counted, say so. If you do not, say that and what you would check first. Give no figure you cannot stand behind. | F3, F4 and F5 are probed here. A figure you cannot explain under a second question is worse than none. |

**Reverse questions (Round 1)**

1. "What does the next step after this screen look like?" Why it lands: it shows you are thinking about process.
2. "Which hub or branch would this role be based in?" Why it lands: location is open, and asking it plainly is better than guessing.
3. "Who will I be meeting on the panel?" Why it lands: it asks for the names, which feeds the interviewer read.

---

## Round 2: Head of Member Services (45 min, future manager, mostly behavioural)

**Relationship:** hiring manager, your future manager. **Personas:** Skeptic (weight 4), Values/Behavioral (weight 4), Case/Strategist (weight 1, touched through B8). The recruiter said mostly behavioural, so the Values/Behavioral weight is high, and the hiring-manager prior keeps the Skeptic high.

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the contact centre and presenting gaps | High: the hiring-manager prior, and both gaps are on the JD | A plain acknowledgment, a plan, and a stop. Hold through two follow-ups. |
| Values/Behavioral | STAR-shaped stories against the values | High: the recruiter named this round as mostly behavioural | Selection scaffolds with an honest branch. "I" for what you did. |
| Case/Strategist | A live problem on digital | Low here, since the panel carries the case: touched through B8 | Clarify before you structure. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD covers the contact centre, and you've never worked in one. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Say: "I haven't worked in a contact centre. What I know about complaints is from the branch log, which I handled." Then name one first step you would take to learn the contact-centre side, as a plan. Hold through two follow-ups by returning to the log and the plan. | F2 is the largest scope gap, and this is the most likely probe. This is the highest-return rehearsal in the pack. |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level" | "Presenting to senior leaders. I haven't presented to anyone above regional level." Then how you would learn it, as a plan. | F7 is a stated gap, and the honest answer is short. |
| B3 | "Tell me about a problem you found that you then had to keep hold of until it was solved." | VAL | [grounded] "Own the Fix: whoever finds the problem keeps hold of it until it is solved" (values you pasted) | Pick a problem you found that nobody asked you to hold. Say what you did next and where it stopped. Answer slot: if the spreadsheet showed a pattern you acted on, say what you did; if it only reported, say so and say what you would do with a pattern now. | No quoted sentence carries a fix, so the story must come from you. |
| B4 | "Tell me about a time you put a member's view ahead of the process." | VAL | [generic] | Selection scaffold: pick a case where the process and what was fair to the member pointed apart. Say what you did and what the member was told. If none comes to mind, say so, then give the nearest case your log carries, or how you would handle one. | Members First is a published value, and no quoted sentence carries a story for it. |
| B5 | "Tell me about a time you had to explain something to a member, and they still didn't follow." | VAL | [grounded] "trained new tellers on our escalation script" | Answer slot: if you changed how the script was explained so tellers understood it first time, say how; if the script stayed as written, say so and say what you would change. | Plain Words is the value that says a member should not need it explained twice. Your sentence carries the teaching, not the plain words. |
| B6 | "How have you coached a colleague on escalation decisions?" | JD | [grounded] "trained new tellers on our escalation script" | Say: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor or anyone beyond tellers, say who and what happened; if not, say so and describe how you would coach a supervisor on an escalation. | F6 is transferability. The JD's coaching line is about supervisors. |
| B7 | "Walk me through how you'd report complaint volumes and resolution times each month." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the spreadsheet in those words, and say who reads it. For volumes, say what it counts. Answer slot for resolution times: if the spreadsheet held them, say what they measured and how time was counted; if not, say so and say what you would add first. | F3, F4 and F5. Bring the spreadsheet, anonymised, if you can. It is your strongest artifact. |
| B8 | "The strategy moves 40% of member service to digital channels by 2028. How would you work with the digital team on a self-service journey?" | JD | [grounded] "move 40% of member service to digital channels by 2028" | Structure, not a story: pick one complaint type members raise, what the member is trying to do, what the journey must stop doing, and who you would put in the room. Answer slot: if you have worked with a digital team, say what you did; if not, say so and say how you would start. | F8 is discovery. This is the one case-style question in the round. |
| B9 | "When did a complaint you handled have a deadline you could not move?" | JD | [grounded] "I handled the branch's formal complaints log" | Open prompt. Answer slot: if a complaint you handled had a deadline, say what it was and how you kept to it; if the log carried no deadline you were held to, say so and say what rules governed it, if you know. | F9 is discovery, and "regulated complaints" is a JD line. |

**Reverse questions (Round 2)**

1. "What would you need to see from me in the first 90 days to think the role had worked?" Why it lands: it asks a manager's own success criteria.
2. "How does complaints work today across the contact centre and the branches?" Why it lands: it shows you are thinking about the scope gap.
3. "How will complaints move once branches are consolidated into hubs?" Why it lands: it ties the question to the strategy without guessing at the outcome.
4. "What's the first decision you'd want the person in this role to make alone?" Why it lands: it asks for the real authority.
5. Interviewer-path question: not available until the Head of Member Services is named.

---

## Round 3: Panel of two branch managers (60 min, includes a 20-minute case)

**Relationship:** two branch managers, names not yet known. **Personas:** Values/Behavioral (weight 4), Case/Strategist (weight 3), Peer Evaluator (weight 2), Pressure (weight 1). The recruiter said the panel scores against the four values, so Values/Behavioral is the top weight. The case takes the Case/Strategist weight.

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored against the four values | High: the recruiter says the panel is the values round | The cheat sheet below. Each value gets a mapped story or a selection scaffold. |
| Case/Strategist | The 20-minute escalation case | High: the case is in the brief | Clarify, then structure, then say what you would tell the member. |
| Peer Evaluator | Seams with branch teams, disagreement | Medium: the branch managers would work next to this role | Propose seam principles. Do not pretend to know their seams. |
| Pressure | Time-boxed challenge | Low to medium: a panel of two can press | Hold, then concede what is true. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has escalated the same complaint to you a third time, and the branch says it is closed. Talk us through the next 20 minutes." | CASE | [grounded] "trained new tellers on our escalation script" | Clarify first: what the escalation script says, who closed the complaint, and what the member was told. Name the rules you would check rather than assume them. Then approach, risks, and what you would say to the member. You know the script from teaching it, and you can say so. | This is the 20-minute case the recruiter named. The JD's "end to end" line sits under it. |
| C2 | "Tell us about a complaint you kept hold of until it was solved." | VAL | [grounded] "Own the Fix: whoever finds the problem keeps hold of it until it is solved"; "I handled the branch's formal complaints log" | Pick a complaint that took more than one step. Say what you did at each step and where it ended. Answer slot: if you followed a complaint through to resolution, say what you did; if the log only recorded complaints, say so and say what you would do differently now. | Own the Fix. The log is the nearest case your material carries. |
| C3 | "When did a member's side of the counter change how you would run a process?" | VAL | [generic] | Selection scaffold: pick a time the rule and the member's side pointed apart. Say what you chose and why. If none comes to mind, say so, then give the nearest case your log carries, or how you would handle one. | Members First. No quoted sentence carries it. |
| C4 | "We are moving eight branches into five hubs. What do you tell the town, and the staff who remain?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" | Say what members in the town keep and lose, in plain terms. Do not defend or attack the decision. Say what you would measure and what the town will feel. | Neighbours, Not Numbers. Do not guess whether the panel's own branches are on the list. Ask in reverse questions if it matters. |
| C5 | "Explain the outcome of that complaint back to me in one sentence a member would follow." | VAL | [generic] | Write one sentence: what happened, what happens next, and what the member can do. No jargon. Practise it aloud before the round. | Plain Words, as a live test. |
| C6 | "Our branches and the contact centre sit side by side. Where's the seam with you, and what happens when we disagree?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" | Propose seam principles: who owns a complaint at handover, and who decides when the branch and the contact centre disagree. Answer slot: if you have managed a handover between two teams, say how it went; if not, say so and name the principle you would start from. | Peer Evaluator. The JD names the seam. |
| C7 | "Which number on your monthly complaints spreadsheet would you defend least?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Premised question: it names the spreadsheet you built, and no figure. Pick a number you know. Say how it was counted and the assumption behind it you would defend least. If you cannot name a figure confidently, say which one you would check first. | The defend-the-number probe for F3 and F4. |
| C8 | "Sixty seconds: why should we hire someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Hold, do not fold. Say: "I haven't worked in one." Then what you bring from the branch log and the spreadsheet, in those words. Concede plainly what you do not yet know about the contact-centre queue. Hold through two follow-ups. | Pressure, and the most direct form of B1. |

**Reverse questions (Round 3, panel)**

1. "What's the escalation case that keeps coming back in your branches?" Why it lands: it shows you are already thinking about the job.
2. "What could a new person do in their first month that would genuinely help your team?" Why it lands: it is the reciprocity question for a peer panel.
3. "How do complaints move when a branch joins a hub?" Why it lands: it asks about the consolidation without guessing at the outcome.
4. "What makes a complaint here worth escalating?" Why it lands: it asks for the working threshold.

**Values cheat sheet (Round 3)**

No quoted sentence carries a values story. Each value has a selection scaffold with an honest branch. The strongest preparation is a real example from your own record for each value.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold: pick a time the rule and the member's side pointed apart. If none, say so, then give the nearest case your log carries, or how you would handle one. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Scaffold: pick a time you changed how something was explained. Your nearest carried thing is "trained new tellers on our escalation script." If the script stayed as written, say so and say what you would change. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold: pick a time you weighed a town's view against a figure. If none, say so, then say how you would keep the town in view through a hub move. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Mapped in C2: "I handled the branch's formal complaints log," with the answer slot. |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1-1 |
| Own the member complaints process end to end across branches and the contact centre | B1, C1, C6 |
| Report monthly on complaint volumes and resolution times | B7, C7 |
| Coach branch supervisors on escalations | B6 |
| Work with digital teams on self-service journeys | B8 |
| Experience handling regulated complaints | B9, C2 |
| Confident presenting to senior leaders | B2, R1-7 |
| Comfortable with Excel reporting | R1-8, B7 (F5 slot) |

## Sources

- **Provided:** your JD text; your background message; the values you copied from ashgrovecu.org on 17 November 2026; your summary of the July 2026 strategy brief; the recruiter's three-round email.
- **Searches and fetches:** none sent.

**Research tier: L1, searches 0 of 6, fetches 0 of 2; user links read 0.** Every L1 target was fixed by material you already supplied.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove values | skipped | Fixed by the values you pasted. The values cheat sheet uses your copy. |
| 2. interview process | skipped | Fixed by the recruiter's email: three rounds, and the panel scores against the values. |
| 3. strategy and recent news | skipped | Fixed by the strategy-brief summary you pasted (July 2026, under six months old). |
| 4. interviewer name and company | n/a | No names given. The interviewer read is absent. |
| 5. representative JD | skipped | Fixed by the JD you supplied. |

## Upgrade menu

- The Head of Member Services and both branch managers' names → a tailored reverse question per round, persona weights read from their public footprint, and the interviewer read.
- Your CV, pasted → quotes from the document itself rather than from your message. Each "your message" source becomes "your CV."
- The monthly complaints spreadsheet, anonymised → F3 moves to high confidence, and B7 and C7 get worked answers from the file.
- The 20-minute case's format from the recruiter (given in advance or on the day, notes allowed) → if it is a set brief, a build section for it.
- The complaints framework and deadlines you worked under → F9 and B9 move from a slot to a grounded answer.
- A deeper research pass (L2): company strategy brief, interviewer footprint, and loop reports. About six more searches and two more fetches, several more minutes. Offered once.
- tuesday-dossier.md, if you have one → verified evidence and prohibited claims carried in. Without it, the pack is built from your raw inputs as it stands.
