# Interview prep pack: Operations Manager, Atlas Freight

Round: not yet stated. Built for a hiring-manager round (assumed). Interviewer: unknown. Research tier: L0 (your documents only; no searches run).

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = a stated requirement; **EXP** = what you actually did, tested for attribution; **CASE** = a live problem; **CO** = company knowledge (not built, no research run); **VAL** = values (not built, no values in hand).
- Guidance is scaffolding, not a script. Each answer should run 90 to 120 seconds spoken.

## 2. Prep triage

Prep time was not stated, so no schedule is given. Start with A1 and A5, the two questions most likely to decide the round.

## 3. Fit snapshot

Requirements are quoted from the job description you gave. Evidence is quoted from your own messages.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows seven years in ops and one site's surge plan. Stay with those words. Answer slot: if you have run terminal operations across more than one site, say which and how; if not, say so and say what you would need to learn about the other sites first. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your 40% is a mis-pick rate, not on-time performance or cost-per-shipment. Say the result as it is. Answer slot: if you have moved an on-time or cost-per-shipment figure yourself, say which and how; if not, say so and say how you would measure them first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows 3 supervisors, not 12, and not four sites. Say what you lead now in those words. Answer slot: if you have set priorities across more than one team at once, say what they were; if not, say so and say what you would put in place first for 12. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | discovery | Your material says Excel skill, not reporting built. Answer slot: if you have built reporting others used, say what it covered; if not, say so and say what you would build first. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | high | [grounded] | capability | The words you can say: "I haven't used Power BI." Then how you would learn it, as a plan, not as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Your material shows seven years in ops and a senior shift role. It does not show how many years you have led people. Answer slot: give that number in your own words; if it is under five, say so and lead with the seven years of ops behind it. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Say "Green Belt certified," with the certificate ready to show. |
| G1 | "Own daily terminal operations across 4 sites" (JD); location and daily schedule of the sites are not in the posting you gave | none given. Your material does not establish whether the four sites' locations and daily shift pattern work for you. | none | [grounded] | hard_gate | Surfaced, not bridged. This row asks nothing here; the gate question is in the message that delivers this pack. |

## 4. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed 12 supervisors, or led a 12-person team | Inflated form of F3 | "currently a senior shift manager over 3 supervisors," at its own scope. The limit is the pack's observation: your material shows 3. A1 and D3 stay inside that scope. |
| Ran operations across four sites, or owned terminal operations | Inflated form of F1 | "7 years in warehouse and distribution ops" and one site's surge plan. The pack observes that your material does not show multi-site ops. |
| Cut on-time performance or cost-per-shipment | Inflated form of F2 | "cut mis-pick rate 40%," as a mis-pick figure only. |
| Built Power BI dashboards, or reporting in Power BI | Negative you stated, F5 | "I haven't used Power BI." No slot names a dashboard. |
| Lean or Six Sigma expert, or ran a Lean programme | Inflated form of F7 | "green belt certified." |
| The method, baseline or denominator behind the 40% | Figure you gave, not a stated method | Answer slots only: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. |

## 5. Persona weights

No interviewer information was given, so weights use round-type priors for a hiring manager (the assumed round). Recalibrate once the round and relationship are known.

| Persona | Weight | Why | How it shows up | Likelihood and counter-strategy |
|---|---|---|---|---|
| Skeptic | Top, 5 questions | A hiring manager is buying capability and derisking gaps; your gaps are scale (F3, F6) and Power BI (F5) | "Which requirement is furthest from your material?" | Highest. Counter: name the gap in your words, hold the true part, concede the scale |
| Case / Strategist | 4 questions | Hiring managers test live problems on the actual role | Diagnose a cost or on-time drop across four sites | High. Counter: clarify, then objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | 5 questions | The JD names a reporting requirement, and your 40% is a headline number | "How was that counted?" | High. Counter: name the weakest assumption before they do |
| Pressure | 3 questions | Likely in a manager round testing composure on the scale gap | "Why you over someone who has led 12?" | Medium. Counter: pause, restate, hold through two follow-ups, concede specifically |
| Conversational | 2 questions | Casual openers still score | "Walk me through the journey." | Medium. Counter: a 90-second arc |
| Peer Evaluator | 2 questions | Ops managers work next to peers in finance, sales and HR | "Where is the seam?" | Lower. Counter: seam principles, not a claimed seam |

## 6. Question banks

### A. Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which requirement in this role would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Highest-ROI prep in this pack. Name the gap in your own words: the 3 supervisors you lead now, against the 12 the role leads across four sites. Hold what is true: the team-level work you have done. Then concede the scale plainly, not defensively. Then your first 30 days: what you would look at first at each site. Hold through two follow-ups by returning to the 3 supervisors, never by adding to them. | F3 is the biggest gap and the objection most likely to be asked in some form. |
| A2 | "I don't see scale of 12 supervisors across four sites in your background. How would you handle that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Accept the premise as the quote carries it: 3 supervisors today. Answer slot: if you have led people across more than one site, say so in your own words; if not, say so plainly, then describe the first thing you would put in place. | F3 and F1. The interviewer's line presupposes only the team size in your quote. |
| A3 | "What in your background says you can carry the leadership load in this role?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; [grounded] "ran the site's peak-season surge plan two years running" | Lead with the redesign and the surge plan, in your words, as evidence of running operations. Do not claim the outcomes lead to scale. Then concede the scale gap in one sentence. | F2 and F1. The question asks you to argue for fit; the quotes are the evidence. |
| A4 | "How much of that 40% was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Separate what you did (the redesign of the pick path) from what the site or others contributed, in your words. If you don't know how much of the change was yours, say so. | F2. Attribution is the probe, not the number. |
| A5 | "The role asks for 5+ years of operations leadership. How many years have you led people, and in what roles?" | JD | [grounded] "7 years in warehouse and distribution ops"; [grounded] "currently a senior shift manager over 3 supervisors" | Give the number you can stand behind: the years you have held people leadership, and the role each covered. Answer slot: if it is under five, say the number first, then the seven years of ops behind it. Do not round up. | F6. A number asked for directly; the honest branch is the number itself. |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Cost-per-shipment is up across the four sites this quarter. Diagnose it." | CASE | [generic] | Clarify first: which costs, which sites, which period. Then objective, segmentation by site and by cost line, approach, metrics, and risks. Think aloud. | A live problem from the JD's cost requirement (F2). It asks nothing about your past. |
| B2 | "You are starting in 90 days across four terminals. What do you need to know first?" | CASE | [generic] | Structure the first 90 days: what you need in the first two weeks, what you check at each site, and what you would fix first. | A live problem from the JD's site requirement (F1). |
| B3 | "On-time performance dropped at one site last month. What do you check first?" | CASE | [generic] | Start with the data definition of on-time, then the site's inbound and outbound timing, then staffing and peak effects. Name the one check you would run in the first hour. | A live problem from the JD's on-time requirement. |
| B4 | "Peak season is eight weeks out and one site has no surge plan. What do you do?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Use your surge plan as the reference: what you put in place, in your words, then how you would adapt it to a site with no plan. | Your surge plan is the strongest lived evidence for an operations case. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How were the mis-pick figures counted: per line, per order, or per unit?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you know the denominator, say it; if you don't, say so plainly. Do not guess. | F2. A figure you gave raises the denominator slot. |
| C2 | "Show me the Excel you would use for a daily on-time view. What goes in, and what is typed by hand?" | JD | [grounded] "solid Excel" | Describe the Excel work you have actually done, in your words. If you have not built a daily view, say so and say what you would build first, and what you would automate. | F4. The Excel requirement is discovery, not capability. |
| C3 | "If the on-time number and the cost number disagree, which one do you trust?" | JD | [generic] | Name the weakest assumption in each number before they do. Then the check you would run to settle it. | A JD-driven metrics question; no claim about your past. |
| C4 | "Which daily number would you move to a Power BI dashboard first?" | JD | [grounded] "never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then which number you would move first, and why, as a plan. | F5. Asked casually in a prober's register; still scored. |
| C5 | "Did you apply Lean or Six Sigma method to the pick path redesign, or was it separate?" | JD | [grounded] "green belt certified"; [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you applied a named Lean or Six Sigma tool, name it; if the redesign and the Green Belt were separate, say so. Do not name a tool you did not use. | F7. Premised question, with the honest branch built in. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has led 12 supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause, then restate the question. Hold: the three supervisors, the mis-pick cut and two peak seasons, all in your words. Hold through two follow-ups. Concede specifically if pushed: "You're right, I haven't led 12." | F3. Hold-then-concede on the scale gap. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the redesign as yours. Concede what others did in the same period, in your words, without folding on the redesign. | F2. Attribution under pressure. |
| D3 | "You have led 3 supervisors. Why should I believe 12 works?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Name the step you would take first, in a plan, not a past. Do not claim a result at 12. Concede the risk plainly. | F3. Presupposes only the quoted team size. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; [grounded] "currently a senior shift manager over 3 supervisors" | A 90-second arc: seven years in warehouse and distribution, to senior shift manager over 3 supervisors, to what you want next. Keep it to those words. | The casual opener is scored for communication economy. |
| E2 | "What are you playing with in Power BI these days?" | JD | [grounded] "never used Power BI" | "I haven't used Power BI yet." Then what you would do in the first month to learn it. Do not claim any exposure. | F5, asked casually. |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-Q1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claimed seam: how you would agree on handoffs and what happens when a shift's numbers conflict with another team's. | Peer-style probing of partnership fit. |
| F-Q2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Name the principle you would use, then one concrete case in your own words. If you have no such case, say so. | Credit probes come collegially. |

Requirement coverage:

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, B2, B3 |
| Drive on-time performance and cost-per-shipment down | B1, B3, C3, A3 |
| Lead a team of 12 supervisors | A1, A2, D1, D3 |
| Build reporting in Excel/Power BI | C2, C4, E2 |
| 5+ years operations leadership required | A5 |
| Lean/Six Sigma a plus | C5 |

## 7. Reverse questions

1. "What does the first 90 days look like for someone taking over leadership of the supervisors?" Why it lands: it shows you are planning for the scale, and invites specifics.
2. "Which of the four sites has the most pressure on on-time performance right now?" Why it lands: it shows you think by site, not by company average.
3. "How is cost-per-shipment measured across the four sites today?" Why it lands: it shows you think in denominators.
4. "What reporting do supervisors use each day, and what do they wish they had?" Why it lands: it points to the reporting requirement, from the people who use it.
5. "What does success look like at the six-month mark for this role?" Why it lands: it turns the interview toward their scoring criteria.

## 8. Delivery coaching

No working-style assessment was provided, so this section is dropped.

## 9. Sources

Provided documents: the job description excerpt and your message about your background.

Research tier: L0. No searches or fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (not built). Moves the VAL bank, which is absent. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure; would set the persona weights for the actual round. |
| 3. Atlas Freight strategy / recent news | unavailable | Would add CO questions and a grounding brief. |
| 4. Interviewer name and company | n/a | No name given; no query to form. |
| 5. Representative operations manager JD | skipped | The JD you gave fixes the fit snapshot. |

## 10. Upgrade menu

- The round type and the interviewer's role → persona weights for the actual round (A1 and D1 may move)
- The interviewer's name → a tailored reverse question, and weights read from their public profile
- Research at L1 (up to 6 searches, 2 fetches) → values questions and interview loop structure; CO questions on Atlas Freight's current strategy
- The full job description, if the text you gave is a summary → any requirement not yet in the fit snapshot becomes a row
- A Power BI or Excel report you built, described or shared → F4 moves from discovery to presentation, and C2 gets a concrete artifact
- The four sites' locations and daily shift pattern → G1 becomes a resolved row
