# Stripe, Product Operations Manager: final-round prep pack

Role: Product Operations Manager. Company: Stripe. Interviewer: not named. Round: final round, relationship not stated. No job description, CV or background was provided, so this is a worksheet-level pack: every requirement is generic, and every answer is a selection scaffold you fill from your own experience.

## How to use this pack

- Personas describe how a question will be asked. Types describe what is being scored.
- Type key: **VAL** behavioral/values alignment · **EXP** work-experience deep-dive · **JD** role-driven · **CO** company and strategy knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words, in 90–120 seconds.

## Fit snapshot (worksheet variant)

No requirement below is quoted from a posting or from your material, so each one is `[generic]` role-family pattern. Your material establishes none of them yet.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designs and runs recurring operating processes (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process you designed or ran end to end, and what it changed. Pick a recurring process you ran or improved; if none comes to mind, say so plainly, then give the nearest thing you did and how you would design this one |
| F2 | Coordinates work across several teams to a deadline (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a cross-team deliverable with named dependencies and a date. Pick one; if there was none, say so and describe how you would set up the dependencies first |
| F3 | Uses metrics and analysis to drive operating decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you chose and used to decide something. Name one and what it decided; if you have not used one that way, say so and say which metric you would start with |
| F4 | Influences teams without direct authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a decision you moved by persuasion rather than by a reporting line. If none comes to mind, say so, then describe how you would get a reluctant owner to act |
| F5 | Writes clearly for senior leaders (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a document a leader acted on. Name one; if none, say so and describe how you would structure a one-page recommendation |
| F6 | Work authorization, office location and office days (gate; role-family pattern) | none given | none | [generic] | hard_gate | Your material does not establish this, and the pack does not assume it is met. Check the posting and answer the gate question in the upgrade menu before the interview |

Gap types are `discovery` for every non-gate row, because silence in your material is not a capability gap. F6 is a hard gate, surfaced, not bridged.

## Prohibited claims

Built locally, because no CV or background was given. No quoted sentence exists to stretch, so no entry is an inflated form of your past.

| Not coached | Basis | Honest form |
|---|---|---|
| Owning an operating process, metric or stakeholder outcome that you have not described to this pack | No quoted material; claims a candidate reaches for under pressure | Describe what you did, in your own words, with the scope you actually had. The pack does not write it for you |

## Persona table

Relationship and loop are unknown and no loop source was read, so weights are flat, and that is the weakest form of this pack. The archetype fallback is generic: no values-style round is detected.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Asks how a number was counted | Medium | Product Ops is metric-heavy; flat weight | Name the weakest assumption before they do; say plainly what you do not know |
| Pressure / Stress | Interrupts, plays devil's advocate | Medium | Final rounds test composure | Pause, restate, hold a position through two follow-ups before any concession |
| Values / Behavioral | Scenario prompts, STAR-shaped stories | Medium | Common in final rounds; no published values read | STAR for the story, "we" for context, "I" for the decision |
| Case / Strategist | Live operating problems | Medium | Product Ops is often case-led | Clarify, then structure, then metrics, then risks; think aloud |
| Skeptic | Probes gaps and motivation | Medium | Motivation and fit are always probed | Rehearse the most likely objection until it is plain |
| Conversational | Friendly, unstructured, rapport-first | Medium | Casual questions are still scored | 90-second biography arc; treat casual questions about the job as scored |
| Peer Evaluator | Seams between teams, credit-sharing | Low-medium | Only if the final includes a peer | Propose seam principles; frame what you bring to their team |

## Question banks

Depth is flat, two or three per persona, because the weights are unknown. Totals: 18 questions, within the 18–26 coverage range. No question presupposes any fact about your past; each is an open prompt or a live problem.

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you would measure whether a cross-team launch worked." | JD | [generic] | Name the outcome metric first, then the input metrics, then the one assumption you would test first. Say how you would count it and what would change your mind | F3 is the row this probes; JD because the role scores metric design |
| A2 | "Tell me about a metric you used to make an operating decision. How was it counted?" | EXP | [generic] | Open prompt. Choose one metric you actually used. State how it was counted, what it is sensitive to, and which part of the counting was yours. If you have not used one that way, say so and say which metric you would start with | Open prompt on F3; the defend-the-number slot applies only if you give a figure |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over an internal candidate?" | JD | [generic] | Lead with the one thing about you that the internal candidate cannot easily match. Keep it specific. Stop at 60 seconds | Tests composure under time pressure; the row is F1 and F2 |
| B2 | "Tell me about a process you improved. How much of the change was actually yours?" | EXP | [generic] | **Highest-ROI prep in this pack.** Open prompt on F1. Name the process, your part, and the part others did. Hold through two follow-ups by returning to what you did. If you did not improve a process, say so, then describe the nearest change you led or influenced. Concede specifically on the part that was not yours; never fold on the part that was | Probes attribution, the most likely objection for a role built on process ownership |
| B3 | "You have not run an operating process at our scale. Why would yours work here?" | JD | [generic] | Name the first thing you would do in the role, then say what you do not yet know about scale. Hold the first point through one follow-up; concede the uncertainty, not the plan | Pressure on F1's scale; the question asserts a premise about your scale, so answer from your own experience and do not accept the premise |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to deliver an unpopular truth to a senior leader." | VAL | [generic] | Open prompt. Choose one instance; give the context, your decision, and what happened after. If none comes to mind, say so plainly, then give the nearest one you have and how you handled it | Scored behavioral prompt; no values were read, so this is generic |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Name the metric you gave up, the customer outcome, and what it cost. If you have no such instance, say so, then describe how you would decide between them | Scored prompt; the row is F5 |
| C3 | "Tell me about a cross-team plan that went sideways. What did you do in the next 48 hours?" | VAL | [generic] | Open prompt. Describe the first two actions, who you talked to, and what you changed. Stay on your own actions, not the team's | Tests F2 under stress, asked as a story |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch how you would set up an operating review for a new product line. What do you need to know first?" | CASE | [generic] | Clarify the goal, the owners, and the decision cadence. Then structure: inputs, review rhythm, metrics, escalation. State one risk | Live problem on F1; asks no past claim |
| D2 | "Launches slip about one time in five. Diagnose it." | CASE | [generic] | Clarify what counts as a slip. Segment by cause: scope, dependencies, decision latency. Name the metric you would check first | Live problem on F2 |
| D3 | "Which three metrics would you watch for a team that takes requests from four other teams?" | CASE | [generic] | Pick metrics tied to the decision, not to activity. One should measure response time, one quality, one the balance between teams | Live problem on F3 |
| D4 | "A VP asks for a one-page recommendation on whether to retire an internal tool. What do you ask first?" | CASE | [generic] | Ask who uses it, what it costs, and what replaces it. Then state the recommendation and the decision it asks for | Live problem on F5 |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the weakest area honestly, then the specific step you would take in the first two weeks to close it | Probes self-assessment; the row is F1 or F3 |
| E2 | "What would make you a weak hire for this role?" | EXP | [generic] | Name one real risk, not a humble-brag. Say how you would check it early | Probes candor on the whole fit snapshot |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the two or three turns that mattered, and why this role now. Keep it to what you did | Casual opener, still scored; a pre-scripted arc avoids drift |
| F2 | "What are you reading or trying in operations tooling these days?" | JD | [generic] | Name one tool or practice you have used or are testing, and what you learned. Do not claim use you do not have | Casual probe on the role's tooling; F3 and F1 |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as who decides what and how disagreement escalates. Do not pretend to know their seam | Peer-style probe on F2 |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name how you credit others in writing and in the room. Keep it to a practice you have used | Peer probe on F4 |

## Requirement coverage

| Requirement | Covered by | Notes |
|---|---|---|
| F1 Operating processes | B2, D1, E1 | |
| F2 Cross-team coordination | D2, C3, G1 | |
| F3 Metrics for decisions | A1, A2, D3 | |
| F4 Influence without authority | G2 | Thin; upgrade with a named example |
| F5 Writing for leaders | C2, D4 | |
| F6 Gate: authorization, location, office days | none, and why | A gate, asked in the upgrade menu, not rehearsed |

## Reverse questions

1. "What does a strong first 90 days look like here, and what would you expect to have changed?" Why it lands: it turns the interview toward outcomes.
2. "What was the hardest operating decision this team made last quarter?" Why it lands: it shows you care how decisions get made.
3. "How does the team decide between building a process and buying a tool?" Why it lands: it shows you understand the trade-off Product Ops faces.
4. "Which teams would I depend on most, and where do their priorities collide?" Why it lands: it signals you think in seams.
5. "What did the last person in this role do well, and what did they leave undone?" Why it lands: it invites an honest picture of the job.

## Sources

Provided documents: none beyond your message. No job description, CV or background was supplied.

Searches sent: three, each to a declared target, each refused. Query 1: "Stripe values operating principles" (refused). Query 2: "Stripe interview process product operations manager final round" (refused). Query 3: "Stripe product operations manager job description" (refused). Fetches: none sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call refused. The values cheat sheet is absent; no VAL question is mapped to a published value |
| 2. Stripe interview process, Product Operations | unavailable | Every call refused. The loop is not established, so the persona table uses flat weights and the generic archetype |
| 3. Stripe strategy and recent news | unavailable | No call sent: the host refused search, so no CO question is grounded in current strategy |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so no query could be formed |
| 5. Representative Product Operations Manager JD | unavailable | Every call refused. The requirements in the fit snapshot are generic, not `[inferred]` |

## Upgrade menu

- Your round type and who you are meeting (hiring manager, peer, skip-level, cross-functional panel) → persona weights and the reverse questions retuned to the round
- The job description text → the six `[generic]` rows become `[grounded]` or `[inferred]`, and the requirement coverage table becomes checkable
- Your CV or a background summary → the worksheet becomes a real fit snapshot, and the answer slots become story maps from your own sentences
- Web search permission → reruns targets 1, 2, 3 and 5, which adds a values cheat sheet, a loop structure, and grounded CO questions
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- The recruiter's prep email → coverage of any pre-declared deliverable, such as a presentation or take-home
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief and loop reports, if permission is granted
