# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship (future manager or peer) not yet confirmed.
**Round:** 60 minutes on Friday. Built as a hiring-manager round.
**Changes:** first delivery.

## How to use

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral and values alignment
- **EXP**: work-experience deep-dive; whether your claims hold up under scrutiny
- **JD**: role-driven; can you do the listed job, including its gaps
- **CO**: company and strategy knowledge
- **CASE**: hypothetical or live problem

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: answer the first branch if it is true for you, and the second branch if it is not. Nothing here supplies a fact about your past.

Source labels: **JD** means the job text in your message. **your message** means your background as you described it. No CV was supplied.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for two titles and for live events. If you ran or planned for a second title, or events beyond the weekly drops, say which. If not, say that, and say how you would plan two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given (your message names no work with those four teams) | none | [grounded] | discovery | Silence, not a gap you stated. Answer slot: name a release or drop where you worked with design, art, engineering or community. Say what you asked each to do and what happened. If there was none, say so, and say how you would run one update across the four. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning a review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs to report, or ran a review after an event, say which and what changed. If the numbers were set for you, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Your line reaches the requirement. Bridge: "I wrote the release checklist our QA team still uses." The checklist is an inspectable artifact, so expect a probe on what it checks and who keeps it current. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | The years are specific. Live-service is not stated. Bridge: "I was an associate producer at a puzzle-game studio for 4 years." Answer slot: say whether the puzzle game ran on a live schedule and what that meant for you in your own words. The content-drop calendar is the nearest live-service work your message carries. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Your line reaches the requirement. Bridge: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on what the calendar held and who depended on it. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your line reaches the requirement in other terms. Bridge: "I presented the monthly retention numbers to the studio head." Adds nothing to the quote. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A written artifact that others use. Bridge: "I wrote the release checklist our QA team still uses." Adds nothing to the quote. |
| F9 | [generic] leading the people on a team (role-family; not a JD line, though F2 is close) | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated. Words, as a plain acknowledgment: "I haven't led a team." Then a plan, never a past: how you would get four teams moving without authority over any of them. |
| F10 | [generic] monetisation work, in-app purchases (role-family; not in the JD text) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words, as a plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, never a past: how you would learn the monetisation side before your first event. |

Confidence grades your evidence. Provenance grades this pack's statement about it. No gate row: the JD's "3+ years" is a length of experience, not a gate.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1: the JD's "two of our mobile titles" widens your "our main title" | F1's quote at its own scope. The material says one title's weekly content-drop calendar, not live events across two titles. A2 and B1 stay inside that scope. |
| Owned the KPIs the studio reports | Inflated form of F3 and F7: "presented" widened to "owned" | F3's quote at its own scope. Presenting is not owning. This limit is the pack's observation, not words for you. |
| Led a team | Sourced: your stated negative (F9) | "I haven't led a team." |
| Ran in-app purchase events, or monetised a game | Sourced: your stated negative (F10) | "I haven't worked on a game with in-app purchases." |

## Persona weights

Relationship prior for a hiring manager is Case plus Skeptic. Interviewer signals: none, because no research ran. Loop: unknown.

| Persona | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems from the JD: two titles, four teams, a bad retention day | High. The hiring-manager prior, and the JD's most specific lines are all live problems | 5 | Clarify, then structure, then name the trade-off in writing |
| Skeptic | Probes the two stated gaps and the two-title scope | High. The hiring-manager prior, and your gaps are visible in one line each | 5 | Rehearse the single most predictable objection until it is plain |
| Data-Driven Prober | Asks how retention was counted and which KPIs you chose | Medium. The JD names retention and KPIs, but your material is one line | 3 | Say what you know about the count, and say plainly what you don't |
| Pressure | Interrupts or challenges your lack of team leadership | Medium. A manager-level role with a stated leadership gap | 3 | Hold the position through two follow-ups, then concede the specific limit |
| Conversational | Opens with "walk me through the journey" | Certain as an opener, and scored | 2 | A 90-second arc, rehearsed once |

Total: 18 questions. Depth follows weight: 5, 5, 3, 3, 2.

## Question banks

### Bank A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, a weekly update on each, and a team you don't run. What do you need to know before you plan the next month?" | CASE, JD | [generic] | Clarify before you structure: each title's current event cadence, what a good month looks like, which teams are already committed, and QA's lead time. Then sequence the month. Claim nothing about your past here. | F1 and F2 are the gaps. A live problem drawn from the JD's own lines, asking nothing about your history. |
| A2 | "Day-three retention on a new content drop is down. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify the cohort and the release window. Split by player segment. Separate what changed in the drop from what changed around it. Name the metric you would check first and the one you would hold back. | F7: retention is in the JD and in your material. A live problem. |
| A3 | "Design wants a bigger event, art can't deliver the assets in time, and engineering says the feature isn't safe to ship. How do you run this update?" | CASE, JD | [generic]. Raising source: JD "coordinate design, art, engineering and community teams on each update" | Name the conflict and what each team protects. Decide what you can call yourself, and put any trade-off for the owner in writing with a dated choice. Answer slot: if you have run a version of this, say which teams and what you asked each to do. If not, say so, and give the plan. | F2 is a discovery gap. This is the live problem behind the JD line. |
| A4 | "Walk me through what goes into the post-event review for an event that missed its target." | JD | [generic]. Raising source: JD "own the post-event review and the KPIs it reports" | Target against plan. Say what you tried, what the data can't tell you, what changes next time, and who owns it by when. Answer slot: if you have written or run a post-event review, say what it contained. If not, say so, and give this one. | F3 is transferability. The review is the JD's own line. |
| A5 | "Live events on mobile often involve store offers and in-app purchases. How would you plan one?" | CASE | [generic] | Clarify what the offer may do, the store-review and timing constraints, and which metric shows whether it worked. Say plainly that you haven't worked on in-app purchases, then what you would learn first, as a plan. Plain acknowledgment: "I haven't worked on a game with in-app purchases." | F10 is a stated gap. The question is generic, so it makes no claim about this employer. |

### Bank B: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran the content-drop calendar for your main title. This role runs live events for two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Hold the quote: "For two years I ran the weekly content-drop calendar for our main title." Hold through two follow-ups by returning to the calendar, never by adding to it. Concede specifically: say what you have run, which is one title's calendar, then give the plan: clarify each title's cadence, agree one shared calendar, and check QA's lead time. Answer slot: if you ever planned events or calendars beyond the main title, say which. If not, say that plainly. | F1 is where the JD presses hardest, so this objection will arrive in some form. It gets the deepest rehearsal because it is predictable and the answer is thin. |
| B2 | "Four teams, and no authority over any of them. Why would design or engineering move a date for you?" | JD | [grounded] "Never led a team" | Hold: teams move for a shared, dated trade-off, not for seniority. Do not claim authority you lack. Answer slot: if you have coordinated across design, art, engineering or community on a release, name the teams and what you asked each to do. If your work was with QA only, say so. | F2 is a discovery gap and F9 a stated gap. This is the Skeptic's probe on both. |
| B3 | "Have you worked on a game with in-app purchases?" | EXP | [grounded] "never worked on a game with in-app purchases" (plain acknowledgment) | Say it flat: "I haven't worked on a game with in-app purchases." Then one plan: how you would learn the monetisation side before your first event. Claim no in-app purchase exposure. | F10 is a yes or no probe on a gap you stated. Answer it as the gap it is. |
| B4 | "The job asks for three years of live-service work. Was the puzzle game live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years." | Answer with the years and the calendar, in those words. If the puzzle game ran on a live schedule, say what that meant for you. If you are not sure it counts as live-service, say so. | F5 is transferability. The requirement is a term of years, not a gate, and the calendar is your nearest answer. |
| B5 | "Why leave after four years for this role?" | EXP | [generic] | Answer slot: your reason for leaving, in your own words. This pack has no reason for you. Say what this role gives you that your current one does not. | A motivation-consistency probe. It makes no claim about your history. |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the monthly retention number you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know the cohort, the window and the source, say them. If you don't, say so plainly. Then name, in your own words, the assumption behind the figure you would defend least. | F7. The question presumes only the quoted "retention numbers". No figure is given, so no figure is supplied here. |
| C2 | "Which KPI did you own, and which did you only report?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you chose any KPI, say which and why. If the numbers were set for you, say so plainly. | F3. The JD asks you to own KPIs. Your material shows presenting. Keep the answer at that scope. |
| C3 | "What does your release checklist check, and what happens when an item fails?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Describe the items in your own words. If you don't know what happens on a failure, say so. Bring the checklist if you can. | F4. The checklist is your strongest artifact, and its probe is likely. |

### Bank D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why give a two-title role to someone who has run one calendar?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the calendar and do not fold. Concede a specific limit: you have run one title's calendar, so say that. Then the plan, in two sentences. Hold through two follow-ups. | F1, timed. Same objection as B1, delivered under pressure. |
| D2 | "How much of that release checklist was your call, and how much did QA set?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: say which items you wrote and which QA set. If you don't know, say so. Hold only the line you can back. | F4. Attribution under a challenge. |
| D3 | "You haven't led a team. What happens when design says no to your date?" | JD | [grounded] "Never led a team" (plain acknowledgment: "I haven't led a team.") | Say the acknowledgment flat. Then the plan: ask what the date protects, put the trade-off in writing, and escalate with a dated choice. Hold the plan and concede the authority. | F2 and F9. The Pressure version of the coordination probe. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years."; "Presented the monthly retention numbers to the studio head."; "Wrote the release checklist our QA team still uses." | A 90-second arc: the studio, the calendar, the checklist, the retention numbers, then what you want next. Use these sentences in your own words, and nothing more. | An opener, and scored for communication economy. |
| E2 | "What live game are you playing right now, and what would you change in its events?" | JD | [generic] | Name one game you play and one event decision in it you would make differently, with a reason. Make no claim about Saltmarsh titles, since no research ran. | A casual route to the JD's live-events topic. |

### Requirement coverage

- R1, two titles and the live-events calendar: A1, B1, D1
- R2, coordinate four teams on each update: A3, B2, D3
- R3, post-event review and KPIs: A4, C2
- R4, release checklist with QA: C3, D2
- R5, 3+ years live-service: B4, E1
- R6, content calendar: B1, E1
- R7, retention metrics: A2, C1
- R8, clear written communication: none, and why. The round is spoken. If a writing task is announced, see the upgrade menu.

## Reverse questions

1. "What would a good first 90 days look like for this role?" Why it lands: it shows you are planning, not waiting to be told.
2. "Which two titles does this role cover, and what does each one's weekly update look like?" Why it lands: it names the scope you are being hired into.
3. "How do design, art, engineering and community agree on an update's date today?" Why it lands: it shows you already think about the four-team coordination.
4. "Who owns the post-event review now, and what do they usually change first?" Why it lands: it tests the JD's review line from the inside.
5. "What would you need to see from this hire by month six?" Why it lands: it turns the interview into a shared definition of success.
6. "What did your last producer need that they didn't get?" Why it lands: it invites the interviewer's own pain, which you can then answer with your plan.

## Sources

- Provided documents: the JD text and your background, both in your message. Read.
- Searches sent: 4 (see the target accounting below). Every one was refused by the host, because web search permission was not granted. No fetches.
- No values page, interview loop, strategy or interviewer footprint was available. Company-level content is therefore generic, labelled `[generic]`.

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values (query: "Saltmarsh Games values") | unavailable | Values cheat sheet, not built. Search refused; no values page supplied |
| 2. Saltmarsh Games interview process (query: "Saltmarsh Games interview process live operations producer") | unavailable | Loop structure and persona weights. Generic priors used |
| 3. Strategy and recent news (query: "Saltmarsh Games mobile game live operations news") | unavailable | Grounding brief and CO questions, not built. Search refused |
| 4. Interviewer footprint (query: "Tobias Wrenfield Saltmarsh Games Head of Live Operations") | unavailable | Interviewer read, persona weights, a reverse question tied to his path. Search refused |
| 5. Representative JD | skipped | The JD in your message fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Tobias's public footprint (once search is allowed) → an interviewer read, persona weights, and a reverse question tied to his career path
- Saltmarsh's values page, pasted → a values cheat sheet, with a story per value drawn from your quoted sentences
- The 60-minute format (one-to-one or panel), and any case or exercise → how much time A1 and A3 get
- The recruiter's note on focus areas, or any pre-declared deliverable → a build section per deliverable
- Your CV as a file → quotes move from "your message" to your CV, and F1 to F8 gain a stronger source
- The retention figure you presented, with its method if you know it → defend-the-number slots for C1
- A second title's calendar, if you ran one → upgrades F1, B1 and D1 from thin to grounded
