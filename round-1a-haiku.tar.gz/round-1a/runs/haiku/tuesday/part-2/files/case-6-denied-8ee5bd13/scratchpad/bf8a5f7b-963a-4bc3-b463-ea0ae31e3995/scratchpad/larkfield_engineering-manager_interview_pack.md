# Larkfield Systems, Engineering Manager: combined prep pack

Changelog: first version. Three rounds in loop mode: shared fit snapshot, then one mini-pack per round.

**Role:** Engineering Manager, device-management services, Larkfield Systems (industrial IoT, ~600 people)
**Rounds:**
- Tuesday, 45 min: hiring manager (Director of Engineering, your likely manager)
- Thursday after, 60 min: panel, two staff engineers and a product manager
- Following Monday, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy"

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. All three company searches were refused by the host. Nothing about Larkfield's values, loop or strategy is established. Company-specific content is labelled `[generic]`.

## How to use

Personas describe how a question arrives. Types describe what is being scored:

- **VAL**: behavioural or values alignment
- **EXP**: deep-dive on your own experience
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

Guidance is scaffolding for a spoken answer, not a script. Where a guidance cell says "answer slot", it is an instruction for the interview. It asks for no reply here.

## Fit snapshot (shared across all three rounds)

**Sources.** Requirements come from the role summary you supplied, quoted as "role summary". Your evidence comes from your message, quoted verbatim. No CV and no full job description were supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says one team of six, and it does not mention two squads or device-management work. Say the team of six and the three years in those words. Answer slot: if you have led work on device-facing or hardware-attached systems, say what it was and what you decided; if not, say so, and say how you would learn the domain. |
| F2a | "own delivery, hiring and growth for 11 engineers" (role summary): hiring | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | The quote reaches hiring in role-relevant terms. It covers backend roles only. Say the roles and the number in those words. |
| F2b | "own delivery, hiring and growth for 11 engineers" (role summary): delivery | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material says one reliability quarter, held against roadmap pressure, for one team. It does not show delivery across eleven engineers. Answer slot: describe how you would run delivery across two squads, and say which parts you have run before. |
| F2c | "own delivery, hiring and growth for 11 engineers" (role summary): growth | none given | none | [grounded] | discovery | Your material does not show anyone you have grown. Answer slot: name an engineer you grew into a larger role, what you did, and what changed. If there is no such case, say so plainly and say how you would start. |
| F3a | "partner with hardware and product on roadmap" (role summary): product | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows you pushed a roadmap decision against pressure. It does not show partnering with a product team on a roadmap. Say the reliability quarter in those words. |
| F3b | "partner with hardware and product on roadmap" (role summary): hardware | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | discovery | Your material says nothing about working with a hardware team. Your stated limit covers owning a hardware-adjacent roadmap, not partnering with a hardware team. Answer slot: if you have worked with a hardware team in any capacity, say how; if you have not, say so, and say how you would set that partnership up. |

**Points the snapshot cannot settle:**

- The role summary says the squads are led, and it does not say whether they have their own leads. If they do, managing managers becomes a requirement, and your stated limit "I've never managed managers" becomes a `capability` row. Confirm this with the recruiter before Tuesday.
- The summary says "partner with" hardware and product. It does not say "own" a hardware roadmap. If the full posting says "own", F3b's gap type changes. Your stated limit on owning a hardware-adjacent roadmap would then carry the row.
- The 60% on-call figure and the 40 interviews are figures you gave. Each raises defend-the-number slots in the banks below, and each is a place where you should say only what you can repeat under a second question.

## Prohibited claims

These are the claims this pack will not coach, and why. Each entry lists its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have managed managers" | Your stated limit | Plain acknowledgment, from your message: "I've never managed managers." Then a plan, said as a plan. |
| "I have owned a hardware-adjacent roadmap" | Your stated limit | Plain acknowledgment, from your message: "I've never owned a hardware-adjacent roadmap." |
| "I led delivery for eleven engineers" | Inflated form of F1 and F2b | The team of six, at its own scope (F1). The reliability quarter, at its own scope (F2b). Your material says one team. |
| "I ran a reliability programme across the organisation" | Inflated form of F2b | The reliability quarter, held against roadmap pressure, for one team (F2b). |

The 60% figure is not on this list. It is an answer slot, and the defend-the-number slots in the banks govern it.

## Round 1: Hiring manager (Director of Engineering), Tuesday, 45 min

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live roadmap problems with hardware and product | High. The Director is buying capability on a live roadmap. This is the hiring-manager prior. | Clarify, then structure, then name the metric. |
| Skeptic | Probes gaps in F1, F2c and F3b | High. The gaps are visible in the summary. | Rehearse the most predictable objection until it is boring. Bridge only from quotes. |
| Data-Driven Prober | Asks how the 60% and the 40 interviews were counted | Medium. Both figures are on your CV-style statements. | Say what you can and cannot say about each count. Name the weakest assumption before they do. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, a hardware team and a product lead want different things from the next two quarters. How would you sequence that?" | CASE | [generic] | Clarify first: which devices, which customers, what date is committed. Then state the objective, segment the work, set the approach, name two metrics, and name the main risk. Do not claim any past sequencing. | F3 is the requirement this tests. The question makes no claim about your history. |
| A2 | "A device fleet's check-in failures rose 20% this month. Walk me through how you would diagnose it with your squads." | CASE | [generic] | Clarify the population and the time window. Structure before you diagnose. Say what you would ask the hardware team first. | A live problem from the role. It presupposes nothing about you. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary) | Name the hardware partnership as the weakest area. Then give the bridge from F3a: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Say the roadmap negotiation in those words. Then say the ramp plan. Do not claim hardware experience. | F3b is the weakest row. The Skeptic will go there, so name it first. |
| A4 | "You've led one team of six. Why would two squads and eleven people be different?" | EXP | [grounded] "3 as a team lead of 6" (your message) | Accept the difference and say what you would do about it: a plan, not a past. Answer slot: if you have run anything bigger, or with more than one team, say what it was in your own words; if not, say so and state the step you would take first. | F1 is the premise. The second branch allows that the larger scope has not been done. |
| A5 | "How did you count the 60% on-call drop?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say what you counted, over what period, and from which source. Name the assumption you would defend least. Say which part of the drop was yours. If you do not know how it was counted, say so plainly. Do not supply a method, baseline or attribution model. | A figure you gave raises the defend-the-number slots. The honest branch is "I don't know how it was counted." |
| A6 | "Walk me through your hiring loop. How many of the 40 interviews turned into offers?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Give the count you have. Say which steps of the loop you ran and which others ran. Answer slot: if you do not have the offer count, say so plainly. | F2a is the strongest row. The offer count is the probe the Director is most likely to ask for. |
| A7 | "Which of your own decisions in the reliability quarter would you change?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name one decision you would change, and what you would do differently. This tests self-assessment. Do not manufacture a regret you do not have. | The reliability quarter is your strongest story. The Director will test whether you can judge it honestly. |
| A8 | "What would make you a manager of managers?" | JD | [generic] | Frame it as a plan, not a claim: what you would learn, who you would ask, and what you would hand off first. Do not describe any past experience of managing managers. | This is the predictable objection to F5. It is the highest-ROI rehearsal in this round. |

**Highest-ROI rehearsal, round 1: A3 and A5.** Practise A3 until the bridge from the reliability quarter is smooth and the hardware gap is named first. Then practise A5 until you can say what you counted, what you cannot say, and which part was yours.

**Reverse questions (round 1)**

1. "What does a good first quarter look like here, and what would you need to decide by week six?" Why it lands: it converts the interview into a planning conversation.
2. "Where does the hardware roadmap get decided, and who has the final call?" Why it lands: it turns F3b into a question about how the work actually runs.
3. "What is the state of the two squads today, and what would the first 30 days need to fix?" Why it lands: it asks for the live context a role-level pack cannot supply.
4. "How much of the roadmap is set by the device launch calendar?" Why it lands: it tests whether you understand the hardware constraint.
5. "What would you most want the next engineering manager to get right?" Why it lands: it asks for the Director's own priorities, which only they can give.

No interviewer profile was supplied, so none of these ties to the Director's own career path. The upgrade menu explains what a name would add.

## Round 2: Panel (two staff engineers, one product manager), Thursday, 60 min

**Persona table**

| Member | Persona weights | Reasoning | Counter-strategy |
|---|---|---|---|
| Staff engineer 1 | Data-Driven Prober (top), then Pressure | Technical depth on a device-management service; probes the reliability claim | Say what you can and cannot say about the number. Name the weakest assumption. |
| Staff engineer 2 | Pressure (top), then Data-Driven Prober | Tests composure on the roadmap-pressure story and on the management gap | Hold a position through two follow-ups. Concede only what is true. |
| Product manager | Peer Evaluator (top), then Case / Strategist | Tests partnership on the roadmap and the seam between engineering and product | Propose seam principles, not a pretended answer. Give reciprocity. |

Weights are shown so you can recalibrate. Each member's personas come from their role on the panel, since no names were given.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through the reliability quarter. Which of its changes did you make, and which did you watch others make?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the changes in your own words. Separate the ones you decided from the ones others owned. Answer slot: if you did not make a given change, say so. | F2b is the evidence. The staff engineer will test exactly who did what. |
| B2 | "What would have to be true for that 60% to be an artifact of how you measured it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the measurement you would defend least and why. Say what would falsify it. If you do not know how it was counted, say so plainly. | The defend-the-number slot. Same figure as A5, a different probe. |
| B3 | "How do you know a device-management service is reliable enough? What do you measure at the device?" | CASE | [generic] | Clarify what reliable means for the fleet, then name the measures you would use and where they come from. Do not claim device-level measurement you have done. | F3b is the gap. The engineer is testing whether you know the domain's measures, not whether you have run them. |
| B4 | "You pushed a reliability quarter through against roadmap pressure. Who pushed back, and what did you concede?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold the position through two follow-ups. Then concede one specific point you actually gave up. Answer slot: if no one pushed back, say so plainly, and say what the pressure was. | F3a is the evidence. The hold-then-concede structure is the rehearsal. |
| B5 | "Sixty seconds: why should this team trust a manager who has never managed managers?" | Pressure | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Accept the plain acknowledgment: "I've never managed managers." Then give the plan, in your own words, and the first thing you would ask the team. Do not claim a past you do not have. | The sourced negative. Answer with the limit first, then the plan. |
| B6 | "Our squads sit beside the hardware team. Where's the seam with product, and what happens when we disagree?" | Peer | [grounded] "partner with hardware and product on roadmap" (role summary) | Propose seam principles: who decides what, and how disagreement is escalated. Do not pretend to know their seam. Use F3a's quote if you describe a past disagreement. | The Peer Evaluator's stem, taken from the role summary's own words. |
| B7 | "A feature the product team wants would add two weeks to a device-service release. What do you do?" | CASE | [generic] | Clarify the trade-off, the customer impact and the date. Then name the decision and who makes it. | A live roadmap problem. It makes no claim about your history. |
| B8 | "How do you handle credit when your squad's work spans teams?" | Peer | [generic] | Give the principle first, then one concrete practice. Do not claim a specific credit dispute you have not described. | A standard peer probe. |

**Highest-ROI rehearsal, round 2: B2 and B4.** The staff engineers will return to the reliability figure from two directions. Practise both.

**Reverse questions (round 2)**

1. To a staff engineer: "What is the most fragile part of the device-management stack today?" Why it lands: it shows you want to know the system's weak points before you touch them.
2. To the product manager: "Which roadmap decision in the last quarter did engineering push back on, and what happened?" Why it lands: it tests the partnership with a concrete case.
3. Reciprocity, because the panel includes peers: "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: it turns the question round to what you would bring.
4. To a staff engineer: "How do the staff engineers want to be involved in hiring?" Why it lands: it signals you will share the load.
5. To the product manager: "What does product need from engineering that it is not getting?" Why it lands: it invites a candid answer about the seam.

## Round 3: VP Engineering, Monday, 30 min (values and leadership philosophy)

**Values cheat sheet: not included.** The values section needs Larkfield's published values, and none were in hand. The recruiter's words name a values-style round, so the VAL questions below are themed on that. The upgrade menu asks for the values page.

**Persona table**

| Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Top | The recruiter named the round as values and leadership philosophy | STAR-shaped stories. "We" for context, "I" for your contribution. |
| Pressure | Second | A VP's time-boxed challenge on the management gap | Pause, restate, hold one position through two follow-ups. |
| Case / Strategist | Third | Skip-level altitude; expect a strategy question about the device business | Clarify, then name the metric. Use only what you can defend. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | If the reliability quarter is the story you would tell, say the pressure, the decision, and the figure you can defend. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | This is an open prompt. The reliability quarter is your nearest story, so it is the starting point. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one time where the customer outcome changed the decision. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | No quote carries a customer story. The honest branch is required. |
| C3 | "You've never managed managers. Why should we pick you now?" | Pressure | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Accept the plain acknowledgment: "I've never managed managers." Then give the plan, the first step, and what you would hand off first. | The sourced negative. The VP will test the limit, so answer it before the plan. |
| C4 | "How does Larkfield make money from the device fleet, and where does a device-management service fit?" | CO | [generic] | Name what you do not know about the business, then give the hypothesis you would test first. Do not claim knowledge of Larkfield's strategy: no research was available. | Strategy knowledge would have come from research, which did not run. This question is generic for that reason. |
| C5 | "What do you do when a senior engineer disagrees with you?" | VAL | [generic] | Give the principle, then one concrete practice. Do not claim a specific disagreement you have not described. | A standard leadership-philosophy probe. |
| C6 | "Your VP wants fewer incidents, product wants new features. How do you decide?" | CASE | [generic] | Clarify the customer impact and the date, then state the decision rule and who owns it. | A live trade-off. It makes no claim about your history. |
| C7 | "What would your squads say about you when you are not in the room?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Answer with one thing the team would say that you can point to. If you cannot point to it, say so. | An open prompt about how you lead. Keep it to what you can show. |

**Highest-ROI rehearsal, round 3: C1 and C3.** The VP's first question is likely to be one of these. Practise the plain acknowledgment in C3 until it is calm, then practise the C1 story until the decision is clear.

**Reverse questions (round 3)**

1. "Which of the values are lived here, and which are written?" Why it lands: it asks the VP to separate practice from statement.
2. "What would you want the new engineering manager to change in the first 90 days?" Why it lands: it asks for the VP's priorities in the role.
3. "How do you want the engineering managers to make the trade-off between reliability and roadmap?" Why it lands: it links the VP's philosophy to the work you did.
4. "What does good leadership philosophy look like here, in your own words?" Why it lands: it asks the VP to describe the philosophy the recruiter named.

## Sources

**Provided documents:** the role summary and your message. No CV, no full job description.

**Research:** L1, searches 3 of 6, fetches 0 of 2.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, round 3. Three search calls were refused by the host. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. The rounds come from your message, so persona weights do not depend on it. Three search calls were refused by the host. |
| 3. Larkfield Systems strategy or recent news | unavailable | CO questions, round 3 and round 1. Three search calls were refused by the host. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative role JD | skipped | The role summary you supplied fixes the requirement list. |

## Upgrade menu

- **Full job description text** → the requirement rows become `[grounded]` in full, and the posting will show whether it says "own" or "partner" for the hardware roadmap, which changes F3b.
- **Whether the two squads have their own leads** → decides whether managing managers is a requirement. If it is, F5 becomes a `capability` row and the A8 and C3 slots change.
- **Your CV** → lifts the medium rows in F1 and F2 to stronger evidence, and answers which roles the 40 interviews covered.
- **The offer count from the 40 interviews** → fills the answer slot in A6.
- **Larkfield's published values page, pasted** → a values cheat sheet for round 3, and VAL questions tied to named values.
- **Permission for the three company searches** → values, interview process and strategy, each checked against Larkfield specifically. The round 3 CO question and the values section depend on them.
- **Panel member names and roles** → per-member persona weights for round 2, instead of the blended weights above.
- **The Director's name and public profile** → an interviewer read, persona weights for round 1, and a reverse question tied to their career path.
- **Hours available before Tuesday** → a prioritised prep schedule, sized to the time you have.
