# Operations Manager, Atlas Freight: interview prep pack

Role: Operations Manager (regional logistics, 800 employees, 4 sites). Interviewer: not given. Round: not given, so every persona is weighted flat. Research: none run (L0), so no company values, interview process or strategy are included.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: **EXP** (your past work, attribution), **JD** (the listed requirements), **CASE** (a live problem), **VAL** (values or behaviour; none in this pack, since no values round is established), **CO** (company knowledge; none, since no research ran).
- Guidance is scaffolding for a spoken answer, not a script. Each guidance cell is written from the quoted lines in the fit snapshot. If a cell needs something you did not say, it is an answer slot, and you fill it in your own words or say it was not yours.

## Fit snapshot

Requirements are the JD lines you pasted. Evidence is quoted from your message. Nothing else is used about your experience.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows a shift run over 3 supervisors, not 4 sites. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have been accountable for daily operations beyond one shift, say where and how; if you have not, say so and say how you would take on four sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | discovery | The quote is about mis-pick accuracy. It does not show whether it reaches on-time performance or cost per shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, say what moved and how it was counted; if you did not track them, say so. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows 3 supervisors. The JD asks for 12. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have led more supervisors or a larger structure, say how; if not, say so and say how you would build a team of 12. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | discovery | A self-rating with nothing inspected behind it, so it is not asserted as a claim. Answer slot: name one report you built in Excel and what it tracked; if you have not built one, say so and say what you used. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | high | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, as a plan, not as past experience. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Seven years of operations work is not the same as seven years of leadership, and your material does not say how many years you led people. Answer slot: say how many years you have led people, in your own words; if it is fewer than five, say so and give the number. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Words: "I'm green belt certified." No certificate is in view, so expect a probe on what you applied it to. |
| F8 | [generic] Planning and running a peak-season surge; not a JD line | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | Relevant to the cost and throughput requirements, but the JD does not name peak planning, so it is not a requirement row. Words: "I ran the site's peak-season surge plan two years running." |

Read across the rows: the JD's largest asks (4 sites, 12 supervisors, 5+ years of leadership) sit above the scale in your quotes. Power BI is a stated absence. The pack does not claim any of these scales.

Gates: the JD states no location, schedule or credential gate, so no gate row appears.

## Personas (flat weights)

Round type and interviewer are unknown, so no relationship prior applies. Every persona is weighted the same and depth is set by the flat weights below. This is a weaker pack than one built for a known round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | "Walk me through how that number was counted." | High. The 40% is the one hard number in your material, so probers will go to it first. | Know what you can say about how it was counted; say plainly when you do not know; name the weakest assumption before they do. |
| Pressure / Stress | Interrupts; "sixty seconds"; "how much of that was actually you?" | High. The gap between 3 supervisors and 12 is the obvious place to press. | Pause, restate the question, hold the position through two follow-ups, then concede the specific uncertainty without folding. |
| Case / Strategist | A live problem from this role: day one across 4 sites, an on-time slip, a cost rise. | High. The JD reads as a scoring sheet for a hiring manager, and case problems test the four-site role directly. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and say your hypothesis early. |
| Skeptic | "Which part of this JD would you be weakest at on day one?" | High. Your gaps against the JD are the Skeptic's material. | Rehearse the single most predictable objection until it is plain. Name the gap in your own words and give a ramp plan. |
| Values / Behavioral | "Tell me about a time…" | Low to medium. No values round is established, so this is a flat prior. | Choose a real story, say which part was yours, and if none fits, say so and give the nearest thing you have. |
| Conversational / Rapport | "So, walk me through the journey." | Medium. Casual openers still score. | A 90-second arc drawn only from your quotes. Treat the Lean question as scored. |
| Peer Evaluator | "Where's the seam between our teams, and what happens when we disagree?" | Medium. Operations roles often work beside other functions. | Give seam principles, not invented detail; show a disagreement where you kept the relationship. |

## Question banks

Provenance sits before guidance. Every candidate sentence the guidance rests on is quoted in its row.

### A. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you counted the 40% mis-pick reduction." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Story-mapped on F2: the rate, the pick path redesign, and the 40%, the beats the quote states. Answer slot: say how the 40% was counted, in your own words; name the assumption behind it you would defend least; say which part of the redesign was yours. If you do not know how it was counted, say so. | F2 is the one hard number, and probers test attribution. Asked in your words, not as a method. |
| A2 | "Which operational numbers did you own and report, and which moved?" | JD | [grounded] JD: "drive on-time performance and cost-per-shipment down" | Open prompt. Answer slot: name the numbers you tracked, in your own words. If on-time performance or cost per shipment were not among them, say so plainly and say which metric you would put first and why. | F2 gives the gap; the JD line is the raising source. No claim about your past is made here. |
| A3 | "What is the weakest assumption in taking a pick-path fix from one site to four?" | CASE | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the weakest assumption in your own words before they do. If you have not tested the fix beyond the site where you made it, say so and say how you would test it. | Connects F2 to F1. The question is a live problem about transfer, so it presupposes no fact beyond the quote. |

### B. Pressure / Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why you, for a four-site role?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); JD: "Own daily terminal operations across 4 sites" | Pause. Restate the question. Anchor on what you stated: the shift and the 3 supervisors. Answer slot: name the part of the four-site role your quotes do cover, and say plainly the part they do not. | F1's transferability gap is the pressure point. The honest answer is the one that names the gap. |
| B2 | "This role leads 12 supervisors. You lead 3. Why do you think you can make that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); JD: "lead a team of 12 supervisors" | **Highest-ROI prep in this pack.** This is the most predictable objection, and it sits where your material is thinnest. Hold through two follow-ups on what the quote carries: the 3 supervisors you lead. Concede the step to 12 in your own words. Answer slot: say what you have done with supervisors, and if the 12-person structure is new to you, say so and say what you would do in the first 90 days. Never describe a team larger than 3 as yours. | F3 is the deepest rehearsal because the interviewer scores exactly this step. Five follow-up levels are the target. |
| B3 | "You're solid on Excel. Which report of yours would you defend under questioning?" | JD | [grounded] "solid Excel" (your message); JD: "build reporting in Excel/Power BI" | Pick a real report you built, and say what it tracked and who used it. If you did not build one, say so, and say what you used instead. Do not name a report you did not build. | F4 is low confidence, so the Excel answer rests on the report you can name. Power BI is covered in D2. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You start on day one across four terminals. What do you need to know first, and what do you do in week one?" | CASE | [generic] | Clarify: what each site's volume, shift pattern and on-time baseline look like. Then segment by site and by shift, state an approach, name the metrics, and name the risks. Think aloud. | A live problem from the JD's four-site line (F1). It needs no claim about your past. |
| C2 | "On-time performance at one site has slipped for three weeks. Diagnose it." | CASE | [generic] | Clarify whether the slip is across all shifts or one. Then state a hypothesis early, test it with the data you would ask for, and name the one check that would change your mind. | Tests the JD's on-time line (F2). Generic, because it is a pattern for the problem. |
| C3 | "Cost per shipment rose 8% over peak. What do you change in the first two weeks?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Structure first: cost drivers, then levers, then what you would measure. If you draw on peak work, use the quote at its own scope. Answer slot: say which parts of the surge plan were yours to set and which were set above you. | Ties the JD's cost line to F8, the one peak-season quote, without stretching it. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The JD asks for 5+ years of operations leadership. How many of your years were in a leadership role?" | JD | [grounded] JD: "5+ years operations leadership required"; "7 years in warehouse and distribution ops" (your message) | Give the years you led people, in your own words. Answer slot: if fewer than five, say so and give the number, and say what the seven years covered. Never count years of operations work as years of leadership. | F6 is the gap. The question asks for a number, and the honest answer is the one you can defend. |
| D2 | "How would you build the reporting this role needs, given that you haven't used Power BI?" | JD | [grounded] "never used Power BI" (your message); JD: "build reporting in Excel/Power BI" | Plain acknowledgment: "I haven't used Power BI." Then a plan, in those words: what you would learn first and how you would test it on real site data. | F5 is a stated absence, so the acknowledgment is yours to say. The plan is a plan, not a past. |
| D3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message); JD: "lead a team of 12 supervisors" | Name Power BI honestly as the first gap. Name the 12-supervisor step second. Give one ramp plan for each. Do not list a third gap you have not been asked about. | The Skeptic's favourite question. Two named gaps, each with a plan, beat a list of five. |

### E. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell leadership an unpopular truth." | EXP | [generic] (open prompt; theme from the Values persona stem) | Selection scaffold: pick a time you raised a problem with someone senior, where you named a stake, did not fold, and kept the relationship. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | No sentence of yours carries this story, so guidance is a scaffold, not a mapped answer. |
| E2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] (open prompt; theme from the Values persona stem) | Scaffold: pick a time a service promise and a site target pulled apart, and say which you chose and why. If none, say so and give the nearest case. | Same reasoning as E1. |

### F. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc using only the two quotes: seven years in warehouse and distribution, now a senior shift manager over 3 supervisors. Add the pick path redesign only in your own words. | Casual openers are scored. The arc is built from what you stated and nothing more. |
| F2 | "What are you playing with in Lean at the moment?" | JD | [grounded] "green belt certified" (your message); JD: "Lean/Six Sigma a plus" | State the Green Belt exactly, without stretching it. Answer slot: if the pick path redesign was run under your Green Belt, say so; if it was not, say what it was run under. | F7 is a plus requirement, asked casually but scored. |

### G. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | EXP | [generic] (persona stem) | Give seam principles, not invented detail. Show one disagreement where you kept the relationship. If none fits, say so and give the nearest one. | Peer scoring is about partnership. No quote carries a disagreement story, so this is a scaffold. |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | If the surge plan involved other teams, say which parts were yours and which were theirs, in your own words. If it did not, say so and describe how you would split credit. | F8 is the one quote that spans teams. Attribution is the scored thing. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | B1, C1, D3 |
| Drive on-time performance and cost-per-shipment down | A2, C2, C3 |
| Lead a team of 12 supervisors | B2, D3 |
| Build reporting in Excel/Power BI | B3, D2 |
| 5+ years operations leadership required | D1 |
| Lean/Six Sigma a plus | F2 |

Every JD requirement has at least one question. Session total: 18 questions.

## Reverse questions

Each one has a reason it lands. None are tied to the interviewer's path, since no interviewer profile exists.

1. "What does the first 90 days look like for someone taking over one of the four sites?" Why it lands: it turns the four-site step into a plan you can discuss.
2. "Which of the four sites has the most room to improve on on-time performance, and what is driving it?" Why it lands: it shows you read the JD's on-time line and want the real problem.
3. "How is reporting reviewed each week today, and who reads it?" Why it lands: it shows you care whether the Excel and Power BI work gets used.
4. "What would make you say six months from now that this hire was a good one?" Why it lands: it surfaces the scoring criteria in their own words.
5. "What is the hardest operational decision the leadership team has made in the last year?" Why it lands: it gets the interviewer talking about the job itself.

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot, since no dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs terminal operations across four sites | Inflated form of F1 | Your quote at its own scope: a senior shift manager over 3 supervisors. The pack's observation: your material does not show four sites. |
| Leads 12 supervisors | Inflated form of F3 | Your quote: 3 supervisors. The 12 is the step B2 asks about. |
| Owned on-time performance or cost per shipment | Inflated form of F2 | Your quote: the mis-pick reduction. Whether you tracked on-time or cost is an answer slot. |
| Five years of operations leadership | Inflated form of F6 | Your quote: 7 years in warehouse and distribution ops. Leadership years are an answer slot. |
| Has built Power BI reporting | Negative you stated, F5 | "I haven't used Power BI." |

## Sources

- Provided documents: the JD lines and the background summary in your message. No full JD text, CV or certificate was provided.
- Searches and fetches sent: none.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet, section 10 (not built). No search sent; research is pending your reply to the question below. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure; persona weights would follow named rounds. Weights are flat without it. |
| 3. `Atlas Freight strategy` / recent news | unavailable | CO bank. No CO questions were written, and the CASE questions are generic. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query. |
| 5. representative `Operations Manager` JD | skipped | The JD lines you supplied fix the fit snapshot and the JD-tagged questions. |

The name "Atlas Freight" may be shared with other companies, so any search results need checking against this company before use.

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights from their public footprint
- The round type (recruiter screen, hiring manager, or panel) → persona weights reshaped for that round
- Full JD text → the requirement rows you have not pasted, and any gates the posting states
- Your confirmation of research (about six searches and two page fetches) → Atlas Freight's published values, interview process and recent strategy, which would move the values section, CO questions and loop structure
- A tuesday-dossier.md from a later session → the gaps this prep exposed, carried into the next pack
