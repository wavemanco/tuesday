# Ashgrove Credit Union · Member Experience Lead · Interview prep pack

**Loop mode.** Three rounds on Thursday 26 November 2026: recruiter (30 min), Head of Member Services (45 min, mostly behavioural, your future manager), and a panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values). Interviewers for rounds 2 and 3 are not yet named.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural or values alignment · **EXP** your own experience, tested for attribution · **JD** the job's stated requirements · **CO** company and strategy knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- Two kinds of row are instructions, not questions. **Logistics slots** (pay, notice, location, reason for leaving) take your own figures. **Answer slots** name what a probe is likely to ask and give both honest branches: if it was yours, say how; if it was not, say so plainly.
- Square brackets appear only as provenance labels: `[grounded]`, `[inferred]`, `[generic]`.

## Prep triage (nine days, 17 to 25 November)

Done well, in this order:

1. **The panel case, R3-1.** It is the one graded case and the hardest 20 minutes. Practise it aloud three times against the clock.
2. **The plain acknowledgments, R1-6, R1-7, R2-3, R2-4, R3-2.** Say "I've never worked in a contact centre" and "I've never presented to anyone above regional level" without flinching. Then the hold-then-concede in R3-2.
3. **Your three stories, R2-1, R2-2, R3-3.** Each is built only from a sentence you wrote. Get each to 90 seconds with its honest branch.
4. **The strategy fluency, R1-8, R2-5, R2-6.** Know the three moves in the brief and what each means for complaints.
5. **The logistics figures, R1-2 to R1-5.** Decide your own answers before the call, not during it.

Everything else is insurance.

| Day | Work | Tied to |
|---|---|---|
| Tue 17 Nov | Read this pack once. Write your background in 90 seconds. Settle the four logistics figures. | R1-1 to R1-5 |
| Wed 18 Nov | Write R2-1, R2-2 and R3-3 on paper, then say each aloud. Name the honest branch for each. | Stories |
| Thu 19 Nov | Say the four plain acknowledgments ten times each. Write the 90-second ramp plan for contact-centre work. | R1-6, R2-3, R3-2 |
| Fri 20 Nov | Read the strategy brief twice. Say the three moves and their complaints implications in 60 seconds. | R1-8, R2-5, R2-6 |
| Sat 21 Nov | Write the first-24-hours plan for the escalation case. Time it to 20 minutes, aloud. | R3-1, R3-7 |
| Sun 22 Nov | Hold-then-concede against two follow-ups. Work out what your spreadsheet counted, in your words. | R3-2, R3-5, R3-8 |
| Mon 23 Nov | Full mock of rounds 1 and 2, with someone playing the interviewer if you can. | All round 1 and 2 rows |
| Tue 24 Nov | Full mock of round 3: panel, then the case. Then the reverse questions. | All round 3 rows |
| Wed 25 Nov | Light review only. No new material. Reread the answer slots. Sleep. | Pack |

## The fit snapshot

Shared across all three rounds. Each evidence cell holds only your own sentences, quoted exactly. Gap and bridge language follows the evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows one branch's formal complaints log. It does not show end-to-end ownership, and it does not show the contact centre. Say what you handled, in those terms. Answer slot: if you owned a complaint from first contact to closure, say which and how; if not, say so and stay with the log. |
| F2 | "report monthly on complaint volumes" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | none | This already reaches monthly reporting. Lead with it in these words. Expect a probe on what it counts. |
| F3 | "resolution times" — JD | none given | low | [inferred] | discovery | Your material does not mention resolution times. Answer slot: if the spreadsheet tracked how long complaints took to close, say what it measured; if it did not, say so and say what you would measure first. |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as branch supervisor." — your message | medium | [grounded] | transferability | Your material shows you trained tellers on the branch's script, and supervised for three years. It does not show coaching other supervisors. Answer slot: if you coached a supervisor on an escalation, say what and how; if not, say so and describe how you trained tellers. |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | — | discovery | Your material is silent on digital work. Answer slot: if you worked with anyone on a digital journey, say what; if you did not, say so and say what you would learn first. |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as branch supervisor." — your message | medium | [grounded] | none | Six years in retail banking reaches the length and the sector. Expect a probe on whether counter work counts as customer operations; answer it with what you did at the counter. |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | A formal complaints log is adjacent work. Your material does not say the complaints were regulated or what rules governed them. Use "formal complaints log" in your own words, and do not call it regulated unless you know it was. Answer slot: if the log followed a set procedure or external timescales, name them; if not, say so. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Your own stated gap. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan and never as a past. |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote reaches reporting, but your material does not name the tool. Say which tool it was, in your own words. |
| F10 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Your own stated gap. Words: "I've never worked in a contact centre." Then a ramp plan, said as a plan. |
| F11 | Office pattern and sites the role covers — not stated in the JD or the recruiter's email | none given; your material does not establish it | none | — | hard_gate | A gate the material does not settle. This row asks nothing of its own. The gate question in the upgrade section asks whether it is met. |

## Prohibited list

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran complaints end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not words for you: your material says one branch's log, not end-to-end and not the contact centre. Slot stays inside the log. |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote: you trained new tellers on the branch's script. |
| Experience in regulated complaints | Inflated form of F7 | "formal complaints log", at its own scope. |
| Reported resolution times every month | Inflated form of F3 | The spreadsheet quote, and the observation that your material does not mention resolution times. |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot. |
| Worked in a contact centre | Negative you stated, F10 | "I've never worked in a contact centre." No slot. |

## Grounding brief

Your material includes the July 2026 strategy brief, as you summarised it. Say these in your own words. Do not quote the brief back as research.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

## Values cheat sheet (round 3)

The loop source (the recruiter's email) says the panel scores against the four values, so this section lives with round 3.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a member-side decision. Scaffold: pick a complaint where you decided from the member's side. If none comes to mind, say so, then give the nearest thing: how you handled the log (F1). |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F4: "trained new tellers on our escalation script." Beats the sentence states: you trained tellers, on the branch's script. Answer slot: if you changed how the script explained things, say how; if not, say how you taught it. |
| Neighbours, Not Numbers | Every branch is part of its town. | F2: "I built the monthly complaints spreadsheet our regional manager uses." No town-level detail is quoted. Scaffold: a time a number pointed at a place or a group. If none, say the spreadsheet counted, and you would look at place first. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F1: "I handled the branch's formal complaints log." The sentence does not say solved. Answer slot: if you kept a complaint until it was solved, say how; if you handed it on, say to whom and what you checked afterwards. |

## Persona table

| Round | Dominant persona and weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 · Recruiter (30 min) | Conversational, six questions (R1-1 to R1-5, R1-8) | Friendly questions that are scored: logistics, motivation, what you know about the strategy | High. Recruiter priors: logistics and consistency, in a friendly register. | Treat the logistics as scored. Answer each with your own figure. |
| 1 · Recruiter | Skeptic, two questions (R1-6, R1-7) | The two stated gaps, asked directly | High. Both gaps are in your own sentences, so they will be found. | Say the plain acknowledgment first, then the nearest thing your material carries. |
| 2 · Head of Member Services (45 min) | Values/Behavioral, four questions (R2-1, R2-2, R2-7, R2-8) | Open prompts for stories | High. The recruiter says the round is mostly behavioural, which moves this persona to the top. | Story from a sentence you wrote. Say the honest branch if no story fits. |
| 2 · Head of Member Services | Case, two questions (R2-5, R2-6) | Live problems on digital and hub consolidation | Medium. Your future manager will test the strategy in their own terms. | Clarify first, then structure, then name the assumption. |
| 2 · Head of Member Services | Skeptic, two questions (R2-3, R2-4) | Contact centre and senior presenting | High. These are the stated gaps. | Plain acknowledgment, then a plan. |
| 3 · Panel of two branch managers (60 min) | Values/Behavioral, four questions (R3-3, R3-4, R3-6, R3-7) | Values-scored prompts, one per value and extras | High. The panel scores against the four values. | Map one story per value, or use the honest branch. |
| 3 · Panel | Case, one question (R3-1) | The 20-minute escalation case | High. The recruiter named it. | Think aloud. Structure before answering. |
| 3 · Panel | Pressure, two questions (R3-2, R3-8) | Composure and attribution | Medium. Two branch managers may test whether your complaint work was yours. | Hold through two follow-ups. Concede exactly what you do not know. |
| 3 · Panel | Data-driven prober, one question (R3-5) | What the spreadsheet counted | Medium. Excel is a JD requirement. | Say what it counted. Say what it did not. |

## Round 1 · Recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | Open in 90 seconds: the six years, the last three as a branch supervisor, then the complaints work in the order you did it. Use only the beats the sentences state. | Opens every later round. F6 is the evidence, and F1 and F4 follow. |
| R1-2 | "Why are you looking to move now?" | EXP | [generic] logistics slot | Give your own reason for leaving, in one sentence, in your own words. Your material gives none, so none is supplied here. | Motivation consistency is scored. The reason is yours alone. |
| R1-3 | "What are your pay expectations?" | JD | [generic] logistics slot | Give your own figure, or ask for the band first. Your material gives no figure, so none is supplied here. | A figure that is not yours cannot be defended in round 2. |
| R1-4 | "What's your notice period?" | JD | [generic] logistics slot | Give your actual notice period, in your own words. | Logistics are knockout checks in this register. |
| R1-5 | "Which branches or sites can you work from, and on what office pattern?" | JD | [generic] logistics slot | Say the branches or site and the days you can work. Your material gives none. This is the location slot that F11 leaves open. | The role spans branches and a contact centre. |
| R1-6 | "You haven't worked in a contact centre. What makes you think you can do this role?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I've never worked in a contact centre." Then the nearest thing your material carries: the complaints work you did, in the sentence's own terms. Do not claim contact-centre knowledge. | F10 is the stated gap. Round 3 returns to it (R3-2). |
| R1-7 | "Have you presented to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Answer slot: if you took the spreadsheet through a discussion with your regional manager, say what that was; if not, say so and say how you would prepare. | F8 is the stated gap. A plain acknowledgment costs little here; a bluff costs the round. |
| R1-8 | "What do you know about where we're heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028" and "consolidate eight branches into five hubs over 2027" — strategy brief summary, July 2026 | Name the three moves in your own words: digital by 2028, hubs over 2027, small-business lending in Q1 2027. Then one sentence on what the hub move would mean for complaints. Do not quote the brief as research. | Scored although casual. The grounding brief feeds it. |

## Round 2 · Head of Member Services (45 min, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-1 | "Tell me about a complaint you took through the formal log from start to finish." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | Pick one complaint you logged and handled. The sentence states the formal log and your handling; use only those. Answer slot: how it ended. If you saw it through to a decision, say what you did. If you passed it on, say to whom. Say "we" for the branch and "I" for your step. | F1 is the end-to-end requirement, and this question tests it directly. |
| R2-2 | "Tell me about a time you had to explain something to a member twice." | VAL | [grounded] "trained new tellers on our escalation script." — your message | Pick an explanation that did not land first time. The sentence states that you trained tellers on the branch's script; the script was the branch's, so do not say you wrote it. Answer slot: if you changed how the script explained things, say how and why; if not, say how you taught it and what you watched for. If none comes to mind, say so. | Plain Words is a published value. F4 is the nearest sentence. |
| R2-3 | "We run complaints across a contact centre too. How would you learn it in the first month?" | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I've never worked in a contact centre." Then a plan, said as a plan: observe the complaint flow, read real case records, spend time with team leads in the first two weeks. [generic] | F10 is the stated gap. A ramp plan is allowed; a claim of past knowledge is not. |
| R2-4 | "How would you present complaint trends to the senior leadership team?" | JD | [grounded] "I've never presented to anyone above regional level." — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Then the structure you would use: volumes first, then the cases that moved, then the ask. [generic] | F8 is the stated gap. The structure is a generic plan. |
| R2-5 | "Forty percent of member service moves to digital by 2028. Which complaints would you look at first to decide which self-service journey to fix?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief summary | Clarify first: what counts as digital, what the complaint categories are. Then rank by volume and by how often a case reopens. Name the assumption you would test first. [generic] | A live problem, not a question about your history. F5 is silent, so no claim is made about it. |
| R2-6 | "Eight branches become five hubs during 2027. A branch closes with open complaints. What happens to them?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief summary | Clarify: which cases move, who owns them, whether the member is told. Then list open cases by age, name one owner for each, and tell each member before the move. [generic] | The branch is part of its town. The question tests whether you see the member, not only the count. |
| R2-7 | "A supervisor escalates every complaint to head office. What do you do?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor." — your message | Start with what the supervisor is deciding and what the member needs. Answer slot: if you coached another supervisor on escalations, say how; if not, say so and describe the coaching you would do, such as reviewing two escalations together. [generic] | F4 is transferability. Coaching other supervisors is not in your material. |
| R2-8 | "Tell me about a time you disagreed with your manager about a complaint decision." | VAL | [generic] no quoted sentence carries a disagreement | Selection scaffold: pick a time you disagreed and kept hold of the problem afterwards. It needs a real stake, the moment you disagreed, and what you did next. If none comes to mind, say so plainly, then give the nearest thing: how you handled the log (F1). | Behavioural round. No sentence of yours carries this story, so it is a scaffold. |

## Round 3 · Panel of two branch managers (60 min, including a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-1 | "A member has been moved between two of your branches over a disputed charge for six weeks. Now they say they will take it to the regulator. What do you do first?" | CASE | [generic] | Think aloud. Clarify: who owns the case now, what the member has been told, what the records show. Contain: one named owner, one call back with a time, a record of each step. Escalate: check your procedure for the regulator route before you commit. Timing: about 3 minutes to clarify, 10 to plan, 7 for the member conversation. Cite no specific rule. [generic] | The case the recruiter named. No sentence of yours speaks to it. |
| R3-2 | "You've never worked in a contact centre. Why should this panel believe you can run one?" | JD | [grounded] "Never worked in a contact centre" — your message; "6 years in retail banking, the last 3 as branch supervisor." — your message | Hold with the plain acknowledgment: "I've never worked in a contact centre." Then hold the position from your sentence: six years in retail banking, the last three as a supervisor, and the complaints work you did. Hold through two follow-ups. Concede exactly what you do not know: "I can't yet say how a contact centre's queue runs; I'd learn that first." Do not fold on the complaints work. | F10 is the stated gap. Pressure tests composure: hold the position you can back, and concede only what you cannot. |
| R3-3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log." — your message | Pick a complaint you kept hold of. The sentence states that you handled the log; the solving is an answer slot. Answer slot: if it was solved, say how and what you did; if you handed it off, say to whom and what you checked afterwards. If none comes to mind, say so, then give the nearest thing. | Own the Fix is a published value. F1 is its evidence. |
| R3-4 | "When did a number you were tracking point you at one branch's town?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." — your message | Scaffold: a time a figure pointed at a place or a group of customers. Say what the figure was and what you did. If none, say the spreadsheet counted, and you would look at place first. Do not say the spreadsheet changed decisions. | Neighbours, Not Numbers is a published value. No sentence of yours carries a place-level story. |
| R3-5 | "Walk me through what your monthly complaints spreadsheet counted, and how." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." — your message | Say what it counted: volumes, by category, by branch if it did. If it did not count resolution time, say so. You have given no figure, so no defend-the-number slot is raised. If you recall one figure, say how it was counted and which part was yours. | F2, F3 and F9 meet the JD's reporting and Excel requirements. The honest answer is the precise one. |
| R3-6 | "Tell me about a time a member's view changed a decision you had made." | VAL | [generic] no quoted sentence carries it | Scaffold: a decision you changed after a member told you something. It needs the decision, the member's point, and what changed. If none comes to mind, say so, then give the nearest thing: a complaint you handled from the member's side. | Members First is a published value. No sentence of yours carries this, so it is a scaffold. |
| R3-7 | "Show us how you'd explain a refused claim to a member who has already had it explained twice." | VAL | [generic] | Lead with the outcome in the first sentence, the reason in one, then what happens next and by when. Write it aloud, then read it back as the member would. [generic] | Plain Words is a published value. The question tests the rewrite, not your history. |
| R3-8 | "Of that log, how much of the handling was actually yours?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Say what you did in the log, in your own words. Where others did steps, say so. The claim stands at its own scope: you handled the log. Do not claim a team's work as yours, or yours as the team's. | An attribution probe. The quote is the whole claim, so the honest answer is the whole answer. |

## Reverse questions

Each one is for the interviewer. "Why it lands" says what it shows.

| Round | Question | Why it lands |
|---|---|---|
| 1 · Recruiter | "What does the round-two manager most want to see that today's conversation can't show?" | Shows you are preparing for the next round, and gives you what to prepare. |
| 2 · Head of Member Services | "What would you want fixed in the complaints process in the first 90 days?" | Shows you read the hub plan, and invites a real answer. |
| 2 · Head of Member Services | "Which of the five hubs would this role's complaints work sit with first?" | Anchors the conversation in the strategy brief, which you have read. |
| 3 · Panel | "Which of the four values do you see most in a complaint you would be proud of?" | Shows how the panel scores, and invites them to describe it. |
| 3 · Panel (reciprocity, peers) | "What would make a branch manager's first month with this team genuinely useful?" | Turns the panel into peers. It asks what you can bring to their branches, not only what you need. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre | R2-1, R2-3, R3-1, R3-3 |
| Report monthly on complaint volumes and resolution times | R3-5, R2-4 |
| Coach branch supervisors on escalations | R2-7 |
| Work with digital teams on self-service journeys | R2-5 |
| 4+ years in financial-services customer operations | R1-1 |
| Experience handling regulated complaints | R2-1, R3-1 |
| Confident presenting to senior leaders | R1-7, R2-4 |
| Comfortable with Excel reporting | R3-5 |
| Contact-centre operations (scope of the role) | R1-6, R2-3, R3-2 |

Question total: 24 (eight per round).

## Sources

**Provided documents**
- The job description, as pasted.
- Ashgrove's values, as you copied them from ashgrovecu.org/about/values on 17 November 2026.
- The recruiter's email on the three rounds and the panel's values scoring.
- The July 2026 strategy brief, as your summary of it. The pack quotes your summary, not the brief's own text.
- Your background, from your message.

**Research tier: L0 — no searches**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values, copied this morning, fix the value names and their meanings. Feeds the values cheat sheet. |
| 2. Ashgrove interview process, Member Experience | skipped | The recruiter's email names the three rounds, their length and who runs each, and the panel's values scoring. It is a loop source and establishes the loop. |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, under six months old, fixes the current priorities. Feeds R1-8, R2-5, R2-6. |
| 4. Interviewer footprint | n/a | No interviewer names were given, so there is no query to form. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The names of the round 2 and round 3 interviewers → persona weights for each person, an interviewer read, and a reverse question tied to their own path.
- The recruiter's note on the 20-minute case, if one exists → the case's exact shape, and a graded write-up section if it is sent ahead.
- The strategy brief's own text, not your summary → the grounding brief quotes exact wording.
- An anonymised view of the monthly spreadsheet: its column headings and one summary row, with no member details → F2 and F9 move from medium to high, and R3-5 gets a real artifact to rehearse.
- Your branch's complaints procedure, as you ran it → R2-1 and R3-1 can use your actual steps, not generic ones.
- A tuesday-dossier.md from a prior session → carries verified evidence and any gaps already found.
- A deeper research pass, optional: recent leadership changes and the hub timetable, up to 6 more searches and 2 more fetches, several minutes → the grounding brief's live-context section.
