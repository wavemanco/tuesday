# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. **Interviewer:** not named.
**Built from:** the underwriting dossier `tuesday-dossier.md` (version 1.1, generated 2026-08-14, decision `conditional_go`). The dossier is about three months old. Confirm with the recruiter that the posting is unchanged before Thursday.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **JD**: can you do the listed job, including its gaps
- **EXP**: does what you did survive attribution
- **CASE**: structure and reasoning on a live problem from the role
- **CO**: company knowledge (not covered, see Sources)

Guidance is scaffolding, not a script. Say the answer in your own words, and rehearse only what you actually did.

## Prep triage

Thursday is two days away. In order:

1. **A1** aloud, three times, with two follow-ups each. It is the objection the underwriter named.
2. **A2** and **A4**: your day-one gap and what you decided on the integrations you led.
3. **B1** and **B5**: the two live problems.
4. **A3** and **C2**: the two answers you cannot fill from your material. Decide what honest answer you will give.

Everything else is insurance.

## Fit snapshot

Requirement text is quoted from the dossier's `role_profile`, which stands in for the JD. Evidence is quoted from the dossier's `verified_candidate_evidence` (E1 to E3). Confidence and gap type are the dossier's where it grades a row. Rows R2 to R4 are not graded in the dossier, so their grading here is this pack's reading. Check it against the full evidence map.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Wrote the internal integration playbook" (dossier E2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | low | [inferred] | transferability | Your verified work is adjacent: integration leadership, a playbook and roadmap-input sessions. It does not reach the product management title. Say it plainly: "I haven't held a product management title. What I've done is lead integrations end to end and feed client evidence into product." Limit, as the pack's own observation: the sessions fed input to product; the material does not show you set what product built. |
| R1a | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] | capability | Stated absence, recorded in the dossier's acknowledge_gap field. Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan, never as a past. |
| R2 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | high | [grounded] | transferability | Your inspectable work is integrations on the vendor's APIs, end to end. The material does not show a platform product you shipped as its owner. Describe the integration work at its own scope and stop there. |
| R3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook" (dossier E2) | high | [grounded] | discovery | The playbook is a process document, not API documentation or schemas. Answer slot: if you reviewed docs or schemas before partners saw them, say which and what you checked; if not, say so and say what you would check first. |
| R4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | medium | [grounded] | transferability | Your evidence reaches customers and product. Your verified material does not show engineering or sales. Say so. E3 is medium confidence: name its limit before it is asked for. |
| R5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | No verified entry speaks to this requirement. Answer slot only, under A3. Do not describe Agile work you have not stated. |

## Prohibited claims

This pack will not coach any of the claims below, in any answer, slot, or reverse question. The first three come from the dossier's `prohibited_claims`. The last two are inflated forms built here from quoted sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | Plain acknowledgment: "I haven't held a product management title." |
| Having owned a product roadmap | dossier prohibited_claims and acknowledge_gap | Plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | dossier prohibited_claims | Plain acknowledgment: "I haven't set priorities for an engineering squad." |
| Shaped the product roadmap | Inflated form of E3, "Ran quarterly roadmap-input sessions feeding client evidence to product" | E3 at its own scope. Limit, as the pack's observation: the material says input sessions, not the roadmap's decisions. |
| Owned integration delivery as product owner | Inflated form of E1, "Led 30+ end-to-end client integrations" | E1 at its own scope. Limit, as the pack's observation: the verified entry says led integrations, not a product role over them. |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gap between the JD and your title history. Asks for day one, and for decision authority | High. A hiring manager is buying capability and derisking gaps. The dossier names the objection | Rehearse A1 until it is plain. Concede roadmap ownership specifically and early |
| Case / Strategist | Live problems on the role's own work: specs for two squads, partner discovery, adoption baseline | High. The JD's responsibilities are the case material | Clarify, then structure. Ask who decides roadmap calls before you answer |
| Data-Driven Prober | Asks how your numbers were counted: 30+, three years | Medium-low. You have one headline count and it is the one most likely to be probed | Count 30+ precisely, and say which of the integrations were yours to decide |

Weights: Skeptic and Case at depth 5, Prober at depth 3. The round is a single hiring-manager conversation, so there is no panel blend. No interviewer profile exists, so there is no interviewer read.

## Question banks

Coverage follows the requirement list. Session total: 13 questions plus 5 reverse questions.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Having held a product manager title or role"; [grounded] "Having owned a product roadmap" (both dossier prohibited_claims); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Highest-ROI prep in this pack. Hold: "I haven't held a product management title, and I haven't owned a product roadmap. What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, from scoping to go-live." Hold through two follow-ups by returning to the integrations at their own scope. Concede specifically: the roadmap and prioritization are what you would be learning, and say how you would learn them. | Named by the underwriter as the likely objection. It targets R1, and its negatives have sources, so it may be asked as written. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier acknowledge_gap) | Plain acknowledgment: "I haven't owned a product roadmap." Then a ramp plan, stated as a plan: what you would do in your first weeks to learn roadmap decisions with the squad leads. Never describe a past you do not have. | R1a is a stated capability gap. No bridge is coached here. |
| A3 | "Tell me about your Agile delivery experience." | JD | [inferred] JD line "Agile delivery experience" (dossier role_profile R5). No verified entry speaks to this requirement. | Clarify answer slot: if you ran planning or sprints with a squad, say how; if you worked alongside a squad's process without running it, say that; if you have not worked that way, say so, and say what you would want to confirm about how this team defines Agile delivery. | R5 is a discovery gap with a clarify strategy. No quote can carry it. |
| A4 | "On the integrations you led, what did you decide, and what was decided for you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Answer slot: name which of scoping, requirements, architecture, UAT and go-live you decided, in your own words. If any were set by others, say so plainly. Stay inside those five stages. | This is the decision-authority probe. The dossier leaves authority unverified, so attribution is the honest answer. |
| A5 | "Why this role, and why now?" | JD | [generic] role-family motivation question. No raising source names it. | Answer in terms of the partner-API work the JD describes and what you want to learn in the PM seat. Name roadmap ownership as the part you are growing into. Make no claim about your past here. | A standard hiring-manager question. The guidance is generic, so it stays generic. |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have 90 days to lift partner adoption of the API platform, and you would be writing specs for two engineering squads. What do you need to know first, and in what order?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Clarify, then objective, partners and segments, approach, metrics, risks. Think aloud. Ask who decides roadmap calls between the PM and the squad leads before you answer. Make no claim about your past. | The two squads are the JD's own line. The decision-authority question is unresolved in the dossier. |
| B2 | "Three integration partners want three different things from the platform. How would you decide what goes on the roadmap?" | CASE | [grounded] "Run discovery with integration partners" (dossier role_profile responsibilities); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Structure the trade-off: what each request blocks, how many partners each affects, and where requests cluster. Any clause about your integration work rests on E1's stages, at their own scope. Do not claim you set roadmap priorities. | The problem is the JD's, and E1 gives the nearest scoping evidence. |
| B3 | "How would you set the baseline for partner API adoption, and who would own it?" | CASE | [grounded] "Define and track adoption metrics" (dossier role_profile responsibilities) | Ask first how adoption is counted today. No current baseline is stated, so do not invent one. Then propose a definition and an owner, labelled as a proposal. | The dossier names the missing baseline as a risk to validate. |
| B4 | "Engineering, sales and customers want different things from one partner API. How do you keep them aligned?" | JD | [grounded] "Stakeholder management across engineering, sales, customers" (dossier role_profile R4); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | Story-mapped on E3: the sessions, the client evidence, the product team that received it. Answer slot: if you ran or influenced a step after that, say what it was and what part was yours; if not, say so and describe what you would put in place with engineering and sales. Name E3's limit yourself: the proof for these sessions is limited. | R4 is a transferability gap. E3 is medium confidence, so the limit is volunteered. |
| B5 | "Walk me through how you would run discovery with an integration partner, from the first call to a decision." | CASE | [grounded] "Run discovery with integration partners" (dossier role_profile responsibilities) | Structure: what to learn first (their integration, their blockers, their volume), who joins (engineering, sales), what gets written down. Your scoping work is the nearest evidence, at the scope in E1: "scoping, requirements." | The discovery responsibility is the JD's. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you tell whether a partner's integration is going well after go-live?" | JD | [grounded] "Define and track adoption metrics" (dossier role_profile responsibilities); [grounded] "go-live" from E1 | Name a leading indicator and a lagging one, and the assumption you would defend least. If you have a figure from your own integrations, say how it was counted. If you do not know how it was counted, say so. | Tests metric attribution on the adoption responsibility. |
| C2 | "Show me what a good API reference looks like. What do you check in a schema before a partner sees it?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier role_profile R3); [grounded] "Wrote the internal integration playbook" (dossier E2) | Answer slot: if you reviewed docs or schemas before partners saw them, say which and what you checked; if not, say so and say what you would check first. Do not describe the playbook as an API reference. | R3 is a discovery gap. The playbook is a process document. |
| C3 | "Name an API product you have shipped, end to end, and your part in it." | JD | [grounded] "Shipped API or platform products" (dossier role_profile R2); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Answer slot: if you shipped a product, name it and your part. If the work was client integrations on the vendor's APIs, say that is what it was, in E1's terms. If none of it was yours, say so. | The question presupposes a shipped product, so its second branch must allow that it never happened. |

### Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Resolves the decision-authority risk. Asked as diligence, it answers something you need before accepting. | [grounded] dossier questions_for_employer |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | Resolves the missing baseline. The answer tells you whether B3 is a definition problem or a data problem. | [grounded] dossier questions_for_employer |
| RQ3 | "Who signs off on the roadmap, and how quickly is a call made when the two squads disagree?" | A second angle on the same authority risk, aimed at process rather than titles. | [generic] |
| RQ4 | "Which partner integration problem has come up most in the last few months?" | Shows you read the discovery responsibility, and gets you real partner data to think with. | [grounded] "Run discovery with integration partners" (dossier role_profile) |
| RQ5 | "What would you need to see in the first six months to call this hire a good one?" | Shows you are thinking about outcomes at the altitude of the role. | [generic] |

No interviewer profile exists, so no reverse question ties to the interviewer's own path.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1: 3+ years product management experience | A1, A4, A5 |
| R1a: owning a roadmap and prioritization authority | A2, B1 |
| R2: shipped API or platform products | C3, B2 |
| R3: technical fluency, API docs, schemas | C2 |
| R4: stakeholder management | B4 |
| R5: Agile delivery experience | A3 |
| Define and track adoption metrics | B3, C1 |
| Run discovery with integration partners | B5, RQ4 |
| Write specs and drive delivery with two engineering squads | B1 |

Nothing in the list goes uncovered.

## Sources

- **Provided documents:** `tuesday-dossier.md`, version 1.1, generated 2026-08-14. Sections consumed: `role_profile`, `decision`, and `handoff_to_mock_interview`. Not present in the dossier: `evidence_map`, `risk_register`, `evidence_state`. The pack therefore grades R2 to R4 itself.
- **Searches sent:** "Quartzline partner API platform product manager" and "Quartzline strategy 2026 news". Both were refused by the permission step, so neither returned a result.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | No call sent. No loop source documents a values round, so no values cheat sheet is built. |
| 2. Quartzline interview process, product manager | unavailable | The query was refused. The single 45-minute hiring-manager session is established by your own words, so the pack does not depend on this search. |
| 3. Quartzline strategy / recent news | unavailable | The query was refused. Would have moved the case bank toward company strategy. No such question is in this pack. |
| 4. interviewer name Quartzline | n/a | No interviewer name was given. |
| 5. representative product manager JD | skipped | The dossier's `role_profile` fixes the requirements and JD-tagged questions. |

## Upgrade menu

- Interviewer's name → a tailored reverse question and persona weights from their public footprint.
- Permission for web search → Quartzline values, interview process and strategy: a company-strategy question bank, and a values cheat sheet if the round is values-style.
- Recruiter's note on the round's focus, and any exercise it includes → coverage of any pre-declared deliverable.
- The dossier's full `evidence_map` and `risk_register` → R2 to R4 graded from the underwriter's own map, not this pack's reading.
- Your CV → quotes beyond the three verified entries, so more of the banks can be story-mapped.
