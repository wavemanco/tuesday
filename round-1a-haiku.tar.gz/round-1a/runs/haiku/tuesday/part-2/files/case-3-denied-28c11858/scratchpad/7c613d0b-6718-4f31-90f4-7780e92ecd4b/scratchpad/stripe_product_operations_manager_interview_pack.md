# Stripe, Product Operations Manager: final-round prep pack

**Changelog:** first version. No job description, CV, or round details were provided, and web search was unavailable, so every requirement and question below is generic and labelled as such.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural or values alignment · **EXP** your own experience, probed · **JD** the role's listed requirements · **CO** company and strategy knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Each guidance cell is meant to be speakable in 90 to 120 seconds.

## Research status

Research was unavailable in this session: the search tool was not permitted, so nothing about Stripe's values, interview loop, or current strategy has been verified. Treat every company-specific claim as something to check before the interview. The Stripe-specific sections below are deliberately empty for this reason.

## Fit snapshot (worksheet variant)

No CV or JD is in the conversation, so no evidence cell can quote you. Every row is a generic requirement for the role family, not a Stripe requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or programmes across product, engineering and go-to-market teams (role family) | none given | none | [generic] | discovery | Strong evidence is a launch or process you ran across two or more teams, with its outcome named. Selection scaffold: pick one cross-team programme you helped run. If you cannot name one, say so plainly, then give the nearest thing you did do. |
| F2 | Running an operating cadence: planning, intake and prioritisation reviews (role family) | none given | none | [generic] | discovery | Strong evidence is a recurring review you ran or shaped, and the decisions it produced. Selection scaffold: pick a recurring review you took part in, say what it decided, and say plainly if you did not own it. |
| F3 | Defining and tracking metrics for a team or programme (role family) | none given | none | [generic] | discovery | Strong evidence is a metric you defined, what it measured, and how it was counted. Selection scaffold: pick a metric you tracked. If you cannot name one, say so plainly, then say what you would measure first. |
| F4 | Designing processes that hold up as an organisation grows (role family) | none given | none | [generic] | discovery | Strong evidence is a process you designed or changed, and what broke or held as the team grew. Selection scaffold: pick a process you changed. If none comes to mind, say so plainly, then describe how you would design one. |
| F5 | Communicating with senior leaders and managing stakeholders who disagree (role family) | none given | none | [generic] | discovery | Strong evidence is a decision you brought to leadership, and how you handled disagreement. Selection scaffold: pick a time you disagreed with someone senior. If none comes to mind, say so plainly, then give the nearest case. |
| F6 | Working knowledge of payments or fintech (Stripe-specific, role family) | none given | none | [generic] | discovery | Strong evidence is a specific observation about payments operations you can defend. This row is an upgrade item: without the JD, it is unverified. Say what you know, and say plainly where your knowledge stops. |

**Gate rows:** none identified. Without the JD, no requirement can be classed as a gate.

## Prohibited claims

No candidate sentences are quoted yet, so no inflated-form entries can be built. The standing rule applies to every answer: do not claim work, scale, metrics or outcomes you have not described to me in your own words. Your material does not yet show any of them. Claims to avoid until they are yours to describe: any cross-team launch you did not lead, any metric you did not define yourself, and any scale or outcome you cannot name a figure for.

## Persona weights

The round type is "final round", but the relationship to the interviewers is unknown, and no loop source establishes the format. Weights below are a blended, generic guess. Treat them as flat until the round is confirmed.

| Persona | Weight | Why it is weighted this way | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Top, 5 questions | Final rounds commonly include a live operating problem; this is the most likely format for a product ops role | Clarify, then structure, then metrics, then risks, and think aloud |
| Skeptic | Mid, 3 questions | Final rounds commonly check fit and gaps before an offer | Answer the predictable objection plainly, name a ramp plan, and do not bluff |
| Data-Driven Prober | Mid, 3 questions | Ops roles are measured, so a metric you mention may be questioned | Name the weakest assumption before the interviewer does |
| Peer Evaluator | Mid, 3 questions | Ops roles sit between teams, so a future peer may test the seams | Propose principles for seams, and show what you would bring to their team |
| Values / Behavioural | Low, 2 questions | No values-style round is detected, because Stripe's values were not verified | Use STAR for stories; do not invent a value mapping |
| Pressure / Stress | Low, 2 questions | Possible in a final round, but not established | Pause, restate the question, and hold a position through two follow-ups |
| Conversational / Rapport | Low, 2 questions | Casual openers are still scored | Use a 90-second arc, and treat casual questions as scored |

## Question banks

Every question below is `[generic]`. No question presupposes anything about your past, and every answer is either a selection scaffold or a plain instruction.

### A. Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch milestone is slipping two weeks. What do you do?" | CASE | [generic] | Clarify which milestone, which owner, and what the slip blocks. Then cover cause, impact, options, the decision owner and the communication. Name the one number you would check first. | F1 and F2: cross-team delivery under a deadline is the likeliest live problem. |
| A2 | "How would you know whether a new internal process is working?" | CASE | [generic] | Define the outcome, a leading and a lagging indicator, a baseline, a counter-metric, and what result would make you stop. | F3 and F4: measurement of a process change is a core product ops task. |
| A3 | "Two teams disagree on how to prioritise incoming requests. How do you resolve it?" | CASE | [generic] | Clarify the criteria both teams use. Propose a decision framework, then an escalation path if the framework fails. | F2 and F5: prioritisation conflict is a standard ops problem. |
| A4 | "The organisation doubles in headcount next year. What breaks first, and what would you build?" | CASE | [generic] | Name the process most likely to fail first, the signal you would watch, and one thing you would build before the growth arrives. | F4: scaling is a common final-round theme for ops roles. |

### B. Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap, in your own words. Then give a concrete ramp plan: what you would learn first, from whom, and by when. Do not claim a skill you have not described. | Highest-ROI prep: every final round checks fit and gaps. The objection cannot be sharpened until your CV is in. |
| B2 | "Why product ops, and why now?" | EXP | [generic] | Give a motivation in your own words that matches your actual history. Do not invent a turning point. If the honest answer is a gradual interest, say that. | Motivation consistency is scored in finals. |
| B3 | "Tell me about a process you designed that did not work." | EXP | [generic] | Open prompt. Pick a real process. If you have none, say so plainly, then describe the process you would design first and why. | F4: this tests honest self-assessment. |

### C. Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a metric you defined. How was it counted?" | EXP | [generic] | Open prompt. If you give a figure, expect follow-ups on how it was counted and what it is sensitive to. Answer in your own words. If you did not count it, say so. | F3: metrics are probed to their counting method. |
| C2 | "Pick a result you would cite. Which assumption behind it would you defend least?" | EXP | [generic] | Open prompt. Name the weakest assumption before the interviewer does. If you do not know how a figure was counted, say so plainly. | F3: this converts a gotcha into a credibility point. |
| C3 | "What would you not trust in a dashboard you inherited?" | CASE | [generic] | Name one data-quality risk you would check first, and how you would check it. | F3: a probe of metric hygiene in a generic setting. |

### D. Peer Evaluator (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam. Say how you would disagree with an equal, and what you would do after. | F1 and F5: a future peer tests partnership fit. |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the contributors by role, not by your own story. Describe one concrete habit you use. | F1: a common collegial probe. |
| D3 | "What would you need from my team to do this job well?" | JD | [generic] | Name two specific needs, and say what you would bring to their team in return. | Reciprocity: shows you are thinking about their load, not only yours. |

### E. Values / Behavioural (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Pick a real time, say what the truth was, what you did, and how it landed. If none comes to mind, say so plainly, then give the nearest case. | F5. Not a verified Stripe value. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Pick a real time. If none comes to mind, say so plainly, then describe how you would decide. | Not a verified Stripe value. |

### F. Pressure / Stress (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give your strongest honest answer in under 60 seconds. Hold it through two follow-ups. Concede specific uncertainty without folding on the core claim. | Tests composure. |
| F2 | "Which of your results is actually yours?" | EXP | [generic] | Open prompt. Separate what you did from what your team did, in your own words. | Tests attribution under pressure. |

### G. Conversational / Rapport (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [generic] | Use a 90-second arc: where you started, the turn that mattered, and what you are looking for now. Keep it in your own words. | Casual openers are scored. |
| G2 | "What have you been thinking about in payments or fintech operations lately?" | CO | [generic] | Name one observation you can defend, and say where your knowledge stops. | F6: tests genuine interest without a verified company brief. |

## Coverage

| Requirement (generic) | Question IDs | Note |
|---|---|---|
| F1 Cross-team coordination | A1, D1, E1 | |
| F2 Operating cadence | A1, A3, B1 | |
| F3 Metrics | A2, C1, C2, C3 | |
| F4 Process design at scale | A2, A4, B3 | |
| F5 Senior stakeholders | A3, E1, F1 | |
| F6 Payments / fintech knowledge | G2 | Unverified; no Stripe-specific question |

## Values / principles cheat sheet

Not included. No Stripe values were verified, and no values-style round is detected.

## Reverse questions

Each question below has a reason it lands.

1. "What does a strong first 90 days look like for this role?" It shows you are planning for the job, not just for the offer.
2. "Which operating problem is this role most likely to fix first?" It turns the interview into a conversation about the team's real work.
3. "What does product ops here decide not to take on?" It shows you understand that ops roles are defined by their limits.
4. "How will success for this role be measured in year one?" It signals you think in outcomes.
5. "What is a process here that people complain about but that has survived for a reason?" It tests your judgment and shows you respect existing work.
6. If the round includes a peer: "What could a new person do in their first month that would genuinely help your team?" It is a reciprocity question, which converts the conversation into a peer one.

## Sources

Provided documents: the role title and company name, and the phrase "final round", from the request. No JD, CV or recruiter guidance.

**Research tier:** L0. The search tool was not permitted, so no search could run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, section 10: not built. Queries sent: "Stripe company values operating principles", refused |
| 2. Stripe interview process, product ops | unavailable | Loop structure: round formats unknown, persona weights stay generic. Queries sent: "Stripe interview process Product Operations Manager final round", refused |
| 3. Stripe strategy / recent news | unavailable | CO questions are generic (G2 only). Queries sent: "Stripe strategy recent news 2026", refused |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative JD for the title | unavailable | Fit snapshot rows stay generic. No search was sent for this target |

## Upgrade menu

- The job description → replaces the six generic fit rows with quoted requirements, enables the gate check, and adds JD-tagged questions
- Your CV or résumé → quotes your sentences into the evidence column, and replaces selection scaffolds with story maps
- Who you will meet in the final round, and their roles → an interviewer read and reweighted personas
- The recruiter's notes on the final round's format → confirms the loop, and adds build sections for any deliverable
- Stripe's values page, pasted here → a values cheat sheet, with each value mapped to a story from your CV
- Permission for web search → verified values, loop structure and strategy, replacing the generic rows and questions
