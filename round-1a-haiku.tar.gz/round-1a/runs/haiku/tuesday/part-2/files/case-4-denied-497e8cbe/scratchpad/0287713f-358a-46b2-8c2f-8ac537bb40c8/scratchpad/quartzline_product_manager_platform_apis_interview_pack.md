# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: 45-minute conversation with the hiring manager (Thursday). Interviewer name: not given. Relationship: hiring manager.
Changelog: first pack, built from your underwriting dossier (dossier_version 1.1, generated 2026-08-14). No CV or company research was available in this run.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: JD = requirement or responsibility; EXP = your own past work; CASE = live problem; CO = company knowledge; VAL = values.
- Guidance is scaffolding, not a script. Speak it in your own words, and say only what you did.

## Sources and research status

- Dossier consumed: role_profile (requirements R1 to R5), handoff_to_mock_interview (verified evidence, weak areas with strategies, likely objection, risks, employer questions, prohibited claims).
- No CV provided. The dossier's verified_candidate_evidence stands in for it.
- The dossier is dated 2026-08-14, about three months old. Check the posting is still live and unchanged before Thursday.
- Research tier: L1, searches 3 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Calls refused by host permission. Values cheat sheet absent; no company values used |
| 2. Quartzline interview process, product manager | unavailable | Call refused. Loop structure unknown; persona weights use the relationship prior and the generic fallback |
| 3. Quartzline strategy and news | unavailable | Call refused. CO questions below are generic |
| 4. Interviewer name and Quartzline | n/a | No name given |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements |

Searches sent, all refused: "Quartzline company values"; "Quartzline interview process product manager platform APIs"; "Quartzline strategy news".

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Skeptic | Top, 5 questions | Hiring-manager prior: they buy capability and test gaps. The dossier names the PM-title objection |
| Case / Strategist | 4 questions | Hiring-manager prior: live problems on their roadmap |
| Data-Driven Prober | 3 questions | Your headline numbers and the roadmap-input evidence will be probed |
| Pressure | 3 questions | Dossier objection will be pushed past two follow-ups |
| Conversational | 3 questions | Casual openers are still scored |

No loop source established the loop, so the generic archetype's flat weighting applies. No values-style round is detected.

## Fit snapshot

Evidence column: your candidate sentences only, quoted from the dossier's verified_candidate_evidence and marked by origin. Requirement text is the dossier's role_profile requirement text, which stands as the supplied JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (R1, must have, JD via dossier) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier, verified_candidate_evidence | low | [inferred] | transferability | The adjacent work is integration leadership, not PM experience. Words: "I haven't held the PM title. What I have is the integration work." The limit stays named |
| F2 | "Shipped API or platform products" (R2, must have, JD via dossier) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier, verified_candidate_evidence | high | [grounded] | transferability | You delivered API integrations for clients. You did not ship a product. Say which, in those words. Expect a probe on what the product side did with it |
| F3 | "Technical fluency: API docs, schemas" (R3, important, JD via dossier) | "Wrote the internal integration playbook her team uses" — dossier, verified_candidate_evidence | low | [inferred] | discovery | The playbook is documentation of integrations. It does not show schema work. Answer slot: if you set schema or documentation standards in it, say which; if not, say so and say how you'd learn them |
| F4 | "Stakeholder management across engineering, sales, customers" (R4, important, JD via dossier) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier, verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier, verified_candidate_evidence | medium | [grounded] | none | Clients and product are covered. Engineering and sales are not shown. Lead with the sessions in the quote's terms. Medium: limited inspectable proof, expect a probe |
| F5 | "Agile delivery experience" (R5, preferred, JD via dossier) | none given | none | [grounded] | discovery | Your material does not show it. Answer slot in the bank below |
| F6 | Owning a roadmap and prioritization authority (R1 sub-claim, dossier unknowns) | none given; you have stated no such experience | none | [grounded] | capability | Plain acknowledgment: "I haven't owned a roadmap." Then how you would learn it, as a plan |

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | dossier prohibited_claims | "I haven't held the PM title." Then the integration work, quoted at its own scope |
| Owned a product roadmap | dossier prohibited_claims and acknowledge_gap | "I haven't owned a roadmap." No slot |
| Set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set priorities for an engineering squad." No slot |
| "Drove the roadmap" (stretched wording of the roadmap-input quote) | inflated form of "Ran quarterly roadmap-input sessions feeding client evidence to product" | The quote at its own scope. Your material says you ran the input sessions, not that you drove the roadmap |

## Question banks

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "Wrote the internal integration playbook her team uses" — dossier; the negatives rest on the dossier's prohibited_claims and acknowledge_gap fields | Highest-ROI rehearsal. Open with the limit in your words: "I haven't held the PM title, and I haven't owned a roadmap." Then the quoted integration work, then the playbook. Do not argue you are equivalent to a PM with three years. Say what you would need to learn first, and how you would find out where decision rights sit. Hold through two follow-ups by returning to the integrations. Concede the roadmap gap plainly if pushed | The dossier names this as the likely objection. F1 is transferability, so this is a bridge with its limit named |
| A2 | "Which roadmap decisions have you made alone?" | JD | [grounded] dossier acknowledge_gap field "Owning a roadmap and prioritization authority" | Plain acknowledgment: "I haven't owned a roadmap." Then how you'd learn to make those calls, as a plan. No slot here | F6 is capability with no credible evidence. A bridge would be inventing one live |
| A3 | "Describe your agile delivery experience inside a product org." | JD | [inferred] The R5 requirement text, "Agile delivery experience" (dossier role_profile). No candidate sentence speaks to it | Answer slot: if you worked in sprints with engineering teams, say what that was in your own words. If you did not, say so, and say what you would want to confirm about how this team defines agile | F5 is discovery. The guidance states no claim about your past |
| A4 | "You'd be driving delivery with two engineering squads you don't lead. How do you get them to commit to your priorities?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" — JD via dossier; [grounded] "I haven't set priorities for an engineering squad." — dossier prohibited_claims | Plain acknowledgment, then a plan: how you'd earn alignment, and what you would ask the squad leads first. No past claim about squad alignment | The squad-authority question is the unverified risk in the dossier. Stay with what you can say honestly |
| A5 | "What's your first 90 days in a role where the squad leads hold decisions you need?" | JD | [generic] | Structure a plan. Learn the decision rights, meet the partners, map the two squads' current priorities. Make no claim about past work | Probes the squad-authority risk. The plan is future-tense, so nothing is claimed |

### Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has flattened. What would you need to know before proposing a fix?" | CASE | [generic] | Clarify, then objective, then segmentation of partners, then approach, metrics, risks. Ask for the current adoption baseline first | Matches the dossier's unstated adoption baseline. Live problem, no past claim |
| B2 | "Sketch how you'd choose the next three partner integrations to prioritise." | CASE | [generic] | Clarify the criteria. Then score partners on value, effort and risk, and name the trade-off. Say which assumption you would test first | A roadmap-style problem from the role's ownership responsibility |
| B3 | "A partner's integration stalls at UAT. Walk us through your first three moves." | CASE | [generic] | Clarify what is blocked. Separate the technical blocker from the commercial one. Name who you would involve and in what order | Tests delivery and stakeholder handling without asking about your past |
| B4 | "Which metric would you put on the roadmap first, and what would you give up to move it?" | CASE | [generic] | Name one metric and its trade-off. Say what would make you change it | The dossier's metric risk. Structure over the right answer |

### Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier | Say what the count includes, in your own words. Name the assumption you would defend least. Answer slot: if you counted them, say how. If you did not keep a count, say so plainly and say what you can show | F1 and F2 rest on this figure. The figure must not be explained beyond what you can repeat |
| C2 | "Which part of the playbook would you defend least?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier | Name the section you would change first and why. Say who else used it, if you know | F3 is discovery. A weakest-assumption answer shows judgment about your own work |
| C3 | "What happened to the roadmap-input evidence once it reached product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier | Volunteer the limit first: "I ran the sessions. Product owned what happened next." Answer slot: if you know what product did with the evidence, say so. If you don't, say so plainly | The dossier rates this medium. Name the limit before it is extracted |

### Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Thirty integrations is a delivery record, not a product record. What did you decide that changed what shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier | Pause, then restate. Hold: "The integration work is what I can speak to directly, from scoping to go-live." Hold through two follow-ups. Concede specifically: "Whether my input changed what product shipped, I can't show. I'd want to find out here." Answer slot: if you made a product decision, say which; if there was none, say so | The question presupposes a decision. The second branch lets that premise be false. Hold is only what the quote carries |
| D2 | "We're hiring a PM to make calls you haven't made. Convince me you'd make them." | JD | [grounded] dossier acknowledge_gap field "Owning a roadmap and prioritization authority" | Do not argue the point. Concede the gap plainly: "I haven't made those calls." Then say how you'd build the judgment, and what you would check first | A pressure test on F6. Plain acknowledgment only, no bridge |
| D3 | "Why is a delivery role enough preparation for this one?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier | Hold the integration work. Concede the PM-specific gap. Name what you would need to learn in the first month | Tests your composure on the transferability gap |

### Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier | A 90-second arc: where you started, the integration work, the playbook, why this role. Stop at the limit and say it | Casual openers are scored. Keep it to what the quotes carry |
| E2 | "What are you playing with in partner APIs these days?" | JD | [generic] | Name the API work you actually did, and what you'd want to learn next | Casual question on a hot JD topic. Answer from your own work |
| E3 | "What's the most interesting partner integration you've run?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier | Pick one integration. Use the beats the quote states: scoping, requirements, architecture, UAT, go-live. Tell only what you did | An open prompt. Choose a real instance from the 30+, not an invented one |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| R1, 3+ years product management experience | A1, A2, D1, D2, D3 |
| R2, Shipped API or platform products | C1, E3 |
| R3, Technical fluency: API docs, schemas | C2 |
| R4, Stakeholder management across engineering, sales, customers | C3, A4 |
| R5, Agile delivery experience | A3 |
| Decision authority versus the squad leads (dossier risk) | A4, A5, reverse question 1 |
| Adoption metrics, no baseline (dossier risk) | B1, reverse question 2 |

## Reverse questions

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it tests the decision-authority risk the posting does not evidence.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the dossier found no stated baseline. The answer tells you whether the job starts from a number.
3. "What would a strong first 90 days look like for this role?" Why it lands: it turns the conversation to success criteria, which the hiring manager owns.
4. "Where do the two squads and the partner team most often disagree on priority?" Why it lands: it shows you are testing the seam before you join it.
5. "What has the last person in this role had to hand back, and why?" Why it lands: it surfaces the scope problem directly, without asking you to guess.

No interviewer profile was provided, so the interviewer-path question is omitted. The hiring manager is not a peer, so no reciprocity question is included.

## Upgrade menu

- Your CV, or the bullet text behind the three quoted integration lines → lets the quotes carry more of your story and makes F1 to F4 stronger
- Current JD text → the dossier is about three months old. Confirms the requirements still match; a changed JD moves the fit snapshot
- The interviewer's name → persona weights from their public footprint, and a tailored reverse question
- The recruiter's note on the 45 minutes → whether a case or exercise is planned
- Deep research (L2): up to 6 more searches and 2 more fetches, several minutes. Want it? A strategy brief would turn B1 to B4 and the CO questions from generic into Quartzline-specific
- Re-running the company research once the host permits search → Quartzline values, loop structure and strategy, all currently generic
