# Interview prep pack: Operations Manager, Atlas Freight

**Built for:** a hiring-manager round. You didn't say who you're meeting, so this assumes the role's likely reporting line. Relationship weights are priors, not read from anyone. Interviewer: not named.
**Basis:** the JD text and your background summary. No CV was provided, so every candidate quote below is from your message and is marked "your message."

## How to use

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words.

| Tag | Meaning |
|---|---|
| **JD** | Can you do the listed job, including its gaps |
| **EXP** | Do your past claims survive scrutiny, and what was actually yours |
| **CASE** | Structure and reasoning on a live problem from this role |

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message. No requirement here is a hard gate: the JD names no legal or credential bar, and "5+ years" is a length-of-experience requirement, which is graded like any other.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site's surge plan, not daily operations across four. Words: "I ran the site's peak-season surge plan two years running." Answer slot: if you have run operations across more than one site, say which and how you kept them running; if you have not, say so, and say how you would set up daily control across four. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors now, against twelve. Words: "I'm currently a senior shift manager over three supervisors." Answer slot: if you have led more than three supervisors or more than one layer, say how many and how it worked; if not, say so and say how you would structure twelve. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Seven years is in operations overall. Your material does not show how many of them were in charge of other people. Words: "I have seven years in warehouse and distribution operations." Answer slot: from what date have you been responsible for other people's work? If that is under five years, say so. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | none given | none | [grounded] | discovery | Your material gives no on-time or cost figure. Answer slot: if you have moved either figure, say which, by how much, and what you did; if you have not, say so and say what you would measure first. |
| F5 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | A quality figure, not an on-time or cost figure. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: how the 40% was counted, in your own words, and which part of the redesign was yours. |
| F6 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | presentation | The quote reaches the Excel half in other terms. Words: "I'm solid in Excel." Nothing more is in the material. |
| F7 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | You stated this one. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. Words: "I'm Green Belt certified." A certificate is inspectable and has not been inspected, so expect a probe. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure, and this pack will not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | "I ran the site's peak-season surge plan two years running." Your material shows one site; that is the pack's observation, not a claim about you. |
| Led twelve supervisors | Inflated form of F2 | "I'm currently a senior shift manager over three supervisors." |
| Five years of operations leadership | Inflated form of F3 | "I have seven years in warehouse and distribution operations," plus the start date you give in F3's slot. |
| Moved on-time performance or cost-per-shipment | Inflated form of F4 and F5 | The mis-pick figure at its own scope. |
| Built or used Power BI | Negative you stated, F7 | "I haven't used Power BI." |
| Six Sigma Black Belt, or led Lean projects | Inflated form of F8 | "I'm Green Belt certified." |

## Persona table

Weights: Case/Strategist 5, Skeptic 4, Data-Driven Prober 3, Pressure 3, Conversational 3. Total: 18 questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live problem on the four sites | High. Hiring managers buy capability and test it on their own roadmap. | Clarify, then objective, segments, approach, metrics, risks. Say the structure aloud. |
| Skeptic | "You lead three; this role leads twelve." | High. Three visible gaps: F2, F3 and F7. This is the likeliest objection. | Rehearse B1 until it is plain. Hold the true position, concede the exact gap. |
| Data-Driven Prober | Asks how the 40% was counted | Medium-high. A headline figure draws probes. F5. | Name the weakest assumption before they do. Say what you do not know. |
| Pressure | "Sixty seconds: why you?" | Medium. Hiring managers sometimes test composure. | Pause, restate, hold through two follow-ups, then concede precisely. |
| Conversational | "Walk me through the journey." | Medium. Casual questions are still scored. | A 90-second arc built only from your quotes. |

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A site has missed on-time by about eight points for six weeks. What do you need to know first, and what would you do in the first thirty days?" | CASE | [generic] | Clarify: which site, which shifts, what changed, how on-time is defined. Then segment by site, shift and lane, pick the first cut, and name the two metrics you would watch. Say the risk you would watch for. | A live problem from the JD's on-time requirement (F4). It makes no claim about your past. |
| A2 | "How would you set up daily control across four sites?" | JD | [generic] | Describe one daily rhythm: a shared scorecard, a short start-of-shift review, and a clear escalation path. Answer slot: if you have set up a daily review across more than one site, say how; otherwise say what you would put in place first. | F1 is the gap. The guidance gives a structure, not a history. |
| A3 | "Your supervisors are split across four sites, and two sites run well below target on cost-per-shipment. Which do you look at first?" | CASE | [generic] | Rank by size of gap and by how quickly it can move. Ask what the cost-per-shipment definition includes before you act on it. | A cost-per-shipment requirement (F4) as a decision, not a record. |
| A4 | "Walk me through how you'd build the first weekly report for this group, from raw data to the decision it drives." | JD | [grounded] "solid Excel" (your message) | Start from the decision, then the metrics, the data source, and the refresh. Say Excel for what you can do now. Describe Power BI as a plan, not a skill. | F6 and F7. The question asks for a sequence; the answer must not claim a past report. |
| A5 | "What would make the first six months in this role look like success?" | CASE | [generic] | Name two or three measurable outcomes tied to the JD's own terms: on-time, cost-per-shipment, and the supervisor team's stability. | A generic, role-level question. It presupposes nothing about you. |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You lead three supervisors today. This role leads twelve across four sites. Why should we believe you can run it?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; [grounded] "7 years in warehouse and distribution ops" (both your message) | **Highest-ROI prep in this pack.** Hold the true position in the quote's own terms: "I'm currently a senior shift manager over three supervisors." Then give what you would do to reach twelve, and name what you have not done. Hold through two follow-ups by returning to the three supervisors and the seven years. Concede exactly: "Twelve across four sites is more than I've run." Answer slot: if you have led more than three supervisors or more than one site, say so now and how it worked; if not, say that plainly and stay with your plan. | F2 and F3 are the most predictable objection. The deepest rehearsal goes here because the material is thinnest here. |
| B2 | "The requirement is five years of operations leadership. How many years have you been responsible for other people's work?" | JD | [grounded] "7 years in warehouse and distribution ops"; [grounded] "currently a senior shift manager over 3 supervisors" (both your message) | State the number as your own figure. Answer slot: give the date you first held responsibility for other people's work; if it is under five years, say so and say where the time went. Do not round it up. | F3 is a discovery gap. The answer decides the requirement, not the wording. |
| B3 | "The posting asks for Power BI. Have you built a dashboard in it?" | JD | [grounded] "never used Power BI" (your message) | Plain answer: "I haven't used Power BI." Then how you would learn it, as a plan. Do not describe any dashboard. | F7 is a stated gap. The honest answer is the acknowledgment. |
| B4 | "What part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message) | Name the weakest part first: the Power BI tooling, and the first weeks of daily control across four sites. Give the ramp plan. | Persona stem. Naming the gap first is the Skeptic's strongest answer. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the mis-pick rate fell 40%. What was the baseline, and over what period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number in your own words: how it was counted, what it is sensitive to, and the assumption you would defend least. Answer slot: if you know the baseline and the period, say them; if you do not, say so. | F5. A headline figure raises the defend-the-number slots. |
| C2 | "Which part of that 40% was yours, and which part was the site's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the part that was yours, in your own words. Answer slot: if the pick redesign was yours, say which part; if it was not, say so plainly and say what you did. | Attribution is the probe's real target. |
| C3 | "Which on-time or cost-per-shipment figures have you tracked yourself?" | JD | [generic] | Answer slot: if you have tracked either, name the figure and how it was counted; if you have not, say so and say what you would track first. | F4. No quote carries either figure. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who already runs a multi-site operation?" | JD | [generic] | Pause, then restate. Hold the position you can back: seven years in operations and the peak-season plan. Answer slot: if you have run multi-site work, say so; if not, concede the gap plainly and say why you still fit the role. | F1 and F3. The hold is what your material carries, not more. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede: hold the part that was yours, then concede the part that was the team's, specifically. Answer slot: if the redesign was not yours, say so plainly. | Pressure on attribution. |
| D3 | "A senior leader wants a weekly dashboard. Why should we trust you to build it?" | JD | [grounded] "solid Excel" (your message) | Hold on Excel: "I'm solid in Excel." Concede Power BI plainly: "I haven't used Power BI," then the plan to learn it. | F6 and F7 together. |

### E. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops"; [grounded] "ran the site's peak-season surge plan two years running"; [grounded] "currently a senior shift manager over 3 supervisors" (all your message) | A 90-second arc built only from those three quotes, in that order. Add nothing. | Casual openers are scored. The arc uses only what you said. |
| E2 | "What are you actually doing in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Answer in your own words. Do not claim more than "solid." | F6. |
| E3 | "How are you finding the Lean side — green belt and all?" | JD | [grounded] "green belt certified" (your message) | Name the certification. Answer slot: if you have run a project under it, say which; if not, say so. | F8. |

## Requirement coverage

| JD requirement | Question IDs | Fit rows |
|---|---|---|
| Own daily terminal operations across 4 sites | A2, B1, D1 | F1 |
| Drive on-time performance and cost-per-shipment down | A1, A3, C1, C3 | F4, F5 |
| Lead a team of 12 supervisors | B1, A2 | F2 |
| Build reporting in Excel/Power BI | A4, B3, D3, E2 | F6, F7 |
| 5+ years operations leadership required | B2, B1 | F3 |
| Lean/Six Sigma a plus | E3 | F8 |

## Reverse questions

1. "What does the first ninety days look like for the person in this role, and what would make them go well?" Why it lands: it shows you're thinking about the job, not the title.
2. "How are the four sites different day to day, and where does each one struggle most?" Why it lands: it shows you're thinking about multi-site operations.
3. "How is on-time performance measured here, and who reviews it each week?" Why it lands: it signals a data-led approach.
4. "What reporting does the operations leadership team use each week today?" Why it lands: it turns the Power BI gap into a conversation about what they need.
5. "What has made people in this role succeed, or struggle?" Why it lands: a candid answer tells you what they are really scoring.

## Sources

- Provided documents: the JD text and your background summary (your message).
- Searches: none run.
- **Research tier: L0 — no searches.** The default research run waits on the consent item in the message.

| Target | Status | What it would have moved |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet. Not built: no values-style round is established. |
| 2. `Atlas Freight interview process, operations manager` | unavailable | Loop structure and persona weights. Held on consent. |
| 3. `Atlas Freight strategy` / recent news | unavailable | A CASE question grounded in current strategy. Held on consent. |
| 4. Interviewer name and company | n/a | No name was given, so there is no query to form. |
| 5. Representative JD for this title | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Your round type and who you are meeting → reweights every persona bank.
- Your CV → promotes the message quotes in F1–F8 to CV quotes, and lets dates and scope be checked.
- Your Green Belt certificate → F8 moves from medium to high confidence, and the probe is answered in advance.
- The interviewer's name → personalized persona weights and a tailored reverse question, from public footprint only.
- Research consent (default run: up to six searches, two fetches) → values cheat sheet, loop structure, and a strategy-grounded CASE question.
- The recruiter's prep email → coverage of any pre-declared deliverable.
- The number of years you have held responsibility for other people's work → closes F3, and settles B2's answer.
