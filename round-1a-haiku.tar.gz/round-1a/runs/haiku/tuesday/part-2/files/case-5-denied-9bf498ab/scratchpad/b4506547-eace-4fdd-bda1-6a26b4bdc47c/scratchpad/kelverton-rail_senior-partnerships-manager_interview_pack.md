# Kelverton Rail, Senior Partnerships Manager: second-round panel pack

Round: panel, 60 minutes. First 15 minutes: a spoken point of view (no slides) on where you would take operator partnerships over 18 months, landing on what it means for the operators. Then Q&A; Ross pushes on commercials.
Interviewers: Deepa (VP Partnerships, future manager) and Ross (Commercial Director).
Research tier: L1, not run. Web search was refused by the host (permission not granted), so every company fact below is `[generic]` or comes from your own words. Nothing here is checked against Kelverton's values page, strategy or interview guidance.
Changelog: first build.

## How to use + type key

Personas = how a question is asked. Types = what is being scored.
VAL = values. EXP = your own experience. JD = the role. CO = company and strategy. CASE = live problem.
Guidance is scaffolding, not a script. Rehearse out loud, in your own words.

## Prep triage (about 4 hours)

1. POV, out loud, twice, timed to 15 minutes (about 75 min). Section 5.
2. Defend-the-number and quota honesty, Ross's questions B1 to B3 (about 60 min).
3. The two stated gaps: rail sales (A3) and direct quota (B2) (about 30 min).
4. Deepa's case and skeptic questions A1, A2, A4 (about 45 min).
5. Reverse questions, pick five (about 15 min).

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's own words, quoted, so they are `[grounded]`. No JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue." (your message) | medium | [grounded] | transferability | The channel you ran was ISV partners at a payments company, not train operators. Say the channel in your own terms: "I took the ISV channel from six partners to forty." Anything about operators is an answer slot: what you would do with a train operator that differs from an ISV partner. |
| F2 | "Ross will push on commercials." (recruiter email) | "never carried a direct quota, only influenced revenue." (your message) | none | [grounded] | capability | Your stated absence, given back in your words: "I haven't carried a direct quota." Then what you did carry: influenced revenue. No claim of quota work. |
| F3 | "what it means for the operators themselves" (recruiter email) | "I know the operator world from the other side" (your message) | low | [inferred] | transferability | Your sentence covers planning-side work in transport consulting, not operator commercial decisions. Say what you saw from the planning side. Answer slot: which operator decisions you saw up close, and which you only read about. |
| F4 | Rail-sector sales experience (inferred from the role's market, JD not supplied) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Your stated absence: "I haven't sold into rail." Then how you would learn the rail buying cycle, as a plan and never as a past. |

Gate rows: the material says nothing about location or working pattern. See question 3 under the upgrade menu.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operator partnerships | Inflated form of F1. Your sentence covers an ISV channel. | "I took the ISV channel from six partners to forty." Limit as the pack's observation: your material shows the channel, not operator work. |
| Owned quota or a sales target | Negative you stated, F2 | "I haven't carried a direct quota." |
| Sold into rail | Negative you stated, F4 | "I haven't sold into rail." |
| Knows how the £4M was counted | Silent in your material. Inflating it would invent a method. | Answer slot only (B1). |

## Graded deliverable: the 15-minute point of view

Build section for the POV. The recruiter asked for a short spoken POV, so this is graded. Each thesis carries a concession; pick one or two.

Consensus answer to avoid: "lead with the biggest operators and grow renewals." Every prepared candidate will say it. Lead with the divergence, or name the anti-pick.

Thesis options, all `[generic]` (role-family reasoning, not Kelverton or operator data):

- T1. Operators buy scheduling on outcomes they can measure (punctuality, timetable-change cost, disruption recovery). Partnerships should share the data that proves them. Concession: operators buy on cost and regulatory obligation first, and outcome data depends on access the operators may not give.
- T2. Partner with the planning and infrastructure side as well as the operator, so the software fits how timetables are actually changed. Concession: this widens the number of buyers and dilutes the channel focus.
- T3. Make operators co-designers of the next 18 months' roadmap through a small design-partner cohort. Concession: it slows the roadmap and risks building for the loudest operator.

Anti-pick: do not chase the largest operator first. Say why it is the wrong first move.

The thesis you choose has to survive the "what it means for the operators" test. Each one has to end in something an operator would notice, such as a timetable change that takes less time, or a disruption that recovers faster.

Check before the interview: the internal market report. The recruiter says it was shared, and you have read it. If its consensus differs from T1 to T3, say where you diverge and why. Reciting the report is scored as homework.

Also check: the current state of the rail reform programme and how operator contracts are changing. I have not verified this, so do not state it as fact unless you have checked it.

## Persona table

| Persona | Who | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Case/Strategist | Deepa | Live problem on the operator roadmap | High | Hiring-manager prior; she is buying capability | Clarify before structuring, then name the metric you would watch |
| Skeptic | Deepa | "Why would an operator take your call?" | High | The F4 and F1 gaps are the obvious objection | Hold, then concede the gap in plain words (A3) |
| Pressure / Stress | Ross | "What number would you commit to?" | High | Commercial Director, stated focus on commercials | Hold the position through two follow-ups; concede uncertainty specifically (B1, B3) |
| Data-Driven Prober | Ross | How the £4M was counted, which part was yours | High | Influenced revenue invites attribution questions | Say what you know, say plainly what you do not (B1) |

Panel: Deepa carries the skeptic and case weight; Ross carries the commercial pressure.

## Question banks

Deepa (highest weight, depth 4 to 5):

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you took the channel from six partners to forty." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue." (your message) | Tell the arc in your own words: the starting point, the stages, the outcome you can state. Answer slot: if you chose which partners to recruit or how to prioritise them, say so and say how you decided. If you did not, say that. | F1 is the strongest evidence and the likeliest opener |
| A2 | "What would you do with our operators in the first 90 days?" | CASE | [generic] | Clarify first: which operators, which products, what the 90 days must change. Then structure around the three theses. Name the metric you would watch. | The role's own first problem |
| A3 | "Why would an operator take a call from someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message) | "I haven't sold into rail." Then "I know the operator world from the other side", as the planning-side view you saw. Answer slot: which operator decisions you saw close up, and which you only read about. | F4 is the skeptic's objection; this is the one to rehearse hardest |
| A4 | "How would you know a partnership with an operator was working?" | CO | [generic] | Name one outcome an operator would notice (T1), then one way you would track it, without inventing a figure | Ties the POV to measurement |

Ross (commercial pressure, depth 3):

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your partners drove roughly £4M of influenced revenue. What would you defend to me?" | EXP | [grounded] "roughly £4M of influenced revenue." (your message) | Defend-the-number slots, all of them. How it was counted, in your own words: if you know, say it; if you do not, say "I don't know how it was counted." The weakest assumption behind it: name it before he does. Which part was yours: say so plainly. | F1's figure is the commercial probe; these are the four slots a figure raises |
| B2 | "Have you ever carried a quota?" | EXP | [grounded] "never carried a direct quota" (your message) | Hold: "I haven't carried a direct quota." Then the influence you did carry. Answer slot: how you would set and track a target for operators, as a plan. | F2 is the stated absence; the question is coming |
| B3 | "Give me a year-one revenue commitment for operator partnerships. Sixty seconds." | CASE | [generic] | Hold the structure: the pipeline you would need, the conversion assumption you would test, and the one number you would not commit to yet. Hold through two follow-ups; concede uncertainty specifically | Pressure question, no past claim |

Reverse questions (for the end, pick five; each has a reason it lands):

1. "What did the last operator partnership that fell short teach the team?" Lands because it asks for their own lesson, not a pitch.
2. "Which operator decisions do you expect to change most in the next 18 months?" Lands because it asks about their world, not yours.
3. "How does partnership revenue get credited between channel and direct sales?" Lands because it tests the commercial model with Ross in the room.
4. "What would a successful first six months look like to you, Deepa?" Lands because it sets the manager's bar in her own words.
5. "What is one thing a new Senior Partnerships Manager should not do in their first month?" Lands because it signals you respect the existing team's way of working.

## Coverage

| Requirement | Questions | Notes |
|---|---|---|
| Operator partnerships over 18 months | POV, A2, A4 | |
| What it means for operators | POV T1 to T3, A2 | |
| Commercials | B1, B2, B3 | |
| Rail-sector experience | A3 | Stated gap |
| Channel scale | A1 | |

## Sources

Provided documents: your message, the recruiter's email (quoted).
Not provided: the internal market report (you have read it; I do not have it), and no JD.
Research tier: L1, searches 5 of 6, fetches 0 of 2. Five searches were sent; the host refused all of them.
- Kelverton values: refused. Values cheat sheet not built.
- Interview process: refused. Round structure is from the recruiter's email only.
- Strategy and news: refused. CO questions are `[generic]`.
- Interviewer footprint (Deepa, Ross): refused. Interviewer read absent.
- Representative JD: not sent; the host refused searching. No JD was supplied.

## Upgrade menu

- The internal market report, or its three to five key findings → replaces the `[generic]` theses with a checked consensus and a divergence; upgrades T1 to T3 and B3
- The JD text → turns F1 to F4 into `[grounded]` rows and adds JD-tagged questions
- Where the role is based and how many days in the office → fills the gate row; without it the location question stays open
- Deepa's and Ross's public footprint → an interviewer read and sharper reverse questions
- Search access in the host → runs the L1 targets; values, strategy and interviewer footprint would move A2, A4, B3 and the reverse questions
