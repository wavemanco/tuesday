# Interview prep pack: Priya, Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Round:** single 60-minute session
**Interviewer:** Dan Kovac, Director of Sales Strategy
**Relationship:** peer. Both report to the same VP.
**Research:** none ran. Web search was refused in this session, so company facts come only from your research note (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values alignment · **EXP** work-experience deep-dive · **JD** role/JD-driven · **CO** company and strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Speakable in 90 to 120 seconds.
- **Answer slots** are instructions for the interview. They are not questions to you.
- Quotes in the Provenance and evidence columns are your brief's own sentences. Nothing else is treated as something Priya has said.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — coach's notes | medium | [grounded] | transferability | Adjacent, not GTM ownership. The material shows product strategy and ops, not go-to-market for a product line. Words at the quote's own scope: "I spent nine years in product strategy and ops at a large consumer-tech company." Expect a probe on scope. Answer slot: if any go-to-market decision for a product was yours to make, say which and how you decided; if none was, say so and stay with the product-strategy work. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | discovery | The quote shows a revenue model, not a whitespace analysis across the four motions. The material is silent on whether one exists. Answer slot: if you have sized unserved demand for any of land, adopt, expand or renew, say which and how; if you have not, say so and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — coach's notes | medium | [grounded] | none | The quote reaches the requirement in its own terms. The caveat: it names tools, not an analysis. Name the tools, and any analysis you ran yourself, in your own words. The probe is on what you ran, not on what you know. |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | transferability | Adjacent: partner-level economics used in negotiations, not a partner motion. Keep the quote's scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you designed any part of how partners were engaged or paid, say which and what partners did with it; if none of that was yours, say so and say what the model was used for. |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | none | The quote reaches the requirement in its own terms: targets agreed across orgs. Lead with the targets and the consensus in those words. Expect a probe on who agreed and how far the targets moved. |
| F6 | "AI experience a plus" — JD highlights | derived from "uses AI tools daily" — coach's notes | low | [inferred] | transferability | Daily use is what the quote carries: name the tools and what you use them for. Do not present use as building AI. Labelled inferred because the evidence is thin. |
| F7 | Headline metric: the ~$400M ARR uplift (no JD line; coach's notes) | "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | medium | [grounded] | none | The quote carries a figure and an attribution that is "credited with", not "drove". Attribution is the probe. Say what you proposed and how much of the uplift was yours, in your own words. The coach's notes are the only source for this figure. |
| F8 | Classic sales-ops or quota-setting (no JD line; likely interviewer probe) | "No classic sales-ops or quota-setting experience." — coach's notes | none | [grounded] | capability | The absence is stated. Words: "I haven't done classic sales-ops or quota-setting." Then how you would learn it, said as a plan and never as a past. Never claim sales-ops or quota work, and add nothing to make the gap feel smaller. |

**Notes on the snapshot**

- **Gate rows: none.** The highlights name no location, work-authorization, licence, credential or travel term. If the full JD has one, it becomes a hard-gate row.
- **Source check.** F1, F3, F5, F7 and F8 rest on the coach's notes. Priya should confirm each sentence is hers before she rehearses it. F8's negative in particular must be her own statement before she says it.

## Reading the interviewer

Public profile as you supplied it. No research ran.

- **Career pattern:** pricing and monetization roles, with one early-stage-startup chapter.
- **Self-described style:** "relentlessly data-driven."

**Practical implications**

1. Every figure will be taken apart to its assumptions. Weight the Prober bank up (A1 to A4).
2. Case questions tilt toward pricing, packaging and unit economics, which is his native language (C1, C3).
3. A startup chapter means builder stories land with him. Expect a scrappiness probe on big-company pace (F1, G1).
4. As a peer, he will test the seam between their work and hers, collegially (B1, B4).

**Mirror opportunities**

- **Shared professional path:** none supplied. There is no shared career jump to offer.
- **Shared vocabulary:** "revenue model." Priya's sentence "built a partner-level revenue model used in carrier negotiations" (F4) uses the same term his pricing work does.

## Persona table

Weights are the relationship prior for a peer (Peer Evaluator and Data-Driven Prober), adjusted by the self-described data-driven profile (Prober up). Total: 21 questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (weight 5) | Asks how each figure was counted and which assumption is weakest. Goes two levels deeper than the answer. | High. His profile says "relentlessly data-driven," and the $400M figure and the revenue model are the most testable things on the page. | Know what you can and cannot say about each figure. Name the weakest assumption before he does. Say plainly when you do not know. |
| Peer Evaluator (weight 4) | Probes the seam between teams, asks what he would need to provide, and tests credit-sharing and disagreement. | High. This is the peer-round prior. | Lead with what you bring his team. Propose seam principles rather than a map you have not seen. |
| Case/Strategist (weight 3) | Gives a live problem on land/adopt/expand/renew or a competitive bundle. | Medium. His pricing spine and the whitespace requirement both point here. | Clarify, then structure, then answer. Challenge one premise. |
| Skeptic (weight 3) | Presses the two gaps that touch the JD's required line: sales-ops/quota and partner-motion design. | Medium. Both gaps are real and sit on his home turf of sales strategy. | Rehearse the limit until it is plain. Pair it with a concrete plan. |
| Pressure (weight 2) | Time-boxed challenges, comparisons with an internal quota-runner. | Low. Nothing in the profile signals it; kept at two so the style is not met cold. | Pause. Hold the position through two follow-ups. Concede the specific gap, never the core claim. |
| Conversational (weight 2) | Casual openers such as "walk me through the journey," and the JD's plus item asked casually. | Low to medium. Casual questions about hot JD topics are still scored. | Keep the 90-second arc to your own sentences. Treat the casual AI question as scored. |
| Values/Behavioral (weight 2) | Behavioral stories, though no values round was detected. | Low. Kept at two because a peer can still ask for a story. | Use selection scaffolds where your material has no story. Say so rather than invent an ending. |

## Question banks

Ordered by persona weight. Provenance comes before the guidance. Every candidate sentence the guidance rests on is quoted in its row.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where does the ~$400M ARR uplift come from?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | Story-mapped on F7: the change you proposed, and the uplift it was credited with, in those words. Weakest-assumption move: name, in your own words, the assumption behind the figure you would defend least, before he does. Answer slot: how the figure was counted, what it is sensitive to, and which part was yours. If you know these, say them. If you do not know how it was counted, say so plainly. | F7 is the headline figure, and a data-driven peer tests it first. EXP because it tests attribution. The guidance never upgrades "credited with" to "drove." |
| A2 | "What did you decide about that store-surface change?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | You proposed it. Say what you proposed, and what you decided after proposing. Answer slot: if you decided anything after the proposal, say which. If the decision was not yours, say so plainly and say what you proposed. Never "I decided" or "I owned." | Tests whether the proposal was hers and what was adopted by others. Shares the F7 quote so the attribution stays at its own scope. |
| A3 | "Walk me through how the partner-level revenue model was built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes | Story-mapped on F4: built, then used in carrier negotiations. Those are the beats the sentence states. If you cannot walk through how it was built, say so plainly and describe what it was used for. | F4 is the revenue-model evidence. The Prober tests how a model was built. The question presupposes only "built," which the quote carries. |
| A4 | "Which assumption in that revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes | The weakest-assumption move in its purest form. Name it if you know it. If you do not know which assumption is weakest, say so and say which one you would test first. | A persona stem. Kept as its own question because the Prober tends to ask it directly after A3. |
| A5 | "Tell me about an analysis you ran yourself in SQL or Tableau where the answer changed a decision." | JD | [grounded] "skilled in SQL/Tableau" — coach's notes | Open prompt on the JD's "run independent analysis." Selection scaffold: pick an analysis you ran yourself. Say the question, the data, and what changed. If no analysis of yours changed a decision, say so plainly, then name the tools and one thing you use them for. | F3. The JD requirement needs a JD-tagged question. The honest branch is built in. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on the product launches. Where's the seam between your go-to-market work and mine?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" — coach's notes. Raising source: "own GTM strategy for two new product lines" — JD highlights | Reciprocity framing: start with what you bring his team, at the scope of the product-strategy work, before what you need. Propose seam principles, not a map you have not seen. Answer slot: if you have made a go-to-market decision for a product, say which and how. If you have not, say so and propose a principle for the handoff. | F1 is the candidate evidence. The question is the collegial version of the GTM objection. R1 gets its JD-tagged question here. |
| B2 | "Tell me about a time you disagreed with another team over a target. How did it end?" | JD | [grounded] "set annual volume targets with cross-org consensus" — coach's notes. Raising source: "strong cross-functional influence" — JD highlights | Open prompt. Story-mapped on F5, beat by beat: the targets, the orgs, the consensus. Selection scaffold ending in the honest branch: pick a disagreement you resolved in a target or planning cycle. Say what each side wanted, what you gave, and whether the agreed target held. If none comes to mind, say so plainly, then describe how the cross-org consensus on targets was reached. Use "we" for context and "I" for your contribution. | F5 is the influence evidence. A peer's credit-sharing probe lands here. |
| B3 | "What partner-facing work have you designed, and how did partners respond?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes. Raising source: "partner-motion design experience required" — JD highlights | This premise is not carried by the quote, so the guidance is an answer slot. Its second branch lets the premise be false. Answer slot: if you designed any part of how partners were engaged or paid, say which and how partners responded. If no partner motion was yours to design, say so plainly, and say what the partner-level model was used for in carrier negotiations. | F4 is the required gap. Partner motion is the JD's required line, and a peer whose team touches partners will probe it. Never describe a partner program. |
| B4 | "If our two teams disagreed about how a launch's target should split across land and expand, what would you want from me?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes. Raising source: "identify whitespace across land/adopt/expand/renew" — JD highlights | Propose seam principles rather than pretending to know the seam. The revenue model is the only evidence you can cite, at its own scope. Answer slot: if you have sized whitespace across any of land, adopt, expand or renew, say which and how. If you have not, say so and propose a principle for splitting the target. | F2 is the whitespace evidence. R2 gets its JD-tagged question here. |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Adoption is flat on one product line and expansion is up. Diagnose it. What do you need to know first?" | CASE | [generic] | Structure: clarify, objective, segmentation, approach, metrics, risks. Use the note's vocabulary, "enterprise expansion." Before proposing a fix, ask what the unit economics look like for each motion. Name one premise you would challenge. The case makes no claim about your past. | A live problem from the JD's land/adopt/expand/renew line, with the pricing and unit-economics tilt from his spine. |
| C2 | "Northwind's priorities are enterprise expansion, an AI copilot launch and reaching profitability. Which would you put a go-to-market plan behind first, and what do you give up?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | Take a position and name the trade-off. Use the three priorities in the note's words. No claim about your past. | The CO bank. Grounded in your note because no live research ran, so the note is the only current-strategy source. |
| C3 | "A much larger platform vendor is bundling a similar capability. How do you compete with a bundle?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your research note | Pricing and packaging angle, his native language. Say what you would not try to match on price, and what you would sell instead. Name one lever you would test. No claim about your past. | The competitive threat is from your note. The pricing lens reflects his career spine. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." — coach's notes. [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes | **Highest-ROI prep in this pack.** Bridge from the revenue model at its own scope. Name the limit plainly: "I haven't done classic sales-ops or quota-setting." Then a concrete 30-day plan, said as a plan. Hold through two follow-ups by returning to those same facts. Deepest rehearsal, by follow-up level: (1) the weakest area. (2) "How would you approach quota-setting for a team?" (3) "And partner motion?" Answer to (3) through B3's slot. | Two gaps touch the JD's required line and his home turf: F8 (sales-ops and quota) and F4 (partner motion). Skeptics go straight at them, and the objection will come in some form. |
| D2 | "How would you tell a volume target from a quota?" | JD | [grounded] "set annual volume targets with cross-org consensus" — coach's notes. Plain acknowledgment, F8: "No classic sales-ops or quota-setting experience." — coach's notes | Answer the distinction from the concept first, not from your history. Then, if asked about your own work: "I set annual volume targets with cross-org consensus." Stop there. Then the plain acknowledgment: "I haven't done classic sales-ops or quota-setting." | The distinction is Dan's domain, and the question presupposes no past practice. The sourced negative is the one F8 gives. |
| D3 | "What would make you credible running go-to-market for a product line within ninety days?" | JD | [generic] | Give a ramp plan, said as a plan. Answer slot: if you have led any go-to-market decision for a product, say which and how. If you have not, say so and give the first three moves. Make no claim about your past. | R1 is the JD's headline requirement. This is the Skeptic's standard probe, asked without presupposing a negative: the material is silent on GTM ownership, so no negative is stated. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has run quota?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" — coach's notes. [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes | Pause, then restate the question. Hold the work that is yours: product strategy and ops, and the partner-level revenue model used in carrier negotiations. Hold through two follow-ups. Concede specifically when pushed: "I haven't done classic sales-ops or quota-setting." Never fold on the core claim to restore harmony. | Pressure is weight 2. This uses the same sourced negative as D1 and D2, so the concession wording does not drift. |
| E2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | Hold: "I proposed the change, and the uplift was credited to it." Concede where it is true: if you cannot split the figure, say so and say what you would need to split it. Never "drove" or "owned." | The same figure as A1, time-boxed. This is attribution honesty under pressure. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" — coach's notes. [grounded] "9 at a large consumer-tech company in product strategy & ops" — coach's notes. [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes | A 90-second arc in three beats: consulting, then product strategy and ops, then the partner-level revenue model. Add no roles, dates or outcomes beyond those quotes. | Casual openers are scored. The arc keeps the biography to sentences she actually stated. |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] derived from "uses AI tools daily" — coach's notes. Raising source: "AI experience a plus" — JD highlights | Name the tools and one daily use. Answer slot: if you have built anything with them, say what. If not, say that you use them. Never present use as building. | F6. The casual question on the JD's plus item is scored, and the low confidence keeps its label inferred. |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "set annual volume targets with cross-org consensus" — coach's notes | Open prompt. Selection scaffold: pick a time you told someone senior something they did not want to hear. Say what the truth was, what it cost, and whether the relationship held. If no such time comes to mind, say so plainly, then describe how the targets were agreed across orgs. | No published company values are in hand, so this names no value. The peer may still ask for a behavioral story. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where a customer's need cut against a number you owned. Say what you gave up and what the customer got. If none comes to mind, say so plainly and name the nearest trade-off in your own work. | A persona stem. The cell names no company value, and the values cheat sheet is absent because no values round was detected. |

**Requirement coverage**

| Stated requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | B1, D3, C1 |
| identify whitespace across land/adopt/expand/renew | B4, C1 |
| run independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | B3, D1 |
| strong cross-functional influence | B2 |
| AI experience a plus | F2 |

Headline metric (~$400M): A1, A2, E2. Revenue model: A3, A4, B4, E1, F1. Sales-ops/quota negative: D1, D2, E1. Company priorities and bundling threat: C2, C3. Values: none, and why: no values round was detected, so no value is mapped. G1 and G2 cover behavioral stories.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent time in an early-stage startup before your pricing and monetization work. What from that chapter still shapes how you think about price?" | Tied to his own path. It turns a probe into a peer conversation and shows you read his profile, not just the company's. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. A peer weights this heavily as a preparation signal. |
| R3 | "How are enterprise expansion targets set across sales and product this year?" | Ties to the note's first priority and opens the seam. |
| R4 | "Where does the bundling threat show up first in the deals your team sees?" | Tests the competitive picture from his data, at a peer's altitude. |
| R5 | "When the AI copilot and the core product compete for the same account, who decides the trade-off?" | Exposes decision rights, which a peer can answer and a candidate cannot guess. |

## Prohibited claims

Not coached, with each entry's basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I drove the ~$400M ARR uplift" or "I owned the store-surface change" | Inflated form of F7 ("credited with") | F7's quote at its own scope. The limit is the pack's own observation: the material says the uplift was credited to the change, not who else contributed. A1 and E2 stay inside that scope. |
| "I designed the partner motion" or "I set up the partner program" | Inflated form of F4 (a revenue model used in negotiations) | F4's quote at its own scope. The material says a model, not a partner motion. B3's slot asks only what was yours. |
| "I ran go-to-market for product lines" | Inflated form of F1 (product strategy and ops) | F1's quote at its own scope. D3 and B1 hold to it. |
| "I set the targets on my own" | Inflated form of F5 (targets with cross-org consensus) | F5's quote. The consensus stays in the sentence. |
| "I built AI products" or "I've worked on AI" | Inflated form of F6 (uses AI tools daily) | The quote at its own scope: daily use. |
| "I've sized whitespace across all four motions" | Inflated form of F2 (a revenue model) | F2's quote. B4 and the F2 slot ask only which motion, if any, was sized. |
| "I haven't done quota or sales-ops work, so I'm weak there" (said as a verdict, not a plan) | Sourced entry: F8's negative | The plain acknowledgment: "I haven't done classic sales-ops or quota-setting." Followed by the plan, never a verdict on her ability. |

## Sources

**Provided documents**

- Your brief: JD highlights, candidate background as coach's notes, the research note on the three priorities and the bundling threat, and the interviewer profile line ("relentlessly data-driven," plus the career spine).

**Searches sent**

1. "Northwind Data company values principles": refused. Web search permission was not granted in this session.
2. "Northwind Data Compass AI copilot launch": refused. Same cause.
3. "Dan Kovac Director of Sales Strategy Northwind Data": refused. Same cause.

**Fetches sent:** none (0 of 2).

**Research tier:** L1 requested. Searches 0 of 6 (3 refused), fetches 0 of 2.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Would have moved the values cheat sheet, but only if a values round were detected. None was, so it would have moved nothing here. Search 1 refused. |
| 2. `Northwind Data interview process` | unavailable | Would have confirmed the loop structure. The round is a single peer session from your brief, so the peer prior stands. Not run; no query was sent for this target. |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three priorities and the bundling threat. The CO bank is fixed by the note. |
| 4. `Dan Kovac Northwind Data` | unavailable | Would have moved the interviewer read beyond your profile line, and the specificity of R1. Search 3 refused. |
| 5. Representative `Director of Sales Strategy` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Full JD text → the six requirement rows become quoted lines, not highlights, and any gate term in the full text becomes a hard-gate row.
- Web search permission → the three refused searches can run (L1). Dan's public footprint would sharpen the interviewer read and check R1 against his published talks or writing. The company values check would matter only if a values round is announced.
- A sentence from Priya on any sales-ops, quota or partner-program work → upgrades D1, D2, B3 and F8 from slot or negative to a story-mapped answer. Her own sentence is the only thing that can do this.
- Confirmation that the coach's-notes sentences are Priya's own → makes F1, F3, F5 and F7 rest on her statements rather than on the note.
- The round's stated focus, from the recruiter, if any → reweights the personas, especially whether the round leans toward sales strategy or product.
- A `tuesday-dossier.md`, if one exists from an earlier session → would add verified evidence and a prohibited-claims guardrail to the banks.
