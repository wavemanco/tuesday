# Priya: interview prep pack, Senior GTM Strategy Lead, Emerging Products

**Company:** Northwind Data (B2B data-infrastructure SaaS, about 3,000 employees)
**Conversation:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy. **Peer**, reporting to the same VP.
**Built on:** your message only (candidate summary, JD highlights, interviewer note, research note). No web research ran this time (both searches were refused), so company values, loop structure and recent news come from your research note alone.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it is scoring.
- Type key: **VAL** behavioral / values · **EXP** work-experience deep-dive · **JD** role requirement · **CO** company and strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Each cell should be speakable in about 90 to 120 seconds.
- Lines marked **Answer slot** are instructions for the interview. They ask nothing of you here.
- Every claim about Priya's past rests on a quoted sentence from your message, or it is an answer slot. Nothing is supplied for her.
- Left out on purpose: prep triage (no prep time given), values cheat sheet (no values-style round detected, and no values were retrieved), graded deliverables (none declared), delivery coaching (no assessment provided).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | low | [grounded] | transferability | Your material shows product strategy and operations, not go-to-market ownership. Bridge: "Product strategy and operations at a large consumer-tech company." Answer slot: name any go-to-market decision you made yourself; if there is none, say so and name the nearest decision you did make. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The model is revenue work, not a whitespace analysis across the lifecycle. Bridge: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if the model surfaced a segment or lifecycle stage nobody was covering, say which; if it was built for negotiation only, say so. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a request for a worked example; lead with one analysis you ran yourself. Limit: "skilled" is a self-assessment with no artifact in the material. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The quote is partner economics, not partner-motion design (terms, incentives, enablement). Bridge: the model, at its own scope. Answer slot: if you designed partner terms, incentives or enablement, say which; if not, say so and say what the model covered. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches the requirement. Bridge: "I set annual volume targets with cross-org consensus." Expect a probe on whether targets are quotas. They are not, unless stated otherwise (see prohibited claims). |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Use of AI tools, not building AI features. Bridge: "I use AI tools daily." Answer slot: name one workflow where AI changed a piece of your analysis; if none, say so. |
| F7 | Sales-ops and quota-setting, a peer-side area not in the JD highlights (plain prose, [generic]) | "No classic sales-ops or quota-setting experience" (your message) | none | [grounded] | capability | This is the absence you stated, and the peer is likely to probe it. Plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." Then the nearest thing your material shows: "set annual volume targets with cross-org consensus", said as targets, not quotas. |
| F8 | "B2B data-infrastructure SaaS" (company profile, your message; not a JD highlight) | "9 at a large consumer-tech company in product strategy & ops" (your message) | low | [grounded] | discovery | Your material is silent on business buyers and business products. Answer slot: if you have worked with business buyers or on a business product, say which; if not, say so and say how you would learn the business buyer. |
| F9 | Headline metric (your message; not a JD highlight, plain prose) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | none | Limited inspectable proof, so expect a probe on attribution. Bridge: "I proposed a store-surface change; it is credited with a ~$400M ARR uplift." The defend-the-number slots in A2 apply. |

**Gate check:** the material contains no gate (authorization, location, notice, pay, travel or credential). Nothing is marked `hard_gate`.

## Grounding brief

Learn the vocabulary from your research note. Quotes are your note's words, not verified this run.

- Stated priorities: "enterprise expansion"; "AI copilot launch ('Compass')"; "reaching profitability".
- Main competitive threat: "bundling by a much larger platform vendor".
- Current segmentation language: the JD's own "land/adopt/expand/renew". Use it; do not correct the interviewer's framing.
- Stale framings: none identified, because none were checked.

## Reading the interviewer

From your message only. Public footprint was not checked, so treat these as a working read.

- **Career spine:** "pricing and monetization roles", plus one "early-stage-startup chapter".
- **Self-described style:** "relentlessly data-driven".
- **What lands with him:**
  1. Expect every metric to be taken back to its assumptions (A1, A2). Name your weakest assumption first.
  2. Case questions tilt toward pricing, packaging and unit economics (C3). That is his native language.
  3. The startup chapter makes a scrappiness probe plausible: "how did you work when there was no team to lean on?" Your material is silent on that, so the answer is a slot, not a story.
  4. The mirror: your partner-level revenue model is monetization work, and it is the closest thing to his path in your material (F2, F4).
- No shared career jump is stated in the material, so none is offered as a mirror.

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Takes apart numbers and inputs, asks for the denominator and the assumption behind each figure | **Top, 5 questions.** The peer prior puts Prober and Peer Evaluator first. "Relentlessly data-driven" raises Prober above the default. | Name the weakest assumption before he does; say plainly what you do not know about how a figure was counted. |
| Peer Evaluator | Seam-splitting between teams, credit-sharing, disagreement with equals | **4 questions.** Peer prior. He is pricing what the hire costs his team. | Offer seam principles, not claimed seams. Reciprocity: what you bring his team. |
| Case / Strategist | Live problem on pricing, whitespace, the competitor's bundle | **3 questions.** The role is GTM strategy, and his pricing background tilts case questions toward price. | Clarify, then structure land, adopt, expand, renew. Say the framework aloud. Challenge one premise. |
| Skeptic | Quiet probing of the gap: the GTM ownership line, the sales-ops absence, the "why leave" question | **3 questions.** Mid weight. The largest gaps (F1, F7) are where a peer will press. | Rehearse the most predictable objection until it is plain. Calibrated candor, not a bluffed competency. |
| Pressure / Stress | Interruption, time-boxing, "how much of that was actually you?" | **2 questions.** Peer round, so this is a touch, not a focus. The headline metric invites it. | Hold the quoted position through two follow-ups; concede the specific you can name, never the core claim. |
| Conversational / Rapport | Friendly, unstructured openers that are still scored | **2 questions.** Casual openers are still scored; the reverse-questions slot is weighted heavily. | A pre-scripted 90-second arc. Treat casual questions about AI as scored. |
| Values / Behavioral | Scenario probes on customer-versus-metric or unpopular truths | **2 questions.** No values round detected, so this is a touch only. Every persona is touched, so there is no first-time style live. | Selection scaffolds with an honest branch; no mapped story exists without research. |

Total: 21 questions, inside the 18 to 26 range.

## Question banks

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the inputs to the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, and it was used in carrier negotiations. Walk through the inputs you chose, in your own words. Name the assumption you would defend least before he does. Answer slot: if others set the inputs, say which and what you controlled. | F2 and F4 both rest on this model, so it is the likeliest place a prober starts. EXP because it tests what was hers. |
| A2 | "Which number on your CV would you defend least, and how was it counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Beats the quote states: you proposed the change, and the uplift is credited to it. Name the weakest assumption you know of first. Answer slot: how the uplift was counted and who credited it. If you can say, say how, in your own words. If you cannot, say so plainly. Say which part was yours to propose and which the team built. | F9 is the headline figure, and "credited" is the word to keep. Defend-the-number slots apply: how counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| A3 | "What is a question you have answered with SQL or Tableau, and what did you do yourself?" | JD | [grounded] "skilled in SQL/Tableau" | Open prompt: you choose the analysis. Story-map only the skill the quote states. Answer slot: if you ran the analysis independently, describe the query or view and what it counted. If the work sat inside someone else's dashboard, say so and say what you added. | JD requirement "run independent analysis in SQL and Tableau" (F3, `none`). This is the "show me" probe. Open form because the material names no specific analysis. |
| A4 | "How were the annual volume targets set, and who had to agree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: you set annual volume targets, with cross-org consensus. Say who was in the room, in your own words. Answer slot: if the targets were split into team quotas or tied to compensation, say so and how. If they were not, say plainly that they were targets, not quotas. | F5, the JD's "strong cross-functional influence". This is where a peer checks whether targets are quotas. They are not, unless you say so. |
| A5 | "Which measure from that consumer-tech work would you bring to a business-data buyer, and which would you not trust?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | No beats invented. Name one measure from that period that transfers, and one you would not trust across the business context. Answer slot: if you used no measure from that period you can name, say so and name what you would check first. | F8 is `discovery`: the business-buyer gap is silent in the material. A transfer claim without a denominator is the first thing this persona picks at. |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between sales strategy and emerging-product go-to-market, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you claim to know. Define handoffs by decision (who sets a price, who sets a target, who approves a partner term), not by org chart. Ask what he owns today before naming any boundary. Makes no claim about your past. | Peer stem. The JD's "strong cross-functional influence" is the raising source for the seam theme. [generic] because it is a pattern for the seam question, not a fact about this team. |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Beats the quote states: you proposed the change, and it is credited. Use "I" for what you proposed and "we" for what the team built. Answer slot: who else shaped the change and how you got it adopted. If you did something specific to get it adopted, say what. If not, say so. | Credit-sharing probe. The $400M quote is the nearest story, and "credited" is the word to keep, not "drove". |
| B3 | "Tell me about a time you disagreed with a peer on a number, and how it resolved." | JD | [grounded] "set annual volume targets with cross-org consensus" | Open prompt: you choose the instance. The quote carries the ending: consensus was reached on the targets. Answer slot: if a disagreement on the targets stands out, name it and how it resolved. If none does, say so plainly, then give the nearest thing your material carries, or how you would handle it. | JD's cross-functional influence, F5. Disagreement with equals is a peer-scoring theme. Open form, because the material does not name a disagreement. |
| B4 | "Partner motion: who owns partner terms today, and where would you draw the line on your side?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: the model, used in carrier negotiations. Keep its scope as the model, not a partner program. Answer slot: if you designed partner terms, incentives or enablement, say which. If you did not, say so and say what the model covered. | F4 is `transferability`. The JD's "partner-motion design experience required" is the raising source. The question asks him to define the line, which keeps the answer from claiming design work. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line is flat for two quarters after launch. Diagnose it: what do you need to know first?" | CASE | [generic] | Clarify, then state the objective, segment by land, adopt, expand and renew (the JD's vocabulary), set an approach, name metrics, then risks. Think aloud. Challenge one premise respectfully. Presupposes nothing about you. | JD: "own GTM strategy for two new product lines" and "identify whitespace across land/adopt/expand/renew" (F2). A live problem from the role. |
| C2 | "Size the whitespace for an AI copilot add-on. Where do you start?" | CASE | [grounded] "AI copilot launch ('Compass')" (your research note) | Clarify the buyer first. Segment by lifecycle stage. Name what you would need to see before sizing anything. Do not claim a sizing method from past work; you have none stated. | Ties to a stated company priority (Compass). CO and CASE dual-tag: the grounding is your note, and the live problem is the task. |
| C3 | "A much larger platform vendor starts bundling a comparable capability into its suite. What happens to our pricing on the overlapping products?" | CASE | [grounded] "bundling by a much larger platform vendor" (your research note) | Clarify which products overlap and which customers the bundle reaches. Segment by who is likely to switch. Then the options: hold, unbundle, re-package. Name the metrics you would watch before changing any price. | The main competitive threat from your note. Tilted toward pricing and unit economics, because his career is pricing and monetization. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which go-to-market decisions have you made yourself, if any, and which were made with you?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights); "9 at a large consumer-tech company in product strategy & ops" (your message) | **Deepest rehearsal.** Hold through two follow-ups by returning to what the material states: the product strategy and operations, and the model you built. Concede specifically: name the go-to-market work you have not run. Follow-up 1 (which part was yours?): answer from the quotes. Follow-up 2 (who decided?): say who, in your own words. Follow-up 3 (what would you do differently?): one concrete change. Follow-up 4 (what would you learn first?): name it. Answer slot: if no go-to-market decision was yours, say so plainly and name the closest decision you did make. | **Highest-ROI prep in this pack.** The JD's headline ownership line is F1, the biggest gap, and it is where the interview will press. The question asks what she has made without presupposing that she has made any. |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message); "set annual volume targets with cross-org consensus" (your message) | Name the weakest part in your own words. If it is sales-ops or quota work, use the plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." Then the nearest thing you have: the target-setting. Then the ramp: what you would learn first, and how. Do not claim the area. | F7, `capability`. This is a likely peer probe. Calibrated candor, not a bluffed competency. |
| D3 | "Why leave consumer tech for B2B data infrastructure now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Motivation. The material does not state a reason. Answer slot: give the reason you actually hold, in one or two sentences, in your own words. | Skeptic probes motivation consistency. Dual-tagged on motivation, but EXP is the primary type because the question is about her history. |

### E. Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede. Hold "I proposed the change" through two follow-ups, and do not strengthen the verb. Concede the specific: the uplift is credited to it, and any split you cannot vouch for. Answer slot: if you know how the credit was divided, say how. If you do not, say so and say what you can vouch for. | Stress on the headline figure. The hold is the quote's own verb; the concession is the part you can name. |
| E2 | "Sixty seconds: why you for this role?" | JD | [grounded] "2 years strategy consulting at a top firm" (your message); "9 at a large consumer-tech company in product strategy & ops" (your message) | Two beats, each quoted: the consulting years, then the consumer-tech product strategy and operations. Do not state a motivation the material does not carry. Answer slot: the one reason you hold for this role, in your words. | Timed. The 60-second version is the answer to "why you" under a stopwatch. |

### F. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" (your message); "9 at a large consumer-tech company in product strategy & ops" (your message); "uses AI tools daily" (your message) | A 90-second arc in three beats, each a quoted clause: consulting, then consumer-tech product strategy and operations, then AI tools used daily. Keep to those words. | Casual opener, still scored. The pre-scripted arc is the answer to a "walk me through" from a rapport builder. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name one tool and one task you use it for. Say "use", not "build". Answer slot: name one workflow where AI changed a piece of your analysis; if none, say so. | JD plus-skill (F6), asked casually. Scored even in a casual register. |

### G. Values / Behavioral (2)

No values round was detected, and no company values were retrieved, so these are scaffolds, not mapped stories.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] (no quoted sentence carries a story here) | Selection scaffold: pick a time a customer's need and an internal target pulled against each other. Name the metric, the customer and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Persona stem for the values profile. [generic] is the honest label, because no sentence in the material carries this story. |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] (no quoted sentence carries a story here) | Selection scaffold: pick a time a finding contradicted what leadership wanted. Name the finding, to whom, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Persona stem, low weight. Same honest branch as G1. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | D1, C1 |
| identify whitespace across land/adopt/expand/renew | C1, C2 |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | B4, A1 |
| strong cross-functional influence | A4, B1, B2, B3 |
| AI experience a plus | F2 |

Every JD highlight has at least one question. The highlights are partial. The full JD may add requirements the banks do not yet cover (upgrade menu).

## Reverse questions

At least five, one tied to his path, and one reciprocity question because he is a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You started in pricing and monetization, then spent a stretch at an early-stage startup. What did the startup teach you that the bigger-company pricing work did not?" | Ties to his own path. Turns a probe into a peer conversation and shows you researched him, not only the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for a peer. It moves the conversation from what she needs to what she brings. |
| R3 | "Which pricing and target decisions for new products sit with your team, and which would sit with the GTM lead?" | Maps the seam he cares about and shows she is already thinking about the boundary. |
| R4 | "Of the three priorities, enterprise expansion, Compass and reaching profitability, which is your team's binding constraint right now?" | Shows she read the stated priorities and asks for his view, not a recital. |
| R5 | "When the bundling threat shows up in a deal, how does your team decide whether to hold price?" | A pricing-native question on the main competitive threat. It tests where he is personally exposed. |
| R6 | "Where does partner-terms work sit today?" | Defines the partner-motion boundary. His answer tells her what the role would own. |

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot, because no dossier was provided.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope: "9 at a large consumer-tech company in product strategy & ops". The limit is the pack's own observation: your material shows product strategy and operations, not go-to-market ownership. D1's slot stays inside that scope. |
| Drove or led the ~$400M ARR uplift | Inflated form of F9 | F9's quote: "proposed a store-surface change credited with a ~$400M ARR uplift". The verb stays "proposed". B2 and E1 ask only what she can vouch for. |
| Set quotas or ran sales-ops | Negative she stated (F7), and an inflated form of F5 | Plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." Targets are not quotas; A4 asks her to say so. |
| Designed partner programs or terms | Inflated form of F4 | F4's quote: "built a partner-level revenue model used in carrier negotiations". B4 asks which line she would draw, not what she designed. |
| Built AI features or models | Inflated form of F6 | "uses AI tools daily". F2 and F6 ask about workflow, not building. |

Silence is not listed: whether she has worked with business buyers (F8) is an answer slot, not a prohibited claim.

## Sources

**Provided:** your message, which holds the candidate summary, the JD highlights, the interviewer note and the research note. No documents were attached, and no dossier was present.

**Searches sent this run:**

| Query | Outcome |
|---|---|
| "Northwind Data company values" | refused (search permission not granted) |
| "Northwind Data interview process sales strategy" | refused (search permission not granted) |

**Research tier:** L1, with searches 0 of 6 (2 refused) and fetches 0 of 2.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have fed the values cheat sheet. Not included: no values-style round was detected. |
| 2. Northwind Data interview process, sales strategy | unavailable | Would have confirmed the loop structure. This is a single conversation, so persona weights rest on the peer relationship prior. |
| 3. Company strategy and recent news | skipped | Your research note already supplies the priorities and the main threat. |
| 4. Interviewer name and company | unavailable | Would have checked public talks and writing. Not searched this run; the interviewer read rests on your message alone. |
| 5. Representative JD for the title | unavailable | The highlights do not cover the full JD, so a representative JD would have filled the gaps. Not searched. |

## Upgrade menu

- **The full JD text** → the six highlight rows move from partial to complete, and any requirement the highlights omit gets a JD-tagged question.
- **Permission to run web research** → a values cheat sheet, the loop structure, and a check on the Compass and bundling details in your note.
- **Dan's public talks or writing** → a tailored reverse question and persona weights read from his footprint.
- **Any go-to-market decision you made yourself, stated in your words** → D1 moves from answer slot to story-mapped, and F1 gains a quoted basis.
- **The breakdown of the ~$400M figure, in your words** → A2 and E1 gain a quoted basis for how it was counted.
- **A `tuesday-dossier.md` from an earlier session, if you have one** → verified evidence and prohibited claims in place of the local list.
