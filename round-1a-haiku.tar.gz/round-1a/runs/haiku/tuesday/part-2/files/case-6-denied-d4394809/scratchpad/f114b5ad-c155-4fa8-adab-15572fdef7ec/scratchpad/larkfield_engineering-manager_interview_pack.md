# Engineering Manager, Larkfield Systems: prep pack (loop mode, three rounds)

Candidate: Yusuf. Company: Larkfield Systems (industrial IoT, about 600 people). Role: Engineering Manager, leading two squads on device-management services.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (hiring manager, future manager) | 45 min | Hiring manager |
| 2 | Thursday, the day after | Two staff engineers and a product manager | 60 min | Panel (peers) |
| 3 | The following Monday | VP Engineering | 30 min | Values and leadership philosophy |

First version. No changelog.

## How to use, and the type key

Personas describe how a question is asked. Types describe what is being scored.

- **Case**: a live problem from the role, scored on structure and reasoning.
- **EXP**: a question about something you did, scored on whether it survives scrutiny.
- **JD**: a requirement from the role summary, scored on whether you can do it, including its gaps.
- **VAL**: a values or leadership question, scored on whether a past decision shows the value.
- **CO**: company and strategy knowledge. Not covered here, because no research ran (see Sources).

Guidance is scaffolding, not a script. Rehearse the shape and the honest branch, not a sentence you have not said before.

Answer slots (phrased "if you... say how; if not, say so") are instructions for the interview. They ask for no reply here.

## Shared fit snapshot

The requirements come from the role summary in your message, which is the only role text I have. A full posting would turn several unquoted rows into quoted ones (see the upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message, role summary) | "3 as a team lead of 6, currently at a payments company" (your message) | medium | [grounded] | transferability | Your material says a team lead of six for three years, not two squads. Words: "For three years I was a team lead of six." Answer slot: if you have coordinated work across more than one team, say what that was and what you did in it; if you have not, say so plainly. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message, role summary): hiring part | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | transferability | Your material says you run the loop, not what you decided at the end of it. Words: "I run our hiring loop for backend roles, about 40 interviews last year." Answer slot: if you made the hiring decisions, say how; if someone else made them, say so. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message, role summary): delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your material shows delivery under pressure through reliability work, not delivery planning for a squad. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you planned delivery for a team and what it shipped, say how; if your delivery work was reliability work, say that. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message, role summary): growth part | none given | none | [grounded] | discovery | Your material says nothing about growing people's roles. Answer slot: if you have grown someone's role on your team, say what changed for them and what you did; if you have not, say so plainly and say how you would start. |
| F5 | "Lead two squads" implies leads under the manager (inferred from the role summary: two squads and 11 engineers) | "I've never managed managers and never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Your own negative, given back as your words. Words: "I haven't managed managers." No slot. Never describe managing leads you did not manage. |
| F6 | "partner with hardware and product on roadmap" (your message, role summary): hardware part | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Your own negative, given back as your words. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | "partner with hardware and product on roadmap" (your message, role summary): product part | "I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your material shows you held a roadmap against pressure. It does not show partnering with product on a roadmap. Answer slot: if you set a roadmap with product, say how; if the roadmap was set above you, say so. |

Gate check: the role summary states no location, work-pattern, pay or start-date terms, and your material is silent on them. No gate row is written, because nothing in the material shows a gate. Your answer to the question at the end of this pack decides whether one is needed.

Requirement strength: the material is thin on hardware (F6) and on managing leads (F5). Those two are the pack's real exposure. Expect them in the Director round.

## Shared prohibited list

Built from the fit snapshot before any question was written. No answer slot, hold, bridge or reverse question may assert or imply a listed claim.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6, currently at a payments company." The limit is this pack's observation: your material says a team of six, not two squads. |
| Owned hiring end to end | Inflated form of F2 | F2's quote at its own scope: you run the loop. The decision authority is an answer slot, not a claim. |
| Drove the 60% drop alone | Inflated form of F3 | F3's quote: "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The 60% is the team's figure. Only the pushing-through is yours to claim. |
| Managed managers | Negative you stated, F5 | "I haven't managed managers." No slot. |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot. |

## Shared sources note

Round-level persona weights below rest on the three rounds you gave, which name the relationship and the format. No interviewer names were given, so there is no interviewer read. No company values or strategy are in hand, so there is no values cheat sheet and no strategy-grounded CO question.

---

## Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona table

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on the device roadmap, hardware timing, two squads' priorities | High. A hiring manager is buying capability and needs to see how you would start on their roadmap. The relationship prior for hiring manager is Case plus Skeptic. | Clarify before structuring. Name what you would ask hardware and product first. Do not propose a plan on a roadmap you have not seen. |
| Skeptic | Quiet probing of F5 and F6: managing leads, the hardware roadmap, why you are leaving a payments team | High. Your two stated negatives are the gaps this role is most likely to probe. | Say your two negatives in your own words before they do. Then give the plan for learning, as a plan. Hold the plan through one follow-up. |
| Data-Driven Prober | The 60% figure, the 40 interviews, the growth question | Medium. Your figures are specific and you will be asked how they were counted. | Know what you can and cannot say about how each figure was counted. Say plainly when you do not know. |

Weights, shown so you can recalibrate: Case 4 questions (top persona), Skeptic 3, Prober 2. Relationship priors set these; no interviewer signals exist to adjust them.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Two squads, one device-management roadmap, and hardware on the other side of the table. What do you do in your first 90 days?" | CASE | [grounded] "Lead two squads building device-management services"; "partner with hardware and product on roadmap" (your message, role summary) | Clarify first: what the hardware release cadence is, who owns the device firmware decisions, and what the two squads already ship. Structure as objective, then sequence: listen, map the squads' commitments, pair with hardware on the next release. Make no claim about your past. | The role summary raises this directly. It is a live problem, so it presupposes nothing about you. |
| H2 | "You've said you've never owned a hardware-adjacent roadmap. Where would you be weakest on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" (your message) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the plan, as a plan: what you would read, whom you would ask, and what you would bring to the first hardware review. Hold it through two follow-ups by returning to the plan, never by adding a past. Concede specifically if pushed: name the one thing you would be slowest on. | F6 is the single most predictable objection to you in this round. A rehearsed, non-defensive answer changes the interview. This is the highest-ROI prep in the pack. |
| H3 | "Two squads means someone under you runs part of it. What have you done with managers, as opposed to team leads?" | EXP | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then what you did with the team leads you did manage: the team of six, in your own words. Answer slot: if you have set a lead's objectives or reviewed their work, say how; if not, say so. | F5 is a gap you stated. The premise is your own negative, so the question carries no new claim. |
| H4 | "Walk me through the reliability quarter. What was the roadmap pressure, and what did you do with it?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped on F3: the quarter, the pressure, the pushing-through. Answer slot: if you chose what to defer or what the quarter covered, say which and how you decided; if those calls were made above you, say so and describe what you did do. | F3 is the strongest story you have and the likeliest to be probed. The quote carries the story; the middle is yours to tell. |
| H5 | "The 60% on-call drop. How was it counted, over what period, and which part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Weakest-assumption move: name the assumption behind the 60% you would defend least, before they do. Answer slot: if you know how it was counted, say how; if you do not, say so plainly. Then say which part was yours, in the words of the quote. | A figure you gave raises this defend-the-number question. It is the Prober's favourite. |
| H6 | "A device fleet has a firmware fault in one batch. Do you fix it in hardware or ship a feature the roadmap needs? Talk me through it." | CASE | [generic] | Clarify: how many devices, how severe, what the roadmap commitment is. Structure: the risk, the options, who decides, what you would tell product. Make no claim about your past. | A live problem from the role's hardware-roadmap line. Presupposes nothing about you. |
| H7 | "You run the loop for backend roles. What did you decide at the end of it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Restate the scope in your own words: you ran the loop, about 40 interviews. Answer slot: if you made the hire or no-hire calls, say how you made them and what you weighed; if the call was someone else's, say so plainly. | F2. A probe on the decision is likely because the role says "own hiring". |
| H8 | "Tell me about the last hire you would make again, and the one you would not." | EXP | [inferred] the role summary's "own delivery, hiring and growth for 11 engineers" (your message). Open prompt. | Selection scaffold: pick a hire from a loop you ran, with a named reason you would repeat or change the call. If no such hire comes to mind, say so plainly, then give the nearest one your material carries. | Open prompt on the hiring line. Its theme comes from the role summary, not from anything you have said. |
| H9 | "The role owns growth for 11 engineers. How have you grown the people on your team, and what changed for them?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your message, role summary) | Answer slot: if you have grown someone's role, say what changed for them and what you did; if you have not, say so plainly and say how you would start. Do not describe a promotion you did not make. | F4, with no evidence. The requirement is the role's own, so the question is fair. The honest branch is a plan, not a past. |

### Reverse questions, round 1

| Question | Why it lands |
|---|---|
| "What does a good first 90 days look like for this role, and what would you call a miss?" | It turns their Case probe into a scoring criterion, and it shows you want to be measured on the right things. |
| "Which decisions this year depend most on hardware timelines?" | It shows you have already found the hardware dependency and want to plan around it, which is the gap H2 is about. |

---

## Round 2: Thursday, panel (two staff engineers and a product manager), 60 min

The panel's personas are blended across the panel, because no names were given. Each member's relationship is a peer prior.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (staff engineers) | Follow-ups on the 60%, the quarter's scope, what the metrics measure | High. Two staff engineers read the CV line by line; your 60% is the magnet figure. | Name the weakest assumption before they do. Say which part of the quarter you would defend least. |
| Peer Evaluator (staff engineers) | Where the seam with the platform team sits, credit sharing, disagreeing with equals | High. Staff engineers price what a hire costs their own work. | Propose seam principles rather than pretending to know the seam. Show what you bring their team, not just what you need. |
| Case / Strategist (product manager) | Firmware fault in 48 hours, feature-versus-hardware trade-offs, what you need from product | High. The PM is buying the partnership the role names. | Clarify before structuring. Name the one premise you would challenge. |

Weights, shown: Prober 3, Peer 3, Case 3. Equal weights because three members split the room. If you learn who asks what, the weights move.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How was the on-call burden counted, and over what period?" | EXP | [grounded] "My team's on-call burden dropped 60%" (your message) | Weakest-assumption move: name the assumption behind the 60% you would defend least. Answer slot: if you know the counting method, say it; if not, say so plainly. | Defend-the-number question, raised by F3's figure. |
| P2 | "Which part of the reliability quarter would you defend least?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Name the part you would defend least before they probe it. Hold the rest of the quarter to what the quote carries. | Tests whether your story survives its weakest point. |
| P3 | "Which device-management metric would you not trust yet, and why?" | CASE | [generic] | Name one metric, the assumption it rests on, and how you would check it. No claim about your past. | A live problem on the role's own domain. |
| P4 | "Our two teams sit side by side on the device stack. Where's the seam with platform, and what happens when we disagree?" | Peer | [generic] | Propose seam principles: who owns the interface, how disagreements escalate, what a joint review looks like. Do not claim a seam you have not worked on. | Peer evaluators probe the seam. The question is a role-level pattern, not a fact about your past. |
| P5 | "When roadmap pressure came in against that quarter, what did you do?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped on F3, with the pushing-through in your own words. Answer slot: if you chose what to defer, say which and how you decided; if those calls were not yours, say so and say what you did. | Peer probe on disagreement with equals; the same story as H4, told to peers. |
| P6 | "How do you handle credit when work spans teams?" | Peer | [generic] | Name a specific case where credit was shared and how you raised it. If no such case comes to mind, say so plainly, then give the nearest one. | Peer-style probe on credit. Its theme is the panel's own, not from your material. |
| P7 | "A firmware update breaks for three percent of units. What do your squads do in the next 48 hours?" | CASE | [generic] | Clarify: which units, what the rollback path is, who owns customer comms. Structure: contain, diagnose, communicate, decide. No claim about your past. | A live product problem. |
| P8 | "Product wants a feature that adds two quarters of hardware work. How do you push back?" | CASE | [generic] | Clarify the feature's value and the hardware constraint. Propose a set of trade-off options, with a named decision owner. | The role's roadmap partnership, asked as a problem. |
| P9 | "What would you need from product in your first quarter to deliver?" | JD | [grounded] "partner with hardware and product on roadmap" (your message, role summary) | Name two or three things, in terms of decisions and access rather than headcount. Answer slot: if you have set a roadmap with product before, say how; if not, say what you would ask for first. | F7. The product-partnership line of the role, asked as a practical question. |

### Reverse questions, round 2

| Question | Why it lands |
|---|---|
| "What could a new person do in their first month that would genuinely help your team?" | This is the reciprocity question a peer panel expects. It turns the panel from interviewers into future colleagues. |
| "Where do the device-management and platform roadmaps currently collide?" | It shows you have heard the seam question and want to see where it bites now. |

---

## Round 3: Monday, VP Engineering, values and leadership philosophy, 30 min

The round is named as values-style in the recruiter's words, which is a loop source, so the round is detected as values-style. No published values page is in hand, so no values cheat sheet is included (see Sources).

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Open prompts on unpopular truths, customer-first decisions, what your leadership philosophy costs | High. The round is named as values and leadership philosophy. | Pick an instance with a named stake and an intact relationship at the end. Where no instance fits, say so, then give the nearest. |
| Pressure / Stress | Sixty seconds on why you, how much of the 60% was you | Medium-high. A VP tests composure on a figure they will have heard about. | Pause, restate the question, anchor in what you stated. Hold the position through two follow-ups. Concede specifically, never on the core claim. |
| Case / Strategist (exec) | Where the device category is going, what you would stop doing | Medium. An executive round usually touches strategy, which this pack could not research. | Answer from the role, not from invented market data. Say what you would need to know. |

Weights, shown: Values 4 (top), Pressure 2, Case 2. The round is short (30 min), so eight questions is the ceiling.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] (theme from the recruiter's "values and leadership philosophy") | Selection scaffold: pick a time you told leadership something they did not want to hear, with a named stake and a moment you did not fold. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the reliability quarter, and what it cost. | No candidate sentence carries an unpopular-truth story, so this is a scaffold, not a mapped story. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold, as V1. Name the metric and the customer, in your own words, and what you gave up. If none comes to mind, say so plainly. | A values stem. Your material carries no customer story, so the scaffold is the honest form. |
| V3 | "What is your leadership philosophy in one sentence, and where has it cost you?" | VAL | [generic] | One sentence, then one cost. The cost must be a real one. Do not give a sentence you would not defend under a follow-up. | Open prompt on the round's named theme. |
| V4 | "You pushed a reliability quarter through against roadmap pressure. What happened when the pressure came in?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped on F3. Answer slot: if you chose what to defer, say which and how you decided; if those calls were not yours, say so and describe what you did do. Name the stakeholder who pushed, only if you know who it was. | The round's values theme meets your strongest story. Expect it to be the chosen example. |
| V5 | "Sixty seconds: why should we hire you over the next candidate?" | Pressure | [generic] | Pause. Restate the question. Lead with the reliability quarter and the hiring loop, in your own words, then stop. Do not argue against unseen candidates. | A time-boxed challenge. Composure is what is being scored. |
| V6 | "That 60% — how much of it was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Hold the pushing-through, in the quote's words. Concede specifically on the team's share: say what you cannot claim, and say which causes you can name, if any. Never fold on the pushing-through. | The honest version of an inflation probe. Your answer should show the line between your act and the team's result. |
| V7 | "What would you stop doing in your first 30 days?" | Case | [generic] | Name one thing you would stop, with the reason and the person it affects. Do not describe a stop you did not make. | An executive probe on judgment, asked as a plan. |
| V8 | "Where does device management go in two years, and what would you bet on?" | Case | [generic] | Name one bet and what would change your mind. If you have a view of the category, say it as a view; if you do not, say what you would need to know. Make no market claim you cannot defend. | An executive strategy probe. No research ran, so it is generic by design. |

### Reverse questions, round 3

| Question | Why it lands |
|---|---|
| "How does leadership here decide between a reliability quarter and a feature push?" | It shows you understand the tension your strongest story sits in, and it gets the VP's actual trade-off in their own words. |
| "What would you want a new engineering manager to have changed by their first year?" | It asks for the success criteria in the VP's own terms, which is the question a leadership-philosophy round rewards. |

---

## Requirement coverage

The role summary's requirements, mapped to the question IDs that cover them.

| Requirement | Questions covering it |
|---|---|
| Lead two squads building device-management services | H1, H3, P9 |
| Own delivery | H4, P5, V4 |
| Own hiring | H7, H8 |
| Own growth for 11 engineers | H9 |
| Partner with hardware on roadmap | H2, H6, P8 |
| Partner with product on roadmap | P7, P9, V8 |

No requirement is uncovered. The gate check has no question in the banks: it is one of the two questions at the end of this message.

## Sources

- Provided: your message. Role summary, candidate background (quoted in the fit snapshot), the three rounds and their relationships.
- Web search, two calls, both refused (permission not granted):
  - "Larkfield Systems values": refused
  - "Larkfield Systems interview process engineering manager": refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, section 10, which is absent because no published values are in hand. Round 3's V1 and V2 are scaffolded, not mapped. |
| 2. Larkfield Systems interview process | unavailable | Loop structure. The three rounds come from your message, which establishes the loop, so no archetype fallback is needed for round count. Round 3's values detection rests on the recruiter's words, not on a published loop. |
| 3. Larkfield Systems strategy or recent news | unavailable | CO questions in round 3 (V8) and any strategy-grounded differentiator. Without it, V8 is generic. |
| 4. Interviewer name and company | n/a | No names were given, so there was no query to form. The interviewer read is absent and the upgrade menu says what names would unlock. |
| 5. Representative Engineering Manager JD | unavailable | The fit snapshot's requirement quotes. The role summary in your message is not a full posting, so the JD-tagged questions rest on it. |

Note: the company name may be a small or new company. If search returns nothing attributable to Larkfield Systems, none of its facts would be used. The values and strategy gaps above stay open until the upgrade menu's items are supplied.

## Upgrade menu

- The full posting, or the recruiter's prep email → converts the role-summary rows from your message into quoted JD rows, and tests the gate check for location, pay and start date (F1 to F7, gate row)
- The recruiter's notes on focus areas or deliverables for any round → coverage of any pre-declared deliverable, and a reweight of the panel round
- The company's published values page, pasted → the values cheat sheet for round 3, and the V1 and V2 stories mapped to published values rather than scaffolded
- The Director's, the VP's and the panel's names → an interviewer read, and per-member personas for the panel instead of a blend
- A CV or resume, attached → more quoted evidence, especially for growth (F4), where the material is silent now
- Permission to run web search → company values, loop structure, and current strategy for the CO questions. Permission was not granted in this run, so these are absent. A deeper research pass is also available once search works
