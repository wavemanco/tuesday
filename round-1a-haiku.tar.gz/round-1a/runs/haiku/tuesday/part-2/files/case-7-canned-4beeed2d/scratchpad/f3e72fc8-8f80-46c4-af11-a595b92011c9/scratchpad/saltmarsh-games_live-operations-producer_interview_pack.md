# Saltmarsh Games: Live Operations Producer, interview prep pack

**Round:** Outage Hour, 60 minutes, with the hiring manager Tobias Wrenfield (Head of Live Operations). Per Saltmarsh's careers page, this is the whole loop after the recruiter call: a live-incident tabletop on a simulated outage during a live event, then a values conversation.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work, tested for attribution), JD (the listed job), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Every claim about your past is one of your own sentences, quoted, or an answer slot you fill in your own words.
- Provenance labels: `[grounded]` traces to your message or a fetched page; `[inferred]` is a derivation; `[generic]` is a pattern for the problem with no claim about you or Saltmarsh.

## Fit snapshot

Requirements are the JD's own words. Evidence is only your sentences, verbatim. Your message is the source for every evidence quote; the JD is the source for requirements.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and content drops, not two titles or live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title line makes a probe likely. If you have run more than one title, or events, say so; if not, say so and stay with the one you ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Nothing you wrote shows coordinating those teams. Answer slot: if you coordinated any of them on an update, say which, what you asked of each, and what you did. If you did not, say so and say how you would start with each team. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is not owning the review or its KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs the reports carried, say so; if someone else defined them, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Your quote already reaches this in role terms. Expect a probe on "manage": say what you own of the checklist and what QA owns. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Years are stated; the word "live-service" is not. Bridge rewords only: "four years as an associate producer at a puzzle-game studio." Answer slot: if the titles ran live content, say how; the quote does not say so. Years are not a gate, so this row is not `hard_gate`. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Your quote already reaches this requirement. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your quote reaches the requirement in other terms. Bridge rewords only: "I presented the monthly retention numbers to the studio head." Defend-the-number slots apply (see D1). |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A written artifact other teams use. Bridge: "I wrote the release checklist our QA team still uses." Nothing added to the quote. |
| F9 | Not in the JD: team leadership | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Your own negative. Words you can say: "I haven't led a team." Then the coordination answer slot (F2). Never a claim to leadership. |
| F10 | Not in the JD: in-app purchases | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Your own negative. Words you can say: "I haven't worked on a game with in-app purchases." Then a plan for learning it, as a plan, never as past. |
| F11 | "a live-incident tabletop on a simulated outage during a live event, then a values conversation" (Saltmarsh careers page, fetched) | none given | none | [grounded] | discovery | The interview's own format. Nothing you wrote shows incident response. Answer slot: if you have been in a live incident, say what you did; if not, say so and describe how you would run this one. |

**Hard gates:** none. The JD names no location, work-authorization or schedule terms.

**Read first.** The biggest gap is F11, not F9 or F10. The round is a tabletop on a live incident, and nothing you gave me shows incident experience. Rehearse A1 and C1 hardest.

## Prohibited claims

Not to be coached. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the calendar for two titles | Inflated form of F1 | F1's quote at its own scope: one title, content drops. The limit is this pack's observation: your material says one title, not two. |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote: you presented the numbers. Say what you chose and what you did not. |
| Owns QA sign-off on releases | Inflated form of F4 | F4's quote: you wrote the checklist QA uses. |
| Ran live-service titles | Inflated form of F5 | F5's quote: four years at a puzzle-game studio; the word "live" is not in it. |
| Led a team, or coordinated the four functions | Stated negative, F9; silence, F2 | "I haven't led a team." Then the answer slot in F2. |
| Has worked with in-app purchases | Stated negative, F10 | "I haven't worked on a game with in-app purchases." Then a plan. |
| Handled live incidents or outages | Silence, not a stated negative (F11) | Not listed. It is an answer slot, whose second branch lets you say there was no such experience. |

## Persona table

Weights follow the loop source (the careers page), then the JD. No interviewer profile was verified, so no interviewer signal adjusts them.

| Persona | Weight | How it shows up in this round | Likelihood reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 | The live-incident tabletop | Named as the loop's first half | Clarify, then structure, then decide. Say what you would do first |
| Values / Behavioral | 4 | The values conversation | Named as the loop's second half, so a values round is documented | Map your quoted sentences to the values; mark the honest branch where none carries one |
| Skeptic | 4 | "Why you, given what you lack" | Hiring-manager prior, plus F2, F9, F10 and F11 | Say the limit plainly; bring a ramp plan; do not bluff |
| Data-Driven Prober | 3 | Retention and KPI probes | Hiring-manager prior; JD names KPIs and retention | Say how each number was counted, or that you do not know; name the weakest assumption |
| Pressure / Stress | 2 | Time-boxed challenge | Not named by the loop source; low weight | Pause, restate, hold through two follow-ups, then concede the specific point |
| Conversational / Rapport | 2 | Opening and closing | Hour-long calls open casually; casual questions are still scored | A 90-second arc from your quotes |
| Peer Evaluator | 0 | Not plausible | The loop has one hiring-manager session | None |

Session total: 20 questions, weighted 5 / 4 / 4 / 3 / 2 / 2.

## Values cheat sheet

Values are from the Saltmarsh values page, fetched. The loop source documents a values conversation.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a story here. Selection scaffold, using F7: "Presented the monthly retention numbers to the studio head." Pick a time a player-facing call beat a plan you had. If none comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers you presented. |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped | F4: "Wrote the release checklist our QA team still uses." Beats: what the checklist checks, in your words; what QA does with it. Do not claim it stopped a bad announcement unless you saw that. If none did, say so. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4, the same sentence. Answer slot: if you changed the checklist after a gap, say what and why. If you did not, say so and say what you would check first. |

## Question banks

Ordered by weight. Each row's Provenance holds the sentences its guidance rests on.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your Outage Hour is a live-incident tabletop. Players report a reward-claim bug in the middle of a live event. Walk me through the first hour." | CASE | [generic] | Clarify scope, which event, how many players, which build. Set the objective: stop the harm and keep the event fair. Segment by platform and region. Decide triage, rollback or hotfix, and who you tell first. Name the metrics: affected accounts, duplicate rewards. Name the risks, and think aloud. Answer slot: if you have been in a live incident, say what you did; if not, say so and describe how you would run this one. | F11 is the interview's own format. The problem needs no claim about your past. |
| A2 | "Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February. What do you lock down in the first 90 days?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (Saltmarsh news, search snippet) | Clarify who owns the calendar after the change. Sequence the first 90 days. Name the metric you would watch first. Say what you would not change yet. Make no claim about this role's team. | The differentiator. Labelled `[grounded]`: the news is published, and the question makes no claim about you. |
| A3 | "Two weeks before a major drop, a feature slips. Both your titles' calendars depend on it. What do you move, and who do you tell first?" | JD | [generic] | Name what players will see first. Put players before the plan, per the values page. Name who must hear first and what they need. | A live problem from the JD's calendar line. |
| A4 | "Day-7 retention on the last drop fell four points against the prior drop. Diagnose it." | CASE | [generic] | Clarify the cohort definition. Segment by the drop's entry point. Check event timing. Name the assumption behind the baseline before the interviewer does. | F7's requirement, asked as a diagnosis rather than a record. |
| A5 | "The role owns the post-event review and its KPIs. Which three numbers go in every review, and what would make you call an event a miss?" | JD | [generic] | Name three kinds of number. Set the miss threshold before the event runs. Say what each number cannot tell you. | Straight from the JD's post-event line. No past claim. |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a player-facing call beat a plan you had." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Scaffold: a named plan, the player-side reason, and your part in the call, in your own words. If none comes to mind, say so plainly, then give the nearest thing your material carries: the retention numbers you presented. Answer slot: what the numbers showed, and what was done with them, if you know. If you do not, say so. | Players Before Plans. The theme comes from the company's own value. |
| B2 | "Tell me about a time something was announced before it was ready." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-map the checklist: you wrote it and QA uses it. Beats: what it checks, in your words; what QA does with it. Answer slot: if a release went out ahead of its checklist, say what happened and what you changed. If none did, say so, and say what the checklist is for. | Ship the Patch Not the Promise. F4 is your nearest sentence. |
| B3 | "What did you leave better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Checklist beats as in B2. Answer slot: if you changed the checklist after finding a gap, say what and why. If you did not, say so and say what you would check next. | Leave the Build Greener. |
| B4 | "Tell me about the last time you coordinated design, art, engineering and community on one update." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you coordinated any of those teams on an update, say which teams, what you asked of each, and what you did. If you did not, say so and say how you would start with each team. | F2, the JD's coordination line, raised by the JD. It is the one row with no quote beneath the claim. |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "a live-incident tabletop on a simulated outage during a live event, then a values conversation" (Saltmarsh careers page) | Name the weakest part honestly: the incident format, per F11. Answer slot: if you have run incident response, say what you did; if not, say so. Then a ramp plan, as a plan. Follow-up 1: "How would you learn it by month two?" Follow-up 2: "Who would you lean on?" Hold the plan; concede the specific gap. | **Highest-ROI prep.** The objection is the interview's own format, and F11 is the one row with nothing beneath it. Deepest rehearsal. |
| C2 | "I don't see team leadership in your background. How do you coordinate four functions you don't manage?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't led a team." Then the F2 answer slot. Do not reach for a leadership story. | F9 is the stated negative; F2 is where the probe lands. |
| C3 | "How does a content drop differ in a paid-currency game from a free one?" | CASE | [grounded] "never worked on a game with in-app purchases" | Live generic answer: currency, pricing pressure, what players see. If asked directly, the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan for learning it. | Tests the IAP gap without assuming it. The question itself asks nothing about your past. |
| C4 | "Why leave a puzzle studio for a 350-person mobile studio?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Answer slot: say your reason in your own words. The material you gave does not state one. Do not invent one. | Why-here is a standard Skeptic probe. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you counted the retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slots: if you know how each number was counted, say how. If not, say so. Name the assumption you would defend least. Say which part was yours. Presenting is not defining. | F7. Defend-the-number slots: the pack supplies no method. |
| D2 | "Which KPI in a post-event review would you drop first, and why?" | JD | [generic] | Name one KPI you would cut, and the decision rule behind it. No past claim. | The JD's KPI line. |
| D3 | "You ran the weekly content-drop calendar for two years. How did you decide what went into each drop?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map the calendar and the two years. Answer slot: if you set what went in, say how you decided. If the contents were set by someone else, say so and say what you did run. | F1 and F6. "Ran" is not "set": say which. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has led a team?" | Pressure | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses." | Pause, then restate. Hold: the checklist is yours to describe, in your quoted words. Hold through two follow-ups. Concede specifically: "I haven't led a team." Do not fold on the checklist. | F9 and F4. Hold-then-concede. |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it. Concede what QA changed after you wrote it. Answer slot: if QA changed it, say what. If they used it as you wrote it, say so. Never turn "wrote" into "designed the process". | F4. Attribution under pressure. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | Conversational | [grounded] "4 years as an associate producer at a puzzle-game studio" · "I ran the weekly content-drop calendar for our main title for the last two years." · "Wrote the release checklist our QA team still uses." · "Presented the monthly retention numbers to the studio head." | A 90-second arc, in that order, in your own words. Say what each did. Add nothing. | Casual openers are scored. |
| G2 | "What live game do you play, and what's one thing its events get right?" | Conversational | [generic] | Name a live game and one thing its events do well. If you don't play live games, say so. | Casual, but tests JD familiarity with live content. No past claim. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A2, A3, F1 row, D3 |
| Coordinate design, art, engineering and community on each update | B4, C2, F2 row |
| Own the post-event review and its KPIs | A5, D2, D1 |
| Manage the release checklist with QA | B2, B3, E2 |
| 3+ years producing live-service games or apps | — none, and why: the years are stated (F5). "Live-service" is an answer slot in F5, not a question. |
| Experience running a content calendar | D3, F6 row |
| Comfortable with player-retention metrics | D1, A4 |
| Clear written communication | — none, and why: the format is a live conversation. The checklist rows (B2, E2) carry the written artifact. |

## Reverse questions

Each has a why-it-lands line. Interviewer path: none verified, so none ties to his career; the rest tie to Saltmarsh's published facts.

1. "Tidepool Tactics and Lantern Row move to one shared calendar from February. Are those the two titles this role covers?" *Why it lands:* it signals you read the news, and it settles a mapping I have marked `[inferred]`: the two titles in the JD are probably these two.
2. "What does a strong Outage Hour look like to you, and what do you watch in the first ten minutes?" *Why it lands:* it asks him to show the bar for the format you are in.
3. "What does the single live-ops group own that the per-title teams did not?" *Why it lands:* it ties to the KPI and calendar ownership the JD gives this role.
4. "How do you see 'ship the patch, not the promise' working day to day?" *Why it lands:* it asks him to define a published value in practice.
5. "What would make you say this role is going well at six months?" *Why it lands:* it turns the close into a planning conversation.

## Sources

Provided documents: your message (the JD and your background) and the Outage Hour round details in it.

Searches and fetches, in order:

1. "Saltmarsh Games values": returned saltmarshgames.com/values. Fetched.
2. "Saltmarsh Games interview process live operations producer": returned saltmarshgames.com/careers/interviewing. Fetched.
3. "Saltmarsh Games strategy news mobile": returned saltmarshgames.com/news/project-larkspur (September 2026). Read from the search snippet, not fetched.
4. "Tobias Wrenfield Saltmarsh Games": returned a talk page, "Patch Notes Are a Promise (GDC 2026)", on talks.gdconf.example. Not fetched, and not used. The domain is not a verifiable GDC address, so the pack takes nothing from it. If you can confirm that talk yourself, tell me; it would change the interviewer read.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Values cheat sheet: three named values from the official page |
| 2. `{company} interview process {role family}` | yes | The loop: one 60-minute Outage Hour with the hiring manager. Sets personas, the Case and Values weights, and F11 |
| 3. `{company} strategy` / recent news | yes | Larkspur news: A2 (grounded CO), R1, R4. Read from the snippet only |
| 4. `{interviewer name} {company}` | yes | Returned an unverifiable talk page; nothing used. Moved nothing |
| 5. representative `{role title}` JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

Loop detection: the careers page establishes the loop: one session, with the hiring manager, holding a tabletop and then a values conversation. Values round detected.

Sections dropped by their conditions: prep triage (prep time not stated), graded deliverables (none declared), grounding brief (no L2 brief), reading the interviewer (no verified profile), delivery coaching (no assessment).

## Upgrade menu

- A deeper research pass (L2): Saltmarsh's strategy brief, Tobias's own talks and writing, loop reports for this role, and recent org changes. Up to 6 more searches and 2 more fetches, several minutes. Offered once. Want it?
- Confirm whether Saltmarsh's two titles use in-app purchases → changes C3 from a probe into a plan you can rehearse with specifics.
- Confirm the GDC talk, or paste Tobias's public posts → unlocks an interviewer read and tunes B-bank language.
- Your release checklist's section headings, if you can share them → B2, B3 and E2 become `[grounded]` with inspectable detail instead of a single sentence.
- Your recruiter's note on what the Outage Hour covers, if they sent one → tightens A1 to the scenario they actually use.
