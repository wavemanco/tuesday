# Ashgrove Credit Union, Member Experience Lead: interview pack (loop mode)

Candidate: Dara. Role: Member Experience Lead, Ashgrove Credit Union. Rounds on 26 November 2026, three in one day:

- **Round A:** recruiter screen, 30 minutes.
- **Round B:** Head of Member Services (your future manager), 45 minutes, mostly behavioural.
- **Round C:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores against the four published values.

First delivery, so there is no changelog. Interviewer names are not given, so there is no interviewer read; the upgrade menu says what names would add.

## How to use

Personas are how each question is asked. Types are what is being scored: VAL (values and behaviour), EXP (your own experience), JD (the role as posted), CO (company and strategy), CASE (a live problem). The guidance is scaffolding, not a script. Say it in your own words, and stop where the quotes stop.

## Fit snapshot (shared across rounds)

Evidence comes only from your message. Each quote is verbatim, and the quotes are the only things the guidance says about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Say the years as you gave them: six years in retail banking, the last three as a branch supervisor. The quote is limited proof, so expect a probe on what the years covered. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says formal complaints at branch level, not regulated complaints, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the posting names regulated complaints, so expect a probe on whether that log worked to rules or timescales set from outside the branch. If it did, say which and what you did. If it did not, say so plainly and describe how the log was kept. |
| F3 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: a monthly complaints spreadsheet that your regional manager uses. Say it in those words, and add no tools, features or figures that are not in the quote. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material shows a monthly spreadsheet and does not show which measures it carried. Answer slot: if it carried complaint volumes or resolution times, say which, and how each was counted, in your own words. If it carried neither, say so plainly and say which measure you would report first. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Your material shows training tellers on an escalation script, and three years as a branch supervisor. It does not show coaching supervisors, so the words stay at tellers: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor through an escalation, say what you did. If you did not, say so plainly and say how you would start. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | This row covers the branch part only. The words stay at branch scope: "I handled the branch's formal complaints log." Answer slot: if any complaint on that log went beyond your branch, say which and who else had a part. If none did, say so plainly. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show work with a digital team. Answer slot: if you worked with one on a member-facing change, say what it was and what your part was, in your own words. If you did not, say so plainly and say how you would begin. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your stated words: "I've never presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Do not add any senior presentation to your history. |
| F9 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated words: "I've never worked in a contact centre." Then how you would learn contact-centre work, said as a plan. Never a claim to contact-centre work. |

Gap type follows the evidence cell. F1 is none because the quote already reaches the requirement, and the length of experience is not a gate. No requirement in the posting is a gate, so none is surfaced as one.

## Prohibited claims (shared)

Each entry says what this pack will not coach, why, and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've run a contact centre" or any contact-centre experience | Stated negative: "Never worked in a contact centre" (F9) | "I've never worked in a contact centre," then a plan as a plan. No answer slot. |
| Any presentation to senior leaders | Stated negative: "I've never presented to anyone above regional level" (F8) | The plain acknowledgment, then a plan as a plan. No answer slot. |
| "I handled regulated complaints" | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." The limit is this pack's observation, in its own analysis: your material says the log, not regulated complaints. |
| "I owned the complaints process end to end" | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says one branch's log. |
| "I built the reporting on volumes and resolution times" | Inflated form of F4 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Which measures it carried is an answer slot, not a claim. |
| "I coached branch supervisors on escalations" | Inflated form of F5 | F5's quote at its own scope: "I trained new tellers on our escalation script." |

## Grounding brief (shared)

Your message gave a summary of the 2026 strategy brief, not the brief itself. Everything below is the recruiter's summary as you sent it. Nothing here is checked against the published document, so say these figures as the recruiter gave them.

- "move 40% of member service to digital channels by 2028" (your message). Used in round B, question B9.
- "consolidate eight branches into five hubs over 2027" (your message). Used in round B, question B8.
- "launch a small-business lending product in Q1 2027" (your message). Not used in a question. Know it in one line in case it comes up.
- "the main competitive pressure is app-only banks" (your message). Context for B9.

No stale framing was found in what you sent.

## Round A: Recruiter screen (30 minutes)

**Persona weights.** Conversational, weight 6: this is a friendly screen, and the logistics questions (pay, notice, location, reason for leaving) are knockout checks, which is where recruiter screens get scored. Light Skeptic, weight 2: the one stated gap is the first thing a screen tends to reach.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Opens with "walk me through," then asks logistics in a relaxed register | High. Recruiter-screen prior; the logistics are knockout checks | A 90-second arc from your quotes; logistics answered in your own words |
| Light Skeptic | "What's least like your current work?" | Medium. The contact-centre gap is stated, so a screen can reach it | Plain acknowledgment, then a plan as a plan |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career in customer-facing financial services." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | A 90-second arc in this order: six years in retail banking; the last three as a branch supervisor; the complaints log you handled; training new tellers on the escalation script; the monthly spreadsheet your regional manager uses. Stop at the quotes. | F1 is the evidence for the four-years requirement. The question is casual, but it is scored. |
| A2 | "Why this role, and why now?" | EXP | [generic] | Give your reason in your own words. Your material does not carry one, so there is no story to map. Name the part of this job you want to do, and say it plainly. | Motivation consistency is what a screen checks against your CV. |
| A3 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot. Give your own number, or say you would like the band first. Do not name a figure you have not set yourself. | Knockout check on pay. The answer is yours to give. |
| A4 | "What notice would you need to give, and when could you start?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. | Knockout check on notice. |
| A5 | "Where would you need to be based, and how often?" | JD | [generic] | Logistics slot. Say where you can work and how often, in your own terms. If the posting names a pattern, answer against it, and say plainly if it does not suit you. | Knockout check on location. |
| A6 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot. Give the reason you actually have, in one sentence, in your own words. Do not invent a reason that sounds better. | Reason for leaving is scored at screen. |
| A7 | "Which part of this role is least like the work you do now?" | JD | [grounded] "Never worked in a contact centre" (your message) | Say the stated gap plainly: "I've never worked in a contact centre." Then the nearest work your material carries, the complaints log in F2's words. Then how you would learn the contact-centre side, as a plan. | F9 is the stated gap, and a light Skeptic opens on it. This is the first sighting; round B is where it gets rehearsed. |
| A8 | "What are you using in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Story mapped on F3: what you built, and who uses it, in those words. Answer slot: if you used particular Excel features, name them in your own words. If the spreadsheet was built in another tool, say so. | F3 is the evidence for the Excel requirement, asked casually because it is a stated job term. |

### Reverse questions (round A)

1. "What does the Head of Member Services most need from this hire in the first 90 days?" Why it lands: it aims at the manager's real problem and shows you are planning for the job.
2. "How is the 2027 hub move being planned against complaints still open when a branch closes?" Why it lands: it ties to the strategy summary and to B8.
3. "Which of the four values is hardest to score for this role, and why?" Why it lands: it shows you know the panel scores values, and it asks where they expect the bar to sit.
4. "How are complaints counted at the moment, across branches and the contact centre?" Why it lands: it is the measure the reporting part of the job will sit on.
5. "What does a good month look like in this role?" Why it lands: it lets them define success in their terms.

## Round B: Head of Member Services (45 minutes)

**Persona weights.** Skeptic, weight 4: this is the future manager, and the stated gaps (contact centre, senior presentation, regulated complaints, scope) are what a manager checks before a hire. Values and Behavioural, weight 4: the recruiter says mostly behavioural. Case and Strategist, weight 2: the hub move and the digital plan are the live problems this role will face.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Goes straight to the contact-centre gap, then scope and senior presentation | High. The stated gaps are the first thing a manager derisks | Plain acknowledgment, then a plan as a plan. Hold through two follow-ups, then concede what you do not yet know |
| Values and Behavioural | "Tell me about a time…" questions, with STAR-shaped answers | High. The recruiter said mostly behavioural | Story from the quotes where one carries a story. Where none does, a selection scaffold ending in its honest branch |
| Case and Strategist | Hub consolidation and the digital plan | Medium. Strategy is in the recruiter's summary, so it is a fair question | Clarify first, then structure aloud, then name the risk |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns the member complaints process end to end across branches and the contact centre. You've never worked in a contact centre. What makes you the one to own it?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I handled the branch's formal complaints log" (your message) | Highest-ROI prep in this pack. Hold on the plain acknowledgment: "I've never worked in a contact centre." Then the nearest work your material carries, in F2's words. Then how you would learn the contact-centre side, as a plan, saying what you would learn first. Hold through two follow-ups by returning to the complaints log and the plan. Concede specifically what you do not yet know about contact-centre work. | F9 is the stated gap, and this is the probe most likely to come in some form. |
| B2 | "Your complaints work sat in one branch. Did any of it go beyond that branch?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if any complaint on the log went beyond your branch, say which and who else had a part. If none did, say so plainly and describe how the log was handled inside the branch. Hold by returning to the log. | F6 is the scope gap, and the probe lands on it. |
| B3 | "You'd present monthly to senior leaders. You haven't presented above regional level. How would you do it?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan as a plan: what you would do before the first senior presentation, in your own words. Keep the plan about preparation, not history. Concede the part you expect to find hardest. | F8 is the stated gap. The question's premise is the posting's own line. |
| B4 | "The role handles regulated complaints. Did your branch's formal log work to rules set from outside the branch?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if it worked to rules or timescales set outside the branch, say which and what you did. If it did not, say so plainly and describe how the log was kept. | F2 is the evidence, and "regulated" is the word the log does not show. |
| B5 | "Tell me about a complaint you had to escalate past your own authority. What did you do?" | VAL | [grounded] "trained new tellers on our escalation script" (your message); [grounded] "the last 3 as a branch supervisor" (your message) | Open prompt. Pick a complaint you escalated, and tell the steps in order. Answer slot: if none comes to mind, say so plainly, then give the nearest thing your material carries, training new tellers on the escalation script, and how you would handle an escalation now. | The posting asks you to coach on escalations, so escalation is a raising source for this open prompt. |
| B6 | "When have you coached someone else through an escalation?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you coached anyone through an escalation, say what you said and what they did. If you trained tellers on the script, say what that looked like, and say plainly if you did not coach supervisors. | F5 is the transferability gap. Stay with what you did, not what a supervisor would need. |
| B7 | "Tell me about a time you delivered an unpopular truth to your manager." | VAL | [generic] | Selection scaffold: pick a time you told someone above you something they did not want to hear, with a stake that was real, a moment you did not fold, and a working relationship at the end. If no such time comes to mind, say so plainly, then say how you would handle it. | Stem from the values persona. Your material carries no such story, so the guidance is a scaffold with its honest branch. |
| B8 | "Eight branches are moving into five hubs over 2027. A complaint from a branch that is closing is in your queue. What happens to it?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your message, the strategy summary); scenario [generic] | Structure: clarify whether the complaint's deadline runs past the closure date and who holds it during the move. Objective: the member gets an answer on time and the file is right. Approach: one named owner, a call to the member today, the file checked, the decision recorded. Name a regulator's timescale only if you have checked it. | Live problem from the strategy summary. The guidance asks no claim about your past. |
| B9 | "Digital is meant to take 40% of member service by 2028. Which complaints will it not reach?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message, the strategy summary) | Name the complaints a self-service journey cannot close, the ones that need a judgement or a decision. Say what you would check before you believed the 40% holds for complaints. Stay with the recruiter's summary and do not add figures. | CO question grounded in the strategy summary. The recruiter's line is the raising source. |
| B10 | "Tell me about a time you worked with a digital or app team on a change for members." | JD | [generic] | Answer slot: if you worked with a digital team on a member-facing change, say what the change was and what your part was, in your own words. If you did not, say so plainly, and say how you would begin with the digital team in this role. | F7 is silence in your material. The question is asked because the posting names digital teams. |

### Reverse questions (round B)

1. "Which parts of end-to-end complaint handling sit with branches today, and which with the contact centre?" Why it lands: it finds the seam, and shows you are thinking about the job's real split of work.
2. "Where do members get stuck in self-service journeys now, from the complaints you see?" Why it lands: it ties your question to the digital plan and to what the manager already sees.
3. "What did the last person in this role leave unfinished?" Why it lands: it shows you are thinking about handover, and it may name the first problem to own.
4. "How do you want supervisors to learn escalations: by example, by script, or by review?" Why it lands: it reveals the manager's coaching approach, which is the posting's own line.
5. "How would you know, six months in, that the coaching had worked?" Why it lands: it asks for a measure, which is the reporting side of the role.

## Round C: Panel of two branch managers (60 minutes)

**Persona weights.** Values and Behavioural, weight 4: the panel scores against the four published values, so each value gets one question. Peer Evaluator, weight 2: both panellists are branch managers, so the seam and credit questions come collegially. Data-Driven Prober, weight 2: the spreadsheet is the one figure you named. Case and Strategist, weight 2: the 20-minute escalation case.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioural | One question per published value, scored | High. The recruiter says the panel scores against the four values | Story from the quotes where one carries a story. Where none does, a selection scaffold and its honest branch |
| Peer Evaluator | Seams between branches and the contact centre; who gets the credit | Medium. Branch managers, so the hire touches their load | Reciprocity: what you bring their team. Propose seam principles, not a known seam |
| Data-Driven Prober | Asks how the spreadsheet counted things | Medium. You named one figure-producing tool | Name the assumption you would defend least. Say plainly when you do not know how a figure was counted |
| Case and Strategist | The 20-minute escalation case | High. The recruiter named it | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise |

### Values cheat sheet

The panel scores against these four values, in the words the company published (your message, copied from ashgrovecu.org/about/values on 17 November 2026). Each value has a mapped story where one of your quotes carries one. Where none does, a selection scaffold ends in its honest branch.

| Value (official name) | Working meaning (paraphrase) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quote carries a member-side decision. Scaffold: pick a decision where you chose the member's side over a process rule, and say what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, the wording was wrong. | The nearest quote is "I trained new tellers on our escalation script" (F5). Scaffold: pick a time you changed how something was explained so it landed first time. If none comes to mind, say so plainly, then say how you would know a script has landed. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quote carries a local story. Scaffold: pick a complaint where something local mattered more than a figure. If none comes to mind, say so plainly, then say how you would weigh a town's view of its branch against a target. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | The nearest quote is "I handled the branch's formal complaints log" (F2), which does not say the complaints were solved. Scaffold: pick a complaint you kept hold of until it was solved. If you passed one on before it was solved, say so and why. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a decision you made from the member's side of the counter, even though the process pointed the other way." | VAL | [generic] | Selection scaffold for Members First, Always. Pick a decision, with the stake and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries. | The panel scores this value. Your material carries no member-side decision, so there is no story to map. |
| C2 | "Tell me about a time you had to explain something so that a member or colleague did not need it explained twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you changed how a script or explanation was given so it landed first time, say what changed. If you did not, say so plainly, and say how you would know a script had landed. | Plain Words. F5 is the nearest quote, and it does not show a rewritten explanation. |
| C3 | "Tell me about a complaint where something local mattered more than the numbers." | VAL | [generic] | Selection scaffold for Neighbours, Not Numbers. Pick a complaint where a local detail changed the answer. If none comes to mind, say so plainly, then say how you would weigh a town's view of its branch against a target. | The panel scores this value. No quote in your material speaks to it. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Story mapped on F2, but the quote does not show a complaint carried to a solution. Answer slot: if you kept a case until it was solved, say what held it open and what closed it. If you passed one on before it was solved, say so and why. | Own the Fix. The question's premise is the value's own wording, which the panel is entitled to ask. |
| C5 | "Our teams sit side by side. Where's the seam between branch and contact-centre complaints, and what happens when you disagree?" | JD | [generic] | Propose seam principles rather than pretending to know their seam: a single owner per complaint, and a rule for who calls the member. If you have sat on a seam like this, say where. If not, say what you would ask both teams first. | The posting's end-to-end line, asked collegially. No claim about your past. |
| C6 | "How do you handle credit when a complaint is fixed by two teams?" | JD | [generic] | Reciprocity framing: what you would bring their teams, not only what you need. Say who gets the member's thanks, and that you would make it visible to both teams. | Peer credit probe. Pattern for the question, not a fact about you. |
| C7 | "Walk me through the monthly complaints spreadsheet. What did you count, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: say what it counted, in your own words. If you cannot say how a figure was counted, say so plainly. | F4's gap. The question asks what the spreadsheet did and does not presuppose a measure. |
| C8 | "If your spreadsheet carried a resolution time, which assumption behind it would you defend least?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if it carried resolution times, name the assumption you would defend least. If it carried none, say so plainly and say which measure you would add first. | F4 again. The question is conditional, so it asserts no measure. |
| C9 | "A member says a fee was taken twice. The branch says the fee is right, and the contact centre says the branch's file is wrong. It is now past its target time. Talk us through the next hour." | CASE | [generic] | Structure aloud: clarify the fee, whose file, the target time and what happens when it is missed. Objective: the member gets an answer on time, and the file is right. Segmentation: who owns the fix now. Approach: one owner, a call to the member today, the file checked, the decision recorded. Metrics: time to first update, and how many come back. Do not name a regulator's timescale you have not checked. | The 20-minute case. The scenario is the panel's, and it asserts nothing about your past. |
| C10 | "The branch manager asks you to back the branch. What do you say?" | CASE | [generic] | Challenge one premise respectfully: the question is what the member needs, not whose side you take. Hold the position through two follow-ups by returning to the owner and the call to the member. Concede specifically what you would need to check before you decided. | Case follow-up. This is where a peer panel pushes on the seam. |

### Reverse questions (round C)

1. Reciprocity: "What could a new person do in their first month that would genuinely help your team?" Why it lands: branch managers are your peers here, and this asks what they need, not what you want.
2. "Where do complaints most often stall between your branch and the contact centre?" Why it lands: it finds the seam from the branch side.
3. "When two branches disagree about who owns a complaint, what happens?" Why it lands: it shows you are thinking about the handoffs the role will own.
4. "How do the four values show up in what your branches score on a complaint?" Why it lands: it asks how the panel itself reads the values in practice.
5. "What is the one thing about complaints in your branch that the monthly figures don't show?" Why it lands: it invites their own knowledge, and it shows you read the figures as a starting point.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, B2, C5, C6 |
| Report monthly on complaint volumes and resolution times | C7, C8 |
| Coach branch supervisors on escalations | B5, B6 |
| Work with digital teams on self-service journeys | B9, B10 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B4, B2 |
| Confident presenting to senior leaders | B3 |
| Comfortable with Excel reporting | A8, C7 |
| Published value: Members First, Always | C1 |
| Published value: Plain Words | C2 |
| Published value: Neighbours, Not Numbers | C3 |
| Published value: Own the Fix | C4 |
| Pay, notice, location and reason for leaving (recruiter screen) | A3, A4, A5, A6 |

No requirement is left without a question.

## Sources

- **Provided documents:** your message. It holds the job description, the values copied on 17 November 2026 from ashgrovecu.org/about/values, the recruiter's round description, a summary of the 2026 strategy brief, and your background.
- **Research tier:** L1, with no searches run. Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove values | skipped | Values cheat sheet, round C. The values were pasted in your message, so there is nothing to fetch |
| 2. ashgrove interview process | skipped | Round structure and persona weights. The recruiter's email names the three rounds and who runs each, which establishes the loop |
| 3. ashgrove strategy and recent news | skipped | Grounding brief, B8 and B9. The strategy summary in your message is under six months old |
| 4. interviewer name and Ashgrove | n/a | No names were given for the Head of Member Services or the branch managers, so there is no query to form. The upgrade menu says what names would unlock |
| 5. representative role JD | skipped | The job description was supplied, so it fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The Head of Member Services' name and the two branch managers' names → an interviewer read, persona weights for each panel member, and a reverse question tied to each one's career path
- The full 2026 strategy brief in place of the summary → a grounding section with current figures, and CO questions in the brief's own wording
- Your CV, or any figures the complaints log produced → more quotes for F4 and F5, and F4 moves from low to medium if the CV names the measures
- Prep time before 26 November → a prioritised schedule for the three rounds
- The recruiter's note on any round's focus areas → a check of the coverage against what the recruiter says each round will test
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes → the public talks of panel members once they are named, and role-family loop reports for this employer. Want it?
- A tuesday-dossier.md from an earlier session, if you have one → verified evidence and any claims you have already corrected, which would bind every line of this pack
