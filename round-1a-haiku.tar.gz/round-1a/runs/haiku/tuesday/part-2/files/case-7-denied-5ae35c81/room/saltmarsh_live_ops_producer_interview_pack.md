# Saltmarsh Games: Live Operations Producer, interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games (mobile, about 350 people). Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring-manager round, not yet confirmed. Date: Friday 20 November 2026, 60 minutes.

## How to use and type key

Personas are how a question is asked. Types are what it scores.

- CASE: a live problem from the role, solved aloud. Scores structure and reasoning.
- EXP: a question about something you did. Scores whether it holds up under scrutiny and whether it was really yours.
- JD: a question about a stated requirement of the posting. Scores whether you can do the listed job, gaps included.
- CO: company and strategy knowledge. Not covered here, because research did not run (see Sources).
- VAL: behavioural, against published values. Not covered here, because no values round is detected.

Guidance is scaffolding, not a script. Say it in your own words, and say only what you did.

## Prep triage

You have three days. Spend them in this order.

1. B1, the post-event review question. It is the most likely hard probe, and your material does not yet answer it. Decide honestly what you owned, and rehearse both branches out loud.
2. The F1, F3 and F5 bridges. Say the quoted sentences in your own words, aloud, until they come without hedging.
3. A1 and A4. Build a two-minute retention-drop plan from what you have done, and name the first 72-hour metrics you would watch.
4. B2 and B3. Practise the two plain acknowledgments, "I have never led a team" and "I haven't worked on a game with in-app purchases", then say what you would do about each.
5. Everything else is insurance.

## The fit snapshot

Requirements come from the JD you supplied. Evidence is quoted from your own message. No requirement in this table is a hard gate: the material shows no location, work-authorisation or schedule term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and a weekly content-drop calendar. The posting asks for live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD raises live events on two titles, so expect a probe on the second. If you planned anything beyond weekly drops, or worked on a second title, say what and your part; if not, say so and say how you would run two calendars. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | discovery | [grounded] | discovery | Your material does not show cross-team coordination on an update. Answer slot: if you coordinated design, art, engineering or community on a drop, say which, and how; if you did not work across those teams, say so and say how you would set up an update. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote or chose a post-event review, say which and how; if none was yours, say so and say what you did with the numbers. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Bridge: "I wrote the release checklist our QA team still uses." Showing the checklist itself would raise this to high confidence. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The years meet the requirement. Your material does not say the title was live-service. Bridge: "Four years as an associate producer at a puzzle-game studio." Answer slot: the posting names live-service, so expect that probe. If the title took ongoing updates after launch, say what they were and your part; if not, say so and say what the content-drop work was. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Bridge: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches retention reporting. Bridge rewords only that quote: "I presented the monthly retention numbers to the studio head." No figure was given, so no defend-the-number slot is raised. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | A written artifact in use by another team. Bridge: as F4. |

## Prohibited list

Each entry names its basis and its honest form. No answer, bridge or rationale in this pack asserts a listed claim.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The limit is the pack's own observation: your material says the numbers, not the review. B1's slot stays inside that scope. |
| Ran the live-events calendar across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: one title is in your material. |
| The puzzle title was live-service | Inflated form of F5 | "4 years as associate producer at a puzzle-game studio." The material says content drops, not the live-service term. B4's slot asks what the title did after launch. |
| Led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I have never led a team." No slot. |
| Experience with in-app purchase games | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Persona weights

No round type or interviewer profile was given, so the relationship is assumed as a hiring-manager round. The fallback archetype is Generic (screen, hiring manager, panel), with flat weights said plainly, because no loop source established the loop.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | Live problems on the live-events calendar and cross-team update coordination | Highest. A Head of Live Operations is buying the ability to run the calendar, so expect a live plan. | Clarify, then structure, then name the metrics you would watch. Use only what you have done in the anecdotes. |
| Skeptic (weight 4) | Probes the gaps: leadership, in-app purchases, live-service | High. The posting and your material diverge at three points: F5, F2 and the leadership and purchase negatives. | Acknowledge each gap in one plain sentence, then move to the ramp plan. |
| Data-Driven Prober (weight 4) | Asks how the retention numbers were counted and what you owned | High. Retention is a named requirement, and F3 and F7 are the figures the posting will test. | Say plainly what you know about how numbers were counted, and whose definitions they were. |
| Pressure / Stress (weight 3) | Time-boxed challenge on leadership and on the review | Medium. Plausible at a senior level. | Pause, hold the quoted position through two follow-ups, then concede the exact uncertainty. |
| Conversational / Rapport (weight 2) | Open biography and "what are you playing" | Medium. Casual openers are still scored. | Prepare a 90-second arc from quoted sentences only. |

Session total: 18 questions, within the 18 to 26 range.

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would plan the next two months of live events for a title whose retention is falling." | CASE | [generic] | Clarify what falling means and for which cohort. Then objective, segments, event options, metrics and risks. Name the first metric you would check. | Covers the calendar requirement. A live problem, so it makes no claim about your past. |
| A2 | "An event lifts engagement but doubles support tickets. What do you do next?" | CASE | [generic] | Clarify what counts as a lift. Check what the release checklist did and did not catch. Involve community and set a decision point. | Covers the post-event review requirement. A problem from the role. |
| A3 | "We want a joint update for both titles in one month. Walk me through who you bring in, and when." | CASE | [generic] | Sequence the design, art, engineering and community inputs, then the decision points where a drop could slip. | Covers F2's requirement as a live problem, with no claim about your past. |
| A4 | "Which metric would you watch in the first 72 hours after a live event, and what would make you roll it back?" | JD | [generic] | Name two or three metrics, a threshold for each, and who owns the rollback call. | Covers the KPI requirement. The answer is a plan, not a record. |
| A5 | "A design lead wants a feature that engineering says takes three weeks, and the date is fixed. What do you do?" | CASE | [generic] | Clarify what can be cut or moved. Bring the two leads together with the date as the fixed point. Decide and record the call. | Cross-team conflict, a common live-ops problem. No claim about your past. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Highest-ROI prep. "Tell me about the last time an update's results were reviewed. What did you own?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Open prompt. The hold is only the quoted sentence: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote or chose the review, say which and how. If none of it was yours, say so plainly, and say what you did with the numbers you presented. Hold through two follow-ups by returning to the numbers, never by adding to them. | F3 is where the post-event review requirement presses hardest, so this objection will arrive in some form. JD because it scores a stated requirement. |
| B2 | "You have never led a team. Why should we trust you to coordinate four functions with no authority over them?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I have never led a team." Then say what you did coordinate, at its own scope, using F4 and F8. Then the ramp plan. | Not a JD line, but the likely probe from the Skeptic. The acknowledgment is your own statement. |
| B3 | "You haven't worked on a game with in-app purchases. What would you need to learn first?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then name what you would learn first, as a plan, not a past. | Not a JD line. Mobile studios often probe monetisation, so this is the inferred likely objection. |
| B4 | "The role asks for three years of live-service work. Your four years were at a puzzle studio. Was that title live-service?" | JD | [grounded] "4 years as associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if the title took ongoing updates after launch, say what they were and your part. If not, say so and say what the content-drop work was. Do not use the phrase live-service about the title unless you can say what it meant. | F5 is the requirement the posting presses on. Premise is the JD's, so the second branch allows it to be false. |

### Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which retention number did you present most often, and how was it defined?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the definition if you know it. If you did not set it, say whose it was. No figure was given, so the slot is the definition alone. | F7. Probers ask for the definition before the number. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the assumption you know of, in your own words. If you do not know how it was counted, say so. | F7. A standard prober move, and an honest "I don't know" is an acceptable answer. |
| C3 | "How did you decide what went into a drop, and what did you check afterwards?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say which content decisions were yours and what you checked after a drop. If others set the scope, say whose decisions were yours. | F1 and F6. Tests whether "ran" means set or only executed. |
| C4 | "Tell me about a release where the checklist caught something." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. Answer slot: if a release where the checklist caught something comes to mind, tell it in your own words. If none does, say so, then say how the checklist is used now. | F4. Open prompt, so no event is supplied. |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team over someone who has?" | EXP | [grounded] "Never led a team" | Plain acknowledgment: "I have never led a team." Hold the position that the role's coordination work is what you have done, using F4 and F8 at their own scope. Concede the leadership gap explicitly after the second follow-up. | Hold then concede. The held position must be one your quotes carry. |
| D2 | "That retention result: which part of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name your part at the quote's scope: you presented the numbers. If you produced the analysis, say so. If not, say so. | F7. A stress version of C1 and C2. |
| D3 | "You were an associate producer for four years. What decisions did that title let you make alone?" | EXP | [grounded] "4 years as associate producer at a puzzle-game studio." | Hold: name the content-drop calendar as the decision you ran, using F1's quote. Concede: the title's decisions beyond that were not yours to make. | F5 and F1. Tests the seniority of the work. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "4 years as associate producer at a puzzle-game studio." | A 90-second arc from quoted sentences only: the studio, the calendar, the checklist, the retention reporting, and why this role. | Casual openers are scored. The arc is pre-scripted, not improvised. |
| E2 | "What are you playing in mobile at the moment?" | CO | [generic] | Name one mobile game you play, with your own reasons. Make no market claims. | Scored as interest. Pattern only, no fact about the company. |

## Coverage line

- Plan and run the live-events calendar for two titles: F1, A1, C3. Two-title coverage is answer-slot material only.
- Coordinate design, art, engineering and community on each update: F2, A3, A5.
- Own the post-event review and the KPIs it reports: F3, B1, A2, A4.
- Manage the release checklist with QA: F4, C4.
- Three years of live-service work: F5, B4, D3.
- Experience running a content calendar: F6, C3, E1.
- Player-retention metrics: F7, C1, C2, D2.
- Clear written communication: F8 only. No question covers it, because a conversation shows little of writing. Your checklist is the artifact to show.
- Not in the JD: leadership (B2, D1) and in-app purchases (B3), both included as likely probes.

## Reverse questions

Each has a reason it lands. Six in all; no interviewer profile, so none ties to Tobias Wrenfield's own career path.

1. "How often does the calendar change across the two titles today, and what sets the cadence?" Shows you have read the posting. Lets them name the current pattern.
2. "Where does the post-event review sit now, who writes it, and who reads it?" Shows you know the review is owned, and asks who owns it.
3. "When a drop slips, how do design, art, engineering and community learn about it, and who makes the call?" Tests the coordination model without accusing it.
4. "What would the first 90 days need to look like for this role to be working?" Signals a planning mindset.
5. "Which of the two titles is more at risk on retention right now, and what is the plan?" Asks a live question and shows you think in metrics.
6. "How does the monetisation side of the calendar work, and where does this role fit into it?" Surfaces your in-app purchase ramp in a question, not a confession.

## Sources

Provided documents: the job description and background in your message. No other documents were supplied.

Research tier: L0 (intended L1; every search was refused by the host, so nothing was found). Searches 4 of 6, fetches 0 of 2.

Searches sent, all refused by the host's permission setting:
- "Saltmarsh Games values": refused.
- "Saltmarsh Games interview process Live Operations Producer": refused.
- "Saltmarsh Games mobile studio strategy news": refused.
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section 10. Not produced anyway, because no values round is detected. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure and persona weights. Weights stay on the Generic archetype, flat and said plainly, until a loop source is found. |
| 3. Saltmarsh Games strategy | unavailable | Grounding brief and CO questions. CO questions are generic, so only E2 is included. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and a tailored reverse question. Both absent. |
| 5. Representative Live Operations Producer JD | skipped | Your JD fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The round type and who is on the call. This sets the relationship, and with it the persona weights and reverse questions.
- Permission to run the four searches above. Then the values, the loop structure and the interviewer's public footprint could be added, and a tailored reverse question written.
- The title's launch model: whether it took ongoing updates after launch. This settles F5 and B4.
- The release checklist, if you can share it. This raises F4 to high confidence.
- Whether you owned a post-event review. This settles the B1 slot and the F3 bridge.
