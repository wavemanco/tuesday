# Priya: Senior GTM Strategy Lead, Emerging Products, Northwind Data — interview prep pack

**Round:** 60-minute single conversation with Dan Kovac, Director of Sales Strategy. Dan is a **peer**, reporting to the same VP.
**Built on:** your message (JD highlights, Priya's background, your research note, Dan's profile). No full JD text and no CV were supplied. Web search was refused in this session, so values, loop structure and Dan's public footprint are not established (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values alignment · **EXP** work-experience deep-dive · **JD** role/JD-driven · **CO** company and strategy knowledge · **CASE** live problem.
- Provenance: **[grounded]** traceable to your message or research note · **[inferred]** derived from a stated fact or the role · **[generic]** a pattern with no claim about Priya or Northwind.
- Guidance is scaffolding, not a script. Answer slots are instructions for the interview. They ask nothing of you here.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — your message (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — your message; "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material shows product strategy, operations and a revenue model. It does not show go-to-market ownership of a product line. Words: "Nine years at a large consumer-tech company in product strategy and ops." Answer slot: if any go-to-market decision for a product line was yours to make, say which and how you decided; if none was, say so and stay with the strategy and ops work. |
| F2 | "identify whitespace across land/adopt/expand/renew" — your message (JD highlights) | "set annual volume targets with cross-org consensus" — your message | low | [inferred] | discovery | The material shows volume targets, not whitespace. Answer slot: if you have identified a gap in land, adopt, expand or renew, name the motion and what you found; if you have not, say so and say how you would find it. |
| F3 | "run independent analysis in SQL and Tableau" — your message (JD highlights) | "skilled in SQL/Tableau" — your message | medium | [grounded] | none | Confirmed skill, no inspectable artifact. Expect a probe on what you have run yourself. |
| F4 | "partner-motion design experience required" — your message (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material shows a partner-level revenue model, not a partner motion. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you designed any part of a partner motion, say which; if the model was built for negotiations and you did not design the motion, say so. |
| F5 | "strong cross-functional influence" — your message (JD highlights) | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Words: "I set annual volume targets with cross-org consensus." Lead with the consensus, in those terms. |
| F6 | "AI experience a plus" — your message (JD highlights) | "uses AI tools daily" — your message | medium | [grounded] | presentation | Words: "I use AI tools daily." Expect a probe on which tools and for what, answered in your own words. |
| F7 | Sales-ops and quota-setting (not a JD line; your message, and the peer's team's domain) | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A stated absence. Words: "I haven't done classic sales-ops or quota-setting." Then the nearest thing your material carries, at its own scope: "I set annual volume targets with cross-org consensus." Then how you would learn quota-setting, said as a plan, never as a past. |
| F8 | None in the JD highlights. Headline figure on the CV-style summary (your message) | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | discovery | A headline figure with no stated method. Answer slots: the defend-the-number questions in bank A (how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours). |

**Requirement coverage.** Every JD highlight maps to at least one question. The one that was missing, the whitespace line, now has C4.

| Requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | C2, A3 |
| identify whitespace across land/adopt/expand/renew | C4 |
| run independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | A3, D2 |
| strong cross-functional influence | A4, B2 |
| AI experience a plus | G2, D3 |
| Sales-ops and quota-setting (not a JD line; the peer's domain) | D1, E1 |

## 6. Grounding brief (from your research note)

Used as provided. Your note's date was not given, so confirm it is under six months old before the interview. Nothing here was checked against a public source in this session.

- Stated priorities: enterprise expansion; an AI copilot launch ("Compass"); reaching profitability. — your message
- Main competitive threat: bundling by a much larger platform vendor. — your message

## 7. Reading the interviewer

**Dan Kovac, Director of Sales Strategy (peer).** From the profile you gave:
- Career spine: pricing and monetization roles, plus one early-stage startup chapter.
- Self-described as "relentlessly data-driven."

Practical implications:
1. Every metric Priya gives will be probed to its assumptions. Know the weakest one before he asks.
2. Case questions will lean toward pricing, packaging and unit economics. That is his native language.
3. The startup chapter means builder stories land with him, and he may test for scrappiness.
4. Shared professional path: his monetization spine sits closest to the revenue-model sentence (F1 and F4). That is the honest mirror to use. Do not invent a shared jump, since Priya has no startup chapter.

Public footprint was not searched (refused). Anything beyond your profile text is unknown here.

## 8. Persona table

Weights reasoning: the relationship prior for a peer round is Peer Evaluator and Data-Driven Prober. Dan's self-described "relentlessly data-driven" and his pricing spine raise the Prober and Case weights. The loop is not established by any source, so there is no named round to tune to. Persona weights therefore rest on the peer prior and the profile, not on this company's documented process. Depth follows weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| A. Data-Driven Prober | Attribution probes on the $400M figure, the model and the analysis | High. Peer prior plus his self-description. Top weight | Know how each figure was counted, or say plainly you do not know. Name the weakest assumption first | 5 |
| B. Peer Evaluator | Seam questions, disagreement, credit, what he would need from her | High. Peer prior. Second weight | Reciprocity: what she brings his team, not only what she needs | 4 |
| C. Case/Strategist | Bundling threat, Compass pricing, priorities, whitespace | Medium-high. Pricing spine and your research note. Four questions, one above the mid-weight of 3, to cover the whitespace line | Clarify, then structure, then answer. Think aloud | 4 |
| D. Skeptic | Quota gap, partner-design gap, AI use | Medium. The two JD and peer-domain gaps are the likeliest objections | Rehearse the quota objection until it is plain. Calibrated candor, not bluffing | 3 |
| E. Pressure | "Why you over an internal candidate?" and "how much of it was you?" | Low-medium. No pressure signal in the profile, but the $400M figure invites it | Pause, restate, anchor in quoted sentences. Hold two follow-ups, then concede exactly | 2 |
| G. Conversational | Journey opener; AI "playing with" | Low, but scored casually. Two questions | A 90-second arc from quoted sentences only | 2 |
| Values / principles | Not detected | No loop source establishes a values round, and the generic fallback reads no. So no values cheat sheet | None | 0 |

**Protective mini-bank:** not requested, so omitted.

## 9. Question banks

Session total: 20 questions, inside the 18 to 26 range.

Every row's guidance rests only on the quoted sentence in its Provenance column. Where the guidance would need a practice, figure or event that no quote carries, it is an answer slot.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Say what you know about how the figure was counted, in your own words. Answer slot: if you know the counting method, say it; if you do not, say that plainly and do not reconstruct one. Name the part that was yours: the proposal is the part your sentence states | F8 is the headline figure and the likeliest probe. Every headline figure gets this slot |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Name the weakest assumption you know of before he does. Answer slot: if you know one, name it; if you do not know the assumptions behind the figure, say so. "I don't know how it was counted" is a valid branch | The weakest-assumption move converts a gotcha into credibility. Pairs with A1 |
| A3 | "Walk me through the partner-level revenue model you built. What was it used for, and which parts were yours?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — your message | Story map from the quote: you built it, it was a partner-level revenue model, it was used in carrier negotiations. Tell those beats in your words. Answer slot: if you chose its inputs or structure, say which and why; if they were set by others or were not yours, say so and describe what you did with the model | F4 is the partner-motion requirement. Premised only on the built model and its use |
| A4 | "Walk me through how you set annual volume targets with cross-org consensus." | JD | [grounded] "set annual volume targets with cross-org consensus" — your message | Story map from the quote: you set the targets, with cross-org consensus. Say which decisions were yours and who was in the room only if you can name them. Answer slot: if the consensus process changed a number, say which and how; if no number moved, say so | F5's requirement. Tests the cross-functional claim by asking for the mechanism |
| A5 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision. Take me through one end to end." | JD | [grounded] "skilled in SQL/Tableau" — your message | Selection scaffold: pick an analysis you ran yourself, from question to decision. If none changed a decision, say so and take him through the nearest one you ran. If you ran none yourself, say that plainly | Open prompt on the JD line "run independent analysis in SQL and Tableau." F3 is medium-confidence, so expect the follow-up |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your partner work and the sales-strategy team's work, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know his team's seam. Disagreement story: pick a time you disagreed with an equal and it went somewhere. If none comes to mind, say so and give the nearest one | Peer seam probe. The question is his team's, so the guidance makes no claim about Priya |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" — your message | Use "we" for context and "I" for what you did. Anchor on the quoted scope: targets set with cross-org consensus. Do not claim a credit split you cannot describe | Peer credit probe. F5 is the quote that carries the story |
| B3 | "What would you need from my team in your first month?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" — your message | Name the inputs you would need, and what you could offer back from the quoted work, in those terms. Reciprocity: what you bring his team, not only what you need | Peer reciprocity. Keeps the answer about his team, not her requirements |
| B4 | "Which of your team's current decisions would you want my input on first?" | JD | [generic] | Name the kind of decision and why your skill set fits it, without claiming a decision was yours. Keep it to the decision's nature, not your history | A peer conversation signal. Includes a reciprocity line the rubric asks for |

### C. Case/Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A larger platform vendor bundles a comparable capability into its suite. Where does that hurt us first, and what do you do in the first 30 days?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your research note | Clarify the objective. Segment by where the bundle lands. Propose a first-30-days approach and the metrics you would watch. Name one risk. Think aloud and challenge one premise respectfully | Live problem from the research note. Presupposes nothing about Priya's past |
| C2 | "Compass is an AI copilot launch across two new product lines. How would you price and package it?" | CASE | [grounded] "an AI copilot launch ('Compass')" — your research note; "own GTM strategy for two new product lines" — your message (JD highlights) | Lean on pricing, packaging and unit economics, his native language. Lay out the pricing options and what would decide between them. Do not claim a prior pricing decision | Dan's pricing spine makes this the likeliest case. Tilts toward his angle |
| C3 | "Northwind has three priorities: enterprise expansion, the Compass launch, and reaching profitability. If they conflict, which do you protect first?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — your research note | Commit to a position and name the trade-off. Connect it to a motion or a metric. No claims about your history | Company-altitude test built on the note. Dan's role makes this likely |
| C4 | "Where's the whitespace across land, adopt, expand and renew for a new product line?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" — your message (JD highlights) | Structure first: the four motions, then where each new product line would sit, then how you would size one gap. Do not claim a whitespace you have found | Covers the JD's whitespace requirement, which no other question reaches. F2 is low-confidence, so the answer is structure, not history |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You don't have sales-ops or quota-setting experience. How would you run a quota process for a team that does?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" — your message | Plain acknowledgment: "I haven't done classic sales-ops or quota-setting." Then the nearest thing your material carries, at its own scope: "I set annual volume targets with cross-org consensus." Then how you would learn quota-setting, as a plan | The single most predictable objection for this peer, from a sales-strategy team. Highest-ROI prep in the pack: rehearse until the acknowledgment is calm and brief |
| D2 | "Your JD asks for partner-motion design. Have you designed one?" | JD | [grounded] "partner-motion design experience required" — your message (JD highlights); "built a partner-level revenue model used in carrier negotiations" — your message | Answer slot: if you designed any part of a partner motion, say which and how you decided. If the model was built for negotiations and you did not design the motion, say so, and describe the model | F4. Premises only what the quote carries. The second branch allows that no motion was designed |
| D3 | "You say you use AI tools daily. What have you used them for in work you could show me?" | JD | [grounded] "uses AI tools daily" — your message | Describe your use in your words. Answer slot: if none of it is in work you can show, say so, and describe how you would use AI in a new product line | F6. The question asks for inspection, so the guidance says plainly what is and is not inspectable |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your message | Pause. Restate the question. Anchor in the quoted sentence. Hold the position that the nearest proof is the revenue-model and volume-target work, through two follow-ups. Concede exactly: "I don't have quota-setting experience, and I won't argue that away" | Pressure version of the sales-ops objection. Hold-then-concede, never folding on the core |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | Hold: "I proposed the change." Concede: if you cannot say how much of the uplift was yours, say that plainly, and say what you proposed and what you did after | Pressure on the headline figure. The hold is the quoted "proposed"; the concession is exact |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" — your message | A 90-second arc, one beat per quoted clause, in your own words. Nothing beyond the quotes | Casual but scored. Rehearse the arc so it is not improvised |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" — your message | Name the tools in your own words. Say what you use them for. Do not name a tool you have not used | F6. Asked casually, scored against the "AI a plus" line |

## 11. Reverse questions

Each one is for Priya to ask Dan. Why it lands is listed beside it.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent your career on pricing and monetization. Where do pricing decisions for new product lines get made today, and who makes the call?" | Ties to his own path. His native ground turns the interview into a peer conversation |
| R2 | "You spent time at an early-stage company. What from that would you want a team launching two new product lines to keep?" | Ties to his startup chapter. Shows you researched him, not only the company |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which the peer round calls for |
| R4 | "How is Compass's contribution to enterprise expansion measured in its first year?" | Tests the company's stated priorities. Shows you read the note, not the headline |
| R5 | "Which decision in the next two quarters would you most want a second pair of eyes on?" | Peer-level and specific. Opens the seam conversation from B1 |

## 13. Prohibited claims

Built locally from the fit snapshot. No dossier is present. Nothing in the answers may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | Quote: "9 at a large consumer-tech company in product strategy & ops." Analysis, in the pack's own words: your material says product strategy and ops, not go-to-market ownership |
| Designed a partner motion | Inflated form of F4 | Quote: "built a partner-level revenue model used in carrier negotiations." Analysis: your material says the model, not the motion |
| Has sales-ops or quota-setting experience | Negative Priya stated, F7 | Plain acknowledgment: "I haven't done classic sales-ops or quota-setting." No slot |
| Drove the ~$400M ARR uplift | Inflated form of F8 | Quote: "proposed a store-surface change credited with a ~$400M ARR uplift." Analysis: your material says proposed and credited, not drove |
| Led the cross-org consensus | Inflated form of F5 | Quote: "set annual volume targets with cross-org consensus." Analysis: your material says set with consensus, not led the consensus |

## 14. Sources

- **Provided:** your message. It carries the JD highlights (not the full JD text), Priya's background, your research note (priorities and the bundling threat), and Dan's profile (pricing and monetization spine, one early-stage startup chapter, self-described "relentlessly data-driven").
- **Searches sent, all refused:**
  - "Northwind Data values operating principles": refused
  - "Northwind Data interview process Senior GTM Strategy Lead": refused
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused
- **Fetches:** none sent.
- **Dossier:** none present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Refused. Would have set whether a values round exists and the values cheat sheet. Neither is produced |
| 2. Northwind Data interview process | unavailable | Refused. Would have named the loop, moving persona weights from flat to the named rounds |
| 3. Northwind Data strategy / recent news | skipped | Your research note supplies the priorities and the threat, which fix the CO bank's inputs |
| 4. Dan Kovac footprint | unavailable | Refused. Would have added talks and writing to the interviewer read and tuned reverse questions |
| 5. Representative JD | skipped | JD highlights were supplied, so the representative-JD target does not apply. Full text is still missing (upgrade menu) |

## 15. Upgrade menu

- **Full JD text** → the six JD-highlight rows (F1 to F6) become quoted from the posting, not from your note, and the JD-tagged questions can cite its lines.
- **Priya's CV** → the fit snapshot's evidence cells come from the CV, and any row an artifact backs can move to a higher confidence band.
- **Location and work-pattern terms from the JD** → if the full JD states any, they become gate rows, and each one gets its own question.
- **Web search allowed** → values, loop structure and Dan's public talks and writing become checkable. That would settle whether a values round exists and would sharpen his reverse questions. Without it, the persona weights rest on the peer prior and the profile alone.
- **Deeper research (offered once):** up to 6 more searches and 2 more fetches, several minutes. Only if search is allowed.
- **Confirm your research note is under six months old** → the grounding brief and C2 and C3 stay current.
