# Interview prep pack: Engineering Manager, Larkfield Systems

Loop mode: three rounds, one shared fit snapshot, a mini-pack per round, one shared upgrade menu.

- Round H: Hiring manager, Director of Engineering, Tuesday, 45 min
- Round P: Panel, two staff engineers and a product manager, Thursday, 60 min
- Round V: VP Engineering, "values and leadership philosophy", following Monday, 30 min

Built with no posting text, no CV file and no web research (see Sources). The role is taken from your own description.

## How to use + type key

Personas = how a question is asked. Types = what is being scored.

- **EXP**: work-experience deep-dive. Whether what you did survives scrutiny.
- **JD**: role-driven. Whether you can do the listed job, gaps included.
- **CASE**: live problem. Structure and reasoning.
- **CO**: company and strategy knowledge. Not covered here, because research was unavailable.
- **VAL**: values and behaviour. Past behaviour, not slogans.

Guidance is scaffolding, not a script. Answer slots are instructions for the interview: they are not questions to me.

---

## Sources

Provided documents: your message only (role description, background, the recruiter's words "values and leadership philosophy" as you relayed them). No posting text, no CV file, no dossier.

Web search was requested three times and refused by the host, so every research target below is unavailable. Nothing from memory was used for company facts.

Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0.

| Query sent | Outcome |
|---|---|
| Larkfield Systems values | refused |
| Larkfield Systems interview process engineering manager | refused |
| Larkfield Systems industrial IoT device management strategy | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (section 10) omitted: no published values in hand |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure comes from your message: three named rounds, each with who runs it, which establishes the loop. Archetype fallback not used |
| 3. Larkfield Systems strategy | unavailable | Round V's CO question (V6) is generic and labelled as such |
| 4. Interviewer name | n/a | No interviewer named, only titles. Interviewer read absent |
| 5. Representative JD for the title | unavailable | No call sent; the host refused search, and no posting was supplied |

Loop: established by your message, which names the three rounds and who runs each.

---

## Fit snapshot (shared across all rounds)

Requirements come from your role description, which is the only requirement text in hand. They are quoted from your message, so they are `[grounded]`. The posting text, when it arrives, may add rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says team lead of 6 for three years. It does not show leading more than one team. Answer slot: if you have led across more than one team, say how; if not, say so and say how you would split the work of two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message), hiring | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | none | Hiring is reached in role terms. Expect a probe on the 11, which the quote does not carry. Lead with the loop in your own words. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message), growth | none given | none | [grounded] | discovery | Your material does not show growing engineers. Answer slot: if you have run promotions, development plans or growth moves for people, say which; if not, say so and say how you would start. |
| F4 | "partner with hardware and product on roadmap" (your message) | "after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | "I pushed a reliability quarter through against roadmap pressure." That is roadmap negotiation in software, and it stays at that scope. Answer slot: if you worked with hardware or product on that roadmap, say how; if hardware was not part of it, say so. |
| F5 | "partner with hardware and product on roadmap" (your message) | "I've never managed managers and never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |

Two notes on the snapshot:

- **Managing managers is not a row.** Your role description does not say whether the two squads have their own leads. If they do, "I've never managed managers" becomes a live gap, and the VP and hiring-manager rounds will test it. See the upgrade menu.
- **Gate rows: none yet.** Location, office days and work authorization are not in your description. If the posting names any, they become gate rows, and the material would need to show them met.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" or "I managed 11 engineers" | Inflated form of F1 and F2 | "Team lead of 6," at its own scope. The limit is this pack's observation: your material says one team of six |
| "I've managed managers" | Stated negative, "I've never managed managers" | Plain acknowledgment: "I've never managed managers." No slot |
| "I've owned a hardware-adjacent roadmap" | Stated negative, F5 | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot |
| "I led a company-wide reliability programme" | Inflated form of F4 | "I pushed a reliability quarter through against roadmap pressure," at its own scope |
| The 60% as yours alone | Inflated form of the on-call quote | "My team's on-call burden dropped 60% after I pushed a reliability quarter through," with both halves kept |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| Lead two squads | H1, H4, V8 | Scope gap is the first thing the hiring manager will test |
| Delivery | H4, P5 | |
| Hiring | H8 | |
| Growth for 11 engineers | V7 | Partial: F3 is a discovery row, and V7 asks about managers, not engineers. No separate engineer-growth question, because the material does not show one |
| Partner with hardware and product on roadmap | H2, P1, P5, P6 | H2 is the highest-ROI prep in the pack |

---

## Round H: Hiring manager (Tuesday, 45 min)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the two gaps: scope and hardware | High. A hiring manager is buying capability and derisking the two gaps in F1 and F5 | Rehearse the single objection until it is plain: hold, then concede specifically |
| Data-Driven Prober | Counts the 60% | Medium. The number is on your CV and is the one thing they can test in 45 minutes | Know what you can and cannot say about how it was counted |
| Case/Strategist | A live problem on the two squads' roadmap | Medium. The role is described as roadmap work | Clarify before structuring |

Weights: Skeptic 4, Prober 2, Case 1, JD 1. Persona counts follow the 4 / 3 / 2 depth rule.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've led a team of six. What changes when you're leading two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Say what you have led, in those words: a team of six, for three years. Then say what you would change for two squads, in your own words. Answer slot: if you have led across more than one team, say how; if not, say so and say how you would split the work. | F1 is the scope gap; this is its likeliest probe |
| H2 | "Why should we expect you to partner on a hardware-adjacent roadmap?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Highest-ROI prep. Hold: "I haven't owned a hardware-adjacent roadmap." Then the nearest thing your material carries: "I pushed a reliability quarter through against roadmap pressure." Hold through two follow-ups by returning to that quarter. Concede the gap in one sentence, then a plan for learning it, said as a plan. Never describe hardware work you did not do | F5 and F4 meet here; the honest answer is the limit plus a plan |
| H3 | "Why leave payments for industrial IoT, and why now?" | EXP | [generic] | Name the pull toward this role in one sentence, from work you have done, not from the posting. If the pull is only the role, say that plainly | No quote carries a motivation; a motivation claim with no source is guidance resting on nothing, so it is a scaffold |
| H4 | "What would you do in the first 90 days across two squads?" | CASE | [grounded] "Lead two squads building device-management services" (your message) | Clarify first: what the hardware commitments are, how often you ship, and what the two squads look like now. Then structure. Make no claim about your past | Live problem on the role, presupposing nothing about you |
| H5 | "Walk me through how the on-call result was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Defend-the-number slot. Answer slot: if you measured it, say what you measured, over what period and from what baseline; if you did not, say so plainly. Name the weakest assumption you know of before they do | The 60% raises the defend-the-number slots. Attribution is the probe |
| H6 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] same quote as H5 | Name the weakest assumption in your own words. If you do not know how it was counted, say that; it is an honest branch | Metric questions include the weakest-assumption move |
| H7 | "You've never managed managers. What's the first thing you'd want to know before you did?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then the first thing you would check, as a plan | A stated negative the interviewer will raise; the answer is the limit and a concrete first step |
| H8 | "Walk me through how you run your hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | Tell the loop's stages as you run them, then the 40 interviews. Answer slot: for each stage, say which decisions were yours and which were the panel's. If the hiring decision was not yours, say so | F2 is covered; the probe is what was your call |

### Reverse questions

- "What does good look like for the two squads by month six?" Why it lands: it turns the scope question into a measurable one, and invites them to say what they expect.
- "Where do hardware dependencies most often slow the device-management roadmap?" Why it lands: it shows you know where the seam is, before anyone tells you.
- "What has the team tried in hiring that did not work?" Why it lands: it signals curiosity about the loop without asking them to defend it.
- "How is the hiring manager's time split between roadmap and people today?" Why it lands: it shows you are thinking about the job's shape, not just its title.
- "What would you want the new manager to take off your plate first?" Why it lands: a practical question that a would-be boss can answer.

Note: there is no interviewer profile, so no reverse question ties to their career path.

---

## Round P: Panel (Thursday, 60 min)

Two staff engineers and a product manager. Names are unknown, so personas are assigned per round rather than per person.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seams between squads and hardware, disagreement, credit | High for the staff engineers. They price what the hire does to their work | Propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Staff engineers test the reliability result | Medium. Two engineers with the same CV line will both read it | Name the baseline question before they do |
| Case/Strategist | The PM's roadmap trade-off | High for the PM. The role partners with product on the roadmap | Clarify the objective before deciding |

Weights: Peer 3, Case 3, Prober 2.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Where's the seam between your squads and the hardware team, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Describe a seam principle, not a claimed history. Then the quarter: the pressure was roadmap pressure. Answer slot: if you disagreed with hardware or product in that quarter, say how it ended; if hardware was not part of it, say so and give the principle you would use | F4 and F5 meet at the seam |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Use "my team's" for what the team did and "I" for what you pushed through. Say which is which | Credit-sharing probe on the quote's own split |
| P3 | "How would you know the reliability gain was real a year on?" | EXP | [grounded] same quote as P2 | Name what you would watch and what would change your conclusion. Answer slot: if you tracked anything over time, say what; if you did not, say so | Prober's test of a result with no follow-up on record |
| P4 | "What was the baseline the 60% is measured from?" | EXP | [grounded] same quote as P2 | Defend-the-number slot. Answer slot: if you can state the baseline, say it; if not, say so and say how you would check | The figure raises this slot, and nothing else |
| P5 | "Next quarter, product wants a feature and reliability work needs the same squad. How do you decide?" | CASE | [generic] | Clarify the objective, who bears the cost of delay, and what evidence would change the call. Make no claim about your past | Live roadmap problem, raised by the posting's partnership with product |
| P6 | "What would you need from product before committing a squad to a device-management feature?" | CASE | [generic] | Name the inputs in order: the customer problem, the dependency on hardware, and the cost of being wrong | Partnership question from the PM's side |
| P7 | "What would make you say no to a hardware team's request?" | CASE | [generic] | Structure a rule, then a test of it. Name what would make you revisit it | Tests whether you have a rule, not whether you have a story |
| P8 | "When a staff engineer disagrees with a roadmap call you've made, what happens next?" | EXP | [generic] | Say how you would test the disagreement, not who wins. If you have a real instance, use it in your own words; if not, say you would test it | Peer-collegial version of the roadmap pressure question |

### Reverse questions

- Reciprocity, because two of the interviewers are peers: "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: it turns the panel into a partnership conversation.
- "Where do staff engineers and product most often disagree about device-management scope?" Why it lands: it names the seam the panel will care about.
- "How much of the roadmap is fixed by hardware commitments?" Why it lands: it shows you understand the constraint before you have a view on it.
- "What would make the first quarter a success from your side?" Why it lands: it asks for the standard that the panel will judge against.
- "Where does the on-call load sit across the squads now?" Why it lands: it shows you are already thinking about the reliability work the panel will want to discuss.

---

## Round V: VP Engineering (Monday, 30 min)

Values and leadership philosophy, as the recruiter described it. This is a detected values-style round, from the recruiter's own words.

Values cheat sheet (section 10): omitted. Published values are not in hand, and the research that would have supplied them was refused.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…", leadership philosophy | High. The recruiter named this round | Map a story to each question where your material carries one; where it does not, select one and name the honest branch |
| Pressure | Challenges to the reliability result and to your stance | Medium. A VP tests composure on the one claim that carries the CV | Hold, then concede specifically |
| Case / Strategist | A trade-off between squads and hardware | Medium. Strategy is the VP's altitude; without research, the questions are generic | Name the trade-off before answering |

Weights: Values 4, Pressure 2, Case/CO 2.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold. The quote shows pushing a quarter against roadmap pressure. It does not show who you told or how. If you took it to leadership, say how; if the pressure came from elsewhere, say so and give the nearest moment you did take it up | Open prompt; the reliability quarter is the nearest story your material carries |
| V2 | "What's your leadership philosophy in a sentence, and what has tested it?" | VAL | [generic] | Give the philosophy in your own words and one moment that tested it. If nothing has tested it yet, say so | Open prompt; no quote carries a philosophy |
| V3 | "Your 60% — how much was your team's work, and how much was luck?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Hold: your team's work and the push both mattered. Concede specifically what you cannot separate. Hold through two follow-ups; do not fold on the core claim | Pressure question on the one number; hold-then-concede |
| V4 | "Why should I believe you'll hold a reliability line when the roadmap is pressing?" | VAL | [grounded] same quote as V3 | Hold the position through two follow-ups by describing what you did, then concede what is uncertain | Pressure on the stance the quote supports |
| V5 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need beat a metric you were tracking. If none comes to mind, say so plainly, then give the nearest thing your material carries | Open prompt; no customer story is in the material |
| V6 | "What is device management worth to an industrial customer, and where would you invest next?" | CO | [generic] | Structure the answer around the customer's cost of downtime. Make no claim about this company's strategy, because none was researched | Strategy altitude; generic because research was refused |
| V7 | "How would you develop a manager who reports to you?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then the first three things you would do, said as a plan | Stated gap; the VP will probe the manager layer |
| V8 | "Where would you draw the line between what a squad owns and what hardware owns?" | CASE | [generic] | Clarify ownership first. Then give the line and the test for moving it | Live problem on the role's partnership with hardware |

### Reverse questions

- "How do you define a leader who is growing in this company?" Why it lands: it asks for the standard, and tells the VP you are thinking about growth, not only delivery.
- "Where has the leadership philosophy been tested most recently?" Why it lands: it shows you know values are lived, not published.
- "What do you wish your engineering managers did more of?" Why it lands: a direct question about the job's gap, from someone who will judge the answer.
- "What is the hardest trade-off you expect the next engineering manager to make?" Why it lands: it signals you are ready for the hard part.
- "How do you want managers to handle a roadmap call that hurts reliability?" Why it lands: it connects your strongest story to the VP's own standard.

---

## Upgrade menu

- Full posting text → turns the requirement rows from `[grounded]` to quoted rows, and may add gate rows (location, office days, work authorization), which change the fit snapshot
- Whether the two squads have their own leads → decides whether "I've never managed managers" is a live gap, and reweights H7 and V7
- Approval to run web search again, for the three refused targets → published values for a values cheat sheet in round V, loop confirmation, and current strategy for V6 (currently generic)
- Interviewer names, one per round → personal persona weights, and a reverse question tied to each interviewer's path
- Any record behind the 60% (a dashboard export or on-call log) → raises the H5, H6, P3, P4 and V3 rows from `[grounded]` to inspectable, and makes defend-the-number answers specific
- The recruiter's note on what the VP values → sharpens V2 and V5 from `[generic]` to `[grounded]`
