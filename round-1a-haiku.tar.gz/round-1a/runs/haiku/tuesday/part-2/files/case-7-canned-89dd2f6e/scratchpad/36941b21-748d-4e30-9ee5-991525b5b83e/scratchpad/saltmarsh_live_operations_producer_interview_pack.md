# Interview prep: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not yet confirmed). Length: 60 minutes. Built on the JD and your message. No research was run.

## How to use

Personas describe how a question arrives. Types describe what is being scored. Type key:

- **VAL**: behavioural and values alignment
- **EXP**: your work-experience deep-dive
- **JD**: the role's stated responsibilities
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: answer it in your own words. Either branch it gives is an honest answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Your message gives the years and the studio type, not the words live-service. Say it in your terms: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: if the puzzle title had updates after launch, say what shipped and how often, in your own words. If it was a one-off launch, say so and say what you would bring to a live title. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The strongest match you have. Confirmed, but with limited inspectable proof, so expect a probe on it. Lead with the quote's own terms: "For two years I ran the weekly content-drop calendar for our main title." |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material covers one title. The two-title part is not in it, so the bridge stops at one. Answer slot: if you ever planned across more than one title, say how. If you have not, say so plainly and say how you would plan two calendars that share a team. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote shows you presented retention numbers. It does not show that you built or defined them. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: name the retention figure you used most, and what you could explain about how it was counted. If you could not explain it, say so. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you have run one, describe it in your own words. If you have not, say so and describe the structure you would use: what you would measure and what you would decide from it. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show cross-team coordination. Answer slot: describe how one update moved from plan to live across those four teams, in your own words. If others ran that coordination, say who did and what you did. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement. It says you wrote the checklist, not that you ran each release against it, so expect a probe on the ongoing part. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is written work that other people rely on. Bridge: "I wrote the release checklist our QA team still uses." The quote does not show how clear it was. |
| F9 | Leading a team (not in the JD; your own note) | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would learn it, said as a plan and never as a past. |
| F10 | Working on a game with in-app purchases (not in the JD; your own note) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetisation side, said as a plan. |

Your message gives no figures, so no headline number on it needs a defend-the-number question.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Sourced negative (F9), and the inflated form of F6 | "I haven't led a team." Plain acknowledgment, no slot. |
| Worked on in-app purchase monetisation | Sourced negative (F10) | "I haven't worked on a game with in-app purchases." Plain acknowledgment, no slot. |
| Ran the calendar across two titles | Inflated form of F3 | F3's quote at its own scope. Your material says one title. |
| Owned the post-event review and the KPIs | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." Your material says presented, not owned. |
| The puzzle title was live-service | Inflated form of F1 | "4 years as an associate producer at a puzzle-game studio." Your message does not say the title was live-service. Describe the calendar in your words. |

## Persona table

Relationship is assumed to be hiring manager, so the priors are Case/Strategist and Skeptic. Depth follows weight: 4 to 5 questions for the top persona, 3 for mid, 2 for low.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case/Strategist | Live problems from the roadmap: plan this, diagnose that | Highest. A hiring manager is buying the ability to plan and run a calendar. | Clarify, then structure: the goal, the segment, the metric, the risk. Think aloud. | 5 |
| Skeptic | Quiet probing of the gaps: two titles, leading a team, in-app purchases | High. Your gaps are visible in the JD and your note. | Rehearse the one predictable objection until it is calm. Concede the gap plainly, then give the plan. | 3 |
| Data-Driven Prober | Asks how a number was counted and what you would defend least | Medium. Your retention work is presented, not built, so the questions will follow it. | Say what you can explain and say plainly when you cannot. | 3 |
| Pressure | Interrupts, time-boxes, questions how much was yours | Medium. A new head of live ops may test composure. | Hold a position through two follow-ups, then concede a specific point. | 2 |
| Conversational | Friendly openers that are scored anyway | Medium. Casual questions still score. | Have a 90-second arc ready. Treat casual questions about the JD as scored. | 2 |
| Values/Behavioral | Scenario probes on published values | Low. No values were given, so no values bank. | Use the quotes you have; say so where none fits. | 0 |
| Peer Evaluator | Seam-splitting between teams | Not plausible for a hiring manager. | None. | 0 |

## Question banks

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The next content drop is due in three weeks, and the event plan has two open design dependencies. How would you decide what ships?" | CASE | [generic] | Structure it: what the drop must achieve, what you would cut first, who confirms the dependencies, and what you would record. This question needs no claim about your past. | The core of the role's calendar work. F2 is the evidence you would draw on in practice. |
| A2 | "Retention fell after the last event. Walk me through how you would diagnose it in the first week." | CASE | [generic] | Clarify the metric and the time window. Split by cohort or segment. Check who saw the event. Then decide what to test first. | F4 is where the retention requirement is raised. |
| A3 | "The role plans the live calendar for two titles. How would you set up each one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Name what you would need to know about each title first. Answer slot: say what carries over from the calendar you ran, and what you have not done. | F3 is transferability. The question is the JD's own line, so it is fair to answer it. |
| A4 | "You have run one calendar. What would be different about running two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | The highest-ROI rehearsal in this pack. Hold: "For two years I ran the weekly content-drop calendar for our main title." Hold through two follow-ups by returning to that calendar. Concede specifically: "I haven't run two at once." Answer slot: if you ever planned more than one title's schedule, say how. If not, say so plainly and say how you would plan two. | F3 is the likeliest objection and the requirement most likely to be probed. Holding one title is what your material carries. |
| A5 | "Before you commit a date to one live event, what do you need from design, art, engineering and community?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Name the answers you need from each team before a date is set. Answer slot: say what you have actually done with those teams, in your own words. If you have not worked with one of them, say so. | F6 is discovery. The question shows the coordination the role expects. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "3+ years producing live-service games or apps" (JD) | Name one part honestly. The likely answers are the two-title calendar or the cross-team coordination. Then say how you would close it. | F1 and F3 are the gaps. Answering first with the gap is stronger than waiting to be probed. |
| B2 | "You have never led a team. Why would this role be different from the last one?" | EXP | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then say what you did do with the calendar and the checklist, in your own words, and how you would learn to lead people. | F9 is a stated gap. The honest answer is the acknowledgment plus the plan. |
| B3 | "What draws you to a live mobile title, and what would you be leaving?" | CO | [generic] | Answer from your own reasons. This question makes no claim about your history. | Motivation consistency is a Skeptic test. Your answer should match the reasons you give for the move. |
| B4 | "Which of design, art, engineering or community would be hardest to get answers from, and why?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer from experience only. If you have not worked with one of the four, say which ones you have worked with. | F6 is discovery, so this question checks it directly. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Which number did you look at first, and what would you need to know about how it was counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the number you used most, in your own words. Weakest-assumption move: name the assumption behind it that you would defend least. Answer slot: if you did not know how it was counted, say so. If someone else produced it, say so. | F4 is presentation. The prober's job is to find where you stop knowing. |
| C2 | "How would you run a post-event review, and what KPIs would it report?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Answer slot: if you have run one, describe it in your own words. If not, say so and describe the structure: what you would measure, against what, and what you would decide. | F5 is discovery. The question is open, so it presupposes nothing about your past. |
| C3 | "The release checklist you wrote is still in use. What does it cover, and how do you know?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe what the checklist covers, in your own words. Answer slot: if you do not know what it has caught, say so. | F7 and F8 rest on this quote. The probe is whether you know its scope. |
| C4 | "What is the smallest change in retention you would treat as real?" | JD | [generic] | Say the threshold you would use and what you would check before acting on it. There is no claim about your past here. | Retention is a stated requirement, and this question tests whether you think about noise. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has led a live team?" | EXP | [grounded] "Never led a team" (your message) | Hold on what you offer: the calendar you ran and the checklist you wrote. Concede specifically: "I haven't led a team." Hold through two follow-ups, then concede the point and stop. | F9 is the stated gap. Pressure tests whether you fold or hold. |
| D2 | "That checklist: how much of the QA result was actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold to what you wrote. Do not claim QA results. Concede what was not yours. | F7 is the quote's scope. The probe is whether you claim more than you did. |
| D3 | "Tell me about a time you held back a live release because it was not ready." | JD | [grounded] "manage the release checklist with QA" (JD) | An open prompt. If an instance comes to mind, tell it in your own words. If none does, say so plainly, then give the nearest thing your material carries: the checklist you wrote and how QA uses it. | Managing the release checklist is the JD requirement, and this probe tests judgment about a go or no-go. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: the four years, the calendar you ran, the checklist you wrote, and the retention numbers you presented. Use your words and stop at the end of the evidence. | Opens the interview. The arc sets the frame for every later question. |
| E2 | "What mobile game have you been playing lately, and what live event in it did you notice?" | CO | [generic] | Name one game and one live event you noticed. Say what you would keep and what you would change. Make no claim about the company. | A casual question on the role's core topic, and scored as one. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, A4 |
| Coordinate design, art, engineering and community teams on each update | A5, B4 |
| Own the post-event review and the KPIs it reports | C2 |
| Manage the release checklist with QA | C3, D2, D3 |
| 3+ years producing live-service games or apps | B1, E1 |
| Experience running a content calendar | A1 |
| Comfortable with player-retention metrics | A2, C1, C4 |
| Clear written communication | C3 (the checklist is written work others use) |

## Reverse questions

Your interviewer profile is absent, so these are role-generic. Each one says why it lands.

1. "Which title would you want me on first, and what would the first quarter look like?" Why it lands: it shows you are already thinking about the two-title plan.
2. "How are post-event reviews used today, and who acts on the KPI readout?" Why it lands: it tests whether the KPI ownership is real.
3. "Who can say no to a live date, and where does QA sit in that decision?" Why it lands: it tests the authority behind the release checklist.
4. "When a live event underperforms, what does the team change first: the calendar, the content or the retention plan?" Why it lands: it shows you care about the diagnosis, not only the calendar.
5. "What would you want the new person to have fixed by day 90?" Why it lands: a hiring manager's answer tells you what the role is for.

## Sources

- Provided documents: the JD and your message.
- Research tier: L0. No search or fetch was run. Consent is asked for below.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet (not built). No research consent yet. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure and persona weights. No research consent yet. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Company and strategy questions (CO). No research consent yet. |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Interviewer read and a tailored reverse question. No research consent yet. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot. |

No interviewer profile, values, deliverables or prep-time information was given, so the interviewer read, values cheat sheet, graded deliverables and prep triage are left out.

## Upgrade menu

- Tobias Wrenfield's public profile → a tailored reverse question, and persona weights read from his footprint
- Whether Tobias is your manager or a peer → reweights the persona table and the question banks
- Saltmarsh's recent live events or strategy → company and strategy questions (CO) grounded in current titles; none exist yet
- A redacted copy of the release checklist, or a retention summary you wrote → F7 and F8 move from quote-only to inspectable proof
- Whether the puzzle title had updates after launch → F1's answer slot becomes a `[grounded]` statement you can say in full
- The recruiter's note on focus areas → coverage weights for the banks
- Hours you have before Friday → a prep triage section, scheduled to the time you have
