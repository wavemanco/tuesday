# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** 60-minute interview, Friday. Relationship assumed to be hiring manager, since the interviewer is the head of the function. This is an assumption; see the upgrade menu.
**Research tier:** no web search was run (see Sources). Company values, loop structure and strategy are not established here.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **EXP**: work-experience deep-dive. Tests whether your claims survive scrutiny.
- **JD**: role-driven. Tests the listed responsibilities and qualifications, gaps included.
- **CASE**: a live problem from the role. Tests structure and reasoning.
- **VAL**: behavioural. Tests past behaviour against principles. No company values are established here, so VAL questions use generic themes.
- **CO**: company and strategy knowledge. Not covered in this pack, because no research ran.

Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Fit snapshot

Requirements are quoted from the JD you supplied. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Words: "For the last two years I ran the weekly content-drop calendar for our main title." Your material shows one title and content drops, not two titles and live events. That limit is this pack's observation, not words for you. Answer slot: if you planned or ran anything for a second title, say what, and how you decided it. If not, say so, and say what you would need to know about a second title's calendar before changing anything. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | discovery | Your material shows coordination with QA, not with the other four teams. Words: "I wrote the release checklist our QA team still uses." Plain acknowledgment, from your stated negative: "I haven't led a team." Answer slot: name one content drop where you coordinated with a team other than QA, and what you needed from each. If no drop involved them, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Words: "I presented the monthly retention numbers to the studio head." Presenting numbers is not owning the review or choosing the KPIs. That limit is this pack's observation. Answer slot: if you chose which numbers went into that presentation or how they were counted, say which and why. If someone else set them, say so, and say what you would check first. |
| F4 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Words: "I spent 4 years as an associate producer at a puzzle-game studio." Your material gives the years and an associate title. It does not say which decisions were yours. Length of experience is not a gate, so this row is graded on fit, not treated as a near miss. |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Words: "I ran the weekly content-drop calendar for our main title for the last two years." Expect a probe on what running it meant. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Words: "I presented the monthly retention numbers to the studio head." Your material shows you handled the numbers, not how they were counted. Answer slot: if you can say how a retention figure was counted, say it in your own words, and name the assumption you would defend least. If you cannot, say so, and say how you would find out. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | Words: "I wrote the release checklist our QA team still uses." Do not say you managed it. Expect a probe on whether you maintain it or only wrote it. |
| F8 | "clear written communication" (JD) | none given | low | [grounded] | discovery | Your material names two written artifacts, the release checklist and the retention presentation, but shows neither. Answer slot: name one written artifact you would show, and what it let people do. |
| F9 | I haven't worked on a game with in-app purchases (your message, not a JD line; the role-family expectation is [generic]) | "never worked on a game with in-app purchases" (your message) | high | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." This is your stated absence, so it can be said plainly. No answer slot. Do not add monetisation experience to bridge it. |

**Gate check:** none of the JD's requirements is a gate under the suite's definition. "3+ years" is a length of experience, graded above.

## Prohibited claims

These are claims this pack will not coach, built from the fit snapshot. Each one is a stretched form of something you said, or a negative you stated.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a live-events calendar for two titles | Inflated form of F1 | "For the last two years I ran the weekly content-drop calendar for our main title." Your material says one title, not two. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." |
| Led design, art, engineering and community through updates | Inflated form of F2, and your stated negative "Never led a team" | "I haven't led a team." Then: "I wrote the release checklist our QA team still uses." |
| Set the QA release process | Inflated form of F7 | "I wrote the release checklist our QA team still uses." |
| Ran in-app purchase events | Your stated negative, F9 | "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Relationship priors come from the hiring-manager row: Case/Strategist and Skeptic. There is no interviewer profile, so no signal adjusts the weights. No loop source was read, so the loop is not established; these weights rest on the generic archetype, with flat weights said plainly.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: team leadership, the four-team coordination, no in-app purchase work | 5 questions. Top weight, because your two stated gaps are this persona's material and the hiring-manager prior names it | Rehearse the team-leadership objection until it is plain. Hold what you did, concede what you did not |
| Case/Strategist | Live problems on a two-title calendar and a retention drop | 4 questions. Hiring-manager prior; the JD asks you to plan and run | Clarify, then structure, then name your metric and its weakest assumption |
| Data-Driven Prober | Asks how the retention figure was counted | 3 questions. The JD names retention metrics and KPIs | Say how you know a number, and say plainly when you do not |
| Pressure | Interrupts, time-boxes, asks how much was really you | 2 questions. No profile to raise it | Pause, restate, hold a position through two follow-ups, then concede specifically |
| Conversational | Opens with a casual "walk me through" | 2 questions. An opener is scored too | Keep a 90-second arc ready |
| Values / Behavioural | Scenario probes | 2 questions. No values-style round is detected, so this is a kept minimum, not a weight | Pick a real moment, or say so plainly and give the nearest thing your material carries |
| Peer | Seam-splitting with other teams | 0. The relationship is a hiring manager, not a peer | None |

## Question banks

Provenance lists every sentence the guidance rests on. Speak the answer slots as instructions, not as questions.

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never led a team, and this role coordinates four on every update. Why would they move for you?" | JD | [grounded] "Never led a team"; JD "coordinate design, art, engineering and community teams on each update" | Hold: "I haven't led a team." Then describe how you got work done across people you did not manage, using the QA checklist: "I wrote the release checklist our QA team still uses." Answer slot: name one update where you got another team to agree to something, and what you did to get it. If none of the four teams was part of your work, say so and describe how you would set up the first month. Hold through two follow-ups by returning to the checklist. Concede that you have not managed people. | This is the highest-ROI prep in the pack. F2 is the largest gap, and the question's premise is your own stated negative. Deepest rehearsal, because it will be asked in some form. |
| A2 | "You have run one title's content calendar. This role plans two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; JD "Plan and run the live-events calendar for two of our mobile titles" | Hold: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned or ran anything for a second title, say what and how you decided. If not, say so, and say what you would need to know first. | F1 is transferability. The question's premise is the JD's two-title line, and your quote does not carry it. |
| A3 | "Who decided what the post-event review measured?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you chose the numbers or their definitions, say which and why. If someone else set them, say so and say what you would check first. Never describe a KPI you did not track. | F3. Presenting is your quote's scope; the question asks about ownership. |
| A4 | "Your background is puzzle games with no in-app purchases. How would you plan an event whose rewards are paid for?" | CASE | [generic] pattern; [grounded] "never worked on a game with in-app purchases" | Concede: "I haven't worked on a game with in-app purchases." Then plan from first principles: name the first question you would ask, what the player pays for, and what the event must not break. This is a plan, not a past. | F9, and the role-family expectation that the interview will test monetisation. |
| A5 | "Four years as an associate producer, on a puzzle game. Which live decisions were yours to make?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Answer slot: name which decisions were yours, in your words, and which were not. If the title did not give you the decision, say so. | F4. The question's premise is the years and the title, both in your quote. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The battle pass ships in six weeks and its reward curve is wrong. Walk me through your first week." | CASE | [generic] | Clarify: which metric is wrong, against what baseline, and which players are affected. Then decide what stops, who must agree (design, engineering, community), and what QA needs before any change ships. Think aloud. | A live problem from the role. The JD raises the coordination line, so the case tests it. |
| B2 | "Retention fell 15% after a limited-time event. Diagnose it." | CASE | [generic] | Clarify the cohort, the event, and how retention is defined. Then list hypotheses (difficulty, reward value, a bug, timing) and the data you would pull for each. Say what you would decide before the data arrives. | The JD asks for comfort with retention metrics, so the metric is the test. |
| B3 | "A two-title calendar for next quarter, with four teams involved. What do you lock first?" | CASE | [generic] | Lock the QA window and the release date first, then the dependency order across the four teams. Name the trade-off you are accepting. | JD "Plan and run the live-events calendar for two of our mobile titles". Tests F1 and F2 together. |
| B4 | "An event's content is late, and community has already announced it. What do you do in the next 24 hours?" | CASE | [generic] | Decide what the player sees, who signs off (design, engineering, QA), and what the community message says. Do not claim a past instance. | The JD's coordination line, under time pressure. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how one of your monthly retention numbers was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you can say how it was counted, say it in your words, and name the assumption you would defend least. If you cannot, say so, and say how you would find out before the next report. Never supply a cohort definition. | F6. Defend-the-number slot: the figure is yours to explain, not this pack's. |
| C2 | "Which step on the release checklist has caught the most bugs, and how do you know?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Answer slot: if you can name a step and what it caught, say so. If you have no such record, say so, and say how you would start tracking it. | F7. The question assumes a record; the second branch allows that there is none. |
| C3 | "Your calendar covered one title. What did a drop involve, from start to finish?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what a drop involved, in your own words, and what the cadence was. If you did not track what a drop cost, say so. | F5. Tests what running the calendar actually meant. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we give a live-ops role to someone who has never led a team?" | JD | [grounded] "Never led a team" | Pause. Restate the question. Hold: "What I have is the calendar I ran and the checklist still in use." Concede specifically: you have not managed people. Hold through two follow-ups before conceding anything more. | Pressure persona. The stem is from the persona model, and the premise is your stated negative. |
| D2 | "That retention number: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you produced any part of the figure, say which part. If you only presented it, say so and stop there. | F6, under pressure. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: four years at a puzzle-game studio, the calendar you ran, the checklist, the retention reporting, and what you want next. Use only these sentences. | Opener, scored like any question. |
| E2 | "What are you playing right now, and what would you change about how a game handles events?" | JD | [generic] | Have one current game you can describe with specifics. Do not assert anything about this studio's titles, since nothing was researched. | A casual question on a JD topic. |

### Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you pushed back on a deadline." | VAL | [generic] | Selection scaffold: pick a time a date or scope was at risk, you named the stake, and you said so. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the checklist, or the retention presentation. | Open prompt, with a persona stem. No values are established. |
| V2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Same scaffold: a real moment with a named stake. If none, say so plainly. | Persona stem. Not tied to a published value. |

**Requirement coverage**

| JD requirement | Questions | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | A2, B3 | |
| Coordinate design, art, engineering and community teams | A1, B3, B4 | |
| Own the post-event review and KPIs | A3, C1 | |
| Manage the release checklist with QA | C2, A1 | |
| 3+ years live-service | A5, E1 | |
| Content calendar | C3, E1 | |
| Player-retention metrics | B2, C1, D2 | |
| Clear written communication | none, and why: your material shows no written sample to test, so no question can test it. The upgrade menu asks for one. | |

**Not in the JD, still likely:** in-app purchases (A4, B1).

## Reverse questions

1. "What did the last live event that missed its target teach the team, and what changed afterwards?" Why it lands: it asks how post-event learning works, which the JD's review line requires.
2. "Which two titles are on the calendar, and what does each one's next quarter look like?" Why it lands: it shows you want the real scope before you talk about it.
3. "Who sets the KPI definitions that the post-event review reports on?" Why it lands: it goes straight to the ownership question behind F3.
4. "How does the release checklist work today, and what happens when a QA sign-off fails?" Why it lands: it shows you know the checklist is a live system, not a document.
5. "What would a strong first 90 days look like in this role?" Why it lands: a generic but reliable question that shows you think in plans.

No reverse question is tied to the interviewer's path, because there is no interviewer profile.

## Sources

- Provided documents: the job description you pasted; your message describing your background.
- Searches sent, both refused (permission not granted in this session):
  - "Saltmarsh Games values": refused.
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused.

**Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Both calls refused. Would have moved the values cheat sheet, which is dropped because no published values are in hand. |
| 2. Saltmarsh Games interview process | unavailable | No call sent, because the host refused search. Would have moved the loop structure, and so the persona weights. |
| 3. Saltmarsh Games strategy / recent news | unavailable | No call sent, because the host refused search. Would have moved the CO questions, which are absent. |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Call refused. Would have moved the interviewer read and a tailored reverse question. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Permission for web search → the company's values by name, the loop structure, a strategy pass, and Tobias's public footprint → a values cheat sheet, an interviewer read, a tailored reverse question, and persona weights that rest on this company rather than on the generic archetype. A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes, is also available if you want it.
- Whether Tobias is your direct manager or a senior partner on the team → reweights every bank. A manager shifts weight toward the Skeptic; a partner shifts it toward the Prober.
- The round's format: one conversation, or a panel → persona weights per member.
- A written sample of your work, names removed, such as the release checklist or a retention summary → F8 moves from low to medium, and the clear-communication requirement gains a question.
- A retention figure you can explain in your own words → C1 and F6 gain a worked defend-the-number answer, in your words.
- Details of a second title, if you ever planned one → A2 gains a grounded answer slot.
