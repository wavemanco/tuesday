# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer
**Company:** Saltmarsh Games (mobile studio, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager (the careers page describes the round as the hiring manager's Outage Hour).
**Round:** 60 minutes. Live-incident tabletop on a simulated outage during a live event, then a values conversation.
**Candidate:** Femi (they/them)

This is the first version. Nothing has changed yet.

---

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

Type key:

- **CASE**: a live problem from the role. Scores structure and reasoning.
- **JD**: a stated responsibility or requirement. Scores whether you can do the listed job, gaps included.
- **EXP**: a question about something you did. Scores whether your account holds up under scrutiny.
- **VAL**: a values question. Scores whether past behaviour shows the company's published values.
- **CO**: company knowledge. Scores whether you have done the homework.

The guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

---

## Fit snapshot

Requirements come from the JD you supplied, quoted. Your evidence is quoted from your message, with the source named. The fit snapshot is the basis for every question bank below.

Gate check: none of the JD's requirements is a legal or credential gate. They are experience and skill terms, so each is graded on fit and gap like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material gives a content-drop calendar for one title, not a live-events calendar for two. Say the calendar you ran, at its own scope. Answer slot: if you planned events or a second title's calendar, say how; if you did not, say so plainly and stay with the one title you ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Never led a team" (your message) | low | [inferred] | discovery | Your material says nothing about coordinating these four functions. The only related line is a negative about leading a team, which does not answer this requirement. The pack's bridge is its own derivation: this is the gap the interviewer is most likely to test. Answer slot: if you coordinated a cross-team update, say which teams and what you did; if you did not, say so plainly and say how you would set one up. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material says you presented the numbers. It does not show a post-event review or ownership of a KPI. Keep to the word "presented." Answer slot: if you owned how a figure was defined or reported, say so and how; if you only presented figures someone else produced, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote already reaches this requirement: a checklist you wrote that QA still uses. Expect a probe on it, since it is a claim you can be asked to show. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years are stated. Your material does not say whether the title ran as a live-service product, which the JD asks about. That is the pack's observation, not words for you. Say the four years and the studio type as you wrote them. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement in its own terms. Expect a probe on how it ran week to week. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is not the same as analysing them. Keep to what you presented. Answer slot: if you built or checked the figures, say how; if you only presented them, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The checklist is written work that is still in use. Offer it as the example, in those words. A sanitised copy would make this row inspectable (see the upgrade menu). |
| F9 | Not in the JD. A likely probe for a live-service role: "[generic] live-service KPIs commonly include monetisation" | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan and never as a past. Nothing added to make it feel smaller. |

Note on F9: the JD does not mention in-app purchases. The requirement behind F9 is the pack's own inference about live-service KPIs, which is why its provenance is set by the quote and not by the JD.

---

## Prohibited claims

Claims this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the live-events calendar for both titles" | Inflated form of F1 | F1's quote at its own scope: a content-drop calendar for one title. Your material says the calendar for one title, not events, not two titles. |
| "I owned the post-event review and its KPIs" | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. |
| "I coordinated design, art, engineering and community on every update" | Inflated form of F2; no quote carries it | Nothing is written for this. Answer slot A5 applies. |
| "I analysed the retention cohorts myself" | Inflated form of F7 | F7's quote: you presented the monthly retention numbers. Answer slot applies. |
| "I wrote the checklist and ran QA's sign-off" | Inflated form of F4 | F4's quote: you wrote the checklist QA still uses. Nothing about sign-off. |
| "I have led a team" | Negative the candidate stated (F2) | "I haven't led a team." No slot. |
| "I have shipped a game with in-app purchases" | Negative the candidate stated (F9) | "I haven't worked on a game with in-app purchases." No slot. |

---

## Reading the interviewer

Public professional footprint only.

- **Career pattern:** a talk listing from GDC 2026 describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. This came from a search result snippet; the talk page was not opened.
- **Published position:** the talk "Patch Notes Are a Promise" argues that a live team is judged by how often its patch notes describe what actually shipped.

**Practical implications:**

1. Expect the tabletop to turn on a mismatch between what was announced and what shipped. Your release checklist is the closest thing you have to that territory. Describe what it checks, in your words.
2. He will test whether your accounts match what happened. Precision lands better with him than polish.
3. His path runs through QA, not production. Do not claim a shared jump: your path is producer, and the material does not show a QA step. You can still ask him about his path (reverse question R1).

**Mirror opportunities:** the words "patch notes" and "what shipped" come from his published talk and from the company's values. Use them in the values answers, where they sit naturally.

---

## Persona table

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop: a live incident during a live event | High. The careers page describes the tabletop as part of the round, and a hiring manager's prior weights live problems on the actual roadmap. | Clarify, then structure, then act. Say what you would check first. Name who you would bring in. |
| Values/Behavioral | The values conversation after the tabletop | High. The careers page names the values conversation as the second half. | Map one story to each value where your material carries one. Where it does not, use the selection scaffold and its honest branch. |
| Skeptic | Quiet probing of the two gaps you stated: team leadership and in-app purchases | High. The JD asks for coordination across four functions, and your message names two gaps the JD touches. | Rehearse the team-leadership question until it is plain. Concede the gap, then give a ramp plan. Do not bluff. |
| Data-Driven Prober | Questions on how the retention figure was counted, and which KPI you would defend | Medium. The JD names KPIs and retention metrics, and your CV line is a headline figure. | Say what you know about how it was counted, and say plainly when you do not. Name the weakest assumption yourself. |
| Pressure | Time-boxed challenges to the gaps and to the retention claim | Medium. Hiring-manager rounds sometimes press on a stated gap. | Pause. Hold a position you can back. Concede only the specific uncertainty. |
| Conversational | A friendly opener and a question on current play | Low to medium. The round has a fixed structure, but the opener is still scored. | Keep a ninety-second arc ready for the biography question. Treat the casual question as scored. |

---

## Question banks

Weights: Case/Strategist 5, Skeptic 3, Values 3, Prober 3, Pressure 2, Conversational 2. Total: 18.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running on both titles and players say a reward is missing from the patch notes. Walk me through the first hour." | CASE | [generic] | Clarify: which title, which players, is the reward missing from the game or from the notes. Then check what the release checklist says shipped. Then decide the player message and whether to hotfix. Name engineering, QA and community. | The tabletop is the round's core. The talk's mismatch theme shapes the scenario. No claim about your past. |
| A2 | "Day-one retention drops six points two days after a content drop. What do you check first?" | CASE | [generic] | Segment before you conclude: new against returning players, platform, app version, the timing of the drop. Name the metric definition first. | Your retention work is the closest thing to this. The question asks for a method, which is generic. |
| A3 | "Walk me through how you would plan the live-events calendar for two titles for the next quarter." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped from F1: the calendar you ran, in your words. Answer slot: if you planned events or a second title's calendar, say how; if you did not, say so plainly and describe how you would sequence two titles. | F1 is the calendar requirement's evidence; this question is the JD's stated job. |
| A4 | "Engineering has a risky migration in the week design wants a big event. What do you do?" | CASE | [generic] | Name the trade-off, ask engineering for the risk in their words, decide with a named owner, write the decision down. | A live trade-off between two teams. No claim about your past. |
| A5 | "Which teams do you need on each update, and what does each need from you?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" | Answer slot: if you coordinated a cross-team update, say which teams and what you did; if you did not, say so plainly and describe how you would set one up. | F2 is the gap; this is the JD's own requirement, asked directly. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [inferred] "Never led a team" | Name the team-leadership gap first, in your words. Then give a ramp plan for the first month. Do not list a strength to soften it. | F2 is the gap the skeptic reaches first. |
| B2 | "You have never led a team, and this role coordinates four functions on every update. How do you get design, art, engineering and community to move without authority over them?" | JD | [grounded] "Never led a team" | **Highest-ROI prep.** Hold: say what you would do first. Concede: coordinating is not leading, and you have not done it at this scale. Answer slot: if you coordinated across teams without authority, say which and what moved; if you did not, say so plainly and give your plan. Hold through two follow-ups by returning to your plan. | F2's requirement is the one most likely to be probed, and it is where your material is thinnest. The second branch of the slot allows the practice never existed. |
| B3 | "This role's titles earn through in-app purchases. Have you worked on a game with them?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan. No slot. | F9 is a stated gap. The plain answer is safer than a bridge. |

### Values (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (nearest thing) | Open prompt. Pick a time a planned drop went against what players needed: a named stake, what you chose, what it cost. If none comes to mind, say so plainly, then give the calendar you ran and how it handled player feedback, in your words. | Maps to the value "Players Before Plans." No story is in your material, so this is a selection scaffold. |
| C2 | "Tell me about a release where what was announced differed from what shipped." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (nearest thing) | Open prompt. If you have a time a note and a build disagreed, say which check caught it or did not. If none comes to mind, say so plainly, then describe what the checklist covers, in your words. | Maps to "Ship the Patch Not the Promise." The checklist is the nearest thing; do not claim it caught anything unless you can say how. |
| C3 | "What have you left in a release process that the next team still uses?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Say what the checklist is and that QA still uses it. Do not claim more than that. | Maps to "Leave the Build Greener." F4's quote is the only supported claim here. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that monthly retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number slot. Say what you know about how it was counted, in your words. Name the assumption you would defend least. Say which part was yours. Answer slot: if you do not know how it was counted, say so. | F7 is the evidence; the prober tests whether you know your own figure's method. |
| D2 | "Which KPI would a post-event review report first, and what is its weakest assumption?" | JD | [generic] | Name one KPI and say which assumption behind it you would defend least. | Covers the JD's KPI requirement without claiming you have done one. |
| D3 | "If retention fell after a content drop, what would you need to see before you called it a drop problem?" | CASE | [generic] | Name the cohort, the baseline, and the non-drop explanations you would rule out first. | Retention is a JD requirement, and this asks for method. No claim about your past. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire someone who has never led a team?" | JD | [grounded] "Never led a team" | Hold: name what you did carry, the weekly calendar. Concede plainly that you have not led a team. Do not fold on the core claim that the calendar work is real. | F2's gap under time pressure. |
| E2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: say what you presented and what was someone else's. Concede only the specific uncertainty about how the number was produced. | F7 under challenge. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | CO | [grounded] "4 years as an associate producer at a puzzle-game studio" | Ninety seconds: four years at the puzzle studio, the content-drop calendar, the checklist QA still uses, the retention numbers you presented, and the two gaps stated plainly. | F5 and F1 are the arc's material. |
| F2 | "What are you actually playing in mobile live-service games these days?" | CO | [generic] | Name a game you actually play and one thing it does with its live calendar. Keep it true. | The casual question about a JD topic is scored. No claim about your past. |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4 |
| "coordinate design, art, engineering and community teams on each update" | A5, B2, E1 |
| "own the post-event review and the KPIs it reports" | D2, D1 |
| "manage the release checklist with QA" | A1, C2 |
| "3+ years producing live-service games or apps" | F1 (conversational arc) |
| "experience running a content calendar" | A3, C1 |
| "comfortable with player-retention metrics" | A2, D1, D3, E2 |
| "clear written communication" | none, and why: a written-communication question would be a test you take live. The sanitised checklist in the upgrade menu covers it. |

---

## Values / principles cheat sheet

Values, from the company's published values page:

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | Selection scaffold (C1). Your material holds the calendar you ran, not a case where players won. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | Selection scaffold (C2). F4 is the nearest quote. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4's quote carries the checklist still in use (C3). Do not claim more than that. |

---

## Reverse questions

Five questions, each with why it lands.

- **R1 (ties to the interviewer's path):** "Your talk argues patch notes are a promise. What does a good patch-notes review look like on your team?" *Why it lands:* it asks him about his own published argument, and it turns the interview into a peer conversation.
- **R2:** "What would the first ninety days look like for the person in this role on both titles?" *Why it lands:* it shows you are planning for the job, not interviewing for it.
- **R3:** "How does the post-event review reach the KPIs, and who owns each number?" *Why it lands:* it tests the ownership question from the JD and gives you the answer you need for F3.
- **R4:** "Which of the two titles has the most in-app purchase exposure, and what does that change in the calendar?" *Why it lands:* it asks about F9 without asserting it, and the answer tells you what to learn.
- **R5:** "Where does a live incident most often go wrong between engineering, QA and community on your team?" *Why it lands:* it asks for the real pain point, which the tabletop is likely to test.

---

## Sources

**Provided documents:** the JD text, your message describing your background, and the request. The round description and the interview loop are from the careers page below.

**Searches and fetches (L1 tier):**

1. Query "Saltmarsh Games mobile studio values": returned saltmarshgames.com/values.
2. Query "Tobias Wrenfield Head of Live Operations Saltmarsh Games": returned a GDC 2026 talk listing, talks.gdconf.example/2026/patch-notes-are-a-promise. Snippet only; the page was not fetched.
3. Query "Saltmarsh Games interview process Live Operations Producer": returned saltmarshgames.com/careers/interviewing.
4. Fetch saltmarshgames.com/values: the three values and their one-line meanings.
5. Fetch saltmarshgames.com/careers/interviewing: the loop is a recruiter call, then the Outage Hour, a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

**Research tier: L1, searches 3 of 6, fetches 2 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh values | yes | Values cheat sheet, the three values by name. |
| 2. interview process | yes | Round structure: tabletop plus values conversation. Persona weights follow it. |
| 3. strategy / recent news | unavailable | No search was run. The fetch budget went to the values and careers pages. It would have moved the grounding brief; L2 can run it. |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Interviewer read and the reverse question R1. The talk was seen in a snippet only. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- A sanitised copy of the release checklist → F8 moves from `[grounded]` with a verification caveat to an inspectable work sample, and the written-communication requirement gets a question.
- The event calendar for the title you ran, or any plan for a second title → F1 and A3's answer slot get your own material.
- Whether you owned any part of the post-event review → F3 and D1 get a fact to work from.
- How the monthly retention figure was counted, if you know → D1's defend-the-number slot gets your words.
- The GDC talk's full text or slides → C2 and R1 get the talk's actual argument in its own terms.
- L2 deep research (strategy brief, recent company news, the interviewer's other talks) → the grounding brief and the strategy-based questions. Cost: up to 6 more searches and 2 more fetches. Offered once; it runs only on your say-so.
