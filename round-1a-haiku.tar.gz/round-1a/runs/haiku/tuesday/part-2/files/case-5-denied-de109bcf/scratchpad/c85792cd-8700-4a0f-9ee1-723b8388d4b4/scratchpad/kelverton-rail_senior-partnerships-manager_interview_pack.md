# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Interviewers:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: 15-minute spoken POV, then Q&A. Ross will push on commercials.
**Format:** Session mode, one panel. No loop source established the rounds, so persona weights rest on the relationship priors, not on this company's documented process.
**Research status:** No company research ran this session. Web search was declined at the permission step, so nothing below about Kelverton's values, strategy or interview process is sourced. Company-specific content is either quoted from your message or the recruiter's email, or labelled `[generic]`.

## 1. How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: work-experience deep-dive. Tests whether what you did holds up under scrutiny.
- **JD**: role-driven. Tests whether you can do the job, gaps included.
- **CO**: company and strategy knowledge. Not researched here, so the CO rows are generic.
- **CASE**: live problem. Tests structure and reasoning.
- **VAL**: none. No values round was detected, so there is no values cheat sheet.

Guidance is scaffolding, not a script. Speak it in your own words.

## 2. Prep triage (about 4 hours)

1. **Build the POV (about 80 min).** Pick one thesis from section 7, write its concession aloud, and time it to 3 minutes. The 15-minute slot is the thesis plus two supporting moves, not a survey. Everything else in this pack supports this.
2. **Ross's commercial bank (about 60 min).** Rehearse C1 to C4 aloud, out loud, twice each. The defend-the-number and direct-quota questions are where the panel will spend its time.
3. **The rail gap (about 40 min).** Rehearse D2 and R3 until the plain acknowledgment ("I haven't sold into rail") comes out without a hedge. This is the highest-ROI prep in the pack.
4. **Reverse questions and questions to me (about 30 min).** Pick three from section 11.

Everything else is insurance.

## 3. Fit snapshot

Requirement sources: the recruiter's and your message's own words, quoted. No job description was supplied, so the requirement column is the panel brief and your stated background, not a JD.

Evidence sentences (all from your message):
- E1: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- E2: "running the ISV channel"
- E3: "so I know the operator world from the other side"
- E4: "Never sold into rail specifically" (stated negative)
- E5: "never carried a direct quota, only influenced revenue" (stated negative)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter) | "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your operator-side view comes from transport consulting, not from partnership strategy. Say it in the quote's terms, then say what you would test first. Answer slot: if you can name one operator-side planning problem you saw directly, say what it was; if you did not see one, say so and stay with the planning view you have. |
| F2 | "what it means for the operators themselves" (recruiter) | "so I know the operator world from the other side" (your message) | low | [inferred] | discovery | Your material does not show an operator-side commercial outcome you tracked. Answer slot: if you measured anything about what operators gained from a partnership, say what and how; if you did not, say so and say what you would measure first. |
| F3 | "Ross will push on commercials" (recruiter) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The material says influenced revenue, not sourced or closed revenue. Say the figure as influenced, in those words. The limit is this pack's observation, not something to say for you. |
| F4 | sells scheduling software to train operating companies (your message, on Kelverton) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated and the pack cannot close. Words: "I haven't sold into rail specifically." Then how you would learn it, as a plan, never as a past. Do not add rail sales claims to make the gap feel smaller. |
| F5 | a revenue target for the role [generic, role-family pattern] | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't carried a direct quota." Then the nearest thing you did carry (influenced revenue, E1) said at its own scope. |

**Gate rows:** none established. Your material says nothing about office pattern, right to work or notice. This is asked in section 13 (question 3).

## 4. Prohibited claims

Not to be coached in any answer, slot, hold or drill feedback. Each has its basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" | Stated negative, E4 | Plain acknowledgment: "I haven't sold into rail specifically." No slot. |
| "I carried a quota" or "I hit a number I was measured on directly" | Stated negative, E5 | "I haven't carried a direct quota. My number has been influenced revenue, roughly £4M." |
| "I drove £4M" / "I sourced £4M" | Inflated form of E1 ("influenced") | E1's quote at its own scope. This pack's limit: your material says influenced, not sourced. The slot stays inside influenced. |
| "I owned the channel's revenue target" | Inflated form of E2 ("running the ISV channel") | "I ran the ISV channel. I took it from 6 partners to 40." |
| "I know operators from the inside" / "I worked for an operator" | Inflated form of E3 ("from the other side") | E3 at its own scope: you know the operator world from the consulting side. |

## 5. Persona weights

| Persona | Weight | Why | Likely from |
|---|---|---|---|
| Pressure / Stress | High | Ross is Commercial Director and has said he will push on commercials. Composure is what he scores. | Ross |
| Data-Driven Prober | High | Ross's commercial questions will go to the number (influenced vs sourced). Prober style is native to a commercial lens. | Ross |
| Case / Strategist | High | Deepa is the future manager; the POV is a strategy talk, and she is buying capability. | Deepa |
| Skeptic | High | Both panellists will test the rail gap and the quota gap, the two gaps your material states. | Both |

Depth: Ross 5 questions (top persona by panel). Deepa 4. Both personas touched by both interviewers to avoid a first-time style live.

**Interviewer read:** absent. No public footprint was researched. The reverse questions below are role-generic until you give the profiles (section 13).

## 6. Question banks

### Ross (Commercial Director): Pressure and Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Influenced revenue is not revenue. Walk me through how you counted the £4M." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure as influenced, in your words. Answer slot (defend-the-number): how the figure was counted, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before he does. | F3. Probers test whether the number survives its own counting. |
| R2 | "You've never carried a quota. Why should I believe you can own a number?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" | Hold through two follow-ups: "I haven't carried a direct quota. The number I've been measured on is the partner count and the influenced revenue." Concede specifically: forecast accountability and closing are different from influence, and you have not done them. Do not fold on the core claim. | F5. Held position: only what the quote carries. |
| R3 | "Sixty seconds: why hire someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment first: "I haven't sold into rail." Then the nearest thing you did carry, E3 (the operator-side view). Answer slot: the first 90 days you would use to learn the rail sale, in your own words. | F4. The highest-ROI rehearsal in this pack, with D2. |
| R4 | "Of the 6-to-40 growth, how much was recruiting partners and how much was their own pipeline?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot (defend-the-number): the split between your recruiting and the partners' pipeline, if you know it. If you do not, say so. Do not invent a split. | Defend-the-number slot from E1. |
| R5 | "Rail margins are tight. Where does a partner's margin come from, and what do you give away?" | CO | [generic] | Structure it aloud: who pays, from which budget line, what a discount buys. Name one trade you would refuse. No claim about your past needed. | Generic commercial probe on the sector's economics; not a fact about Kelverton. |

### Deepa (VP Partnerships, future manager): Case and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch how you would grow operator partnerships over 18 months. What do you need to know first?" | CASE | [generic] (raising source: the recruiter's "over the next 18 months") | Clarify, then objective, segmentation (operators by size and contract type), approach, metrics, risks. Say the one thing you would need from her before you start. | This is the POV's question in case form. The source is the recruiter's own words. |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I haven't sold into rail specifically." Then E3 at its own scope. Answer slot: the first 30 days, in your own words, for learning the sale. Do not describe how you would sell into rail as if you had. | F4. The highest-ROI rehearsal in this pack, with R3. |
| D3 | "What does an operator need from a scheduling partner that a vendor pitch misses?" | JD | [grounded] "so I know the operator world from the other side" | Story-map from E3's sentence: the operator-side view from consulting. Answer slot: if you saw a planning problem directly, say what it was and what you did about it; if you did not, say so and say what you would ask operators first. | F1. Tests whether your operator view is specific or generic. |
| D4 | "Why would you be better at this than someone who has sold rail for ten years?" | Skeptic stem | [grounded] "took it from 6 partners to 40" and E3 | Do not argue the comparison. Name what you have (partner growth, the operator-side view) and concede what they have (rail sales depth). Hold the view that partner-channel design transfers; concede that you have not sold into this market. | F1 and F4. Skeptic reads a bluff immediately. |

**Deepest rehearsal (highest-ROI prep):** R3 and D2, the rail-sales gap. It is the question most likely to be asked in some form, and the pack has no more affirmative content for it than "I haven't sold into rail" plus what you did carry. A rehearsed plain answer changes the interview.

**Coverage:** the recruiter's three briefs ("18 months", "operators themselves", "commercials") are covered by D1, D3, R5 and R1. Requirement coverage line: POV theme → D1, D3, section 7 build; operators themselves → D3, F2 slot; commercials → R1 to R5. No JD, so no JD-line check.

## 7. Graded deliverable: the 15-minute POV (no slides)

Declared by the recruiter: a short POV on where you would take the operator partnerships over 18 months, with a landing on what it means for the operators.

**Grounded facts you can build on:**
- F1: "so I know the operator world from the other side" (your message)
- E1: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message)

**Consensus answer (what most candidates will say):** more operators, more integrations, a tiered partner programme, a bigger channel. Differentiate from it. Do not recite it.

**Theses (pick one; each has a mandatory concession):**

- **T1: Partner on the operator's planning cycle, not the sales cycle.** Build the partnership around when operators actually change timetables. *Concession:* I do not know how these operators buy scheduling software. If the buying sits with a central function, this thesis narrows. [generic]
- **T2: Make a shared operational outcome the partnership's metric.** Measure partners on what the operator gains (fewer planning disruptions, faster change cycles), not on volume. *Concession:* partners may not get the operator data needed to prove it. [generic]
- **T3: Fewer, deeper operator alliances over a wide channel.** *Anti-pick:* do not sign every operator into a standard partner programme. *Concession:* the channel lesson from E1 (6 to 40) argues the other way, and I would be going against it on purpose. Say that directly.

**Build for the chosen thesis:**
1. Open: your operator-side view (F1), in those words.
2. The thesis and its concession, aloud.
3. Two moves, each with a measure of what the operator gains.
4. The close: what it means for operators, in one sentence. Draft: "An operator's planning team gets a partner who plans around its timetable changes, not around ours." [generic; test it in the drill before you use it.]

## 8. Values / principles cheat sheet

Not produced: no values-style round was detected, and no values page was read.

## 9. Reverse questions (at least five; each with why it lands)

1. "What would make you say a partner is working a year after it signs?" Why: it turns your POV's operator outcome into the interviewer's own measure.
2. "Which operator relationships would you least like to lose, and why?" Why: it shows you are listening for priorities, not reciting.
3. "How does the commercial model for operator partnerships differ from your other channels?" Why: Ross will answer this in his own terms. Role-generic.
4. "When an operator pushes back on a scheduling change, who here owns that conversation?" Why: it separates partnership from account management.
5. "What did the last person in this role get wrong in their first 90 days?" Why: a peer-level question to Deepa, and it surfaces the actual ramp.

**Tied to the interviewer's path:** none. No profile was researched. Add their career paths to make this one specific (section 13).

## 10. Delivery coaching

Not produced: no working-style assessment was provided.

## 11. Prohibited claims check

Re-read section 4 before any answer. Every slot above stays inside the quoted sentence it rests on.

## 12. Sources

- Your message: the role brief, the background, the stated negatives (E1 to E5), the recruiter's three briefs (quoted).
- Research: no search or fetch sent for any target after the permission declined (see table).

**Research tier: L1 — searches 3 of 6, fetches 0 of 2. All calls refused at the permission step.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet: not produced anyway, since no values round was detected. Would have grounded any values-style answer. |
| 2. Kelverton Rail interview process | unavailable | Loop structure: persona weights stay on relationship priors, not on a documented loop. |
| 3. Kelverton Rail strategy / news | unavailable | CO bank: R5 stays generic. The POV's concrete options would have been checked against current priorities. This is the largest gap. |
| 4. Deepa / Ross public footprint | unavailable | Interviewer read absent; reverse questions role-generic. |
| 5. Representative JD | unavailable | No JD supplied; fit requirements are the recruiter's words, not a JD. |

Refused calls: "Kelverton Rail values", "Kelverton Rail strategy news", "Kelverton Rail interview process": each refused at the permission step.

## 13. Upgrade menu

- The job description text → six requirement rows become `[grounded]` against a JD, and the JD-tagged questions get real coverage.
- The market report's headline findings (paste the shortlist or three bullets; you read it, I have not) → a grounded differentiation for the POV, instead of the generic thesis set.
- Kelverton's values page and recent strategy or news, pasted, or a grant of web search → the CO bank goes from generic to grounded, and the POV can answer the company's current priorities.
- Deepa's and Ross's public profiles → persona weights from their career pattern, and reverse questions tied to their paths.
- Any stated office pattern, right-to-work position, notice or pay term from the role → a gate row, shown prominently, with no bridging.
- Whether a written deliverable beyond the POV is expected → a second build section.

---

*No watch-out line here. It closes the message that presents this file.*
