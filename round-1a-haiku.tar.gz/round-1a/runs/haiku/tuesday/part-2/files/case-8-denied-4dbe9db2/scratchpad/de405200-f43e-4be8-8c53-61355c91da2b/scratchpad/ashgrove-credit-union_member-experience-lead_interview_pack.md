# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Loop mode, three rounds on 26 November 2026:** recruiter screen (30 min); Head of Member Services, your future manager (45 min, mostly behavioural); branch-manager panel (60 min, including a 20-minute complaint-escalation case that also scores the four values).

Built from: the JD text, the values text you copied on 17 November 2026, the July 2026 strategy brief the recruiter sent, the recruiter's email, and your message about your background. No web research ran. Interviewer names are not known yet.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores: VAL (values), EXP (your experience, checked for attribution), JD (a role requirement), CO (company and strategy), CASE (a live problem).
- **Guidance is scaffolding, not a script.** Each answer should be speakable in 90 to 120 seconds.
- **Quoted sentences in your message are yours.** Rehearse those words, not stronger ones.
- **Provenance:** a label leads each cell. [grounded] traces to your message, the JD, the values text or the strategy brief. [inferred] is derived from those, with the derivation named. [generic] is a pattern for the round, not a fact about Ashgrove.
- **Answer slots** are instructions with two honest branches: "if you did this, say how; if not, say so." They are not questions to you.

## 1. Prep triage (9 days)

1. **17 to 19 Nov:** write up to four stories from real work, one each for A2 to A5, using only what happened. This is the biggest gap in the pack. None of your quoted sentences carries a values story.
2. **20 to 21 Nov:** rehearse C2 (the two gaps you stated) and A1 until the plain acknowledgment comes out steadily. C2 decides the hiring-manager round.
3. **22 to 23 Nov:** run B1 against a 20-minute timer twice, then B2.
4. **24 Nov:** walk through the spreadsheet (D1 to D3). Bring a copy with the column headings only, no member data.
5. **25 Nov:** say F1 out loud, answer F2 to F5 in your own words, and rehearse B3 and B4 from the brief only.
6. **26 Nov:** rest.

Everything else is insurance.

## 2. Fit snapshot

Requirements are the JD's own words. Evidence is your sentences, verbatim. **No row is a hard gate:** none of the eight requirements is an eligibility, licence, location or pay term, so none is surfaced as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | Say it in your own words: six years in retail banking, the last three as a branch supervisor. Let the interviewer make the link to the posting's phrase. Your material does not say which of the years were in customer contact; C5 covers that. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | For the branch's formal complaints log, you handled it. Your material shows a branch log, not the process end to end. Answer slot: if you set steps beyond the log, say which and how you decided; if you handled only the log, say so, and say how items reached it and left it. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | "I haven't worked in a contact centre." Then how you would learn the contact-centre side, said as a plan. Never a claim of contact-centre work. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | transferability | Your material shows a monthly spreadsheet for your regional manager. It does not show resolution times. Answer slot: if the spreadsheet held dates or durations, say what it counted and how; if not, say so, and say what you would add first. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | You trained tellers on the escalation script. The posting asks about coaching supervisors, which your material does not show. Answer slot: if you coached a supervisor on an escalation, say what you did and what changed; if not, say so, and say how you would start. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you worked with any team on how a member moved through a channel, say what you did; if not, say so, and say how you would find out where members get stuck. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | Derived from the quote in F2. The word "formal" is not the word "regulated", and your material does not say which rules the log ran to. Answer slot: if it ran to rules set outside Ashgrove's own policy, name them and what you had to do to meet them; if it ran only on branch policy, say so. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. Never a claim of senior presentations. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | You built a spreadsheet that is in regular use. Expect a probe on how it works. The file is inspectable, so bring a copy with no member data. |

## 3. Grounding brief: Ashgrove's stated strategy

**Provenance: [grounded], from the 2026 strategy brief the recruiter sent (published July 2026, about four months old, so current for this pack).**

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Use the brief's own wording. If an interviewer uses different words for the same plan, match theirs and do not correct them.

## 4. Persona weights by round

Weights are questions per persona, set by the relationship and round priors. The recruiter email gives the rounds and who runs each, so the loop is established; no archetype fallback is used.

| Round | Persona (questions) | Why this weight |
|---|---|---|
| Recruiter screen | Conversational (5) | Four logistics rows are required in a 30-minute screen; the biography arc is the fifth. Light skeptic inside the logistics slots. |
| Head of Member Services | Skeptic (5), Data-Driven Prober (4), Values/Behavioral (1) | A hiring manager is buying capability and derisking gaps. The spreadsheet is your one inspectable proof, so a manager who has read it will probe how it is counted. The behavioural round carries one values story. |
| Branch-manager panel | Values/Behavioral (4), Case/Strategist (5), Pressure (2) | The panel scores the four values and runs the escalation case. Pressure is a low-weight composure check. |

**Counter-strategies, in brief:** Skeptic: rehearse the one predictable objection until it is boring, and concede gaps plainly. Prober: know what your numbers count, and say which you do not know. Values: a story for each value, or a scaffold ending in the honest branch. Case: clarify, then structure, out loud. Pressure: pause, restate, and hold your sentence through two follow-ups.

## 5. Round 1: recruiter screen (30 min)

Five questions, below the loop-mode range of eight to twelve: a 30-minute screen cannot carry more, and the four logistics rows are required.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | So, walk me through the journey. | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" and "I handled the branch's formal complaints log" and "trained new tellers on our escalation script" and "I built the monthly complaints spreadsheet our regional manager uses" (your message) | A 90-second arc in the order your sentences give: six years in retail banking, the last three as a branch supervisor; the formal complaints log; training tellers on the escalation script; the spreadsheet your regional manager uses. Say each once, in those words. | The biography question. The arc is four quotes and nothing more. |
| F2 | What is your notice period? | JD | [generic] recruiter-screen logistics pattern | Instruction: give your actual notice period in your own words. If you have not confirmed it, say so, and say when you will. | Logistics slot for notice. The pack supplies no figure. |
| F3 | What are your pay expectations? | JD | [generic] recruiter-screen logistics pattern | Instruction: give your own figure, or ask for the band first. Use only a number you have set. | Logistics slot for pay. The pack supplies no figure and no salary history. |
| F4 | Where can you work, and how often? | JD | [generic] recruiter-screen logistics pattern | Instruction: state where you can work and how often, in your own words. The posting states no location term, but the hub plan may change where roles sit, so ask about it. | Logistics slot for location. |
| F5 | Why are you looking to move? | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Instruction: give your own reason in a sentence or two. Your material states none, so the pack supplies none. | Logistics slot for the reason for leaving. |

**Reverse question for this round:**

- **R5:** "How does the panel score against the four values, and what happens to those scores afterwards?" *Why it lands:* it shows you have read the values text, and the recruiter can answer it.

## 6. Round 2: Head of Member Services (45 min, your future manager)

Ten questions: one values story, five skeptic questions, four prober questions. Most are behavioural.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Tell me about a time you delivered an unpopular truth to leadership. | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt, selection scaffold. Pick a time you told someone senior what they did not want to hear: the stake, the moment you did not soften it, and a working relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log, and only what you did with it. | Persona stem for the behavioural round. No quoted sentence carries a story, so this is a scaffold, not a mapped answer. |
| C1 | Which part of this role would you be weakest at on day one? | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then how you would learn it, as a plan: listen to calls with the team before you change anything. Never a claim of contact-centre work. | Skeptic stem. The weakness is the one you stated, so the answer is the one you already gave. |
| C2 | I don't see contact-centre work or presenting above regional level in your background. How would you handle both in this role? | JD | [grounded] "Never worked in a contact centre" and "I've never presented to anyone above regional level" (your message) | Say, in these words: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level." Then a plan for each, said as a plan. Hold the complaints core, which the log supports. If pressed, concede both gaps plainly. | Highest-ROI prep in this pack: F3 and F8 are the two stated gaps, both in the JD's headline ask. Deepest rehearsal: follow-ups "what would you do in week one of a contact centre?" and "who would you present to first, and what would you show them?" |
| C3 | Why this role, rather than staying a branch supervisor? | JD | [generic] | Give the reason in your own words. Your material states none, so the pack supplies none. If the role's pull is real for you, name the part of the posting that pulls you. Do not borrow the strategy brief as your reason unless it is yours. | Skeptic's motivation probe. No reason is in the material, so the answer is a scaffold. |
| C4 | How would you coach a branch supervisor whose escalations come late? | JD | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you coached a supervisor on an escalation, say what you did and what changed. If not, say so, describe how you trained tellers on the script, and say how you would start with supervisors. | The posting asks about supervisors; your material reaches tellers only (F5). The answer stays inside what you trained. |
| C5 | Walk me through the six years: which roles were customer-facing? | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Scaffold: name each role and its dates, in your own words. Mark which were in customer contact and which were not. The posting's test is customer operations. | The posting's 4+ years line, in its own terms. F1 shows the years but not which were customer-facing, so the answer has to supply that detail. |
| D1 | Walk me through how you built the monthly complaints spreadsheet. | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Story mapped on F9: you built it, your regional manager uses it, and it is monthly. Answer slot: name its columns in your own words. If you chose what each counted, say so; if someone else set the columns, say that. | The Excel reporting requirement, answered with the one inspectable artifact you have. The question is premised only on the quote. |
| D2 | How did you check the spreadsheet against the branch log? | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if you checked it against the log, say how and how often. If you did not, say so, and say what you would check first. | A prober asks how a figure was counted. A check is not in your quotes, so the second branch must allow there was none. |
| D3 | The posting asks for monthly resolution times. Which of your spreadsheet's measures could you turn into one, and which could you not? | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD) and "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if the spreadsheet holds dates you could subtract, say which and what it gives you. If it does not, say so, and say what you would add first. | F4's gap, rehearsed. Resolution times are not in your material, so the honest answer is ready before the probe arrives. |
| D4 | What rules did a complaint on your formal log have to meet, and who checked them? | JD | [grounded] "I handled the branch's formal complaints log" (your message) and "experience handling regulated complaints" (JD) | Answer slot: if the log ran to rules set outside Ashgrove's own policy, name them and what you had to do to meet them. If it ran only on branch policy, say so. | F7 is discovery: "regulated" is the posting's word, not yours. The premise that outside rules applied is not in your material, so the second branch must allow that they did not. |

**Reverse questions for this round:**

- **R1:** "What would a good first 90 days look like for someone who owns complaints across branches and the contact centre?" *Why it lands:* it turns a skeptic round into a planning conversation.
- **R2:** "How do you expect the 2027 hub consolidation to change who owns a complaint once it is open?" *Why it lands:* it shows you have read the strategy brief and asks about ownership, the part the JD is about.
- **R6:** "Which monthly report do you read first, and what decision does it feed?" *Why it lands:* it shows you understand what the reporting is for.

## 7. Round 3: branch-manager panel (60 min, with the 20-minute case)

Eleven questions: four values questions, five case questions, two pressure questions. The panel is also the values round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A2 | When did you put a member ahead of an internal measure? | VAL | [grounded] "I handled the branch's formal complaints log" (your message); value "Members First, Always" (pasted values text) | Raising source: the value "Members First, Always". Scaffold: pick one decision where a member's outcome cost you something you were measured on: the stake, what you chose, what you told the member. If there is none, say so, and use the log only for what you did with one entry. | The panel scores Members First. No quote carries the story, so this is a scaffold. |
| A3 | Tell me about a time a member did not understand what you had told them. What did you change? | VAL | [grounded] "trained new tellers on our escalation script" (your message); value "Plain Words" (pasted values text) | Scaffold: pick a time an explanation failed and you rewrote it. If you changed how tellers explained the escalation script, say what changed and why. If not, say so, and give a time you re-explained something in plainer words, with what you did. | Plain Words is the value your material touches least. The honest branch matters here. |
| A4 | Tell me about a decision where a local detail changed the answer. | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); value "Neighbours, Not Numbers" (pasted values text) | Scaffold: pick one decision where the branch's town changed the outcome: the detail, the decision, what it cost. If none, say so, and say how you would learn what a town needs before a hub change. | Neighbours, Not Numbers is the value the hub plan tests most directly. No quote carries a local story. |
| A5 | Tell me about a problem you kept hold of until it was solved. What happened when it looked solved and wasn't? | VAL | [grounded] "I handled the branch's formal complaints log" (your message); value "Own the Fix" (pasted values text) | Scaffold: pick a problem you found and stayed on past the point where someone else would have passed it on: the problem, the moment it looked closed, what you did next. If none, say so, and give the nearest thing your material carries: the log, and only what you did about an item that came back. | Own the Fix has no mapped story at all. The honest branch is the most likely answer, so rehearse it. |
| B1 | A member has escalated a complaint for the second time. The branch says it is resolved; the member says it is not. You have 20 minutes. Walk us through what you do. | CASE | [generic] | Structure aloud: clarify (what the member asked for, what has been done, any deadline or right to escalate), objective (close it properly, with one named owner), segmentation (one member, one branch, or a pattern), approach, measures, risks. Time-box: about 3 minutes clarifying, 5 structuring, 10 deciding and acting, 2 closing. Keep one owner until solved. Tell the member in plain words. Check any timeline or rule rather than assume one. | A panel case scores structure over the answer. The case is generic: it stands for the escalation the posting names and presumes nothing about this branch. |
| B2 | How would you know each month whether escalations are being handled well? | CASE | [grounded] "report monthly on complaint volumes and resolution times" (JD) | Pick measures that each say what they count: volume, time to resolve, and how many reopen. Name the weakest assumption: what a "resolved" flag means in the log. Say what you would check before trusting the number. | The reporting line is the raising source. The question tests whether you know what a count includes. |
| B3 | Ashgrove plans to move 40% of member service to digital channels by 2028. What would you check first about complaints before that move? | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Start with which complaints come from the channels that will move, and which members cannot use digital. Name one check you would run before the change. Do not quote figures you do not have. | The brief is in hand and current. The company-strategy bank needs it. |
| B4 | Eight branches become five hubs over 2027. What changes about who owns a complaint once it is open? | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Say what the hub changes for ownership and for the member's local contact: who the member talks to, and who decides. Ask one question about the hub design before you answer. | Tests whether you can think at the company's altitude. It links to Neighbours, Not Numbers. |
| B5 | A member cannot see where their complaint is in the app. Which team do you bring in first, and what do you ask them for? | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Name the digital team and the member-facing team. Ask for the journey map and the three most common reasons members call. Say what you would test before changing the screen. | F6 is discovery, so the answer has to stay within what you have done. CASE delivery; the question presumes no past. |
| E1 | That log, then. How much of it was actually you? | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Hold the sentence you wrote: you handled the branch's formal complaints log. Hold through two follow-ups. Concede plainly any part someone else decided, and name it. Never add to the log to make it bigger. | Persona stem for attribution pressure. The honest hold is the quote itself. |
| E2 | Sixty seconds: why should a panel trust a branch supervisor to run complaints across branches and the contact centre? | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Pause, restate, then answer in your own words: what you have run (the log, the escalation-script training), what you have not (the contact centre), and how you would get there. Hold through one challenge. Concede the contact-centre gap plainly. | A time-boxed, pressured version of the headline requirement. The answer is bounded by F2 and F3, not by the posting's wording. |

**Reverse questions for this round:**

- **R3:** "When a complaint reaches a branch manager, what do you wish had come with it?" *Why it lands:* a peer-level, operational question, and the answer feeds the case.
- **R4:** "What could a new person do in their first month that would genuinely help your branches?" *Why it lands:* it is the reciprocity question. Panel members are peers to the team this role sits in, and it signals you are thinking about their load.

## 8. Values and principles cheat sheet

Values text is what you pasted on 17 November 2026 from ashgrovecu.org/about/values. It was not fetched by the pack.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | None mapped. Selection scaffold: A2, ends in the honest branch. |
| Plain Words | If a member needs it explained twice, the explanation was wrong. | None mapped. Selection scaffold: A3, ends in the honest branch. |
| Neighbours, Not Numbers | Every branch is part of its town. | None mapped. Selection scaffold: A4, ends in the honest branch. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | None mapped. Selection scaffold: A5, ends in the honest branch. |

No quoted sentence of yours carries a values story. Each value therefore gets a scaffold, not a mapped answer. Build a real case for each before 26 November, or say plainly on the day that you have none.

## 9. Requirement coverage

| JD requirement | Question IDs covering it |
|---|---|
| 4+ years in financial-services customer operations | F1 (arc), C5 (JD) |
| Own the member complaints process end to end across branches and the contact centre | C1, C2, E2 (JD) |
| Report monthly on complaint volumes and resolution times | B2 (CASE), D3 (JD) |
| Coach branch supervisors on escalations | C4 (JD) |
| Work with digital teams on self-service journeys | B5 (JD) |
| Experience handling regulated complaints | D4 (JD) |
| Confident presenting to senior leaders | C2, E2 (JD) |
| Comfortable with Excel reporting | D1 (JD), D2 |

Every requirement has at least one JD-tagged question. No deliverable was declared, so there is no build section.

## 10. Prohibited claims

What this pack will not coach, and why. Each entry has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end" | Inflated form of F2. The posting widens "I handled the branch's formal complaints log". | F2's quote at its own scope. The pack's own observation: your material says the branch's log, not the process. |
| "Coached branch supervisors on escalations" | Inflated form of F5. Your material says tellers. | F5's quote at its own scope. |
| "Wrote the escalation script" | Inflated form of F5. Your material says "our escalation script". | F5's quote at its own scope. |
| "Handled regulated complaints" | Inflated form of F7. Your material says "formal", not "regulated". | F7's answer slot only. |
| "Presented to senior leaders" | Negative you stated (F8). | "I haven't presented to anyone above regional level." |
| "Worked in a contact centre" | Negative you stated (F3). | "I haven't worked in a contact centre." |

No figure appears anywhere in this pack. You gave none, so none is supplied.

## 11. Sources

- **Provided documents:** the JD text, the values text you pasted (from ashgrovecu.org/about/values, 17 November 2026), the July 2026 strategy brief the recruiter sent, the recruiter's email on the process, and your message about your background (quoted above as "your message").
- **Dossier:** none present.

**Research tier: L1, searches 0 of 6, fetches 0 of 2; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove values | skipped | The pasted values text fixes the four names and their wording. Section 8. |
| 2. interview process | skipped | The recruiter's email fixes the three rounds, who runs each, and the panel's values scoring. Sections 5 to 7. |
| 3. strategy or recent news | skipped | The strategy brief you were sent fixes current priorities. Section 3. |
| 4. interviewer name | n/a | No names were given, so there was no query to form. |
| 5. representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## 12. Upgrade menu

- **Your CV** → the fit snapshot quotes it in place of your message, and rows cite "your CV". Some medium rows may move up once an inspected artifact is in hand.
- **The spreadsheet's column headings, no member data** → D1 to D3 get a grounded artifact, and F9 may move from medium to high.
- **Interviewer names (Head of Member Services and the two branch managers)** → persona weights from their public footprint, and a reverse question tied to their own path.
- **The recruiter's prep email** → whether any pre-work or presentation is expected. Any declared deliverable gets its own build section.
- **One real escalation you handled, in your own words** → A2 to A5 move from scaffolds to mapped stories, and the values cheat sheet fills.
- **Deeper research, offered once:** up to 6 more searches and 2 more fetches, several more minutes, for Ashgrove's recent organisation context and any public interview reports. Want it?
- **Your answers to the two questions in the message** → F6, F7, D4 and B5 are restructured accordingly.
