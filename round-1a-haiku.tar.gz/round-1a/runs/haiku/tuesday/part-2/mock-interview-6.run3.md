Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-6-denied-8686014b/76cb86dd-b6e5-4e9d-abf1-e532da1847a7/scratchpad/larkfield-systems_engineering-manager_interview_pack.md. It covers all three rounds: a shared fit snapshot, a mini-pack per round with its own persona weights and questions, and a shared upgrade menu.

Two things shaped it:
- **Research didn't run.** Web search was refused on this host, so there are no values, no interview-process details and no strategy context. The values cheat sheet is dropped, and the round-3 questions are built on your material only.
- **Your gaps are the centre of it.** The pack treats "I've never managed managers" and "never owned a hardware-adjacent roadmap" as stated gaps. It rehearses a plain acknowledgment plus a plan, not a story that stretches past them. Round 1, question A2 is the one to rehearse hardest.

I also flagged a few numbers you should not repeat as written. The 40 is interviews, not hires. The 60% is yours to defend only as far as you can say how it was counted.

Two questions will sharpen it, and they're the ones I'd most like answered:

1. Can you paste the full job description? The requirements are currently the role summary you gave me, so the JD-tagged questions are not yet worded from the posting.
2. Where is the role based, what is the office or travel pattern, and why are you moving from payments? The pack can't answer the motivation question or the location gate without these.

If you'd like to run a live drill, pick a round and I'll play its interviewer. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. And I can convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

Loop mode, three rounds: shared fit snapshot and sources, then one mini-pack per round, then a shared upgrade menu. Built on your message alone; research did not run (see Sources).

## How to use + type key

- **Personas** = how the question is asked. **Types** = what is being scored.
- **VAL** behavioral and values · **EXP** your own past, probed · **JD** the role's stated requirements · **CO** company and strategy · **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, in 90–120 seconds.
- Answer slots are instructions for the interview. They ask for no reply here.

## Round schedule and persona weights

| Round | Who | Relationship | Dominant personas (weight) | Why |
|---|---|---|---|---|
| 1. Tuesday, 45 min | Director of Engineering (hiring manager) | Hiring manager | Case/Strategist (top), Skeptic (top), Data-Driven Prober (mid) | They are buying capability and derisking gaps. Expect live problems on the device-management roadmap and a probe on the gaps you have stated |
| 2. Thursday, 60 min | Two staff engineers + one product manager | Panel: peer, plus cross-functional | Peer Evaluator (top, staff engineers), Data-Driven Prober (top, staff engineers), Skeptic (mid, PM) | Staff engineers price what you cost their work and probe the numbers. The PM tests the hardware and product partnership |
| 3. Following Monday, 30 min | VP Engineering | Skip-level, values round | Values/Behavioral (top), Pressure (top), Conversational (low) | Scored leadership conversation at altitude. Pressure follows from the gaps. Values are scored, even though the round is short |

Interviewers are not named, so there is no interviewer read. Weights follow relationship priors. The loop is established by your schedule (three named rounds), not by a loop source.

## Fit snapshot (shared across all three rounds)

Requirements are the role description in your message, quoted. It is the recruiter's or your own relay of the role, so it carries `[grounded]`. No full JD was supplied, so the requirement text is not a JD line.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role description) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says a team of six, not two squads and not device management. The bridge stays there: "For three years I led a team of six." Answer slot: if you have set direction across more than one team, say how, in your own words; if not, say so and describe the team you led. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role description), hiring part | "I run our hiring loop for backend roles" (your message) | medium | [grounded] | presentation | The quote already reaches hiring in other terms: backend roles, not the whole org. Lead with the loop in those terms: "I run our hiring loop for backend roles." Adds no figure. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role description), growth part | none given | none | [grounded] | discovery | Your material does not show growth of engineers. Answer slot: if you have grown an engineer into a bigger role, say who and what you did, in your own words; if you have not, say so and say how you would start. |
| F4 | "partner with hardware and product on roadmap" (role description) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | The quote carries roadmap negotiation on a payments team, not with hardware. The bridge states the scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: name one time you negotiated a roadmap with a team that was not your own, and what you did in it. |
| F5 | Hardware-adjacent roadmap ownership (not a stated requirement; implied by "device-management services" and "hardware") | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | A stated absence, and it stays a gap. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan, never as a past. Nothing added to make the gap feel smaller. |
| F6 | Managing managers (not a stated requirement; likely given 11 engineers across two squads) | "I've never managed managers" (your message) | none | [grounded] | capability | A stated absence. Words: "I've never managed managers." Then how you would run that layer, as a plan. |
| F7 | Device-management services, industrial IoT (role description, "device-management services") | none given | none | [inferred] | discovery | Your material is silent on IoT or device services. Answer slot: if any of your backend work touched devices, fleets, or telemetry, say which and how, in your own words; if none did, say so plainly and say what you would learn first. |
| F8 | On-site location and office pattern (gate) | none given | none | [grounded] | hard_gate | Your material does not establish this. The one question about it is in the message's questions. |

Confidence grades your evidence. Provenance grades what this pack wrote. Gap type is a separate call.

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis. No guidance, slot, bridge or drill feedback may assert these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" or "I've led cross-team direction" | Inflated form of F1 | "For three years I led a team of six." The limit is the pack's observation: your material says a team of six, not two squads. |
| "I've managed managers" | Stated negative, F6 | "I've never managed managers." No slot. |
| "I've owned a hardware roadmap" or "I know hardware roadmaps" | Stated negative, F5 | "I've never owned a hardware-adjacent roadmap." No slot. |
| "We cut on-call 60%" or "I cut on-call 60%" alone | Inflated form of F4 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The pack's observation: the material does not say what else moved the number or who else did the work. |
| "I made 40 hires" or "I ran hiring for the whole org" | Inflated form of F2 | "About 40 interviews last year" and "backend roles." Interviews are not hires. |

## Round 1: Director of Engineering (hiring manager), Tuesday

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live problem on device-management services | High. A hiring manager buys capability; a live problem tests it directly | Clarify before structuring. Think aloud. Challenge one premise per case |
| Skeptic | "Which part of this would you be weakest at on day one?" | High. F5 and F6 are the largest gaps and are plain to see | Lead with the plain acknowledgment. Then the plan. Calibrated candor over bluffing |
| Data-Driven Prober | "Walk me through how the 60% was counted." | Mid. The 60% is a headline figure and probers test it | Know the limit of what you can say about the number. Name the weakest assumption you know of |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads are building device-management services and you are new to them. What do you do in the first 30 days?" | CASE | [generic] | Clarify first: what the squads own, what is failing, what the roadmap is. Then a plan for listening to each squad, to hardware, and to product, with what you would change and when. The question makes no claim about your past, so the guidance makes none. | A live problem from the role; the premise is the role's, and `[generic]` because it is a pattern, not a fact about this employer |
| A2 | "Which part of a device-management roadmap would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" | **Highest-ROI prep in this pack.** The hold is the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then the plan: how you would learn it, the first people you would ask, and what you would own in the first quarter. Hold through two follow-ups by returning to the plan, never by adding experience. | F5 is the largest gap and the likeliest objection. JD because it scores the stated scope |
| A3 | "You led a team of six. What did your team own, and where did your remit stop?" | EXP | [grounded] "For three years I led a team of six" (F1 bridge; source: your message, "3 as a team lead of 6") | Story-mapped on F1: the team of six, and the three years. Say what the team owned, in your own words. Answer slot: if you set direction across more than one team, say how; if not, say so and describe where your remit stopped. | F1 is the best evidence for the squad-lead requirement and the likeliest place for a scope probe |
| A4 | "Your team's on-call burden dropped 60%. How was that counted, and which part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number slots. Answer slot: if you can say how the 60% was counted, say it; if you cannot, say so plainly. Name the assumption you would defend least. Say which part was yours, in your own words. | F4 is the headline figure and a probe target; a figure raises these four slots and no others |
| A5 | "You run our hiring loop for backend roles. About 40 interviews last year. How did you decide who advanced?" | EXP | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" | Say what the loop is and how it decides, in your own words. Answer slot: if your loop changed in any way, say what changed and who it was for. Name 40 as interviews, not hires. | F2 is presentation-level evidence for hiring; this probe tests whether it reaches the requirement |
| A6 | "Growth for 11 engineers: name one engineer you have grown, and what you did." | EXP | Open prompt, theme from the role description: "own delivery, hiring and growth for 11 engineers" | Selection scaffold: pick a time you helped an engineer move up or take on more. It needs a named person, what you did, and what happened. Honest branch: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start. | F3 is discovery and has no quote. The theme is the role's own |
| A7 | "Why leave a payments team, and why this role now?" | JD | [grounded] "I run our hiring loop for backend roles" | Motivation is yours to state. The material does not give your reason. Answer slot: say the reason in your own words, specific to this role. Do not reach for the role's appeal you have not checked. | Skeptic probe on F5 and F6 and the motivation probe the role will raise |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would a successful first six months look like for whoever runs these two squads?" | Puts the role's altitude on the table; you learn the real scope |
| "How does device-management work split between the hardware team and this org?" | Probes the seam you will need to own; signals you know the domain exists |
| "What has the on-call and reliability load looked like on these squads?" | Ties to your strongest evidence and asks for a number you can use |
| "What did the last person in this role get wrong?" | Direct, useful, rarely asked; the answer tells you about the roadmap pressure |
| "What would make you confident in me by the end of the first quarter?" | Makes the success criteria explicit |

## Round 2: Panel, Thursday

Two staff engineers (peer) and one product manager (cross-functional). Personas: Peer Evaluator and Data-Driven Prober for the staff engineers; Skeptic for the product manager.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting: "Where's the seam between our teams?" | High. Peers price what the hire costs their work | Propose seam principles, not claims about a seam you have not seen. Show reciprocity |
| Data-Driven Prober | "Which assumption behind that number would you defend least?" | High. The panel includes two engineers, and the 60% is a headline figure | Name the assumption before they do. Say plainly what you do not know |
| Skeptic (PM) | "The hardware team says the sensor cannot do it. Product needs it. What do you do?" | Mid. A cross-functional partner tests the stated partnership | Hold the partnership principle and concede the tradeoff specifically |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Seam principles, not claims: how you would find where the work meets, who decides, and how you disagree with equals. Name what you would bring to their team, not only what you need from it. | A peer stem from the personas file; no claim about your past |
| B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name the weakest assumption in your own words before they do. Answer slot: if you know how the figure was counted, say what it is sensitive to; if you do not, say so plainly. | Defend-the-number slot on F4, aimed at the panel's prober |
| B3 | "How would you split device-management service boundaries between your squads and the firmware team?" | CASE | [generic] | Clarify what each side owns. Propose a boundary principle, state a hypothesis, and say what would change it. Do not claim a boundary you have set before. | A live problem from the role; no past claim |
| B4 | "The sensor cannot support the feature product wants. What do you do?" | CASE | [generic] | Clarify the constraint, the deadline and the customer cost. Offer two options with the tradeoff for each, and say which you would take and why. | Tests the hardware and product partnership, the role's stated scope |
| B5 | "You ran hiring for backend roles. What did you change in the loop, and why?" | EXP | [grounded] "I run our hiring loop for backend roles" | Say what you changed, in your own words. Answer slot: if you changed nothing, say so and say what you would change first. | F2 probe from the prober's side |
| B6 | "What would you need from product in the first quarter, and what would you give them?" | JD | [generic] | Reciprocity framing: name what you need and what your team gives in return. No claim about past collaboration. | Peer and PM reciprocity; the PM tests partnership |
| B7 | "On a reliability fix that spans teams, how do you handle credit?" | EXP | Open prompt, theme from the panel's peer stem; [grounded] "I pushed a reliability quarter through against roadmap pressure" as the nearest story | Story-mapped on the reliability quarter: the stake, the pressure, what you did. Answer slot: if others did part of it, name them and what they did; if you did it alone, say so. | Peer credit probe on F4; the honest answer is what was yours |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Where do your squads and the firmware team disagree most often right now?" | Shows you looked at the seam; invites a real answer |
| "What would a new engineer do in their first month that would help your team?" | Reciprocity: a peer question, and it answers "what can I bring" |
| "What is the hardest reliability problem on the device side?" | Ties to your strongest evidence |
| "How do you handle a roadmap conflict between product and hardware?" | Probes the partnership in the PM's own terms |

## Round 3: VP Engineering, following Monday

30 minutes on values and leadership philosophy. The company's published values could not be fetched (see Sources), so there is no values cheat sheet, and the round is scored on leadership and pressure.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time you delivered an unpopular truth to leadership." | High. The round is labeled values and leadership | Story-mapped from the reliability quarter. Name the beats the sentence states. Say where the material shows no such time |
| Pressure | "Why you, over an internal candidate?" | High. Your gaps are the obvious place to press | Pause, restate, hold the position through two follow-ups, then concede the specific gap |
| Conversational | "So, walk me through the journey." | Low. Still scored | Keep a 90-second arc ready. Do not treat it as unscored |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | Open prompt, theme from persona stem; [grounded] "I pushed a reliability quarter through against roadmap pressure" as the nearest story | Story-mapped from the reliability quarter: the pressure, the decision you held, and the outcome the sentence states. Answer slot: say who the pressure came from and what you said to them, in your own words. If no such time comes to mind, say so plainly, then give the reliability quarter. | Nearest story to the VAL theme; your material does not name who pressed or what was said |
| C2 | "Sixty seconds: why you, over an internal candidate?" | Pressure stem | [grounded] "I've never managed managers" | Hold: your strengths as a team lead, stated from F1. Concede plainly: you have not managed managers, and say how you would close that. Do not fold on the core claim. | Pressure on F6 and F1 |
| C3 | "That result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: name the part you pushed through. Answer slot: say how much of the 60% you can attribute, and to what. If you cannot attribute it, say so. Concede the unattributable part specifically. | Pressure on F4's figure |
| C4 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open-prompt scaffold: pick a time a user or customer outcome beat an internal number. It needs a named customer, the metric you gave up, and the result. If none, say so plainly, then give the nearest thing your material carries, or how you would decide. | A values stem; no claim about your past |
| C5 | "What is your leadership philosophy for managing managers?" | VAL | [generic] | Say what you believe, in your own words. Answer slot: if you have a view on how to lead managers, say it. If not, say so plainly, and describe how you would learn it. | F6 is a stated absence; the question asks for a view, not a past |
| C6 | "How do you grow an engineer who may become a manager?" | VAL | Open prompt, theme from the role description: "own delivery, hiring and growth for 11 engineers"; [grounded] "I run our hiring loop for backend roles" as the nearest story | Selection scaffold: pick an engineer you have grown or would grow toward a bigger role. Honest branch: if none comes to mind, say so plainly and say how you would start. | F3 is discovery. This is the round's growth question |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What does this leader need from a manager of managers in the first year?" | Asks for the altitude and the success criteria in one question |
| "How do you decide when to push a reliability fix against roadmap pressure?" | Tests the same tradeoff you have lived, at the VP's level |
| "What did you learn from the last reorg in engineering?" | Shows you know the org has a history |

## Requirement coverage

| Requirement (source) | Questions |
|---|---|
| Lead two squads (role description) | A1, A3, B3 |
| Building device-management services (role description) | A1, A2, B3, B4 |
| Own delivery (role description) | A1, A4, B2 |
| Hiring (role description) | A5, A7, B5 |
| Growth for 11 engineers (role description) | A6, C6 |
| Partner with hardware and product on roadmap (role description) | A2, B1, B4, B6 |
| Managing managers (not stated; F6) | C2, C5 |
| Hardware roadmap (not stated; F5) | A2, B4 |

## Prohibited claims: rehearsal

Rehearse none of the entries in the prohibited list above. Any answer that drifts into one has failed the probe the question was asking.

## Sources

- Provided documents: your message (role description; candidate summary). No JD, no interviewer names, no company materials.
- Research: **Research tier: L1 — searches 2 of 6, fetches 0 of 2.** Both searches were refused because web search was not permitted on this host.
  - `Larkfield Systems industrial IoT company values`: refused
  - `Larkfield Systems engineering manager interview process device management`: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet (section 10). Dropped: no published values in hand |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have moved loop structure and persona weights. Weights here follow your round schedule instead |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the CO bank. No CO questions in this pack; the CASE questions are generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form |
| 5. representative engineering manager JD | unavailable | Would have supplied JD-level requirements to replace the role description. Requirements here are the role description, quoted |

## Upgrade menu

- The full JD text → six requirements become JD lines, and the JD-tagged questions get their exact wording
- Interviewer names for each round → persona weights per person and a tailored reverse question for each
- Company values, if you paste them or allow a search → a values cheat sheet for Round 3
- Your reason for the move and your location and office pattern (question 2 in the message) → the gate row, and the motivation answer slot (A7)
- Prep time before Tuesday → a prioritized triage section
- Any example of growing an engineer, or of a device-adjacent project → closes F3 and F7 from slots to evidence
