Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-7-denied-1b2a9bb0/def4b243-9a71-4b8f-9854-e143415f0a9d/scratchpad/saltmarsh_live_operations_producer_interview_pack.md, and I've also sent it to you as a rendered file. I built it for a hiring-manager round, since your note doesn't say what Tobias's role is in your loop.

Company research didn't run. Web search was refused in this session, so the pack has no Saltmarsh values, interview structure, strategy, or background on Tobias. Those parts are generic, and the pack lists them in its Sources section. If you paste Saltmarsh's values or careers page, or Tobias's public profile, I can ground them.

The biggest gap is leadership. You've never led a team, and the JD asks you to coordinate four disciplines on each update. Rehearse the team-leadership question (Q1 and S2) through two follow-ups. Give the coordination mechanism you'd use, then say "I haven't led a team" plainly. Your in-app purchase gap is the second-likeliest probe, and the pack covers it too.

Two more offers, neither pushed:
- Say the word and I'll play the Skeptic on S2, the question the pack names as its highest-ROI prep.
- I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, a peer, or on a panel, and did the recruiter name any focus areas or an exercise? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed to be hiring manager, not confirmed. Format: 60 minutes, Friday. Round type: not stated.

Built on the JD you pasted and your background as you described it. Company-specific material is absent: web search was refused in this session, so there are no Saltmarsh values, loop structure, strategy or interviewer read. Those rows are marked in Sources.

## How to use

- Personas are how a question is asked. Types are what it scores.
- **JD**: the question is about a line in the job description.
- **EXP**: your past work, tested for what was actually yours.
- **CASE**: a live problem from the role, scored on structure.
- **CO** (company and strategy knowledge) and **VAL** (values fit): none in this pack, because no company research ran.
- Guidance is scaffolding, not a script. An "answer slot" is an instruction for the interview. It is not a question to me.

Highest-ROI prep: the team-leadership objection, Q1 and S2, rehearsed to the second follow-up. It is the question most likely to come up in some form, and it is where your material is thinnest.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content drops, for two years. Bridge: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two titles and live events are wider than that. If you planned for a second title, or for events beyond content drops, say which and what you decided. If not, say so and describe the one-title calendar you ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | The material is silent on cross-team coordination. Answer slot: name one update where you got other teams to a date, and what each team had to hand over. If there was no such update, say so and describe how you would run one. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | discovery | Your material shows presenting retention numbers. It does not show a post-event review, or who chose the figures. Answer slot: if you reviewed how a content drop performed, say what you looked at and who read it. If there was no such review, say so, and say what you would review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | transferability | The quote is adjacent: it carries writing the checklist and QA's continued use of it, not running releases. Bridge: "I wrote the release checklist our QA team still uses." Answer slot, inside that scope: which parts of the checklist were yours to set. If QA ran the checks without you, say so. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years is in your material, but as associate producer, not producer, and at a puzzle studio. Live-service work shows only in the content-drop line (F6). Bridge: "For four years I was an associate producer at a puzzle-game studio." Answer slot: say what share of those years was live-service work, and what made it so. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Lead with it as written. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented retention numbers. Bridge: "I presented the monthly retention numbers to the studio head." No further practice is added. |
| F8 | "clear written communication" (JD) | none beyond the checklist in F4 | low | [grounded] | discovery | Your material shows one written artifact, the checklist, and no status or review write-up. Answer slot: bring one written thing you produced for a team, and say who read it. If you have none to name, say what you would write first. |
| F9 | "Never led a team" (your message; not a JD line, but the JD's coordinate and own lines are where it will be probed) | none given | none | [grounded] | capability | Stated absence. Words: "I haven't led a team." Then the closure path, as a plan and never as a past: the coordination mechanism you would run first. |
| F10 | "never worked on a game with in-app purchases" (your message; not in the JD text) | none given | none | [grounded] | capability | Stated absence. Words: "I haven't worked on a game with in-app purchases." Then what you would check first on a monetized title, as a plan. |

Pack observation, not words for you: your material shows content drops, a checklist and a retention presentation. It does not show a post-event review, cross-team coordination, or written status work. Expect probes there.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Led design, art, engineering and community" | inflated form of F2, and the negative in F9 | "I haven't led a team." Then the coordination you did, in your own words |
| "Owned the post-event review" | inflated form of F3 | "I presented the monthly retention numbers to the studio head." No review is shown in the material |
| "Ran event calendars for two titles" | inflated form of F1 | One title, weekly content drops, for the last two years |
| "Managed the release checklist with QA" | inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| "Set the KPIs" or "chose the retention definition" | inflated form of F7 | "I presented the monthly retention numbers to the studio head." |
| "I've worked on a game with in-app purchases" | the stated negative in F10 | "I haven't worked on a game with in-app purchases." No slot |

## Persona table

Weights come from the hiring-manager prior: Case/Strategist and Skeptic lead. There are no interviewer signals, and no loop is established, so the weights rest on that prior, not on Saltmarsh's process.

| Persona | How it shows up | Likelihood, and why | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the gaps: leadership, live-service years, IAP | High. Hiring-manager prior, and your gaps sit in the JD's lead lines (F2, F3, F9, F10) | Name the gap plainly, then the plan. Hold two follow-ups | 5 |
| Case/Strategist | Live problems on the calendar: a late event, a retention drop, a QA blocker | High. Hiring-manager prior, and the JD is a run-the-calendar job | Clarify, then objective, segmentation, approach, metrics, risks | 5 |
| Data-Driven Prober | Walks through your retention presentation and your calendar | Medium-high. The JD names retention metrics; your message has one retention line | Say how a figure was counted, or that you don't know | 4 |
| Pressure | Interrupts, asks how much was actually you | Medium. A stress probe on the leadership gap | Pause, restate, hold, then concede specifically | 3 |
| Conversational | Opens with the biography; casual questions on live-ops | Certain to open. Scored casually | A 90-second arc in the quotes' words | 2 |
| Peer | Seams between design, art and engineering over a disputed date | Medium. The coordination line; a peer may sit in | Seam principles, not pretended knowledge | 2 |

Total: 21 questions.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | S1, C2 |
| Coordinate design, art, engineering and community | S2, E1, E2 |
| Own the post-event review and the KPIs | P4, C5 |
| Manage the release checklist with QA | C4, Q3 |
| 3+ years producing live-service games or apps | S3, V1 |
| Experience running a content calendar | P3, V1 |
| Comfortable with player-retention metrics | P1, P2 |
| Clear written communication | C5 |

Not JD lines, but stated gaps: never led a team, covered by S2 and Q1. No in-app purchases, covered by S4 and R4.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name the two-title scope as your weakest line: "I ran one title's weekly content drops for two years." Answer slot: if you have planned for a second title, say which and how. If not, say so, and name the first thing you would learn. | F1 is the JD's headline scope at a smaller size. This is likely to be the opening probe. |
| S2 | "How would you coordinate design, art, engineering and community on each update?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); "Never led a team" (your message) | Give the mechanism in your own words: one owner per update, a shared checklist as the gate, dated handoffs. Then "I haven't led a team." Answer slot: if you have coordinated across teams, name the teams and what you handed each one. If not, say so. Hold two follow-ups on the mechanism. | F2 and F9 together. This is the leadership objection in its JD form. |
| S3 | "Three-plus years of live-service work is the bar. How much of your four years was live-service work?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say what the four years held: the content-drop calendar, and the associate role. If you want to call the content drops live-service, say what they were. If you are unsure whether the title counts, say so. | F5. Honest answer is the scope of the role, not a bigger number. |
| S4 | "You've never worked on a game with in-app purchases. Why would this role be different?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Start plain: "I haven't worked on a game with in-app purchases." Then what you would check first on a monetized title, as a plan. Do not describe monetization work you did not do. | F10. Monetization is not a JD line; it is your stated gap. |
| S5 | "Why this role, and why now, after four years on one puzzle title?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Give your own reason in one sentence, in your own words. It must be one you can repeat under a second question. | Motivation probe. The reason is yours to supply. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A live event is two days late and the art team says it can't make the date. What do you do?" | CASE | [generic] | Structure it: what slipping costs and who it hits; options (cut scope, move the date, split the update); decide with the owners; what goes to QA; what the community team hears. No claim about your past is needed. | Generic live problem. A pattern for the role, not a fact about Saltmarsh. |
| C2 | "Sketch the next quarter's events for two titles. What do you need to know first?" | CASE | [generic] | Clarify before structuring: each title's retention by cohort, the event mix so far, team capacity by discipline, and whether either title takes purchases. Then a calendar by title, with a reason to move each event. | Covers the JD's two-title line at its own scope. |
| C3 | "Retention dropped after an event. Diagnose it." | CASE | [generic] | Segment first: new versus returning players, platform, days since the event. Name the event as one suspect among several. Say what you would check before blaming it. | Metric-diagnosis stem. |
| C4 | "QA finds a blocker two days before a release. Walk me through the call." | CASE | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Structure: go/no-go criteria agreed before this moment, who decides, what slips and what does not. If the checklist you wrote has a go/no-go line, say so. If it does not, say what you would add. | Covers the release-with-QA line. The quote supports the checklist, not who decided releases, so the decision part is a slot. |
| C5 | "Write the first two lines of a post-event review for a content drop, now." | CASE | [generic] | Line one: what the drop was and when it shipped. Line two: the one number that says whether it worked, and the comparison you would use. Say what you would want to know before writing the number. | Covers the post-event review line and the written-communication line. No past claim. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say which cut you showed and what it was for. Answer slot: if you chose the cut, say why. If the numbers came from another team, say whose. If you cannot say how a figure was counted, say so plainly. | F7. Premised only on the quoted presentation. |
| P2 | "Which retention definition did the studio use, and what would it hide?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the definition you were working from, and the assumption you would defend least. Answer slot: if you do not know which definition the studio used, say so and say what you would check. | The JD's retention line, asked as a definition question. |
| P3 | "Which number from the content-drop calendar would you defend first, and which would you defend least?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name a number the calendar tracked, if it tracked one. If it did not, say so and name the one you would track first. | Content-calendar line (F6). |
| P4 | "Describe a time a figure changed what the team did after a content drop." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Open prompt. If you can name a figure that changed a drop, say what it was and what changed. If none did, say so plainly, then say what you would measure after the next drop, and when. | F3. The raising source is the JD's own-the-post-event-review line. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" (your message) | Pause, restate the question, then: "I haven't led a team." Hold on what you can back: the calendar and the checklist. Hold through two follow-ups. Concede specifically: "I don't have a team-lead track record." Do not concede the coordination mechanism. | The deepest rehearsal in this pack, with S2. |
| Q2 | "The retention result you presented: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: "I presented them." Say what you did, at the quote's scope. If you did not build the analysis, say so. Hold two follow-ups before any concession. | Attribution under pressure. |
| Q3 | "Why would QA trust a checklist written by a producer?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: QA still uses it. That is the evidence. If you know how QA's use came about, say so. If not, say so. Concede that QA's edits may matter more than your draft. | Covers the release line, from the QA side. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Wrote the release checklist our QA team still uses" (your message); "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc: the four years, the content-drop calendar, the checklist, the retention presentation, and why this role. Use only the quotes' words. | Scripted arc. Touches the live-service, calendar, release and retention lines in one breath. |
| V2 | "What's a live-ops update you've admired, and why?" | JD | [generic] | Name a real update and say what it did. If you can't name one, say so, then name a puzzle-game update you would study. | Casual, and still scored for live-ops understanding. |

### Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our design and art leads sit beside engineering. Where's the seam, and what happens when a date is disputed?" | JD | [generic] | Name the seam as principles: who owns the date, who can accept risk, who escalates. Do not pretend to know Saltmarsh's seam. Ask about it instead. | The coordination line, in collegial form. |
| E2 | "How do you handle credit when an update spans teams?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Name what others did and credit them by name. For the checklist: you wrote it, and QA uses it. | Credit probe on the release line. |

## Reverse questions

Five are included. No interviewer profile exists, so none ties to Tobias's own path.

1. "What does the first 90 days look like for whoever takes the calendar for these two titles?" Why it lands: it shows you are planning the role, and it tells you what the job is really for.
2. "How is the post-event review run now: who writes it, and who reads the KPIs?" Why it lands: it turns your weakest line (F3) into a question about their process.
3. "Where does the release checklist sit with QA, and who signs off a release?" Why it lands: your checklist experience becomes a question about how they actually ship.
4. "How do these two titles split between purchase and non-purchase revenue, and how does live-ops plan around that?" Why it lands: it turns your IAP gap into a question they have to answer.
5. "What is harder about this calendar than it looks from outside?" Why it lands: it invites candour, and managers tend to answer it directly.

## Sources

Provided documents: the JD and your background message, both in this conversation. No CV file was provided.

Searches sent, all refused, none returned a result. Not retried:
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process Live Operations Producer": refused
- "Saltmarsh Games mobile game studio news strategy": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have supplied value names for a values cheat sheet. None is in the pack, because no values round is detected. |
| 2. Saltmarsh interview process | unavailable | Would have named the loop's rounds. Persona weights stand on the hiring-manager prior, not the company's loop. |
| 3. Saltmarsh strategy and recent news | unavailable | Would have fed the CO questions. None are in the pack, so current priorities are absent. |
| 4. Tobias Wrenfield with Saltmarsh Games | unavailable | Would have given an interviewer read and a tailored reverse question. The reverse questions are generic. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's public profile, or a Saltmarsh values or careers page you paste → grounded values, the loop's rounds, an interviewer read, and a tailored reverse question. Adds the CO questions too.
- The recruiter's email on focus areas or a pre-declared exercise → coverage of any deliverable they name.
- Your CV → the quotes move from "your message" to "your CV", and dates can be checked.
- A non-confidential copy of the release checklist, or the retention slide you presented → F4 becomes an inspectable artifact. F8 moves from low to medium.
- If you have a tuesday-dossier.md, send it → the gaps this prep exposed carry into any later round.
