Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-tuesday-part-2-rooms-case-6-denied-7fa00a0d/280c9ccf-d33b-42aa-b4fe-e402a4a7feb2/scratchpad/Larkfield_engineering-manager_interview_pack.md`. It covers all three rounds with one shared fit snapshot and a question bank per round.

Web research was refused in this session, so the pack is built from your message only. It has no company values, no loop structure and no strategy context. The VP round's values cheat sheet is missing for that reason.

**What the pack says matters most:**

1. **The Director round will likely test management of managers.** You've never managed managers, and that's the gap to rehearse. Answer with your plan and what you'd do first, not with a past. The question is B2 in the file.
2. **The panel will probe hardware.** You've never owned a hardware-adjacent roadmap. Say that plainly, then offer a seam principle instead of claiming to know their seam.
3. **Your 60% on-call result will get attacked.** Expect "what else changed that quarter?" Name the other changes you can't rule out before they do. Say you pushed the reliability quarter through; don't say it was the only cause.
4. **The VP round is framed as values.** Open with one sentence on your leadership philosophy, then one story. Your strongest stories are the reliability quarter and the hiring loop.

**Two things would sharpen it:**

Do you have the full JD or the recruiter's prep email? Those would replace my quoted role description with the actual requirements and show any focus areas for the rounds.

Are the two staff engineers and the PM named, or at least their roles? With names I can weight the panel per person instead of blending them.

If you want the research pass, grant web search permission and I'll rerun it for Larkfield's values and the loop structure.

I can also drill any question live: I'll play the Director and push on B2 with follow-ups, then give feedback against that question's guidance. Or I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager — Loop prep pack

Loop mode: three rounds, one shared fit snapshot, then a mini-pack per round.
Built from your message only. Web research was not run (see Sources), so the company's values, loop structure and strategy are not in this pack.

## 1. Title block

- Role: Engineering Manager, device-management services
- Company: Larkfield Systems (industrial IoT, ~600 people)
- Rounds: (1) hiring manager, Director of Engineering, 45 min; (2) panel, two staff engineers + product manager, 60 min; (3) VP Engineering, 30 min, framed by the recruiter as "values and leadership philosophy"
- Regeneration: none (first build)

## 2. How to use + type key

Personas = how the question is asked. Types = what is being scored.

- **EXP** — what you actually did (scored on whether it is yours)
- **JD** — a probe on a stated requirement
- **CASE** — a live problem to structure
- **BEH** — a scenario asking for past behaviour or a leadership stance
- **REV** — a question you ask them

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## 3. Prep triage

Prep time was not stated, so this is the full pack. Priority order:

1. **B2 (Director round): the management-of-managers gap.** Highest-ROI prep. You have never managed managers, and the Director will most likely test it.
2. **Section 5 F3 and the hardware-roadmap answer.** You have never owned a hardware-adjacent roadmap. The panel's PM and staff engineers will probe it from two angles.
3. **C1 (VP): leadership philosophy in your own words.** Recruiter-framed values round with no published values in hand.
4. **The 60% on-call story.** Use it in all three rounds. Rehearse the attribution, not the number.

Everything else is insurance.

## 4. Fit snapshot (shared across rounds)

Requirements come from your role description. No full JD was supplied, so every requirement below is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" — your role description | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | presentation | Your material shows hiring, in backend roles, at the loop level. Say that in those terms: "I run our hiring loop for backend roles." The growth half is not shown here. Answer slot: if you grew anyone's career on your team, say who and how, in your own words; if not, say so and describe what you would do with 11 engineers. |
| F2 | "Lead two squads building device-management services" — your role description | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your quote is one team of six, not two squads of eleven in total. Say the team, the six, and the three years, and do not stretch the number. Answer slot: how you would split the two squads and what would make you change the split. |
| F3 | "partner with hardware and product on roadmap" — your role description | "I've never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | Your own negative. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan and never as a past. |
| F4 | "own delivery, hiring and growth for 11 engineers" — your role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | presentation | Your material shows delivery under roadmap pressure, with one outcome measure. Say what you pushed and what it did. Answer slot: how you would know the 60% was the quarter and not other changes, and which of the team's decisions were yours. |
| F5 | Management of managers — not in your role description; implied by the Director and VP rounds | "I've never managed managers." — your message | none | [grounded] | capability | Your own negative. Words: "I've never managed managers." Then the leadership plan for managers, said as a plan. |
| F6 | Seniority — your background | "9 years engineering, 3 as a team lead of 6" — your message | high | [grounded] | none | Quote already reaches the seniority claim. No bridge needed. |

Notes on the table:
- F3 and F5 are negatives you stated, so their words can be given back verbatim. No bridge is inflated.
- F1, F2 and F4 are where the probes will land. Each is a quote with an answer slot.

## 5. Prohibited claims (built locally, binds every guidance cell)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | F5, your negative | "I've never managed managers." Plus the plan. |
| Owned a hardware-adjacent roadmap | F3, your negative | "I've never owned a hardware-adjacent roadmap." Plus the plan. |
| The 60% on-call drop was caused by you alone | Inflated form of F4. The material says you pushed the quarter through, not that you were the only cause | F4's quote at its own scope: you pushed it, and the burden dropped afterwards. The limit is the pack's observation: the material does not isolate your cause. |
| Grew engineers into promotions | Not in material | Not coached. If it is true, the answer slot in F1 is where to say it. |

## 6. Persona weights per round

| Round | Dominant personas | Reasoning | Counter-strategy |
|---|---|---|---|
| Director (hiring manager, 45 min) | Case/Strategist + Skeptic | Hiring managers buy capability and derisk gaps. Expect live problems on the roadmap and direct probes on F5 and F3 | Clarify, then structure. Rehearse the Skeptic's objection until it is boring |
| Panel (2 staff engineers + PM, 60 min) | Data-Driven Prober (staff) + Peer Evaluator (PM) | Staff engineers test depth and numbers. The PM prices the seam with hardware and product. Panel members' names are unknown, so weights are blended | Ask the question you are scored on before you answer it. Name the weakest assumption in the 60% figure first |
| VP Engineering (30 min) | Values/Behavioral + Pressure | Recruiter framed it as values and philosophy. Leadership philosophy is scored under pressure | Say the philosophy in one sentence first, then a story. Hold a position through two follow-ups |

## 7. Question banks

### Round 1: Director of Engineering (hiring manager, 45 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you run your hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Say the loop, the roles, and the 40 interviews in those words. Answer slot: which parts of the loop you designed and which you inherited. | F1 is the evidence for the hiring requirement; EXP because it tests what you actually did |
| B2 | "You've never managed managers. How would you lead two leads who haven't had a manager?" | JD | [grounded] "I've never managed managers." — your message | The highest-ROI rehearsal. Hold: "I've never managed managers." Then the plan: how you would learn it, the first thing you would do with the two squads, and who you would ask. Hold through two follow-ups by returning to the plan, never by adding to it. | F5 is the gap this round is built to test. The question is a premise the JD raises and your quotes do not carry, so the second branch of the answer is the honest one |
| B3 | "Our squads build device-management services with hardware. Which hardware decision would you make first?" | CASE | [generic] | Clarify first: what the hardware constraints are, who owns them, what breaks. Structure: the decision, the options, the risks. The question needs no claim about your past | Live problem on the roadmap. Presupposes no fact about your experience |
| B4 | "Tell me about a time you pushed a reliability investment through against roadmap pressure." | BEH | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Tell the reliability quarter in your words: what you pushed, the pressure, what the team gave up, and the 60% with its limit. Answer slot: which parts of the outcome you can attribute to the quarter | F4 is your strongest story. The Director will test whether it is yours |

### Round 2: Panel (2 staff engineers + PM, 60 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you measure whether the device-management services are healthy?" | CASE | [generic] | Clarify what "healthy" means for devices at scale. Name the metrics, the denominator and the assumption you would defend least | Data-Driven Prober angle. Presupposes nothing about your past |
| C2 | "Your on-call number dropped 60%. What else changed that quarter?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Hold the quote. Name the other changes you know of, say which you cannot rule out, and say what the quarter changed for you specifically. Answer slot: what you did to check the attribution | F4's weakest assumption. Name it before they do |
| C3 | "Where would your team's and the hardware team's roadmaps collide, and how would you handle it?" | PM-seam | [generic] | Propose a seam principle, not a claim to know their seam. Say what you would need from hardware and product first | Peer Evaluator angle. F3 is the honest limit here: say you have not owned a hardware-adjacent roadmap, then the seam principle |

### Round 3: VP Engineering (values and leadership philosophy, 30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What is your leadership philosophy?" | BEH | [generic] | Say it in one sentence first. Then one story from your quoted sentences: the reliability quarter (F4) or the hiring loop (F1). Answer slot: which story carries the philosophy, and where none does, say so | The recruiter framed this as values. No company values are in hand, so no values cheat sheet |
| D2 | "Tell me about a time you pushed back on leadership." | BEH | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message (paraphrase check: this is the quote's own clause, not a new claim) | Say the pushback and the result. Answer slot: whether the pushback landed, and what it cost | F4's pressure element. Hold the story to what you stated |
| D3 | "What would you do with a manager you hired who was stronger than you in the domain?" | BEH | [generic] | Keep the answer in the leadership plan, not in past management. Say what you would do first | F5 is the honest limit: no managers managed yet. Present a plan |

## 8. Reverse questions (≥5, with why each lands)

1. "What does success look like for this role at six months?" — why it lands: it shows you are planning the first half, not hoping.
2. "How do the two squads split the device-management scope today?" — why it lands: it reveals the actual structure and what you would inherit.
3. "Where does hardware sit relative to product in roadmap decisions?" — why it lands: it shows you are already thinking about F3's gap.
4. "What has the team learned from the last quarter's reliability and delivery tension?" — why it lands: it links to F4 without claiming the story as yours.
5. "What would make the hiring of managers succeed here?" — why it lands: it converts F5 into a peer conversation.

## 9. Sources

- Provided documents: your message (the role description, your background and the three rounds). No JD, no recruiter email.
- Research tier: L1 requested. Web search was refused by permission in this session, so no searches or fetches ran.
- Target accounting:
  - Company values and public strategy: unavailable (search refused)
  - Round/loop structure: unavailable
  - Interviewer public footprint: skipped (no names given)
  - Representative JD: unavailable

## 10. Upgrade menu

- The full JD text → turns the role-description quotes into `[grounded]` requirement rows and may surface new gates
- The recruiter's prep email → coverage of any pre-declared deliverable and the panel's focus areas
- The panel's names and roles → per-member persona weights instead of blended ones
- The Director's name → persona weights and a tailored reverse question, from public footprint
- Company's published values (pasted or sent when research is allowed) → a values cheat sheet for the VP round
