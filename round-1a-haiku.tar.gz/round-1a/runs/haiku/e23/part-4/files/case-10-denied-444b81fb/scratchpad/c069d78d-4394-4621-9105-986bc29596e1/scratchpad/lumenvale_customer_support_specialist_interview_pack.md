# Interview prep: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Round: first interview, a text chat on Telegram, set up by Marcus Hale (talent team). Built from your summary of the job ad and your background. No research was run.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored: **VAL** (values), **EXP** (your past work), **JD** (a requirement from the ad), **CO** (company knowledge), **CASE** (a live problem). Guidance is scaffolding, not a script. In a written chat, keep answers to short paragraphs and reread them before sending.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier" (your message) | medium | [grounded] | none | No gap. Say the years and the role as you stated them. Expect a probe on whether a service advisor role counts as support. |
| F2 | "Zendesk or similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Your material names Freshdesk, a similar ticketing tool, used daily. Words: "I use Freshdesk every day." Nothing you gave shows Zendesk, so do not imply it. Answer slot: see A2. |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Email volume is not the same as written clarity, so the bridge is not stretched. Answer slot: if an email you wrote got a reply or thanks from a customer, say which in your own words; if none stands out, say how you write a customer reply. |
| F4 | "confidence handling escalations" (your summary of the ad) | "trained four new starters on our refunds process last year" (your message) | low | [inferred] | transferability | Refunds is adjacent to escalations, not the same thing. Make that case and its limit: "I trained four new starters on our refunds process last year." Answer slot: if an escalation came to you, say which and what you did; if none did, say so plainly. |
| F5 | Software-company setting (not in your ad summary) | "I've never worked for a software company" (your message) | high | [grounded] | capability | The absence is one you stated. Words: "I haven't worked for a software company." Then how you would learn their product, said as a plan and never as a past. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Zendesk experience | Inflated form of F2: the ad names Zendesk, you named Freshdesk | F2's quote at its own scope. A2's slot covers the Zendesk question |
| Handled escalations | Inflated form of F4: you trained others on refunds | F4's quote at its own scope. The pack's observation: your material shows training others, not escalations |
| Ran onboarding, or led the refunds process | Inflated form of "trained four new starters on our refunds process" | The training quote at its own scope |
| Software-company experience | Negative you stated (F5) | "I haven't worked for a software company." No slot |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Presses the Zendesk gap, the escalation gap and the software background | High. A team lead is buying capability and checking gaps, so the prior is Case plus Skeptic (hiring-manager pattern), and the ad lists the gaps directly | Plain acknowledgment where you stated the gap, then a bridge from what you did state, then a plan |
| Case / Strategist (weight 3) | A live support scenario in the chat | Medium. Team leads often test this in writing | Clarify first, then steps, then the reply |
| Data-Driven Prober (weight 2) | Asks how the 60-a-day figure was counted | Medium. The figure is a sentence you wrote, so it gets read closely | Defend the number: how it was counted, the weakest assumption, what was yours |
| Conversational (weight 2) | An opener and "what do you know about us?" | Medium. Chat openers feel casual but are scored | A 90-second arc, and treat "what do you know about us?" as scored |

## Question banks

Depth follows weight. This bank is short (eight questions) because a summary of the ad and your background are all I had to work from.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked for a software company. What would you need to learn first?" | JD | [grounded] "I've never worked for a software company" (your message) | Plain acknowledgment: "I haven't worked for a software company." Then a plan, not a past: what you would learn first, such as their product and their ticket workflow. Do not claim knowledge of their product | F5 is the one gap you stated outright. The question asks for a plan, so give one |
| A2 | "Our ad asks for Zendesk experience. Have you used it?" | JD | [grounded] "I use Freshdesk every day" (your message) | Highest-ROI rehearsal in this pack. Answer slot: if you have used Zendesk, say how, in your own words; if not, say so plainly, then return to Freshdesk: "I use Freshdesk every day." Hold through two follow-ups by returning to Freshdesk, never by adding to it | F2 is the most likely objection. The ad names Zendesk, so this will come up in some form |
| A3 | "Tell me about a time you handled an escalation." | JD | [grounded] "trained four new starters on our refunds process last year" (your message) | Open prompt, with its theme from the ad's escalation line. Pick a time you passed something up or held a position with a customer. If none comes to mind, say so plainly, then give the nearest thing your material carries: the refunds training, and how you would handle the next escalation | F4's gap is the second likely probe. The honest branch is part of the answer |
| A4 | "Why this role?" | JD | [generic] | Name one thing in the ad you want to do, in your own words. Do not describe their product or strategy you have not researched | A motivation check from the Skeptic. It asks for your reason, so the guidance supplies no fact about you |

### B. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes that their refund still hasn't arrived after ten days, and they're angry. Write your first reply." | CASE | [generic] | Acknowledge the wait. Check the facts (order, refund route, date). Say what happens next and by when. Say what you cannot yet promise. Keep it to four to six sentences | Tests written tone and judgement on a live problem. It needs no claim about your past |
| B2 | "A customer says the app 'stopped working after the update.' You don't know the cause yet. What do you tell them, and what do you ask?" | CASE | [generic] | Clarify before guessing: device, version, what they tried, the exact error. Say what you are checking. Do not guess the cause. Say when you would escalate to engineering | Tests clarify-before-structure, in writing. Generic by design |

### C. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say you answered around 60 calls and emails a day. How was that counted, and what part of it was yours?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Defend the number. Answer slot: say how you know the figure, in your own words. If you don't know how it was counted, say so plainly. Name the weakest assumption you know of, and say which part was yours. Do not supply a method or a baseline | The number is a magnet for probing. F3 rests on the same sentence |

### D. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me a bit about yourself." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); "I use Freshdesk every day" (your message); "trained four new starters on our refunds process last year" (your message) | A 90-second arc with three beats: the role and years, the daily Freshdesk use, the refunds training. Each beat is a clause your sentences state. Stop there | A chat opener is scored. This is the biography answer |
| D2 | "What do you know about Lumenvale?" | CO | [generic] | Say what the ad tells you, and ask one thing you don't know. Do not describe their product, strategy or values, because this pack did not research them | A company-knowledge question with no research behind the pack, so the guidance stays generic on purpose |

### Requirement coverage

| Requirement (ad) | Covered by |
|---|---|
| 2+ years in customer support | F1, D1 |
| Zendesk or similar ticketing tool | F2, A2 |
| Clear written communication | F3, B1, B2 |
| Confidence handling escalations | F4, A3 |
| Software-company setting (not in your ad summary) | F5, A1 |

## Reverse questions

Ask at least some of these. Each one shows you are planning for the role.

| Question | Why it lands |
|---|---|
| "What does a typical first week look like for someone in this role?" | Shows you are planning, and tells you how much training to expect |
| "Which ticketing tool does the team use day to day?" | Shows you are ready for Zendesk-style tools, and tells you how far your Freshdesk work carries over |
| "What gets escalated, and where does it go next?" | Tests your escalation judgement and shows you thought about the handoff |
| "How does the team measure a good reply?" | Shows you care about quality, not only volume |
| "What did the last person in this role find hardest?" | Turns a gap into a conversation about the work, and shows where the role is hard |

## Sources

- Your message describing the role, your background and the job ad's requirements, as summarised.
- Marcus Hale's Telegram message, as quoted in your message.
- Research tier: L0. No search or fetch was run.

## Upgrade menu

- The full job ad text → turns the four summarised requirements into `[grounded]` quotes and sharpens A2 to A4
- Any Zendesk, escalation or software-company experience you have, if true → upgrades A2 and A3 from a slot to a story
- The support team lead's name → an interviewer read and a tailored reverse question
- Standard research on Lumenvale (values, interview process, recent news) → a values cheat sheet and a grounding brief
- The recruiter's process email → coverage of any test or assignment they name
