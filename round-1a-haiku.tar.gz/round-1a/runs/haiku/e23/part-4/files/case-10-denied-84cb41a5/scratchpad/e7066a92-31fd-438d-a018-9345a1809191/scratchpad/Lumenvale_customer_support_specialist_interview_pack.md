# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote)
**Company:** Lumenvale Software
**Interviewer:** Support team lead (name not given). Invitation came from Marcus Hale, talent team.
**Format:** Written interview in a Telegram text chat. The message says the offer and onboarding would also happen in the chat.

Built from your summary of the job ad and your background. No full job description and no web research were available (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **EXP** = your past work, tested for accuracy. **JD** = the job's stated requirements. **CASE** = a live problem. **VAL** = values. **CO** = company knowledge.
- Guidance is scaffolding, not a script. Write answers in your own words.

## Before you reply to Marcus: verify the recruiter and the company

The hiring process here runs only on Telegram, including the offer and onboarding. Scammers often use this pattern. Please check before you share anything personal.

- **Find the job yourself.** Go to the company's website by typing its address, not by clicking a link from the chat. Confirm the Customer Support Specialist posting is there and matches the one you applied for.
- **Check the recruiter.** Confirm that Marcus Hale appears on the company's own website or on a LinkedIn profile that names the company. Ask him to confirm the interview by email from an address on the company's own domain, as shown on its website. Reply by email, not only in Telegram.
- **Check the company exists.** Look for a registered business record in the country it operates from, a real physical or support address, and reviews from other candidates or staff. Be cautious if there is little or none.
- **Never pay anything** for equipment, training, a "security check" or a placement fee.
- **Do not share bank details, a passport or ID scan, or national ID numbers in this chat.** You can give those only after a written offer arrives by email from the company's domain and you have verified it.
- **Treat urgency and pressure as warning signs**, such as "reply in the next hour" or a request to move to another app.
- **The interview itself is a text chat**, which is normal for remote support roles. Its format does not show that the company is legitimate. The checks above do.

## Fit snapshot

Requirements are your own summary of the ad, since the full text was not supplied. Evidence cells quote only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (your summary of the ad) | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" (your message) | high | [grounded] | none | Your sentence already reaches this. Lead with the years and the volume in those words. |
| F2 | "Zendesk or a similar ticketing tool" (your summary of the ad) | "I use Freshdesk every day" (your message) | high | [grounded] | presentation | Freshdesk is a similar ticketing tool, so the quote reaches the requirement. Say it as you said it: "I use Freshdesk every day." Do not claim Zendesk. |
| F3 | "clear written communication" (your summary of the ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Your material shows volume of email, not how clear the writing is, so the bridge cannot go further. Answer slot: if a reply of yours was praised, or a written answer prevented a follow-up, say what it was. If not, say how you check your writing before sending. |
| F4 | "confidence handling escalations" (your summary of the ad) | none given | none | [grounded] | discovery | Your material does not show escalations. Answer slot: if you passed a case up, or took one on, say what you did and how it ended. If you have not, say so and say what you would do first. |
| F5 | Experience with a software company's product or customers (role-family, not in the ad) | "I've never worked for a software company." (your message) | none | [generic] | capability | You stated this absence yourself, so the plain acknowledgment is yours to give: "I haven't worked for a software company." Then how you would learn the product, said as a plan, never as a past. |

## Prohibited claims

Each entry lists its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have used Zendesk" | Inflated form of F2. The sentence says Freshdesk. | "I use Freshdesk every day." If asked about Zendesk, say you have not used it and how you would learn it. |
| "I have worked for a software company" | Negative you stated (F5) | "I've never worked for a software company." |

## Question banks

Persona weights for this round: Prober 4 (heavy), Skeptic 3, Rapport 2. The team lead is likely to read your CV closely and to test the software-company gap in the chat.

### Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through a typical day in your current role." | EXP | [grounded] "answering around 60 calls and emails a day" | Start with the volume in your own words: 60 contacts a day across calls and email. Describe what your day looked like, in order. | F1 is the strongest line you have, and an open question about your day lets you use it directly. |
| A2 | "How many of those were escalated, and what did you do with them?" | EXP | [grounded] "answering around 60 calls and emails a day"; [grounded] "I use Freshdesk every day" | Answer slot: if you passed cases up, say which kind and how you decided. If you did not, say so plainly and describe how you handled difficult cases yourself. | F4 is the gap. The question's premise, that some were escalated, is raised by the ad, not by your material. |
| A3 | "How do you use Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Describe what you do in the tool, in your own words. Answer slot: if you set up views, macros or automations, say so. If not, say you used it as set up. | F2 is the requirement this question tests. Keep the answer to what you did. |
| A4 | "We use Zendesk. How quickly could you get productive in it?" | JD | [grounded] "I use Freshdesk every day" | Say that you use Freshdesk every day, not Zendesk. Then describe how you would learn Zendesk. Give a plan, not a past. | The ad names Zendesk. The gap is in the tool, not in your daily work. |
| A5 | "Tell me about a time you handled an escalation." | JD | [generic] scaffold; no quote carries escalations | Selection scaffold: "pick a time a customer's issue went beyond first-line, name the stake, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it." | Open prompt on the ad's escalation requirement. Your material does not supply a story, so you choose the example. |
| A6 | "How did you train the four new starters on refunds?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped on the quoted sentence: you trained four people, on refunds, last year. Answer slot: describe how you structured the training, but only if you did it. | The training is your strongest evidence of written and process communication. Keep the words to the sentence. |
| A7 | "What steps of the refunds process did you teach?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: name two or three steps in your own words. If you were trained on the process and did not write it, say so. | Premise-as-question: it asks about the process you taught, which is the quoted sentence's content. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked for a software company. Why should we believe you'll fit a product support team?" | JD | [grounded] "I've never worked for a software company."; [grounded] "answering around 60 calls and emails a day" | **Highest-ROI prep.** Hold: your customer-side experience is 60 contacts a day, Freshdesk daily, and training others. Concede: you will need to learn the product and that will take time. Hold the position through two follow-ups by returning to the volume and the tool, not by adding claims. | F5 is the most likely objection. The hold is only what the quotes carry. |
| B2 | "Show me a short reply to a customer whose refund is two weeks late." | CASE | [generic] | Write the reply live. Acknowledge the delay, say what you will do, and give a time you can keep. Do not promise anything you cannot control. | A live problem from the role. It asks about no past work, so no claim about your experience is needed. |
| B3 | "When has a message of yours been understood on the first try?" | JD | [grounded] "answering around 60 calls and emails a day" | Open prompt. If you have one, say what it was and what made it clear. If not, say so and describe how you check a message before sending it. | F3 is thin. Your answer is the evidence the team lead is looking for. |
| B4 | "A customer asks a question you cannot answer. What do you do?" | JD | [generic] scaffold | Say what you would check, who you would ask, and what you would tell the customer while you wait. Do not guess. | Covers the escalation requirement from the other side. |
| B5 | "How did you know the four people you trained had learned the process?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: if you checked their work or their results, say what you checked. If you did not, say so plainly and describe how you would check next time. | Tests whether the training result is evidence or just an event. |

### Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What drew you to customer support?" | VAL | [generic] | Give one honest reason in your own words. Do not invent a story. | Open prompt, low risk. Keeps the chat warm. |
| C2 | "What would you want to learn about our product in your first month?" | CO | [generic] | Name two areas, such as how a feature works or how customers use it. Do not claim knowledge of the product you do not have. | Shows you are thinking about the role, not only about yourself. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | A1, B1 |
| Zendesk or a similar ticketing tool | A3, A4 |
| Clear written communication | B2, B3 |
| Confidence handling escalations | A2, A5, B4 |
| Software company product knowledge (not in the ad) | B1, C2 |

## Reverse questions

1. "What does a typical first month look like for this role?" Why it lands: it shows you are planning for the job, not just the offer.
2. "How are escalations passed from first line to the product team?" Why it lands: it shows you understand the escalation process the ad asks about.
3. "Is there a tone or style guide for written replies?" Why it lands: it shows you care about clear writing, which the ad lists.
4. "What does a new team member most often need help with in their first 90 days?" Why it lands: it invites a candid answer about the ramp, which is your main gap.
5. "How would you like candidates to follow up after the chat?" Why it lands: it shows you are thinking about the process and the next step.

## Sources

- **Provided documents:** your Telegram message from Marcus Hale; your summary of the job ad; your background summary.
- **Research tier:** L1, with web search not run. The search tool was not permitted in this session, so every research target below is `unavailable`.

| Target | Status | What it would have moved |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet. Omitted because no published values are in hand. |
| 2. Lumenvale interview process for support roles | unavailable | Loop structure and persona weights. Weights are set from the round type and your summary only. |
| 3. Lumenvale strategy or recent news | unavailable | CO bank. The CO question in C2 is generic. |
| 4. Interviewer name and footprint | n/a | No name given beyond "support team lead". |
| 5. Representative JD for the title | unavailable | Would have turned the summary requirements into quoted lines. |

## Upgrade menu

- The full job description text → the summary requirements become quoted, `[grounded]` lines, and the JD questions gain exact wording
- The team lead's name and role → persona weights and a tailored reverse question
- The round type (team lead as your future manager, or a peer) → reweights the banks
- Company or recruiter contact details you verified → a check of the company's official email domain and a sharper pre-chat check
