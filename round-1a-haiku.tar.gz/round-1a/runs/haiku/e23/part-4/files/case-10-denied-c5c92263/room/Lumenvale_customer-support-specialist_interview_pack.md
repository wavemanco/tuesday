# Interview prep: Customer Support Specialist, Lumenvale Software (remote)

Candidate: Imani. Format: text chat on Telegram with the support team lead (invite from Marcus Hale, talent team). Interviewer's relationship to you: not yet confirmed, so banks are weighted as a hiring-manager round.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **JD** (the ad's requirements), **EXP** (your past work), **CASE** (a live support problem), **VAL** (values; none detected here), **CO** (company knowledge; not researched).
- Guidance is scaffolding, not a script. Each answer should run about 90 to 120 seconds, or about 150 words in chat.
- Every claim about your experience is one of your own sentences, quoted in the Provenance column. Rehearse only what those sentences support.

## Research tier

L0: provided material only. Two web searches were attempted and refused (permission not granted), so nothing about Lumenvale's current products, values or team was checked. See Sources.

## Verify the hiring process first

Do this before you send any documents or personal details. The invite asks for a text-chat interview, and says the offer and onboarding will also be done in the chat. Legitimate employers do not normally complete an offer or onboarding in a messaging app. I could not verify Lumenvale or Marcus Hale from here.

- Find the job on Lumenvale's own website, reached by typing the address yourself rather than following a link in the Telegram message. Check that the title and ad text match what you applied for.
- Check Marcus Hale's name on Lumenvale's official site or LinkedIn. Ask for a company email address and a video call on a company platform, and see whether the reply comes from that domain.
- Check that Lumenvale is a registered company (for the UK, Companies House; for the US, the state registry).
- Never send bank details, passport or ID scans, National Insurance or Social Security numbers, or a full date of birth in the chat before a verified offer.
- Never pay for equipment, training, background checks or "onboarding" fees. A real employer does not ask for these.
- Treat pressure ("reply today", "offer ready this week") and requests to move to another app as warning signs.
- Do not install software, click links to forms, or share one-time codes sent to you.
- If any check fails, stop replying. Report the account to Telegram, and to the company through its official contact details.

## Fit snapshot

Requirements are your summary of the ad, quoted as you gave them. Ask for the full ad text to make these verbatim (see upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" (ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | none | No gap. Say the years and the setting in your own words. |
| F2 | "Zendesk or a similar ticketing tool" (ad, as you summarised it) | "I use Freshdesk every day" (your message) | medium | [grounded] | none | The ad allows "similar", so Freshdesk should reach it. Expect a probe on Zendesk specifically. Do not claim Zendesk. |
| F3 | "clear written communication" (ad, as you summarised it) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | transferability | Your material shows volume of written contact, not its quality. The chat interview tests quality directly. Words: "I answer around 60 calls and emails a day." Answer slot: if a reply you wrote changed an outcome, say what it was. If none stands out, say so. |
| F4 | "confidence handling escalations" (ad, as you summarised it) | none given | none | [inferred] | discovery | The material does not show escalations. Answer slot: if you handled one, say what it was and where it went. If you did not, say so and say how you would learn the escalation path. |
| F5 | Software company experience (not listed in the ad) | "I've never worked for a software company" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked for a software company." Then how you would learn their product, as a plan and never as a past. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. The pack will not coach them.

| # | Claim not to make | Basis | Honest form |
|---|---|---|---|
| P1 | Any escalation handling story | F4 has no quote | "I haven't handled one I can describe; here is how I would approach it." |
| P2 | Any Zendesk experience | F2 quotes Freshdesk only | "I use Freshdesk daily; I'd learn Zendesk's features quickly." |
| P3 | Owning or managing the refunds process | Your sentence says you trained four starters on it | "I trained four new starters on our refunds process." |
| P4 | Software or SaaS product knowledge | F5 | "I haven't worked for a software company." |
| P5 | Any metric beyond your own figures | Only "around 60" a day, "three years", "four starters" are stated | Repeat those figures as given. For any count, answer "I don't know how it was counted" if asked. |

## Persona weights

Hiring-manager prior (the team lead is most likely the manager): Case/Strategist and Skeptic dominate. Data-Driven Prober and Conversational are added because this is a chat round, where written care is scored from the first message.

| Persona | Shows up as | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Live support scenario in chat | High | A team lead buys the ability to handle a real queue | Clarify, then structure, then answer |
| Skeptic | Probing the gaps: no software company, no escalations | High | F4 and F5 are the visible gaps | Rehearse the one objection until plain |
| Data-Driven Prober | Asks how the 60 a day was counted | Medium | A round figure invites a follow-up | Say what you know and what you don't |
| Conversational | Casual opener, "tell me about yourself" | Medium | Chat openers are scored too | A 90-second arc, prepared |
| Pressure | Time-boxed replies, challenge to one answer | Low to medium | Chat rounds sometimes time responses | Pause, restate, hold one position |

## Question banks

Question IDs are letter-by-persona. Depth follows weight.

### A. Case/Strategist (5)

| ID | Type | Question | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| A1 | CASE | "A customer writes that their refund has not arrived after 10 days. What do you do?" | Clarify the order and payment method first. Then check the refund status, set a timeline, and write back in plain words. Escalate only if the timeline breaks. | [grounded] "I trained four new starters on our refunds process last year" (your message) | Tests the refund process you know, from the agent's side |
| A2 | CASE | "A customer is angry about a billing error on an account you can't see. What's your first reply?" | Acknowledge, state what you will check, give a time to reply. Do not promise a fix you cannot make. | [grounded] "answering around 60 calls and emails a day" (your message) | Tests the written tone under pressure |
| A3 | JD | "How would you use Zendesk for a ticket queue you've never seen?" | Name the features you know from Freshdesk (views, macros, tags), say you would learn Zendesk's equivalents. | [grounded] "I use Freshdesk every day" (your message) | Covers the Zendesk-or-similar requirement |
| A4 | CASE | "A bug blocks many customers at once. What do you tell the first customer who writes?" | Say what you know, what you have passed on, and when you will update. | [inferred] none | Tests calm writing on a team issue |
| A5 | JD | "Walk me through how you would handle a ticket you can't resolve yourself." | Describe the handoff: what you record, who you pass it to, and what the customer hears. | [grounded] "I trained four new starters on our refunds process last year" (your message) | Covers the escalation requirement at the level you can defend |

### B. Skeptic (4)

| ID | Type | Question | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| B1 | EXP | "You haven't done escalations. How would you handle one?" | Answer slot: if you have, describe it. If you have not, say so plainly, then give your approach: clarify, check, hand off with notes. | [grounded] "I've never worked for a software company" (your message) | Highest-ROI prep. The ad asks for escalation confidence and your material does not show it. |
| B2 | EXP | "What makes you the right choice over someone who has worked in software support?" | Do not argue down the software background. Give the transfer: customer volume, written care, the same tool daily. Then say what you would learn first. | [grounded] "I've never worked for a software company" (your message), [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Tests whether you can hold a gap without bluffing |
| B3 | EXP | "Which part of this role would you be weakest at on day one?" | Name the product and the escalation path. Give a concrete ramp plan. | [grounded] "I've never worked for a software company" (your message) | A probe that rewards honest self-assessment |
| B4 | EXP | "Why would you leave an energy supplier for a software company?" | Give the motive in terms of the job, not the employer's sector. | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Motivation consistency |

### C. Data-Driven Prober (3)

| ID | Type | Question | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| C1 | EXP | "You said around 60 calls and emails a day. How was that counted?" | Answer slot: "I don't know how it was counted" is an honest answer. Say whether it was a daily estimate or a log. | [grounded] "answering around 60 calls and emails a day" (your message) | Defend-the-number. The figure is round and approximate, so say so. |
| C2 | EXP | "Which part of your Freshdesk use would you defend least?" | Name the part you are least sure of, such as how far you configured it or whether you used reports. | [grounded] "I use Freshdesk every day" (your message) | Tests the depth of the tool claim |
| C3 | EXP | "How do you know your written replies were clear?" | Answer slot: if you have feedback or a measure, say so. If not, say how you check a reply before sending. | [inferred] none | Tests written quality, which the chat itself scores |

### D. Conversational (3)

| ID | Type | Question | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| D1 | EXP | "So, tell me about yourself." | A 90-second arc: three years in customer service, daily ticketing work, the refunds training, then why this role. | [grounded] "3 years as a customer service advisor at an energy supplier" (your message), [grounded] "I trained four new starters on our refunds process last year" (your message) | Chat openers are scored |
| D2 | EXP | "What are you doing to get better at support work right now?" | Name one thing you have done. If nothing recent, name one plan and when you will start. | [inferred] none | Shows growth without inventing it |
| D3 | JD | "How would you write to a customer when you have bad news?" | Lead with the fact, then the next step, then a time. Keep it short. | [grounded] "answering around 60 calls and emails a day" (your message) | Written communication, tested in your own reply |

### E. Pressure (2)

| ID | Type | Question | Guidance | Provenance | Rationale |
|---|---|---|---|---|---|
| E1 | EXP | "You have one sentence. Why you?" | Pause. Give one sentence with one fact from your material. | [grounded] "3 years as a customer service advisor at an energy supplier" (your message) | Tests composure in a short-answer format |
| E2 | EXP | "That seems thin. Be honest: how much of the refunds process did you own?" | Hold: you trained four starters on it. Do not claim to have owned it. | [grounded] "I trained four new starters on our refunds process last year" (your message) | Tests the difference between training and ownership |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| 2+ years in customer support | A2, D1 |
| Zendesk or similar | A3, C2 |
| Clear written communication | A2, C3, D3 |
| Confidence handling escalations | A5, B1 |

## Reverse questions

Ask two or three in the interview, chosen for the role:

1. "What does a good first month look like for this role?" Why it lands: it shows you are planning the job, not just applying.
2. "What are the most common reasons a ticket gets escalated here?" Why it lands: it shows you understand the escalation path the ad asks for.
3. "How do you train new support staff on tools and process?" Why it lands: it connects to your own training experience.
4. "What does the team do with feedback on written replies?" Why it lands: it signals that writing quality matters to you.
5. "What is the next step in the hiring process, and through what channel will it happen?" Why it lands: it gives you a verifiable next step, and it is a fair check on the process (see Verify the hiring process first).

## Sources

- Provided: your message (summary of the ad, background, the Telegram invite text).
- Research tier: L0. Two web searches (Lumenvale Software careers; Lumenvale Software recruitment and Telegram interview) were attempted and refused: permission not granted. No fetches. Target accounting: company values, current strategy, loop structure: unavailable.

## Upgrade menu

- The full ad text → turns the summarised requirements into verbatim quotes and may add requirements the pack does not yet cover
- The team lead's name and role → tailored reverse questions, and persona weights read from their public footprint
- Confirmation whether the team lead will be your manager or a peer → reweights the banks (current weights assume a manager)
- A web search, when allowed → checks Lumenvale and Marcus Hale against official sources, and adds company-strategy questions
- An escalation example you handled, even a small one → replaces the answer slots in B1 and F4 with your own words
