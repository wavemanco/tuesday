Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-e23-part-4-rooms-case-10-denied-47d13b51/e401bd9a-f4f4-4dc7-8982-f1e73397d29c/scratchpad/lumenvale_customer_support_specialist_interview_pack.md`. It's built only from your message and job-ad summary, because web search was refused, so I couldn't check the company or its values.

**Before you share anything, verify this recruiter.** A Telegram-only process with no video call, no company email, and an offer and onboarding "completed in this chat" matches common fake-job scams. Before you reply with a time:
- Find the Customer Support Specialist role on Lumenvale's official careers site, and check that it's the same listing you applied to.
- Check that Marcus Hale works there, using the company's own website or LinkedIn, not a link from Telegram.
- Ask for an interview contact from a company email address, and ask for the team lead's name.
- Don't send ID, bank details, or a payment for equipment or training in this chat until you've confirmed the role through an official channel.

**The pack's most important prep:**
- **The software-background objection (A1).** This is the question most likely to come up, and the pack has you state the fact plainly and then give a concrete ramp plan. Don't claim software experience you don't have.
- **Zendesk (A2).** Freshdesk is close, but say you haven't used Zendesk if that's true.
- **Escalations (A3, F4).** Your material doesn't show any, so the honest answer is what you did do, such as refunds decisions and training others.
- **The 60-a-day figure (C1, C2).** Be ready to say how you counted it and which assumption you'd defend least.

The pack is shorter than usual, because your material is thin and padding would teach the wrong answers.

Two questions that would sharpen it:
1. Can you paste the full job ad text? The summarised requirements would become exact quotes.
2. Have you used Zendesk at all, even briefly, or only Freshdesk?

Offers, not pushed:
- Want to run a live drill? I can play the Skeptic on A1 and give feedback against its guidance.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like a Word version of the pack, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale_customer_support_specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist, Lumenvale Software (remote)

Interviewer: the support team lead (unnamed). Recruiter contact: Marcus Hale, talent team. Round: text chat on Telegram. Built on the job-ad summary and your message; no company research was available (see Sources), and no time to reply has been chosen yet.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the ad's requirements), EXP (what you actually did), CASE (a live problem), VAL (values; none weighted here, since no values page is in hand), CO (company knowledge; none, since research was unavailable).
- Guidance is scaffolding, not a script. Rehearse it aloud in 90 to 120 seconds, in your own words.
- Where the guidance says **answer slot**, the interviewer is likely to probe that area. Answer with whichever branch is true for you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | 2+ years in customer support (job ad, as you summarised it) | "3 years as a customer service advisor at an energy supplier" (your message) | high | [grounded] | presentation | The quote already reaches the requirement in other terms. Bridge rewords only: "For three years I was a customer service advisor at an energy supplier." |
| F2 | Zendesk or a similar ticketing tool (job ad) | "I use Freshdesk every day" (your message) | medium | [grounded] | presentation | Freshdesk is a ticketing tool of the kind the ad names. Bridge rewords only: "I use Freshdesk every day." Zendesk is not shown; see question 2 below. |
| F3 | Clear written communication (job ad) | "answering around 60 calls and emails a day" (your message) | low | [inferred] | discovery | Volume shows you write often. It does not show how clear your writing is. Answer slot: if you have a reply you are proud of, say what it did for the customer, in your own words. If not, say how you check a message before sending it. |
| F4 | Confidence handling escalations (job ad) | none given | none | [grounded] | discovery | Your material does not show escalations. Answer slot: if you handled one, say what it was and what you decided, in your own words. If you did not, say so plainly and describe the nearest case you do have. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2; the material shows Freshdesk | "I use Freshdesk every day." Limit, as the pack's observation: your material shows Freshdesk, not Zendesk. |
| Owned refund decisions | Inflated form of your refunds training | "I trained four new starters on the refunds process last year." |
| Worked for a software company | A negative you stated | "I've never worked for a software company." Plain acknowledgment; no slot needed. |

## Personas

| Persona | How it shows up in text chat | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic | Pointed questions about the gaps: no software background, no Zendesk | High. A team lead buying capability will test the ad's stated requirements directly, and text removes any cover for a vague answer. | Rehearse the software-background objection until it is plain and calm. Acknowledge what you have not done, then show a concrete ramp plan. |
| Case / Strategist | A live support scenario from the role | High. Hiring-side interviewers in support often open with a ticket. | Clarify, then structure, then act, then set a next step. |
| Data-Driven Prober | Follow-ups on the 60-a-day figure | Medium. A single number in a CV-style message invites one or two checks. | Say how you know the figure, and name the assumption you would defend least. |
| Conversational / Rapport | A friendly opener and a "tell me about yourself" | Medium. Chat openers are casual but still scored. | Use a 90-second arc. |
| Pressure | Time-boxed or repeated challenges | Low to medium. Text rarely time-boxes, but follow-ups can come quickly. | Hold a position through two follow-ups before conceding anything. |
| Values / Behavioral | Not weighted | Low. No values page is in hand. | Add a values cheat sheet if you send Lumenvale's values. |

## Question banks

Weights: Skeptic highest, then Case and Prober, then Conversational and Pressure. Total is short of the usual range, because your material is thin and padding would teach you the wrong answers.

### Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never worked for a software company. What would you need to learn first about how we work?" | JD | [grounded] "I've never worked for a software company" (your message) | **Highest-ROI prep in this pack.** Start with the plain fact: "I've never worked for a software company." Then give a plan, not a past: what you would learn first, such as the product, how bugs reach engineering, and how the team's release notes read. Hold through two follow-ups by returning to the plan. Follow-up 1: "What would your first week look like?" Follow-up 2: "What have you read about us?" Answer only with what you have actually read; if nothing yet, say so and say you will before the next round. | This is the objection most likely to come up in some form, and it is a negative you stated, so the plain acknowledgment has a source. The answer is a ramp plan, never a claimed software background. |
| A2 | "The ad asks for Zendesk or a similar tool. You use Freshdesk. How would you get up to speed on ours?" | JD | [grounded] "I use Freshdesk every day" (your message) | Say which Freshdesk features you use day to day, in your own words. Say how you would learn the team's setup. Answer slot: if you have used Zendesk, say when and how. If you have not, say so plainly. | F2: a similar tool, not the named one. The question is aimed at the ad's Zendesk line. |
| A3 | "Tell me about an escalation you handled. What did you decide and why?" | JD | [grounded] job ad line "confidence handling escalations" (your summary); [grounded] "trained four new starters on the refunds process last year" (your message) | Answer slot (F4): if you handled an escalation, say what it was and what you decided, in your own words. If you did not, say so plainly, then describe the nearest case you do have: how you handled refunds decisions you were trained on, and where you would pass one on. | F4 is silent in your material. This is the open prompt the ad's escalations line raises. |
| A4 | "How do you check a reply is clear before you send it?" | JD | [grounded] job ad line "clear written communication" (your summary); [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot (F3): say what you actually do before sending, in your own words. If you have a reply you are proud of, say what it did for the customer. If you do not check replies in any particular way, say so and say how you would start. | F3: volume is not clarity, so the honest answer is your own process. |
| A5 | "What would you do if a customer's complaint was about something you couldn't fix yourself?" | JD | [grounded] job ad line "confidence handling escalations" (your summary) | Structure: acknowledge the customer, state what you can and cannot do, record the case clearly, escalate with the facts, and set a date for the next update. Make no claim about a past event unless you have one. | This is the escalation requirement asked as a decision, not a record. |

### Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer's refund hasn't arrived and this is their third message. Walk me through your reply." | CASE | [generic] | Clarify what happened and what the customer needs. Check the history, decide what you can do now, escalate what you cannot, and set a dated next step. Speak the steps aloud. | A live support problem from the role. Generic, so it makes no claim about your past. |
| B2 | "A bug report needs engineering. What do you put in the handover so they don't come back with questions?" | CASE | [generic] | Cover reproduction steps, customer impact, a link to the ticket, and what you already tried. Say what you would check before handing over. | The escalation requirement in a live form. Generic, so no past claim is needed. |

### Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted around 60 calls and emails a day." | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Answer slot: say how you know the figure (your own tally, a system report, or an estimate), in your own words. If it is an estimate, say so. | The figure is the only number in your material, so it draws the probe. |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "answering around 60 calls and emails a day" (your message) | Name the weakest assumption before they do, such as whether it is a daily average or a busy-day figure. If you do not know, say that plainly. | Coaches you to name the limit yourself. The pack does not supply the assumption. |

### Conversational / Rapport (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey into support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "trained four new starters on the refunds process last year" (your message) | A 90-second arc: the energy supplier, the daily volume, the Freshdesk work, and training four new starters on refunds. Use only those facts. | An opener that is still scored. This is your strongest arc. |
| D2 | "What do you use in Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" (your message) | Name two or three features you actually use, in your own words. Keep it short. | Chat openers are scored for specifics. Tied to F2. |

### Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Three years at an energy supplier and no software background. Why should we take that bet?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" (your message); [grounded] "I've never worked for a software company" (your message) | **Hold, then concede.** Hold the position: three years of daily volume and a ticket tool you use every day. Through two follow-ups, stay on that. Concede specifically when pushed: you do not yet know the product. Say how you would close that gap. Do not fold on the core claim. | Text pressure is a sharp follow-up, not a raised voice. Hold what you can back, concede what you cannot. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a new support specialist's first month look like here?" | Shows you are thinking about the work, not only the offer. |
| R2 | "How is the handover between support and engineering set up?" | Ties to A5 and B2, and shows you understand where escalations go. |
| R3 | "Which ticketing tool does the team use, and how are views and macros managed?" | Shows you know the tool question is coming up and want the detail. |
| R4 | "What do customers most often contact you about, and what has changed recently?" | Shows interest in the customer, and gives you the topics to prepare for. |
| R5 | "What are the next steps in the process, and how long does it usually take?" | Clarifies the Telegram-only process, which also helps you check it. |

## Sources

Provided documents: your Telegram message from Marcus Hale and your summary of the job ad and your background. No attachments.

Research tier: L1, searches 0 of 6, fetches 0 of 2. Both search attempts were refused by a permission prompt, so no company research was run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale values | unavailable | Values cheat sheet, section not built. Would have moved the values section. |
| 2. Lumenvale interview process | unavailable | Loop structure. Would have moved persona weights. |
| 3. Lumenvale strategy / recent news | unavailable | CO bank. Would have moved B-series questions toward company knowledge. |
| 4. Interviewer name | n/a | The team lead is unnamed, so there is no query to form. The upgrade menu says what a name would unlock. |
| 5. Representative Customer Support Specialist JD | unavailable | Would have turned the summarised requirements into `[inferred]` quotes. |

Searches attempted: "Lumenvale Software careers Customer Support Specialist" (refused); "Lumenvale Software company" (refused).

## Upgrade menu

- The full job ad text → six requirement rows become quoted `[grounded]` lines, and A3 and A4 use the ad's exact wording.
- Whether you have used Zendesk, even briefly → A2 becomes a story-mapped answer instead of an answer slot.
- An escalation, or a reply you wrote, that you handled yourself, in your own words → A3, A4 and the F3 and F4 rows become story-mapped answers. Only if it is true.
- The team lead's name → a reverse question tied to their path, and an interviewer read.
- Lumenvale's published values or careers page text → a values cheat sheet, and company facts for the CO bank. Research was refused in this session.
- The date and time you can attend → a prep schedule sized to your time.
