**Before you prepare anything: please don't send the fee, passport photo, bank details, or deposit the cheque.** Requests like these are common in job scams. A real interview doesn't need any of them, and a cheque you deposit and partly forward to a "vendor" is a known fraud pattern, because the cheque bounces later and the money you sent is gone. Also, the reply address is at a `.example` domain, which isn't a real company domain. Before any further contact, check that Brennock Facilities Ltd exists through the Companies Registration Office and its own website, and reply only through contact details you find there.

Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-e23-part-6-rooms-case-12-denied-f5f54db3/158c9edd-9d2b-4e88-88a2-d6b72c689d04/scratchpad/brennock_remote_admin_assistant_interview_pack.md`. I didn't run any web searches, so it uses only your email and your message. I built it for a 30-minute call with the office manager, which I treated as a hiring-manager round.

What to expect and how to prepare:

- **Likely opener:** "Tell me about yourself." Keep it to about 90 seconds: the clinic, the appointment book for four physios, the unpaid invoices you chased, and Word.
- **Most likely hard question:** "This job is more admin than a receptionist role. What would you do on day one that you haven't done?" Be specific about the gaps: travel booking and invoice processing. Chasing unpaid invoices is not the same as processing them, so don't blur the two.
- **Where you're thin:** travel booking has no evidence in your material, and Excel is "okay". If you have one real example of either, rehearse it. If you don't, say so plainly and describe how you'd learn the tools.
- **Don't stretch it:** "ran the appointment book" is not "managed executive calendars", and "chased invoices" is not "processed invoices". Rehearse only what you actually did, in your own words.
- **Reverse questions:** ask about the typical week, the travel and approval systems, and who provides equipment. A legitimate employer will answer that last one plainly.

Would you like me to play the Skeptic and run a live drill on the day-one question? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

Can you paste the full text of the ad? Your summary is enough for this pack, but the exact wording would let me quote the requirements rather than paraphrase them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock_remote_admin_assistant_interview_pack.md -----
# Brennock Facilities Ltd: Remote Administrative Assistant, interview prep pack

**Candidate:** Aoife
**Role:** Remote Administrative Assistant, Brennock Facilities Ltd
**Interviewer:** office manager (name not given)
**Round:** 30-minute video call
**Research tier:** L0, provided material only. No searches were run.

## Before you prepare: the email is a warning sign

Do not pay the €95 fee, send a passport photo, send bank details, or deposit any cheque for this job. Those requests are common in job scams. A legitimate interview does not require any of them, and a cheque you deposit and partly forward to a "vendor" is a known fraud pattern: the cheque bounces later and the money you sent is gone. Check the company independently (for example, the Companies Registration Office register and the company's own website) before any further contact. The reply address is at a `.example` domain, which is not a real company domain. Do not reply to that address with personal or financial details.

The rest of this pack is written so that you can prepare for the role in any case, but treat the interview as unconfirmed until you have verified the company.

## How to use + type key

- **Personas** = how the question is asked. **Types** = what is being scored.
- Types: **JD** = role requirements. **EXP** = your past experience. **CASE** = a live problem. **CONV** = a conversational opener. **VAL** = values (none detected here).
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words, and stop at what you actually did.

## Prep triage

Time available is not stated. Assuming a few evenings:

1. Rehearse A1 and A6 until you can deliver them in about 90 seconds each. These are the most likely openers and the hardest objection.
2. Rehearse A3 and A5, the two areas where you have the least direct evidence.
3. Prepare two or three reverse questions from section 11.
4. Everything else is insurance.

## Fit snapshot

Requirements come from the ad as you summarised it, not verbatim text. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" (ad, as summarised by you) | "I ran the appointment book for four physios" (your message) | medium | [grounded] | transferability | Your material shows a shared appointment book for four people, not calendars for executives. Words: "For two years I ran the appointment book for four physios." Answer slot: if you handled clashes or rescheduling rules, say how you decided, in your own words; if not, say so and describe how you ran the book. |
| F2 | "booking travel" (ad, as summarised by you) | none given | none | [inferred] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so and say how you would learn the company's booking tools. |
| F3 | "preparing documents in Word" (ad, as summarised by you) | "I'm good with Word" (your message) | medium | [grounded] | none | Your quote reaches the requirement, but it is self-rated with no example behind it. Expect a probe; have one concrete document ready to describe. |
| F4 | "preparing documents in Excel" (ad, as summarised by you) | "okay with Excel" (your message) | low | [inferred] | discovery | Your material does not show what you have done in Excel. Answer slot: name one spreadsheet task you have actually done; if none, say so plainly. |
| F5 | "processing supplier invoices" (ad, as summarised by you) | "chased unpaid invoices" (your message) | medium | [grounded] | transferability | Chasing unpaid invoices is adjacent to processing them. Words: "I chased unpaid invoices." Answer slot: if you entered, matched or approved invoices, say what the steps were; if you did not, say so and say what you would learn first. |

Requirement-coverage: F1 covered by A2; F2 by A3; F3 by A6 and A4; F4 by A4; F5 by A5.

## Prohibited claims

These claims are not to be coached. Each one goes further than what you said.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed executive calendars | Inflated form of F1 | "I ran the appointment book for four physios." The limit is this pack's observation: your material shows one shared book, not executive calendars. |
| Experienced with travel booking | Inflated form of F2 | Nothing about travel is in your material. Use the answer slot in A3. |
| Experienced with supplier invoice processing | Inflated form of F5 | "I chased unpaid invoices." The observation is that chasing is not processing. |
| Advanced Excel | Inflated form of F4 | "Okay with Excel." |

## Question banks

Persona weights: the round is with the office manager, so the hiring-manager prior applies: Case/Strategist and Skeptic dominate. Conversational sets the tone for the opener.

### Case / Strategist (highest weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A2 | "How would you keep a busy calendar organised for someone with many competing meetings?" | JD | [grounded] "I ran the appointment book for four physios" | Story-map on F1: the appointment book for four physios, and the two years. Name how you kept the book accurate, in your own words. Answer slot: if you handled clashes, say how you decided; if not, say so and describe how you ran the book. | F1 is the evidence for calendar management and the likeliest place to be probed. |
| A3 | "Have you booked travel before? Walk me through a booking." | JD | none given | Scaffold, no story. Honest branch: "if you have booked travel, describe one booking; if not, say so plainly and describe how you would learn the company's booking tools and approval rules." | F2 has no evidence, so the pack writes no claim about travel. |
| A4 | "How comfortable are you with Excel? What have you used it for?" | JD | [grounded] "okay with Excel" | Say it as you said it, then name one task you have actually done. Answer slot: if you have no example, say so plainly. | F4 is a low-confidence rating; the probe is likely. |
| A5 | "Walk me through how you would process a supplier invoice from receipt to payment." | JD | [grounded] "chased unpaid invoices" | Separate what you did (chasing) from what you would do (processing). Describe the steps you would follow and the checks you would make. Answer slot: if you did any part of processing, describe it; if not, say so. | F5 is the adjacent work; this question tests the gap. |

### Skeptic (high weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A6 | "This job is more admin than a receptionist role. What would you do on day one that you have not done before?" | JD | [grounded] "I ran the appointment book for four physios" | Hold the position that the book transfers. Name what you have not done (travel booking, invoice processing) and give a concrete first-week plan. Hold through two follow-ups; concede the gap specifically rather than folding on the whole claim. | This is the highest-ROI prep: the most predictable objection, and the gaps are in the requirements most likely to be probed. |
| A7 | "Why should I hire someone with two years at a clinic over someone with office experience?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Name what the clinic work gave you that transfers, using only the appointment book and invoice chasing. Do not claim office experience you do not have. | A pressure version of the skeptic question. |
| A8 | "Your manager is away and two executives need flights for the same day, and an invoice is overdue. How do you prioritise?" | CASE | [generic] | Clarify first: deadlines, who decides, what is reversible. Then order the tasks and say what you would tell each person. | A live problem from the ad's responsibilities. It asks about no past work. |

### Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about yourself and what drew you to this role." | CONV | [grounded] "I ran the appointment book for four physios"; "good with Word" | A 90-second arc: the clinic, the appointment book, the invoices you chased, Word. Keep to these facts. | The usual opener; it is scored for economy and fit. |
| A9 | "Any questions for me?" | CONV | [generic] | Ask one or two questions from section 11. | Rapport interviewers weight this slot heavily. |

## Reverse questions

1. "What does a typical week look like, and what share is calendars, travel and invoices?" Why it lands: shows you want the real workload.
2. "Which systems do you use for travel booking and invoice approval?" Why it lands: tests the tooling you would need.
3. "Who would I work with most day to day, and how are conflicting requests prioritised?" Why it lands: asks about the working relationship.
4. "How is remote work set up, including equipment and who provides it?" Why it lands: a legitimate employer answers this plainly, and the answer is a useful check on the email you received.
5. "What would a good first 90 days look like?" Why it lands: shows you are planning the role.

## Sources

Provided material only: the recruiter email and your message. No searches were run at L0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Values cheat sheet not built; L0 was used |
| 2. interview process | unavailable | Loop structure not confirmed; L0 was used |
| 3. company strategy / recent news | unavailable | Grounding brief not built; L0 was used |
| 4. interviewer name | n/a | No name given |
| 5. representative JD | unavailable | The ad as you summarised it fixes the fit snapshot, so the JD tier is partly met |

## Upgrade menu

- The full text of the ad → the requirements in the fit snapshot become quoted rather than paraphrased
- The office manager's name → a tailored reverse question and persona weights from public information
- Confirmation of the company's registration and website → a decision on whether to proceed (this is outside the pack's scope)
- Any travel-booking or invoice-processing experience you have → the answer slots in A3 and A5 become story-mapped
