# Interview prep: Remote Administrative Assistant, Brennock Facilities Ltd

**Read first: this email has several scam markers. Do not pay, do not send documents, and do not deposit any cheque until you have verified the company (section 1).**

Research tier: L0. No web search was run. Everything below comes from your message and the job email you pasted.

## 1. Red flags in the invitation email

| Red flag in the email | Why it matters |
|---|---|
| €95 "equipment registration fee" to a "supplier's account" before your slot is confirmed | Legitimate employers do not charge candidates to be interviewed or registered. Paying a third-party IBAN is a classic advance-fee fraud. |
| Passport photo and bank details "before the interview" | Not needed for a 30-minute screening call. This is the material used for identity theft and account takeover. |
| €1,850 cheque to "deposit", then send the balance to an "approved vendor" | This is the overpayment or fake-cheque scam. The cheque is usually fraudulent. It may look cleared for days, then bounce, and the money you sent is gone. You may also be used as a money mule. |
| Payment details are a personal-looking IBAN, not the company's own account | Real companies pay their own suppliers, and they do not ask candidates to pay suppliers for them. |
| Email domain is `hr@brennock.example` | `.example` is a reserved placeholder domain that cannot be a real company's email address. Treat the address as fake unless you find the company's real domain yourself. |
| Role mixes remote admin with "processing supplier invoices" and cash handling | Remote payment-handling roles are a common cover for money-mule recruitment. |

**What to do now:**
1. Do not pay the fee, do not email a passport or bank details, and do not deposit or spend against the cheque.
2. Verify the company independently. Search the Companies Registration Office (CRO) register for "Brennock Facilities" and check the registered name, number and address. Find the company's website through a search engine, not through the link or contact details in the email. Phone the switchboard you find there and ask whether they are recruiting for this role and whether they ever charge candidates a fee.
3. Ask the sender one question in writing: "Does the company charge candidates any fee at any stage?" A real recruiter will answer plainly. A scammer will push urgency.
4. If you have already sent money or details: contact your bank now, report the transfer, and report the scam to An Garda Síochána (or your local police) and to the bank's fraud team.

I cannot confirm from here whether Brennock Facilities Ltd exists. Step 2 above settles that.

## 2. If the company checks out, here is the prep

Everything below is built from your message. Items marked `[inferred]` are my reading of what the role usually involves, not something you have told me.

### 2.1 Fit-gap map

| Requirement (job ad) | Your evidence (your words) | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|
| Managing calendars | "ran the appointment book for four physios" (your message) | medium | [grounded] | presentation | Your material says you ran the appointment book, so say that in those terms. Name what the book involved: bookings, changes, and keeping four diaries apart. Do not claim calendar software skills you have not stated. |
| Booking travel | none given | none | [inferred] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, say how. If you have not, say so plainly and describe how you would approach it. |
| Preparing documents in Word | "good with Word" (your message) | medium | [grounded] | none | Your quote already reaches this. Give one concrete example of a document you produced, in your own words. |
| Preparing documents in Excel | "okay with Excel" (your message) | low | [grounded] | discovery | Your material says "okay", so do not stretch it. Answer slot: say what you have done in Excel. If the work has been limited, say so plainly and say what you are practising now. |
| Processing supplier invoices | "chased unpaid invoices" (your message) | low | [grounded] | transferability | Chasing unpaid invoices is the receivables side. Processing supplier invoices is the payables side. Say what you did on invoices, and do not claim you have processed supplier invoices unless you have. |
| Remote working | none given | none | [inferred] | discovery | Your material does not show remote work. Answer slot: say whether you have worked remotely, and how you keep organised and reachable if you have not. |

### 2.2 Prohibited claims (things not to say, even under pressure)

| Not to claim | Basis | Honest form |
|---|---|---|
| That you have processed supplier invoices through to payment | Stretched form of "chased unpaid invoices" | "I chased unpaid invoices. Here is what that involved." |
| That you are advanced in Excel | Stretched form of "okay with Excel" | "I'm okay with Excel. Here is what I have used it for, and what I'm building up." |
| That you have managed travel bookings or remote work | Not in your material | Describe how you would do it, and say what you have not done. |

### 2.3 Likely questions and answer guidance

Format: question, type, provenance, guidance. Speakable in about 90 seconds each.

**A1. "Walk me through your background."** Type: VAL / JD. Provenance: [grounded] "two years as a receptionist at a physiotherapy clinic". Guidance: Give a 90-second arc: the clinic, the appointment book for four physios, the invoice chasing, then why you want this role. Rationale: an opener that every interviewer asks.

**A2. "How would you manage a busy calendar for several people?"** Type: JD, CASE. Provenance: [grounded] "ran the appointment book for four physios". Guidance: Use the appointment book as your example. Describe how you kept four diaries clear, how you handled changes, and how you prioritised. Answer slot: if you handled double-bookings or urgent reshuffles, say how you decided. If you did not, say so and describe how you would handle them. Rationale: the calendar requirement is the job's core.

**A3. "Have you processed supplier invoices before?"** Type: JD. Provenance: [grounded] "chased unpaid invoices". Guidance: Be precise. You chased unpaid invoices. Say what that involved: the follow-up, the people you contacted, the outcome. Answer slot: if you entered, matched or approved supplier invoices, say what you did. If not, say so plainly and describe how you would learn the process. Rationale: the ad asks for invoice processing, and your evidence is on the other side of it.

**A4. "How confident are you in Excel?"** Type: JD, pressure. Provenance: [grounded] "okay with Excel". Guidance: Give the honest rating, then one example of what you have done. Hold this position if pressed. Do not inflate "okay". Rationale: the gap is visible on the CV, so it will be probed.

**A5. "Tell me about a time you booked travel for someone."** Type: EXP. Provenance: none (no sentence in your material). Guidance: Selection scaffold: pick a time you arranged something that had to fit other people's plans. If none comes to mind, say so plainly, then describe how you would book a trip for an executive. Rationale: travel booking is in the ad and nothing in your material covers it.

**A6. "How do you keep on top of work when you are not in the office?"** Type: VAL / JD. Provenance: none. Guidance: Selection scaffold: give a specific routine you use to stay organised and reachable. If you have not worked remotely, say so, then describe how you would manage it. Rationale: remote work is central to the role, and your material is silent on it.

**A7. "Why this role?"** Type: VAL. Provenance: none. Guidance: Connect the role's tasks to what you enjoy from the clinic work. Keep it honest and short. Rationale: a standard motivation question.

### 2.4 Questions to ask the interviewer

1. "What does a typical week look like in this role, and which parts take the most time?" (Why it lands: it shows you are thinking about the job, not only the offer.)
2. "What do you use for calendars, travel and invoice approval?" (Why it lands: it tests whether the tools exist, and it gives you the detail you need to rehearse.)
3. "Does the company ever charge candidates any fee at any stage?" (Why it lands: a legitimate employer answers this without difficulty. Watch the response closely.)
4. "How is onboarding equipment provided?" (Why it lands: the company should provide equipment, not ask you to buy it.)
5. "How will you be checking in with the remote team?" (Why it lands: it shows you plan to work remotely and gives the office manager a question to answer.)

### 2.5 Prep plan

Do this in order:
1. Verify the company (section 1). Do not prepare beyond this until it checks out.
2. Write your 90-second background arc (A1) and say it aloud twice.
3. Write one example each for the calendar, invoice and Excel questions (A2, A3, A4), using only what you did.
4. Spend an hour on Excel basics you have not used before: formulas, filters and a simple table. Be able to show one example.
5. Practise the three honest-branch answers (A5, A6, A7) once each, out loud.

Everything else is insurance.

## 3. Interview format

The email says 30 minutes by video with the office manager. Confirm the platform, the time, and the name of the person you are meeting, through the company's own contact details.

## Upgrade menu

- A real job posting, with a link from the company's own site → checks the requirements against the posted wording
- The company's CRO number and registered address → lets us confirm whether the company is registered
- Your Excel experience in more detail → firms up the Excel rows in the fit-gap map
