# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: office manager (name not given). Format: 30-minute video call. Relationship assumed: hiring-manager-style round, since the office manager will likely own the role's day-to-day work. Changes if this is wrong are listed in the upgrade menu.

**Before anything else:** the invitation shows fraud markers (a fee before interview, a request for passport and bank details, a cheque to deposit with money sent on). Do not pay, send ID, or deposit the cheque until you have verified the company independently. This pack is prep for a real interview only if verification succeeds.

## How to use + type key

Personas describe how the question is asked. Types describe what is being scored.

- **EXP**: what you actually did
- **JD**: whether you can do a stated requirement
- **CASE**: how you reason through a live problem
- **MOT**: why this role and this company
- **BEH**: how you behave with others

Guidance is scaffolding, not a script. Rehearse in your own words.

## The fit snapshot

Requirements are from your summary of the ad, not verbatim, so they are unquoted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Manage calendars (ad, as you summarised it) | "where I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your material shows a shared appointment book for four people. Say that, in those terms. Calendars for executives or across time zones are not shown; do not claim them. |
| F2 | Book travel (ad) | none given | none | [grounded] | discovery | Answer slot: if you have booked travel for anyone, say what and for whom. If not, say so and say how you would learn the booking tools. |
| F3 | Prepare documents in Word (ad) | "good with Word" — your message | medium | [grounded] | none | The quote reaches the requirement. Name the documents you have produced. |
| F4 | Prepare documents in Excel (ad) | "okay with Excel" — your message | low | [grounded] | discovery | Answer slot: name the functions or sheets you have actually built. If you have not built any, say so plainly. |
| F5 | Process supplier invoices (ad) | "chased unpaid invoices" — your message | low | [grounded] | transferability | Chasing invoices is adjacent to processing them. Say what you chased and whom you contacted. Do not describe approving, coding or paying invoices unless you did. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for executives or across time zones | Inflated form of F1 | F1's quote at its own scope: a shared appointment book for four people |
| Booked corporate travel | No evidence given (F2) | "I haven't booked travel for work yet." Then how you would learn it |
| Built complex Excel workbooks | Inflated form of F4 | Answer slot only: name what you built, or say you have not built any |
| Processed supplier invoices through accounts payable | Inflated form of F5 | "I chased unpaid invoices." Nothing further |

## Personas

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Case / Practical | Live scenarios about the job, such as a clash of diaries or an invoice query | High: an office manager tests workload | Think aloud: clarify, state the priority, propose options. No past claims needed |
| Conversational | Friendly opener, "walk me through your background" | High: the first five minutes are often casual | Pre-rehearse a 90-second background arc. Treat casual questions as scored |
| Skeptic | "You haven't done X, how would you handle it?" | Medium: Excel and invoicing are the likely gaps | Admit the gap plainly, then describe how you would close it |

## Question banks

**Case / Practical (weight: 2 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people want the same meeting room at the same time. What do you do?" | CASE | [generic] | Ask about priority, then propose one option and a fallback. Keep it short | A common admin problem. No claim about your past |
| A2 | "How would you handle a supplier invoice that doesn't match the purchase order?" | JD | [generic] | Say what you would check first and who you would contact. Say you would confirm the process before paying anything | Tests the invoice requirement (F5) without asking for experience you do not show |

**Conversational (weight: 2 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | Use the quote's own beats: the clinic, the appointment book, the four physios, the invoices. Keep it under 90 seconds | F1 and F5 are the evidence. Rationale refers to them by row ID only |
| B2 | "What do you enjoy most about admin work?" | MOT | [generic] | Answer honestly. Link to scheduling or organising, which your background supports | Motivation check. No claim needed |

**Skeptic (weight: 2 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Excel is part of this role. How would you rate yourself?" | JD | [grounded] "okay with Excel" — your message | Rate yourself as you did in your message. Name the functions you have used. If you have not built a workbook, say so plainly. Answer slot: name what you built | F4 is the likeliest objection. This is the highest-value rehearsal in the pack |
| C2 | "You haven't booked travel before. How would you manage it?" | JD | [grounded] "I haven't booked travel for work yet." — your message | Accept the gap, then describe how you would learn the booking tools and what you would do for the first trip | F2's honest form. Do not describe bookings you have not made |

## Reverse questions

1. What does a typical week look like, and which of the four tasks takes most time? Why it lands: it shows you care about the actual workload.
2. Who approves supplier invoices, and what is the process? Why it lands: it reveals how invoices are controlled.
3. What tools and software does the team use day to day? Why it lands: it tests whether the role is real and what the first week involves.
4. How is the role supervised when it is remote? Why it lands: it shows you are thinking about working remotely.
5. What does success look like after three months? Why it lands: it gives you a concrete target to commit to.

## Upgrade menu

- The interviewer's name and role title → a tailored reverse question and a read of their public background
- The full advert text → the requirements in the fit snapshot become exact quotes
- Confirmation of where you applied (job board or direct) → helps verify the company before you commit anything
- Confirmation that the interview is with the office manager named in the email → confirms the round type
