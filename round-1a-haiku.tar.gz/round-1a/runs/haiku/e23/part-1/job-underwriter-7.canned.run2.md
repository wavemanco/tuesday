**Decision: conditional go. Apply, but only after confirming the employer and what the role's caseload looks like.** The core clinical match is strong. The gaps are about independent caseload work and a few specialist skills, and you can speak to the first honestly.

**Decision snapshot**
- Fit: strong on the essential criteria, partial on the role's day-to-day shape.
- Hard gates: all met. NMC registration active, full UK licence (category B), more than one year post-registration. The licence also covers the pool cars.
- Opportunity: unverified. I did not search for the employer, so Calderbrook's existence, stage and posting are unconfirmed.
- Research tier: L0, no searches. Everything about the employer and pay below is from the advert alone or is `[generic]`.

**Evidence map**

| Requirement | Fit | Evidence from your CV |
|---|---|---|
| NMC registration (Adult) | Met | PIN active, revalidation March 2028 `[grounded]` |
| Full UK licence | Met | Category B `[grounded]` |
| 1+ year post-registration | Met | Five years as staff nurse `[grounded]` |
| Wound care | Strong | Pressure ulcers and surgical wounds. Leg ulcers not mentioned. |
| Catheter care | Met | Stated `[grounded]` |
| Insulin administration | Met | Stated `[grounded]` |
| Continence care | Partial | Catheter care is stated; general continence assessment is not |
| Home visits | Strong, transferable | 18 months of visits in the first week after discharge. This is your closest analogue to community work. |
| Own caseload | Gap | Never held one. Discharge visits were a team-supported role, so independent prioritisation and caseload management are untested. |
| End-of-life visits | Gap | Not in CV. Ask whether you did palliative or end-of-life care on the ward. |
| Care planning | Partial | Likely through discharge work, but not stated `[inferred]` |
| Clear, timely records | Unverified | Not stated. Ask about EPR use. |
| Doppler (desirable) | Gap | Never done. Learnable; check whether Calderbrook trains it. |

**Gap read**
- The caseload gap is the main one. Home visits and discharge work are real evidence of independent clinical judgment. Do not describe them as caseload management, and do not claim you led or managed anything you did not.
- Doppler is desirable, not essential. It is a capability gap that is easy to raise in an interview.
- Leg-ulcer assessment and compression management are the adjacent skills to ask about. Pressure ulcer experience transfers, but say so as transfer, not as leg-ulcer experience.

**Risk register**
- Employer not verified. Check the live posting or the company's own careers page, or ask Rhiannon Mabbott directly.
- Band 5 on a CIC. Band 5 normally sits on NHS Agenda for Change terms. A CIC may use different terms. Confirm the pay structure and the mileage rate. Band 5 pay scales are `[generic]`, and I have not checked the current figures.
- Pay range £31,050–£37,800 is the advert's own figure `[grounded]`.

**Application plan**
- Lead with the discharge-to-assess home visits and the wound, catheter and insulin work.
- Be specific about what you did independently on those visits. Do not write "managed a caseload".
- Name Doppler as something you want to learn, and say how you would approach it.
- Email or call Rhiannon Mabbott before you apply. Ask about caseload size, the support model, EPR, lone working, Doppler training and the employment terms.
- Any CV wording or cover letter text needs your approval before it goes out.

**Research:** Research tier: L0 — no searches; user links read 0

**Would you like me to run a light search on the employer and pay structure?** It would check whether Calderbrook is a live, consistent CIC, and whether the Band 5 terms match the advert. Up to 5 searches and 2 fetches.

**Questions**
1. Have you done any palliative or end-of-life care on the ward or in discharge work?
2. Have you assessed or managed leg ulcers, including compression therapy?
3. Which EPR systems have you used, and how did you handle lone-working and visit scheduling?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.