**Yes, worth applying, as a `conditional_go`.** You clear both hard gates (R1, R2), and the clinical core the post names is direct in your CV (R4a, R5, R7). The conditions are your own caseload (R10) and the documentation side (R11, R12), which your CV doesn't evidence yet.

**Decision snapshot**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R4a, R5, R7 · adjacent: R4b (leg-ulcer care) · unclear: R6 (continence care), R8 (end-of-life visits), R9 (care planning), R11 (electronic patient record), R12 (clear, timely written records)
- `important` — adjacent: R10 (own caseload)
- `preferred` — absent: R13 (Doppler assessment)

What matters: R10, the caseload, is the real stretch; R6, R8, R9, R11 and R12 are unknown rather than missing, since your CV is silent on them; R13 is desirable, not essential.

**Opportunity ledger.** The employer checks out and the pay is stated and sits within the survey band (RR4). The advert itself is unverified (RR2), and the caseload set-up and documentation expectations are open (RR1, RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the caseload is sized and supported as described (R10, RR1); (2) the documentation and EPR expectations are standard (R11, R12, RR3); (3) the post is still open (RR2).

Note that years of experience (R3) is a must-have, not a hard gate: a gate is a term, not a length of experience.

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0**

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` About page |
| Mandate | District nursing for housebound adults: wounds, catheters and continence, end-of-life, insulin, care planning, on the EPR; a small caseload with senior nurse support | `[grounded]` JD |
| Pay and travel | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | The 2026 England survey (1,240 respondents) puts community staff nurse, Band 5, at a median of £34,300, interquartile range £32,400–£36,600. The posted range covers that interquartile range, so there is no pay mismatch. | `[generic]` Wardround 2026 pay guide |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` speaker profile |
| Scope read | A normal-scope district nursing post; a small caseload is ordinary for it | `[inferred]` from the JD's wording |
| Unknowns | Caseload size; supervision model; EPR system; whether Doppler training is given; whether the advert is still live | — |
| Contradictions | None found between the JD and the About page. The careers page was not read. | `[grounded]` About page |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | NMC registration as an Adult Nurse | hard_gate | direct | high | none | Your PIN and registration are active (per your CV), and revalidation is due March 2028 | `[grounded]` your CV | none |
| R2 | Full UK driving licence | hard_gate | direct | high | none | Category B, full licence | `[grounded]` your CV | none |
| R3 | At least one year post-registration | must_have | direct | high | none | Five years as a staff nurse | `[grounded]` your CV | none |
| R4a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds. Community wound work is not named, so medium. | `[grounded]` your CV | E1 |
| R4b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over, but compression and leg-ulcer management are not in your CV. Limit: leg ulcers not exercised. | `[inferred]` from R4a | G2 |
| R5 | Catheter care | must_have | direct | high | none | Stated in CV | `[grounded]` your CV | none |
| R6 | Continence care | must_have | unclear | low | discovery | Not in your CV | `[grounded]` CV silence | G5 |
| R7 | Insulin administration | must_have | direct | high | none | Stated in CV | `[grounded]` your CV | none |
| R8 | End-of-life visits | must_have | unclear | low | discovery | Not in your CV. Acute ward and home visits make it plausible, but that is an inference. | `[grounded]` CV silence; `[inferred]` plausibility | G3 |
| R9 | Care planning | must_have | unclear | low | discovery | Discharge-to-assess planning may overlap; not stated | `[grounded]` CV silence | G5 |
| R10 | Own caseload | important | adjacent | medium | transferability | Seven days of home visits in the first week after discharge are the nearest thing. Limit: you have never held a list you were accountable for over weeks. | `[inferred]` from the discharge-to-assess role | G1 |
| R11 | Electronic patient record | must_have | unclear | low | discovery | Not stated | `[grounded]` CV silence | G4 |
| R12 | Clear, timely written records | must_have | unclear | low | discovery | Not evidenced in the CV; a claim about your records needs an example | `[grounded]` CV silence | G4 |
| R13 | Doppler assessment (desirable) | preferred | absent | high | capability | You have never done one, as you told me | `[grounded]` your statement | G6 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own caseload (R10, important) | transferability | Home visits in the first week after discharge; no owned list | Caseload is the core of the role, and the posting puts it first | Discharge-to-assess follow-up lists; a handover you led; a case where you set a discharge plan that held | An anonymised referral or visit log; a handover example | `[inferred]` bridge from the discharge role; `[generic]` that caseload is the likeliest interview probe |
| G2 | Leg-ulcer care (R4b, must_have) | transferability | Wound care for pressure and surgical wounds; no leg-ulcer work named | Leg-ulcer care is named in the JD's lead sentence | Any leg-ulcer dressings or compression you have applied | A dressing or wound-care example | `[grounded]` JD; `[inferred]` adjacency |
| G3 | End-of-life visits (R8, must_have) | discovery | Nothing in the CV | Named in the JD | Any end-of-life or palliative visits on the ward or at home | A case summary | `[grounded]` CV silence |
| G4 | EPR and written records (R11, R12, must_have) | discovery | Nothing in the CV | Both are essential-style wording in the JD | Any EPR you have used; a record you wrote and had audited | An EPR name; a redacted note | `[grounded]` CV silence; `[generic]` that EPR and records are common interview probes |
| G5 | Continence and care planning (R6, R9, must_have) | discovery | Continence and planning are not in the CV | Named in the JD | Continence assessments; discharge plans you wrote | A plan or assessment | `[grounded]` CV silence |
| G6 | Doppler assessment (R13, preferred) | capability | Never done | Desirable, so a minor risk | The team's public talk on Doppler training for new staff | Ask in the chat whether training is given | `[grounded]` your statement; `[grounded]` team lead's talk |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload set-up and supervision not described | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse." | The caseload may be sized or supported differently from what the JD implies | `[inferred]` from the posting's silence on size | How many patients would I hold on my own list in the first month, and what does senior support look like day to day? | unresolved |
| RR2 | Advert not confirmed live | unknown | — | "Current vacancies are listed on our careers page" (About page) | The post may be filled, or the advert stale | `[generic]` common pattern for employers that list vacancies on their own site; careers page not read | Is this post still open, and what is the closing date? | unresolved |
| RR3 | Documentation load on the EPR | risk_signal | low | "all recorded on our electronic patient record" | Timely recording may be expected from day one | `[inferred]` from the JD's emphasis on timely records | What turnaround do you expect for community documentation, and how is it audited? | unresolved |
| RR4 | Team teaches Doppler to newcomers | positive_signal | — | "Doppler training for staff new to community work" (speaker profile) | Doppler may be taught in-house rather than expected at entry | `[grounded]` speaker profile; `[inferred]` that it applies to this post | Is Doppler training provided for this post? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the home visits, wound care and insulin, and describe the discharge role as visits, not a caseload | R10, R4a, R7; avoids claiming a caseload you haven't held | `[grounded]` CV | pending your approval |
| A1 | Check the live advert and closing date on Calderbrook's careers page before you apply | RR2 | `[grounded]` About page | — |
| A2 | Ask Rhiannon for the informal chat, and raise caseload size, supervision, EPR and Doppler training | RR1, RR3, RR4 | `[grounded]` JD contact | pending your approval (outreach text) |
| A3 | Describe Doppler honestly as not yet done, with willingness to train | R13 | `[grounded]` your statement | pending your approval |

**Evidence status**

Verified: none yet. The employer's existence and the pay band come from research, not from claims in your CV.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC careers community staff nurse"; the About page (calderbrookhealth.example/about) confirmed the entity. The careers page was not fetched, so the advert is unverified (RR2). |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay 2026/27 salary range"; returned the Wardround 2026 pay guide (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; returned the forum speaker profile (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the team-lead read and the Doppler lead (RR4). |

**Questions**

1. R10/G1 — On discharge-to-assess, did you hold a list of patients you were accountable for over several weeks? If so, roughly how many, and what did you own? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. R8/G3 — Have you done end-of-life visits, at home or on the ward? What did you do, and who was involved?
3. R11, R12/G4 — Which electronic record system have you used, and have you had your documentation audited?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Upgrade menu**

- A link to the live advert, or the careers-page listing → RR2 closes, with the closing date.
- An anonymised discharge-to-assess visit or handover log → R10 may move from adjacent toward direct.
- Any leg-ulcer or compression example → R4b may move to direct.
- Any end-of-life, continence or care-plan example → R6, R8, R9 move from unclear.
- The EPR name → R11 moves from unclear.
- A deeper research pass on Calderbrook (inspection reports, published reviews, the team's recent history; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write a `tuesday-dossier.md` that carries this analysis forward and feeds later interview prep.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.