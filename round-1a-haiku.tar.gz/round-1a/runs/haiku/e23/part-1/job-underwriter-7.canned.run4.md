**Decision snapshot: conditional_go.** Your essential requirements are met on your CV. The one open item is that I couldn't check the employer, so the decision is held until you've confirmed the posting is live and the company is real.

- **Essentials:** NMC Adult registration, full UK licence, and 1+ year post-registration are all met `[grounded]`.
- **Hard gates:** none failed. Location (Halifax) matches. Pay has no floor from you, so it's unknown.
- **Confidence:** high on the clinical overlap, medium on records and care planning.

**Role reality**
- Band 5 district nursing for housebound adults, with a small personal caseload and a senior community nurse behind it `[grounded]`.
- The posting is specific and realistic, names a contact, and separates essentials from desirables `[grounded]`.
- £31,050–£37,800 plus mileage `[grounded]`. Whether that sits within the Band 5 range is `[generic]`, not checked.
- Because you have five years' experience, this is a Band 5 role for someone with one. That may be a step back in banding, but that's an inference `[inferred]`.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | NMC Adult registration, active | Essential | met | high | none (verify on NMC register) | Your CV |
| 2 | Full UK driving licence | Essential | met | high | none | Cat B stated |
| 3 | 1+ year post-registration | Essential | met | high | none | Five years |
| 4 | Clear, timely written records | Essential | partial | medium | presentation | Records not described; EPR not named |
| 5 | Wound care | Core | met | high | none | Pressure ulcers, surgical wounds |
| 6 | Leg-ulcer care | Core | partial | medium | transferability | Not claimed; wound experience is adjacent |
| 7 | Catheter and continence care | Core | partial | medium | discovery | Catheter stated; continence not |
| 8 | Insulin administration | Core | met | high | none | Stated |
| 9 | Care planning | Core | partial | medium | discovery | Likely in discharge work, not stated |
| 10 | End-of-life visits | Core | not evidenced | low | discovery | Nothing stated |
| 11 | Own caseload | Implied | not met | — | capability | Never held one |
| 12 | Lone working in patients' homes | Implied | partial | medium | transferability | Home visits, not described as independent |
| 13 | Doppler assessment | Desirable | not met | — | capability | Never done |
| 14 | Halifax base | Structural | met | high | none | Stated |

**Gap queue** (no questions here; the questions are below)
- **Records (row 4):** Name the EPR you used and how you documented.
- **Continence, care planning, end-of-life (rows 7, 9, 10):** These may be covered by your discharge work but aren't on your CV.
- **Own caseload (row 11):** Closed by a senior-supported start, which the posting describes, plus a question to the employer about caseload build-up.
- **Doppler (row 13):** Desirable only. Ask whether training is provided.

**Opportunity risk register**
- **Employer unverified (medium).** I did no research, so I can't confirm Calderbrook Community Health CIC exists as described. Resolve it by checking the live posting, the company's entry on the Companies House or CIC register, and the email domain from Rhiannon Mabbott.
- **Banding mismatch (low).** Band 5 with five years' experience. Check whether the role has progression.
- **Unknowns.** Caseload size, supervision frequency, on-call and weekend rota, EPR system, Doppler training.

**Application plan**
1. Confirm the posting is live and the employer is real.
2. Ask Rhiannon Mabbott about caseload build-up, supervision, the EPR, and Doppler training. The posting invites this.
3. Lead with the 18 months of home visits in the discharge-to-assess team, plus wound, catheter and insulin work. Say plainly that you haven't held a caseload or done Doppler.
4. Don't claim leg-ulcer or caseload experience. Don't describe the home visits as "autonomous" unless you can confirm that.
5. Any CV or application wording comes to you for approval before it's used.

**Evidence status**
Research tier: L0 — no searches; user links read 0

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Not run in this first pass; offered below |
| 2. Role-family pay and scope sweep | skipped | Not run; pay band is `[generic]` |
| 3. Hiring manager footprint | n/a | No hiring manager named |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file for later use, if you'd like.

**Upgrade menu**
- **Light research (5 searches, 2 fetches):** Verifies the employer and checks the pay band against Band 5 norms.
- **Your NMC register check:** Confirms the registration you've stated.
- **The live posting link:** Lets me check the posting directly.

**Questions**
1. Row 10: Did your ward or discharge team have any end-of-life or palliative contact with patients?
2. Rows 4 and 9: Which electronic records system did you use, and did you do care planning as part of discharge work?
3. Row 13: Have you had any exposure to leg-ulcer assessment, such as compression or ABPI, on the ward?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.