**Yes, worth applying for, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (clear, timely written records)
- `important`: direct: R5, R7, R9 · adjacent: R6 (leg-ulcer care), R12 (holding your own caseload) · unclear: R8 (continence care), R10 (end-of-life visits), R11 (care planning), R13 (electronic patient record)
- `preferred`: absent: R14 (Doppler assessment)

What moves it: R4, the essential records line, has nothing behind it yet; R12, the caseload, is the shape of the job and you have not held one; R6 is adjacent to your wound work, not the same skill.

Opportunity ledger: the posting has one clear positive, RR6, with its scope and named senior support stated plainly. The open points are RR1 (caseload size and first-months support undefined), RR3 (pay basis unstated), RR5 (Doppler training unknown), RR2 (mileage sits beside pool cars, `severity: low`) and RR4 (employer not checked, because no lookups were run).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 checked on the NMC register, since the gate currently rests on your word; (2) R4 answered with a concrete example (question 1 below); (3) RR1 and RR3 answered at the informal chat; (4) in interview, leg-ulcer work framed as wound care generally, not leg-ulcer expertise (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC, Halifax | `[grounded]` JD header |
| Mandate | District nursing for housebound adults in their homes: wound and leg-ulcer, catheter and continence, end-of-life, insulin, care planning, all on the EPR | `[grounded]` JD |
| Caseload | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| Pay | £31,050–£37,800 a year plus mileage | `[grounded]` JD |
| Market calibration | Not run; no role-family sweep at this research tier, so the pay is not set against any band | — |
| Scope read | Reads as a standard community staff nurse post | `[generic]` role-family norm, not checked |
| Unknowns | Employer and live posting unverified; pay scale basis; caseload size; Doppler training; contract type; start date | `[grounded]` JD silence |
| Contradictions | "Pool cars are provided" beside "plus mileage" | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as Adult Nurse | hard_gate | direct | medium | none | CV: active, Adult, revalidation March 2028; the register entry is inspectable but unchecked | `[grounded]` CV | Check the NMC register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV: full, category B | `[grounded]` CV | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as staff nurse. Experience, not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | none | discovery | The CV says nothing about records | `[grounded]` CV silence | Q1 |
| R5 | Wound care: pressure ulcers, surgical wounds | important | direct | medium | none | Both named | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Wound care carries over. Limit: no leg-ulcer assessment or compression work named | `[inferred]` adjacency from R5; `[generic]` that leg ulcers differ in cause | Gap queue G2 |
| R7 | Catheter care | important | direct | medium | none | Named | `[grounded]` CV | none |
| R8 | Continence care beyond catheters | important | unclear | none | discovery | Catheter care named; continence beyond it not | `[grounded]` CV silence | Gap queue G3 |
| R9 | Insulin administration | important | direct | medium | none | Named | `[grounded]` CV | none |
| R10 | End-of-life visits | important | unclear | none | discovery | Nothing on end-of-life care | `[grounded]` CV silence | Q3 |
| R11 | Care planning | important | unclear | none | discovery | Not named; discharge visits may have involved it | `[grounded]` CV silence | Q2 |
| R12 | Holding your own caseload, with senior support | important | adjacent | medium | transferability | You have never held one (your statement). Nearest work: first-week home visits after discharge, which end before ongoing care. Limit: no continuity over weeks | `[grounded]` your statement; CV | Gap queue G6 |
| R13 | Electronic patient record | important | unclear | none | discovery | The CV does not name the EPR you used | `[grounded]` CV silence | Gap queue G7 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No Doppler, by your statement | `[grounded]` your statement; closure route `[generic]`: in-post training or a course | Gap queue G8 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Written records (R4) | discovery | No records evidence in the CV | Essential; the first condition for go | A de-identified note, audit or feedback on your notes, or EPR training | `[grounded]` CV silence |
| G2 | Leg-ulcer care (R6) | transferability | Wound work named; leg ulcers not | A responsibility; the bridge has a limit | Any leg-ulcer or compression patient you looked after, even as second nurse | `[inferred]` |
| G3 | Continence care (R8) | discovery | Catheter care named; continence not | Named responsibility | Continence assessments or bladder training you were part of | `[grounded]` CV silence |
| G4 | End-of-life visits (R10) | discovery | Nothing in the CV | Named responsibility, unevidenced | End-of-life care on the ward or in discharge visits | `[grounded]` CV silence |
| G5 | Care planning (R11) | discovery | Not named | Core to a caseload | Plans you wrote and followed up at discharge visits | `[grounded]` CV silence |
| G6 | Own caseload (R12) | transferability | Adjacent home visits; no owned caseload | The job's shape; decides whether the first months are supported or overwhelming | Visits where you followed the same patients over repeated contacts | `[grounded]` your statement |
| G7 | EPR (R13) | discovery | System not named | Used on every visit | Which system you used on the ward | `[grounded]` CV silence |
| G8 | Doppler (R14) | capability | Absent | Preferred; a minor risk | Whether in-post training is offered | `[generic]` closure route |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and support undefined | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" may mean more patients than you can carry alone in your first months | `[inferred]` from the JD's silence on numbers | How many patients would I hold at the start, and what does the senior nurse do in my first three months? | unresolved |
| RR2 | Mileage against pool cars | risk_signal | low | "pool cars are provided" / "plus mileage" | Mileage may apply only to own-car use, which the pool cars would make unnecessary | `[inferred]` from the two terms side by side | When would mileage be claimed if pool cars are provided, and is it paid on my own car? | unresolved |
| RR3 | Pay basis not stated | unknown | — | "Band 5", £31,050–£37,800 | The grade name suggests an NHS-style scale; the CIC's basis is unstated | `[inferred]` from the grade name | Which pay scale is the Band 5 on, and does the range include progression? | unresolved |
| RR4 | Employer and posting not checked | unknown | — | "Calderbrook Community Health CIC" | The posting is unverified | `[grounded]` no lookups run | Which organisation would employ me, and where is this role on its own careers page? | unresolved |
| RR5 | Doppler training provision | unknown | — | "Desirable: Doppler assessment for leg ulcers" | If training is given in post, R14 closes; if not, it stays open | `[inferred]` from the desirable listing | Is Doppler training provided for a nurse who doesn't yet do it, and when? | unresolved |
| RR6 | Scope and support stated plainly | positive_signal | — | "supported by a senior community nurse" | Named support lowers the risk behind RR1 | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the line to the top of your experience: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | Your closest match to community work; every word is from your CV | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | Leave caseload, leg-ulcer and Doppler out of the CV rather than stretching the wound-care line to cover them | Would assert experience you have not had | `[grounded]` R6, R12, R14 | `resume_edits_pending_approval` (advice; no text added) |
| P1 | Check your NMC register entry before applying | R1 rests on your word | `[grounded]` R1 | For you to do |
| P2 | Bring RR1 and RR3 to the informal chat with Rhiannon Mabbott | The employer can answer both; the posting offers the chat | `[grounded]` JD contact | Your choice |
| P3 | Lead with the home visits and say plainly that you have not held a caseload | Interviewers commonly probe this gap, so the honest version is the one that holds up | `[generic]` interview pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | You chose no lookups. Would have confirmed the employer exists and the posting is live (RR4) |
| 2. Role-family sweep | unavailable | You chose no lookups. Would have set the pay range against role-family norms (RR3) |
| 3. Hiring manager's public footprint | unavailable | A name was given (Rhiannon Mabbott, Community Nursing Team Lead) and you chose no lookups. Would have shown the team's public role |

If you want this kept, I can write it out as `tuesday-dossier.md`, the full assessment in a file you can carry into a later turn.

## Upgrade menu

- An NMC register entry showing Adult and active → R1 to `high`.
- A de-identified record, or audit feedback on your notes → R4 to `medium` or `high`.
- Training certificates for catheter, continence or insulin care → R7, R8, R9 to `high`.
- Any leg-ulcer or compression work, even as second nurse → R6 to `direct`.
- Any end-of-life or care-planning experience → R10, R11.
- Written answers from the employer on caseload size, mileage, pay scale and Doppler training → RR1, RR2, RR3, RR5 close.
- An employer check and a pay check, up to 5 searches and 2 page fetches. Say the word and I'll run them.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **R4**: Which record-keeping standard were you held to on the ward, and did anyone audit or give feedback on your notes?
2. **R11**: On the discharge-to-assess visits, did you plan care you then followed up yourself, or was each visit a one-off?
3. **R10**: Have you been part of end-of-life care on the ward or in a discharge visit? What did you do, and who led it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.