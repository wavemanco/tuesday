## Decision snapshot

**Verdict: conditional go.** Apply. Your essential criteria are met on the evidence you gave. The condition is that the posting is confirmed live (see the failed-attribution entry below).

- **Hard gates:** NMC Adult registration (met, active, PIN 19F4417X). Full UK driving licence, category B (met). Based in Halifax, same town as the role (met). Pay: the posting gives £31,050–£37,800 plus mileage, and I have no stated floor from you, so this is unknown on your side.
- **Essential criteria:** Adult NMC registration (met). Driving licence (met). One year's post-registration experience (met, about five years). Clear, timely written records (unknown; not evidenced in your CV).
- **Desirable:** Doppler assessment for leg ulcers (not met).
- **Research tier:** L0, provided documents only. I have not checked that Calderbrook Community Health CIC or this advert exists outside the text you pasted.

## Role reality

- **Role:** Community Staff Nurse, Band 5, district nursing, housebound adults at home. Holds a small personal caseload with a senior community nurse as support. Wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, all on an electronic patient record (EPR).
- **Scope signal [grounded]:** The posting says you hold your own caseload. That is the main change from your current role.
- **Pay [grounded]:** £31,050–£37,800 a year plus mileage. Pool cars are provided, so the mileage element may be lower than it looks. No market calibration done at L0.
- **Contradictions:** None found in the advert itself.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Essential, hard gate | Current NMC registration, Adult | Met | High | None | Your CV: PIN and active status, revalidation March 2028 |
| 2 | Essential, hard gate | Full UK driving licence | Met | High | None | Your CV: full licence, category B |
| 3 | Essential | One year's post-registration experience | Met | High | None | Five years as staff nurse |
| 4 | Essential | Clear, timely written records | Unknown | Low | Evidence gap | Not in CV; EPR use not stated |
| 5 | Core | Wound care (leg ulcers) | Partial | Medium | Presentation / context | Pressure and surgical wounds shown; leg ulcers not named |
| 6 | Core | Catheter and continence care | Partial | Medium | Presentation | Catheter care shown; continence not named |
| 7 | Core | Insulin and care planning | Partial | Medium | Presentation | Insulin shown; care planning only implied by discharge work `[inferred]` |
| 8 | Core | Home visits, housebound adults | Met (adjacent) | Medium | Transferability | Home visits in discharge-to-assess role |
| 9 | Core | Own caseload | Not met | n/a | Experience gap | Never held one |
| 10 | Core | End-of-life visits | Unknown | Low | Discovery | Not in CV |
| 11 | Desirable | Doppler assessment, leg ulcers | Not met | n/a | Capability | Never done; usually trainable on the job `[inferred]` |

## Gap recovery queue

- **Own caseload (row 9):** Transferable, not a hard gate. The discharge-to-assess home visits are your closest evidence. Closing it means a concrete example of managing your own visit list and prioritising it.
- **Doppler (row 11):** Desirable only. Closing it means an agreed training path or a confirmed plan to learn it in post.
- **Written records (row 4):** Essential and not yet evidenced. Closing it means naming the EPR you have used and one example of a clear, timely entry.
- **Leg ulcers, continence, end-of-life (rows 5, 6, 10):** Presentation gaps where you may already have the experience. Closing them means confirming what you have done.

## Opportunity risk register

- **Failed attribution (open):** I have not confirmed the employer or the advert exists beyond the text you gave me. Resolve by getting the live posting link, the Calderbrook careers page, or the recruiter's email domain. Until then, this is a condition on the go.
- **Pay (unknown on your side):** The range is in the advert. Whether it meets your floor is for you to judge; I have no benchmark for it at this research tier.
- **Mileage:** Pool cars reduce the cost. Your personal mileage exposure is not stated.

## Application plan

1. Confirm the live posting (link or careers page) before you spend time on the application.
2. Lead with the discharge-to-assess home visits and wound, catheter and insulin work. Those are the strongest matches.
3. State the caseload gap yourself and frame it as the next step, not something you are hiding.
4. Do not claim Doppler, leg-ulcer or end-of-life experience you have not had. Describe it as learning you are ready to take on.

## Evidence status

Research tier: L0 — no searches
| Target | Status | Reason |
|---|---|---|
| 1. Company website and careers page | skipped | Research not consented; L0 |
| 2. Role-family sweep (pay, scope) | skipped | Research not consented; L0 |
| 3. Hiring manager footprint | n/a | No hiring manager named; only a team lead |

## Dossier offer

If you want, I can save this assessment as a tuesday-dossier.md file for later use with the mock-interview skill.

## Upgrade menu

- **Live posting link or careers page (unlocks the employer check):** Turns the failed-attribution entry into a verified fact.
- **L1 research (up to 5 searches, 2 page fetches):** Checks the employer exists as described, and gives a market check on the Band 5 pay and scope.
- **Leg-ulcer or continence examples from your ward or discharge work:** Raises rows 5 and 6 from partial to met.
- **Name of the EPR you have used:** Raises row 4 from unknown to evidenced.

## Questions

1. Have you dressed or assessed leg ulcers (for example venous ulcers with compression) in your ward or discharge work?
2. Which EPR systems have you used, and how did you record home visits?
3. Is £31,050 a floor you would accept, and is the commute from Halifax to the patch workable for you?

Answer in prose, or say "skip" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.