Before I build the prep pack, I want to flag something. This message has several common recruitment-scam markers: an unknown number, a "found your profile online" opener, a remote job with flexible hours, and a process that's entirely on WhatsApp with no calls or video. That doesn't prove it's a scam, but please verify before you invest time or share anything personal. I'll load the skill so I can tell you what it needs from you.
I can't build the prep pack yet. The skill needs the company and role title before it can run, and the message doesn't include either.

**I'd treat this as a likely scam until it's verified.** Your interview is tomorrow, so you have time to check:

- **No calls or video for a full hiring process is a major red flag.** Legitimate recruiters almost always do at least a phone or video screen, and the contract is never finalised over WhatsApp.
- **"Found your profile online" plus a vague "flexible remote role" is a common opener** in fake job offers. Those scams often go on to ask for fees, bank details, or ID documents "for onboarding" or "equipment."
- **Ask Jess for the agency name, the client company name, and the job title.** Then find the role on that company's official careers page, not through a link Jess sends.
- **Check the agency independently.** In the UK, look it up on Companies House. Elsewhere, check its registered business record and reviews. Search for the agency name with "scam" to see if others have reported it.
- **Call the company through a number from its official website,** not the number that messaged you, and ask whether they're hiring for that role and whether they use this agency.
- **Don't send money, bank details, your passport or other ID, or your National Insurance/Social Security number** until you have a verified offer and a contract from a company you've confirmed.

If Jess can't give you a company name and role you can verify, I'd skip the interview.

If it checks out, send me these and I'll build the pack:

1. **The role title and company name** (required to start).
2. **The job description**, if you have it.
3. **Your CV or a summary of your experience.** This lets the answers draw on what you actually did.