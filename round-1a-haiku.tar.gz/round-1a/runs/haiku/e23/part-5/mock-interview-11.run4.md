I can help you prep, but I'd check this one before the interview. The message has several hallmarks of recruitment scams:

- **Unsolicited contact** from an unknown number, with no company name, job title, or specifics about the role.
- **No voice or video at any stage.** Legitimate recruiters almost always use a call or video call, at least for the first screen.
- **Hiring end to end over WhatsApp**, including the contract. Real employers send contracts by email from a company domain.
- **Very fast timing**: an interview tomorrow, arranged by a first message.

Scams like this often go on to ask for an ID or bank details "for payroll," a fee for training or equipment, or a "test" payment to forward. Your applications may be genuine, but scammers also scrape job boards and CVs, so the link to your applications doesn't prove this message is legitimate.

**Before tomorrow, I'd do this:**

1. **Reply and ask for specifics:** the company name, the exact job title, the job posting link, and the recruiter's full name and agency. Ask for a phone or video call instead of WhatsApp. A real recruiter will expect that.
2. **Check the company independently.** Find it through a search engine or LinkedIn, not through the message. Confirm the job appears on its official careers page.
3. **Check the recruiter.** Look for a LinkedIn profile with a real work history and a company that matches what they say.
4. **Look up the agency** if one is named, on the company register for their country (e.g. Companies House in the UK).
5. **Don't share** your passport, ID, bank details, or National Insurance/tax number over WhatsApp, and don't pay anyone for anything.

If the company and recruiter check out and they agree to a call or video interview, I'll run the mock-interview prep. To do that, I need:

- The job posting or description, and the company name
- Your CV, or the parts that matter for this role
- The interview format, if they tell you (screen, panel, technical, etc.)

If you can't verify them, I'd decline the WhatsApp interview. You can still prep for real roles, and I'm happy to do that with you.