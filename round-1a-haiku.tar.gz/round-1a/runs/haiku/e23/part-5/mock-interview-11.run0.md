Before you prep, I'd check this first. The message has several common job-scam signs:

- **Unsolicited contact** from an unknown number, saying they "found your profile online." That's plausible after a lot of applications, but a real recruiter can point to the specific role and posting.
- **No call or video, ever.** A real employer hiring for a contract almost always does at least one call or video step, and usually works over email from a company domain.
- **Vague role, quick timeline.** "Remote with flexible hours" and an interview tomorrow, arranged in one message.

Scams like this often go on to ask for ID, bank details, or a payment for equipment or training, or they send a fake cheque to "buy equipment." Don't send any of those.

**Checks to do before tomorrow:**
1. Reply and ask for the company name, the exact job title, the posting link, and the recruiter's full name and company email address.
2. Find the job on the company's own careers page, or on the job board where you applied. If it isn't there, that's a bad sign.
3. Search the company name and the number, and add "scam" to the search. Look up the company in its national business register if it has one.
4. Check whether "Jess" and the consultancy have a real LinkedIn profile with a history.
5. If the company checks out, ask for a short video or phone call to confirm.

If you can't verify the company, I'd skip the 11am slot.

If it checks out, send me the job description and your CV and I'll run the mock-interview prep pack: likely questions, answer guidance based on your background, and a few questions to ask them. I haven't run it yet because it needs the role details, which I don't have. I can also run a practice screening drill now with general remote-role questions if you'd like to warm up in the meantime.