I've loaded the mock-interview skill, but I can't build the pack yet, and I'd hold off on the 11am slot until you've checked this recruiter.

**The message has the hallmarks of a recruitment scam:**
- It's unsolicited and says they "found your profile online", and it names no company.
- The whole process runs over WhatsApp, with no call or video at any stage. Legitimate recruiters almost always use a phone or video call at some point.
- The job is vaguely described as "remote, flexible hours", which is how fake-job offers are usually pitched.
- It's set up for tomorrow with no prior exchange.

Your applications may well be the source, but scammers also harvest CVs from job boards and copy real recruiters' names. Whatever the answer, don't share your passport, ID, bank details, tax or national insurance number, or any payment details over WhatsApp. Don't pay for training, equipment or "background checks", and don't receive money or buy gift cards or crypto on anyone's behalf. Those are the usual routes to fraud and money-laundering charges.

**To check it:**
1. Ask for the company's full legal name, the recruiter's full name, and a company email address (not Gmail or similar).
2. Search the company's official website and LinkedIn. The recruiter should appear there with the same name and role.
3. Ask whether you can have a 10-minute phone or video call. A real recruiter will say yes; a scammer will find a reason to keep it on WhatsApp.
4. Find the original posting on the job board you applied through and reply via that board's messaging.

**To build your prep pack, I need:**
1. The company name and exact role title, plus where you saw the posting. These are the minimum for the pack.
2. The job posting text (or a link I can read) and your CV, or say "no" and I'll work from the role title alone and label the results as less tailored.
3. The round type: is this a screening call only, or a later round with a hiring manager?

Send me those, and I'll build the full pack once the company checks out. If it doesn't, I'd suggest you don't go to the 11am slot at all.