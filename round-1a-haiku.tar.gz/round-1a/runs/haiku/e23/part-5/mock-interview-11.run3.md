I couldn't build the full prep pack yet, because it needs the company name and job title, and this message has neither. I also think you should check this before you prepare for it. The message has several common signs of a recruitment scam:

- **You didn't name a company or role.** The message is generic, and the sender found you "online" without saying where.
- **Everything is over WhatsApp, and they say no calls or video.** Legitimate recruiters almost always have a phone or video screen, and they don't mind you checking them out.
- **It's unusually fast.** An interview tomorrow, with a contract to follow in the same chat.
- **"Remote, flexible hours" with no details.** This is the usual bait. Scams in this pattern often ask for fees for "training" or equipment, ask you to forward or move money, ask for bank details or ID "for onboarding", or send fake cheques.

**Before you reply with any personal information:**

1. **Check your applications.** Did you apply to this agency or company? If you can't find the application, be suspicious.
2. **Ask for the details in writing.** Ask for the company name, the exact job title, the agency's name, and the recruiter's full name and company email address.
3. **Verify independently.** Look up the company yourself through its official website or a switchboard number you find on your own. Don't use links or numbers the sender gave you. Check the agency's registration on the official register for your country, if it has one.
4. **Ask for a call or video interview.** A real recruiter will say yes. If they refuse or push you to stay on WhatsApp, treat that as the answer.
5. **Never send** ID or passport copies, bank details, national insurance or tax numbers, or any money. Don't pay fees, don't buy equipment on their say-so, don't move or forward money, and don't install apps or open links they send.
6. **If it looks like a scam,** block and report the number in WhatsApp, and report it to your national fraud reporting service (for example Action Fraud in the UK, or the FTC in the US).

**If the company and role check out**, send me these and I'll build the full pack:

- The **company name** and **exact job title**, and the agency name if one is involved (this is required).
- Your **CV or a short background summary**, so the answers are based on what you've actually done.
- Whether you know the **round type** (for example, a screening call with a recruiter, or a later round with a hiring manager), if they've said.