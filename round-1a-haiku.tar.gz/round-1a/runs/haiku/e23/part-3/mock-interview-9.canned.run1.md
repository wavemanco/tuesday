Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-e23-part-3-rooms-case-9-canned-751f3917/81a8e01b-964b-4443-b4ea-e2df4cd24b28/scratchpad/Orrinsford_fourth-grade-teacher_interview_pack.md`. I built it for a 45-minute panel because the district's hiring page describes its teacher interviews as one building panel: the principal and two grade-level teachers.

Three things to know first:

- **The gap that matters most is fourth grade.** You've never taught it, and the panel will likely ask about it in some form. Question A2 is the highest-return practice: say the plain fact first, then give a concrete plan for learning the grade. The pack also covers your never having been a team lead.
- **The license is met.** Your PEL and its June 2029 expiry are on your CV, so the pack raises no question about it.
- **Your resume included your Social Security number.** I left it out of the pack. Don't include it on anything you send to a school district.

Everything is sourced to your invite, your background, or the district's own pages. I didn't have the posting text, so the requirements that come from the district's hiring page and a representative listing are labelled as inferred. The pack has 21 questions, weighted toward a skeptic (the principal) and a values interviewer, with peer and prober questions for the two team members.

Offers, one line each:
- I can play the Skeptic on A2 as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.
- I can convert the pack to a Word document if you want one.

Do you have the full posting, and did HR say what the panel will focus on? Either would sharpen the requirement rows and the persona weights.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Orrinsford_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Format: 45-minute panel on Thursday (19 November). Panel: Principal Dolores Vantongeren plus two members of the fourth-grade team. Built from the invite and your background. No posting text was supplied, so requirements come from the invite, the district's own careers and mission pages, and one representative listing, each labelled.
## How to use this pack

- **Personas** describe how a question will arrive. **Types** describe what it scores: VAL = values and behaviour, EXP = your own experience, JD = the role's stated requirements, CO = company knowledge, CASE = a live problem.
- The guidance is scaffolding, not a script. Say things in your own words, and stop where your material stops.
- An **answer slot** is an instruction for the interview: it gives you two honest branches. It is not a question to me.

## Reading the interviewer

- **Dolores Vantongeren, Principal.** Public footprint only: principal of Halvering Elementary since 2022, after nine years as a reading specialist. Her 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5 (source: ilprincipalsforum.example, search result, not fetched).
- **Implications.** Reading is her stated professional focus, so expect reading questions from her. Her career is reading-centred, so the reading-club and curriculum sentences from your CV will matter to her.
- **Mirror opportunity.** Shared focus, not a shared career jump: reading. Your quoted sentence is "I led our grade level's move to a new reading curriculum in 2024" (your CV). Use it to talk about reading, not about her path.
- **Panel members.** No names were given, so no public footprint was researched. Their persona weights below are the peer prior.

## Fit snapshot

The requirement column quotes only text in the invite, the district's pages, or the listing. The evidence column quotes only your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" (invite) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | medium | [grounded] | none | No gap. Words: "I hold the Illinois PEL with an elementary endorsement, active through June 30, 2029." Bring a copy of the license if asked. The gate is met, so no question about it is raised. |
| F2 | "Fourth Grade Teacher" position (invite title) | "Six years teaching third grade at a public elementary school in Joliet" (your CV), "I've never taught fourth grade" (your message) | none | [grounded] | capability | A stated absence, which the pack gives back in your words: "I haven't taught fourth grade." Then say how you would learn the grade, as a plan and never as a past: which fourth-grade materials you would read first and which teammate you would ask. Do not describe fourth-grade experience you do not have. |
| F3 | "work with the grade-level team" (representative listing, inferred) | "I led our grade level's move to a new reading curriculum in 2024" (your CV) | medium | [inferred] | presentation | The quote already reaches teamwork in other terms. Reword only that quote: "In 2024 I led our grade level's move to a new reading curriculum." Add no meeting, decision or outcome. |
| F4 | "how you work with families" (Orrinsford hiring page, fetched) | "I write a weekly email to families." (your CV) | medium | [grounded] | none | The quote reaches the requirement directly. Words: "I write a weekly email to families." Lead with the email. |
| F5 | "reading instruction" (Orrinsford hiring page, fetched) | "I led our grade level's move to a new reading curriculum in 2024" (your CV), "I've run the after-school reading club for the last two years." (your CV) | medium | [grounded] | presentation | Both quotes reach reading instruction in other terms. Reword only them. The club is after school, so say that yourself rather than letting a panel discover it. |
| F6 | "Every Child a Reader: no student leaves third grade without a reading plan" (Orrinsford mission page, fetched) | "I've run the after-school reading club for the last two years." (your CV) | low | [inferred] | discovery | The club quote touches reading but does not show whether reading plans were written for students. Answer slot: if you wrote a reading plan for any student, describe what it said and how you tracked it; if you did not, say so and describe how you would write one. |
| F7 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" (Orrinsford mission page, fetched) | none given | none | [grounded] | discovery | No quote touches assessment. Answer slot: if you have used an assessment to change what you taught, say what and why; if you have not, say so and describe how you would use one. |

Gap types in use: F1 none, F2 capability (stated), F3 and F5 presentation, F4 none, F6 and F7 discovery. Provenance labels: F1, F2, F4 and F5 are grounded; F3 and F6 inferred; F7 is grounded because the belief is quoted from the district's page.

## Prohibited claims

These are claims the pack will not coach. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Taught fourth grade, or any fourth-grade experience | Stated negative (F2) | "I haven't taught fourth grade." Plain acknowledgment, no answer slot. |
| Served as a team lead | Stated negative: "I've never been a team lead" (your message) | "I haven't been a team lead." Plain acknowledgment, no answer slot. |
| Owned the district's reading program or curriculum selection | Inflated form of F3 and F5 | Your quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: the material says the move, not the selection or ongoing ownership. |
| Wrote a reading plan for each student | Inflated form of F6 | The club quote at its scope. Answer slot, as in F6. |
| Speaks with every family each term | Inflated form of F4 and of the district belief "each teacher speaks with every family each term" | "I write a weekly email to families." The district's belief is the district's, not your record. |

## Persona table

Panel weighting follows the relationship priors: the principal is a hiring-side read (Skeptic and Values), and each grade-level colleague is a peer (Peer Evaluator and Prober).

| Persona | How it shows up | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the fourth-grade gap and the missing team lead, asks why now and why here | High, weight 5. The invite's grade title and your two stated absences make this the likeliest line of questioning | Rehearse the single most predictable objection until it is plain; say the stated absence first; keep the plan concrete |
| Values / Behavioral | Scenario questions tied to the district's three beliefs | High, weight 4. The mission page says the beliefs "guide every hire" | Map each belief to a quoted sentence where one exists; where none does, use the selection scaffold and its honest branch |
| Peer Evaluator | Seam questions about third to fourth grade, what the hire adds to the team's planning | Medium, weight 3. Grade-level colleagues price what a hire costs their work | Reciprocity framing: what you bring to their team, and a principle for the seam |
| Data-Driven Prober | Asks how you know something worked, how it was counted | Medium, weight 3. Your CV has no outcome figures, so a probe will most likely ask for one | Say what you tracked, or say plainly you did not track it; name the weakest assumption before they do |
| Case / Strategist | A live problem about a fourth grader | Low, weight 2. The invite names no case | Clarify, then assess, then plan; think aloud |
| Pressure | Time-boxed challenge to the fourth-grade absence | Low, weight 2 | Hold the plan through two follow-ups; concede only what you cannot yet say |
| Conversational | Friendly opener about your path | Low, weight 2. A rapport opener is still scored | Pre-scripted 90-second arc; treat casual questions about families and reading as scored |

## Question banks

Coverage at a glance follows in the next section. Totals: 21 questions. Highest-ROI prep is A2, the fourth-grade absence in the panel's own words.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What in that prepares you for fourth-grade reading?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | Start from the six years, in your own words. Then the plain acknowledgment: "I haven't taught fourth grade." Answer slot: if you know fourth-grade reading expectations from any source, name it; if not, say so and say what you would read first | F2 is the main gap, and this question is its first form |
| A2 | "What would you need to learn first to teach fourth grade well?" | JD | [grounded] "I've never taught fourth grade" | Highest-ROI rehearsal. Open with the plain acknowledgment, then the plan: which materials you would read, which data you would request, which teammate you would ask. Hold through two follow-ups by returning to the plan. Concede specifically: "I can't yet say how fourth-grade pacing differs from third." | F2 is the objection the panel will raise in some form, and a non-defensive plan changes the interview |
| A3 | "Why fourth grade, after six years in third?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer your motivation in your own terms, and do not claim a reason you have not stated. Answer slot: if the reason is that the position is open, say so; if it is something you can name, name it | A standard motivation probe on the grade change |
| A4 | "Your reading club has run two years. Did you ever write a reading plan for a student?" | JD | [grounded] "I've run the after-school reading club for the last two years." | Describe the club in its own terms. Answer slot: if you wrote a plan for any student, say what it said and how you tracked it; if you did not, say so and describe how you would write one | F6 is discovery with low confidence, and the belief "no student leaves third grade without a reading plan" is the raising source |
| A5 | "How would you work with a team whose lead you have never been?" | JD | [grounded] "I've never been a team lead" "I led our grade level's move to a new reading curriculum in 2024" | Plain acknowledgment: "I haven't been a team lead." Then describe the move in the sentence's scope only, and how you worked with colleagues on it | Team lead is not a stated requirement, but the team format makes this probe likely |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a student's reading changed because of something you did." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story map on the curriculum move: the 2024 move and your part in leading it, in the sentence's terms. Answer slot: if you tracked what changed for students, say what you counted; if you did not, say so | Open prompt tied to "Every Child a Reader" |
| B2 | "How do you keep families informed about their child's reading?" | VAL | [grounded] "I write a weekly email to families." | Describe the weekly email in your own words. Answer slot: if every family replies or speaks with you each term, say how; if not, say so and what you would do | "Families Are Partners" |
| B3 | "Our assessments inform teaching and never replace it. Tell me about an assessment that changed what you taught next." | VAL | [generic] | Selection scaffold: pick a time an assessment changed your next lesson; if none comes to mind, say so plainly, then describe how you would use one | F7 is discovery, so this is a scaffold, not a story |
| B4 | "What does a classroom routine look like in your room?" | VAL | [grounded] "I write a weekly email to families." | Describe one routine in your own words. Answer slot: if you have a reading routine you can name, name it; if not, describe one you would start | Classroom routines are a stated panel topic on the hiring page |

### C. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you fit into a fourth-grade team's planning?" | JD | [inferred] "work with the grade-level team" "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity framing: what you bring to their planning, in terms of the 2024 move; then what you would need from them. No claim about how their planning runs | F3 is the teamwork bridge; the requirement is inferred from a listing |
| C2 | "Where do you see the seam between third and fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Propose a principle: what a third grader should leave with. Answer slot: if you have seen a third-to-fourth handoff, say it; if not, say so and propose how you would find out | A peer probe on the grade change |
| C3 | "What would help you most from a new colleague in the first month?" | VAL | [generic] | Ask for what you need, and offer what you bring. Name one concrete offer from your own experience | Peer reciprocity, the one question a colleague asks to test partnership |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How would you judge whether the 2024 curriculum move helped students?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name the assumption you would defend least, in your own words. Answer slot: if you tracked a result, say what you counted and how; if you did not, say so | A metric probe on the one outcome-shaped sentence you have |
| D2 | "How do you know your weekly family email reaches every family?" | EXP | [grounded] "I write a weekly email to families." | Answer slot: say how you check delivery; if you do not check, say so | A probe on a routine claim |
| D3 | "Walk me through who attended the reading club and how you tracked attendance." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Say the club's shape in your words. Answer slot: if you tracked attendance, say how; if you did not, say so | A denominator probe on the club |

### E. Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A fourth grader reads well below grade level in October. What do you do first?" | CASE | [generic] | Clarify, then assess, then plan. Name what you would check first. No claim about your past | A live reading problem, the panel's own focus |
| E2 | "Sketch a family-communication routine for the team." | CASE | [grounded] "I write a weekly email to families." | Anchor in the weekly email and build out from it. Make no claim beyond the sentence | "Families Are Partners" as a plan |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Fourth grade is a different job. Why should we hire someone who has never done it?" | JD | [grounded] "I've never taught fourth grade" | Hold: "I haven't taught fourth grade," then the plan. Hold through two follow-ups by returning to the plan. Concede: "I can't yet say how fourth grade differs in pacing" | Pressure form of A2 |
| F2 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Do not compare. Name what you bring, in the six years' terms, and stop | A composure test |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through your path to teaching." | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | A 90-second arc: start, the six years, the reading club, the 2024 move, and why you are here. Make no claim beyond the quotes | A rapport opener that is still scored |
| G2 | "What's the best part of working with families?" | VAL | [grounded] "I write a weekly email to families." | Keep it short and specific to the email | A casual question on a stated focus |

## Requirement coverage

| Requirement | Source | Questions |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | Invite | none, and why: the gate is met by your CV, so no question is raised |
| Fourth-grade teaching | Invite title | A1, A2, A3, F1, F2 |
| Work with the grade-level team | Listing, inferred | C1, C2, A5 |
| How you work with families | Orrinsford hiring page | B2, B4, E2, G2 |
| Reading instruction | Orrinsford hiring page | B1, D1, D3, A4, E1 |
| Every Child a Reader: reading plans | Orrinsford mission page | A4 |
| Teach for Tomorrow: assessment | Orrinsford mission page | B3 |
| Classroom routines | Orrinsford hiring page | B4 |
| Team lead | Not a stated requirement; your own stated absence | A5 |

## Reverse questions

Each question has a "why it lands."

1. "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What does a fourth-grade conference look like here?" Why it lands: it ties to the principal's own work and shows you read her, not only the district.
2. "How does the fourth-grade team plan reading instruction together?" Why it lands: it asks about the team you would join.
3. "What does the district expect from a fourth-grade teacher in the first term?" Why it lands: it turns the grade change into a shared question.
4. "How do families reach teachers here, and how often?" Why it lands: it shows you read the district's families belief.
5. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity, for the peer colleagues.
6. "What support exists for a teacher taking on a grade she hasn't taught?" Why it lands: it names the gap as a question, not an apology.

## Sources

Provided documents: your invite (pasted) and your background (pasted).

Searches and fetches, with results:

- "Orrinsford Community School District Halvering Elementary School": no results.
- "Orrinsford Community School District values mission": returned orrinsfordschools.example/about/mission-and-beliefs.
- "Orrinsford Community School District fourth grade teacher interview process": returned orrinsfordschools.example/careers/how-we-hire-teachers.
- "Dolores Vantongeren principal Halvering Elementary": returned ilprincipalsforum.example/speakers/dolores-vantongeren.
- "Illinois elementary teacher fourth grade job description reading instruction families": returned k12jobsboard.example/listings/fourth-grade-teacher (snippet only, not fetched).
- Fetched: orrinsfordschools.example/about/mission-and-beliefs; orrinsfordschools.example/careers/how-we-hire-teachers.

Research tier: L1, searches 5 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Mission page: three beliefs, used in sections B and the fit snapshot rows F6 and F7 |
| 2. Orrinsford interview process, fourth-grade role | yes | Hiring page: one 45-minute building panel, principal plus two grade-level teachers; the panel asks about reading instruction, classroom routines and families. This establishes the loop: one session, a panel. No values-style round is named, so the values cheat sheet is dropped |
| 3. Strategy and recent news | skipped | The invite fixes the format, and a district with no published strategy gives no competitive frame for a CO bank |
| 4. Interviewer name | yes | Principal footprint: one public talk, a career summary. Panel members had no names, so no search |
| 5. Representative JD | yes | The K12 listing, from its snippet, supplies inferred requirements F3 and C1 |

No deep research was run. The offer appears in the upgrade menu.

## Upgrade menu

- The full posting text → replaces the [inferred] requirements F3 and C1 with [grounded] ones, and adds any requirement the listing does not show
- HR's stated focus areas for the panel → reweights the persona table and retunes the reading questions
- The panel members' names → per-member persona weights and a tailored reverse question for each member
- Any fourth-grade pacing guide or curriculum name you can share → gives the answer slot in A2 a concrete first branch
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → adds district strategy, recent hiring changes and interviewer talks
