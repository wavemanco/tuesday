# Interview prep: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel, 45 minutes, Thursday. Principal Dolores Vantongeren, plus two fourth-grade team members (names not given). Built for Grace from her CV, her note, and the invite. Two things were assumed and are listed in the upgrade menu: that the principal is your direct manager in this role, and that the two team members are teachers at your level.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

- **JD**: can you do the listed job, gaps included
- **EXP**: do your CV's claims survive scrutiny, and what did you actually do
- **VAL**: does past behavior show the district's published beliefs
- **CO**: company and strategy knowledge (not covered in this pack; see the upgrade menu)
- **CASE**: a live problem from the actual role, reasoned aloud

## Prep triage (Thursday, about two days)

1. **A1 and A5**: the fourth-grade gap. Practice until your first answer is plain and your follow-up answers don't change. This is the highest-return prep in the pack.
2. **B2 and F4**: reading instruction. The principal's public focus is reading, and your curriculum move is your strongest material.
3. **C2 and A3**: the team-lead gap, asked by the team members.
4. **Reverse questions**: pick three and write them on a card.
5. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Met on your CV. Have the registration and its expiry date ready. Nothing in the material shows the license has been checked, so expect it to be confirmed. |
| F2 | "Fourth Grade Teacher" — position title, your invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Your material says third grade, six years, a public elementary school in Joliet. Say that and stop there; fourth grade is adjacent work, not the same grade. Answer slot: a fourth-grade teacher plans and teaches reading, writing, math, science and social studies (typical listing, see Sources). If any of those were taught at third grade, say which and what carried over; if not, say so. |
| F3 | "Fourth Grade Teacher" — position title, your invite | "I've never taught fourth grade" — your message | high | [grounded] | capability | Words: "I haven't taught fourth grade." Then how you would learn it, stated as a plan and never as a past. |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | none | The quote reaches reading instruction in its own terms. Bridge only that: "I led our grade level's move to a new reading curriculum in 2024." The material does not say what "led" covered. |
| F5 | "Every Child a Reader" — district mission and beliefs page | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | The quote reaches the reading belief in its own terms. Your material gives no outcome for the club, so say what it was and do not add one. |
| F6 | Team leadership — not in your invite or any source; flagged by you | "I've never been a team lead." — your message | high | [grounded] | capability | Words: "I haven't been a team lead." Then your approach to leading a team, as a plan. |
| F7 | "work with the grade-level team" — typical fourth-grade listing [inferred] | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | presentation | Your material shows grade-level work through that move, and no more. Bridge only the quote's own words. Do not expand it into team decisions you did not describe. |
| F8 | "communicate regularly with families" — typical fourth-grade listing [inferred]; "each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | none | The weekly email is what your material shows. It does not show that you have spoken with every family each term. If that is true, say it; if not, say what you do. |

Confidence grades your evidence. Provenance grades this pack's statements about it. Gap type is the routing rule's call on F1 to F8.

## Prohibited claims

Not coached in this pack, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Having taught fourth grade | Your own statement, F3 | "I've never taught fourth grade." Plain acknowledgment, source: your message. No slot. |
| Having been a team lead | Your own statement, F6 | "I've never been a team lead." Plain acknowledgment, source: your message. No slot. |
| Choosing or designing the reading curriculum | Inflated form of F4 | The quote at its own scope: you led the move. Your material says you led the move, not that you chose the curriculum. |

## Requirement coverage

| Requirement | Source | Covered by |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | Your invite | F1. None needed: met on your CV, confirm at interview |
| Fourth-grade teaching | Position title | A1, A2, A5 (F2, F3) |
| Reading instruction | District hiring page | B2, D2, E2 (F4) |
| Classroom routines | District hiring page | B3 (no material on routines; selection scaffold) |
| Working with families | District hiring page; typical listing | C3 (F8) |
| Working with the grade-level team | Typical listing | C1, C2 (F7) |
| Every Child a Reader | District beliefs | F1 values question, D1 (F5) |
| Families Are Partners | District beliefs | F2 values question (F8) |
| Team leadership | Your own gap | A3, C2 (F6) |
| Teach for Tomorrow, Not for the Test | District beliefs | None: the name is all the sources give, so no story is coached against it |

## Reading the interviewer

Dolores Vantongeren is the principal. Public footprint only:

- Principal of Halvering Elementary since 2022, after nine years as a reading specialist.
- A 2025 forum talk, "Small Groups, Big Readers," on weekly reading conferences in grades 3 to 5.

Implications:

- Expect reading questions from her round. Your F4 and F5 rows are where that material is strongest.
- Expect a small-group question (B2). Only describe small-group work if you did it.
- Her public path is from reading work into leadership. You can ask her about that path (reverse question 3). You may not claim a shared jump, because the material does not show your side of one.

## Persona table

Panel: blend the top two personas of each member's relationship. The principal is assumed to be a hiring manager (Case/Strategist and Skeptic). The team members are assumed to be peers (Peer Evaluator and Data-Driven Prober). Conversational is an opener. Values is weighted low because no values-style round is documented.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (principal) | Probes the fourth-grade and team-lead gaps; asks why now, why here | High. Your two gaps are the obvious objections, and the invite is for a fourth-grade role | Rehearse A1 until boring. Hold through two follow-ups. Concede specifically, never fold |
| Case/Strategist (principal) | Live reading or routines problem for a fourth-grade class | High. Her public focus is reading | Clarify, then plan, then name a check. Say what you would learn first |
| Peer Evaluator (team) | Seams between classes, shared planning, families | High. Team members judge whether you add to their load | Offer seam principles, not a claimed seam. Ask what they need |
| Data-Driven Prober (team) | Asks what the club or the email accomplished | Medium. Your claims are real but unquantified | Say what you counted, and say plainly when you did not count |
| Conversational (opener) | "Walk us through your path" | Medium. Casual openers are still scored | Prepare a 90-second arc |
| Values (principal or team) | Published beliefs as prompts | Low to medium. Beliefs are published, but no values round is documented | Map stories to beliefs only where your CV carries one; say plainly where it does not |

## Question banks

### A. Skeptic (principal), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years. What would you need to learn first to teach fourth grade well?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; [grounded] "I've never taught fourth grade" — your message | Hold to the quotes: six years of third grade, and no fourth grade. Name the one thing you would learn first and how, as a plan. Hold through two follow-ups by returning to what you have taught. Concede the fourth-grade gap specifically. Answer slot: none needed for the plan; any claim about fourth-grade work you have done must be in your own words, and if there is none, say so. | The highest-return rehearsal in this pack: F2 and F3 are the gap this question targets, and it will arrive in some form |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" — your message | Name the content area you would be least ready for, then how you would plan it in week one. Do not claim any fourth-grade planning you have not done | F3's gap, asked as a self-assessment; it tests whether you name the gap before the panel does |
| A3 | "Tell me about the closest you've come to leading other adults. What did it involve?" | EXP | [grounded] "I've never been a team lead." — your message; [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Say the plain acknowledgment first: "I haven't been a team lead." Then describe the move in the quote's words. Answer slot: if you chaired or directed any part of that move, say which and how you decided; if you did not, say so and describe your role in it | F6 and F7: the honest answer to a team-lead probe is the plain acknowledgment plus your nearest real work |
| A4 | "Why leave a school where you've taught for six years, and why this one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | Give your real reason in your own words. The material does not state one, so the answer must come from you. Do not criticize your current school | Motivation probe; the Skeptic's standard question |
| A5 | "You're asking to teach a grade you haven't taught. Why take that risk over someone who has?" | JD | [grounded] "I've never taught fourth grade" — your message; [grounded] "I write a weekly email to families" — your CV | Hold: your third-grade reading work, your routines and your family communication all transfer, and you can name them. Hold through two follow-ups. Concede specifically: "I haven't taught fourth grade, and that is the part I would plan for first." Never fold on the transfer | Pressure version of A1. Hold-then-concede: the hold is the quotes' scope, not more |

### B. Case/Strategist (principal), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A child in your class reads at a second-grade level in October. Walk me through the first two weeks." | CASE | [generic] | Clarify: what assessment you have, what the child has been taught. Then: a small-group plan, a check at week two, and a family conversation. Say what you would learn first | A live reading problem from the role. The question makes no claim about your past |
| B2 | "Your fourth graders are at four reading levels. How do you run small-group reading in a 45-minute block?" | CASE | [inferred] the district's reading focus, from the 2025 talk title "Small Groups, Big Readers" and the hiring page's "reading instruction" — public sources; [grounded] "I've run the after-school reading club for the last two years" — your CV | Give a structure: groups, rotation, check. Answer slot: if the club used small groups, say how it was organized in your own words; if it did not, say so and describe what you would do in the block | The principal's public focus; F5 is the club's only evidence, and its format is not in the material |
| B3 | "Walk us through the routines you'd set in the first week of a fourth-grade class." | CASE | [grounded] "Panels ask about reading instruction, classroom routines and how you work with families" — district hiring page | Name three routines in order and why. Answer slot: if you have set routines you can describe from your work, use one in your own words; if not, describe the routine you would set and why | Routines are a named panel topic; the material has none, so this stays a plan |

### C. Peer Evaluator (team members), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our team plans together every week. Where would you want the seam between your class and ours?" | JD | [inferred] "work with the grade-level team" — typical fourth-grade listing | Propose principles: shared unit calendar, shared assessment dates, agreed reading routines. Say you would ask them where the seam sits now. Do not claim you know their seam | F7's requirement; team members weigh whether you add to their load |
| C2 | "You've never been a team lead. What would you do if the team disagreed with your plan?" | JD | [grounded] "I've never been a team lead." — your message | Say the plain acknowledgment: "I haven't been a team lead." Then your approach: listen, check the goal, settle the plan on evidence. Answer slot: if you have disagreed with a colleague about a plan, say what happened and how it ended; if not, describe the approach | F6's gap, asked by peers in collegial form |
| C3 | "Families are where our workload piles up. How do you handle a parent who disagrees with your grading?" | JD | [grounded] "I write a weekly email to families" — your CV | Say what your weekly email does and what it doesn't. Answer slot: if you have handled a parent disagreement, say how; if none came up, say so and describe your approach | F8: the email is real; any parent-conference claim is not in the material |

### D. Data-Driven Prober (team members), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did the after-school reading club look like, and how would you know whether it was working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" — your CV | Describe the club in your own words. Answer slot: if you tracked anything (attendance, reading levels), name it; if you tracked nothing, say so plainly and say what you would track | F5 has no outcome in the material; the question asks for the method without presupposing one |
| D2 | "You say you led the move to the new reading curriculum. Which decisions were yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Name the weakest assumption you would defend least, before they do. Answer slot: if you chose the curriculum or any part of the rollout, say which and how; if the choice was made above you and your part was leading the move, say that plainly | F4 is your strongest evidence and the likeliest place for a probe. Do not say you chose the curriculum; it is on the prohibited list |
| D3 | "How do you know your weekly family email is doing its job?" | EXP | [grounded] "I write a weekly email to families" — your CV | Say what the email is for. Answer slot: if you count replies or opens, name what you count; if you do not, say so and say what you would measure | F8's bridge: the question asks what you measure, and the honest answer may be nothing |

### E. Conversational (opener), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your path to teaching in Joliet and to here." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV | A 90-second arc: six years of third grade, the reading curriculum move, the club, the family email, and why fourth grade, in that order. Answer slot: your reason for fourth grade in your own words; the material does not state one | An opener is scored. The arc is the material's order, nothing added |
| E2 | "What are you actually doing with reading instruction these days?" | JD | [grounded] "Panels ask about reading instruction, classroom routines and how you work with families" — district hiring page | Name what you use and how you use it in your own words. Answer slot: if your current reading program is one you can name, name it; if not, describe what you do | Casual, but reading is a named panel topic |

### F. Values (principal or team), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Orrinsford's belief is that every child leaves third grade with a reading plan. What does that look like in your class?" | VAL | [grounded] "Every Child a Reader" — district beliefs page; [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Hold to the quote: your reading move. Answer slot: if you wrote or used reading plans, say what they were; if the move changed what teachers did with reading plans, say what changed; if not, say so and describe what you would do | The district's published belief is a raising source for this theme. The answer must come from your work, not the belief |
| F2 | "Orrinsford says families are partners, with each teacher speaking to every family each term. How do you make that happen?" | VAL | [grounded] "I write a weekly email to families" — your CV | Say what the weekly email does. Answer slot: if you have spoken with every family in a term, say so; if not, say so and say how you would reach every family | F8's honest form: the email is real, the speaking-to-every-family claim is not in the material |

## Reverse questions

1. "What does a strong first year look like for a fourth-grade teacher on this team?" Why it lands: it signals you are planning for the role, not for the interview.
2. "How do the fourth-grade reading plans connect to what the third-grade team already does?" Why it lands: it shows you know the transition is the gap, and asks how they handle it.
3. "Principal Vantongeren, what made the move from reading specialist to principal the right next step for you?" Why it lands: it ties to her public path and turns the interview toward a peer conversation.
4. "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" Why it lands: reciprocity with the team members, who judge whether you add to their load.
5. "What does the team expect a new teacher to take on in the first year, and what should they leave alone?" Why it lands: it surfaces the workload they are protecting.
6. "How does the grade level check reading progress across the year?" Why it lands: it ties to the district's reading belief and asks for their process, not an opinion.

## Sources

Provided documents: your CV (as pasted), your message, and the interview invite.

Queries and results (L1, four searches; no fetches):

- "Orrinsford Community School District Halvering Elementary School values" → mission and beliefs page: "Every Child a Reader," "Families Are Partners," and "Teach for Tomorrow, Not for the Test"
- "Orrinsford Community School District fourth grade teacher interview process panel" → "How we hire teachers" page: one 45-minute building panel with the principal and two grade-level teachers; panels ask about reading instruction, classroom routines and how you work with families
- "Dolores Vantongeren principal Halvering Elementary" → Illinois principals forum speaker profile: principal since 2022, nine years as a reading specialist before that; 2025 talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5
- "fourth grade teacher job description Illinois elementary responsibilities qualifications" → K12 jobs board listing (typical, not this district's): plan and teach reading, writing, math, science and social studies; differentiate instruction; keep classroom routines; communicate with families; work with the grade-level team

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Beliefs in F5, F8, F1 values question and the Values bank; no values cheat sheet, because the hiring page names panel topics, not a values round |
| 2. Interview process | yes | Panel structure; persona blend |
| 3. Strategy / recent news | unavailable | Not run in this pass. Would have moved the CO bank, which this pack does not include |
| 4. Interviewer name | yes | Reading the interviewer; reading weighting; reverse question 3 |
| 5. Representative fourth-grade JD | yes | Typical-listing requirements, marked [inferred] in F2, F7, F8, B2, C1 |

No values-style round is detected: the hiring page does not name one, so the values cheat sheet is omitted.

## Upgrade menu

- A full job posting (JD) → converts the typical listing's rows (F7, F8, C1, B2 and the representative JD answer slot in F2) from [inferred] to [grounded]
- The names of the two team members → persona assignments per member, and tailored reverse questions
- Confirmation that the principal is your direct manager and the team members are your peers, or leads → reweights the persona table
- A recruiter's note on process or any deliverable → coverage for any named exercise
- Deep research (L2, offered once: about six more searches and two fetches on the district's strategy, the principal's talks and writing, and recent district news) → a grounding brief, and a CO bank for strategy questions
