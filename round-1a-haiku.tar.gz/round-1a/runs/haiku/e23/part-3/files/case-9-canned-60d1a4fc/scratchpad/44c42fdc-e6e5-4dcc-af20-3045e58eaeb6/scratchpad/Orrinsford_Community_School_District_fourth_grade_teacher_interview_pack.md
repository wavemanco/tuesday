# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District · 45-minute panel · Principal Dolores Vantongeren plus two fourth-grade team members (names not yet known)

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral / values alignment with the district's published beliefs |
| EXP | Your own experience: does your account hold up under follow-up |
| JD | Role requirement the panel will score |
| CO | Company knowledge (not covered: no strategy research ran) |
| CASE | Live problem from the classroom, delivered aloud |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." (invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV) | high | [grounded] | none | No gap. Your credential is stated in those words; say it that way. |
| F2 | "Panels ask about reading instruction, classroom routines and how you work with families." (district hiring page) | "I led our grade level's move to a new reading curriculum in 2024" (your CV); "I've run the after-school reading club for the last two years" (your CV) | medium | [grounded] | presentation | The two quotes reach reading instruction in other terms: a curriculum move you led, and a club you run. Reword only those; add no practice. Answer slot: the panel may ask how the curriculum was chosen or what the club achieved. If you chose the curriculum, say how and why; if the decision was made above you, say so plainly and describe your part. |
| F3 | "Fourth Grade Teacher position" (invitation) | "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | low | [grounded] | capability | Words for the gap: "I've never taught fourth grade." Then the adjacent quote, at its own scope: six years of third grade. Do not describe fourth-grade work as if you had done it; describe how you would learn it, as a plan. |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families." (district hiring page) | none given | none | [inferred] | discovery | Your material does not show a classroom routine. Answer slot: describe a routine you run now, in your own words, and say how you would set routines for a fourth-grade day. If you have no routine you can describe, say so and say what you would set up first. |
| F5 | "Families Are Partners: each teacher speaks with every family each term." (district values page) | "I write a weekly email to families." (your CV) | medium | [grounded] | transferability | Your quote is written contact, weekly. It does not show a conversation with every family each term. Bridge at its own scope: the weekly email. Answer slot: if you have spoken with families each term, say how often and about what, in your own words; if not, say so and say what the email gives you. |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district values page) | "I've run the after-school reading club for the last two years" (your CV) | low | [inferred] | discovery | Your material names the club but not what it measured. Answer slot: if any assessment changed what you taught, say which and how; if none did, say so and say what you would assess first. |
| F7 | "two members of our fourth-grade team" (invitation) | "I've never been a team lead." (your message) | none | [grounded] | capability | Words for the gap: "I haven't been a team lead." Then how you would work as a team member, said as a plan, never as a past. |

Confidence grades the evidence. Provenance grades what this pack wrote about it. Gap types follow the evidence cell.

## Prohibited claims

Not coached in any answer, bridge or reverse question. The honest form is given for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Chose the reading curriculum | Inflated form of F2: the quote says you led the move | "I led our grade level's move to a new reading curriculum in 2024." Limit, in the pack's own analysis: your material says you led the move, not that you selected the curriculum. |
| Ran the school's reading program | Inflated form of F2: the quote says a club you run | "I've run the after-school reading club for the last two years." |
| Has taught fourth grade | Negative you stated (F3) | "I've never taught fourth grade." |
| Has been a team lead | Negative you stated (F7) | "I've never been a team lead." |

## Reading the interviewer

Public footprint only. Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist. Her 2025 talk at a state principals' forum covered weekly reading conferences in grades 3 to 5. Source: ilprincipalsforum.example speaker page.

- Expect reading-instruction probes from her. Her public work is reading conferences, so a concrete account of reading instruction will land.
- Her background is reading specialist to principal. This is not a career jump like yours, so there is no shared-jump reverse question on her path.
- No shared-jump mirror. Use her talk's vocabulary only if your own material uses it.

## Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Principal (hiring manager prior) | Live classroom problems, e.g. a struggling reader in October | High: the invitation is a hiring panel and her talk is on reading | Clarify, then assess, then plan, then say how you'd know it worked |
| Skeptic | Principal | Fourth-grade gap, team-lead gap | High: the two stated gaps are the most probable objections | Hold, then concede specifically; the plan is a plan, not a past |
| Peer Evaluator | Team members (peer prior) | Seam questions, how you'd join the team | High for a grade-team panel | Reciprocity: what you'd bring the team, not only what you need |
| Data-Driven Prober | Team members | Reading club results, assessment use | Medium: no results in your material | Say what you did and did not count; name the weakest assumption you know |
| Values / Behavioral | Panel (district values) | Families, assessment | Medium: the district names these beliefs | Map to your quoted sentences; where none carries a story, use the selection scaffold |
| Conversational | Opening question | "Tell me about yourself" | High as an opener | Pre-scripted 90-second arc from your own sentences (D1) |

Weights: Principal 5 questions, each team member 3 to 4, opener 1.

## Question banks

### A. Principal (Case / Skeptic), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the reading curriculum move you led." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Name the move, who was involved, and what you did, using "led" only for what your sentence says. Answer slot: if you chose the curriculum, say how and why; if the decision was made above you, say so and describe your part. | F2 is the strongest reading evidence and her likeliest entry point |
| A2 | "A fourth grader reads at a second-grade level in October. What do you do in the first two weeks?" | CASE | [generic] | Structure: what you would assess first, how you would group, what you would tell the family, and how you would check progress. The question makes no claim about your past. | A live classroom problem from the hiring panel's reading focus |
| A3 | "You've taught third grade. What's your plan for fourth-grade content?" | JD | [grounded] "I've never taught fourth grade" (your message); "Six years teaching third grade at a public elementary school in Joliet" (your CV) | Say the adjacency at its own scope: six years of third grade. Plain acknowledgment: "I've never taught fourth grade." Then a plan for learning the fourth-grade content. | F3 |
| A4 | "Why should we take a third-grade teacher for a fourth-grade role?" | JD | [grounded] "I've never taught fourth grade" (your message) | The highest-ROI prep in this pack. Hold: name the six years and what they cover; concede the gap in one plain sentence; present the ramp as a plan. Hold through two follow-ups by returning to what you have done, never by adding to it. | F3 is the most probable objection; the panel will ask it in some form |
| A5 | "You haven't been a team lead. How would you work with two colleagues who've taught this grade for years?" | JD | [grounded] "I've never been a team lead." (your message) | Plain acknowledgment: "I haven't been a team lead." Then how you would work as a member: listen first, bring your reading data, share credit. Plan language only. | F7 |
| A6 | "Every Child a Reader: no student leaves third grade without a reading plan. How would you write one for a student?" | VAL | [inferred] "Every Child a Reader: no student leaves third grade without a reading plan." (district values page); [grounded] "I've run the after-school reading club for the last two years" (your CV) | Describe what a reading plan contains in your own words. Answer slot: if you have written one for a student, say so and what it held; if not, say so and describe how you would write one. | Names the district belief; the club is the nearest quote |
| A7 | "How do you work with a family whose child is struggling?" | VAL | [inferred] "Families Are Partners: each teacher speaks with every family each term." (district values page); [grounded] "I write a weekly email to families." (your CV) | Start from the weekly email. Answer slot: if you have had conversations with families about a struggling child, say how and what came of it; if not, say so and describe how you would open that conversation. | F5 |

### B. Team members (Peer Evaluator / Prober), weight 3 to 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What does reading instruction look like in your room?" | JD | [inferred] "Panels ask about reading instruction, classroom routines and how you work with families." (district hiring page); [grounded] "I led our grade level's move to a new reading curriculum in 2024" (your CV) | Story from the curriculum move, in your own words. Answer slot: if your block was set by the curriculum, say so; if you built parts of it yourself, say which parts. | F2 |
| B2 | "How did you know the reading club was working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" (your CV) | Name what you did in the club. Answer slot: if you tracked anything, say what and how; if you did not, say so and say what you would track first. | F6; metric question, so name your weakest assumption before they do |
| B3 | "How do you keep in touch with families across a term?" | VAL | [grounded] "I write a weekly email to families." (your CV) | Describe the weekly email and what it contains. Answer slot: if you have had conversations with each family in a term, say how; if not, say so and say what the email covers. | F5 |
| B4 | "A family tells you the weekly email is too long. What do you do?" | CASE | [generic] | Structure: ask what they need, change one thing, check back. The question needs no claim about your past. | Peer-style probe of a family-communication habit |
| B5 | "What would you need from a new teacher on this team in the first month?" | JD | [generic] | Reciprocity: what you would bring to the team and what you would ask for. No claim about your past. | Peer reciprocity; the question is a seam probe |

### C. Second team member and values, weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time an assessment changed what you taught." | VAL | [inferred] "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." (district values page); [grounded] "I've run the after-school reading club for the last two years" (your CV) | Open prompt. Selection scaffold: pick a time a result changed a lesson; if none comes to mind, say so plainly, then give the nearest thing your material carries: the reading club. | F6 |
| C2 | "Walk me through a fourth-grade day in your room." | JD | [inferred] "Panels ask about reading instruction, classroom routines and how you work with families." (district hiring page) | Describe your current routine in your own words, then how you would adapt it. Answer slot: if you have no routine you can describe, say so and say what you would set up first. | F4 |
| C3 | "What would you plan first for the fourth-grade team's reading unit?" | CASE | [generic] | Structure: what you would look at, what you would ask the team, what you would decide first. No claim about your past. | A team-based live problem |

### D. Opener

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about yourself." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" (your CV); "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" (your CV) | A 90-second arc from those five sentences in your own words, in this order: where you teach and how long; your credential; the curriculum move; the club; the family email. Stop there. | Pre-scripted arc so the opener is not improvised |

Requirement coverage: "Panels ask about reading instruction, classroom routines and how you work with families." → A2, A7, B1, B3, B4, C2. "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." → none, and why: the material shows it met (F1), so it earns no question. "Fourth Grade Teacher position" → A3, A4. "two members of our fourth-grade team" → A5, B5, C3. "Every Child a Reader" → A6. "Families Are Partners" → A7, B3. "Teach for Tomorrow, Not for the Test" → C1, B2.

Total: 18 questions (A 7, B 5, C 3, D 1, plus the values bank counted in A and C). Session totals are within the 18–26 range.

## Reverse questions

Each has a reason it lands.

1. "Your 2025 talk covered weekly reading conferences in grades 3 to 5. What would that look like in fourth grade on this team?" Why it lands: ties to her own public work, so it reads as research and as a peer conversation.
2. "Who writes each student's reading plan on this team, and when is it reviewed?" Why it lands: connects to the district's Every Child a Reader belief.
3. "How does a typical term of family contact work for a fourth-grade teacher here?" Why it lands: tests the Families Are Partners belief in practice.
4. "What does the district count as a successful year for a fourth grader?" Why it lands: shows you think about outcomes, not only tasks.
5. "What would you want a new teacher on this team to do in the first month?" Why it lands: reciprocity for the peer members; the answer tells you where the seam is.

## Sources

Provided documents: the invitation; the candidate's resume and message.

Searches and fetches this run:
- "Orrinsford Community School District Halvering Elementary values" → returned mission-and-beliefs page; fetched it.
- "Orrinsford Community School District fourth grade teacher panel interview" → returned how-we-hire-teachers page; fetched it.
- "Dolores Vantongeren principal Halvering Elementary" → returned ilprincipalsforum speaker page (snippet only; not fetched).

Research tier: L1 — searches 3 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Values in A6, B2, C1, A7, B3, reverse question 3 |
| 2. `{company} interview process {role family}` | yes | Panel topics (reading, routines, families) in F2, F4, C2 |
| 3. `{company} strategy` / recent news | unavailable | Budget went to the values, process and interviewer targets first. Would move a CO bank; none is in this pack. Offered in the upgrade menu. |
| 4. `{interviewer name} {company}` | yes | Interviewer read; reverse question 1 |
| 5. representative `{role title}` JD | skipped | The invitation and the district's hiring page already fix the panel's topics |

## Upgrade menu

- The two fourth-grade team members' names → per-member persona weights and reverse questions for each
- The recruiter's note on any demonstration lesson or written task → coverage of that deliverable
- A strategy and recent-news search → CO questions on the district's current priorities
- The full posted job description → F4 and F7 graded against every listed requirement
- Your own account of a routine, a family conversation or an assessment you used → moves those answer slots to quoted evidence (only if it is true, in your words)
- Deep research (offered once; up to 6 more searches and 2 more fetches, roughly the time of this run) → interviewer talks and writing, role-family loop reports, recent district news
