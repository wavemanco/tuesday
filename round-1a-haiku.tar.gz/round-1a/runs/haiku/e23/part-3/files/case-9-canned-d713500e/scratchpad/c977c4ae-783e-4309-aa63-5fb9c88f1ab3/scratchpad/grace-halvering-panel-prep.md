# Mock Interview Prep Pack: Fourth Grade Teacher, Halvering Elementary (Orrinsford CSD)

**Format:** 45-minute panel. Principal Dolores Vantongeren plus two fourth-grade team members.
**Built from:** the invitation and the candidate's resume. No job description was supplied. No web research was run (tier L0). Items marked `[inferred]` come from the title, not from a posting.

## Fit snapshot

| Requirement | Candidate evidence (verbatim) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| Valid Illinois PEL with elementary endorsement (stated in invitation) | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | High | None | n/a |
| Elementary classroom teaching `[inferred]` | "Six years teaching third grade at a public elementary school in Joliet." | High | Adjacent (grade level) | "My six years in third grade mean I know what students bring into fourth grade. I have not taught fourth grade itself." |
| Fourth-grade experience `[inferred]` | "I've never taught fourth grade" | Gap | Absent | Do not claim it. Bridge through third-grade work only. |
| Reading instruction `[inferred]` | "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." | High | None | n/a |
| Grade-team collaboration / leadership `[inferred]` | "I led our grade level's move to a new reading curriculum in 2024" | Medium | Absent (team lead) | "I've never been a team lead. The closest I've come is leading our grade's curriculum move." |
| Family communication `[inferred]` | "I write a weekly email to families." | High | None | n/a |

## Prohibited claims (built locally)

- Do not claim any fourth-grade teaching experience, including student-teaching or substituting, unless the candidate states it.
- Do not claim team-lead experience. Describe the curriculum move only as "led our grade level's move."
- Do not claim knowledge of Halvering's curriculum, values, or data. None has been researched.
- Do not imply the 2024 curriculum move was district-wide unless the candidate says so.

## Persona weights

- **Principal (Vantongeren):** high weight on leadership gaps, the team-lead question, and how the candidate would ramp up. Reads the invitation's license requirement as a gate the candidate already passes.
- **Fourth-grade peers (two):** high weight on instructional specifics and on fit with an existing team. Likely to probe the third-to-fourth transition.
- Relationship priors are panel-default. No interviewer profiles were provided.

## Most likely objection (highest-ROI rehearsal)

**"You've never taught fourth grade or been a team lead. Why should we pick you over someone who has?"**

Guidance: Acknowledge both gaps plainly in one sentence. Then bridge with what you did do: six years of third-grade instruction, the grade-level curriculum move, and two years of running a reading club. Close with what you would do in the first 30 days to get up to speed with the fourth-grade team. Do not argue that the gaps don't matter.

*Provenance: candidate's own sentences: "I've never taught fourth grade and I've never been a team lead."*

## Question banks

### Principal (leadership and fit)

| # | Question | Type | Guidance | Provenance |
|---|---|---|---|---|
| P1 | Tell us about the reading curriculum change. What did you lead, and what did you not? | Behavioral | Describe the steps you personally ran. Name the parts others owned. Do not stretch the scope. | Candidate sentence: "I led our grade level's move to a new reading curriculum in 2024." |
| P2 | You have not taught fourth grade. What would your first 30 days look like? | Situational | Answer with a concrete plan: observe, meet the team, review the fourth-grade scope and sequence, ask for materials. Scaffold: pick a time you took on a new grade or new expectations. | Answer slot. The material does not cover this. |
| P3 | You have not been a team lead. Why should we trust you to help lead a grade-level team? | Skeptic | Acknowledge the gap. Name the nearest thing you have done. Say what you would want to learn. | Candidate sentence: "I've never been a team lead." |
| P4 | Why this school and this grade? | Motivation | Answer from your own reasons. Do not claim knowledge of Halvering that you have not researched. | Answer slot. |

### Fourth-grade peers (instruction and collaboration)

| # | Question | Type | Guidance | Provenance |
|---|---|---|---|---|
| F1 | Fourth-grade reading shifts from learning to read toward reading to learn. How have you handled that shift in your own practice? | Technical | Be honest that you have not taught fourth grade. Describe how you have prepared third-grade readers for more complex texts. Do not claim fourth-grade experience. | Answer slot, partly scaffolded by the candidate's third-grade and reading-club sentences. |
| F2 | Tell us about the reading club. What did students get out of it, and how did you know? | Behavioral | Describe what you actually ran and what you tracked. If you measured nothing, say so. | Candidate sentence: "I've run the after-school reading club for the last two years." |
| F3 | A teammate plans very differently from you. What do you do? | Collaboration | Scaffold: pick a real disagreement about approach, what you did, and how it ended. | Answer slot. |
| F4 | How do you keep families informed about what's happening in class? | Communication | Describe the weekly email: what it contains, and how you adjust it when families don't respond. | Candidate sentence: "I write a weekly email to families." |

### Panel-wide skeptic (rehearse once)

- "Your background is strong in third grade. Why would you be effective in a different grade?" Acknowledge the transfer risk, then give one specific example of learning a new grade's expectations.

## Values cheat sheet

Omitted. No values were detected because no research was run.

## Reverse questions for the panel

- "What does the fourth-grade team most need from a new teammate in the first semester?" *Why it lands:* it shows you are thinking about their needs, not only your own.
- "How does the team currently plan and share reading instruction?" *Why it lands:* it shows you are ready to work within a shared process.
- "What would a successful first year look like for this role?" *Why it lands:* it gives you the evaluation criteria and signals that you plan to be measured.

## Delivery coaching

Omitted. No working-style assessment was provided.

## Upgrade menu

- **Job description (paste it):** unlocks a fit snapshot against the actual requirements instead of inferred ones.
- **Recruiter or HR guidance:** whether the panel expects a demo lesson, a written deliverable, or a particular focus area. Usually one email to the recruiter.
- **Interviewer names:** unlocks an interviewer read and sharper reverse questions. Public professional footprint only.
- **Research depth (L1 or L2):** unlocks Halvering and district values, the district's reading program, and recent strategy.
- **Dossier from job-underwriter:** if you have one, it would add verified evidence and a confirmed list of claims to avoid.
