# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Company:** Halvering Elementary School, Orrinsford Community School District
**Format:** 45-minute panel, Thursday
**Panel:** Principal Dolores Vantongeren, plus two members of the fourth-grade team (names not given)
**Research tier:** L0, provided documents only. School-specific content is generic (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** your past experience, **JD** the role's listed requirements, **CO** company knowledge (not used here, since no research ran), **CASE** a live problem.
- Guidance is scaffolding, not a script. Rehearse the structure and say the words in your own voice.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — invitation | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | high | [grounded] | none | No gap. Say it in the resume's terms. Check the status on the state licensure lookup before Thursday. |
| F2 | "Fourth Grade Teacher position" — invitation (title) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [grounded] | transferability | Your material says third grade, and the bridge stays there: "For six years I taught third grade." Answer slot: the title makes a probe on fourth-grade content likely. Say what from third grade carries over, in your own words. If you have taught or planned fourth-grade content, say what. If not, say so, and say how you would learn what fourth grade expects. |
| F3 | "two members of our fourth-grade team" — invitation (panel) | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [grounded] | transferability | Words: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the panel comes from the fourth-grade team, so expect a probe on working with that team. If the move involved fourth-grade teachers, say how. If not, say what you did with your own grade team. |
| F4 | Grade-team leadership (not in the invitation; a common expectation, [generic]) | "I've never been a team lead" — your CV | high | [grounded] | capability | Words, from your own statement: "I haven't been a team lead." Then what you would bring to a grade team, said as a plan, not as a past. |
| F5 | Reading instruction (role-family expectation, [generic]) | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | presentation | Words: "I've run the after-school reading club for the last two years." Say what the club was for, in your own words. Add no figures. |
| F6 | Regular communication with families (role-family expectation, [generic]) | "I write a weekly email to families" — your CV | high | [grounded] | none | Quote it as written: "I write a weekly email to families." |

Gap-type routing: F1 is a gate the material shows met, so it routes by its evidence cell to `none`. F2 and F3 are adjacent work that does not fully reach the requirement (`transferability`). F4 is a stated absence (`capability`). F5 restates a quote in other terms (`presentation`). F6 is fully reached (`none`).

## Prohibited claims

Claims this pack will not coach, and why. Each is a claim a candidate could reach for under pressure.

| Claim (listed wording) | Kind | Basis | Honest form |
|---|---|---|---|
| Teaching or having taught fourth grade | Sourced entry | Your CV: "I've never taught fourth grade" | "I haven't taught fourth grade. What I have is six years of third grade." |
| Having been a team lead, or having led a team | Sourced entry | Your CV: "I've never been a team lead" | "I haven't been a team lead." Then the move you led, at its own scope. |
| Choosing, selecting or adopting the reading curriculum | Inflated-form entry | Your CV says you led the move to the curriculum, not that you chose it | Quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Your material says the move, not the selection. |
| Designing or building the reading club | Inflated-form entry | Your CV says you run the club | "I've run the after-school reading club for the last two years." |

## Persona weights

Relationship priors: a hiring-manager prior (Case plus Skeptic) for the principal, and a peer prior (Peer Evaluator plus Prober) for the two team members. The round is a panel, so each member's top personas are blended.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes the grade change and the team-lead gap | High. The principal is buying a fourth-grade hire who has only taught third grade, and the invitation makes the grade the headline | Name the gap in your own words first, then a ramp plan | 4 |
| Peer Evaluator | Collaboration, disagreement, credit | High. Two fourth-grade teachers will be asking what working with you is like | Reciprocity framing; say what you need and what you bring | 4 |
| Data-Driven Prober | Reading club and curriculum: how results were known | Medium. No figures are in your material, so any figure you cite will be checked | Say what you can and cannot say about how it was counted | 3 |
| Case / Strategist | A live reading or family-communication problem | Medium. The panel is hiring for classroom work, so a live problem is plausible | Clarify, then objective, then approach, then measures, then risks | 3 |
| Values / Behavioral | Stories about families and disagreement | Medium-low. No published school values were checked, so the questions are generic | Stories with a specific moment; say so when none comes to mind | 2 |
| Pressure | Composure on the grade change and the curriculum credit | Medium-low. Used for a stress round if the panel runs one | Pause, restate, hold two follow-ups, then concede a specific point | 2 |
| Conversational | Opening "walk me through" and an easy closing question | Medium. Casual openers are still scored | A 90-second arc, pre-built from your quotes | 2 |

## Question banks

Question IDs are letter-by-persona. Every guidance cell rests on the quotes shown in its Provenance column. Where a cell has no quote, it is a selection scaffold or an answer slot.

### Skeptic (weight 4)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | JD, EXP | "Fourth grade is a different grade. What makes a third-grade teacher ready for it?" | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV. Raising source: the title "Fourth Grade Teacher position," from the invitation | Open with the quote at its own scope: "For six years I taught third grade." Then name one thing from third grade that carries over, in your own words. Answer slot: if you have taught or planned any fourth-grade content, say what it was. If not, say so, and say how you would learn what fourth grade expects in your first month. | The title is the raising source. The grade change is the most likely probe from a principal. Covers F2. |
| A2 | EXP, VAL | "You haven't been a team lead. What would you do on a grade team?" | [grounded] "I've never been a team lead" — your CV; [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Plain acknowledgment first: "I haven't been a team lead." Then the one thing your material shows, at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say how you would contribute to a grade team's planning, in your own words. Do not claim a team-lead role you did not hold. | A stated gap, asked directly. Covers F3 and F4. |
| A3 | JD | "Which part of this role would you be weakest at on day one?" | [grounded] "I've never taught fourth grade" — your CV | Answer with the stated gap, then a ramp plan, not a bluff. The honest answer is fourth-grade content, and what you would do about it in the first month. | A persona stem. The stated gap is the honest answer, and the ramp plan carries the weight. |
| A4 | VAL | "What draws you to fourth grade, specifically?" | [generic] no quoted sentence carries motivation; this is a selection scaffold | Say in your own words what draws you to this grade. If the reason is the reading work or the team, say so. If you have no specific reason yet, say so and say what you would want to learn. | "Why this, why now" is a standard skeptic probe. Your material does not show a motivation, so the answer is yours to supply. |

### Peer Evaluator (weight 4)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | VAL | "Our team plans together. Tell me about a time you disagreed with a colleague about a lesson or an assessment. How did it go?" | [generic] no quoted sentence carries a disagreement. Raising source: "two members of our fourth-grade team," from the invitation | Selection scaffold: pick a time you disagreed with a colleague about instruction. It needs a specific disagreement, what you did, and a working relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Peer disagreement probe. Your material has no such example, so the scaffold ends in an honest branch. |
| B2 | EXP | "Walk me through the reading curriculum move in 2024. What did you lead, and what did the rest of the grade do?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Story map from the quote. Beats: the move, the grade level, the year. Answer slot: say which parts of the move you led, in your own words. Where a part was not yours, say so plainly and stay with what you led. | A peer's credit-and-scope probe on your strongest quote. Covers F3. |
| B3 | EXP, VAL | "When a grade-level project goes well, how do you describe who did what?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Use "I" for what you did and "we" for team outcomes. Describe others' work only as far as you saw it. Do not name a contribution of someone else's that you did not see. | A credit-sharing probe, which is a peer stem. |
| B4 | VAL | "What would you need from the rest of the team in your first month?" | [generic] no quoted sentence carries this; a reciprocity question | Name specific help in your own words. Then say what you would bring to their planning, as a plan rather than a past. | Reciprocity framing, which peer evaluators weight heavily. |

### Prober (weight 3)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | EXP | "Tell me about the after-school reading club you've run for two years. How did it work?" | [grounded] "I've run the after-school reading club for the last two years" — your CV | Story map from the quote. Beats: the club, the two years. Answer slot: if you can give a figure (students, sessions, reading gains), name it and say how it was counted. If you cannot, say so. | The club is a headline line on your CV, so expect a count probe. Covers F5. |
| C2 | JD, EXP | "How would you know a reading curriculum was working in your classroom?" | [generic] no quoted sentence carries a measurement; a selection scaffold | Name what you would look at first and what would change your mind. Answer slot: if you tracked anything with the curriculum move, say what and how. If you did not, say so. | A prober's measurement probe, and the honest answer depends on what you did. |
| C3 | EXP | "What evidence would convince you the curriculum move was worth it?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Name the assumption behind any result you would cite, in your own words, before they ask. If you have no result, say so. | The weakest-assumption move. Your material has no result, so the honest answer is to say so. |

### Case / Strategist (weight 3)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | CASE, JD | "It's mid-October. Several of your fourth graders read well below grade level. What's your first two weeks?" | [generic] a live problem; it asks about no past and presupposes nothing about you | Clarify first: which skills are behind, what the assessment shows, what the current curriculum already provides. Then the objective, how you would group students by need, your approach, what you would measure, and the risks (time, family communication). Speakable in 90–120 seconds. | A live classroom problem, which the principal and team would use to test reasoning. Covers the grade-level JD expectation. |
| D2 | CASE, VAL | "Two members of a grade team disagree about keeping a reading curriculum. How do you move them forward?" | [generic] a live problem; the panel is from the fourth-grade team | Clarify what is in dispute. Hear both views. Name who makes the decision. Propose a test or review date. Do not claim a decision authority you do not have. | Tied to the team-lead gap in F4, asked as a problem rather than a history. |
| D3 | CASE, VAL | "A parent emails asking why their child's reading grade dropped this month. What do you send back?" | [grounded] "I write a weekly email to families" — your CV | State the facts you have, what you will check, and when they will hear back. Make no promises you cannot keep. Use the quote as the bridge: you already write to families each week. | A family-communication live problem tied to the weekly email. Covers F6. |

### Values / Behavioral (weight 2)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| V1 | VAL | "Tell me about a time you had to tell a family something hard." | [grounded] "I write a weekly email to families" — your CV | Pick a specific time a message had to carry hard news. Say what you wrote and how the family responded. If no such time comes to mind, say so plainly, then give the weekly email as the nearest thing your material carries, and how you would handle a hard message. | An open prompt about family communication. Your material has no specific example, so the honest branch matters. |
| V2 | VAL | "Tell me about a time you disagreed with a decision from school leadership." | [generic] no quoted sentence carries this; a selection scaffold | Pick a decision you disagreed with, then what you did and how the relationship held. If no such time comes to mind, say so plainly, then say how you would raise a disagreement with a principal. | A standard values probe for a principal. Your material has no example, so the scaffold ends in an honest branch. |

### Pressure (weight 2)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| E1 | JD | "Sixty seconds: why should we hire someone who has never taught fourth grade?" | [grounded] "I've never taught fourth grade" — your CV | Pause. Restate: "I haven't taught fourth grade." Hold on the position your material carries: six years of third grade. On two follow-ups, do not fold. Then concede one specific point: name the fourth-grade skill you would need to learn first, and how. | The grade change asked as a stress question. Hold, then concede specifically. |
| E2 | EXP | "That reading curriculum move: how much of it was actually you?" | [grounded] "I led our grade level's move to a new reading curriculum in 2024" — your CV | Hold at the quote's scope: "I led the move." Concede what is specific: name any part of the move that was not yours, in your own words. Do not add a credit you did not have. | A credit-and-scope challenge on your strongest quote. Hold then concede. |

### Conversational (weight 2)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| G1 | VAL, EXP | "So, walk me through your path into teaching." | [grounded] "Six years teaching third grade at a public elementary school in Joliet" — your CV; [grounded] "I've run the after-school reading club for the last two years" — your CV | A 90-second arc, built from your quotes: the license, six years of third grade, the reading curriculum move, the reading club, the weekly family email, then what draws you to this grade (an answer slot, as A4). | A casual opener that is still scored. Pre-built so it does not sprawl. |
| G2 | JD | "What part of teaching do you enjoy most?" | [generic] no quoted sentence carries this; a selection scaffold | Say it in one sentence, then give one example from your material. If the example is the reading club, say what it is. | An easy-sounding question that tests whether you can be concise and specific. |

### Requirement coverage

| Requirement (source) | Question IDs |
|---|---|
| Valid Illinois PEL with an elementary endorsement (invitation) | None, and why: the material shows it met (F1). Status check is in the upgrade menu. |
| Fourth Grade Teacher position (invitation title) | A1, A3, A4, D1 |
| Two members of our fourth-grade team (invitation, panel) | B1, B2, B4, D2 |
| Grade-team leadership (not in the invitation; [generic]) | A2, D2 |

## Reverse questions

Each has a "why it lands." No interviewer profile was supplied, so none is tied to a career path. One is a peer reciprocity question.

1. **"What does the fourth-grade team's planning look like week to week?"** Shows you want to understand how the team works before you propose anything.
2. **"Which parts of the reading curriculum does the team use most, and where do they struggle with it?"** Ties to F3 and shows you know the curriculum is the live issue.
3. **"What would a strong first semester look like for this role, in your view?"** Lets the principal define success, which you can then match.
4. **"How does the school support teachers who are new to a grade?"** Lands on the transferability gap (F2) and asks for the support you would need.
5. **"What could a new person do in their first month that would genuinely help your team?"** Peer reciprocity. It turns the question back to what you bring.
6. **"What is the most important thing you want from the person you hire?"** Gives the principal a chance to name the criterion, so you can answer it directly.

## Sources

- **Provided documents:** the invitation from the Human Resources office, and your resume ("your CV"). Your note also named the panel.
- **Research:** none run. Research tier L0. No search or fetch was made, so the school's values, strategy, loop structure, and the panel's public profiles are not in this pack.
- **Target accounting:**
  - Company values: skipped (L0).
  - Loop structure: skipped (L0).
  - Current school strategy: skipped (L0).
  - Interviewer public footprint: skipped (L0).
  - Representative job posting: skipped (L0).
- **Dropped sections:** prep triage (prep time not stated), graded deliverables (none declared), grounding brief (L0), reading the interviewer (no profile), values cheat sheet (no published values in hand), delivery coaching (no assessment provided).

## Upgrade menu

- The full job posting text → requirement rows beyond the license become `[grounded]`, and the coverage table gets the real requirements.
- What HR said the panel will focus on, or any demo lesson or portfolio asked for → a graded-deliverable section, and the persona weights shift.
- The panel members' names → a per-member interviewer read and a tailored reverse question. The principal's name alone lets research find her public profile.
- Research at L1 (say yes) → school-specific context, any published values, and loop structure.
- Your own answers to the answer slots (A4, G2, C1) → quoted into the fit snapshot, which upgrades the rows that draw on them.
