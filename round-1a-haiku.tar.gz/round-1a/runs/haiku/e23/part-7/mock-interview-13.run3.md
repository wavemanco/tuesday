Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-e23-part-7-rooms-case-13-denied-4df4c7b9/db5c3a28-7c68-4d8b-98bb-fb6c523651e4/scratchpad/quillmoor_operations_coordinator_interview_pack.md`. It's built from the advert and your notes only. I didn't run web research, so nothing about Quillmoor's values, strategy or team is checked.

**The four items Hannah asked about**

- **Salary:** Say the number first: "I'm hoping for £42,000." If she pushes for flexibility, ask what the range for this role is. Don't name a floor.
- **Notice period:** Not in your notes. Say it as a number. I need it for the pack.
- **Hybrid:** "Two days at Avonmouth works from north Bristol. I'd want to keep it to two, three at most."
- **Reason for moving:** "Our Bristol office is closing next year. The only offer is relocating to Reading, which I don't want to do." Keep it factual, with no criticism of the employer.

**The two gaps to be ready for**

- **SAP:** "I haven't used SAP. We ran our own in-house stock system." Then stop, or add a learning plan clearly framed as a plan. Don't imply SAP experience.
- **Production planning, warehouse and QA:** Your background is deliveries and supplier chasing. If she raises planning or QA, answer honestly: say how you coordinated with those teams if you did, or say plainly that you didn't and describe how your depot scheduling links to the warehouse. Don't claim planning work. This is the likeliest objection, so practise it until the honest answer sounds calm.

**Other things she may probe**

- **The "about a third" stock-count figure:** Be ready to say what you counted, over what period, and what the drop was sensitive to. Name the assumption you'd defend least, and which part was yours. Don't explain a method you can't repeat.
- **Weekly on-time dispatch reporting:** Your material doesn't show this. Say so, and say what you would track first.
- **Excel:** Name the features you actually used (formulas, lookups, pivots). If you used few, say that.

**Questions to ask Hannah**

1. What does a typical week look like, and who would I coordinate with most?
2. What's the on-time dispatch target, and where is it now?
3. Who would this role report to?
4. What's the timeline to a decision, and what happens next?
5. How long have you been recruiting for operations roles at Quillmoor?

**Before Thursday:** Have your notice period, the £42,000 figure and this pack open. Note her name and the next step before you hang up.

Two options, neither pushed:

- I can run a live drill on the planning/QA question (B1 in the pack), where I play Hannah and push back on your answer.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later sessions.

Could you tell me your notice period? It goes into the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations_coordinator_interview_pack.md -----
# Quillmoor Diagnostics — Operations Coordinator — recruiter screen prep

Recruiter: Hannah Lowther (Talent Partner). Thursday 2pm, 30-minute phone call, on the mobile number on your application.

**Scope:** built from the advert, your notes and Hannah's message. No web research was run (tier L0), so nothing here about Quillmoor's values, strategy or team is checked. Those questions stay generic.

## How to use

Personas = how it's asked. Types = what's scored (JD = the advert's requirements; EXP = what you actually did). Guidance is scaffolding for a spoken answer, not a script.

## Prep triage (30 minutes)

1. Salary number and notice period: say them in plain words.
2. Hybrid pattern.
3. Reason for moving.
4. The two gaps: SAP, and production planning / QA.
5. Your questions for Hannah.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | [grounded] | none | Meets it. Say it in those terms. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Delivery scheduling is adjacent work, not production planning or QA. Say what you scheduled and for whom. Answer slot: if you coordinated with planning or QA, say how; if not, say so. |
| F3 | "track supplier deliveries and chase late orders" — advert | "I chase suppliers when orders slip" — your message | high | [grounded] | none | Meets it in your own words. |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | A figure. Expect a probe on how it was counted (see B2). |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show dispatch reporting. Answer slot: if you have reported delivery timing to anyone, say what and how often; if not, say so and say what you would track first. |
| F6 | "ERP (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A stated gap. Words: "I haven't used SAP. We ran our own in-house stock system." Then a learning plan, said as a plan, never as past experience. |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | medium | [inferred] | discovery | Rebuilding a spreadsheet touches Excel without showing how deep you went. Answer slot: name the features you used (formulas, lookups, pivots); if you used few, say so. |

## Prohibited (not to be coached)

| Not coached | Basis | Honest form |
|---|---|---|
| Ran production scheduling | Inflated form of F2 | F2's quote at its own scope: deliveries for three depots. |
| Used SAP | Stated negative (F6) | "I haven't used SAP." |
| Reported on-time dispatch | Not in your material; silence is an answer slot, not a claim | Answer slot only (F5). |

## Persona weights

Recruiter screen → Conversational (lead, 4 questions) + light Skeptic (2 questions). Hannah's own agenda is salary, notice, hybrid and motivation, so those carry most of the call.

## Question banks

### A — Conversational (recruiter register)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me a bit about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots" | 60–90 seconds: four years, three depots, the delivery schedule, chasing suppliers when orders slip, and the stock-count rebuild. Stop there. | F1 and F3 are the first things she checks. |
| A2 | "What are you looking for in salary?" | JD | [grounded] advert: "£38,000–£44,000" | Say the number first: "I'm hoping for £42,000." If pressed for flexibility, ask what the range for this role is. Don't name a floor. | First item on her agenda. |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] advert: "two days a week at our Avonmouth site in Bristol"; your message: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | "Two days at Avonmouth works from north Bristol. I'd want to keep it to two, three at most." | Her agenda item. Keep it to the facts. |
| A4 | "What's prompting the move?" | JD | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | "Our Bristol office is closing next year. The only offer is relocating to Reading, which I don't want to do." No criticism of the employer. | A motivation check. No single type fits cleanly, so it's JD-adjacent. |
| A5 | "Do you have ERP experience, such as SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | "I haven't used SAP. We ran our own in-house stock system." Then stop, or add a learning plan clearly framed as a plan. | F6. Say the no first. |

### B — Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers production planning, the warehouse and QA. Your background is deliveries and suppliers — what's your experience there?" | JD | [grounded] "I schedule deliveries for our three depots"; "I chase suppliers when orders slip" | **Highest-ROI prep.** Answer slot: if you coordinated with planning, the warehouse or QA, say how, in your own words. If not, say so plainly, then describe how your depot scheduling links to the warehouse. Hold this position through one follow-up; do not claim planning work. | F2 is the largest gap and the likeliest objection. Rehearse until the honest answer is boring and calm. |
| B2 | "How was that stock-count figure measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what you counted, over what period, and what it was sensitive to. Answer slot: name the assumption you would defend least, and which part was yours. Don't explain a method you can't repeat. | F4. The figure is the magnet for a probe. |
| B3 | "Have you reported on on-time dispatch?" | JD | [grounded] advert: "report weekly on on-time dispatch" | Answer slot (F5): if you have reported delivery timing, say what and how often; if not, say so and say what you would track first. | F5 gap. Answer it straight. |
| B4 | "How comfortable are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet" | Name the features you used. Answer slot: if you used formulas, lookups or pivots, name them; if you used few, say so. | F7. Don't say "advanced" unless you can show it. |

Requirement coverage: 2+ years → A1; planning / warehouse / QA → B1; supplier chasing → A1; stock records → B2; weekly dispatch → B3; Excel → B4; SAP → A5; salary → A2; hybrid → A3.

## Reverse questions (for you to ask Hannah)

1. "What does a typical week look like, and who would I be coordinating with most?" — shows you're thinking about the job itself.
2. "What's the on-time dispatch target, and where is it now?" — a concrete figure that shows you care about the reporting duty.
3. "Who would this role report to?" — checks the reporting line.
4. "What's the timeline from here to a decision, and what happens next?" — closes the call with next steps.
5. "How long have you been recruiting for operations roles at Quillmoor?" — ties to her path, not to a profile.

## Call checklist

- Phone charged, quiet room, mobile number on your application answered.
- Your CV and this pack open.
- Your notice period stated as a number.
- Salary: "£42,000" said once, then stop.
- Note her name and the next step before you hang up.
- Message her on LinkedIn to confirm anything she says that changes.

## Upgrade menu

- Your notice period → fills the placeholder for the notice question.
- Quillmoor research at L1 (values, recent news) → a "why Quillmoor" answer grounded in their own words.
- The full job advert with team size → tighter reverse questions.
