I've saved the full pack to `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-e23-part-7-rooms-case-13-denied-50eeb801/31d380cd-e98a-4cd5-b8fd-35eae811feef/scratchpad/quillmoor-screen-prep.md`. It's built from the advert and your notes only; I didn't run any company research, so I don't know Quillmoor's values, team or process.

# Recruiter screen prep: Quillmoor Diagnostics, Operations Coordinator

**Call:** Thursday 2pm, 30 minutes, by phone to your mobile, with Hannah Lowther (Talent Partner).

## Fit snapshot

| Requirement (advert) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" | High | None | Met. State it plainly. |
| Track supplier deliveries and chase late orders | "I schedule deliveries for our three depots and chase suppliers when orders slip." | High | None | Direct match. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | High | None | Strongest proof point. Confirm what "rebuilt" covered and who else contributed. |
| Coordinate production schedules across planning, warehouse and QA | "I schedule deliveries for our three depots" | Medium | Domain | Bridge: "My scheduling covered three sites. Production planning and QA are new to me, and that's what I'd want to learn." |
| Report weekly on on-time dispatch | Not in the material | Low | Evidence gap | Answer slot: have you reported on delivery performance? |
| Confident with Excel | "I rebuilt our stock-count spreadsheet" | Medium | Unverified level | Shows build work, not a skill level. Answer slot: which functions you use. |
| ERP (SAP or similar), a plus | "Never used SAP. We run our own in-house stock system." | Low | Tool gap | Describe what the in-house system does. Don't claim ERP experience. |

## Prohibited claims (binding on every answer)

- Any SAP or ERP experience.
- Production planning or QA involvement.
- On-time dispatch reporting, unless you did it.
- A stated Excel level such as "advanced".
- The one-third reduction as yours alone, unless you confirm it.
- Any notice period or current salary. You supply both.

## Likely questions and guidance

**Q1. Salary.** Give £42,000 as your target, then ask where the band sits. Don't reveal a floor. The advert's £38,000–£44,000 puts £42,000 in the upper half.
Suggested: "I'm hoping for around £42,000. Could you tell me where the range sits for this role?"

**Q2. Notice period.** Give your actual notice period. Don't guess. Mention any effect from the office closure on your start date only if it's true.

**Q3. Two days at Avonmouth.** Two days works from north Bristol. State three days as your limit, plainly. Check your real commute to Avonmouth before Thursday.

**Q4. What's prompting the move?** Keep it factual and don't criticise the employer. "Our Bristol office is closing next year, and the only option is relocating to Reading, which doesn't work for me. I'd rather build on the coordination work I've done here in Bristol."

**Q5. ERP experience?** Say no, then describe the in-house system: what it does and what you entered or tracked. Don't say you're learning SAP unless it's true.

**Q6. Fit with planning, warehouse and QA?** Lead with three-site scheduling and supplier chasing. Acknowledge the production and QA gap in one sentence.

**Q7. Improving accuracy.** Use the stock-count rebuild and the one-third reduction. Say what you did and what others did, and use the figure exactly as stated.

## Plan for the call

- **Before 2pm:** have your notice period, current salary, commute time, the £42,000 target, a one-line reason for moving, and the stock-count story in about 60 seconds.
- **Setup:** be somewhere quiet, with the phone charged and the advert open.
- **Order:** follow her agenda: salary, notice, hybrid, reason for moving, then the team and next steps.
- **Close:** ask about the timeline and the next step.
- **After:** if anything changes, message her on LinkedIn, as she asked.

## Reverse questions for Hannah

1. "How is on-time dispatch measured today, and where do misses usually come from?"
2. "How do planning, the warehouse and QA share the production schedule?"
3. "Which system does the team use for stock and orders?"
4. "Are the Avonmouth days fixed, or can they move?"
5. "What's the timeline after this call?"

## Upgrade menu

- **Notice period and current salary:** sharpens the notice answer and salary positioning.
- **Excel detail (lookups, pivots, formulas):** turns the Excel row into a claim you can make.
- **Any process details Hannah gave (interviews, a test):** covers the team and next-steps part of the call.
- **Company research:** values and recent news would sharpen the team discussion.
- **Hiring manager's name, if you have one:** adds an interviewer read for later rounds.

---

I can run a live drill on the salary or reason-for-moving questions, with me playing Hannah.
I can also save a `tuesday-dossier.md` with this pack's feedback, if you're using the job-underwriter flow.

**Questions for you:**
1. What's your notice period, and what's your current salary?
2. Beyond building the stock-count spreadsheet, what Excel do you use: lookups, pivots, formulas?
3. Did Hannah mention any steps after this call, such as interviews or a test?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-screen-prep.md -----
# Recruiter screen prep: Quillmoor Diagnostics, Operations Coordinator

**Call:** Thursday 2pm, 30 minutes, by phone to your mobile, with Hannah Lowther (Talent Partner).
**Built from:** the advert and Sam's notes only. No company research was run, so Quillmoor's values, team and process are unknown.

## Fit snapshot

| Requirement (advert) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" | High | None | Met. State it plainly. |
| Track supplier deliveries and chase late orders | "I schedule deliveries for our three depots and chase suppliers when orders slip." | High | None | Direct match. |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | High | None | Strongest proof point. Confirm what "rebuilt" covered and who else contributed. |
| Coordinate production schedules across planning, warehouse and QA | "I schedule deliveries for our three depots" | Medium | Domain | Adjacent. Multi-site scheduling is shown; production planning and QA are not. Bridge: "My scheduling covered three sites. Production planning and QA are new to me, and that's what I'd want to learn." |
| Report weekly on on-time dispatch | Not in the material | Low | Evidence gap | Answer slot: have you reported on delivery performance? If yes, describe it. If no, say you would build it. |
| Confident with Excel | "I rebuilt our stock-count spreadsheet" | Medium | Unverified level | Shows spreadsheet build work, not a skill level. Answer slot: which functions you use (lookups, pivots, formulas). |
| ERP (SAP or similar), a plus | "Never used SAP. We run our own in-house stock system." | Low | Tool gap | Bridge: describe what the in-house system does and what you tracked in it. Do not claim ERP experience. |

## Prohibited claims (local, binding on every answer)

- Any SAP or ERP experience.
- Production planning or QA involvement.
- On-time dispatch reporting, unless Sam did it.
- A stated Excel level such as "advanced" or "expert".
- The one-third reduction as Sam's alone, unless Sam confirms it.
- Any notice period or current salary. Neither is in the material; Sam supplies both.

## Likely questions and guidance

**Q1. Salary expectations.** *Type: compensation.* *Provenance: Sam's stated target.*
Guidance: Give £42,000 as your target, then ask where the band sits. Do not reveal a floor. The advert publishes £38,000 to £44,000, so £42,000 is in the upper half; you do not need to justify it at length.
Suggested answer: "I'm hoping for around £42,000. Could you tell me where the range sits for this role?"

**Q2. Notice period.** *Type: availability.* *Provenance: answer slot.*
Guidance: Give the actual notice period. Do not guess. If your office closure affects your start date, mention it only if it is true.

**Q3. Two days at Avonmouth.** *Type: logistics.* *Provenance: Sam's stated position.*
Guidance: Say two days works from north Bristol. State three days as your limit, plainly and without apology. Check your real commute to Avonmouth before the call (answer slot).

**Q4. What's prompting the move?** *Type: motivation.* *Provenance: Sam's quoted sentences.*
Guidance: Keep it factual and do not criticise the employer. "Our Bristol office is closing next year, and the only option is relocating to Reading, which doesn't work for me. I'd rather build on the coordination work I've done here in Bristol."

**Q5. Do you have ERP experience?** *Type: skill gap.* *Provenance: Sam's quoted sentence.*
Guidance: Say no, then describe the in-house system. Answer slot: what the system does and what you entered or tracked in it. Do not say you are learning SAP unless that is true.

**Q6. How does your experience fit planning, warehouse and QA?** *Type: fit.* *Provenance: Sam's quoted sentence.*
Guidance: Lead with three-site scheduling and supplier chasing. Acknowledge the production and QA gap in one sentence and name what you would want to learn.

**Q7. Tell me about improving accuracy.** *Type: experience.* *Provenance: Sam's quoted sentence.*
Guidance: Use the stock-count rebuild and the one-third reduction over a year. Say what you did yourself and what others did, and use the figure exactly as stated.

## Plan for the call

- **Before 2pm:** have your notice period, current salary, commute time, the £42,000 target, a one-line reason for moving, and the stock-count story in about 60 seconds.
- **Setup:** be somewhere quiet with your mobile charged. Keep the advert open.
- **Open:** "Thanks Hannah, happy to answer your questions."
- **Order:** follow her agenda: salary, notice, hybrid, reason for moving, then the team and next steps.
- **Close:** ask about the timeline and the next step.
- **After:** if anything changes, message her on LinkedIn, as she asked.

## Reverse questions for Hannah

1. "How is on-time dispatch measured today, and where do misses usually come from?" Shows you think about the reporting duty.
2. "How do planning, the warehouse and QA share the production schedule?" Tests how cross-functional the role is.
3. "Which system does the team use for stock and orders?" Surfaces the ERP situation before interview.
4. "Are the Avonmouth days fixed, or can they move?" Gets concrete on the hybrid pattern.
5. "What is the timeline after this call?" Confirms next steps.

## Upgrade menu

- **Notice period and current salary:** sharpens Q2 and salary positioning.
- **Excel detail (lookups, pivots, formulas):** turns the Excel row from a gap into a claim you can make.
- **Any process details Hannah gave (interviews, a test):** covers the team and next-steps part of the call.
- **Company research (default depth):** company values and recent news would sharpen the team discussion.
- **Hiring manager's name, if you have one:** adds an interviewer read for later rounds.
