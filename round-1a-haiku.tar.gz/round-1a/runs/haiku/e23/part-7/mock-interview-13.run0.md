Web search was refused in this session, so the pack will rest on your advert, your background and Hannah's message. I'll write the pack to the scratchpad.
Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a-runs-haiku-e23-part-7-rooms-case-13-denied-76d4fb58/d3542519-ded5-41a6-bed7-73f8f141be65/scratchpad/quillmoor_operations-coordinator_interview_pack.md`. I built it for a recruiter screen, since Hannah's message gave the format. Web search was refused in this session, so it uses only the advert, your background and her message.

Three things to do before Thursday:

- **Fill in your notice period.** It isn't in what you gave me, so the pack leaves a blank for it (A3).
- **Rehearse the production-planning answer (B1).** This is the highest-return prep. The advert's first line is production planning, the warehouse and QA, and your material covers deliveries. Hold the deliveries line through two follow-ups.
- **Prepare the SAP and figure answers (B2, C1).** Say "Never used SAP" plainly, and be ready to explain how the one-third discrepancy figure was counted.

The pack also has the salary answer, the hybrid answer (two days is fine, three is the limit), a reason-for-leaving answer that stays factual, a phone checklist and six questions to ask Hannah.

Would you like me to run a drill on B1 before Thursday? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Quillmoor Diagnostics — Operations Coordinator — Recruiter screen prep

**Call:** 30 minutes by phone, Thursday 2pm, with Hannah Lowther (Talent Partner). She will ring the mobile number on your application.
**She said she will cover:** salary expectations, notice period, how the hybrid pattern works, what's prompting the move, then the team and next steps.
**Built on:** the advert, your background as you described it, and Hannah's message. No CV text was supplied, so every quote about your past is attributed to "your message". Web search was refused in this session, so nothing about Quillmoor beyond the advert is included.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| EXP | Your past work, tested for what you actually did |
| JD | The advert's requirements, and the logistics she will screen |
| CASE | A live problem from the role; no claim about your past |

Guidance is scaffolding, not a script. Say things in your own words, and only what the quoted sentence in each row supports.

## Prep triage

Prioritised for a 30-minute screen:

1. **Fill in your notice period** (A3). It is not in your material, and she will ask. Your notice period is ______.
2. **Say the salary answer aloud** (A2, D1): one sentence, the same words each time.
3. **Rehearse B1 — the highest-ROI prep in this pack.** The advert's first line is production planning, the warehouse and QA. Your material covers deliveries. Hold the deliveries line through two follow-ups.
4. **Rehearse B2 and C1:** the SAP gap, and the one-third discrepancy figure.
5. **Rehearse A4 and A5:** the hybrid pattern and the closure, both short.
6. **Pick three reverse questions** from the list at the end.

Everything else is insurance.

**Phone checklist:** answer on the mobile number from your application; sit somewhere quiet; have the advert, this pack and any CV open; keep a pen by you; if she gives a figure, repeat it back before you answer; if she asks something this pack does not cover, answer from your own experience and say plainly where it ends.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Lead with the four years in those words. |
| F2 | "coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots. It does not mention production schedules, planning or QA. Bridge: "I schedule deliveries for our three depots." Answer slot: if you coordinated anything beyond deliveries, say what and how you decided. If none of it was yours, say so plainly and stay with the deliveries. |
| F3 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | Reaches the requirement directly. Lead with "chase suppliers when orders slip." |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Reaches the requirement. The figure carries a verification caveat: your material does not show how it was counted. Expect a probe; see C1. |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Answer slot: if you reported on dispatch, say what you reported and how often. If no such report was yours, say so plainly and say what you would track first. |
| F6 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | Plain acknowledgment from your own words: "Never used SAP." The in-house system is adjacent work, not an ERP match. Limit, as the pack's observation: your material does not say what the in-house system covers. |
| F7 | "confident with Excel" — advert | none given (the spreadsheet in F4 is not named as Excel) | none | [grounded] | discovery | Answer slot: if you use Excel, say where and what for. If you use another spreadsheet tool, name it. If you have not used Excel, say so plainly and say how you would build that skill. |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your target sits inside the advert's band. |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The pattern matches your stated limit. The location and schedule terms are met by your own statement. |

Not in the table: your notice period. Your material does not contain it, so this pack does not supply one.

## The prohibited list

Claims this pack will not coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| "Set production schedules" | Inflated form of F2: the advert's wording, not your sentence | F2 at its own scope: "I schedule deliveries for our three depots." Limit, as the pack's observation: your material says deliveries, not production schedules. |
| "I have SAP experience" or "I've used an ERP" | Negative you stated (F6) | "Never used SAP." Then what you do have: "we run our own in-house stock system." |
| "The discrepancies fell because of me alone" | Inflated form of F4: sole credit and cause | F4's quote at its own scope. Limit, as the pack's observation: your material does not say who else worked on the count, or how it was measured. |
| "Happy to work three days" | Sourced entry: contradicts your stated limit (F9) | "Two days at Avonmouth is fine, but I wouldn't want more than three." |

## Persona table

| Persona | How it shows up in this screen | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Opener, background, the notice and salary questions | High. A recruiter screen's prior is friendly and logistics-led, and the questions are still scored | 90-second arcs; treat casual questions as scored |
| Skeptic | The production-planning gap (F2) and the SAP gap (F6); "why now" | High. Both gaps are in the advert, so a recruiter checking fit will see them | Hold the deliveries line; state the SAP gap plainly |
| Pressure | Salary pushed down; three days pushed up | Medium. A light prior for this round, so only a few questions | Hold the stated figure and limit; concede only what you have decided |
| Data-Driven Prober | The one-third figure and its attribution | Medium. The CV line is your headline metric | Defend the number: how it was counted, the weakest assumption you know, which part was yours |
| Case / Strategist | Live supplier and QA problems | Low to medium. Screens rarely use cases, but the advert's duties are operational | Clarify, then structure |

Session total: 17 questions. That is one under the 18 floor, because a 30-minute recruiter screen is logistics-led; the bank is sized to that.

## Question banks

### A — Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story map on F1 and F3: the four years, the wholesaler, the three depots, the supplier chasing, in those words and that order. End on the quote from F4: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material has no account of how you got into logistics, so if she asks, answer in your own words. | Opening question of the screen, scored for fit. F1 and F3 supply the beats; F4 closes it. |
| A2 | "What are you hoping to earn?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure as you wrote it: "I'm hoping for £42,000." Then stop. Do not add a range or a floor; your material gives a target only. Answer slot: if she offers a figure below your target, say what you would need to see before you answer, in your own words. | F8: the advert's band covers your target, so this is a check, not a gap. A short, clear number lands better than a hedge. |
| A3 | "What's your notice period?" | JD | [generic] screening pattern. Your notice period is not in your material. | Your notice period is ______. Fill this in before Thursday. State the number and whether it is contractual. If you are not sure, say so and say when you will confirm. | A timing check for the logistics screen. The figure is left blank on purpose: this pack has no source for it. |
| A4 | "How do you feel about two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Two days first: "Two days at Avonmouth is fine." Then the limit: "Three is the most I'd do." Answer slot: if she explains which days the team uses, say what you were told. If she has not said, ask her (see reverse questions). | F9: the advert's pattern matches your constraint. The three-day ceiling is the one part she may test. |
| A5 | "What's prompting the move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the closure and the Reading offer in those words, briefly and without criticism. Then one sentence on what you want next, in your own words. Your material does not say what draws you to this role, so that sentence is yours to write. | Motivation is one of her stated topics. Kept short and factual, the reason is positive. The answer slot is the honest form: the material gives no "why this role". |

### B — Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is building supplies, and this is diagnostics manufacturing. Where has your work touched production planning, the warehouse or QA?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots" | Lead with the deliveries, in your words: "I schedule deliveries for our three depots." Answer slot: if you coordinated anything beyond deliveries (planning, the warehouse or QA), say what and how you decided. If none of it was yours, say so plainly, then say what carries across: scheduling deliveries for three depots. Hold the deliveries line through two follow-ups. | F2: the highest-ROI rehearsal in this pack. The advert's first line names planning, the warehouse and QA, so this objection is likely in some form. The most likely failure is stretching deliveries into production scheduling under the second follow-up. |
| B2 | "You've never used SAP. Why would this work?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | "I've never used SAP. We run our own in-house stock system." Answer slot: if you have used any other ERP or planning system, name it and what you did in it. If you have not, say so, and say how you would learn SAP, as a plan and not as a past. Do not argue that the in-house system is the same thing. | F6: ERP is "a plus", so this is not a knockout, but recruiters screen on it. It is the second most predictable objection. |
| B3 | "The advert asks for a weekly on-time dispatch report. What have you reported on?" | JD | [grounded] advert: "report weekly on on-time dispatch" | Answer slot: if you reported on dispatch, say what you reported and how often. If no such report was yours, say so plainly and say what you would track first. | F5: no quote reaches this requirement, so the pack supplies no reporting record. |
| B4 | "Why would you take a coordinator role at a manufacturer now, after four years at a wholesaler?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Use the closure as the reason and the role as the next step. Answer slot: if there is something in the advert that draws you, say it in your own words. Do not supply it. | Motivation consistency, the Skeptic's usual probe. Pairs with A5. |

### C — Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Defend-the-number slot: say what you counted and over what period, in your own words. Name the weakest assumption you know of. If you do not know how it was counted, say "I don't know how it was counted" plainly. Do not supply a method or a baseline. Answer slot: if you did the counting, say so; if someone else did, say who and what they did. | F4: the figure is yours; the method is not in your material. The weakest-assumption move converts a gotcha into a credibility point. |
| C2 | "You rebuilt the spreadsheet. Which parts were yours and which came from the team?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet" | Say which part you rebuilt, using the quote's own words. Answer slot: if others worked on it, name them and what they did. If you did it alone, say so. | An attribution probe on F4. The question presumes a team, so the second branch, that you did it alone, is the honest one. |
| C3 | "The advert wants confident Excel. Where have you used it?" | JD | [grounded] advert: "confident with Excel" | Answer slot: if you use Excel, say where and what for, in your own words. If you use another spreadsheet tool, name it. If you have not used Excel, say so plainly and say how you would build the skill. | F7: your material does not name Excel. Discovery, so the slot is the honest form. |

### D — Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "We're at the bottom of our band. Would you take £38,000?" | JD | [grounded] "I'm hoping for £42,000." | Hold the figure you gave: "I'm hoping for £42,000." If she pushes, do not name a new number unless you have decided one. Answer slot: if you want to think about a lower figure, say what you would need to see first, in your own words. | F8: the band covers your target. Hold-then-concede: hold the target, and concede only a decision you have actually made. |
| D2 | "Would you do three days if the team needed it?" | JD | [grounded] "I wouldn't want more than three." | Hold: "Two days at Avonmouth is fine. Three is the most I'd do." Do not add flexibility you have not stated. Hold through two follow-ups. | F9: the three-day ceiling is yours, and this tests it under pressure. |
| D3 | "Sixty seconds: why should we take you over someone who has SAP?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year."; "Never used SAP — we run our own in-house stock system." | Open prompt: answer with the rebuild and the figure, in those words. Do not argue against SAP experience. Answer slot: if you have a specific reason the in-house system's work would carry over, say it in your own words. | Time-boxed and comparative. The honest answer is what you did, not a claim of equivalence. |

### E — Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier says a delivery will be two weeks late. What do you do?" | CASE | [generic] role pattern; no claim about you | Structure: what the late order blocks, who needs to know today, what you ask the supplier for (a firm date, or a partial shipment), and what planning and the warehouse must change. | Raised by the advert's "track supplier deliveries and chase late orders". Pure role pattern. |
| E2 | "A QA hold blocks a batch planning needs on Thursday. How do you reschedule?" | CASE | [generic] role pattern; no claim about you | Clarify: how long the hold runs, who decides its release, what sits downstream. Then options, and what each costs. | Raised by the advert's "coordinate production schedules between planning, the warehouse and QA". Pure role pattern. |

### Requirement coverage

| Advert requirement | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, B1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, E2 |
| Track supplier deliveries and chase late orders | A1, E1 |
| Keep stock records accurate | C1, C2 |
| Weekly on-time dispatch reporting | B3 |
| Confident with Excel | C3 |
| ERP (SAP or similar), a plus | B2, D3 |
| £38,000–£44,000 | A2, D1 |
| Hybrid, two days at Avonmouth | A4, D2 |

## Reverse questions for Hannah

| Question | Why it lands |
|---|---|
| "What happens after this call, and who would I meet next?" | It asks about the next steps she has said she will cover, and shows you were listening. |
| "Is the two-day Avonmouth pattern set by the team, or by the role?" | It tests whether the pattern is fixed before you accept it. |
| "Which systems do planning, the warehouse and QA use to share schedules?" | It asks about the ERP question without apologising for the gap. |
| "What does on-time dispatch look like at the moment, and how is it reported?" | It asks about the weekly report directly, and shows you read the advert. |
| "Is this a new post or a replacement?" | It tells you whether the team is growing or turning over. |
| "Is the salary band fixed for the post, or is there room within it?" | It opens the pay conversation on terms you can use. |

## Sources

**Provided documents:** the advert (Operations Coordinator, Quillmoor Diagnostics); your background, as written in your message; Hannah Lowther's LinkedIn message confirming the call.

**Searches sent:** three, all refused by the host (WebSearch permission was not granted):
- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics Avonmouth operations careers": refused
- "Quillmoor Diagnostics interview process recruitment": refused

**Research tier:** L1 — searches 0 of 6, fetches 0 of 2

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor values | unavailable | Refused. Would have supplied a values cheat sheet, but no values-style round was detected, so section 10 is absent either way. |
| 2. Quillmoor interview process, operations | unavailable | Refused. Would have supplied loop structure. Hannah's message already fixes this screen's four topics. |
| 3. Quillmoor strategy / recent news | unavailable | No query sent: the host refused search. Would have grounded a company-strategy question; none is in this pack. |
| 4. Hannah Lowther, Quillmoor | unavailable | No query sent: the host refused search. Would have supplied an interviewer read; a recruiter's public footprint is a small gain. |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the requirement-tagged questions. |

## Upgrade menu

- **Your notice period** → fills A3, which is blank in this pack.
- **Your CV, as text** → the quotes move from "your message" to "your CV", and the grounding of F1 to F9 is stronger.
- **Anything about Quillmoor that drew you to it**, in your own words → a "why this company" answer, which this pack does not have.
- **The Quillmoor values page, pasted** → a values cheat sheet and a grounded "why Quillmoor" answer.
- **Hannah's prep email, if she sent one** → weights and coverage changed to match any focus areas she named.
- **Deep research (L2)**, if search is available → a strategy brief and company context, at a cost of six more searches and two more fetches.
