**Assumption:** I built this from the advert and your notes only. I didn't research Quillmoor, so the pack doesn't cite its values or recent news. The call is a recruiter screen with Hannah Lowther, so the priors favour logistics, pay and fit over technical depth.

## Fit snapshot

| Requirement (advert) | Your evidence (quoted) | Confidence | Gap type | Gap-and-bridge language |
|---|---|---|---|---|
| 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" | Strong | None | — |
| Track supplier deliveries, chase late orders | "I chase suppliers when orders slip" | Strong | None | — |
| Keep stock records accurate | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Strong | None | — |
| Coordinate production schedules across planning, warehouse and QA | "I schedule deliveries for our three depots" | Partial | Adjacent: delivery scheduling, not production | "My scheduling has been deliveries across three depots rather than production lines, so I'd be learning the production side." |
| Weekly on-time dispatch reporting | Not stated in your notes | Unknown | Unverified | Confirm before the call whether you've reported on dispatch performance. |
| Confident with Excel | "I rebuilt our stock-count spreadsheet" | Partial | Level not stated | Describe what you built, not a skill rating. |
| ERP (SAP or similar), a plus | "Never used SAP — we run our own in-house stock system." | None for SAP | Missing, nice-to-have | "I haven't used SAP, but I've worked with our in-house stock system and I'd be keen to learn an ERP." |
| Salary £38,000–£44,000 | Your target: £42,000 | Within range | None | — |
| Hybrid, 2 days at Avonmouth | "two days at Avonmouth is fine, but I wouldn't want more than three" | Yes | None | — |

## Prohibited claims (this pack won't coach these)

- Any production-scheduling or planning experience.
- Any SAP or ERP experience.
- A dispatch-reporting figure you haven't got.
- That the stock-count improvement was yours alone. "I rebuilt" is accurate; a sole-credit claim isn't in your notes.
- Any criticism of your current employer or Quillmoor.

## Answers for the screen

**Salary.** Ask for their range first: "What's the budget for this role?" If they press for your number: "I'm targeting around £42,000, which sits within the range in the advert. I'd also consider the full package." Don't go below £42,000 on the call.

**Notice period.** Answer with the number: "My notice period is [X weeks]." I need that figure to finish this answer (see the questions below).

**Hybrid.** "Two days at Avonmouth works for me. I'm in north Bristol, so it's manageable. I'd want to keep it to no more than three days a week." Don't quote a journey time you haven't measured.

**Reason for moving.** "Our Bristol office is closing next year, and the only option offered is relocating to Reading. I'd rather stay in Bristol, and this role matches the coordination work I already do." Keep it factual. Don't add "only offer" as a complaint.

**SAP gap.** Use the gap-and-bridge line above. Don't say you'll "pick it up quickly".

**Production gap.** Use the gap-and-bridge line above, and don't expand it.

## Questions to ask Hannah

1. What salary range has been budgeted for this role?
2. Who would I report to, and how is the team structured?
3. Which systems would I use day to day?
4. What are the next steps and rough timing after this call?

## Upgrade menu

- **Notice period length** (you haven't given it): I can finish the notice answer.
- **Dispatch reporting experience:** if you've done it, I can add a sourced line to the fit snapshot.
- **Company research (L1):** I didn't search Quillmoor. A search would add their published values and any recent news to the pack, at a modest cost.
- **Full job-underwriter dossier:** would add verified evidence grades and a constraint list.

**Offers (neither pushed):** I can run a live drill on the salary and move-reason answers, and I can write a `tuesday-dossier.md` from this pack if you want to keep it.

## Questions for you

1. What is your notice period, in weeks?
2. Are you currently on a salary figure that Hannah is likely to ask about? If so, what is it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.