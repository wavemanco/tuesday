# Quillmoor Diagnostics — Operations Coordinator — recruiter screen prep

Recruiter screen with Hannah Lowther, Talent Partner. Thursday 19 November, 2pm, 30 minutes by phone to the mobile number on your application. Candidate: Sam.

Built on your message, the advert as you pasted it, and Hannah's LinkedIn message. Web search was refused in this session, so nothing here comes from outside Quillmoor's own material. Anything about the company the pack does not have is absent, not guessed.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

- **VAL**: whether past behaviour shows a company's published values. None is in this pack, because no values source was read.
- **EXP**: whether what you did survives scrutiny, and whether you can say exactly what was yours.
- **JD**: whether you can do what the advert lists, including the gaps.
- **CO**: company and strategy knowledge. None is in this pack, because no research ran.
- **CASE**: a live problem from the role, reasoned aloud.

## Prep triage

Prep time is Tuesday 17 to Thursday 19 November.

1. Tonight: give me, or write down, your notice period and the earliest start date it implies. Bank D and row F10 wait on it.
2. Wednesday, 20 minutes: write your own answers to C1 and C2. How was the "about a third" counted, what is it sensitive to, which assumption would you defend least, and which part was yours. Only what you know.
3. Wednesday, 15 minutes: answer A4 and C3. What tool was the stock-count spreadsheet in, and what did you do in it.
4. Wednesday and Thursday morning: say B1 out loud, timed to 90 seconds, then answer its two follow-ups. This is the deepest rehearsal in the pack.
5. Thursday morning: A1 as a 90-second arc, then D1 and D2 once each.

Everything else is insurance.

## The fit snapshot

Requirements are quoted from the advert, and evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | Meets the requirement in role-relevant terms. Expect a probe on the four years, which A1 covers. |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | presentation | Your sentence already reaches this in other words: deliveries, and chasing suppliers when orders slip. Say it in those words. Do not add a tracking system, a late-order count or a supplier list that the sentence does not give. |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Covers the requirement. The figure is the likeliest probe target, so the defend-the-number questions in bank C apply to it, and only those. |
| F4 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | Excel is inferred from the spreadsheet line; your message never names the tool. Answer slot: say what tool the stock-count spreadsheet was in and what you did in it. If it was not Excel, say so plainly and name the tool. |
| F5 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | The in-house stock system is adjacent work, not an ERP, so do not call it one. The plain acknowledgment is your own negative: never used SAP. It is a plus in the advert, not a requirement. |
| F6 | "coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material shows delivery scheduling across three depots. It does not show production scheduling, planning or QA. Say the delivery work, and no more. Answer slot: if you have coordinated across any function other than deliveries, say which and how. |
| F7 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Answer slot: if you reported any delivery measure to a manager or team, say what it counted and how often. If you did not, say so plainly and describe what you did report. |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert (gate: location and schedule) | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own stated constraint matches the advert's pattern: two days, with three as your ceiling. Say both figures as you gave them. |
| F9 | "£38,000–£44,000" — advert (gate: pay) | "I'm hoping for £42,000." — your message | high | [grounded] | none | The figure sits inside the advert's range. It is a hope, not a floor, and the pack does not know your floor. Bank D handles that. |
| F10 | "your notice period" — Hannah's message (gate: schedule) | none given | none | [grounded] | hard_gate | Your material does not establish a notice period. Hannah has said she will ask, so the figure is needed before Thursday. The pack writes no words for it until you answer the question at the end of this message. |

Most of the Gap and bridge language above holds only what your quotes carry. Where the pack says your material does not show something, that is its own observation, not words for you to say.

## Persona table

Relationship priors for a recruiter screen are Conversational plus a light Skeptic (`references/personas.md`). No interviewer profile exists, and no loop source establishes more than this one call. So the loop is not established beyond it, and the weights below are a flat fallback for everything after this call. The mix is set for a 30-minute screen, not a panel.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Conversational / Rapport | Friendly openers, "walk me through", casual questions about the advert's topics | High. Hannah's message names salary, notice, hybrid and motivation as her agenda, in a warm register. The casual questions are still scored. | Pre-scripted 90-second arc for the biography question. Treat casual questions about Excel and the advert as scored. | 5 (A) |
| Skeptic | "Why leave?", "what would you be weakest at?", gap probes | High. A recruiter screen checks motivation consistency and knockout facts, and this advert has two plain gaps against your material: production and QA, and SAP. | Rehearse the most predictable objection until it is boring. Bridge from adjacent evidence you stated, and say the limit plainly. | 5 (B) |
| Data-Driven Prober | "How was that counted?", "which assumption?" | Medium. Recruiters rarely probe figures, but the one figure on your CV will be read. | Name the weakest assumption before they do, or say plainly you do not know how it was counted. | 3 (C) |
| Pressure / Stress | Pay pushback, "why should we pay this", time-boxed answers | Medium. Pay is the one topic Hannah will push on. | Hold the stated figure through two follow-ups. Concede only the specific point that is true. | 3 (D) |
| Case / Strategist | A short live scenario from the role | Low to medium. A 30-minute screen may include one scenario about late orders or stock accuracy. | Clarify, structure, then answer, thinking aloud. | 2 (E) |

Total: 18 questions. Top weights are Conversational and Skeptic. No values round is detected, so there is no values persona.

## Question banks

### A — Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through how you got into logistics coordination." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" — "I schedule deliveries for our three depots and chase suppliers when orders slip." | About 90 seconds: the four years at a building-supplies wholesaler, then the job as you do it. Schedule deliveries for three depots, and chase suppliers when orders slip. Stop there. Add no earlier roles, reasons or qualifications that you have not given me. | F1 and F2 are the material. The casual opener is scored for communication economy. |
| A2 | "What's prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Say the closure and the relocation offer as you put them, then stop. Keep "which I don't want" as your own preference. Do not speak about Reading or the company beyond that. | Hannah named this topic. The risk is over-explaining, and motivation is checked against the rest of your answers. |
| A3 | "The role is two days a week at Avonmouth. How does that sit with you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Two days is fine, and three is your ceiling. Say both figures. | F8 is a gate met on your own constraint. This is where Hannah's hybrid topic gets its answer. |
| A4 | "What are you playing with in Excel these days?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the tool the stock-count spreadsheet was in, and say what you did in it. If you did not use Excel, say so plainly and name the tool. | The casual phrasing presupposes Excel use that your quotes do not state, so the second branch allows that it was not Excel. "Confident with Excel" is a requirement, and it is scored here too. |
| A5 | "What would your last manager say you're best at?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Choose the rebuild if it is the thing you would name, and say what you did and what changed, in your own words. Do not quote a manager you have not heard from. | A casual strength question still asks for a claim, and the claim has to stay inside what you did. |

### B — Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our work is production: planning, the warehouse and QA. Your background is deliveries across three depots. What would be your weakest area on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." — "Never used SAP — we run our own in-house stock system." | Deepest rehearsal, and the highest-ROI prep in this pack. Say what you did, keeping the scope: deliveries across three depots. Name the gap plainly: production scheduling, QA and SAP are not in your material. Do not argue it away. Follow-up 1, "isn't scheduling scheduling?": hold with "scheduling deliveries is what I've done; production and QA aren't in it." Follow-up 2, "how would you learn SAP?": give a plan, not a past, and say the SAP point in the words of your "Never used SAP" line. Hold through two follow-ups before conceding anything more. | This is the objection most likely to come in some form. It is the advert's production line and the SAP plus, both set against a depot-delivery record (F5, F6). A non-defensive answer here changes the screen. |
| B2 | "I don't see production scheduling or QA in your background. How would you handle that here?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you have coordinated across production, planning or QA in any role, say where and how. If you have not, say so plainly, then describe how you would learn the production side. | The persona stem, aimed at F6. The premise is the interviewer's observation, and the second branch allows that you have no such experience. |
| B3 | "Four years is a long time in one kind of job. Why leave now?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Hold the stated reason: the office closes next year, and relocation is the only offer. Hold through two follow-ups by returning to that. Do not add a reason the material does not carry. | Skeptic motivation probe. Hannah's "what's prompting a move" makes this a recurring line. |
| B4 | "Hybrid sounds fine in theory. What would make you say no?" | JD | [grounded] "I wouldn't want more than three." | Name the ceiling: three days a week. Say what would break it, only if you know. Do not invent a commute time. | Tests whether F8, a gate met on your own constraint, holds under a hypothetical. |
| B5 | "Our managers get a weekly on-time dispatch report. Have you produced one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you reported any delivery measure, say what it counted and how often. If you did not, say so plainly and describe what you did report. | F7: the advert names weekly dispatch reporting, and no quote reaches it. Expect this probe, because the advert puts it in a sentence. |

### C — Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 'about a third' was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot, defend-the-number: say how you counted it, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Use your own words. If you did not count it that way, say so, and say what you can stand behind. | Every headline figure on your CV gets this. F3 is the line, and the figure is about a third, not a measured fall. |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: name the weakest assumption before they do. If you do not know how it was counted, say so plainly. | The weakest-assumption move, and the second follow-up to C1. |
| C3 | "What tool was that spreadsheet in, and what did you do in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: name the tool, and say what you did in it. If it was not Excel, say so plainly. | The Excel requirement, asked directly. F4 has no quote that names the tool. |

### D — Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pay £42,000 for someone who has never used SAP?" | JD | [grounded] "I'm hoping for £42,000." — "Never used SAP — we run our own in-house stock system." | Hold the figure: you are hoping for £42,000, which sits inside the advert's £38,000–£44,000. On SAP, concede the specific point in your own words, the way your "Never used SAP" line states it, and say what your experience does cover from your sentences. Hold through two follow-ups, and concede only the SAP point. | Pressure stem. The second quote is where the concession sits. |
| D2 | "What's the lowest you'd accept?" | JD | [grounded] "I'm hoping for £42,000." | Answer slot: if there is a figure below which you would not move, say it. If there is not, say what would move the number. Do not guess a floor. | Pay is a term, and your stated figure is a hope, not a floor. The answer belongs to you. |
| D3 | "What's your notice period, and how soon could you start?" | JD | [grounded] "your notice period" — Hannah's message | Answer slot: give your notice period and the earliest start it implies, as one figure, without rounding down. | This is a term of the offer, not a requirement, so it is tagged JD as the nearest type. It is the gate F10 is waiting on. |

### E — Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier's delivery is three days late and the warehouse shift depends on it. What do you do first?" | CASE | [generic] — the advert's "track supplier deliveries and chase late orders" is the raising source | Structure: confirm the order's status with the supplier today. Tell the warehouse and the planner what is now uncertain. Decide whether the shift changes. Then record it. Think aloud, and name your first two calls. | A live problem from the advert's late-orders line. It asks about no past, so it claims nothing about you. Labelled generic because it is a pattern, not a fact about this employer. |
| E2 | "How would you check a stock record is accurate before dispatch?" | CASE | [generic] — the advert's "keep stock records accurate" is the raising source | Structure: pick the records due out, count against them, reconcile the differences, and log which did not match and why. | A live problem from the advert's accuracy line. Generic structure only. |

## Requirement-coverage line

| JD requirement or term | Covered by |
|---|---|
| 2+ years in operations or logistics coordination | A1, F1 |
| track supplier deliveries and chase late orders | A1, E1, F2 |
| keep stock records accurate | C1, E2, F3 |
| report weekly on on-time dispatch | B5, F7 |
| coordinate production schedules between planning, the warehouse and QA | B1, B2, F6 |
| confident with Excel | A4, C3, F4 |
| ERP experience (SAP or similar) a plus | B1, F5 |
| £38,000–£44,000 | D1, D2, F9 |
| Hybrid: two days a week at Avonmouth | A3, B4, F8 |
| Notice period (Hannah's topic, not in the advert) | D3, F10 |

## Reverse questions

Hannah is a recruiter, so there is no interviewer profile and no peer reciprocity question. Each question below is role-generic.

1. "How do production, the warehouse and QA split scheduling decisions day to day?" Why it lands: it tests the production gap, and shows you read the advert.
2. "Which stock system does the team use day to day, and how are discrepancies handled?" Why it lands: it asks about SAP openly, and the answer tells you what you would be working in.
3. "What does the weekly on-time dispatch report look like, and who reads it?" Why it lands: it turns F7 into a question you can answer with real detail.
4. "Which two days are fixed for Avonmouth, and how are they set?" Why it lands: it checks the hybrid pattern you were told about.
5. "What does the next step after this call look like, and how long does it usually take?" Why it lands: Hannah said she would cover next steps, so this is the natural close.

## Prohibited claims

Built locally from the fit snapshot, since no dossier was supplied. Each entry names its basis, and the honest form is how the pack may still speak about that area.

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP, or ERP experience | Inflated form of F5: "in-house stock system" widened to ERP, and your own negative | "Never used SAP — we run our own in-house stock system." Plain acknowledgment: never used SAP. No ERP claim. |
| Coordinated production, planning or QA | Inflated form of F6: "schedule deliveries" widened to production | "I schedule deliveries for our three depots." The limit is the pack's own observation: your material shows deliveries, not production or QA. |
| Strong or advanced Excel | Inflated form of F4: the spreadsheet sentence does not name the tool | F3's sentence at its own scope. A4 and C3 ask the tool question. |
| Cut discrepancies by a third on your own | Inflated form of F3: the quote says you rebuilt the sheet and discrepancies fell, not that the fall was yours alone | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." C1 asks which part was yours. |

## Sources

Provided documents: your message (background, position, reasons); Hannah Lowther's LinkedIn message (call time, topics); the advert as you pasted it.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Refused. Would have supplied value names for a values-style round, and none is detected in this loop. |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Refused. Would have set the loop beyond this call, which is currently a flat fallback. |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Refused. Would have fed a CO question, and a recruiter screen carries none in this pack. |
| 4. Hannah Lowther (recruiter) public footprint | skipped | The inputs fix this output: Hannah's own message fixes the call's topics, and no interviewer read is produced for a recruiter. |
| 5. Representative operations coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD questions. |

Searches sent, all refused by the host (permission not granted):
- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics strategy news" — refused

## Upgrade menu

- Your notice period → F10 moves from a gap to a stated term, and D3 gets a written answer
- The tool the stock-count spreadsheet was in, and what you did in it → F4 moves from discovery to grounded, and A4 and C3 get written answers
- How the "about a third" was counted → C1 and C2 take your own words in place of slots
- Any delivery reporting you did → F7 gets a quote, and B5 gets a written answer
- Web search permission granted → the three L1 searches run (values, interview process, strategy). A values sheet appears only if a values round is documented.
- A deeper research pass, on consent: up to 6 more searches and 2 more fetches, several minutes, for a strategy brief and role-family loop reports. It also needs search permission first. Want it?
