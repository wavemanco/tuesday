**Decision: no_go.** Don't send your IBAN, PPS number, or passport photo, don't pay the €349, and don't deposit or forward any cheque. This is a fake-overpayment scam with a fake job on top. Your background fits the role well, but that doesn't change the verdict: the scam is built to target people with exactly your skills.

**Hard gates:** None of the role's stated terms fails your constraints outright. The process itself fails the integrity check (R1–R3 below).

**Fit ledger (candidate side, self-reported, not verified):**
- Strong: customer service with Zendesk at about 60 tickets a day, training two new starters, and maintaining a team Excel tracker map directly onto the posting's requirements. [grounded, from your message]
- Unverified: good written English and a quiet workspace. [inferred]
- Pay: at €26/hr, reaching €30,000 takes about 22 hours a week every week, before the unstated commission. The posting's 15–30 hours is a wide range. [grounded arithmetic, from the posting]

**Opportunity ledger, risk register:**

| # | Red flag | Severity | Basis |
|---|---|---|---|
| R1 | Asks you to pay €349 for "equipment" before any work, with a promise of a refund | Critical | [grounded] message 2 |
| R2 | Sends a cheque for €2,850, asks you to keep €350 and pass the rest to a "partner." This is the classic fake-cheque scheme: the cheque bounces weeks later, and the money you sent is gone | Critical | [grounded] message 3; [generic] scam pattern |
| R3 | Asks for IBAN, PPS number and passport photo before an interview | Critical | [grounded] message 1 |
| R4 | Telegram-only, no calls or video, "passed screening" from a chat message | High | [grounded] posting and messages |
| R5 | Offer made after a single chat exchange | High | [grounded] message 3 |
| R6 | HR contact is a generic mail address, not a company domain | High | [grounded] contact line |
| R7 | Employer existence not checked. No web research was run this turn, so the company is unverified | Standing entry | [inferred] |

Legitimate employers pay through payroll, provide or reimburse equipment, and don't ask for a PPS number or passport before an interview. Nothing in this process matches that.

**Application plan:** Don't apply through this channel. Your background is a good fit for real remote coordinator and customer operations roles. Look for postings on the company's own careers page, and only proceed to a real interview with video or phone and a verifiable company.

**Evidence status:** Research tier: L0 — no searches. You didn't ask for research, and the verdict doesn't depend on it.
- L1-1, company site and careers page: skipped. No research consent this turn.
- L1-2, role-family sweep: skipped. No research consent this turn.
- L1-3, hiring manager footprint: n/a. No named manager was given.

**If you've already sent anything:** Call your bank now and tell them you've shared your IBAN, and ask them to watch for unusual activity. If you sent your PPS number or passport, contact the Department of Social Protection about PPS misuse and report it to your local Garda station. Change the passwords on any accounts linked to that email or phone. Also report the posting to the jobs site.

I can save this underwriting as a `tuesday-dossier.md` for later if you want it.

**What would change this:** A verifiable company entry on an official register, and a live posting on the company's own website. I can run that check if you want it.

1. Have you already sent any of these, the IBAN, PPS, passport photo, or any money?
2. Which country does the company say it's based in? That determines which company register to check.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.