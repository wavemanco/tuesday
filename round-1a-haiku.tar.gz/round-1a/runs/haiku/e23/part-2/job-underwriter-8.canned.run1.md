**Decision: no_go.** Don't send anything else, don't pay anything, and don't deposit the cheque. This is almost certainly a scam, and the messages show the standard fake-job patterns.

Research tier: L0, no searches. The assessment rests only on what you pasted.

## Decision snapshot

- **Opportunity:** no_go. Several independent scam markers, and any one of them is enough to walk away.
- **Candidate fit:** strong on paper. Three years of customer service at a high ticket volume, Zendesk, training new starters, and an Excel tracker all match the posted requirements. These are your own claims, not verified. Fit doesn't change the decision.
- **Hard gates:** pay floor of €30,000 is not established. The posting gives €26/hour for 15–30 hours a week plus commission, which is roughly €20k–€40k a year before commission, and no salary is offered. [grounded]

## Why this is a scam

1. **You pay them.** A €349 "equipment" transfer to a third party, refunded "with your first wages." Legitimate employers don't ask new hires to buy their own kit. [generic]
2. **The cheque is a trap.** They send you €2,850, you keep €350, and transfer the rest to their "partner." The cheque will bounce after you've sent real money, and the bank can hold you liable for the amount. This is the fake-cheque scam.
3. **Your identity is the target.** They asked for your IBAN, PPS number and passport photo before any interview. A real employer needs these only after a verified hire, and never over Telegram.
4. **The process doesn't add up.** You were told you "passed first screening" before a chat interview, then "the job is yours" after a chat with no interview content. [grounded]
5. **The channel is set up to avoid checks.** Telegram only, no calls or video, a personal handle, and a generic email domain (`postmail.example`) rather than a company domain. Per-order commission with "no experience needed" is also a common money-mule structure. [generic]

No verifiable positive signals appear in the posting or the messages.

## What to do now

- Don't send the IBAN, PPS number, passport photo, or any payment to @VellowayHiring or velloway.hr@postmail.example.
- If a cheque arrives, don't deposit it. Take it to your bank unopened.
- If you have already sent any of those details, call your bank now to flag the account, report to the Gardaí (garda.ie), and report the Telegram account to Telegram. Keep the chat logs. Watch your accounts and credit for unfamiliar activity, since the PPS number is a lasting identifier.

For remote roles, apply through the employer's own careers page and check that the company exists in the official register before you engage. Real coordinator roles pay a salary and don't ask you to pay for equipment.

Dossier offer: I can write up a `tuesday-dossier.md` of this assessment for your records if that would help.

Upgrade menu: an L1 check (up to 5 searches and 2 page fetches) could confirm whether Velloway Logistics is registered in Ireland. It wouldn't change the no_go, but it would tell you whether the company is real or impersonated, which matters for a report.

Questions (answer in prose, skipping is fine):
1. Which jobs site did you find the posting on? That's where to report it.
2. Has a cheque actually arrived, or is it only promised?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.