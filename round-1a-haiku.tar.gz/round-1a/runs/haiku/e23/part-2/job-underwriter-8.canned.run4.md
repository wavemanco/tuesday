**Decision: no_go. Don't send anything else, don't pay the €349, and don't lodge any cheque.** This is a fake-cheque and advance-fee scam, and the posting is the bait.

**Decision snapshot**
- **Opportunity:** no_go. Every stage asks for money or identity documents, which legitimate employers do not do.
- **Candidate fit (separate ledger):** strong on the stated requirements. Three years of Zendesk ticket handling, training two new starters and keeping a weekly Excel tracker match "attention to detail" and "confident with spreadsheets" well. Written English is plausible from the work but unverified. "Quiet place to work" is unknown. These are CV-only claims, so confidence is moderate.
- **Hard gates:** none fail on the role's terms. The €30,000 floor is a poor match: €26/hour for 15–30 hours a week is roughly €20,000–€40,000 a year before commission, and the posting doesn't state the commission.
- **Research tier:** L0, no searches. The verdict rests on the messages you pasted, not on checking the company.

**Red flags in the messages**
1. **Identity documents before any interview.** Your IBAN, PPS number and passport photo are a full identity-theft kit. A "first screening" never needs them.
2. **Paying for equipment.** Asking you to pay €349 to an "equipment partner", refunded later, is the classic advance-fee scam. A real employer supplies its own equipment.
3. **The cheque.** You're told to lodge €2,850, keep €350 and forward the rest to the "partner". Banks often make cheque funds visible within days, before the cheque clears. You would send your own money, and weeks later the cheque bounces and you owe the bank the full amount.
4. **The process.** Telegram only, no calls or video, and a contact email on a generic domain.

**What to do now**
- **Don't send your IBAN, PPS number or passport.** If you've already sent any of them, call your bank today, ask for a fraud flag on the account, and report the PPS exposure to the Department of Social Protection.
- **Stop replying.** Block @VellowayHiring and report the account to Telegram.
- **Report the listing** to the job site, and report the scam to the Gardaí (you can do this online via the Garda website).
- **Ignore the email address** too. Don't reply to it.

**Upgrade menu:** A link to the original job-site listing would show whether the posting appears elsewhere. It wouldn't change the decision.

**Question:** Do you want me to draft the report text for the job site or the Gardaí?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.