## Decision snapshot

**Decision: `no_go`. Don't send anything, and don't pay anything.**

- **Fit ledger (candidate):** Your background matches the stated requirements well. Ticket handling in Zendesk, training new starters and Excel tracking all map directly to this role. [grounded]
- **Opportunity ledger (role):** Disqualifying. The hiring process asks for your bank details, PPS number and passport before any interview, then asks you to pay €349 for "equipment," then describes a cheque arrangement that requires you to move money out of your account. This is a known fraud pattern: the cheque is likely fake, and by the time the bank reverses it, the money you forwarded is gone. [inferred from the messages you quoted; I have not verified the company or the cheque]
- **Hard gates:** Pay floor is at risk. At the posted rate, 15 hours a week comes to about €20,280 a year and 30 hours about €40,560, so your €30,000 floor depends on hours that aren't guaranteed. [grounded arithmetic from the posting]. Separately, the upfront payment and identity requests are a deal-breaker regardless of pay.

Research tier: L0 — no searches

## Role reality

- **Stated:** remote order processing, 15–30 hours a week, up to €26/hour plus commission, Telegram-only hiring, no calls or video. [grounded]
- **Withheld:** the company's registration, address, named manager, a live posting on an employer site, and what the "commission" pays out. [grounded: absent from the posting]
- **Contradiction:** the posting says "no experience needed, full training provided," but the messages ask for an equipment payment and bank transfers before any work starts. [grounded]

## Evidence map (key rows)

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must-have | Attention to detail | Likely met | medium | none | Ticket and tracker work [grounded from your background] |
| 2 | must-have | Spreadsheet confidence | Met | high | none | Keep the weekly Excel tracker [grounded] |
| 3 | must-have | Written English | Not assessed | — | discovery | Not in your background summary |
| 4 | must-have | Quiet workspace | Your call | — | discovery | Not a background item |
| 5 | hard_gate | Pay meets €30k floor | Unlikely at low hours | medium | capability | Arithmetic above [grounded] |
| 6 | hard_gate | No upfront payment or sensitive-data requests | Fails | high | — | The messages you quoted [grounded] |

## Opportunity risk register

- **Upfront €349 payment to an "equipment partner"** — critical. Legitimate employers don't charge for equipment or kit. [inferred]
- **Sensitive data before any role is confirmed** (IBAN, PPS, passport) — critical. This enables identity theft and account fraud. [inferred]
- **Cheque deposit with forwarding of the balance** — critical. Classic overpayment scam; the cheque typically bounces after the funds you sent have cleared out. [inferred]
- **Telegram-only process, free-mail contact domain** — high. The contact address is a generic webmail-style domain, not a company domain. [grounded]
- **Pay can't reach your floor at low hours** — medium. [grounded arithmetic]

## Application plan

Don't apply through this route. Don't paste your IBAN into anything. If you want to pursue remote customer-service or coordinator roles, your Zendesk and tracker experience is strong, and you could look at employers that list on their own careers pages and have a verifiable registration.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 tier: no research run in this engagement |
| 2. Role-family sweep | skipped | L0 tier: no research run |
| 3. Hiring manager footprint | n/a | No name given |

## Upgrade menu

- **A link to the live posting on an employer site or a job board you trust** — would let me check whether the listing exists independently of the Telegram chat.
- **The company's registration number (CRO) or registered address** — would let you check the entity yourself on the official register.
- **Research at L1** — up to 5 searches and 2 page fetches to check whether Velloway Logistics exists as described.

## Questions

1. Would you like me to run the L1 check (up to 5 searches and 2 page fetches) on Velloway Logistics? It won't change the decision, but it will tell you whether the company exists.
2. Has anything been sent or paid yet, to anyone, by any method? If yes, contact your bank now and report the Telegram account to Gardaí.

I can also write up the warning signs as a short note you can keep.

I can save this assessment as a dossier file (`tuesday-dossier.md`) if you want a record.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.