**Decision: no_go.** Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't deposit the cheque. Your fit doesn't change this. The payment and document requests are the problem, not the job's merits. [inferred]

**Hard gates (opportunity side):**
- Candidate pays a €349 "equipment" fee to the employer's partner: failed.
- Candidate deposits a cheque, keeps €350 and forwards the rest to a third party: failed.
- Identity and bank documents requested before any real interview: failed.

**Why this is a scam pattern** [generic]:
1. **Pay to start.** Legitimate employers don't charge staff for equipment or direct them to pay a "partner."
2. **Overpayment cheque.** They send €2,850, you keep €350 and forward about €2,500. The cheque bounces days or weeks later, after the money has left your account. You lose the money, and your bank may hold you liable. This is the classic fake-cheque fraud.
3. **Documents first.** IBAN, PPS number and passport before any real interview enable identity theft. An account that receives and forwards money can make you a money mule.
4. **Process.** Telegram only, no calls or video, a "chat interview," "you passed" after one screening, and no experience needed at a high rate.
5. **Contact.** velloway.hr@postmail.example is a generic mail domain, not a company domain.

**Fit (candidate side, secondary):** Strong on the stated requirements. Three years of customer service with about 60 Zendesk tickets a day, two starters trained, and a team Excel tracker all map directly. Pay is not the blocker either: 15–30 hours at €26/hr is roughly €20k–€40k a year before commission, so your €30k floor sits within that range. The money flow is the issue.

**Research tier: L0 — no searches.** I didn't verify that Velloway Logistics exists. The verdict doesn't depend on it, since even a real employer has no reason to ask for these payments.

**If you've already sent anything:** Contact your bank now, and don't reply to the Telegram account. Report it to the Gardaí (Garda National Economic Crime Bureau) and to Telegram.

**What would change this:** Nothing in the posting or messages would. A live company careers page or a contract from a company domain would only confirm the employer exists, and a real employer still wouldn't ask for these payments.

If useful, I can also write a `tuesday-dossier.md` so future underwriting starts from your background.

1. Have you sent any money, documents or your IBAN yet?
2. Can you share the jobs site name and the listing link so you can report it?
3. Do you want help drafting a decline reply, or a shortlist of roles that use your Zendesk and Excel experience?

Answer in your own words, and skipping any question is fine.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.