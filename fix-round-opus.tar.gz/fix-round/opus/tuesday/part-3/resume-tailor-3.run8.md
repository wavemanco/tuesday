I've read the tailoring playbook. Here is the ledger.

I read your dossier for the same Quartzline role. I'm using its requirement calls as they stand, carrying the E1 edit forward, and adding both rejected inferences to the "not written" list. The dossier's `conditional_go` decides whether to apply; it doesn't change how I tailor. Your CV came as six sentences, not a file, so each "current line" below is your own sentence, quoted exactly.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." *(as its own bullet)* | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; edit carried over from the dossier | pending your approval |
| E2 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to directly under the integrations bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, kept as the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved above Experience, "Comfortable in" kept)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

**Notes:**
- **E1:** your playbook sentence stays word for word. "The whole team" doesn't become "company-wide."
- **E2:** this is your closest evidence for running discovery with integration partners, so it moves up. It still reads "roadmap-input," not "roadmap ownership." Your sessions collected feedback *for* product, and product owned the decisions.
- **E5:** the summary uses only your own three sentences, kept as three. The "30+" still counts integrations.
- **Job title:** your current title stays as it is. There's no retitle row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier calls it adjacent: transferability gap, medium confidence. Integration leadership is adjacent; you've never held a PM title or owned prioritisation. Named absence below. | `[grounded]` dossier evidence_map R1; CV |
| R2 | Shipped API or platform products | important | `not_evidenced` | Dossier calls it adjacent, medium confidence. You integrated your company's REST APIs for clients; the CV doesn't show you shipping the API itself. Recall prompt C1. | `[grounded]` dossier evidence_map R2; CV |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4 and E3: Postman, SQL, OpenAPI, 30+ REST API integrations | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E5: client integrations end to end, plus quarterly sessions feeding product | `[grounded]` CV |
| R5 | Run discovery with integration partners | important | `surfaced_by_edit` | E2. It's adjacent: you collected client feedback for product. You didn't own discovery. | `[grounded]` CV |
| R6 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | "Comfortable in … OpenAPI specs" isn't product-spec writing or leading engineering delivery. Recall prompt C2. | `[grounded]` CV |
| R7 | Define adoption metrics | important | `not_evidenced` | Nothing in the CV covers this. Recall prompt C3. | `[grounded]` CV |
| R8 | Own the roadmap | important | `not_evidenced` | The dossier already found roadmap ownership not evidenced. Named absence below. | `[grounded]` dossier evidence_map R1 reasoning |

## Gap handling

**Recall prompts** (the questions are in the closing block)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Shipped API or platform products | important | Many client integrations of APIs your company built. It doesn't show whether you shaped the API itself. | This is the core of a platform-API PM role. Without it you read as a strong API user, not someone who builds API products. | An endpoint or field added because of your integration findings; an SDK, sample app or sandbox you specified; a versioning or deprecation change you drove | Ticket or PRD links, release notes naming you, a changelog | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on platform-PM applications |
| C2 | Write specs, drive delivery with engineering | important | You're comfortable working with OpenAPI specs. Nothing shows you writing requirements that engineers built from. | The JD's day-to-day is specs plus two squads | Requirements docs written for engineering after an integration blocker; acceptance criteria you set; a cross-team fix you coordinated through to release | A spec or ticket you wrote (redacted is fine) | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs here |
| C3 | Define adoption metrics | important | Nothing yet | Quartzline names it as a responsibility | Time-to-first-call or go-live tracking across your integrations; SQL reports on client API usage; playbook success measures | A dashboard, query or report | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs here |

**Named absences**
- **R1, 3+ years PM:** you haven't held a PM title, and the JD makes it a must-have. No wording closes that gap. The honest route is an interview case built on the adjacent evidence: E2's quarterly sessions and E1's playbook. If C1 or C2 comes back with real examples, that case gets stronger. If neither does, the dossier's `conditional_go` is the right frame, not a rewritten CV.
- **R8, roadmap ownership:** your sessions fed someone else's roadmap. Closing this takes a role where you set priorities yourself. Examples: an internal tooling roadmap, an associate-PM step, or a role-scoped title. It isn't worth hinting at on this CV.

## Not written, and why

- **"Product Manager" or "3+ years of product management":** you've never held the title.
- **"Owned / drove / set the product roadmap":** you wrote "roadmap-input sessions collecting client feedback for product." Input isn't ownership.
- **"Ran discovery with integration partners":** this is the JD's wording. Your words are "client" and "collecting feedback." Swapping them in would quietly upgrade what you did.
- **"Shipped / built our REST APIs":** you led integrations *of* them.
- **"Authored OpenAPI specifications":** you wrote "comfortable in." That isn't authorship.
- **"Drove delivery with engineering squads" and "defined adoption metrics":** neither is stated. These wait on C2 and C3.
- **"Playbook adopted company-wide":** your words are "the whole team uses."
- **From the dossier's rejected inferences, unchanged:** "built an internal request-triage tool." It was a memory lead, and you couldn't confirm you owned it.
- **From the dossier's rejected inferences, unchanged:** "has been the customer of a partner API platform." You worked vendor-side.

## Parse-safety check

You pasted text, not a file, so I couldn't check for columns, tables, text boxes, icons, header or footer content, file type, or hidden text. "Summary," "Experience" and "Skills" are standard headings that parsers recognise. Send the file and I'll run the full check.

## Upgrade menu

- **Your actual CV file:** lets me run the full parse check and quote your current bullets rather than these summary sentences.
- **The integration playbook (redacted is fine):** would move E1 from self-report to inspected evidence.
- **One write-up you sent product after a roadmap-input session:** the strongest proof available for R5, and a start on R1.
- **The R1 gap in interviews:** it's the first thing an interviewer will probe, and mock-interview can rehearse your answer.

## Questions

**C1:** Did any change to your company's API itself come from your integration work, and what was your part in it? For example, a new endpoint, a field, an SDK or a deprecation.
**C2:** Have you ever written a requirements doc or ticket that engineers built from? What was it, and who carried it to release?
**C3:** Did you track anything on how clients used the APIs after go-live, such as time-to-first-call or usage queries? Who decided what to measure?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.