I've read the tailoring rules and am now pulling the last bit of guidance before I build your edit list.
Priya, here's the tailoring as a list of proposed edits. Nothing is applied yet. You approve each row by its number, and I produce the tailored CV from the approved rows only.

You described your CV rather than pasting it, so I've built from your message. Each "Current line" and "Traces to" cell quotes your message, not the CV document itself.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(none in your message)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `reframe` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Incident commander for six incidents; on-call every fourth week for two years." | `reframe` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python, Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your message | pending your approval |

What these rows hold back on, on purpose:
- **E3** ties "about 40k requests/minute" to *one* service, not all three.
- **E4** keeps "six incidents" without adding "major" or "critical", and keeps "incident commander" rather than "led incident response".
- **E5** says "onboard" and "pairing", not "mentor". You didn't use that word, and the posting's version is narrower (see C2).

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | "Senior Software Engineer, 7 years" plus the ledger services. Your message doesn't say whether the Python years were backend work, so a reader is assuming it | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1, E6. Your message doesn't say which language the three ledger services are written in (C1) | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | 40k req/min and the Kafka/gRPC listing come close, but nothing describes a distributed architecture → C1 | `[grounded]` |
| R4 | Strong incident response | must-have | `already_evidenced` | Six incidents as incident commander; E4 puts that first | `[grounded]` |
| R5 | Experience mentoring | must-have | `not_evidenced` | Onboarding pairing is close but isn't mentoring mid-level engineers. E5 carries it as you wrote it → C2 | `[grounded]` |
| R6 | Drive down p99 latency | important | `already_evidenced` | 380ms → 95ms; E2 moves it to the top | `[grounded]` |
| R7 | Go services handling high request volume | important | `already_evidenced` | E3 | `[grounded]` |
| R8 | Own on-call for your services | important | `already_evidenced` | E4 | `[grounded]` |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your message → C3 | `[grounded]` |
| R10 | Build-cache / developer-tools domain | preferred | `not_evidenced` | Named absence, below | `[grounded]` |

## Gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale; production Go | must-have | Three owned services, one at about 40k req/min; Go is a daily language; Kafka and gRPC are listed as tools. It doesn't say the services are in Go or how they talk to each other | It's a named requirement, and a tools list doesn't show architecture | Ledger services talking over Kafka topics or gRPC; replication or multi-region setup; idempotency or exactly-once handling for ledger writes; partition or sharding work | Design doc, architecture diagram, a repo or PR you can describe | `[grounded]` what your message does and doesn't say; `[generic]` how screeners treat tools-only evidence |
| C2 | Experience mentoring | must-have | Onboarding two or three new hires a year, with a month of pairing each | The posting says "mentor mid-level engineers", and onboarding new hires is a different relationship | Ongoing 1:1s with a mid-level engineer; design-review coaching; helping someone get promoted; leading the onboarding programme itself | Onboarding doc you wrote, a promotion packet you contributed to | `[grounded]` what your message says; `[generic]` how "mentoring" gets probed |
| C3 | Partner with product on roadmap sequencing | important | Nothing | It's a stated part of the job | Negotiating the order of ledger work with a PM; writing tech-debt vs. feature trade-off proposals; a quarterly planning input you owned | Planning doc, RFC with a sequencing section | `[grounded]` absence in your message; `[generic]` how this gets asked about |

**Named absence (R10):** nothing shows build tooling or developer-tools work, and the posting lists it as context, not as a requirement. It isn't worth closing for this application. Your cache-layer rework stays described as what it was, without dressing it up as build caching.

## Not written, and why

- **"Distributed systems at scale" as a line about you.** That's the posting's wording, and your message describes services and traffic, not architecture. It waits on C1.
- **"Production Go services"** waits on C1 too, because your message doesn't say the ledger services are written in Go.
- **"Mentored mid-level engineers" or "mentor to new hires".** You wrote "onboarding" and "pair with them", and switching to the posting's word would claim a different relationship.
- **"Partnered with product on roadmap."** There's no evidence for it yet (C3).
- **"Caching / build-cache expertise"** drawn from the cache-layer rework. You reworked one cache layer, and expertise is a broader claim.
- **"Handles 40k+ requests/minute across three services."** That moves the number from one service to all three.
- **"7 years of backend" or "7 years of Go".** You said 7 years total, with Go for 4.

## Parse-safety check

These checks need the actual file, and I only have your description, so none of them could run: layout, tables or text boxes, headers and footers, section headings, file type.

## Upgrade menu

- **The CV itself (.docx or PDF):** lets me run the parse-safety check and quote your real lines.
- **A design doc, postmortem or dashboard for the p99 work or one of the incidents:** gives an interviewer something concrete behind your strongest bullets.
- **Answers to C1–C3:** each answer you confirm can turn a gap into a real row.

## Questions

C1: Are the three ledger services written in Go, and how do they connect: Kafka, gRPC, replicas, multiple regions?
C2: Beyond the first-month pairing, have you mentored a mid-level engineer over a longer stretch, even informally?
C3: Have you worked with a PM on the order of ledger work, for example trading tech debt against features in planning?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.