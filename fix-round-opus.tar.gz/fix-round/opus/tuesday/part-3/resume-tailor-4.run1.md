Now the reframing audit, evidence conventions, and the citations I'll quote.
Short answer: keyword matching is probably not your main problem. Your file layout may be, and so is the gap between your experience and this job's tool stack. Below is everything I can honestly change, everything I won't write, and three questions that could close real gaps.

**On the ATS premise.** The best evidence I have is small: one vendor interviewed 25 US recruiters. In that sample, "AI/content auto-rejection configured" applied to "8% of recruiters", which is two people. Where software did reject people automatically, it was "almost always knockout questions", meaning "yes/no eligibility checks (work authorization, required license, location)" on the application form, not your resume. Match scores are mostly used "to prioritize who gets reviewed first". A low score is not an automatic rejection, though "in high-volume roles, it can push you to the bottom of the pile". A sample that size can't tell you which of these is rejecting you. So the useful move is to make your true keywords easy to find and make sure the file can be read by a machine. Stuffing in keywords won't help.

**What the coverage map shows.** Only Kubernetes (R1), CI/CD (R3) and Python (R12) can be raised by an edit, and Kubernetes only as a proof-of-concept. Everything else in the job description is `not_evidenced`. No wording fixes that. Whether the role is worth applying to with gaps this size is a separate question, which the job-underwriter module answers.

**What I built from.** You described your resume but didn't paste it. Each "Traces to" cell quotes your own description word for word. "Current line" shows what I assume is on the page. The job description gives no priority levels, so I assigned must-have, important or preferred myself. Check those.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" | *(unchanged, moved to first bullet)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year" | "Ran a two-month Kubernetes proof-of-concept last year (not taken to production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | "Cloud: AWS (EC2, S3, RDS, IAM) · Containers: Docker · CI/CD: Jenkins · Config management: Ansible · Monitoring: CloudWatch · Scripting: Python, Bash" | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your description | pending your approval |
| E4 | Skills | *(Kubernetes not listed)* | Add to the Containers line: "Kubernetes (two-month proof-of-concept)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E5 | Skills | "Bash and Python scripting" | "Python and Bash scripting" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your description | pending your approval |
| E6 | Summary | *(no current line assumed)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |

Notes:
- **E2 and E4 keep "proof-of-concept" on purpose.** Kubernetes is the first word in the job description, so it needs to be findable. Without the qualifier it becomes production experience you don't have, and an interviewer will find that out in one question.
- **E6 keeps "4 years" attached to your job title.** You didn't say you had four years on AWS, so the summary doesn't say it either.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | surfaced_by_edit | E2, E4; proof-of-concept only, not production; C1 may add detail | `[grounded]` your description |
| R2 | AWS EKS | must-have | not_evidenced | General AWS is in E3 and E6; EKS isn't mentioned; C1 | `[grounded]` your description |
| R3 | CI/CD | must-have | surfaced_by_edit | E1, E6; Jenkins | `[grounded]` your description |
| R4 | GitLab CI specifically | important | not_evidenced | N1 | `[grounded]` your description |
| R5 | Terraform | must-have | not_evidenced | C2; Ansible is config management, a different kind of tool | `[grounded]` your description |
| R6 | Platform reliability / SRE practices | must-have | not_evidenced | C3 | `[grounded]` your description |
| R7 | Observability: Prometheus, Grafana | important | not_evidenced | CloudWatch monitoring is in E3 but is a different tool; C3 | `[grounded]` your description |
| R8 | Helm | important | not_evidenced | C1 | `[grounded]` your description |
| R9 | GitOps / ArgoCD | important | not_evidenced | N2 | `[grounded]` your description |
| R10 | Python | important | surfaced_by_edit | E5; scripting only | `[grounded]` your description |
| R11 | Developer experience | important | not_evidenced | N3; the pipeline in E1 is related but doesn't show it | `[grounded]` your description |
| R12 | Service mesh / Istio | preferred | not_evidenced | N4 | `[grounded]` your description |
| R13 | Vault | preferred | not_evidenced | N4 | `[grounded]` your description |
| R14 | Go | preferred | not_evidenced | N5 | `[grounded]` your description |

## Recovery per gap

**Recall prompts.** The questions for these are at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes depth, EKS, Helm | must-have | That a Kubernetes proof-of-concept happened, but not what it involved | Kubernetes is the core of this role | The proof-of-concept ran on EKS; you installed or wrote Helm charts; you moved a real service onto the cluster | Proof-of-concept repo, design doc, write-up | `[grounded]` what your description says; `[generic]` how central Kubernetes is to platform roles |
| C2 | Terraform | must-have | Ansible only | Infrastructure-as-code is listed as core | Any Terraform or CloudFormation, even small; changes to someone else's modules | Repo, merge requests | `[grounded]` what your description says; `[generic]` what this gap costs in platform roles |
| C3 | Reliability / SRE, observability | must-have | CloudWatch "for monitoring" | "Own platform reliability" is the role's stated purpose | You set up CloudWatch alarms or dashboards; you were on-call; you wrote incident reviews; you tracked uptime | Dashboard screenshots, runbooks, incident docs | `[grounded]` what your description says; `[generic]` how reliability ownership is assessed |

**Named absences.** Nothing in your description suggests experience here, so these are gaps with a way to close each one.

| # | Gap | How to close it | Provenance |
|---|---|---|---|
| N1 | GitLab CI: you've used Jenkins, not GitLab | Rebuild one of your Jenkins pipelines in GitLab CI in a public repo; then it becomes a project you can list | `[grounded]` your description; `[generic]` how close the two tools are |
| N2 | GitOps / ArgoCD | Deploy to a personal cluster through ArgoCD from a Git repo; this fits naturally with N1 | `[generic]` |
| N3 | Developer experience | Not worth chasing for this application unless you have real examples of improving other developers' workflow, and nothing you've described shows that | `[grounded]` your description |
| N4 | Istio, Vault | Both are preferred skills; not worth closing before applying. Learn them on the job | `[generic]` |
| N5 | Go | Preferred; a small Go CLI tool or Kubernetes operator in a repo would close it over time | `[generic]` |

## Not written, and why

- **"Kubernetes" with no qualifier, or "Kubernetes in production."** It was a two-month proof-of-concept that never went live.
- **Retitling you as "Platform Engineer."** Your title was DevOps Engineer.
- **"GitLab CI/CD" or a general "CI/CD platform" for your Jenkins work.** The tool is different, and "platform" makes the claim bigger.
- **"Observability" or "Prometheus/Grafana" for CloudWatch monitoring.** That's the job description's vocabulary, not your history.
- **"Infrastructure as Code" or "Terraform" for Ansible.** You called it config management, which is a different kind of work.
- **"SRE" or "owned platform reliability."** Nothing you've described supports it yet. C3 might.
- **A skills block listing EKS, Helm, ArgoCD, Istio, Vault or Go.** Listing tools you haven't used is the keyword stuffing that fails in the first technical screen.

## Parse-safety check

I couldn't inspect the PDF, so this is based on how you described it. I also couldn't check whether it contains hidden text, for example left over from a template.

| Check | Finding |
|---|---|
| Two-column layout | **Risk.** Parsers often read straight across both columns, which mixes them together. Your skills could get merged with your experience text, and dates can end up separated from the roles they belong to. |
| Skill icons | **Risk.** If a skill appears only as an icon, a parser loses it completely. Icons next to text can turn into garbage characters. |
| Contact details in the header | **Risk.** Parsers often drop page headers, which can leave your application with no way to contact you. |
| Canva PDF | **Unknown.** Test it: open the PDF, select all, and paste into a plain text editor. If text is missing, scrambled or out of order, that's what the ATS sees too. |

This is about machine-readability only. I'm not recommending a redesign.

## Upgrade menu

- **Your actual resume text or PDF:** gives exact current lines for every row and a real parse check.
- **Any proof-of-concept artifact (repo, doc, notes):** would let E2 say what the proof-of-concept actually covered.
- **Any infrastructure-as-code you've written:** could turn R5 into a real ledger row.

## Questions

**C1:** In the Kubernetes proof-of-concept, what did you personally do? Was it on EKS, did you use Helm, and did any real service run on it?
**C2:** Have you written or changed any Terraform or CloudFormation, even a small amount?
**C3:** Around CloudWatch, did you set up alarms or dashboards, do on-call, or write incident reviews?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip. To apply edits, reply with which rows to approve, e.g. "Approved: E1, E3".

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.