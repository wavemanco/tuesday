Reading the last two reference files (the parse-safety rules and the scope rules) before I draft your ledger.
I've drafted the ledger below. One thing first: the posting's must-have is "3+ years data engineering", and your 5 years are as a Senior Data Analyst. No rewording changes that, so I haven't tried. What the edits do is put your engineering-adjacent work first: the dbt models, the star schema, the nightly job and the API scripts. Three gaps might shrink depending on your answers to the questions at the end. Whether to apply at all is a separate decision, and job-underwriter is the module for that.

Every quote below comes from your message, which I'm treating as your own account rather than a finished resume.

## Edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged wording — moved to first bullet under Senior Data Analyst)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our data engineer at the time" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fix our nightly dbt job when it breaks; added tests to it" — placed third | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Two bullets: "Wrote Python scripts to pull vendor APIs on a cron" / "Python (pandas) for analysis" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "Daily SQL on Redshift — complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` | pending your approval |
| E6 | Skills | *(no current line)* | "SQL (Redshift, window functions, CTEs) · dbt · Python (pandas) · star schema design" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |
| E7 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail, moving into data engineering. Built and maintained about 25 dbt models, including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` | pending your approval |

Notes on these rows:
- **E2** keeps "with" your data engineer. Saying you designed the schema alone would claim more than you told me.
- **E4** drops your word "some" from "some scripting". If that makes the line sound bigger than the work was, reject E4 or tell me how many scripts there were and how long they ran (C1 below).
- **E7** says plainly that you're moving into data engineering. It doesn't hint that you already are a data engineer.
- **The title stays "Senior Data Analyst".** Any data-engineering title would be an upgrade, not an equivalent.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Named absence below. The adjacent work is in E1–E4 | `[grounded]` your title and years as you stated them |
| R2 | Production Python | must-have | `not_evidenced` | Recall prompt C1. E4 shows scripting, not production code | `[grounded]` |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | Recall prompt C2. You said "Never used Airflow"; a cron is not orchestration as written | `[grounded]` |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E2, E6. One mart, designed together with your data engineer | `[grounded]` |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1, E2. About 25 dbt models and one star schema, not the whole warehouse | `[grounded]` |
| R6 | Build batch pipelines | important | `not_evidenced` | Covered by C1 and C2. The dbt models and cron scripts are next to this, but neither is a pipeline you built as written | `[grounded]` |
| R7 | Data quality | important | `surfaced_by_edit` | E3: you added tests to the nightly job | `[grounded]` |
| R8 | Own SLAs | important | `not_evidenced` | Recall prompt C3 | `[grounded]` |
| R9 | Spark | important | `not_evidenced` | Named absence below | `[grounded]` "Never used Airflow or Spark." |
| R10 | Streaming / Kafka | preferred | `not_evidenced` | Named absence below | `[grounded]` "Never touched Kafka." |
| R11 | Partner with analytics on requirements | important | `not_evidenced` | Named absence below | `[grounded]` |

## Recovery per gap

**Recall prompts** (the questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, plus "some scripting" on a cron. That doesn't show that anyone else relied on the scripts | It's a must-have, and "for analysis" reads as notebook work | The vendor-API scripts feeding tables other people query; error handling or retries you added; the code living in a shared repo with review; tests on Python code | The repo, a PR, the script itself | `[grounded]` what you wrote; `[generic]` how analysis Python reads on data-engineering applications |
| C2 | Airflow or equivalent orchestration | must-have | A cron, and a nightly dbt job you fix. You didn't say what schedules that job | The posting says "or equivalent", so whatever actually runs your dbt job might count | dbt Cloud jobs, Dagster, Prefect, Step Functions, Jenkins; setting up job dependencies or retries yourself | The job config, a screenshot of the scheduler | `[grounded]` what you wrote; `[inferred]` from the JD's "or equivalent" that a non-Airflow scheduler may count |
| C3 | Own SLAs | important | You fix the nightly job "when it breaks". No deadline or downstream consumers are stated | SLAs are a stated responsibility, and the posting is explicit about owning them | A deadline the orders mart had to meet before morning reports; an on-call or alerting setup; telling stakeholders when the job was late | An alert config, a runbook, an incident note | `[grounded]` what you wrote; `[generic]` what SLA ownership usually looks like |

**Named absences:**
- **R1 — 3+ years data engineering.** You have none under that title, and the posting calls it a must-have. Wording can't fix this. What might narrow it: good answers to C1–C3, or aiming for analytics-engineer roles, where your dbt work matches directly. Or apply anyway, knowing this is the first thing a screener will check.
- **R9 — Spark** and **R10 — Kafka.** You've never used either. Spark is listed under the role's tools rather than as a requirement, and streaming is "a plus". A small public project would give you something to talk about, but it wouldn't count as on-the-job experience, and a resume line about it has to say so.
- **R11 — Partner with analytics.** Your resume doesn't describe gathering requirements from anyone. You may well have examples. Give me one specific sentence in a later turn and I'll trace a row to it. If you don't, the gap stays open.

## Prohibited claims — not written, and why

- **Any "Data Engineer" title, or "X years of data engineering".** Your title is Senior Data Analyst.
- **"Built / owned data pipelines".** You built dbt models and cron scripts. "Pipelines" is the posting's word, not yours.
- **"Production Python".** That depends on C1. You wrote "Python for analysis".
- **"Orchestrated" or "Airflow" anywhere, including Skills.** You said "Never used Airflow".
- **Spark or Kafka in Skills.** Listing a tool you've never used is the line an interviewer checks first.
- **"Owned data quality and SLAs".** You added tests and fix breakages. Owning SLAs is a different job (C3).
- **"Designed the warehouse" / "led dimensional modelling".** You designed one mart's schema, together with someone else.
- **"Partnered with analytics".** You *are* analytics. Using the posting's word would change which side of the work you were on.

## Parse-safety check

Your resume came as pasted prose, so I couldn't check layout: columns, tables, headers and footers, images, or file type. Those checks still need to run on the real file. One practical point: keep "dbt", "Redshift", "Python" and "star schema" as plain text in a section headed Skills or Experience, so a parser can find them.

## Upgrade menu
- **The vendor-API script repo**, or one script: this could support production Python (C1).
- **The scheduler config for the nightly dbt job**: this could support orchestration (C2).
- **Your dbt project or lineage graph**: this would make E1 and E2 something a reader can check.

## Questions

C1 — Did anyone other than you rely on the vendor-API scripts' output, and did they have error handling, a shared repo or code review?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — What actually runs the nightly dbt job (dbt Cloud, another scheduler, a cron), and did you set any of it up?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did the nightly job have a deadline it had to meet, or people who were told when it was late?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.