I've read the resume-tailor playbook and its references; checking the upgrade-menu rules, then I'll write the ledger.
I used the dossier's evidence map, its pending edit and its rejected inferences instead of working them out again. The confidence ratings carry over unchanged: the dossier marks both PM experience and API products as adjacent at medium confidence, so expect an interviewer to probe them.

**One assumption:** your message gives a summary of your CV, not the document. I've treated each sentence you wrote as a CV line and quoted it exactly. Once I have the real file, I'll redo the trace quotes against your actual bullets.

## Proposed edits — all pending your approval

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as a separate bullet, no longer buried inside another line | `surface` | "Wrote the internal integration playbook the whole team uses." (dossier `resume_edits_pending_approval` E1: "surface the integration playbook authorship into its own line") | `[grounded]` CV; dossier edit | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(wording unchanged; moved to first bullet under the role)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(wording unchanged; moved to second bullet, directly under E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Summary | *(no current line)* | "7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Comfortable in Postman, SQL, OpenAPI specs." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

What I kept on purpose:
- **E2** keeps "client" and "our REST APIs". You worked on the side that provides the API, helping clients integrate with it, and that is the side Quartzline's platform sits on. Changing those words would blur which side you were on.
- **E3** keeps "for product". It shows that you fed the roadmap without owning it.
- **E1** keeps "the whole team" and doesn't stretch it to "company-wide".
- **E4** keeps three separate sentences so no single clause claims more than its source does, and it keeps "Comfortable in".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Taken from the dossier: adjacent work, transferability gap, medium confidence. E2 and E3 show the adjacent work; roadmap ownership and prioritisation authority aren't shown. Recall prompt C1 | `[grounded]` JD; dossier evidence_map R1 |
| R2 | Shipped API or platform products | important | `not_evidenced` | Taken from the dossier: adjacent, medium confidence. E2 shows you delivered integrations of the API, which is different from shipping the API. Recall prompt C3 | `[grounded]` JD; dossier evidence_map R2; CV |
| R3 | Technical fluency | important | `already_evidenced` | "Comfortable in Postman, SQL, OpenAPI specs." and "REST APIs"; E4 also puts them in the summary | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 put the client-facing work first. Working with internal engineering stakeholders isn't shown | `[grounded]` CV |
| R5 | Own the partner-API roadmap | important | `not_evidenced` | "Ran quarterly roadmap-input sessions" is input to a roadmap, not ownership of one. C1 covers this | `[grounded]` JD; CV |
| R6 | Run discovery with integration partners | important | `not_evidenced` | E3 shows you collected feedback. Running discovery, meaning designing it and turning findings into recommendations, isn't shown. Recall prompt C2 | `[grounded]` JD; CV |
| R7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Named absence, below | `[grounded]` JD; CV |
| R8 | Define adoption metrics | important | `not_evidenced` | Named absence, below | `[grounded]` JD; CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM (and roadmap ownership) | must-have | It shows 7 years of integration leadership and quarterly input sessions. It shows no decision you made about what got built or in what order | It's the posting's only must-have, and the dossier's reasoning found the decision authority missing, not just the title | Deciding the scope or sequence of client integrations, including what to cut; deciding what went into the playbook and when it changed; choosing which feedback themes from the sessions went to product as priorities | Playbook revision history; a prioritised list you kept; a message from product deferring to your call | `[grounded]` JD and dossier; `[generic]` PM hiring commonly probes for decisions made, not titles held |
| C2 | Run discovery with integration partners | important | It shows that you ran the sessions and collected the feedback. It doesn't show what you did with it | Discovery is one of the four named responsibilities | You designed the session agenda or questions; you wrote the summary that went to product; you followed up one-on-one with clients to dig into a request | A session write-up, a template or a deck | `[grounded]` JD and CV |
| C3 | Shipped API or platform products | important | It shows you integrated "our REST APIs". It doesn't show any change to the API that you shaped | The dossier rates this adjacent, and the posting is for an API platform | An endpoint or field added after integration pain you reported; an OpenAPI spec change you drafted or reviewed; a docs change you pushed through | A release note, a spec diff or a ticket | `[grounded]` JD, CV and dossier |

**R7, named absence.** Your CV shows no specs written for engineering and no delivery you drove with an engineering team. To close it, you'd need either that history (tell me if you have it) or a work sample: see the offer in the upgrade menu.

**R8, named absence.** Your CV doesn't mention any measure you defined or tracked. Nothing gets written here until a real one turns up. It's listed as a responsibility, not a requirement, so I wouldn't force it.

## Prohibited claims

Not written, and why:
- **"Product Manager" or "product management experience":** in your words, you "Never held a PM title". It's the must-have, so it stays a named gap.
- **"Owned" or "shaped the API roadmap":** your sessions collected feedback "for product". Saying you owned the roadmap changes the verb and the kind of work.
- **"Shipped API products" or "built our REST APIs":** you integrated them for clients.
- **"Partner integrations":** your word is "client", and "partner" is the posting's word. Swapping it changes who those people were to you.
- **"Ran discovery":** your phrase is "collecting client feedback". Discovery is different work.
- **"Standardised integration across the company" for the playbook:** you wrote "the whole team uses".
- **"Drove delivery with engineering" or "defined adoption metrics":** neither is stated anywhere.
- From the dossier, unaltered: "built an internal request-triage tool — memory lead, candidate could not confirm ownership".
- From the dossier, unaltered: "has been the customer of a partner API platform — candidate worked vendor-side".

## Parse-safety check

You sent text, not a file, so I couldn't check columns, tables, text boxes, images, headers and footers, section headings or file type. A `.docx` or a PDF with selectable text is the safe pair.

## Upgrade menu
- **Your actual CV file:** I could quote your real bullets in the trace column and run all six parse checks.
- **The playbook itself, or a redacted excerpt:** in this field the inspectable proof is a document you wrote, and it would raise E1's confidence above medium.
- **A roadmap-input write-up you sent product:** this is the artifact that would turn C2 into a real line.
- **Offered proposal, built only if you say yes:** a one-page spec for a partner-API feature as a work sample. The dossier calls R1 a transferability gap, and that's the kind of gap a work sample can close. It would also give R7 something real to point to.

**C1:** Over the 7 years, name one decision about what got built, or in what order, that was yours to make and not product's.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2:** After a quarterly roadmap-input session, what did you hand product, and who wrote it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3:** Can you name one change to your REST APIs that shipped, and say what your part in it was?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.