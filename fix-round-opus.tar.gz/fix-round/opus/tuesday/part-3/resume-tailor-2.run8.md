I've read the resume-tailor instructions. Below is the proposed set of edits; none of them is applied yet.

**First, the honest part.** Bellhaven's must-haves are 3+ years of data engineering, production Python and Airflow-style orchestration. Your background as you've described it shows none of those, and no wording can change that. It does show real work right next to them: about 25 dbt models, a star schema, keeping a nightly job running and adding tests. Those can lead the resume in your own words. Whether to apply with this gap is a separate question; the job-underwriter module is the one that answers it.

**What I assumed:** you gave me a description rather than your resume, so the "Current line" cells say "(not provided)". Every proposed line is built only from your sentences, quoted exactly.

### Edit ledger (each row needs your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | (not provided) | "Senior Data Analyst, 5 years in retail, moving into data engineering. Built and maintained about 25 dbt models, including the core orders mart. Designed the orders mart's star schema with our then-data engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics"; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E2 | Experience, bullet 1 | (not provided) | "Built and maintained about 25 dbt models, including the core orders mart" | `surface` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E3 | Experience, bullet 2 | (not provided) | "Designed the star schema for the orders mart with our then-data engineer" | `surface` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E4 | Experience, bullet 3 | (not provided) | "Fix the nightly dbt job when it breaks; added tests to it" | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E5 | Experience, bullet 4 | (not provided) | "Python scripts that pull vendor APIs on a cron; pandas for analysis" | `reorder` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E6 | Experience, bullet 5 | (not provided) | "SQL every day on Redshift: complex window functions and CTEs" | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E7 | Skills | (not provided) | "SQL (Redshift, window functions, CTEs) · dbt (models, tests) · Python (pandas) · cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I've fixed our nightly dbt job when it breaks and added tests to it."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

Why some rows are worded the way they are:
- **E3 keeps "with our then-data engineer".** Dropping it would turn shared design into sole design, and an interviewer would ask about it.
- **E4 says "fix… when it breaks", not "owned the pipeline" or "on-call".**
- **E5 puts the cron scripts before the analysis work.** That's the most engineering-like part of your Python. It still says "scripts", not "pipelines" or "production". C2 below could change that.
- **E1 says "about 25"**, not "25+".

### Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your title is analyst. The related work is in E2–E4. See G1 and C3. | `[grounded]` JD, your message |
| R2 | Production Python | must-have | `not_evidenced` | Analysis plus cron scripts. "Production" isn't established. See C2. | `[grounded]` JD, your message |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | You said you've never used Airflow. The nightly dbt job and cron are related, but whether either counts as "equivalent" is unknown. See C1. | `[grounded]` JD, your message |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E3. "Star schema" is the specific term screeners know, and it's your word. | `[grounded]` your message |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E2, E3 and E6. This covers one mart and its schema, not the whole warehouse. | `[grounded]` your message |
| R6 | Batch pipelines (Spark) | important | `not_evidenced` | Batch transforms in dbt are visible through E2. You said you've never used Spark. See G2. | `[grounded]` your message |
| R7 | Own data quality | important | `surfaced_by_edit` | E4: you added tests. That shows the work, not ownership. | `[grounded]` your message |
| R8 | Own SLAs | important | `not_evidenced` | Nothing you described says you were accountable for a deadline. See G3. | `[grounded]` your message |
| R9 | Partner with analytics on requirements | important | `not_evidenced` | You've been the analytics side, not the engineer partnering with it. See G4. | `[grounded]` your message |
| R10 | Streaming / Kafka | preferred | `not_evidenced` | You said you've never touched Kafka. See G2. | `[grounded]` JD, your message |

### Recovery per gap

**Recall prompts.** Each one's question is in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | A nightly dbt job you fix, and cron scripts. It doesn't show who scheduled them or what runs them. | The posting says "or equivalent". If something you configured counts, this must-have becomes a weaker match rather than a missing one. | You set up or changed the dbt Cloud schedule; you wrote crontab entries or chained jobs together; you added retries or failure alerts | The job config, crontab, or a run-history screenshot | `[grounded]` what your message does and doesn't say; `[generic]` how "or equivalent" is usually read |
| C2 | Production Python | must-have | Scripts that pull vendor APIs on a cron. It doesn't show whether anything depends on them. | Scripts that feed tables or dbt sources used by other people are closer to production than analysis notebooks are. | The scripts load Redshift tables that dbt reads; they're in git and get reviewed; they have error handling or alerting | Repo or file, a dbt sources file that points at their output | `[grounded]` what your message does and doesn't say; `[generic]` how hiring managers read "production" |
| C3 | 3+ years data engineering | must-have | 5 years as an analyst. It doesn't show how long the dbt and modelling work has run. | The years requirement won't be met, but "X years building dbt models" is a true, specific number a screener can weigh. | When you built the first dbt model; when the orders mart went live | Git history of the dbt project | `[grounded]` what your message does and doesn't say; `[generic]` how years requirements are screened |

**Named absences:**
- **G1. Data engineering years.** You haven't held a data engineering role, and the posting makes it a must-have. Closing it means holding that title somewhere. Analytics-engineer roles are the usual step, and your dbt work fits them directly. This gap won't close for this application.
- **G2. Spark and Kafka.** You've never used either. Kafka is only listed as a plus. Spark has no closure path for this application. A small public project would give you something real to talk about in an interview, but it isn't resume experience until it exists, and even then it's a project, not a job.
- **G3. SLAs.** Fixing a job when it breaks is not owning a deadline. If someone held you to "the mart is fresh by 7am", that would count, but you didn't say so. Bring it up only if it's true.
- **G4. Partnering with analytics.** Claiming you "partnered with analytics" would put you on the wrong side of the table in your own history. The true version, "I've been the person writing those requirements", is better said in a cover letter or interview than as a resume line. I've drafted no wording for it.

### Not written, and why

- **"Data Engineer" as a title, or "3+ years data engineering":** you haven't held the title or the years.
- **"Analytics Engineer" as a retitle:** your title was Senior Data Analyst. A retitle can clarify a title, not upgrade it.
- **"Production Python" or "built data pipelines":** your words are "scripting" and "on a cron". That stays true unless C2 says otherwise.
- **Airflow, Spark or Kafka anywhere, including a Skills list or "familiar with":** you said you've never used them. A listed tool reads as a tool you can use.
- **"Owned data quality and SLAs" or "on-call for pipelines":** E4 says what you did. Ownership is a different claim.
- **"Led dimensional modelling of the warehouse":** this would turn "with" into "led", and one mart into the whole warehouse.
- **Any reliability metric** (failure rate, runtime saved): you gave none.

### Parse-safety check

I couldn't run any of the file checks (columns, tables, headers and footers, images, file type) because I only have your description, not the document. The one thing I can say is to keep E7 under a standard "Skills" heading so a parser recognises it.

### Upgrade menu

- **Your actual resume text or file:** gives real "Current line" cells, possible cuts of analytics-only bullets, and the full parse check.
- **The dbt project (repo or screenshots of the docs/lineage):** for data engineering, the proof screeners actually check is code. It would back up E2–E4 rather than leave them as your word.
- **Answers to C1–C3:** each could turn a must-have from missing into a weaker match, with new rows.

### Questions

C1. What actually runs the nightly dbt job and the vendor-API scripts (plain cron, dbt Cloud's scheduler, something else), and did you set up or change any of it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2. Do the vendor-API scripts load data that something else depends on, like a Redshift table, a dbt source or a dashboard? Are they in version control?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3. Roughly when did you build your first dbt model, and when did the orders mart go live?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.