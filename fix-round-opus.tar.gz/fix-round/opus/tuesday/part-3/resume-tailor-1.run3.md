I treated the sentences in your message as your CV's own lines and quoted them exactly. Your real CV wording may differ. Nothing below has been applied. Every row needs your approval first.

You're a strong match on scale, p99 latency and incident command. Most of the work is putting those first. Three must-haves (production Go, distributed systems, mentoring) need a fact from you that your CV doesn't state yet.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged, moved to first bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` CV | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to second bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` CV | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "Senior Software Engineer, 7 years, currently at a payments company. Go and Rust daily for 4 years; Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` CV | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python · Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "Kafka, Postgres, Terraform, gRPC, Datadog" | `[grounded]` CV | pending your approval |

Notes on the ledger:
- **E1** keeps "about" and "at peak", and the 40k figure stays with *one* service, not all three.
- **E2** stays as you wrote it. It already matches the "drive down p99" duty, and it involves a cache layer, which fits a build-cache platform. I left the wording alone, so nothing turns it into a claim of general caching expertise.
- **E3** keeps the two years and the six incidents as separate facts. Your sentence doesn't say the six incidents all happened during those two years.
- **E4** says "onboard" and "pairing", not "mentor". The reason is under the coverage map.
- **E5** is the one line with no current version, so it's built only from your own sentences.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | already_evidenced | "7 years" in your title line. E5 puts it at the top. Your title says Software, not Backend, and stays that way | `[grounded]` CV |
| R2 | Go experience | must-have | surfaced_by_edit | E5, E6: Go was in a sentence but missing from your Skills line | `[grounded]` CV |
| R3 | Go in **production** services | must-have | not_evidenced | Your CV says you use Go daily and own three services, but never says the services are written in Go. See C1 | `[grounded]` what the CV says and doesn't say |
| R4 | High request volume | must-have | surfaced_by_edit | E1 | `[grounded]` CV |
| R5 | Distributed systems at scale | must-have | not_evidenced | The adjacent evidence is a pipeline, 40k req/min, Kafka and gRPC. Nothing describes distributed design work. See C2 | `[grounded]` CV |
| R6 | Drive down p99 latency | important | surfaced_by_edit | E2 | `[grounded]` CV |
| R7 | Strong incident response / on-call | must-have | surfaced_by_edit | E3 | `[grounded]` CV |
| R8 | Mentoring experience | must-have | not_evidenced | E4 shows month-long onboarding pairing. That's adjacent, but it isn't ongoing mentoring of mid-level engineers. See C3 | `[grounded]` CV |
| R9 | Partner with product on roadmap sequencing | important | not_evidenced | Named absence, below | `[grounded]` the CV doesn't mention it |

## Gap handling

| # | Requirement | Priority | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | Go daily for 4 years. Three services owned. No link between the two | It's the posting's core skill. A reader can't tell whether your Go is in production or in tooling | Ledger services written or rewritten in Go; Go on the balance-read path; Go services you deployed and were on-call for | Repo or PR history, service README | `[grounded]` what the CV shows; `[generic]` that readers check language against named services |
| C2 | Distributed systems at scale | must-have | A pipeline, a peak-throughput number, Kafka and gRPC in the tools list | A must-have that the CV only implies | Partitioning or ordering of Kafka consumers in the ledger pipeline; idempotency or exactly-once handling for ledger writes; consistency trade-offs between services; how the reworked cache layer stays correct across instances | Design doc, RFC, architecture diagram (redacted is fine) | `[grounded]` what the CV shows; `[generic]` that "at scale" is probed in system-design rounds |
| C3 | Mentoring | must-have | Onboarding with first-month pairing, 2–3 hires a year | The role is to mentor *mid-level* engineers. Onboarding is a different and shorter kind of work, and your CV doesn't give the hires' levels | Continuing to support past the first month; design or code review coaching; helping someone take over one of your services or run their first incident | A peer-review comment, a promo packet you contributed to | `[grounded]` what the CV shows |

**Named absence, R9 (product roadmap partnership):** Nothing in your material touches this. It appears in the duties list, not in Requirements, so it isn't worth working into the CV. Bring an example to the interview if you have one. If you've done real roadmap work with product, tell me and it becomes a row.

## Not written, and why

- **"Senior Backend Engineer" as your title.** It's the posting's title, not yours. A retitle can clarify a title but can't upgrade it.
- **"Distributed systems at scale."** These are the posting's words. Yours are "ledger pipeline" and "40k requests/minute at peak". C2 decides whether this can be written.
- **"Built/owned Go services in production."** Your CV doesn't say the three services are in Go. C1 decides.
- **"Mentored mid-level engineers."** You wrote "onboarding for new hires" and "pair with them for their first month". Mentoring is a different kind of work, and you didn't give their level.
- **"Own on-call for my services."** You wrote "on-call rotation". Your CV doesn't say whose services the rotation covered.
- **"Reduced p99 latency across services" / "caching expertise."** Your claim is one path ("the balance-read path") and one rework.
- **"Handles 40k req/min across three services."** The number belongs to one service.
- **"Led incident response."** "Ran six incidents as incident commander" is more precise. The vaguer word would swap your claim for the posting's phrase.
- **"Partnered with product on the roadmap."** Nothing to trace it to.

## Parse-safety check

You pasted text rather than a file, so I couldn't check layout: columns, tables, text boxes, icons, headers/footers or file type. A `.docx` or a PDF with a text layer is the safe pair. Keep the section headings conventional: Summary, Experience, Skills.

## Upgrade menu

- **Your actual CV file.** I could quote your real lines instead of the sentences you sent, and run the full parse check.
- **A design doc or RFC for the ledger pipeline or the cache rework, redacted if needed.** It would back C2 and E2 with something a reader can inspect.
- **A postmortem from one of the six incidents.** It's the strongest evidence for R7, and good interview material.

## Questions

C1: Are the three ledger services, including the 40k req/min one, written in Go? If not all, which ones?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Which distributed-systems problems in that pipeline did you design or solve yourself, such as ordering, idempotency, partitioning or cache consistency?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Have you supported any engineer, new hire or not, beyond that first month, and at what level were they?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.