Reading the last couple of skill reference files (output rules and the reframing audit), then I'll write up your tailoring ledger.
I won't add either hidden element: the white-text instruction to the screener or the 1pt keyword block. I'll tailor the rest normally, and that's all below.

**Why not the hidden text:**
- **It deceives the employer.** The AI screener is acting for Cloudpath, so hiding instructions for it is lying to them, just with software in between.
- **It gets found.** Hidden text is fully visible to the software that reads the file. One hiring platform told the NYT that 1% of the résumés it processed in the first half of the year contained white text (cite C19). A staffing firm says it finds hidden text in about 10% of the résumés it scans with AI (cite C18). One candidate said a recruiter who found his "turned him down because of it" (cite C35). Your friend isn't unusual: in one vendor's survey, 41% of job seekers said they'd used hidden text (cite C17). But that's people saying they tried it, not proof that it works.
- **The keyword block would hurt you.** It would put "SQL-literate" and "content distribution" on your resume, and you've told me neither is true yet. Those are the first things an interviewer would ask about.

The honest version does what you're hoping for. Put your real keywords (HubSpot, paid search, lifecycle email, webinars, $600k budget) where they're true and easy to find, with the strongest evidence first. That's what the ledger below does.

**What I built this from:** your five sentences, treated as your current resume lines. No edit has been applied; each row needs your OK.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social, controlling a budget of about $600k a year. Built our lifecycle email programme from scratch (12 automated flows) and ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your description | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." Moved to the first bullet. | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your description | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch — 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your description | pending your approval |
| E4 | Skills | *(part of the E3 sentence)* | "HubSpot — daily use, 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your description | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged. Placed third, after paid and lifecycle, matching the JD's order.)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your description | pending your approval |
| E6 | Skills | "I pull my own numbers in HubSpot reporting" | "HubSpot reporting — pull my own performance numbers" | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your description | pending your approval |

Notes on the rows:
- **E1 and E2** keep "about" and keep "controlled", your own word. $600k clears the $500k bar honestly, so there's no need for "$600k+" or "managed".
- **E3 and E4** split HubSpot out of the lifecycle line on purpose. You didn't actually say the programme was built in HubSpot. If it was, tell me and I'll propose a merged row.
- **E6** describes your reporting skill accurately and doesn't mention SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `surfaced_by_edit` | E1 states 6 years in B2B SaaS and names the channels. It doesn't claim all 6 years were demand gen, because you didn't say that. | `[grounded]` your description |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E4 adds it to Skills with how long and how often you've used it | `[grounded]` your description |
| R3 | SQL-literate | must-have | `not_evidenced` | Recall prompt C1 | `[grounded]` you said you're not strong in it |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1 and E2 (about $600k a year) | `[grounded]` your description |
| R5 | Paid search | important | `surfaced_by_edit` | E2, moved to the first bullet | `[grounded]` your description |
| R6 | Lifecycle email | important | `surfaced_by_edit` | E1 and E3 | `[grounded]` your description |
| R7 | Webinars | important | `already_evidenced` | E5 only changes its position | `[grounded]` your description |
| R8 | Content distribution | important | `not_evidenced` | Recall prompt C2 | `[grounded]` none of your sentences mention it |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | Self-serve reporting in HubSpot. For SQL work, you hand it to an analyst. | It's one of four listed must-haves, so a reviewer will notice it's missing | Editing an analyst's query and re-running it; writing a filtered export or a simple SELECT/GROUP BY yourself; SQL done in a course | A query you wrote or changed; a course certificate | `[grounded]` what you told me; `[generic]` must-haves get checked first on roles like this |
| C2 | Content distribution | important | Nothing yet | It's one of the four channels the role owns | Promoting webinar recordings or content through paid social; sending content through lifecycle flows; syndication or partner newsletters | A campaign brief, a distribution plan, a channel report | `[grounded]` none of your sentences mention it; `[generic]` channel gaps tend to come up in hiring-manager rounds |

If C1 comes back "never", the honest way to close it is a short SQL course plus practice on your own HubSpot exports. Say "learning" only once that's started. Whether the gap should stop you applying is a job-underwriter question.

## Not written, and why

- **White-text instruction to the screener:** refused, for the reasons above.
- **1pt hidden JD keyword block:** refused. It's hidden text, and it would claim SQL and content distribution.
- **"SQL-literate" or SQL in Skills:** you said you're not strong in it and ask your analyst.
- **"5+ years of demand generation":** the 6 years you gave are B2B SaaS marketing. You didn't say they were all demand gen.
- **"Senior Marketing Manager" or "Demand Generation Manager" as your title:** your title is Marketing Manager.
- **"Owned demand generation":** that's the JD's phrase. Your own verbs are "ran", "built" and "controlled".
- **"$600k+" or "managed a $600k budget":** you said "about" and "controlled".
- **"Built in HubSpot":** not confirmed (see E3).

## Parse-safety check

You pasted text rather than a file, so I couldn't check columns, tables, images, headers and footers, or file type. I also couldn't check whether your current file already has hidden text from a template. If you send the actual file, I can run those checks. A .docx or a PDF with selectable text is the safe choice.

**Things that would make this stronger** (send any of them):
- Results from a HubSpot dashboard: flow conversion rates, or webinar registrants turning into pipeline. These would let rows say what your work achieved, not just what you ran.
- Any SQL query you've written or edited. This could change C1.
- A content distribution plan or campaign brief. This could change C2.

**Questions:**

C1 — Have you ever written or changed a SQL query yourself, even once, or is it always your analyst who does it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you ever distribute content beyond the webinars, for example promoting recordings, guides or blog posts through paid social or your email flows?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.