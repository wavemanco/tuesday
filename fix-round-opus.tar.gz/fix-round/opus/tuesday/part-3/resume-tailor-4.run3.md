Still on your resume. I've read the tailoring rules and I'm checking one more section before I write up the edit list.
I couldn't open your PDF, so all of this is built from how you described your resume. Nothing below changes your resume until you approve it.

## Is it really the keyword matching?

Possibly, but probably not on its own. The only evidence I have is small: one résumé-builder company interviewed 25 US recruiters. Automatic rejection based on resume content was rare: "We only saw 2 of 25 using it." (cite C25). What did reject people without a human looking was the yes/no questions on the application form: "When automated filters are used, they’re almost always knockout questions" (cite C26). Where systems score resumes against the job, "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27). So keywords can affect where you sit in the queue. With 25 interviews, that's as far as the evidence goes.

*Sources: C25–C27 are all one article: Enhancv, "Does the ATS Reject Your Resume? 25 Recruiters Explain What Really Happens". Enhancv sells a resume builder, and calls its findings themes rather than representative statistics.*

Two other problems stand out more:

1. **Your file format.** A two-column Canva PDF with skill icons and contact details in the header is exactly the kind of file that resume software often reads badly (see the format check below).
2. **The tech stack.** Of the 15 requirements in the coverage map, only rows 1, 8, 10 and 12 are backed by anything you told me. No keyword change can honestly close the other 11. Adding them would get you past the software and then sink you on the first technical question.

If you want to weigh up whether this role is worth applying for at all, the job-underwriter module handles that.

## Edit ledger

Every proposed line quotes your own words as you wrote them in your message. I haven't seen your actual resume lines, so the "Current line" column is blank.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(not seen)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |
| E2 | Skills (plain text, no icons) | *(not seen; currently icons)* | "Cloud: AWS (EC2, S3, RDS, IAM) · Containers: Docker · CI/CD: Jenkins · Config management: Ansible · Monitoring: CloudWatch · Scripting: Python, Bash" | `reframe` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[inferred]` I chose the category labels; every tool is one you named. "CI/CD" names the category Jenkins belongs to and makes no claim about your pipeline. Reject it if you'd rather say "Build & deploy". | pending your approval |
| E3 | Experience | *(not seen)* | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E4 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — moved to first bullet of your current role, with E3 directly after it)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |

Three things to know about these rows:
- **E3 puts "Kubernetes" on your resume truthfully**, and the "never went to production" part stays. It goes in Experience, not in the E2 skills list. A bare "Kubernetes" in a skills list drops the part that keeps it honest.
- **E2 is the biggest keyword fix you can make.** If your skills exist only as icons, resume software may not see any of them.
- On the resume, replace "last year" in E3 with the actual year.

## Coverage map

The job post doesn't say which requirements are must-haves. I assigned priority based on the one stated responsibility ("own platform reliability and developer experience") and how many of the listed tools cluster around it.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | `surfaced_by_edit` | E3. A two-month proof-of-concept, never in production, and the line says so | `[grounded]` your description; `[inferred]` priority |
| 2 | AWS EKS | must-have | `not_evidenced` | You list AWS (EC2, S3, RDS, IAM) but not EKS. See C1 | `[grounded]` your description; `[inferred]` priority |
| 3 | Terraform | must-have | `not_evidenced` | Ansible is a configuration tool, not Terraform. See C2 | `[grounded]` your description; `[inferred]` priority |
| 4 | GitOps / ArgoCD | important | `not_evidenced` | Named absence N1 | `[grounded]` your description; `[inferred]` priority |
| 5 | Helm | important | `not_evidenced` | May be part of your Kubernetes proof-of-concept. See C1 | `[grounded]` your description; `[inferred]` priority |
| 6 | Istio / service mesh | preferred | `not_evidenced` | Named absence N2 | `[grounded]` your description; `[inferred]` priority |
| 7 | Prometheus / Grafana | important | `not_evidenced` | Named absence N3. C3 also asks about it | `[grounded]` your description; `[inferred]` priority |
| 8 | Monitoring (CloudWatch) | important | `surfaced_by_edit` | E2 | `[grounded]` your description |
| 9 | Vault | preferred | `not_evidenced` | Named absence N4 | `[grounded]` your description; `[inferred]` priority |
| 10 | CI/CD | must-have | `surfaced_by_edit` | E1, E2, E4 (Jenkins) | `[grounded]` your description |
| 11 | GitLab CI | important | `not_evidenced` | Named absence N5 | `[grounded]` your description; `[inferred]` priority |
| 12 | Python | important | `surfaced_by_edit` | E2. Scripting level, as you described it | `[grounded]` your description |
| 13 | Go | preferred | `not_evidenced` | Named absence N6 | `[grounded]` your description; `[inferred]` priority |
| 14 | SRE practices / platform reliability | must-have | `not_evidenced` | See C3 | `[grounded]` your description; `[inferred]` priority |
| 15 | Developer experience | important | `not_evidenced` | Depends on who used your deploy pipeline (see "What would help") | `[grounded]` your description; `[inferred]` priority |

## Gaps that a memory might close

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS, Helm | must-have | A two-month Kubernetes proof-of-concept, with no platform or tools named | EKS sits at the centre of this job's stack | The proof-of-concept ran on EKS; you installed or wrote Helm charts; you deployed one real service into it | The proof-of-concept repo, its manifests or charts, a write-up or demo notes | `[grounded]` what your description does and doesn't say; `[generic]` what a missing core-stack item costs on platform roles |
| C2 | Terraform | must-have | Ansible for configuration; nothing about provisioning infrastructure | It's one of the job's core tools, and Ansible is a different kind of work | Any Terraform or CloudFormation, even read-only or a single module; scripted provisioning of EC2 or RDS | A repo, a merged change, a module you maintained | `[grounded]` what your description does and doesn't say; `[generic]` cost on roles of this kind |
| C3 | SRE practices, platform reliability | must-have | CloudWatch monitoring, with no on-call or incident work mentioned | It's the job's one stated responsibility | On-call rotation, incident response or postmortems, alarms you designed, uptime targets, Prometheus anywhere | A postmortem, alarm or runbook docs, a dashboard | `[grounded]` what your description does and doesn't say; `[generic]` cost on roles of this kind |

## Gaps with nothing behind them yet

| # | Requirement | Gap | What would close it | Provenance |
|---|---|---|---|---|
| N1 | GitOps / ArgoCD | You've never mentioned using ArgoCD or a GitOps workflow | A public lab project that deploys to Kubernetes through ArgoCD from a git repo. It's small and shareable, and closes N1 together with C1 | `[generic]` |
| N2 | Istio / service mesh | No service mesh experience | It's listed among the tools, not as a must-have. Not worth closing just for this application; it's an interview topic to say "not yet" to honestly | `[generic]` |
| N3 | Prometheus / Grafana | You use CloudWatch, which is a different tool | Add Prometheus and Grafana to the same lab project, monitoring the service it deploys | `[generic]` |
| N4 | Vault | No secrets-management tool mentioned | It's in the tools list, not a must-have. Not worth closing just for this application | `[generic]` |
| N5 | GitLab CI | You use Jenkins | The ideas carry over, but you can't list GitLab without having used it. A GitLab CI pipeline in the lab project would close it | `[generic]` |
| N6 | Go | No Go mentioned | A realistic fix takes months, not one application. Leave it off and expect it to come up | `[generic]` |

## What I won't write, and why

- **"Platform Engineer" as your title.** You haven't held it, so your title stays "DevOps Engineer".
- **"Kubernetes" in the skills list, "production Kubernetes", or "deployed on EKS".** Your proof-of-concept never reached production, and nothing you've said places it on EKS.
- **Terraform, ArgoCD, Helm, Istio, Vault, Prometheus, Grafana, GitLab or Go anywhere.** You've given no evidence for any of them yet. C1–C3 can change that for some of them. Nothing else can.
- **"Observability" in place of your "monitoring".** It's the job post's word, not yours, and it describes broader work than CloudWatch monitoring.
- **"GitOps" or "platform" describing your Jenkins pipeline.** Same reason: the job post's vocabulary attached to your history.
- **"Infrastructure as code" for Ansible.** You wrote "config management", which is a different kind of work.
- **"Owned platform reliability" or "SRE".** Nothing you've told me supports it yet (see C3).

## File format check

I haven't inspected the file, so this is based only on your description.

| Check | What you described | What breaks | What it costs |
|---|---|---|---|
| Two columns | Two-column layout | Resume software reads across the page, mixing text from both columns line by line | Skills can end up in the middle of job entries; dates can separate from their roles |
| Icons | An icon for each skill | Icons turn into garbage characters or get skipped | Any skill shown only as an icon is invisible to the software. E2 deals with this |
| Header contents | Contact details in the header | Headers are often thrown away as page decoration | A recruiter may have no way to reach you |
| File type | A PDF exported from Canva | Software can only read a PDF that contains real text | Quick test: select all in the PDF, paste into a plain text editor, and check that the result is complete and in the right order. A .docx or a PDF with selectable text is the safe choice |
| Section headings, hidden text | Couldn't check | — | Paste the text or attach the file and I'll check both |

## What would help

- **Your actual resume text or file.** I could fill in the current lines, run a real format check, and look for hidden text left by the template.
- **Your Kubernetes proof-of-concept repo or notes.** That would firm up E3 and might close C1.
- **Who used your Jenkins deploy pipeline** (your team only, or other teams). That decides whether row 15, developer experience, has anything behind it.

## Three questions

C1: In the Kubernetes proof-of-concept, what did it run on (EKS or something else), did you use Helm, and what did you actually deploy?
C2: Have you written or changed any Terraform or CloudFormation, even a small amount?
C3: Have you been on call, handled incidents, or written postmortems, and did you ever use Prometheus or Grafana?

You can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.