I've built this from the sentences in your message and treated them as your CV's current lines, because the CV text itself wasn't pasted. Each "Traces to" cell quotes your message word for word. Nothing is applied yet: every row waits for your approval.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in our ledger pipeline at a payments company. Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline — one handles about 40k requests/minute at peak." *(second bullet; only "I" dropped)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year; pair with them for their first month." *(placed after the incident bullets)* | `reorder` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E7 | Skills | *(languages not in the skills list as described)* | "Languages: Go, Rust, Python" | `surface` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` your message | pending your approval |
| E8 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "gRPC, Kafka, Postgres, Datadog, Terraform" | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your message | pending your approval |

Notes on the choices:
- **E1:** "Go" and the services are kept in separate sentences. Your message doesn't say which language those services are written in (see C1).
- **E3:** "about" and "at peak" stay in. Those qualifiers keep the claim honest.
- **E4 and E5:** splitting the line doesn't attach the six incidents to the two-year window, because your sentence doesn't say they happened in it.
- **E6:** says "onboard", not "mentor", for the reason given under Not written below.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 shows 7 years as a Senior SWE. Your message doesn't say how much of that was backend, so the line says "7 years" and not "7 years backend". | `[grounded]` |
| R2 | Production Go: Go experience | must-have | `surfaced_by_edit` | E1 and E7: Go daily for 4 years | `[grounded]` |
| R3 | Production Go: Go on the services you own | must-have | `not_evidenced` | Recall prompt C1 | `[grounded]` |
| R4 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3 has three services and about 40k req/min at peak; E8 puts Kafka and gRPC first. The words "distributed systems" aren't used for your own work. | `[grounded]` |
| R5 | Strong incident response | must-have | `surfaced_by_edit` | E4 and E5 | `[grounded]` |
| R6 | Mentoring: onboarding new hires | must-have | `surfaced_by_edit` | E6 | `[grounded]` |
| R7 | Mentoring: mid-level engineers | must-have | `not_evidenced` | Recall prompt C2 | `[grounded]` |
| R8 | Drive down p99 latency | important | `surfaced_by_edit` | E2 (first bullet) and E1 | `[grounded]` |
| R9 | High request volume | important | `surfaced_by_edit` | E3 | `[grounded]` |
| R10 | Own on-call for your services | important | `surfaced_by_edit` | E5 shows the rotation. Your message doesn't say whether it covers your own three services. | `[grounded]` |
| R11 | Partner with product on roadmap sequencing | important | `not_evidenced` | Recall prompt C3 | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | Go and Rust daily for 4 years, and three owned services, but not which language those services are in | The JD's core work is "design and ship Go services handling high request volume". If your 40k req/min service is in Go, that's your strongest line for this role. | The 40k req/min service; the balance-read path; any Go service in the ledger pipeline | Repo or PR links (if shareable), a design doc | `[grounded]` what your message does and doesn't say; `[generic]` how screeners weigh "language used in production" against "language known" |
| C2 | Mentoring mid-level engineers | must-have | Onboarding and month-long pairing with new hires, which is a different group and a different kind of work from mentoring mid-levels | Mentoring is in both the responsibilities and the requirements | Regular design or code review for a mid-level engineer; helping someone get promoted; coaching someone through their first incident-commander shift | A promotion packet you contributed to, written feedback | `[grounded]` what your message says; `[generic]` how this reads on senior applications |
| C3 | Partner with product on roadmap sequencing | important | Nothing either way | It's a named responsibility, so an interviewer is likely to ask | Deciding with a PM whether the p99 work went before a feature; scoping the ledger services' roadmap; trade-off docs | A planning doc or roadmap proposal you wrote | `[grounded]` what your message says; `[generic]` what this costs at the senior level |

## Not written, and why

- **"Production Go services handling 40k requests/minute":** your message doesn't say the 40k service is in Go, so it could be Rust. C1 settles this.
- **"Built distributed systems at scale":** that's the JD's phrasing. Yours is "three services in our ledger pipeline" at "about 40k requests/minute at peak", and your phrasing is the one you can defend line by line.
- **"Mentored engineers" or "Mentored mid-level engineers":** you wrote "onboarding" and "pair with them for their first month". New hires aren't mid-levels, and onboarding isn't mentoring.
- **"Owned on-call for my services":** you described a rotation, not which services it covers.
- **"Partnered with product on roadmap":** nothing in your material supports it yet.
- **"Caching / build-cache experience":** you reworked one cache layer. That's a strong bullet, and it isn't platform experience.
- **"Senior Backend Engineer" as your title, or "7 years of Go":** your title is Senior Software Engineer, and you've used Go for 4 years.

## Parse-safety check

The resume came as a summary in chat, not as a file, so I couldn't check layout, columns, tables, headers and footers, images, section headings, file type or hidden text. If you share the file, I can run those checks.

## Upgrade menu

- **Paste the CV text itself.** I'll re-trace every row against your exact wording, not this summary.
- **A postmortem or design doc** (redacted is fine) for the p99 rework or one of the six incidents would raise E2 and E4 from self-report to inspectable evidence.
- **Optional extra, built only if you say yes:** an interview-ready version of each bullet (what was yours and what was the team's). It would help because the p99 and incident-commander lines are the ones most likely to be probed.

## Questions

C1 — Which language is the ~40k requests/minute service written in, and the balance-read path?
C2 — Beyond onboarding new hires, have you regularly mentored a mid-level engineer, for example through design reviews, code review or promotion support?
C3 — Have you worked with a product manager on what got built when, such as sequencing the p99 work against feature work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.