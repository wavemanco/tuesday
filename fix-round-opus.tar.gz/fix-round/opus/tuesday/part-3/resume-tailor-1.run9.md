**Built on one assumption:** you described your CV rather than pasting it, so the "Current line" column uses your description, not the CV's actual wording. Nothing here has been applied. Every row waits for your approval.

Your material covers this JD unusually well. The latency rewrite, the 40k requests/minute service, the on-call record and the six incidents as incident commander map almost one-to-one onto it. Most of the work is putting that evidence first. The other part is not letting the JD's wording ("design and ship Go services", "distributed systems at scale", "mentor mid-level engineers") slip into lines about your own history that your own sentences don't support yet.

## Requirements

| Tier | Requirement |
|---|---|
| Must-have | 5+ years backend; production Go; distributed systems at scale; strong incident response; experience mentoring |
| Important (responsibilities) | Design and ship Go services at high request volume; drive down p99 latency; own on-call for your services; mentor mid-level engineers; partner with product on roadmap sequencing |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (current role) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV, as you described it | pending your approval |
| E2 | Experience (current role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV, as you described it | pending your approval |
| E3 | Experience (current role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV, as you described it | pending your approval |
| E4 | Experience (current role) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year), pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV, as you described it | pending your approval |
| E5 | Experience (current role) | *(bullet order)* | Order: E1, E2, E3, E4 | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander."; "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV, as you described it | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" plus languages | "Go, Rust, Python · Kafka, gRPC, Postgres, Terraform, Datadog" | `reorder` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV, as you described it | pending your approval |
| E7 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years. Own three services in the ledger pipeline at a payments company; cut p99 on the balance-read path from 380ms to 95ms." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV, as you described it | pending your approval |

Notes on the rows:
- **E2 and E4 keep the qualifiers.** "About", "at peak", "usually" and "on my team" stay in. The qualifier is usually the honest part.
- **E7 avoids the JD's words.** It doesn't say "backend", "high-volume" or "distributed", because none of your sentences do. If the C1 and C2 questions below come back yes, it can gain them.
- **E6 only reorders.** Putting Go first and grouping Kafka and gRPC together makes you easier to find. It adds nothing new.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E7 states 7 years as a Senior Software Engineer. That all 7 were backend isn't in your sentences, so the line claims 7 years of engineering, not 7 years of backend. | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E6 and E7 put "Go and Rust daily for 4 years" up front. Whether the three ledger services are written in Go isn't stated (see C1). | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | 40k requests/minute is evidence of load. Kafka and gRPC appear only as listed tools, and a listed tool isn't a system you built. See C2. | `[grounded]` |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E3, moved up by E5 | `[grounded]` |
| R5 | Experience mentoring | must-have | `not_evidenced` | Onboarding new hires (E4) is real and adjacent. It isn't the same as mentoring mid-level engineers, and their level isn't stated. See C3. | `[grounded]` |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E1 and E7. One path, one result, stated exactly. | `[grounded]` |
| R7 | Own on-call for your services | important | `surfaced_by_edit` | E3. Whether the rotation covers your own services isn't stated, so the line says "on-call", not "on-call for my services". | `[grounded]` |
| R8 | Design and ship services at high request volume | important | `surfaced_by_edit` | E2 shows ownership and volume. "Designed" isn't in your sentences: owning a service and designing it are different claims. | `[grounded]` |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material touches this. See C4. | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | Go daily for 4 years. It doesn't say the services you own are written in Go. | It's the language of the job. If your services are Go, saying so is the strongest single line you can add. | The three ledger services; the balance-read cache rework; any Go service you took to production | A design doc, a PR history, a service README | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C2 | Distributed systems at scale | must-have | Kafka and gRPC listed, and one service at about 40k requests/minute at peak | It's a must-have, and today the resume only implies it | Services talking to each other over gRPC; Kafka consumers or producers in the ledger pipeline; horizontal scaling, partitioning, idempotency or exactly-once handling for ledger writes | An architecture diagram, a design doc, a postmortem | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C3 | Mentoring mid-level engineers | must-have | A month of pairing with two or three new hires a year | The JD names mid-level engineers specifically. Onboarding juniors and mentoring mid-levels read differently. | Design-review guidance; ongoing code-review coaching; helping someone lead their first project or first incident | A promotion packet you contributed to, a peer-review note | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C4 | Partner with product on roadmap | important | Nothing | Less likely to decide a screen than R1–R5, but likely to come up with a hiring manager | Sequencing ledger work against product launches; pushing back on a deadline with a technical-risk case; scoping a migration with a PM | A planning doc, a roadmap comment thread | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

I'm holding the C4 question for a later turn to stay within three questions.

## Not written, and why

- **"Designed and shipped Go services"**: you wrote "own", not "designed", and you didn't say what language the services are in. This one waits on C1.
- **"Built distributed systems at scale"**: Kafka and gRPC are listed tools. Owning a service that uses them is a different claim, and C2 is what would support it.
- **"Mentored mid-level engineers"**: you onboard new hires. Swapping the JD's word "mentor" for your "onboarding", and assuming a level, would be two changes inside one line you'll say out loud.
- **"Drove down p99 latency across services"**: you cut p99 on one path. That specific claim is stronger than the general one.
- **"Owned on-call for my services"** and **"Led incident response"**: you were on a rotation every fourth week and incident commander on six incidents. The JD's phrasing widens both.
- **"High-throughput" or "high request volume"**: the JD's words. "About 40k requests/minute at peak" is yours and is more checkable.
- **"Partnered with product on roadmap"**: nothing in your material supports it yet.

## Parse-safety check

Your CV arrived as a description, not a file, so I couldn't check layout: columns, tables, text boxes, header and footer placement, icons or skill bars, section headings, or file type. Paste the text or attach the file and I'll run them. Truthful keywords that are already in your material (Go, gRPC, Kafka, p99, incident commander, on-call) are placed early by E5–E7.

## Upgrade menu

- **Your actual CV text.** The "Current line" and "Traces to" cells would then quote the real document, not your summary of it.
- **A postmortem or design doc** for the cache rework or one of the incidents. In engineering, this is the kind of document that lets a reviewer check a claim. Redact anything confidential.
- **Optional extra I can do:** a short cover note, built only from rows you approve. A 180-person company is likely to read one.

## Questions

C1: Are the three ledger services you own written in Go, and did you design any of them or inherit them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: How do those services interact with each other and with the rest of the pipeline? For example, over gRPC between services, Kafka between stages, or multiple instances behind a load balancer.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Beyond the first-month pairing, have you guided more experienced engineers? For example, in design reviews, code reviews, or helping someone run their first incident.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.