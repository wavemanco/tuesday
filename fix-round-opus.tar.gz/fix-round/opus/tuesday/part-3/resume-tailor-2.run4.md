Reading the tailoring playbook's rules on structure; the ledger is coming next.
I can't rewrite this into a data engineering resume, and you shouldn't want me to. The posting's must-have is "3+ years data engineering". Your history is analytics, and every interviewer will ask about it. What I can do is put your strongest engineering-adjacent work first, in your own words: the dbt models, the star schema and keeping the nightly job running. The posting's tools you don't have get named as gaps, each with a way to close it. Missing years of experience don't automatically disqualify you, but here it's a real shortfall. Whether it's worth applying anyway is a separate question I can answer with the job-underwriter.

You sent background notes, not a resume file. I've treated each sentence as a line on your resume, and as something you say about yourself that an interviewer may probe.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail, moving into data engineering. Built and maintained about 25 dbt models including the core orders mart, and designed its star schema with our then-data engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your notes | pending your approval |
| E2 | Experience, bullet 1 | "Built and maintained about 25 dbt models including the core orders mart." | *(wording unchanged; moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your notes | pending your approval |
| E3 | Experience, bullet 2 | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your notes | pending your approval |
| E4 | Experience, bullet 3 | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke and added tests to it" | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your notes | pending your approval |
| E5 | Experience, bullet 4 | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis — pandas, some scripting to pull vendor APIs on a cron" | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your notes | pending your approval |
| E6 | Experience, bullet 5 | "SQL every day on Redshift, complex window functions and CTEs." | "SQL every day on Redshift — complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your notes | pending your approval |
| E7 | Skills | *(no current line)* | "SQL (Redshift) · dbt · Python (pandas) · cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your notes | pending your approval |

Some qualifiers are kept on purpose, because they're the honest part of each line:
- "about 25"
- "with our then-data engineer"
- "some scripting"

Dropping any of them would make the line claim more than you told me.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Named absence N1. Related work is in E1–E4, but your notes show no data engineering role. | `[grounded]` |
| R2 | Production Python | must-have | `not_evidenced` | Recall prompt C2. Your notes describe analysis plus "some scripting". | `[grounded]` |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | Recall prompt C1. Cron and the nightly dbt job are nearby; what schedules that job is unknown. | `[grounded]` |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E3 and E1. This covers one mart, designed jointly. | `[grounded]` |
| R5 | Build batch pipelines | important | `surfaced_by_edit` | E2 covers the dbt transformation layer. Pulling data in and owning a pipeline end to end aren't in your notes. | `[grounded]` |
| R6 | Own data quality | important | `surfaced_by_edit` | E4 (fixes and tests). "Own" isn't in your notes. | `[grounded]` |
| R7 | Own SLAs | important | `not_evidenced` | Named absence N2 | `[grounded]` |
| R8 | Partner with analytics on requirements | important | `not_evidenced` | Recall prompt C3 | `[grounded]` |
| R9 | Spark | important | `not_evidenced` | Named absence N3. You said: "Never used Airflow or Spark." | `[grounded]` |
| R10 | Streaming / Kafka | preferred | `not_evidenced` | Named absence N4. You said: "Never touched Kafka." | `[grounded]` |

## Gaps

**Recall prompts** (the questions are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | You fix and test the nightly dbt job and run scripts on cron. It doesn't say what triggers the job or who looks after the scheduling. | It's a must-have, and the posting says "or equivalent". | dbt Cloud jobs you set up or scheduled; cron schedules you wrote and kept running; retries or alerts you added; a scheduler someone else ran that you added tasks to | Your cron files or job settings; the dbt project's job setup | `[grounded]` what your notes say and don't; `[generic]` "or equivalent" is often read loosely for career changers |
| C2 | Production Python | must-have | Python for analysis plus "some scripting" to pull vendor APIs | It's a must-have, and "production" is the word that matters. | Vendor-API scripts others relied on every day; error handling, retries, logging; code review, tests, version control; how long they've run unattended | A repo or code sample, even with private parts removed | `[grounded]` what your notes say and don't; `[generic]` production Python is often probed with a code walkthrough |
| C3 | Partner with analytics on requirements | important | Nothing about defining requirements | You've been the analytics side asking a data engineer for things, which is useful here if it really happened. | Specs you wrote for the then-DE; deciding on the orders mart's grain or fields with the people who'd use it; turning stakeholder requests into dbt models | A spec doc, a ticket, a design note | `[grounded]` what your notes say and don't |

**Gaps with nothing in your notes to draw on:**
- **N1 — 3+ years of data engineering.** You haven't held a data engineering job. Wording can't fix that.
  - Closing it takes either pipeline ownership in your current job (the orders mart pipeline is the obvious candidate) or targeting analytics-engineer roles as a stepping stone.
  - Or apply anyway, knowing the hiring team may say no on this point alone.
- **N2 — SLAs.** Nothing says you were held to freshness or delivery targets.
  - Closing it: agree a freshness target for the nightly job at work and track it. That's realistic within a few months.
- **N3 — Spark.** You've never used it, and no wording changes that.
  - Closing it: a small public project, such as a batch job over a public dataset with a written explanation. That gives an interviewer something to look at, but it isn't work experience and mustn't be presented as such.
- **N4 — Kafka/streaming.** You've never touched it. It's listed as a plus, so it's the least important gap.
  - Closing it isn't worth doing for this application ahead of N1–N3.

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** You haven't held either title. Changing it would be the first thing a reference check catches.
- **"3+ years of data engineering experience."** Your notes say five years of analytics.
- **"Built and owned batch pipelines."** That's the posting's wording. You built dbt models, and "owned" is a step up from "fixed when it breaks".
- **"Owned data quality and SLAs."** You fixed the job and added tests. Ownership and SLAs aren't in your notes.
- **"Modelled the warehouse."** You designed one mart's star schema, together with someone else. Both the scope and the verb would grow.
- **Dropping "with our then-DE."** That would turn shared design work into sole design.
- **"Production Python."** This stays out unless C2 confirms it.
- **Airflow, Spark or Kafka in Skills**, even as "familiar with". You said "Never used" and "Never touched".
- **"Partnered with analytics."** You *are* analytics. This would flip which side of the relationship you were on, and C3 is the honest version.
- **"25 dbt models" without "about."** You gave an approximate number, so it stays approximate.

## Formatting check

You sent text, not a file, so I couldn't check columns, tables, headers and footers, images or file type. One thing I can see: use standard section headings ("Summary", "Experience", "Skills") so screening software sorts the content correctly. Send a .docx or PDF and I'll run the full check.

## What would improve this

- **Your actual resume file:** the full formatting check, plus your employer, dates and any lines your notes left out.
- **A repo or sample of the vendor-API scripts:** this could turn C2 from a claim into something you can show.
- **Your dbt project or job config:** something checkable behind E2–E4, and possibly an answer to C1.

## Questions

**C1:** What actually triggers the nightly dbt job: dbt Cloud, cron, or something another team runs? Did you set up or change that schedule yourself?

**C2:** Are any of the vendor-API scripts something other people depend on every day? Do they have error handling, retries or logging? Are they in version control?

**C3:** When you designed the orders mart with the then-DE, who decided its grain and fields? Did you write any specs or requirements for them?

You can answer in text, paste a voice transcript, attach a document, send a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.