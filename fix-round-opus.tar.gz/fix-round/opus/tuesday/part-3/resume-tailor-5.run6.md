I'm declining the hidden text, but the full tailoring is below.

## The hidden text: I won't add it

I won't put in the white-text instruction or the 1pt keyword block. Here's why:

- **It deceives the employer.** The screener is software working for them. Fooling it is fooling them, and that's hard to explain if an interviewer asks about it.
- **It gets found.** The software that reads your resume sees hidden text just as clearly as the visible text. One hiring platform told a newspaper that 1% of the resumes it processed in a half-year contained white text (cite C19). A large staffing firm said it finds hidden text in about 10% of the resumes it scans with AI (cite C18). One candidate said a recruiter who found his hidden prompt turned him down for it (cite C35). Your friend isn't alone: in a hiring-software vendor's survey, 41% of US job seekers said they had used hidden text (cite C17). That's why screeners now look for it.
- **The keyword block would hurt you on SQL.** It would put "SQL" on your resume when you've told me you're not strong in it. That gap is the one most likely to come up in an interview.
- **It's what the employer decides, not you.** You can't know whether being caught stays limited to this one application.

You also don't need it. The JD lists paid search, lifecycle email, webinars, HubSpot and a budget over $500k, and you can honestly claim all of them. The visible fix is to put those first, using your own words. One small vendor study found that match scores mostly decide who gets reviewed first, not who gets rejected (cite C27).

## Edit ledger

You sent a description rather than a resume, so there are no "current lines". Each row quotes the sentence of yours it comes from.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social on a budget I controlled of about $600k a year, and built our lifecycle email programme from scratch." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your description | pending your approval |
| E2 | Experience | *(no current line)* | "Ran paid search and paid social; controlled a budget of about $600k a year." | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your description | pending your approval |
| E3 | Experience | *(no current line)* | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your description | pending your approval |
| E4 | Skills | *(no current line)* | "HubSpot — daily use, 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your description | pending your approval |
| E5 | Experience | *(no current line)* | "Ran a monthly webinar series, averaging 300 registrants." | `reframe` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your description | pending your approval |
| E6 | Experience | *(no current line)* | "Pull my own performance numbers in HubSpot reporting." | `reframe` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your description | pending your approval |
| E7 | Experience | *(order of E2, E3, E5, E6)* | *(unchanged lines — ordered E2, E3, E5, E6, matching the JD's order with the budget first)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your description | pending your approval |

Notes on the rows:
- **E1 and E2** keep the budget tied to paid search and paid social. They don't turn it into a general "marketing budget". "About" stays in.
- **E3 and E4** are split because your sentence doesn't actually say the email programme was built in HubSpot. If it was, tell me and E3 can say so.
- **E5** says "registrants", not "attendees".
- **E6** drops the SQL half of your sentence. It doesn't claim SQL, and it doesn't advertise the gap either.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Paid search | must-have | `surfaced_by_edit` | E1, E2 | `[grounded]` your description |
| R2 | Lifecycle email | must-have | `surfaced_by_edit` | E1, E3 | `[grounded]` your description |
| R3 | Webinars | must-have | `surfaced_by_edit` | E5 | `[grounded]` your description |
| R4 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E4 | `[grounded]` your description |
| R5 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1, E2: about $600k a year, for paid search and paid social | `[grounded]` your description |
| R6 | 5+ years in B2B SaaS marketing | must-have | `surfaced_by_edit` | E1: 6 years B2B SaaS | `[grounded]` your description |
| R7 | 5+ years specifically in demand gen | must-have | `not_evidenced` | You haven't said how long the demand-gen work itself ran; recall prompt C1 | `[grounded]` what your description does and doesn't say |
| R8 | Content distribution | must-have | `not_evidenced` | Recall prompt C2 | `[grounded]` what your description does and doesn't say |
| R9 | SQL-literate | must-have | `not_evidenced` | Named gap G1 | `[grounded]` your own words: "I'm not strong in SQL" |

## Gap handling

**Recall prompts:**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years as Marketing Manager in B2B SaaS. It doesn't say how many of those years you spent on paid, lifecycle and webinar work. | A reader may take "6 years" to mean 6 years of demand gen. The resume shouldn't say that unless it's true. | Paid search from your first year; lead-gen campaigns before HubSpot arrived 4 years ago; an earlier email tool | Dates from a prior resume; an old campaign report | `[grounded]` what your description shows; `[generic]` how senior demand-gen screens read tenure |
| C2 | Content distribution | must-have | Nothing yet | It's one of the four things the role owns, and the only one you haven't mentioned | Promoting webinar recordings; paid social pushing gated content; repurposing content into the lifecycle flows; syndication or a newsletter | A campaign brief, a content calendar, distribution numbers | `[grounded]` absent from your description; `[generic]` what the requirement usually covers |

**Named gap:**

| # | Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|---|
| G1 | SQL-literate | You said you're not strong in SQL and ask your analyst. Nothing will be written that suggests otherwise. | Before interviews: a short SQL course, then writing a few of the queries you'd normally ask for, against your own data. After that you could truthfully say "basic SQL". Until then, have an honest answer ready: you pull your own HubSpot reporting and work with an analyst on queries. | `[grounded]` your own words; `[generic]` the closing path |

## Not written, and why

- **The hidden instruction and the 1pt keyword block.** Refused, for the reasons above.
- **"SQL" anywhere, including Skills.** You told me you're not strong in it.
- **"6 years of demand generation".** Your sentence says 6 years in B2B SaaS. C1 can change this.
- **"Managed a $600k marketing budget".** The budget you described covered paid search and paid social, not all of marketing.
- **"Owned demand generation" or "Led demand gen".** That's the JD's wording. You said "ran", and you haven't said you owned the whole function.
- **"300 attendees".** You said registrants.
- **"Content distribution".** Not in your material yet.
- **"Senior Marketing Manager" as your title.** That's the target role, not your current title.

## Parse-safety check

You pasted text rather than a file, so I couldn't check layout: columns, tables or text boxes, images, contact details in headers or footers, section headings, or file type. I also couldn't check whether your current PDF already contains hidden text from a template or an earlier tool. Send the file and I'll run both checks. A `.docx` or a PDF with a selectable text layer is the safe choice.

Whether the SQL gap is worth applying around is a separate decision, and the job-underwriter can help with that.

## What would strengthen this

- **Your current resume file:** lets me run the layout and hidden-text checks, and gives your real bullets to work from.
- **Campaign results** (cost per lead, pipeline, or MQLs from paid search and the lifecycle flows): the JD is about demand gen, and results are what senior demand-gen screens look for.
- **Webinar numbers beyond registrants** (attendance rate, leads sourced): would make E5 stronger.
- **Dates for each role:** these settle C1.

## Questions

C1: How many of your 6 years did you spend running paid search, lifecycle email or webinars, and what did you do before that?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Did you do any content distribution, such as promoting webinar recordings, paid social for gated content, syndication or newsletters? If so, what was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.