I've read the tailoring rules and here is the full set of proposed edits. You described your CV in prose and didn't paste its lines, so I've treated each of your sentences as the current wording and quoted them exactly. Nothing below is applied yet: you approve or reject each row, and I'll build the tailored CV from the approved ones only.

## Requirements (from the JD)

- **Must-have:** 5+ years backend · production Go · distributed systems at scale · strong incident response · experience mentoring
- **Important (from the duties):** owning services · Go services at high request volume · driving down p99 latency · on-call for your own services · partnering with product on roadmap order
- **Preferred:** build-cache / developer-tools background (not stated as a requirement)

## Proposed edits

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in a payments ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." *(second bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Incident commander on six incidents." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year), pairing with them for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E7 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Go, Rust, Python · Kafka, gRPC, Postgres · Terraform, Datadog" | `reorder` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your message | pending your approval |

Why these rows look the way they do:
- **E2 goes first** because it lines up most closely with the duty "drive down p99 latency". It also uses the word "cache", which is the platform's business. The figures stay as you wrote them, 380ms to 95ms, rather than being turned into a percentage.
- **E3 keeps "one", "about" and "at peak".** The 40k figure belongs to one service, not to all three.
- **E4/E5 split your on-call sentence** so the incident-commander record stands on its own line. Neither half says "strong" or "led incident response". "Strong incident response" is the JD's phrase, not yours.
- **E6 keeps your verb, "onboard",** and doesn't say "mentor". Pairing with new hires for a month may read as mentoring to a hiring manager, but that's their call to make, not a word to put in your mouth. "Usually" stays in.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `not_evidenced` | 7 years as a software engineer, but backend is only clearly shown for the Go/Rust years. Whether the Python years were backend isn't stated. Recall prompt C1 | `[grounded]` your message |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1, E7: Go daily for 4 years while owning production services. Which language the 40k service runs on is open (C2) | `[grounded]` your message |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3: three services in a pipeline, one at about 40k req/min peak. The phrase "distributed systems" is not written for you. Kafka and gRPC are listed, not shown in use | `[grounded]` your message |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E4, E5 | `[grounded]` your message |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E6 shows onboarding and pairing. Whether you work with mid-level engineers, the JD's target, isn't stated. Recall prompt C3 | `[grounded]` your message |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E2 | `[grounded]` your message |
| R7 | Own services / on-call for them | important | `surfaced_by_edit` | E3 for ownership. E5 says "on-call rotation", but not that the rotation covers your own services | `[grounded]` your message |
| R8 | Partner with product on roadmap sequencing | important | `not_evidenced` | Named absence below | `[grounded]` your message |
| R9 | Build-cache / developer-tools domain | preferred | `not_evidenced` | Named absence below. E2's cache-layer work is the nearest real point of contact | `[grounded]` your message |

## Gaps

**Recall prompts** (the questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | 7 years total. Backend is clear only for the Go/Rust period | `[grounded]` the JD lists it first among requirements. `[generic]` a years requirement is often the first thing a screener checks | Python APIs or services; data-pipeline jobs; internal backend tooling | Earlier job titles or a prior resume version | `[grounded]` what your message does and doesn't say; `[generic]` what this costs on applications of this kind |
| C2 | Production Go at high volume | must-have | Go and Rust together for 4 years. The language of the 40k-req/min service isn't stated | `[grounded]` the JD's first duty is "Go services handling high request volume" | The 40k service itself; the balance-read path; any of the three services | A repo link, a design doc, or just naming each service's language | `[grounded]` what your message does and doesn't say |
| C3 | Experience mentoring | must-have | Onboarding and month-long pairing with new hires | `[grounded]` the JD says "mentor mid-level engineers" | Ongoing 1:1s after the first month; code-review guidance; helping someone ship a service or take on-call | Anything a mentee or manager wrote down; an onboarding doc you authored | `[grounded]` what your message does and doesn't say |

**Named absences** (out of question budget, or nothing to pull):
- **R8, product partnership:** nothing you sent mentions working with product on how roadmap work is ordered. To close it you'd need a real example, such as agreeing the order of ledger work with a PM. If you have one, send it in a later turn and I'll write a row from it. If not, it's an "important" duty rather than a requirement, so leave it out of the CV.
- **R9, build-cache domain:** you haven't worked on build systems, and the JD doesn't ask for it. The only way to close it would be actual build-tooling work, which isn't worth chasing for this application. E2's cache work is the honest point of contact.

## Not written, and why

- **"Distributed systems at scale" as a line about you.** Your words are three services and about 40k req/min at peak, and those numbers make the case better than the label.
- **"Go services handling 40k requests/minute".** You haven't said that service is in Go (C2).
- **"Mentored engineers" / "mentored mid-level engineers".** Your word is onboarding, and the new hires' levels aren't stated. Swapping in the JD's word would claim a different kind of work.
- **"Owned on-call for my services".** You described a rotation, not its scope.
- **"Led incident response" / "strong incident response".** You ran six incidents as incident commander, and that's what gets written.
- **"Reduced p99 latency by 75%".** That's arithmetic on your numbers, not a figure you gave. 380ms to 95ms stays as written.
- **"Build-cache" or "developer-tools experience".** Your cache work was on a balance-read path.
- **Kafka or gRPC ownership/expertise.** A listed tool isn't a tool you own until you say how you used it.
- **"Partnered with product".** Nothing to trace it to.

## Parse-safety check

This came as pasted prose, not a file, so I couldn't check for multi-column layout, tables or text boxes, icons or skill bars, contact details in headers or footers, non-standard section headings, or file type. If you send the file (a .docx or text-layer PDF), I'll run all of them. One check I can make: "Go", "p99", "on-call" and "incident commander" appear in your own sentences, so these rows keep them as plain text where a keyword search would find them.

## What would sharpen this

- **Your actual CV text or file:** lets me quote your real current lines instead of your summary, and run the full parse check.
- **How Kafka and gRPC figure in your three services:** could turn R3 from scale-only evidence into evidence of how the system is built.
- **A postmortem or design doc** for the p99 work or one of the six incidents: a document someone could read, which is the strongest kind of proof in backend engineering.
- **A product-ordering example:** the only thing that could close R8.

## Questions

C1. Was the work before Go and Rust (the Python years) backend services, and roughly how long was that?
C2. Which language is the service handling about 40k requests/minute written in, and the other two?
C3. Beyond the first month of pairing, do you keep supporting the people you onboard, and are any of them mid-level rather than new grads?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.