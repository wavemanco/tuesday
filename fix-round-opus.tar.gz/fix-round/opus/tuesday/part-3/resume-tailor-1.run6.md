I've drafted the tailoring as a list of proposed edits (E1–E6) for you to approve or reject one by one. Nothing has been applied to your CV yet.

You sent a summary of your CV rather than the CV itself. Every proposed line below is built only from the eight sentences you wrote, and each row quotes the sentence it comes from. I haven't seen your current CV wording, so the "Current line" column says *not seen*.

## Proposed edits

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *not seen* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in a payments company's ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your description | pending your approval |
| E2 | Experience | *not seen* | "Own three services in the ledger pipeline — one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your description | pending your approval |
| E3 | Experience | *not seen* | "On call every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your description | pending your approval |
| E4 | Experience | *not seen* | "Onboard new hires on the team — usually two or three a year — pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your description | pending your approval |
| E5 | Experience | *not seen* | *(bullet order: p99 → services → incidents → onboarding)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander."; "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your description | pending your approval |
| E6 | Skills | *not seen* | "Go, Rust, Python · gRPC, Kafka, Postgres, Terraform, Datadog" | `reorder` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your description | pending your approval |

Notes on the edits:
- **E2:** "about", "at peak" and "one" stay in. The 40k figure belongs to one service, not all three.
- **E3:** "Incident commander" is your own phrase, so it stays.
- **E4:** This line doesn't say "mentor". The coverage map below explains why.
- **E5:** The p99 line goes first, word for word, because driving down p99 latency is one of the job's named responsibilities.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `surfaced_by_edit` | E1 puts "7 years" and your languages first. Your material only shows backend work for your current role; whether the Python years were backend is question C1 | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 and E6 put Go first and show daily use. Which of your three services are written in Go is not stated (question C2) | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E2 shows a three-service pipeline and about 40k requests/minute at peak. The phrase "distributed systems" is not written as your claim | `[grounded]` |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E3 | `[grounded]` |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E4 shows onboarding and pairing. Whether you've mentored beyond the first month is question C3 | `[grounded]` |
| R6 | Drive down p99 latency | important | `already_evidenced` | Supported as written; E5 moves it to the top | `[grounded]` |
| R7 | Own services handling high request volume | important | `already_evidenced` | Supported as written; E2 tightens it | `[grounded]` |
| R8 | Own on-call for your services | important | `surfaced_by_edit` | E3. Your description doesn't say whether the rotation covers your own services | `[grounded]` |
| R9 | Mentor mid-level engineers | important | `not_evidenced` | Question C3 | `[grounded]` |
| R10 | Partner with product on roadmap sequencing | important | `not_evidenced` | Named absence, below | `[grounded]` |

## Gaps to close

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | 7 years as an engineer; Go and Rust for 4, Python before that. Only the current role is clearly backend | It's the first requirement listed | Python APIs or workers; batch or data pipelines; an earlier backend role | Earlier CV versions; job titles and dates | `[grounded]` what you wrote; `[generic]` years requirements are often checked first |
| C2 | Production Go | must-have | Daily Go and Rust; three services you own, language not stated | The role is "design and ship Go services" | One of the ledger services in Go; the balance-read cache work in Go; Go tooling you shipped | Repos or PRs; service READMEs | `[grounded]` what you wrote; `[generic]` language-specific roles often probe which code was yours |
| C3 | Mentoring, mid-level engineers | must-have | Onboarding two or three new hires a year, with first-month pairing | The job names mentoring mid-level engineers | Ongoing 1:1s after onboarding; design-review coaching; helping someone level up | A promotion packet you contributed to; review threads | `[grounded]` what you wrote; `[generic]` onboarding and mentoring are often weighed differently |

**R10, working with product on roadmap sequencing (no evidence).** Nothing you sent mentions product or roadmap work. Closing this gap would take one real example: for instance, if you sequenced the cache rework against other priorities together with a PM. If you have no such example, leave this one off. It's listed as a responsibility of the role, not as a requirement.

## Not written, and why

- **"7 years of backend experience"**: you said "Senior Software Engineer, 7 years", not that all seven were backend.
- **"Designed and built Go services"**: you wrote "own", and the services' language isn't stated. Upgrading "own" to "designed and built" changes what you're claiming.
- **"Distributed systems at scale"**: this is the job description's wording, not yours. What you have is one service at about 40k requests/minute and a three-service pipeline.
- **"Mentored engineers"**: what you described is onboarding and first-month pairing, which is a different activity from mentoring.
- **"Led incident response" / "Owned on-call"**: you were in a one-week-in-four rotation and were incident commander for six incidents. "Incident commander" stays because it's your phrase.
- **Kafka, Postgres, Terraform at scale**: these are tools your CV lists. A listed tool isn't a tool you own.
- **"Reduced p99 by 75%"**: 380ms → 95ms is your own figure, and it's more checkable than a percentage.
- **Build-cache or developer-tools experience**: nothing you sent mentions it.

## Machine-readability check

You pasted a description, not the file. I couldn't check columns, tables, headers or footers, icons, section headings or file type. The job's main keywords (Go, p99, on-call, incident, services) already appear in your own sentences, so no keyword needs adding.

## What would make this stronger

- **Your actual CV text or file:** the "Current line" column would then show your real wording, and I could run the machine-readability check.
- **A design doc, PR or latency dashboard for the p99 work:** this is the proof engineering interviewers usually ask about.
- **A postmortem you wrote as incident commander:** it backs up the incident-response line.
- **One example of planning work with product:** it would turn R10 into a real edit.

## Questions

C1. Were the years you worked in Python building backend services? If so, what kind?
C2. Which of your three ledger services are written in Go, and was the balance-read cache work in Go?
C3. Beyond first-month pairing, have you kept mentoring anyone? Were any of your new hires mid-level?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.