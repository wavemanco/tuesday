I won't add the hidden instructions or the 1pt keyword block. I've tailored everything else below.

**Why not the hidden text.** It's aimed at software screening on the employer's behalf, so it's deceiving the employer. It also gets found, because the parser reads the same text a screener does. One platform told the NYT that "1% of the resumes it processed in the first half of the year contained white text messages" (cite C19). One candidate said "One recruiter discovered the prompt hacking and turned him down because of it" (cite C35). What happens after that is up to Cloudpath, not you.

**Where your friend's premise is off.** In one small vendor sample of 25 US recruiters, content-based auto-rejection was rare: "We only saw 2 of 25 using it" (cite C25). Most automated rejection came from "knockout questions" on the application form (cite C26), not from keyword counts. Match scores mostly decide "who gets reviewed first" (cite C27).

**What does the keyword job honestly.** Your own background already uses most of the posting's words: paid search, lifecycle email, webinars, HubSpot and a budget figure. So the honest fix is to place those words early and plainly, which the ledger does. The one keyword you can't honestly use is SQL.

*Assumption:* your background is the only source. I've read it as self-reported, five sentences, quoted exactly.

## Edit ledger — `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E3 | Skills | *(no current line)* | "HubSpot (daily use, 4 years)" | `surface` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series, averaging 300 registrants." | `reframe` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your background | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |
| E6 | Experience | "but I'm not strong in SQL — I ask our analyst." | *(removed from the resume)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |
| E7 | Experience | *(bullet order)* | E1, then E2, E4, E5, in the posting's order: paid search and budget, lifecycle email, webinars, reporting | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |
| E8 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social with a budget of about $600k a year. Built our lifecycle email programme from scratch: 12 automated flows." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |

Notes on the rows:
- **E1 and E8** keep "controlled" and "about". They don't use the posting's word "managed", and they don't write "$600k+".
- **E2** keeps "our".
- **E4** says "registrants", not "attendees", so the 300 stays attached to what you actually counted.
- **E6** only removes a statement about a weakness; it adds no claim. Expect to be asked about SQL in interviews, and answer it the way you told me.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `already_evidenced` | "6 years B2B SaaS" meets the length. No line labels the work "demand generation", because you never called it that; the channels in E1, E2 and E4 show the work. | `[grounded]` your background |
| R2 | HubSpot or Marketo | must-have | `surfaced_by_edit` | E3 puts it in Skills; E2 and E5 keep it in Experience | `[grounded]` your background |
| R3 | Managed a budget over $500k | must-have | `surfaced_by_edit` | E1, placed first by E7; about $600k a year | `[grounded]` your background |
| R4 | SQL-literate | must-have | `not_evidenced` | Recovery row C1 | `[grounded]` your own words: "not strong in SQL" |
| R5 | Paid search | core duty | `surfaced_by_edit` | E1, first bullet | `[grounded]` your background |
| R6 | Lifecycle email | core duty | `surfaced_by_edit` | E2 | `[grounded]` your background |
| R7 | Webinars | core duty | `already_evidenced` | E4 only adjusts wording | `[grounded]` your background |
| R8 | Content distribution | core duty | `not_evidenced` | Recovery row C2 | `[grounded]` nothing in your background mentions it |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | SQL-literate | must-have | You report in HubSpot and ask an analyst for SQL work. "Not strong" may still mean some SQL. | It's a listed requirement, and an interviewer can test it in one question. If nothing turns up, the way to close it is a few weeks of real practice: write queries against your own campaign or CRM data until you can do joins and group-bys without help. | Editing or rerunning a query your analyst wrote; filtering a data-warehouse table yourself; writing a SELECT in a BI tool such as Looker or Metabase | A query you wrote; a dashboard you built on SQL | `[grounded]` what you said; `[generic]` how screens test listed technical requirements |
| C2 | Content distribution | core duty | Nothing in your background covers distributing content | It's one of the four named duties, and the only one with no evidence | Promoting webinar recordings by email or paid social; syndicating gated content; running promoted posts for assets | A distribution calendar; a campaign report | `[grounded]` what your background does and does not say; `[generic]` how duty lists are read |

## Not written, and why

- **Hidden white-text instructions to the screener.** You asked for this and I refused it, for the reasons at the top.
- **A 1pt hidden block of the posting's keywords.** Refused for the same reasons. The truthful keywords are in E1–E5, in plain sight.
- **"SQL-literate" or "SQL" anywhere.** By your own words, the evidence isn't there yet.
- **"Demand generation" as a label for your history.** It's the posting's term, not yours. Your channels show the work without it.
- **"Managed a budget over $500k".** Your word was "controlled" and your figure was "about $600k". I kept both.
- **"Owned demand gen" or "led".** Neither appears in what you wrote.
- **"Senior Marketing Manager" as a title.** That would be a title upgrade. Your title stays Marketing Manager.
- **"Marketo".** You didn't mention it.
- **"300 attendees".** You counted registrants.

## Parse-safety check

You pasted text, not a file. That means I couldn't check columns, tables, text boxes, headers and footers, section headings or file type. I also couldn't check whether a template or an earlier tool left hidden text in your current file. If you send the file, those checks can run.

## Upgrade menu

- **Your actual resume file (.docx or PDF):** runs the full parse-safety check, including for hidden text you didn't put there, and gives the ledger your real current lines plus employer names and dates.
- **A HubSpot workflow list or a lifecycle performance summary:** backs up the 12 flows, and could add an outcome to E2 if it holds one.
- **A webinar registration report:** backs up the 300 average.

Whether the SQL gap makes this role worth applying to is a question for job-underwriter.

## Questions

C1: Have you ever written or edited a SQL query yourself, even a simple one, or is it always the analyst?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Did you distribute content beyond the webinars, for example promoting recordings, gated assets or blog posts through email or paid channels?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.