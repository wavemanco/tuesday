Quick status: I've read the tailoring playbook. Now I'm checking the citation entries behind the screening claims before I write your ledger.
Sam, keyword matching is probably not the main reason you're being rejected. I've still done the full tailoring below. Two things matter more.

**1. The ATS probably isn't auto-rejecting you on keywords.** The only evidence I have is one small study: a résumé-builder company (which has an interest in this topic) interviewed 25 US recruiters.
- **Keyword auto-rejection is rare in that sample.** Only "AI/content auto-rejection configured: 8% of recruiters", which is 2 of the 25 (cite C25).
- **Most automatic rejections come from the application form.** "When automated filters are used, they're almost always knockout questions", meaning yes/no checks like work authorisation, required licence or location (cite C26). Your resume doesn't affect those.
- **Match scores mostly decide who gets read first.** "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). The study talks about match scores, not keywords, so the idea that keywords drive the score is an assumption.

So it's worth putting the right keywords in, but only where they're true.

**2. Your PDF layout is a bigger risk than your wording** (see the parse check at the end). Also, the coverage map below shows most of this posting's core tools aren't in your background yet. That can't be fixed with keywords, and the gap section says so plainly.

What I'm working from: you didn't paste the resume text, so I used the four sentences you wrote in your message. Each one is quoted exactly in the "Traces to" column. The "Current line" column is blank because I can't see the PDF. I also had to guess the priorities, because the posting is just a list of tools. I treated the tools named first, plus "own platform reliability", as must-haves.

---

## What you can truthfully claim

| Source sentence (yours) | What it supports |
|---|---|
| "DevOps Engineer, 4 years." | Title, tenure |
| "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | Tools you've used. It doesn't say how deep, apart from the qualifiers you wrote ("scripting", "for config management", "for monitoring") |
| "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | You built a deploy pipeline and you maintain about 30 jobs |
| "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | Kubernetes, as a 2-month PoC only |

## Proposed edits (`resume_edits_pending_approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(not visible)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E2 | Experience | *(not visible)* | "Ran a Kubernetes proof-of-concept for two months — never went to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E3 | Skills | *(icon column)* | "Cloud: AWS (EC2, S3, RDS, IAM) · Containers: Docker; Kubernetes (two-month proof-of-concept) · Build & deploy: Jenkins · Config management: Ansible · Monitoring: CloudWatch · Scripting: Python, Bash" | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E4 | Experience | *(not visible)* | *(unchanged: the Kubernetes PoC bullet (E2) moves directly under the Jenkins pipeline bullet, above the other bullets)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |

Why they're written this way:
- **E2 and E3 keep "proof-of-concept" and "two months".** The keyword "Kubernetes" becomes visible to a screener, and an interviewer won't be surprised by it.
- **E3 uses plain-text skill groups instead of icons.** Icons often don't come through as text when software reads the PDF (see the parse check). Python stays labelled "Scripting" because that's the word you used.
- **E4 only changes the order.** One study found that language models pay most attention to what comes at the start or end of a long text (cite C28). Whether that applies to resume screening is an assumption, but a reader who stops early still sees your most relevant work.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes (any hands-on use) | must-have | `surfaced_by_edit` | E2, E3, E4. PoC only | `[grounded]` |
| R2 | Kubernetes in production | must-have | `not_evidenced` | Recall prompt C1 | `[grounded]` |
| R3 | AWS EKS | important | `not_evidenced` | AWS is covered but EKS isn't; recall prompt C1 | `[grounded]` |
| R4 | Helm | important | `not_evidenced` | Recall prompt C1 | `[grounded]` |
| R5 | Terraform | must-have | `not_evidenced` | Recall prompt C3. Ansible is related but does a different job | `[grounded]` |
| R6 | CI/CD pipelines | important | `surfaced_by_edit` | E1. Jenkins deploy pipeline | `[grounded]` |
| R7 | GitLab CI | important | `not_evidenced` | Named absence | `[grounded]` |
| R8 | ArgoCD / GitOps | must-have | `not_evidenced` | Named absence | `[grounded]` |
| R9 | Istio / service mesh | important | `not_evidenced` | Named absence | `[grounded]` |
| R10 | Prometheus / Grafana / observability | must-have | `not_evidenced` | Named absence. CloudWatch is related but different | `[grounded]` |
| R11 | Vault | important | `not_evidenced` | Named absence. IAM is a different tool | `[grounded]` |
| R12 | Python | important | `surfaced_by_edit` | E3, as scripting | `[grounded]` |
| R13 | Go | preferred | `not_evidenced` | Named absence | `[grounded]` |
| R14 | SRE practices / owning platform reliability | must-have | `not_evidenced` | Recall prompt C2 | `[grounded]` |
| R15 | Developer experience | important | `not_evidenced` | Recall prompt C2 | `[grounded]` |

Only R1, R6 and R12 can be covered from what you've told me. Every other row is `not_evidenced`.

## Gaps that might close with more detail from you

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes in production, EKS, Helm | must-have | A two-month PoC that never went to production. It doesn't say where it ran or what tools it used | The whole platform is built on these, so a hiring manager will likely ask about this first | The PoC ran on EKS rather than minikube or kind; you wrote or installed Helm charts; you moved a real service onto it, even if it never shipped | PoC write-up, repo, chart files, a demo | `[grounded]` what you said; `[generic]` that Kubernetes depth gets probed first for platform roles |
| C2 | SRE practices, platform reliability, developer experience | must-have | You maintain about 30 Jenkins jobs. Nothing about on-call, incidents, uptime, or who uses what you build | "Own platform reliability and developer experience" is how the posting describes the job | You're on call for the pipeline; you've fixed broken builds for other teams; you set up alerts in CloudWatch; developers use your jobs themselves | Incident notes, a runbook, an internal docs page | `[grounded]` what you said; `[generic]` that ownership language gets tested in interviews |
| C3 | Terraform / infrastructure as code | must-have | Ansible "for config management". Nothing about provisioning infrastructure | It's one of the first tools listed | Terraform, CloudFormation or CDK for any AWS resource, at work or on a personal project | A repo, module or pull request | `[grounded]` what you said; `[generic]` how central IaC is to platform roles |

## Gaps with nothing to draw on

- **ArgoCD / GitOps:** you haven't mentioned using either. To close it, deploy something to a cluster with ArgoCD from a Git repo and write it up. That's a few weekends of personal-project work, not a resume line.
- **Istio / service mesh:** not mentioned. This is the least worth closing for a first application. Learn the concepts well enough to discuss them, and don't claim it.
- **Prometheus / Grafana:** CloudWatch is a different tool. To close it, run Prometheus and Grafana on your PoC cluster or a home lab, with real dashboards and alerts.
- **Vault:** not mentioned, and IAM isn't the same thing. You'd need to actually use Vault for secrets, for example on a home lab.
- **GitLab CI:** you use Jenkins. You could port one of your Jenkins pipelines to GitLab CI in a personal repo. Until then, the resume says Jenkins.
- **Go:** not mentioned, and it's listed last. A small Go command-line tool or Kubernetes operator in a repo would close it. It's not urgent compared with R2, R5 and R8.

## Not written, and why

- **"Production Kubernetes" or "Kubernetes experience" without the PoC qualifier.** You said it "never went to production". Removing that turns a prototype into a production claim, and an interviewer will find out with one question.
- **"CI/CD pipeline" in place of "deploy pipeline".** "CI/CD" is the posting's word. You wrote "deploy pipeline", and CI means automated builds and tests, which you haven't mentioned. If your pipeline does that, answer C2 or C3 and I'll redo the row.
- **"Observability" for CloudWatch.** You wrote "CloudWatch for monitoring". "Observability" is the posting's word for a wider practice (metrics, logs, traces) built on different tools.
- **"Infrastructure as code" for Ansible.** You wrote "for config management". Configuring servers isn't the same work as provisioning infrastructure.
- **"Owned platform reliability".** You maintain jobs. Ownership and reliability haven't come up in anything you've told me.
- **A skills list stuffed with the posting's tools (Terraform, ArgoCD, Istio, Vault, Helm, Go).** None of them come from your background. Listing them would put lines on your resume that you can't defend.

## Parse check (things that break automated reading)

This is based on your description. I haven't seen the file.

| Check | Your resume | What breaks | What it costs |
|---|---|---|---|
| Multi-column layout | Two-column Canva PDF | Parsers read straight across the page, mixing the two columns | Lines from both columns get jumbled, and dates can end up next to the wrong jobs |
| Images and icons | An icon for each skill | Icons come out as garbage characters or get skipped | If a skill name lives only in or beside an icon, it may never reach the ATS. That works against exactly the keyword matching you're worried about |
| Header content | Contact details in the header | Headers can be thrown away as page decoration | Recruiters may be unable to contact you |
| Hidden text | Couldn't check | I can't open the file | Canva templates sometimes include placeholder text. If you send the file, I can check |
| File type | PDF | It's safe if the text can be selected | Check you can highlight and copy all the text. A `.docx` is the other safe option |

I'm reporting these risks, not redesigning your resume. The layout is your call. These are the places where your real experience could get lost before anyone reads it.

Whether this role is worth applying for, given the gaps above, is what job-underwriter decides.

---

**What I can add if you want** (optional): if you'd like a role this resume already covers well to compare against, I can do the same tailoring for a plain "DevOps Engineer (AWS/Jenkins)" posting you paste. It would show how much of the rejection pattern comes from fit rather than keywords.

**Questions:**

C1: What did the Kubernetes PoC actually involve: was it on EKS, did you use Helm, what did you deploy, and why did it stop?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Do you handle on-call or incidents for the pipeline or infrastructure, and who runs the 30 Jenkins jobs: you, or developers on other teams?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Have you ever created AWS resources with Terraform, CloudFormation or CDK, at work or on your own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.