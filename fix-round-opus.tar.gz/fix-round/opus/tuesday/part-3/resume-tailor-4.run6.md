Let me read the referenced files.
I'm treating your description as the resume's content. I haven't seen the PDF, so every edit below quotes your own words from this message, and you should check each one against what the resume actually says.

**First, the keyword theory.** The best evidence I have says ATS software usually doesn't silently reject resumes for missing keywords. In one small study (a resume-builder company interviewed 25 US recruiters), only 2 had content-based auto-rejection switched on (cite C25). When those recruiters did use automated filters, they were "almost always knockout questions" (cite C26). Those are the yes/no questions on the application form, like work authorization or location. Match scores were mostly used "to prioritize who gets reviewed first" (cite C27). That sample is too small to settle the question. But it suggests your problem is more likely one of two things:

1. **A layout risk.** A two-column layout with skill icons could mean the software never reads your real keywords at all. See the parse-safety check.
2. **A real gap.** Most of this posting's toolset isn't in your experience. Rewording can't fix that, and I won't write around it.

Whether the role is worth applying for, given those gaps, is a question for the job-underwriter module.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(resume not seen)* | "Cloud: AWS (EC2, S3, RDS, IAM)" / "Containers: Docker" / "Configuration management: Ansible" / "Monitoring: CloudWatch" / "Scripting: Python, Bash", as plain text, one per line | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E2 | Skills | *(resume not seen)* | "CI/CD: Jenkins" | `reframe` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[inferred]` from Jenkins being a CI/CD server; the label "CI/CD" is my word, not yours | pending your approval |
| E3 | Skills | *(resume not seen)* | "Kubernetes (two-month proof-of-concept; not run in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E4 | Experience | *(resume not seen)* | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." moved to first bullet | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E5 | Experience | *(resume not seen)* | "Ran a Kubernetes proof-of-concept for two months last year; it did not go to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E6 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E3 and E5 keep "not run in production" deliberately.** That qualifier is what makes the line safe to defend in an interview.
- **In E5, swap "last year" for the actual year.** I won't guess it.
- **In E6, "about 30" stays attached to "Jenkins jobs".** It doesn't become "30 pipelines" or "30 services".

## Coverage map

The posting doesn't rank its requirements. The priorities below are my reading of it.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | `surfaced_by_edit` | E3, E5: PoC only, labelled as such; production experience is still not shown | `[grounded]` |
| R2 | AWS EKS | must-have | `not_evidenced` | AWS breadth is shown (E1), EKS is not; recall prompt C1 | `[grounded]` |
| R3 | Terraform | must-have | `not_evidenced` | Ansible is config management, not provisioning; recall prompt C2 | `[grounded]` |
| R4 | GitOps / ArgoCD | must-have | `not_evidenced` | Named absence below | `[grounded]` |
| R5 | Observability (Prometheus, Grafana) | must-have | `not_evidenced` | CloudWatch monitoring is adjacent and kept in your words (E1); named absence below | `[grounded]` |
| R6 | CI/CD | must-have | `surfaced_by_edit` | E2, E4, E6: Jenkins pipeline plus about 30 jobs | `[grounded]` |
| R7 | GitLab CI | important | `not_evidenced` | Named absence below | `[grounded]` |
| R8 | Python | must-have | `already_evidenced` | "Python scripting": E1 keeps it as plain text so it can be parsed | `[grounded]` |
| R9 | Go | important | `not_evidenced` | Named absence below | `[grounded]` |
| R10 | Helm | important | `not_evidenced` | Folded into recall prompt C1 | `[grounded]` |
| R11 | Istio / service mesh | important | `not_evidenced` | Named absence below | `[grounded]` |
| R12 | Vault | important | `not_evidenced` | Named absence below | `[grounded]` |
| R13 | SRE practices / own platform reliability | must-have | `not_evidenced` | Recall prompt C3 | `[grounded]` |
| R14 | Developer experience | important | `not_evidenced` | Your pipeline is the closest thing, but your material doesn't say who used it or what it changed for them | `[grounded]` |

## Gap handling

**Recall prompts.** These are gaps where you may have something I haven't seen. The questions are at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS, Helm | must-have | A Kubernetes PoC, with no cluster type or tooling named | It's the platform this role runs on | The PoC ran on EKS rather than minikube or kops; you installed charts with Helm; you wrote manifests for a real service | The PoC repo, manifests, a Helm values file | `[grounded]` what your message does and doesn't say; `[generic]` EKS and Helm are core keywords on platform roles of this kind |
| C2 | Terraform | must-have | Ansible only | Infrastructure-as-code is how this platform gets built | Any Terraform, even a single module; CloudFormation for the RDS or IAM setup; Terraform used in the PoC | A repo, a merged PR | `[grounded]` what your message does and doesn't say; `[generic]` IaC is usually screened for directly on roles of this kind |
| C3 | SRE practices / reliability | must-have | Nothing on on-call or incidents | The role says you will "own platform reliability" | You were on an on-call rotation; you wrote postmortems; you set CloudWatch alarms that paged people | A postmortem doc, an alarm config, a runbook | `[grounded]` what your message does and doesn't say; `[generic]` reliability ownership is often probed in platform interviews |

**Named absences.** These are gaps with nothing to recover from your current material.
- **GitOps/ArgoCD, Istio, Prometheus/Grafana, Vault, Go, GitLab CI:** nothing in your experience covers these. To close them, build a public repo with Terraform provisioning EKS, ArgoCD deploying a Helm chart, and Prometheus/Grafana monitoring it. That's a few weekends of work, and it gives you something you can actually point to. It still won't count as production experience. Go and Istio are realistically "not worth closing for this application." Learn them on the job, or target roles one step closer to your current work.

## Not written, and why

- **"Kubernetes in production" or "managed Kubernetes clusters":** your own sentence says it "never went to production."
- **"Platform Engineer" as your title:** you held "DevOps Engineer". The title is the first thing a reference check confirms.
- **"Infrastructure as code (Ansible)" or "Terraform":** Ansible is config management. Calling it IaC changes the kind of work it was.
- **"Observability" for CloudWatch:** you wrote "monitoring". The posting's word implies Prometheus/Grafana-style metrics and tracing work you haven't described.
- **"GitOps" or "developer experience" for the Jenkins pipeline:** those are the posting's words. Using them for your pipeline would claim a practice you haven't described.
- **"Owned platform reliability" or "SRE":** nothing in your material supports this unless C3 comes back yes.
- **A "familiar with" list of the JD's tools, or a hidden keyword block:** both put words on your resume that you can't defend, and hidden text can be detected (cite C19).

## Parse-safety check

I checked against your description of the PDF, not the file itself.

| Risk | What breaks | What it costs you |
|---|---|---|
| Two-column layout | Parsers read left to right across both columns | Skills and job bullets can merge into word salad, and dates can detach from roles |
| Icons for each skill | If a skill name is part of the icon image rather than text, it's skipped | **Your real keywords (AWS, Docker, Jenkins, Python) may not be read at all.** This is the likeliest keyword problem you actually have |
| Contact details in the header | Headers are often discarded as page decoration | A recruiter may get your resume with no way to reach you |
| Canva PDF | I couldn't check this | If you can't select and copy the text in the PDF, nothing in it is being read |

I'm not recommending a redesign, only flagging what may not survive the parser.

## Upgrade menu

- **The PoC repo or manifests** would let me tighten E3 and E5 and answer C1 with proof.
- **Any Terraform or CloudFormation you've written** would answer C2.
- **Who used your Jenkins pipeline and what it replaced** could turn R14 from a gap into a real line.
- **The actual PDF** would let me run the parse checks on the file rather than on your description.

## Questions

C1: Did your Kubernetes PoC run on EKS, and did you use Helm in it?
C2: Have you written any Terraform or CloudFormation, at work or on your own?
C3: Have you been on call, or handled or written up production incidents?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.