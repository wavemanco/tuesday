Thanks, Dev. Below is the edit list for your resume. You gave me your background as prose, not as the resume itself, so I've written each line as a new line rather than as a change to an existing one. Every proposed line quotes the sentence of yours it comes from. Nothing has been applied. You approve or reject each row, and I build the resume only from the ones you approve.

Before the table, the honest picture. Three of the posting's must-haves are not on your resume: **3+ years of data engineering**, **production Python**, and **Airflow or equivalent orchestration**. No wording fixes that. What your background does support well is the warehouse side of the role: the dbt models, the orders mart, the star schema and the tests. The edits below put those first, and the gap tables say where a true answer from you could add more.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Moving from analytics into data engineering." | `surface` | "I'm trying to move into data engineering from analytics." | `[grounded]` your message | pending your approval |
| E2 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail. Built and maintained about 25 dbt models, including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E3 | Experience | *(no current line)* | "Built and maintained about 25 dbt models, including the core orders mart" (placed as the first bullet) | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E4 | Experience | *(no current line)* | "Designed the star schema for the orders mart with our then-data engineer" (second bullet) | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message. "DE" is spelled out as "data engineer"; check that this is what you meant | pending your approval |
| E5 | Experience | *(no current line)* | "Fixed the nightly dbt job when it broke and added tests to it" (third bullet) | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E6 | Experience | *(no current line)* | Two bullets: "Wrote Python scripts that pull vendor APIs on a cron" (fourth) and "Python (pandas) for analysis" (lower down) | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E7 | Experience | *(no current line)* | "SQL every day on Redshift: complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E8 | Skills | *(no current line)* | "SQL (Redshift: window functions, CTEs) · dbt (models, tests) · Python (pandas, API scripting, cron) · Star schema design" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I've fixed our nightly dbt job when it breaks and added tests to it."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E2 and E3 keep "about 25".** They don't round it up to "25+".
- **E4 keeps "with our then-data engineer".** You designed the schema together with them, not alone.
- **E5 says "fixed… when it broke".** It doesn't say "owned" or "on call for" the job.
- **E6 puts the cron scripts fourth, above the pandas work.** They're the closest thing you have to ingestion work, and they're described as scripts, not as "pipelines".
- **E8 lists Airflow, Spark and Kafka nowhere.**

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years of data engineering | must-have | `not_evidenced` | Your 5 years are as an analyst. The dbt and scheduling work is related but isn't data engineering experience. Named absence below. | `[grounded]` your message |
| R2 | Production Python | must-have | `not_evidenced` | Python "for analysis" plus cron scripts. Whether those scripts count as production depends on facts you haven't given yet. Recall prompt C1. | `[grounded]` your message |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | "Never used Airflow." Cron and the nightly dbt job may count partly, depending on what schedules that job. Recall prompt C2. | `[grounded]` your message |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E4 and E8 (the orders mart star schema, co-designed). How much modelling you've done beyond that one schema is untested. Recall prompt C3. | `[grounded]` your message |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E2, E3, E4 | `[grounded]` your message |
| R6 | Data quality | important | `surfaced_by_edit` | E5: you added tests to the nightly job | `[grounded]` your message |
| R7 | Own SLAs | important | `not_evidenced` | You fixed failures. Nothing says you owned a delivery target. Named absence below. | `[grounded]` your message |
| R8 | Batch and streaming pipelines (Spark, Kafka) | important | `not_evidenced` | "Never used Airflow or Spark." "Never touched Kafka." Named absence below. | `[grounded]` your message |
| R9 | Streaming experience | preferred | `not_evidenced` | Covered by the Spark/Kafka absence | `[grounded]` your message |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | You are the analytics side. Nothing yet shows you gathering requirements from others. Recall prompt C4, held for a later turn. | `[grounded]` your message |

## Recovery per gap

**Recall prompts.** These are things you might have done but haven't mentioned yet.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis and cron scripts that pull vendor APIs. It doesn't say whether anyone depended on them or how they were run. | It's a must-have. If the screener sees only "pandas for analysis", it reads as unmet. | Scripts in git with code review; retries, logging or alerting when a vendor API failed; tables other teams used that your scripts loaded; packaging, tests or CI | A repo link, a pull request, an alert config | `[grounded]` what you wrote; `[generic]` how must-haves are screened in roles like this |
| C2 | Orchestration | must-have | A nightly dbt job you fix and test, plus cron. It doesn't say what schedules the dbt job or who set it up. | "Or equivalent" leaves room. A dbt Cloud job, a scheduler with dependencies or a cron setup you configured may be partial evidence. | You set up the dbt Cloud schedule; you managed the job's dependencies or run order; you added failure alerts; you chained the API pulls ahead of the dbt run | Job config, a screenshot of the scheduler | `[grounded]` what you wrote; `[generic]` how "or equivalent" tends to be read |
| C3 | Dimensional modelling | must-have | One star schema, co-designed. | It's a must-have. Your share of one schema is thinner than "dimensional modelling" as a skill. | Other marts you modelled (inventory, customers); slowly changing dimensions; deciding the grain of the fact tables; conformed dimensions shared across marts | Your dbt project, an ERD, a design doc | `[grounded]` what you wrote; `[generic]` how this gets probed in interviews |
| C4 | Partner with analytics on requirements | important | Nothing yet. | You already sit where the role's partners sit, which may count once it's stated. | You gathered metric definitions from stakeholders and turned them into the mart's design | A spec or a ticket | `[grounded]` what you wrote; `[inferred]` from the JD's wording |

**Named absences.** Here you've said there's nothing to find.

- **3+ years of data engineering (R1).** You have zero years in a data engineering title, and the posting says it's a must-have. Wording can't close this. What can: a role titled Analytics Engineer, or a data engineering role that leans on dbt; an internal move into data engineering; or confirmed answers to C1–C3, which would make the related work more substantial. Whether to apply anyway is a call for job-underwriter, not for this edit list.
- **Spark and Kafka/streaming (R8, R9).** You've never used either. Streaming is only listed as a plus, but Spark is in the core duties. A small public project would give you something to show: a Kafka topic feeding a Spark or Python consumer into a warehouse table, run by Airflow. It would show as a personal project and never as work experience.
- **SLA ownership (R7).** Fixing failures isn't the same as owning a delivery target. To close it, you'd need to own a stated data delivery deadline at work, for example taking ownership of the nightly job's completion time.

## Prohibited claims

Not written, and why:
- **"Data Engineer" or "Analytics Engineer" as your title.** You held neither title. Your title stays Senior Data Analyst.
- **"Built and owned batch pipelines".** These are the posting's words. Yours are "scripting to pull vendor APIs on a cron" and fixing a dbt job.
- **"Production Python".** Not stated. It waits on C1.
- **Airflow, Spark or Kafka anywhere, including the Skills list.** You said you've never used them. A tool in your Skills list is a tool you'll be asked about.
- **"Orchestrated" or "orchestration".** It waits on C2.
- **"Owned data quality and SLAs".** You added tests and fixed failures. Owning is a different job.
- **"Designed the warehouse" or "Led the star schema design".** It was one mart's schema, designed with your then-DE.
- **"25+ dbt models".** You wrote "about 25".
- **"Partnered with analytics".** These are the posting's words, and they would put you on the data engineering side of a partnership you were part of from the analytics side.

## Parse-safety check

You pasted your background as text, not as a resume file. That means I couldn't check layout, columns, tables, headers and footers, section headings, file type, or whether the file contains hidden text you didn't put there. Send the actual file and I'll run those checks.

**Upgrade menu:**
- **Your dbt project, as a repo link or an export.** This makes E3, E4, E5 and E8 checkable rather than only your word, and could support C3.
- **The cron scripts' repo.** This is the evidence C1 needs.
- **The scheduler config for the nightly job.** This is the evidence C2 needs.
- **Your current resume file.** This replaces the "no current line" cells with real before-and-after edits, and makes the parse-safety check possible.

**Questions:**

C1: Did anyone other than you depend on the data the vendor-API scripts loaded, and were the scripts in version control, reviewed, or set up to alert you when they failed?

C2: What actually runs the nightly dbt job (dbt Cloud, cron, something else), and did you set up or change its schedule or dependencies?

C3: Besides the orders mart, have you modelled any other fact or dimension tables, or made design calls like the grain of a table or how to track history?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.