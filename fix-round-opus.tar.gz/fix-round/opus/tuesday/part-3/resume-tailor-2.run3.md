Before the edits: Bellhaven lists "3+ years data engineering" as a must-have, and nothing you've told me is data engineering by title or by most of its work. Your 5 years are analytics, with real data engineering work alongside them: dbt models, the star schema, fixing and testing the nightly job. The edits below put that work first. None of them can make it read as 3+ years of data engineering, and I haven't tried. The gap is named below.

You sent your background as notes, not as a resume file, so I've treated each sentence as your own claim. Nothing is applied yet: every row waits for your approval.

## The edits

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet under Senior Data Analyst)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your background | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Co-designed the star schema for the orders mart with our data engineer at the time" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed the nightly dbt job when it broke and added tests to it" | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your background | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python (pandas) for analysis" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python scripting to pull from vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "Daily SQL on Redshift, including complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your background | pending your approval |
| E7 | Skills | *(no current line)* | "SQL (Redshift) · dbt · Python (pandas) · cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your background | pending your approval |
| E8 | Summary | *(no current line)* | "Senior Data Analyst in retail, moving into data engineering. Built and maintained about 25 dbt models, including the core orders mart, and co-designed its star schema with our data engineer at the time." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your background | pending your approval |

Notes on these rows:
- **E2** keeps "with our data engineer at the time". You designed the schema with someone. Dropping that would turn a shared design into one you did alone, and an interviewer would ask about it.
- **E3** says you fixed and tested the job. It doesn't say you owned it, ran it reliably or kept it to an SLA, because you didn't say you did.
- **E5** keeps it at "scripting". "Some scripting" doesn't say how many scripts there were, so I haven't written "scripts".
- **E8** leaves out "5 years". Your note doesn't say whether that's 5 years in the senior title or 5 years in total, so I've taken the smaller claim. Put your real dates in the job header.
- **E7** leaves out Airflow, Spark and Kafka. It would be dishonest to list them, and they would also get you more keyword matches than you can back up in an interview.

**How to order it** (pending your approval): Put E8 first, then E1 and E2 at the top of your experience bullets. Dimensional modelling is the must-have you can show most directly, so it should be the first thing a reader sees.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Named absence below. Related work is in E1–E3 | `[grounded]` your title and work are analytics |
| R2 | Production Python | must-have | `not_evidenced` | Analysis Python and cron scripting (E4, E5) don't show production use. Recall prompt C2 | `[grounded]` your background |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | Depends on what schedules the nightly dbt job. Recall prompt C1 | `[grounded]` "Never used Airflow or Spark." |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E2 and E8. You co-designed the schema, not alone | `[grounded]` your background |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1 and E6: dbt models on Redshift | `[grounded]` your background |
| R6 | Own data quality | important | `surfaced_by_edit` | E3: you added tests. Owning data quality is more than that, and the line doesn't claim it | `[grounded]` your background |
| R7 | Own SLAs | important | `not_evidenced` | Recall prompt C3 | `[grounded]` your background is silent on this |
| R8 | Build and own batch pipelines (Spark) | important | `not_evidenced` | Named absence below | `[grounded]` "Never used Airflow or Spark." |
| R9 | Streaming (Kafka) | preferred | `not_evidenced` | Named absence below | `[grounded]` "Never touched Kafka." |
| R10 | Partner with analytics on requirements | important | `surfaced_by_edit` | E2. You've been the analytics side of that partnership, not the data engineering side, so you can't write that you partnered with analytics | `[grounded]` your background |

## Gaps

**Recall prompts.** Your work might cover these, but your notes don't say enough to tell.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | There's a nightly dbt job and some cron scripts. Nothing says what schedules the dbt job or whether you set it up | "Or equivalent" leaves room. A dbt Cloud schedule or another scheduler you set up or changed might count. Cron alone probably won't | You set up or changed the dbt job's schedule; you added retries or dependencies between steps; you set up failure alerts | The job's config or a screenshot of the schedule | `[grounded]` what your notes say; `[generic]` how screeners read "or equivalent" |
| C2 | Production Python | must-have | Python for analysis, plus vendor API scripts on cron | Postings use "production" to mean code other people depend on, kept in version control, tested and monitored | Others use the vendor data your scripts pull; the scripts are in git; they have tests, error handling or alerting | A repo link, or a description of the scripts | `[grounded]` your notes; `[generic]` what "production" usually means |
| C3 | Own SLAs | important | Fixes made "when it breaks" | Owning SLAs means a promise to others that you're accountable for keeping | Dashboards had to be ready by a set time; you were the person called when the job failed; you tracked how often it failed | A runbook, an incident note, an on-call rota | `[grounded]` your notes are silent; `[generic]` what owning SLAs means |

**Gaps with nothing to pull.**
- **3+ years of data engineering (must-have).** You don't have it by title, and the work you've described is analytics with some data engineering alongside. Ways to close it: move first into an analytics engineering role or a data engineering role open to career-changers, or take on pipeline work in your current job until it adds up to real years. Whether applying here makes sense with this gap is a question for job-underwriter, not this edit.
- **Spark.** You've never used it. Ways to close it: Spark work in your current job, or a public project that runs a real batch job on Spark. Treat a project as practice, not as years of experience.
- **Kafka / streaming (preferred).** You've never touched it. It's listed as a plus, not a requirement, so it isn't worth closing before you apply. It's worth closing for later data engineering roles.

## What I didn't write, and why

- **"3+ years of data engineering experience"** or **"Data Engineer"** in any form: it isn't your title or most of your work.
- **"Analytics Engineer"** as a new job title: that would be an upgrade, not an equivalent title.
- **"Built and orchestrated data pipelines"**: you fixed and tested one nightly job. You didn't build or orchestrate pipelines.
- **"Production Python" / "built ingestion pipelines"**: both are the posting's words. Your words are "some scripting to pull vendor APIs on a cron".
- **"Owned data quality and SLAs"**: you added tests and fixed failures. Owning them is a different job.
- **"Designed the warehouse's dimensional model"**: you designed one mart's star schema, together with a data engineer.
- **"Partnered with analytics stakeholders"**: you were the analytics side. Writing this would put you on the other side of the table.
- **Airflow, Spark or Kafka anywhere on the resume**, including the skills line.

## Will it parse?

You sent pasted notes, not a file, so I couldn't check layout, tables, headers and footers, file type, or hidden text. Use standard section headings (Summary, Experience, Skills) and send it as a .docx or a PDF with selectable text.

## What would strengthen it

- **A repo or a description of the vendor API scripts:** could move C2 to grounded.
- **The nightly job's schedule config, or a screenshot of it:** could close C1.
- **Your dbt project, or its docs and tests:** would back up E1 and E3 with something a reader can check.
- **A public batch or streaming project** (a proposal, built only if you want it): shows Spark or Kafka as something you've learned. It doesn't add years.

## Questions

**C1:** What runs the nightly dbt job (dbt Cloud, cron, something else), and did you set up or change its schedule, retries or alerts?
**C2:** Do other people or reports depend on the vendor API scripts, and are they in version control with any tests or alerting?
**C3:** Did the nightly job have a deadline people relied on, and were you the person expected to fix it when it missed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.