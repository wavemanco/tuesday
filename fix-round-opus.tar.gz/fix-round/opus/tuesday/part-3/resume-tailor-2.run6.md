Reading the remaining playbook references (output rules, parse-safety) before building your ledger.
I've built your edit ledger. Before the details, one thing to know first: **the JD's must-have is "3+ years data engineering", and nothing you've told me covers it.** You have 5 years as an analyst who did real analytics-engineering work (dbt models, a star schema, fixing and testing the nightly job). That work is close to data engineering and it's what this resume leads with. Rewording can't turn it into data-engineering years, Airflow, Spark or Kafka, so I haven't tried. Whether it's worth applying with that gap is a job-underwriter question.

You sent me a description of your background, not your actual resume. So every proposed line is new, and each one traces to a sentence from your message, quoted word for word. Because there's no document or supporting material yet, all rows are `[grounded]` with this caveat: confirmed by you, nothing to inspect yet, expect an interviewer to probe them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (bullet 1) | *(no current line)* | "Built and maintained about 25 dbt models, including the core orders mart" | `surface` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E2 | Experience (bullet 2) | *(no current line)* | "Designed the star schema for the orders mart with our then-data engineer" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience (bullet 3) | *(no current line)* | "Fix the nightly dbt job when it breaks; added tests to it" | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E4 | Experience (bullet 4) | *(no current line)* | "Wrote Python scripts that pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E5 | Skills | *(no current line)* | "Python (pandas)" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E6 | Skills | *(no current line)* | "SQL (Redshift), daily: complex window functions, CTEs" | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E7 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail. Built and maintained about 25 dbt models, including the core orders mart, and designed its star schema with our then-data engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |

Why the rows look like this:
- **E1–E4 lead the Experience section** because they're the work closest to the JD. Your reporting and analysis bullets go below them. I can't write that reordering as a row until I see your real bullets.
- **E2 keeps "with our then-data engineer".** If you drop it, "designed" becomes sole authorship, and an interviewer will ask who else was in the room.
- **E3 keeps "when it breaks".** That describes fixing failures as they happen, not running the job. It doesn't say "owned reliability" or "on-call".
- **E7 keeps your title as Senior Data Analyst.** The title is accurate, and the summary carries the dbt work instead of a renamed title.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Named absence, see below. The dbt work in E1–E3 is related but isn't DE tenure | `[grounded]` your title and description |
| R2 | Production Python | must-have | `not_evidenced` | Recall prompt C1. E4 shows scripting, but nothing says it ran in production | `[grounded]` your message |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | Recall prompt C2. You haven't used Airflow, but "or equivalent" leaves room depending on what schedules the nightly dbt job | `[grounded]` your message |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E2, E7. Co-designed one mart's star schema | `[grounded]` your message |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E1, E2. Covers the orders mart and about 25 models, not the whole warehouse | `[grounded]` your message |
| R6 | Data quality | important | `surfaced_by_edit` | E3. Added tests to the nightly job | `[grounded]` your message |
| R7 | Own SLAs | important | `not_evidenced` | Recall prompt C3 | `[grounded]` your message |
| R8 | Batch pipelines with Spark | important | `not_evidenced` | Named absence, see below | `[grounded]` your message |
| R9 | Streaming / Kafka | preferred | `not_evidenced` | Named absence, see below | `[grounded]` your message |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | Named absence, see below. You've been the analytics side asking, not the DE side receiving | `[grounded]` your message |

## Recovery per gap

**Recall prompts** (the questions are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, and scripts pulling vendor APIs on a cron. Doesn't say whether anything downstream depended on them | A must-have; listing only pandas reads as analyst Python | Vendor-API scripts feeding tables others query; scripts in version control with code review; retries, logging or alerts you added | Repo link, a PR, a run log | `[grounded]` what you said; `[generic]` how screeners read analyst Python |
| C2 | Orchestration (or equivalent) | must-have | The nightly dbt job exists; it's unclear what schedules it | "Or equivalent" may let a scheduler you configured count | dbt Cloud jobs you set up; cron or CI schedules you wrote; job dependencies you defined | Job config, a CI file | `[grounded]` what you said; `[inferred]` from the JD's "or equivalent" |
| C3 | Own SLAs | important | You fix the nightly job when it breaks. Nothing yet about a deadline it had to meet | The JD pairs data quality with SLAs | A "dashboards ready by 8am" deadline; alerts on failure; a freshness check you added | An alert config, a runbook, a dbt freshness test | `[grounded]` what you said; `[generic]` what SLA ownership usually means |

**Named absences:**
- **R1, 3+ years DE:** you don't have DE tenure, and a must-have can't be argued away on the page. Ways to close it: an internal move or a stretch of formal DE duties at your current job, or targeting **analytics engineer** roles, where your dbt and modelling work counts directly. For this posting, the gap stays.
- **R8, Spark:** you've never used it. Closing it takes a real batch job on real data, either a side project or work tasks. Weeks of that, not a course certificate.
- **R9, Kafka:** you've never touched it. The JD lists it only as a plus, so it's not worth closing for this application specifically. A small producer/consumer project would let you discuss it honestly if asked.
- **R10, partnering with analytics:** you've sat on the analytics side, so a line saying you took requirements from analysts would flip which side you were on. If you ever wrote specs for your then-DE, that's a real line, and you can send it with your resume.

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** You've held neither title. E7 says what you did without renaming the job.
- **"3+ years of data engineering experience."** Not true. Your five years were as an analyst.
- **"Built and owned data pipelines."** That's the JD's vocabulary, not yours. You built dbt models and fix the job when it breaks. Owning pipelines is a different job.
- **"Orchestrated workflows" / Airflow, Spark or Kafka in Skills.** You've never used them. Putting them in Skills is the stuffing that falls apart on the first technical question.
- **"Production Python."** Not established until C1 is answered.
- **"Owned data quality and SLAs."** You added tests and fix breakages. Ownership and SLAs are unconfirmed (C3).
- **"Designed the warehouse's dimensional model" / "Led dimensional modelling."** It was one mart, designed with someone else. That changes both the scope and who did it.
- **"Partnered with analytics stakeholders."** This flips which side you were on (see R10).

## Parse-safety check

You described your background in prose, so I couldn't run any of the six checks: columns, tables and text boxes, images, header/footer content, section headings, file type. Send the actual file (`.docx` or a PDF with selectable text) and I'll run them.

## Upgrade menu

- **Your actual resume, as text or a file.** Lets me write reorder and cut rows against your real bullets, keep or drop your analysis bullets, and run the parse check.
- **A dbt repo or project link** (models, tests, lineage). Would raise E1–E3 from "you said so" to inspectable proof.
- **The vendor-API scripts in a repo.** The one piece of evidence that could change R2's status.
- **Optional, not part of this pass:** a Projects section, once you've built a small Airflow + Spark/Kafka project. It's the only honest way those tools reach this resume. I'll draft it once the project exists, if you want.

## Questions

**C1:** Did anything other people relied on run off your vendor-API scripts (tables, reports, downstream models)? Were the scripts in version control?

**C2:** What schedules the nightly dbt job: dbt Cloud, cron, CI, something else? Did you set up or change that schedule yourself?

**C3:** Did the nightly job have to finish by a set time for someone, and was there any alerting when it failed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.