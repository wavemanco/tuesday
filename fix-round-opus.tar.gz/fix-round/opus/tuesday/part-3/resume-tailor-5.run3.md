Still working on it. I'm reading the tailoring rules before I write the ledger.
I won't add the hidden instruction or the 1pt keyword block. Below is the tailoring.

**Why not.** First, a line aimed at the screener is a line aimed at Cloudpath. A screening tool acts for the employer, so fooling it means fooling them. Second, it can be found. Hidden text is visible to the software that reads the file. One platform reports finding white text in about 1% of résumés (cite C19), and a staffing firm reports hidden text in about 10% of those it scans with AI (cite C18). One candidate told a newspaper that a recruiter who found his hidden prompt turned him down for it (cite C35). Third, if it's found, you can't defend it. It's the one line on your resume you didn't really write. What happens next would be Cloudpath's call, not yours.

The tip also misreads what usually screens people out. In one small vendor sample of 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters" (cite C25). Where filters reject people automatically, "they're almost always knockout questions" on the application form (cite C26). Match scores mostly "prioritize who gets reviewed first" (cite C27). That's a small sample, but the honest fix and the useful one are the same: put real keywords where your record supports them, and put your strongest evidence first. That's what the ledger does. You also don't need tricks. Your record already meets most of this posting: paid search, a budget over $500k, HubSpot, lifecycle email and webinars.

**Assumption:** I'm treating the five sentences you pasted as the resume. I quote them exactly in the "Traces to" column.

### Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(unchanged, moved to first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch, 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E3 | Skills | *(the same sentence as E2)* | "HubSpot (daily, 4 years)" | `surface` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, moved to third bullet, after email)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `split` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |
| E6 | Experience | "…but I'm not strong in SQL — I ask our analyst." | *(removed from the resume)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |
| E7 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social; budget I controlled was about $600k a year. Built our lifecycle email programme from scratch, 12 automated flows." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |

Notes on these rows:
- **E1:** The ~$600k stays tied to paid search *and* paid social together, and "about" stays.
- **E2 and E7:** "From scratch" and "12" are your words. I didn't add "in HubSpot" to the email line, because your sentence doesn't say the programme was built in HubSpot.
- **E4:** "Registrants" isn't turned into "attendees".
- **E6:** Cutting the SQL phrase only removes a disclaimer. It doesn't make the HubSpot claim bigger. If they ask about SQL, answer the way you did here.

### Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Paid search | must-have | `already_evidenced` | E1 moves it to the top bullet | `[grounded]` resume |
| R2 | Budget over $500k | must-have | `already_evidenced` | "about $600k a year", covering paid search and paid social; E1 puts it first | `[grounded]` resume |
| R3 | HubSpot or Marketo | must-have | `already_evidenced` | E3 adds it to Skills so a keyword search finds it; no Marketo claim | `[grounded]` resume |
| R4 | Lifecycle email | must-have | `already_evidenced` | E2 makes it its own bullet | `[grounded]` resume |
| R5 | Webinars | must-have | `already_evidenced` | E4 | `[grounded]` resume |
| R6 | 5+ years B2B demand gen | must-have | `already_evidenced` | "6 years B2B SaaS" as Marketing Manager; the resume doesn't say all six were demand-gen work (see C3) | `[grounded]` resume |
| R7 | Content distribution | important | `not_evidenced` | Recall prompt C1 | `[grounded]` nothing in the resume mentions it |
| R8 | SQL-literate | must-have | `not_evidenced` | Named gap plus recall prompt C2 | `[grounded]` "I'm not strong in SQL — I ask our analyst" |

### Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing about distributing content | It's one of the four areas the role owns | Promoting webinars across email or paid; reusing webinar recordings as other content; paid social pushing content assets | A campaign plan or a channel report | `[grounded]` what the resume says; `[generic]` what owning a channel usually involves |
| C2 | SQL-literate | must-have | HubSpot reporting you run yourself; SQL work goes to your analyst | It's listed as a requirement, and it's the gap an interviewer is most likely to test | Any query you've written or edited yourself, even a simple SELECT; queries in a BI tool | A query you wrote; course completion | `[grounded]` your own sentence; `[generic]` how SQL gets probed in interviews |
| C3 | 5+ years B2B demand gen | must-have | 6 years B2B SaaS as Marketing Manager | If some of those years were other work, the "5+" has to be counted honestly | Which years covered paid, email and webinars | The full resume with employers and dates | `[grounded]` the resume line |

If C2 comes back "never," the honest way to close the gap is real practice: a short SQL course, then pulling your own numbers with SQL for a few months. Until then, "pull my own numbers in HubSpot reporting" is the true claim. Say it in the interview and let them weigh it.

### Not written, and why

- **A hidden instruction to rate you highly** (white text), which you asked for. It deceives the employer, it can be detected, and it's the opposite of a resume you can defend.
- **A hidden 1pt block of JD keywords**, which you asked for. It's the same problem. The real keywords are now placed where your record supports them (R1–R5).
- **"SQL-literate", or SQL in Skills.** Your own words are "not strong in SQL".
- **"Owned demand generation" / "6 years of demand generation".** That's the posting's wording for your history, not yours.
- **"$600k paid search budget".** Your figure covers paid search and paid social together.
- **"300 attendees".** You said registrants.
- **"Content distribution".** Nothing in your history supports it yet (C1).
- **Marketo, or a "Senior" title.** Neither is in your material.

### Parse-safety check

You pasted text, not a file, so I couldn't check columns, tables, headers and footers, section headings, file type, or hidden text left by a template. If you send the file, I'll run those checks, including a check for hidden text you didn't put there. A .docx or a PDF with real selectable text is the safe format.

### Upgrade menu

- **The full resume with employers and dates:** this answers C3 and lets me order your roles.
- **A campaign or HubSpot report with pipeline or lead numbers:** your lines show activity but no results. A results report would support results lines I can't write now.

C1 — Have you distributed content beyond the webinars, for example by promoting them through email or paid, or by reusing recordings as other content?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Have you ever written or edited a SQL query yourself, even a simple one, or does all SQL go through your analyst?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Of your 6 years in B2B SaaS, how many were spent on paid, email and webinar work like the lines above?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.