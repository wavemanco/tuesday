I've read the tailoring rules. Here is your edit ledger.

**My read:** this resume can honestly show three things the job wants: warehouse modelling (the star schema), dbt work, and data-quality work (tests on the nightly job). It can't show the main must-have, which is 3+ years of data engineering. It also can't show production Python, Airflow, Spark or Kafka. I've written nothing that hides those gaps. They're listed below with what it would take to close them. You sent a description rather than a resume, so each line below is built only from your own sentences. I've added no employer names, dates or numbers.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst with 5 years in retail, moving from analytics into data engineering." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics" | `[grounded]` | pending your approval |
| E2 | Experience | *(no current line)* | "Built and maintained about 25 dbt models, including the core orders mart." | `surface` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` | pending your approval |
| E3 | Experience | *(no current line)* | "Designed the star schema for the orders mart with our then-data engineer." | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |
| E4 | Experience | *(no current line)* | "Fixed our nightly dbt job when it broke, and added tests to it." | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` | pending your approval |
| E5 | Experience | *(no current line)* | "Wrote Python scripts, run on a cron, to pull from vendor APIs." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E6 | Experience | *(no current line)* | "Write SQL every day on Redshift, including complex window functions and CTEs." | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` | pending your approval |
| E7 | Experience | *(no current line)* | "Use Python (pandas) for analysis." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E8 | Experience | E2–E7 as above | *(unchanged, in this order: E2, E3, E4, E5, E6, E7, so the warehouse and pipeline-shaped work comes first and the analysis work last)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE."; "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` | pending your approval |
| E9 | Skills | *(no current line)* | "SQL (Redshift), dbt, Python (pandas), star schema design" | `surface` | "SQL every day on Redshift"; "Built and maintained about 25 dbt models"; "I write Python for analysis — pandas"; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |

Notes on these rows:
- **E1** uses your own words for the move. It doesn't call you a data engineer. Being upfront here gives a reviewer the frame for the bullets that follow.
- **E3** keeps "with our then-DE." Dropping it would make the design sound like yours alone. Interviewers will ask about it, so be ready to say which parts were yours.
- **E3 and E9** say "star schema," not "dimensional modelling." A star schema *is* dimensional modelling, and any reviewer will make that connection. The job ad's term isn't put into your history for you.
- **E5** describes the cron scripts as scripts. It doesn't call them "ingestion pipelines" or "production Python."
- **E7** keeps "for analysis" because that limit is the honest part of the line.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your 5 years are as an analyst. E2–E4 show DE-adjacent work, not DE years. See named absences. | `[grounded]` |
| R2 | Production Python | must-have | `not_evidenced` | E5 shows scheduled scripts. Whether they count as production depends on answer C1. | `[grounded]` |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | The cron scripts (E5) and nightly dbt job (E4) are adjacent. What scheduled that job is unknown, see C2. | `[grounded]` |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E3, E9 | `[grounded]` |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E2, E3 | `[grounded]` |
| R6 | Own data quality | important | `surfaced_by_edit` | E4 shows you added tests, not that you owned quality | `[grounded]` |
| R7 | Own SLAs | important | `not_evidenced` | Nothing says the nightly job had a deadline you answered for, see C3 | `[grounded]` |
| R8 | Batch pipelines with Spark | important | `not_evidenced` | "Never used Airflow or Spark." See named absences. | `[grounded]` |
| R9 | Streaming / Kafka | preferred | `not_evidenced` | "Never touched Kafka." See named absences. | `[grounded]` |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | You've been the analytics side, and E3 shows you working with a DE. Your resume can't claim you "partnered with analytics." Say it in your cover letter or interview instead. | `[grounded]` |

## Gap handling

**Recall prompts** (the questions are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, plus cron scripts pulling vendor APIs. It doesn't say whether others depended on them or how they were run. | It's a must-have, and "for analysis" reads as not production. | Scripts in version control or code review; scripts other teams' data relied on; error handling, retries or alerts when a vendor API failed; running on a server rather than your laptop | The repo, a README, an alert config | `[grounded]` what you said; `[generic]` how reviewers usually read "Python for analysis" |
| C2 | Airflow or equivalent orchestration | must-have | You fix the nightly dbt job, but nothing says what scheduled it | "Or equivalent" may cover a scheduler you've already used. That's the one must-have where wording you can back up might close the gap. | dbt Cloud job scheduling; a DAG the then-DE built that you edited or re-ran; a cron or CI job you set up | Job config, a screenshot of the schedule, a PR | `[grounded]` |
| C3 | Own SLAs | important | Fixes when the job breaks, but no stakes or deadline | Owning SLAs is the core of "own data quality and SLAs" | Dashboards that had to be fresh by a set time; being the person paged or messaged when it failed; a written freshness target | A runbook, an incident note, a dbt freshness test | `[grounded]` |

**Named absences:**
- **R1, 3+ years of data engineering:** You don't have this, and the ad marks it must-have. Wording can't fix it. Your adjacent work (E2–E4) is your case, and a reviewer may still filter you out on years. What would close it: a role titled analytics engineer, or a role with DE duties, for 1–2 years. You could also aim at junior or mid-level DE and analytics-engineer postings, where this resume matches more closely.
- **R8, Spark:** You've never used it. A small public project would give you something to point to: a PySpark batch job over a public dataset, scheduled with Airflow, which also gives you evidence for R3. It wouldn't add years.
- **R9, Kafka/streaming:** You've never touched it, and the ad lists it as a plus. It's not worth closing before you apply. Leave it out.

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** You're a Senior Data Analyst. Retitling is an upgrade, not an equivalent.
- **"3+ years of data engineering experience."** Your 5 years are analytics.
- **"Built and owned batch pipelines."** You built dbt models and fixed the nightly job. Owning pipelines is a different job.
- **"Production Python."** Nothing yet shows the scripts were production. That's open in C1.
- **"Airflow," "Spark," "Kafka," or "orchestration experience"** anywhere, including the skills line. You said you've never used them.
- **"Built ingestion pipelines from vendor APIs."** You wrote cron scripts. "Pipelines" changes the kind of work.
- **"Owned data quality and SLAs."** You added tests and fixed failures. Owning them goes further than that.
- **"Led" or "owned" the star schema design.** You designed it *with* the then-DE.
- **"Partnered with analytics on requirements."** You were the analytics team. The ad's word would switch which side of the table you sat on.
- **Any numbers** (rows, runtimes, uptime). You gave none, so I invented none.

## Parse-safety check

You sent prose, not a file, so I couldn't check layout, columns, tables, headers and footers, or file type. Keep standard headings (Summary, Experience, Skills) and send a `.docx` or a PDF with selectable text.

## Upgrade menu

- **Your actual resume:** gives me your current lines, employer, dates and anything you left out, so rows become before-and-after edits instead of new lines.
- **The dbt repo or script repo (even private screenshots):** could support C1 and C2 and make the E2–E5 claims easy to verify.
- **A small Airflow + PySpark project:** gives you something real to cite for R3 and R8. Offered as an extra if you want help scoping one.

Whether to apply given R1 is a separate decision the job-underwriter module can make.

## Questions

C1: Were your vendor-API scripts in version control and running somewhere other than your own machine, and did anyone else's data depend on them?
C2: What actually scheduled the nightly dbt job: dbt Cloud, Airflow run by the DE, cron, something else?
C3: Did that nightly job have a time it had to finish by, and were you the one people came to when it missed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.