I'm reading the cited sources on ATS screening before writing your edit ledger.
I worked through this as an edit ledger: a list of proposed changes, each traced to your own words, and none applied until you approve. First, the premise.

**Keywords are probably not what's auto-rejecting you.** The evidence on this is thin. One résumé-builder company interviewed 25 US recruiters. Only 2 of the 25 had content-based auto-rejection switched on (cite C25). When the recruiters did use automated filters, *"they're almost always knockout questions"*: yes/no eligibility checks such as work authorization, licence or location (cite C26). You answer those on the application form, not in your resume. Where match scores exist, a *"Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile"* (cite C27). That keywords drive those scores is an inference. So keywords matter for being found, but they can only go where your experience supports them.

The coverage map below shows the bigger problem. Most of this JD's stack (rows 6–16) isn't in your background at all, and rewording can't fix that. Your two-column Canva layout may also be breaking before any keyword is counted (see the parse-safety check).

I haven't seen your actual resume text, so I built this from your description. "Current line" says so wherever I'm guessing.

## Requirements
The posting is mostly a tools list and doesn't say which items are required. I treated the one stated responsibility as **must-have** and each listed tool as **important**.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(not seen; assumed shown as icons)* | Python scripting, Bash scripting, Docker, Jenkins, AWS (EC2, S3, RDS, IAM), CloudWatch (monitoring), Ansible (config management) | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your description | pending your approval |
| E2 | Experience | *(not seen)* | Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs, moved to first bullet | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |
| E3 | Experience | *(unknown whether it's on the resume)* | Ran a two-month Kubernetes proof-of-concept in 2025; it did not go to production | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[inferred]` year worked out from "last year" as of today | pending your approval |
| E4 | Summary | *(no current line)* | DevOps Engineer, 4 years. Built a deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. AWS (EC2, S3, RDS, IAM), Docker, Python and Bash scripting. | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your description | pending your approval |

- **E1** puts your skills in plain text, which is what a parser and a keyword match can read, and leads with the items closest to this JD. It keeps "scripting" and "monitoring" exactly as you wrote them.
- **E3** keeps "did not go to production". Calling it "Kubernetes experience" without that would turn a prototype into production work, and any Kubernetes interviewer would spot it within one question.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Own platform reliability and developer experience | must-have | not_evidenced | Recall prompt R2 | `[grounded]` nothing in your description covers reliability ownership |
| 2 | Python | important | surfaced_by_edit | E1, E4; scripting only | `[grounded]` |
| 3 | CI/CD | important | surfaced_by_edit | E2, E4; Jenkins deploy pipeline, the CD side | `[grounded]` |
| 4 | Kubernetes (proof-of-concept) | important | surfaced_by_edit | E3 | `[grounded]` |
| 5 | Kubernetes in production | important | not_evidenced | Recall prompt R1; otherwise a named absence | `[grounded]` "never went to production" |
| 6 | AWS EKS | important | not_evidenced | R1 (was the PoC on EKS?) | `[grounded]` you list AWS services, but not EKS |
| 7 | Helm | important | not_evidenced | R1 | `[grounded]` |
| 8 | Terraform | important | not_evidenced | Recall prompt R3 | `[grounded]` Ansible is config management, not provisioning |
| 9 | SRE practices | important | not_evidenced | R2 | `[grounded]` |
| 10 | Prometheus / Grafana / observability | important | not_evidenced | Named absence; CloudWatch monitoring sits in E1 as itself | `[grounded]` |
| 11 | GitLab CI | important | not_evidenced | Named absence | `[grounded]` |
| 12 | ArgoCD / GitOps | important | not_evidenced | Named absence | `[grounded]` |
| 13 | Istio / service mesh | important | not_evidenced | Named absence | `[grounded]` |
| 14 | Vault | important | not_evidenced | Named absence | `[grounded]` |
| 15 | Go | important | not_evidenced | Named absence | `[grounded]` |

## Recovery per gap

**Recall prompts** (the questions for these are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Kubernetes, EKS, Helm | important | Only that a two-month PoC happened | Kubernetes heads the JD and EKS and Helm depend on it | Running the PoC cluster on EKS; packaging an app with a Helm chart; writing the manifests yourself rather than following a tutorial | The PoC repo, manifests, or a write-up | `[grounded]` what you've said; `[generic]` platform roles usually probe hands-on cluster work |
| R2 | Platform reliability, SRE | must-have | Nothing on uptime, incidents or on-call | It's the one stated responsibility | Being on an on-call rota; setting up CloudWatch alarms; handling incidents or postmortems; other teams deploying through your pipeline | Alarm configs, a runbook, a postmortem | `[grounded]` absent from your description; `[generic]` SRE screens look for incident and alerting work |
| R3 | Terraform / IaC | important | Ansible for config management only | Terraform sits near the top of the JD's stack | Any Terraform or CloudFormation used for provisioning; scripted AWS resource creation | Repo files (.tf or templates) | `[grounded]`; `[generic]` IaC is usually a core expectation on platform teams |

**Named absences.** Rewording can't close these.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| A1 | ArgoCD, GitOps, Istio, Vault, Prometheus/Grafana, GitLab CI, Go | important | None of them | Together they're most of the listed stack | Nothing in your description. The way to close them: a personal project (EKS via Terraform, deployed with Helm and ArgoCD, monitored with Prometheus/Grafana) that you list honestly under "Projects". That earns the keywords truthfully, but it's not job experience. A Go gap needs real Go code. | Public repo | `[grounded]` absent from your description; `[generic]` a project lists as a project, not as experience |

## Not written, and why

- **"Kubernetes experience" / "production Kubernetes"**: your PoC never went to production. Writing it that way would turn a prototype into production work.
- **"CI/CD pipelines"**: you wrote "deploy pipeline". If your Jenkins jobs also build and test code, tell me and the label is justified.
- **"Observability"**: you wrote "CloudWatch for monitoring". "Observability" is the JD's word, and borrowing it would claim more than you did.
- **"Infrastructure as Code"**: Ansible was for config management, which isn't the provisioning this JD means.
- **"Platform Engineer" as your title**: you were a DevOps Engineer. Renaming the role would be an upgrade, not an equivalent.
- **Any listed tool you haven't used (ArgoCD, Istio, Vault, Go, Grafana and the rest)**: none of them goes in, including as "familiar with". Hidden or white-text keywords are also out, because they can be detected.

## Parse-safety check
I haven't seen your PDF, so these are risks based on what you've described, not confirmed findings:

| Check | Risk | What it costs |
|---|---|---|
| Two-column layout | Parsers read straight across both columns | Skills and experience can mix together, and dates can come loose from the roles they belong to |
| Icons for each skill | If a skill exists only as an icon, it's not text | Those skills are simply missing for the parser, including any keyword match |
| Contact details in the header | Headers can be thrown away as page furniture | You can become unreachable |
| Canva PDF export | Not checked: whether there's a selectable text layer | Without one, nothing is readable |

I couldn't check your section headings or look for hidden text. A `.docx` or a PDF with a selectable text layer is the safe pair of formats. Whether this role is worth applying for given rows 5–15 is job-underwriter's call.

## What would sharpen this (offered, not yet built)
- **Paste your actual resume text.** "Current line" becomes real, and I can check your headings and wording.
- **Share the PoC repo or manifests.** That could turn rows 6–7 into real evidence.
- **Optional extra: a scoped personal-project plan for A1.** One line on why: it's the only honest way to these keywords. I'll build it only if you want it.

## Questions
R1: For the Kubernetes PoC, what did you personally build? Was it on EKS, and did you use Helm?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R2: Have you been on call, set up CloudWatch alarms, or handled production incidents? Do other teams deploy through your pipeline?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R3: Have you provisioned any AWS infrastructure with Terraform or CloudFormation, even a little?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.