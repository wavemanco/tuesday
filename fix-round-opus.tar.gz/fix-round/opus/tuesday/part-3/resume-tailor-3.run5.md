**How I worked:** I tailored from the CV summary in your message, not from the CV file, so the "current line" for each row is your own sentence, and I can't see your layout or the order of your bullets. From the dossier I took the fit calls (R1 and R2 both adjacent, medium confidence), its pending edit E1, and its two rejected inferences. The `conditional_go` decision is noted, and I haven't acted on it. Nothing below has been applied yet.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(inside another line, per the dossier; I can't see where)* | "Wrote the internal integration playbook the whole team uses." | `surface` | "Wrote the internal integration playbook the whole team uses."; dossier E1: "surface the integration playbook authorship into its own line" | `[grounded]` CV; carried over from the dossier | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged; moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged; moved to the second bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged; Skills section moved above Experience)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

Notes on the rows:
- **E2 keeps "client" and "our REST APIs".** You worked for the vendor, on the side that provides the API. "Partner" is the posting's word, and I've kept it out of your lines.
- **E3 keeps "for product".** Those words say you fed the product team, not that you were on it. They're what makes the line defensible.
- **E5 is three separate sentences, not one.** Joined into one sentence, the feedback sessions could read as part of leading the integrations. The "7 years" stays across both titles as you wrote it. If you held them one after the other, tell me the split and I'll make it a new row.
- **No row uses "product manager", "roadmap ownership", "discovery" or "shipped".** That's deliberate; see the "Not written" list below.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years as a PM | must-have | `not_evidenced` | Inherited from the dossier: adjacent, transferability gap, medium confidence. Your integration leadership is close, but roadmap ownership and prioritisation authority aren't shown → C1 | `[grounded]` dossier evidence map; CV: "Never held a PM title." |
| R2 | Shipped API or platform products | important | `not_evidenced` | Inherited: adjacent, medium. You implemented the vendor's APIs for clients; that isn't shipping the API → C2 | `[grounded]` dossier evidence map; CV |
| R3 | Technical fluency | important | `already_evidenced` | Postman, SQL, OpenAPI specs, plus 30+ REST integrations. E4 moves it earlier | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3: clients through integrations, product through the feedback sessions. The JD's phrase is never claimed | `[grounded]` CV |
| R5 | Owning the platform roadmap | important | `not_evidenced` | You gave roadmap input; owning the roadmap isn't shown → C1 | `[grounded]` CV; dossier R1 reasoning |
| R6 | Running discovery with integration partners | important | `surfaced_by_edit` | E3 shows you collected client feedback for product. It doesn't show you ran discovery that decided what got built | `[grounded]` CV |
| R7 | Writing specs and driving delivery with two engineering squads | important | `not_evidenced` | The playbook (E1) is process documentation, not a product spec. Nothing shows you directed engineering work → C2 | `[grounded]` CV |
| R8 | Defining adoption metrics | important | `not_evidenced` | "30+" counts integrations; it isn't an adoption metric → C3 | `[grounded]` CV |

## Gaps you might be able to close

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM; owning the roadmap (R1, R5) | must-have | Product-adjacent work: input to the roadmap and end-to-end integration leadership. Nothing shows you decided what got built or in what order | It's the posting's only must-have. Without evidence of prioritisation authority, your case rests on the adjacent work alone | You decided which client requests went into the quarterly sessions and in what priority; product built something because of your case for it; you set the order of an integration backlog and others followed it; you decided what the playbook covered and kept it current | Session decks or notes; a product ticket or release note that cites your input; the playbook's revision history | `[grounded]` what the CV does and doesn't say; `[generic]` what a missing must-have costs on PM applications |
| C2 | Shipped API/platform products; writing specs and driving delivery (R2, R7) | important | You know OpenAPI specs and implemented the vendor's APIs. Nothing shows you wrote a spec or that something you specified shipped | The role's day-to-day is writing specs and delivering with two squads | You drafted or edited an OpenAPI spec or an endpoint change; you wrote requirements for an API change that came from client feedback; you worked with engineering on a fix or feature until it shipped | A spec or PR you wrote; a changelog entry; a requirements document | `[grounded]` what the CV does and doesn't say; `[generic]` what specs evidence on platform-PM applications |
| C3 | Defining adoption metrics (R8) | important | A count of integrations. No metric that you defined or tracked | Defining adoption metrics is named as a core duty | You tracked time-to-go-live, integration completion rates or API call volume after launch; you reported integration health to leadership; you set targets for the team | A dashboard, a report, or a QBR slide | `[grounded]` what the CV does and doesn't say; `[generic]` what metrics evidence on platform-PM applications |

**One gap that wording can't close: the PM title.** You've never held one, and no rewording can turn your 7 years into 3+ years as a PM. If C1 turns up real prioritisation authority, it strengthens the case that your experience transfers, but it still won't make the years PM years. The realistic way to close it for this application is a short work sample, such as a one-page API-platform roadmap or spec, sent with the application. That's offered in the upgrade menu below.

## Not written, and why

- **"Product Manager", or any title with "Product" in it.** You've never held one, and the requirement it would cover is the must-have.
- **"Owned the roadmap."** You ran sessions that gave input to the roadmap. Giving input isn't owning, and the dossier already said so.
- **"Shipped API products" / "built our API platform".** You led client integrations of the vendor's APIs. Implementing an API for clients is different work from shipping it.
- **"Ran discovery with integration partners."** These are the posting's words. Yours are "collecting client feedback" and "client". Swapping them would turn a feedback collector into a discovery lead, and your clients into partners.
- **"Wrote OpenAPI specs."** You wrote "Comfortable in". Knowing a tool isn't the same as having written the spec.
- **"Defined adoption metrics" / "drove adoption".** Nothing in your CV supports either.
- **"Worked with engineering squads" / "drove delivery".** Nothing in your CV supports either.
- **"Adopted company-wide" for the playbook.** You said "the whole team uses" it, so the scope stays at the team.
- **From the dossier's rejected inferences, unchanged:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership"; "has been the customer of a partner API platform — candidate worked vendor-side".

## Parse-safety check

You sent your background as a written summary rather than the CV file, so I couldn't check columns, tables, headers and footers, images, section headings, file type, or hidden text. These checks run once I have the actual `.docx` or PDF.

## Upgrade menu

- **The CV file itself.** Each row could then quote your real bullet, and the parse-safety check could run.
- **The integration playbook.** Something a reader can inspect would back E1, which currently rests on your word alone.
- **Session notes or a product ticket** that cites your input. This is the most direct thing that could make C1 a line I can write.
- **Proposed, beyond what you asked for:** a one-page Quartzline API roadmap or spec as a work sample. It's the one thing that can show PM judgement when the title is missing, and this role's must-have is exactly that gap. I'll only build it if you say yes.

## Questions

C1: In the quarterly roadmap-input sessions, or anywhere else, did you ever decide what product built or the order it was built in, as opposed to passing feedback along? If so, give one example.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Have you ever written or edited an API spec or a set of requirements that engineering then built and shipped?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Did you track any numbers on your integrations after they went live, such as time to go-live, completion rates or usage?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.