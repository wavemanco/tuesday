I can rewrite it for this job, but I can't make it look like you've already been a data engineer, and I don't think you'd want that. The posting's must-haves include "3+ years data engineering", Airflow or similar, and production Python. As you've described it, your experience shows none of those directly. You do have real evidence for the warehouse side: dbt models, a star schema and tests. So the plan below puts that work first and is clear that you're moving into the field.

I worked from your sentences exactly as you wrote them, since you sent a description rather than the resume itself. Nothing below has been applied yet. Approve or reject each change by its number.

## Proposed changes

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years in retail, moving from analytics into data engineering. Built and maintained about 25 dbt models, including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "I'm trying to move into data engineering from analytics"; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | "Built and maintained about 25 dbt models, including the core orders mart" | `surface` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer" | `surface` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message; I read "DE" as data engineer | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke, and added tests to it" | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas), plus some scripting to pull vendor APIs on a cron" | `surface` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "SQL every day on Redshift: complex window functions and CTEs" | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your message | pending your approval |
| E7 | Experience | *(order of bullets)* | E2, E3 and E4 go first. E5 and E6 go after them. | `reorder` | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE."; "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E8 | Skills | *(no current line)* | "SQL (Redshift) · dbt (models, tests) · dimensional modelling (star schema) · Python (pandas, API scripting) · cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "added tests to it"; "I designed the star schema for the orders mart with our then-DE."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

Some details I kept on purpose:
- **"about 25"**: the number stays as you gave it.
- **"with our then-DE"**: the star schema stays shared work.
- **"some scripting"**: I didn't drop the "some".
- **"fixed … when it broke"**: I didn't change it to "owned".

Those are the details an interviewer will ask about.

## What the job asks for vs. what your resume shows

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your title is analyst. The dbt and modelling work is related, but how long you've done it isn't stated. See "Gaps with nothing to add" below. | `[grounded]` your message |
| R2 | Production Python | must-have | `not_evidenced` | You describe Python for analysis plus "some scripting" on a cron. Whether that counts as production is unknown, so I read it the modest way. Question C1. | `[grounded]` your message |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | "Never used Airflow". The cron scripts and the nightly dbt job are close, but not orchestration as written. Question C2. | `[grounded]` your message |
| R4 | Dimensional modelling | must-have | `surfaced_by_edit` | E3, E8 | `[grounded]` your message |
| R5 | Model the warehouse | important | `surfaced_by_edit` | E2, E3, E1 | `[grounded]` your message |
| R6 | Build and own batch pipelines (Spark) | important | `not_evidenced` | dbt work is batch transformation, which E2 shows. Owning the pipeline isn't shown, and "Never used … Spark". | `[grounded]` your message |
| R7 | Own data quality and SLAs | important | `not_evidenced` | E4 shows the dbt tests you added. Nothing shows you owned an SLA. Question C3. | `[grounded]` your message |
| R8 | Streaming (Kafka) | preferred | `not_evidenced` | "Never touched Kafka" | `[grounded]` your message |
| R9 | Partner with analytics on requirements | important | `not_evidenced` | You *were* the analytics side. See "Not written, and why". | `[grounded]` your message |

## Gaps where you may have more to add

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, and scripts that pull vendor APIs on a cron. It doesn't say whether anything depended on them. | It's a must-have. On postings like this, analysis-only Python is usually read as not meeting it. | Scripts that loaded tables your dbt models read from; retries or error handling when an API failed; code in git that others reviewed | The repo, a dbt source definition pointing at their output, a runbook | `[grounded]` what you wrote; `[generic]` how screeners usually read this |
| C2 | Airflow or equivalent orchestration | must-have | A cron schedule and a nightly dbt job. Who scheduled it, and how, isn't stated. | "Equivalent" is your best opening here, but only if you configured something. | Setting up the dbt Cloud schedule or cron jobs; ordering jobs so one runs after another; setting up retries or failure alerts | The job config, a crontab, alert setup | `[grounded]` what you wrote; `[generic]` how "equivalent" is usually judged |
| C3 | Data quality and SLAs | important | You added tests and fixed the job when it broke. Whether there was a deadline, and whether you were responsible for it, isn't stated. | The posting asks you to "own" this. Fixing failures on a deadline is the nearest evidence you could have. | Fixing the mart before a morning report was due; being the person who got paged; adding tests after a specific failure | The test files, an incident note, a Slack alert channel | `[grounded]` what you wrote; `[generic]` how ownership is usually tested |

## Gaps with nothing to add

- **3+ years of data engineering.** You haven't held a data engineering role. To close this you'd need the dbt and modelling work to show a few years of real pipeline duties, which C1–C3 might partly show, or to aim at roles that explicitly hire analysts moving across. Whether to apply anyway is a separate decision; the **job-underwriter** module handles that.
- **Spark.** Never used it. A small personal project would let you say "worked with it", not "used in production". It isn't in the must-haves, so it's not worth chasing just for this role.
- **Kafka / streaming.** Never used it. It's only listed as a plus, so leaving it out costs little. A small personal project would let you discuss it in an interview, but it doesn't belong on the resume as experience.
- **Partnering with analytics.** There's no resume line for this. It's an interview point: you know the analytics side's needs from the inside.

## Not written, and why

- **"Data Engineer" or "Analytics Engineer" as your title.** Your title was Senior Data Analyst.
- **"Airflow", "Spark", "Kafka", "streaming" anywhere, including the skills list.** You've never used them. A keyword in your skills list gets asked about.
- **"Built batch pipelines" or "built data pipelines".** That's the posting's wording, not yours. You built dbt models; I left them described that way.
- **"Orchestrated" or "scheduled pipelines".** "On a cron" is what you said. C2 could change this.
- **"Production Python" or "built Python services".** You said Python for analysis plus some scripting. C1 could change this.
- **"Owned the nightly pipeline" or "owned data quality and SLAs".** You said you fixed it when it broke and added tests.
- **"Designed the warehouse" or "Designed the star schema" without "with our then-DE".** That would widen the scope and drop the shared credit.
- **"25+ dbt models".** You said "about 25".
- **"Partnered with analytics on requirements".** You were the analyst, so this would swap which side you were on.

## Will it read correctly by software?

You sent a description rather than a file, so I couldn't check the things that usually break when software reads a resume:
- columns
- tables
- icons
- headers and footers
- file type

Use standard section names (Summary, Experience, Skills) and send a .docx or a PDF with selectable text. The real keywords dbt, Redshift, star schema and Python all appear in E2, E3, E6 and E8 where your experience supports them.

## What would strengthen this

- **Your dbt project or test files.** Something an interviewer can look at would firm up E2–E4.
- **The vendor-API scripts in a repo.** This is the most direct way to address the production Python requirement if C1 comes back yes.
- **An optional extra, beyond the resume:** I can outline a small personal project, such as an Airflow job loading from a stream into a star schema. It would give you something truthful to point to for orchestration and streaming in interviews. It wouldn't count as work experience. Just ask if you want it.

## Questions

C1 — Did your vendor-API scripts load data that dbt models or other people relied on, and did they have error handling, alerts or version control?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — What actually runs the nightly dbt job (dbt Cloud, cron, something a data engineer set up), and did you configure any of its schedule, order, retries or alerts?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — When the nightly job broke, who was expected to fix it, and was there a time it had to be fixed by, such as a morning report?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.