I'm writing up the tailoring ledger for your CV against the Quartzline posting. I've read the resume-tailor instructions and used your dossier excerpt.

Before the ledger, four things I assumed:
- **Your CV text:** you gave me a summary, not the document. So the "current line" quotes below are your sentences from this message. If the real CV words them differently, the quotes need to match the real wording.
- **The dossier:** I kept its verdicts. R1 and R2 stay `adjacent` at `medium` confidence, and tailoring doesn't raise that. The excerpt doesn't cover technical fluency or stakeholder management, so I assessed those two myself from your CV.
- **The decision:** the dossier's `conditional_go` is noted. Whether to apply is outside this task.
- **Nothing is applied yet.** I'll produce the tailored CV only from the rows you approve.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses" (sitting inside a longer line, I assume) | "Wrote the internal integration playbook the whole team uses" (as its own bullet) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; drafted in the dossier as E1, checked again here | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end" | *(wording unchanged; moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product" | *(wording unchanged; moved to the second bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor"; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E5 | Skills | "Comfortable in Postman, SQL, OpenAPI specs" | *(wording unchanged; Skills moved directly under the Summary)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

Why some words stay exactly as you wrote them:
- **"our REST APIs" (E2, E4)** says you worked on the vendor side, implementing your own company's APIs for clients. "Partner APIs" or "the API platform" would change which side of the work you were on.
- **"for product" (E3, E4)** says you gathered input for the product team, not that you owned the roadmap. Removing it would turn feeding the roadmap into owning it.
- **E4 keeps three separate sentences.** Combined into one, the feedback sessions would read as part of leading the integrations, and you didn't say that.
- **"30+" stays attached to integrations (E4).** It doesn't become 30+ partners, clients or adopters.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier: adjacent, transferable, medium confidence. E3 and E4 show related integration leadership. Owning the roadmap and having authority to prioritise aren't shown anywhere (recall prompt C1) | `[grounded]` dossier evidence map and CV |
| R2 | Shipped API or platform products | must-have | `not_evidenced` | Dossier: adjacent, medium confidence. E2 shows you implemented APIs your company had already built. Building or shipping one isn't shown (C2) | `[grounded]` dossier evidence map and CV |
| R3 | Technical fluency | must-have | `surfaced_by_edit` | E5. E2 backs it up too | `[grounded]` CV |
| R4 | Stakeholder management | must-have | `surfaced_by_edit` | E2 and E3, client-facing and product-facing. The CV won't use the phrase "stakeholder management" itself (see the list below) | `[grounded]` CV |
| D1 | Run discovery with integration partners | important (duty) | `not_evidenced` | E3 is related. Collecting feedback for product is a different job from running discovery yourself | `[grounded]` CV |
| D2 | Write specs and drive delivery with two engineering squads | important (duty) | `not_evidenced` | Being comfortable with OpenAPI specs isn't writing product specs. Nothing mentions delivery work with engineering (C2) | `[grounded]` CV |
| D3 | Define adoption metrics | important (duty) | `not_evidenced` | Nothing in your material covers this (C3) | `[grounded]` CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM: roadmap ownership and prioritisation | must-have | Feedback sessions held for the product team. No decision rights are stated. | It's the requirement listed first, and the one an interviewer will test first. | You ranked client requests before handing them over; you sat in planning where items were cut; you decided which integration-side work went first. | A ranked request list, notes from a session, a planning document | `[grounded]` what the CV says and doesn't say; `[generic]` how PM screens usually treat a non-PM title |
| C2 | Shipped API products / write specs / work with engineering on delivery | must-have | Implementation of APIs that already existed. No specs or delivery work mentioned. | It's a must-have. A PM title isn't required here, but evidence of shipping is. | You wrote requirements for a connector, an endpoint change or an SDK fix that engineering then built; you wrote a spec in OpenAPI; you tracked an integration feature through to release. | The spec, the ticket, a release note | `[grounded]` what the CV says and doesn't say; `[generic]` what platform-PM roles typically probe |
| C3 | Define adoption metrics | important | Nothing. | It's a stated duty of the role. | You tracked time-to-go-live across the 30+ integrations, error rates after launch, or API usage per client. | A dashboard, a SQL query, a quarterly report | `[grounded]` what the CV says and doesn't say |

If C1 comes back "no, I handed findings over", R1 becomes a stated gap. The way to close it is one of these: a role with real prioritisation authority, an associate or technical PM role, or a cover note that states the transferable case and its limits.

## Not written, and why

- **"Built an internal request-triage tool"** — rejected in the dossier. It came from a memory lead, and you couldn't confirm you owned it.
- **"Has been the customer of a partner API platform"** — rejected in the dossier. You worked vendor-side.
- **"Product Manager", "Technical PM" or "3+ years of product management"** — you've never held a PM title. The gap is named in the coverage map instead of hidden.
- **"Owned the API roadmap" or "prioritised the roadmap"** — you ran input sessions *for* product. Owning the roadmap is a different job.
- **"Shipped API products" or "built REST APIs"** — you integrated *our* REST APIs for clients. Building them would be a different kind of work, and a different verb.
- **"Ran partner discovery"** — that's the posting's wording. Yours is "collecting client feedback", and switching the words changes both the activity and who it was with.
- **"Stakeholder management" or "drove delivery with engineering"** — these are the posting's phrases, not facts you've stated about yourself.
- **"Wrote API specs"** — you said you're "comfortable in" OpenAPI specs. Being comfortable with a tool isn't the same as having written specs in it.
- **"Defined adoption metrics" or "drove adoption across 30+ partners"** — nothing supports this. And the 30+ counts integrations, not adopters.

## Parse-safety check

This came to me as typed text, not a file, so I couldn't check for columns, tables, text boxes, icons, headers or footers, or the file type. With your real headings I could also check that sections like Summary, Experience and Skills use names screening software recognises. Send the file and I'll run all of it.

## Upgrade menu

- **The CV itself (.docx or PDF):** gives real "current line" quotes and makes the parse-safety check possible.
- **The integration playbook (or a redacted extract):** something an interviewer can actually inspect, which helps against R1 and R2's medium confidence. It's the main extra thing I'd suggest; it's optional.
- **Any spec, ticket or dashboard from the recall prompts:** turns a recall answer into a supported claim.

## Questions

C1 — When a roadmap-input session ended, did you decide or rank what went to product, or did you hand over the feedback for product to prioritise?
C2 — Have you ever written a requirements doc or spec (for example a connector, an endpoint change, or in OpenAPI) that engineering built from, and did you follow it through to release?
C3 — Across the 30+ integrations, did you track anything after go-live, such as time-to-live, error rates or usage, and how?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.