I've read the resume-tailor playbook and its rules on hidden text. Here's the result.

## The hidden text: I won't add it

I've left out both the white-text instruction and the 1pt keyword block. Here's why:

- **It deceives Cloudpath.** The screener works for the employer, so tricking it means tricking them. If it came up in an interview you'd have to explain a line you wrote to fool their process.
- **It gets found.** The software that reads your resume sees hidden text just as clearly as visible text. One hiring platform disclosed that it found white text in 1% of the resumes it processed in half a year (cite C19). A staffing firm says it finds hidden text in about 10% of the resumes it scans with AI (cite C18). One candidate said a recruiter turned him down after finding his (cite C35).
- **You can't control what happens if it's caught.** That's the employer's call.

You also don't need it, for two reasons:
- **Your real experience already matches this job.** You have paid search, lifecycle email, webinars, HubSpot and a budget over $500k. The legitimate version of the trick is to put those keywords where your experience backs them up, and put them first.
- **The automated rejection you're worried about is less common than people say.** In one small survey of recruiters, 2 out of 25 had content-based auto-rejection turned on (cite C25). When automated filters are used, they are "almost always knockout questions" (cite C26) on the application form, not your resume.

**One assumption:** you sent a summary, not your resume's actual wording. So the "Current line" column says *not seen*. Each "Traces to" cell quotes your message exactly.

## Requirements from the JD

- **Must-have:** 5+ years B2B demand gen; HubSpot or Marketo; SQL-literate; managed a budget over $500k
- **Important:** owning paid search, lifecycle email, webinars and content distribution

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(not seen)* | "B2B SaaS Marketing Manager, 6 years. Ran paid search and paid social; controlled a budget of about $600k a year. Built our lifecycle email programme from scratch — 12 automated flows." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E2 | Experience | *(not seen)* | "Ran paid search and paid social; controlled a budget of about $600k a year." | `surface` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your message | pending your approval |
| E3 | Experience | *(not seen)* | "Built our lifecycle email programme from scratch — 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E4 | Skills | *(not seen)* | "HubSpot — daily use, 4 years; pull my own numbers in HubSpot reporting" | `merge` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your message | pending your approval |
| E5 | Experience | *(not seen)* | "Ran a monthly webinar series, average 300 registrants." | `surface` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |
| E6 | Experience | *(not seen)* | *(the E2, E3 and E5 bullets put first in your current role, in that order, matching the JD's order)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |

Some deliberate choices:
- **"About" stays.** E1 and E2 say "about $600k" and not "$600k+".
- **"Controlled" stays as your word.** It isn't upgraded to "owned".
- **E3 doesn't add "in HubSpot".** Your sentence doesn't say the programme was built there.
- **E5 says "registrants", not "attendees".**

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1 states 6 years and names the activities. Real role dates have to carry the years; I have none to add | `[grounded]` your message |
| R2 | HubSpot or Marketo | must-have | surfaced_by_edit | E4 | `[grounded]` your message |
| R3 | SQL-literate | must-have | not_evidenced | G1: your message says the opposite | `[grounded]` your message |
| R4 | Budget over $500k | must-have | surfaced_by_edit | E1 and E2 | `[grounded]` your message |
| R5 | Paid search | important | surfaced_by_edit | E2 | `[grounded]` your message |
| R6 | Lifecycle email | important | surfaced_by_edit | E3 | `[grounded]` your message |
| R7 | Webinars | important | surfaced_by_edit | E5 | `[grounded]` your message |
| R8 | Content distribution | important | not_evidenced | G2: paid social is related but isn't the same thing | `[grounded]` your message |

## Gaps you'd need to close

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SQL-literate | must-have | You do your own HubSpot reporting and send SQL questions to an analyst. That's reporting skill, not SQL. | It's a listed must-have. Some interviewers will test it live. | Editing or rerunning a query the analyst gave you; writing simple SELECT/WHERE filters; reading SQL to check a number. If none of these apply, a short SQL course plus a few queries on your own campaign data would close it in weeks, not months. | A saved query; a course certificate; a notebook | `[grounded]` what your message says; `[generic]` that SQL may be tested in interviews |
| G2 | Content distribution | important | Nothing yet. Paid social is related, but it isn't content distribution. | It's one of the four areas the role owns. | Promoting ebooks or reports through paid or email channels; syndication deals; turning webinars into blog or social content | Campaign brief; channel report | `[grounded]` what your message says; `[generic]` what an uncovered area costs on a demand-gen application |

The SQL gap is where to decide whether this role is still worth your time. That's what job-underwriter is for.

## Not written, and why

- **Hidden white-text instruction and 1pt keyword block:** refused, for the reasons at the top.
- **"SQL" in Skills:** your own words are "I'm not strong in SQL".
- **"Senior Marketing Manager" or "Demand Generation Manager" as your title:** your title is Marketing Manager.
- **"6 years of demand generation" or "owned demand gen":** that's the JD's wording, not yours. The 6 years belong to your title, and you didn't say how long you ran each channel.
- **"Managed a $600k+ budget":** yours was "about $600k", and "controlled" isn't changed to "managed".
- **"Content distribution" anywhere:** there's no evidence for it yet (G2).
- **"Built in HubSpot" or "300 attendees":** neither is in your sentences.

## Parse-safety check

You pasted a summary, not a file, so I couldn't check the layout. That means no check for columns, tables, headers and footers, or file type. I also couldn't check whether your current file already has hidden text from a template. If it does, that's a risk you can't see. Send the `.docx` or PDF and I'll run all of these.

## What would make this better

- **The resume itself (pasted text or file):** fills in the real current lines and runs the parse-safety check.
- **Any results numbers** you have for the webinars or email flows (pipeline, MQLs, conversion rates): E3 and E5 could carry them, as long as you supply the figures.
- **Role dates:** these let R1 show the years clearly.

## Questions

G1 — Have you ever edited, rerun, or written any SQL query yourself, even a simple one the analyst gave you?
G2 — Have you promoted content like ebooks, reports, or webinar recordings through paid, email, or partner channels?
Paste your actual resume text or attach the file so I can quote your real lines.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.