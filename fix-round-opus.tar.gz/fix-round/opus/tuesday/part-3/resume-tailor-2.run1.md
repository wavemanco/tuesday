I'm tailoring your resume for the Bellhaven role. First, a short summary of where you stand, then the proposed edits.

**I haven't rewritten the resume yet.** Below is a list of proposed edits. Each one sits next to the sentence of yours it comes from, and you approve or reject each one. I'll build the final resume from the ones you approve. Your resume came as a short description, so I've treated each of your sentences as a resume line from your current role.

**Where you stand:** your strongest match is warehouse modelling. You have the star schema and the dbt marts. The data-quality part of "own data quality and SLAs" is covered in part. Three must-haves aren't shown by what you gave me: "3+ years data engineering", production Python, and Airflow or equivalent orchestration. Spark and Kafka are absent, and no wording can fix that. Whether those gaps make this worth applying for is a separate question, which the job-underwriter module covers.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Your title is analyst. The dbt and schema work is close to data engineering but isn't the title. Recall prompt C3 | `[grounded]` your message |
| R2 | Production Python | must-have | `not_evidenced` | E5 shows your API scripting as you described it. Whether it counts as "production" is C1 | `[grounded]` |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | "Never used Airflow". A cron schedule is scheduling, not orchestration. What ran the nightly dbt job is C2 | `[grounded]` |
| R4 | Dimensional modelling / model the warehouse | must-have | `surfaced_by_edit` | E2, E3, E8. Co-designed, and it stays co-designed | `[grounded]` |
| R5 | Build batch pipelines | important | `surfaced_by_edit` | E1, E8: about 25 dbt models are batch transformations. Not "pipelines you owned" | `[grounded]` |
| R6 | Own data quality | important | `surfaced_by_edit` | E4: you added tests to the nightly job and fix it when it breaks | `[grounded]` |
| R7 | Own SLAs | important | `not_evidenced` | Named absence below | `[grounded]` |
| R8 | Spark | important | `not_evidenced` | Named absence below | `[grounded]` |
| R9 | Streaming / Kafka | preferred | `not_evidenced` | Named absence below | `[grounded]` |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | You were the analytics side working with a data engineer, the opposite side from this role. No resume line | `[grounded]` |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your message | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data engineer" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(E2's line, moved to second bullet)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks" / "Added tests to our nightly dbt job" | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas)" / "Python scripting to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "SQL daily on Redshift: complex window functions and CTEs" | `compress` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` | pending your approval |
| E7 | Skills | *(no current line)* | "SQL (Redshift), dbt, Python (pandas), cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` | pending your approval |
| E8 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models, including the core orders mart. Designed the star schema for the orders mart with our then-data engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` | pending your approval |

Notes on some rows:
- **E2 keeps "with".** Interviewers ask about schema design in data engineering loops, and "co-designed with the data engineer" is the version you can defend.
- **E5 keeps "some scripting"** as scripting. It doesn't turn into "built ingestion pipelines".
- **E8 keeps "5 years" attached to your title as you wrote it.** It doesn't say 5 years of data engineering.

## Gaps

**Recall prompts.** These are gaps where something you've done might count:

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | must-have | Python for analysis, plus scripts that pull vendor APIs on a cron. Nothing says whether anything depended on them | It's a must-have, and "for analysis" reads as notebook work | Scripts others relied on daily; retries or error alerts; code in git with review; a script that ran unattended for months | The repo, or one script | `[grounded]` what you wrote; `[generic]` how data engineering screens read "analysis Python" |
| C2 | Airflow or equivalent orchestration | must-have | You fix the nightly dbt job, but nothing says what scheduled or ran it | If it ran on an orchestrator (dbt Cloud jobs, Dagster, Prefect, a managed scheduler), that's the "equivalent" the posting allows | Configuring the job's schedule or dependencies; reruns or backfills you triggered | Job config, a screenshot of the run history | `[grounded]`; `[generic]` |
| C3 | 3+ years data engineering | must-have | 5 years as an analyst. The dbt and modelling work is there, but its share of your time isn't | Recruiters often read a must-have like this by title. Time spent mainly on dbt is the honest counterweight | Stretches where modelling and dbt were most of your job; covering data engineering duties after the data engineer left | Your dbt commit history, a role description | `[grounded]`; `[generic]` |

**Named absences.** These are gaps with nothing to pull, and each says what would close it:
- **Spark (R8):** you've never used it. A personal project would show you've learned it, not that you've used it in production. It's listed in the duties, not the requirements, so don't try to close it for this application.
- **Kafka / streaming (R9):** you've never touched it. It's listed as a plus. Same answer: closing it means real streaming work, which isn't possible before you apply.
- **SLAs (R7):** nothing you've told me shows a stated deadline you were held to. If the nightly job had a fixed delivery time, mention it when you answer C2 and this row changes.
- **Partner with analytics (R10):** you were the analytics partner, the opposite side. This is worth raising in an interview, not as a resume line.

## Prohibited claims

Not written, and why:
- **"Data Engineer" or "Analytics Engineer" as a title:** you held neither, and changing the title would be an upgrade, not an equivalent.
- **"Built and owned data pipelines":** you built dbt models and fix a job someone else set up. "Own" is the posting's word, not yours.
- **"Orchestrated workflows" or "Airflow-adjacent":** you said you've never used Airflow. Phrasing that hints at it without saying it is exactly what I won't write.
- **"Production Python":** not established until C1 is answered.
- **"Led" or "designed the warehouse":** it was one mart's schema, designed together with the data engineer.
- **"Owned data quality and SLAs":** you added tests and fix breakages. SLAs aren't mentioned anywhere in what you gave me.
- **"Partnered with analytics stakeholders":** it reverses which side you were on.

## Parse-safety check

You described your resume rather than sending the file, so I couldn't check the layout: columns, tables, headers, footers, images or file type. Send the file and I'll run those checks. Use the usual section headings (Summary, Experience, Skills) so the edits above land where resume software looks for them.

## Upgrade menu

- **Your dbt project, or its test YAML files:** would make E1 and E4 provable.
- **The vendor API script repo:** would make E5 provable and could close C1.
- **The orders mart diagram (ERD):** would make E2 and E8 provable.

## Questions

C1: Did anything or anyone depend on your vendor API scripts running? If so, what happened when they failed?
C2: What actually ran the nightly dbt job (cron, dbt Cloud, something else), and did you ever change its schedule or setup?
C3: Over the 5 years, roughly how much of your time went to dbt and modelling work rather than analysis?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.