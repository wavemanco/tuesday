I've read the resume-tailor playbook and its reference files. The full edit ledger is below.

**Basis.** I'm using your dossier excerpt for the same Quartzline role. Its readings for R1 and R2 (`adjacent`, confidence `medium`) carry over unchanged, its pending edit becomes E1, and both rejected inferences go straight into the not-written list. The underwriter's `conditional_go` doesn't change anything here. The other requirement rows are worked out from your CV here, because your excerpt only had R1 and R2. You pasted the CV as sentences, so I'm assuming each sentence is its own line under one role, and I'm quoting your exact wording.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." *(currently inside another line, per dossier)* | "Wrote the internal integration playbook the whole team uses." | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; inherited from dossier `resume_edits_pending_approval` E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, directly under E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." *(moved into its own Skills section, near the top)* | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Wrote the internal integration playbook the whole team uses." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV | pending your approval |

Notes from checking each line:
- **E2:** "our REST APIs" stays. It records that you integrated your employer's API into client systems. "30+" stays attached to "integrations".
- **E3:** "collecting client feedback for product" stays word for word. Your sessions fed product's roadmap; they didn't set it. Moving the line up puts it where a PM reader will see it, but it adds nothing to the claim.
- **E4:** "Comfortable" stays. It's your honest level, and a bare tools list would claim more.
- **E5:** this summary uses three of your sentences and nothing else. It deliberately doesn't mention "product" or "roadmap", because the roadmap-input sentence is exactly where "PM" would start to creep in.

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Dossier: adjacent, transferability gap, confidence medium. E2, E3 and E5 put the nearby work up front; recall prompt C1 below | `[grounded]` dossier evidence_map R1 |
| R2 | Shipped API or platform products | must-have | `not_evidenced` | Dossier: adjacent, confidence medium. You integrated APIs; the CV doesn't show you shipping one. Recall prompt C2 | `[grounded]` dossier evidence_map R2 |
| R3 | Technical fluency | important | `surfaced_by_edit` | E4, backed up by E2 ("REST APIs") | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 (clients, end to end) and E3 (client feedback to product) | `[grounded]` CV |
| R5 | Discovery with integration partners (responsibility) | important | `not_evidenced` | E3 is the closest evidence: you collected feedback for product, which isn't the same as running discovery. Covered by C1 | `[grounded]` CV |
| R6 | Write specs, drive delivery with two squads (responsibility) | important | `not_evidenced` | Being comfortable with OpenAPI specs doesn't show you writing product specs. Covered by C2 | `[grounded]` CV |
| R7 | Define adoption metrics (responsibility) | important | `not_evidenced` | Nothing in the CV mentions metrics. Recall prompt C3 | `[grounded]` CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM; partner discovery | must-have | You ran feedback sessions for product. It doesn't show you deciding what went on the roadmap | It's the first must-have, and without a PM title the CV has to show product judgment some other way | You decided which client requests went forward and which didn't; you ranked the session output before handing it over; product asked you to make trade-off calls | A ranked request list, session write-ups, a roadmap doc you contributed to | `[grounded]` what the CV does and doesn't say; `[generic]` career-switch PM applications are usually screened for decision-making, not for nearby work |
| C2 | Shipped API/platform products; specs | must-have | You integrated your company's APIs. It doesn't show you changing or shipping one | This is the core of a platform API PM role | Client feedback became an API change you wrote up or specified; you wrote OpenAPI spec changes that engineering built; you briefed engineers on what integrations needed | A spec or ticket you wrote, a changelog entry tied to your request | `[grounded]` what the CV does and doesn't say; `[generic]` platform PM roles usually test spec-to-delivery experience |
| C3 | Adoption metrics | important | No metrics anywhere | "Define adoption metrics" is in the job description; your 30+ integrations may have measurable results | You tracked how long integrations took, go-live counts, or how much clients used the API after launch; the playbook changed one of those numbers | A dashboard, a report, playbook version notes | `[grounded]` what the CV does and doesn't say; `[generic]` integration work often has untracked results |

**Named absence:** "drive delivery with two engineering squads". Nothing in your CV shows you directing engineering work. If C2 turns up a spec you handed to engineers, that partly closes it. If not, it stays an honest gap that a cover note can address. It's not something to write into the CV.

## Not written, and why

- **"Built an internal request-triage tool"**: rejected in your dossier (memory lead; you couldn't confirm you owned it). It won't come back under any wording.
- **"Has been the customer of a partner API platform"**: rejected in your dossier. You worked on the vendor side, not as the customer.
- **"Product Manager" / "Technical PM" in any title**: you've never held a PM title. "Solutions engineer / implementation lead" stays as you wrote it.
- **"Ran discovery with integration partners"**: that's the posting's wording. Yours is "collecting client feedback for product". "Partners" changes which side of the table you sat on, and "discovery" turns gathering feedback into a different, more senior kind of work.
- **"Owned / shaped the API roadmap"**: you gave input to the roadmap. You didn't own it, and the dossier says your prioritisation authority isn't shown.
- **"Shipped API products" / "platform"** describing your work: you integrated APIs, and the CV doesn't say you shipped one.
- **"Defined adoption metrics" / "drove delivery with engineering"**: nothing in your material supports either.
- **"Company-wide integration standard"**: your playbook is used by "the whole team", not the whole company.

## Parse-safety check

You pasted the CV as text, so I couldn't check columns, tables, text boxes, images, or headers and footers. Two things to check yourself: use conventional headings ("Summary", "Experience", "Skills"), and send it as a `.docx` or a PDF with a real text layer.

## Upgrade menu

- **Your actual CV file**: lets me run the full parse check and replace my one-role assumption with your real dates and structure.
- **The integration playbook (redacted)**: it's the most checkable thing you've got. It would strengthen E1 and could become a work sample.
- **Session notes, or a feature request that shipped**: would give C1 and C2 real evidence to quote.
- **Optional, built only if you approve:** a short cover-note paragraph that addresses the missing PM title directly, using the evidence above. A PM-track move is exactly where a CV can't explain itself.

The interview question about having no PM title is something the mock-interview module can rehearse with you later.

**Questions**

C1: When you ran the quarterly roadmap-input sessions, did you decide or rank which client requests went to product, or did you pass everything along and product decided?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Did any feedback you collected become an API change that you wrote up, specified, or saw through to release?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Across the 30+ integrations, did you track any numbers, such as time to go-live, go-live counts, or usage afterwards, or did the playbook change any of them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.