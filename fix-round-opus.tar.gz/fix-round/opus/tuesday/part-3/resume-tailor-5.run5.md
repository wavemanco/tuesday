Still reading the tailoring module's rules before I write the ledger. Two more files to go.
I'm not adding the hidden text or the 1pt keyword block. Here's why:

- **It's aimed at the employer.** The AI screener works for the employer, so hidden instructions to it are a lie to the employer. "I'm not lying to a person" sounds very different if it comes up in an interview.
- **It can be found.** The software that reads your resume sees hidden text just as it sees the rest. One platform publishes how often it finds white text (cite C19), and a staffing firm reports what its AI scanning turns up (cite C18). One candidate told a newspaper that a recruiter found his hidden prompt and turned him down for it (cite C35). What happens after it's found is up to the employer, not you.
- **You don't need it.** "Ignore previous instructions" is only worth trying when the real resume is weak, and yours isn't. You meet most of this posting in plain view. Paid search, lifecycle email, webinars, HubSpot and a budget over $500k all appear below as visible lines you can defend. The honest fix for "will the AI pick me up?" is to put those true keywords early, and the ledger does that.

Here's the tailoring. **Assumption:** you pasted notes, not the document, so each "current line" is your own sentence as you wrote it.

## Edit ledger (resume_edits_pending_approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social, controlling a budget of about $600k a year." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your notes | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social, controlling a budget of about $600k a year" | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your notes | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your notes | pending your approval |
| E4 | Skills | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot (daily use, 4 years)" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your notes | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged; placed third, after paid search and lifecycle email, the order the posting lists them)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your notes | pending your approval |
| E6 | Skills | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "HubSpot reporting (pull my own numbers)" | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your notes | pending your approval |

Notes on these rows:
- E2 keeps "about" and "a year". The $600k stays tied to paid search and paid social, because that's what your sentence says.
- E3 doesn't say "built in HubSpot". Your sentence puts the two facts side by side but never says the programme was built in HubSpot, so the rows keep them apart. If it was, tell me and I'll merge them.
- E6 sits under Skills, away from any SQL wording, so it can't be read as SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Paid search | must-have | already_evidenced | Your paid search sentence; E1 also puts it in the summary | `[grounded]` |
| R2 | Lifecycle email | must-have | already_evidenced | E3 | `[grounded]` |
| R3 | Webinars | must-have | already_evidenced | E5 | `[grounded]` |
| R4 | Content distribution | must-have | not_evidenced | C2 below. Paid social is nearby work but not the same thing | `[grounded]` |
| R5 | 5+ years B2B | must-have | already_evidenced | "6 years B2B SaaS", now in E1 | `[grounded]` |
| R6 | 5+ years specifically in demand gen | must-have | not_evidenced | C1 below. Your notes don't say how many of the 6 years were these channels | `[grounded]` |
| R7 | HubSpot or Marketo | must-have | surfaced_by_edit | E4 | `[grounded]` |
| R8 | SQL-literate | must-have | not_evidenced | C3 below | `[grounded]` |
| R9 | Managed budget over $500k | must-have | surfaced_by_edit | E1 and E2: about $600k a year | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | 6 years in B2B SaaS as Marketing Manager, but not how long you ran these channels | It's the first must-have, and a reader checks it against your dates | All 6 years running paid or lifecycle programmes; an earlier role doing campaign execution; time split between demand gen and brand or product marketing | Role dates per job, old job descriptions | `[grounded]` what your notes say; `[generic]` that readers check tenure against dates |
| C2 | Content distribution | must-have | Nothing on distributing content | It's one of the four channels the job owns | Promoting webinar recordings after the live session; gated ebooks or reports through paid channels; content syndication vendors; partner or newsletter placements | Campaign briefs, syndication contracts, a content calendar | `[grounded]` the absence; `[generic]` how often owners of these four channels get asked about each one |
| C3 | SQL-literate | must-have | You said you're not strong in SQL and ask your analyst | It's a stated requirement, and HubSpot reporting won't count as SQL | Any query you've written or edited yourself, even a simple SELECT; a SQL course | A query you saved, a course certificate | `[grounded]` your own statement; `[generic]` how screeners read SQL against reporting tools |

If C3 comes back "none", the gap is named and stays visible. Closing it would mean basic SQL: SELECT, WHERE, GROUP BY and joins. That's a few weeks of practice on your own HubSpot exports, and then you could say "SQL (basic)" truthfully. Until then the resume says nothing about SQL. Whether this gap means the role isn't worth applying for is a question for job-underwriter.

## Not written, and why

- **Hidden instruction text and the 1pt keyword block:** refused for the reasons at the top. Your visible lines already cover every keyword in this posting that your experience supports.
- **"SQL" in Skills, or "data-driven / SQL-savvy":** you told me you're not strong in it. Writing "SQL-literate" because the posting asks for it is the exact substitution I won't make.
- **"6 years of demand generation":** "demand generation" is the posting's word. Yours is "B2B SaaS" plus the specific channels. That stays until C1 is answered.
- **"Built our lifecycle programme in HubSpot":** your sentences don't connect the two facts.
- **"Managed $600k+" or "$600k budget":** you said "about", and "about" stays.
- **"Content distribution":** paid social isn't content distribution, and an interviewer would ask what you distributed.
- **"Senior Marketing Manager" as a title:** your title is Marketing Manager.
- **"Marketo":** not in your notes.
- **"Owned demand gen":** the job owns it. You "ran" these channels, and that's the verb kept.

## Parse-safety check

You pasted notes, not the file, so I couldn't check any of these: columns, tables or text boxes, images, header or footer content, section headings, file type. I also couldn't check whether your current file already has hidden text from a template or an earlier tool. If you send the file, I'll check both.

## Upgrade menu

- **Send the actual resume file (.docx or PDF).** Proposal: this would let me run the full parse-safety and hidden-text checks, and base each row on your real current lines instead of your notes.
- **Send webinar or email results** (pipeline, conversion, open rates). Proposal: E3 and E5 currently have no outcome figures, and outcome figures are the strongest evidence for a demand gen role. I'll only use numbers you give me.

## Questions

C1: Of your 6 years, how many were spent running paid, lifecycle or webinar programmes yourself, and what did you do in the rest?
C2: Have you done any content distribution, such as promoting webinar recordings, gated content through paid channels, syndication, or partner placements, and which parts did you run yourself?
C3: When you say "not strong in SQL", have you ever written or edited a query yourself, even a simple one, or is it none so far?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.