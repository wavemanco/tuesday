Your layout is a bigger risk than your keywords, and it's the cheapest thing to fix. The second issue is harder: most of this posting's tools aren't in your background, and tailoring can't add them.

**On "it's the keyword matching":** the evidence on automatic rejection is thin, and it points elsewhere.
- In one résumé-builder vendor's interviews with 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters." (cite C25) That's two people.
- Those same recruiters said "When automated filters are used, they're almost always knockout questions" (cite C26). Those are the yes/no questions on the application form, not your resume.
- Keyword match scores mostly decide who gets read first: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile." (cite C27)

So the useful move is to make sure every keyword you can honestly claim is on the resume and can be read by the software. Putting in ones you can't back up won't help. Your two-column Canva PDF with skill icons and contact details in the header could be losing real content before anyone sees it (see the parse-safety check below).

Against this posting, 12 of the 15 requirements I mapped aren't supported by what you've told me. That's a question of whether to apply, which job-underwriter covers. This answer only covers the tailoring.

I haven't seen your resume itself, only your description of it. So every proposed line below quotes your message, and "Current line" is unknown.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(not seen; position unknown)* | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs" as the **first** bullet of your current role | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E2 | Projects | *(not seen)* | "Ran a Kubernetes proof-of-concept for two months last year; it never went to production." (replace "last year" with the actual year) | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E3 | Skills | *(not seen)* | "Kubernetes (two-month proof-of-concept; not production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E4 | Skills | *(not seen; currently icons)* | Plain-text lines: "Cloud: AWS (EC2, S3, RDS, IAM)" / "Containers: Docker" / "Deployment pipelines: Jenkins" / "Config management: Ansible" / "Scripting: Bash, Python" / "Monitoring: CloudWatch" | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E5 | Summary | *(no current line known)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. AWS (EC2, S3, RDS, IAM), Docker, Ansible, CloudWatch; Bash and Python scripting." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E2 goes under "Projects", not under your job.** You didn't say the proof-of-concept was done at work. If it was, question C1 lets me move it under your role.
- **E3 keeps the "proof-of-concept" note on purpose.** "Kubernetes" becomes findable without claiming you've run it in production.
- **E4 says "Deployment pipelines", not "CI/CD".** Your sentence says *deploy* pipeline. I can't tell from it whether those 30 jobs also build or test code.

## Coverage map

The posting lists everything at the same level, so the priorities are my reading. Things tied to the title or to "you will own", plus the core Kubernetes, infrastructure-as-code, GitOps and observability tools, are must-have. The rest are important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes: hands-on | must-have | surfaced_by_edit | E2, E3: a two-month proof-of-concept, qualifier kept | `[grounded]` your PoC sentence; `[inferred]` priority from the posting's focus |
| R2 | Kubernetes: running it in production | must-have | not_evidenced | You said it "never went to production"; see the absences table | `[grounded]` |
| R3 | AWS EKS | must-have | not_evidenced | EC2, S3, RDS and IAM are shown; EKS is unknown → C1 | `[grounded]` |
| R4 | Terraform | must-have | not_evidenced | Ansible handles configuration, which is a different job from provisioning infrastructure → C3 | `[grounded]` |
| R5 | GitOps / ArgoCD | must-have | not_evidenced | See the absences table | `[grounded]` |
| R6 | Prometheus / Grafana / observability | must-have | not_evidenced | CloudWatch monitoring is related work (E4) → C2 | `[grounded]` |
| R7 | SRE practices / owning platform reliability | must-have | not_evidenced | → C2 | `[grounded]` |
| R8 | CI/CD | must-have | surfaced_by_edit | E1: the deploy pipeline. Whether the jobs also build or test is unknown, so no "CI" claim yet | `[grounded]` |
| R9 | GitLab CI | important | not_evidenced | Jenkins only; see the absences table | `[grounded]` |
| R10 | Developer experience | must-have | not_evidenced | See the absences table and the upgrade menu | `[grounded]`; `[inferred]` priority from "you will own" |
| R11 | Helm | important | not_evidenced | → C1 | `[grounded]` |
| R12 | Istio / service mesh | important | not_evidenced | See the absences table | `[grounded]` |
| R13 | Vault | important | not_evidenced | See the absences table | `[grounded]` |
| R14 | Python | important | already_evidenced | "Python scripting", worded the way you wrote it. If it only appears as an icon, see the parse-safety check | `[grounded]` |
| R15 | Go | important | not_evidenced | See the absences table | `[grounded]` |

## Recovery per gap

**Questions to ask you (the questions themselves are at the end):**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes / EKS / Helm | must-have | A two-month proof-of-concept that never reached production; nothing on what it ran on or what you did | Kubernetes is the centre of this platform | Was it on EKS? Did you write Helm charts or deployment files? Was it at work? Did you choose what to test? | A repo, a design doc, a write-up of the findings | `[grounded]` what you said; `[generic]` that Kubernetes depth gets probed in platform interviews |
| C2 | SRE / observability | must-have | CloudWatch "for monitoring"; nothing on alerts, on-call or incidents | Owning reliability is half of the "you will own" sentence | Writing CloudWatch alarms; being on an on-call rota; leading or writing up incident reviews; building dashboards people used | Runbooks, a post-incident review, dashboard screenshots | `[grounded]` what you said; `[generic]` what platform roles usually screen for |
| C3 | Terraform / infrastructure as code | must-have | Ansible for config management only | Terraform is one of the posting's headline tools | Any Terraform, CloudFormation or CDK, even small; how the AWS resources were created; whether the PoC cluster was set up in code | A repo or a merged change | `[grounded]` what you said |

**Gaps with nothing to pull from yet, and what closing them would take:**

| Requirement | The gap | What closing it would take | Provenance |
|---|---|---|---|
| Kubernetes in production | You've never run it in production | A production role, or months on a long-running personal cluster listed as a project, not as work | `[grounded]` |
| GitOps / ArgoCD, Helm | Not in anything you described | A public home-lab repo (EKS + Terraform + ArgoCD + Helm), listed under Projects. One repo covers several gaps | `[grounded]` the gap; `[generic]` the closing path |
| Istio / service mesh | Not in anything you described | Add it to that same lab. Realistically, it's a second-tier gap for this role | `[grounded]`; `[generic]` |
| Vault | Not in anything you described; IAM is a different job | Add secrets management to the lab | `[grounded]`; `[generic]` |
| Go | Not in anything you described | A small Go tool you wrote and published. Not worth chasing just for this application | `[grounded]`; `[generic]` |
| GitLab CI | Jenkins only | Rebuilding one pipeline in GitLab CI in the lab. Being able to talk about how Jenkins and GitLab differ helps in interviews | `[grounded]`; `[generic]` |
| Developer experience | You said "our deploy pipeline" but not who uses it | Name who deploys through it; see the upgrade menu | `[grounded]` |

## Not written, and why

- **"Platform Engineer" as your title.** Your title is DevOps Engineer. Changing it is an upgrade, not an equivalent.
- **"Managed / ran Kubernetes clusters", "EKS".** You ran a two-month proof-of-concept that never went to production. Making it sound like production work is the one inflation an interviewer will catch in a single question.
- **"CI/CD pipelines", "GitLab CI".** You said *deploy* pipeline, in Jenkins.
- **"Infrastructure as code with Ansible".** You wrote "config management". Calling it infrastructure as code changes what kind of work it was.
- **"Observability", "SRE practices", "owned platform reliability", "improved developer experience".** These are the posting's words, not yours. Using them for CloudWatch monitoring or Jenkins jobs would describe your past in the employer's terms.
- **A skills block listing ArgoCD, Istio, Vault, Helm, Terraform or Go.** This is what keyword-stuffing usually looks like. Every entry would fail the first question about it.

## Parse-safety check

These risks come from your description. I haven't inspected the file, so this is general knowledge of how text extraction fails, not a measured rate.

| Check | What you described | What breaks | What it costs |
|---|---|---|---|
| Multi-column layout | Two columns | Parsers read straight across the page, so the columns can mix together | Dates and tools end up detached from the role they belong to |
| Images and icons | "icons for each skill" | Icons come out as garbage characters or are skipped | If any skill name exists only as an icon, it's missing, including keywords like Python and AWS |
| Contact details in the header | "contact details in the header" | Header and footer text is often thrown away as page decoration | Recruiters may have no way to reach you |
| File type / text layer | Canva PDF | Depends on the parser | Quick test: select all the text in the PDF and paste it into a plain text editor. Anything missing or scrambled there is probably missing for the parser too. A `.docx` or a PDF with a text layer is the safe pair |
| Section headings | Unknown | Section detection looks for standard labels | Couldn't check |
| Hidden text from the template | Unknown | — | Couldn't check without the file |

## Upgrade menu

- **Your actual resume text (pasted, or as a .docx).** I could quote your real lines, fill in "Current line", and run the heading and hidden-text checks.
- **What the 30 Jenkins jobs do, and who deploys through them.** If they build or test code, the "CI/CD" label is open to you. If other teams ship through the pipeline, that starts to cover developer experience.
- **Anything from the proof-of-concept** (repo, doc, write-up). That would make it something an interviewer can check, not just your word.
- **A home-lab repo, if you build one.** A single repo could start closing R2, R5, R11, R12 and R13 as a project.

## Questions

C1: In the Kubernetes proof-of-concept, what did you personally build or set up? Was it on EKS, did you use Helm, and was it done at work?
C2: Have you been on call, set up CloudWatch alarms, or handled or written up incidents? What did you own?
C3: Have you written any Terraform, CloudFormation or CDK, even a small amount, or were the AWS resources set up some other way?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.