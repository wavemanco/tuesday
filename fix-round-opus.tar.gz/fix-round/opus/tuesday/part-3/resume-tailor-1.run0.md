Priya, here's the tailoring as a list of proposed edits. Nothing is applied yet. Every row quotes the sentence of yours it comes from, and you approve or reject each row on its own.

**What I worked from:** you described your CV rather than pasting it. So the "Current line" column uses your own sentences as the lines, and every quote is from your message.

## Proposed edits

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV summary | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet under your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV summary | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV summary | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander; on-call rotation every fourth week for two years." | `reframe` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV summary | pending your approval |
| E5 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python, Kafka, Postgres, gRPC, Terraform, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV summary | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team (usually two or three a year), pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV summary | pending your approval |

Some notes on these rows:
- **E3:** the 40k requests/minute belongs to one service, not all three. "About" and "at peak" stay.
- **E4:** this leads with the incident-commander work because "strong incident response" is a hard requirement in the posting. Your words are kept.
- **E6:** "usually" stays, and the line says onboarding, not mentoring.
- **E2:** I kept 380ms → 95ms as raw figures rather than turning them into a percentage, because an interviewer can check the raw numbers.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | Your title and 7 years. E1 repeats them in the summary. | `[grounded]` |
| R2 | Production Go | must-have | `surfaced_by_edit` | E1 and E5 bring Go to the top. Your material doesn't say your three services are written in Go, so no line claims that (C1). | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3 shows three services and the 40k/min volume, and Kafka is in E5. The phrase "distributed systems" isn't yours, so it stays out. | `[grounded]` |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E4: six incidents as incident commander | `[grounded]` |
| R5 | Experience mentoring | must-have | `not_evidenced` | Close but not the same. E6 covers onboarding and first-month pairing, while the posting asks for mentoring mid-level engineers (C2). | `[grounded]` |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E2: the p99 result becomes your first bullet | `[grounded]` |
| R7 | Own on-call for your services | important | `surfaced_by_edit` | E4. You don't say whether the rotation covers your own three services, so no line claims that. | `[grounded]` |
| R8 | Partner with product on roadmap sequencing | important | `not_evidenced` | Nothing in your material (C3) | `[grounded]` |

## Gaps to look into

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Go | must-have | You use Go daily and own three services, but the two facts are never connected | The posting is about designing and shipping Go services, and a reader may not assume the connection | One of the three ledger services written in Go; the cache-layer rework done in Go; Go services you shipped from scratch | Repo or PR links, a design doc | `[grounded]` what the resume says; `[generic]` how readers treat a language that isn't tied to any work |
| C2 | Experience mentoring | must-have | Onboarding and a month of pairing with two or three new hires a year | It's a hard requirement, and the posting means mid-level engineers, not only new hires | Regular 1:1s with a mid-level engineer; reviewing someone's design docs over time; helping a teammate prepare for promotion; teaching on-call to people joining the rotation | A promo packet you contributed to, a peer review, a written onboarding guide | `[grounded]` what the resume says; `[generic]` that "onboarding" may be read as weaker than "mentoring" |
| C3 | Partner with product on roadmap sequencing | important | Nothing | It's a stated part of the job | Negotiating with a PM about when the ledger work would ship; arguing for reliability work on the roadmap after an incident; scoping a quarter's plan for your services | A planning doc, an RFC with product sign-off | `[grounded]` what the resume says; `[generic]` how this is usually shown |

## Lines I chose not to write

- **"Mentored mid-level engineers":** your experience is onboarding new hires. It stays out until C2 is answered.
- **"Designed and built distributed systems at scale":** "distributed systems" is the posting's phrase, and "designed and built" goes beyond "own".
- **"Built Go services handling 40k requests/minute":** this ties Go to the services (not stated) and implies the volume applies to more than one service.
- **"Owned on-call for my services":** you said you're on a rotation every fourth week. Whether it covers your own services, and whether you own it, isn't stated.
- **"Led incident response for the ledger platform":** you ran six incidents as incident commander, and that's the claim the CV makes.
- **"Caching/performance expert":** what you described is one cache-layer rework with a strong result. The bullet says exactly that.
- **"Partnered with product on the roadmap":** nothing in your material supports it yet (C3).

## Parse check

I couldn't check the layout because your CV came as a description, not a file. Columns, tables, contact details in headers or footers, and section headings all need the actual document. As a general point, a `.docx` or a PDF with selectable text is the safe choice.

## What would strengthen this

- **The CV itself (pasted text or file):** I'd quote your real bullets instead of your summary and run the full parse check.
- **A link to the cache-rework PR, design doc or dashboard:** this is the strongest proof for your top bullet.
- **A redacted postmortem from one of your six incidents:** it backs up E4 and gives you a ready story for interviews.
- **Optional extra:** once these rows are settled, I can draft a two-sentence summary built only from approved rows. I'd only do it if you want it.

## Questions

**C1:** Are any of your three ledger services, or the cache-layer rework, written in Go?
**C2:** Apart from new hires, have you mentored anyone more senior over time, for example regular 1:1s, reviewing their designs, or helping with a promotion?
**C3:** Have you worked with a PM on what your services build, or when?

For any of these you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.