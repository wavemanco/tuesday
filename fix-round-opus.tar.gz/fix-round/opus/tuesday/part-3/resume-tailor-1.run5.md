Priya, your background lines up with this JD better than most. You already have the p99 cut, the 40k requests/minute service and six incidents as incident commander. Tailoring here is mostly about putting those first and keeping out phrases the CV can't support.

I worked from what you pasted, not from the CV file itself. So the "Current line" column shows your sentences as you typed them, and every edit traces back to one of them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call every fourth week for two years; incident commander for six incidents." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E5 | Skills | "Go and Rust daily for 4 years, Python before that." | "Go and Rust: daily for 4 years. Python before that." *(as the first Skills line)* | `surface` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "gRPC, Kafka, Postgres, Datadog, Terraform" | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV | pending your approval |
| E7 | Summary | *(no current line)* | "Senior Software Engineer, 7 years; Go and Rust daily for 4 years. Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer. Incident commander for six incidents." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |

Notes on the edits:
- **E2** keeps "about", "one" and "at peak". The 40k figure applies to one service, not all three, and the line still says so.
- **E4** says "onboard" and "pair", not "mentor". The gap is covered in C2 below.
- **E6** moves the tools closest to service work to the front. Nothing is added, and a listed tool still only claims that you listed it.
- **E7** leaves out the word "backend" on purpose. See C1.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `not_evidenced` | The CV shows 7 years as an engineer, but only the 4 Go/Rust years clearly involve backend services. The Python years aren't described. See C1 | `[grounded]` JD Requirements; your CV |
| R2 | Production Go | must-have | `surfaced_by_edit` | E5, E7 show daily Go. The CV doesn't say which of your three services are written in Go. See C2 | `[grounded]` JD; your CV |
| R3 | Distributed systems at scale | must-have | `not_evidenced` | E2 shows request volume. Kafka and gRPC appear only in a tools list. See G1 | `[grounded]` JD; your CV |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E3, E7 | `[grounded]` JD; your CV |
| R5 | Experience mentoring | must-have | `not_evidenced` | E4 is onboarding and pairing with new hires. Mentoring mid-level engineers isn't stated. See C3 | `[grounded]` JD; your CV |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E1, E7 | `[grounded]` JD duties; your CV |
| R7 | Services handling high request volume | important | `surfaced_by_edit` | E2 | `[grounded]` JD duties; your CV |
| R8 | Own on-call for your services | important | `surfaced_by_edit` | E3 shows the rotation. The CV doesn't say the rotation covers your own three services, so no line claims it | `[grounded]` JD duties; your CV |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | See G2 | `[grounded]` JD duties; your CV |

## Gap handling

**Things your answers could fix (the questions are at the end):**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | 7 years total, with 4 years of Go/Rust services. The years before that are summed up as "Python before that." | It's a stated requirement, and 4 clearly backend years is below it | Python APIs or workers; data pipelines; internal services before the payments role | Old resume, repo, or a job description from that period | `[grounded]` what the CV says and doesn't say; `[generic]` reviewers counting years per stack |
| C2 | Production Go | must-have | Go daily, and ownership of three services. The CV never links the two | It's the JD's core language requirement. The posting also says "design and ship Go services," which an interviewer will probe | Any of the three ledger services written in Go; Go services you designed from scratch vs. took over | Repo, design doc, or service README | `[grounded]` what the CV says and doesn't say; `[generic]` interviewers asking which language your services are in |
| C3 | Mentoring | must-have | One month of pairing with each new hire | The JD asks you to mentor mid-level engineers, which is a different relationship from onboarding | Ongoing 1:1s; code-review coaching; helping someone lead a design or their first incident; a promotion you supported | Onboarding plan, design review threads, feedback you wrote | `[grounded]` what the CV says and doesn't say; `[generic]` senior roles judging mentoring past onboarding |

**Gaps your current material can't fill:**

| # | Requirement | Gap | What closing it would take | Provenance |
|---|---|---|---|---|
| G1 | Distributed systems at scale | The CV shows one service at about 40k requests/minute at peak and lists Kafka and gRPC as tools. It never describes distributed-systems work | A sentence in your own words on what your ledger services do with Kafka or gRPC, such as consumers, partitioning, cross-service calls, consistency or retries. Once you tell me, that can become a traceable line | `[grounded]` your CV |
| G2 | Partner with product on roadmap | Nothing in your material covers work with product | A real example of you sequencing work with a PM. If you have none, leave it out: it's a duty, not a listed requirement | `[grounded]` JD; your CV |

## Not written, and why

- **"Built/own three Go services."** You haven't said which language the services are in. Merging two sentences into this one would invent the link between them.
- **"Distributed systems at scale."** That's the JD's wording. Your evidence is one service at about 40k requests/minute at peak, plus a tools list.
- **"Mentored engineers" / "mentored mid-level engineers."** You onboard new hires and pair with them for a month. Using the JD's word would change what kind of work it was.
- **"Owned on-call for my services."** You were on a rotation. Whether it covered your own services isn't stated.
- **"Led incident response for the team."** You were incident commander for six incidents. "The team" would widen the scope.
- **"7 years of backend experience."** You said 7 years, not 7 backend years.
- **"Kafka / Terraform expertise."** These are listed tools, and a listed tool isn't one you've shown you own.
- **"Partnered with product on roadmap."** Nothing supports it.

## Parse-safety check

You pasted a summary, not the file. So I couldn't check for columns, tables, text boxes, headers/footers, icons, headings or file type. The content itself raises no parse risk. Keep standard headings (Summary, Experience, Skills) and send it as a `.docx` or a PDF with real selectable text.

## Upgrades

- **Your actual CV text or file.** With it, the ledger can quote your real lines, not your summary of them, and the layout checks above can run.
- **A redacted postmortem you wrote as incident commander, and the cache-rework design doc or its Datadog p99 graph.** These are the documents engineering interviewers trust. They would back up R4 and R6.
- **A repo or design doc for one of the ledger services.** That would answer C2 and G1 with evidence, not only your word.

## Questions

C2: Which of your three ledger services are written in Go, and did you design any of them from scratch?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Beyond the first month with new hires, have you coached a mid-level engineer over time, for example through regular 1:1s, design reviews, or helping them run something?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C1: Was your Python work before Go and Rust backend work, and roughly how many years was it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.