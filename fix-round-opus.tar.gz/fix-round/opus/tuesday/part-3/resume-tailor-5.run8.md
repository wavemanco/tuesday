I won't add the hidden instruction or the 1pt keyword block. Here's why:

- **It's deception aimed at the employer.** The AI screener works for Cloudpath, so text that's hidden to tell it how to rate you is a hidden message to them. If an interviewer asks what it was, there's no good answer.
- **Software can see it.** Parsers pull out white and tiny text along with everything else, and some screening companies look for it. Greenhouse told the New York Times that white text turned up in 1% of the résumés it processed in the first half of 2025. ManpowerGroup says it finds hidden text in about 10% of the résumés it scans with AI. One candidate told the NYT a recruiter found his hidden prompt and turned him down because of it.
- **What happens after it's found is up to the employer.** You can't know whether it ends with this one application.

You also don't need it. Against the JD, your real experience covers the budget (about $600k against the $500k+ requirement), HubSpot, lifecycle email, paid search and webinars. The honest way to help both screeners and people is to put that evidence first, in plain words, which is what the edits below do. There are two real gaps, SQL and content distribution. I've named them below and haven't written around them.

**What I worked from:** the five sentences in your message. You described your background rather than pasting the resume, so the "Current line" column shows your own words.

## Requirements

| Must-have | Important (the role's scope) |
|---|---|
| 5+ years B2B demand gen · HubSpot or Marketo · SQL-literate · budget over $500k | Paid search · lifecycle email · webinars · content distribution |

## The coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1 states "6 years B2B SaaS" up front. Your sentence says six years as Marketing Manager, not six years of demand gen, so the JD's term isn't used for your history. See question C3 | `[grounded]` "Marketing Manager, 6 years B2B SaaS." |
| R2 | Managed a budget over $500k | must-have | surfaced_by_edit | E2 and E3 move the $600k to the top of Experience and keep "about" | `[grounded]` "budget I controlled was about $600k a year" |
| R3 | HubSpot or Marketo | must-have | surfaced_by_edit | E4 and E5 give HubSpot its own line in Skills | `[grounded]` "HubSpot daily for 4 years" |
| R4 | SQL-literate | must-have | not_evidenced | Recovery row G1; prohibited list | `[grounded]` "I'm not strong in SQL — I ask our analyst." |
| R5 | Paid search | important | already_evidenced | Stated directly; E3 moves it first | `[grounded]` "Ran paid search and paid social" |
| R6 | Lifecycle email | important | already_evidenced | E4 makes it its own bullet | `[grounded]` "built our lifecycle email programme from scratch, 12 automated flows" |
| R7 | Webinars | important | already_evidenced | Stays as written | `[grounded]` "Ran a monthly webinar series, average 300 registrants." |
| R8 | Content distribution | important | not_evidenced | Recovery row G2; paid social is related work, not the same thing | `[grounded]` nothing you wrote mentions distributing content |

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social, controlling a budget of about $600k a year. Built our lifecycle email programme from scratch — 12 automated flows." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social, controlling a budget of about $600k a year" | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E3 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | *(E2's wording, moved to first bullet)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E4 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch — 12 automated flows" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E5 | Skills | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot — daily use, 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E6 | Skills | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "HubSpot reporting — pull my own numbers" | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |

Notes on the rows:

- **"About" stays in E1 and E2.** Your sentence doesn't say whether the $600k covered only paid search and paid social or more than that, so the wording takes the smaller reading.
- **E4 and E5 are separate lines.** Your sentence doesn't actually say the email programme was built in HubSpot, so the two facts stay apart.
- **E6 claims HubSpot reporting only.** It doesn't stand in for SQL.
- **The webinar line stays as you wrote it.** "Average 300 registrants" is already specific.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SQL-literate | must-have | You pull your own numbers in HubSpot reporting and send SQL work to an analyst. That shows you work with data, but not SQL. | It's a listed must-have, so someone will probably ask about it on a screening call | Editing a query someone else wrote; filtering in BigQuery, Looker or Metabase; a SQL course or certificate | A query you wrote, a course certificate, a dashboard you built from SQL | `[grounded]` what you wrote; `[generic]` that listed must-haves get checked on screening calls |
| G2 | Content distribution | important | Paid social and email are channels that could carry content, but you haven't said they did | It's one of the four areas the JD lists for the job | Promoting ebooks or webinar recordings through paid social; a newsletter flow among the 12; syndication or partner placements | A campaign report, a list of flows, an asset calendar | `[grounded]` what you wrote; `[generic]` what this role usually covers |

**If C1 comes back "never":** SQL is a named gap, and no wording will cover it. Closing it takes a few weeks of basic SELECT/JOIN/GROUP BY practice on real marketing data. On the call, say plainly that you pull your own HubSpot numbers, work with an analyst on SQL, and are learning it. Don't put that plan on the resume as if it were a skill you already have.

## Not written, and why

- **White-text instruction to the screener** — you asked for it. It's deceptive, it can be found, and you couldn't defend it. Refused.
- **Hidden 1pt block of JD keywords** — you asked for it. Same reasons. Where a keyword is true, it now appears in visible text: paid search, lifecycle email, webinars, HubSpot, budget.
- **"SQL-literate" / "SQL" in Skills** — you said you're not strong in SQL and ask your analyst.
- **"6 years of demand generation"** — your words are "Marketing Manager, 6 years B2B SaaS". "Demand generation" is the JD's term, and you haven't said all six years were in that work.
- **"Senior Marketing Manager" or "Demand Gen Manager" as your title** — that would be a promotion, not the same title said more clearly.
- **"Owned demand generation" or "content distribution"** — neither appears in what you wrote.
- **"$600k+" or "managed $600k"** — "about" goes, and "controlled" becomes the JD's "managed". Neither is your wording.

## Parse-safety check

You gave me prose rather than a file, so I couldn't check columns, tables, text boxes, icons, headers and footers, or file type. I also couldn't check whether your current resume already has hidden text from a template or an old tool. If you send the file, I'll run both checks. One point to know now: a parser pulls out white or 1pt text like any other text, so it would end up in the plain text a recruiter or AI reads.

## Upgrade menu

- **The actual resume file:** shows your real current lines, the layout check and the hidden-text check.
- **Paid search results you can stand behind** (pipeline, cost per lead, or meetings booked): would let E2 say what the $600k produced.
- **Webinar outcomes** (attendance rate, follow-on pipeline): would add a result to the registrant count.
- Whether the SQL must-have makes this role worth applying for is a question for the job-underwriter module.

**Questions**

C1 — Have you ever written or edited a SQL query yourself, even a simple one, or used a SQL-based tool like Looker, Metabase or BigQuery?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did your paid social or email flows promote content such as ebooks, blog posts or webinar recordings, or did you run any syndication?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Of the 6 years, how many were you running paid search, email and webinar programmes like these, and what did the other years involve?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.