I worked from your CV summary and the dossier. From the dossier I used the role profile, rows R1 and R2 of the evidence map, the pending edit E1 and both rejected inferences. I read the conditional-go decision and left it alone, because whether to apply isn't something this step decides. You pasted a summary of your CV, not the document itself, so each "current line" below is your sentence as you gave it here. Nothing has been changed yet: every row waits for your approval.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." *(as its own bullet)* | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; this is the dossier's pending edit E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV; dossier R2, medium | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV; dossier R1, medium | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved to the top of Skills)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

What these rows deliberately leave alone:
- **E2** keeps "our REST APIs". You were on the vendor side, integrating your company's own APIs for clients. "30+" still counts integrations. The line doesn't become "shipped APIs".
- **E3** keeps "collecting client feedback for product". It doesn't become "shaped the roadmap" or "ran discovery".
- **E4** keeps "Comfortable in". That qualifier is the honest part of the line.
- **E5** keeps three separate sentences, so the feedback sessions don't read as part of owning the product.
- I didn't add a bracketed note like "(REST API integrations)" after your title. Your material doesn't say the whole 7 years was API integration work.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM, incl. owning the roadmap | must-have | `not_evidenced` | Related work is in E3 and E5. This uses the dossier's call as is: related, transferable, medium confidence, with "roadmap ownership and prioritisation authority not evidenced". Recall prompt C1 | `[grounded]` dossier R1; CV "Never held a PM title." |
| 2 | Shipped API or platform products | important | `not_evidenced` | Related work: E2 shows you integrated APIs, which isn't the same as shipping them. Uses the dossier's call (related, medium). Recall prompt C2 | `[grounded]` dossier R2; CV |
| 3 | Technical fluency | important | `already_evidenced` | Your Postman, SQL and OpenAPI line plus the 30+ REST integrations already show it. E4 only moves it up | `[grounded]` CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E3 and E5 put client-facing work up front. Working with internal engineering or leadership isn't shown anywhere | `[grounded]` CV |
| 5 | Run discovery with integration partners | important | `surfaced_by_edit` | E3 shows the client-feedback sessions. The line won't use the word "discovery" | `[grounded]` CV |
| 6 | Write specs; drive delivery with engineering squads | important | `not_evidenced` | Recall prompt C3 | `[grounded]` CV |
| 7 | Define adoption metrics | important | `not_evidenced` | Named as a gap below | `[grounded]` CV |

## Closing the gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM / roadmap ownership | must-have | You gathered roadmap input for product. Nothing shows you deciding priorities | `[generic]` On a must-have, a gap like this is usually the first thing a hiring manager probes | Deciding which client integrations went first when capacity was short; deciding what went into the playbook and what stayed out; turning session findings into a ranked list that product acted on | A prioritised list, a roadmap-input summary you wrote, an email where product took up your ranking | `[grounded]` what the CV says; `[generic]` what this costs |
| C2 | Shipped API/platform products | important | You integrated the APIs. Nothing shows you changing them | `[generic]` Platform PM roles usually check for work on the product itself, not just with it | Specifying a new endpoint, field or error behaviour that got built; maintaining the OpenAPI spec as opposed to reading it; owning a connector, SDK or sample integration release | A spec diff, a changelog entry, a ticket you authored | `[grounded]` CV; `[generic]` cost |
| C3 | Specs and delivery with engineering | important | No spec writing or work alongside engineers is mentioned | `[generic]` This is the core weekly work in the posting's responsibilities | A requirements doc engineers built from; following a client-driven fix from request through to release; attending sprint planning for integration work | The doc, the ticket thread, a release note | `[grounded]` CV; `[generic]` cost |

**Adoption metrics:** nothing in your material mentions defining or tracking a metric. Closing this needs a real example where you set or tracked a usage, go-live or adoption measure. If there isn't one, list it as a gap and prepare to explain how you would approach it, without claiming you've done it.

## Not written, and why

- **"Product Manager" or "3+ years of product management":** you've never held the title. The related work is in E3 and E5, and the gap is named above rather than covered over.
- **"Owned / shaped the product roadmap":** you ran sessions that collected input for product. Owning the roadmap would be both a different verb and a different job.
- **"Shipped API products" or "built our APIs":** you led integrations of them. That's a different kind of work.
- **"Ran discovery with integration partners":** that's the posting's wording, not yours. Your words were "collecting client feedback", and "clients" also shouldn't quietly become "partners".
- **"Wrote / authored OpenAPI specs":** you said you're "comfortable in" them. When a line could be read two ways, I take the reading that claims less.
- **"API platform"** for your employer's APIs: that's also the posting's word.
- **"Defined adoption metrics":** there's no evidence for it.
- **Rejected inferences from the dossier, unchanged:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership"; "has been the customer of a partner API platform — candidate worked vendor-side".

## Format check (can parsers read it)

I couldn't run this check. You pasted a summary, not the file, so columns, tables, headers and footers, icons and file type are all unchecked.

## Upgrade menu

- **Your actual CV text or file:** with it, the "current line" quotes match your real wording, and I can run the format check.
- **An excerpt of the integration playbook:** something an employer can actually look at, which makes E1 harder to doubt.
- **A roadmap-input session summary that product acted on:** the most direct way to strengthen the case for requirement 1.

## Questions

C1: Did you ever decide what got prioritised, in what order, rather than passing input on for product to decide? If so, give one specific example.
C2: Did any change to the REST APIs themselves (a new endpoint, a field, a change to the spec) start with you and get built?
C3: Have you written a document that engineers built from, or followed a piece of work from a client request through to release?

For any of these, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.