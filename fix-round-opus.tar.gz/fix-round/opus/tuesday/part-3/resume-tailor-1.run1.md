Let me read those files individually.
Priya, I worked from the sentences in your message and treated them as your CV's current wording. If the actual CV words things differently, paste it and I'll redo the "Current line" column against it. Nothing below has been applied. Each row waits for your approve or reject.

**One finding first.** Your CV says you use Go daily and that you own three services. It never says the services are written in Go. Tessellate's main ask is "design and ship Go services", so it's tempting to join those two facts, but I didn't. Question C1 at the end is about this.

## Requirements, as the posting ranks them

- **Must-have:** 5+ years backend; production Go; distributed systems at scale; strong incident response; experience mentoring.
- **Important (from the responsibilities):** Go services handling high request volume; driving down p99 latency; owning on-call; mentoring mid-level engineers; working with product on roadmap order.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Own three services in our ledger pipeline — one handles about 40k requests/minute at peak. Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer. Ran six incidents as incident commander." | `merge` | "Senior Software Engineer, 7 years."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E2 | Experience, current role | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E3 | Experience, current role | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline — one handles about 40k requests/minute at peak." (second bullet) | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E4 | Experience, current role | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." / "On-call rotation every fourth week for two years." (two bullets, third and fourth) | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience, current role | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year; pair with them for their first month." (fifth bullet) | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E6 | Skills | "Go and Rust daily for 4 years, Python before that." | *(unchanged, moved to the first line of Skills)* | `reorder` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` your message | pending your approval |
| E7 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Kafka, gRPC, Postgres, Datadog, Terraform" | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E1** keeps every clause as you wrote it. It says "ran six incidents", not "led incident response". It doesn't say the six incidents happened within the two years, because your sentence doesn't say that.
- **E3** stays at 40k requests per **minute**. Turning it into a per-second figure, or calling it "high-throughput", would change what you claimed.
- **E4** splits the line so the incident-commander work gets its own bullet. Each half is still your wording.
- **E7** only changes the order. A tool on a list shows you used it, not that you own it, so none of these tools is moved into an experience bullet.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | already_evidenced | "Senior Software Engineer, 7 years" plus services you own today. Your material doesn't say whether the Python years were backend work. | `[grounded]` your message |
| R2 | Production Go | must-have | surfaced_by_edit | E6 puts "Go and Rust daily for 4 years" first in Skills | `[grounded]` your message |
| R3 | Go services handling high request volume | important | not_evidenced | The volume is covered (E3). The fact that the services are in Go is not. Recall prompt C1. | `[grounded]` your message |
| R4 | Drive down p99 latency | important | surfaced_by_edit | E2 and E1: 380ms to 95ms | `[grounded]` your message |
| R5 | Strong incident response | must-have | surfaced_by_edit | E4 and E1: six incidents as incident commander | `[grounded]` your message |
| R6 | Own on-call for your services | important | already_evidenced | E4 covers the rotation. Your material doesn't say the rotation covers your own services. | `[grounded]` your message |
| R7 | Distributed systems at scale | must-have | not_evidenced | Three services in a pipeline, plus Kafka and gRPC on the tools list. Nothing describes distributed-systems design work. Recall prompt C2. | `[grounded]` your message |
| R8 | Mentoring (mid-level engineers) | must-have | not_evidenced | E5 shows onboarding and a month of pairing with new hires. Onboarding isn't mentoring. Recall prompt C3. | `[grounded]` your message |
| R9 | Partner with product on roadmap order | important | not_evidenced | Nothing in your material. Named absence below. | `[grounded]` your message |

## Gaps you might be able to fill

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Go services handling high request volume | important | Daily Go use and three owned services, but nothing linking the two | It's the first line of the job description, so a reader will look for it first | The 40k requests/minute service is written in Go; you designed or rewrote one of the three in Go; the cache-layer rework was in Go | Repo or service README naming the language; the design doc | `[grounded]` what your message does and doesn't say; `[generic]` how early a reader looks for the headline requirement |
| C2 | Distributed systems at scale | must-have | Service count and request volume, but no design content | It's a must-have, and screeners for this kind of role tend to look for design work, not tool names | Partitioning or consumer-group design for Kafka in the ledger pipeline; consistency or idempotency handling between services; caching across instances in the balance-read rework | Design doc, architecture diagram, incident write-up | `[grounded]` what your message does and doesn't say; `[generic]` what screeners look for |
| C3 | Experience mentoring mid-level engineers | must-have | A month of onboarding pairing per new hire, two or three a year | The posting names mid-level engineers specifically, and that's different from onboarding new hires | Ongoing 1:1s with a mid-level engineer; reviewing someone's design docs over months; coaching a teammate into the on-call rotation or into incident-commander duty | A peer-review quote, a promotion packet you contributed to | `[grounded]` what your message does and doesn't say; `[generic]` how roles like this weigh mentoring |

**Named absence, R9 (product and roadmap):** Your material says nothing about working with product. Closing this would take one real example, such as negotiating with a PM about when the p99 work got scheduled. If there isn't one, it's listed as a responsibility rather than a requirement, so I'd leave it out and not write around it.

## Not written, and why

- **"Designed and shipped Go services"**: you never said the services are in Go, and you said you own them, not that you designed them. This waits on C1.
- **"Distributed systems at scale" / "high-throughput distributed systems"**: those are the posting's words. Yours describe a pipeline and a request rate.
- **"Mentored engineers"**: you onboard and pair with new hires for a month. Calling that mentoring changes the kind of work.
- **"Partnered with product on roadmap"**: nothing to trace it to.
- **"Own on-call for my services"**: you're on a rotation, and you didn't say which services it covers.
- **"Six incidents in two years"**: your sentence doesn't connect the six incidents to the two-year period.
- **"40k RPS" or any per-second version**: your figure is per minute.

## Format check

You pasted text rather than a file, so I couldn't check layout: columns, tables, headers and footers, images, or file type. Send the .docx or PDF and I'll run those checks. The section names I used (Summary, Experience, Skills) are standard ones that parsers recognise.

## What more material would unlock

- **The actual CV file:** runs the format check, and replaces "your message" with your CV's real wording.
- **The cache-rework design doc, or a dashboard showing p99:** would back up E2.
- **A redacted post-incident review where you were incident commander:** would back up E4.
- **A design doc for the ledger pipeline:** could close C2 directly.

## Questions

C1: Are the three ledger services, especially the one at 40k requests/minute, written in Go, Rust, or a mix? Did you design any of them, or take them over?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Have you made design decisions about how the ledger pipeline's services coordinate, such as Kafka partitioning, retries or idempotency, or consistency between services?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: Beyond the first-month pairing, have you guided any mid-level engineer over a longer stretch, through 1:1s, design reviews, or getting them ready for on-call?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.