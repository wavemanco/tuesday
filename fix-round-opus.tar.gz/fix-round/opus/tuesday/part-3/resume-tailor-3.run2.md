I've read the resume-tailor playbook and checked the dossier rules. I'm skimming the last two reference sections, then I'll build your edit ledger.
# CV tailoring: Product Manager, Platform APIs at Quartzline

I'm using the dossier's role profile, its evidence-map judgments on R1 and R2, its pending edit E1 and its two rejected inferences. I haven't re-judged anything it already decided. The dossier's `conditional_go` still stands. Whether to apply isn't part of this step.

I built this from the CV text you pasted. In the tables, the "current line" for each of your sentences is that sentence as you typed it. If your real CV words them differently, the quotes need checking. Nothing below is applied yet. Every row is waiting for your approval.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (currently sits inside your experience summary) | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv; carried over from dossier edit E1 | pending your approval |
| E2 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to first bullet under your role)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E3 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to second bullet, directly after E2)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." moved into a Skills section near the top | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end, and ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |

What each row deliberately keeps:
- **E1** keeps "internal" and "the whole team". It doesn't grow into "company-wide" or "the standard for".
- **E2** moves up without changing. "Ran… sessions collecting… feedback for product" doesn't become "shaped the roadmap".
- **E3** keeps "30+" attached to client integrations, and keeps "our REST APIs" as the vendor's APIs. It doesn't become APIs you built.
- **E4** keeps "Comfortable in". That word is your own level of claim.
- **E5** uses your title exactly as written. Both claims stay as separate clauses, so the feedback sessions don't read as roadmap ownership.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | 3+ years PM | must-have | `not_evidenced` | The dossier says R1 is adjacent, with a transferability gap at medium confidence. Adjacent work is visible through E2, E3 and E5. Roadmap ownership and authority to prioritise aren't shown. Recall prompt C1. | `[grounded]` dossier evidence_map R1 |
| K2 | Shipped API or platform products | must-have | `not_evidenced` | The dossier says R2 is adjacent, at medium confidence. You integrated clients onto the vendor's APIs, which is not the same as shipping the API product. Recall prompt C2. | `[grounded]` dossier evidence_map R2 |
| K3 | Technical fluency | important | `already_evidenced` | "Comfortable in Postman, SQL, OpenAPI specs." and "30+ client integrations of our REST APIs" both read clearly as they are. E4 makes them easier to find. | `[grounded]` cv |
| K4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E5. This is client-facing and product-facing work as you describe it. The JD's word "stakeholder management" is not used about you. | `[grounded]` cv |
| K5 | Own the API platform roadmap | important | `not_evidenced` | Your sessions fed into the roadmap, and someone else owned it. This is covered by C1. | `[grounded]` cv; dossier R1 reasoning |
| K6 | Discovery with integration partners | important | `not_evidenced` | Closest evidence: E2's quarterly feedback sessions. Collecting feedback for product is different work from running discovery. | `[grounded]` cv |
| K7 | Write specs and drive delivery with two engineering squads | important | `not_evidenced` | Named absence A1. C2 may partly recover it. | `[grounded]` cv |
| K8 | Define adoption metrics | important | `not_evidenced` | Recall prompt C3. | `[grounded]` cv |

## Gap handling

**Recall prompts.** The questions they lead to are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM / roadmap ownership | must-have | It shows 7 years feeding client input to product. It doesn't show you deciding what got built or in what order. | It's the posting's only must-have that's about experience. Screeners usually read "never held the title" as a gap unless they can see decision rights. | You decided the order of integration work across the 30+ clients. You chose what went into the playbook and what was cut. You ranked the client feedback before handing it to product, and product acted on your ranking. | A feedback summary or ranked list you sent to product. A planning doc showing your calls. | `[grounded]` what the CV does and doesn't say; `[generic]` how screeners treat missing PM titles |
| C2 | Shipped API or platform products | must-have | It shows deep use of an API from the vendor side. It doesn't show any change to the API itself. | This role owns the product partners integrate with. Delivery experience on the product side is the core of the job. | Problems you found during integrations that became endpoint or spec changes. An OpenAPI spec section, sample, or SDK snippet you wrote that shipped to clients. | The ticket or spec you wrote. A changelog entry that names your input. | `[grounded]` what the CV does and doesn't say; `[generic]` what platform-PM roles weigh |
| C3 | Define adoption metrics | important | No numbers appear except "30+" integrations. | The JD names metrics as part of the job. Measurement experience of any size helps. | You tracked time-to-integrate, go-live rates, or support tickets per integration. You measured how the team used the playbook. You used SQL to report on client usage. | A dashboard, a query, or a quarterly report. | `[grounded]` what the CV does and doesn't say |

**Named absence A1: writing specs and driving delivery with engineering squads.** Nothing in your material shows you directing engineering work. One project would close this gap: a scoped piece of internal tooling or API work where you write the spec and an engineer builds it. If C2 turns up a spec you wrote, part of the gap closes now.

## Not written, and why

- **"Product Manager" or "3+ years of product management".** You've never held the title. The dossier rates this as adjacent with medium confidence, and writing a CV line doesn't raise that.
- **"Owned the roadmap" or "shaped the product roadmap".** You ran sessions that fed the roadmap. Owning it is a different job.
- **"Shipped / launched / built our REST APIs".** You led integrations of them. Changing the verb would change the kind of work you did.
- **"Ran discovery with integration partners".** That's the posting's wording. Yours is "roadmap-input sessions collecting client feedback". "Partners" and "discovery" would claim more than you've said.
- **"Drove delivery with engineering teams" or "wrote product specs".** Nothing you've told me supports these. See A1.
- **"Defined adoption metrics" or "drove playbook adoption".** "The whole team uses" isn't a metric, and no measurement appears in your CV.
- **A changed job title** such as "Technical Product Lead", or just "Implementation Lead". The first upgrades your title. The second picks one half of "solutions engineer / implementation lead" without knowing whether those were one job or two.
- **From the dossier's rejected inferences, unchanged:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership"; "has been the customer of a partner API platform — candidate worked vendor-side".

## Parse-safety check

Your CV arrived as pasted text, so I couldn't check columns, tables, text boxes, images, headers or footers, or file type. The ledger assumes standard section headings: Summary, Experience and Skills. If your file uses different headings, tell me. The posting's terms "REST APIs", "OpenAPI", "Postman", "SQL" and "roadmap" already appear in lines that trace to your own sentences, so a keyword search would find them without adding anything.

## What would improve this

- **Your actual CV file (.docx or PDF).** It lets me run the layout checks and quote your real lines instead of your summary.
- **The integration playbook, or an excerpt.** For a PM role, a document you wrote is the kind of evidence that could raise R1/R2 confidence above medium.
- **One feedback summary from a roadmap-input session that you sent to product.** This would show whether you ranked the feedback or only collected it, which is C1's core question.

## Questions

**C1:** Over those 7 years, was there any decision about what got built, or in what order, that was yours to make rather than something you recommended? For example, sequencing client integrations or ranking feedback that product then acted on.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2:** Did anything you found during integrations become a change to the API itself, such as a spec edit, a new endpoint or a sample? If so, did you write the request or spec?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3:** Did you ever track a number about integrations or the playbook, such as time to go-live, ticket volume or team usage, even informally in SQL?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.