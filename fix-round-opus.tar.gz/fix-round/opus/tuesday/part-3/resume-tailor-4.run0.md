I need to correct one assumption before the edits: keyword matching probably isn't what's rejecting you. In one vendor's interviews with 25 US recruiters, only "2 of 25" had content-based auto-rejection turned on (cite C25). That sample is small, but the same recruiters said "When automated filters are used, they're almost always knockout questions" (cite C26), meaning yes/no questions on the application form about work authorisation, licences or location. Where match scores exist, "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). So keywords mostly decide how soon a person looks at your resume, not whether one does.

The coverage map below shows the bigger problem. Most of this posting's stack (Terraform, ArgoCD, Istio, Prometheus, Grafana, Vault, EKS, Helm, GitLab, Go) isn't in your history. Rewording can't add it, and I won't add it, because an interviewer would ask about it within minutes. Two things are fixable. First, your Kubernetes and pipeline work can be put up front, worded honestly. Second, your file layout may be hiding the keywords you do have (see the file check below).

I haven't seen the resume itself, only your description of it. So every edit below quotes your own words from your message, and the "Current line" column is blank.

## Proposed edits

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(not seen)* | "Ran a two-month Kubernetes proof-of-concept; it did not go to production." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E2 | Experience | *(not seen)* | *(unchanged, moved to the first bullet of your current role)* "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |
| E3 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your description | pending your approval |
| E4 | Skills | *(not seen)* | "Python and Bash scripting; AWS (EC2, S3, RDS, IAM); Docker; Jenkins; Ansible for config management; CloudWatch for monitoring" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your description | pending your approval |
| E5 | Skills | *(not seen)* | "Kubernetes (two-month proof-of-concept, not production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |

- **E1 and E5** get "Kubernetes" into the text in a form you can stand behind. "Did not go to production" stays because it's the honest part, and an interviewer will ask.
- **E2 and E3** put your strongest evidence first. "About 30" stays attached to "Jenkins jobs", with your "about" kept.
- **E4** puts Python and AWS first because the posting names them. It says "scripting", as you did, not "development".
- **The job title stays "DevOps Engineer".** I'm not retitling it "Platform Engineer".

## How your resume covers the posting

The posting doesn't rank its requirements, so the priorities are my reading of it.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes, hands-on exposure | must-have | `surfaced_by_edit` | E1, E5: a proof-of-concept only | `[grounded]` your description; `[inferred]` must-have, because EKS, ArgoCD, Istio and Helm all sit on Kubernetes |
| R2 | Kubernetes run in production | must-have | `not_evidenced` | Question C1 | `[grounded]` "never went to production" |
| R3 | Own platform reliability; SRE practices | must-have | `not_evidenced` | Question C2; CloudWatch is related but different work | `[grounded]` the posting's "You will own platform reliability" |
| R4 | Developer experience | important | `not_evidenced` | Nothing you wrote says who used the pipeline or how; I won't infer it | `[grounded]` the posting |
| R5 | CI/CD | important | `surfaced_by_edit` | E2, E3: Jenkins | `[grounded]` your description |
| R6 | GitLab CI specifically | important | `not_evidenced` | Question C3 | `[grounded]` the posting |
| R7 | AWS | important | `already_evidenced` | Your skills list: EC2, S3, RDS, IAM | `[grounded]` your description |
| R8 | AWS EKS | important | `not_evidenced` | Question C1: did the proof-of-concept use EKS? | `[grounded]` the posting |
| R9 | Python | important | `already_evidenced` | E4: scripting. This only counts if the parser can read your skills section (see file check) | `[grounded]` "Bash and Python scripting" |
| R10 | Terraform | important | `not_evidenced` | Question C3; Ansible is config management, not the same thing | `[grounded]` your description |
| R11 | Prometheus, Grafana, observability | important | `not_evidenced` | Question C2 | `[grounded]` "CloudWatch for monitoring" |
| R12 | Helm | important | `not_evidenced` | Question C1 | `[grounded]` the posting |
| R13 | ArgoCD, GitOps | important | `not_evidenced` | Named gap G1 | `[grounded]` the posting |
| R14 | Istio, service mesh | important | `not_evidenced` | Named gap G2 | `[grounded]` the posting |
| R15 | Vault | important | `not_evidenced` | Named gap G3 | `[grounded]` the posting |
| R16 | Go | important | `not_evidenced` | Named gap G4 | `[grounded]` the posting |

## What would close each gap

| # | Requirement | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| C1 | Kubernetes in production, EKS, Helm | A two-month proof-of-concept that never went to production | Kubernetes underlies most of this posting's stack | The proof-of-concept ran on EKS; you wrote or installed Helm charts; you deployed real services to it; you wrote up findings or a recommendation | A design doc, a repo, a slide deck from the proof-of-concept | `[grounded]` what you described; `[generic]` what this costs on Kubernetes-centred platform roles |
| C2 | Reliability, SRE practices, observability | "CloudWatch for monitoring" | The role statement is reliability ownership | You set up CloudWatch alarms or dashboards; you were on call; you handled incidents or wrote postmortems or runbooks | A runbook, an alarm config, a postmortem with the confidential parts removed | `[grounded]` what your description does and doesn't say; `[generic]` what this costs on SRE-leaning roles |
| C3 | Terraform, GitLab CI, Vault, Prometheus | Not mentioned | Each one you've really used becomes a keyword you can honestly include | Terraform in a side project; GitLab CI in an earlier job or open source; Vault or Secrets Manager for credentials | A repo, a merge request, a config file | `[grounded]` that it's absent; `[generic]` how these tools usually appear |

**Gaps with nothing to pull from (unless your answer to C3 changes that):**

| # | Gap | What would close it | Provenance |
|---|---|---|---|
| G1 | You haven't used ArgoCD or GitOps | A public repo where you deploy an app to EKS or a local cluster through ArgoCD, with Helm and Terraform. That one project would also cover R8, R10 and R12. | `[grounded]` that it's absent; `[generic]` that a home-lab repo is the proof engineers usually keep |
| G2 | You haven't used Istio or any service mesh | Add Istio to the same lab project. It isn't worth delaying this application for. | `[grounded]` that it's absent |
| G3 | You haven't used Vault | Add Vault-managed secrets to the lab project | `[grounded]` that it's absent |
| G4 | You haven't written Go | A small Go command-line tool or Kubernetes controller. It takes months to become credible, so it's not a short-term fix. | `[grounded]` that it's absent |

## What I didn't write, and why

- **"Production Kubernetes experience" or "managed Kubernetes clusters":** your proof-of-concept never went to production.
- **"Platform Engineer" as your title:** that's an upgrade, not an equivalent.
- **"Observability" for CloudWatch:** that's the posting's word, and you wrote "monitoring". It would claim the practice the posting asks for.
- **"Infrastructure as Code (Terraform)" based on Ansible:** they're different tools doing different jobs.
- **"CI/CD with GitLab" or "GitOps pipelines" based on Jenkins:** you built it in Jenkins.
- **"Owned platform reliability" or "improved developer experience":** nothing you wrote supports either yet. C2 might.
- **"Python development":** you wrote "scripting".
- **A skills line listing posting tools you haven't used, even as "familiar with":** this is the usual "ATS optimisation", and it's a list of things you'd be asked about and couldn't answer.

## Checking your file for parsing problems

This is based only on your description. I couldn't open the PDF, so I couldn't check whether it has selectable text, which file type it is, or whether it contains any hidden text.

| Check | What you described | What breaks | What it costs |
|---|---|---|---|
| Multi-column layout | Two columns | Parsers often read straight across both columns | Text from the two columns gets mixed together, and dates can come loose from their jobs |
| Images or icons | "icons for each skill" | Icons can come out as garbage characters or be skipped | If a skill's name appears only as an icon, the parser sees no keyword at all. This is the one real keyword problem you can fix. |
| Contact details in the header | "contact details in the header" | Headers are sometimes discarded as page decoration | Recruiters may not get your contact details |
| File type | Canva PDF | Some exports flatten text into images | If the text can't be selected, nothing gets read |

You can test this yourself: open the PDF, select all, copy, and paste into a plain text editor. If the text comes out jumbled, missing, or without your skill names and email, a parser probably sees the same thing.

## What would make this better

- **Paste your resume's text.** I can then fill in the real current lines and quote your exact wording instead of your summary.
- **Send the PDF.** I can run the parsing checks I couldn't do above.
- **Share anything from the proof-of-concept** (repo, doc or deck). C1 could then become an inspectable, stronger edit.
- **Separate question:** with this many gaps, the job-underwriter module can help you decide whether this role is worth applying to, or whether a DevOps role that leads with AWS and CI/CD is a better target for now.

## Questions

**C1:** In the Kubernetes proof-of-concept, what did you actually set up: was it on EKS, did you use Helm, and did any real service run on it?
**C2:** With CloudWatch, did you set up alarms or dashboards, take on-call shifts, or handle and write up incidents?
**C3:** Have you used Terraform, GitLab CI, Vault, Prometheus or Go anywhere (a past job, a side project, open source), even in a small way?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.