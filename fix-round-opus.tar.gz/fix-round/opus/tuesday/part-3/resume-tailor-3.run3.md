I've read the resume-tailor instructions and your dossier, and here's the edit list. One caveat first: your dossier rates this role a `conditional_go`, and the conditions are the same gaps listed below. I can't write around them, only point them out. I also worked from the CV summary you pasted, not the CV file, so the section names are my best guess.

## Edit list (nothing applied yet)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (currently sits among other duties) | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; carried over from the dossier's pending edit E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, above E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Summary | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

What these rows deliberately keep:
- **E1** keeps "the whole team uses". It doesn't become "company-wide" or "standardised".
- **E3** keeps "roadmap-input" and "for product". Those words say you fed the roadmap, and the hiring manager will ask whether you owned it.
- **E4** keeps your "solutions engineer / implementation lead" wording, with no product-style title. It stays as three separate sentences so the feedback sessions don't read as part of running the integrations.
- **"30+"** stays attached to "client integrations" everywhere.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Your work is close to PM but not PM, and the dossier says why: roadmap ownership and authority to prioritise aren't shown, confidence medium. E3 and E4 show the closest work. Recall prompt C1 | `[grounded]` dossier evidence_map R1; CV "Never held a PM title." |
| R2 | Shipped API or platform products | important | `not_evidenced` | Close but not the same, confidence medium. You integrated your company's APIs, you didn't ship them. E2 shows the closest work. Recall prompt C2 | `[grounded]` dossier evidence_map R2 |
| R3 | Technical fluency | important | `already_evidenced` | "Comfortable in Postman, SQL, OpenAPI specs." plus E2's REST APIs | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3 move the client-facing work up front. The phrase "stakeholder management" itself isn't written | `[grounded]` CV |
| R5 | Discovery with integration partners | important | `surfaced_by_edit` | E3 is the closest thing: client feedback collected for product. It isn't discovery, and they were your clients, not partners | `[grounded]` CV |
| R6 | Write specs and drive delivery with two eng squads | important | `not_evidenced` | Nothing shows authoring product specs or running delivery. Being comfortable with OpenAPI specs isn't the same thing. Recall prompt C1 | `[grounded]` CV |
| R7 | Define adoption metrics | important | `not_evidenced` | Your CV has no metrics. Recall prompt C3 | `[grounded]` CV |

## Gap handling

**Never having a PM title is a gap no wording can close.** It's a must-have, and you've never held the title. The realistic way to close it is to show PM *work* (C1) and let the interview judge whether it counts. If C1 comes back empty, a "technical PM" or "integrations PM" role a step down, or a solutions-to-product internal move, closes it more reliably than this application.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM; write specs; drive delivery | must-have | Integration leadership and feeding input to the roadmap. Nothing shows you decided what got built | Owning the roadmap is the first duty listed. Without any decision-making evidence, R1 reads as a straight miss | You wrote requirements for engineering on an integration gap; you decided the order of playbook or tooling work; you ran an internal project with engineers to a release | A requirements doc or ticket you wrote, a playbook changelog | `[grounded]` what the CV does and doesn't say; `[generic]` how PM screens usually treat roadmap ownership |
| C2 | Shipped API or platform products | important | You integrated your company's APIs for clients | Platform PM screens usually look for a hand in what the API *became* | Client feedback you turned into a specific endpoint or API change that shipped; deprecation or versioning work you coordinated | Release notes or a ticket naming you | `[grounded]` CV and dossier R2; `[generic]` platform-PM screening pattern |
| C3 | Define adoption metrics | important | No numbers anywhere | The posting names metrics as a core duty | You tracked time-to-go-live across the 30+ integrations; error or ticket rates before and after the playbook; usage numbers you reported to product | A dashboard, a QBR (quarterly business review) slide, a SQL query you ran | `[grounded]` CV; `[generic]` role-family expectation |

## Not written, and why

- **"Product Manager", or "X years of product management"**: you wrote "Never held a PM title."
- **"Owned" or "drove the API roadmap"**: your own word is "roadmap-input", and the dossier records ownership as not shown.
- **"Shipped" or "launched REST APIs"**: you integrated them. Changing the verb changes the kind of work.
- **"Ran discovery with integration partners"**: that's the posting's vocabulary. You collected feedback from your own clients, and "partners" would move which side of the table you sat on.
- **"Wrote product specs" or "drove delivery with engineering"**: nothing in your CV supports either yet (C1).
- **Any adoption or impact metric**: none was given (C3).
- **"Playbook adopted company-wide"**: you said "the whole team".
- **From the dossier's rejected inferences, unchanged:** "built an internal request-triage tool". That came from my memory, not from you, and you couldn't confirm you owned it. Also "has been the customer of a partner API platform": you worked vendor-side.

## Parse-safety check

You pasted text, so I couldn't check layout, columns, tables, headers and footers, or hidden text. Send the file and I'll run those checks. One thing I can say now: use standard section headings ("Summary", "Experience", "Skills"), and send it as `.docx` or a PDF with selectable text.

## Upgrade menu

- **The integration playbook itself** (redacted is fine). It's the one inspectable artifact you have, and it would turn E1 from your own claim into checkable evidence. It may also answer C1.
- **A write-up you sent product from a roadmap-input session.** It would show whether your input shaped decisions, which is the R1 question.
- **An older version of your CV.** Older versions often contain specifics the current one dropped.

## Questions

C1 — Was there ever a time you decided *what* engineering built and in what order, or wrote the requirements they built from? If so, what was it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did any feedback from your integrations or roadmap-input sessions become a specific API change that shipped, and what part of that was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you track or report any numbers on the integrations or the playbook, such as time to go live, ticket volume or usage?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.