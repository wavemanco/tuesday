Now the files it names.
Nadia, the dossier said conditional go. Here is the ledger to tailor your CV for the Quartzline Platform APIs PM role. **Nothing has been applied yet:** I'll build the tailored CV only from the rows you approve.

**What I worked from.** You gave me six sentences about your CV, not the document itself, so each "current line" below is your own sentence. From the dossier I used the R1 and R2 assessments, the pending edit E1 and the two claims you already rejected. The dossier excerpt didn't include the role profile, so I used the job description you pasted. It also didn't assess technical fluency or stakeholder management, so I judged those two myself from your sentences.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." (dossier E1: currently not its own line) | "Wrote the internal integration playbook the whole team uses." (its own bullet) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged: moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged: moved to second bullet, above E1)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |

Why the rows are written this way:
- **E4 keeps three separate sentences.** Joining them would make collecting feedback read like part of running the roadmap, and none of your sentences says that.
- **"30+" stays attached to "client integrations."**
- **"Our REST APIs" stays.** You integrated the APIs; nothing here says you built them.
- **E1 keeps "the whole team."** It does not say "company-wide."

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | `not_evidenced` | You've never held a PM title. The dossier rated this adjacent: a transferability gap at medium confidence, because roadmap ownership and prioritisation authority aren't shown. The nearby work is in E4, E2 and E3. Recovery is C1. | `[grounded]` dossier R1; CV |
| 2 | Shipped API or platform products | important | `not_evidenced` | Integrating your employer's APIs is shown (E2). Shipping the API product itself is not. The dossier rated this adjacent at medium confidence; the excerpt didn't give its gap type. Recovery is C2. | `[grounded]` dossier R2; CV |
| 3 | Technical fluency | important | `already_evidenced` | "Comfortable in Postman, SQL, OpenAPI specs" plus the REST API integrations come across on one read. E2 puts the integrations first. | `[grounded]` CV |
| 4 | Stakeholder management | important | `surfaced_by_edit` | E2 shows end-to-end client integrations and E3 shows sessions feeding product. The JD's phrase itself isn't used about you. | `[grounded]` CV |
| 5 | Own the roadmap | important | `not_evidenced` | You ran sessions that fed input to product. Owning the roadmap isn't shown. Recovery is C1. | `[grounded]` CV; dossier R1 reasoning |
| 6 | Discovery with integration partners | important | `surfaced_by_edit` | E3 shows you collected client feedback for product. That reads as related work, not as discovery you ran for a roadmap of your own. | `[grounded]` CV |
| 7 | Write specs, drive delivery with two engineering squads | important | `not_evidenced` | Your CV shows no specs engineers built from and no work with engineering teams. A playbook is not a product spec. Recovery is C2. | `[grounded]` CV |
| 8 | Define adoption metrics | important | `not_evidenced` | Your CV has no metric of any kind. Recovery is C3. | `[grounded]` CV |

## Gaps: what would close them

| # | Requirement | Priority | What your CV shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM / own the roadmap | must-have | That you collected client feedback for product. Not whether you decided anything with it. | This is the one must-have. Without evidence that you decided priorities, the PM-years requirement rests only on related work. | Ranking session output before it went to product; deciding the order or scope of integration phases with a client; deciding what went into the playbook and when it was revised | Session summaries or decks you wrote; a prioritised feedback list | `[grounded]` what the CV does and doesn't say; `[generic]` what this costs when switching into PM |
| C2 | Shipped API products / write specs | important | That you're comfortable with OpenAPI specs. Not that you wrote one. | Writing specs is half of the day-to-day job described. | An endpoint or field a client integration needed that you wrote up and engineering built; an OpenAPI change you drafted; a requirements doc for an integration feature | The spec or ticket; a changelog entry it led to | `[grounded]` what the CV does and doesn't say; `[generic]` how hiring panels test spec writing |
| C3 | Define adoption metrics | important | No measure of any kind. | The posting asks you to define these measures yourself. | Time to go-live per integration; number of clients live; API usage after launch | A dashboard, report or QBR slide you produced | `[grounded]` what the CV does and doesn't say |

## What I didn't write, and why

- **"Product Manager" or "product management experience."** You've never held the title. The gap is named above instead.
- **"Owned the roadmap."** You ran sessions that fed product, which is a different job.
- **"Ran discovery with integration partners."** Those are the JD's words. Yours are "collecting client feedback for product."
- **"Partners" in place of "clients."** It's the posting's word, and it would change the commercial relationship you described.
- **"Shipped" or "built" our REST APIs.** You integrated them.
- **"Authored OpenAPI specs."** "Comfortable in" is not the same as wrote.
- **"Drove delivery with engineering squads" or "defined adoption metrics."** No evidence for either yet. C2 and C3 could change that.
- **"Playbook adopted company-wide."** You wrote "the whole team."
- **"Stakeholder management" as a phrase about your own history.** It stays the JD's term.
- **"Built an internal request-triage tool."** This came from my memory, and you couldn't confirm owning it (you rejected it in the dossier).
- **"Has been the customer of a partner API platform."** You worked on the vendor side (you rejected this in the dossier).

## Parse-safety check

I couldn't run it. You gave me sentences, not the file, so I can't check for columns, tables, text in headers or footers, icons, hidden text or file type. Nothing in your sentences raises a parse risk.

## What more input would add

- **The CV itself** (a .docx or a PDF with selectable text). I could quote your current lines and their order exactly and run the parse check.
- **The full dossier.** The role profile and the remaining assessments would mean I inherit the technical-fluency and stakeholder-management calls instead of making them myself.
- **The integration playbook.** It's something an interviewer can actually inspect, and it's the strongest proof you have.
- **Answers to the questions below.** Each one could turn a gap into a real CV line.

## Questions

C1: From the quarterly roadmap-input sessions, did you decide or rank which client requests went to product, or did product take the raw feedback and prioritise it themselves?
C2: Have you ever written a spec, requirements doc or OpenAPI change that engineers built from, and did it ship?
C3: Across the 30+ integrations, did you track or define any measure, such as time to go-live, clients live, or API usage after launch?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.