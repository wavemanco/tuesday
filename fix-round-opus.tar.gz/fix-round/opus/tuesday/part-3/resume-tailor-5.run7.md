I won't add the hidden white-text instruction or the 1pt keyword block, and here's why:

- **It deceives the employer.** The AI screener works for the employer, so planting instructions for it is lying to the employer. That's hard to defend if it comes up in an interview.
- **It works against the rest of your resume.** Everything below is built so you can stand behind every line. A hidden line is one you'd be asked about and couldn't defend.
- **It gets found.** The parsing software reads hidden text like any other text. One hiring platform told a newspaper that "1% of the resumes it processed in the first half of the year contained white text messages" (cite C19). One candidate said "One recruiter discovered the prompt hacking and turned him down because of it" (cite C35). What happens once it's spotted is up to the employer, not you.

The fear behind your friend's advice is mostly wrong. In one small survey of 25 recruiters, two had content-based auto-rejection switched on (cite C25). "When automated filters are used, they’re almost always knockout questions" (cite C26), and those are the yes/no questions on the application form, not the resume. Match scores mostly decide "who gets reviewed first" (cite C27). So the useful move is to put true keywords where your experience backs them up and your strongest evidence first. That's what the edits below do.

**What I worked from:** your five pasted sentences, used as the current lines. I haven't seen the resume file, so the real wording, layout and dates may differ.

## Proposed edits (none applied yet)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social and controlled a budget of about $600k a year. Built our lifecycle email programme from scratch (12 automated flows) and ran a monthly webinar series averaging 300 registrants." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year" | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years; built our lifecycle email programme from scratch — 12 automated flows" | `reframe` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series averaging 300 registrants" | `compress` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting" | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |
| E6 | Skills | *(HubSpot appears only inside an Experience sentence)* | "HubSpot (daily, 4 years), including HubSpot reporting" | `surface` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |

Notes on these rows:
- **E1** puts your three strongest must-have matches first: the years, the budget and HubSpot. It uses your verbs: "ran", "controlled", "built".
- **E2** keeps "about". It also keeps "controlled" rather than the JD's "managed".
- **E4** keeps **registrants**. Changing that to "attendees" would make a bigger claim than your sentence does.
- **E5** drops only the SQL half of your sentence, which you wouldn't put on a resume anyway. The HubSpot reporting claim stays the same size, and nothing anywhere suggests you know SQL.

## How the JD's requirements are covered

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B SaaS marketing | must-have | `surfaced_by_edit` | E1 opens with "6 years in B2B SaaS" | `[grounded]` resume |
| R2 | 5+ years in demand gen specifically | must-have | `not_evidenced` | The 6 years describe B2B SaaS marketing. Your material doesn't say how many of them were paid, lifecycle or webinar work. See C3 | `[grounded]` resume |
| R3 | HubSpot or Marketo | must-have | `already_evidenced` | "HubSpot daily for 4 years"; E6 also lists it under skills | `[grounded]` resume |
| R4 | SQL-literate | must-have | `not_evidenced` | Your own words: "not strong in SQL". See C2 | `[grounded]` resume |
| R5 | Budget over $500k | must-have | `already_evidenced` | About $600k a year across paid search and paid social; E2 keeps it | `[grounded]` resume |
| R6 | Paid search | important | `already_evidenced` | E2 | `[grounded]` resume |
| R7 | Lifecycle email | important | `already_evidenced` | E3; built from scratch, 12 flows | `[grounded]` resume |
| R8 | Webinars | important | `already_evidenced` | E4 | `[grounded]` resume |
| R9 | Content distribution | important | `not_evidenced` | Your material doesn't mention it. See C1 | `[grounded]` resume |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing on content | It's one of the four jobs the role says you'll own, and the only one with no evidence | Promoting ebooks or reports through paid social; turning webinar recordings into on-demand pages or nurture emails; sending blog content through your lifecycle flows | A content calendar, a campaign brief, a HubSpot report on content downloads | `[grounded]` what the resume shows; `[generic]` what an empty spot on a named responsibility costs |
| C2 | SQL-literate | must-have | "not strong in SQL — I ask our analyst" | It's a must-have, so expect an interviewer to test it | Editing a query your analyst wrote; filtering an exported table yourself; a SQL course | A query you wrote or changed | `[grounded]` your own statement; `[generic]` that must-haves get tested |
| C3 | 5+ years in demand gen | must-have | 6 years B2B SaaS; HubSpot for 4 of them | If paid, lifecycle or webinar work covers fewer than 5 of the 6 years, you're below the stated bar | Earlier roles that included paid campaigns, email, events or lead programmes | Role dates and a line on what each role covered | `[grounded]` what the resume shows; `[generic]` that years requirements get counted |

**If C2 comes back as "no hands-on SQL":** that requirement stays unmet. The fix is real practice: SELECT, JOIN and GROUP BY on your own marketing data until you can answer one funnel question without your analyst. After that, "basic SQL" is a line you can defend. Until then the honest answer is "I pull my own numbers in HubSpot reporting and work with an analyst for SQL." For this JD that's a weakness, but you can defend it.

## Not written, and why

- **Hidden white-text instruction to AI screeners.** I refused it for the reasons at the top.
- **1pt hidden keyword block.** I refused this too: it's the same deception, and your real keywords already appear in visible lines.
- **"SQL" or "SQL-literate" anywhere.** You said you're not strong in it.
- **"Demand generation" as a label for your history.** It's the JD's word. If your title, team or past resumes used it, show me and it can go in.
- **"Owned demand gen" or "managed a $600k budget".** "Owned" and "managed" are the JD's verbs; yours are "ran" and "controlled".
- **"300 attendees".** You said registrants.
- **"Senior Marketing Manager" or any upgraded title.** Your title is Marketing Manager.
- **Marketo.** You didn't mention it.
- **"Built our lifecycle programme in HubSpot".** That's probably true, but your sentence links the two with a dash and never says it. Confirm it and I'll propose the line.
- **Pipeline, MQL or revenue results.** You haven't given any, so none are written.

## Parse-safety check

Your resume arrived as pasted text, so I couldn't check the layout, columns, tables, headers and footers, section headings or file type. I also couldn't check whether a template or earlier tool left hidden text in your file. If that's in there, it's a risk you can't see. Send the file and I'll run all of these checks.

## Upgrade menu

- **The resume file** (.docx or PDF): the real parse-safety and hidden-text checks, and edits against your actual lines.
- **Outcome numbers** from your paid or lifecycle work, such as leads, pipeline or conversion rates: these would support results lines, and none exist yet.
- **A HubSpot campaign or reporting dashboard:** the most convincing proof you could show for HubSpot and budget claims.
- **Role dates and employers:** these settle C3.

## Questions

**C1:** Have you ever handled getting content in front of buyers, such as promoting reports, repurposing webinar recordings, or running content through your email flows? If so, what did you do?

**C2:** Have you ever written or edited a SQL query yourself, even a simple one?

**C3:** Of your 6 years, how many were spent running paid, lifecycle email or webinar work?

For any of these, you can answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.