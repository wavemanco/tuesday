I won't add the hidden text or the 1pt keyword block. The tailoring is below in full, and nothing in it is applied until you approve it.

**Why I won't add the hidden text:**
- **It deceives the employer.** It works by misleading software that reads applications on the employer's behalf. You'd be judged on lines you didn't write and couldn't defend if asked.
- **It gets found.** The software that reads your PDF sees white and 1pt text the same as any other text. One hiring platform said "1% of the resumes it processed in the first half of the year contained white text messages" (cite C19). ManpowerGroup says it finds hidden text in "about 10% of the resumes it scans with AI" (cite C18). One candidate told the NYT that a recruiter "discovered the prompt hacking and turned him down because of it" (cite C35). After that, what happens is up to the employer.
- **You don't need it.** Your real experience covers most of this posting. Put the matching keywords where your experience backs them up, and put your strongest lines first. That gets you found honestly. The edits below do both.

## Edit ledger

You gave me a summary, not the resume file. So the "Current line" column shows the sentence you wrote. Your title stays **Marketing Manager**.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social, controlling a budget of about $600k a year. Built our lifecycle email programme in HubSpot from scratch — 12 automated flows." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social; controlled a budget of about $600k a year." | `compress` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your background | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme in HubSpot from scratch — 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E4 | Skills | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot — daily use for 4 years" | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your background | pending your approval |
| E5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers in HubSpot reporting." | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |
| E6 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged; Experience bullets ordered E2, E3, this line, E5)* | `reorder` | "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants."; "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` your background | pending your approval |

Notes on the edits:
- **E1** never uses the phrase "demand generation." That's the posting's term, not yours. Paid search, lifecycle email and webinars are demand generation, and a reader will see that from what you list.
- **E3 and E4** split your HubSpot sentence in two. The "4 years" goes in Skills, so it isn't dropped when the bullet gets shorter.
- **E5** keeps only the reporting half of your sentence. It doesn't stand in for SQL (see C2 below).

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1. Your 6 years are as a Marketing Manager in B2B SaaS. Calling them "demand gen" is left to the reader, not written in for you | `[grounded]` your background |
| R2 | HubSpot or Marketo | must-have | surfaced_by_edit | E3, E4. HubSpot only | `[grounded]` your background |
| R3 | SQL-literate | must-have | not_evidenced | C2. You said you're "not strong in SQL" | `[grounded]` your background |
| R4 | Managed a budget over $500k | must-have | surfaced_by_edit | E1, E2. About $600k a year, kept as "about" | `[grounded]` your background |
| R5 | Paid search | important | surfaced_by_edit | E2, placed first by E6 | `[grounded]` your background |
| R6 | Lifecycle email | important | surfaced_by_edit | E3 | `[grounded]` your background |
| R7 | Webinars | important | already_evidenced | Your line works as written. E6 only moves it | `[grounded]` your background |
| R8 | Content distribution | important | not_evidenced | C1 | `[grounded]` nothing you shared mentions it |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | No mention of getting content out beyond webinars and email | It's one of the four channels the role owns, and the only one with nothing behind it | Promoting webinar recordings after the live session; running gated content (ebooks, reports) as offers in your paid campaigns; sending blog or resource content through lifecycle flows; working with partners to share content | A campaign list, a HubSpot content or landing-page report, a paid campaign showing content offers | `[grounded]` what you shared does and doesn't say; `[generic]` what an unfilled channel costs on applications like this |
| C2 | SQL-literate | must-have | You "pull my own numbers in HubSpot reporting" but you're "not strong in SQL" and ask an analyst | It's listed as a requirement. HubSpot reporting is a different skill from SQL, so E5 doesn't fill this gap | This is a real gap, not a wording problem. To close it: a few weeks of SQL basics, then write the queries you currently ask your analyst for, yourself, against your own marketing data. Once you have, it can go on the resume truthfully. Until then, say it straight in interviews: "I self-serve in HubSpot reporting and I'm learning SQL" | A query you wrote yourself, even one the analyst checked; a course you finished | `[grounded]` your own statement; `[generic]` what a missing listed requirement costs |

Missing a listed must-have raises the question of whether this role is worth applying to. That's job-underwriter's call, not this module's.

## Not written, and why

- **White-text instruction to the AI screener.** Refused, for the reasons at the top.
- **A hidden 1pt keyword block.** Refused for the same reasons. The keywords your experience supports are now in visible lines (E1 to E4).
- **"Senior Marketing Manager."** That's the posting's title, not yours.
- **"6 years of demand generation" / "Owned demand generation."** These use the posting's words for your past. "Own" is the posting's verb; yours is "ran."
- **"SQL" in Skills.** You told me you're not strong in it.
- **"Content distribution."** Nothing you shared mentions it (see C1).
- **"300 attendees."** You said registrants. Attendance is a different, smaller number.
- **"$600k+" or "over $500k budget."** You said "about $600k." "About" stays.
- **"Marketo."** You only mentioned HubSpot.

## Parse-safety check

| Check | Result |
|---|---|
| Columns, tables, text boxes, icons, header/footer content | Couldn't check: I got pasted text, not the file |
| Section headings | Use standard labels (Summary, Experience, Skills) so parsers recognise them |
| File type | A `.docx` or a PDF with a real text layer is the safe pair |
| Hidden text already in the file | Couldn't check without the file. Templates and old tools sometimes leave some behind |

## Upgrade menu

- **Your actual resume file:** I could run the layout checks, look for leftover hidden text, and quote your real current lines instead of your summary.
- **Results numbers you already have** (pipeline, MQLs, or opportunities from paid search, the email flows or the webinars): demand gen hiring managers look for outcomes, and right now every line describes activity. I'd add only numbers you give me.
- **A webinar or email performance report:** this would give you a document to back up the 300-registrant and 12-flow claims if an interviewer asks.

## Questions

C1: Have you ever promoted content beyond the live webinar, for example by sending out the recordings, using gated content in paid campaigns, or putting blog content into your email flows?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: When you say "not strong in SQL," have you ever written or edited a query yourself, even one the analyst checked? Or have you never written one?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.