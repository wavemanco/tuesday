The keyword gap is real, but adding keywords won't close most of it. This posting lists 16 skills. Your experience honestly covers about four: Kubernetes (as a proof of concept only), CI/CD (through Jenkins, not GitLab), Python and AWS (not EKS). For Terraform, ArgoCD, Istio, Prometheus, Grafana, Vault, Helm, GitOps and Go, nothing you've told me supports listing them. Putting them on the resume would mean claiming tools you'd be asked about in the first technical screen. So this pass does two things: it makes sure the true keywords you have can be read and found, and it names the rest as gaps with a way to close each one.

**On "the ATS is auto-rejecting me":** the evidence is thinner than the folklore. In one vendor's interviews with 25 US recruiters, "AI/content auto-rejection configured: 8% of recruiters" (cite C25). That's two people, so it shows the practice exists but is uncommon in that small sample. The same recruiters said "When automated filters are used, they're almost always knockout questions" (cite C26). Those are the yes/no questions on the application form, such as work authorization or location. Where match scores are used, "Many teams use match scores/filters to prioritize who gets reviewed first" (cite C27), and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). So keywords probably affect *how soon* you're read more than *whether* you're read.

**Your file format is a likelier culprit than your wording.** A two-column Canva PDF, skill icons and contact details in the header are three common ways a resume gets scrambled when software converts it to text. The check below covers this.

I haven't seen your PDF, so the "current line" column below uses your own sentences from your message.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "Bash and Python scripting" | "Python scripting" and "Bash scripting" as two separate skills entries, Python first | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to first bullet under DevOps Engineer)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E3 | Experience | *(you didn't say whether it's on the resume now)* | "Ran a two-month Kubernetes proof-of-concept (not taken to production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E4 | Skills | "AWS (EC2, S3, RDS, IAM)" | *(unchanged, moved to the top of the skills list)* | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |

Notes on the rows:
- **E3** keeps "not taken to production" on purpose. Without it, the word "Kubernetes" will be read as production experience, and the first follow-up question will expose that. The qualifier is what lets you talk about it with confidence. Add the year yourself; I didn't turn "last year" into a date.
- **E2** keeps "about 30" and "deploy pipeline". I didn't write "CI/CD pipeline", because you described deploying and didn't mention builds or tests. Question C3 asks about that.

## Coverage map

The posting doesn't rank its skills, so I haven't made up must-haves from a tools list. Only the stated responsibility is marked must-have.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Own platform reliability, SRE practices | must-have | `not_evidenced` | Recall prompt C2 | `[grounded]` JD; your message |
| 2 | Developer experience | must-have | `not_evidenced` | Related work in E2; recall prompt C3 | `[grounded]` JD; your message |
| 3 | Kubernetes | important | `surfaced_by_edit` | E3, proof of concept only; recall prompt C1 | `[grounded]` your message |
| 4 | CI/CD | important | `surfaced_by_edit` | E2 (Jenkins); recall prompt C3 | `[grounded]` your message |
| 5 | Python | important | `surfaced_by_edit` | E1 | `[grounded]` your message |
| 6 | AWS EKS | important | `not_evidenced` | Other AWS services in E4; recall prompt C1 | `[grounded]` your message |
| 7 | Helm | important | `not_evidenced` | Recall prompt C1 | `[grounded]` your message |
| 8 | Prometheus, Grafana, observability | important | `not_evidenced` | CloudWatch is related; recall prompt C2 | `[grounded]` your message |
| 9 | GitLab CI | important | `not_evidenced` | Named absence | `[grounded]` your message |
| 10 | Terraform | important | `not_evidenced` | Named absence | `[grounded]` your message |
| 11 | ArgoCD, GitOps | important | `not_evidenced` | Named absence | `[grounded]` your message |
| 12 | Istio, service mesh | important | `not_evidenced` | Named absence | `[grounded]` your message |
| 13 | Vault | important | `not_evidenced` | Named absence | `[grounded]` your message |
| 14 | Go | important | `not_evidenced` | Named absence | `[grounded]` your message |

## Recovery per gap

**Recall prompts** (the questions themselves are at the end):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Kubernetes, EKS, Helm | important | A two-month proof of concept that didn't reach production. It doesn't say what ran, where, or what part was yours. | Kubernetes underlies most of this posting's tools, so the proof of concept is your strongest true link to the role. | Whether the cluster was EKS; whether you wrote Helm charts or manifests; what workload you deployed; whether you presented findings | A repo, a design doc, a demo recording, a write-up of the findings | `[grounded]` what you told me; `[generic]` platform roles of this kind usually centre on Kubernetes |
| C2 | Reliability, SRE, observability | must-have | "CloudWatch for monitoring". It doesn't say whether you set alarms, built dashboards, went on call or handled incidents. | Reliability is the one responsibility this posting names. | CloudWatch alarms or dashboards you set up; an on-call rotation; an incident you diagnosed; a post-mortem you wrote | An alarm config, a dashboard screenshot, a post-mortem | `[grounded]` what you told me and the JD |
| C3 | CI/CD, developer experience | must-have | You built a Jenkins deploy pipeline and maintain about 30 jobs. It doesn't say whether the pipeline builds and tests code, or who relies on it. | If it does builds and tests and other developers depend on it, that is real CI/CD and real developer-experience work. | Build and test stages; how many teams or developers deploy through it; deploy time or failure rate before and after | The Jenkinsfile, the job list, a pipeline run log | `[grounded]` what you told me |

**Named absences:**
- **Terraform:** you haven't used it. Ansible is configuration management, which is different from infrastructure-as-code provisioning. To close it: provision something real with Terraform. The project below would do it.
- **ArgoCD / GitOps:** you haven't used it. To close it: deploy to a cluster through ArgoCD from a Git repo.
- **Istio / service mesh:** you haven't used it. This is the hardest gap and the least worth closing just for an application. Learn the concepts for interviews, but don't list it.
- **Vault:** you haven't used it. IAM is related but not the same thing. To close it: add Vault-managed secrets to the project below.
- **GitLab CI:** you haven't used it. To close it: run the project's pipeline in GitLab CI. Coming from Jenkins, this is the quickest gap to close.
- **Go:** you haven't used it. To close it: a small Go tool or Kubernetes operator in the same repo. Otherwise, rely on Python.

One public repo would close six of these gaps with something a hiring team can inspect: EKS provisioned with Terraform, apps deployed by ArgoCD via Helm, Prometheus and Grafana, Vault, GitLab CI.

## Prohibited claims: not written, and why

- **"Platform Engineer" as your title.** Your title is DevOps Engineer. Changing it is the kind of thing a background check catches.
- **"Production Kubernetes", "managed Kubernetes clusters", "EKS".** You ran a two-month proof of concept that "never went to production".
- **"Terraform" or "Infrastructure as Code" for Ansible.** These are different tools for different jobs.
- **"Observability stack" for CloudWatch.** That's the posting's word, not yours. "CloudWatch for monitoring" is accurate.
- **"CI/CD pipeline".** You said "deploy pipeline". This waits on C3.
- **Owning "platform reliability".** Nothing you've told me shows ownership yet. This waits on C2.
- **Any hidden or invisible keyword block.** Software reads hidden text, it can be found, and it would put lines on your resume you couldn't defend.

## Parse-safety check

These are risks I can see from your description. I haven't redesigned anything.

| Check | Your resume | What it costs |
|---|---|---|
| Multi-column layout | Two columns | Software may read across both columns line by line and mix them up, so dates and bullets get separated from their roles |
| Icons | An icon for each skill | **If any skill appears only as an icon, it doesn't exist as text**, and the keyword you're worried about is missing entirely |
| Content in the header | Your contact details | Headers are sometimes thrown away during parsing, which can leave you unreachable |
| File type | Canva PDF | Fine if the PDF has real, selectable text. To test, select all the text, paste it into a plain text editor, and read what comes out in order |

I couldn't check your section headings, hidden template text or the actual text layer without the file.

## Upgrade menu

- **Your resume's text** (copy and paste from the PDF): I'd replace my assumed "current lines" with your real ones and run the full check.
- **The proof-of-concept repo or write-up:** would move E3 from your word to something a reader can inspect.
- **Optional, beyond this pass:** a scoped plan for the portfolio project above, built only if you want it. It's the one move that turns several gaps into real resume lines.

Whether this role is worth applying to now, with these gaps, is a question for job-underwriter.

## Questions

**C1:** In the Kubernetes proof of concept, where did the cluster run (EKS or something else), what did you deploy, and which parts did you build yourself, such as manifests, Helm charts or networking?
**C2:** Beyond collecting CloudWatch metrics, did you set up alarms or dashboards, go on call, or diagnose an incident? If so, what's one example?
**C3:** Does your Jenkins pipeline build and test code as well as deploy it, and roughly how many developers or teams use it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.