I've drafted the edits as a list for you to approve or reject one at a time. Nothing has been applied yet. One note before the table: you sent a summary of your CV, not its actual lines. So I've treated your own sentences as the current lines. Every proposed line below draws only on those sentences, and each one quotes the sentence it came from.

Overall, your CV already covers the core of this job: response time at the slow end (p99), high request volume, on-call and running incidents. The real gaps are working with product on the roadmap and mentoring mid-level engineers.

## Proposed edits

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Software engineer, 7 years; currently Senior Software Engineer at a payments company. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV summary | pending your approval |
| E2 | Experience (first bullet) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the top of your current role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your CV | pending your approval |
| E3 | Experience (second bullet) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your CV | pending your approval |
| E4 | Experience (third bullet) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Incident commander on six incidents; on-call every fourth week for two years." | `reframe` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your CV | pending your approval |
| E5 | Experience (fourth bullet) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires to my team, usually two or three a year, pairing with each for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your CV | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python · gRPC, Kafka, Postgres · Terraform, Datadog" | `reorder` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your CV | pending your approval |

Why some rows are worded the way they are:
- **E1:** "Senior Software Engineer, 7 years" could mean 7 years in total or 7 years at senior level. I took the reading that claims less. If you've been senior for all 7 years, tell me and I'll change it.
- **E3:** The 40k requests/minute is for one service, not all three. That's why "about," "at peak" and "one" all stay. It also doesn't say "Go services," because your CV doesn't say which language those services are written in.
- **E4:** This puts incident commander first, since the job lists "strong incident response" as a requirement. It doesn't say "on-call for my services," because your CV doesn't connect the rotation to your three services.
- **E5:** This says "onboard," not "mentor." Pairing with new hires for a month is real, but it's different from mentoring mid-level engineers (more on that below).

## How the CV covers the job

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | `already_evidenced` | "7 years" plus owning services. The CV doesn't say whether your Python years were backend work | `[grounded]` CV text; `[generic]` readers usually count a senior title with service ownership toward this |
| R2 | Production Go | must-have | `surfaced_by_edit` | E6 puts Go first in Skills. E1 states "daily for 4 years." Question R2 below could make it stronger | `[grounded]` |
| R3 | Distributed systems at scale | must-have | `surfaced_by_edit` | E3 moves "about 40k requests/minute at peak" near the top. Kafka and gRPC are in Skills via E6 | `[grounded]` |
| R4 | Strong incident response | must-have | `surfaced_by_edit` | E4 leads with "incident commander on six incidents" | `[grounded]` |
| R5 | Experience mentoring | must-have | `surfaced_by_edit` | E5 covers onboarding and month-long pairing. That's what your CV shows, not ongoing mentorship | `[grounded]` |
| R6 | Drive down p99 latency | important | `surfaced_by_edit` | E2 makes the 380ms → 95ms result your first bullet. The cache-layer rework also fits a build-cache platform, but only as a fact about the job | `[grounded]` |
| R7 | Own on-call for your services | important | `already_evidenced` | "every fourth week for two years," and E4 keeps it | `[grounded]` |
| R8 | Mentor mid-level engineers | important | `not_evidenced` | See C2 | `[grounded]` |
| R9 | Partner with product on roadmap sequencing | important | `not_evidenced` | See C1 | `[grounded]` |

## The gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Partner with product on roadmap sequencing | important | Nothing about product, planning or prioritisation | It's one of five core duties in the job description | Arguing for the cache rework against feature work; ordering the ledger-pipeline migrations; scoping work with a product manager each quarter | A planning doc, an RFC with a section on order of work, a roadmap you contributed to | `[grounded]` what the CV says; `[generic]` senior roles at small dev-tools companies often probe this |
| C2 | Mentor mid-level engineers | important | Onboarding new hires for their first month | The job asks for mentoring mid-level engineers, and your CV shows mentoring people who are new | Ongoing 1:1s with an engineer after onboarding; reviewing a mid-level engineer's design doc; coaching someone through their first incident command | Review threads, a design doc you coached on, a promotion packet you wrote input for | `[grounded]` what the CV says; `[generic]` interviewers will ask for a mentoring example |

## Things I won't write, and why

- **"Designed and shipped Go services":** Your CV doesn't say your services are in Go (you use Go and Rust), or that you designed them. You said you own them.
- **"Distributed systems at scale":** That's the job description's wording, not yours. "About 40k requests/minute at peak" is more concrete and you can defend it.
- **"40k requests/minute across three services":** The number belongs to one service.
- **"Mentored engineers" / "mentor mid-level engineers":** Your CV describes onboarding pairing. Changing the verb changes what kind of work it was.
- **"Owned on-call for my services":** Your CV doesn't connect the rotation to your services.
- **"Partnered with product on the roadmap":** Your CV has no evidence of this. It's covered in C1 instead.
- **Any build-cache or developer-tools experience:** You didn't mention any. Your cache-layer work is real, but it's not build caching.

## Will screening software read it?

You pasted text, not a file, so I couldn't check for columns, tables, text boxes, icons, content in headers or footers, file type, or hidden text. Send the file and I'll run those checks. The only check that applies to your text is section headings. Use standard ones (Summary, Experience, Skills) so the software can tell what each section is.

## What would make this stronger

- **Your actual CV file:** I could quote your real lines and run the full screening check.
- **A dashboard screenshot or postmortem showing the p99 drop:** You'd have proof ready for the most likely interview question.
- **A redacted postmortem from one of the incidents you ran:** It supports R4 with real material.
- **A planning doc or RFC:** It could close C1.

## Questions

C1: Have you ever had a say in what your team built first, or in what order? For example, did you argue for the cache rework ahead of other work, or help a product manager plan a quarter?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Beyond the first month, have you kept supporting any of those hires, or guided a mid-level engineer through a design or an incident?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R2: Which of your three ledger services are written in Go? If any are, E3 can say "Go services" honestly.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.