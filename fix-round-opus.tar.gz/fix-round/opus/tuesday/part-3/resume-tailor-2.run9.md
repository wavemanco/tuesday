I've read the tailoring playbook. Here is your ledger.

**Read this first.** Your resume can be tailored to show this role's modelling and dbt work clearly. It can't make you meet the bar, and no honest wording will. Three of the four must-haves aren't supported by what you sent: 3+ years of data engineering, production Python, and Airflow or a similar orchestrator. The fourth, dimensional modelling, is supported. A resume that hints otherwise falls apart at the first technical screen, when someone asks "walk me through a DAG you wrote." Whether it's worth applying with that gap is a separate decision, and the job-underwriter module is built for it.

One assumption: you sent prose, not the resume itself. So the "Current line" column quotes your sentences from this message, not lines from the document.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models, including the core orders mart. Designed the orders mart's star schema with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your own description; nothing to inspect yet, expect a probe | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your own description | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our data engineer at the time" | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your own description | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke and added tests to it" | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your own description | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Two bullets: "Python for analysis (pandas)" and "Wrote Python scripts to pull vendor APIs on a cron" | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your own description | pending your approval |
| E6 | Skills | *(no current line)* | "SQL (Redshift; window functions, CTEs) · dbt · Python (pandas) · cron" | `surface` | "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your own description | pending your approval |

Notes on what these rows hold back:
- **E3 keeps "with our then-DE."** Dropping it would turn shared design work into solo design.
- **E4 says "fixed when it broke,"** not "owned pipeline reliability" or "maintained SLAs."
- **E5 says "some scripting,"** not "built ingestion pipelines."
- **Your job title stays "Senior Data Analyst."**

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | `not_evidenced` | Related work appears in E1–E4, but under an analyst title. Recovery prompt C1 | `[grounded]` |
| R2 | Production Python | must-have | `not_evidenced` | E5 shows the cron scripts as they are. Whether they count as "production" is unknown. Recovery prompt C2 | `[grounded]` |
| R3 | Airflow or equivalent orchestration | must-have | `not_evidenced` | You said you've never used Airflow. What schedules the nightly dbt job is unknown. Recovery prompt C3 | `[grounded]` |
| R4 | Dimensional modelling / model the warehouse | must-have | `surfaced_by_edit` | E3 and E1. Shared design with a DE, so expect questions on which decisions were yours | `[grounded]` |
| R5 | Data quality | important | `surfaced_by_edit` | E4 covers the tests you added. Owning SLAs isn't covered (see R9) | `[grounded]` |
| R6 | Build and own batch pipelines | important | `not_evidenced` | E2 shows dbt transformation work. Building whole pipelines isn't shown | `[grounded]` |
| R7 | Spark | important | `not_evidenced` | Named gap below | `[grounded]` |
| R8 | Streaming / Kafka | preferred | `not_evidenced` | Named gap below | `[grounded]` |
| R9 | Own SLAs | important | `not_evidenced` | Named gap below | `[grounded]` |
| R10 | Partner with analytics on requirements | important | `not_evidenced` | You've been the analytics side of that partnership, not the engineering side. Named gap below | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years as an analyst, with dbt and modelling work. It doesn't say how long the dbt work has been a regular part of your job | This is the posting's headline must-have, and your title doesn't meet it | Years of keeping the dbt project running; being the person who covered for the DE; owning the orders mart after the DE left | Git history of the dbt repo; a role description; a manager's note | `[grounded]` what the resume says; `[generic]` a title gap on a must-have usually gets screened hard |
| C2 | Production Python | must-have | Analysis Python, plus cron scripts that pull vendor APIs | The JD asks for production code, and the gap between analysis code and production code is what gets probed | Cron output landing in tables that dashboards or dbt models read from; retries, logging or alerting in those scripts; scripts in version control with code review | The script repo; a table that depends on the scripts | `[grounded]` what the resume says; `[generic]` interviewers usually probe how production code was deployed and tested |
| C3 | Airflow or equivalent orchestration | must-have | You've never used Airflow, and the resume doesn't say what runs the nightly job | "Or equivalent" leaves room if dbt Cloud jobs, Dagster, Prefect or a similar tool scheduled your work | dbt Cloud job setup; cron with dependencies between steps; another team's scheduler that you configured jobs in | Job configs; screenshots of the scheduler | `[grounded]` what the resume says; `[generic]` cron alone rarely passes as "equivalent orchestration" |

**Named gaps, and what would close each one:**
- **Spark (R7):** You've never used it. To close it: a hands-on project where you run PySpark jobs on a real dataset you can show. Done over a few weekends, it becomes a portfolio line, not a work claim.
- **Kafka/streaming (R8):** You've never touched it. It's listed as a plus, not a requirement, so it isn't worth closing for this application. A small Kafka-to-warehouse project would help in later DE applications.
- **SLAs (R9):** Fixing a job when it breaks is not owning an SLA. Unless there was a defined freshness target you were responsible for (tell me if there was), this stays an interview talking point about how you'd approach it.
- **Partnering with analytics (R10):** You were the customer, not the engineer. That's useful context in an interview ("I know what analysts need from a DE") but it isn't a resume line.

## Prohibited claims

Not written, and why:
- **"Data Engineer" or "Analytics Engineer" as your title.** You held neither title. A retitle can't be an upgrade.
- **"Built and owned batch pipelines."** You built dbt models. Owning a pipeline end to end is different work.
- **"Production Python."** Your words are "Python for analysis" and "some scripting." C2 might change this. Wording can't.
- **"Orchestrated workflows" or "managed scheduling."** You've never used Airflow, and a cron script isn't orchestration unless C3 shows something more.
- **Spark, Kafka or streaming anywhere,** including the skills list. A tool you haven't used doesn't go in the keyword list.
- **"Owned data quality and SLAs."** That's the JD's wording. Yours is "fixed… when it breaks and added tests."
- **"Led" or "owned" warehouse modelling.** You designed the schema with the DE, and E3 keeps that.
- **"Partnered with analytics."** That's the JD's wording, and it would put you on the engineering side of a relationship where you were the analyst.

## Parse-safety check

Your resume arrived as prose, so I couldn't check layout, columns, tables, headers and footers, section headings or file type. Send the document and I'll run the check on it. On keywords: once E6 is applied, the terms you can back up (dbt, Redshift, SQL, Python) are easy to find. Airflow, Spark and Kafka are left out on purpose.

## Upgrade menu

- **The actual resume file.** The "Current line" column would then quote the document exactly, and the parse check could run.
- **The dbt repo or its test config.** Would turn E2 and E4 from claims you'd have to back up verbally into evidence an interviewer can inspect.
- **The vendor-API scripts.** Would decide C2 one way or the other.

## Questions

C1: For how many of your 5 years have the dbt models and the nightly job been your regular responsibility, and did you take over any of the DE's work after they left?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2: Do the outputs of your vendor-API cron scripts feed tables that other people or dbt models depend on, and do the scripts have retries, logging or alerting?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3: What actually triggers the nightly dbt job: dbt Cloud, cron, or another scheduler, and did you set it up or change it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.