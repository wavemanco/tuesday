Sam, here's the tailoring pass. Nothing has been applied yet: every proposed change below waits for your approval.

## First, the ATS premise

Keywords probably aren't why you're being rejected, at least not on their own.

- **Automatic rejection by content is less common than people think.** In one small vendor study, recruiters said "When automated filters are used, they're almost always knockout questions" (cite C26). Those are the yes/no questions on the application form, such as work authorisation or location. Only 2 of 25 recruiters had content-based auto-rejection switched on (cite C25), and a sample that small can't say how rare it really is.
- **Keywords matter for ranking.** The same study found "Many teams use match scores/filters to prioritize who gets reviewed first," and "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). It's my inference that keywords drive those scores.

That points at two things you can fix and one you can't:

1. **The file may be erasing keywords you already have.** A two-column layout, skill icons and contact details in the header are the classic ways text gets lost when software reads a resume. The parse-safety section below covers this.
2. **Some of your real experience isn't on the page in a way a reader can find.** The ledger fixes that.
3. **Most of this posting's stack isn't in your experience yet.** That includes Kubernetes in production, EKS, Terraform, ArgoCD, Helm, Istio, Vault, Prometheus, Grafana, GitLab CI and Go. No wording closes that gap honestly. I've listed each one as a gap with a way to close it, not as a line to write anyway.

**What I assumed:** I haven't seen the PDF. Your message describes your resume, so I've treated the sentences you wrote as its content and quoted them as your source.

## Requirements

The posting doesn't mark any requirement as must-have or nice-to-have, so I ranked them by how central each is to "own platform reliability and developer experience":

- **Must-have:** Kubernetes, AWS EKS, Terraform, CI/CD, observability (Prometheus/Grafana)
- **Important:** GitOps/ArgoCD, Helm, SRE practices, Python, platform reliability, developer experience
- **Preferred:** Istio/service mesh, Vault, GitLab specifically, Go

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the first bullet under DevOps Engineer)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved to the second bullet under DevOps Engineer)* | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "Cloud: AWS (EC2, S3, RDS, IAM)" / "Containers: Docker" / "CI: Jenkins" / "Config management: Ansible" / "Monitoring: CloudWatch" / "Scripting: Bash, Python" as plain-text lines | `split` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your message | pending your approval |
| E4 | Skills | *(no current line)* | "Kubernetes (two-month proof-of-concept, not in production)" added under the "Containers" line | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your message | pending your approval |
| E5 | Summary | *(no current line)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your message | pending your approval |

Notes on the rows:

- **E1 and E5:** "our" and "about 30" stay attached to "Jenkins jobs". The jobs aren't turned into pipelines, and "deploy pipeline" isn't turned into the posting's word "CI/CD". I don't know where this bullet sits now. If it's already first, reject E1.
- **E2 and E4:** "proof-of-concept" and "two months" stay. That's the honest version, and an interviewer would find the production gap in one question anyway. If the PoC isn't on your resume at all, E2 adds it from what you've told me.
- **E3:** Each tool becomes plain text with a category label, so a parser can read the words even if the icons are lost.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes, hands-on | must-have | `surfaced_by_edit` | E2, E4. The PoC only, qualifier kept | `[grounded]` |
| R2 | Kubernetes in production | must-have | `not_evidenced` | Named absence N1 | `[grounded]` |
| R3 | AWS EKS | must-have | `not_evidenced` | Recall prompt C1. AWS itself is in E3; EKS is not | `[grounded]` |
| R4 | Terraform | must-have | `not_evidenced` | Recall prompt C2. Ansible is config management, a different job | `[grounded]` |
| R5 | CI/CD | must-have | `surfaced_by_edit` | E1, E5. This is Jenkins, not GitLab | `[grounded]` |
| R6 | Observability (Prometheus/Grafana) | must-have | `not_evidenced` | Recall prompt C3. CloudWatch monitoring is related work | `[grounded]` |
| R7 | Python | important | `already_evidenced` | "Python scripting", made easier to find by E3 | `[grounded]` |
| R8 | Helm | important | `not_evidenced` | Recall prompt C1 | `[grounded]` |
| R9 | GitOps / ArgoCD | important | `not_evidenced` | Named absence N2 | `[grounded]` |
| R10 | SRE practices / platform reliability | important | `not_evidenced` | Recall prompt C3 | `[grounded]` |
| R11 | Developer experience | important | `not_evidenced` | Named absence N3 | `[grounded]` |
| R12 | Istio / service mesh | preferred | `not_evidenced` | Named absence N4 | `[grounded]` |
| R13 | Vault | preferred | `not_evidenced` | Named absence N4 | `[grounded]` |
| R14 | GitLab CI | preferred | `not_evidenced` | Named absence N5 | `[grounded]` |
| R15 | Go | preferred | `not_evidenced` | Named absence N5 | `[grounded]` |

## Gaps

**Recall prompts:** gaps where you may have experience you haven't mentioned. The questions are at the end.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS, Helm | must-have | A two-month Kubernetes PoC. It doesn't say where it ran or how things were deployed | EKS is the posting's named platform, and Kubernetes is the core of it | The PoC ran on EKS rather than minikube or kind; you wrote or installed Helm charts; you containerised a real service for it | The PoC's repo, manifests or chart files, or a write-up | `[grounded]` what the resume says; `[generic]` what this costs in platform-role screening |
| C2 | Terraform | must-have | Ansible for config management; no provisioning tool | Platform teams usually provision through infrastructure-as-code | Any Terraform, even one module; CloudFormation; provisioning the PoC cluster with code | A repo, a merged change, a module | `[grounded]` what the resume says; `[generic]` what this costs |
| C3 | Observability, SRE practices | must-have | "CloudWatch for monitoring" | The role "will own platform reliability" | Alarms and dashboards you built; being on call; incident follow-ups you wrote; Prometheus or Grafana used anywhere, PoC included | A dashboard screenshot, a runbook, an incident review | `[grounded]` what the resume says; `[generic]` what this costs |

**Named absences:** gaps with nothing to look for, and how each one could be closed.

- **N1, Kubernetes in production:** You haven't run it in production. Closing this takes real time on production workloads. A homelab won't replace that, but a public repo running a full EKS setup (Terraform, Helm, ArgoCD, Prometheus) would make "hands-on" something a reader can inspect.
- **N2, GitOps / ArgoCD:** Not in your experience. You could close it in a weekend project, for example ArgoCD syncing that repo. Only list it once you've done it.
- **N3, Developer experience:** Nothing you've told me shows it. If other teams deploy through your pipeline, that would count, but only if you say so; I won't assume it.
- **N4, Istio and Vault:** Not in your experience. These are preferred skills. I wouldn't chase them for this application.
- **N5, GitLab CI and Go:** Not in your experience. Your Jenkins work transfers to GitLab, but the resume should keep saying "Jenkins". Go is preferred, and only real code would close it.

## Not written, and why

- **"Kubernetes in production" or "managed Kubernetes clusters":** You ran a two-month PoC that never went to production.
- **Retitling you "Platform Engineer":** That's a different title from the one you held, which would be an upgrade, not an equivalent.
- **"Designed CI/CD pipelines" or "CI/CD (GitLab)":** You wrote "deploy pipeline in Jenkins". Swapping in the posting's words changes what you did and what you did it with.
- **"Observability" for CloudWatch:** Monitoring with one AWS service and owning observability are different kinds of work.
- **"Infrastructure as code (Ansible/Terraform)":** You used Ansible for config management. Putting it next to Terraform suggests provisioning experience you haven't described.
- **A skills block of the posting's tools, "familiar with Terraform/EKS/Helm", or any hedged version:** This is the keyword-stuffing move. It might raise a match score, but it puts tools on your resume that you can't answer for in the first technical screen.

## Parse safety

These are risks to check, not design advice.

| Check | What I see | Risk |
|---|---|---|
| Multi-column layout | Two columns | Text from the two columns can get mixed together, and dates can separate from the roles they belong to |
| Icons | One icon per skill | If any skill appears only as an icon or logo, the software reading the resume never sees the word. That would hit AWS, Docker and Python first |
| Contact details in header | Yes | Headers can be dropped, which leaves you with no contact details |
| File type | Canva PDF | This is fine only if the PDF has a real text layer. A `.docx` or a PDF with a text layer is the safe pair |
| Section headings, hidden text, tables and text boxes | Not checked | I haven't seen the file, so these checks couldn't run |

**Quick self-test:** open the PDF, select all, paste into a plain-text editor, and read the result. If skills are missing or your columns are interleaved, that's the problem to fix first.

Whether this role is worth applying for, given N1 to N5, is a job-underwriter question.

## What would strengthen this

- **The PoC's repo or manifests:** This would turn R1 from your own account into something a reader can inspect, and it might settle C1.
- **Any Terraform or CloudFormation you've written:** This might settle C2.
- **A CloudWatch dashboard, runbook or incident write-up:** This would support C3.
- **The PDF itself, or its pasted text:** I could then run the checks that couldn't run.

## Questions

**C1:** Where did the Kubernetes PoC run (EKS or something local), and did you use Helm or write the manifests yourself?
**C2:** Have you written any Terraform or CloudFormation, even one module or a single change?
**C3:** Beyond CloudWatch, have you set up alarms or dashboards, been on call, or written up an incident?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.