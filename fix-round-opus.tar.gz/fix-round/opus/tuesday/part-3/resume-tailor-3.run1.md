I've read the resume-tailor instructions and your dossier; the ledger is below.

**What this is built on:** the five sentences you pasted, in the order you pasted them, and your dossier. It inherits the dossier's calls as they are: R1 and R2 stay `adjacent` at `medium` confidence, its edit E1 is used rather than redone, and its two rejected inferences are carried over word for word. Because you pasted a summary rather than the CV itself, the "current line" in each row is your own sentence, not a line I could see on the page.

## Edit ledger: `resume_edits_pending_approval`

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own bullet | `surface` | "Wrote the internal integration playbook the whole team uses." (dossier `application_plan` E1: "surface the integration playbook authorship into its own line") | `[grounded]` CV + dossier | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, moved to second bullet, above the playbook line)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved above Experience)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | "Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

Notes on what the rows protect:
- **E2 and E5 keep "client" and "our REST APIs".** You implemented your employer's APIs for its clients. You didn't build or ship them. Those words keep your side of the work accurate, and "30+" still counts integrations.
- **E3 keeps "for product".** You collected feedback that went to the product team. That's real evidence for this role, but it isn't owning the roadmap, and the line shouldn't imply that you did.
- **E4 keeps "Comfortable in".** That's your own level claim, so I didn't turn it into a bare list.
- **E5 is two sentences on purpose.** Joining them would make the integrations read as part of the title. There's no PM wording in it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | `not_evidenced` | Related work is in E3 and E5. The dossier says roadmap ownership and decisions about what gets built first aren't shown → C1 | `[grounded]` dossier evidence_map R1 + CV |
| R2 | Shipped API or platform products | important | `not_evidenced` | Related work is in E2: you integrated APIs but didn't ship them. Dossier: `adjacent`, medium → C2 | `[grounded]` dossier evidence_map R2 + CV |
| R3 | Technical fluency | important | `already_evidenced` | "Comfortable in Postman, SQL, OpenAPI specs" and the REST integration work. E4 moves it higher | `[grounded]` CV |
| R4 | Stakeholder management | important | `surfaced_by_edit` | E2 and E3: client integrations end to end, plus quarterly sessions feeding the product team | `[grounded]` CV |
| R5 | Write specs and drive delivery with engineering | important | `not_evidenced` | Being comfortable with OpenAPI specs isn't the same as writing specs for engineers → C3 | `[grounded]` CV |
| R6 | Discovery with integration partners | important | `not_evidenced` | E3 is related (collecting client feedback), but research you ran yourself isn't stated. See "Gaps with no question" | `[grounded]` CV |
| R7 | Define adoption metrics | important | `not_evidenced` | Nothing in your material. See "Gaps with no question" | `[grounded]` CV |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM / roadmap ownership | must-have | Seven years in solutions and implementation roles, and quarterly sessions sending client feedback to product. It doesn't show you deciding what got built. | This is the posting's one stated must-have, and you've never held the title | You chose which feedback went to product and in what order; you scoped what an integration would and wouldn't include; you decided which fixes went into the playbook first | A summary you sent to product; a list of features that came from your sessions; a scoping doc | `[grounded]` what the CV does and doesn't say; `[generic]` screeners for PM roles usually look for prioritisation decisions first |
| C2 | Shipped API or platform products | important | You led integrations of APIs your employer shipped | Without it, your API work reads as customer-facing implementation rather than product work | An endpoint or field added because of your integrations; a change to the API docs you wrote; an SDK or connector you specced | A changelog entry, a pull request or ticket, a docs page | `[grounded]` CV; `[generic]` platform PM roles usually ask what you changed in the API itself |
| C3 | Write specs and drive delivery with engineering | important | You list OpenAPI specs as a tool you're comfortable with | The role works with two engineering teams, and specs are the main thing you'd hand them | Requirements you wrote for an integration build; tickets you wrote for engineers to deliver; an OpenAPI spec you wrote or changed | A redacted spec or ticket | `[grounded]` CV; `[generic]` spec samples are a common PM interview request |

**Gaps with no question, given the three-question limit:**
- **Discovery (R6):** your CV shows feedback collection, not discovery you led. To close it: if you ever ran interviews or problem-framing sessions yourself, tell me in a reply and it gets its own row. If not, write up one session's findings as a short work sample.
- **Adoption metrics (R7):** none of your material mentions it. To close it: if you ever tracked integration go-lives or API usage, that's a lead. If not, a one-page sketch of adoption metrics for an API is a fair way to show you can do it. It isn't worth a CV line you can't back up.

## Not written, and why

- **"Product Manager" or "3+ years of product management":** you've never held a PM title, and it's the must-have.
- **"Owned the API roadmap":** you ran sessions that fed input to the product team. The dossier records that ownership isn't shown.
- **"Shipped / built / launched REST APIs":** you led integrations *of* them. That changes both what kind of work it was and which side you sat on.
- **"Ran discovery with integration partners":** that's the posting's wording. Yours is "collecting client feedback".
- **"Managed integration partners":** your word is "client". Swapping it in moves you to the platform side of the relationship.
- **"Wrote API specs":** you listed a tool you're comfortable with, which isn't the same as producing the work.
- **"Playbook adopted company-wide":** you said "the whole team".
- **"Built an internal request-triage tool":** a lead from memory that you couldn't confirm as yours (rejected in the dossier).
- **"Has been the customer of a partner API platform":** you worked on the vendor side (rejected in the dossier).

## Parse-safety check

You pasted plain text, so I couldn't check columns, tables, images, headers and footers, headings or file type. Send the file (.docx or a PDF with a text layer) and I'll run those checks.

## Upgrade menu

- **The CV itself:** I'd quote real lines rather than your summary, and the parse checks above could run.
- **A redacted excerpt or the contents page of the playbook:** something an interviewer can actually look at, which moves E1 from what you've said toward what they can check.
- **Outputs from your roadmap-input sessions:** the strongest possible evidence for R1 and R6, if any feature can be traced back to them.

## Questions

C1: In those quarterly sessions or your integration work, was there a time you decided what got prioritised or cut, rather than passing feedback on for someone else to decide?
C2: Did any change to the REST APIs themselves (an endpoint, a field, a docs change) ship because of something you raised or wrote?
C3: Have you written requirements, tickets or an OpenAPI spec that engineers then built from?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.