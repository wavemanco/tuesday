**Yes, it's worth applying, on two conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: adjacent: R7 (BigQuery as the warehouse) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)

R7: a credible bridge from Snowflake, with its limit named. R8 and R9: your background doesn't mention them either way, so they're questions, not gaps.

**Opportunity ledger.** Sound and open about its terms. The employer and the live posting both check out (RR2), and the pay range sits across the market band (RR1). Three things are open: the equity terms (RR3), who you'd report to (RR4) and how big the team is (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is met: you're US-based or can work from Denver; (2) R7 is presented honestly as adjacent: Snowflake, not BigQuery.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, matched by search |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | One domain (reporting) end to end, from ingestion through modelling to contracts. The JD mentions no direct reports | `[inferred]` from the JD's responsibilities and its silence on managing people |
| Market calibration | For Senior Data Engineer at Series B–D, "Senior" typically means 5–8 years and one domain's pipelines with no reports. Base median is $151,000, interquartile range $139,000–$163,500. This posting's 5+ years and one-domain scope fit that norm. Its $148,000–$166,000 range starts $3,000 below the median and tops out $2,500 above the upper quartile (RR1) | `[generic]` role-family band from the Datawright 2026 report you supplied (n=2,310), not a search; `[grounded]` JD for the posted range |
| Unknowns | Equity terms; reporting line; team size; whether data contracts already exist or are yours to build | — |
| Contradictions | None between your pasted JD and the live careers page | `[grounded]` search result for the careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you can work in the US | `[grounded]` JD; your background is silent | Question 1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years, stated. Your typed background is self-report, so `medium` is the ceiling until something is inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily," stated | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | Built the company's dbt project on Snowflake, about 180 models. Snowflake meets the JD's "a cloud warehouse" as written | `[grounded]` your background; JD wording | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | Set up the Great Expectations test suite, stated | `[grounded]` your background | none |
| R7 | Running a dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | You've never used BigQuery; your dbt and warehouse work is on Snowflake. The modelling, testing and orchestration carry over. Limit: none of it was done on BigQuery's cost, partitioning or SQL-dialect specifics | `[grounded]` your own statement; `[inferred]` the carry-over, from dbt being warehouse-agnostic in your stated work | see G1 |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | Six years of pipelines suggests you've done ingestion, but your background doesn't name sources or tools | `[inferred]` from the general DE background; `[grounded]` silence on ingestion | Question 2 below |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | A Great Expectations suite is related but isn't the same as an agreed contract with consumers. Your background doesn't say whether analysts relied on schemas or guarantees you owned | `[grounded]` GE claim; `[inferred]` that it's related to contract work | Question 3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | dbt on Snowflake, about 180 models; no BigQuery | It's the platform you'd run on day one. A named bridge makes this easy to answer when it comes up | dbt patterns that don't depend on the warehouse (incremental models, tests, sources); any warehouse cost or performance tuning you did on Snowflake | A small personal dbt project on BigQuery; a sanitized dbt docs page or repo excerpt from the Snowflake project | `[grounded]` your statement; `[generic]` that warehouse switches get probed in interviews for this role family |
| G2 | App and CRM ingestion (R8, important) | discovery | Pipelines in general; no ingestion sources named | One of the three named responsibilities | Pulling from a product database or event stream; pulling a CRM (Salesforce, HubSpot) or an HR/payroll SaaS API; using Fivetran, Airbyte or custom Python extractors | An Airflow DAG excerpt, a pipeline diagram, a design doc | `[grounded]` silence in your background |
| G3 | Data contracts (R9, important) | discovery | A Great Expectations suite; no contracts with consumers stated | One of the three named responsibilities, and the one with the least visible evidence | Schema agreements with analysts or finance; dbt model contracts or versioned models; alerting consumers when a source changed | A contract spec, a dbt `contract:` config, a Slack or RFC write-up | `[grounded]` the GE claim; `[inferred]` that it's related |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, and across the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range covers the market median and goes past the upper quartile, so pay isn't a reason to pass | `[grounded]` JD; `[generic]` the Datawright band | Where in the range do you expect to place someone with 6 years? | noted |
| RR2 | Employer and posting confirmed | positive_signal | — | "Founded 2016, Denver. 264 employees." | The entity exists as described and the role is live | `[grounded]` careers and about pages, from search | — | noted |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The form, size and vesting of the grant are all unknown | `[inferred]` from the posting naming equity with no detail | What form does the equity take, how large is a typical grant at this level, and what's the vesting schedule? | unresolved |
| RR4 | No hiring manager or reporting line | unknown | — | (posting names no hiring manager) | You can't tell yet whether you'd report into data, engineering or analytics | `[grounded]` posting silent | Who would this role report to, and where does that person sit? | unresolved |
| RR5 | Team size unstated against an end-to-end mandate | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You could be the only owner of ingestion, warehouse and contracts, or one of several engineers | `[inferred]` from the scope language against no mention of a team | How many data engineers work on these pipelines today, and who's on call for them? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "built our dbt project on Snowflake, about 180 models" and "set up our Great Expectations test suite", in your own verbs | see R4, R6 | `[grounded]` your background | pending your approval |
| P2 | State BigQuery plainly: "dbt and warehouse modelling on Snowflake; no BigQuery yet". Never write "BigQuery" as a skill | see R7 | `[grounded]` your statement | pending your approval |
| W1 | Optionally, a small dbt-on-BigQuery personal project before the technical round | see R7, G1 | `[generic]` a work sample narrows a platform gap | pending your approval |
| Q1 | Ask the RR1, RR3, RR4 and RR5 questions word for word in the recruiter screen | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1, searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning senior data engineer careers", which returned "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer, accepting applications). Searched "Pellucid Learning online tutoring Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about). Checked your pasted material: both match. Fed role reality's organization and contradictions rows, and RR2 |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can save this as a `tuesday-dossier.md` if you want a file to carry into the next steps.

**Upgrade menu**
- Where you're based and whether you can work in the US → R1 closes, and the status likely moves to `go`.
- Answers to G2 and G3 → R8 and R9 resolve.
- A sanitized dbt docs page, repo excerpt or DAG from your Snowflake work → R4–R6 can rise to `high`.
- The hiring manager's name → role reality's scope read, and which story to lead with.
- Equity details from the recruiter → RR3 closes.
- A deeper pass on Pellucid (funding and leadership changes, hiring patterns, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1: Are you US-based, or otherwise able to work remotely in the US or from Denver?

G2: What sources have you ingested from: a product database, event streams, a CRM or other SaaS APIs? Which tools did you use, and which parts did you build?

G3: Did analysts or finance depend on schemas or guarantees you owned, and how did you tell them about breaking changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.