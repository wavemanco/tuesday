Many reference files. Read them in parallel.
Yes, it looks worth applying to, but check two things first. The web search and page fetch I tried were refused, so I couldn't confirm the posting is live. And you haven't said where you're based. Details below.

## Decision snapshot

**Yes, worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or our Denver office)
- `must_have`: direct: R2, R3, R4, R5, R7, R8
- `important`: adjacent: R6 (dbt-modelled warehouse in BigQuery) · unclear: R9 (Ingestion from our app and CRM), R10 (The data contracts our analysts depend on)

R6: a credible bridge from Snowflake, with its limit named; R9, R10: your background says nothing about these yet, which isn't the same as a gap; R2–R8 (`medium` each): stated by you, nothing to inspect yet.

**Opportunity ledger.** The role is coherent and well paid: the pay range sits at or above the market band (RR2) and the scope is concrete (RR6). The employer couldn't be confirmed from live sources this turn (RR1). The reporting line (RR3), the equity terms (RR4) and who has authority over data contracts (RR5) are unstated.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting checks out as live on Pellucid's own careers page (RR1); (2) you're US-based or able to work from Denver (R1); (3) BigQuery is presented as a new warehouse you're moving to from Snowflake, never as experience you have (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` your paste of the about page, not checked live |
| Mandate | Pipelines behind reporting: ingestion from app and CRM, a dbt warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Requirements | 5+ yrs DE; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver | `[grounded]` JD |
| Scope read | Owns one domain's pipelines (reporting), with no mention of managing people | `[inferred]` from the JD's mandate and its silence on direct reports |
| Market calibration | Senior DE at Series B–D: median base $151k, IQR $139k–$163.5k, "Senior" usually 5–8 yrs, one domain's pipelines, no reports. The posting's low end ($148k) is just under the median; its high end ($166k) is above the 75th percentile. This is a market band, not this employer's offer | `[generic]` Datawright 2026 report (US, n=2,310), from your recruiter; `[grounded]` JD for the posted range; `[inferred]` that the posted range is base salary |
| Unknowns | Live status of the posting; hiring manager and reporting line; equity type and size; who owns the producer side of data contracts; work authorization terms | — |
| Contradictions | None between your pasted JD and about page; not checked against the live site | `[grounded]` the two pastes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether you're authorized to work in the US, so the gate isn't settled | `[grounded]` JD terms; background silent | Closing question on R1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years. That's specific, but nothing inspectable yet. `[generic]` 6 years is inside the report's 5–8 for "Senior" | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily": stated, nothing to inspect | `[grounded]` your background | none; a code sample would raise it |
| R4 | dbt | must_have | direct | medium | none | Built the company's dbt project, ~180 models. Specific, nothing to inspect yet | `[grounded]` your background | none; a sanitized DAG or lineage screenshot would raise it |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets "a cloud warehouse" as the JD words it | `[grounded]` your background; JD wording | none |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | It's in the responsibilities, not the listed requirements. Your dbt-on-Snowflake work carries over directly at the modelling layer. Limit: no BigQuery use. `[generic]` BigQuery differs from Snowflake in its cost model, partitioning and clustering, the dbt adapter's config and GCP permissions | `[grounded]` your "never used BigQuery"; `[generic]` platform differences | see G-row plan W1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated directly | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | "Set up our Great Expectations test suite": specific, nothing to inspect yet | `[grounded]` your background | none; an excerpt of the expectations would raise it |
| R9 | Ingestion from our app and CRM | important | unclear | none | discovery | Your background doesn't say which sources you've ingested from or how | `[grounded]` background silent | see G2 |
| R10 | The data contracts our analysts depend on | important | unclear | none | discovery | dbt and GE work sit near contracts, but you haven't said you've defined or enforced schema agreements with producers or consumers | `[grounded]` background silent; `[inferred]` closeness from the GE suite | see G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Data contracts (R10, important) | discovery | A GE suite and a dbt project; nothing about agreements with the teams producing or consuming the data | It's one of three named mandates. Evidence would move R10 from unclear to direct or adjacent | dbt model contracts or enforced schemas; GE checks that block a load when a source schema changes; an agreed spec with app engineers for event or table fields; SLAs or freshness tests analysts rely on | A contract YAML, a schema-change runbook, a sanitized GE data-docs page | `[grounded]` background silent; `[inferred]` that this moves the row |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Pipelines and orchestration, but no named sources or ingestion tools | It's the first stage of the mandate. `[generic]` CRM ingestion usually means API extraction or a managed connector | Pulling from a production app database (CDC, replicas); a CRM or HRIS API into Snowflake; Fivetran/Airbyte/custom Python extractors in Airflow | An Airflow DAG excerpt, an extractor repo | `[grounded]` background silent; `[generic]` CRM ingestion pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the reason is only that the checks were refused, not that anything was found | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay range stated, at or above the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and competitive for this seniority | `[grounded]` JD figure; `[generic]` Datawright band | Where in the range does someone with six years typically land? | noted |
| RR3 | No hiring manager or reporting line named | unknown | — | (posting names no hiring manager) | The data team's structure, centralized or embedded, is unclear | `[inferred]` from the posting's silence | Who does this role report to, and how big is the data team? | unresolved |
| RR4 | Equity unspecified | unknown | — | "plus equity" | Grant type, size and vesting are open | `[inferred]` from the posting's wording | What's the equity: options or RSUs, size, vesting, and latest valuation or strike? | unresolved |
| RR5 | Contract ownership without stated authority over upstream producers | unknown | — | "the data contracts our analysts depend on" | The role may answer for contracts without the power to stop upstream schema changes | `[inferred]` from the JD's mandate against its silence on authority | Who owns the producer side of the contracts, and can this role block an upstream schema change? | unresolved |
| RR6 | Coherent, concrete scope | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery" | The stack and requirements line up, with no bundled roles | `[grounded]` JD | What does success look like in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "built our dbt project on Snowflake (about 180 models)" and "set up our Great Expectations test suite", in your own verbs | see R4, R8 | `[grounded]` your background | pending your approval |
| P2 | State BigQuery honestly, e.g. "Snowflake in production; BigQuery not yet used" | see R6 | `[grounded]` your "never used BigQuery" | pending your approval |
| W1 | Optional: port a small slice of a dbt project to a BigQuery sandbox to narrow R6's limit | see R6 | `[generic]` that a hands-on sample narrows a platform gap | pending your approval |
| A1 | Before investing effort, open the posting from Pellucid's own careers page | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions from RR1, RR3, RR4 and RR5 word for word | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring Denver Series C" and fetched pellucidlearning.com/careers/senior-data-engineer to check your pastes are current. The host refused both calls. Would have moved the contradictions row in role reality and RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted is in hand and already fixes the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

---

I can save this as `tuesday-dossier.md` for later turns or interview prep. Just say the word.

**Upgrade menu**
- Granting web access, or opening the posting yourself from pellucidlearning.com/careers → RR1 clears and the main condition on `conditional_go` lifts.
- Your location and US work authorization → R1 settles.
- Your pay floor and any other non-negotiables → constraint rows checked against $148k–$166k.
- Answers to G1 and G2 → R10 and R9 resolve.
- A sanitized code sample or repo (dbt DAG or lineage, GE expectation suite, Airflow DAG) → R3, R4, R7 and R8 can rise from `medium` to `high`.
- The hiring manager's name → a sharper scope read and a better choice of which story to lead with.
- A deeper pass on Pellucid (funding and leadership changes, employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs, if the host allows search.

**Questions**

R1: Are you based in the US, and authorized to work there, or able to work from Denver?

G1: Have you set up schema or data agreements with the teams producing or using the data, such as dbt contracts, GE checks that stop a load, or an agreed spec with app engineers? What was yours?

G2: Which sources have you ingested from (production app databases, a CRM or other SaaS APIs), and with what tooling?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.